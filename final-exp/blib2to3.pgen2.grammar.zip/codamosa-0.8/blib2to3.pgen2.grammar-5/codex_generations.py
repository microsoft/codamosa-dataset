

# Generated at 2022-06-11 19:34:44.311252
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()

    # Set up instance attributes
    def set_up_dict(d):
        d['spam'] = 1
        return d
    g.keywords = set_up_dict(g.keywords)
    g.tokens = set_up_dict(g.tokens)
    g.symbol2label = set_up_dict(g.symbol2label)

    g.symbol2number['spam'] = 1
    g.number2symbol[1] = 'spam'
    g.labels.append(('spam', 'eggs'))
    g.labels.append(('ham', None))
    g.states.append(1)
    g.dfas[1] = (1, 2)
    g.start = 'spam'


# Generated at 2022-06-11 19:34:57.036682
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:35:09.218032
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # See issue 34251.
    from . import pgen2
    from .conv import gen_py_grammar_tables_for_version
    pgen = pgen2.PgenParserGenerator()
    g = pgen.parse_grammar("Grammar/Grammar", version="37")
    py_grammar = gen_py_grammar_tables_for_version("37", g)
    with tempfile.NamedTemporaryFile() as f:
        py_grammar.dump(f.name)
        with open(f.name, "rb") as f2:
            pickle_data = f2.read()

# Generated at 2022-06-11 19:35:12.611099
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump(b'Grammar_dump.pickle')

    assert os.path.isfile(b'Grammar_dump.pickle')
    os.remove(b'Grammar_dump.pickle')

# Generated at 2022-06-11 19:35:23.257063
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv, pgen2
    from .tokenize import untokenize

    root: Optional[Text] = None
    for path in ("/usr/local/lib/python3.5/python.grammar", "/usr/lib/python3.5/grammar.txt"):
        if os.path.exists(path):
            root = path
            break
    if not root:
        raise RuntimeError("Python grammar not found!")

    dfa = pgen2.load_grammar(root)
    g = conv.dfa2grammar(dfa, "root")
    f = open("Grammar.dump-test.pkl", "wb")
    g.dump(f)
    f.close()
    g = Grammar()
    g.load("Grammar.dump-test.pkl")


# Generated at 2022-06-11 19:35:25.982872
# Unit test for method load of class Grammar
def test_Grammar_load():
    Grammar().load(__file__)


# Generated at 2022-06-11 19:35:33.603619
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'func': 272, 'name': 273, 'args': 274, 'kwonlyargs': 275, 'vararg': 276, 'kwarg': 277, 'defaults': 278, 'kw_defaults': 279}
    g.number2symbol = {272: 'func', 273: 'name', 274: 'args', 275: 'kwonlyargs', 276: 'vararg', 277: 'kwarg', 278: 'defaults', 279: 'kw_defaults'}

# Generated at 2022-06-11 19:35:41.679535
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.g = Grammar()
            self.g.symbol2number = {"a": 256, "b": 257, "c": 258}
            self.g.number2symbol = {256: "a", 257: "b", 258: "c"}
            self.g.states = [[(1, 2), (3, 4), (5, 6)], [(7, 8), (9, 10), (11, 12)]]

# Generated at 2022-06-11 19:35:45.365328
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Loads the given bytes object.
    # Used by pickletools.genops.
    # This re-compiles the grammar, so it isn't used in normal operation.
    #assert False, 'unimplimented'
    # issue: DeprecationWarning: invalid escape sequence \
    # issue: assert False, 'unimplimented'
    pass

# Generated at 2022-06-11 19:35:52.350590
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import convert

    g = Grammar()
    g.convert(convert("Grammar/Grammar.txt"))
    g.dump("Grammar/Grammar.pkl")
    g = Grammar()
    g.load("Grammar/Grammar.pkl")

    with open("Grammar/Grammar.pkl", "rb") as f:
        g.loads(f.read())

# Generated at 2022-06-11 19:35:59.116796
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('test_Grammar_dump.pkl')
    g1 = Grammar()
    g1.load('test_Grammar_dump.pkl')
    assert g == g1

# Generated at 2022-06-11 19:36:01.371448
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.NamedTemporaryFile() as tmpf:
        grammar.dump(tmpf.name)

# Generated at 2022-06-11 19:36:09.696101
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def size_of_file(f):
        # type: (Path) -> int
        return os.stat(f).st_size
    orig_file = "Grammar.pickle"
    if os.path.isfile(orig_file):
        os.remove(orig_file)
    g = Grammar()
    g.dump(orig_file)
    orig_file_size = size_of_file(orig_file)
    assert orig_file_size > 0
    g.dump(orig_file)
    assert size_of_file(orig_file) == orig_file_size

# Generated at 2022-06-11 19:36:19.597797
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a fresh grammar object
    grammar = Grammar()

    # Set the base attributes of grammar
    grammar.symbol2number = {'and': 257, 'or': 258, 'not': 259, 'in': 260}
    grammar.number2symbol = {257: 'and', 258: 'or', 259: 'not', 260: 'in'}
    grammar.states = [[(0, 1), (257, 2)], [(0, 2)], [(0, 3)]]

# Generated at 2022-06-11 19:36:31.751925
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class GrammarLoadTestCase(unittest.TestCase):
        def setUp(self):
            # Initialize an empty Grammar and dump it to a file
            g = Grammar()
            g.dump("Grammar.dump")

        def tearDown(self):
            # Remove the dumped file
            os.remove("Grammar.dump")

        def test_load_Grammar(self):
            # Make a copy of the original dumped data
            with open("Grammar.dump", "rb") as f:
                d = f.read()
            if not d:
                raise unittest.SkipTest("no data to load")

            # Load the grammar from a file
            g = Grammar()
            g.load("Grammar.dump")

            # Load the grammar from a bytes object


# Generated at 2022-06-11 19:36:38.172576
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    from io import StringIO
    import unittest
    i = StringIO()
    o = StringIO()
    print('test_Grammar_load', file=i)
    g = Grammar()
    pickle.dump(g.__dict__, o)
    g2 = Grammar()
    pickle.load(o, g2.__dict__)
    assert g.__dict__ == g2.__dict__

if __name__ == '__main__':
    test_Grammar_load()

# Generated at 2022-06-11 19:36:50.220147
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pickle
    grammar = Grammar()
    grammar.symbol2number = {'foo': 1}
    grammar.number2symbol = {2: 'bar'}
    grammar.states = [[[(0, 0)]]]
    grammar.dfas = {3: ([[(0, 0)]], {0: 0})}
    grammar.labels = [(0, 'EMPTY')]
    grammar.keywords = {'bar': 0}
    grammar.tokens = {1: 1}
    grammar.symbol2label = {'foo': 2}
    grammar.start = 256
    f = open(sys.argv[1], 'wb')
    grammar.dump(f)
    f.close()

# Generated at 2022-06-11 19:37:01.933855
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import py_yaml_test_grammar as py_yaml_test_grammar_module
    import copy

    rule_kwargs = {"type": str}
    py_yaml_test_grammar = py_yaml_test_grammar_module.Grammar(
        rule_class=py_yaml_test_grammar_module.Rule, rule_kwargs=rule_kwargs
    )
    py_yaml_test_grammar.symbol2number.update({'single_input': 257})
    py_yaml_test_grammar.symbol2number.update({'file_input': 258})
    py_yaml_test_grammar.symbol2number.update({'eval_input': 259})
    py_yaml_test_grammar.symbol2number.update

# Generated at 2022-06-11 19:37:03.772896
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("/tmp/.test.pickle")

# Generated at 2022-06-11 19:37:09.709240
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import StringIO

    g = Grammar()
    g.symbol2number["a"] = 1
    f = StringIO.StringIO()
    pickle.dump(g.__dict__, f)
    g.load(f)
    assert g.symbol2number == {"a": 1}


if __name__ == "__main__":
    test_Grammar_load()

    # enable 'import grammar' in __main__
    import sys

    sys.modules["grammar"] = sys.modules["pgen2.grammar"]

# Generated at 2022-06-11 19:37:19.435518
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .parse import ParseError
    from .pgen2.driver import Driver
    from .pgen2 import tokenize

    g = Grammar()
    g.load(Driver.grammar)
    t = tokenize.generate_tokens(open(__file__).readline)
    tok = [o.type for o in t]
    assert tok == [token.ENCODING, token.NEWLINE, token.NEWLINE, token.ENDMARKER]
    try:
        t.__next__()
        assert False
    except ParseError:
        pass

# Generated at 2022-06-11 19:37:29.980813
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Lib/test/grammar.txt")

# Generated at 2022-06-11 19:37:40.729949
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'sym1': 256}
    g.number2symbol = {256: 'sym1'}
    g.states = [
        [
            [(1, 2), (0, 0)],
            [(1, 3), (0, 0)],
            [(1, 4), (0, 0)],
            [(1, 5), (0, 0)],
            [(1, 6), (0, 0)],
            [(1, 7), (0, 0)]
        ]
    ]
    g.dfas = {256: (g.states[0], {1: 1})}
    g.labels = [(1, 'l1')]
    g.keywords = {'k1': 1}
    g.tokens = {1: 1}
   

# Generated at 2022-06-11 19:37:44.201035
# Unit test for method load of class Grammar
def test_Grammar_load():
    from lib2to3.pgen2 import driver
    g = driver.load_grammar("Grammar.txt", "Grammar.pickle")

# Generated at 2022-06-11 19:37:51.000056
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys

    filename = "data/test_dump.pkl"
    g = Grammar()
    g.dump(filename)
    with open(filename, "rb") as f:
        size = len(f.read())
    if size != 65:
        print("test failed: size", size)
        sys.exit(1)
    else:
        os.remove(filename)
    return True

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:37:53.665291
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump("dump.pkl")
    gram.load("dump.pkl")
    gram.report()



# Generated at 2022-06-11 19:37:54.784749
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert True


# Generated at 2022-06-11 19:37:58.926651
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen

    g = Grammar()
    g.dump("Grammar.dump")
    g = Grammar()
    g.load("Grammar.dump")
    g.report()

    f = pgen.generate_grammar()
    g = Grammar()
    g.loads(f)
    g.report()

# Generated at 2022-06-11 19:38:10.337182
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'a': 10, 'b': 11, 'c': 12}
    grammar.states = [ [(1, 0), (2, 1)], [(3, 2)], [], [(0, 3)]]
    grammar.dump("./grammar.pickle")
    with open("./grammar.pickle", "rb") as f:
        new_grammar = pickle.load(f)
    assert new_grammar == {'symbol2number': {'a': 10, 'b': 11, 'c': 12},
                           'states': [[(1, 0), (2, 1)], [(3, 2)], [], [(0, 3)]]}
    os.remove("grammar.pickle")


# Generated at 2022-06-11 19:38:15.550684
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = r"D:\GitHub\MacroHard\python\lib\grammar\Grammar.pickle"
    grammar = Grammar()
    grammar.load(filename)
    print(grammar.report())


# Generated at 2022-06-11 19:38:29.723981
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import grammar
    import pickle
    import pytree

    # Make an empty grammar object
    g = grammar.Grammar()

    # Dump the empty grammar to a temp file
    filename = "tst_empty_g.pickle"
    g.dump(filename)

    # Load the empty grammar from the temp file
    tst_g = pickle.load(open(filename, "rb"))

    # Reload the grammar, re-pickling it to a different filename
    filename_new = "tst_empty_g_new.pickle"
    tst_g.dump(filename_new)

    # Reload the grammar, re-pickling it to a different filename -
    # this time using loads() rather than dump()
    tst_g2 = pickle.loads(open(filename_new, "rb").read())

   

# Generated at 2022-06-11 19:38:42.635195
# Unit test for method dump of class Grammar

# Generated at 2022-06-11 19:38:49.137221
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar"""
    import sys
    import pickle

    class C:
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

    pickled_g = pickle.dumps({'foo': 'x', 'bar': 'y'},
                             pickle.HIGHEST_PROTOCOL)

    g = C(1, 2)
    g.load(sys.stdin)
    g.loads(pickled_g)

# Generated at 2022-06-11 19:38:51.532727
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__import__("importlib").util.find_spec("typed_ast").origin.replace(".pyc", ".pkl"))
    print(g)

# Generated at 2022-06-11 19:38:58.004187
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Testing Grammar.load()
    """
    g = Grammar()
    g.number2symbol = {256: 'foo', 257: 'bar'}
    g.start = 256
    g.dump('_pgen_test.pickle')
    g2 = Grammar()
    g2.load('_pgen_test.pickle')
    assert g == g2

# Generated at 2022-06-11 19:39:00.114793
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar is not None


# Generated at 2022-06-11 19:39:07.470919
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import py_compile
    grammar = Grammar()
    fname = (
        os.path.dirname(os.path.abspath(py_compile.__file__))
        + os.path.sep
        + "grammar3.6.pickle"
    )
    grammar.load(fname)

    grammar.async_keywords = True
    for i in range(len(grammar.labels)):
        if grammar.labels[i] == (1, "async"):
            grammar.labels[i] = (1, "async_perm")
            break
    newf = "grammar3.6" + sys.version[0:3] + ".pickle"

    grammar.dump(newf)

# Generated at 2022-06-11 19:39:15.623913
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump()"""
    import sys
    import io
    import types

    # create a Grammar object
    g = Grammar()
    g.keywords = {'if': 1, 'else': 2}
    g.start = 4

    # dump the object
    output = io.StringIO()
    g.dump(output)
    data = output.getvalue()
    output.close()

    # create a new object and load it
    ng = Grammar()
    if sys.version_info[0] == 2:
        data = types.CodeType(0, data, 0, False, False, False, '', '', 0, '')
        ng.loads(data)
    else:
        ng.loads(data.encode())
    assert ng.keywords == g.keywords

# Generated at 2022-06-11 19:39:21.274657
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    fname = 'tmp'
    res1 = os.path.isfile(fname)
    g.dump(fname)
    res2 = os.path.isfile(fname)
    os.remove(fname)
    res3 = os.path.isfile(fname)
    assert res1 == False and res2 == True and res3 == False

# Generated at 2022-06-11 19:39:30.606289
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import os
    from test.support import run_unittest, captured_stdout
    from . import genericset

    class GrammarLoaderTestCase(unittest.TestCase):

        def setUp(self):
            self.grammar = Grammar()
            self.filename = "grammar.pickle"

        def tearDown(self):
            if os.path.exists(self.filename):
                os.remove(self.filename)

        def test_load(self):
            self.grammar.dump(self.filename)
            grammar = Grammar()
            grammar.load(self.filename)
            self.assertEqual(self.grammar, grammar)


# Generated at 2022-06-11 19:39:40.859263
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    # Note that this is a relative path.
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    return grammar

if __name__ == "__main__":
    grammar = test_Grammar_load()
    grammar.report()

# Generated at 2022-06-11 19:39:43.756990
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "test_Grammar_dump.test"

    grammar.dump(filename)


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:39:50.905653
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "this is not a filename"
    g = Grammar()
    try:
        g.load(filename) # no exception
    except:
        assert False, "load should accept any string"
    with open(filename, 'w') as f:
        f.write("garbage")
    try:
        g.load(filename) # no exception
    except:
        assert False, "load should accept existing file"

# Generated at 2022-06-11 19:39:54.589783
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    assert g.states[0][0] == (257, 1)

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:39:57.417891
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "dump"
    g = Grammar()
    g.dump(filename)
    f = open(filename, "rb")
    assert type(pickle.load(f)) is dict


# Generated at 2022-06-11 19:40:09.173326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("data_files/Grammar.dump")
    assert os.path.isfile("data_files/Grammar.dump")

    # load the file and verify the date
    g.load("data_files/Grammar.dump")
    assert g.symbol2label == {}

# Generated at 2022-06-11 19:40:15.750566
# Unit test for method load of class Grammar
def test_Grammar_load():
    import py_grammar
    g1 = py_grammar.PyGrammar()
    g1.symbol2number["foo"] = 5
    g1.dump("/tmp/py.pgen")
    g2 = py_grammar.PyGrammar()
    g2.load("/tmp/py.pgen")
    assert g1.symbol2number == g2.symbol2number

# Generated at 2022-06-11 19:40:16.777245
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass

# Generated at 2022-06-11 19:40:21.190923
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            grammar = Grammar()
            grammar.load(os.path.join(
                os.path.dirname(os.path.dirname(__file__)),
                "Grammar.txt"
            ))

    unittest.main(exit=False, verbosity=2)

# Generated at 2022-06-11 19:40:30.464665
# Unit test for method load of class Grammar
def test_Grammar_load():
    # verify that all of the instance variables are set to the
    # expected value
    grammar = Grammar()
    grammar.load('data/Grammar.pkl')

# Generated at 2022-06-11 19:40:46.646875
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    import os
    import sys
    import pickle

    interactive = sys.flags.interactive
    sys.flags.interactive = False
    try:
        g = Grammar()
        g.start = 10
        (fd, name) = tempfile.mkstemp()
        g.dump(name)
        del g
        g = Grammar()
        g.load(name)
        assert g.start == 10
        os.remove(name)
    finally:
        sys.flags.interactive = interactive

# Generated at 2022-06-11 19:40:58.128426
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TG(Grammar):
        pass
    tg = TG()
    tg.states = [1, 2, 3]
    tg.keywords = {'one':1, 'two':2}
    tg.symbol2label = {'one':1, 'two':2}
    tg.tokens = {1:1, 2:2}
    tg.symbol2number = {'one':1, 'two':2}
    tg.dfas = {1:[1, 2], 2:[1, 2]}
    tg.labels = [1, 2]
    tg.number2symbol = {1:'one', 2:'two'}
    tg.start = 3
    tg.async_keywords = True

# Generated at 2022-06-11 19:41:00.797800
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("filename")

# Generated at 2022-06-11 19:41:06.828195
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .conv import convert_grammar

    with open(pgen2.grammar_file, "rb") as f:
        input = f.read()

    d = convert_grammar(input)
    g = pgen2.Grammar(d)

    tmpfile = tempfile.TemporaryFile()
    g.dump(tmpfile)

    tmpfile.seek(0)

    g2 = pgen2.Grammar()
    g2.load(tmpfile)

# Generated at 2022-06-11 19:41:16.227764
# Unit test for method load of class Grammar
def test_Grammar_load():
    class FakeClass1:
        def __init__(self):
            self.symbol2number = {}
            self.number2symbol = {}
            self.states = []
            self.dfas = {}
            self.labels = []
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256
            self.async_keywords = False

        def _update(self, attrs: Dict[str, Any]) -> None:
            for k, v in attrs.items():
                setattr(self, k, v)

        def load(self, filename: Path) -> None:
            """Load the grammar tables from a pickle file."""
            with open(filename, "rb") as f:
                d = pickle.load(f)

# Generated at 2022-06-11 19:41:19.856260
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pgen2.pgen
    g = pgen2.pgen.Grammar()
    g.start = 0x3040
    with open(sys.argv[1], 'wb') as f:
        g.dump(f)
    with open(sys.argv[1], 'rb') as f:
        g.load(f)
    g.report()

# Generated at 2022-06-11 19:41:29.333311
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test dumping and loading of Grammar object
    g = Grammar()
    g.dump(filename="test_Grammar_dump.pickle")
    g2 = Grammar()
    g2.load(filename="test_Grammar_dump.pickle")
    assert g.number2symbol == g2.number2symbol
    assert g.dfas == g2.dfas
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label
    assert g.labels == g2.labels
    assert g.states == g2.states
    assert g.start == g2.start
    assert g.async_keywords == g2.async_keywords

# Generated at 2022-06-11 19:41:30.764124
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("foo.pickle")

# Generated at 2022-06-11 19:41:39.973108
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar."""

    g = Grammar()
    import parse
    g.number2symbol[0] = ""
    g.states = [[[(0,0)]], [[(0,1)]]]
    g.dfas = {0x0100:[0, {0:1}]}
    g.labels.append((0,""))
    g.labels.append((0,""))
    g.tokens = {0:1}
    g.keywords = {"if":1}

    # Create a temporary file for testing.
    (fh, filename) = tempfile.mkstemp()
    os.close(fh)


# Generated at 2022-06-11 19:41:49.343711
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test grammar in a state before any subsequent grammar files are loaded
    grammar_file = os.path.join(os.path.dirname(__file__), "..", "Grammar.pkl")
    with open(grammar_file, "rb") as f:
        dump1 = f.read()

    # Test grammar with the grammar files Grammar/Grammar and Grammar/Grammar3
    # loaded.
    from .pgen2.pgen import generate_grammar
    grammar = generate_grammar()
    with tempfile.TemporaryFile() as f:
        grammar.dump(f)
        f.seek(0)
        dump2 = f.read()

    # Must be consistent with the dump method.
    assert dump1 == dump2

# Generated at 2022-06-11 19:42:02.315901
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    grammar = Grammar()
    grammar.load(filename)
    assert grammar.symbol2number['if_stmt'] == 307
    assert grammar.dfas[307][0][1] == [(293, 2), (309, 8), (322, 4), (0, 4)]
    assert grammar.labels[1] == (1, None)
    assert grammar.start == 256



# Generated at 2022-06-11 19:42:06.060630
# Unit test for method load of class Grammar
def test_Grammar_load():
    class GrammarA(Grammar):
        def __init__(self):
            self.a = 1
    a = GrammarA()
    assert a.loads(pickle.dumps(a)) is None


# Generated at 2022-06-11 19:42:09.072057
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    g = Grammar()
    g.dump("/tmp/foobar.pkl")
    h = Grammar()
    h.load("/tmp/foobar.pkl")
    assert h.keywords == g.keywords

# Generated at 2022-06-11 19:42:16.023200
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert len(g.symbol2number) == 0
    assert len(g.number2symbol) == 0
    assert len(g.states) == 0
    assert len(g.dfas) == 0
    assert len(g.labels) == 1
    assert len(g.keywords) == 0
    assert len(g.tokens) == 0
    assert len(g.symbol2label) == 0
    assert g.start is None
    assert not g.async_keywords
    g.symbol2number['1'] = 1
    g.number2symbol[1] = '1'
    g.states.append([])
    g.dfas[1] = (['1'],{})
    g.labels.append(('1', '1'))
   

# Generated at 2022-06-11 19:42:21.556183
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class C(Grammar):
        def __init__(self, a):
            self.a = a
    c = C(1)
    c.dump('/tmp/r')
    assert os.path.exists('/tmp/r')
    os.remove('/tmp/r')
    assert not os.path.exists('/tmp/r')


# Generated at 2022-06-11 19:42:30.341215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"foo": 0, "bar": 1}
    g.number2symbol = {0: "foo", 1: "bar"}
    g.states = []
    g.dfas = {}
    g.labels = [(0, "EMPTY")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256

    with tempfile.NamedTemporaryFile() as f:
        g.dump(f)
        f.seek(0)

# Generated at 2022-06-11 19:42:41.704427
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import sys
    import os


    class Grammar_dump_TestCase(unittest.TestCase):
        def setUp(self):
            self.g = Grammar()
            self.g.symbol2number["foo"] = 1
            self.g.symbol2number["bar"] = 2
            dfa0 = [
                [(1, 0), (2, 1)],
                [(0, 0)],
            ]
            dfa1 = [
                [(1, 1), (2, 2)],
                [(0, 1)],
            ]
            self.g.states = [dfa0, dfa1]

# Generated at 2022-06-11 19:42:50.911441
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import tempfile
    import tempfile
    import os, os.path
    data = dict(a1=1, a2="2")

    class TestCase(unittest.TestCase):
        def test(self):
            g = Grammar()
            fp = tempfile.NamedTemporaryFile(mode="wb")
            pickle.dump(data, fp)
            fp.close()
            g.load(fp.name)
            self.assertEqual(g.a1, data["a1"])
            self.assertEqual(g.a2, data["a2"])

            # Bug #815491
            # Issue: load calls pickle.load(fp) which closes fp
            # Hence need to reopen fp
            fp = open(fp.name, "rb")

# Generated at 2022-06-11 19:42:55.864173
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    # create a pickle file
    g.report()
    g.dump("Grammar.pickle")
    # load from the pickle file
    g = Grammar()
    g.load("Grammar.pickle")
    g.report()

# Generated at 2022-06-11 19:43:00.559255
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    from .conv import convert

    # This string is copied from the Python 3.7.3 grammar file.

# Generated at 2022-06-11 19:43:16.315836
# Unit test for method dump of class Grammar
def test_Grammar_dump():  # pragma: no cover
    import sys
    from . import pgen, tokenize

    def print_grammar_tables(module, file=sys.stdout) -> None:
        """
        Print the grammar and token tables from a pgen parse module.
        """
        p = pgen.ParserGenerator(module)
        g = p.grammar
        g.report()
        print()
        for t in tokenize.tok_name:
            print(t, tokenize.tok_name[t])
        print()
        print(len(tokenize.tok_name), "tokens")
        print(len(g.symbol2number), "symbols")
        print(len(g.labels), "labels")
        print(len(g.states), "states")

# Generated at 2022-06-11 19:43:27.656735
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import pytree

    import sys
    import marshal
    import tempfile
    import unittest
    import shutil

    # FIXME: for now, don't run the unit test if we can't import
    # the pgen2 driver.
    # FIXME: for now, don't run the unit test if it's not Python 3.
    if sys.version_info[:2] < (3, 0):
        return

    class DriverTC(unittest.TestCase):

        def setUp(self) -> None:
            self.tempdir = tempfile.mkdtemp()
            self.pickle_file = os.path.join(self.tempdir, "Grammar.pickle")


# Generated at 2022-06-11 19:43:38.243271
# Unit test for method load of class Grammar
def test_Grammar_load():
    class MyGrammar(Grammar):
        def __init__(self) -> None:
            pass

    g = MyGrammar()
    assert not g.symbol2number
    assert not g.number2symbol
    assert not g.states
    assert not g.dfas
    assert g.labels == [(0, "EMPTY")]
    assert not g.keywords
    assert not g.tokens
    assert not g.symbol2label
    assert g.start == 256
    assert not g.async_keywords
    g._update({"a": 1})
    assert g.a == 1
    g.load(os.path.join(os.path.dirname(__file__), "Python.pkl"))
    assert g.symbol2number
    assert g.number2symbol


# Generated at 2022-06-11 19:43:48.295503
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_file = os.path.join(os.path.dirname(__file__), 'Grammar.dump')
    grammar = Grammar()
    grammar.load(test_file)
    assert grammar.tokens[1] == 1
    assert grammar.tokens[2] == 2
    assert grammar.tokens[3] == 3
    assert grammar.keywords['foo'] == 4
    assert grammar.symbol2label['bar'] == 5
    assert grammar.labels[5] == (256, 'bar')

    assert grammar.symbol2number['BAR'] == 256
    assert grammar.symbol2label['BAR'] == 5
    assert grammar.dfas[256][0][1][1] == 1
    assert grammar.dfas[256][0][2][0] == 6

# Generated at 2022-06-11 19:43:58.142711
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import sys
    import parser

    class Grammar1_testClass(unittest.TestCase):

        class TestGrammar(Grammar):

            def __init__(self) -> None:
                Grammar.__init__(self)
                self.symbol2number = {"start": 0}
                self.number2symbol = {0: "start"}
                self.dfas = {0: ([[(0, 0)]], {0: 0})}
                self.keywords = {}
                self.tokens = {}
                self.labels = [(0, "EMPTY")]
                self.symbol2label = {}
                self.start = 0

        def test_1(self) -> None:
            a = self.TestGrammar()
            b = Grammar()
           

# Generated at 2022-06-11 19:44:04.416296
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import conv
    from . import pgen2
    from .pgen2.parse import generate_grammar_tables

    filename = "Grammar.pkl"
    g = Grammar()
    g.load(filename)
    grammar = pgen2.Driver(
        conv.convert_grammar(g), "<unknown>", lookup_function="__import__"
    ).grammar()
    generate_grammar_tables(grammar, filename)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:44:07.315421
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump(tempfile.mktemp(text=True))


# Generated at 2022-06-11 19:44:15.823589
# Unit test for method load of class Grammar
def test_Grammar_load():
    def graph(states: DFA) -> List[List[int]]:
        return list(map(lambda state: sorted(x[1] for x in state), states))
    g = Grammar()
    g.load("../pgen2/Grammar.pickle")
    # DFAs for tokens and start symbol
    print("token DFAs")
    for n in range(256):
        print("DFA for", token.tok_name[n], graph(g.states[g.dfas[n][0]]))
    print("start symbol DFA")
    print("DFA for", _reverse_symbol_lookup(g, g.start), graph(g.states[g.dfas[g.start][0]]))
    # Keywords
    print("keywords")

# Generated at 2022-06-11 19:44:23.986057
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    pytype: disable=module-attr
    """
    import inspect
    import tempfile
    import pickle
    from . import grammar

    g = grammar.Grammar()
    g.symbol2number["foo"] = 1
    g.number2symbol[2] = "bar"
    g.states = []
    g.dfas = {}
    g.labels = [(1, None), (2, "foo"), (3, "bar")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256

    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        g.dump(f.name)
        g_loaded = pickle.load(f)


# Generated at 2022-06-11 19:44:33.795870
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tokenize
    class Test_Grammar_dump(unittest.TestCase):
        def test_it(self):
            grammar = Grammar()
            test = "[1,2,3]"
            with tokenize.StringIO(test) as test_file:
                token_list = list(tokenize.tokenize(test_file.readline))
                for token in token_list:
                    grammar.tokens[token.type] = token.type
            with tokenize.StringIO(test) as test_file:
                grammar.tokens[0] = 0
                token_list = list(tokenize.tokenize(test_file.readline))
                grammar.labels = [[ttok.type, ttok.string] for ttok in token_list]
            grammar.number