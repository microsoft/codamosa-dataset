

# Generated at 2022-06-11 19:34:42.310350
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Pickle the Grammar object
    filename = 'test.pickle'

    # Create a dummy pgen output
    symbol2number = {'A': 256, 'B': 258}
    number2symbol = {256: 'A', 258: 'B'}
    states = [[[(258, 0), (0, 1)]]]
    dfas = {258: ([[(258, 0), (0, 1)]], {258: 1})}
    labels = [(0, 'EMPTY'), (258, None)]
    keywords = {}
    tokens = {}
    symbol2label = {'A': 256, 'B': 258}
    start = 256

    gr = Grammar()
    gr.symbol2number = symbol2number
    gr.number2symbol = number2symbol
    gr.states = states

# Generated at 2022-06-11 19:34:49.135855
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Issue #43749: check Grammar dump create a temporary file with
    # correct name in the same directory as the target file.
    tmp_dir = tempfile.TemporaryDirectory()
    try:
        grammar = Grammar()
        grammar.dump(os.path.join(tmp_dir.name, "grammar.dat"))
    finally:
        tmp_dir.cleanup()

# Generated at 2022-06-11 19:34:49.620998
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-11 19:34:59.486850
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pgen2.token

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            # Test dump/load of empty grammar
            g = Grammar()
            with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
                g.dump(f.name)
            g2 = Grammar()
            g2.load(f.name)
            self.assertIsInstance(g2, Grammar)
            os.unlink(f.name)

            # Test dump/load of small grammar
            g = Grammar()
            g.symbol2number = {"spam": 257, "eggs": 258}
            g.number2symbol = {257: "spam", 258: "eggs"}
            g.states = [[]]

# Generated at 2022-06-11 19:35:03.807320
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.start == 256
    data = pickle.dumps(grammar, pickle.HIGHEST_PROTOCOL)
    grammar.loads(data)
    assert grammar.start == 256

# Generated at 2022-06-11 19:35:07.257232
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = tempfile.mktemp()
    g = Grammar(filename)
    g.dump(filename)
    g.load(filename)


# Generated at 2022-06-11 19:35:15.446134
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {
        "expr_stmt": 256,
        "del_stmt": 257,
        "flow_stmt": 258,
        "import_stmt": 259,
        "global_stmt": 260,
        "nonlocal_stmt": 261,
        "assert_stmt": 262,
        "compound_stmt": 263,
        "async_stmt": 264,
    }

# Generated at 2022-06-11 19:35:24.113093
# Unit test for method load of class Grammar
def test_Grammar_load():
    # import pickle
    # data = (1, b"dummy_string")
    # pickled = pickle.dumps(data)
    pickled = (
        b'\x80\x03]q\x00(K\x01X\t\x00\x00\x00dummy_stringq\x01e.'
    ) # for mypyc
    g = Grammar()
    g.loads(pickled)
    # assert g.pickled == data


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()
    else:
        test_Grammar_load()
        print("-- test ok --")

# Generated at 2022-06-11 19:35:28.459022
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import parse_grammar
    from .pgen import driver

    grammar = Grammar()
    parse_grammar(grammar, driver.grammar, "file.py")
    filename = tempfile.mktemp()
    grammar.dump(filename)
    grammar.load(filename)

# Generated at 2022-06-11 19:35:37.905927
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Construct a grammar object
    grammar1 = Grammar()

    # Assign instance attributes
    grammar1.symbol2number = {'eval_input': 256, 'single_input': 256}
    grammar1.number2symbol = {256: 'eval_input', 257: 'single_input'}
    grammar1.states = [[(257, 1)], [(258, 2)]]
    grammar1.dfas = {
        257: ([(258, 2)], {258: 1}),
        258: ([], {257: 1})
    }
    grammar1.labels = [(0, "EMPTY"), (257, None), (258, None)]
    grammar1.keywords = {}
    grammar1.tokens = {258: 258}
    grammar1.symbol2label = {}
    grammar1.start = 256

# Generated at 2022-06-11 19:35:42.181421
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pkg_resources
    from .pgen2 import driver

    # Generate a parse table file.
    path = pkg_resources.resource_filename("lib2to3.pgen2", "Python.asdl")
    driver.generate_grammar(path)

# Generated at 2022-06-11 19:35:49.155486
# Unit test for method load of class Grammar
def test_Grammar_load():
    fp = tempfile.NamedTemporaryFile(delete=False)
    g = Grammar()
    g2 = Grammar()

# Generated at 2022-06-11 19:35:57.828657
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar"""
    from .conv import ConvParser
    import os.path

    fn = os.path.abspath('test_grammar.pkl')
    f = open(fn, 'wb')
    g = Grammar()
    c = ConvParser()
    try:
        c.convert(os.path.abspath('test_grammar.txt'), g)
        g.dump(f)
        f.close()
        f = open(fn, 'rb')
        a = Grammar()
        a.loads(f.read())
        f.close()
    finally:
        try:
            os.unlink(fn)
        except OSError:
            pass

# Generated at 2022-06-11 19:36:08.917767
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pgen2.grammar
    from pgen2.pgen import load_grammar
    from pgen2 import tokenize

    # The following test case is from issue #12424.

    def cmp(a,b):
        print(a)
        print(b)
        assert a == b

    old_path = sys.path
    sys.path = [os.path.dirname(pgen2.grammar.__file__)]
    try:
        p = load_grammar('Python.g')
    finally:
        sys.path = old_path
    p.dump(r'Grammar.pickle')

    p2 = Grammar()
    p2.load(r'Grammar.pickle')

    f = tokenize.StringIO("def a():\n raise")
   

# Generated at 2022-06-11 19:36:11.747889
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "Grammar_dump.tmp"
    g = Grammar()
    assert os.path.isfile(filename) == False
    g.dump(filename)
    assert os.path.isfile(filename) == True
    os.remove(filename)
    assert os.path.isfile(filename) == False

# Generated at 2022-06-11 19:36:18.971044
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .compile import compile
    from .future import absolute_import

    g = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        compile(absolute_import, g, None, f.name)
    with open(f.name, "rb") as f:
        d = pickle.load(f)
    os.unlink(f.name)
    gram = Grammar()
    gram._update(d)
    assert gram.symbol2number == g.symbol2number
    assert gram.number2symbol == g.number2symbol
    assert gram.states == g.states
    assert gram.dfas == g.dfas
    assert gram.labels == g.labels
    assert gram.start == g.start
    assert gram.keywords == g.keywords


# Generated at 2022-06-11 19:36:24.446923
# Unit test for method load of class Grammar
def test_Grammar_load():
    def f(n, s):
        def g(obj):
            return obj.symbol2number[n] + len(obj.number2symbol) + len(obj.states) + obj.start

        g(Grammar().loads(s))


# Generated at 2022-06-11 19:36:27.819305
# Unit test for method load of class Grammar
def test_Grammar_load():
    p = Grammar()
    p.load(None)
    p.load(1)
    p.load(None)
    p.load(1)

# Generated at 2022-06-11 19:36:37.318804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import pickle
    import shutil
    import tempfile
    import unittest


# Generated at 2022-06-11 19:36:40.855456
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    fd, filename = tempfile.mkstemp()
    os.close(fd)
    try:
        g.dump(filename)
    finally:
        os.unlink(filename)


# Generated at 2022-06-11 19:36:45.236310
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pkl"))

# Generated at 2022-06-11 19:36:55.080207
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from importlib import util

    spec = util.find_spec("parser")
    if spec is None:
        return
    parser = spec.loader.load_module()
    assert hasattr(parser, "symtable")
    symtable = parser.symtable
    assert hasattr(symtable, "sym_name")
    sym_name = symtable.sym_name
    grammar = Grammar()
    grammar.symbol2number = {sym_name[sym]: sym for sym in sym_name}
    grammar.number2symbol = {sym: sym_name[sym] for sym in sym_name}

    fd, filename = tempfile.mkstemp()

# Generated at 2022-06-11 19:37:06.382632
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from pprint import pprint
    from pygram.conv.pickletools import pickle_loads
    import pygram
    g = pygram.python_grammar
    old_start = g.start
    g.start = 2345
    s = pickle.dumps(g)
    h = pygram.Grammar()
    h.loads(s)
    print(old_start, g.start)
    assert h.start == old_start

    # start was pickled as a byte string and unpickled as a byte string
    assert isinstance(h.start, bytes)

    # ok, let's try it with a real pickle
    g = pygram.python_grammar
    g.start = b's'
    s = pickle_loads(pickle.dumps(g))
    h

# Generated at 2022-06-11 19:37:18.199011
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar"""
    filename = tempfile.mktemp()

# Generated at 2022-06-11 19:37:24.126295
# Unit test for method load of class Grammar
def test_Grammar_load():
    p = Grammar()
    p.report()
    p.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    p.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:37:29.340894
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = "Grammar_dump.pkl"
    g.dump(filename)
    with open(filename, "rb") as f:
        gg = pickle.load(f)
    os.remove(filename)

    # Check type and known key in dict 
    assert(isinstance(gg, dict))
    assert("keywords" in gg)

# Generated at 2022-06-11 19:37:30.847665
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("./python2.7.grammar")

# Generated at 2022-06-11 19:37:39.925975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import tokenize
    from . import token

    filename = tempfile.mkstemp()[1]
    g = pgen2.driver.load_grammar(str(tokenize.__file__))
    g.dump(filename)

    tok = g.tokens
    tokens = {}

    for name in dir(token):
        if name.isupper():
            num = getattr(token, name)
            sym = tok.get(num)
            if sym:
                sym = g.labels[sym][1]
            tokens[name] = num, sym

    os.unlink(filename)

# Generated at 2022-06-11 19:37:43.202861
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    assert not g.number2symbol
    g.number2symbol['65'] = 'okay'
    assert g.number2symbol['65'] == 'okay'
    # Should not raise exception
    g.dump('test_grammar_dump')



# Generated at 2022-06-11 19:37:53.665591
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Provide sample grammar tables
    class FakeGrammar(Grammar):
        def __init__(self):
            self.symbol2number = {'foo': 1}
            self.number2symbol = {1: 'foo'}
            self.states = [0]
            self.dfas = {1: (0, {1: 1})}
            self.labels = [(0, 'EMPTY'),
                           (1, None)]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256
            self.async_keywords = False

    # Save the grammar tables to a temporary file
    g = FakeGrammar()
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)



# Generated at 2022-06-11 19:38:09.477719
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {'foo': 5}
    g.dump('x.out')
    g2 = Grammar()
    g2.load('x.out')
    assert g.symbol2number == g2.symbol2number
    os.unlink('x.out')

# Generated at 2022-06-11 19:38:20.588261
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2

    # Generate a pickle file with the grammar tables.
    g = pgen2.generate_grammar()
    g.dump("Grammar.pickle")

    # Load the grammar tables from the pickle file.
    g.load("Grammar.pickle")

    # Dump the grammar tables a second time.  Verify that the resulting
    # file is the same as the original file.
    from . import pgen2

    g.dump("Grammar.pickle.2")

    with open("Grammar.pickle", "rb") as f1, open("Grammar.pickle.2", "rb") as f2:
        assert f1.read() == f2.read()

    os.remove("Grammar.pickle.2")



# Generated at 2022-06-11 19:38:28.536989
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_dump"
    g = Grammar()
    g.number2symbol = {"number": "symbol"}
    g.states = [["states"]]
    g.dump(filename)

    # Load the dump file
    g = Grammar()
    g.load(filename)

    assert "number" in g.number2symbol
    assert g.number2symbol["number"] == "symbol"
    assert len(g.states) == 1
    assert g.states[0] == ["states"]

    os.remove(filename)

# Generated at 2022-06-11 19:38:30.676000
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert len(g.states) == 0
    g.load("Grammar/Grammar.pkl")
    assert len(g.states) != 0

# Generated at 2022-06-11 19:38:43.383276
# Unit test for method load of class Grammar
def test_Grammar_load():
    def verify_attr(attr, value):
        value_check = getattr(g, attr)
        if value_check != value:
            raise ValueError(f"{attr} is {value_check} but should be {value}")

    g = Grammar()
    g.load(f"{__file__[:-3]}_grammar.pkl")
    verify_attr('symbol2number', {'file_input': 258, 'eval_input': 259})
    verify_attr('number2symbol', {258: 'file_input', 259: 'eval_input'})
    verify_attr('states', [[[(1, 1), (2, 2)], [(3, 3)]]])

# Generated at 2022-06-11 19:38:50.756135
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import io
    import pkg_resources
    import pytest

    def bad_data(g):
        g.loads(b"")

    g = Grammar()
    with open(pkg_resources.resource_filename(__name__, "Grammar.pkl"), "rb") as f:
        g.loads(f.read())
    # Use pickle protocol version 3 to dump the grammar
    # (Python 3.x uses protocol version 3 by default)
    ostream = io.BytesIO()
    pickle.dump(g.__dict__, ostream, 3)
    g_reload = Grammar()
    g_reload.loads(ostream.getvalue())

    with pytest.raises(TypeError):
        bad_data(g)

# Generated at 2022-06-11 19:39:02.691431
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pgen2.parse
    g = pgen2.parse.Grammar()
    g.load(pgen2.parse.__file__[:-1])
    assert g.number2symbol[257] == 'single_input'
    assert g.number2symbol[258] == 'file_input'
    assert g.number2symbol[259] == 'eval_input'
    assert g.number2symbol[260] == 'decorator'
    assert g.number2symbol[266] == 'funcdef'
    assert g.number2symbol[273] == 'lambdef'
    assert g.keywords['True'] == 291
    assert g.keywords['None'] == 292
    assert g.keywords['False'] == 293
    assert g.keywords['print'] == 294
    assert g

# Generated at 2022-06-11 19:39:12.850856
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest

    from .pgen2 import driver

    # Test creation of grammar
    gr: Grammar = driver.load_grammar("Grammar/Grammar")
    assert isinstance(gr, Grammar)
    assert len(gr.states) == 2308
    assert len(gr.dfas) == 2347
    assert gr.labels[0] == (0, "EMPTY")
    assert gr.tokens[token.COMMENT] == 1
    assert gr.tokens[token.NL] == 2
    assert gr.async_keywords == False

    # Test saving and loading grammar
    with tempfile.TemporaryFile() as f:
        gr.dump(f)
        f.seek(0)
        gr_copy = Grammar()
        gr_copy.load(f)


# Generated at 2022-06-11 19:39:19.776806
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    from .conv import pygram
    from .pgen2 import tokenize

    g = pygram.python_grammar
    g.dump(sys.argv[1])
    g = Grammar()
    g.load(sys.argv[1])
    tokenize.tokenize(sys.stdin.readline, g)

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:39:25.213999
# Unit test for method load of class Grammar
def test_Grammar_load():  # noqa: D102
    import pickle

    g = Grammar()
    # load fails before dump
    g.load("pgen_test/test_grammar_1.pkl")
    g.dump("pgen_test/test_grammar_1.pkl")
    # load succeeds after dump
    g.load("pgen_test/test_grammar_1.pkl")
    g.load("pgen_test/test_grammar_2.pkl")

    with open("pgen_test/test_grammar.pkl", "rb") as f:
        g = Grammar()
        g.loads(pickle.load(f))

# Generated at 2022-06-11 19:39:40.815611
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pkgutil
    import pkg_resources
    from . import token

    # Get path for grammar pickle file within this directory
    path = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    # Check that the file exists
    assert os.path.isfile(path)

    # Load the grammar tables from the pickle file
    g = Grammar()
    g.load(path)


# Generated at 2022-06-11 19:39:47.043402
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pgen2

    class TestCase(unittest.TestCase):
        def test_dump(self):
            g = pgen2.generate_grammar("grammar.txt")
            g.dump("grammar.pickle")
            g2 = Grammar()
            g2.load("grammar.pickle")
            self.assertEqual(len(g2.states), len(g.states))
            self.assertEqual(len(g2.dfas), len(g.dfas))

    unittest.main(TestCase, verbosity=2)



# Generated at 2022-06-11 19:39:54.297994
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    from .pgen2 import driver

    drv = driver.Driver()
    g = drv.load_grammar("Grammar.txt")
    filename = "dump.pkl"
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g == g2, "Grammars should be equal"
    shutil.rmtree(filename)

# Generated at 2022-06-11 19:40:05.501414
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Insure that dump of Grammar class does not fail
    gr = Grammar()
    gr.dump("tmp.txt")
    with open("tmp.txt", "rb") as f:
        d = pickle.load(f)
    assert d["keywords"] == gr.keywords
    assert d["tokens"] == gr.tokens
    assert d["symbol2label"] == gr.symbol2label
    assert d["symbol2number"] == gr.symbol2number
    assert d["number2symbol"] == gr.number2symbol
    assert d["dfas"] == gr.dfas
    assert d["labels"] == gr.labels
    assert d["states"] == gr.states
    assert d["start"] == gr.start
    os.remove("tmp.txt")


# Generated at 2022-06-11 19:40:11.823076
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {"xx": 2, "yy": 4}
    g.number2symbol = {2: "xx", 4: "yy"}
    g.start = 4
    g.dump("/tmp/g.pkl")
    h = Grammar()
    h.load("/tmp/g.pkl")
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.start == h.start

# Generated at 2022-06-11 19:40:16.584460
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test load method
    """
    grammar = Grammar()
    grammar.load("./pygram/Grammar.pickle")
    assert isinstance(grammar, Grammar)
    grammar.load("./pygram/Grammar37.pickle")
    assert isinstance(grammar, Grammar)


# Generated at 2022-06-11 19:40:19.924569
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("foo")

if __name__ == "__main__":
    import sys

    g = Grammar()
    g.loads(open(sys.argv[1], "rb").read())
    g.report()

# Generated at 2022-06-11 19:40:28.242975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    from pprint import pprint
    from .pgen2 import driver
    g = driver.load_grammar("../Grammar/Grammar")
    gramart = Grammar()
    g.dump("../Grammar/Grammar.pickle")
    gramart.load("../Grammar/Grammar.pickle")
    pprint(gramart.symbol2number)
    pprint(gramart.number2symbol)
    pprint(gramart.states)
    pprint(gramart.dfas)
    pprint(gramart.labels)
    pprint(gramart.start)
    pass

# Generated at 2022-06-11 19:40:29.967179
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("./tests/Grammar_dump/Grammar_dump.pkl")

# Generated at 2022-06-11 19:40:32.947036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This function just confirms that Grammar.dump() doesn't crash.
    # It doesn't do any kind of rigorous testing.
    g = Grammar()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name
    try:
        g.dump(filename)
        # with open(filename, 'rb') as f:
        #   print(f.read())
    finally:
        os.remove(filename)

# Generated at 2022-06-11 19:40:39.418402
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    my_grammar = Grammar()
    my_grammar.dump("/dev/null")

# Generated at 2022-06-11 19:40:49.794436
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that Grammar.load reads a code object and sets things up so
    # that parse_grammar can construct the actual parser object
    from . import grammar
    from . import parse
    from .tokenize import detect_encoding, open

    # pylint: disable=unused-variable
    b'\x80'
    # Detect file encoding.
    encoding, lines = detect_encoding(open(grammar.__file__))
    # pylint: enable=unused-variable
    with open(grammar.__file__, "rb") as file:
        encoding, lines = detect_encoding(file)
    g = Grammar()
    g.load(grammar.__file__)
    p = parse.Parser(g, "<testgrammar>", flags=parse.OPT_DEBUG)
    # We do not

# Generated at 2022-06-11 19:40:55.158365
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    test Load()
    """
    x = Grammar()
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    x.dump(temp_file.name)
    temp_file.close()
    x.load(temp_file.name)
    os.unlink(temp_file.name)



# Generated at 2022-06-11 19:41:05.517268
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar."""

    filename = 'test_Grammar_dump.tbl'
    try:
        g = Grammar()
        g.dump(filename)
        del g
        g = Grammar()
        g.load(filename)
    finally:
        try:
            os.remove(filename)
        except OSError:
            pass

    def check(name: str, ref: Any) -> None:
        """Check that an attribute of the grammar as expected."""
        val = getattr(g, name)
        assert val == ref, "Incorrect value for Grammar.{}:\nExpected:\n{}\nFound:\n{}".format(
            name, repr(ref), repr(val)
        )

    check("async_keywords", False)
    check

# Generated at 2022-06-11 19:41:15.923436
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import sys
    import unittest
    from shutil import copyfile, rmtree
    from test.test_unparse import testdir

    # Create a dummy grammar
    g = Grammar()
    g.symbol2number = {'b':1, 'a':2}
    g.number2symbol = {1:'b', 2:'a'}
    g.states = [[(0, 1), (1, 2)], [(1, 2), (2, 3)], [(0, 1)]]
    g.dfas = {3: (1, {2: 1}), 1: (0, {1: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, 'a'), (1, None), (0, 'EMPTY')]
    g.keywords

# Generated at 2022-06-11 19:41:25.534338
# Unit test for method load of class Grammar
def test_Grammar_load():
    from io import BytesIO
    from . import pickle as py_pickle
    from . import pgen

    p = py_pickle._Pickler(BytesIO(), protocol=py_pickle.HIGHEST_PROTOCOL)
    g = Grammar()
    g.loads(b"")
    g.load(r"Python37\Grammar.txt")
    g.dump(r"Python37\GrammarDump.txt")
    p.dump(Grammar())

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:41:30.814136
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen
    from .pgen2 import tokenize

    p = pgen.PgenParser(opmap, debug=True)
    p.parse(tokenize.generate_tokens(open("Grammar.txt").readline), "Grammar.txt")
    g = p.parsing_tables

    s = pickle.dumps(g, pickle.HIGHEST_PROTOCOL)

    g2 = Grammar()
    g2.loads(s)
    g2.report()

    assert g == g2

# Generated at 2022-06-11 19:41:33.415611
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = 'python/Grammar'
    grammar = Grammar()
    grammar.load(filename)


if __name__ == "__main__":
    import unittest

    # This will run any tests that aren't marked @skip
    unittest.main(verbosity=1, exit=False)

# Generated at 2022-06-11 19:41:36.410315
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("error.pickle")
    grammar.load("error.pickle")
    grammar.report()

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:41:40.941449
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest

    src = """
    x = 1
    y = 2
    """.strip()

    with tempfile.TemporaryFile() as tmp:
        with pytest.warns(DeprecationWarning):
            Grammar().dump(tmp)

# Generated at 2022-06-11 19:41:46.509107
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load('Grammar.txt')
    gr.report()

# Generated at 2022-06-11 19:41:52.454284
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "test_Grammar_dump.pkl"
    grammar = Grammar()
    try:
        os.unlink(filename)
    except FileNotFoundError:
        pass
    grammar.dump(filename)
    assert os.path.exists(filename)
    os.unlink(filename)


# Generated at 2022-06-11 19:41:55.220964
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    d = g.__getstate__()
    data = pickle.dumps(d)
    g.loads(data)
    assert data == pickle.dumps(g.__getstate__())


# Generated at 2022-06-11 19:41:59.836180
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    grammar = driver.load_grammar("Python.asdl")
    grammar.dump("Python3.3.gram")

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:42:09.891109
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    def test(source: bytes) -> None:
        mod = driver.load_grammar(source)
        state = mod.grammar.states
        assert state[0][0][0][0] == 0
        assert state[-1][0][0][1] == state[-1][1][0][1] == len(state)

    test(b"")
    test(driver.grammar_header)


if __name__ == "__main__":
    import sys
    if sys.argv[1:]:
        g = Grammar()
        g.load(sys.argv[1])
        g.report()

# Generated at 2022-06-11 19:42:14.022440
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestParser:
        def __init__(self):
            self.get_grammar = Grammar()

    p = TestParser()
    p.get_grammar.loads(pickle.dumps({'__module__': '__builtin__'}))
    p.get_grammar.load("./test/test_grammar.pkl")

test_Grammar_load()

# Generated at 2022-06-11 19:42:25.538276
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    def file_handler(filename):
        assert filename == os.path.join(
            os.path.dirname(__file__), "../../Grammar.txt"
        )


# Generated at 2022-06-11 19:42:26.100352
# Unit test for method dump of class Grammar
def test_Grammar_dump(): pass  # For now

# Generated at 2022-06-11 19:42:29.773879
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    s = pickle.dumps(({'a': 1, 'b': 2},), pickle.HIGHEST_PROTOCOL)
    g.loads(s)
    assert g.dfas == {'a': 1, 'b': 2}


# Generated at 2022-06-11 19:42:41.452640
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:42:52.044929
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Function to unit test Grammar.dump()."""
    g = Grammar()
    g.tokens = {1:1, 2:2}
    g.dump("/tmp/foo.pickle")


# Generated at 2022-06-11 19:43:01.542192
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-11 19:43:04.380547
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {'foo': 256}
    grammar.dump("dummy-filename")

# Generated at 2022-06-11 19:43:06.798905
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock
    g = Grammar()
    g.dump(unittest.mock.Mock())



# Generated at 2022-06-11 19:43:15.710545
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Make a test grammar.
    gram = Grammar()
    gram.symbol2number = dict(A=257, B=258)
    gram.number2symbol = dict(zip(gram.symbol2number.values(), gram.symbol2number.keys()))
    gram.states = [[(1, 2), (3, 4), (0, 4)], [(0, 2)]]
    gram.dfas = {257: (0, {'a': 1, 'b': 1}), 258: (1, {'c': 1, 'd': 1})}
    gram.labels = [(0, 'EMPTY'), (257, None), (258, None), (1, 'a'), (2, 'b'), (3, 'c'), (4, 'd')]
    gram.keywords = dict(b=2)


# Generated at 2022-06-11 19:43:19.546774
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    from io import BytesIO  # python 3

    g = Grammar()
    out = BytesIO()
    g.dump(out)
    g.loads(out.getvalue())

# Generated at 2022-06-11 19:43:27.439378
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    for k, v in opmap.items():
        g.tokens[v] = v
        g.keywords[k] = v
    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)
    with open(f.name, "rb") as f:
        new_g = Grammar()
        new_g.loads(f.read())
    assert new_g.tokens == g.tokens
    assert new_g.keywords == g.keywords


del opmap_raw

# Generated at 2022-06-11 19:43:38.155366
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump."""
    import os
    import shutil
    from pytype import load_pytd
    from pytype.pyc import load_grammar

    for pytd_path, g_path in [
        ("pytype/tests/data/python/grammar.pytd", "build/lib2to3/Grammar.txt")
    ]:
        with load_pytd.TempInput(pytd_path) as td:
            g = load_grammar.get(td, pytd_path)
        path = os.path.join(os.path.dirname(__file__), "temp_grammar.txt")
        g.dump(path)
        with open(path, "rb") as f:
            new = f.read()

# Generated at 2022-06-11 19:43:48.293881
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump("gramdump.pkl")
    gram2 = Grammar()
    gram2.load("gramdump.pkl")
    gram3 = gram.copy()
    assert gram.labels == gram2.labels
    assert gram2.labels == gram3.labels
    assert gram.symbol2number == gram2.symbol2number
    assert gram2.symbol2number == gram3.symbol2number
    assert gram.number2symbol == gram2.number2symbol
    assert gram2.number2symbol == gram3.number2symbol
    assert gram.states == gram2.states
    assert gram2.states == gram3.states
    assert gram.dfas == gram2.dfas
    assert gram2.dfas == gram3.dfas
    assert gram

# Generated at 2022-06-11 19:43:58.143215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    from .pygram import python_grammar_no_print_statement
    g = python_grammar_no_print_statement

    f = io.BytesIO()
    g.dump(f)
    f.seek(0)
    g1 = pickle.load(f)
    assert g1.symbol2number == g.symbol2number
    assert g1.number2symbol == g.number2symbol
    assert g1.keywords == g.keywords
    assert g1.tokens == g.tokens
    assert g1.symbol2label == g.symbol2label
    assert g1.labels == g.labels
    assert g1.start == g.start
    assert g1.async_keywords == g.async_keywords


# Generated at 2022-06-11 19:44:11.454308
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"a": 0, "b": 1, "c": 2}
    g.number2symbol = {"0": "a", "1": "b", "2": "c"}
    g.states = [DFA([(0, 1), (2, 3)]), DFA([(4, 5)])]
    g.dfas = {
        8: (DFA([(6, 7)]), {1: 1, 2: 1}),
        0: (DFA([(1, 2), (0, 2)]), {0: 1}),
        1: (DFA([(1, 2), (0, 2)]), {1: 1}),
    }

# Generated at 2022-06-11 19:44:16.259595
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr: Grammar
    gr = Grammar()
    gr.load('./Python/Grammar-3.0')

if __name__ == '__main__':
    gr = Grammar()
    gr.load('./Python/Grammar-3.0')

# Generated at 2022-06-11 19:44:24.141776
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create empty Grammar
    g = Grammar()
    # Test load from empty string (should fail)
    try:
        g.loads(b"")
    except pickle.UnpicklingError:
        pass
    else:
        raise AssertionError("Grammar.loads should have thrown an UnpicklingError")
    # Test load from empty dict (should succeed)
    g.loads(b"\x80\x03}q\x00.")
    # Test load from empty dict (should succeed)
    g.loads(b"\x80\x03}q\x00(adict\n.)")
    # Test load from dict with only 'symbol2number' (should succeed)

# Generated at 2022-06-11 19:44:33.863519
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os.path
    from . import pgen2

    gram = pgen2.driver.load_grammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    gram.dump(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    gram2 = Grammar()
    gram2.load(os.path.join(os.path.dirname(__file__), "Grammar.pickle"))
    assert gram.symbol2number == gram2.symbol2number
    assert gram.number2symbol == gram2.number2symbol
    assert gram.states == gram2.states
    assert gram.dfas == gram2.dfas