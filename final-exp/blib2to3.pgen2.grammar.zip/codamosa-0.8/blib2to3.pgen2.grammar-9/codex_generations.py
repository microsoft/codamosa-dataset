

# Generated at 2022-06-11 19:34:43.300531
# Unit test for method load of class Grammar
def test_Grammar_load():
    states = [
        [(1, 0)],
        [(0, 0)],
    ]
    startsymbol = 256
    keywords = {}
    symbols = {'a': 256}
    g = Grammar()
    g.start = startsymbol
    g.states = states
    g.symbol2number = symbols
    t = g.copy()
    g.dump('_pgen_test.pkl')
    t.load('_pgen_test.pkl')
    if g != t:
        raise AssertionError('load/dump not working')
    print('Grammar.load passed')
    os.remove('_pgen_test.pkl')

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:34:46.385371
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__[:-1] + "y")


# Generated at 2022-06-11 19:34:53.018940
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test of the method dump() of class Grammar of the module grammar
    # This is to test if it is possible to write a file that contains the
    # grammar tables pickled.

    test_grammar = Grammar()
    with tempfile.TemporaryFile() as f:
        test_grammar.dump(f)


# Generated at 2022-06-11 19:34:59.212664
# Unit test for method load of class Grammar
def test_Grammar_load():

    def check_Grammar_load():
        import sys
        import types
        import unittest.mock
        
        test_dict = {'a': 1, 'b': 2}
        test_pkl = pickle.dumps(test_dict)

        g = Grammar()
        
        # Test by patching keyword arguments of method _update.
        with unittest.mock.patch.object(g, '_update') as mock_update:
            g.loads(test_pkl)
            mock_update.assert_called_with(test_dict)

    check_Grammar_load()

# Generated at 2022-06-11 19:35:11.043192
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test adding to the dictionary
    import datetime
    import pytest
    import xmlrpc.server
    import xmlrpc.client

    # Make a date time |time.struct_time| object to test
    test_time = datetime.datetime(
        2003, 8, 12, 22, 5, 0, 0, datetime.timezone.utc
    ).timetuple()
    test_str = "__str__"
    test_blob = b"__blob__"
    test_int = 1234
    test_server = xmlrpc.client.ServerProxy("https://pypi.org/pypi")

    # Test values include date time objects and blob objects

# Generated at 2022-06-11 19:35:22.183529
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import importlib
    import sys

    grammar = Grammar()
    grammar.start = 257
    grammar.symbol2number = {'foo': 257, 'bar': 258}
    grammar.number2symbol = {257: 'foo', 258: 'bar'}
    grammar.states = [0, 1]
    grammar.dfas = {257: ([([64], 1)], {0: 1}), 258: ([([], 1)], {0: 1})}
    grammar.labels = [([], 1), ([], 1), ([(0, None)], 1)]
    grammar.keywords = {}
    grammar.tokens = {}
    grammar.symbol2label = {'foo': 2, 'bar': 3}
    grammar.async_keywords = False

    # dump the grammar
    tmpdir = tempfile.mk

# Generated at 2022-06-11 19:35:27.622412
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    import unittest
    from .pgen2 import driver

    class LoadTest(unittest.TestCase):

        # Unit test
        def test_load(self):
            driver.parse_grammar(sys.modules[__name__].__file__, "Grammar")

    unittest.main()

# Generated at 2022-06-11 19:35:37.497673
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:35:46.475806
# Unit test for method load of class Grammar
def test_Grammar_load():
    import difflib
    import os
    import tempfile

    grammar = Grammar()
    grammar.symbol2number = { 'Foo': 257 }
    grammar.number2symbol = { 257: 'Foo' }
    grammar.states = [[]]
    grammar.dfas = { 257: ([], { 97: 1, 98: 1 }) }
    grammar.labels = [(0, 'EMPTY')]
    grammar.keywords = { 'and': 2 }
    grammar.tokens = { 61: 3 }
    grammar.symbol2label = { 'Foo': 257 }
    grammar.start = 257

    with tempfile.NamedTemporaryFile("w+b", delete=False) as f:
        grammar.dump(f.name)
    with open(f.name, "rb") as f:
        pkl

# Generated at 2022-06-11 19:35:52.219836
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    fs = os.path.join(os.path.dirname(os.path.realpath(__file__)), "Python37.pkl")
    grammar.load(fs)
    assert grammar is not None
    assert grammar.symbol2number is not None
    assert len(grammar.symbol2number) > 0
    assert grammar.number2symbol is not None
    assert len(grammar.number2symbol) > 0
    assert grammar.states is not None
    assert len(grammar.states) > 0
    assert grammar.dfas is not None
    assert len(grammar.dfas) > 0
    assert grammar.labels is not None
    assert len(grammar.labels) > 0
    assert grammar.keywords is not None

# Generated at 2022-06-11 19:35:55.991553
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import imp, tempfile, os


# Generated at 2022-06-11 19:36:06.901461
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test the dump method by loading from the dump.
    """
    from . import conv, pgen

    pickle_file = os.path.join(os.path.dirname(__file__), 'GrammarTables.pickle')
    if not os.path.exists(pickle_file):
        print("Generating pickle file %s" % pickle_file)
        with open(pickle_file, "wb") as f:
            g = conv.Converter("Grammar.txt", "Python.asdl", "Python.gr", package="typing")
            pgen.write_tables(g, f)
    g = Grammar()
    g.load(pickle_file)
    assert g.start == 256
    assert g.keywords["False"] == 259

# Generated at 2022-06-11 19:36:15.721005
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .grammar import Grammar
    from .tokenize import generate_tokens
    import io

    class MyGrammar(Grammar):

        def __init__(self):

            Grammar.__init__(self)
            self.symbol2number = {}

# Generated at 2022-06-11 19:36:27.477761
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    g = Grammar()
    g.symbol2number = {
        "and": 2,
    }
    g.number2symbol = {
        2: "and",
    }
    g.states = [
        [
            [(0, 1), (0, 1)],
            [(0, 1), (0, 1)],
        ],
    ]
    g.dfas = {
        2: (
            [
                [(0, 1), (0, 1)],
                [(0, 1), (0, 1)],
            ],
            {
                1: 1,
            },
        ),
    }
    g.labels = [(0, "EMPTY"), (0, "EMPTY")]
    g.keywords = {
        "and": 1,
    }

# Generated at 2022-06-11 19:36:32.769601
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Initialize
    grammar = Grammar()
    filename = "test.pkl"
    # Test
    grammar.dump(filename)
    try:
        # Get object from file
        with open(filename, 'rb') as f:
            obj = pickle.load(f)
        assert obj['symbol2number'] == {}, "Object from file test.pkl is incorrect"
    finally:
        # Remove file
        os.remove(filename)

# Generated at 2022-06-11 19:36:41.540776
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:36:52.916604
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle, tempfile
    from pprint import pprint
    grammar = Grammar()
    grammar.symbol2number = {'key2': 8, 'key1': 2}
    grammar.number2symbol = {2: 'key1', 8: 'key2'}
    grammar.states = [[(0, 0)], [(0, 1)]]
    grammar.dfas = {1: ([(0, 1)], {1: 1}), 17: ([(0, 1)], {1: 1})}
    grammar.labels = [(0, 'EMPTY'), (1, None), (0, None), (3, None)]
    grammar.keywords = {'key2': 3, 'key1': 2}
    grammar.tokens = {1: 1, 3: 3}

# Generated at 2022-06-11 19:37:05.306972
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test1():
        g = Grammar()
        g.load("python2-grammar.pkl")
        assert g.symbol2number["trailer"] == 264
        assert g.symbol2number["expr_stmt"] == 282
        assert g.symbol2number["expr_stmt_nocond"] == 284
        assert g.symbol2number["compound_stmt"] == 278
        assert g.number2symbol[264] == "trailer"
        assert g.number2symbol[282] == "expr_stmt"
        assert g.number2symbol[284] == "expr_stmt_nocond"
        assert g.number2symbol[278] == "compound_stmt"

# Generated at 2022-06-11 19:37:06.707139
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # No test yet, since Grammar.dump is only used during build.
    return

# Generated at 2022-06-11 19:37:18.521476
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:37:30.825499
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {1: 'foo'}
    g.symbol2number = {'foo': 1}
    g.dfas[1] = (
        [[(0, 0)], [(0, 1)], [(1, 1)], [(6, 2)], [(2, 1)], [(6, 2)], [(0, 3)], [(0, 6)], [(0, 3)]],
        {64: 0, 1: 1, 2: 1, 4: 1, 5: 1}
    )
    g.labels = [
        (0, 'EMPTY'), (64, None), (1, None), (6, None), (2, None), (5, None)
    ]

# Generated at 2022-06-11 19:37:31.634958
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")

# Generated at 2022-06-11 19:37:41.357651
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import tempfile
    from . import tokenizer
    from . import parser

    # Generate a simple grammar to test with
    g = Grammar()
    g.symbol2number["newline"] = 256
    g.symbol2number["indent"] = 257
    g.symbol2number["dedent"] = 258
    g.symbol2number["endmarker"] = 259
    g.number2symbol = dict((g.symbol2number[k], k) for k in g.symbol2number)


# Generated at 2022-06-11 19:37:52.058535
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Testing load of Grammar class"""
    filename = os.path.abspath(os.path.join(__file__, "..", "..", "Grammar.txt"))
    grammar = Grammar()
    grammar.load(filename)
    for symbol in ["def", "async", "with", "as"]:
        assert symbol in grammar.symbol2number
    for token in [token.NAME, token.NUMBER]:
        assert token in grammar.tokens
    for keyword in ["if", "else", "elif", "except"]:
        assert keyword in grammar.keywords
    assert grammar.labels[0] == (0, "EMPTY")
    assert len(grammar.states) == 1


# Generated at 2022-06-11 19:38:00.642414
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.number2symbol = {1: '1'}
    g.symbol2number = {'1': 1}
    g.states = [{1: 'state'}]
    g.dfas = {1: 'dfa'}
    g.labels = ['label']
    g.keywords = {'keyword': 1}
    g.tokens = {1: 1}
    g.symbol2label = {'symbol': 1}
    g.start = 1
    g.async_keywords = False
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "Grammar")
        g.dump(path)
        g1 = Grammar()
        g1.load(path)
       

# Generated at 2022-06-11 19:38:11.857433
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest
    import _pickle
    g = Grammar()
    g.symbol2number = {'foo': 42}
    g.number2symbol = {42: 'foo'}
    g.states = [[(1, 2), (3, 4)], [(5, 6), (3, 8)]]
    g.dfas = {42: ([(1, 2), (3, 4)], {1: 1, 2: 1}), 43: ([(7, 8)], {8: 1})}
    g.labels = [(1, '42'), (3, None), (5, 'class'), (7, None)]
    g.keywords = {'class': 5}
    g.tokens = {42: 1}
    g.symbol2label = {'foo': 42}

# Generated at 2022-06-11 19:38:22.216160
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    # Generate dummy tables for testing
    # add a few symbols
    g.symbol2number["a"] = 256
    g.symbol2number["b"] = 257
    g.symbol2number["c"] = 258
    # each symbol is represented by a 2-state DFA
    g.dfas[256] = [[[(257, 258)], []], 256]
    g.dfas[257] = [[[(258, 259)], []], 257]
    g.dfas[258] = [[[(259, 260)], []], 258]
    g.states = [[[(257, 258)], []], [[(258, 259)], []], [[(259, 260)], []]]

# Generated at 2022-06-11 19:38:26.822978
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pkl")
    g.report()
    g.dump("Grammar.pkl.1")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:38:28.617911
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:38:31.129398
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    tbl_name = "pgen-dump-test.tbl"
    try:
        g.dump(tbl_name)
    finally:
        try:
            os.unlink(tbl_name)
        except FileNotFoundError:
            pass

# Generated at 2022-06-11 19:38:39.417692
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test dump method of Grammar class"""

    import sys
    from . import driver

    class MockedOpt:
        picklefile = "none"

    class MockedParser:
        opt = MockedOpt()

    class MockedDriver:
        parser = MockedParser()
        grammar = Grammar()

    driver = MockedDriver()
    driver.grammar.dump(filename=sys.stdout)

# Generated at 2022-06-11 19:38:49.031153
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    import pytest

    class P(pickle.Unpickler):

        # Add support for protocol 5: https://bugs.python.org/issue34665
        @classmethod
        def find_class(cls, module, name):
            if (
                module == "builtins"
                and name in ["bytes", "bytearray", "memoryview", "set", "frozenset"]
            ):
                return getattr(builtins, name)
            else:
                return pickle.Unpickler.find_class(module, name)


# Generated at 2022-06-11 19:38:51.532229
# Unit test for method load of class Grammar
def test_Grammar_load():
    # We only test if a class Grammar can be used with method load
    # i.e., this test is a mere interface test
    g = Grammar()
    g.load(__file__)

# Generated at 2022-06-11 19:39:03.117805
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()


# Generated at 2022-06-11 19:39:08.111345
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.TemporaryDirectory() as tempdir:
        fname = os.path.join(tempdir, "tempfile.pickle")
        g.dump(fname)
        g1 = Grammar()
        g1.load(fname)
    assert g == g1



# Generated at 2022-06-11 19:39:10.612856
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-11 19:39:21.046231
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    if hasattr(token, "indent"):
        grammar.start = token.indent
        grammar.tokens = {1: 200, 2: 201, 3: 202, 4: 203, 5: 204, 6: 205, 7: 206}
        grammar.keywords = {
            "async": 400,
            "await": 401,
            "asyncfor": 402,
            "asyncwith": 403,
            "asyncdef": 404,
            "True": 405,
            "False": 406,
            "None": 407,
        }

# Generated at 2022-06-11 19:39:27.356872
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import  pgen2
    g = Grammar()
    g.start = 256
    s = pickle.dumps(g)
    g.loads(s)
    try:
        g.loads(s)
    except OSError:
        pass
    else:
        print("Expected OSError while dumping again to the same filename")
    pgen2.write_grammar(g, "tmp.pickle")

# Generated at 2022-06-11 19:39:39.019164
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:39:41.995601
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    g = Grammar()
    g.load(driver.mkgrammar(token))

    g.dump(tempfile.mktemp())

# Generated at 2022-06-11 19:39:56.048343
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import io
    import pickle
    t = unittest.TestCase()
    # test empty Grammar
    g = Grammar()
    s = io.BytesIO()
    pickle.dump(g.__dict__, s)
    s.seek(0)
    h = Grammar()
    h.load(s)
    t.assertEqual(g.__dict__, h.__dict__)
    # test two-element Grammar
    d = {}
    d["symbol2number"] = {'x': 5, 'y': 7}
    d["number2symbol"] = {5: 'x', 7: 'y'}

# Generated at 2022-06-11 19:40:07.966904
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    if os.name == "java":
        return
    import unittest
    import shutil

    class GrammarTest(unittest.TestCase):
        def test_Grammar_dump(self):
            grammar = Grammar()
            grammar.async_keywords = True
            grammar.start = 257
            grammar.states = [
                [],
                [[128, 2], [129, 3], [130, 4], [131, 5]],
                [[0, 2]],
                [[0, 3]],
                [[0, 4]],
                [[0, 5]],
            ]
            grammar.tokens = {258: 1, 259: 2, 260: 3, 261: 4}

# Generated at 2022-06-11 19:40:19.218790
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import grammar
    from . import pygram
    from . import pgen2

    g = grammar.Grammar(grammar.grammar_nts, grammar_token, grammar_token.values())
    tables = pgen2.pgen(g, pygram.python_grammar_no_copy)
    tables.dump("mytables.pkl")

    tables2 = grammar.Grammar()
    tables2.load("mytables.pkl")
    tables2.report()
    tables2.dump("mytables2.pkl")

    with open("mytables.pkl", "rb") as f1, open("mytables2.pkl", "rb") as f2:
        assert f1.read() == f2.read()

    # cannot pickle a subclass

# Generated at 2022-06-11 19:40:25.027832
# Unit test for method load of class Grammar
def test_Grammar_load():
    class FakeGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"kA": 1, "kB": 2}
            self.number2symbol = {1: "kA", 2: "kB"}
            self.states = [[[(1, 1), (2, 2)]]]
            self.dfas = {1: ([[(1, 1), (2, 2)]], {1: 2}), 2: ([[(3, 3)]], {3: 2})}
            self.keywords = {"a": 1, "b": 2}
            self.tokens = {"a": 1, "b": 2}
            self.labels = [(0, "a"), (1,"b"), (2, "c")]
            self.start

# Generated at 2022-06-11 19:40:31.818883
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    path = "test_dump.pkl"
    grammar.dump(path)

    try:
        grammar.load(path)
    except IOError as e:
        # Assert dump created the file
        assert False, "Failed to open {path}.  Error: {e}".format(
            path=path, e=e
        )

    try:
        os.remove(path)
    except Exception as e:
        assert False, "Failed to delete {path}.  Error: {e}".format(
            path=path, e=e
        )

# Generated at 2022-06-11 19:40:45.261335
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert

    g = Grammar()

# Generated at 2022-06-11 19:40:48.903743
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load(os.path.join(os.path.dirname(__file__), 'Grammar.pkl'))

if __name__ == '__main__':
    import unittest as ut
    ut.main(__name__, verbosity=2, exit=False)

# Generated at 2022-06-11 19:40:59.333042
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.number2symbol = {
        257: "START",
        258: "ENDMARKER",
        259: "newline",
        260: "name",
        261: "number",
        262: "string",
        263: "N_TOKENS",
        264: "NT_OFFSET",
    }
    gr.symbol2number = {
        "START": 257,
        "ENDMARKER": 258,
        "newline": 259,
        "name": 260,
        "number": 261,
        "string": 262,
        "N_TOKENS": 263,
        "NT_OFFSET": 264,
    }
    

# Generated at 2022-06-11 19:41:09.237534
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from . import pgen
    from ._tokenize import detect_encoding, TokenInfo
    from .token import NAME, OP, NEWLINE
    from .tokenize import tokenize, prepare_user_input

    # Load pickled grammar data from testdata directory
    grammar = Grammar()
    grammar.load("Grammar.dat")

    # pgen.pgen.generate_grammar_file("Grammar.dat")
    # d = grammar.__dict__
    # del d["pgen"]
    # del d["symbol2label"]
    # with open("Grammar.dat", "wb") as f:
    #     pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)

    # Read Python code sample from testdata directory

# Generated at 2022-06-11 19:41:13.193299
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import tokenize
    from .pgen2 import driver
    from . import parse

    parser = driver.load_grammar("../Grammar/Grammar")


# Generated at 2022-06-11 19:41:28.200033
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.dat")

    print(g.number2symbol[256])
    print(g.number2symbol[258])
    print(g.number2symbol[264])
    print(g.number2symbol[265])
    print(g.number2symbol[268])
    print(g.number2symbol[269])

    print(len(g.states[0]))
    print(len(g.states[1]))
    print(len(g.states[2]))
    print(len(g.states[3]))
    print(len(g.states[4]))
    print(len(g.states[5]))
    print(len(g.states[6]))

# Generated at 2022-06-11 19:41:29.203384
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar().dump is Grammar.dump

# Generated at 2022-06-11 19:41:33.234079
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    attrs = {"a": "b"}
    grammar._update(attrs)
    assert grammar.a == attrs["a"]



# Generated at 2022-06-11 19:41:38.658328
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g1 = Grammar()
    try:
        fname = "test_ast.test_Grammar_dump.pkl"
        g.dump(fname)
    finally:
        try:
            os.unlink(fname)
        except:
            pass

if __name__ == "__main__":
    import sys

    g = Grammar()
    if len(sys.argv) > 1:
        g.load(sys.argv[1])
    else:
        g.report()

# Generated at 2022-06-11 19:41:42.929988
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    test_file_path = tempfile.mkdtemp()
    grammar.dump(test_file_path)
    grammar.start = 0
    grammar.load(test_file_path)
    assert grammar.start != 0

# Generated at 2022-06-11 19:41:46.946951
# Unit test for method load of class Grammar
def test_Grammar_load():
    def test(filename: Path) -> None:
        g = Grammar()
        g.load(filename)
        g.report()

    filename = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    test(filename)
    test(os.fspath(filename))

# Generated at 2022-06-11 19:41:56.159764
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number["symbol"] = "number"
    g.number2symbol["number"] = "symbol"
    g.states = [["state"]]
    g.dfas = [["dfas"]]
    g.labels = ["label"]
    g.start = "start"
    g.keywords = ["keywords"]
    g.tokens = ["tokens"]
    g.symbol2label = ["symbol2label"]

    temp_name = tempfile.mktemp()
    g.dump(temp_name)

    h = Grammar()
    h.load(temp_name)

    assert g.__dict__ == h.__dict__

    os.unlink(temp_name)

# Generated at 2022-06-11 19:42:06.379421
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import sys
    import unittest

    try:
        from backports.tempfile import TemporaryDirectory
    except ImportError:
        from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        fn = os.path.join(tmpdir, "python.pkl")
        with open(fn, "wb") as f:
            pickle.dump(sys.version, f, pickle.HIGHEST_PROTOCOL)

        with open(fn, "rb") as f:
            expected = pickle.load(f)

        # Grammar._load_file(fn)
        from .pgen2 import driver

        grammar = driver.load_grammar(None)  # type: ignore
        assert hasattr(grammar, "load")
        grammar.load(fn)

# Generated at 2022-06-11 19:42:14.528150
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    old_symbol2number = {'TYPE_COMMENT': 57,
                         'NAME': 256,
                         'STRING': 265}
    old_number2symbol = {256: 'NAME',
                         264: 'INDENT',
                         265: 'STRING',
                         266: 'DEDENT',
                         267: 'NEWLINE'}

# Generated at 2022-06-11 19:42:18.469317
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    assert not hasattr(gram, "start")
    gram.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert gram.start == 256

# Generated at 2022-06-11 19:42:27.132647
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    f = Grammar()
    f.dump()

# Generated at 2022-06-11 19:42:33.988146
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.symbol2number["atom"] == 256
    assert grammar.symbol2number["comp_for"] == 458
    assert len(grammar.states) == 337
    assert len(grammar.labels) == 790
    assert len(grammar.tokens) == 94

# Generated at 2022-06-11 19:42:40.771044
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create an empty Grammar object, then pickle and unpickle it
    g = Grammar()
    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        temp_file_path = f.name
    try:
        g.dump(temp_file_path)
        g2 = Grammar()
        g2.load(temp_file_path)
        assert g.__dict__ == g2.__dict__
    finally:
        os.remove(temp_file_path)

# Generated at 2022-06-11 19:42:50.370794
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    import pytest

    # Need to use a subclass to initialize the tables
    class DummyGrammar(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)
            self.symbol2number = {"a": 1}
            self.number2symbol = {1: "a"}
            self.states = [[]]
            self.dfas = {1: ([], {})}
            self.labels = [(2, 3)]
            self.keywords = {"a": 4}
            self.tokens = {5: 6}
            self.symbol2label = {"b": 7}
            self.start = 8

    # create a dummy file
    fname = "test_dump"
    open(fname, "w").close()
    assert os

# Generated at 2022-06-11 19:42:57.285660
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.pickle')
    assert g.symbol2number is not None
    assert g.number2symbol is not None
    assert g.states is not None
    assert g.dfas is not None
    assert g.labels is not None
    assert g.keywords is not None
    assert g.tokens is not None
    assert g.symbol2label is not None

# Generated at 2022-06-11 19:43:00.039522
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("tmp.pkl")
    # test grammar tables dump

# Generated at 2022-06-11 19:43:02.138734
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # XXX Implement!
    assert 0, "Unimplemented method test_Grammar_dump"


# Generated at 2022-06-11 19:43:05.512986
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), 'Grammar.pkl'))
    g.report()

# Generated at 2022-06-11 19:43:15.067480
# Unit test for method load of class Grammar
def test_Grammar_load():
    # assume that method dump is working
    fname = tempfile.mktemp(suffix=".pickle")
    g1 = Grammar()
    g1.dump(fname)
    g2 = Grammar()
    g2.load(fname)
    os.unlink(fname)
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.states == g2.states
    assert g1.dfas == g2.dfas
    assert g1.labels == g2.labels
    assert g1.start == g2.start
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2

# Generated at 2022-06-11 19:43:19.546044
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test to fail, grammar object doesn't have attribute '__dict__'
    grammar = Grammar()
    try:
        grammar.dump('grammar.pkl')
        assert False, 'Expected a ValueError'
    except ValueError:
        assert True

# Generated at 2022-06-11 19:43:31.721348
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__)
    assert g.states
    assert g.dfas
    assert g.number2symbol
    assert g.symbol2number

# Generated at 2022-06-11 19:43:32.696394
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load


# Generated at 2022-06-11 19:43:40.577359
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:43:49.411925
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dfas = {}
    gram.symbol2number = {}
    gram.number2symbol = {}
    gram.keywords = {}
    gram.tokens = {}
    gram.symbol2label = {}
    gram.labels = []
    gram.states = []
    gram.start = 256
    gram.async_keywords = False
    fd, name = tempfile.mkstemp()

# Generated at 2022-06-11 19:43:55.334495
# Unit test for method load of class Grammar
def test_Grammar_load():
    p = pickle.dumps({"states": [[[(0, 1), (3, 2), (1, 1)], [(1, 1)]]]})
    g = Grammar()
    g.loads(p)
    assert g.states == [[[(0, 1), (3, 2), (1, 1)], [(1, 1)]]], g.states

# Generated at 2022-06-11 19:44:04.418298
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile
    from .conv import convert
    from .pgen import driver

    fdir = tempfile.mkdtemp()
    fpath = os.path.join(fdir, "dump_data.py")

# Generated at 2022-06-11 19:44:07.651888
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as directory:
        grammar.dump(directory + "/grammar")

# Generated at 2022-06-11 19:44:14.697824
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # import os, shutil, sys
    if os.path.exists("Grammar"):
        shutil.rmtree("Grammar")
    os.mkdir("Grammar")
    if os.path.exists("Grammar.pickle"):
        os.remove("Grammar.pickle")
    try:
        Grammar().dump("Grammar/__init__.pickle")
    except Exception as err:
        print("unexpected error in Grammar().dump():", err)
    else:
        sys.stdout.write("passed test of method dump of class Grammar\n")

# Generated at 2022-06-11 19:44:23.328515
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .grammar import Grammar
    from .token import NAME, NUMBER, STRING, NL, NEWLINE
    from .pytokenize import tokenize

    g = Grammar()
    g.loads(grammar_pickle)
    if g.symbol2number["atom"] != 256:
        print("test_Grammar_load: failed - symbol2number")
    if g.number2symbol[0] != "EMPTY":
        print("test_Grammar_load: failed - number2symbol")
    if g.async_keywords:
        print("test_Grammar_load: failed - async_keywords")
    if g.start != 256:
        print("test_Grammar_load: failed - start")
    # the following is just a sanity check to
    # make sure the tables are of

# Generated at 2022-06-11 19:44:33.665408
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {"foo": 42}
    g.number2symbol = {42: "foo"}
    g.states = [[(42, 1)]]
    g.dfas = {42: ([[(1, 0)]], {1: 1})}
    g.labels = [(42, "none")]
    g.start = 42
    g.keywords = {"42": 42}
    g.tokens = {42: 42}
    g.symbol2label = {"42": 42}
    g.async_keywords = False

    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)