

# Generated at 2022-06-11 19:34:55.589327
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g1 = Grammar()
    g1.dump('/tmp/some_arbitary_file')

    g2 = Grammar()
    g2.load('/tmp/some_arbitary_file')

    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.states == g2.states
    assert g1.dfas == g2.dfas
    assert g1.labels == g2.labels
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.start == g2.start

# Generated at 2022-06-11 19:35:00.232323
# Unit test for method load of class Grammar
def test_Grammar_load():
    import subprocess
    import sys

    cmd = [sys.executable, "cgrammar.py", "-g", "Python.asdl", "Grammar.txt"]
    data = subprocess.check_output(cmd, universal_newlines=True)
    g = Grammar()
    g.loads(data)
    g.report()

del test_Grammar_load

if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-11 19:35:01.916459
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")

# Generated at 2022-06-11 19:35:04.576122
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    grammar.load(filename)

# Generated at 2022-06-11 19:35:14.337892
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test of method load of class Grammar, returning nothing.
    """
    s2n = {"and": 258, "not": 257}
    n2s = {257: "not", 258: "and"}
    states = [[(None, 257, 0), (None, 258, 1)], [], [(None, 0, 1)]]
    dfas = {257: (states[0], {1: 1, 58: 1}), 258: (states[1], {1: 1, 58: 1})}
    labels = [
        (0, "EMPTY"),
        (1, None),
        (58, None),
        (257, "and"),
        (258, "not"),
    ]
    start = 258
    keywords = {"and": 258, "not": 257}

# Generated at 2022-06-11 19:35:18.301073
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    def f(fn):
        g.dump(fn)
    f("file.py")
    f(b"file.py")
    f(Path("file.py"))

# Generated at 2022-06-11 19:35:20.925176
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.copy()

# Generated at 2022-06-11 19:35:30.884151
# Unit test for method load of class Grammar
def test_Grammar_load():
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        # Create a new Grammar object
        gram = Grammar()

        # Create a dictionary with Grammar attributes

# Generated at 2022-06-11 19:35:39.923551
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pickle as pickle_mod

    class SubGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {"foo": 1}
            self.number2symbol = {1: "foo"}
            self.states = [1, 2, 3]
            self.dfas = {1: 2}
            self.labels = [1, 2, 3]
            self.keywords = {1: 2}
            self.tokens = {1: 2}
            self.symbol2label = {1: 2}
            self.start = 256

    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, "test.pickle")

# Generated at 2022-06-11 19:35:40.409804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-11 19:35:55.175760
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os.path
    from types import ModuleType
    from pprint import pprint

    # Create a dummy grammar module object that can be passed as an argument
    # to the Grammar class constructor
    gram_module = ModuleType("grammar")
    gram_module.__file__ = "Grammar test file"
    # Pickle the grammar module object
    pkl = pickle.dumps(gram_module, pickle.HIGHEST_PROTOCOL)
    # Test the method load
    gram = Grammar()
    gram.loads(pkl)

    # Test attributes of the Grammar instance
    assert gram.symbol2number == {}
    assert gram.number2symbol == {}
    assert gram.states == []
    assert gram.dfas == {}
    assert gram.labels == [(0, "EMPTY")]


# Generated at 2022-06-11 19:36:05.503433
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Grammar is an abstract class, so we can't instantiate it
    # directly, but we can subclass it.
    class MyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {"A": 1}
            self.number2symbol = {1: "A"}

# Generated at 2022-06-11 19:36:10.159997
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'foo': 42}
    g.dump("pgen.out")
    g2 = Grammar()
    g2.load("pgen.out")
    assert g2.symbol2number == {'foo': 42}
    os.unlink("pgen.out")

# Generated at 2022-06-11 19:36:18.505864
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import StringIO
    import sys

    class MyGrammar(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)

            class _MockFile:
                def __init__(self) -> None:
                    self.name = "test.out"

                def write(self, text) -> None:
                    pass

                def close(self) -> None:
                    pass

            self.file = _MockFile()
            self.symbol2number = {"key": 1}
            self.number2symbol = {1: "key"}
            self.states = [0, 1]
            self.dfas = {2: 3, 4: 5}
            self.labels = [6, 7]
            self.keywords = {"key": 1}


# Generated at 2022-06-11 19:36:20.127094
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    g = Grammar()
    g.start = 0
    pickle_bytes = pickle.dumps(g)
    g2 = Grammar()
    g2.loads(pickle_bytes)

# Generated at 2022-06-11 19:36:31.914493
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    g = Grammar()
    g.symbol2number = {"$empty": 256, "root": 257}
    g.number2symbol = {256: "$empty", 257: "root"}
    g.states = [[(0, 1), (256, 1)]]
    g.dfas = {257: (g.states[0], {40: 1})}
    g.labels = [(0, "EMPTY"), (40, None)]
    g.keywords = {}
    g.tokens = {91: 2, 93: 3}
    g.symbol2label = {}
    g.start = 257

    with tempfile.NamedTemporaryFile(delete=False) as f:
        g.dump(f.name)

    h = Grammar()
    h.load(f.name)

# Generated at 2022-06-11 19:36:36.084473
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar."""
    with open("Grammar.dump.temp", "wb") as f:
        pickle.dump({}, f)
    with open("Grammar.dump.temp", "rb") as f:
        d = pickle.load(f)
    assert d == {}

# Generated at 2022-06-11 19:36:43.134908
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    gr = driver.load_grammar("Grammar/Grammar")

    fname = tempfile.mktemp()
    try:
        gr.dump(fname)
        gr2 = Grammar()
        gr2.load(fname)
        assert gr.symbol2number == gr2.symbol2number
        assert gr.number2symbol == gr2.number2symbol
        assert gr.states == gr2.states
        assert gr.dfas == gr2.dfas
        assert gr.labels == gr2.labels
        assert gr.start == gr2.start
    finally:
        try:
            os.remove(fname)
        except (OSError, TypeError):
            pass

# Generated at 2022-06-11 19:36:54.155056
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test dump to same file
    g = Grammar()
    filename = './grammars/Grammar.txt'
    g.dump(filename)
    g1 = Grammar()
    g1.load(filename)
    assert g1.symbol2number == g.symbol2number
    assert g1.number2symbol == g.number2symbol
    assert g1.states == g.states
    assert g1.dfas == g.dfas
    assert g1.labels == g.labels
    assert g1.keywords == g.keywords
    assert g1.tokens == g.tokens
    assert g1.symbol2label == g.symbol2label
    assert g1.start == g.start
    assert g1.async_keywords == g.async_

# Generated at 2022-06-11 19:37:06.099343
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Verify method load of class Grammar.
    """

    import pickle


# Generated at 2022-06-11 19:37:15.518617
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # we don't want to depend on the generated pickle file
    basepath = os.path.join(os.path.abspath(os.path.dirname(__file__)), "..")
    filename = os.path.join(basepath, "Grammar.pkl")
    g = Grammar()
    g.dump(filename)


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:37:27.785778
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")
    assert g.symbol2number["and"] == 258
    assert g.symbol2number["or"] == 261
    assert g.symbol2number["not"] == 264
    assert g.symbol2number["in"] == 267
    assert g.symbol2number["is"] == 270
    assert g.symbol2number["lambda"] == 273
    assert g.symbol2number["nonlocal"] == 276
    assert g.symbol2number["await"] == 279
    assert g.symbol2number["async"] == 282
    assert g.number2symbol[258] == "and"
    assert g.number2symbol[261] == "or"
    assert g.number2symbol[264] == "not"

# Generated at 2022-06-11 19:37:39.335775
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from . import pickletools
    from . import token

    def dumps_equals_loads(pkl: bytes) -> None:
        loads = pickle.loads(pkl)
        dumps = pickle.dumps(loads)
        assert pkl == dumps

    class TestGrammar(unittest.TestCase):
        def _makeOne(self):
            class MyGrammar(Grammar):
                symbol2number = {
                    "foo": 0x0101,
                    "bar": 0x0202,
                }

                number2symbol = {
                    0x0101: "foo",
                    0x0202: "bar",
                }


# Generated at 2022-06-11 19:37:43.745233
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv, pgen

    g = Grammar()
    conv.convert(g, "Parser/Grammar.txt")
    pgen.validate_all(g)
    g.dump("Test/test_Grammar.pkl")

    h = Grammar()
    h.load("Test/test_Grammar.pkl")

    pgen.validate_all(h)

# Generated at 2022-06-11 19:37:54.030156
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    fname = "test.pickle"
    g = Grammar()
    # Set instance variable states
    g.states = [[(1, 2), (1, 3)], [(1, 4), (1, 5)]]
    # Set instance variable number2symbol
    g.number2symbol = {1: "symbol1", 2: "symbol2"}
    # Set instance variable labels
    g.labels = [(token.NAME, None), (token.NEWLINE, None)]
    g.dump(fname)

    # Get instance variable states
    states = []
    for dfa in g.states:
        state = []
        for arc in dfa:
            state.append((g.number2symbol[arc[0]], arc[1]))
        states.append(state)

    # Get instance variable labels


# Generated at 2022-06-11 19:37:59.079102
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # This is a reasonable test, but it might be better to test the
    # pickle files themselves.
    g = Grammar()
    with tempfile.TemporaryDirectory() as tmpdirname:
        filename = os.path.join(tmpdirname, "test")
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
        assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-11 19:38:10.524858
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class SubGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {"start":34}
            self.number2symbol = {34:"start"}
            self.states = []
            self.dfas = {}
            self.labels = [(0, "EMPTY")]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256
            self.async_keywords = False

    subgrammar = SubGrammar()
    tempfilename = "grouptoname"
    subgrammar.dump(tempfilename)
    
    with open(tempfilename, "rb") as f:
        d = pickle.load(f)

    os.remove

# Generated at 2022-06-11 19:38:21.749358
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(
        os.path.dirname(__file__),
        '..',
        'Lib',
        'test',
        'somegrammar.pkl')
    with open(filename, 'rb') as f:
        pickled = f.read()
    g = Grammar()
    g.loads(pickled)
    assert g.keywords == {'True': 567, 'False': 568}
    assert g.start == 5
    assert g.number2symbol == {0: 'EMPTY', 1: 'EndMarker', 2: 'NAME', 3: 'NUMBER',
                               4: 'STRING', 5: 'NEWLINE', 256: 'file_input',
                               257: 'func_def', 258: 'args', 259: 'return_stmt'}
    assert g

# Generated at 2022-06-11 19:38:31.972930
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    from io import BytesIO
    from . import conv
    from . import pickle

    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    path = tmpfile.name
    g = conv.CConverter()
    g.get_grammar(3)
    g.dump(path)

    with open(path, "rb") as f:
        d = pickle.load(f)
    g = Grammar()
    g._update(d)

    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    path = tmpfile.name
    g.dump(path)

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary

# Generated at 2022-06-11 19:38:44.038780
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pickle
    from tokenize import tokenize
    from typing import Generator

    class Grammar(object):
        def __init__(self):
            self.symbol2number = {}
            self.number2symbol = {}
            self.states = []
            self.dfas = {}
            self.labels = [(0, "EMPTY")]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256
            self.async_keywords = False


# Generated at 2022-06-11 19:38:51.602476
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    from . import pgen2

    filename = tempfile.mktemp(prefix="pgen2_parser_Grammar_dump")
    try:
        g = pgen2.driver.load_grammar(filename)
        g.dump(filename)
    finally:
        try:
            shutil.rmtree(os.path.dirname(filename))
        except FileNotFoundError:
            pass

# Generated at 2022-06-11 19:38:52.641484
# Unit test for method load of class Grammar
def test_Grammar_load():
    pass


# Generated at 2022-06-11 19:39:04.634581
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle as pickle
    import io
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def setUp(self):
            self.G = Grammar()
            self.G.start = 0
            self.G.labels = [(1, "EMPTY")]
            self.G.symbol2number = {"'{'": 0, "','": 1, "'}'": 2}
            self.G.keywords = {"for": 0}
            self.G.tokens = {"NAME": 0, "NUMBER": 1, "STRING": 2, "COMMENT": 3}
            self.G.number2symbol = {"0": "'{'", "1": "','", "2": "'}'"}

# Generated at 2022-06-11 19:39:13.857797
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    g = Grammar()
    g.number2symbol = {1: "one", 2: "two"}
    g.states = [[[(1, 1), (2, 2)], [(3, 3)]]]

    g.dump("test_grammar.pkl")

    with open("test_grammar.pkl", "rb") as f:
        d = pickle.load(f)


# Generated at 2022-06-11 19:39:16.717768
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Just a preliminary test for testing mypy type checking.
    g = Grammar()
    g.dump(tempfile.mkstemp()[1])

# Generated at 2022-06-11 19:39:20.524432
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    g = Grammar()
    g.load(filename)
    g.states  # type: ignore


# Generated at 2022-06-11 19:39:30.012991
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.loads(pickle.dumps({
        "symbol2number": {"foo": 257},
        "number2symbol": {257: "foo"},
        "dfas": {257: ([[(256, 1)]], {256: 1})}
    }))


if __name__ == "__main__":
    import unittest

    class Test_Grammar_load(unittest.TestCase):
        def test_success(self):
            gr = Grammar()
            gr.loads(pickle.dumps({
                "symbol2number": {"foo": 257},
                "number2symbol": {257: "foo"},
                "dfas": {257: ([[(256, 1)]], {256: 1})}
            }))

    unittest.main()

# Generated at 2022-06-11 19:39:41.852763
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import pickle
    from io import BytesIO
    def fake_pickle_dump(obj, output, protocol):
        x = sys.stdout
        sys.stdout = output
        pickle.dump(obj)
        sys.stdout = x
    def fake_pickle_load(filename):
        raise Exception("Can't load")
    import pytest
    from typing import Sequence
    with pytest.raises(Exception) as exc:
        Grammar.dump(Grammar(), "foo")
    assert "no attribute 'dump'" == str(exc.value)
    gs = Grammar.__subclasses__()
    for g in gs:
        try:
            g.dump = Grammar.dump
        except Exception as e:
            print(e)

# Generated at 2022-06-11 19:39:49.919831
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from . import conv
    from . import pgen2
    import grammar
    import os

    pytest.importorskip("pgen2")  # type: ignore # noqa

    g = grammar.Grammar()

    conv.initialize_grammar(g)
    pgen2.load_grammar(g, grammar.__file__)

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        g.dump(f.name)

    g2 = grammar.Grammar()
    with open(f.name, "rb") as f:
        d = pickle.load(f)
    g2._update(d)

    os.remove(f.name)

    assert g2.dfas == g.dfas
    assert g2.symbol

# Generated at 2022-06-11 19:40:00.486652
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # pylint: disable=missing-if-statement,unused-import,import-outside-toplevel,protected-access
    from . import conv, pgen, pickletools
    grammar = pgen.generate_grammar("Grammar")
    grammar.dump("Grammar.pkl")
    print("Pickle file:")
    pickletools.dis("Grammar.pkl")
    dfa = grammar.states[10]
    print("\nDFA 10:")
    for i, arc in enumerate(dfa):
        print("  %2d:" % i, end=" ")
        for arc_ in arc:
            if arc_[0] == 0:
                print("(0, %d)" % arc_[1], end=" ")

# Generated at 2022-06-11 19:40:13.181140
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test for Grammar.load()

    Build a Grammar object for Python 2 and a Grammar object for Python
    3 and compare them.  They should be equivalent.
    """

    from .pgen2 import driver

    g2 = driver.load_grammar(pickle_file="Grammar/Grammar.pkl")
    if g2 is None:
        raise ImportError("Couldn't import Grammar/Grammar.pkl")
    g3 = driver.load_grammar(pickle_file="Grammar/Grammar3.pkl")
    if g3 is None:
        raise ImportError("Couldn't import Grammar/Grammar3.pkl")
    assert g3.labels == g2.labels
    assert g3.symbol2label == g2.symbol2label
   

# Generated at 2022-06-11 19:40:23.984708
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Instantiate a Grammar and call load() with a pickle file created by dump().
    """

    filename = "Grammar.pickle"

    with open(filename, "rb") as f:
        d = pickle.load(f)

    g = Grammar()
    g.load(filename)
    assert g.states == d["states"]
    assert g.symbol2number == d["symbol2number"]
    assert g.number2symbol == d["number2symbol"]
    assert g.keywords == d["keywords"]
    assert g.tokens == d["tokens"]
    assert g.symbol2label == d["symbol2label"]
    assert g.dfas == d["dfas"]
    assert g.labels == d["labels"]

# Generated at 2022-06-11 19:40:32.054302
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar as _g
    from . import pgen as _p
    import os

    # Non-existent path
    p = _p.PgenParser("../_test/grammar3.6.cfg")
    g = _p.load_grammar("../_test/grammar3.6.cfg", p)

    g.dump("../_test/non_existent.grm")

    g.dump("../_test/grammar3.6.grm")
    g1 = _g.Grammar()
    g1.load("../_test/grammar3.6.grm")
    assert g.symbol2number == g1.symbol2number
    assert g.number2symbol == g1.number2symbol
    assert g.dfas == g1.dfas
    assert g.key

# Generated at 2022-06-11 19:40:34.943408
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(r"grammar.pickle")

# Generated at 2022-06-11 19:40:46.824432
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    grammar.symbol2number = {"A": 1, "B": 2}
    grammar.number2symbol = {1: "A", 2: "B"}
    grammar.states.append([{"A": 1}])

    dfa = [
        {(0, "A"), (0, "B")},
        {(1, "A")},
        {(1, "B")},
    ]
    grammar.states.append(dfa)

    grammar.dfas = {"A": (dfa, {1, 2}), "B": (dfa, {1, 2})}

    grammar.labels = [(0, "EMPTY"), (1, "A"), (1, "B")]

    grammar.keywords = {"A": 1, "B": 1}
    grammar.tokens

# Generated at 2022-06-11 19:40:53.572421
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2.driver import Driver
    from . import token

    g = Driver().parse_grammar(token.__file__, 'exec')
    g.dump('test.pkl')

    # Make sure we can read this later...
    import pickle
    with open('test.pkl', 'rb') as f:
        g2 = pickle.load(f)

    assert g.__dict__ == g2.__dict__

# Generated at 2022-06-11 19:41:01.421912
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import tempfile
    from . import token
    from .parse import Parser

    class GrammarTestCase(unittest.TestCase):
        def test_dump_load(self):
            grammar = Grammar()

            grammar.symbol2number = {
                "a": 1,
                "b": 2,
                "c": 3,
            }

            grammar.number2symbol = {
                1: "a",
                2: "b",
                3: "c",
            }

            grammar.keywords = {
                "and": 1,
                "as": 2,
            }

            grammar.tokens = {
                token.NAME: 1,
                token.STRING: 2,
            }


# Generated at 2022-06-11 19:41:09.374219
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "tmp.pk"
    g = Grammar()
    g.keywords = {'False': 4, 'True': 5, 'None': 6}
    g.start = 257
    g.tokens = {0: 0, 1: 1, 2: 2, 3: 3}
    g.states = [[(0, 0)]]
    g.symbol2number = {'START': 257}
    g.number2symbol = {257: 'START'}
    g.labels = [(0, 'EMPTY'), (1, 'ENDMARKER'), (2, 'NAME'), (3, 'NUMBER'),
                 (4, 'False'), (5, 'True'), (6, 'None')]
    g.symbol2label = {'False': 4, 'True': 5, 'None': 6}

# Generated at 2022-06-11 19:41:18.630767
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.number2symbol = {256: 'file_input', 257: 'eval_input', 258: 'DECORATOR'}
    g.symbol2number = {'file_input': 256, 'eval_input': 257, 'DECORATOR': 258}
    g.start = 256

# Generated at 2022-06-11 19:41:23.680760
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "testdata/grammar.pickle"
    try:
        os.remove(filename)
    except OSError:
        pass
    g = Grammar()
    g.dump(filename)

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:41:33.520313
# Unit test for method load of class Grammar
def test_Grammar_load():
    '''
    >>> import os, pickle
    >>> import lib2to3.pgen2.driver as D
    >>> g = D.load_grammar('python2.pickle')
    >>> isinstance(g, pickle.Unpickler)
    True
    '''
    pass


# Generated at 2022-06-11 19:41:36.204641
# Unit test for method load of class Grammar
def test_Grammar_load():    
    imp = Grammar()
    # This test only fails if pickle protocol version >= 5 (Python 3.4)
    g = imp.load('./pythonparser/Grammar.pickle')



# Generated at 2022-06-11 19:41:39.458263
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join("Grammar", "Grammar.pkl"))
    g.report()

# Generated at 2022-06-11 19:41:44.519973
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

    print("test_Grammar_load:")
    grammar.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:41:49.139036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        from .grammar import auto_grammar
    except ImportError:
        from . import grammar

        auto_grammar.parse_grammar(
            open(grammar.__file__.rstrip("c")), "exec", auto_grammar.Grammar()
        )

    auto_grammar.Grammar().dump(grammar.__file__.rstrip("c") + ".auto.pickle")

# Generated at 2022-06-11 19:41:56.050893
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from io import BytesIO

    d = driver.Driver()
    filename = d.find_grammar()
    d.parse_grammar(filename)
    g = d.pgen.grammar
    g.dump("./test_Grammar_dump.pickle")
    with open("./test_Grammar_dump.pickle", "rb") as f:
        contents = f.read()

    g2 = Grammar()
    g2.loads(contents)
    assert g2.dfas == g.dfas, "Grammar instance variables do not match"

# Generated at 2022-06-11 19:42:04.121066
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {}
    g.number2symbol = {}
    g.states = []
    g.dfas = {}
    g.labels = [(0, "EMPTY")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    filename="test_Grammar_dump.pkl"
    g.dump(filename)

    reloaded_grammar = Grammar()
    reloaded_grammar.load(filename)
    #for name in reloaded_grammar.__dict__:
    #    assert getattr(g, name) == getattr(reloaded_grammar, name), \
    #        "{} {} {} {}".format(name, g.__dict__[name],

# Generated at 2022-06-11 19:42:07.333494
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize

    g = Grammar()
    g.load('Grammar.pickle')
    for op, tok in opmap.items():
        assert tokenize.opmap[op] == tok

# Generated at 2022-06-11 19:42:14.803107
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # From grammar.txt, instead of using the actual pickle file
    Grammar = Grammar()

# Generated at 2022-06-11 19:42:18.091089
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import convert  # type: ignore

    g = Grammar()
    convert(g)
    assert g.start == 256


del TypeVar, os, pickle, tempfile

# Generated at 2022-06-11 19:42:36.589963
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "../Files/Grammar.pickle"
    g = Grammar()
    g.load(filename)
    print("Dump the grammar tables to standard output, for debugging.")
    print("s2n")
    print(g.symbol2number)
    print("n2s")
    print(g.number2symbol)
    print("states")
    print(g.states)
    print("dfas")
    print(g.dfas)
    print("labels")
    print(g.labels)
    print("start", g.start)
    g.report()
    print("END")

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:42:46.963216
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.start = 2
    grammar.symbol2number = {"key":2}

    # mypyc generates objects that don't have a __dict__, but they
    # do have __getstate__ methods that will return an equivalent
    # dictionary
    if hasattr(grammar, "__dict__"):
        d = grammar.__dict__
    else:
        d = grammar.__getstate__()  # type: ignore

    with tempfile.TemporaryFile("w+b") as f:
        pickle.dump(d, f, pickle.HIGHEST_PROTOCOL)
        f.seek(0)
        loaded_grammar = Grammar()
        loaded_grammar.load(f)
        assert grammar.start == loaded_grammar.start
        assert grammar.symbol2

# Generated at 2022-06-11 19:42:54.626627
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that load loads the current grammar correctly
    from . import pgen
    from . import parse as _parse  # noqa

    g = Grammar()
    f = tempfile.NamedTemporaryFile(delete=False)
    pgen.main(f.name)
    g.load(f.name)
    f.close()
    return g


grammar = test_Grammar_load()  # type: Grammar

# Generated at 2022-06-11 19:42:58.216595
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "data/grammar.test.pkl"
    grammar = Grammar()
    grammar.dump(filename)
    assert os.path.isfile(filename)
    assert os.stat(filename).st_size > 0
    grammar.load(filename)
    os.remove(filename)

# Generated at 2022-06-11 19:43:09.009977
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pkl")
    gr = Grammar()
    gr.load(filename)
    assert gr.symbol2number["and"] == 257
    assert gr.number2symbol[257] == "and"
    assert gr.states[0][0][0] == (1, 2)
    assert gr.dfas[257] == (gr.states[0], {1: 1, 3: 1})
    assert gr.labels[1] == (1, None)
    assert gr.keywords["for"] == 5
    assert gr.tokens[1] == 4
    assert gr.start == 256



# Generated at 2022-06-11 19:43:15.762410
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = os.path.join(tempfile.gettempdir(), "grammar.pickle")
    try:
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
    finally:
        if os.path.exists(filename):
            os.remove(filename)


if __name__ == "__main__":
    import unittest

    unittest.main("lib2to3.pgen2.driver", verbosity=1, exit=False)

# Generated at 2022-06-11 19:43:27.330791
# Unit test for method load of class Grammar
def test_Grammar_load():
    gl = Grammar()
    gl.load("./test/test_grammar.pkl")

# Generated at 2022-06-11 19:43:30.423143
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    # check that the dump function can be called without an error
    grammar.dump(tempfile.mktemp())


# Generated at 2022-06-11 19:43:39.282623
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def dummy_dict(**kwargs):
        return kwargs
    class DummyGrammar(Grammar):
        def __getstate__(self):
            return dummy_dict(**{"symbol2number": {},
                                 "number2symbol": {},
                                 "states": [[]],
                                 "dfas": {},
                                 "labels": [],
                                 "keywords": {},
                                 "tokens": {},
                                 "symbol2label": {},
                                 "start": 256,
                                 "async_keywords": False})
    g = DummyGrammar()
    with tempfile.TemporaryDirectory() as dir:
        path = os.path.join(dir, "grammar.pickle")
        g.dump(path)

# Generated at 2022-06-11 19:43:48.132138
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import tokenize
    pgen = tokenize.generate_grammar()
    pgen.dump(tempfile.NamedTemporaryFile().name)
    pg = Grammar()
    pg.load(tempfile.NamedTemporaryFile().name)
    assert pg.symbol2number == pgen.symbol2number
    assert pg.number2symbol == pgen.number2symbol
    assert pg.keywords == pgen.keywords
    assert pg.tokens == pgen.tokens
    assert pg.states == pgen.states
    assert pg.labels == pgen.labels
    assert pg.start == pgen.start
    assert pg.dfas == pgen.dfas



# Generated at 2022-06-11 19:44:07.086035
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pickle
    import unittest

    class PickleTestCase(unittest.TestCase):

        def pickletest(self, obj: Any, proto: int = 0) -> None:
            f = io.BytesIO()
            pickle.dump(obj, f, proto)
            f.seek(0)
            newobj = pickle.load(f)
            self.assertEqual(obj, newobj)

        def pickletest_empty(self, proto: int) -> None:
            self.pickletest_data("")
            for mode in ("b", "t"):
                self.pickletest_data("", mode)

        def pickletest_data(self, data: bytes, mode: str = "b") -> None:
            f = io.BytesIO(data)
            f

# Generated at 2022-06-11 19:44:15.800767
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle
    import pickletools

    class TestCase(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(__file__.replace(".py", ".pkl"))
            g2 = g.copy()
            if hasattr(g, "__dict__"):
                d = pickle.dumps(g.__dict__)
            else:
                d = pickle.dumps(g.__getstate__())  # type: ignore
            g2.loads(d)
            self.assertEqual(g2.async_keywords, False)

    unittest.main(module="test_Grammar", exit=False)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:44:16.966987
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "Grammar.pickle"
    Grammar().dump(filename)
    Grammar().load(filename)
    os.remove(filename)



# Generated at 2022-06-11 19:44:22.306847
# Unit test for method load of class Grammar
def test_Grammar_load():
    for attr in (
        "symbol2number",
        "number2symbol",
        "states",
        "dfas",
        "labels",
        "start",
        "keywords",
        "tokens",
    ):
        if not hasattr(Grammar, attr):
            raise AssertionError(attr)
        if not callable(getattr(Grammar, attr)):
            raise AssertionError(attr)

# Generated at 2022-06-11 19:44:33.322001
# Unit test for method load of class Grammar
def test_Grammar_load():

    grammar_path = os.path.join(
        os.path.dirname(__file__), "Grammar.pkl"
    )

    grammar = Grammar()
    grammar.load(grammar_path)


# Generated at 2022-06-11 19:44:38.340746
# Unit test for method load of class Grammar
def test_Grammar_load():
    # type: () -> None
    s = ""
    for k in dir(token):
        if k[:3] != "ERR":
            s += "%-20s %s\n" % (k, getattr(token, k))
    gram = Grammar()
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("#%%\n%s\n" % s)
        f.write("#%%\ndef p_error(p): pass\n")
        f.flush()
        gram.load(f.name)

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:44:45.504799
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import ast
    import sys
    import unittest
    import tokenize
    from io import StringIO
    from typing import TYPE_CHECKING
    from typing import cast

    if TYPE_CHECKING:
        import io  # pylint: disable=cyclic-import

    def parse(text: str) -> ast.Module:
        mode = "exec" if sys.version_info[:2] < (3, 6) else "eval"
        return cast(ast.Module, ast.parse(text, mode=mode))

    class TestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.maxDiff = 1000
            self.grammar = Grammar()
            self.grammar.make_pgen()
