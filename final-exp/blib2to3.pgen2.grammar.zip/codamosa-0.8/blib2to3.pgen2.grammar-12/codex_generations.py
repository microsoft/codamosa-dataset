

# Generated at 2022-06-11 19:34:55.590001
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("Grammar.dump")
    g1 = Grammar()
    g1.load("Grammar.dump")
    assert g.keywords == g1.keywords
    assert g.tokens == g1.tokens
    assert g.labels == g1.labels
    assert g.dfas == g1.dfas
    assert g.states == g1.states
    assert g.start == g1.start
    assert g.async_keywords == g1.async_keywords
    assert g.keywords == g.keywords
    assert g.tokens == g.tokens
    assert g.labels == g.labels
    assert g.dfas == g.dfas
    assert g.states == g.states

# Generated at 2022-06-11 19:34:59.632162
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load('data/grammar.pkl')

    unittest.main()

# Generated at 2022-06-11 19:35:01.586313
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.TemporaryDirectory() as temp:
        path = temp + "/dump"
        g = Grammar()
        g.dump(path)
        assert os.path.isfile(path)

# Generated at 2022-06-11 19:35:07.442145
# Unit test for method load of class Grammar
def test_Grammar_load():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(pickle.dumps({"a":"b"}, pickle.HIGHEST_PROTOCOL))
    try:
        g = Grammar()
        g.load(f.name)
        assert g.a == "b"
    finally:
        os.remove(f.name)

# Generated at 2022-06-11 19:35:15.554458
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the load method of class Grammar"""

    import pickle
    from io import BytesIO

    filename = "test/pgen_input"
    g_class = Grammar

    g = g_class()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False

    # load from file
    g1 = g_class()
    g1.load(filename)
    assert g1.symbol2number == g.symbol2number


# Generated at 2022-06-11 19:35:24.141339
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        import py_compile
    except ImportError:
        pass
    else:
        g = Grammar()
        g.states = [
            [
                [(1, 2), (2, 3)],
                [(1, 2), (2, 3)],
                [(1, 2), (2, 3)],
                [(1, 2), (2, 3)],
            ],
            [
                [(1, 2), (2, 3)],
                [(1, 2), (2, 3)],
                [(1, 2), (2, 3)],
                [(1, 2), (2, 3)],
            ],
        ]
        g.start = 256

# Generated at 2022-06-11 19:35:32.953707
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tempfile
    import pickle
    import os

    class MyGrammar(Grammar):
        pass

    m = MyGrammar()
    m.symbol2number = {'foo': 1, 'bar': 2, 'zzz': 42}
    m.number2symbol = dict(zip(m.symbol2number.values(), m.symbol2number.keys()))
    with tempfile.TemporaryDirectory() as tmpdir:
        m.dump(os.path.join(tmpdir, 'test'))
        n = MyGrammar()
        n.load(os.path.join(tmpdir, 'test'))
        assert m.symbol2number == n.symbol2number
        assert m.number2symbol == n.number2symbol

# Generated at 2022-06-11 19:35:43.054695
# Unit test for method load of class Grammar
def test_Grammar_load():
    import shutil

    path = "test"
    g = Grammar()
    g.dump(path)
    h = Grammar()
    h.load(path)
    assert g.start == h.start
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label
    assert g.async_keywords == h.async_keywords
    shutil.rmtree(path)



# Generated at 2022-06-11 19:35:46.041328
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load == Grammar.load


# Generated at 2022-06-11 19:35:48.595298
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    filename = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    data = driver.load_grammar(filename)
    assert isinstance(data, Grammar)



# Generated at 2022-06-11 19:35:58.804351
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test dump and load of private instance attributes
    import pickle
    from io import BytesIO

    grammar = Grammar()

# Generated at 2022-06-11 19:36:03.920468
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    from .conv import parse_grammar

    parse_grammar(g, "Grammar.txt", "Grammar.pickle", "Python.asdl")
    g2 = Grammar()
    g2.load('Grammar.pickle')
    assert g == g2

# Generated at 2022-06-11 19:36:08.225109
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test Grammar.load().
    """
    class X(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.x = 1

        def load(self, filename):
            Grammar.load(self, filename)
            self.x = 42

    x = X()
    assert x.x == 1
    x.load(filename="graminit.py")
    assert x.x == 42

# Generated at 2022-06-11 19:36:16.785271
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar"""
    # Preserves the file after the program exists
    g = Grammar()
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    g.dump(temp_file.name)
    g2 = Grammar()
    g2.load(temp_file.name)
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens
    assert g.symbol2label == g2.symbol2label


# Generated at 2022-06-11 19:36:28.127364
# Unit test for method load of class Grammar
def test_Grammar_load():
    class C(Grammar):
        pass

    x = C()
    y = C()

    x.symbol2number = "hello"
    x.number2symbol = "world"
    x.dfas = "foo"
    x.keywords = "bar"
    x.tokens = "baz"
    x.symbol2label = "qux"
    x.labels = "foobar"
    x.states = "bazbar"
    x.start = "bazbaz"

    filename = "C.pickle"
    x.dump(filename)
    y.load(filename)

    if y.symbol2number != "hello":
        raise AssertionError
    if y.number2symbol != "world":
        raise AssertionError

# Generated at 2022-06-11 19:36:36.056406
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from .pgen2 import tokenize
    from .parse import Parser
    from . import token
    from . import symbol

    # Create an instance of class Grammar
    g = Grammar()

    # Call method loads of class Grammar
    g.loads(pickle.dumps(g))

    # Verify attribute symbol2number of class Grammar
    assert isinstance(g.symbol2number, dict)
    assert g.symbol2number == {}
    # Verify attribute number2symbol of class Grammar
    assert isinstance(g.number2symbol, dict)
    assert g.number2symbol == {}
    # Verify attribute states of class Grammar
    assert isinstance(g.states, list)
    assert g.states == []
    # Verify attribute dfas of class Grammar

# Generated at 2022-06-11 19:36:45.836072
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class TestGrammar(Grammar):
        def __init__(self):
            self.symbol2number = {"foo": 23}
            self.number2symbol = {42: 23}
            self.states = [[1, 2], [2, 3]]
            self.dfas = {23: (1, {"bar": 1})}
            self.labels = [(0, "EMPTY"), (42, "bar")]
            self.keywords = {"foo": "bar"}
            self.tokens = {42: 43}
            self.symbol2label = {"foo": 1}
            self.start = 256
            self.async_keywords = False

    t = TestGrammar()

# Generated at 2022-06-11 19:36:55.418413
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = {'empty': 258, 'one': 259, 'two': 260, 'three': 261}
    grammar.number2symbol = {258: 'empty', 259: 'one', 260: 'two', 261: 'three'}
    grammar.states = [
        [
            [(258, 1), (260, 3)],
            [(259, 2)],
            [],
            [(259, 4)],
            [],
            [(259, 0)],
        ]
    ]
    grammar.dfas = {259: (0, {258: 1, 260: 1})}
    grammar.labels = [
        (0, 'EMPTY'),
        (259, None),
        (260, None),
        (261, None),
        (258, None),
    ]

# Generated at 2022-06-11 19:36:56.313102
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load()

# Generated at 2022-06-11 19:37:07.433125
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    # Set up grammar
    g = Grammar()
    g.symbol2number = {'single_input': 257, 'eval_input': 258, 'decorator': 259}
    g.number2symbol = {257: 'single_input', 258: 'eval_input', 259: 'decorator'}

# Generated at 2022-06-11 19:37:19.108263
# Unit test for method load of class Grammar
def test_Grammar_load():
    fn = os.path.dirname(__file__) + os.sep + 'Grammar.pickle'
    g = Grammar()
    g.load(fn)
    assert g.symbol2number == {'term': 258, 'nil': 259, 'LPAR': 257, 'factor': 260}
    assert g.number2symbol == {258: 'term', 259: 'nil', 257: 'LPAR', 260: 'factor'}
    assert g.states == [
        [[(257, 1), (0, 2)], [(257, 4), (0, 5)], [(0, 3)], [(0, 4)], [(0, 5)], [(0, 5)]]
        ]

# Generated at 2022-06-11 19:37:29.843460
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = tempfile.mktemp()
    try:
        m = Grammar()
        m.dump(filename)
        n = Grammar()
        n.load(filename)
        assert n.symbol2number == m.symbol2number
        assert n.number2symbol == m.number2symbol
        assert n.dfas == m.dfas
        assert n.keywords == m.keywords
        assert n.tokens == m.tokens
        assert n.symbol2label == m.symbol2label
        assert n.labels == m.labels
        assert n.states == m.states
        assert n.start == m.start
        assert n.async_keywords == m.async_keywords
    finally:
        os.remove(filename)


# Generated at 2022-06-11 19:37:31.692953
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("../Grammar.pickle")

# Generated at 2022-06-11 19:37:41.381960
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from ..tests.test_grammar import pgen_grammar, tokenizer_grammar
    import shutil

    grammar = Grammar()
    fname = "test_grammar_dump.pkl"
    try:
        grammar.loads(pgen_grammar)
        grammar.dump(fname)
        # Test if it really is a pickle file
        with open(fname, "rb") as f:
            assert f.read() == pgen_grammar
    finally:
        try:
            shutil.unlink(fname)
        except FileNotFoundError:
            pass

    grammar = Grammar()
    fname = "test_grammar_dump.pkl"

# Generated at 2022-06-11 19:37:51.216095
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    grammars = [
        g.symbol2number,
        g.number2symbol,
        g.states,
        g.dfas,
        g.labels,
        g.keywords,
        g.tokens,
    ]
    grammars2 = [
        g.symbol2number,
        g.number2symbol,
        g.states,
        g.dfas,
        g.labels,
        g.keywords,
        g.tokens,
    ]
    for k in range(len(grammars)):
        assert grammars[k] == grammars2[k]

# Generated at 2022-06-11 19:37:55.532525
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    filename = "badfile"
    with tempfile.TemporaryDirectory() as tmp:
        filename = tmp + "/test_Grammar_dump.pickle"
        g.dump(filename)

    g2 = Grammar()
    g2.load(filename)
    assert g == g2

# Generated at 2022-06-11 19:38:05.792120
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    # test dump function
    grammar.states = [[(1, 2), (3, 4)]]
    grammar.symbol2number = {'abc': 5}
    grammar.number2symbol = {6: 'def'}
    grammar.dfas = {0: ([[(1, 2)]], {1: 2})}
    grammar.labels = [(1, 'empty')]
    grammar.keywords = {'abc': 1}
    grammar.tokens = {1: 1}
    grammar.start = 4
    grammar.async_keywords = False

    pickle_file = os.path.join(os.path.dirname(__file__), 'data_grammar.pickle')
    grammar.dump(pickle_file)


# Generated at 2022-06-11 19:38:12.504951
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MockGrammar(Grammar):
        def __init__(self):
            # Todo: Perhaps use pytest monkeypatch to replace os.replace with NOP
            # so that method dump of class Grammar can be fully tested
            self.filename = "filename.pickle"
            self.temp_file_content = None
            self.temp_file_delete = False
            self.dump_protocol = pickle.HIGHEST_PROTOCOL
        def dump(self, filename):
            self.filename = filename
        def update(self, attrs: Dict[str, Any]):
            self.temp_file_content = attrs
            self.filename = None
        def NamedTemporaryFile(self, dir, delete):
            self.dir = dir
            self.delete = delete

# Generated at 2022-06-11 19:38:22.415815
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    gr.start = 32
    gr.number2symbol = {32: 'spam', 123: 'egg'}
    gr.symbol2number = {'spam': 32, 'egg': 123}
    gr.labels = [(0, "EMPTY"), (1, None), (2, "KEYWORD")]
    gr.keywords = {'foo': 2}
    gr.tokens = {125: 1}
    gr.symbol2label = {'spam': 32}

    fd, filename = tempfile.mkstemp(prefix='parser')
    gr.dump(filename)
    os.close(fd)

    h = Grammar()
    h.load(filename)
    os.unlink(filename)

    assert h.start == gr.start

# Generated at 2022-06-11 19:38:30.731498
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    unittest.TestCase().assertEqual(opmap['+'], token.PLUS)
    unittest.TestCase().assertEqual(opmap[':'], token.COLON)
    unittest.TestCase().assertEqual(opmap['='], token.EQUAL)
    unittest.TestCase().assertEqual(opmap['@='], getattr(token, 'ATEQUAL'))
    unittest.TestCase().assertEqual(opmap['//'], token.DOUBLESLASH)
# end of unit test for method load of class Grammar

# Generated at 2022-06-11 19:38:44.560881
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:38:45.188773
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass

# Generated at 2022-06-11 19:38:56.380407
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from .token import ISTERMINAL

    _p = driver.load_grammar("Grammar/Grammar")
    if not os.path.exists("Grammar/Grammar" + ".pickle"):
        _p.dump("Grammar/Grammar" + ".pickle")

    with open("Grammar/Grammar" + ".pickle", "rb") as f:
        d = pickle.load(f)

    assert d == _p.__getstate__()

    pickle.loads(pickle.dumps(_p))
    _p == Grammar()

    _labels = _p.labels
    assert _labels[1] == (0, 'EMPTY')
    assert _labels[2] == (0, 'NAME')


# Generated at 2022-06-11 19:39:06.501227
# Unit test for method load of class Grammar
def test_Grammar_load():
    g1 = Grammar()
    g2 = Grammar()
    g1.dump("foo.pkl")
    g2.load("foo.pkl")
    assert g1.symbol2number == g2.symbol2number
    assert g1.number2symbol == g2.number2symbol
    assert g1.states == g2.states
    assert g1.dfas == g2.dfas
    assert g1.labels == g2.labels
    assert g1.keywords == g2.keywords
    assert g1.tokens == g2.tokens
    assert g1.symbol2label == g2.symbol2label
    assert g1.start == g2.start
    assert g1.async_keywords == g2.async_keywords

# Generated at 2022-06-11 19:39:15.075393
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from .conv import PyCF_ONLY_AST
    from .pgen2 import driver
    from .pgen2.parse import parse_grammar
    from .pgen2.pgen import Pgen, save_grammar

    pgen = Pgen(parse_grammar(driver.grammar, "file.py", PyCF_ONLY_AST), "file.py")
    pgen.generate_grammar()
    f = tempfile.NamedTemporaryFile(mode="w+b", delete=False)

# Generated at 2022-06-11 19:39:26.900389
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import pgen
    import sys
    import time

    g = driver.load_grammar(sys.version_info.major)
    # mypyc doesn't generate __dict__, so we need to check if it is present
    def test_dict_attr(k: str) -> bool:
        return hasattr(g, k) and (type(getattr(g, k)) == dict)

    for k in "symbol2number number2symbol keywords tokens".split():
        if not test_dict_attr(k):
            raise RuntimeError(f"assertion failed: {k!r}")
    for k in "labels dfas states".split():
        if not hasattr(g, k):
            raise RuntimeError(f"assertion failed: {k!r}")

# Generated at 2022-06-11 19:39:30.513259
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    pkl = BytesIO()
    pickle.dump({"test": "pass"}, pkl, protocol=pickle.HIGHEST_PROTOCOL)
    pkl.seek(0)
    g = Grammar()
    g.loads(pkl.read())
    assert g.test == "pass"

# Generated at 2022-06-11 19:39:42.655859
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class G(Grammar):
        def __init__(self) -> None:
            Grammar.__init__(self)

        def report(self) -> None:
            pass

    g = G()
    g.symbol2number.update([("1", 1), ("2", 2)])
    g.number2symbol.update([(1, "1"), (2, "2")])
    g.states.append([[(1, 0), (2, 1)], []])
    g.dfas.update([(0, ([[(1, 0), (2, 1)], []], {1: 1}))])
    g.labels.append((3, "3"))
    g.labels.append((4, "4"))
    g.keywords.update([("5", 5)])
    g

# Generated at 2022-06-11 19:39:55.397270
# Unit test for method load of class Grammar
def test_Grammar_load():
    from pgen2 import driver
    from pgen2.pgen import generate_grammar
    from pgen2.conv import convert_grammar
    from pgen2.parse import ParseError

    g = driver.load_grammar("Python.g")
    assert isinstance(g, Grammar)
    g2 = driver.load_grammar("Python.g")
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels
    assert g.start == g2.start
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens



# Generated at 2022-06-11 19:40:03.183607
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Ensure that Grammar.load() can load a grammar pickle.
    """
    a = Grammar()
    a.dump("a.pkl")
    b = Grammar()
    b.load("a.pkl")
    assert a.symbol2number == b.symbol2number
    assert a.number2symbol == b.number2symbol
    assert a.states == b.states
    assert a.dfas == b.dfas
    assert a.labels == b.labels
    assert a.start == b.start

# Generated at 2022-06-11 19:40:15.271714
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.keywords['True'] = 'boolean'
    g.tokens[1] = 'one'
    g.dump('/tmp/grammar.pickle')

    g2 = Grammar()
    g2.load('/tmp/grammar.pickle')
    assert g.keywords == g2.keywords
    assert g.tokens == g2.tokens

# Generated at 2022-06-11 19:40:18.933339
# Unit test for method dump of class Grammar
def test_Grammar_dump():  # FIXME
    g = Grammar()
    g.dump("grammar.pickle")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:40:21.568446
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # grammar.dump()
    import tempfile

    f = tempfile.NamedTemporaryFile(delete=False)
    g = Grammar()
    g.dump(f.name)
    t = g.loads(open(f.name, "rb").read())



# Generated at 2022-06-11 19:40:30.527774
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:40:32.772784
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle as p

    s = p.dumps({1:2})
    g = Grammar()
    g.loads(s)
    assert g.__dict__ == {1: 2}

# Generated at 2022-06-11 19:40:40.110543
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pass
    # gr = Grammar()
    # import pytest
    # import os.path
    #
    # assert os.path.isfile("Grammar.pickle")
    # gr.load("Grammar.pickle")
    #
    # with pytest.raises(Exception) as execinfo:
    #    gr.dump("Grammar.pickle")
    # assert "PermissionError" in str(execinfo.value)

# Generated at 2022-06-11 19:40:46.362272
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test Grammar.dump() method.

    dump() method writes the grammar tables to a pickle file.
    """
    test_grammar = Grammar()
    test_file = "temp_file.pickle"
    test_grammar.dump(test_file)
    assert os.path.exists(test_file)
    os.unlink(test_file)

# Generated at 2022-06-11 19:40:47.353276
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("grammar.pickle")

# Generated at 2022-06-11 19:40:58.831429
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Unit test for method dump of class Grammar
    """
    def get_first(d: Dict[int, int]) -> int:
        for x in d.keys():
            return x

    g = Grammar()
    g.start = 257
    g.dfas[257] = ([[(257, 258)], [(0, 258)]], {257: 1})
    g.symbol2number["a"] = 257
    g.number2symbol[257] = "a"
    g.labels.append((257,None))
    g.labels.append((0, "EMPTY"))
    g.states = [[(1, 2)], [(0, 2)]]
    g.tokens[1] = 1

# Generated at 2022-06-11 19:41:08.348207
# Unit test for method load of class Grammar
def test_Grammar_load():
    if '__name__' in locals():
        g = Grammar()
        g.name = 'PCC_Grammar'
        g.start = 257
        expectedDump = pickle.dumps(g.__getstate__(),pickle.HIGHEST_PROTOCOL)
        with tempfile.NamedTemporaryFile(delete=False) as f:
            g.dump(f.name)
        with open(f.name, 'rb') as f:
            actualDump = f.read()
        os.remove(f.name)
        assert(expectedDump == actualDump)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:41:19.672584
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("/something/that/does/not/exist")
    pass

# Generated at 2022-06-11 19:41:29.244893
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.symbol2number = {}
    gr.number2symbol = {}
    gr.states = []
    gr.dfas = {}
    gr.labels = []
    gr.keywords = {}
    gr.tokens = {}
    gr.symbol2label = {}
    gr.start = 256
    gr.async_keywords = False
    gr.load("./Grammar")
    assert gr.symbol2number == {}
    assert gr.number2symbol == {}
    assert gr.states == []
    assert gr.dfas == {}
    assert gr.labels == []
    assert gr.keywords == {}
    assert gr.tokens == {}
    assert gr.symbol2label == {}
    assert gr.start == 256

# Generated at 2022-06-11 19:41:39.259587
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Tests method Grammar.load"""
    # Generate some useless data
    seed = [1, 2, 3]
    filename = tempfile.mktemp()
    with open(filename, "w") as f:
        pickle.dump(seed, f)
    # LOAD: Reads pickle file
    gr = Grammar()
    gr.load(filename)
    # Check if the data correspond to the useless data
    assert gr.symbol2number == {'1': 2, '2': 4, '3': 6}
    assert gr.number2symbol == {2: '1', 4: '2', 6: '3'}

# Generated at 2022-06-11 19:41:49.444412
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock
    g = Grammar()
    g.symbol2number = {"'symbol2number'": 2, "'number2symbol'": 3}
    with unittest.mock.patch('pickle.dump') as mock_dump:
        g.dump("filename")

# Generated at 2022-06-11 19:41:57.547158
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()

    s2n = {"foo": 256, "bar": 257, "baz": 258}
    n2s = {256: "foo", 257: "bar", 258: "baz"}
    states = [[[(1, 42), (2, 43)], [(3, 44)], [], []]]
    dfas = {257: (states[0], {1: 1, 2: 1}), 258: (states[0], {3: 1})}
    labels = [(0, "EMPTY"), (1, "a"), (2, None), (3, "a"), (42, None), (43, None), (44, None)]

# Generated at 2022-06-11 19:42:09.279508
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:42:11.925313
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load("Grammar.pickle")
    gram.report()


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:42:17.680514
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test load()
    """
    from . import pgen2

    g = Grammar()
    pgen2.driver.run_pgen(g, "__main__")
    fd, fn = tempfile.mkstemp(".pkl")
    os.close(fd)
    g.dump(fn)
    g2 = Grammar()
    g2.load(fn)
    os.remove(fn)

# Generated at 2022-06-11 19:42:20.133413
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    grammar = Grammar()
    driver.load_grammar("Grammar/Grammar", grammar)



# Generated at 2022-06-11 19:42:29.345819
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2

    g = pgen2.driver.load_grammar("/usr/local/Cellar/python/3.7.4_1/Frameworks/Python.framework/Versions/3.7/lib/python3.7/grammar3.7.pickle")
    g.dump("test.pickle")
    g2 = Grammar()
    g2.load("test.pickle")
    g2.dump("test2.pickle")
    with open("test.pickle", "rb") as f1:
        p1 = f1.read()
    with open("test2.pickle", "rb") as f2:
        p2 = f2.read()
    assert p1 == p2


# Generated at 2022-06-11 19:42:53.051171
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.symbol2number = {'a': 1}
    grammar.number2symbol = {1: 'a'}
    grammar.states = [
        [
            [(0, 1), (2, 3)],
            [(4, 5), (6, 7)],
            [(8, 9), (10, 11)],
        ],
    ]
    grammar.dfas = {
        1: ([[(0, 1), (2, 3)], [(4, 5), (6, 7)], [(8, 9), (10, 11)]], {1: 1, 2: 1}),
    }
    grammar.labels = [(0, 'EMPTY'), (12, 'e'), (13, 'd'), (14, 'c'), (15, 'b')]
    grammar.keywords = {}

# Generated at 2022-06-11 19:43:02.394762
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle
    from os import path,remove
    from io import BytesIO

    class GrammarDumpTester(unittest.TestCase):

        def setUp(self):
            self.grammar = Grammar()
            self.grammar.symbol2number = {"foo": 1}
            self.grammar.number2symbol = {1: "foo"}
            self.grammar.states = [[(1, 2)]]
            self.grammar.dfas = {0: ([[(1, 2)]], {})}
            self.grammar.labels = [(1, "foo")]
            self.grammar.keywords = {"bar": 2}
            self.grammar.tokens = {3: 2}

# Generated at 2022-06-11 19:43:13.533872
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Dummy vars with normal content
    dummy_symbol2number = {'C': 3, 'B': 2, 'A': 1}
    dummy_number2symbol = {1: 'A', 2: 'B', 3: 'C'}
    dummy_states = [ [[(0, 'EMPTY')], [(1, 0)]] ]
    dummy_dfas = {1: ([[(0, 'EMPTY')], [(1, 0)]], {1: 1})}
    dummy_labels = [(1, 'A')]
    dummy_keywords = {'A': 1}
    dummy_tokens = {1: 2}
    dummy_symbol2label = {'A': 1}
    dummy_start = 1
    dummy_async_keywords = False
    # Create a dummy grammar
    dummy_

# Generated at 2022-06-11 19:43:24.798333
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import shutil

    test_dir = os.path.join(os.path.dirname(__file__), "test_load_data")

    def test_Grammar_load_pkl_file(pkl_filename):
        pkl_path = os.path.join(test_dir, pkl_filename)
        g = Grammar()
        g.load(pkl_path)
        assert g.symbol2number == {'ifelsestmt': 5, 'ifelsetest': 10, 'ifstmt': 7,
                                   'test': 12, 'while_stmt': 8}

# Generated at 2022-06-11 19:43:31.405819
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.async_keywords = False

        def __getstate__(self):
            return {
                "symbol2number": self.symbol2number,
                "number2symbol": self.number2symbol,
                "states": self.states,
                "dfas": self.dfas,
                "labels": self.labels,
                "keywords": self.keywords,
                "tokens": self.tokens,
                "symbol2label": self.symbol2label,
                "start": self.start,
                "async_keywords": self.async_keywords,
            }

    g = TestGrammar()
    g

# Generated at 2022-06-11 19:43:39.869340
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    class MyGrammar(Grammar):
        pass
    g = MyGrammar()
    g.symbol2number = {'b': 3, 'a': 2, 'c': 4}
    g.number2symbol = {3: 'b', 2: 'a', 4: 'c'}
    g.states = [[[2, 1], [2, 2], [2, 3], [1, 4]]]
    g.dfas = {2: ([[2, 1], [2, 2], [2, 3], [1, 4]], {1: 1, 2: 1, 3: 1, 4: 1})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, None), (4, None)]

# Generated at 2022-06-11 19:43:46.523957
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest.mock

    g = Grammar()
    g.dump("filename")

    with unittest.mock.patch("kalpana.pgen2.grammar.tempfile.NamedTemporaryFile") as m:
        f = unittest.mock.Mock()
        f.name = "tmp"
        m.return_value = f
        g = Grammar()
        g.dump("filename")
        os.replace.assert_called_with("tmp", "filename")

# Generated at 2022-06-11 19:43:55.124843
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dump("dummy.py")
    g2 = Grammar()
    g2.load("dummy.py")
    assert g == g2
    # TODO: What's the right way to test this?  g and g2 both had the
    # same dict items but dicts don't define __eq__.  I don't think
    # we need to compare the dict items themselves, just that the
    # objects have the same dict items.
    # assert g.__dict__ == g2.__dict__
    os.remove("dummy.py")

# Generated at 2022-06-11 19:44:04.146714
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Unit tests for method load of class Grammar.

    test_Grammar_load() first pickles some mapping data to a temporary
    file, then loads the file into a new mapping object, and compares
    the two.
    """

    # Define some mapping data to be pickled
    symbol2number = {
        "and": 1,
        "assert": 2,
        "break": 3,
        "class": 4,
        "continue": 5,
        "def": 6,
        "del": 7,
        "elif": 8,
        "else": 9,
        "except": 10,
    }

# Generated at 2022-06-11 19:44:11.949595
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test load() with a dummy grammar."""
    gram = Grammar()
    gram.start = 2
    gram.tokens = {"A": 1, "B": 2}
    gram.keywords = {"x": 3, "y": 4}
    gram.labels = [(0, "EMPTY"), (1, "A"), (2, "B"), (3, "x"), (4, "y")]
    gram.symbol2number = {"S": 0, "a": 1, "b": 2}
    gram.number2symbol = {0: "S", 1: "a", 2: "b"}