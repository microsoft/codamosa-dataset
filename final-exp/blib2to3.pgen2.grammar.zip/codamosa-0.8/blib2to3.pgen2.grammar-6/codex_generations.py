

# Generated at 2022-06-11 19:34:43.535013
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number["s1"] = 256
    g.symbol2number["s2"] = 257
    g.number2symbol[256] = "s1"
    g.number2symbol[257] = "s2"
    g.states.append([(0, 0), (0, 1), (0, 1)])
    g.states.append([(257, 1), (256, 1), (0, 2)])
    g.keywords["x"] = 0
    g.tokens[1] = 0
    g.labels.append((token.NAME, "NAME"))
    g.labels.append((1, "NUMBER"))
    g.labels.append((257, "s1"))
    g.symbol2label["s2"] = 257
   

# Generated at 2022-06-11 19:34:56.668435
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.symbol2number = {"foo": 100}
    grammar.number2symbol = {100: "foo"}
    grammar.states = [[(0, 1)]]
    grammar.dfas = {1: ([[(0, 1)]], {1: 1})}
    grammar.labels = [(0, None)]
    grammar.keywords = {"async": 1}
    grammar.tokens = {token.ASYNC: 1}
    grammar.symbol2label = {"foo": 1}
    grammar.start = 256
    grammar.async_keywords = False

    # we need to mock tempfile.NamedTemporaryFile
    import contextlib


# Generated at 2022-06-11 19:35:05.271284
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class Dummy(Grammar):

        def __init__(self) -> None:
            super().__init__()
            self.foo = "bar"
            self.baz = 123

    dummy = Dummy()
    dummy.dump("/tmp/.dummy")
    assert os.path.isfile("/tmp/.dummy")
    dummy2 = Dummy()
    dummy2.load("/tmp/.dummy")
    assert dummy2.foo == dummy.foo
    assert dummy2.baz == dummy.baz
    os.unlink("/tmp/.dummy")

# Generated at 2022-06-11 19:35:14.693830
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .parse import Parser
    from .conv import convert

    # check if Grammar.load works
    temp_dir = tempfile.TemporaryDirectory()
    path = os.path.join(temp_dir.name, "grammar.pkl")

    try:
        grammar = convert(grammar_file=os.path.join(
            os.path.dirname(__file__), "Grammar.txt"))
    except FileNotFoundError:
        print("Cannot find Grammar.txt")
        return

    try:
        grammar.dump(path)
        grammar2 = Grammar()
        grammar2.load(path)
    except FileNotFoundError:
        print("Failed to dump or load pickle file")
        return

    # check if the two grammars are identical

# Generated at 2022-06-11 19:35:23.997406
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a testing grammar
    g = Grammar()
    g.symbol2number = {'AaAa': 257, 'aAaA': 258}
    g.number2symbol = {257: 'AaAa', 258: 'aAaA'}
    g.states = [[[(1, 257), (2, 258)], [(3, 3)], [(4, 4)], [(5, 5)], [(6, 6)]]]

# Generated at 2022-06-11 19:35:32.922459
# Unit test for method load of class Grammar
def test_Grammar_load():
    # The following test is intended to confirm that the method load of class Grammar
    # can read a valid grammar data file and reconstruct the Grammar object it was
    # serialized from.
    import os, sys
    from . import pgen2
    from . import tokenize
    from . import token as token

    grammar = pgen2.load_grammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    assert isinstance(grammar, Grammar)
    assert len(grammar.symbol2number) == 298
    assert len(grammar.number2symbol) == 298
    assert len(grammar.states) == 542
    assert len(grammar.dfas) == 298
    assert len(grammar.labels) == 1018
    assert grammar.start == 256


# Generated at 2022-06-11 19:35:41.316079
# Unit test for method load of class Grammar
def test_Grammar_load():
    """This test creates a simple grammar that is given as input to a
    pickle file.  It then creates a Grammar object and calls load()
    on that pickle file to read the input grammar's data into the
    object.  For each instance variable in the object, this test
    prints the variable's name, its type, and its value.  This test is
    not comprehensive.
    """
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}

# Generated at 2022-06-11 19:35:48.651740
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()
    gr.symbol2number = {"a": 1, "b": 2}
    gr.number2symbol = {1: "a", 2: "b"}
    gr.states = [[(1, 1), (2, 2)], [(2, 2), (1, 1)]]
    gr.dfas = {1: ([(1, 1), (2, 2)], {1: 1, 2: 1, 3: 1}), 2: ([(2, 2), (1, 1)], {1: 1, 2: 1, 3: 1})}
    gr.labels = [(0, "EMPTY"), (1, None), (2, None)]
    gr.keywords = {"a": 1}
    gr.tokens = {1: 1}
    gr.start = 1
    # test file

# Generated at 2022-06-11 19:35:54.236318
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # The unit test parses the Python Grammar once.
    # It does not test the dump and load functions.

    from .pgen2 import driver

    # Get the Python Grammar
    gr = driver.load_grammar("Grammar.txt")
    # Parse it
    gr.parse("example/Grammar.txt")

# Generated at 2022-06-11 19:36:04.537374
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class TestGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)

    test_grammar = TestGrammar()
    test_grammar.dump("test_grammar.pkl")

    # Load the file again to check if the dumped data is same as the original data
    with open("test_grammar.pkl", "rb") as f:
        d = pickle.load(f)


# Generated at 2022-06-11 19:36:16.835794
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from textwrap import dedent
    from .conv import parse_grammar, compile_grammar
    from .pgen2 import driver
    from .tokenizer import generate_tokens, TokenInfo
    from . import token

    test = """\
        a = b c d
        b = d e
        c = "f"
        d = "e" | "f"
    """
    gl = parse_grammar(dedent(test))
    g = compile_grammar(gl)
    g.dump("grammar.pkl")

    with open("grammar.pkl", "rb") as f:
        pickle_d = pickle.load(f)
    print(pickle_d)


# Generated at 2022-06-11 19:36:23.276326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test dumped pickle can be reloaded
    import pickle
    g = Grammar()
    g.dump("Grammar.dump")
    pickle.loads(pickle.dumps(g))


if __name__ == "__main__":
    import sys

    g = Grammar()
    g.load(sys.argv[1])
    g.report()

# Generated at 2022-06-11 19:36:34.478373
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pkl")
    # pickle.load returns a dict which doesn't have a __dict__ attribute
    if hasattr(g, "__dict__"):
        d = g.__dict__
    else:
        d = g.__getstate__()  # type: ignore
    d["labels"].pop(0)

# Generated at 2022-06-11 19:36:42.597268
# Unit test for method load of class Grammar
def test_Grammar_load():
    import functools
    import unittest
    tc = unittest.TestCase()
    from . import grammar, conv, pickle

    g = grammar.Grammar()
    tc.assertEqual(g.tokens, {})
    # Load pickle.py into the Grammar object.
    # Make sure it can parse itself after loading.
    try:
        r = conv.parse(g, "pickle.py")
    except conv.ParseError:
        tc.fail("Can't parse pickle.py")
    f = open("pickle.py")
    src = f.read()
    f.close()
    if conv.parsesuccess is not None:
        tc.assertEqual(conv.parsesuccess(r), src)

# Generated at 2022-06-11 19:36:53.706526
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'a': 2, 'b': 3}
    g.number2symbol = {2: 'a', 3: 'b'}
    g.states = [0, 1]
    g.dfas = {2: (3, 4)}
    g.labels = [(5, 6), (7, 8)]
    g.keywords = {'9': 10}
    g.tokens = {11: 12}
    g.symbol2label = {'13': 14}
    g.start = 15
    g.async_keywords = True

    with tempfile.TemporaryDirectory() as f:
        g.dump(os.path.join(f, 'test'))
        h = Grammar()

# Generated at 2022-06-11 19:37:06.052700
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import datetime
    import io
    import pickle
    import sys
    import tempfile
    import unittest

    from typing import Optional
    from . import pgen

    pickle_proto = pickle.HIGHEST_PROTOCOL
    assert pickle_proto >= 3

    with tempfile.NamedTemporaryFile(mode="wb", delete=False) as f:
        test_file = f.name

# Generated at 2022-06-11 19:37:17.792926
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import unittest

    class GrammarLoadTests(unittest.TestCase):
        def test_load(self):
            g = Grammar()
            g.load(pkl)
            self.assertEqual(g.symbol2number, {'foo': 256, 'bar': 257})
            self.assertEqual(g.number2symbol, {256: 'foo', 257: 'bar'})
            self.assertEqual(g.states, [
                [(0, 1), (1, 2), (4, 3), (0, 4)],  # state 0
                [(1, 2), (4, 3), (0, 4)],  # state 1
                [],  # state 2
                [],  # state 3
                []  # state 4
            ])
            self.assertEqual

# Generated at 2022-06-11 19:37:29.294375
# Unit test for method load of class Grammar
def test_Grammar_load():
    import _ast

    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert isinstance(g.start, int)
    assert isinstance(g.labels, list)
    assert g.states and isinstance(g.states, list)
    for dfa in g.states:
        for state in dfa:
            for label, target in state:
                assert isinstance(label, int)
                assert isinstance(target, int)
    assert isinstance(g.dfas, dict)
    for key, (dfa, first) in g.dfas.items():
        assert isinstance(key, int)
        assert isinstance(dfa, list)
        assert isinstance(first, dict)

# Generated at 2022-06-11 19:37:40.301106
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    
    # Test case 1: an empty grammar
    grammar = Grammar()
    with tempfile.NamedTemporaryFile("wb+b") as f:
        grammar.dump(f.name)
        f.seek(0)
        grammar.load(f.name)
        assert grammar.symbol2number == {}
        assert grammar.number2symbol == {}
        assert grammar.states == []
        assert grammar.dfas == {}
        assert grammar.labels == [(0, "EMPTY")]
        assert grammar.keywords == {}
        assert grammar.tokens == {}
        assert grammar.symbol2label == {}
        assert grammar.start == 256
        assert grammar.async_keywords == False

    # Test case 2: a non-empty grammar

# Generated at 2022-06-11 19:37:41.162162
# Unit test for method load of class Grammar
def test_Grammar_load():
    print(Grammar().load)

# Generated at 2022-06-11 19:37:54.863921
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    from . import parse

    # Check that dump and load are inverses
    # This test will be removed once the pgen module is no longer used
    # in CPython.
    grammar = Grammar()
    # This assumes that the test file is syntactically correct Python
    filename = "Grammar.py"
    parse.pgen(grammar, filename)
    with tempfile.TemporaryDirectory() as dirname:
        filename = os.path.join(dirname, "test.pkl")
        grammar.dump(filename)
        grammar2 = Grammar()
        grammar2.load(filename)
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.number2symbol == grammar2.number2symbol
    assert grammar.states == grammar2.states

# Generated at 2022-06-11 19:38:00.346851
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from .conv import convert
    from .parse import test_grammar

    # create a Pickle of a Python grammar
    fname = tempfile.mktemp(".pkl")
    try:
        convert(test_grammar, fname)
        # load the generated Pickle file
        with open(fname, "rb") as f:
            pdata = pickle.load(f)

        g = Grammar()
        g.loads(pdata)
    finally:
        os.remove(fname)

# Generated at 2022-06-11 19:38:03.591018
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import py
    g = Grammar()
    f = py.path.local.make_numbered_dir(prefix='pytest-grammar-dump-')
    g.dump(str(f / "tables"))

# Generated at 2022-06-11 19:38:11.765909
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import pgen2.pgen
    import pgen2.conv
    import pickle

    g = pgen2.pgen.parse_grammar(pgen2.conv.pgen_grammar_file())
    f = io.BytesIO()
    pickle.dump(g.__getstate__(), f, pickle.HIGHEST_PROTOCOL)
    f.seek(0)
    gr = Grammar()
    gr.loads(f.read())
    assert gr.__getstate__() == g.__getstate__()

# Generated at 2022-06-11 19:38:19.265950
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from . import parse

    cwd = os.path.dirname(__file__)
    pickle_file_path = os.path.join(cwd, "Grammar.pickle")

    g = pgen2.generate_grammar()
    g.dump(pickle_file_path)

    g = Grammar()
    g.load(pickle_file_path)

    parse.Parser(g, "")
    assert True

# Generated at 2022-06-11 19:38:21.304808
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.txt")
    grammar.report()

# Generated at 2022-06-11 19:38:31.104057
# Unit test for method load of class Grammar
def test_Grammar_load():
    fn = "./Grammar.pickle"
    g1 = Grammar()
    g1.load(fn)
    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        print(dict_attr)
        print(getattr(g1, dict_attr))
    print("labels")
    print(g1.labels)
    print("states")
    print(g1.states)
    print("start")
    print(g1.start)
    print("async_keywords")
    print(g1.async_keywords)

# Generated at 2022-06-11 19:38:43.631825
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a temporary file
    filehandle, filename = tempfile.mkstemp()
    with os.fdopen(filehandle, 'wb') as f:
        f.close()

    # Create a Grammar instance
    g = Grammar()
    g.symbol2number = {'single': 256, 'double': 257}
    g.states = [([(0, 0)], (1, 2)), ([(0, 3)], (4, 5))]
    g.dfas = {256: (0, {1, 2}), 257: (1, {4, 5})}
    g.labels = [(0, None), (1, None), (2, None), (3, None), (4, None), (5, None)]
    g.start = 256
    g.dump(filename)

    # Reload the pickled

# Generated at 2022-06-11 19:38:51.108235
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    test_file = tempfile.TemporaryFile('wb')
    g.dump(test_file)
    test_file.seek(0)
    d = pickle.load(test_file)
    test_file.close()
    assert isinstance(d, dict)
    assert 'symbol2number' in d
    assert 'dfas' in d
    assert 'keywords' in d
    assert 'tokens' in d
    assert 'labels' in d
    assert 'start' in d
    assert 'async_keywords' in d
    assert g.symbol2number == d['symbol2number']
    assert g.number2symbol == d['number2symbol']
    assert g.dfas == d['dfas']

# Generated at 2022-06-11 19:39:02.912546
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.instance = Grammar()
            self.instance.symbol2number = {'test': 1}
            self.instance.number2symbol = {1: 'test'}
            self.instance.states = [[(1, 2)]]
            self.instance.dfas = {1: ([(1, 2)], {})}
            self.instance.labels = [(1, 2)]
            self.instance.keywords = {'test': 1}
            self.instance.tokens = {1: 1}
            self.instance.symbol2label = {'test': 1}
            self.instance.start = 256
            self.instance.async_keywords = True


# Generated at 2022-06-11 19:39:15.014414
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    class InnerGrammar(Grammar):
        # mypyc generates objects that don't have a __dict__, but they
        # do have __getstate__ methods that will return an equivalent
        # dictionary
        if hasattr(grammar, "__dict__"):
            d = grammar.__dict__
        else:
            d = grammar.__getstate__()  # type: ignore

        def __init__(self):
            self._update(InnerGrammar.d)

    inner_grammar = InnerGrammar()
    assert grammar.symbol2number == inner_grammar.symbol2number
    assert grammar.number2symbol == inner_grammar.number2symbol
    assert grammar.states == inner_grammar.states

# Generated at 2022-06-11 19:39:26.818788
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import os
    import sys
    import pickle
    from types import ModuleType

    # Ensure the generated pickle can be read on both Python 2 and 3.
    # This works because pickle on each version can only read pickles
    # generated by the same major version.
    if sys.version_info[0] == 3:
        major_ver = 3
    else:
        major_ver = 2

    class Grammar_dump_TestCase(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.pickle_file_py2 = os.path.join(self.tmpdir, "pgen_data_py2")

# Generated at 2022-06-11 19:39:27.664570
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    raise NotImplementedError()


# Generated at 2022-06-11 19:39:32.539822
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle

    g = Grammar()
    g.symbol2number = {'foo': 42}
    d = pickle.dumps(g)

    # XXX: This test is never run, but will be broken if the
    # Grammar class changes.
    h = Grammar()
    h.loads(d)
    assert h.symbol2number == g.symbol2number, h.symbol2number

# Generated at 2022-06-11 19:39:44.289460
# Unit test for method load of class Grammar
def test_Grammar_load():
    from io import BytesIO
    from pickle import dumps
    from test.test_grammar import pgen_grammar

    g = pgen_grammar("Grammar/Grammar")
    f = BytesIO()
    g.dump(f)
    f.seek(0)
    h = Grammar()
    h.load(f)
    assert g.states == h.states
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens
    assert g.symbol2label == h.symbol2label

# Generated at 2022-06-11 19:39:56.216941
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.number2symbol = {257: 'foo', 258: 'bar', 259: 'baz'}
    g.symbol2number = {'foo': 257, 'bar': 258, 'baz': 259}
    g.states = [
        [
            [(0, 1), (257, 2), (258, 3)],
            [(258, 4), (259, 5)],
            [(0, 2)],
            [(0, 3)],
            [(0, 4)],
            [(0, 5)],
        ]
    ]

# Generated at 2022-06-11 19:40:08.046846
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    import tempfile

    tempdir = tempfile.mkdtemp()

    # Dump from a string
    pkl = 'ccopy_reg\n_reconstructor\np0\n(cv1\nGrammar\np1\nc__main__\nGrammar\np2\ntRp3\nRp4\n.'
    x = Grammar()
    x.loads(pkl)
    assert x.symbol2number == {}
    assert x.number2symbol == {}
    assert x.states == []
    assert x.dfas == {}
    assert x.labels == [(0, 'EMPTY')]
    assert x.keywords == {}
    assert x.tokens == {}
    assert x.symbol2label == {}

# Generated at 2022-06-11 19:40:14.106342
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    pkl = Grammar().dump.__code__.co_code
    assert pkl.find(b"dump") > -1
    assert pkl.find(b"pickle") > -1
    assert pkl.find(b"tempfile") > -1

# Generated at 2022-06-11 19:40:24.123524
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:40:32.127234
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {
        "x": 256,
        "y": 257,
        "z": 258,
    }
    g.number2symbol = {
        256: "x",
        257: "y",
        258: "z",
    }
    g.states = [
        [[(0, 1), (0, 2)], [(258, 3), (0, 3)], [(0, 3)], [(0, 4), (258, 4)]],
        [[(0, 5), (257, 6), (0, 6)], [(0, 7)], [(0, 8), (257, 8)], [(0, 9), (0, 10)]],
    ]

# Generated at 2022-06-11 19:40:48.435784
# Unit test for method load of class Grammar
def test_Grammar_load():
    assert Grammar().load
    exp = "assert isinstance(filename, str), filename"
    with tempfile.NamedTemporaryFile() as f:
        g = Grammar()
        with raises(TypeError) as excinfo:
            g.loads(b'hello')
        assert excinfo.value.args[0] == exp

        g.loads(b'\x80\x02}q\x00.')
        g.dump(f.name)
        with open(f.name, "rb") as f:
            b = f.read()
        assert b == b'\x80\x02}q\x00.'
        with raises(TypeError) as excinfo:
            g.load(1)
        assert excinfo.value.args[0] == exp

# Generated at 2022-06-11 19:40:53.280174
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    # Create the file.
    g.dump('Grammar.pickle')
    # Verify that the file is written.
    assert os.path.isfile('Grammar.pickle')
    # Cleanup.
    os.remove('Grammar.pickle')

# Generated at 2022-06-11 19:40:57.650894
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test the store/load methods
    gram = Grammar()
    filename = "Grammar.pickle"
    gram.dump(filename)
    gram2 = Grammar()
    gram2.load(filename)
    assert gram == gram2
    os.unlink(filename)

# Generated at 2022-06-11 19:41:08.461128
# Unit test for method load of class Grammar
def test_Grammar_load():
    sample_DFA = [
        [(0, 1), (1, 2), (5, 1)],
        [(1, 3)],
        [(0, 3), (2, 3)],
        [(3, 4)],
        [(0, 5), (4, 4)],
    ]
    sample_DFAs = [sample_DFA]
    sample_Labels = [(0, None), (1, None), (1, "keyword"), (2, None), (3, None)]
    sample_symbol2num = {"a": 10, "b": 20}
    sample_num2symbol = {10: "a", 20: "b"}
    sample_keywords = {"keyword": 1}
    sample_tokens = {1: 1, 2: 2}

# Generated at 2022-06-11 19:41:17.937567
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class DummyGrammar(Grammar):
        def __init__(self, **kwargs):
            super().__init__()
            self.__dict__.update(kwargs)

    # Check that Grammar.dump doesn't throw exception, and
    # that Grammar.loads(Grammar.dump(dummygrammar))
    # returns an equivalent dummygrammar.
    dummygrammar1 = DummyGrammar(a=1, b='foo', c=['bar', [3, 4], 5], d={6: 7})
    fileobj = tempfile.NamedTemporaryFile()
    filename = fileobj.name
    fileobj.close()  # needed for Windows
    dummygrammar1.dump(filename)
    dummygrammar2 = DummyGrammar()
    dummygrammar2.load(filename)

# Generated at 2022-06-11 19:41:25.912848
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert len(g.symbol2number) == 0
    assert len(g.number2symbol) == 0
    assert len(g.states) == 0
    assert len(g.dfas) == 0
    assert len(g.labels) == 1
    assert len(g.keywords) == 0
    assert len(g.tokens) == 0
    assert len(g.symbol2label) == 0
    assert g.start == 256
    assert not g.async_keywords

# Generated at 2022-06-11 19:41:37.635351
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MyGrammar(Grammar):
        pass

    s2n = {"a": 0x100, "b": 0x101, "start": 0x100}
    n2s = {0x100: "a", 0x101: "b"}
    states = [[[(1, 0), (2, 1)], [[(3, 1), (4, 2)]]]]
    dfas = {0x100: (states[0], {1: 1, 2: 1}), 0x101: (states[0], {1: 1, 2: 1})}
    labels = [(token.NEWLINE, None), (0x100, None), (0x101, None)]
    g = MyGrammar()
    g.symbol2number = s2n
    g.number2symbol = n2s

# Generated at 2022-06-11 19:41:48.119497
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gr = Grammar()

    # add some attributes
    import os
    gr.symbol2number = {'program' : 0}
    gr.number2symbol = {0 : 'program'}
    gr.states = [1, 1]
    gr.dfas = {3 : (0,0), 4 : (1,1)}
    gr.labels = [(0,0), (1,1)]
    gr.keywords = {'def' : 0}
    gr.tokens = {0 : 0}
    gr.symbol2label = {'def' : 1}
    gr.start = 0
    gr.async_keywords = False

    filename = os.path.join(os.path.dirname(__file__), 'test_dump.pickle')

    gr.dump(filename)
    gr

# Generated at 2022-06-11 19:41:53.865392
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import tokenizer

    gr = Grammar()
    driver.load_grammar(gr, tokenizer)

    f = tempfile.NamedTemporaryFile()

    gr.dump(f.name)
    gr2 = Grammar()
    gr2.load(f.name)

    assert gr.keywords == gr2.keywords



# Generated at 2022-06-11 19:42:00.769662
# Unit test for method load of class Grammar
def test_Grammar_load():
    class my_Grammar(Grammar):
        def load(self, filename: Path) -> None:
            raise Exception("bug")

    old_opmap = Grammar.opmap
    try:
        Grammar.opmap = opmap
        f = tempfile.NamedTemporaryFile()
        filename = f.name
        g = my_Grammar()
        g.load(filename)
    finally:
        Grammar.opmap = old_opmap

# Generated at 2022-06-11 19:42:10.891009
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import pickle
    from pickle import UnpicklingError

    class MyGrammar(Grammar):
        def load(self, filename: str) -> None:
            if filename == "bad_file":
                pickle.load(sys.stdin)
            else:
                Grammar.load(self, filename)

    grammar = MyGrammar()
    with pytest.raises(UnpicklingError, match="load of persisted data failed"):
        grammar.load("bad_file")

# Generated at 2022-06-11 19:42:16.946165
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from io import BytesIO
    g = Grammar()
    g.symbol2number = {'a': 1, 'b': 2, 'c': 3}
    g.number2symbol = {1: 'a', 2: 'b', 3: 'c'}
    g.states = [[(0, 0), (1, 0), (2, 3)], [(0, 0), (1, 2)]]
    g.dfas = {1: ([(1, 0), (2, 3)], {}), 2: ([(0, 0), (1, 2)], {})}
    g.labels = [(0, 'EMPTY'), (1, None), (2, None), (3, 'KEYWORD')]
    g.keywords = {'abc': 3}

# Generated at 2022-06-11 19:42:27.492910
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pickle

    class TestGrammar(Grammar):
        def __init__(self) -> None:
            self.symbol2number = {'a': 256, 'b': 257}
            self.number2symbol = {256: 'a', 257: 'b'}
            self.states = [
                    [
                        [(1, 2), (3, 4)],
                        [(5, 6)],
                        [(7, 8)],
                        [(9, 10)],
                        []
                    ]
                ]
            self.dfas = {
                    256: (self.states[0], {}),
                    257: (self.states[0], {})
                  }

# Generated at 2022-06-11 19:42:29.979876
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar_obj = Grammar()
    grammar_obj.dump("Grammar.dump")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:42:41.644539
# Unit test for method load of class Grammar
def test_Grammar_load():
    # test the class method load by creating a test file and loading it
    text = """
    symbol2number = {}
    number2symbol = {}
    states = []
    dfas = {}
    labels = [(0, "EMPTY")]
    keywords = {}
    tokens = {}
    symbol2label = {}
    start = 256
    """
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(text.encode("utf8"))
    g = Grammar()
    g.load(f.name)
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
   

# Generated at 2022-06-11 19:42:50.881622
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # How to test the dump() method?
    # Simply create a grammar object, make sure its not None, then dump() it
    # and make sure the file is created and its not empty.
    import os
    import sys
    import shutil

    # Create a fake grammar
    g = Grammar()
    g.symbol2number = {"a": 1, "b": 2}
    g.number2symbol = {1: "a", 2: "b"}
    g.states = [[[(1, 2)], [(2, 1)]]]
    g.dfas = {1: ([[(1, 2)], [(2, 1)]], {1: 1}), 2: ([[(1, 2)], [(2, 1)]], {1: 1})}
    g.labels = [(0, "EMPTY")]


# Generated at 2022-06-11 19:43:01.335300
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    import tempfile
    from types import ModuleType

    # Save Grammar state
    symbol2number = Grammar.symbol2number
    number2symbol = Grammar.number2symbol
    states = Grammar.states
    dfas = Grammar.dfas
    labels = Grammar.labels
    keywords = Grammar.keywords
    tokens = Grammar.tokens
    symbol2label = Grammar.symbol2label
    start = Grammar.start
    async_keywords = Grammar.async_keywords

    # Set up temp file
    dummy_filename = "dummy_0r1rv1xd.pkl"
    dummy_path = os.path.join(tempfile.gettempdir(), dummy_filename)

    # Set up fake grammar table
    Grammar.symbol2number

# Generated at 2022-06-11 19:43:02.829414
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("Grammar.pickle")

# Generated at 2022-06-11 19:43:09.429377
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar.
    """
    from . import pgen2

    g = Grammar()
    g.loads(pgen2.pickle_grammar)

    assert g
    assert len(g.states) > 0
    assert len(g.dfas) > 0
    assert len(g.labels) > 0
    assert g.start > 0

# Generated at 2022-06-11 19:43:17.646972
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class Test(unittest.TestCase):
        def test_load(self):
            g = Grammar()

            g.symbol2number = {'key1': 'value1', 'key2': 'value2'}
            g.number2symbol = {'key3': 'value3', 'key4': 'value4'}
            g.states = ['value5', 'value6']
            g.dfas = {'key7': 'value7', 'key8': 'value8'}
            g.labels = ['value9', 'value10']
            g.keywords = {'key11': 'value11', 'key12': 'value12'}
            g.tokens = {'key13': 'value13', 'key14': 'value14'}
            g.symbol2

# Generated at 2022-06-11 19:43:27.689750
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test that Grammar.dump is pickleable"""
    import pickle
    from pgen2.grammar import Grammar

    g = Grammar()
    g.dump("./tmp")
    g2 = pickle.load(open("./tmp", "rb"))
    os.remove("./tmp")


if __name__ == "__main__":
    g = Grammar()
    test_Grammar_dump()

# Generated at 2022-06-11 19:43:31.587558
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dump("Grammar.dump")
    h = Grammar()
    h.load("Grammar.dump")
    # TODO: Verify that g and h contain the same data

# Generated at 2022-06-11 19:43:38.416036
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import sys
    import pytest

    g = Grammar()
    with pytest.raises(SystemExit) as exc_info:
        g.dump("file")
    assert exc_info.type is SystemExit
    assert exc_info.value.code == 0
    with open("file", 'rb') as f:
        data = f.read()
    os.remove("file")
    g2 = Grammar()
    g2.loads(data)
    # # Compare two Grammar using code to string
    assert str(g) == str(g2)

# Generated at 2022-06-11 19:43:44.924363
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class GrammarDumpTest(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {'a': 100, 'b': 200}
            self.number2symbol = {100: 'a', 200: 'b'}
            self.states = [
                [
                    [(0, 0), (1, 1)],
                    [(0, 1)],
                ],
                [],
            ]
            self.dfas = {100: (0, {100: 1})}
            self.labels = [
                (0, 'EMPTY'),
                (100, None),
            ]
            self.keywords = {'a': 1}
            self.tokens = { }
            self.symbol2label = {'a': 1}


# Generated at 2022-06-11 19:43:47.387552
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # TODO: Test is failing because of import of conv (deprecated)
    assert False, 'test failed'

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:43:57.162461
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    for filename in [
        "Grammar/Grammar.pkl",
        "Grammar/Grammar27.pkl",
        "Grammar/Grammar37.pkl",
    ]:
        grammar.load(filename)
        assert isinstance(grammar.states, list)
        assert isinstance(grammar.dfas, dict)
        assert isinstance(grammar.number2symbol, dict)
        assert isinstance(grammar.symbol2number, dict)
        assert isinstance(grammar.labels, list)
        assert isinstance(grammar.tokens, dict)
        assert isinstance(grammar.keywords, dict)

# Generated at 2022-06-11 19:44:07.364309
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import tempfile
    import shutil
    import sys

    class Tester(unittest.TestCase):
        def setUp(self):
            # save the grammar so we get the same one back
            self.original_grammar = sys.modules["spark_parser.grammar"].original_grammar
            self.moddir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.moddir)

        def test_it(self):
            # here's our tokenizer at work
            def tokenize(source):
                from io import StringIO

                from .tokenize import tokenize as tok

                return list(tok(StringIO(source).readline))


# Generated at 2022-06-11 19:44:13.590318
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    file_name = "test_Grammar.test_Grammar_dump.pkl"
    with open(file_name, "wb") as f:
        g = Grammar()
        g.dump(f)
        assert f.closed

    with open(file_name, "rb") as f:
        g = Grammar()
        g.load(f)
        assert g.symbol2number == {}
        assert f.closed

# Generated at 2022-06-11 19:44:22.774775
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that the load method works as expected.
    class MakeTestGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__(self)
            self.symbol2number = {"s2n": 2}
            self.number2symbol = {"n2s": 2}
            self.states = ["state"]
            self.dfas = {"dfas": "dfa"}
            self.labels = ["label"]
            self.keywords = {"keywords": "keyword"}
            self.tokens = {"tokens": "token"}
            self.symbol2label = {"symbol2label": "symbol"}
            self.start = 256


# Generated at 2022-06-11 19:44:27.045139
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Check that method dump of class Grammar does not raise exceptions.
    """
    g = Grammar()
    g.dump("build/Grammar_dump")

