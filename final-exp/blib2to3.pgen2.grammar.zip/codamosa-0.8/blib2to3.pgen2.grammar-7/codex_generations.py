

# Generated at 2022-06-11 19:34:43.534215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Make sure Grammar.dump can create a pickle file with protocol 4+

    # Cannot use importlib.util.module_from_spec as that requires Python 3.6
    # module_spec = importlib.util.spec_from_file_location('Grammar',
    #                                                      'Grammar.py')
    # module = importlib.util.module_from_spec(module_spec)
    # module_spec.loader.exec_module(module)

    # Create empty 'Grammar' module

    class ModuleType(type(token)):
        def __repr__(self):
            return '<module \'Grammar\' (built-in)>'

    module = ModuleType('Grammar')

    # Insert the class 'Grammar' in the module

    from .pgen2 import driver

    module

# Generated at 2022-06-11 19:34:49.136484
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(
        os.path.dirname(__file__), "Python3.6.pickle"
    )
    g = Grammar()
    g.load(filename)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:34:59.381126
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    from grammar_parser.grammar import Grammar
    import pickle

    # create a grammar object
    grammar_obj = Grammar()
    # set instance variables to be that of a grammar object
    grammar_obj.symbol2number = {'a': 99}
    grammar_obj.number2symbol = {99: 'a'}
    grammar_obj.states = [[[(1, 2)], [(3, 2)], [(3, 2), (1, 4)], [(0, 4)], [(0, 4)]]]
    grammar_obj.dfas = {'SYMBOL': [[[(1, 5)], [(0, 2)], [(0, 3)], [(1, 2)], [(0, 3)], [(0, 3)]], {1: 1}]}
    grammar_obj

# Generated at 2022-06-11 19:35:11.203926
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import pickle


# Generated at 2022-06-11 19:35:22.363245
# Unit test for method load of class Grammar
def test_Grammar_load():
    class C(Grammar):
        pass

    class D(C):
        pass

    c = C()
    d = D()

    for g in (c, d):
        g.load(os.path.join(os.path.dirname(__file__), "graminit.pkl"))

    assert c.symbol2number == d.symbol2number
    assert c.number2symbol == d.number2symbol
    assert c.keywords == d.keywords
    assert c.tokens == d.tokens
    assert c.states == d.states
    assert c.dfas == d.dfas
    assert c.labels == d.labels
    assert c.symbol2label == d.symbol2label
    assert c.start == d.start

    # Second load() call should

# Generated at 2022-06-11 19:35:31.942487
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    import unittest
    import types
    import warnings

    class FakeGrammarAttributes(object):
        pass

    class FakeGrammar(object):
        def __init__(self):
            self.__getstate__ = lambda: self.attr
            self.attr = FakeGrammarAttributes()

    class PickleTests(unittest.TestCase):
        def setUp(self):
            self.pickle_path = tempfile.mktemp()
            self.grammar = FakeGrammar()
            self.grammar.attr.a = 1
            self.grammar.attr.b = 2
            self.opened = False

        def tearDown(self):
            os.remove(self.pickle_path)


# Generated at 2022-06-11 19:35:40.750813
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, "EMPTY")]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False
    g.load("tests/data/Grammar.pickle")

# Generated at 2022-06-11 19:35:43.583602
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dump(str(__file__) + ".grammar")
    gg = Grammar()
    gg.load(str(__file__) + ".grammar")

# Generated at 2022-06-11 19:35:47.550319
# Unit test for method load of class Grammar
def test_Grammar_load():
    import os
    dfa_table = Grammar()
    dfa_table.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-11 19:35:52.567766
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Test Grammar.dump()"""
    path = tempfile.mktemp()
    grammar = Grammar()
    grammar.dump(path)
    with open(path, "rb") as f:
        pickle.load(f)
    os.remove(path)

# Generated at 2022-06-11 19:36:00.367194
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os.path
    import shutil
    import tempfile

    filename = tempfile.mkstemp()[1]

    grammar = Grammar()
    grammar.dump(filename)

    grammar2 = Grammar()
    grammar2.loads(open(filename, 'rb').read())

    assert grammar.symbol2number == grammar2.symbol2number

    os.remove(filename)

# Generated at 2022-06-11 19:36:04.993949
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar."""
    grammar = Grammar()
    grammar.dump("Grammar_dump.db")
    assert os.path.exists("Grammar_dump.db")
    os.remove("Grammar_dump.db")



# Generated at 2022-06-11 19:36:14.405776
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import tempfile
    from . import pgen2
    g = pgen2.driver.load_grammar("Grammar.txt")
    assert hasattr(g, "__dict__")
    f = tempfile.NamedTemporaryFile(delete=False)
    try:
        g.dump(f.name)
        # we can't use g = Grammar() here, as it doesn't have the
        # __getstate__/__setstate__ methods we need
        with open(f.name, "rb") as f:
            d = pickle.load(f)
        g2 = Grammar()
        g2._update(d)

        # Probably we should assert something is true here
    finally:
        os.remove(f.name)

# Generated at 2022-06-11 19:36:25.836211
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test that the method Grammar.load raises an exception when the Python version
    # differs from the version when the tables are created.
    import sys
    import warnings
    import pickle
    import unittest


    class Test_Grammar_load(unittest.TestCase):
        def setUp(self):
            # Save the current version
            self.version = sys.version_info
            sys.version_info = (2, 3, 0, 'final', 0)

            # Create a Grammar object
            self.grammar = Grammar()

        def test_load(self):
            # Check that the method load raises an exception when the Python version
            # differs from the version when the tables are created.
            b = pickle.dumps(self.grammar, pickle.HIGHEST_PROTOCOL)

# Generated at 2022-06-11 19:36:35.243979
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {1: "foo"}
    g.symbol2number = {1: "foo"}
    g.states = [[[(1, 0)]]]
    g.dfas = {1: ([[(1, 0)]], {1: 1}),
              2: ([[(1, 0)]], {1: 1})}
    g.labels = [(1, None)]
    g.keywords = {'foo' : 1}
    g.tokens = {1 : 1}
    g.start = 1
    g.dump("/tmp/test.out")
    f = open("/tmp/test.out", "rb")
    d = pickle.load(f)
    f.close()

# Generated at 2022-06-11 19:36:43.014259
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    pg = driver.load_grammar("Grammar.txt")
    filename = "Grammar.dump"
    pg.dump(filename)
    pg2 = Grammar()
    pg2.load(filename)
    os.remove(filename)
    assert pg.symbol2number == pg2.symbol2number
    assert pg.number2symbol == pg2.number2symbol
    assert pg.tokens == pg2.tokens
    assert pg.keywords == pg2.keywords
    # assert pg.start == pg2.start
    # assert pg.states == pg2.states
    # assert pg.labels == pg2.labels
    # assert pg.dfas == pg2.dfas



# Generated at 2022-06-11 19:36:54.010323
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class TestGrammar(Grammar):
        def __init__(self) -> None:
            super().__init__()
            self.symbol2number = {"one": 1, "two": 2, "three": 3}
            self.number2symbol = {1: "one", 2: "two", 3: "three"}
            self.states = [
                [
                    [(5, 2), (6, 1)],
                    [(2, 3), (3, 1), (4, 4)],
                    [(3, 3), (4, 4)],
                    [],
                    [(3, 4)],
                ]
            ]

# Generated at 2022-06-11 19:36:59.960709
# Unit test for method load of class Grammar
def test_Grammar_load():
    import tokenize
    from . import pytree
    from . import pgen2
    from . import driver
    from .pgen2 import grammar, parse, tokenize as pgen2_tokenize
    from .pgen2 import convert
    import pickle

    pgen = parse.PyParser(grammar, convert, parse.PyParser._token2symbol)


# Generated at 2022-06-11 19:37:05.496887
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

    from .pgen2 import driver

    driver.load_grammar(g)
    g.dump(tempfile.NamedTemporaryFile(delete=False).name)
    g2 = Grammar()
    g2.load(tempfile.NamedTemporaryFile(delete=False).name)

# Generated at 2022-06-11 19:37:11.885524
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pathlib
    import sys
    import unittest

    from . import pgen2
    from . import token

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            # Grammar.dump() dumps the grammar tables to a pickle file
            g_file = pathlib.Path(__file__).with_name("Grammar.pkl")
            g = pgen2.generate_grammar("Python3.grammar")
            g.dump(g_file)
            h = Grammar()
            h.load(g_file)
            self.assertEqual(g.keywords, h.keywords)
            self.assertEqual(g.opmap, h.opmap)
            self.assertEqual(g.tokens, h.tokens)


# Generated at 2022-06-11 19:37:29.065757
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {'A': 256}
    g.number2symbol = {256: 'A'}
    g.keywords = {'async': 1}
    g.tokens = {42: 1}
    g.labels = [(1, 'async'), (2, 'x')]
    g.states = [[(2, 1)]]
    g.dfas = {256: ([(2, 1)], {42: 1})}
    g.start = 256

    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        g2 = Grammar()
        g2.load(f.name)

    assert g.symbol2number == g2.symbol2number

# Generated at 2022-06-11 19:37:39.028003
# Unit test for method dump of class Grammar
def test_Grammar_dump():
	class DummyGrammar(Grammar):
		def __init__(self):
			super().__init__()
			self.x = "x"
			self.y = "y"
	import pickle
	fn = "test.pkl"
	if os.path.exists(fn):
		os.remove(fn)
	g = DummyGrammar()
	g.dump(fn)
	with open(fn, "rb") as f:
		d = pickle.load(f)
	os.remove(fn)
	for k in ("x", "y"):
		assert k in d
	

# Generated at 2022-06-11 19:37:41.633166
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    import pytest

    with pytest.raises(TypeError):
        g = Grammar()
        g.dump(2)



# Generated at 2022-06-11 19:37:53.135458
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

# Generated at 2022-06-11 19:38:01.190617
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    grammar = Grammar()

    # check that dump actually writes to file
    grammar.dump("Grammar_dump.pickle")
    os.utime("Grammar_dump.pickle", None)

    # check that grammar was successfully loaded
    pickle_file = open("Grammar_dump.pickle", "rb")
    pickle_data = pickle_file.read()
    grammar.loads(pickle_data)
    for attr in pickle_data.decode("latin-1").split("\n"):
        if attr in grammar.__dict__.keys() and attr != "dfas":
            if grammar.__dict__[attr] != {}:
                assert grammar.__dict__[attr]
    assert len(grammar.dfas) == 0

    # delete file
    os.remove

# Generated at 2022-06-11 19:38:12.120247
# Unit test for method load of class Grammar
def test_Grammar_load():
    ast = Grammar()

# Generated at 2022-06-11 19:38:22.299804
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    s = b'cposix\n_LazyCorpusLoader\np0\n(csklearn.utils.murmurhash\n_hash\np1\n'
    s += b'(cbuiltins\nobject\np2\nNtp3\nRp4\n(dp5\n.'
    s += b'A\x1b\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    s += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-11 19:38:32.256969
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.labels.append((token.NAME, None))
    g.labels.append((token.NEWLINE, None))

    dfa1 = []
    dfa2 = []
    dfa3 = [[(0,1), (1,1)], [(0,2), (1,1), (1,2)]]

    g.states.append(dfa1)
    g.states.append(dfa2)
    g.states.append(dfa3)

    g.dfas[257] = (g.states[2], {token.NAME:1, token.NEWLINE:1})
    g.dfas[258] = (g.states[0], {token.NAME:1, token.NEWLINE:1})

# Generated at 2022-06-11 19:38:44.258542
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def check(symbol2number, number2symbol, states, dfas, labels,
              keywords, tokens, symbol2label, start):
        assert g.symbol2number == symbol2number
        assert g.number2symbol == number2symbol
        assert g.states == states
        assert g.dfas == dfas
        assert g.labels == labels
        assert g.keywords == keywords
        assert g.tokens == tokens
        assert g.symbol2label == symbol2label
        assert g.start == start

    g = Grammar()
    g.symbol2number = {'a': 100, 'b': 101, 'c': 102}
    g.number2symbol = {100: 'a', 101: 'b', 102: 'c'}

# Generated at 2022-06-11 19:38:46.988936
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .conv import conv
    from .pgen import driver

    grammar = Grammar()
    grammar.load(driver.main(conv.convert, "Python.asdl", "Python/ast.py"))

# Generated at 2022-06-11 19:39:27.030891
# Unit test for method dump of class Grammar

# Generated at 2022-06-11 19:39:38.629181
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2
    from .pgen2 import tokenize

    name = "left-recursion-test"
    path = os.path.join(os.path.dirname(__file__), "Grammar.dump")
    g: Grammar = pgen2.driver.load_grammar(name)
    assert g.start == g.symbol2number["file_input"]
    assert g.start == 256
    if os.path.exists(path):
        assert os.path.isfile(path)
    g.dump(path)
    assert g.start == 256
    assert os.path.exists(path)
    assert os.path.isfile(path)
    assert g.async_keywords == tokenize.async_keywords

# Generated at 2022-06-11 19:39:40.858659
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-11 19:39:44.633563
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    pickle_file = tempfile.mktemp()
    grammar.dump(pickle_file)
    # check if file exists
    file_exists = os.path.isfile(pickle_file)
    os.remove(pickle_file)
    assert file_exists

# Generated at 2022-06-11 19:39:56.634225
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import importlib
    import grammar
    import _ast
    import pygram

    def monkey_patch(old_method, new_method):
        import types

        def get_func(new_method):
            def new_func(self, *args, **kwargs):
                return new_method(self, *args, **kwargs)

            return new_func

        old_method_func = types.MethodType(get_func(old_method), None)
        setattr(old_method.__self__, old_method.__name__, new_method)

    def is_identifier(name):
        return all(c.isidentifier() for c in name)


# Generated at 2022-06-11 19:40:06.325964
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import shutil
    import os
    import pgen2.parse
    import pgen2.grammar

    tmpname = "/tmp/test_Grammar_dump"
    if os.path.exists(tmpname):
        shutil.rmtree(tmpname)
    os.mkdir(tmpname)

    try:
        g = pgen2.grammar.Grammar()
        g.load(pgen2.parse.__file__[:-1])
        g.dump(tmpname + "/graminit.dmp")
        g.load(tmpname + "/graminit.dmp")
    finally:
        shutil.rmtree(tmpname)

# Generated at 2022-06-11 19:40:14.032369
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), 'Grammar.pickle'))
    assert g.symbol2number['single_input'] == 257
    assert g.symbol2number['eval_input'] == 258
    assert g.symbol2number['decorated'] == 259
    assert g.symbol2number['async_funcdef'] == 260
    assert g.symbol2number['funcdef'] == 261
    assert g.symbol2number['parameters'] == 262
    assert g.symbol2number['typedargslist'] == 263
    assert g.symbol2number['tfpdef'] == 264
    assert g.symbol2number['varargslist'] == 265
    assert g.symbol2number['vfpdef'] == 266

# Generated at 2022-06-11 19:40:23.562561
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:40:25.452056
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("/tmp/Grammar.pickle")
    g.report()


# Generated at 2022-06-11 19:40:33.989673
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class GrammarTestCase(unittest.TestCase):
        def test_dump(self):
            g = Grammar()

# Generated at 2022-06-11 19:41:09.890432
# Unit test for method load of class Grammar
def test_Grammar_load():
    from os import unlink
    from os.path import basename, dirname, isfile
    from tempfile import TemporaryDirectory
    from typing import Sequence
    import_file = __file__
    filename = basename(import_file)
    temp_dir = dirname(import_file) if isfile(import_file) else TemporaryDirectory()
    dump_file = temp_dir.name + f'{os.sep}{filename}.dump'
    dump_file_in_memory = dump_file + b'.in_memory'
    _dumped_Grammar = Grammar()
    _dumped_Grammar.dump(dump_file)
    _loaded_Grammar = Grammar()
    _loaded_Grammar.load(dump_file)
    _dumped_Grammar_in_memory = Grammar()
   

# Generated at 2022-06-11 19:41:18.900504
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    import tempfile
    import os

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 0), (2, 1)], [(1, 1), (3, 1)]]]
    g.dfas = {1: (0, {1: 1, 2: 1}), 2: (0, {3: 1, 4: 1})}
    g.labels = [(1, 'foo'), (2, 'bar'), (3, None), (4, 'baz')]
    g.start = 1

    fd, fn = tempfile.mkstemp()
    os.close(fd)

    g.dump(fn)


# Generated at 2022-06-11 19:41:28.825380
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test the method load of class Grammar"""
    grammar = Grammar()
    d = {
        "symbol2number" : {"_" : 256, "a" : 257, "b" : 258},
        "number2symbol" : {256 : "_", 257 : "a", 258 : "b"},
        "states" : [[[(257, 1)]], [[(258, 2)]]],
        "labels" : [[256, None], [256, None], [256, None]],
        "keywords" : {"_" : 1, "a" : 2},
        "tokens" : {257 : 1, 258 : 2},
        "symbol2label" : {"_" : 1, "a" : 2},
        "start" : 256
    }

# Generated at 2022-06-11 19:41:33.567007
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    temp_file = tempfile.NamedTemporaryFile(mode='w+')
    temp_file.close()
    grammar.dump(temp_file.name)
    grammar.load(temp_file.name)

# Generated at 2022-06-11 19:41:40.608898
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    import os
    import sys

    if sys.version_info >= (3, 8):
        import importlib.resources as pkg_resources
        from . import testdata
    else:
        import importlib_resources as pkg_resources
        from . import testdata_py37 as testdata

    with pkg_resources.open_binary(testdata, "G1.pkl") as f:
        s = f.read()
    p = pickle.loads(s)
    g = Grammar()
    g.loads(s)
    assert g.symbol2number == p.symbol2number
    assert g.number2symbol == p.number2symbol
    assert g.states == p.states
    assert g.dfas == p.dfas

# Generated at 2022-06-11 19:41:50.155304
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'COMMA': 258, 'LPAR': 256, 'NAME': 257}
    g.number2symbol = {256: 'LPAR', 257: 'NAME', 258: 'COMMA'}
    g.labels = [(0, 'EMPTY'), (256, None), (257, None), (258, None)]
    g.keywords = {'COMMA': 258}
    g.tokens = {256: 256, 257: 257, 258: 258}
    g.symbol2label = {}
    g.start = 256

    #
    # Note: in order to make the test deterministic, we need to
    #       make sure that we can force the dump() to write to a
    #       temporary file, i.e. to avoid any effect by the presence
   

# Generated at 2022-06-11 19:41:53.453491
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    for k in ("symbol2number", "number2symbol", "states", "dfas", "labels"):
        assert hasattr(g, k)

# Generated at 2022-06-11 19:42:02.198534
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test Grammar.load()"""
    g = Grammar()

    # Test a bogus filename
    try:
        g.load('bogus')
    except FileNotFoundError:
        pass
    else:
        raise AssertionError('FileNotFoundError not raised for bogus file')

    # Test an empty file
    try:
        g.load('__init__.py')
    except EOFError:
        pass
    else:
        raise AssertionError('EOFError not raised for empty file')

    # Test an unreadable file
    # XXX not tested

    # Test a bad pickle file
    # XXX not tested

    # Test an unloadable pickle file
    # XXX not tested

# Generated at 2022-06-11 19:42:12.415085
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import pytest
    import types

    g = Grammar()
    g.symbol2number = {'foo': 1003}
    g.number2symbol = {1003: 'foo'}
    g.keywords = {'blah': 1}
    g.tokens = {2: 3}
    g.symbol2label = {'foo': 12}
    g.labels = [('bar', 'baz')]
    g.states = [0, 1, 2]
    g.dfas = {4: (0, 1)}
    g.start = 5
    g.async_keywords = True
    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        f.file.seek(0)

        g1 = Grammar()

# Generated at 2022-06-11 19:42:22.829623
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a Grammar object
    g = Grammar()
    # Force the creation of the .pickle file
    g.report()
    # Assert that the .pickle file is created
    assert os.path.exists("Grammar.pickle")
    # Create new Grammar object
    g2 = Grammar()
    # Load the .pickle file in the new Grammar object
    g2.load("Grammar.pickle")
    # Assert that the data was loaded
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas == g2.dfas
    assert g.labels == g2.labels

# Generated at 2022-06-11 19:43:17.618045
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:43:28.266927
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar."""
    grammar = Grammar()
    grammar.load("_test/Grammar_test.pickle")
    assert grammar.symbol2number == {'and': 258, 'atom': 259, 'expr': 260, 'testlist': 261}
    assert grammar.number2symbol == {258: 'and', 259: 'atom', 260: 'expr', 261: 'testlist'}

# Generated at 2022-06-11 19:43:33.224290
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from tokenize import tokenize, NAME, OP
    from io import BytesIO
    from .dfasim import DFAState
    from .dfa import DFA
    import random
    from .gen import generate_label, generate_keyword, generate_token

    # Build a grammar
    g = Grammar()
    syms = [generate_label() for _ in range(random.randint(6, 10))]
    syms.append("EMPTY")
    for s in syms:
        g.symbol2number[s] = len(g.number2symbol) + 256
        g.number2symbol[len(g.number2symbol) + 256] = s
    for _ in range(random.randint(1, 3)):
        name = generate_label()
        g.sy

# Generated at 2022-06-11 19:43:37.312868
# Unit test for method load of class Grammar
def test_Grammar_load():
    test_grammar = Grammar()
    test_grammar.dump("./pgen_grammar.pkl")
    new_grammar = Grammar()
    new_grammar.load("./pgen_grammar.pkl")
    os.remove("./pgen_grammar.pkl")

# Generated at 2022-06-11 19:43:47.718975
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys
    try:
        from test.support import temp_cwd
    except ImportError:
        import tempfile
        temp_cwd = tempfile.TemporaryDirectory

    g = Grammar()
    with temp_cwd() as dirname:
        g.dump(os.path.join(dirname, "Grammar.pickle"))
        g.dump(os.path.join(dirname, "Grammar" + os.extsep + "pickle"))
    with temp_cwd() as dirname:
        if sys.platform.startswith("win"):
            g.dump("\\\\?\\" + os.path.join(dirname, "Grammar.pickle"))

# Generated at 2022-06-11 19:43:57.983854
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    import io
    # Pickle a couple grammar objects to ByteStreams
    g1 = Grammar()
    g1.symbol2number = {'NAME': 1, 'NUMBER': 2, 'STRING': 3, 'NEWLINE': 4, 'INDENT': 5, 'DEDENT': 6, 'ENDMARKER': 7, 'LPAR': 8, 'RPAR': 9}
    g1.number2symbol = {1: 'NAME', 2: 'NUMBER', 3: 'STRING', 4: 'NEWLINE', 5: 'INDENT', 6: 'DEDENT', 7: 'ENDMARKER', 8: 'LPAR', 9: 'RPAR'}

# Generated at 2022-06-11 19:43:59.473226
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load("/dev/null")
    grammar.loads(b"")

# Generated at 2022-06-11 19:44:01.615052
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    G = Grammar()
    s = BytesIO()
    G.dump(s)
    G2 = Grammar()
    G2.loads(s.getvalue())

# Generated at 2022-06-11 19:44:04.032528
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "grammar.pickle"
    grammar.dump(filename)
    assert os.path.exists(filename)
    os.unlink(filename)

# Generated at 2022-06-11 19:44:07.225034
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import py_compile
    py_compile.compile("Grammar.py")
    sys.exit(0)