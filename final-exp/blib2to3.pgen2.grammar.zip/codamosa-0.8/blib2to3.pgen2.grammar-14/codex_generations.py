

# Generated at 2022-06-11 19:34:56.690752
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import copy
    import os
    import pickle
    import unittest

    class PickleTestCase(unittest.TestCase):
        _LEGACY_SAVE_OPTION = pickle.HIGHEST_PROTOCOL

        _LEGACY_PROTOCOLS = [0, 1, 2, pickle.HIGHEST_PROTOCOL - 1]

        def load_test_data(self):
            raise NotImplementedError

        def check_data(self, data):
            raise NotImplementedError

        def create_data(self):
            raise NotImplementedError

        def test_pickling(self):
            data = self.create_data()
            data1 = copy.deepcopy(data)

# Generated at 2022-06-11 19:35:08.870136
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import pgen2
    from . import token, tokenize
    from io import BytesIO
    class TestGrammarMethods(unittest.TestCase):
        def test_Grammar_dump(self):
            gr = pgen2.driver.load_grammar("Grammar/Grammar")
            fd = BytesIO()
            gr.dump(fd)
            gr.loads(fd.getvalue())
            tkn = tokenize.generate_tokens(BytesIO("print(1 + 2)").readline)

# Generated at 2022-06-11 19:35:20.016730
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test = Grammar()
    test.symbol2number = {'s1': 4, 's2': 5}
    test.number2symbol = {4: 'c1', 5: 'c2'}
    test.states = [[[(1, 2), (3, 4)]], [[(5, 6), (7, 8)]]]
    test.dfas   = {3: ([[(1, 2), (3, 4)]], {1: 1}), 4: ([[(5, 6), (7, 8)]], {5: 1})}
    test.labels = [(0, "EMPTY"), (1, None), (2, None), (3, None), (4, 'c1'), (5, 'c2'), (6, None), (7, None), (8, None)]

# Generated at 2022-06-11 19:35:23.270115
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # verify we can dump the pickle file to disk
    grammar = Grammar()
    tmpfile = tempfile.NamedTemporaryFile()
    grammar.dump(tmpfile.name)
    tmpfile.close()

# Generated at 2022-06-11 19:35:32.618882
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    This method tests the dump method of class Grammar. It checks that the
    method works as intended, and also checks that if a problem occurs,
    the correct error is raised.
    """
    import pickle
    import os
    import tempfile
    import filecmp
    from typing import Optional, Any

    def _check(a: Any, b: Any) -> bool:
        """
        This method compares two files. It returns True if their
        content is the same, and False if not.
        """
        return filecmp.cmp(a, b)

    def get_temp_file(prefix: str) -> str:
        fd: int
        filename: str
        with tempfile.TemporaryDirectory() as temp_dir:
            fd, filename = tempfile.mkstemp(prefix=prefix, dir=temp_dir)

# Generated at 2022-06-11 19:35:42.635502
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 1
    g.symbol2number["foo"] = 2
    g.number2symbol[2] = "foo"
    g.keywords["bar"] = 3
    g.tokens[4] = 5
    g.labels = [(6, "baz"), (7, "qux")]
    g.states = [[[(8, 9)], [(10, 11)]]]
    g.dfas[12] = ([[(13, 14), (15, 16)]], {17: 18})
    g.symbol2label["zap"] = 19
    g.async_keywords = False

    d = tempfile.mktemp()

# Generated at 2022-06-11 19:35:53.820423
# Unit test for method load of class Grammar
def test_Grammar_load():
    import doctest

    g = Grammar()
    doctest.run_docstring_examples(g.load, globals(), True, __name__)

    # doctest.testmod()
    # doctest.testmod(m, *args, **kwargs)
    # doctest.run_docstring_examples(p, globals, verbose, name)

    # doctest.run_docstring_examples(__import__(os.path.basename(__file__).split('.')[0]),globals(),verbose=True,name=__name__)

    # if __name__=='__main__':
    #   doctest.testmod()

# Generated at 2022-06-11 19:35:55.542765
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.pickle")


# Generated at 2022-06-11 19:36:06.273714
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import _testcapi
    class Grammar2(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number[None] = 1
            self.number2symbol[2] = None
            self.states = [1,2]
            self.dfas = {1 : (1,2)}
            self.labels = [(1,2,3)]
            self.keywords = {1 : 2}
            self.tokens = {1 : 2}
            self.symbol2label = {1 : 2}
            self.start = 3


# Generated at 2022-06-11 19:36:15.558006
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """This is a unit test for method dump of class Grammar."""

    # Create the grammar
    grammar = Grammar()
    grammar.symbol2number["START"] = 0
    grammar.number2symbol[0] = "START"
    grammar.states.append([(1, 0), (2, 0)])
    grammar.states.append([(3, 0), (4, 0)])
    grammar.labels.append(("EMPTY", None))
    grammar.labels.append(("EMPTY", None))
    grammar.labels.append(("EMPTY", None))
    grammar.labels.append(("EMPTY", None))
    grammar.start = 0

    # Dump the grammar
    grammar.dump(tempfile.gettempdir() + "\\Grammar_dump_test.pkl")


# Generated at 2022-06-11 19:36:31.201310
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Asserts Grammar loads works for files created with dump
    """
    filename = "test1"
    g1 = Grammar();
    g1.dump(filename)
    g2 = Grammar();
    g2.load(filename)
    if g1.symbol2number != g2.symbol2number or g1.number2symbol != g2.number2symbol or g1.states != g2.states or g1.dfas != g2.dfas or g1.labels != g2.labels or g1.keywords != g2.keywords or g1.tokens != g2.tokens or g1.symbol2label != g2.symbol2label or g1.start != g2.start:
        raise AssertionError()
    os.remove(filename)

# Generated at 2022-06-11 19:36:33.652806
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("bnf_parse.pickle")
    with open("bnf_parse.pickle", "rb") as f:
        d = pickle.load(f)
        assert d == g.__dict__



# Generated at 2022-06-11 19:36:38.441983
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from io import BytesIO

    g = Grammar()
    driver.parse_grammar("Grammar/Grammar", g)
    out = BytesIO()
    g.dump(out)
    out = BytesIO(out.getvalue())
    g2 = Grammar()
    g2.loads(out.getvalue())


# Generated at 2022-06-11 19:36:44.935024
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import tempfile
    import unittest

    # A subclass of Grammar that implements method dump()
    class GrammarSubclass(Grammar):

        def __init__(self) -> None:
            Grammar.__init__(self)
            self.symbol2number = {'start': 256, 'keyword': 257, 'token': 258}
            self.number2symbol = {256: 'start', 257: 'keyword', 258: 'token'}
            self.states = [[[(1, 1)], [(0, 2)]], [[(0, 3)]]]

# Generated at 2022-06-11 19:36:54.916333
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {'foo': 13, 'bar': 14, 'baz': 15}
    g.number2symbol = {13: 'foo', 14: 'bar', 15: 'baz'}
    g.start = 256
    g.keywords = {'foo': 1, 'bar': 2, 'baz': 3}
    g.tokens = {'foo': 1, 'bar': 2, 'baz': 3}
    g.symbol2label = {'foo': 1, 'bar': 2, 'baz': 3}
    g.labels = [(0, "EMPTY")]

# Generated at 2022-06-11 19:37:00.692314
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv

    def path(f):
        if __name__ == "__main__":
            return f

        return os.path.join(os.path.dirname(conv.__file__), f)

    g = Grammar()
    g.dump(path("Grammar.dump.new"))
    g = Grammar()
    g.load(path("Grammar.dump"))

# Generated at 2022-06-11 19:37:07.883858
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.pickle')
    assert len(g.symbol2number) == 118
    assert len(g.number2symbol) == 118
    assert len(g.states) == 119
    assert len(g.dfas) == 118
    assert len(g.labels) == 923
    assert len(g.keywords) == 77
    assert len(g.tokens) == 77
    assert g.start == 256
    assert g.async_keywords == False

# Generated at 2022-06-11 19:37:18.868059
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from io import BytesIO

    g = Grammar()
    g.symbol2number['name'] = 99
    g.number2symbol[99] = 'name'
    g.states = [
        [(1, 1), (2, 2)],
        [(3, 3), (4, 4)],
        [(5, 5)],
        [(6, 6)],
        [(7, 7)],
        [(8, 8)],
    ]
    g.dfas = {
        0: ([[(0, 5)]], {}),
        1: ([[(0, 6)]], {}),
        2: ([[(0, 7)]], {}),
    }

# Generated at 2022-06-11 19:37:29.737980
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def _check_load(g: Grammar) -> None:
        filename = "test_Grammar_dump.pkl"
        try:
            g.dump(filename)
            g.clear()
            g.load(filename)
        finally:
            try:
                os.remove(filename)
            except OSError:
                pass

    g = Grammar()
    g.symbol2number = {'EMPTY': 256, 'file_input': 258}
    g.number2symbol = {256: 'EMPTY', 258: 'file_input'}
    g.states = [[[(3, 1)], [(2, 1)]]]

# Generated at 2022-06-11 19:37:36.235328
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert grammar.start == 257
    # A final state has a label 0, indicating completion of the rule.
    assert (0, 4) in grammar.states[4]
    assert (4, 4) in grammar.states[4]

# Generated at 2022-06-11 19:37:46.533464
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import tempfile
    from pickle import Unpickler

    def read_pickle(filename):
        with open(filename, "rb") as file:
            return Unpickler(file).load()

    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 1), (2, 2)], [(3, 3), (4, 4)], [(5, 5), (6, 6)]]]

# Generated at 2022-06-11 19:37:51.037584
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.states = []
    g.dfas = {2: ([[],[[0,0]]], {0: 0})}
    g.symbol2number = {}
    g.number2symbol = {}
    g.labels = [(0, "EMPTY")]
    g.keywords = {}
    g.tokens = {}
    g.symbol2label = {}
    g.start = 256
    g.dump("")


if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:37:52.925170
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load(__file__.replace(".py", ".pkl"))

# Generated at 2022-06-11 19:37:59.655510
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import py_compile
    import importlib.util

    # compile a simple grammar to a temporary file
    with tempfile.NamedTemporaryFile() as f:
        py_compile.compile("import ast", f.name)

        # load the compiled grammar
        descr = importlib.util.spec_from_file_location("test", f.name)
        m = importlib.util.module_from_spec(descr)
        descr.loader.exec_module(m)


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:38:06.882357
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.states = [[(1, 2), (3, 3)], [(1, 2), (3, 3)]]
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)

    grammar.states = [[(3, 4), (7, 8)]]
    grammar.load(f.name)
    assert grammar.states == [[(1, 2), (3, 3)], [(1, 2), (3, 3)]]
    os.remove(f.name)

# Generated at 2022-06-11 19:38:09.353256
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = './Grammar.pickle'
    g = Grammar()
    g.dump(filename)
    g1 = Grammar()
    g1.load(filename)


# Generated at 2022-06-11 19:38:11.398864
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert not g.dfas
    g.load(token.__file__.rstrip("co"))
    assert g.dfas

# Generated at 2022-06-11 19:38:17.184127
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    filename = "tmp/tpickle2.pkl"
    if os.path.exists(filename):
        os.remove(filename)

    g = Grammar()
    g.dump(filename)

    assert os.path.exists(filename)
    os.remove(filename)

# Generated at 2022-06-11 19:38:20.920350
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test loading a pickled grammar
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))

# Generated at 2022-06-11 19:38:31.336337
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pkgutil
    import sys
    from .pgen2 import tokenize as pgen_tokenize
    from . import tokenize as tokenize_
    from . import ast as ast_

    pgen_tokenize.EXACT_OPMAP = opmap
    tokenize_.EXACT_OPMAP = opmap

    grammar = Grammar()
    # pytree is a standard library since 3.9 and py36_ast.asdl has
    # been removed in 3.9
    if sys.version_info < (3, 9):
        grammar.load(pkgutil.get_data("py36_ast", "asdl.py"))
    else:
        grammar.load(pkgutil.get_data("pytree", "asdl.py"))

    # Verify the load by comparing to the source

# Generated at 2022-06-11 19:38:47.790365
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    test_file = __file__.replace(".py", ".test.pickle")
    grammar.load(test_file)
    assert grammar.start == 257
    assert grammar.symbol2number["start"] == 257
    assert grammar.number2symbol[257] == 'start'
    assert grammar.keywords == {'False': 258, 'None': 259, 'True': 260}

# Generated at 2022-06-11 19:38:59.774058
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:39:05.285445
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pytest
    from pickle import dumps
    with pytest.raises(FileNotFoundError):
        Grammar().load('whatever.pkl')
    mydict = {'symbol': 'val'}
    pkl = dumps(mydict)
    g = Grammar()
    g.loads(pkl)
    assert g.symbol == 'val'

if __name__ == "__main__":
    g = Grammar()
    g.report()

# Generated at 2022-06-11 19:39:14.385713
# Unit test for method load of class Grammar
def test_Grammar_load():
    import py
    import sys
    import pickle
    if sys.version_info[:2] >= (3, 7):
        g = Grammar()
        g.loads(py.path.local(__file__).dirpath().dirpath().dirpath().join('grammar37.pkl').read_binary())
        assert g.keywords['async'] == pickle.loads(py.path.local(__file__).dirpath().dirpath().dirpath().join('keywords37.pkl').read_binary())['async']
        assert g.tokens[token.NAME] == pickle.loads(py.path.local(__file__).dirpath().dirpath().dirpath().join('tokens37.pkl').read_binary())[token.NAME]

# Generated at 2022-06-11 19:39:21.806502
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert len(grammar.states) == 0
    assert len(grammar.dfas) == 0
    assert len(grammar.labels) == 1
    assert len(grammar.keywords) == 0
    assert len(grammar.tokens) == 0
    assert len(grammar.symbol2label) == 0
    assert grammar.start == 256


if __name__ == "__main__":
    from . import driver_py

    driver_py.main("--grammar")

# Generated at 2022-06-11 19:39:25.721108
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test the dump method
    #
    # What happens if we tell dump() to dump to a subdirectory that doesn't exist?

    g = Grammar()
    g.dump("/nonexistentdirectory/test")

# Generated at 2022-06-11 19:39:29.343328
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    assert grammar.symbol2number == {}
    assert grammar.keywords == {}
    assert grammar.tokens == {}
    grammar.load("Grammar/Grammar.pickle")
    assert grammar.symbol2number != {}
    assert grammar.keywords != {}
    assert grammar.tokens != {}

# Generated at 2022-06-11 19:39:33.561359
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "/tmp/python-grammar-test-dump"
    g = Grammar()
    g.load("Grammar.pickle")
    g.dump(filename)
    g.load(filename)
    # delete the file
    os.unlink(filename)

# Generated at 2022-06-11 19:39:44.499430
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test the dump method of Grammar
    # Test the loads method of Grammar

    g = Grammar()
    assert g.symbol2number is None
    g.symbol2number = {"sym1": 1}
    assert g.symbol2number == {"sym1": 1}
    assert g.number2symbol is None
    g.number2symbol = {1: "sym1"}
    assert g.number2symbol == {1: "sym1"}
    assert g.states is None
    g.states = [["This is state 1"]]
    assert g.states == [["This is state 1"]]
    assert g.dfas is None
    g.dfas = {"This is a DFA"}
    assert g.dfas == {"This is a DFA"}
    assert g.labels is None
    g

# Generated at 2022-06-11 19:39:56.494291
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # type: () -> None
    g = Grammar()
    g.symbol2number = {'foo': 1, 'bar': 2}
    g.number2symbol = {1: 'foo', 2: 'bar'}
    g.states = [[[(1, 2)], [(3, 4)], [(5, 2)]], [[(6, 7)], [(8, 9)]]]
    g.dfas = {42: (g.states[0], {0: 1}), 100: (g.states[1], {0: 2})}
    g.labels = [(10, 'foo'), (11, 'bar'), (12, 'baz'), (13, None),
                (14, 'lambda'), (15, None), (16, 'alpha'), (17, 'beta')]

# Generated at 2022-06-11 19:40:11.651896
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a dummy Grammar object
    g = Grammar()
    g.symbol2number = {"foo": 27}
    g.number2symbol = {27: "foo"}
    g.states = [["states"]]
    g.dfas = {"dfas": (1, 2)}
    g.labels = [("labels", 3)]
    g.start = 4
    # Dump it to a pickle file
    g.dump("_tmp")
    # Load from the pickle file
    g2 = Grammar()
    g2.load("_tmp")
    # See if the data matches
    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.dfas

# Generated at 2022-06-11 19:40:20.031917
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Test for normal input
    g = Grammar()
    g.load('Grammar.pickle')
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert len(g.states) == 0
    assert len(g.dfas) == 0
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False
    # Test for non-existed path
    try:
        g.load('NotExistedFileTestGrammarPickle')
    except:
        assert False, 'No exception should be thrown'


# Generated at 2022-06-11 19:40:30.288841
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    g = Grammar()
    g.load("Grammar.txt")
    d = driver.Driver(g, g.start, convert=driver.convert_tree)

# Generated at 2022-06-11 19:40:34.669439
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import py._path.local
    import pickle
    from io import BytesIO

    customGrammar = Grammar()
    customGrammar.symbol2number = {'ABC': 1000, 'def': 2000}
    customGrammar.number2symbol = {1000: 'ABC', 2000: 'def'}
    customGrammar.states = [[(0, 0)]]
    customGrammar.dfas = {1000: ([[(0, 0)]], {})}
    customGrammar.labels = [(0, None), (1000, 'ABC')]
    customGrammar.keywords = {}
    customGrammar.tokens = {10: 1000}
    customGrammar.symbol2label = {'ABC': (1000, 'ABC')}
    customGrammar.start = 1000


# Generated at 2022-06-11 19:40:46.647172
# Unit test for method load of class Grammar
def test_Grammar_load():
    def load_Grammar(initial_grammar: Grammar, pkl: bytes) -> Grammar:
        g = initial_grammar
        g.loads(pkl)
        return g

    import sys
    from test.libregrtest.grammar_samples import sample_grammar_pickle


# Generated at 2022-06-11 19:40:58.129553
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Confirm that Grammar.dump uses an atomic write for the file handle
    grammar = Grammar()
    filename = tempfile.mktemp()

    # Create a temporary file using a NamedTemporaryFile
    # and make sure the file is visible to the Grammar.dump method
    with tempfile.NamedTemporaryFile(delete=False, dir=os.path.dirname(filename)) as f:
        grammar_dump_filename = f.name


# Generated at 2022-06-11 19:41:02.964945
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("{}/Grammar.pkl".format(os.path.dirname(__file__)))
    g.report()



# Generated at 2022-06-11 19:41:10.178568
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    import py_compile as py_compile
    pkl_path = py_compile.__file__.replace("py_compile.cpython-37.pyc",
                                           "Grammar.pkl")
    g.load(pkl_path)
    assert g.symbol2number["atom"] == 270
    assert g.number2symbol[270] == "atom"
    assert g.states[0] == [(257, 1), (268, 1)]
    assert g.dfas[270][0] == [(257, 2)]
    assert g.dfas[270][1] == {token.NAME: 1, token.NUMBER: 1, token.STRING: 1}
    assert g.labels[0] == (0, "EMPTY")
    assert g.labels

# Generated at 2022-06-11 19:41:16.261642
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create an object of class Grammar
    g = Grammar()
    # Create a file with contents of g (g is a dictionary)
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump(g.__dict__, f, pickle.HIGHEST_PROTOCOL)
    # Load the file into object g2 of class Grammar
    g2 = Grammar()
    g2.load(f.name)
    assert g == g2

# Generated at 2022-06-11 19:41:19.005475
# Unit test for method load of class Grammar
def test_Grammar_load():
    class Foo(Grammar):
        def __init__(self):
            pass

    foo = Foo()
    foo.load(
        os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    )  # do not fail

# Generated at 2022-06-11 19:41:29.904583
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "Grammar_dump.txt"
    g = Grammar()
    g.dump(filename)
    with open(filename, "rb") as f:
        d = pickle.load(f)
    assert d == {
        "symbol2number": {},
        "number2symbol": {},
        "states": [],
        "dfas": {},
        "labels": [(0, "EMPTY")],
        "keywords": {},
        "tokens": {},
        "symbol2label": {},
        "start": 256,
        "async_keywords": False,
    }

# Generated at 2022-06-11 19:41:39.622623
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    assert not g.symbol2number
    # mypyc doesn't generate a __dict__, it has a __getstate__
    assert hasattr(g, "__getstate__") or g.symbol2number is g.__dict__["symbol2number"]
    s2n = {"if": 256}
    n2s = {256: "if"}
    d = {"symbol2number": s2n, "number2symbol": n2s}
    g.loads(pickle.dumps(d))
    assert g.symbol2number == s2n
    assert g.number2symbol == n2s
    if hasattr(g, "__getstate__"):
        # mypyc doesn't generate a __dict__, it has a __getstate__
        assert g.sy

# Generated at 2022-06-11 19:41:41.598740
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.loads(pickle.dumps(g))


# Generated at 2022-06-11 19:41:47.273462
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Construct the grammar object
    grammar = Grammar()
    grammar.keywords = {'for': 1, 'if': 2}
    grammar.start = 256
    grammar.tokens = {56: 3, 57: 4}

    # Dump the grammar to tempfile
    with tempfile.NamedTemporaryFile(delete=False) as f:
        grammar.dump(f.name)


# Generated at 2022-06-11 19:41:48.856861
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test.pkl")
    os.unlink("test.pkl")

# Generated at 2022-06-11 19:41:52.921248
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from .parse import Parser

    grammar = pgen2.driver.load_grammar("Grammar/Grammar")
    assert grammar

    p = Parser(grammar)
    assert p

# Generated at 2022-06-11 19:42:01.180749
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Verify that Grammar.load() can read a pickle dump of a Grammar instance
    import pickle
    import io

    f = io.BytesIO()

    g = Grammar()
    g.symbol2number['SYMBOL'] = 42
    pickle.dump(g.__getstate__(), f, pickle.HIGHEST_PROTOCOL)

    f.seek(0)
    h = Grammar()
    h.loads(f.read())

    assert h.symbol2number.get('SYMBOL') == 42

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:42:06.966820
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .parser import PythonParser
    grammar = PythonParser("3.7").grammar
    import sys
    import os
    filename = f'mymagicsquare.{sys.implementation.cache_tag}'
    grammar.dump(filename)
    grammar.load(filename)
    grammar.report()
    os.remove(filename)

# Generated at 2022-06-11 19:42:14.776716
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class MockObject(object):
        def __init__(self, attrs: Dict[str, Any]) -> None:
            self.__dict__.update(attrs)

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            self.ge = Grammar()
            self.attrs = {
                "symbol2number": {},
                "number2symbol": {},
                "states": [],
                "dfas": {},
                "labels": [],
                "keywords": {},
                "tokens": {},
                "start": 256,
                "symbol2label": {},
                "async_keywords": False,
            }
            self.ge._update(self.attrs)

# Generated at 2022-06-11 19:42:17.512497
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__.replace(".py", ".pickle"))
    g.report()

# Generated at 2022-06-11 19:42:24.413896
# Unit test for method load of class Grammar
def test_Grammar_load():
    import sys
    import unittest

    class GrammarLoadTests(unittest.TestCase):
        def setUp(self):
            self.grammar = Grammar()
            self.grammar.load(os.path.join(
                os.path.dirname(sys.executable), "python3.7.grammar"
            ))

        def test_keywords(self):
            self.assertEqual(self.grammar.keywords['yield'], 0)

    unittest.main()


# Generated at 2022-06-11 19:42:26.663818
# Unit test for method load of class Grammar
def test_Grammar_load():
    m = Grammar()
    m.load(__file__[:-3] + "data/Grammar.pickle")
    m.report()


# Generated at 2022-06-11 19:42:38.107417
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Test whether a pickle file is created by Grammar.dump() and can be loaded
    again by Grammar.load().
    """
    # 1. Create a Grammar object and dump it to a file
    grammar = Grammar()

    # 2. Load the file again
    grammar.load(grammar.dump(".test.pickle"))

    # 3. Check whether the Grammar instance has the expected string representation

# Generated at 2022-06-11 19:42:48.331326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class MyGrammar(Grammar):
        def __init__(self):
            Grammar.__init__(self)
            self.symbol2number = {"a": 10, "b": 20}
            self.number2symbol = {10: "a", 20: "b"}
            self.states = [[[(10, 1), (20, 2)], [(0, 99)]]]
            self.dfas = {10: ([], {}), 20: ([], {})}
            self.labels = [(10, None), (20, None)]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = {}
            self.start = 256

    my_grammar = MyGrammar()
    with tempfile.TemporaryDirectory() as my_temp_dir:
        my

# Generated at 2022-06-11 19:42:54.101583
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = "START"
    g.states = "STATES"
    g.tokens = "TOKENS"
    g.labels = "LABELS"
    g.keywords = "KEYWORDS"
    g.symbol2label = "S2L"
    g.dfas = "DFAS"
    g.symbol2number = "S2N"
    g.number2symbol = "N2S"
    f = tempfile.mktemp()
    g.dump(f)
    g2 = Grammar()
    g2.load(f)
    assert g2.start == "START"
    assert g2.states == "STATES"
    assert g2.tokens == "TOKENS"

# Generated at 2022-06-11 19:43:00.297574
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number["value"] = 2
    g.states = [[], [1, 2]]
    pkl = pickle.dumps(
        {"symbol2number": {"value": 5}, "states": [[], [1, 2]]},
        pickle.HIGHEST_PROTOCOL,
    )

    assert not g.symbol2number["value"] == 5
    g.loads(pkl)
    assert g.symbol2number["value"] == 5

# Generated at 2022-06-11 19:43:11.641879
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import unittest

    from .grammar import Grammar

    class G:
        def __init__(self) -> None:
            self.s = 1

    class GrammarTestCase(unittest.TestCase):
        def test_load(self) -> None:
            # all types are not added
            grammar = Grammar()
            grammar.load(io.BytesIO(b"hello world"))
            self.assertEqual(grammar, {})

            grammar = Grammar()
            grammar.load(io.StringIO("hello world"))
            self.assertEqual(grammar, {})

            # need to add a type to enable mypyc support
            grammar = Grammar()
            grammar.load(io.BytesIO(pickle.dumps(G())))

# Generated at 2022-06-11 19:43:14.273464
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load("../Grammar.pickle")
    gr.report()

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:43:25.789560
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256
    g.symbol2number = {"a": 260, "b": 262}
    g.number2symbol = {260: "a", 262: "b"}
    g.labels = [(0, "EMPTY"), (1, "a"), (2, "b")]
    g.tokens = {1: 1, 2: 2}
    g.states = [[(1, 1)], [(2, 2)]]
    g.dfas = {260: ([(1, 1), (2, 3)], {1: 1, 2: 2}), 262: ([(2, 1), (1, 2)], {1: 1, 2: 2})}
    tf = tempfile.NamedTemporaryFile(delete=False)
    os.unlink(tf.name)

# Generated at 2022-06-11 19:43:31.862769
# Unit test for method load of class Grammar
def test_Grammar_load():
    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'foo': 2}
            self.number2symbol = {2: 'foo'}
            self.states = [ ['quux'] ]
            self.dfas = {}
            self.labels = [ (1, 'bar') ]
            self.keywords = {}
            self.tokens = {}
            self.symbol2label = { 'blub': 0 }

    tg = TestGrammar()
    tg.dump("./dumpfile")

    tg2 = TestGrammar()
    tg2.load("./dumpfile")
    assert tg2.symbol2number == {'foo': 2}
    assert tg2.number

# Generated at 2022-06-11 19:43:46.048690
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        g = Grammar()
        g.dump("test_Grammar.dump")
    except Exception as e:
        print(e)
    else:
        assert os.path.exists("test_Grammar.dump")
        os.remove("test_Grammar.dump")
        assert not os.path.exists("test_Grammar.dump")

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:43:49.217206
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.start = 42
    t = tempfile.NamedTemporaryFile()
    g.dump(t.name)
    g.load(t.name)
    assert g.start == 42

# Generated at 2022-06-11 19:43:57.073298
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # XXX Should add a file identifying the version of python used
    # to generate dump file
    # XXX Should put dfa's into a separate file (1 or more)
    # XXX Should put labels into a separate file (1 or more)
    # XXX Should put state items into a separate file (1 or more)
    # XXX Should put keyword items into a separate file
    # XXX Should put token items into a separate file
    import warnings

    warnings.warn("Grammar.dump: write unit test", DeprecationWarning)
    # self.fail("Test if the method dump of class Grammar works.")



# Generated at 2022-06-11 19:43:58.904461
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump("Grammar.dump")


# Generated at 2022-06-11 19:44:00.723846
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    import pickle
    g.load(pickle.__file__) # Does not return anything


# Generated at 2022-06-11 19:44:10.117942
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    class TestGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self._symbol2number = {'a': 1, 'b': 2}
            self._number2symbol = {1: 'a', 2: 'b'}
            self._states = [[]]
            self._dfas = {1: ([], {}), 2: ([], {})}
            self._labels = [(0, 'EMPTY'), (1, 'a'), (2, 'b')]
            self._keywords = {}
            self._tokens = {1: 1, 2: 2}
            self._symbol2label = {'a': 1, 'b': 2}
            self._start = 256
            self._async_keywords = False

        def copy(self):
            new = Test

# Generated at 2022-06-11 19:44:10.563353
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    assert Grammar().dump

# Generated at 2022-06-11 19:44:21.346137
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("@python-debug-grammar")
    assert g.symbol2number["encoding_decl"] == 387
    assert g.start == 256
    assert g.tokens[41] == (1, "import")
    assert (1, "foo") in g.labels
    assert g.dfas[384][1] == {41: 1, 57: 1, 61: 1}  # {ENDMARKER, NAME, NEWLINE}

# Generated at 2022-06-11 19:44:28.903373
# Unit test for method load of class Grammar
def test_Grammar_load():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        pickle.dump({"hello": "world"}, f)
    g = Grammar()
    assert g.hello == None
    g.load(f.name)
    assert g.hello == "world"
    os.remove(f.name)


# Generated at 2022-06-11 19:44:38.027414
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import builtins

    # numexpr is only available in some environments, so
    # create a fake module
    module = builtins.__dict__.get('numexpr')
    if not module:
        numexpr = builtins.__dict__['numexpr'] = type('', (), {})()
        numexpr.__dict__ = {}
        numexpr.__dict__['__name__'] = 'numexpr'
        numexpr.__dict__['__file__'] = 'numexpr'
    # Skip the test if module numexpr does not exist
    # or doesn't have method set_vml_num_threads
    module = builtins.__dict__.get('numexpr')