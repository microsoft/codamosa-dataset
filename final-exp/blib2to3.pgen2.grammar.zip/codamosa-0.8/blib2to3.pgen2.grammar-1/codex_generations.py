

# Generated at 2022-06-11 19:34:41.901403
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # pylint: disable=unused-variable
    # Rule 1: name and parameters
    # Rule 2: docstring
    """
    Unit test for method `Grammar.dump`.
    """
    # pylint: enable=unused-variable
    tables = Grammar()

    # Verify exception raised for empty attribute
    with tempfile.NamedTemporaryFile() as f:
        with pytest.raises(TypeError):
            tables.dump(f.name)

    # Verify pickle file is created
    tables.symbol2number = {}
    with tempfile.NamedTemporaryFile() as f:
        tables.dump(f.name)
        assert os.path.getsize(f.name) > 0



# Generated at 2022-06-11 19:34:46.012325
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = "Grammar_load_temp.pkl"
    g = Grammar()
    g.dump(filename)
    g.load(filename)
    os.remove(filename)

# Generated at 2022-06-11 19:34:54.673806
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import unittest

    class Grammar_dumpTests(unittest.TestCase):
        def test_dump(self) -> None:
            from .pgen2 import driver
            from .pgen2.pgen import Grammar

            data = io.BytesIO()
            g = Grammar()
            driver.load_grammar(g)
            g.dump(data)  # this could raise assertion error
            g.loads(data.getvalue())

    unittest.main()



# Generated at 2022-06-11 19:35:07.209240
# Unit test for method load of class Grammar
def test_Grammar_load():
    import io
    import runpy
    filename = "Grammar.pkl"
    expected = runpy.run_path(filename)
    with io.open(filename, "rb") as f:
        raw = f.read()
    g = Grammar()
    g.loads(raw)
    assert g.symbol2number == expected["symbol2number"]
    assert g.number2symbol == expected["number2symbol"]
    assert g.states == expected["states"]
    assert g.dfas == expected["dfas"]
    assert g.labels == expected["labels"]
    assert g.keywords == expected["keywords"]
    assert g.tokens == expected["tokens"]
    assert g.symbol2label == expected["symbol2label"]
    assert g.start == expected["start"]


# Generated at 2022-06-11 19:35:08.676297
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('Grammar.pickle')

# Generated at 2022-06-11 19:35:16.136501
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test method dump of class Grammar.
    """

    g = Grammar()
    g.symbol2number["something"] = 1
    g.number2symbol[1] = "something"
    g.start = 1

    f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 19:35:18.716967
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Test for the raise clause in method dump of Grammar
    # TODO: add test code
    assert False, "TODO: add test code"



# Generated at 2022-06-11 19:35:26.285839
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    grammar = driver.load_grammar("Grammar.txt")

    fpath: Path = "Grammar.pickle"
    with open(fpath, "wb") as f:
        grammar.dump(f)

    with open(fpath, "rb") as f:
        grammar1 = Grammar()
        grammar1.load(f)



# Generated at 2022-06-11 19:35:33.821039
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import types
    import antlr3

    class TestGrammarLoad(unittest.TestCase):
        def test_load_empty(self):
            import pickle
            g = Grammar()

            # mypyc generates objects that don't have a __dict__, but
            # they do have __getstate__ methods that will return an
            # equivalent dictionary
            if hasattr(g, "__dict__"):
                d = g.__dict__
            else:
                d = g.__getstate__()  # type: ignore

            data = pickle.dumps(d, pickle.HIGHEST_PROTOCOL)
            g1 = Grammar()
            g1.loads(data)
            self.assertEqual(g.symbol2number, g1.symbol2number)

# Generated at 2022-06-11 19:35:41.765728
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from .pgen2 import tokenize

    p = driver.Parser()
    options = p.parse_args(["-o", "python3.7.gram"])
    p.run(options)

    with open("/tmp/python3.7.gram", "rb") as f:
        g = pickle.load(f)

    t = tokenize.generate_tokens("x = 0")
    result = g.parse(tokens=t, start="eval_input")
    assert len(result) == 1

# Generated at 2022-06-11 19:35:54.608244
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2

    grammar = pgen2.driver.load_grammar("Grammar.txt", "Grammar.pickle")
    if hasattr(grammar, '__dict__'):
        dict = grammar.__dict__
    else:
        dict = grammar.__getstate__()
    try:
        grammar.dump('/tmp/Grammar.pickle')
        with open('/tmp/Grammar.pickle', 'rb') as f:
            testdict = pickle.load(f)
    finally:
        os.unlink('/tmp/Grammar.pickle')
    assert dict == testdict


# Generated at 2022-06-11 19:36:04.911715
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token

    filename = "Grammar.dump"

    g = Grammar()

# Generated at 2022-06-11 19:36:14.887405
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Testing the Grammar Class, method dump
    This test ensures the Grammar class can write to a file, and then read the file back
    """
    from .pgen2 import driver

    g, g2 = None, None
    try:
        g = driver.load_grammar("Grammar/Grammar.txt")
        g.dump("Grammar/Grammar.pkl")
        g2 = driver.load_grammar("Grammar/Grammar.pkl")
    finally:
        if g:
            g.close()
        if g2:
            g2.close()

    assert g.symbol2number == g2.symbol2number
    assert g.number2symbol == g2.number2symbol
    assert g.states == g2.states
    assert g.df

# Generated at 2022-06-11 19:36:26.377861
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import sys

    def _test_dump(expect: str, filename: str, pickle_module):
        # This is called twice, once with pickle and once with
        # pickletools
        #
        # pickletools isn't available everywhere, but it is needed for
        # this test

        sys.stdout = sys.__stdout__  # type: ignore
        g = Grammar()
        g.dump(filename)

        # pickletools.dis only works with modules, not objects.
        init_value = "init value"
        with open(filename, "rb") as f:
            pickled = f.read()
            unpickled = pickle_module.loads(pickled)
            assert unpickled == init_value

        with open(filename, "rb") as f:
            data = f.read()


# Generated at 2022-06-11 19:36:36.415253
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    # generated by pgen2.pgen

# Generated at 2022-06-11 19:36:46.322793
# Unit test for method load of class Grammar
def test_Grammar_load():

    import sys
    import pickle
    from pgen2.test.test_parse import find_test_grammar

    if not find_test_grammar():
        # We don't have a test grammar file to use, so skip this test
        print("Skip loading test grammar", file=sys.stderr)
        return

    gr = Grammar()
    gr.load(find_test_grammar())

    # Grammars are pickled with HIGHEST_PROTOCOL, but the version of
    # pickle used to compile the test grammar includes this constant
    # while the version of pickle used to run the test may not.
    # Fall back to hardcoding the value if the constant is unavailable.
    if hasattr(pickle, "HIGHEST_PROTOCOL"):
        protocol = pickle.HIGHEST_PROT

# Generated at 2022-06-11 19:36:55.698578
# Unit test for method load of class Grammar
def test_Grammar_load():
    def load_and_verify(filename: Path, test_filename: Path) -> None:
        info = open(test_filename).read().splitlines()
        expected = dict(x.split(": ", 1) for x in info)
        g = Grammar()
        g.load(filename)
        for name, value in expected.items():
            try:
                object_value = getattr(g, name)
            except AttributeError:
                raise ValueError(f"Error getting attribute {name} from grammar")
            if not isinstance(object_value, dict):
                raise RuntimeError(f"Expected {name} to be a dict and not {type(object_value)}")

# Generated at 2022-06-11 19:37:06.940554
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()

    # Load grammar tables
    grammar.load(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    assert grammar.symbol2number == {'body': 258, 'funcdef': 256, 'decorators': 257,
                                     'decorated': 259, 'trailer': 260}
    assert grammar.number2symbol == {256: 'funcdef', 257: 'decorators',
                                     258: 'body', 259: 'decorated', 260: 'trailer'}
    assert grammar.states == [[[(1, 1)], [], [], [], [], [], [(15, 7)], [], [], [(3, 8)]]]

# Generated at 2022-06-11 19:37:18.747019
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    from test.support import TESTFN
    from . import tokenize
    from . import pgen2

    # Build a Grammar instance with empty tables
    with open(TESTFN, "w") as f:
        f.write("""if 1:
    pass
""")
    with open(TESTFN, "rb") as f:
        tokens = tokenize.generate_tokens(f.readline)
        grammar = pgen2.driver.load_grammar(grammar="Grammar.txt")
    with open(TESTFN, "rb") as f:
        pgen2.driver.write_grammar(f, grammar)
    grammar2 = Grammar()
    grammar2.load(TESTFN)
    # Check that the dumped tables are identical to the original ones

# Generated at 2022-06-11 19:37:25.873732
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Type ignore:
    # https://github.com/python/mypy/issues/5374
    # Until that is addressed, we cannot type-check the creation of Grammar
    # instances

    g = Grammar()  # type: ignore
    assert len(g.states) == 0
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.pkl"))
    assert len(g.states) > 0

# Generated at 2022-06-11 19:37:35.822122
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("tmp.pkl")
    g.load("tmp.pkl")
    os.unlink("tmp.pkl")


test_Grammar_dump()

# Generated at 2022-06-11 19:37:44.618326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    from test.support import temp_dir

    tmp_dir = temp_dir()
    tmp_file = os.path.join(tmp_dir, "grammar.pkl")

    def touch(fn):
        with open(fn, "w") as f:
            f.write("")

    g = Grammar()
    g.dump(tmp_file)
    assert os.path.isfile(tmp_file), "grammar.pkl not created"
    try:
        touch(tmp_file)
    except IOError:
        assert os.path.isfile(tmp_file), "grammar.pkl not created"
    finally:
        shutil.rmtree(tmp_dir)


# Generated at 2022-06-11 19:37:46.751395
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(__file__ + 'c')
    # Must not raise an exception.


# Generated at 2022-06-11 19:37:52.621828
# Unit test for method dump of class Grammar

# Generated at 2022-06-11 19:37:57.664427
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("Grammar.txt")
    g.report()

# Export only the classes and constants needed to run compile(),
# tokenize(), and parser.py.
__all__ = ["Grammar", "Label", "opmap", "token", "test_Grammar_load"]


Grammar.dump(Grammar(), "Grammar.txt")

# Generated at 2022-06-11 19:38:09.360018
# Unit test for method dump of class Grammar
def test_Grammar_dump():

    g = Grammar()

    s = b"cos\nsystem\n(S'ls -l'\ntR."
    g.loads(s)

    # we want to ensure that dump doesn't raise an exception
    g.dump("foo")

    # check to see if the file was created
    try:
        with open("foo", "rb") as f:
            pass
    except IOError:
        return -1

    # clean up
    os.unlink("foo")
    return 0


if __name__ == "__main__":
    import sys

    def report(msg: str) -> None:
        sys.stderr.write("%s\n" % msg)

    def usage(msg: str) -> None:
        if msg:
            report("error: " + msg)

# Generated at 2022-06-11 19:38:10.599026
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.dump("/tmp/_tmp_")
    g.load("/tmp/_tmp_")

# Generated at 2022-06-11 19:38:21.841392
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Class Grammar has a method dump which saves the grammar tables
    to a pickle file.  The file is not guaranteed to be portable across
    Python versions, but it is guaranteed to be readable by the same
    version of the parser that wrote it.

    This test creates a trivial grammar
    and saves it to a temporary file.  It then reads the grammar back
    using load.  If load raises an exception, the test fails.

    """
    g = Grammar()
    g.symbol2number = {"foo" : 257, "bar" : 258}
    g.number2symbol = {257 : "foo", 258 : "bar"}
    g.keywords = {"while" : 259}
    g.tokens = {60 : 260}
    g.start = 258

# Generated at 2022-06-11 19:38:32.031274
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import io
    from . import pygram, pgen2

    g = pygram.python_grammar
    g.start = "file_input"
    g.pgen = pgen2.pgen
    fname = os.path.join(os.path.dirname(__file__), "Grammar.testdump")
    # Pickle using dump method of Grammar
    g.dump(fname)
    with open(fname, "rb") as f:
        pkl = f.read()
    # Pickle using dump method of python2
    with open(fname, "wb") as f:
        pickle.dump(g, f, pickle.HIGHEST_PROTOCOL)
    with open(fname, "rb") as f:
        pkl2 = f.read()

# Generated at 2022-06-11 19:38:44.038524
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load("Grammar.pkl")

# Generated at 2022-06-11 19:38:57.160074
# Unit test for method load of class Grammar
def test_Grammar_load():
    # can't use the Grammar from this module since it has a lot of
    # None attributes which fail in the setattr test.
    from . import conv
    conv.parse_grammar('<string>', start='file_input', all_name='start')


# Generated at 2022-06-11 19:39:06.659319
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest

    class TestGrammar(unittest.TestCase):
        def test_attrs(self):
            self.assertEqual(len(g.symbol2number), 8)
            self.assertEqual(len(g.number2symbol), 8)
            self.assertEqual(len(g.states), 1)
            self.assertEqual(len(g.dfas), 1)
            self.assertEqual(len(g.labels), 5)
            self.assertEqual(len(g.keywords), 1)
            # XXX self.assertEqual(len(g.tokens), 12)
            self.assertEqual(len(g.symbol2label), 5)
            self.assertEqual(g.start, 256)

    g = Grammar()

# Generated at 2022-06-11 19:39:15.187002
# Unit test for method load of class Grammar
def test_Grammar_load():

    class DummyGrammar(Grammar):
        def __init__(self) -> None:
            super(DummyGrammar, self).__init__()
            self.symbol2number = {"a": 1}
            self.number2symbol = {1: "a"}
            self.states = [[]]
            self.dfas = {1: ([], {})}
            self.labels = [(1, None), (2, "b")]
            self.keywords = {"b": 2}
            self.tokens = {1: 1}
            self.symbol2label = {"a": 1}
            self.start = 256

        def test(self):
            assert self.symbol2number == {"a": 1}
            assert self.number2symbol == {1: "a"}

# Generated at 2022-06-11 19:39:20.884790
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number["abc"] = 42
    g.dump("test_dump_grammar.pkl")
    with open("test_dump_grammar.pkl", "rb") as f:
        d = pickle.load(f)
    assert d["symbol2number"]["abc"] == 42

# Generated at 2022-06-11 19:39:30.330463
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    from .parse import Parser
    from .syms import sym_name

    class TestGrammar(Grammar, unittest.TestCase):
        def __init__(self):
            Grammar.__init__(self)
            unittest.TestCase.__init__(self)

    class TestParser(Parser):
        def __init__(self, g: TestGrammar):
            super().__init__(g)
            self.grammar = g

        # Need to override _parse_main to pass it to TestGrammar.
        def _parse_main(self, input: Text) -> None:
            self.grammar._parse_main(input)


    class TestDump(Grammar, unittest.TestCase):
        def __init__(self):
            Gram

# Generated at 2022-06-11 19:39:42.260797
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os, sys
    from parser import grammar

    g = Grammar()
    g.number2symbol = {"number2symbol": True}
    g.symbol2number = {"symbol2number": True}
    g.states = [["states"]]
    g.dfas = {"dfas": True}
    g.labels = ["labels"]
    g.keywords = {"keywords": True}
    g.tokens = {"tokens": True}
    g.symbol2label = {"symbol2label": True}
    g.start = 1

    filename = "test.pkl"
    if os.path.exists(filename):
        os.remove(filename)

    g.dump(filename)

    g2 = Grammar()
    g2.load(filename)

    assert g2

# Generated at 2022-06-11 19:39:52.269386
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import os
    import shutil
    from .pgen2 import driver

    original = os.getcwd()
    try:
        dir = os.path.dirname(__file__)
        os.chdir(dir)
        g = driver.load_grammar("Grammar.txt")
        g.dump("python.pgen")
        g_new = Grammar()
        g_new.load("python.pgen")
        assert g_new == g
        os.unlink("python.pgen")
    finally:
        os.chdir(original)


# Generated at 2022-06-11 19:40:03.528122
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {'X': 57, 'thing': 2, 'start': 1}
    g.number2symbol = {v: k for k, v in g.symbol2number.items()}
    g.states = [[(1, 3), (2, 4)], [(0, 2)], [(1, 5), (0, 6)]]
    g.start = 1
    g.keywords = {'True': 2, 'False': 3, 'None': 4}
    g.tokens = {257: 5}
    g.labels = [
        (0, None),
        (token.NAME, 'True'),
        (token.NAME, 'False'),
        (token.NAME, 'None'),
        (token.STRING, None),
    ]

# Generated at 2022-06-11 19:40:12.736209
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()

# Generated at 2022-06-11 19:40:22.528553
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Verify that the grammar tables can be dumped and loaded.

    """
    import pprint
    import sys

    def main() -> None:
        g = Grammar()

        g.symbol2number["foo"] = 1
        g.number2symbol[2] = "bar"
        g.states = [[[(1, 2), (3, 4)], [(5, 6)], [(7, 8), (9, 10)]]]
        g.dfas = {1: (g.states[0], {1: 1, 2: 1}), 2: (g.states[0], {3: 1})}
        g.labels = [(1, "one"), (2, None), (3, "three")]
        g.keywords = {"four": 4}
        g.tokens = {5: 5}


# Generated at 2022-06-11 19:40:33.619067
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    class TestGrammar(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_Grammar_dump(self):
            return

    unittest.main()


# Generated at 2022-06-11 19:40:35.770833
# Unit test for method load of class Grammar
def test_Grammar_load():
    gram = Grammar()
    gram.load("./grammar.pickle")
    gram.report()


# Generated at 2022-06-11 19:40:46.181902
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    try:
        # Save the current MAXFD value
        maxfd = os.sysconf("SC_OPEN_MAX")

        # Gets the largest available file descriptor
        for fd in reversed(range(maxfd)):
            try:
                os.fstat(fd)
            except OSError:
                continue
            else:
                bigfd = fd
                break
        # -3: one for bigfd and 2 for stdin/stdout.
        fds_used = bigfd - 3
        # This test will fail with a ResourceWarning if the value is too low
        assert fds_used <= 256
    except AttributeError:  # old Python
        pass

# Generated at 2022-06-11 19:40:53.070514
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle
    from importlib import reload
    import py3kwarn
    import pygram
    reload(pygram)
    gr = pygram.Grammar()
    # Dump to pickle
    gr.dump("test.pkl")
    # Load from pickle
    gr1 = pygram.Grammar()
    gr1.load("test.pkl")
    assert gr == gr1
    os.remove("test.pkl")



# Generated at 2022-06-11 19:40:58.053398
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    x = driver.load_grammar("Grammar.txt")
    dump_file = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    x.dump(dump_file.name)
    x.loads(open(dump_file.name, 'rb').read())

# Generated at 2022-06-11 19:41:06.970663
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pickle, sys
    with open(sys.argv[1], "rb") as f:
        d = pickle.load(f)
    g = Grammar()
    g.load(sys.argv[1])
    assert g.symbol2number == d["symbol2number"]
    assert g.number2symbol == d["number2symbol"]
    assert g.states == d["states"]
    assert g.dfas == d["dfas"]
    assert g.labels == d["labels"]
    assert g.start == d["start"]
    print("OK")

# Generated at 2022-06-11 19:41:09.302448
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test that Grammar can be pickled.
    """
    class MyGrammar(Grammar):
        pass

    g = MyGrammar()
    g.dump("/dev/null")

# Generated at 2022-06-11 19:41:18.603471
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import re
    from io import BytesIO
    from pickle import HIGHEST_PROTOCOL

    class MyGrammar(Grammar):
        def __init__(self):
            super().__init__()
            self.symbol2number = {'a': 1}
            self.number2symbol = {1: 'a'}
            self.tokens = {2: 3}
            self.states = [[[(0,0)]]]
            self.dfas = {0: ([[(0,0)]], {1: 2})}
            self.labels = [(0, 'EMPTY')]
            self.keywords = {'a': 1}
            self.symbol2label = {'a': 1}
            self.start = 256

    g = MyGrammar()

# Generated at 2022-06-11 19:41:28.714231
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.symbol2number = {'with': 256}
    g.number2symbol = {256: 'with'}
    g.states = [[[(258, 1), (0, 1)], [(0, 1)]]]
    g.dfas = {256: ([[(258, 1), (0, 1)], [(0, 1)]], {256: 1})}
    g.labels = [(258, 'with'), (0, 'EMPTY')]
    g.keywords = {'with': 258}
    g.tokens = {}
    g.symbol2label = {'with': 258}
    g.start = 256
    g.async_keywords = False
    f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 19:41:38.110849
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar();
    s = "cos\nsystem\n (S'import ...'\ntR."
    g.loads(s.encode())
    assert g.symbol2number == {'system': 258, 'cos': 257}
    assert g.number2symbol == {258: 'system', 257: 'cos'}
    assert g.states == []
    assert g.dfas == {}
    assert g.labels == [(0, 'EMPTY')]
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.start == 256
    assert g.async_keywords == False


# Generated at 2022-06-11 19:41:52.651068
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle

    g = Grammar()
    g.start = 257
    g.states = [[[(0,1)], [(0, 2)], [(0,3)]], [[(0,4)]]]
    g.labels = [(0, None), (257, None), (258, None), (259, None), (260, None)]
    g.dfas = {257: (0, {258: 1, 259: 1, 260: 1})}
    g.symbol2number = {'file_input': 257, 'eval_input': 258}
    g.number2symbol = {257: 'file_input', 258: 'eval_input'}
    with tempfile.TemporaryDirectory() as t:
        g.dump(os.path.join(t, "test_pickle"))

# Generated at 2022-06-11 19:42:02.260067
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar
    from .tokenize import tokenize, untokenize, generate_tokens, generate_tokens_from_chunks
    import types

    my_grammar: Grammar = grammar.Grammar()
    my_grammar.dump("my_grammar.pkl")

    def f(x: int, y=3) -> str: pass
    assert f.__annotations__ == {'x': int, 'y': int, 'return': str}
    assert f.__defaults__ == (3,)
    assert isinstance(f.__code__, types.CodeType)
    assert isinstance(f.__code__.co_code, bytes)
    assert 'foo' in dir()
    assert not hasattr(f, '__closure__')
    x = [1]

# Generated at 2022-06-11 19:42:12.454852
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from tokenize import tokenize, untokenize
    from io import BytesIO

    # Make a grammar
    gram = Grammar()
    gram.symbol2number = {"test1": 1, "test2": 2}
    gram.number2symbol = {1: "test1", 2: "test2"}
    gram.states = [[[(0, 0)], [(0, 1)]]]
    gram.dfas = {1: ([[(0, 0)], [(0, 1)]], {1: 1}), 2: ([[],[(0, 2)]], {2: 1})}
    gram.labels = [(0, "EMPTY"), (1, None), (2, None)]
    gram.keywords = {"key1": 1, "key2": 2}

# Generated at 2022-06-11 19:42:13.558260
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    gram = Grammar()
    gram.dump('test.pkl')

# Generated at 2022-06-11 19:42:18.306152
# Unit test for method load of class Grammar
def test_Grammar_load():
    try:
        os.unlink("_test_Grammar_load.pkl")
    except:
        pass
    g = Grammar()
    g.dump("_test_Grammar_load.pkl")

    g2 = Grammar()
    g2.load("_test_Grammar_load.pkl")

# Generated at 2022-06-11 19:42:25.784787
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    from . import token
    import shutil

    fn = "test.pkl"
    try:
        shutil.copyfile(__file__, fn)
        tokenizer = tokenize.generate_tokens(open(fn).readline)
        p = driver.load_packet(tokenizer)
        g = driver.grammar

        g.dump(fn)
        g.load(fn)
    finally:
        os.remove(fn)



# Generated at 2022-06-11 19:42:37.142090
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pickle
    import os
    import os.path

    test_pkl = os.path.join(os.path.dirname(__file__), "grammar.pkl")
    g = Grammar()
    g.dump(test_pkl)
    with open(test_pkl, "rb") as f:
        assert pickle.load(f) == {
            "async_keywords": False,
            "dfas": {},
            "keywords": {},
            "labels": [(0, "EMPTY")],
            "number2symbol": {},
            "start": 256,
            "states": [],
            "symbol2label": {},
            "symbol2number": {},
            "tokens": {},
        }
    os.remove(test_pkl)

# Generated at 2022-06-11 19:42:47.453338
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def assert_dump_and_load_matches(grammar):
        path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "test.pkl"
        )
        grammar.dump(path)
        new = Grammar()
        new.load(path)
        os.remove(path)
        # mypyc generates objects that don't have a __dict__, but they
        # do have __getstate__ methods that will return an equivalent
        # dictionary
        if hasattr(grammar, "__dict__"):
            assert grammar.__dict__ == new.__dict__
        else:
            assert grammar.__getstate__() == new.__getstate__()

    assert_dump_and_load_matches(Grammar())
    assert_dump_

# Generated at 2022-06-11 19:42:59.558663
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.start = 256

# Generated at 2022-06-11 19:43:10.770675
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import sys
    import tempfile
    import tokenize

    # class GrammarTests(unittest.TestCase):
    #     def test_load(self):
    #         with tempfile.NamedTemporaryFile(delete=False) as f:
    #             pickle.dump(
    #                 {
    #                     "symbol2number": {"test": 0},
    #                     "number2symbol": {0: "test"},
    #                     "states": [[[(256, 0), (257, 1)], [(0, 1)]]],
    #                     "dfas": {0: ([[(256, 0), (257, 1)], [(0, 1)]], [0])},
    #                     "labels": [
    #                         (0, "EMPTY"),
    #                         (256

# Generated at 2022-06-11 19:43:26.357412
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    import io
    import pickle

    with io.BytesIO() as f:
        pickle.dump({}, f)
        f.seek(0)
        g.loads(f.read())
        assert g.symbol2number == {"EMPTY": 256}

        pickle.dump({"symbol2number": {"EMPTY": 256}}, f)
        f.seek(0)
        g.loads(f.read())
        assert g.symbol2number == {"EMPTY": 256}

# Generated at 2022-06-11 19:43:37.387936
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pytest
    import itertools

    test_passed = False

    def do_test_grammar_dump():
        # type: () -> None
        filename = "temp_Grammar_file"
        my_grammar = Grammar()
        # this is our test grammar
        my_grammar.symbol2number = {"a": 1, "b": 2, "c": 3}
        my_grammar.number2symbol = {1: "a", 2: "b", 3: "c"}
        my_grammar.states = [[[(0, 0)], [(1, 2), (3, 0)], [(3, 0)], [(1, 1)]], []]

# Generated at 2022-06-11 19:43:40.100317
# Unit test for method load of class Grammar
def test_Grammar_load():
    def _test(s: str) -> None:
        g = Grammar()
        g.load(s)

    _test("Grammar_load")

# Generated at 2022-06-11 19:43:47.894972
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class X(Grammar):
        def __init__(self):
            super().__init__()
            self.a = 1
            self.b = 2
            self.c = 3
            self.start = 5

    g = X()
    with tempfile.TemporaryDirectory() as td:
        g.dump(os.path.join(td, "t.pkl"))
        h = X()
        h.load(os.path.join(td, "t.pkl"))
        assert h.a == g.a
        assert h.b == g.b
        assert h.c == g.c
        assert h.start == g.start

# Generated at 2022-06-11 19:43:57.983475
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    m = Grammar()
    import sys
    m.symbol2number = {'a':1, 'b':2}
    m.number2symbol = {1:'a', 2:'b'}
    m.states = [1, 2]
    m.dfas = {'a':1, 'b':2}
    m.labels = [1, 2]
    m.start = 34
    with tempfile.NamedTemporaryFile() as f:
        m.dump(f.name)
        with open(f.name, "rb") as f:
            g = pickle.load(f)
            # test that the values match
            assert g['symbol2number'] == {'a':1, 'b':2}
            assert g['number2symbol'] == {1:'a', 2:'b'}

# Generated at 2022-06-11 19:44:02.080648
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.symbol2number = {"foo": 42}
    g.dump("/tmp/g.pkl")
    g2 = Grammar()
    g2.load("/tmp/g.pkl")
    assert g2.symbol2number == g.symbol2number
    os.remove("/tmp/g.pkl")

# Generated at 2022-06-11 19:44:10.895731
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest
    import ast

    class TestGrammar(unittest.TestCase):
        def test_dump(self):
            g = Grammar()
            g.async_keywords = False
            g.keywords = {"async": 0}
            g.symbol2number = {"if": 0}
            g.number2symbol = {0: "if"}
            g.states = [[1]]
            g.dfas = {0: (1, 2)}
            g.labels = [(0, None)]
            g.start = 2

            # Parameter to method dump of Grammar was `filename`
            f = None
            g.dump(f)


# Generated at 2022-06-11 19:44:21.646975
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    driver.main(["-o", "/tmp/Grammar_load.pickle"])
    g = Grammar()
    g.load("/tmp/Grammar_load.pickle")

    # test if load went ok
    assert g.async_keywords == False

# Generated at 2022-06-11 19:44:33.291509
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # This is similar to the dump method, but in test form.  We're
    # checking to make sure data isn't being changed when the grammar
    # is dumped.
    import pickle
    from pprint import pprint

    pickled_grammar = pickle.loads(GRAMMAR_PICKLE)
    for name in pickled_grammar:
        assert getattr(DEFAULT_GRAMMAR, name) == pickled_grammar[name]
    pprint(pickled_grammar["keywords"])


# This is a pickle of the default grammar tables.
# It's accessed by the test_pickle_grammar module.