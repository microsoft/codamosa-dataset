

# Generated at 2022-06-11 19:34:38.281490
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump('grammar1')
    g.load('grammar1')

# Generated at 2022-06-11 19:34:42.949724
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load("../Grammar/Grammar")
    # test if loads doesn't load anything
    g.loads(b"")
    g.start == 1
    # test if the method copy creates a new object
    assert g != g.copy()

# Generated at 2022-06-11 19:34:56.470499
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import Convert
    from pprint import pprint

    g = Grammar()
    conv = Convert(g)
    conv.convert("Grammar/Grammar.txt")

    # Only test mypyc for now
    for mypyc in (True, False):
        with tempfile.TemporaryDirectory() as dirname:
            fname = os.path.join(dirname, "blah")
            g.dump(fname)
            g2 = Grammar()
            g2.load(fname)
            assert g2.symbol2number == g.symbol2number
            assert g2.number2symbol == g.number2symbol
            assert g2.states == g.states
            assert g2.dfas == g.dfas
            assert g2.labels == g.labels


# Generated at 2022-06-11 19:35:03.130099
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver
    grammar = driver.load_grammar(
        str(driver.GRAMMAR_FILE), picklefile=str(driver.PICKLE_FILE)
    )
    grammar.dump("Grammar.dump")
    with open("Grammar.dump", "rb") as f:
        v = pickle.load(f)
    assert v == grammar.__dict__

# Generated at 2022-06-11 19:35:13.374995
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .parser3 import PythonParser
    from .pgen3 import Driver
    from . import tokenize

    def dump_parse(grammar, s):
        """Dump a readable representation of the parse tree for
        string s, assuming the grammar provides parse() and
        p_error().

        """
        tokens = tokenize.generate_tokens(s.encode())
        p = PythonParser(grammar)
        p.setup()
        p.addtoken(token.ENDMARKER)
        tree = p.parse(tokens)
        print(tree)

    def parse_Grammar(s):
        """Parse the string s, which is a Python representation of
        a dict containing the grammar tables, and return the dict.

        """
        tokens = tokenize.generate_tokens(s.encode())

# Generated at 2022-06-11 19:35:21.360536
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import unittest

    import pytest

    class GrammarDumpTests(unittest.TestCase):
        def test_dummy(self):
            self.assertEqual('foo'.upper(), 'FOO')

    with pytest.raises(AttributeError):
        GrammarDumpTests('test_dummy').test_dummy()

    with pytest.raises(TypeError):
        GrammarDumpTests('test_dummy')

    with pytest.raises(TypeError):
        GrammarDumpTests()

# Generated at 2022-06-11 19:35:31.187836
# Unit test for method load of class Grammar
def test_Grammar_load():

    class TestGrammar(Grammar):
        def __init__(self, filename: Path) -> None:
            self.symbol2number = {
                "foo": 1,
                "bar": 2,
            }
            self.number2symbol = {
                1: "foo",
                2: "bar",
            }
            self.states = [
                [(257, 1), (258, 2)],
                [],
                [],
            ]
            self.dfas = {
                1: (self.states[0], {257: 1, 258: 1}),
            }
            self.labels = [
                (0, "EMPTY"),
                (257, "foo"),
                (258, "bar"),
            ]
            self.keywords = {}
            self.tokens = {}
           

# Generated at 2022-06-11 19:35:39.888615
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from .conv import convert
    from . import python_grammar_no_print_statement

    filename = tempfile.mktemp()

    try:
        grammar = convert(driver.parse_grammar(python_grammar_no_print_statement))
        grammar.dump(filename)

        grammar1 = Grammar()
        grammar1.load(filename)
        assert grammar.tokens == grammar1.tokens
        assert grammar.keywords == grammar1.keywords
        assert grammar.start == grammar1.start
        assert grammar.labels == grammar1.labels
        assert grammar.symbol2label == grammar1.symbol2label
    finally:
        try:
            os.remove(filename)
        except FileNotFoundError:
            pass

# Generated at 2022-06-11 19:35:43.704877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import pygram.parse
    import tempfile

    try:
        f = tempfile.NamedTemporaryFile(delete=False)
        pygram.parse.cpython_grammar.dump(f.name)
    finally:
        pass


# Generated at 2022-06-11 19:35:55.489113
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def check_dump(dump_file_name: Path) -> None:
        assert os.path.exists(dump_file_name)

        from . import pickletools

        # TODO: use a memoryview instead of a bytes
        with open(dump_file_name, "rb") as input_file:
            data = input_file.read()
            pickletools.dis(data)

    test_dir = "mypy/test_data/test_dump"
    assert os.path.exists(test_dir)

    grammar = Grammar()
    grammar.symbol2number['a'] = 1
    grammar.number2symbol[2] = 'b'
    dump_file_name = os.path.join(test_dir, "test_dump.dat")
    grammar.dump(dump_file_name)


# Generated at 2022-06-11 19:36:09.315015
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver

    grammar = driver.load_grammar()
    filename = "grammar.pickle"
    grammar.dump(filename)
    grammar2 = Grammar()
    grammar2.load(filename)

    for dict_attr in (
        "symbol2number",
        "number2symbol",
        "dfas",
        "keywords",
        "tokens",
        "symbol2label",
    ):
        assert getattr(grammar, dict_attr) == getattr(grammar2, dict_attr)
    assert grammar.labels == grammar2.labels
    assert grammar.states == grammar2.states
    assert grammar.start == grammar2.start
    assert grammar.async_keywords == grammar2.async_keywords


# Generated at 2022-06-11 19:36:18.236944
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Issue #11812
    gr = Grammar()
    gr.start = 1
    gr.states = [[[(1, 2)], [(1, 3)]]]
    gr.labels = [(256, 'foo'), (257, 'bar')]
    with tempfile.TemporaryDirectory() as tmpdirname:
            filename = os.path.join(tmpdirname, 'grammar.pkl')
            gr.dump(filename)
            gr_loaded = Grammar()
            gr_loaded.load(filename)
            assert gr_loaded.start == 1
            assert gr_loaded.states == [[[(1, 2)], [(1, 3)]]]
            assert gr_loaded.labels == [(256, 'foo'), (257, 'bar')]

# Generated at 2022-06-11 19:36:22.704028
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pgen2
    from . import conv

    s = "x = 1"
    for g in (pgen2.load_grammar(), conv.Converter().convert_grammar()):
        g.dump(b"test.tmp")
        g1 = g.__class__()
        g1.load(b"test.tmp")
        filename = pgen2.tokenize_pgen(s, g1)
        assert filename == pgen2.tokenize_pgen(s, g)
        os.unlink(b"test.tmp")

# Generated at 2022-06-11 19:36:25.017139
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io

    g = Grammar()
    f = io.BytesIO()
    g.dump(f)


# Generated at 2022-06-11 19:36:36.039342
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = { 0x100: "var", 0x101: "var" }
    g.symbol2number = { "var": 0x100 }
    g.labels = [(0, None), (3, "if"), (4, None)]
    g.keywords = { "if": 3 }
    g.tokens = { 3:4 }
    g.async_keywords = False

    state0 = []
    state1 = [(0, 1), (4, 1)]
    state2 = [(0, 2)]
    g.states = [state0, state1, state2]

    first = { 3:1 }     # type: Dict[int, int]

# Generated at 2022-06-11 19:36:42.322886
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Verify that valid pickle file is accepted and that invalid pickle
    # file raises exception.
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.pkl")  # type: ignore

    # This should load Grammar.pkl, which should be a valid pickle file.
    g.load("Grammar.pkl")

    # We should get an exception here since there is no file named
    # 'x' in the directory.
    try:
        g.load("x")
    except OSError:
        pass


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:36:48.513122
# Unit test for method load of class Grammar
def test_Grammar_load():
    # simple test
    g = Grammar()
    g.start = 257
    g.dump("test.pk")
    g.load("test.pk")
    os.unlink("test.pk")
    assert g.start == 257


if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:36:56.523092
# Unit test for method load of class Grammar
def test_Grammar_load():
    source = """
    symbol2number = {}
    number2symbol = {}
    states = []
    dfas = {}
    labels = [(0, 'EMPTY')]
    keywords = {}
    tokens = {}
    symbol2label = {}
    start = 256
    """
    gram: Grammar = Grammar()
    gram.loads(source.encode("utf8"))

    gram.symbol2number = {'s': 2}
    gram.number2symbol = {2: 's'}
    gram.states = [[]]
    gram.dfas = {2: gram.states[0], 'd': gram.states[0]}
    gram.labels = [(0, 'l')]
    gram.keywords = {'k': 0}
    gram.tokens = {1: 2}

# Generated at 2022-06-11 19:37:07.612877
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    def test_load(g: Grammar, filename: Path) -> None:
        g.dump(filename)
        g2 = Grammar()
        g2.load(filename)
        assert g2.symbol2number == g.symbol2number
        assert g2.number2symbol == g.number2symbol
        assert g2.states == g.states
        assert g2.dfas == g.dfas
        assert g2.labels == g.labels
        assert g2.keywords == g.keywords
        assert g2.tokens == g.tokens
        assert g2.symbol2label == g.symbol2label
        assert g2.start == g.start
        assert g2.async_keywords == g.async_keywords


# Generated at 2022-06-11 19:37:17.027635
# Unit test for method load of class Grammar
def test_Grammar_load():
    import py
    import pickle
    gram = Grammar()
    gram.load(py.path.local(__file__).dirpath().join("Grammar.pkl").strpath)
    assert pickle.loads(pickle.dumps(gram)) == gram
    assert "async" in gram.keywords
    assert "async" not in gram.symbol2number
    assert "await" not in gram.keywords
    assert "await" in gram.symbol2number
    assert gram.start == 286

if __name__ == "__main__":
    test_Grammar_load()

# Generated at 2022-06-11 19:37:21.057550
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for method load of class Grammar."""
    grammar = Grammar()
    grammar.load('test_file')

# Generated at 2022-06-11 19:37:30.966388
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import parse
    from . import python_grammar
    from . import grammar
    from . import conv

    filename = str(python_grammar.__file__).replace(".py",".pgen")

    g = parse.Parser(python_grammar, None, conv)
    s = grammar.Grammar()
    s.load(filename)
    assert s.symbol2number == g.symbol2number
    assert s.number2symbol == g.number2symbol
    assert s.states == g.states
    assert s.dfas == g.dfas
    assert s.labels == g.labels
    assert s.keywords == g.keywords
    assert s.tokens == g.tokens
    assert s.symbol2label == g.symbol2label
    assert s.start

# Generated at 2022-06-11 19:37:35.389421
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.dump('/tmp/test_Grammar_dump.pkl')

if __name__ == "__main__":
    test_Grammar_dump()

# Generated at 2022-06-11 19:37:44.747620
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """
    Test dump and load grammar tables pickle.
    """
    from . import conv
    from . import pgen2
    from . import tokenize

    g = Grammar()
    g.symbol2number = {'A': 256, 'B': 257, 'C': 258}
    g.number2symbol = {256: 'A', 257: 'B', 258: 'C'}
    g.keywords = {}
    g.tokens = {1: 2, 3: 4, 5: 6}
    g.labels = [(0, 'EMPTY'), (1, None), (3, None), (5, None), (2, 'token1'), (4, 'token3'), (6, 'token5')]
    g.start = 258

# Generated at 2022-06-11 19:37:55.045215
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    with tempfile.TemporaryDirectory() as dirname:
        filename = os.path.join(dirname, "test.pickle")
        grammar.dump(filename)
        grammar2 = Grammar()
        grammar2.load(filename)
    assert grammar.symbol2number == grammar2.symbol2number
    assert grammar.number2symbol == grammar2.number2symbol
    assert grammar.states == grammar2.states
    assert grammar.dfas == grammar2.dfas
    assert grammar.labels == grammar2.labels
    assert grammar.keywords == grammar2.keywords
    assert grammar.tokens == grammar2.tokens
    assert grammar.symbol2label == grammar2.symbol2label
    assert grammar.start == grammar2.start
    assert grammar.async_

# Generated at 2022-06-11 19:38:02.082110
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import grammar
    from .pgen2.parse import Driver
    from . import pygram
    from io import BytesIO
    import shutil, os, sys

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 19:38:05.405558
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    pkl = grammar.dumps()
    grammar.loads(pkl)
    grammar2 = Grammar()
    assert grammar == grammar2

# Generated at 2022-06-11 19:38:11.857692
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .token import ENCODING
    from .pgen2 import tokenize

    g = Grammar()
    tokens = list(tokenize.generate_tokens("def x(): pass"))
    g.load(tokenize.grammar, tokens)

    assert len(g.states) == 2
    assert len(g.states[0]) == 22
    assert len(g.states[1]) == 16

    # doublecheck, this will fail if the grammar changed
    assert len(tokens) == 3
    assert tokens[0][0] == tokenize.ENCODING
    assert tokens[1][0] == token.NAME
    assert tokens[2][0] == tokenize.NEWLINE



# Generated at 2022-06-11 19:38:22.215230
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    # Unit test for method load of class Grammar
    """
    # save current flags
    old_debug = Grammar.DEBUG
    old_outputdir = Grammar.OUTPUTDIR
    old_tabcheck = Grammar.TABCHECK


# Generated at 2022-06-11 19:38:25.316852
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    with tempfile.NamedTemporaryFile() as f:
        filename = f.name
        g = Grammar()
        g.dump(filename)

# Generated at 2022-06-11 19:38:29.724738
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()

    path_dump = os.path.join(tempfile.gettempdir(), "dumps.pickle")

    grammar.dump(path_dump)

# Generated at 2022-06-11 19:38:32.207896
# Unit test for method load of class Grammar
def test_Grammar_load():
    gr = Grammar()
    gr.load('Grammar.pkl')



# Generated at 2022-06-11 19:38:42.473212
# Unit test for method load of class Grammar
def test_Grammar_load():
    """Unit test for Grammar.load()"""
    test_grammar_tables_file = os.path.join(
        os.path.dirname(__file__), os.pardir, "Grammar.tbl"
    )
    if os.path.isfile(test_grammar_tables_file):
        g = Grammar()
        g.load(test_grammar_tables_file)
        assert g.number2symbol[256] == "file_input"
    else:
        print("warning, test_Grammar.test_Grammar_load: Grammar.tbl not found")



# Generated at 2022-06-11 19:38:52.453930
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io  # type: ignore
    from . import pgen2

    grammar = pgen2.pgen("Grammar/Grammar").grammar
    with io.BytesIO() as f:
        grammar.dump(f)
        grammar2 = Grammar()
        grammar2.loads(f.getvalue())

    assert grammar2.symbol2number == grammar.symbol2number
    assert grammar2.number2symbol == grammar.number2symbol
    assert grammar2.states == grammar.states
    assert grammar2.dfas == grammar.dfas
    assert grammar2.labels == grammar.labels
    assert grammar2.keywords == grammar.keywords
    assert grammar2.tokens == grammar.tokens
    assert grammar2.symbol2label == grammar.symbol2label
    assert grammar2.start

# Generated at 2022-06-11 19:39:00.767988
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.number2symbol = {1: 'a'}

    tf = tempfile.NamedTemporaryFile()
    filename = tf.name
    tf.close()

    grammar.dump(filename)

    # Load the pickled objects
    with open(filename, "rb") as f:
        obj = pickle.load(f)

    # Check that the un-pickled values are the same
    assert obj == grammar.__dict__



# Generated at 2022-06-11 19:39:09.810136
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    with tempfile.TemporaryDirectory() as tmp:
        filename_1 = os.path.join(tmp, "grammar1")
        filename_2 = os.path.join(tmp, "grammar2")
        g.dump(filename_1)
        h = Grammar()
        h.load(filename_1)
        h.dump(filename_2)
        assert open(filename_1, "rb").read() == open(filename_2, "rb").read()

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 19:39:20.071906
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .conv import Conv
    from .pgen import driver
    from .python import Token
    from .tokenize import generate_tokens
    import sys

    grammar = driver.load_grammar()
    f = sys.argv[1]
    g = Conv(grammar)
    g.convert(f, f + ".pkl")
    g2 = Grammar()
    g2.loads(g.pkl)
    with open(f, "rb") as fp:
        tokens = generate_tokens(fp.readline)
        for t in tokens:
            tok = Token(*t)
            print(tok)
            print(g.labels[g.tokens[tok.type]][1])

# Generated at 2022-06-11 19:39:25.980368
# Unit test for method load of class Grammar
def test_Grammar_load():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.pickle")
    dg = load_grammar(filename)
    assert len(dg.symbol2number) == 0
    assert len(dg.number2symbol) == 0
    assert len(dg.states) == 0
    assert len(dg.dfas) == 0
    assert len(dg.labels) == 1
    assert len(dg.keywords) == 0
    assert len(dg.tokens) == 0
    assert len(dg.symbol2label) == 0
    assert dg.start == 256
    assert dg.async_keywords == False



# Generated at 2022-06-11 19:39:36.313452
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import pgen2 as pgen2
    from . import tokenize as tokenize

    g = pgen2.load_grammar()
    f = tokenize.StringIO()
    g.dump(f)
    f.seek(0)
    h = Grammar()
    h.loads(f.read())

    assert g.async_keywords == h.async_keywords
    assert g.labels == h.labels
    assert g.number2symbol == h.number2symbol
    assert g.start == h.start
    assert g.symbol2label == h.symbol2label
    assert g.symbol2number == h.symbol2number
    assert g.keywords == h.keywords
    assert g.tokens == h.tokens

# Generated at 2022-06-11 19:39:46.085192
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    import io
    import os
    import pickle
    import tempfile
    from typing import Any, Callable
    import unittest

    class MockFile(io.BytesIO):
        def __init__(self, *args):
            super(MockFile, self).__init__(*args)
            self.delete = False
            self.name = "/file"

    def mock_os_replace(src, dst):
        raise unittest.SkipTest("unable to replace files on this platform")

    def mock_tempfile_NamedTemporaryFile(
        dir = None,
        prefix = None,
        suffix = None,
        delete = True,
        **kwargs
    ):
        raise unittest.SkipTest("unable to replace files on this platform")


# Generated at 2022-06-11 19:39:53.350384
# Unit test for method load of class Grammar
def test_Grammar_load():
    from . import pickle_grammar, tokenize_pgen

    grammar = Grammar()
    grammar.loads(pickle_grammar)
    assert dir(grammar) == dir(tokenize_pgen)

# Generated at 2022-06-11 19:39:54.394724
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.dump("test")

# Generated at 2022-06-11 19:39:57.977267
# Unit test for method load of class Grammar
def test_Grammar_load():
    class Foo(Grammar):
        pass

    gram = Foo()

    # Something to pickle
    gram.dump("test_Grammar_load.gram")

    # Now load the dumped thing
    gram.load("test_Grammar_load.gram")

# Generated at 2022-06-11 19:40:03.231771
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .pgen2 import driver, write_grammar

    parser = driver.Parser()
    write_grammar.write_grammar(parser, "/tmp/Grammar")
    g = Grammar()
    g.load("/tmp/Grammar")
    g.dump("/tmp/Grammar")

# Generated at 2022-06-11 19:40:12.560144
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .tokenizer import tokenize
    from .parser import Parser, SuiteParser
    from . import stmts
    from . import token

    parse = Parser()

    class MockType(type):
        def __instancecheck__(self, instance: object) -> bool:
            return True

    class MockNode(object):
        __class__ = MockType()

    class MockParser(SuiteParser):
        make_node = lambda *args: MockNode()
        start_symbol = "single_input"

    parse.set_grammar(load_grammar(MockParser))
    parse.setup()

    source = "if True: pass"
    source_encoding = "utf-8"

    # These are the tokens we expect to get out of tokenize

# Generated at 2022-06-11 19:40:19.336625
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load(os.path.join(os.path.dirname(__file__), "Grammar.dat"))
    assert g.start == 256
    assert g.start not in g.tokens


if False:  # for mypy
    def test_Grammar_loads():
        g = Grammar()
        with open(os.path.join(os.path.dirname(__file__), "Grammar.dat"), "rb") as f:
            g.loads(f.read())
        assert g.start == 256
        assert g.start not in g.tokens

# Generated at 2022-06-11 19:40:21.816533
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    class DummyGrammar(Grammar):
        pass

    g = DummyGrammar()
    fd, fname = tempfile.mkstemp()
    g.dump(fname)
    g.load(fname)
    os.remove(fname)

# Generated at 2022-06-11 19:40:30.613416
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    g = Grammar()
    g.number2symbol = {0: 'a'}
    g.states = [[[(1, 2), (3, 4)], [(5, 6), (7, 8)]]]
    g.dfas = {0: ([[(1, 2), (3, 4)], [(5, 6), (7, 8)]], {1: 1})}
    g.labels = [(1, None)]
    g.keywords = {'a': 1}
    g.tokens = {1: 2}
    g.start = 0
    f = tempfile.TemporaryFile()
    g.dump(f)
    f.seek(0)
    g2 = Grammar()
    g2.loads(f.read())
    f.close()
    assert g.number2symbol

# Generated at 2022-06-11 19:40:37.700929
# Unit test for method load of class Grammar
def test_Grammar_load():
    #
    # Python 2
    #
    tmpdir = tempfile.mkdtemp()
    try:
        from test.support import import_module

        pickle = import_module("cPickle")
        cStringIO = import_module("cStringIO")
    except ImportError:
        # Python 3
        tmpdir = tempfile.TemporaryDirectory()
        pickle = import_module("pickle")
        cStringIO = import_module("io")


# Generated at 2022-06-11 19:40:48.868455
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from os import remove
    from io import BytesIO

    g = Grammar()
    g.loads(b"ccopy_reg\n_reconstructor\np1\n(cpycparse.pgen2.Grammar\np2\n")
    b = BytesIO()
    g.dump(b)
    g2 = Grammar()
    g2.loads(b.getvalue())
    assert g == g2

    remove("Grammar_dump.pyc")
    g.dump("Grammar_dump.pyc")
    g2 = Grammar()
    g2.load("Grammar_dump.pyc")
    assert g == g2

    remove("Grammar_dump.pyc")
    g.dump("Grammar_dump.pyc")


# Generated at 2022-06-11 19:41:01.282204
# Unit test for method load of class Grammar

# Generated at 2022-06-11 19:41:05.401541
# Unit test for method load of class Grammar
def test_Grammar_load():
    import pgen2.grammar

    # This needs to be created before running the test
    pgen2.grammar.conv.create_grammar()

    # Test the function called
    g = pgen2.grammar.Grammar()
    g.load(pgen2.grammar.GRAMMAR_PICKLE)

# Generated at 2022-06-11 19:41:15.923784
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    grammar.start = 257
    grammar.symbol2number = {'S': 257}
    grammar.number2symbol = {257: 'S'}
    grammar.states = [[[(257, 0), (0, 257)], [(257, 1), (0, 257)]]]
    grammar.keywords = {'async': 257}
    grammar.tokens = {257: 257}
    grammar.symbol2label = {'S': 257}
    grammar.dfas = {257: [
        [[(257, 0), (0, 256)], [(257, 1), (0, 256)]],
        {257: 1},
        ]}
    grammar.labels = [(0, 'EMPTY'), (257, None)]


# Generated at 2022-06-11 19:41:27.971734
# Unit test for method load of class Grammar
def test_Grammar_load():
    import random
    import tempfile
    from . import pgen2

    # Generate a random token.
    def random_token() -> Tuple[Any, Any]:
        token_id = random.choice(list(token.python_tokens))
        # Generate a random string, if the token is a string.
        if token_id in (token.STRING, token.STRING3, token.NAME):
            chars = [chr(i) for i in range(32, 127)]
            chars.remove("'")
            chars.remove('"')
            token_str = random.choice(chars)
        else:
            token_str = token.tok_name[token_id]
        return token_id, token_str


# Generated at 2022-06-11 19:41:38.483355
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from io import BytesIO

    g = Grammar()
    g.symbol2number = {"foo": 1, "bar": 2, "baz": 3}
    g.dump(os.path.join(tempfile.gettempdir(), "yl_grammar.pkl"))
    g.symbol2number = {"foo": 10, "bar": 20, "baz": 30}
    g.load(os.path.join(tempfile.gettempdir(), "yl_grammar.pkl"))
    assert g.symbol2number == {"foo": 1, "bar": 2, "baz": 3}

    g2 = Grammar()
    g2.symbol2number = {"foo": 1, "bar": 2, "baz": 3}
    stream = BytesIO()
    g2.dump(stream)
   

# Generated at 2022-06-11 19:41:48.782376
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from .token import tokenize

    g = Grammar()
    from .pgen2 import driver

    driver.load_grammar(g)
    # Can't use named temporary file here, as the test suite sets TMPDIR
    # to point to /var/tmp, which causes various problems on macOS
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        g.dump(f.name)
        g2 = Grammar()
        g2.load(f.name)

    # compare all the attributes
    for name in dir(g):
        if name.startswith("_"):
            continue

        if name == "symbol2label":
            label_map = g.symbol2label

# Generated at 2022-06-11 19:41:52.809465
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    from . import conv
    example = conv.parse("Grammar.example", "file_input")
    example.dump("Grammar.example.pkl")
    example.dump("Grammar.example2.pkl")

# Generated at 2022-06-11 19:41:59.695390
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Instantiate the grammar
    from .conv import pgen2grammar

    g = pgen2grammar.pgen2grammar()

    # Create a temporary file for testing
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as f:
        # Dump the grammar to the temporary file
        g.dump(f.name)

        # Make sure the file was written
        assert os.path.getsize(f.name) != 0



# Generated at 2022-06-11 19:42:10.804696
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    """Unit test for method dump of class Grammar."""
    from . import token, pgen2
    from .pygram import python_grammar
    from . import pytree

    g = python_grammar
    fname = "Grammar.testdump.pkl"
    g.dump(fname)
    h = Grammar()
    h.load(fname)
    # Make sure the round-trip was idempotent
    assert g.symbol2number == h.symbol2number
    assert g.number2symbol == h.number2symbol
    assert g.states == h.states
    assert g.dfas == h.dfas
    assert g.labels == h.labels
    assert g.start == h.start
    # Load some real code
    p = pgen2.driver.load_

# Generated at 2022-06-11 19:42:16.911986
# Unit test for method load of class Grammar
def test_Grammar_load():
    def check(g):
        assert g.symbol2number == {"foo": 257, "bar": 258, "baz": 259}
        assert g.number2symbol == {257: "foo", 258: "bar", 259: "baz"}
        assert g.states == [
            [
                [(266, 1), (267, 2)],
                [(268, 3)],
                [(269, 4)],
                [(0, 3)],
                [(0, 4)],
                [(270, 6)],
                [(0, 6)],
                [],
            ]
        ]

# Generated at 2022-06-11 19:42:21.776766
# Unit test for method load of class Grammar
def test_Grammar_load():
    _Grammar_load(globals())


# Generated at 2022-06-11 19:42:30.485326
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = "grammar.pkl"
    grammar = Grammar()
    s2n = {"a": 1, "b": 2}
    n2s = {1: "a", 2: "b"}
    states = [[(1, 1)], [(1, 2)]]
    dfas = {1: ([(1, 1)], {}), 2: ([(1, 2)], {})}
    labels = [(1, "a"), (1, "b")]
    keywords = {"a": 1, "b": 1}
    tokens = {1: 1, 2: 1}
    start = 1
    grammar.symbol2number = s2n
    grammar.number2symbol = n2s
    grammar.states = states
    grammar.dfas = dfas
    grammar.labels = labels

# Generated at 2022-06-11 19:42:41.691392
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.number2symbol = dict(number=1)
    g.symbol2number = {k: v for k, v in g.number2symbol.items()}
    g.states = []
    g.dfas = dict()
    g.labels = []
    g.keywords = dict()
    g.tokens = dict()
    g.symbol2label = dict()
    g.start = 256
    g.async_keywords = False
    assert g.symbol2number == dict(number=1)
    filename = tempfile.mktemp()
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g2.symbol2number == dict(number=1)
    os.remove(filename)

# Generated at 2022-06-11 19:42:43.073816
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    a = Grammar()
    a.dump("a")
    a.load("a")

# Generated at 2022-06-11 19:42:48.626085
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver
    from . import python_grammar
    from .tokenize import generate_tokens

    g = Grammar()
    g.load(python_grammar.__file__)

    p = driver.Parser(g)
    s = "x = 1"
    t = generate_tokens(s)
    p.parse(t)

test_Grammar_load()

# Generated at 2022-06-11 19:43:00.570902
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    test_grammar = Grammar()
    test_grammar.number2symbol = {1: 'a'} 
    test_grammar.symbol2number = {'b': 2}
    test_grammar.states = [[(1, 1)], [(2, 2)]]
    test_grammar.dfas = {1: ([(2, 3)], {1: 1}), 2: ([(3, 4)], {2: 2})}
    test_grammar.labels = [(1, 'a'), (2, 'b')]
    test_grammar.keywords = {'a': 1}
    test_grammar.tokens = {10: 1}
    test_grammar.symbol2label = {'a': 2}
    test_grammar.start = 3
    test_grammar

# Generated at 2022-06-11 19:43:02.869964
# Unit test for method load of class Grammar
def test_Grammar_load():
    grammar = Grammar()
    grammar.load('/python/Python-3.6.1/Grammar/Grammar')

# Generated at 2022-06-11 19:43:13.900802
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Test that Grammar.load can load pickles generated using the Grammar.dump method.

    This doesn't test whether the data loaded corresponds to anything,
    just that it can be loaded without errors.

    """
    import tempfile

    tempdir = tempfile.TemporaryDirectory()

    fname = os.path.join(tempdir.name, "testfile")
    dumpfile(fname)

    from . import parsetok

    parsetok.Grammar().load(fname)

    # Grammar.load won't actually be called for the python3 grammar:
    if not hasattr(parsetok, "python3_grammar"):
        # this raises an error if python2_grammar isn't already defined.
        parsetok.python2_grammar.load(fname)

    tempdir.cleanup

# Generated at 2022-06-11 19:43:15.729466
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    Grammar.load() should be able to load itself
    """
    gr = Grammar()
    gr.load(__file__)



# Generated at 2022-06-11 19:43:21.130780
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    filename = tempfile.NamedTemporaryFile(delete=False).name
    g = Grammar()
    g.dump(filename)
    g2 = Grammar()
    g2.load(filename)
    assert g2.__dict__ == g.__dict__

# Generated at 2022-06-11 19:43:35.225164
# Unit test for method load of class Grammar
def test_Grammar_load():
    from .pgen2 import driver

    g = driver.load_grammar("Grammar.txt")
    g.dump("Grammar.pickle")
    t = Grammar()
    t.load("Grammar.pickle")
    if g.symbol2number != t.symbol2number:
        raise AssertionError("load failed")
    return

# Generated at 2022-06-11 19:43:41.435576
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    # Create a temporary directory
    import tempfile
    dirpath = tempfile.mkdtemp()

    # Write a pickle file
    pickle_file = os.path.join(dirpath, 'example.pkl')
    gr = Grammar()
    gr.dump(pickle_file)

    # Read the pickle file
    gr2 = Grammar()
    gr2.load(pickle_file)
    assert gr2.symbol2number == {}
    assert gr2.number2symbol == {}
    assert gr2.states == []
    assert gr2.dfas == {}
    assert gr2.labels == [(0, "EMPTY")]
    assert gr2.keywords == {}
    assert gr2.tokens == {}
    assert gr2.symbol2label == {}
    assert gr2.start

# Generated at 2022-06-11 19:43:46.173661
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    a_temp_file_name = 'a_temp_file'
    a_temp_grammar = Grammar()
    a_temp_grammar.dump(a_temp_file_name)

    assert os.path.exists(a_temp_file_name)
    os.remove(a_temp_file_name)

# Generated at 2022-06-11 19:43:56.806023
# Unit test for method load of class Grammar
def test_Grammar_load():
    import unittest
    import textwrap
    import sys
    from . import pygram
    from .test import support
    import pickle

    class Grammar_load(unittest.TestCase):

        def _check_load(self, g):
            # Test the raw loads() method
            g2 = pickle.loads(pickle.dumps(g, protocol=0))
            self.assertEqual(str(g), str(g2))

            # Test the instance loads() method
            g2 = Grammar()
            g2.loads(pickle.dumps(g, protocol=0))
            self.assertEqual(str(g), str(g2))

            # Test the load() method
            with support.temp_cwd(support.TESTFN):
                g.dump(support.TESTFN)
               

# Generated at 2022-06-11 19:43:59.389208
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    filename = "test_Grammar_dump.pkl"
    grammar.dump(filename)
    grammar.load(filename)
    os.remove(filename)

# Generated at 2022-06-11 19:44:09.173526
# Unit test for method dump of class Grammar
def test_Grammar_dump():
    grammar = Grammar()
    assert(grammar.start == 256)
    assert(grammar.symbol2number == {})
    assert(grammar.number2symbol == {})
    assert(grammar.states == [])
    assert(grammar.dfas == {})
    assert(grammar.labels == [(0, "EMPTY")])
    assert(grammar.keywords == {})
    assert(grammar.tokens == {})
    assert(grammar.symbol2label == {})
    assert(grammar.async_keywords == False)

    f = tempfile.NamedTemporaryFile()
    fname = f.name
    grammar.dump(fname)
    assert(os.path.isfile(fname))

# Generated at 2022-06-11 19:44:16.037993
# Unit test for method load of class Grammar
def test_Grammar_load():
    """
    This test ensures the method load of class Grammar behaves as expected.

    This test will create a grammar instance, convert all its attributes
    to a dictionary, use pickle to serialize the dictionary, and then use
    pickle to deserialize the serialized data and test to make sure the
    deserialized data is the same as the data before it was serialized.

    """
    grammar = Grammar()
    grammar.symbol2number = {"a": 0, "b": 1, "c": 2}
    grammar.number2symbol = {0: "a", 1: "b", 2: "c"}
    grammar.dfas = {"a": (1, 2)}
    grammar.keywords = {"while": 1, "for": 2}
    grammar.tokens = {"a": 1, "b": 2}

# Generated at 2022-06-11 19:44:20.201872
# Unit test for method load of class Grammar
def test_Grammar_load():
    # Create a mock grammar to pickle and load
    grammar = Grammar()

    # mypyc generated objects don't have __dict__
    if not hasattr(grammar, "__dict__"):
        grammar.__dict__ = {}

    grammar.load('/tmp/foo')

# Generated at 2022-06-11 19:44:32.608920
# Unit test for method load of class Grammar
def test_Grammar_load():
    g = Grammar()
    g.load('/home/alex/.pyenv/versions/3.8.0/lib/python3.8/test/test_grammar.pkl')