

# Generated at 2022-06-11 16:31:04.505885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import collections
    import ansible.plugins.lookup.varnames as varnames_class

    options = {}
    term1 = '^qz_.+'
    term2 = '.+_zone$'
    term3 = '.+_location$'
    options['_terms'] = [term1, term2, term3]

    variables = {
        'qz_1': 1,
        'qz_2': 2,
        'qa_1': 3,
        'qa_': 4,
        'qz_': 5,
        'a2_zone': 6,
        'b2_zone': 7,
        'c3_zone': 8,
        'a2_location': 9,
        'b2_location': 10,
        'c3_location': 11,
    }

# Generated at 2022-06-11 16:31:15.568318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    variables = {'app1_config': {'name': 'app1', 'port': 8080},
                 'app2_config': {'name': 'app2', 'port': 80},
                 'app3_config': {'name': 'app3', 'port': 9000},
                 'zone': 'us-east-1',
                 'location': 'us',
                 'list_of_things': [{'name': 'abc'}, {'name': 'def'}]}

    ret = lookup.run(terms=['^app[123]_config$'], variables=variables)
    assert(len(ret) == 3)
    assert('app1_config' in ret)
    assert('app2_config' in ret)
    assert('app3_config' in ret)

# Generated at 2022-06-11 16:31:26.813931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  Setup the fake data to process
    fake_terms = ['promo.+', '^certified_', 'db_password']
    fake_variables = dict()
    fake_variables['certified_user'] = "hello"
    fake_variables['promo1_value'] = "world"
    fake_variables['promo2_value'] = "!"
    fake_variables['owner_password'] = "password"
    fake_variables['db_password']= "another_password"

    # Create the instance of Lookup Module we will be testing
    test_instance = LookupModule()

    # Generate the test results
    test_results = test_instance.run(fake_terms, fake_variables)
    test_result_string = ';'.join([str(result) for result in test_results])

# Generated at 2022-06-11 16:31:38.464005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""

    # Testing: No variables available to search
    lookup = LookupModule()
    try:
        lookup.run(['qz_1'], variables=None)
        assert False, "AnsibleError not raised."
    except AnsibleError:
        pass

    # Testing: Invalid setting identifier
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    try:
        lookup.run([100, '^qz_.+'], variables=variables)
        assert False, "AnsibleError not raised."
    except AnsibleError:
        pass

    # Testing: Unable to use as a search parameter

# Generated at 2022-06-11 16:31:48.350647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    text_obj=LookupModule()

    # Executing run() with invalid terms
    assert [] == text_obj.run(['abc'],None)

    # Executing run() with valid terms
    assert ['test1','test2'] == text_obj.run(['test'],{'test1':'value1','test2':'value2'})
    assert ['test1'] == text_obj.run(['st1'],{'test1':'value1','test2':'value2'})

    # Executing run() with invalid variables
    try:
        text_obj.run(['ab'],None)
    except Exception as e:
        assert 'No variables available to search' == str(e)

    #Executing run() with invalid terms


# Generated at 2022-06-11 16:31:49.866849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  l.run(terms = ['a'])

# Generated at 2022-06-11 16:32:00.184018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert (lookup.run(terms=[], variables=dict()) == [])
    assert (lookup.run(terms=["^qz_.+"], variables=dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")) == ['qz_1', 'qz_2'])
    assert (lookup.run(terms=[".+"], variables=dict(a=1, b=2, c=3, d=4)) == ['a', 'b', 'c', 'd'])
    assert (lookup.run(terms=["hosts"], variables=dict(hosts_file=1, hosts_path=2)) == ['hosts_file', 'hosts_path'])

# Generated at 2022-06-11 16:32:06.755702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule
    """
    varnames = LookupModule()
    result = varnames.run(terms = ['.+_zone$', '.+_location$'], variables={'value_zone': 'b', 'value_location': 'a', 'value': 'a'})
    assert set(result) == set(['value_zone', 'value_location']), "Result is {}".format(result)


# Generated at 2022-06-11 16:32:10.682456
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    variables = { 'my_var_1': 'Hello', 'my_var_2': 'World' }
    terms = ['my_var_1', 'my_var_2']

    assert module.run(terms=terms, variables=variables) == terms


# Generated at 2022-06-11 16:32:22.451960
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Try to use a list as a search pattern
    try:
        lookup_module = LookupModule()
        lookup_module.run(['This should be a string'])
        raise AssertionError('Accepted list as search pattern')
    except AnsibleError:
        pass

    # Search for strings that are not present
    variables = {
        'somewhat_unusual': '',
        'somewhat_normal': '',
        'rather_normal': '',
        'still_normal': '',
    }
    assert LookupModule()\
        .run(['This should not be present'], variables=variables) == []

# Generated at 2022-06-11 16:32:35.447111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a mock object of parent class LookupBase
    class LookupBaseMock(LookupBase):
        def __init__(self, **kwargs):
            self.options = kwargs

    # create a mock object of variables, a dictionary

# Generated at 2022-06-11 16:32:47.235444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    import re

    class Options(dict):
        def __getattr__(self, name):
            return self.get(name, None)

    test_variables_dict = {'var1': 'val1', 'var11': 'val1', 'var2': 'val2'}
    test_terms = ['^var1$', '^var11$']

    obj = LookupModule()
    options = Options()
    options.var_options = test_variables_dict
    obj.set_options(var_options=options.var_options, direct=options)

    result = obj.run(terms=test_terms)
    assert result == ['var1', 'var11']

    test_terms = ['^var2$']

    obj = Lookup

# Generated at 2022-06-11 16:32:55.480080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  # Test cases
  terms = ['^test_.+']
  variables = {'test_variable': 'test'}
  lookup_result = lookup_module.run(terms, variables)
  assert lookup_result == ['test_variable']

  terms = ['.+']
  variables = {'test_variable': 'test'}
  lookup_result = lookup_module.run(terms, variables)
  assert lookup_result == ['test_variable']

# Generated at 2022-06-11 16:33:03.194200
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a variable data structure for test
    variables = {
        'match_me_1': 'match_me_1',
        'do_not_match_me_1': 'do_not_match_me_1',
        'match_me_2': 'match_me_2',
        'do_not_match_me_2': 'do_not_match_me_2'
    }

    lookup = LookupModule()

    # Test with a single term
    result = lookup.run(
        ['match_me_.+'],  # Search for variables matching this regex
        variables=variables  # The variables data structure
    )

    assert result == ['match_me_1', 'match_me_2']

    # Test with several terms

# Generated at 2022-06-11 16:33:12.604868
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    # Variable names
    vars = ['aa', 'aaa', 'ab', 'ac', 'ad', 'bd', 'bd', 'bc', 'cc', 'bc', 'aa']

    # Pattern for variable names
    terms = ['^a', 'a', 'd$', '.', '^.$', '.*', '...', '......']


    lookup = LookupModule()

    vars_result = []
    for term in terms:
        variables = vars
        vars_result = lookup.run(terms=[term], variables=variables)

        assert len(vars) == len(vars_result)

    # return
    assert len(vars_result) == len(vars)

# Generated at 2022-06-11 16:33:22.310233
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_variables = {
        "CONFIG_VAR_1": "value 1",
        "CONFIG_VAR_2": "value 2",
        "CONFIG_VARTEST_3": "value 3",
        "CONFIG_VAR_4": "value 4",
        "CONFIG_VAR_5": "value 5"
    }

    lm = LookupModule()
    lm.set_options(
        var_options=test_variables,
        direct={}
    )

    # Testing method run with regex matching
    result = lm.run(terms=['^CONFIG_VAR_\d+$'])
    assert len(result) == 4
    assert 'CONFIG_VAR_1' in result
    assert 'CONFIG_VAR_2' in result

# Generated at 2022-06-11 16:33:26.291482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # GIVEN
    obj = LookupModule()

    # WHEN
    assert_result = obj.run(["^qz_.+"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show"})

    # THEN
    assert ["qz_1", "qz_2"] == assert_result

# Generated at 2022-06-11 16:33:33.002649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the run method of LookupModule class
    """

    variables = {'name': 'ansible', 'age': 20, '': 'something'}
    test_terms = ['ans', '^age$', '^(?!name)']

    lookup = LookupModule()
    assert lookup.run(terms=test_terms, variables=variables) == ['name', 'age']


# Generated at 2022-06-11 16:33:41.878103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import PY3
    from ansible.errors import AnsibleLookupError
    import sys

    lookup_base = LookupBase()
    lookup_module = LookupModule()

    # Test default variables
    assert lookup_module.run(terms = '^qz_.+') == ['qz_1', 'qz_2']

    # Test extra_vars
    assert lookup_module.run(terms = '^qz_.+', variables = {'qz_3' : 'hola'}) == ['qz_1', 'qz_2', 'qz_3']

    # Test invalid regex

# Generated at 2022-06-11 16:33:49.803028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    # First test
    terms = ["^qz_.+"]
    variables = {'qz_1': 'hello', 'qz_2': 'world'}
    expected = ['qz_1', 'qz_2']
    assert sorted(lookupModule.run(terms, variables)) == sorted(expected)
    # Second test
    terms = [".+"]
    variables = {'1': 'hello', '2': 'world'}
    expected = ['1', '2']
    assert sorted(lookupModule.run(terms, variables)) == sorted(expected)
    # Third test
    terms = ["hosts"]
    variables = {'other_hosts': 'hello', 'hosts': 'world'}
    expected = ['hosts']

# Generated at 2022-06-11 16:34:03.736568
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing invalid term
    invalid_term = set()
    l = LookupModule()
    v = {
        'qz_1': 'hello',
        'qz_2': 'world'
    }
    try:
        l.run(invalid_term, variables=v)
    except AnsibleError:
        pass
    else:
        raise AssertionError("Expected AnsibleError")

    # Testing missing variables
    l = LookupModule()
    try:
        l.run(['qz_1'])
    except AnsibleError:
        pass
    else:
        raise AssertionError("Expected AnsibleError")

    # Testing invalid regex
    l = LookupModule()
    try:
        l.run(['*'], variables=v)
    except AnsibleError:
        pass

# Generated at 2022-06-11 16:34:12.178560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variables = {}
    lookup_instance = LookupModule()
    lookup_instance.set_options({'_ansible_loader': loader,
                                 '_ansible_no_log': True,
                                 '_ansible_verbosity': 0})

    # Test without variables
    with pytest.raises(AnsibleError):
        lookup_instance.run(terms=[], variables={})

    # Test invalid terms
    with pytest.raises(AnsibleError):
        lookup_instance.run(terms=[{}], variables={})

    # Test invalid regex

# Generated at 2022-06-11 16:34:19.884015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # class variables
    test_lookup_name = "varnames"

    # create instance of LookupModule
    lookup_instance = LookupModule()

    # create test variables in the call to run
    test_variables = {'name1': 'value1', 'name2': 'value2', 'name3': 'value3'}
    test_terms = ['name1', 'name2', 'name3']

    test_result = lookup_instance.run(terms=test_terms, variables=test_variables)

    # display test output
    #print()
    #print(test_result)

    assert test_result == test_variables

# Generated at 2022-06-11 16:34:29.574540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    class MockLookupModule(LookupModule):
        def __init__(self, basedir=None, **kwargs):
            self.basedir = basedir

            class MockLoader:
                config = {'retry_files_enabled': '0'}

            class MockVarManager:
                loader = MockLoader
                config_data = {'retry_files_enabled': '0'}

            class MockPlayContext:
                varmgr = MockVarManager
                retry_files_save_path = '/home'

            class MockTask:
                play = MockPlayContext()

            class MockPlay:
                tasks = [MockTask()]
                basedir = basedir

            self.play = MockPlay()

    # Create a temporary directory to hold Ansible variables

# Generated at 2022-06-11 16:34:35.073523
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def __init__(self):
        self.variables = {'a1': 1, 'a23': 2, 'a345': 3, 'b2': 4}

    lookup = LookupModule()
    lookup.set_options(var_options=self, direct=None)
    terms = ['a.*']
    ret = lookup.run(terms, self.variables)
    assert len(ret) == 3

    return True

# Generated at 2022-06-11 16:34:44.991904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['^'], {}) == []
    assert LookupModule().run(['^foo$'], {}) == []
    assert LookupModule().run(['^foo$'], {'foo': "bar"}) == ['foo']
    assert LookupModule().run(['^foo'], {'foo': "bar"}) == ['foo']
    assert LookupModule().run(['^foo'], {'foo': "bar", 'foobar': "baz"}) == ['foo', 'foobar']
    assert LookupModule().run(['^foo$', '^baz$'], {'foo': "bar", 'baz': "baz"}) == ['foo', 'baz']

# Generated at 2022-06-11 16:34:52.072019
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_variables = {
        'ansible_all_ipv4_addresses': ['1.1.1.1'],
        'my_dict': {'a': 'b'},
        'my_list': ['a', 'b', 'c'],
    }
    module = LookupModule()
    module.set_options(var_options=mock_variables, direct={})
    # Find list variables
    terms = ['my_list']
    assert module.run(terms=terms, variables=mock_variables) == ['my_list']
    # Find dict variables
    terms = ['.*_dict']
    assert module.run(terms=terms, variables=mock_variables) == ['my_dict']
    # Find list and dict variables

# Generated at 2022-06-11 16:35:01.142855
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockVariableManager(object):
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self, loader=None, play=None, task=None, include_hostvars=True):
            return self._vars

    class MockNode(object):
        def __init__(self):
            self._variable_manager = None

        def set_variable_manager(self, manager):
            self._variable_manager = manager

        def get_variable_manager(self):
            return self._variable_manager

    class MockTask(object):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self):
            return self.vars

    module = LookupModule()

    # Test #1 - search for a single var

# Generated at 2022-06-11 16:35:10.920832
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:35:21.208718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = dict(
        aaa='1',
        aab='2',
        aac='3',
        baa='4',
        bab='5',
        bac='6',
        cca='7',
        ccb='8',
        ccc='9')

    lookup_module = LookupModule()

    ret = lookup_module.run((), variables=variables)
    assert ret == []

    ret = lookup_module.run(('^a', '^b'), variables=variables)
    assert ret == ['aaa', 'aab', 'aac', 'baa', 'bab', 'bac']

    ret = lookup_module.run(('^a.+$', '^b'), variables=variables)

# Generated at 2022-06-11 16:35:35.166083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    def test_empty_variable_names():
        ret = lm.run(['name'])
        assert len(ret) == 0

    def test_bad_term():
        ret = lm.run([{'bad': 'term'}])
        assert len(ret) == 0

    def test_one_match():
        ret = lm.run(['.+'], variables={'one': 1})
        assert ret == ['one']

    def test_no_match():
        ret = lm.run(['none'], variables={'one': 1})
        assert len(ret) == 0


# Generated at 2022-06-11 16:35:44.624455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [".+_zone$", ".+_location$"]     # The first terms that will be processed
    #   generate the variables indicated
    variables = dict(log_zone='log_zone_name',
                     log_location='log_location_name',
                     log_service='log_service_name',
                     log_type='log_type_name',
                     log_times='log_times_name',
                     log_port='log_port_name')

    lookup = LookupModule()
    result = lookup.run(terms, variables)
    #   Check that the result is correct
    assert result == ['log_zone', 'log_location']

# Generated at 2022-06-11 16:35:50.984699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['foo', 'bar']

    variables = {'foo': '1', 'foo_bar': '2', 'bar_2': '3', 'bar_1': '4'}

    # get expected result
    expected_result = ['foo', 'foo_bar', 'bar_2', 'bar_1']

    # instantiate lookup class
    lookupModule = LookupModule()

    # get result
    result = lookupModule.run(terms, variables)

    # comapre
    assert result == expected_result

# Generated at 2022-06-11 16:35:58.628111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Method to test run method of class LookupModule
    """
    lookup_obj = LookupModule()
    variables = {
        "var_1": 'hello',
        "var_2": "world",
        "var_3": "hello world",
        "var_4": "how are you",
        "var_5": "hello world how are you",
        "var_6": "hello world how are you I am fine"
    }
    lookup_obj.run(terms=['^var.+'], variables=variables)

# Generated at 2022-06-11 16:36:09.458327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests if lookup returns matches for given regex
    lookup_obj = LookupModule()
    # No variables are specified
    assert lookup_obj.run(["^qz_.+"], None) == []

    # No matches are found for regex
    assert lookup_obj.run(["^qz_.+"], {"qa_1": "hello"}) == []

    # No matching regex
    lookup_obj = LookupModule()
    assert lookup_obj.run(["qz_1"], {"qz_1": "hello"}) == []

    # Matching regex
    lookup_obj = LookupModule()
    assert lookup_obj.run(["qz_1"], {"qz_1": "hello"}) == []

    # Matching regex
    lookup_obj = LookupModule()

# Generated at 2022-06-11 16:36:18.334686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Prepare test data
    terms_list = [
        ['^qz_.+'],
        ['.+'],
        ['hosts'],
        ['.+_zone$', '.+_location$']
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
        'qz_' : 'I wont show either',
        'hello_world': 'test',
        'world_hello': 'test',
        'hello.world': 'test',
        'world.hello': 'test'
    }


# Generated at 2022-06-11 16:36:19.448530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-11 16:36:22.188896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['a'], dict(a='A', b='B')) == ['a']

# Generated at 2022-06-11 16:36:27.322971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {
        'x_data': 100,
        'x_data_cost': 50,
        'y_data': 150,
        'x_data_cost_region': 'east',
        'y_data_cost_region': 'south',
    }

    terms = 'x_data_cost$'
    ret = lookup.run([terms], variables=variables)
    assert ret == ['x_data_cost', 'x_data_cost_region']

# Generated at 2022-06-11 16:36:34.363603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test if the run method of LookupModule class works correctly."""

    lookup_module = LookupModule()

    # Assign variables
    terms = ["name"]
    variables = {
        "name": "ansible",
        "name1": "vagrant",
        "name2": "test",
        "name3": "ansible",
    }

    # Test if the run method works correctly
    assert lookup_module.run(terms, variables) == ['name', 'name3']

# Generated at 2022-06-11 16:36:50.677255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(['^qz_.+'], {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }) == ['qz_1', 'qz_2']



# Generated at 2022-06-11 16:36:59.101663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with "real" data
    def test_real_data(terms, var_options, expected_result):
        # Run the function being tested
        result = LookupModule().run(terms=terms, variables=var_options)[0]
        assert result == expected_result

    # Test with "mocked" data
    def test_mocked_data(terms, expected_result):
        # Mock the lookup plugin
        lookup_plugin_mock = LookupModule()
        lookup_plugin_mock.set_options(var_options=var_options_mock, direct=dict())

        # Make the function being tested available temporarily
        test_fn = lookup_plugin_mock.run

        # Mock the dependencies and run the function being tested

# Generated at 2022-06-11 16:37:08.902945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test data
    variables=dict(a='b', c='d', abab='1234', hello='world')
    lookup_module=LookupModule()

# Generated at 2022-06-11 16:37:10.430872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   testobj = LookupModule()
   testobj.run([], {})

# Generated at 2022-06-11 16:37:17.929341
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_vars are variables that are used by test cases
    test_vars = dict(
        test_var_1 = "a value",
        test_var_2 = "different value",
        test_var_3 = "another value",
        test_var_4 = "yet another value",
        a_var = "test string",
        a_list = [ 1, 2, 3 ],
        a_dict = dict(
            foo = "bar",
            baz = "foobar",
            quux = "barbaz",
        ),
    )

    # test_regexes are Python regular expressions used by test cases

# Generated at 2022-06-11 16:37:27.919084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()

    def test(terms, variables, output):
        ret = test_obj.run(terms, variables)
        assert isinstance(ret, list)
        assert ret == output

    # no variables in the env
    test(['a.+'], None, [])

    # empty terms
    test([], {'a': 'b'}, [])

    # terms not a list
    try:
        test({}, {'a': 'b'})
        assert False, 'expected exception'
    except:
        pass

    # contains invalid regex
    try:
        test(['a['], {'a': 'b'})
        assert False, 'expected exception'
    except:
        pass

    # search in the variables

# Generated at 2022-06-11 16:37:36.545871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import types
    import pprint
    pp = pprint.PrettyPrinter(indent=4)


# Generated at 2022-06-11 16:37:37.164909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:37:47.360000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Mocks and test data
    terms = [
        'qz_.+',
        '.+zone$',
        '.+location$'
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts_zone': ['localhost'],
        'hosts_location': ['/etc/hosts'],
        'host_zone': ['local.zone'],
        'host_location': ['/etc/zone.list']
    }

    # Call the method
    ret = LookupModule(terms, variables).run(terms, variables)

    # Check if the method returns expected value

# Generated at 2022-06-11 16:37:58.172938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()

    variable_names = {
        'hosts': 'hosts',
        'databases': 'databases',
        'project': 'project',
        'project_zone': 'us-central1-f',
        'project_location': 'us-central1-f',
        'zone': 'us-central1-f',
        'location': 'us-central1-f',
    }

    # Simple regular expression
    terms = ['^project', '']
    expected_output = ['project', 'project_zone', 'project_location']
    variables = L.run(terms, variable_names)
    assert variables == expected_output

    # Simple regular expression
    terms = ['^project_zone$']
    expected_output = ['project_zone']

# Generated at 2022-06-11 16:38:27.959031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()

    # Test with invalid settings identifier
    settings = ['test']
    variables = {'test': 'variable'}
    assert test_lookup_module.run(settings, variables) == ['test'], "Should return variable name for settings"
    settings = ['test variable']
    assert test_lookup_module.run(settings, variables) == [], "Should return empty list for invalid settings identifier"

# Generated at 2022-06-11 16:38:36.767401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'_ansible_vars': dict(myvar='hello')})

    # correct variable name, correct variable value
    assert ['myvar'] == l.run([r'\w+'])

    # correct variable name, wrong variable value
    assert [] == l.run([r'\w+', r'\W'])

    # wrong variable name, correct variable value
    assert [] == l.run([r'\W', r'\w'])

    # wrong variable name, wrong variable value
    assert [] == l.run([r'\W'])

    # unsupported type for variable name
    try:
        l.run([1])
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

# Generated at 2022-06-11 16:38:38.783869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run([], {'a':'A', 'b':'B', 'c':'C'})

# Generated at 2022-06-11 16:38:48.212867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    test_vars = { u'asd1': 'foo', u'asd2': 'bar', u'somelongvarname': 'baz' }
    assert set(lookup.run(['asd.'], test_vars)) == set(['asd1', 'asd2'])
    assert set(lookup.run(['somelongvarname'], test_vars)) == set(['somelongvarname'])
    assert set(lookup.run(['.+', '.+'], test_vars)) == set(test_vars.keys())
    assert set(lookup.run(['asd1'], test_vars)) == set(['asd1'])

# Generated at 2022-06-11 16:38:58.360645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_class_declaration: recommended naming pattern
    lookup_plugin = LookupModule()

    # Set up test data variables

# Generated at 2022-06-11 16:39:06.895993
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with no variables available
    lookup_obj = LookupModule()
    try:
        result = lookup_obj.run(
            terms=["foo"],
            variables=None
        )
    except AnsibleError as e:
        assert "No variables available to search" in str(e)
    else:
        assert False

    # Test with non-matching terms
    lookup_obj = LookupModule()
    result = lookup_obj.run(
        terms=["foo"],
        variables={
            "bar": "baz"
        }
    )
    assert result == []

    # Test with matching terms
    lookup_obj = LookupModule()
    result = lookup_obj.run(
        terms=["bar"],
        variables={
            "bar": "baz"
        }
    )

# Generated at 2022-06-11 16:39:07.590217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No test implemented"

# Generated at 2022-06-11 16:39:09.243013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate the LookupModule class
    lm = LookupModule()

    # Just return an empty list
    assert lm.run([], None) == []



# Generated at 2022-06-11 16:39:13.457889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare data
    terms = ['^qz_', '^qa_']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    # Run method with parameters
    ret = LookupModule().run(terms, variables=variables)

    # Assert
    assert ret == ['qz_1', 'qz_2']


# Generated at 2022-06-11 16:39:22.704916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize objects
    lookup_list = [
            '^qz_.+',
            '.+_location$',
            '.+_zone$'
    ]
    vars_list = {
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
            'some_location' : 'hello',
            'something_zone': 'hello',
            'location': 'hello',
            'zone': 'hello',
    }

    # Execute run method: m
    m = LookupModule()

    # Copy the above variables to m.get_basedir
    m.get_basedir = vars_list

    # Expected result

# Generated at 2022-06-11 16:40:20.124260
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # test error case: no variables given
    assert_raises(AnsibleError, lookup_module.run, ['test'])

    # test default: no variable matches
    assert_equal(lookup_module.run(variables={'abc': 'abc'}, terms=['test']), [])

    # test default: single variable matches
    assert_equal(lookup_module.run(variables={'abc': 'abc'}, terms=['abc']), ['abc'])

    # test default: two variables matches
    variables = {'abc': 'abc', 'def': 'def'}
    assert_equal(set(lookup_module.run(variables=variables, terms=['a.c', 'def'])), set(['abc', 'def']))

    # test default: variables

# Generated at 2022-06-11 16:40:29.152061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	
	terms = ['abc']
	variables = {'abc': 1}
	kwargs = {'hostvars': {'hostname' : {}}}	
	lu = LookupModule()
	lu.set_options(var_options=variables, direct=kwargs)
	ret = lu.run(terms, variables=variables, **kwargs)
	assert ret == ['abc']

	terms = ['^test.+']
	variables = {'test': 1}
	kwargs = {'hostvars': {'hostname' : {}}}	
	lu = LookupModule()
	lu.set_options(var_options=variables, direct=kwargs)
	ret = lu.run(terms, variables=variables, **kwargs)
	assert ret == ['test']


# Generated at 2022-06-11 16:40:38.186482
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock variable contents using fixtures/variable_list.json
    variable_list = {
        "Test_variable": "test_value",
        "test_another_variable": "test_another_value"
    }

    # Initialize a LookupModule instance
    lookup = LookupModule()

    # Call method run
    # NOTE: LookupModule.run returns a list as a result of which we cannot use
    # assertEqual as it only compares two objects. So we convert the list to
    # sets and compare them.
    assert set(lookup.run(["test_variable"], variables=variable_list)) == set(["test_variable"])
    assert set(lookup.run(["test_var.*"], variables=variable_list)) == set(["Test_variable", "test_another_variable"])

# Generated at 2022-06-11 16:40:49.730076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run(terms=['^qz_.+'], variables={'qz_1': 'hello'}) == ['qz_1']
    assert lookup.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world'}) == ['qz_1', 'qz_2']
    assert lookup.run(terms=['hosts'], variables={'hosts': 'a1', 'hosts_groups': 'b2'})