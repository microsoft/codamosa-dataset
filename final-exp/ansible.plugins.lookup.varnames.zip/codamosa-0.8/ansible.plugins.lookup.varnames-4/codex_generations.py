

# Generated at 2022-06-11 16:31:05.389299
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    looker = LookupModule()

    # Check the run method with missing argument: variables
    try:
        looker.run([])
        assert(False)
    except AnsibleError as e:
        assert(isinstance(e, AnsibleError))

    # Check the run method with invalid value in terms
    try:
        looker.run([1], {})
        assert(False)
    except AnsibleError as e:
        assert(isinstance(e, AnsibleError))

    # Check the run method with invalid regex in terms
    try:
        looker.run(["*"], {})
        assert(False)
    except AnsibleError as e:
        assert(isinstance(e, AnsibleError))

    # Check the run method with only one valid regex in terms

# Generated at 2022-06-11 16:31:10.991261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'_ansible_variables':{'test_var':'', 'another_test_var':'', 'test_var1':''}})
    assert l.run(terms=['test_var', '^test_var1']) == ['test_var', 'test_var1']

# Generated at 2022-06-11 16:31:19.012526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    lookup = LookupModule()
    terms = [ "^qz_.+", ".+", "hosts" ]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': '8.8.8.8'
    }
    ansible_owned_vars = None
    # test_lookup_plugin.py
    lookup._connection = None
    lookup._templar = None

    result = lookup.run(terms, variables, ansible_owned_vars)


# Generated at 2022-06-11 16:31:24.713577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            terms=dict(required=True, type='list'),
        ),
    )

    terms = module.params['terms']
    variables = module.params['vars']
    direct = module.params['direct']
    lookup_instance = LookupModule()
    result = lookup_instance.run(terms, variables, **direct)

    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:31:30.406645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    module = AnsibleModule(
        argument_spec = dict(
            _terms = dict(required=True, type='list')
        )
    )

    assert LookupModule(module).run(terms=['^qz_.+'],
                                    variables={'qz_1': 'hello',
                                               'qz_2': 'world',
                                               'qa_1': 'I wont show',
                                               'qz_': 'I wont show either'}) == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:31:41.883978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test function for LookupModule method run.
    """
    # a temporary mockup:
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class MockActual(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    kwargs = dict(
        name = "VarName",
        vars = dict(
            a_variable = "valuable",
            another_variable = "valuable",
        ),
    )
    nested_vars = dict(
        server_id = 65,
        another_variable = "valuable",
    )

# Generated at 2022-06-11 16:31:52.949083
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display
    import sys

    # Unit test for method run of class LookupModule
    # Instantiate class
    lookup = LookupModule()

    assert isinstance(lookup, LookupBase)

    assert lookup.run([]) == []

    # Create an empty 'terms' parameter
    terms = []

    # Create an empty 'variables' parameter
    variables = {}

    with pytest.raises(AnsibleError) as excinfo:
        assert lookup.run(terms, variables)

    # Create an empty 'variables' parameter
    variables = None


# Generated at 2022-06-11 16:32:01.629760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["^qz_.+"],dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")) == ["qz_1", "qz_2"]
    assert lookup.run([".+"], dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")) == ["qz_1", "qz_2", "qa_1", "qz_"]
    assert lookup.run(["hosts"], dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")) == []

# Generated at 2022-06-11 16:32:07.216275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = LookupModule().run(terms, variables)
    assert isinstance(ret, list)
    assert 'qz_1' in ret

# Generated at 2022-06-11 16:32:13.467323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.varnames
    lookup_module = ansible.plugins.lookup.varnames.LookupModule(None)
    assert lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", "qz_": "I won't show either"}) == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:32:28.933169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = '''
- name: List variables that start with qz_
  debug: msg="{{ lookup('varnames', '^qz_.+')}}"
  vars:
    qz_1: hello
    qz_2: world
    qa_1: "I won't show"
    qz_: "I won't show either"

- name: Show all variables
  debug: msg="{{ lookup('varnames', '.+')}}"

- name: Show variables with 'hosts' in their names
  debug: msg="{{ lookup('varnames', 'hosts')}}"

- name: Find several related variables that end specific way
  debug: msg="{{ lookup('varnames', '.+_zone$', '.+_location$') }}"
    '''


# Generated at 2022-06-11 16:32:36.230311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re

    lookup_class = LookupModule()
    vars = dict(qz_1='hello', qz_2='world', qa_1='I won\'t show', qz_='I won\'t show either')
    result = lookup_class.run(terms=['^qz_.+'], variables=vars)
    assert(isinstance(result, list))
    for var in result:
        assert(re.match(r'^qz_.+', var))

    result = lookup_class.run(terms=['.+'], variables=vars)
    assert(len(result) == 4)

    result = lookup_class.run(terms=['hosts'], variables=vars)
    assert(len(result) == 0)


# Generated at 2022-06-11 16:32:48.344685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class OptionsModule: pass
    class OptionsModule2: pass
    op1 = OptionsModule()
    op2 = OptionsModule2()
    op1.vars = { "foo" : "bar", "this" : "that", "hello" : "world" }
    op2.vars = { "foo" : "bar", "this" : "that", "hello" : "world" }
    mod = LookupModule()
    mod.set_options(var_options=op1, direct=op2)
    ret = mod.run(["this"], variables=op1.vars)
    assert len(ret) == 1 and isinstance(ret, list) and ret[0] == "this"
    ret = mod.run(["f.o"], variables=op1.vars)
    assert len(ret) == 1 and isinstance

# Generated at 2022-06-11 16:32:53.497227
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # unit test config
    terms = ['term' + str(x) for x in range(1,10)]
    variable_names = ['term' + str(x) for x in range(4,12)]

    # instance class for testing
    look = LookupModule()
    ret = look.run(terms, variable_names)

# Generated at 2022-06-11 16:32:59.511165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    variables = {"test_vars": "test",
                 "test_var_1": "test",
                 "test_var_zone": "test"}
    terms = "test_var.+", "^test_vars$"
    expected = ["test_vars", "test_var_1", "test_var_zone"]
    result = module.run(terms=terms, variables=variables)
    assert result == expected

# Generated at 2022-06-11 16:33:10.242582
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible_collections.ansible.community.tests.unit.plugins.lookup.common import TestLookupBase

    class TestLookupModule(TestLookupBase):
        def test_LookupModule(self, *args, **kwargs):
            lookup_plugin = LookupModule()
            lookup_plugin.set_options(var_options=self.variables, direct=kwargs)

            ret = lookup_plugin.run(terms=['foo'], variables=self.variables, **kwargs)
            self.assertEqual(ret, ['foo'])
            ret = lookup_plugin.run(terms=['.+'], variables=self.variables, **kwargs)
            self.assertEqual(ret, ['foo', 'baz'])

# Generated at 2022-06-11 16:33:18.433381
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.compat.tests.mock import patch, MagicMock

    # preparation
    test_LookupModule = LookupModule()
    test_LookupModule.set_options = MagicMock()
    test_LookupModule.set_options(var_options={}, direct={})

    # test run on empty terms and variables
    terms = []
    variables = {}
    got = test_LookupModule.run(terms, variables)
    want = []
    assert got == want

    # test if an error is raised if no variables are available
    try:
        terms = []
        variables = None
        test_LookupModule.run(terms, variables)
    except AnsibleError:
        pass
    except:
        raise
    else:
        assert False, "AnsibleError not raised"

    # test if terms

# Generated at 2022-06-11 16:33:27.278036
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeLookupModule(LookupModule):

        def __init__(self):
            super(LookupModule, self).__init__()

    lookupModule = FakeLookupModule()
    assert(lookupModule.run(terms=['^[a-z]+$']) == [])

    lookupModule = FakeLookupModule()
    assert(lookupModule.run(terms=['^[a-z]+$'], variables={ 'x': 'y' }) == ['x'])

    lookupModule = FakeLookupModule()
    assert(lookupModule.run(terms=['^[a-z]+$'], variables={ 'x': 'y', 'abc': 'def', '1': '2' }) == ['x', 'abc'])

    lookupModule = FakeLookupModule()

# Generated at 2022-06-11 16:33:34.363239
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LUM = LookupModule()

    class LookupModule_run_vars:
        qz_1 = 'hello'
        qz_2 = 'world'
        qa_1 = "I won't show"
        qz_ = "I won't show either"

    r = LUM.run([ '^qz_.+' ], variables=LookupModule_run_vars)

    assert r == [ 'qz_1', 'qz_2' ], "Wrong variables found: %s" % (r,)

# Generated at 2022-06-11 16:33:40.314401
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.module_utils.six import string_types

    # Create instance of class LookupModule
    lookup_plugin = LookupModule()

    # Test with terms and variables
    terms = ['^qz_.+', '.*']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_plugin.run(terms, variables) == ['qz_1', 'qz_2', 'qz_', 'qa_1', 'qz_1', 'qz_2', 'qz_', 'qa_1']

    # Test with terms and variables, but one term is not string type

# Generated at 2022-06-11 16:33:51.893933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    test_LookupModule.run(terms=["^qz_.+"], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-11 16:34:03.009172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with variable name 'test_variable' matching the term 'test.+'
    y = LookupModule()
    y.set_options(direct={'variables':{'test_variable':'some_value'}})
    assert y.run(['test.+'])[0] == 'test_variable'

    # Test with variable name 'test_variable' not matching the term 'test\d'
    y = LookupModule()
    y.set_options(direct={'variables':{'test_variable':'some_value'}})
    assert y.run(['test\d']) == []

    # Test with variable name 'test_variable' matching the term '^test_variable$'
    y = LookupModule()

# Generated at 2022-06-11 16:34:11.447883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.module_utils.six.moves import StringIO

    lookup = LookupModule()

    dict1 = dict()
    dict1['qz_1'] = 'hello'
    dict1['qz_2'] = 'world'
    dict1['qa_1'] = 'I won\'t show'
    dict1['qz_'] = 'I won\'t show either'

    dict2 = dict()
    dict2['hosts'] = 'host1'
    dict2['hostname'] = 'host2'

    dict3 = dict()
    dict3['1_zone'] = 'zone1'
    dict3['2_zone'] = 'zone2'
    dict3['3_zone'] = 'zone2'

# Generated at 2022-06-11 16:34:17.924303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_options({})
    terms = ["^qz_.+"]
    variables = {"qa_1": "I will not show", "qz_1": "hello", "qz_2": "world", "qz_": "I will not show either"}
    mod.run(terms, variables)
    assert variables["qz_"] == "I will not show either"
    assert set(mod.run(terms, variables)) == {"qz_1", "qz_2"}


# Generated at 2022-06-11 16:34:22.523747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    result = look.run(['^a.+', '^b.+'], {'a1': 1, 'a2': 2, 'b1': 1, 'b2': 2, 'c1': 1, 'c2': 2})
    assert len(result) == 4

# Generated at 2022-06-11 16:34:29.308401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options:
        def __init__(self, direct=None, var_options=None):
            self.direct = direct
            self.var_options = var_options

    class NoArgs:
        pass

    class EmptyArgs:
        def get(self, key, default=None):
            return default

    class OneArgs:
        def get(self, key, default=None):
            if key == 'var_options':
                return {'qz1': 'hello', 'qz2': 'world', 'qz3': 'qz3', 'qz4': 'qz4'}
            else:
                return default


# Generated at 2022-06-11 16:34:38.590742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule({}, {}, ['.*'])

    # First check that we get an error if the variables are not
    # passed.
    try:
        lookup_module.run(['foo'])
        assert False, "Should have raised an error"
    except AnsibleError:
        pass

    # Next, check that we can find the variable that matches the
    # regex.
    ret = lookup_module.run(['foo'], {'foo' : 'bar'})
    assert ret == ['foo']
    
    # Next, ensure that the variable doesn't have to be the only one
    # in the variable hash
    ret = lookup_module.run(['foo'], {'foo' : 'bar', 'bar': 'baz'})
    assert ret == ['foo']
    
    # Next, ensure that

# Generated at 2022-06-11 16:34:48.863142
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['^qz_.+', 'hosts']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'database_host': 'localhost',
        'database_hosts': 'localhost, docker',
    }

    result = LookupModule().run(terms, variables)
    assert result == ['qz_1', 'qz_2', 'qz_','database_hosts'], 'varnames lookup should return all variables'

    result = LookupModule().run(['^qz_.+'], variables)

# Generated at 2022-06-11 16:34:59.236005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    terms = 'qz.+'
    variables = {'qz_1': {'a': 1}, 'qz_2': {'a': 2, 'b': 3}, 'qa_1': {'a': 4}, 'qz_': {'a': 5}}

    assert l.run([terms], variables) == ['qz_1', 'qz_2']

    terms = '.+'
    assert l.run([terms], variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    terms = 'qa.+'
    assert l.run([terms], variables) == ['qa_1']

    terms = ['qz.+', 'qa.+']

# Generated at 2022-06-11 16:35:09.550450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'a': 1, '_a':1, 'x_y': 2, 'z_y': 3}

    # Test empty list of patterns
    result = lookup.run([], variables)
    assert result == []

    # Test empty variables
    result = lookup.run(['a'], {})
    assert result == []

    # Test simple pattern
    result = lookup.run(['a'], variables)
    assert result == ['a']

    # Test multiple patterns
    result = lookup.run(['a', 'z'], variables)
    assert result == ['a', 'x_y', 'z_y']

    # Test multiple patterns, some which do not exist
    result = lookup.run(['a', 'b', 'z'], variables)

# Generated at 2022-06-11 16:35:22.151073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['ansible_.*'], {"ansible_hostname" : 'test1'}) == ['ansible_hostname']
    assert LookupModule().run(['asdf'], {"ansible_hostname" : 'test1'} ) == []
    assert LookupModule().run(['_'], {"ansible_hostname" : 'test1'} ) == []

# Generated at 2022-06-11 16:35:32.551165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.plugins.lookup import LookupModule
    else:
        from ansible.plugins.lookup import LookupModule as LookupModule

    def test_run_method(terms, variables):
        '''
        Objective: Test the run method with different inputs.
        '''
        lm = LookupModule()
        lm.load('varnames', terms, None, variables=variables)
        return lm.run(terms, variables)[0]

    foo = {'name': 'foo', 'version': '1.2.3'}
    bar = {'name': 'bar', 'version': '4.5.6'}
    my_dict = {'foo': foo, 'bar': bar}

    # First test

# Generated at 2022-06-11 16:35:43.400410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError

    # This is an invalid return value
    assert(LookupModule(None, None).run(['^qz_1$']) != [])

    # This is a valid return value
    assert(LookupModule(None, None).run(['^qz_1$'], variables={'qz_1': 'hello', 'qz_2': 'world'}) == ['qz_1'])

    # terms should be an array
    assert_raises(AnsibleError, LookupModule(None, None).run, '^qz_1$')

    # Each term must be a string
    assert_raises(AnsibleError, LookupModule(None, None).run, ['^qz_1$', list()])

    # Each term must be a valid regular expression
   

# Generated at 2022-06-11 16:35:52.666262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case for valid variable names
    lookup = LookupModule()
    terms = 'test_[0-9]+'
    variables={'test_1' : 1,
               'test_2' : 2,
               'TEST_3' : 3 }
    result = lookup.run(terms, variables)
    assert result == ["test_1", "test_2"]

    # test case for invalid variable names
    lookup = LookupModule()
    terms = 'test_[0-9]+'
    variables={'1' : 1,
               '2' : 2,
               'TEST' : 3 }
    result = lookup.run(terms, variables)
    assert result == []

    # test case for multiple terms
    lookup = LookupModule()
    terms = ['ab.*','.+_c']

# Generated at 2022-06-11 16:35:56.440106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['qz_1', 'qz_2']
    variables = {'qz_1': 1, 'qz_2': 2, 'qa_1': 3}

    lookup = LookupModule()
    lookup.run(terms, variables)

# Generated at 2022-06-11 16:36:03.079625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test: no settable variables
    results = module.run([], variables=None)
    assert results == []

    # Test: find one variable
    results = module.run(['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world'})
    assert results == ['qz_1', 'qz_2']

    # Test: find no variable
    results = module.run(['^qz_.+'], variables={'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert results == []

    # Test: find all variables
    results = module.run(['.+'], variables={'qz_1': 'hello', 'qz_2': 'world'})

# Generated at 2022-06-11 16:36:13.972375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeVars():
        def __init__(self, variables):
            self.variables = variables

    module = LookupModule()
    variables = FakeVars({'name': 'ansible', 'ansible_os_family': 'RedHat'})
    terms = ['^name$', 'ans' ]

    expected_result = ['name', 'ansible']
    result = module.run(terms=terms, variables=variables.variables)
    assert result == expected_result, 'LookupModule.run with test #1 failed!'

    terms = ['^name$', 'bob']
    expected_result = ['name']
    result = module.run(terms=terms, variables=variables.variables)
    assert result == expected_result, 'LookupModule.run with test #2 failed!'


# Generated at 2022-06-11 16:36:24.772538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    lookup_module = LookupModule()
    variable_names = {
        'a1': 'foo',
        'a2': 'bar',
        'b0': 'foo',
        'b1': 'bar',
        'b22': 'baz',
        'c0': 'foo',
        'c1': 'bar',
        'c2': 'baz',
        'd1': 'bar',
        'e0': 'foo',
        'e1': 'bar',
        'e2': 'baz',
    }

# Generated at 2022-06-11 16:36:33.526314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	terms = ['a', 'b']
	variables = {'a': 1, 'b': 2, 'c': 3}

	lm = LookupModule()

	returned_val = lm.run(terms, variables)
	assert returned_val == [list(variables.keys())[0], list(variables.keys())[1]]

	terms = ['a', 'z']
	returned_val = lm.run(terms, variables)
	assert returned_val == [list(variables.keys())[0]]

	terms = ['z', 'y']
	returned_val = lm.run(terms, variables)
	assert returned_val == []

# Generated at 2022-06-11 16:36:40.832219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    lookup_module = LookupModule()
    input_variables = {'netconf_port': '9999', 'netconf_address': '10.10.10.10'}
    output_variable_names = lookup_module.run(['netconf_.+'], input_variables)
    assert output_variable_names == ['netconf_port', 'netconf_address']

    input_variables = {'netconf_port': '9999', 'netconf_address': '10.10.10.10'}
    output_variable_names = lookup_module.run(['port'], input_variables)
    assert output_variable_names == []


# Generated at 2022-06-11 16:37:00.471107
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {'test_host': 'host1', 'host': 'host2', 'host_var': 'host3', 'var': 'host4', 'var_host': 'host5'}

    ret = LookupModule.run(['host'], variables)

    assert 'host' in ret
    assert 'host_var' in ret
    assert 'var_host' in ret

    assert len(ret) == 3

#Unit test for method run of class LookupModule if variables is None

# Generated at 2022-06-11 16:37:07.179127
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_mock = LookupModule()

    expected_method_run_result = ['qz_1', 'qz_2']

    mock_terms = ['^qz_.+']
    mock_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    method_run_result = lookup_mock.run(mock_terms, mock_variables)

    assert method_run_result == expected_method_run_result

# Generated at 2022-06-11 16:37:08.306728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 16:37:16.847548
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_var_data = {"test_name": "test_value",
                     "test_name2": "test_value2"
                     }
    tests = []

    test1 = {
        "terms": [r'test_name'],
        "result": ['test_name']
    }

    tests.append(test1)

    test2 = {
        "terms": [r'test_name', r'test_name2'],
        "result": ['test_name', 'test_name2']
    }

    tests.append(test2)

    test3 = {
        "terms": [r'test_name', r'test_name3'],
        "result": ['test_name']
    }

    tests.append(test3)

    lm = LookupModule()


# Generated at 2022-06-11 16:37:23.291893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  """
  Test case for method run of class LookupModule
  """
  lm = LookupModule()
  terms = "^qz_.+"
  variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
  kwargs = {}

  assert lm.run(terms,variables,**kwargs) == ["qz_1", "qz_2"]

# Generated at 2022-06-11 16:37:29.308643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_var = {"Name": "ansible"}
    test_lookup = LookupModule()
    test_lookup.set_options(var_options=test_var, direct=None)
    assert test_lookup.run(['^Name$', 'ansible']) == ['Name']
    assert test_lookup.run(['Name', 'ansible']) == ['Name', 'ansible']
    assert test_lookup.run(['ansible']) == ['ansible']

# Generated at 2022-06-11 16:37:35.214944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    t = ('^qz_.+', 'hosts')
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qz_3': 'world', 'qa_1': 'I wont show', 'qz_': "I won't show either"}
    result = lu.run(t, vars)
    assert result == ['qz_1', 'qz_2', 'qz_3', 'hosts'], result

# Generated at 2022-06-11 16:37:45.400916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    import unittest

    class Options:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class AnsibleModule:

        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-11 16:37:52.099554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run(terms=['^vars_', '.+_yes'], variables={'vars_1': 1,
                                                           'vars_2': 2,
                                                           'test_test': True,
                                                           'test_yes': 'yes'
                                                           })
    assert ['vars_1', 'vars_2', 'test_yes'] == ret, 'LookupModule method run failed.'

# Generated at 2022-06-11 16:38:01.501092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I wont show either'}) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+'], {'x': 'hello', 'y': 'world', 'z': 'I won\'t show'}) == ['x', 'y', 'z']
    assert lookup_module.run(['hosts'], {'ansible_hosts': 'hello', 'other_host': 'world'}) == ['ansible_hosts', 'other_host']

# Generated at 2022-06-11 16:38:37.270908
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    assert isinstance(module, LookupModule)

    assert list(module.run("^qz_.+", { "qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})) == [ "qz_1", "qz_2"]
    assert list(module.run("hosts", { "inventory_hosts": "aaa", "ansible_hosts": "bbb" })) == [ "inventory_hosts", "ansible_hosts" ]

# Generated at 2022-06-11 16:38:47.528331
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import yaml
    import json
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('varnames', class_only=True)
    cur_dir = os.path.dirname(__file__)
    data_dir = os.path.join(cur_dir, '../../../lib/ansible/plugins/lookup/data')
    vars_yaml_file = os.path.join(data_dir, 'test_vars.yml')

    with open(vars_yaml_file, 'r') as f:
        variables = yaml.safe_load(f)

# Generated at 2022-06-11 16:38:57.805702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVariables:
        def __init__(self):
            self.hostvars = {}

    terms_correct = ['^qz_.+', 'hosts', '.+', '.+_zone$', '.+_location$']
    hosts_vars_correct = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either",
                          'dummy_host_var': 'dummy', 'dummy_hosts_var': 'dummy', 'dummy_zone_var': 'dummy', 'dummy_location_var': 'dummy'}
    hosts_vars_incorrect = {'qa_1':"I won't show", 'qz_':"I won't show either"}
    host_start

# Generated at 2022-06-11 16:38:59.226318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (['qz_1','qz_2'] == LookupModule().run(['^qz_.+']))

# Generated at 2022-06-11 16:39:07.102681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import __main__
        __main__.__file__ = 'lookup_plugins.py'
        __main__.__package__ = "ansible.plugins.lookup"
    except ImportError:
        pass

    test_terms = ['^test_.+', '.*part2$']
    test_variables = {'test_a': 1, 'test_b': 2, 'not_a_test': 3, 'the_test_part2': 4, 'test_c': 5, 'test_part2': 6}

    lm = LookupModule()
    res = lm.run(test_terms, test_variables)
    assert res == ['test_a', 'test_b', 'test_c', 'test_part2']

# Generated at 2022-06-11 16:39:13.117689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    import re

    LookupModule_obj = LookupModule()
    variable_names = {"test1": 1, "test2": 2}
    terms = ["test[0-9]"]
    with pytest.raises(AnsibleError, match="No variables available to search"):
        result = LookupModule_obj.run(terms, variables=None)

    with pytest.raises(TypeError):
        LookupModule_obj.run(terms, variables=None, **variable_names)
    
    with pytest.raises(AnsibleError, match="Invalid setting identifier"):
        result = LookupModule_obj.run(1, variables=None, **variable_names)


# Generated at 2022-06-11 16:39:20.583461
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a sample group of variables
    variables = {'abc_host': None, 'def_host': None, 'ghi_host': None}

    # Create the lookup object
    look = LookupModule()

    terms = ['^abc_.+']
    assert look.run(terms, variables) == ['abc_host']

    terms = ['.+_host']
    assert look.run(terms, variables) == ['abc_host', 'def_host', 'ghi_host']

    terms = ['^abc_host$', '^def_host$']
    assert look.run(terms, variables) == ['abc_host', 'def_host']

# Generated at 2022-06-11 16:39:26.626855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init class
    lookup = LookupModule()

    # Check that invalid search parameter types raises an Ansible error
    with pytest.raises(AnsibleError):
        lookup.run(terms=['invalid_term'], variables=None)
    with pytest.raises(AnsibleError):
        lookup.run(terms=['invalid_term'], variables={'a_name': 'a_value'})
    with pytest.raises(AnsibleError):
        lookup.run(terms=[2], variables={'a_name': 'a_value'})

    # Check that a regex search parameter that doesn't compile raises an Ansible error
    with pytest.raises(AnsibleError):
        lookup.run(terms=[r'[\d'], variables={'a_name': 'a_value'})



# Generated at 2022-06-11 16:39:30.486557
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {'myvariable': 'myvalue'}

    terms = ['myvar.*']
    lookup_instance = LookupModule()
    result = lookup_instance.run(terms, variables)
    assert 'myvariable' in result, result

# Generated at 2022-06-11 16:39:38.247782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert [] == lookup.run(['^qz_.+'], variables=vars)
    assert [] == lookup.run(['^qz_.+', '^qz.+'], variables=vars)
    assert [] == lookup.run(['^qz_.+', '^qq.+'], variables=vars)

# Generated at 2022-06-11 16:40:44.683219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Choice(object): pass
    variables = {'test1': 1, 'test2': 2, 'test3': {'test3_1': 1}, 'test4': set([1, 2, 3]), 'test5': [1, 2, 3],
                 'test6': Choice()}
    terms = ['.+', '^test[1-9]$']
    expected = ['test1', 'test2', 'test3', 'test4', 'test5', 'test6', 'test1', 'test2', 'test3', 'test4', 'test5', 'test6']
    lookup = LookupModule()
    result = lookup.run(terms, variables=variables)
    assert result == expected


# Generated at 2022-06-11 16:40:55.224460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.errors import AnsibleError

    # Test with no variables provided
    l = LookupModule()
    assert_exception_message(AnsibleError, "No variables available to search", l.run, terms=['a'])

    # Test with non string pattern
    l = LookupModule()
    assert_exception_message(AnsibleError, 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>',
                             l.run, terms=[1], variables={'1': 1})

    # Test with invalid regexp
    l = LookupModule()