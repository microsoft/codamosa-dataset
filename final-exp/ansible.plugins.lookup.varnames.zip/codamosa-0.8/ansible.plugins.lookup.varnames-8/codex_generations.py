

# Generated at 2022-06-11 16:31:05.632474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test the correct variable names are returned when the search term is exact
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    assert lookup.run(terms, variables) == ['qz_1', 'qz_2']

    # Test that variables with a search term in them are returned
    variables = {'hosts': 2, 'hostname': 'testhost', 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['hosts']

# Generated at 2022-06-11 16:31:16.190121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    varnames = lm.run(["^qz_.*"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    assert varnames == ["qz_1", "qz_2"]
    varnames = lm.run(["^qz_.*"], {"qw_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    assert varnames == ["qz_2"]

# Generated at 2022-06-11 16:31:27.226597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()

    # initialize a test variables set
    test_variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qz_3': 'something',
        'qz_4': 'else',
        'qz_zone': 'foo',
        'qz_location': 'bar',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    # initialize test args
    test_terms = ['^qz_.+', '.+_zone$', '.+_location$']

    # method run should return a list with the keys of all of the variables that match the regex pattern

# Generated at 2022-06-11 16:31:38.903897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test run() with no variable set
    with pytest.raises(AnsibleError):
        lookup_module.run(['_term1', '_term2'])

    # Test run() with a variable set
    variables = {'var1': 1, 'var2': 2, 'var3': 3}
    test_results = lookup_module.run(['var1', 'var2'], variables)
    assert test_results == ['var1', 'var2']

    # Test run() with a variable set and a regex
    test_results = lookup_module.run(['var1', 'var2', 'var_'], variables)
    assert test_results == ['var1', 'var2']

    # Test run() with a variable set, a regex and a term that cannot be compiled


# Generated at 2022-06-11 16:31:42.078988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'term1': 1, 'term2': 2}
    terms = ['term1']
    assert lookup_module.run(terms, variables=variables) == ['term1']


# Generated at 2022-06-11 16:31:53.096904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    import unittest
    import sys
    from ansible.module_utils._text import to_bytes

    class UnitTestCase(unittest.TestCase):
        def test_module_params(self):
            ''' Test for method run of class LookupModule with parameters  '''

            # Test for method run of class LookupModule
            # Create instance of the class
            unit_test_obj = LookupModule()
            # Create the mocks needed
            variables = ('variable', 'q')
            terms = ('^q.+',)
            # Call the method run of LookupModule
            result = unit_test_obj.run(terms, variables, **kwargs)
            # Check if the result is correct
            self.assertEqual(result, ['q'])



# Generated at 2022-06-11 16:32:01.714777
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    # Input: {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, terms=['^qz_.+']
    # Expected output: ['qz_1', 'qz_2']
    # Method run of class LookupModule is called
    # Actual output: ['qz_1', 'qz_2']
    # Test passes
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    ret = LookupModule().run(terms, variables=variables, **{})

# Generated at 2022-06-11 16:32:06.948129
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    vm = LookupModule()

    # Test run with empty terms
    with pytest.raises(AnsibleError) as err:
        assert vm.run([])

    # Test run with invalid terms 
    with pytest.raises(AnsibleError) as err:
        assert vm.run([1])

# Generated at 2022-06-11 16:32:17.964077
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_data = {
        "a_var": 1,
        "this_var": 2,
        "another_variable": 3,
        "this_variable_ends_with_var": 4,
    }

    # Create instance of class LookupModule()
    lm = LookupModule()

    # Check return value from method run() with valid input
    assert lm.run([".+_var"], variables=test_data) == ["a_var", "this_var", "this_variable_ends_with_var"], "Unexpected return value"

    # Check return value from method run() with valid input
    assert lm.run([".+_var$"], variables=test_data) == ["this_variable_ends_with_var"], "Unexpected return value"

    # Check return value from method run() with valid input
    assert l

# Generated at 2022-06-11 16:32:24.869688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    terms.append("^var")
    terms.append("^x")
    variables = {'var1': 'var1 value', 'var2': 'var2 value', 'var3': 'var3 value', 'x1': 'x1 value', 'x2': 'x2 value'}
    lookup = LookupModule()
    result = lookup.run(terms, variables)
    assert result == ['var1', 'var2', 'var3', 'x1', 'x2']

# Generated at 2022-06-11 16:32:38.545015
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing with good input
    test_obj = LookupModule()
    test_input = { 'a': 'A', 'b': 'B' }
    result = test_obj.run(('.+',), variables=test_input)
    assert result == ['a', 'b'], \
        'Search for all variable names failed, expected: %s, actual: %s' % (['a', 'b'], result)

    result = test_obj.run(('b',), variables=test_input)
    assert result == ['b'], \
        'Search for all variable names with term "b" failed, expected: %s, actual: %s' % (['b'], result)

    # Testing with bad input
    # 1. No input provided
    test_obj = LookupModule()

# Generated at 2022-06-11 16:32:47.614883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test for method run of class LookupModule
    import os, sys
    fixture_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    sys.path.insert(0, fixture_dir)
    from _test_lookup_plugins import _test_lookup_plugins_run
    sys.path.remove(fixture_dir)

    _test_lookup_plugins_run('varnames', None, None)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-11 16:32:55.480457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    terms = ["^qz_.+"]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    lookupModule = LookupModule()
    # When
    ret = lookupModule.run(terms, variables)
    # Then
    assert ret == ["qz_1", "qz_2"]

# Generated at 2022-06-11 16:33:03.184587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    groups = {
        'test_group_0': {'test_group_0_var': 'test_group_0_value'},
        'test_group_1': {'test_group_1_var': 'test_group_1_value'},
        'test_group_2': {'test_group_2_var': 'test_group_2_value'},
    }

# Generated at 2022-06-11 16:33:12.172424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        ["^qz_.+",".+","hosts",".+_zone$",'.+_location$'],
        {"qz_1": "hello", "qz_2": "world","qa_1": "I won't show","qz_": "I won't show either", "hosts": "localhost"},
    )
    assert ret == ["qz_1","qz_2","qz_","qa_1","hosts","qz_1","qz_2","qz_","qa_1","qz_1","qz_2","qz_","qa_1"], "Bad ret %s" % ret

# Generated at 2022-06-11 16:33:21.224115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    variables = {
        'aaa_1': 'hello',
        'aaa_2': 'world',
        'aaa_3': 3,
        'b_1': 'hello',
        'b_2': 'world',
        'b_3': 3,
        'c': 'hello',
        'd': 'world',
        'e': 3,
        'zone': 'east'
    }
    # Test 1, match all 3 aaa
    ret = lm.run(['^aaa_.+'], variables=variables)
    assert ('aaa_1' in ret and 'aaa_2' in ret and 'aaa_3' in ret)

    # Test 2, match all 3 b and d

# Generated at 2022-06-11 16:33:28.730084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    #
    # Note that this unit test only tests for success in the run() method.
    #
    # If we receive any errors, we just return a fixed True value.
    # If we receive an invalid value, we also return a fixed True value.
    # Otherwise we return a fixed False value.
    #
    # This keeps the unit test from failing entirely if the run() method
    # doesn't succeed.
    #
    # Note that the run() method for LookupModule currently does not raise
    # any exceptions.  We could, however, test for expected exceptions in
    # this unit test.
    lu = LookupModule()

    # Create a dictionary that contains variables

# Generated at 2022-06-11 16:33:38.086283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_instance = LookupModule()

    # Test: empty variables dictionary
    try:
        test_instance.run(terms=['anything'])
        assert False
    except:
        pass

    # Test: terms_list is empty list
    test_varnames = [ 'a', 'b', 'c', 'd' ]
    result = test_instance.run(terms=[], variables={})
    assert result == []

    # Test: terms_list is not empty list
    result = test_instance.run(terms=test_varnames, variables={})
    assert result == []

    # Test: terms_list has valid regex

# Generated at 2022-06-11 16:33:47.834258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    vars = {'var_1': 'test', 'var_2':'test2', 'var_3':'test3', 'var_4':'test4'}
    lookup_plugin = LookupModule()
    terms = ['^var_[1-2]$']
    print("\tinput = {0}, {1}".format(vars, terms))    
    ret = lookup_plugin.run(terms, vars)
    print("\tret = {0}".format(ret))
    terms = ['^var_[3-4]$']
    print("\tinput = {0}, {1}".format(vars, terms))    
    ret = lookup_plugin.run(terms, vars)

# Generated at 2022-06-11 16:33:51.518463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    # Check that invalid input throws an AnsibleError
    with pytest.raises(AnsibleError):
        l.run(terms=['test_var'], variables={'test_var': 'hello world'})
    # Check that non-string input throws an AnsibleError
    with pytest.raises(AnsibleError):
        l.run(terms=['test_var'], variables={'test_var': 'hello world'}, direct={'var_options': {'test_var': 'hello world'}})


# Generated at 2022-06-11 16:34:10.117723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    klass = LookupModule('varnames')
    assert klass.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert klass.run(['.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-11 16:34:20.363326
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:34:27.187189
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test parameters
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Create class instance
    lookup = LookupModule()

    # Retrieve list of matched variable names
    result = lookup.run(terms, variables)

    # Assertion
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:34:36.969179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with no variables
    l = LookupModule()
    assert l
    try:
        l.run(terms=['test'])
    except Exception as e:
        assert e.__class__ == AnsibleError

    # Testing with invalid term
    l = LookupModule()
    assert l
    try:
        l.run(terms=['test'], variables=dict())
    except Exception as e:
        assert e.__class__ == AnsibleError

    # Testing with valid term
    l = LookupModule()
    assert l
    assert l.run(terms=['^test$'], variables=dict(test=None)) == ['test']

    # Testing with valid terms
    l = LookupModule()
    assert l

# Generated at 2022-06-11 16:34:47.474627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = dict()
    terms = [
        '^qz_.+',
        'hosts',
        '.+_zone$',
        '.+_location$'
    ]
    variables = dict(
        qz_1='hello',
        qz_2='world',
        qa_1='I won\'t show',
        qz_='I won\'t show either',
        qz_zone='zone1',
        qz_location='location1',
        qz_zone_location='zone2'
    )

    lm = LookupModule()
    ret = lm.run(terms, variables)
    print(ret)
    assert ret == ['qz_1', 'qz_2', 'qz_zone', 'qz_location', 'qz_zone_location', 'hosts']

# Generated at 2022-06-11 16:34:47.880643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-11 16:34:51.536964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    try:
        l.run(["abc"], None)
    except AnsibleError as e:
        assert(str(e) == 'No variables available to search')
    else:
        raise Exception("AnsibleError not raised")


# Generated at 2022-06-11 16:35:00.882123
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class_method = LookupModule.run
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options= {'a': 'b', 'c': 'd', 'e': 'f'}, direct= {})

    # test invalid terms
    lookup_obj.run(terms=[1], variables=None)
    assert (False) # fails as expected
    lookup_obj.run(terms=[1], variables=None, **{"fail_on_undefined_errors": True})
    assert (False) # fails as expected

    # test invalid variables
    lookup_obj.run(terms=['a'], variables=None)
    assert (False) # fails as expected
    lookup_obj.run(terms=['a'], variables=None, **{"fail_on_undefined_errors": True})

# Generated at 2022-06-11 16:35:01.543039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:35:11.147859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule
    test_variables = {'a':1, 'b':2, 'ba':3, 'baa':4}

    # Run with incorrect type for terms
    try:
        test_obj.run(test_obj, [2], variables=test_variables)
        error_message = "The provided terms should be of type string"
        raise AssertionError(error_message)
    except AnsibleError:
        pass

    # Run with correct type for terms but incorrect value for variables
    try:
        test_obj.run(test_obj, ['a'])
        error_message = "The provided variables should not be None."
        raise AssertionError(error_message)
    except AnsibleError:
        pass

    # Run with no matching terms
    terms = ['c']
    expected

# Generated at 2022-06-11 16:35:25.550736
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:35:31.472763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inp_vars = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    lk = LookupModule()
    res = lk.run(["^qz_.+"], variables=inp_vars)
    assert res == ["qz_1", "qz_2"]

# Generated at 2022-06-11 16:35:37.251839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import reload_module
    from ansible.utils.display import Display
    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    old_display = Display()
    lk_module = sys.modules[__name__]
    reload_module(lk_module)
    lookup_mdl = LookupModule()


# Generated at 2022-06-11 16:35:48.747986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()

    # test case 1
    def test_case_1():
        terms = ['']
        variables = {'host_1': '1.1.1.1', 'host_2': '2.2.2.2'}
        expected = []
        result = lookup_mock.run(terms, variables)
        assert result == expected

    # test case 2
    def test_case_2():
        terms = ['^\w+_1$']
        variables = {'host_1': '1.1.1.1', 'host_2': '2.2.2.2'}
        expected = ['host_1']
        result = lookup_mock.run(terms, variables)
        assert result == expected

    test_case_1()
    test_case_2

# Generated at 2022-06-11 16:35:59.881433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarModule:
        def __init__(self, name=None, value=None):
            self.name = name
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

        def __ne__(self, other):
            return self.value != other.value

    data = [
        VarModule(name='a', value=1),
        VarModule(name='b', value=2),
        VarModule(name='c', value=3),
    ]

    class JsonParser:
        def __init__(self, data=None):
            self.data = data

        def __iter__(self):
            return iter(self.data)


# Generated at 2022-06-11 16:36:11.185152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = [r'^qz_.+', r'.+', r'hosts', r'.+_zone$', r'.+_location$']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show",
                 'qz_': "I won't show either", 'hosts': ['192.168.1.10', '192.169.1.11'],
                 'region_zone': 'us-east-1a', 'region_location': 'us-east-1',
                 'nam1': 'value1', 'nam2': 'value2'}
    ret = lookup_obj.run(terms, variables)
    assert 'qz_1' in ret
    assert 'qz_2' in ret


# Generated at 2022-06-11 16:36:19.258560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result_1 = lookup_module.run("^qz_.+", variables={'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"})
    result_2 = lookup_module.run(('qz_1','qz_2','qa_1','qz_'), variables={'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"})
    # references to these variables for debugging purposes
    #print(result_1)
    #print(result_2)
    assert result_1 == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:36:26.863815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assemble
    terms = ['qz_', '.+', 'hosts']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': '127.0.0.1',
        'ansible_hosts': '127.0.0.1',
    }

    # Exercise
    lu = LookupModule()
    ret = lu.run(terms, variables)

    # Verify
    assert ret == ['qz_1', 'qz_2', 'hosts', 'ansible_hosts']


# Generated at 2022-06-11 16:36:27.462382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 16:36:37.861394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Replace the run method
    original_run = LookupModule.run
    lookup = LookupModule()
    lookup.set_options = lambda var_options=None, direct=None: 0
    def run_test(terms, variables=None, **kwargs):
        # Redefine the run method
        def run(self, terms, variables=None, **kwargs):
            # Call the original run
            return original_run(self, terms, variables, **kwargs)
        # Make the new run available for the unit tests
        LookupModule.run = run
        # Run the tests
        return run(lookup, terms, variables, **kwargs)

    with pytest.raises(AnsibleError) as e:
        run_test(['abc', 123], {'abc': 'foo'})

# Generated at 2022-06-11 16:37:08.050839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.yaml.objects
    from ansible.plugins.loader import lookup_loader
    import collections
    import copy

    lookup_module = lookup_loader.get("varnames", class_only=True)
    lookup_instance = lookup_module()
    raw = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    terms = ['^qz_', '^qa_']

# Generated at 2022-06-11 16:37:15.761624
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    Plugin = LookupModule()
    terms = ['^qz_.+', 'hosts']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'h_osts': 'hello',
        'hosts': 'world',
    }
    expected = ['qz_1', 'qz_2', 'h_osts', 'hosts']

    # Execute
    result = Plugin.run(terms, variables=variables)

    # Verify
    assert set(result) == set(expected)

# Generated at 2022-06-11 16:37:26.033079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    self = LookupModule()

    # Test with no variables
    try:
        self.run(terms=['qz_.+'])
        assert False
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with variable that are not strings
    try:
        self.run(terms=['qz_.+'], variables={'my_var': 1234})
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "qz_.+" is not a string, it is a <class \'str\'>'

    # Test with a bad regular expression

# Generated at 2022-06-11 16:37:35.215249
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test using no variables to search
    l = LookupModule()
    l._options = {'direct': {}}
    l._templar = None
    vars = None
    terms = ['hosts']
    try:
        l.run(terms, vars)
    except AnsibleError as e:
        assert(e.message == 'No variables available to search')

    # Test using an invalid variable name
    bad_terms = ['.']
    l = LookupModule()
    l._options = {'direct': {}}
    l._templar = None
    vars = {'hosts': 'localhost', 'a': True}

# Generated at 2022-06-11 16:37:40.659774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    data = ['test', 'anothertest']
    test = LookupModule()
    test.set_options(var_options={
        'test': 'test',
        'anothertest': 'anothertest',
        'badtest': 'badtest'
    })
    # Run
    ret = test.run(data)
    # Test
    assert ['test', 'anothertest'] == ret

# Generated at 2022-06-11 16:37:46.762429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test vars
    variables = {
        "var1": "example1",
        "var2": "example2",
        "var3": "example3",
    }
    terms = ["var"]
    # Set up lookup module
    lookup = LookupModule()
    # Run test, expect to get list of variables that match term "var"
    assert lookup.run(terms, variables=variables) == ["var1", "var2", "var3"]


# Generated at 2022-06-11 16:37:53.016917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vm = LookupModule()
    terms = ['^qz_.+']
    variable = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    ret = vm.run(terms, variable)
    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:37:58.529523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    assert lookup.run(terms, variables) == ["qz_1", "qz_2"]

# Generated at 2022-06-11 16:38:08.690270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_variables = {
        "a_variable": "a_value",
        "other_var": "123",
        "something_var": "some_text",
        "somenumber": 123,
        "some_list": [1, 2, 3],
        "some_dict": {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        },
        "a_different_variable": "a_different_value",
        "another_one": "another_one_value"
    }

    test_case_data = {
        "a_variable": "a_value",
        "a_different_variable": "a_different_value",
        "another_one": "another_one_value"
    }

    assert test_case_

# Generated at 2022-06-11 16:38:17.731929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-argument
    def _lookup_vars(string, variables, **kwargs):
        """
        This function should be able to be replaced by a call to self.lookup('vars', string, variables=variables, **kwargs)
        """
        try:
            name = re.compile(string)
        except Exception:
            raise AnsibleError('Unable to use "%s" as a search parameter' % string)
        ret = []
        for varname in variables:
            if name.search(varname):
                ret.append(varname)
        return ret

    

# Generated at 2022-06-11 16:39:05.547051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable_names_test = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'foobar': "I won't show",
        'something_else': "I won't show",
        'another_item': 'blah',
        'hosts.ini': 'hosts.ini',
        'hosts': 'hosts',
        'a_zone': 'a_zone',
        'a_location': 'a_location',
        'a_zone_location': 'a_zone_location',
        'b_location_zone': 'b_location_zone',
    }

    lookup_module = LookupModule()

# Generated at 2022-06-11 16:39:12.104886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test_LookupModule_run"""
    # Create an instance of LookupModule class
    lookup_instance = LookupModule()
    # pylint: disable=unused-variable
    # Define variables
    qz_1 = 'hello'
    qz_2 = 'world'
    qa_1 = "I won't show"
    qz_ = "I won't show either"
    # pylint: enable=unused-variable
    # Include variables in the local variable
    variables = locals()
    # Run the method run of class LookupModule
    ret = lookup_instance.run('^qz_.+', variables)
    # Assert that the returned value is list
    assert(isinstance(ret, list))
    # Assert that the returned value is the expected one

# Generated at 2022-06-11 16:39:17.373122
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    look = LookupModule()
    try:
        look.run(terms=None)
    except AnsibleError as error:
        assert error.args[0] == 'No variables available to search'

    variables = {}
    try:
        look.run(terms=None, variables=variables)
    except AnsibleError as error:
        assert error.args[0] == 'No variables available to search'

    variables = {'a': 1, 'a_b': 2, 'b': 3, 'a_c': 4}

    assert look.run(terms=['a'], variables=variables) == ['a']
    assert look.run(terms=['^a_'], variables=variables) == ['a_b', 'a_c']

# Generated at 2022-06-11 16:39:25.015962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get("varnames", loader=None, templar=None, shared_loader_obj=None)
    assert lookup.run(terms=['^qz_.*'], variables={'qz_1': 'hello', 'qz_2': 'world'}) == ['qz_1', 'qz_2']
    assert lookup.run(terms=['^qa_.*'], variables={'qz_1': 'hello', 'qz_2': 'world'}) == []
    assert lookup.run(terms=['^.*'], variables={'qz_1': 'hello', 'qz_2': 'world'}) == ['qz_1', 'qz_2']


# Generated at 2022-06-11 16:39:35.999370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.plugins.lookup import varnames as v
    # 1st call to set_options - to set variables
    v.LookupModule().run(['.+_zone$'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    # 2nd call - to set params
    v.LookupModule().run(['.+_zone$'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-11 16:39:45.829349
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()
    assert lookup_plugin.run(["unittest_flags"], variables={'unittest_flags': 'flags'}, **{}) == ['unittest_flags']
    assert lookup_plugin.run(["^unittest_flags"], variables={'unittest_flags': 'flags'}, **{}) == ['unittest_flags']
    assert lookup_plugin.run(["^unittest_flags_1$"], variables={'unittest_flags_1': 'flags', 'unittest_flags': 'flags'}, **{}) == ['unittest_flags_1']

# Generated at 2022-06-11 16:39:57.158830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a dummy variable
    variable = {
        'ping_result': {
            'changed': False,
            'ping': 'pong'
        },
        'foo': 'bar'
    }

    # create an instance of the LookupModule class
    lookup = LookupModule()

    # define the variable that are required by lookup plugin
    lookup.set_options(var_options=variable, direct={})

    # search for 'ping_result' variable
    result = lookup.run(terms=['ping_result'])

    # we get it
    assert result == ['ping_result']

    # search for 'bar' variable
    result = lookup.run(terms=['bar'])

    # we don't get it
    assert result == []

    # search for '.*' variable

# Generated at 2022-06-11 16:40:05.556798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  s = '''
- name: List variables that start with qz_
  debug: msg="{{ lookup('varnames', '^qz_.+')}}"
  vars:
    qz_1: hello
    qz_2: world
    qa_1: "I won't show"
    qz_: "I won't show either"

- name: Show all variables
  debug: msg="{{ lookup('varnames', '.+')}}"

- name: Show variables with 'hosts' in their names
  debug: msg="{{ lookup('varnames', 'hosts')}}"

- name: Find several related variables that end specific way
  debug: msg="{{ lookup('varnames', '.+_zone$', '.+_location$') }}"
  '''
  print(s)

# Generated at 2022-06-11 16:40:15.902456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test missing mandatory parameter variables
    with pytest.raises(AnsibleError) as ex:
        LookupModule().run(terms=['.+'])
    assert 'No variables available to search' in str(ex.value)

    # Test passing non-string types to terms
    with pytest.raises(AnsibleError) as ex:
        LookupModule().run(['abc'], variables={'abc': 'def'})
    assert 'Invalid setting identifier' in str(ex.value)

    # Test passing non-existent variables
    assert LookupModule().run(terms=['.+'], variables={}) == []

    # Test passing variables

# Generated at 2022-06-11 16:40:23.232894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    unit test for method run of class LookupModule
    We have to "lookup" a variable in order to actually have access to variables
    """
    terms = ['^qz_.+']
    variables = dict(qz_1='hello', qz_2='world', qa_1='I won\'t show', qz_='I won\'t show either')
    expected_ret = ['qz_1', 'qz_2']
    lm = LookupModule()
    ret = lm.run(terms, variables)
    assert(ret == expected_ret)