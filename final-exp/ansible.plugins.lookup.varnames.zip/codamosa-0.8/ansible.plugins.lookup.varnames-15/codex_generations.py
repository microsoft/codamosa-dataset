

# Generated at 2022-06-11 16:31:04.927859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Testing a simple search with one variable set
    term = ['^qz_.+']
    variable_names = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    t_obj = LookupModule()
    exp_result = ['qz_1', 'qz_2']
    result = t_obj.run(term, variables=variable_names)
    assert exp_result == result
    
    #Testing a simple search with all variables set
    term = ['.+']
    variable_names = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    t_obj = Look

# Generated at 2022-06-11 16:31:15.786159
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # One pattern
    module = LookupModule()
    assert module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world',
                                   'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']

    # One pattern, no variables
    module = LookupModule()
    assert module.run(['^qz_.+'], {}) == []

    # Multiple patterns, one argument
    module = LookupModule()

# Generated at 2022-06-11 16:31:24.891288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    ansible_var = {}
    ansible_var['list_var1'] = 'list var1'
    ansible_var['list_var2'] = 'list var2'
    terms = ['.+_var1$', '.+_var2$']

    # Act
    test_lookup = LookupModule()
    test_run = test_lookup.run(terms, variables=ansible_var)

    # Assert
    assert len(test_run) == 2
    assert test_run[0] == 'list_var1'
    assert test_run[1] == 'list_var2'


# Generated at 2022-06-11 16:31:31.771144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test function for LookupModule run method"""
    run = LookupModule()
    terms = ['^qz_.+', '.+_zone$', '.+_location$']
    vars = {'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': 'I wont show',
            'qz_' : 'I wont show either',
            'foo_zone' : 'bar',
            'bar_zone' : 'baz',
            'baz_location' : 'qux',
            'qux_location' : 'quux',
            'quux_location' : 'quuz',
            'quuz_location' : 'corge'
    }
    actual = run.run(terms, variables=vars)

# Generated at 2022-06-11 16:31:42.948603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test successful term execution
    assert LookupModule().run(
        [
            '^qz_.+'
        ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either"
        }
    ) == ['qz_1', 'qz_2']

    # test term that matches all variables
    assert len(LookupModule().run(
        [
            '.+'
        ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either"
        }
    )) == 4

    assert Lookup

# Generated at 2022-06-11 16:31:51.216604
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        '^qz_.+',
        '.+_zone$',
        '.+_location$'
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': "I'll show too"
    }

    result = LookupModule().run(terms=terms, variables=variables)
    assert result == ['qz_1', 'qz_2', 'hosts']

# Generated at 2022-06-11 16:32:00.587984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['qz_', '^qz_.+', '.+', 'hosts', '.+_zone$']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'qz_zone':'show', 'qz_location':'show'}

# Generated at 2022-06-11 16:32:10.593024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test Case 01
    lookup_test_01 = lookup.run(
        terms=[
            '^qz_.+',
        ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
            'z_': "I won't show either",
            'qz_3': "I won't show either",
        },
    )

    assert lookup_test_01 == [
        'qz_1',
        'qz_2',
        'qz_3',
    ]

    # Test Case 02

# Generated at 2022-06-11 16:32:22.336355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["^qz_.+"], {"qz_1": "hello",
                                           "qz_2": "world",
                                           "qa_1": "I won't show",
                                           "qz_": "I won't show either"}) == ['qz_1', 'qz_2']
    assert LookupModule().run([".+"], {"key": "value"}) == ['key']
    assert LookupModule().run(["hosts"], {"this_host": "localhost",
                                          "other_host": "127.0.0.1"}) == ['this_host', 'other_host']

# Generated at 2022-06-11 16:32:32.893715
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a simple variable for testing
    my_greeting = 'Hello World!'

    # Create the LookupModule instance
    my_lookup = LookupModule()

    # Set up the 'variables' dictionary
    my_lookup.set_options(var_options={'my_greeting': my_greeting}, direct=None)

    # Call the module with a simple test of 'Hello'
    # This should return a list containing 'my_greeting'
    assert my_lookup.run(['Hello']) == ['my_greeting']

    # Call the module with a simple test of '.*'
    # This should return a list containing 'my_greeting'
    assert my_lookup.run(['Hello']) == ['my_greeting']

    # Call the module with a simple test of '

# Generated at 2022-06-11 16:32:49.170381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    class FakeSetOptions(object):
        def __init__(self, result):
            self.result = result
        def set_options(self, *args, **kwargs):
            return self.result

    class FakeVariables(dict):
        def get(self, key):
            return self.get(key)
        def __getitem__(self, key):
            return self.get(key)

    vars = FakeVariables()
    vars.get = lambda key: None

    # Test that module fails with invalid terms
    with pytest.raises(AnsibleError) as exc:
        module.run(None, None, _set_options=FakeSetOptions((None, None, None)))
    assert str(exc.value) == 'No variables available to search'

    # Test that module

# Generated at 2022-06-11 16:33:00.442250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize object
    lookup_module = LookupModule()

    # Test error when variables are not defined
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert(e.message == 'No variables available to search')

    # Test error when term is not string
    try:
        lookup_module.run(terms=[1], variables={'test':'some value'})
    except AnsibleError as e:
        assert(e.message == 'Invalid setting identifier, "1" is not a string, it is a <type \'int\'>')

    # Test error when regular expression cannot be compiled

# Generated at 2022-06-11 16:33:11.093787
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:33:19.011406
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    #Test option error handling
    try:
        lookup.run(['foo'])
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError not raised'

    assert lookup.run(['foo'], {'foo': 'bar'}) == ['foo']

    assert lookup.run(['foo'], {'bar': 'foo'}) == []

    try:
        lookup.run(['['], {'foo': 'bar'})
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError not raised'

    assert lookup.run(['f.+'], {'foo': 'bar'}) == ['foo']
    assert lookup.run(['b.+'], {'foo': 'bar'}) == []

    assert lookup

# Generated at 2022-06-11 16:33:27.685695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import six
    import mock
    import os

    # create mock objects
    terms = ['term1', 'term2']
    regex = mock.Mock()
    variables = {
        'term1': 'variable1',
        'term2': 'variable2'
    }

    # create mock module
    mock_module = mock.Mock()
    mock_module.run_command_environ_update = {
        'LANG': 'C',
        'LC_ALL': 'C',
        'LC_MESSAGES': 'C',
        'ANSIBLE_LOOKUP_VARNAME': __name__,
        'ANSIBLE_LOOKUP_PLUGIN_CONNECTION': '_'
    }

# Generated at 2022-06-11 16:33:37.573191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockLookupBase(LookupBase):
        def get_basedir(self, variables):
            return '$ANSIBLE_CONFIG_DIR'  # try to be compatible with other test cases

        def get_vars(self, loader, path, entities, cache=True):
            if entities is None:
                return variables
            return [variables.get(x) for x in entities]

    def varnames(terms, variables, **kwargs):
        return LookupModule(loader=None, basedir=None, **kwargs).run(terms, variables, **kwargs)


# Generated at 2022-06-11 16:33:47.645377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test that the regexes handle '^' correctly
    # regex should match variables starting with 'q'
    found = LookupModule().run(['^q.+'], dict(q1=1, q2=2, a1=3, a2=4))
    assert len(found) == 2
    assert 'q1' in found
    assert 'q2' in found

    # regex should match variables starting with 'qz_'
    found = LookupModule().run(['^qz_.+'], dict(qz_1=1, qz_2=2, a1=3, a2=4))
    assert len(found) == 2
    assert 'qz_1' in found
    assert 'qz_2' in found

    # test that the regexes handle '$' correctly
    found = LookupModule

# Generated at 2022-06-11 16:33:59.625365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+','.+_zone$', '.+_location$']
    variables = {
        'qz_1':'hello',
        'qz_2':'world',
        'qa_1':'I wont show',
        'qz_':'I wont show either',
        'a_zone': 'Value',
        'a_location': 'Value',
        'a_location_zone': 'Value', # Should not appear
        'zone': 'Value',
        'location': 'Value',
        'location_zone': 'Value' # Should not appear
    }
    lookup_module = LookupModule()
    result = lookup_module.run(terms,variables)
    assert result == ['qz_1', 'qz_2', 'a_zone', 'a_location']

# Generated at 2022-06-11 16:34:06.210426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Call the run method to return list of variables matching given regex
    test_result = LookupModule().run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    # Check wether test result has the correct variable names
    assert 'qz_1' in test_result
    assert 'qz_2' in test_result
    assert 'qa_1' not in test_result
    assert 'qz_' not in test_result


# Generated at 2022-06-11 16:34:13.761509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test 0: No such variable
    variables = {'a': 'test'}
    terms = ['not_existing']
    result = module.run(terms, variables)
    assert result == []

    # Test 1: One match
    terms = ['a.+']
    result = module.run(terms, variables)
    assert result == ['a']

    # Test 2: Multiple matches
    variables['aa'] = 'more test'
    variables['ab'] = 'yet more test'
    result = module.run(terms, variables)
    assert result == ['a', 'aa', 'ab']

    # Test 3: Search by substrings
    terms = ['a']
    result = module.run(terms, variables)
    assert result == ['a', 'aa', 'ab']

    # Test 4: Multiple

# Generated at 2022-06-11 16:34:28.426877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_list = {"test_var_1":"test_val",
                "test_var_2":"test_val",
                "test_var_3":"test_val"}
    string_pattern = "test_var_1"
    regex_pattern = "test_var_2"
    invalid_pattern = "[]"
    # Testing with string pattern
    assert LookupModule(None, None).run([string_pattern],var_list)==["test_var_1"]
    # Testing with Regex pattern
    assert LookupModule(None, None).run([regex_pattern],var_list)==["test_var_2"]
    # Testing with invalid pattern
    try:
        LookupModule(None, None).run([invalid_pattern],var_list)
    except AnsibleError as e:
        assert "Invalid setting identifier"

# Generated at 2022-06-11 16:34:30.044360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add unit test for method run of class LookupModule
    pass


# Generated at 2022-06-11 16:34:38.623036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock up the set_options method of LookupModule
    class mock_LookupModule(LookupModule):
        def set_options(self, var_options=None, direct=None):
            self.options = var_options

    lookup = mock_LookupModule()
    lookup.set_options({'hosts': 1, 'hosts_file': 2})
    assert lookup.run('hosts') == ['hosts', 'hosts_file']
    assert lookup.run('hosts$') == ['hosts']
    assert lookup.run('(hosts|hosts_file)') == ['hosts', 'hosts_file']
    assert lookup.run('^hosts$') == []
    assert lookup.run('(some|whatever)') == []

# Generated at 2022-06-11 16:34:47.962121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '.+']
    variables = \
        {
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': 'I won\'t show',
            'qz_': 'I won\'t show either'
        }
    expected = [
            'qz_1',
            'qz_2',
            'qa_1',
            'qz_',
            'qz_1',
            'qz_2',
            'qa_1',
            'qz_'
        ]

    lu = LookupModule()
    actual = lu.run(terms, variables)

    assert actual == expected

# Generated at 2022-06-11 16:34:58.385152
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:35:01.343576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([".+_zone$", ".+_location$"], {"zone1_location": "location", "location2_zone": "zone", "zone3_location": "location"}) == ['location2_zone', 'zone3_location']

# Generated at 2022-06-11 16:35:11.052478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeVars:
        def __init__(self):
            self.HAVANA = 'HAVANA'
            self.HORROR = 'HORROR'
            self.HUNDRED = 'HUNDRED'
            self.HISTORY = 'HISTORY'

    lookup = LookupModule()
    # search for a pattern
    terms = ['^H.*$']
    variables = FakeVars
    assert lookup.run(terms, variables=variables) == ['HAVANA', 'HORROR', 'HUNDRED', 'HISTORY']
    # search for another pattern
    terms = ['^H[A-Z]{3}$']
    assert lookup.run(terms, variables=variables) == ['HAVANA']
    # search for a pattern with an error
    terms = ['"^H.*$']

# Generated at 2022-06-11 16:35:16.446763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(terms=['qz_.+', 'qa_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})
    print(result)
    assert result == ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-11 16:35:21.846196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    params = {'_terms': ['test_variable']}
    variables = {'test_variable': 'bogus_value'}
    assert lookup.run(terms=['test_variable'], variables=variables) == ['test_variable']
    assert lookup.run(**params, variables=variables) == ['test_variable']

# Generated at 2022-06-11 16:35:32.293654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.utils.display import Display
    display = Display()

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.current_display = display.verbosity
            display.verbosity = 0

        def tearDown(self):
            display.verbosity = self.current_display
        # ---------------------------------------------------------------------------------------------------

        def test_run_with_invalid_terms_should_raise_AnsibleError(self):
            lookup_module = LookupModule()

            with self.assertRaises(AnsibleError) as context:
                lookup_module.run(terms=None, variables={})


# Generated at 2022-06-11 16:35:47.463193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:35:54.696639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple test with variable_names
    variable_names = ['v1', 'v2', 'v3', 'v4', 'v5', 'v6']
    # Search for v4 and v5
    for varname in ('v4', 'v5'):
        # Search for v4 and v5 in the list of variable_names
        for name in (loo.run('v4', variable_names), loo.run('v5', variable_names)):
            assert name == varname

# Generated at 2022-06-11 16:35:57.671685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.run(terms=['^a.+'], variables={'a_var': 'xyz', 'b_var': 'xyz'})


# Generated at 2022-06-11 16:36:07.817251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This unit test tests the method run of class LookupModule
    """
    lookup_module = LookupModule()
    terms = ['qz_1', 'qz_2']
    variables = {'qz_1': 'hello', 'qz_2': 'world'}
    expect_res = ['qz_1', 'qz_2']
    test_res = lookup_module.run(terms, variables)
    assert test_res == expect_res
    terms = ['^qz_.+']
    expect_res = ['qz_1', 'qz_2']
    test_res = lookup_module.run(terms, variables)
    assert test_res == expect_res
    terms = ['.+']
    expect_res = ['qz_1', 'qz_2']
    test_res

# Generated at 2022-06-11 16:36:08.733178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:36:16.190182
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()
    terms = ['^qz_.+', 'hosts']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I will not show', 'qz_': 'I will not show either', 'hosts': '127.0.0.1'}
    ret = lookup_instance.run(terms, variables)
    assert 'qz_1' in ret
    assert 'qz_2' in ret
    assert 'qa_1' not in ret
    assert 'qz_' not in ret
    assert 'hosts' in ret

# Generated at 2022-06-11 16:36:26.003364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    lookup = LookupModule()
    vars = {"v1": "ok", "v2": "nok"}
    result = lookup.run(terms=["v1"], variables=vars)
    assert result == ["v1"]
    result = lookup.run(terms=["v1", "^v.+"], variables=vars)
    assert result == ["v1", "v2"]
    try:
        result = lookup.run(terms=[1], variables=vars)
        assert "error"
    except AnsibleError as e:
        assert str(e) == "Invalid setting identifier, \"1\" is not a string, it is a <class 'int'>"

# Generated at 2022-06-11 16:36:35.095420
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    terms1 = ['aaa', 'bbb']
    variables1 = {'aaa': 1, 'bbb': 3}
    ret1 = module.run(terms1, variables1)
    assert ret1 == [u'aaa', u'bbb']

    terms2 = ['a', '^b.+', 'c.', 'd+']
    variables2 = {'aaa': 1, 'bbb': 3, 'ccc': 5, 'dd': 7}
    ret2 = module.run(terms2, variables2)
    assert ret2 == [u'aaa', u'bbb', u'ccc', u'dd']


# Generated at 2022-06-11 16:36:40.026010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = LookupModule()
    result = looker.run(['qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show'})
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:36:50.541131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.parsing.vault as vault
    import ansible.vars.manager as var_manager
    from ansible.template import Templar
    # setup
    L = plugin_loader.LookupModuleLoader()
    lookup = L.get("varnames")
    variables = {'lookup_test': 'lookup_test_value'}
    templar_obj = Templar(loader=None, variables=variables, vault_secrets=None)
    templar_obj.set_available_variables(variables)
    lookup.set_options(direct={'_templar': templar_obj})
    # create test cases

# Generated at 2022-06-11 16:37:31.841579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class options: pass
    lookup = LookupModule(None, options)

    variables = dict(
        cisco_router01='{"ip": "192.0.2.1", "serialNumber": "1234", "vendor": "Cisco"}',
        cisco_router02='{"ip": "192.0.2.2", "serialNumber": "5678", "vendor": "Cisco"}',
        apc_ups01='{"ip": "192.0.2.3", "serialNumber": "9876", "vendor": "APC"}',
        apc_ups02='{"ip": "192.0.2.4", "serialNumber": "5432", "vendor": "APC"}'
    )

    lookup.set_options(var_options=variables, direct=dict())

    assert lookup

# Generated at 2022-06-11 16:37:36.131165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # module_utils.basic.py: AnsibleModule, __init__, exit_json, fail_json
    # module_utils._text.py: to_native, to_text
    # lookup_plugins.py: LookupBase, __init__
    # The functionality of this method is tested in test_varnames.py
    raise NotImplementedError

# Generated at 2022-06-11 16:37:46.227677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for single search parameter
    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    test_lookup_obj = TestLookupModule()
    variables = {
        'test_re_pattern': 'I am part of test',
        'test_no_pattern': 'I am not part of test',
        'test_re_pattern2': 'I am part of test'
    }
    terms = 'test_re_pattern'
    result = test_lookup_obj.run(terms, variables)
    assert result == ['test_re_pattern', 'test_re_pattern2']

    # Test for multiple search patterns

# Generated at 2022-06-11 16:37:57.262659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_arr_values = ["hello", "world"]
    test_dict_values = {"hello": "world"}
    test_value = "hello"
    test_value2 = "world"
    test_value3 = 12345
    test_value4 = 1.2345
    test_value5 = False
    test_value6 = True
    test_value7 = None

    # Test: No result returned
    variables = {'var_1': test_value, 'var_2': test_value2, 'var_3': test_value3, 'var_4': test_value4, 'var_5': test_value5}
    result = lookup_module.run(["^var_10"], variables)
    assert len(result) == 0
    assert result == []


# Generated at 2022-06-11 16:38:06.693249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This unit test is not very good,
    # But I am just trying to show an example of how to test the LookupModule.
    # In this test, we have no variables and we are looking for a variable with a name
    # of 'a'
    lookup_module = LookupModule()

    # This is the name of the variable we want to find
    var_name = 'a'
    # This is the name of the variable we will fail to find
    fail_var_name = 'b'
    # This is our variable that we are going to use to try to find the variable
    # named 'a'.
    variable = {var_name:'test'}

    # First we run the lookup, with no variables. This will fail.

# Generated at 2022-06-11 16:38:16.544714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup.
    #
    # Regex patterns
    regex1 = '^ab.+'
    regex2 = 'foo'

    # Variables
    variable_names = {
        'abc': '',
        'abcd': '',
        'foo': '',
        'foobar': '',
        'baz': '',
        'other': '',
    }

    # Expected result
    expected_result = [
        'abc',
        'abcd',
        'foo',
        'foobar',
    ]

    # Object under test
    lookup_module = LookupModule()

    # Code under test
    result = lookup_module.run(
        terms=[regex1, regex2],
        variables=variable_names,
        **{}
    )

    # Test assertion
    assert result

# Generated at 2022-06-11 16:38:28.558375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # To generate correct structure of parameters and assign values
    terms = ['qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected = ['qz_1', 'qz_2']
    assert LookupModule().run(terms, variables) == expected

    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert LookupModule().run(terms, variables) == expected


# Generated at 2022-06-11 16:38:37.442763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [
        '^qz_.+',
        '.+_zone$',
        '.+_location$',
        '^.+_location$'
    ]

    test_variables = [
        'qz_1',
        'qz_2',
        'qa_1',
        'qz_',
        'qz_zone',
        'qz_location',
        'qz_zone_location',
    ]

    expected = [
        ['qz_1', 'qz_2'],
        ['qz_zone_location'],
        ['qz_zone_location'],
        ['qz_zone_location']
    ]

    test_obj = LookupModule()

    variables = {}
    test_variables.append('test')

# Generated at 2022-06-11 16:38:47.721211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-11 16:38:58.001118
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()

    test_vars = dict(
        qz_1='hello',
        qz_2='world',
        qa_1="I won't show",
        qz_="I won't show either",
        qz_zone='Seattle',
        qz_location='123 main st'
    )

    # Use of single string as search term
    terms = '^qz_.+'
    ret = lookup_plugin.run(terms, test_vars)
    assert(len(ret) == 3)
    assert('qz_1' in ret)
    assert('qz_2' in ret)
    assert('qz_' in ret)

    # Use of list as search terms
    terms = ['^qz_.+', '^qa_.+']
    ret = lookup_

# Generated at 2022-06-11 16:40:15.600460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+', 'hosts', '.+zone$'] # list of Python regex patterns
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'hosts': '127.0.0.1'} # dictionary
    ret = lookup.run(terms, variables)

    assert ret == ['qz_1', 'qz_2', 'hosts']

# Generated at 2022-06-11 16:40:25.522139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestClass(object):
        def __init__(self):
            self.result = None

    test = TestClass()

    # Success case
    terms = ['^qz_.+']
    variables = {
        'qz_1': 1,
        'qz_2': 2,
        'qa_1': 3,
        'qz_': 4
    }
    lookup_mock = LookupModule(run_once=True, loader=None, templar=None)
    test.result = lookup_mock.run(terms, variables)
    assert(test.result == ['qz_1', 'qz_2'])

    # List is empty
    terms = ['^qz_.+']
    variables = {}

# Generated at 2022-06-11 16:40:35.397543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = { 'foo': 1, 'bar': 2, 'baz': 3 }

    # No terms
    assert lookup.run(terms=[], variables=variables) == []

    # No matches
    assert lookup.run(terms=['nomatch'], variables=variables) == []

    # Regex
    assert lookup.run(terms=['a.+'], variables=variables) == ['bar', 'baz']

    # Non-regex
    assert lookup.run(terms=['foo', 'bar', 'baz'], variables=variables) == ['foo', 'bar', 'baz']

    # Multiple patterns
    assert lookup.run(terms=['a.+', 'ba.+'], variables=variables) == ['bar', 'baz', 'baz']

    # Invalid


# Generated at 2022-06-11 16:40:45.751505
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1
    term = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world'}
    lookup = LookupModule()
    variables = lookup.run(term, variables)
    assert variables == ['qz_1', 'qz_2']

    # test case 2
    term = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world'}
    lookup = LookupModule()
    variables = lookup.run(term, variables)
    assert variables == ['qz_1', 'qz_2']

    # test case 3
    term = ['hosts']
    variables = {'qz_1': 'hello', 'qz_2': 'world'}
    lookup = LookupModule()


# Generated at 2022-06-11 16:40:56.129363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    variables = {}

    # No variables
    terms = [
        '^qz_.+',
        '.+_zone$',
    ]

    try:
        module.run(terms, variables=variables)
        assert False, "Expected run to fail without variables"
    except AnsibleError:
        pass

    # Some variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
    }

    terms = [
        '^qz_.+',
        '.+_zone$',
    ]

    assert module.run(terms, variables=variables) == ['qz_1', 'qz_2']