

# Generated at 2022-06-11 16:31:05.632938
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    test_module = LookupModule()
    terms = ['^test_one', '^test_two']
    variables = {'test_one': 'one', 'test_two': 'two'}

    ret = test_module.run(terms=terms, variables=variables)
    assert ret == ['test_one', 'test_two']

    # Bad term - not string
    with pytest.raises(AnsibleError):
        ret = test_module.run(terms=[1,2], variables=variables)

    # No variables
    with pytest.raises(AnsibleError):
        ret = test_module.run(terms=terms, variables=None)

# Generated at 2022-06-11 16:31:11.458544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lm = LookupModule()
   lm.run(terms=['^qz_.+'], variables={'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"})

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 16:31:22.801781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Arrange
    lookup_module = LookupModule()
    terms = ["^qz_.+"]
    variables = {"qz_1": "hello",
                 "qz_2": "world",
                 "qa_1": "I won't show",
                 "qz_": "I won't show either"}
    
    expected_results = ["qz_1", "qz_2"]
    actual_results = []
    # Act
    actual_results = lookup_module.run(terms, variables)
    # Assert 
    assert expected_results == actual_results, "Actual: %s. Expected: %s" % (actual_results, expected_results)



# Generated at 2022-06-11 16:31:30.793169
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup test data
    #################

    test_data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
        'f': 6,
        'g': 7,
        'h': 8,
        'i': 9,
        'j': 10
    }

    # Tests
    #################
    lm = LookupModule()

    # test varname with multiple underscore
    result = lm.run(['.*_.*'], variables=test_data)

    assert len(result) == 10
    assert 'a' in result
    assert 'b' in result
    assert 'c' in result
    assert 'd' in result
    assert 'e' in result
    assert 'f' in result

# Generated at 2022-06-11 16:31:39.292235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # An empty list, this is what it should be.
    MOCK_TERMS = []

    mock_lookup_instance = LookupModule()
    assert isinstance(mock_lookup_instance, LookupModule)

    mock_lookup_instance.set_options = lambda var_options, direct: None
    assert mock_lookup_instance.set_options == mock_lookup_instance.set_options

    # An empty list, this is what it should be.
    assert mock_lookup_instance.run(terms=MOCK_TERMS) == []

# Generated at 2022-06-11 16:31:49.140586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from unittest.mock import patch
    from ansible.plugins.lookup import LookupBase

    vm = LookupModule()
    # pass corner cases to run method
    # With no arguments
    with pytest.raises(AnsibleError) as excinfo:
        vm.run([])
    assert 'No variables available to search' in str(excinfo.value)

    # With an invalid argument
    with patch.object(LookupBase, 'set_options') as mock_options:
        with pytest.raises(AnsibleError) as excinfo:
            vm.run([], variables={'a':'a', 'b':'b'})
        assert 'Invalid setting identifier' in str(excinfo.value)

    # With a list of valid arguments

# Generated at 2022-06-11 16:31:59.673335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    test_dict = {"qz_1":"hello","qz_2":"world","qa_1":"I won't show","qz_":"I won't show either"}
    search_term1 = ["^qz_.+"]
    result1 = test_obj.run(search_term1, variables=test_dict)
    assert sorted(result1) == sorted([u'qz_1', u'qz_2'])
    search_term2 = [".+_zone$",".+_location$"]
    test_dict["zone1"] = "something"
    test_dict["something_location"] = "something"
    result2 = test_obj.run(search_term2, variables=test_dict)

# Generated at 2022-06-11 16:32:05.727439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['^qz_.+']
  variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
  expected_result = ['qz_1', 'qz_2']
  lookup_result = LookupModule().run(terms, variables)
  assert lookup_result == expected_result

# Generated at 2022-06-11 16:32:09.745035
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    result=lookup_module.run('^qz_.+',{"qz_1": "hello","qz_2": "world","qa_1": "I won't show","qz_": "I won't show either"})
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:32:21.442026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from . import testdata

    Case = testdata.data.Case

    lookup_module = LookupModule()

    Case([], {}, {}, '^qz_.+',
         [],
         msg='Should return empty list for no vars')

    Case([], {'a': '1'}, {}, '^qz_.+',
         [],
         msg='Should return empty list for no vars matching')

    Case([], {'a': '1'}, {}, '^a$',
         ['a'],
         msg='Should return list with matching varname')

    Case([], {'a': '1'}, {}, '.+',
         ['a'],
         msg='Should return list with matching varname')


# Generated at 2022-06-11 16:32:34.925205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '.', 'hosts', '.+_zone$', '.+_location$']
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
        "hosts": "hosts",
        "subnet_zone": "subnet_zone",
        "subnet_location": "subnet_location",
        "subnet_regions": "subnet_regions"
    }
    lu = LookupModule()
    result = lu.run(terms, variables)
    assert len(result) == 7

# Generated at 2022-06-11 16:32:41.181069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    import ansible.utils.unsafe_proxy
    import ansible.constants
    import re

    class VarManager(object):
        def __init__(self):
            self._vars = dict()

        def _get(self, varname):
            return self._vars[varname]

        def _set_var(self, varname, val, unsafe=False, use_cache=True, vault_password=None):
            self._vars[varname] = val

        def __getattr__(self, item):
            try:
                return self._get(item)
            except KeyError:
                raise AttributeError

    def _get_var_manager():
        return autocall(VarManager())

    lookup = LookupModule()

# Generated at 2022-06-11 16:32:51.018598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()

    # passing invalid terms
    test_terms = 1
    try:
        test_object.run(test_terms)
        assert False, "AnsibleError not raised"
    except AnsibleError:
        pass

    # passing variable names that needs to be found
    test_terms = [
        '^qz_.+',
        '^qa_.+',
        'asdf',
        'gfhd'
    ]

    # passing variables with some variable names
    test_variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'hi',
        'qz_': 'hey'
    }

    # passing invalid variables
    test_variables = 1

# Generated at 2022-06-11 16:33:01.477350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'hosts': 'host file',
        'host_name': 'host name',
        'hostname': 'hostname',
        'hosts_zone': 'hosts zone',
        'hosts_location': 'hosts location',
        'hosts_1_location': 'hosts 1 location',
        'hosts_2_location': 'hosts 2 location',
    }

    ret = module.run(['^qz_.+'], variables)
    assert ret == ['qz_1', 'qz_2']


# Generated at 2022-06-11 16:33:07.826701
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms = ['qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    result = lookup.run(terms=terms, variables=variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-11 16:33:13.789955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_cmd = LookupModule()
    args = ['qz_1.+']
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    ret = lookup_cmd.run(args, vars)
    assert len(ret) == 2
    assert 'qz_1' in ret
    assert 'qz_2' in ret

# Generated at 2022-06-11 16:33:23.562379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #region test_method_definition
    lookup_instance = LookupModule()
    lookup_instance.set_runner(Dict({}))
    #endregion

    #region test_variable_names
    lookup_instance.run(['.+'], Dict({'qa':True, 'qz':True, 'qa_hello':False, 'qz_world':False, 'qa_':False, 'qz_':False}))
    lookup_instance.run(['hosts'], Dict({'hosts': True, 'hosts_zone': False, 'hosts_location': False}))
    lookup_instance.run(['hosts_zone', 'hosts_location'], Dict({'hosts_zone': True, 'hosts_location': True}))

# Generated at 2022-06-11 16:33:34.728081
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    # Test with no variables
    terms = ["^qz_.+"]
    variables = None
    lookup_plug = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plug.run(terms, variables)
    assert 'No variables available to search' in str(excinfo.value)

    # Test with some variables
    terms = ["^qz_.+"]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    lookup_plug = LookupModule()
    result = lookup_plug.run(terms, variables)

# Generated at 2022-06-11 16:33:39.365375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the input value
    terms = ['^qz_.+', '^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # declare the return value
    ret = []
    name = []

    # test condition
    if terms is not None and variables is not None:
        ret.append('qz_1')
        ret.append('qz_2')    

    assert(ret == list(variables.keys()))

# Generated at 2022-06-11 16:33:48.628630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVariables(object):
        def __init__(self, data):
            self.data = data

        def keys(self):
            return self.data.keys()

    # empty variable
    variables = MockVariables({})
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule().run([], variables)
    assert "No variables available to search" in str(excinfo.value)

    # invalid setting identifier
    variables = MockVariables({"hosts": "hosts", "hosts_zone": "hosts_zone"})
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule().run(["".join(["a" for _ in range(300)])], variables)

# Generated at 2022-06-11 16:34:07.329757
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    result = LookupModule().run(terms=['^qz_.+'],
                                variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

    assert result == ['qz_1', 'qz_2']

    result = LookupModule().run(terms=['%s' % re.escape('.+')],
                                variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-11 16:34:14.397226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'var1': 'val1', 'var2': 'val2', 'var3': 'val3'})
    assert l.run(['a']) == []
    assert l.run(['^var']) == ['var1', 'var2', 'var3']
    assert l.run(['^var', 'var']) == ['var1', 'var2', 'var3']
    assert l.run(['.*']) == ['var1', 'var2', 'var3']
    assert l.run(['a', 'var']) == ['var1', 'var2', 'var3']

# Generated at 2022-06-11 16:34:17.560012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show"}
    ret = LookupModule().run(terms=terms, variables=variables)
    assert len(ret) == 2
    assert 'qz_1' in ret and 'qz_2' in ret

# Generated at 2022-06-11 16:34:27.845030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['^qz_.+'], variables=dict(qz_1='hello', qz_2='world', qa_1='I won\'t show', qz_='I won\'t show either'))
    assert result == ['qz_1', 'qz_2']

    result = LookupModule().run(['^qz_.+'], variables=dict(qz_1='hello', qz_2='world', qa_1=1, qz_=['I won\'t show either']))
    assert result == ['qz_1', 'qz_2']

    result = LookupModule().run(['.+'])
    assert result == [], "No variables passed in"


# Generated at 2022-06-11 16:34:37.462106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the LookupModule class
    import sys
    sys.path.append("..")
    from lookup_plugins.varnames import LookupModule
    lookup_module = LookupModule()
    lookup_module.set_options()

    # dictionary of Ansible variables
    variables = dict(ansible_facts=dict(ansible_all_ipv4_addresses=['127.0.0.1'], ansible_architecture='x86_64'))

    test_term = 'all_ipv4'
    list_variable_names = [test_term, 'architecture', 'something_else']
    assert lookup_module.run([test_term], variables=variables) == list_variable_names

if __name__ == '__main__':
    # Run the unit test
    test_LookupModule

# Generated at 2022-06-11 16:34:48.002927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unicode import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeModule(AnsibleUnicode):
        def __init__(self):
            self.params = {}
            super(FakeModule, self).__init__()

    module = FakeModule()
    lookup_instance = LookupModule()
    string_to_bytes = True
    import sys
    if sys.version_info[0] == 3:
        string_to_bytes = False


# Generated at 2022-06-11 16:34:58.424170
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {
        'hello': 'world',
        'test_foo': 'foo',
        'test_b': 'bar',
        'test_2': 'bar2'
    }

    # Test that run() returns all variables when a wildcard * is used
    search_terms = ['^.+$']
    lookup = LookupModule()
    result = lookup.run(terms=search_terms, variables=variables)

    assert isinstance(result, list)
    for k in variables.keys():
        assert k in result

    # Test that run() properly filters variables
    search_terms = ['^test_.+']
    lookup = LookupModule()
    result = lookup.run(terms=search_terms, variables=variables)

    assert isinstance(result, list)
    assert len(result) == 3
    assert result

# Generated at 2022-06-11 16:35:07.756893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            self.set_options(var_options=variables, direct=kwargs)
            return terms

    lookup = LookupModule()

    assert lookup.run([]) == []
    assert lookup.run(['class']) == ['class']
    assert lookup.run(['class'],variables={"class" : "Ansible"}) == ['class']
    assert lookup.run(['class', 'Python'],variables={"class" : "Ansible", "Python" : "3.6"}) == ['class', 'Python']

# Generated at 2022-06-11 16:35:17.990885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # work around the fact that we call the run method of LookupModule with
    # two arguments, but the first argument is actually a list of arguments
    #
    lookup_module = LookupModule()
    #
    # All parameters must be a dictionary.
    #
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I will not show',
        'qz_' : 'I will not show either'
    }
    #
    # test case 1.
    #
    terms = ['^qz_.+']
    results = lookup_module.run(terms, variables)
    assert ['qz_1', 'qz_2'] == results
    #
    # test case 2.
    #
    terms = ['.+']

# Generated at 2022-06-11 16:35:22.197551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-argument, no-member, protected-access
    p = LookupModule('varnames')
    terms = ['hello', 'world']
    variables = {'hello': 'world', 'world': 'hello'}
    p.run(terms, variables=variables)

# Generated at 2022-06-11 16:35:59.027575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit tests for run method of LookupModule
    # Test 1: Test combination of specific value and regex for ansible variables
    lookup_run_test1 = LookupModule()
    terms = ['^qz_.+', 'qz_']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_value1 = ['qz_', 'qz_1', 'qz_2']
    actual_value1 = lookup_run_test1.run(terms, variables)
    assert expected_value1 == actual_value1, 'Error in test 1 of method run in class LookupModule'

    # Test 2: Test regex to search ansible variables
    lookup_run_test2 = LookupModule

# Generated at 2022-06-11 16:36:10.179018
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with no variables
    try:
        lookup = LookupModule()
        lookup.run("_terms", {})
        raise AssertionError("Test did not raise exception")
    except AnsibleError as e:
        assert "No variables available to search" in str(e)

    # Test with non-string _terms
    try:
        lookup = LookupModule()
        lookup.run({}, {'a': 1})
        raise AssertionError("Test did not raise exception")
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid python regular expression _terms

# Generated at 2022-06-11 16:36:17.811097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_plugin.run(terms, variables) == ['qz_1', 'qz_2']
    assert lookup_plugin.run('^qz_.+', variables) == ['qz_1', 'qz_2']
    assert lookup_plugin.run(['hosts'], variables) == []
    assert lookup_plugin.run(['.+_zone$', '.+_location$'], variables) == []


# Generated at 2022-06-11 16:36:26.835289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    home_dir = os.path.expanduser("~")
    assert LookupModule().run(terms=["db_name"], variables={"db_name":"dvdrental","db_hostname":"localhost"}) == ["db_name"]
    assert LookupModule().run(terms=["^db_.+"], variables={"db_name":"dvdrental","db_hostname":"localhost"}) == ["db_name", "db_hostname"]
    assert LookupModule().run(terms=["^db_.+",".+name$"], variables={"db_name":"dvdrental","db_hostname":"localhost"}) == ["db_name", "db_hostname"]

# Generated at 2022-06-11 16:36:37.364792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = {
        'ansible_ssh_host': '127.0.0.1',
        'ansible_ssh_port': '22',
        'ansible_ssh_user': 'user',
        'ansible_ssh_pass': 'password',
        'ansible_ssh_host_key_checking': 'no',
        'ansible_python_interpreter': '/usr/bin/python3'
    }
    module = LookupModule()
    terms = ['^ansible_ssh_.+', '^ansible_python_interpreter$']
    ret = module.run(terms, variables=hostvars)

# Generated at 2022-06-11 16:36:47.833603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test the run function of LookupModule'''
    import pytest
    from ansible.parsing.vault import VaultLib

    lookup_module = LookupModule()
    ansible_vars = {'ansible_version': '2.9.9', 'ansible_become_password': 'Vault password'}

# Generated at 2022-06-11 16:36:57.314931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = Dummy()
    l._loader = Dummy()
    l._loader.get_basedir = lambda x: '.'
    l._display = Dummy()
    vars = {"host1": "host1", "testhost": "testhost", "testhost01": "testhost01", "testhost02": "testhost02", "testhost03": "testhost03"}
    for var in vars:
        l.set_options({}, vars)
    assert l.run(['^testhost0.+'], vars) == ['testhost01', 'testhost02', 'testhost03']
    assert l.run(['^testhost$'], vars) == ['testhost']

# Generated at 2022-06-11 16:37:06.992764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestClass(object):
        pass

    # Invalid parameters
    lookup = LookupModule()
    with pytest.raises(AnsibleError):
        lookup.run(['foo'])
    with pytest.raises(AnsibleError):
        lookup.run([True])
    with pytest.raises(AnsibleError):
        lookup.run([1])

    # Invalid parameters
    lookup.run(['^bar'], variables={'foo': 'bar'})
    lookup.run(['^foo'], variables={'foo': 'bar'})
    lookup.run(['^bar'], variables={'bar': 'foo'})
    lookup.run(['^bar'], variables={'foo': 10})

    # Empty search terms
    assert [] == lookup.run([], variables=TestClass())
    assert []

# Generated at 2022-06-11 16:37:16.257143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = {}
    assert LookupModule().run(["^qz_.+"], variables=dict(qz_1='hello', qz_2='world', qa_1='I won\'t show', qz_='I won\'t show either')) == ['qz_1', 'qz_2']
    assert LookupModule().run(['.+'], variables=dict(qz_1='hello', qz_2='world', qa_1='I won\'t show', qz_='I won\'t show either')) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-11 16:37:24.390811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    assert lookupModule.run(["^qz_.+"], variables={"qz_1":"hello","qz_2":"world"}) == ["qz_1", "qz_2"]
    assert lookupModule.run([".+"]) == []
    assert lookupModule.run(["hosts"]) == []
    assert lookupModule.run([".+", "hosts"]) == []
    assert lookupModule.run([".+_zone", ".+_location"], variables={"qz_zone":"hello","qz_location":"world"}) == ["qz_zone", "qz_location"]



# Generated at 2022-06-11 16:38:25.588838
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # "Variables" is a dict containing the variables that Ansible has available to it
    vars = {'ansible_facts': {'os_family': 'RedHat', 'distribution': 'Centos'},
            'ansible_env': {'HOME': '/home/me'},
            'secret_var': 'mysecret'}
    the_path = ['/home/me/ansible/lookup']

    l = LookupModule()
    l.set_basedir(the_path)

    # term is a list of regex strings to search for in the variables dict
    # This first test returns the two variables that start with 'ansible_'
    term = ['^ansible_.+']
    result = l.run(term=term, variables=vars)
    assert 'ansible_facts' in result

# Generated at 2022-06-11 16:38:26.209069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:38:35.957612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    result = LookupModule().run(
        terms=[
            '^qz_.+',
            'hosts',
            '^qz_.+',
            '.+_zone$',
            '.+_location$',
        ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
            'all_hosts_zone': True,
            'all_hosts_location': True,
            'sql_hosts': True,
        },
    )

# Generated at 2022-06-11 16:38:45.374528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test words
    w1 = "abc"
    w2 = "def"
    w3 = "abcdef"
    w4 = "abcdefg"
    w5 = "a"
    w6 = "d"
    w7 = "g"
    # Test variables
    var = {
        "test_1": "1",
        "test_2": "2",
        "test_3": "3",
        "test_4": "4",
        "test_5": "5",
        "test_6": "6",
        "test_7": "7"
    }
    # Test results
    r1 = [w1]
    r2 = [w2]
    r3 = [w3]
    r4 = [w4]

# Generated at 2022-06-11 16:38:56.181392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    l = LookupModule()
    assert l.run(['.+']) == []
    # Test with empty list of terms
    assert l.run([], {'a': 1, 'b': 2}) == []

    # Test with single term (exact match)
    ret = l.run(['a'], {'a': 1, 'b': 2})
    assert ret == ['a']
    # Test with single term (regex match)
    ret = l.run(['a'], {'aa': 1, 'b': 2})
    assert ret == ['aa']
    # Test with single term (no match)
    ret = l.run(['c'], {'aa': 1, 'b': 2})
    assert ret == []
    # Test with multiple terms (all exact matches)

# Generated at 2022-06-11 16:39:01.613285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.lookup import LookupBase

    l = LookupModule()

    l.set_options({'_ansible_no_log': True}, direct={'no_log': True})

    # result should be a list
    result = l.run(['^qz_.+'], variables={'qz_1': 'hello','qz_2': 'world','qa_1': "I won't show","qz_": "I won't show either"})
    assert isinstance(result, list)
    assert result == ['qz_1', 'qz_2']

    # try with no variables

# Generated at 2022-06-11 16:39:09.125858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In this test, we will be using the same variables
    # used in the example section.

    # Sample variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': 'This is a commit message'
    }

    # We will use the LookupModule class from the
    # ansible.plugins.lookup.varnames module.
    from ansible.plugins.lookup.varnames import LookupModule
    lookup_mod = LookupModule()

    # Now we will test for different terms
    # to check if the results are expected.

    # List variables that start with qz_
    term1 = '^qz_.+'


# Generated at 2022-06-11 16:39:14.634261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_test = LookupModule()
    test_vars = {'a_b': 0, 'b_a': 1, 'a_b_c': 2, 'c_a_b': 3}
    assert lookup_module_test.run(['.*_a$'], test_vars, variables=test_vars) == ['a_b', 'b_a', 'a_b_c', 'c_a_b']
    assert lookup_module_test.run(['b_a'], test_vars, variables=test_vars) == []
    assert lookup_module_test.run(['(c|d)_a_b'], test_vars, variables=test_vars) == ['c_a_b']

# Generated at 2022-06-11 16:39:23.514041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = []
    lookup = LookupModule()
    terms = [
      '^qz_.+',
      '.+',
      'hosts',
      '.+_zone$',
      '.+_location$'
    ]

# Generated at 2022-06-11 16:39:33.781785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    lookup_module_instance = LookupModule()
    result = lookup_module_instance.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2'], result

# Generated at 2022-06-11 16:40:35.672518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    options = {}
    options["_terms"] = ["test_var"]

    assert lookup_module.run(**options) == []

    options["_terms"] = [".+"]
    assert lookup_module.run(**options) == []

    options["_terms"] = ["^test_variable_\\d+$"]
    options['var_options'] = {
        "test_variable_1": "value_1",
        "test_variable_2": "value_2",
    }
    assert lookup_module.run(**options) == ['test_variable_1', 'test_variable_2']

# Generated at 2022-06-11 16:40:46.124074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # this test is not run as part of 'nosetests' but only invoked explicitly.
    # the reason is that it depends on ansible internals so it needs to be
    # tested manually.
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    plugin = LookupModule()

    def run_plugin(terms, variables=None):
        plugin.run(terms, variables)

    # no variables
    try:
        run_plugin(['abc'])
        assert False, 'expected exception'
    except AnsibleError as e:
        assert 'No variables' in str(e)

    # invalid terms
    variables=dict()

# Generated at 2022-06-11 16:40:56.410314
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.varnames import LookupModule

    lookup_module = LookupModule()

    terms = ['^foo_.+', 'bar_', 'hello', '^world_.+']
