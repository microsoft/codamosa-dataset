

# Generated at 2022-06-25 11:37:42.730027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_1 = LookupModule()
    lookup_module_obj_2 = LookupModule()
    lookup_module_obj_3 = LookupModule()


# Generated at 2022-06-25 11:37:46.525930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No variables available to search
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run(terms = ['^qz_.+'], variables = None)
    except Exception as e:
        assert(e.args[0] == 'No variables available to search')


# Generated at 2022-06-25 11:37:53.824899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_module_0.run(terms_0, variables_0=variables_0) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:37:56.945988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = dict()
    variables['a'] = 'a'
    variables['b'] = ''
    variables['c'] = 'b'
    lookup_module = LookupModule()
    result = lookup_module.run(['a', 'c'], variables)
    assert result == ['a', 'c']


# Generated at 2022-06-25 11:38:01.976714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=["^qz_.+"], variables={u'qz__': u"I won't show either", u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_1': u'hello', u'qz_': u"I won't show either"}, **{})


# Generated at 2022-06-25 11:38:11.978054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()  # Instantiate class LookupModule
    # Invoke method run of class LookupModule with arguments
    # dict{unicode: set}, dict{unicode: unicode}, dict{unicode: unicode}
    # Return type: list
    assert isinstance(lookup_module_1.run(
        ['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}), list)

# Generated at 2022-06-25 11:38:17.287358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {"a":"1"}
    kwargs = {"variable_start":"a", "variable_end":"b"}
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run("a",variables,**kwargs)
    assert result_0 == ["a"]

# Generated at 2022-06-25 11:38:24.257384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_terms_1 = [u'^qz_.+']
    test_variables_1 = {u'qz_2': u'world', u'qz_1': u'hello', u'qa_1': u"I won't show"}
    expected_result_1 = [u'qz_2', u'qz_1']
    actual_result_1 = lookup_module_1.run(test_terms_1, test_variables_1)
    assert actual_result_1 == expected_result_1


# Generated at 2022-06-25 11:38:28.892558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "qz_1"
    variables = {'qz_1':"hello"}
    kwargs = {"msg":"{{lookup('varnames', '^qz_.+')}}"}
    assert lookup_module_0.run(terms, variables, **kwargs) == ['qz_1']

# Generated at 2022-06-25 11:38:40.222879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 1:
    x = {u'inventory_dir': u'../ansible_collections/ansible/tower/', u'start_at_task': None, u'inventory_file': u'../ansible_collections/ansible/tower/', u'playbook_dir': u'../ansible_collections/ansible/tower/'}
    LookupModule.run(x)
    # test case 2:
    x = {u'name': u'GCE dynamic inventory', u'module': u'gce', u'api_version': 1}
    LookupModule.run(x)
    # test case 3:

# Generated at 2022-06-25 11:38:51.299429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '^qz_.+'
    variables_0 = dict(qa_1='I won\'t show', qz_2='world', qz_1='hello', qz_='I won\'t show either')
    kwargs_0 = dict(direct=None)
    result = lookup_module_0.run(terms=term_0, variables=variables_0, **kwargs_0)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:38:56.280352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[u'^qz_.+'], variables={u'ansible_check_mode': True, u'ansible_module_name': u'command', u'ansible_facts': {}, u'ansible_syslog_facility': u'LOG_USER', u'ansible_syslog_ident': u'ansible-command'})
    return None

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 11:39:00.849391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  vars = { 'VAR': 'test' }
  lookup_module_run_0 = LookupModule().run([ 'VAR'], variables=vars)
  assert isinstance(lookup_module_run_0, list)
  assert lookup_module_run_0 == [ 'VAR' ]

# Generated at 2022-06-25 11:39:12.748016
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Mock variable arguments
    def dict_values(self, *args, **kwargs):
        return ['qz_1', 'qz_2', 'qa_1', 'qz_']

    setattr(lookup_module_0, '_templar', type('', (), {'template': dict_values}))

    # Mock variable arguments
    def dict_keys(self, *args, **kwargs):
        return {'qz_1', 'qz_2', 'qa_1', 'qz_'}

    setattr(lookup_module_0._templar, '_available_variables', type('', (), {'keys': dict_keys}))

    # Test with valid parameters

# Generated at 2022-06-25 11:39:21.597195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Searching for qz_1
    orig_vars_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", }
    kwargs_0 = {'_terms': 'qz_.+'}
    result_0 = lookup_module_0.run(terms=['qz_.+'], variables=orig_vars_0, **kwargs_0)
    assert result_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:22.693595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert to_native(LookupModule.run(None, 'abc')) == 'abc'

# Generated at 2022-06-25 11:39:28.602054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # test case with 0 parameters
    assert None == lookup_module_0.run()
    # test case with 1 parameters
    assert None == lookup_module_0.run(terms=None)
    # test case with 2 parameters
    assert None == lookup_module_0.run(terms=None, variables=None)



# Generated at 2022-06-25 11:39:40.423836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': 'hosts variable',
        'hosts_zone': 'hosts_zone variable',
        'hosts_location': 'hosts_location variable',
    }

    terms = ['^qz_.+']
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']
    assert lookup_module.run(terms) == []

    terms = ['^a_1']
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == []


# Generated at 2022-06-25 11:39:51.008206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    ansible_facts = {'var_name_0': 'val_0'}
    words = []
    words.append('^var.+')
    assert lookup_module_1.run(words, variables=ansible_facts) == ['var_name_0']
    words = []
    words.append('^VAR.+')
    assert lookup_module_1.run(words, variables=ansible_facts) == []
    words = []
    words.append('^VAR.+')
    words.append('^var.+')
    assert lookup_module_1.run(words, variables=ansible_facts) == ['var_name_0']


# Generated at 2022-06-25 11:39:53.355042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() ==  ret



# Generated at 2022-06-25 11:40:08.284038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 11:40:13.571804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:40:20.394295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup data
    lookup_module_1 = LookupModule()
    # Test exception raised
    # AssertionError: Invalid setting identifier, "^qz_.+" is not a string, it is a <class 'str'>

    # Error: test_LookupModule_run : Traceback (most recent call last):
    # File "C:\Github\ansible\test\unit\plugins\lookup\test_varnames.py", line 68, in test_LookupModule_run
    # lookup_module_1.run(['^qz_.+'])
    # File "C:\Github\ansible\lib\ansible\plugins\lookup\varnames.py", line 42, in run
    # raise AnsibleError('Invalid setting identifier, "%s" is not a string, it is a %s' % (term,

# Generated at 2022-06-25 11:40:25.734132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    # Run test:
    lookup_module.run(['^qz_.+'], variables)


# Generated at 2022-06-25 11:40:35.694516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [ '^qz_.+' ]
    variables_1 = '{    qz_1: hello,    qz_2: world,    qa_1: "I won\'t show",    qz_: "I won\'t show either" }'
    kwargs_1 = {}
    assert lookup_module_0.run(terms_1, variables_1, kwargs_1) == [ 'qz_1', 'qz_2' ]

    lookup_module_1 = LookupModule()
    terms_2 = [ '.+' ]

# Generated at 2022-06-25 11:40:45.924376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    terms = ['^qz_.+']
    data = "qz_1: hello\nqz_2: world\nqa_1: 'I won''t show'\nqz_: 'I won''t show either'\n"
    data = to_text(data, errors='surrogate_or_strict')
    data = AnsibleLoader(data, None, yaml_loader=None).get_single_data()

    ret_vars = lookup_module_0.run(terms, data)

    assert ret_vars == ['qz_1','qz_2','qz_']


# Generated at 2022-06-25 11:40:53.954760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule() # dummy instance
    
    #Test 1
    term1 = '^qz_.+'
    variables1 = {'qz_1':'hello', 'qz_2':'world'}
    result1 = lookup_module_1.run(terms=term1, variables=variables1)
    assert result1 == ['qz_1', 'qz_2']
    
    #Test 2
    term2 = 'hosts'
    variables2 = {'hosts':'hosts', 'hosts_group':'hosts_group'}
    result2 = lookup_module_1.run(terms=term2, variables=variables2)
    assert result2 == ['hosts', 'hosts_group']
    
    #Test 3

# Generated at 2022-06-25 11:40:58.339242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['.+_hosts$']
    variables_1 = dict(zz_hosts = dict(hosts=['centos01']))
    assert lookup_module_1.run(terms_1, variables_1) == [u'zz_hosts']

# Generated at 2022-06-25 11:41:08.959182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['^qz_.+']
    variables_1 = {
        'qz_1': 'hello',
        'qz_2': 'world'
    }
    ret_1 = lookup_module_1.run(terms_1, variables_1)
    assert ret_1 == ['qz_1', 'qz_2']

    lookup_module_2 = LookupModule()
    terms_2 = ['.+']
    variables_2 = {
        'qz_1': 'hello',
        'qz_2': 'world'
    }
    ret_2 = lookup_module_2.run(terms_2, variables_2)
    assert ret_2 == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:41:12.676545
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_case_0 = LookupModule()
    lookup_module_case_0.set_options(var_options={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}, direct={})
    result = lookup_module_case_0.run(terms=["^qz_.+"])
    assert result == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:41:34.547097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['^qz_.+', '.+_zone$', '.+_location$'])

# Generated at 2022-06-25 11:41:44.404433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing LookupModule run")
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print("Result: %s" % result_0)
    assert result_0 == []
    lookup_module_1 = LookupModule()
    terms_1 = []
    variables_1 = {'var_1': 0}
    kwargs_1 = {}
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    print("Result: %s" % result_1)
    assert result_1 == []
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:41:55.785504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup environment
    global lookup_module_0
    lookup_module_0 = LookupModule()
    lookup_module_0.run = lambda terms, variables=None, **kwargs: terms

    # Test case 
    class variables(object):
        def __init__(self):
            #self.GCE_KEYFILE_JSON='/home/louis/.gcloud/geheim.json'
            self.GCE_KEYFILE_JSON='/Users/chao/Documents/geheim.json'
            self.ansible_check_mode=False
            self.ansible_connection='ssh'
            self.ansible_diff_mode=False
            self.ansible_facts_module='gce_compute'
            self.ansible_host='23.251.146.184'
            self.ansible_host_

# Generated at 2022-06-25 11:42:06.179055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    variables = {
        "test_string_var": "test_string_var_value",
        "test_int_var": 1,
        "test_list_var": ["test", "list", "var"]
    }

    # test exact match
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["test_string_var"], variables) == ["test_string_var"]
    assert lookup_module_0.run(["test_int_var"], variables) == ["test_int_var"]
    assert lookup_module_0.run(["test_list_var"], variables) == ["test_list_var"]

    # test regex match
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:42:15.692110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms = ['^qz_.+']
  variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
  assert lookup_module_0.run(terms, variables=variables) == ['qz_1', 'qz_2']
  terms = ['.+']
  assert lookup_module_0.run(terms, variables=variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
  terms = ['hosts']
  assert lookup_module_0.run(terms, variables=variables) == []
  terms = ['.+_zone$', '.+_location$']
  assert lookup_module

# Generated at 2022-06-25 11:42:23.226497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test 1
    terms = ['^qz_.+']
    variables = {'qz_2': 'world', 'qz_1': 'hello', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_ret = ['qz_1', 'qz_2']
    lookup_module_0.run(terms, variables=variables)
    assert expected_ret == lookup_module_0._value
    # Test 2
    terms = ['.+']
    variables = {'qz_2': 'world', 'qz_1': 'hello', 'qa_1': "I won't show", 'qz_': "I won't show either"}

# Generated at 2022-06-25 11:42:24.987437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables_0 = {}
    terms_0 = ['.+_zone$', '.+_location$']
    assert (lookup_module_0.run(terms_0, variables=variables_0) == lookup_module_0._value)

# Generated at 2022-06-25 11:42:33.098253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  term = "^qz_.+"
  variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}

  lookup_module = LookupModule()
  lookup_module.run(terms = term, variables = variables)
  if lookup_module._value[0] == "qz_1" and lookup_module._value[1] == "qz_2":
    print("Passed Unit Test_0")
  else:
    print("Failed Unit Test_0")


# Generated at 2022-06-25 11:42:38.663739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = dict()
    kwargs = dict()
    kwargs['wantlist'] = True
    assert lookup_module_0.run(terms=terms, variables=variables, **kwargs) == []



# Generated at 2022-06-25 11:42:44.753749
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    kwargs = {}
    assert lookup_module.run(terms, variables, **kwargs) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:43:33.420034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    values = [
        '^qz_.+',
        'hosts',
        '.+_zone$'
    ]
    key = '_terms'
    keywords = {'variables': {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts_zone': 1,
        'hostd_zone': 2,
        'host_zone': 3,
        'qz_zone': 4,
        'qz_location': 5
        },
        'fail_key': 'msg'
    }
    lookup_module_run.run(values, **keywords)

# Generated at 2022-06-25 11:43:38.861415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    to_check = ['', '', '', '', '', '']
    assert lookup_module_0.run() == to_check


# Generated at 2022-06-25 11:43:44.402846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.run(terms=['^qz_.+'], variables={"qz_1": "hello","qz_2": "world","qa_1": "I won't show","qz_": "I won't show either"})
    lookup_module_run.run(terms=['.+'], variables={})
    lookup_module_run.run(terms=['hosts'], variables={})
    lookup_module_run.run(terms=['.+_zone$', '.+_location$'], variables={})

# Generated at 2022-06-25 11:43:48.266259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["^qz_.+"]
    variables_0 = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    assert lookup_module_0.run(terms_0, variables=variables_0) == ["qz_1", "qz_2"]



# Generated at 2022-06-25 11:43:52.432384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ["^qz_.+"]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    assert lookup_module_1.run(terms, variables=variables) == ['qz_1', 'qz_2']
    assert lookup_module_1.run(["^qa_.+"], variables=variables) == []
    assert lookup_module_1.run([".+"], variables=variables) == variables.keys()
    assert lookup_module_1.run(["hosts"], variables=variables) == []

# Generated at 2022-06-25 11:43:54.378268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:44:00.506896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        '^qz_.+',  # module_args['_terms']
    ]
    variables = {
        'qz_1': lookup_module_0.get_option('qz_1'),
        'qz_2': lookup_module_0.get_option('qz_2'),
        'qa_1': lookup_module_0.get_option('qa_1'),
        'qz_': lookup_module_0.get_option('qz_'),
    }
    ret = lookup_module_0.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:44:02.719774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    vals = lookup.run(terms, variables)
    assert vals == [['qz_1', 'qz_2']]

# Generated at 2022-06-25 11:44:04.925889
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    varname_list = lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert varname_list == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:44:13.556321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, direct={'_ansible_': True})
    terms = ['^qz_.+']
    result_0 = lookup_module_0.run(terms, variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert len(result_0) == 2


# Generated at 2022-06-25 11:45:48.698051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:45:51.364855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test using a patch to mock the return value
    # TODO: This test needs to be improved to more closely resemble the actual usage
    with mock.patch.object(lookup_module_0, 'run', return_value=None) as mock_run:
        assert lookup_module_0.run() == None

# Generated at 2022-06-25 11:45:52.818012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module.run(['test', 'test2']), list)

# Generated at 2022-06-25 11:46:02.228538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={"cname": "content", "dname": "debug"}, direct={"warnings": True})
    lookup_module_1.run(terms=["^qz_.+"], variables={"cname": "content", "dname": "debug"})
    lookup_module_1.run(terms=["^qz_.+"], variables=None)
    lookup_module_1.run(terms=[u"abc"], variables={"cname": "content", "dname": "debug"})
    lookup_module_1.run(terms=["^qz_.+"], variables={"cname": "content", "dname": "debug"})

# Generated at 2022-06-25 11:46:10.693340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    # test with good variables
    variables = {'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"}
    expected_result = ['qz_1', 'qz_2']
    assert(expected_result == lookup_module_0.run(terms, variables))

# test with good variables

# Generated at 2022-06-25 11:46:16.620757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('^qz_.+')
    lookup_module.run('.+')
    lookup_module.run('hosts')
    lookup_module.run('.+_zone$', '.+_location$')

# Generated at 2022-06-25 11:46:18.207637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    try:
        lookup_module.run(terms=[], variables=None, **{})
    except AnsibleError as err:
        assert err.message == 'No variables available to search'


# Generated at 2022-06-25 11:46:28.216763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    # Basic variable
    variables = {'a': 2}
    lookup_module_0 = LookupModule()
    # Setting a=2 in lookup_module_0.get_option()
    lookup_module_0.set_options(var_options=variables)
    # Verifying that the var is set
    test_get_option = lookup_module_0.get_option('a')
    assert test_get_option == 2
    #
    #
    variables = {'az_1': 'hello', 'az_2': 'world', 'az_3': 'hello', 'az_4': 'world'}
    terms = ['az_.']
    lookup_module_0 = LookupModule()
    # Setting a=2 in lookup_module_0.get_option()
    lookup_module_0.set

# Generated at 2022-06-25 11:46:33.310415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']
    variables = {u'qz_1': 'hello', u'qz_2': 'world', u'qa_1': "I won't show", u'qz_': "I won't show either"}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, variables)
    assert type(result) == list
    assert result == [u'qz_1', u'qz_2']


# Generated at 2022-06-25 11:46:35.080251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass
