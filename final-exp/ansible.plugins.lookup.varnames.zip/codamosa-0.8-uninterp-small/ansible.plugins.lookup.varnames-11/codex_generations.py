

# Generated at 2022-06-25 11:37:44.333932
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = dict()
    variables['qz_1'] = "hello"
    variables['qz_2'] = "world"
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"

    lookup_module_1 = LookupModule()
    lookup_module_1.run("^qz_.+",variables)

# Generated at 2022-06-25 11:37:52.337842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    variables = {"ipaddr_10_0_0_1": "10.0.0.1", "ipaddr_10_0_0_2": "10.0.0.2", "ipaddr_10_0_0_2": "10.0.0.2"}
    kwargs = {}
    try:
        ret = lookup_module_0.run(terms, variables, **kwargs)
    except AnsibleError as e:
        error_msg = "No variables available to search"
        assert error_msg in to_native(e)

# Generated at 2022-06-25 11:38:02.048123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with no arguments
    with pytest.raises(AnsibleError):
        lookup_module_0.run()

    # Test with no variable
    with pytest.raises(AnsibleError):
        lookup_module_0.run(['^qz_.+'])

    # Test with no variables
    with pytest.raises(AnsibleError):
        lookup_module_0.run(['^qz_.+'], dict())

    # Test with invalid term

# Generated at 2022-06-25 11:38:10.776929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {}
    variables["qz_1"] = "hello"
    variables["qz_2"] = "world"
    variables["qa_1"] = "I won't show"
    variables["qz_"] = "I won't show either"
    lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:38:22.317159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'direct': {'var_options': {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}}})
    assert lookup_module_0.run([u'^qz_.+']) == ['qz_1', 'qz_2']

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:38:30.643020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule().run
    lookup_module_run_1 = LookupModule().run
    lookup_module_run_2 = LookupModule().run
    lookup_module_run_3 = LookupModule().run
    lookup_module_run_4 = LookupModule().run

    # Test correct value type returned
    assert isinstance(lookup_module_run_0(terms=['qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show'}), list)

# Test lookup plugin with good regular expression

# Generated at 2022-06-25 11:38:40.406364
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for vars = None
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(terms=[""])
    except AnsibleError as e:
        assert e.__str__() == "No variables available to search"
    
    # Unit test for term not str
    try:
        lookup_module_2 = LookupModule()
        lookup_module_2.run(terms=[1])
    except AnsibleError as e:
        assert e.__str__() == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'
    
    # Unit test for regex

# Generated at 2022-06-25 11:38:46.099544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [u'^qz_.+',u'^qz_.+']
    variables = {u'test': u'yaml', u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    ret = lookup_module.run(terms, variables)
    assert ret[0] == u'qz_1'
    assert ret[1] == u'qz_2'

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:38:51.057670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by the user
    # run with arguments provided by

# Generated at 2022-06-25 11:39:02.185636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test zero length list of arguments
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run([], [])
    # Can't catch:
    #     - AnsibleLookupError
    #     - AnsibleUndefinedVariable('No variables available to search')
    except ValueError:
        pass
    # Test zero length list of arguments
    try:
        lookup_module_0 = LookupModule()
        ret = lookup_module_0.run([], {})
        assert ret == []
    # Can't catch:
    #     - AnsibleLookupError
    #     - AnsibleUndefinedVariable('No variables available to search')
    except ValueError:
        pass
    # Test zero length list of arguments with some values

# Generated at 2022-06-25 11:39:12.243701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ('.+_zone$', '.+_location$')
    variables_0 = {'zone_0': 'var_value'}
    variables_1 = {}
    kwargs_0 = {}
    ret = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret == []

    ret = lookup_module_0.run(terms_0, variables_1, **kwargs_0)
    assert ret == []

# Generated at 2022-06-25 11:39:20.449156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    results_expected_0 = sorted(['qz_1', 'qz_2'])
    module = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    actual_results_0 = lookup_module_1.run(["^qz_.+"], variables=module)
    assert(sorted(actual_results_0) == results_expected_0)


# Generated at 2022-06-25 11:39:21.329360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run, there are no test case available.")
    assert True

# Generated at 2022-06-25 11:39:29.256673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([u'^qz_.+'], {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})
    lookup_module_0.run([u'.+'], {})
    lookup_module_0.run([u'hosts'], {})
    lookup_module_0.run([u'.+_zone$', u'.+_location$'], {})

# Generated at 2022-06-25 11:39:35.222848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}
    lookup_module_1 = LookupModule()
    terms = ["^qz_.+"]
    actual = lookup_module_1.run(terms, vars)
    expected = ['qz_1', 'qz_2']
    assert actual == expected


# Generated at 2022-06-25 11:39:41.050335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ '^qz_.+' ]
    variables_0 = {}
    __salt__ = {}
    dunder_salt__ = __salt__
    dunder_context__ = {}
    lookup_module_0._context = dunder_context__


    lookup_module_0._display.warning("No variables available to search")



# Generated at 2022-06-25 11:39:49.323549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variable_terms = ['^qz_.+']
    variable_names = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    variables = lookup_module.run(variable_terms, variable_names)
    assert len(variables) == 2
    assert 'qz_1' in variables
    assert 'qz_2' in variables

# Generated at 2022-06-25 11:39:50.260305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule().run

# Generated at 2022-06-25 11:39:52.597086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1


# Generated at 2022-06-25 11:39:58.316496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "Ansible"
    variables=None
    kwargs=None
    try:
        lookup_module_0.run(terms,variables,kwargs)
    except Exception as e:
        if hasattr(e,"__name__"):
            assert e.__name__ == "AnsibleError"
        elif hasattr(e,"message"):
            assert e.message == "No variables available to search"
        else:
            raise


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:40:08.087600
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # instantiating the class
    lookup_module_1 = LookupModule()

    # creating mock objects
    search_term_2 = "^qz_.+"
    variables_3 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either'
    }

    look_up_4 = lookup_module_1.run([search_term_2], [variables_3])

    assert look_up_4 == ['qz_2', 'qz_1']


# Generated at 2022-06-25 11:40:17.147755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1.run('^qz_.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}), list)
    assert isinstance(lookup_module_1.run('.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}), list)

# Generated at 2022-06-25 11:40:19.675343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=["^qz_.+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:40:24.757717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module_0.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-25 11:40:30.090781
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms = ['^qz_.+']
    variables = {'qz_1': '1', 'qz_2': '2', 'qa_1': '3'}

    ret = lookup_module_0.run(terms, variables)

    assert ret == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:40:36.060789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test fixtures
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    kwargs = {}

    # Exercise the SUT
    result = lookup_module_0.run(terms, variables, **kwargs)

    # Verify the results
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:40:45.962660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, **{})
    lookup_module_0.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, direct={})

# Generated at 2022-06-25 11:40:50.091690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_case_0: Type error test : terms = {'test_case_0': 'test_case_0'}
    with pytest.raises(AnsibleError) as e_info:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms={'test_case_0': 'test_case_0'})
    assert 'Invalid setting identifier' in str(e_info.value)

# Generated at 2022-06-25 11:41:02.249731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["^qz_.+"]

# Generated at 2022-06-25 11:41:10.636740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule.run
    """
    lookup_module_1 = LookupModule()

    # Input params
    terms = ['.*_zone', '.*_location']

    # Check call
    ansible_variables = {'zone': 'us-east-1', 'zone_location': 'us-east-1b'}
    ret = lookup_module_1.run(terms=terms, variables=ansible_variables)

    assert len(ret) == 2
    assert 'zone_location' in ret
    assert 'zone' in ret

# Generated at 2022-06-25 11:41:25.957397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert ret == ['qz_1', 'qz_2']
    lookup_module_0.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, direct={})

# Generated at 2022-06-25 11:41:38.620053
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    d = {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
        "key4": "value4",
        "key5": "value5"
    }

    test_case_1 = lookup_module_0.run(terms="^key.", variables=d)
    test_case_2 = lookup_module_0.run(terms="^key.", variables=d, fail_on_undefined=True)

    # Test Case 1: [key1, key2, key3, key4, key5]
    assert set(test_case_1) == set(["key1", "key2", "key3", "key4", "key5"])

    # Test Case 2: [key1, key2, key3, key4, key5]
   

# Generated at 2022-06-25 11:41:47.913809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    ret = lookup_module_0.run(terms=terms, variables=variables)
    assert ret == ['qz_1', 'qz_2']
    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    ret = lookup_module_0.run(terms=terms, variables=variables)

# Generated at 2022-06-25 11:41:53.453852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
         lookup_module_0 = LookupModule()
         lookup_module_0.run(terms=[],variables='')
    except Exception:
         raise Exception("Failed while trying to call run.")



# Generated at 2022-06-25 11:41:54.846953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = None
    assert result_0 == result_1

# Generated at 2022-06-25 11:42:03.029250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_result = ['qz_1', 'qz_2']
    lookup_module_1 = LookupModule()
    actual_result = lookup_module_1.run(['^qz_.+'], test_vars)
    assert actual_result == expected_result, "%s != %s" % (actual_result, expected_result)

# Generated at 2022-06-25 11:42:06.822430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('^qz_.+') == ['qz_1', 'qz_2']
    assert lookup_module.run('.+') == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run('hosts') == []
    assert lookup_module.run('.+_zone$', '.+_location$') == []

# Generated at 2022-06-25 11:42:15.915098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule(attrs={})
    lookup_module_run_1 = LookupModule(attrs={})
    lookup_module_run_2 = LookupModule(attrs={})
    lookup_module_run_3 = LookupModule(attrs={})

    res = lookup_module_run_0.run(terms=[])
    res = lookup_module_run_1.run(terms=[], variables={})
    res = lookup_module_run_2.run(terms=[], variables={}, **{})
    ret = res
    res = lookup_module_run_3.run(terms=['string0'], variables={'string': 'string0'}, **{})
    ret = res

    return ret

# Generated at 2022-06-25 11:42:20.084418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    x_terms = None
    x_variables = {}
    x_kwargs = {}
    ret_value = lookup_module_1.run(x_terms, x_variables, **x_kwargs)
    print('test_LookupModule_run returned {0}'.format(ret_value))



# Generated at 2022-06-25 11:42:22.136307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = dict(a=1, b=2, c=3)
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['.'], variables=var)


# Generated at 2022-06-25 11:42:38.531049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=["^qz_.+"], variables=None)
    lookup_module_0.run(terms=[".+"], variables=None)
    lookup_module_0.run(terms=["hosts"], variables=None)
    lookup_module_0.run(terms=[".+_zone$"], variables=None)
    lookup_module_0.run(terms=[".+_location$"], variables=None)

# Generated at 2022-06-25 11:42:43.749650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables={'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either', 'qz_2': 'world', 'qz_1': 'hello'}) == ['qz_2', 'qz_1']


# Generated at 2022-06-25 11:42:47.925091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    print("Calling method run of class LookupModule")
    try:
        lookup_module_0.run()
    except Exception as e:
        print(e)
        assert 1 == 0

if __name__ == "__main__":
    # Unit test for method _fail_usage of class LookupModule
    print("\nCalling method _fail_usage of class LookupModule")
    try:
        LookupModule(loader=None, templar=None, variables=None)._fail_usage()
    except Exception as e:
        print(e)
        assert 1 == 0

    # Unit test for method run of class LookupModule
    print("\nCalling method run of class LookupModule")

# Generated at 2022-06-25 11:42:52.011971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})

    assert(ret == ['qz_1', 'qz_2'])

# Generated at 2022-06-25 11:43:00.253388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    vars_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    obj_0 = lookup_module_0.run(terms=terms_0, variables=vars_0)
    assert obj_0 == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:43:04.500930
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Sample data
    terms = ['^qz_.+', 'hosts', '.+_location$']

# Generated at 2022-06-25 11:43:11.134891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [r"^qz_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"};
    expected_result = ['qz_1', 'qz_2']
    parsed_result = LookupModule().run(terms, variables)
    assert parsed_result == expected_result


# Generated at 2022-06-25 11:43:15.928728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(variables=dict(qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either"))
    p = dict(_terms=['^qz_.+'])
    lookup_instance = LookupModule()
    lookup_instance.run(**dict(terms=p['_terms'], **args))

# Generated at 2022-06-25 11:43:26.215408
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    try:
        lookup_module_1.run(terms="^qz_.+", variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    except AnsibleError as e:
        assert True
    else:
        assert False

    try:
        lookup_module_1.run(terms=["^qz_.+"], variables=None)
    except AnsibleError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:43:32.218742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:44:03.807720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['^qz_.+']), list)


# Generated at 2022-06-25 11:44:11.622880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["^qz_.+"]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ["qz_1", "qz_2"]



# Generated at 2022-06-25 11:44:18.504622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['.+']
    variables_0 = {"password": "abc", "username": "abc123"}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result[0] == "username"

# Generated at 2022-06-25 11:44:23.811332
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['.+_zone$', '.+_location$']) is None
# END Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:44:31.668258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    names = lookup_module.run([ '^qz_.+' ])
    assert names == ['qz_1', 'qz_2']
    names = lookup_module.run([ '^qz_.+', '^qa_.+'])
    assert names == ['qz_1', 'qz_2', 'qa_1']



# Generated at 2022-06-25 11:44:35.037751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    lookup_module_0.set_options(var_options=variables_0, direct={})
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert type(ret_0) is list

# Generated at 2022-06-25 11:44:45.061395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
        'key1': 'val1',
        'key2': 'val2',
        'key3': 'val3'
    }
    r = LookupModule().run(['^key.+'],variables=variables, **{})
    assert r == ['key1', 'key2', 'key3']

    r = LookupModule().run(['.+2'],variables=variables, **{})
    assert r == ['key2']

    r = LookupModule().run(['^key1$'],variables=variables, **{})
    assert r == []

    r = LookupModule().run(['^val.+'],variables=variables, **{})
    assert r == []


# Generated at 2022-06-25 11:44:54.976319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_term_0 = []
    test_variables_0 = {}
    test_kwargs_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=test_variables_0, direct=test_kwargs_0)
    test_result_0 = lookup_module_0.run(test_term_0, test_variables_0, **test_kwargs_0)
    assert test_result_0 == []


# Generated at 2022-06-25 11:45:05.184725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    run_result_1 = lookup_module_1.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    run_result_2 = lookup_module_1.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-25 11:45:07.259100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = list()
    variables_0 = dict()
    ret = lookup_module_0.run(terms_0, variables_0)
    msg = "AnsibleError raised"
    assert type(ret) == list

# Generated at 2022-06-25 11:46:19.284943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # TODO: Update module_utils._text.to_text
    assert lookup_module_0.run(['^qz_.+']) == []
    # TODO: Update module_utils._text.to_text
    assert lookup_module_0.run(['^qz_.+', '^qz_.+']) == []
    # TODO: Update module_utils._text.to_text
    assert lookup_module_0.run(['^qz_.+', '^qz_.+', '^qz_.+']) == []
    # TODO: Update module_utils._text.to_text
    assert lookup_module_0.run(['^qz_.+', '^qz_.+', '^qz_.+', '^qz_.+'])

# Generated at 2022-06-25 11:46:26.789272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        '^qz_.+',
    ]
    variables_0 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    _value_0 = lookup_module_0.run(terms_0, variables_0)
    assert _value_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:46:29.352734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = ['a', 'b', 'c']
    res = lookup_module_0.run(terms=vars, variables=None)
    assert res == ['a', 'b', 'c']

# Generated at 2022-06-25 11:46:35.453405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)
    __tracebackhide__ = True
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(terms='^qz_.+', variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I wont show", "qz_": "I wont show either"})
    except Exception as e:
        assert 'No variables available to search' in str(e)
    __tracebackhide__ = True

# Generated at 2022-06-25 11:46:44.333484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # AnsibleModule argument definition.
    options = {
                'terms': [
                    '^qz_.+'
                ]
            }
    # AnsibleModule initialization.
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=options, direct=None)

    # AnsibleModule run.
    result = lookup_module_0.run(options['terms'])

    print("Result: " + str(result))

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:46:53.851956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["^qz_.+", ".+", "hosts", ".+_zone$", ".+_location$"]
    variables_0 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    kwargs_0 = { }
    expected_0 = ["qz_1", "qz_2"]
    actual_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert expected_0 == actual_0

# Run all tests
if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:46:59.633933
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Test case 0
  from ansible.plugins.lookup import LookupBase
  
  lookup_module_1 = LookupBase()
  assert lookup_module_1.run() == []

# Generated at 2022-06-25 11:47:00.649497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['^qz_.+']) == []

# Generated at 2022-06-25 11:47:05.114035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['^(.+)/etc/']
    variables = {}
    variables['git_dest'] = '/home/shivam/ansible_test/test-ansible/roles/role_under_test/files/test.txt'
    variables['ansible_hostname'] = 'shivam-VirtualBox'
    variables['ansible_architecture'] = 'x86_64'
    variables['ansible_userspace_bits'] = '32'
    variables['ansible_nodename'] = 'shivam-VirtualBox'
    variables['ansible_os_family'] = 'Debian'
    variables['ansible_memtotal_mb'] = '1011.56'
    variables['ansible_bios_date'] = '12/01/2006'


# Generated at 2022-06-25 11:47:09.196058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}), list)
