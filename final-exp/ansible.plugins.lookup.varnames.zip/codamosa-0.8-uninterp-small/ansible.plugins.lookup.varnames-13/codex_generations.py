

# Generated at 2022-06-25 11:37:45.907901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables_0 = {'qz_2': 'world', 'qz_1': 'hello', 'qz_': "I won't show either", 'qa_1': "I won't show"}
    terms_0 = ['^qz_.+']
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms_0, variables=variables_0)
    assert type(result) == list
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:37:52.235934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["^qz_.+"]
    variables = {'qz_1': 'hello', '_ansible_no_log': True, 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module_1 = LookupModule()
    assert(lookup_module_1.run(terms, variables=variables)) == ["qz_1", "qz_2"]


# Generated at 2022-06-25 11:38:01.975220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_module_0 = LookupModule()
    variables = dict()
    variables['vm_statistics_interval'] = '90s'
    variables['vm_statistics_percentiles'] = [0.0, 0.25, 0.5, 0.75, 0.9, 0.99]
    variables['vm_statistics_splaytime'] = '90s'
    variables['vm_statistics_zeromessage'] = False
    variables['vm_threads_default'] = '100'
    variables['vm_threads_max'] = '1000'
    variables['vm_threads_max_pool_size'] = '5'
    variables['vm_threads_min_free'] = '50'

# Generated at 2022-06-25 11:38:11.311411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    run_0 = lookup_module_0.run(terms_0, variables_0)
    assert run_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:13.450026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[]) == []

# Generated at 2022-06-25 11:38:20.437979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': 'I wont show either'}
    x = lookup_module_0.run(terms, variables)
    assert x == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:29.236761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    terms = ['^qz_.+']
    res = lookup_module.run(terms=terms, variables=variables)
    assert len(res) == 2
    assert res == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:38:36.754037
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestClass:
        """
        Test class.
        """
        def __init__(self):
            """
            Constructor.
            """
            pass


    lookup_module_inst = LookupModule()
    assert id(lookup_module_inst.run([{}])) == id([])
    assert id(lookup_module_inst.run([123, {}])) == id(['123'])



# Generated at 2022-06-25 11:38:37.605254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True, "Testcase not implemented"

# Generated at 2022-06-25 11:38:42.839444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ["^qz_.+"]
    variables_1 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    ret_1 = lookup_module_1.run(terms_1, variables_1)
    assert ret_1 == ["qz_1", "qz_2"]


# Generated at 2022-06-25 11:38:46.258968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=None, variables=None, kwargs=None)


# Generated at 2022-06-25 11:38:52.209479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:39:01.440406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'a': '1', 'b': '1', 'c': '0'}
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(['^a.+', '^b.+', '^c.+'], var_0)
    if var_1 == ['a', 'b', 'c']:
        return
    else:
        raise RuntimeError("Failed to test method run of class LookupModule")

# Test main function
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:08.872983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_vars = {'qz_1': 'my_hello', 'qz_2': 'my_world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    new_terms = ['^qz_.+']
    my_lm = LookupModule()
    output = my_lm.run(new_terms, my_vars)
    assert output == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:39:17.950421
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    term_1 = '^qz_.+'
    var_1 = lookup_run(lookup_module_1)

    lookup_module_2 = LookupModule()
    term_2 = '.+'
    var_2 = lookup_run(lookup_module_2)
    
    lookup_module_3 = LookupModule()
    term_3 = 'hosts'
    var_3 = lookup_run(lookup_module_3)



# Generated at 2022-06-25 11:39:20.666761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Test will fail until you pass var_0 as an argument.
    assert lookup_run([], var_0=[]) == []


# Generated at 2022-06-25 11:39:31.013168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Tests with no re returned
    data = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup.run(['^no_matching_re'], variables=data) == []
    assert lookup.run([''], variables=data) == []
    assert lookup.run(['\*'], variables=data) == []
    assert lookup.run(['^(?!qz)'], variables=data) == []

    # Tests with re matching
    assert set(lookup.run(['^qz_.+'], variables=data)) == {'qz_1', 'qz_2'}

# Generated at 2022-06-25 11:39:33.307617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    expected = "[u'ret_1']"
    actual = lookup_run(self, varnames, ssl, '^ret_.+')
    assertEqual(actual, expected)


# Generated at 2022-06-25 11:39:42.701410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run("^qz_.+")
    assert var_1 == ['qz_1', 'qz_2', 'qz_']
    var_1 = lookup_module_0.run(".+")
    assert var_1 == []
    var_1 = lookup_module_0.run("hosts")
    assert var_1 == ['inventory_hostnames']
    var_1 = lookup_module_0.run(".+_zone$", ".+_location$")
    assert var_1 == ['dc_zone', 'dc_location']

# Generated at 2022-06-25 11:39:43.532918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:39:52.758812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2)
    if var_2:
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-25 11:39:57.469362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_1 = LookupModule()
  lookup_module_2 = LookupModule()
  lookup_module_3 = LookupModule()

  # TODO: Add testing code for the following cases:
  #   lookup_module_0.run(terms, [])
  #   lookup_module_1.run(terms, [])
  #   lookup_module_2.run(terms, [])
  #   lookup_module_3.run(terms, [])

# Generated at 2022-06-25 11:40:02.310580
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    assert "msg" == lookup_module.run(
        terms="^qz_.+",
        variables={u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    )


# Generated at 2022-06-25 11:40:04.031030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0.startswith(str(list)) == True


# Generated at 2022-06-25 11:40:08.557848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms, variables, **kwargs)
    assert var_1 == list_0


# Generated at 2022-06-25 11:40:12.462835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_var_0 = lookup_module_0.run(lookup_args_0)
    print(lookup_var_0)


# Generated at 2022-06-25 11:40:13.571385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # if var_0 == True:
    assert 2+2 == 4

# Generated at 2022-06-25 11:40:17.023882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'string'
    variables = 'dict'
    kwargs = 'dict'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    assert isinstance(var_0, list)

test_case_0()

# Generated at 2022-06-25 11:40:26.076441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = "I won't show either"
    var_2 = "^qz_.+"
    var_3 = "I won't show"
    var_4 = "hello"
    var_5 = "world"
    var_6 = 'hello'
    var_7 = 'world'
    var_8 = dict()
    var_8['qz_1'] = var_6
    var_8['qz_2'] = var_7
    var_8['qa_1'] = var_3
    var_8['qz_'] = var_1
    var_9 = list()
    var_9.append(var_2)
    var_10 = lookup_module_0.run(var_9, var_8)
    assert var_10

# Generated at 2022-06-25 11:40:27.717971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = run()
    assert result == expected_result

# Generated at 2022-06-25 11:40:40.739901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:40:42.133753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupModule().run(["t"]) == lookup_run(LookupModule(), ["t"]))

# Generated at 2022-06-25 11:40:53.487297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variable_names_0 = list()
    variable_names_1 = list()
    variable_names_2 = list()
    variable_names_3 = list()
    variable_names_4 = list()
    variable_names_5 = list()
    variable_names_6 = list()
    variable_names_7 = list()
    variable_names_8 = list()
    variable_names_9 = list()
    variable_names_0.append('<module_utils.basic.AnsibleModule object=<module_utils.basic.AnsibleModule object>>')
    variable_names_1.append('<module_utils.basic.AnsibleModule object=<module_utils.basic.AnsibleModule object>>')

# Generated at 2022-06-25 11:41:03.774526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variables = {
        '_words': 'hello',
        '_ansible_parsed': False,
        '_ansible_no_log': False,
        '_ansible_debug': False,
    }
    terms = [
        '^qz_.+',
    ]
    # lookup_module_0.run(terms, variables=variables, **{})
    var_0 = lookup_run(lookup_module_0, terms, variables=variables, **{})
    assert var_0 == [], 'Expected empty list, got "%s"' % var_0



# Generated at 2022-06-25 11:41:12.530820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms='^qz_.+',variables={"qz_1":'hello',"qz_2":'world',"qa_1":'I wont show',"qz_":'I wont show either'})
    var_1 = lookup_module_0.run(terms='.+', variables={"qz_1": 'hello', "qz_2": 'world', "qa_1": 'I wont show', "qz_": 'I wont show either'})
    var_2 = lookup_module_0.run(terms='.+', variables={"qz_1": 'hello', "qz_2": 'world', "qa_1": 'I wont show', "qz_": 'I want show'})
    assert var_

# Generated at 2022-06-25 11:41:14.450768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert lookup_module_run.run(terms=terms, variables=variables) == var_0

# Generated at 2022-06-25 11:41:15.671700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    lookup_module_0 = var_0.run('', {}, **{})


# Generated at 2022-06-25 11:41:21.739788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_terms_0 = []
    var_variables_0 = {}
    lookup_module_0 = LookupModule()
    var_return_0 = lookup_module_0.run(var_terms_0, var_variables_0)
    assert var_return_0 == []


# Generated at 2022-06-25 11:41:25.533581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 'value'


# Generated at 2022-06-25 11:41:31.327624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(lookup_module_0)
    assert var_1 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:42:00.065415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['^qz_.+']
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either', '_f': '^qz_.+'}
    kwargs_0 = {'vars': variables_0}
    var_0 = lookup_module_0.run(term_0, **kwargs_0)
    result = {'qz_1', 'qz_2'}
    return var_0 == result


# Generated at 2022-06-25 11:42:05.971444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_0 = lookup_module_0.run(terms,variables=var_0,**kwargs)

test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:42:08.824630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = dict()
    terms = [r'^qz_.+']
    var_0 = lookup_run(lookup_module_0, vars, terms)


# Generated at 2022-06-25 11:42:18.363030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup the environment for testing
    l = LookupModule()
    l.set_options(var_options={'foo': 'bar'}, direct=None)

    # Verify that VariableMatcher is match against the var_options
    assert ['foo'] == l.run('foo')
    assert ['foo'] == l.run(['foo'])

    # Verify that re.compile is used to compile the term
    assert ['foo'] == l.run('f.{1,2}')
    assert ['foo'] == l.run(['f.{1,2}'])

    # Test that single string matches multiple matching terms
    # primarly this verifys that term is forcibly turned into a list
    l.set_options(var_options={'foo': 'bar', 'fie': 'baz'}, direct=None)

# Generated at 2022-06-25 11:42:21.437908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == "", "Incorrect return value for run"


# Generated at 2022-06-25 11:42:22.925164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:42:34.142086
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:42:37.048615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 'qz_1', "Incorrect var_0 value"

# Generated at 2022-06-25 11:42:40.187119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['^qz_.+'], variables=lookup_module_0.set_options(var_options=None, direct=None))

# Generated at 2022-06-25 11:42:44.079547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    vars_terms = {'hello': 'hello world'}
    ret_lookup_run = lookup_module.run(terms=['hello'], variables=vars_terms)
    assert ret_lookup_run == ['hello']


# Generated at 2022-06-25 11:43:27.628928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    res_1 = lookup_module_1.run(terms, variables=variables, **kwargs)
    lookup_module_2 = LookupModule()
    res_2 = lookup_module_2.run(terms, variables=variables, **kwargs)


# Generated at 2022-06-25 11:43:30.630684
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_1 = "^qz_.+"
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, terms=[term_1])
    assert var_1 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:43:36.861492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=["^qz_.+"],variables={"qz_1": "hello","qz_2": "world","qa_1": "I won't show","qz_": "I won't show either"})
    assert(var_0 ==['qz_1', 'qz_2'])
    var_1 = lookup_module_0.run(terms=[".+"],variables={"qz_1": "hello","qz_2": "world","qa_1": "I won't show","qz_": "I won't show either"})
    assert(var_1 ==['qz_1', 'qz_2', 'qa_1', 'qz_'])
    var_2 = lookup_module_

# Generated at 2022-06-25 11:43:41.014056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 11:43:47.124108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
        Args:
            args: Types of args
                name: Type of name
                arg: Type of arg
                options: Type of options
                task_vars: Type of task_vars
                **kwargs: Type of kwargs
        Returns:
            Return a ansible.executor.task_result.TaskResult
    """
    lookup_module_0 = LookupModule()
    var_args = [
        "^qz_.+",
]
    var_kwargs = {
        "vars": {
            "qz_1": "hello",
            "qz_2": "world",
            "qa_1": "I won't show",
            "qz_": "I won't show either",
            "qy_1": "I will show",
        },
    }
    var_

# Generated at 2022-06-25 11:43:48.607599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:43:50.079610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    varnames = LookupModule()
    expected = 'variable_name'
    actual = varnames.run(['variable_name'], {'variable_name': 'test'})
    assert actual == [expected]


# Generated at 2022-06-25 11:43:54.194119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert not hasattr(lookup_module_0, 'run')
    lookup_module_0.run(terms, variables=None, )


# Generated at 2022-06-25 11:43:58.821350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variable_names = ["foo", "bar", "baz", "barfoo", "42", "foo42"]
    variables = {"foo": "foo", "bar": "bar", "baz": "baz", "barfoo": "barfoo", "42": "42", "foo42": "foo42"}
    lookup_module_0.run(terms=variable_names, variables=variables)

# Generated at 2022-06-25 11:44:03.835901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'network'
    if lookup_module_0.run(terms_0) != 'lookup_variable(network)':
        var = False



# Generated at 2022-06-25 11:45:33.238422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:45:35.267478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(terms=None, variables=None, **kwargs)


# Generated at 2022-06-25 11:45:40.119466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert not (var_0)


# Generated at 2022-06-25 11:45:43.108517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == None 


# Generated at 2022-06-25 11:45:45.841843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var1 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    var2 = [qz_1, qz_2]
    lookup_mod = LookupModule()
    result = lookup_mod.run(['^qz_.+'], var1)
    assert result == var2


# Generated at 2022-06-25 11:45:46.886289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert not var_0


# Generated at 2022-06-25 11:45:49.076857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Basic test to check if method run defined in class LookupModule returns a list

  lookup_module_1 = LookupModule()
  var_1 = lookup_run(lookup_module_1)
  assert isinstance(var_1, list)


  lookup_module_2 = LookupModule()
  var_2 = lookup_run(lookup_module_2)
  assert var_1 == var_2



# Generated at 2022-06-25 11:45:55.202549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    lookup_module_0.run(terms_0, variables_0, kwargs_0)


if __name__ == '__main__':
    __main__()

# Generated at 2022-06-25 11:45:56.241428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()
    lookup_mock.run("test_var")


# Generated at 2022-06-25 11:46:01.647607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    var = lookup.run([],variables='',**'kwargs')