

# Generated at 2022-06-25 11:37:48.665676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load module and test cases
    lookup_module_0 = LookupModule()

    # Load fixtures

# Generated at 2022-06-25 11:37:55.215873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}
    assert lookup_module_0.run(terms, variables) == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:38:00.407089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({u'direct': {u'_ansible_verbosity': 3, u'_ansible_version': u'2.8.0.dev0'}})
    terms = ['']
    variables = {}
    lookup_module_0.run(terms, variables)
    terms = ['']
    variables = {}
    lookup_module_0.run(terms, variables)



# Generated at 2022-06-25 11:38:05.857993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    data = {'tmpvar1': 'some value', 'tmpvar2': 'some other value'}
    terms = ['.+']
    lookup_module_0.run(terms, variables=data)


# Generated at 2022-06-25 11:38:13.895069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=["^qz_.+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    lookup_module.run(terms=[".+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    lookup_module.run(terms=["hosts"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})

# Generated at 2022-06-25 11:38:24.500180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'_ansible_verbosity': 0,
                                 '_ansible_no_log': False,
                                 '_ansible_debug': False,
                                 '_ansible_remote_tmp': '/home/vagrant/.ansible/tmp',
                                 '_ansible_keep_remote_files': True})

    lookup_module_0.set_context(dict({'_ansible_syslog_facility': 'LOG_USER',
                                      '_ansible_syslog_ident': 'ansible-lookup',
                                      '_ansible_socket': None,
                                      '_ansible_verbose_always': False}))
    terms_0 = [
        '^qz_.+'
    ]

# Generated at 2022-06-25 11:38:28.287688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    ret = lookup_module_1.run([])
    assert ret == []


# Generated at 2022-06-25 11:38:29.388150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()



# Generated at 2022-06-25 11:38:36.754052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables=variables)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:40.179550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    try:
        lookup_module_0.run(terms_0, variables_0)
    except AnsibleError as e:
        assert e.message == 'No variables available to search'


# Generated at 2022-06-25 11:38:45.972059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_module_0.run(terms=[term], variables=variables) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:49.375448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    variables_0 = {'qa_1': 'I won\'t show', 'qz_2': 'world', 'qz_1': 'hello', 'qz_': 'I won\'t show either'}
    ret_0 = lookup_module_0.run(terms=terms_0, variables=variables_0)
    assert ret_0 == []


# Generated at 2022-06-25 11:38:52.241781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'i wont show', 'qz_': 'i wont show either'}
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:59.378462
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    data_0 = {
            '1': '1',
             }
    terms_0 = ['1']

    lookup_module_0 = LookupModule()

    # Ensure that `run` function of class `LookupModule` returns `list` 
    assert isinstance(lookup_module_0.run(terms=terms_0, variables=data_0), list)

# Generated at 2022-06-25 11:39:09.401468
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    terms_1 = ['^qz_.+']
    variables_1 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    result = lookup_module_1.run(terms=terms_1, variables=variables_1)
    assert result == ['qz_1', 'qz_2']

    terms_2 = ['.+']

    result = lookup_module_1.run(terms=terms_2, variables=variables_1)
    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    terms_3 = ['hosts']


# Generated at 2022-06-25 11:39:14.244302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'name1': {'name2': 'value'}, 'name2': 'value2'}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct={})

    result = lookup_module_0.run(['name1'], variables=variables)

    assert(result == ['name1'])


# Generated at 2022-06-25 11:39:20.540876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_run_0 = lookup_module_0.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except Exception as e:
        assert False, "You can't call lookup module without passing correct values for each required parameter: %s" % to_native(e)

    assert True, "You can call lookup module with passing correct values for each required parameter"


# Generated at 2022-06-25 11:39:24.540259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'a': 1, 'b': 2, 'c': 3}
    lookup_module = LookupModule()
    print(lookup_module.run(['a'], variables=vars))

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:32.055554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '^qz_.+'
    variables =  {
      'qz_1': 'hello',
      'qz_2': 'world',
      'qa_1': "I won't show",
      'qz_': "I won't show either"
    }
    kwargs = {}
    expected_result = ['qz_1', 'qz_2']
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == expected_result


# Generated at 2022-06-25 11:39:40.718532
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("*** test_LookupModule_run")

    lookup_module_1 = LookupModule()

    terms = [
        '^qz_.+'
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    expected_value = [
        'qz_1',
        'qz_2'
    ]
    value = lookup_module_1.run(terms, variables)
    if value != expected_value:
        print("Error.  Expected:\n{}\n\nReceived:\n{}\n".format(expected_value, value))
    else:
        print("Pass")


# Generated at 2022-06-25 11:39:52.848879
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms = [
        '^qz_.+'
    ]

    variables = {
        u'qa_1': u'I won\'t show',
        u'qz_': u'I won\'t show either',
        u'qz_2': u'world',
        u'qz_1': u'hello'
    }

    _kwargs = None

    try:
        result = lookup_module_0.run(terms, variables, **_kwargs)
    except Exception as e:
        print("Exception when calling LookupModule.run:", e)
        assert False

    assert result[0] == u'qz_2'
    assert result[1] == u'qz_1'

# Generated at 2022-06-25 11:39:55.231373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert '_value' in lookup_module_0.run('_terms', 'variables', __ansible_vars__='__ansible_vars__')

# Generated at 2022-06-25 11:39:58.750180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __builtin__
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    assert True

# Generated at 2022-06-25 11:40:03.033553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['^qz_.+'])
    # It is a list of items
    assert isinstance(result, list)
    # It should contain items
    assert len(result) > 0

# Generated at 2022-06-25 11:40:12.815268
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        ".*",
        ".*_zone$",
        ".*_region$"
    ]

    ansible_variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
        "qz_zone1": "east",
        "qz_zone2": "west",
        "qz_region1": "north",
        "qz_region2": "south"
    }

    lookup_module = LookupModule()
    result = lookup_module.run(terms, ansible_variables)
    assert result is not None
    assert len(result) == 4
    assert "qz_zone1" in result

# Generated at 2022-06-25 11:40:16.621079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    search_string = '^qz_.+'
    ret = lookup_module_0.run(search_string)
    assert isinstance(ret, list)
    assert 'qz_1' in ret
    assert 'qz_2' in ret
    assert 'qa_1' not in ret
    assert 'qz_' not in ret


# Generated at 2022-06-25 11:40:24.412639
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_name = 'test_module_name'
    lookup_module_as = 'test_module_as'
    lookup_module_seq = 'test_module_seq'

    terms_add = 'test_terms_add'
    terms_sub = 'test_terms_sub'

    # initialize a LookupModule object
    lookup_module_obj = LookupModule()

    # run test
    lookup_module_result = lookup_module_obj.run(terms_add, terms_sub)

    # check results
    assert lookup_module_result == lookup_module_seq


# Generated at 2022-06-25 11:40:34.224459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variables = {'var2': 'two', 'var1': 'one'}
    terms_0 = ['', '']
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables, **kwargs_0) == list()
    terms_1 = [None, None]
    kwargs_1 = {}
    assert lookup_module_0.run(terms_1, variables, **kwargs_1) == list()
    terms_2 = ['.*', '', '']
    kwargs_2 = {}
    assert lookup_module_0.run(terms_2, variables, **kwargs_2) == list()
    terms_3 = ['', '.*', '']
    kwargs_3 = {}
    assert lookup_module_

# Generated at 2022-06-25 11:40:45.827733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test: Create an empty dict
    # Expect: An error
    try:
        lookup_module_1.run(["test_0"])
    except AnsibleError as e:
        print("test_0: PASS")

    # Test: Create a dict with a non-string key
    # Expect: An error
    try:
        lookup_module_1.run([{}])
    except AnsibleError as e:
        print("test_1: PASS")

    # Test: Create a dict with a non-string value
    # Expect: An error

# Generated at 2022-06-25 11:40:49.509588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=["^qz_.+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ["qz_1", "qz_2"]


# Generated at 2022-06-25 11:40:57.422881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run('^qz_.+')

    assert result == [
        'qz_1',
        'qz_2',
    ]


# Generated at 2022-06-25 11:41:08.437372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0) is LookupModule

    lookup_module_1 = LookupModule()
    assert type(lookup_module_1) is LookupModule

    lookup_module_2 = LookupModule()
    assert type(lookup_module_2) is LookupModule

    lookup_module_3 = LookupModule()
    assert type(lookup_module_3) is LookupModule

    lookup_module_4 = LookupModule()
    assert type(lookup_module_4) is LookupModule

    lookup_module_5 = LookupModule()
    assert type(lookup_module_5) is LookupModule

    lookup_module_6 = LookupModule()
    assert type(lookup_module_6) is LookupModule

    lookup_

# Generated at 2022-06-25 11:41:14.941105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test environment
    lookup_module_0 = LookupModule()
    lookup_module_0.run = MagicMock(return_value = 'A')
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 'A'
    # Teardown test environment


# Generated at 2022-06-25 11:41:19.259916
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test for valid search term
    var_0 = None
    var_a = lookup_module_0.run(var_0)

    # Test for invalid search term
    var_1 = 'bad_term'
    var_b = lookup_module_0.run(var_1)

    # Test no variables available
    var_2 = None
    var_c = lookup_module_0.run(var_2)

# Generated at 2022-06-25 11:41:20.886113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['^qz_.+'])


test_LookupModule_run()

# Generated at 2022-06-25 11:41:26.086752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run(self, terms, variables=None, **kwargs)
    lookup_module_0 = LookupModule()
    variables = {}
    terms = ['^qz_.+']
    var_0 = lookup_module_0.run(terms, variables)
    assert var_0 == []


# Generated at 2022-06-25 11:41:31.708471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    return var_0

# Assertion to ensure that the method run of class LookupModule returns a list

# Generated at 2022-06-25 11:41:37.858588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'ansible_facts': {'ansible_distribution_version': '12.04'}})
    var_0 = lookup_module_0.run(['^ansible_distribution_version'])
    assert var_0[0] == 'ansible_distribution_version'
    assert len(var_0) == 1


# Generated at 2022-06-25 11:41:41.959209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No instance created; test of an abstract method
    pass



# Generated at 2022-06-25 11:41:43.674937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:41:56.136413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '^qz_.+'
    var_0 = lookup_run(lookup_module_0, terms=terms_0)
    assert var_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:42:05.078674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    if var_0 is None:
        var_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    if var_0 is None:
        var_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    if var_0 is None:
        var_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    if var_0 is None:
        var_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_

# Generated at 2022-06-25 11:42:09.592031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['localhost'], variables=None, **{'wantlist': False})
    lookup_module_0.run(terms=[], variables={'localhost': {}}, **{'wantlist': False})
    lookup_module_0.run(terms=[], variables={'localhost': {}}, **{'wantlist': False})

# Generated at 2022-06-25 11:42:12.679722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms_0,variables_0) == ret_0, "Unable to run"

test_case_0()

# Generated at 2022-06-25 11:42:20.599592
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check with '^qz_.+' as term and variables ={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    assert lookup_module_run('^qz_.+',{'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})==['qz_1', 'qz_2']

    # Check with '.' as term and variables ={'key1': 'value', 'key2': 'value'}
    assert lookup_module_run('.',{'key1': 'value', 'key2': 'value'})==['key1', 'key2']



# Generated at 2022-06-25 11:42:21.631842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module.run(terms, variables=None, **kwargs)
    assert result == ret

# Generated at 2022-06-25 11:42:23.046142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)


# Generated at 2022-06-25 11:42:26.970124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = '^qz_.+'
    var_1 = lookup_run(lookup_module_1, term_1)
    assert var_1 == 0


# Generated at 2022-06-25 11:42:29.402772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()


# Generated at 2022-06-25 11:42:31.731856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:43:01.648699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module_0 = LookupModule()
    try:
        result = lookup_module_0.run('^qz_.+', var_0)
        assert result == ['qz_1', 'qz_2']
    except AnsibleFailure as e:
        assert e.message == 'Invalid setting identifier, "^qz_.+" is not a string, it is a <class \'str\'>'
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

# Generated at 2022-06-25 11:43:11.163395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    test_dir = './test/integration/lookup_plugins'
    lookup_module = LookupModule()
    lookup_module._load_name = 'vars.yml'
    lookup_module._basedir = './lookup_plugins'

    lookup_module.set_options(direct={'_terms' : ['^qz_.+']})
    # Exercise
    result = lookup_module.run(lookup_module.get_options()['_terms'], lookup_options={'file' : 'test/integration/lookup_plugins/varnames.yml'})

    # Verify
    expected_result = ["qz_1", "qz_2"]
    assert result == expected_result, 'Expected %s, but got %s' % (str(expected_result), result)

# Generated at 2022-06-25 11:43:15.407306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['', '']
    lookup_module_1 = LookupModule()

    try:
        lookup_module_1.run(terms)
    except AnsibleError as e:
        print('Expected AnsibleError exception')
        assert 'No variables available to search' in str(e)


# Generated at 2022-06-25 11:43:18.138782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = []
    variables_1 = {}

    return_value_1 = lookup_module_1.run(terms=term_1, variables=variables_1)
    assert return_value_1 == []


# Generated at 2022-06-25 11:43:28.327762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # setup()
    #
    # mock setup
    lookup_module_0_mock_setup = Mock()
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options = lookup_module_0_mock_setup
    lookup_module_0_mock_run_input = {
        'terms': [
            "^qz_.+"
        ],
        'variables': {
            'qz_1': "hello",
            'qz_2': "world",
            'qa_1': "I won't show",
            'qz_': "I won't show either",
        }
    }

# Generated at 2022-06-25 11:43:30.174984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run('test_expr')
    assert var_1 is None


# Generated at 2022-06-25 11:43:36.538580
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #  AllKeysDict is used as a mock of variables to test the
    #  lookup module's run method.
    from ansible.module_utils.hashivault import AllKeysDict

    mock_variables = AllKeysDict.fromkeys(
        [
            "qz_1", "qz_2", "qa_1", "qz_"
        ]
    )
    mock_variables.update(
        {
            "qz_1": {
                "value": "hello"
            }
        }
    )
    mock_variables.update(
        {
            "qz_2": {
                "value": "world"
            }
        }
    )

# Generated at 2022-06-25 11:43:41.419562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('^qz_.+')
    assert var_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:43:46.403394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert ret_0 == result_0

test_case_0()

# Generated at 2022-06-25 11:43:47.710140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = 'qz_.+'
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == []


# Generated at 2022-06-25 11:44:43.413723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
	

# Generated at 2022-06-25 11:44:45.028931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:44:51.885467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=str(), variables=str())

# Generated at 2022-06-25 11:44:56.288907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = '^qz_.+'
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    lookup_module_1 = LookupModule()
    out_1 = lookup_module_1.run(terms, variables)
    assert out_1 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:45:00.297048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=terms)
    assert result == expected_result

# Generated at 2022-06-25 11:45:03.589949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'qa_1': 'I won\'t show', 'qz_1': 'hello', 'qz_2': 'world', 'qz_': 'I won\'t show either'}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['^qz_.+'], variables=var_0)



# Generated at 2022-06-25 11:45:11.068728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['^qz_.+'], ['["qz_1":hello,"qz_2":world,"qa_1":"I won\'t show","qz_":"I won\'t show either"]'])
    assert var_0 == '["qz_1","qz_2"]'
    var_1 = lookup_module_0.run(['.+'], ['["qz_1":hello,"qz_2":world,"qa_1":"I won\'t show","qz_":"I won\'t show either"]'])
    assert var_1 == '["qz_1","qz_2","qa_1","qz_"]'

# Generated at 2022-06-25 11:45:17.086706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['q1_', 'q2_']
    var_0 = {'var_0': 'val_0', 'q2_': 'q2_', 'q1_': 'q1_'}
    res_0 = lookup_module_0.run(term_0, var_0)
    assert res_0 == ['q1_', 'q2_']

# Generated at 2022-06-25 11:45:18.487074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)


# Generated at 2022-06-25 11:45:21.118116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:47:25.669143
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Needs to run as an actual test to
    # have self.set_options available

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:47:28.336160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == 'test'

# vim: set sts=4 sw=4 ts=4 expandtab ft=python:

# Generated at 2022-06-25 11:47:30.237742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run("^qz_.+")
    assert var == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:47:31.387047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()

# Generated at 2022-06-25 11:47:32.761360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert var == [], "Incorrect values returned"


# Generated at 2022-06-25 11:47:34.141997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance_0 = LookupModule()
    var_1 = lookup_run(lookup_module_instance_0)
