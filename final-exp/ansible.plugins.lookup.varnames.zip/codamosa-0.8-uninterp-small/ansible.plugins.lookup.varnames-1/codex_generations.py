

# Generated at 2022-06-25 11:37:40.409877
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    terms = ['^qz_.+']
    variables = {u'qz_1': 'hello', u'qz_2': 'world', u'qa_1': "I won't show", u'qz_': 'I won\'t show either'}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables) == [u'qz_1', u'qz_2']

    # Test case 2
    terms = ['.+']
    variables = {u'qz_1': 'hello', u'qz_2': 'world', u'qa_1': "I won't show", u'qz_': 'I won\'t show either'}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run

# Generated at 2022-06-25 11:37:45.853879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ 'http_proxy' ]
    variables = {'http_proxy': 'http://helloworld.com'}
    ret = lookup_module.run(terms, variables=variables)
    assert ret == ['http_proxy']


# Generated at 2022-06-25 11:37:46.415406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:37:57.092848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = { 
        "a1_host": "host1",
        "b1_host": "host2",
        "a2_host": "host3"
        }
    terms = [
        "^a.+",
        "host$"
        ]

    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, vars)
    if len(result) < 3:
        raise AssertionError("Expected %d, but got %d" % (3, len(result)))

# Generated at 2022-06-25 11:38:09.164810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic

    # Create a new argument spec
    argument_spec = basic.AnsibleModule.argument_spec()
    argument_spec.update(dict(
        _terms=dict(required=True, type='list'),
    )
    )

    # Create a new module object
    module_0 = basic.AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )
    # Get a handle on the Ansible variables
    try:
        variables = module_0.params['_ansible_runtime']['variables']
    except:
        variables = None

    # Assign values for the parameters

# Generated at 2022-06-25 11:38:19.337162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["qz_", "qa_"]
    variables_0 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    assert lookup_module_0.run(terms=terms_0, variables=variables_0) == ["qz_1", "qz_2", "qa_1", "qz_"]

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:38:24.797443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == []

# Generated at 2022-06-25 11:38:30.282765
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    variables = {'key': 'value'}
    terms = ['^key$']

    # Invoke method
    #
    # Returns:
    #   list: List of the variable names requested.
    #
    result = lookup_module_1.run(terms, variables)

    assert result == ['key']

# Generated at 2022-06-25 11:38:36.911472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_var = LookupModule()
    terms = [u'qz_1', u'qz_2', u'qa_1', u'qz_', u'^qz_.+']
    ret = ['qz_1', 'qz_2']
    assert lookup_module_var.run(terms) == ret

# Generated at 2022-06-25 11:38:44.638597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['qz_1', 'qz_2'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    lookup_module_0.run(terms=['qz_2'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-25 11:38:52.048504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(lookup_module_0)
    assert var_1 == "LookupModule"


# Generated at 2022-06-25 11:38:54.235863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:38:56.422395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:38:59.042520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)



# Generated at 2022-06-25 11:39:03.612914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 11:39:14.076875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var1_0 = ""
    var1_1 = []
    var1_2 = {
    }
    var2_0 = ""
    var2_1 = []
    var2_2 = {
    }
    var3_0 = ""
    var3_1 = []
    var3_2 = {
    }
    var3_3 = ""
    var3_4 = []
    var3_5 = {
    }


# Generated at 2022-06-25 11:39:18.619374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables)

    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:20.697720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:39:27.643487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_2 = lookup_module_1.run('', {'hosts': 'localhost'})
    assert var_2 == []

    lookup_module_2 = LookupModule()
    assert lookup_module_2.run({}, {}) == None

    lookup_module_3 = LookupModule()
    assert lookup_module_3.run({'1':{}, '2':{}}) == None


# Testing with pytest

# Generated at 2022-06-25 11:39:30.614030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert var_1 == True

# Mock import for unittest
import unittest.mock as mock

# Generated at 2022-06-25 11:39:38.620879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    options_0 = []
    var_0 = LookupModule(options_0)
    var_1 = var_0.run()


# Generated at 2022-06-25 11:39:42.152650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_run_fqn(lookup_module_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:50.124209
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Test case for look_up_variables_in_playbook()

# Generated at 2022-06-25 11:39:54.300895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms=['^qz_.+'],variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert var_1 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:40:02.506288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1':'hello',
                 'qz_2':'world',
                 'qa_1':"I won't show",
                 'qz_':"I won't show either"}
    var_options = {'var_options':variables}
    direct = {}
    lookup_module.set_options(**var_options)
    assert lookup_module.run(terms, **direct) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:40:04.424730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[])


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:40:06.247569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:40:15.733109
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	lookup_module_0 = LookupModule()
	term_0 = "^qz_.+"
	variables_0 = dict()
	variables_0['qz_1'] = "hello"
	variables_0['qz_2'] = "world"
	variables_0['qa_1'] = "I won't show"
	variables_0['qz_'] = "I won't show either"
	kwargs_0 = dict()
	return_value_0 = lookup_module_0.run(terms=[term_0], variables=variables_0, **kwargs_0)
	print(return_value_0)

	lookup_module_1 = LookupModule()
	term_1 = ".+"
	variables_1 = dict()

# Generated at 2022-06-25 11:40:25.981621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    import re
    lookup_module_0 = LookupModule()
    # Test exception raised for missing required kwargs
    try:
        lookup_module_0.run()
    except Exception as e:
        assert(isinstance(e, AnsibleError))
    # Test exception raised for invalid kwargs
    try:
        lookup_module_0.run(variables=None)
    except Exception as e:
        assert(isinstance(e, AnsibleError))
    # Test exception raised for missing required kwargs
    try:
        lookup_module_0.run(variables={})
    except Exception as e:
        assert(isinstance(e, AnsibleError))
    # Test exception raised for invalid kwargs


# Generated at 2022-06-25 11:40:29.380594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run('^qz_.+', vars(lookup_module_0)) == ['qz_2', 'qz_1']

# Generated at 2022-06-25 11:40:45.079168
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:40:49.567662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_x = 'foo'
    var_y = 'bar'
    var_z = 'bla'
    var_1 = {'foo': 'bar', 'Foo': 'BAR', 'bla': 'foo', 'blub': 'bla', 'name': 'blub'}
    term_1 = 'name'
    term_2 = 'bla'
    term_3 = '^Fo'
    lookup_module_1.run([term_1, term_2, term_3], var_1)
    lookup_module_1.run([term_1, term_2, term_3], var_1, bar=var_z)

# Generated at 2022-06-25 11:40:54.177178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms='^qz_1$')
    assert len(var_0) == 1


# Generated at 2022-06-25 11:41:05.805707
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MyMock(object):
        def __init__(self, returns_0):
            self.returns_0 = returns_0

        def __call__(self, *args, **kwargs):
            return self.returns_0

    class MyMock2(object):
        def __init__(self, returns_0):
            self.returns_0 = returns_0

        def __call__(self, *args, **kwargs):
            return self.returns_0


    class MyMock3(object):
        def __init__(self, returns_0):
            self.returns_0 = returns_0

        def __call__(self, *args, **kwargs):
            return self.returns_0



# Generated at 2022-06-25 11:41:08.496037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:41:12.920590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = lookup_module_0.run()
    assert int_0 is None

# Generated at 2022-06-25 11:41:14.816171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:41:15.608961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 11:41:19.788041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()

    var_1 = lookup_run(lookup_module_1)
    var_2 = lookup_run(lookup_module_2)
    var_3 = lookup_run(lookup_module_3)
    var_4 = lookup_run(lookup_module_4)



# Generated at 2022-06-25 11:41:28.277478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # AnsibleError fixtures for test case
    ansible_error_0 = None
    ansible_error_1 = None
    ansible_error_2 = None

    # AnsibleError fixture for test case
    ansible_error_3 = None

    # AnsibleError fixtures for test case
    ansible_error_4 = None
    ansible_error_5 = None
    ansible_error_6 = None

    # AnsibleError fixture for test case
    ansible_error_7 = None

    # AnsibleError fixture for test case
    ansible_error_8 = None

    # AnsibleError fixtures for test case
    ansible_error_9 = None
    ansible_error_10 = None
    ansible_error_11 = None

    # AnsibleError fixture for test case
    ansible_error_12 = None

# Generated at 2022-06-25 11:41:50.244594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])


# Generated at 2022-06-25 11:41:51.998052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result_0 = run(terms, variables=None)
    result_1 = run(terms, variables=vars)



# Generated at 2022-06-25 11:41:58.982170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call method run of LookupModule
    vars_0 = {'any': {'str0': 'str1', 'str2': 'str3', 'str4': 'str5'}}
    res_0 = lookup_module_0.run(terms_0, variables=vars_0)


test_case_0()



# Generated at 2022-06-25 11:42:02.872554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = {}
    var_1["test_var"] = "test_val"
    var_2 = []
    var_2.append("^qz_.+")
    lookup_module_1.run(var_2, var_1)

# Generated at 2022-06-25 11:42:04.031873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:42:12.507503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("[+] Unit test for method run() of class LookupModule")
    lookup_module = LookupModule()
    var = lookup_module.run(['^qz_.+'], {'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"})
    print("[+] Running test case 0")
    assert var ==  ['qz_1', 'qz_2']
    print("[+] Running test case 1")
    var = lookup_module.run(['.+'], {'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"})

# Generated at 2022-06-25 11:42:16.807278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(loader, terms, variables)
    assert isinstance(var_1, list)
    assert var_1 == ['qz_1', 'qz_2']

test_LookupModule_run()

# Generated at 2022-06-25 11:42:17.890275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1


# Generated at 2022-06-25 11:42:23.971526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = "^qz_.+"
    var_2 = {
        "qz_2": "world",
        "qz_1": "hello",
    }
    var_3 = {
        "qz_2": "world",
        "qz_1": "hello",
    }
    var_4 = {
        "qz_2": "world",
        "qz_1": "hello",
    }
    lookup_module_0.run([var_1], var_2, variables=var_3, _ansible_check_mode=var_4)
    assert lookup_module_0 == lookup_module_0


# Generated at 2022-06-25 11:42:35.496365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Verify if test case 0 is working
    if test_case_0() != ("value_0"):
        print("Failure: test_case_0() returned value other then expected value")

    # Verify if test case 1 is working
    if test_case_1() != ("value_1"):
        print("Failure: test_case_1() returned value other then expected value")

    # Verify if test case 2 is working
    if test_case_2() != ("value_2"):
        print("Failure: test_case_2() returned value other then expected value")

    # Verify if test case 3 is working
    if test_case_3() != ("value_3"):
        print("Failure: test_case_3() returned value other then expected value")

    # Verify if test case 4

# Generated at 2022-06-25 11:43:17.475577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for term in LookupModule.run:
        assert isinstance(term, string_types) is True


# Generated at 2022-06-25 11:43:19.286541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(['test_string'])
    assert type(var) == list

# Generated at 2022-06-25 11:43:23.645082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    lookup_module_0.run(terms=terms, variables=variables, **kwargs)

# Generated at 2022-06-25 11:43:25.503835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)

# Generated at 2022-06-25 11:43:28.611439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:43:30.484037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert var_1 is None


# Generated at 2022-06-25 11:43:32.313775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)



# Generated at 2022-06-25 11:43:38.483022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.' 'def']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:43:43.113864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    # Set parameter terms.
    # Call method run.
    # Assert: expected_lookup_results == lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:43:44.715950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 is not None


# Generated at 2022-06-25 11:45:12.925514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:45:15.478235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:45:20.121559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = lookup_run(LookupModule())

# Generated at 2022-06-25 11:45:29.707331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['qz_1', 'qz_2'], "Expected ['qz_1', 'qz_2'], but got %s" % var_0
    var_0 = lookup_run(lookup_module_0, variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'})
    assert var_0 == ['qz_1', 'qz_2'], "Expected ['qz_1', 'qz_2'], but got %s" % var_0

# Generated at 2022-06-25 11:45:34.294017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = dict()
    lookup_module_0 = LookupModule()
    terms_0 = dict()
    var_0 = lookup_module_0.run(terms_0, variables=vars_0)

# Generated at 2022-06-25 11:45:35.835319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == None


# Generated at 2022-06-25 11:45:38.004718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible']
    variables = {'ansible': 'Ansible'}
    ret = lookup_run(lookup_module, terms, variables=variables)
    
    assert ret == ['ansible']


# Generated at 2022-06-25 11:45:38.983463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:45:39.628534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:45:42.912044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0['result'] == 'success'
    assert var_0['msg'] == 'The run method worked'