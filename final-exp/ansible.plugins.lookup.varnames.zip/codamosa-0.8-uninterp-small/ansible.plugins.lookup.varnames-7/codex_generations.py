

# Generated at 2022-06-25 11:37:40.360843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run('foo'), 'foo'

# Generated at 2022-06-25 11:37:43.893107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # First test with one search term
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']
    # More search terms
    terms = ['^qz_.+', '^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I will show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:37:50.789022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options={'ansible_host': 'localhost', 'ansible_port': '22', 'ansible_user': 'test'})

    assert lookup_obj.run(['ansible_.+'], variables={'ansible_host': 'localhost', 'ansible_port': '22', 'ansible_user': 'test'}, **{}) == ['ansible_host', 'ansible_port', 'ansible_user']
    assert lookup_obj.run(['ansible_host', 'ansible_user'], variables={'ansible_host': 'localhost', 'ansible_port': '22', 'ansible_user': 'test'}, **{}) == ['ansible_host', 'ansible_user']

# Generated at 2022-06-25 11:37:57.092888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['^qz_.+']
  variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
  kwargs = {'variable': 'value'}
  lookup_module = LookupModule()

  check = ['qz_1', 'qz_2']
  assert(lookup_module.run(terms, variables, **kwargs) == check)

# Generated at 2022-06-25 11:38:06.077745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms = [
    "^qz_.+",
    ".+",
    "hosts",
    ".+_zone$",
    ".+_location$",
  ]
  variables = {
    "qz_1": "hello",
    "qa_1": "I won't show",
    "qz_2": "world",
    "qz_": "I won't show either",
  }
  ret = lookup_module_0.run(terms, variables)
  assert ret == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:38:12.738411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['^qz_.+', '^qz_.+']
    variables_0 = {'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'qz_1': 'hello'}
    direct_0 = {}
    result_0 = ['qz_2', 'qz_', 'qz_1']
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables_0, **direct_0)
    assert result_0 == lookup_module_0._ret

# Generated at 2022-06-25 11:38:18.918539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for lookup_module_0.run method
    x = vars(__builtins__).copy()
    x.update(globals())
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[], variables=x)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:38:29.255345
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    import re

    variable_name = '_test_var'
    variable_values = {'a': 10, 'b': 20}
    variable_data = {variable_name: variable_values}
    word = 'a'

    lookup_module = LookupModule()

    lookup_module.set_options(var_options=variable_data, direct={})
    result = lookup_module.run(terms=[word], variables=variable_data)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == word

# End of test for

# Generated at 2022-06-25 11:38:40.297670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+', 'hosts', '.+_zone$', '.+_location$', '^qz_.+', 'hosts', '.+_zone$', '.+_location$', '^qz_.+', 'hosts', '.+_zone$', '.+_location$']
    variables_0 = {'qz_3': 'I won\'t show', 'qz_': 'I won\'t show either', 'qz_1': 'hello', 'qz_7': 'nothing', 'qz_2': 'world', 'qa_1': 'I won\'t show'}
    kwargs_0 = dict()
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:38:42.832657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'testvar_name': 'testvar_value'}, direct=None)
    assert lookup_module_0.run(terms=['testvar_name'], variables=None) == ['testvar_name']

# Generated at 2022-06-25 11:38:52.530180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    kwargs = {"direct":True, "variable_name":"test", "variable_value":"Test Module"}
    retvalue = lookup_module_0.run(terms=["qz_1"], variables={"qz_1":"hello", "qz_2":"world", "qa_1":"I won't show", "qz_":"I won't show either"}, **kwargs)
    print(retvalue)

    lookup_module_1 = LookupModule()
    kwargs = {"direct": True, "variable_name": "test", "variable_value": "Test Module"}

# Generated at 2022-06-25 11:39:00.033303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '^qz_.+'
    variables_0 = {"qz_2": "world", "qa_1": "I won't show", "qz_1": "hello", "qz_": "I won't show either"}
    assert lookup_module_0.run(term_0, variables_0) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:11.456872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )
    lookup_module_0.run( terms=[ "string_types" ] )

# Generated at 2022-06-25 11:39:18.591630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms="^qz_.+") == ['qz_1', 'qz_2']
    assert lookup_module.run(terms=".+") == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(terms="hosts") == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(terms=".+_zone$") == []

# Generated at 2022-06-25 11:39:26.471985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:27.733842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 11:39:31.924571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:35.171100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = dict()
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:39:41.021048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = '^qz_.+'
    variables_1 = dict()
    variables_1['qz_1'] = 'hello'
    variables_1['qz_2'] = 'world'
    variables_1['qa_1'] = "I won't show"
    variables_1['qz_'] = "I won't show either"
    kwargs_1 = dict()
    result = lookup_module_1.run(term_1, variables_1, **kwargs_1)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:48.125845
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test a couple of valid and invalid patterns
    assert lookup_module_0.run(["^qz_.+"]), "Valid Regex pattern"
    assert not lookup_module_0.run(["Invalid pattern"]), "Invalid Regex pattern"


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:53.787507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:39:55.688552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run the method run of class LookupModule with a single positional argument
    
    assert_type = isinstance(var_0, list)
    assert_value = var_0

# Generated at 2022-06-25 11:40:06.126072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    test_AnsibleError_0 = AnsibleError('Unable to use "^qz_.+" as a search parameter: missing ), unterminated subpattern at position 4')

    # Test exception raise of AnsibleError for string 'qz_'
    with pytest.raises(AnsibleError) as err:
        var_0 = lookup_run(lookup_module_0, terms='qz_')

    assert err.value.__str__() == test_AnsibleError_0.__str__()

    test_AnsibleError_1 = AnsibleError('Unable to use "^qz_.+" as a search parameter: missing ), unterminated subpattern at position 4')

    # Test exception raise of AnsibleError

# Generated at 2022-06-25 11:40:15.604833
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import re
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types

    # This is a helper function to build a dictionary of variables which
    # can be used as a parameter of method run of class LookupModule.
    # The returned object can be assigned to a variable and then used in a
    # test of the method run.
    def build_env(variables):

        env = {}
        # Assume that variables is a list of two-element tuples,
        # (varname, value).
        for item in variables:

            # Check that variable name is a string.
            assert ( isinstance(item[0], string_types) ), \
                "lookup_module_2: variable name must be a string"

           

# Generated at 2022-06-25 11:40:23.285886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test of method run of class LookupModule

    # The following test will search for varname that starts with qz_ and
    # prints the list of matching varnames

    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(['^qz_.+'])

    assert str(var_1) == str(['qz_1', 'qz_2'])



# Generated at 2022-06-25 11:40:26.323115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x_2 = []
    x_1 = LookupModule()
    x_4 = {}
    try:
        x_1.run(x_2, variables = x_4)
    except AnsibleError as e:
        assert "No variables available to search" in str(e)


# Generated at 2022-06-25 11:40:30.454625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['qz_1', 'qz_2'], var_0
   

# Generated at 2022-06-25 11:40:32.119402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)

# Generated at 2022-06-25 11:40:34.715591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare object for method test
    lookup_module_0 = LookupModule()
    # Call run method
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:40:40.734085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert isinstance(var, list)
    assert var == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:40:49.451922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options, direct=kwargs)
    var_0 = lookup_module_0.run(terms)
    assert var_0 == expected, "Returned variable 'var_0' does not match expected value"

# Generated at 2022-06-25 11:40:56.397263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    modules_path = 'ansible.plugins.lookup.varnames'
    if modules_path not in sys.modules:
        import ansible.plugins.lookup.varnames as varnames
    lookup_module = varnames.LookupModule()
    lookup_module.run(terms=None, variables=None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:40:59.384259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(terms = 'x', variables = {'x': 'y'})
    assert var == ['x']

# Generated at 2022-06-25 11:41:09.226691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Input params missing
    # No exception should be raised
    try:
        lookup_run(lookup_module_0)
    except:
        assert(False)

    # Input params invalid
    # No exception should be raised
    try:
        lookup_run(lookup_module_0, terms = "terms")
    except:
        assert(False)

    # Input params invalid
    # No exception should be raised
    try:
        lookup_run(lookup_module_0, terms = "terms", variables = "variables")
    except:
        assert(False)

    # Input params invalid
    # No exception should be raised

# Generated at 2022-06-25 11:41:14.414368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_name_0 = 'variables'
    var_0 = lookup_run(lookup_module_0, var_name_0)

    assert var_0 == [], "returned value does not match"


# Generated at 2022-06-25 11:41:16.079057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms) == expected_result

# Generated at 2022-06-25 11:41:22.929373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_name_0 = {}
    var_value_0 = ['hosts', 'hosts_file', 'hostvars', 'hostvars_files']

    lookup_module_0 = LookupModule()
    var_value_1 = lookup_module_0.run(var_name_0)

    assert(var_value_0 == var_value_1)

# Generated at 2022-06-25 11:41:24.506993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True
test_case_0()

# Generated at 2022-06-25 11:41:28.133020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(terms, variables=None, **kwargs)

    assert v == var
    assert isinstance(v, list)


# Generated at 2022-06-25 11:41:35.024138
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # parameters
    some_terms = ['foo', 'bar']
    some_variables = {
        'foo': 'foovalue',
        'bar': 'barvalue'
    }

    lookup_module = LookupModule()
    result = lookup_module.run(some_terms, variables=some_variables)

    assert len(result) == 2

# Generated at 2022-06-25 11:41:58.439894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = dict({u'qz__2': 3, u'ansible_env': dict(), u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})
    lookup_module_1 = LookupModule()
    variable_names_1 = [u'qz__2', u'qz_1', u'qz_2', u'qa_1', u'qz_']
    var_2 = lookup_run(lookup_module_1, var_1)
    assert var_2 == [u'qz__2', u'qz_2', u'qz_1']

# Generated at 2022-06-25 11:41:59.742927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert lookup_run(LookupModule(), [('.+', 1)])



# Generated at 2022-06-25 11:42:03.064313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the class LookupModule
    lookup_module_1 = LookupModule()
    var_0 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:42:05.208573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'a': '1', 'b': '2'}
    lookup_module = LookupModule()
    terms = ['^a$']
    ret = lookup_module.run(terms, variables)
    assert len(ret) == 1
    assert ret[0] == 'a'

# Generated at 2022-06-25 11:42:08.935852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}, lookup_options={})


# Generated at 2022-06-25 11:42:14.625765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = dict()
    var_1['test'] = "I'm not a dict"
    var_1['test'] = dict()
    # Call method run of lookup_module_0
    var_2 = lookup_module_0.run(var_0, var_1)


# Generated at 2022-06-25 11:42:18.088403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for term in terms:
        Variable_name_0 = re.compile(Variable_name_0)
        Variable_name_1 = Variable_name_0.search(Variable_name_1)
        if Variable_name_1:
            Variable_name_2.append(Variable_name_1)


# Generated at 2022-06-25 11:42:20.603938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from ansible.plugins.lookup import LookupModule
        lookup_module_0 = LookupModule()
        var_0 = lookup_run(lookup_module_0)
    except Exception as exception:
        print('Exception: ' + str(exception))
        assert False

test_LookupModule_run()

# Generated at 2022-06-25 11:42:24.419713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {}
    var_0 = {}
    var_0['ansible_vault'] = "abc"
    # Initialize class instance
    lookup_module_0 = LookupModule()
    # Run method run with correct parameters
    ret_0 = lookup_module_0.run('^ansible_vault', var_0)
    assert ret_0 == ['ansible_vault'], "'ansible_vault' not equal to expected value '['ansible_vault']'"

# Generated at 2022-06-25 11:42:28.710303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if isinstance(lookup_module_0, LookupModule):
        vars = {}
        terms = []
        lookup_module_0.run(terms, vars)
    else:
        raise Exception('Failed to create instance of LookupModule')


# Generated at 2022-06-25 11:42:58.509840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Case where regex.error would be raised
    try:
        var_0 = lookup_module_0.run([('\\'), (None)])
        assert False, "An exception was not raised as expected."
    except AnsibleError as e:
        assert str(e) == "Unable to use \"\\\\\" as a search parameter: unbalanced parenthesis", "Expected different exception message."

    # Case where AnsibleError would be raised
    try:
        var_1 = lookup_module_0.run([('.*')])
        assert False, "An exception was not raised as expected."
    except AnsibleError as e:
        assert str(e) == "No variables available to search", "Expected different exception message."

    # Case where AnsibleError would be raised

# Generated at 2022-06-25 11:43:05.448573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = 'qz_1'
    var_1 = 'qz_2'
    var_2 = 'qa_1'
    var_3 = 'qz_'
    var_4 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module_0.run([var_0,var_1], variables=var_4)


# Generated at 2022-06-25 11:43:13.119824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    assert(var_0 == None)
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([], {})
    assert(var_1 == None)
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run(['foo', 'bar'], {})
    assert(var_2 == None)


# Generated at 2022-06-25 11:43:17.390045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with default arguments.
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['qz_1', 'qz_2']

    # Test with additional arguments.
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    # Test with additional arguments.
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['na_hosts', 'ns_hosts']

# Generated at 2022-06-25 11:43:19.466055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run() of LookupModule")
    lookup_module_0 = LookupModule()
    lookup_module_0.run("^qz_.+")


# Generated at 2022-06-25 11:43:25.839060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '^qz_.+'
    variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:43:29.041670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = lookup_run(LookupModule())
    var_0_asset_1 = var_0 == []
    assert var_0_asset_1


# Generated at 2022-06-25 11:43:30.894782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[])
    assert var_0 == []


# Generated at 2022-06-25 11:43:37.162523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    lookup_module = lookup_loader.get('varnames')
    assert lookup_module is not None
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['127.0.0.1'])

# Generated at 2022-06-25 11:43:42.840520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = { u'qa_1': u'no'}
  lookup_module_0 = LookupModule()
  assert lookup_module_0.run([ u'qa_1'], var_0)
  #print(lookup_module_0.run([ u'qa_1'], var_0))

# Generated at 2022-06-25 11:44:46.805424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '',
        '',
        '',
        '',
    ]
    variables = {}
    expected_result = [
        '',
        '',
        '',
        '',
    ]
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == expected_result


# Generated at 2022-06-25 11:44:56.640296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=vars)
    result_lookup_module = lookup_module.run(['^qz_.+'])
    assert type(result_lookup_module) is list
    assert 'qz_1' in result_lookup_module and 'qz_2' in result_lookup_module
    assert 'qz_' not in result_lookup_module and 'qa_1' not in result_lookup_module


# Generated at 2022-06-25 11:45:00.332846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=['^qz_.+'])

# Generated at 2022-06-25 11:45:01.101673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert(LookupModule.run())


# Generated at 2022-06-25 11:45:04.261633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('^qz_.+')
    assert len(var_0) == 2
    # qz_1
    assert var_0[0] == 'qz_1'
    # qz_2
    assert var_0[1] == 'qz_2'


# Generated at 2022-06-25 11:45:05.185992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Placeholder for (pending) unit tests
    assert (True)


# Generated at 2022-06-25 11:45:07.053308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [str_0]
    variables_0 = {str_0: str_0}
    var_0 = lookup_run(lookup_module_0, terms_0)



# Generated at 2022-06-25 11:45:08.897131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    expected_0 = {'0': '1', '1': '2'}
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:45:19.745378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_terms_1 = '^qz_.+'
    variables_1 = {
         'qz_1': 'hello',
         'qz_2': 'world',
         'qa_1': "I won't show",
         'qz_': "I won't show either",
     }
    var_kwargs_1 = {
    }
    var_2 = lookup_module_1.run(var_terms_1, variables=variables_1, **var_kwargs_1)
    assert var_2 == ['qz_1', 'qz_2', 'qz_']
    lookup_module_2 = LookupModule()
    var_terms_2 = '.+'

# Generated at 2022-06-25 11:45:24.983198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    aws_01 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    lookup_module_1 = LookupModule() # Create a LookupModule object
    terms_1 = ['^qz_.+']
    var_1 = lookup_module_1.run(terms_1, variables=aws_01)
    #assert var_1 == ['qz_1', 'qz_2', 'qz_']
