

# Generated at 2022-06-25 11:37:44.787284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(['^qz_.+'])
    print("RESULT: {0}".format(result))
    assert result == ['qz_1', 'qz_2', 'qz_']

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:37:49.679529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 =['^qz_.+']
    variables_0 = {
        'qz_2': 'world',
        'qz_1': 'hello',
        'qz_': "I won't show either",
        'qa_1': "I won't show"
    }

    ret = lookup_module_0.run(terms_0, variables_0)
    assert ret == ['qz_2', 'qz_1']

# Generated at 2022-06-25 11:37:56.967885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '^qz_.+'
    variables_0 = {'qz_1': 'hello', 'qa_1': "I won't show", 'qz_': "I won't show either", 'qz_2': 'world'}
    kwargs_0 = {'warnings': ['bar'], 'errors': ['baz']}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:37:58.617374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['a'], variables='') == []



# Generated at 2022-06-25 11:38:05.157733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        result = lookup_module_1.run('^qz_.+',
                                     dict(qz_1='hello',qz_2='world',qa_1='I wont show',qz_='I wont show either'))
    except:
        result = None
    assert result == ['qz_1', 'qz_2']

    try:
        result = lookup_module_1.run('^qz_.+', dict(qz_1='hello',qz_2='world',qa_1='I wont show',qz_='I wont show either'),
                                     var_options=dict(qz_1='hello',qz_2='world',qa_1='I wont show',qz_='I wont show either'))
    except:
        result

# Generated at 2022-06-25 11:38:13.745817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    expected_0 = ["qz_1", "qz_2"]
    expected_0_0 = ["qz_1", "qz_2"]
    variables_1 = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
    }
    terms_1 = ["^qz_.+"]
    result_1 = lookup_module_1.run(terms_1, variables_1)
    assert result_1 == expected_0 or result_1 == expected_0_0
    expected_1 = ["qa_1", "qz_", "qz_1", "qz_2"]

# Generated at 2022-06-25 11:38:17.649344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run('^qz_.+') == ['qz_1', 'qz_2'], 'Test not passed'


# Generated at 2022-06-25 11:38:24.257404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms_0 = ['^qz_.+']
    lookup_module_0.set_options(var_options=variables_0, direct={})
    result = lookup_module_0.run(terms=terms_0, variables=variables_0)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:31.990830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # using regex as terms
    terms = ['^qz_.+']
    var = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}

    # var is dict of dict
    list_var = lookup_module.run(terms, var)
    assert len(list_var) == 2
    assert 'qz_1' in list_var
    assert 'qz_2' in list_var
    assert 'qa_1' not in list_var
    assert 'qz_' not in list_var

    # var is list of dict
    list_var = lookup_module.run(terms, [var])
    assert len(list_var) == 2

# Generated at 2022-06-25 11:38:42.125424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        u'^qz_.+',
        u'.+',
        u'hosts',
        u'.+_zone$',
        u'.+_location$'
    ]
    variables_1 = {
        u'qz_1': u'hello',
        u'qz_2': u'world',
        u'qa_1': u'I won\'t show',
        u'qz_': u'I won\'t show either',
        u'power_state': u'dsadas',
        u'zone': u'zone',
        u'i_location': u'location',
        u'i_zone': u'zone'
    }

# Generated at 2022-06-25 11:38:49.794263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=['^qz_.*'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})

# Generated at 2022-06-25 11:39:00.741462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':'I won''t show', 'qz_':'I won''t show either'}
    lookup_module_0.run(terms=terms, variables=variables)
    terms = ['.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':'I won''t show', 'qz_':'I won''t show either'}
    lookup_module_0.run(terms=terms, variables=variables)
    terms = ['hosts']

# Generated at 2022-06-25 11:39:11.813311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = dict([('qz_', 'I won\'t show either'), ('qz_2', 'world'), ('qz_1', 'hello'), ('qa_1', 'I won\'t show')])
    try:
        result_0 = lookup_module_0.run(terms_0, variables_0)
    except Exception as e:
        print("Can't run lookup module, error: " + str(e))
        return False

    print("Result: " + str(result_0))

    return True


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:16.583220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    results = lookup_module_1.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})
    print("Return value: " + str(results))
    assert len(results) == 4


# Generated at 2022-06-25 11:39:18.138582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[], variables=None, **{})


# Generated at 2022-06-25 11:39:23.199825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_5 = [u'^qz_.+']
    variables_6 = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    kwargs_7 = {u'direct': {}}
    lookup_module_1.run(terms_5, variables_6, **kwargs_7)

test_LookupModule_run()

# Generated at 2022-06-25 11:39:29.771100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["^qz_.+"]
 #   vars = [{'key1': 'value1', 'key2': 'value2'}]
    vars = { 'key1': 'value1', 'key2': 'value2' }
    kwargs = {"direct": {}, "var_options": {}}
    ret = lookup_module_0.run(terms, vars, **kwargs)
    print(ret)

# Generated at 2022-06-25 11:39:40.479119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is a unit test for the method run of class LookupModule.
    # This test case only tests the positive inputs
    # Input parameters:
    # The first input parameter is a list of "terms" and you can enter multiple "terms" in the list
    # The second input parameter is a dictionary of variables
    # Expected output:
    # The output is the list of matching variable names
    
    # test case for the matching variable name in the list:
    #The input parameter terms is ["^qz_.+"]
    #The input parameter variables is {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    #Expected output is ['qz_1', 'qz_2']
    lookup_module_0 = Look

# Generated at 2022-06-25 11:39:44.298737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}
    lookup_obj.run(terms, variables)


# Generated at 2022-06-25 11:39:52.440101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variable = dict({u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})
    assert lookup_module.run(['^qz_.+'], variables=variable) == [u'qz_1', u'qz_2']
    assert lookup_module.run(['.+'], variables=variable) == [u'qz_1', u'qz_2', u'qa_1', u'qz_']
    assert lookup_module.run(['hosts'], variables=variable) == []
    assert lookup_module.run(['.+_zone$', '.+_location$'], variables=variable) == []

# Generated at 2022-06-25 11:40:01.184789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[], variables={})

# Generated at 2022-06-25 11:40:07.541467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    t = []
    t.append('^qz_.+')
    variables = {}
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"
    try:
        lookup_module_0.run(terms=t,variables=variables)
    except Exception as exception_instance:
        print(exception_instance)


# Generated at 2022-06-25 11:40:16.015429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ '^qz_.+', 'hosts' ]
    variables = {
        'bz_1' : 'hello',
        'az_2' : 'world',
        'qa_1' : 'I will not show',
        'qz_' : 'I will not show either',
        'a_host' : 'I am a host',
        'another_host' : 'I am another host'
    }
    ret = lookup_module.run(terms, variables)
    assert len(ret) == 3
    assert 'bz_1' in ret
    assert 'az_2' in ret
    assert 'another_host' in ret


# Generated at 2022-06-25 11:40:24.599982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variable_names = ["qz_1", "qz_2", "qa_1", "qz_"]
    variables = [
        {"qz_1": "hello"},
        {"qz_2": "world"},
        {"qa_1": "I won't show"},
        {"qz_": "I won't show either"}
    ]
    term = "^qz_.+"
    lookup_module.run(term, variables, **kwargs)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:40:34.433625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg0 = ['.+_zone$', '.+_location$']
    arg1 = {'gce_zone': 'us-central1-f', 'gce_location': 'us-central1'}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=arg1, direct=None)

    # Test with the following args
    # ('^qz_.+',)
    # (['^qz_.+'],)
    # Use the following kwargs
    # {'variables': {'gce_zone': 'us-central1-f', 'gce_location': 'us-central1'}}
    # {'variables': {'gce_zone': 'us-central1-f', 'gce_location': 'us-central1'}, '

# Generated at 2022-06-25 11:40:42.208311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_r = LookupModule()
    lookup_module_r.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})

test_LookupModule_run()

# Generated at 2022-06-25 11:40:46.783044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 11:40:50.270969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options = MagicMock(return_value = None)
    lookup_module.set_options = lookup_module.set_options()
    lookup_module.run = MagicMock(return_value = [])
    lookup_module.run = lookup_module.run(terms = [])



# Generated at 2022-06-25 11:41:02.238903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
                "qz_1": "hello",
                "qz_2": "world",
                "qa_1": "I won't show",
                "qz_": "I won't show either"
              }
    terms_1 = ['^qz_.+']
    expected_ret_1 = ["qz_1", "qz_2"]
    assert lookup_module_0.run(terms_1, variables) == expected_ret_1
    terms_2 = ['.+']
    expected_ret_2 = ["qz_1", "qz_2", "qa_1", "qz_"]
    assert lookup_module_0.run(terms_2, variables) == expected_ret_2
    terms_3 = ['hosts']

# Generated at 2022-06-25 11:41:12.418147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '^qz_.+'
    variables = {}
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = 'I won\'t show'
    variables['qz_'] = 'I won\'t show either'
    kwargs_0 = { }
    lookup_module_0.set_options(var_options=variables, direct=kwargs_0)
    test_term_0 = ['^qz_.+']
    result_0 = lookup_module_0.run(test_term_0, variables)
    assert result_0 == [ 'qz_1', 'qz_2' ]
    term_1 = '.+'

# Generated at 2022-06-25 11:41:38.762715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()

    # The variable name variable_0 is not defined, but it doesn't matter because everything is mocked out
    lookup_module_0.run(terms=[], variables={})
    lookup_module_1.run(terms=[], variables={variable_0: []})
    lookup_module_2.run(terms=[], variables={variable_1: [[]]})
    lookup_module_3.run(terms=[], variables={variable_2: {}})

# Generated at 2022-06-25 11:41:45.939097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run("^qz_.+", variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show",
                                                   "qz_": "I won't show either"})
    print(res)
    assert res == ['qz_1', 'qz_2']

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:41:58.219884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import Mapping
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, patch

    lookup_module_0 = LookupModule()

    def side_effect(direct, term):
        return {"": {}}

    with patch.object(lookup_module_0, 'set_options', autospec=True) as mock_set_options, \
            patch.object(lookup_module_0, 'run', return_value="hello world", side_effect=side_effect) as mock_run:

        terms = ["term"]
        variables = "variables"
        kwargs = {"key": "value"}

        lookup_module_0.run(terms=terms, variables=variables, **kwargs)

# Generated at 2022-06-25 11:42:03.668120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(["^qz_.+"], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:42:11.980359
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    lookup_module_1 = LookupModule()
    params_1 = ['^qz_.+']
    variable_names_1 = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    variables_1 = {}
    for variable_name_1 in variable_names_1:
        variables_1[variable_name_1] = variable_name_1
    kwargs_1 = {}

    # Execution
    result_1 = lookup_module_1.run(params_1, variables_1, **kwargs_1)

    # Verification
    assert type(result_1) == list
    assert len(result_1) == 2
    assert result_1 == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:42:18.169306
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = dict(
        qz_1 = "hello",
        qz_2 = "world",
        qa_1 = "I won't show",
        qz_ = "I won't show either"
    )

    lookup_module_1 = LookupModule()
    lookup_module_1._templar = variables

    terms = ['qz_1', 'qz_2']
    ret_val = lookup_module_1.run(terms=terms)
    assert ret_val == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:42:19.881177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['.+']
    variables = {'my_var': 5}
    result = lookup_module.run(terms, variables)
    assert result == ['my_var']

# Generated at 2022-06-25 11:42:30.812390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '^qz_.+',
        '.+',
        'hosts',
        '.+_zone$',
        '.+_location$'
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts_zone': 'hosts_zone',
        'hosts_location': 'hosts_location'
    }


# Generated at 2022-06-25 11:42:36.456038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ["^qz_.+"]
    variables_1 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    expected = ['qz_1', 'qz_2']
    ret = lookup_module_0.run(terms_1, variables_1)
    assert ret == expected

# Generated at 2022-06-25 11:42:42.865718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Setup test data needed for the test to run
    # The data should be such that it should not affect currently running test
    # cases

    # Setup required inputs
    # Here we not provide any input, but the method still should return an
    # object
    terms = []
    variables = {}

    # Invoke method to be tested
    result = lookup_module_0.run(terms, variables)

    # Verify the output
    assert result is not None
    assert not result
    assert isinstance(result, list)

# Generated at 2022-06-25 11:43:02.588480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_0 = LookupModule()

    test_case_0( lookup_module_0)

# Generated at 2022-06-25 11:43:08.630616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils._text import to_native

    lookup_module_0 = LookupModule()

    # set up test input data
    # Change to the correct path
    lookup_module_0.set_options(direct={'_terms': ['^qz_.+']})
    lookup_module_0.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

    variables = {}
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"

    lookup_module_

# Generated at 2022-06-25 11:43:15.960829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    variable_names = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    vars_arguments = {'terms': ['^qz_.+'], 'variables': {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I will not show', 'qz_': 'neither will i'}}
    vars_expected_value = ['qz_1', 'qz_2']

    vars_returned_value = lookup_module_0.run(**vars_arguments)

    assert vars_returned_value == vars_expected_value


# Generated at 2022-06-25 11:43:17.337681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []



# Generated at 2022-06-25 11:43:24.745160
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()

    # Test with all positional arguments
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2' : 'world', 'qa_1' : 'I won\'t show', 'qz_' : 'I won\'t show either'}

    expected_results = ['qz_1', 'qz_2']

    results = lookup_instance.run(terms, variables)

    assert expected_results == results

# Generated at 2022-06-25 11:43:33.970967
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

# Generated at 2022-06-25 11:43:40.301368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo_0 = "Playbook variable"
    ret_val = lookup_module_0.run(terms, variables = foo_0)


# Generated at 2022-06-25 11:43:45.150521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_module = LookupModule()

    # Test args - terms, variables
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Test args - direct
    direct = {}

    # Call run method
    result = lookup_module.run(terms, variables, direct)

    print(result)


# Generated at 2022-06-25 11:43:50.732428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test command line options and error handling
    lookup_module_0.run(terms=["qz_"], variables={u'qa_1': u"I won't show", u'qz_': u"I won't show either", u'qz_1': u'hello', u'qz_2': u'world'})
    lookup_module_0.run(terms=[".+_zone$", ".+_location$"], variables={u'qa_1': u"I won't show", u'qz_': u"I won't show either", u'qz_1': u'hello', u'qz_2': u'world'})

# Generated at 2022-06-25 11:43:55.247133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ ]
    variables_0 = {}
    kwargs = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs) is None

# Generated at 2022-06-25 11:44:37.626607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["^qz_.+"]
    result_0 = lookup_module_0.run(terms_0, variables=None, **kwargs)
    assert len(result_0) == 2


# Generated at 2022-06-25 11:44:46.273223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show'}
    test_terms = ['^qz_.+']
    test_result = ['qz_1', 'qz_2']
    lookup_module_0 = LookupModule()
    variables, __ = lookup_module_0.parse_params(params=variables, inject=None)
    lookup_module_0.set_options(var_options=variables, direct=None)

    # Exercise code
    result = lookup_module_0.run(terms=test_terms, variables=variables)

    # Assert
    assert result == test_result

# Generated at 2022-06-25 11:44:57.078943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    lookup_module_0 = LookupModule()
    terms_0 = ['.+_zone$', '.+_location$']
    variables_0 = {'aws_region': 'us-east-1', 'aws_zone': 'us-east-1a'}

# Generated at 2022-06-25 11:45:04.147896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Executing the run method of LookupModule with term being an instance of str
    # Assert invocation of method lookup_module_0.run with term being an instance of str and variables being an instance of dict
    assert lookup_module_0.run(terms=['my_variable']) == ['my_variable']
    # Executing the run method of LookupModule with term being an instance of str
    # Assert invocation of method lookup_module_0.run with term being an instance of str and variables being an instance of dict
    assert lookup_module_0.run(terms=['my_variable']) == ['my_variable']

# Generated at 2022-06-25 11:45:06.579443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_obj = LookupModule()
    lookup_module_run_obj.run(terms='^qz_.+')


# Generated at 2022-06-25 11:45:07.965141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(["^qz_.+"])) == 2

# Generated at 2022-06-25 11:45:15.037280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run('^qz_.+', {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})
    assert result == [u'qz_1', u'qz_2'], result

# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 11:45:21.542296
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run()
    except Exception as e:
        assert isinstance(e, AnsibleError)

    try:
        lookup_module_0.run('abc')
    except Exception as e:
        assert isinstance(e, AnsibleError)

    try:
        lookup_module_0.run(['abc'])
    except Exception as e:
        assert isinstance(e, AnsibleError)

    assert lookup_module_0.run([], {'a': 'foo'}) == []
    assert lookup_module_0.run(['foo'], {'a': 'foo'}) == ['a']

# Generated at 2022-06-25 11:45:24.587378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the object of class LookupModule
    lookup_module = LookupModule()
    # Create the vars dictionary
    vars= {'az_disk': 'hello',
           'az_host': 'hello',
           'az_zone': 'hello'}
    # Create the terms list
    terms = ['az_.+']
    # Run the run method of class LookupModule with the parameters
    lookup_module.run(terms, vars)


# Generated at 2022-06-25 11:45:26.819972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^(1|2).+$']
    variables = {'1_var': 'val1', '2_var': 'val1', '3_var': 'val1'}
    ret = LookupModule().run(terms, variables)
    expected_ret = ['1_var', '2_var']
    assert ret == expected_ret

# Generated at 2022-06-25 11:47:01.738848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = 1
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run('^qz_.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})
    except Exception:
        ret = 0
    assert ret == 1
#

# Generated at 2022-06-25 11:47:11.333663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
     Unit test for method run of class LookupModule
    '''
    # arguments for instance
    var_options = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    _terms = ['msg="{{ lookup("varnames", "^qz_.+")}}"']
    kwargs = {}
    
    # parameters
    terms = _terms
    variables = var_options
    
    lookup_module_0 = LookupModule()

    # call the method under test
    ret = lookup_module_0.run(terms=terms, variables=variables, **kwargs)

    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:47:17.072512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        '^qz_.+',
    ]
    variables_0 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    expect_0 = [
        'qz_1',
        'qz_2',
    ]
    result_0 = lookup_module_0.run(terms=terms_0, variables=variables_0)
    assert result_0 == expect_0


# Generated at 2022-06-25 11:47:24.148695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    kwargs = {}
    assert_value = '[]'
    # Execute code under test
    lookup_module = LookupModule()
    value = lookup_module.run(terms, variables, **kwargs)
    # Verify results
    assert value == assert_value

# Generated at 2022-06-25 11:47:32.237311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Raises an exception if variables is None
    assert_raises(
        AnsibleError,
        lookup_module_0.run,
        [],
        None,
    )

    # Raises an exception if any of the patterns in terms is not a string
    assert_raises(
        AnsibleError,
        lookup_module_0.run,
        [42],
        {'42': 42},
    )

    # Raises an exception if any pattern in terms is not a valid regex
    assert_raises(
        AnsibleError,
        lookup_module_0.run,
        ['+'],
        {'+': 2.718281828},
    )

    # Verify that the correct list of variables is returned

# Generated at 2022-06-25 11:47:33.415686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert "^qz_.+" in lookup_module_0.run(["^qz_.+"])

# Generated at 2022-06-25 11:47:36.829856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    varnames = lookup_module_0.run(terms=['^qz_.+'], variables=None, **{'play_context': {'name': 'myplay', 'tags': [], 'force_handlers': False}, '_original_file': 'test/ansible_module/hacking/test_templates.py', 'display_skipped_hosts': False})
    assert varnames == []