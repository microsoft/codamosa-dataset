

# Generated at 2022-06-25 11:37:42.714542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert lookup_module_0.run(
    [u'^qz_.+', u'hosts'],
    variables={
       u'qz_1': u'hello',
       u'qz_2': u'world',
       u'qa_1': u'I won\'t show',
    }
) == [u'qz_1', u'qz_2']

# Generated at 2022-06-25 11:37:43.922058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert callable(getattr(LookupModule, "run"))


# Generated at 2022-06-25 11:37:50.944235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test good option with one pattern
    result = lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']

    # Test good option with one pattern
    result = lookup_module.run(['^qz_.+$'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_']

    # Test good option with one pattern

# Generated at 2022-06-25 11:37:52.235489
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert lookup_module_0.run(terms, variables, **kwargs) == ret

# Generated at 2022-06-25 11:38:01.975778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 == []
    terms_1 = []
    variables_1 = {}
    kwargs_1 = {}
    ret_1 = lookup_module_0.run(terms_1, variables_1, **kwargs_1)
    assert ret_1 == []
    terms_2 = []
    variables_2 = {}
    kwargs_2 = {}
    ret_2 = lookup_module_0.run(terms_2, variables_2, **kwargs_2)
    assert ret_2 == []
    terms_3 = []
    variables_

# Generated at 2022-06-25 11:38:10.170533
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()

    # Call method run of class LookupModule
    lookup_module_obj.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-25 11:38:18.597385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
# Input:
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret_varnames = lookup_module_0.run(terms, variables=variables)
    assert ret_varnames == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:22.201110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #
    # Setup test data
    #
    lookup_module_0.set_options(direct=dict())
    #
    # Run the code
    #
    res = lookup_module_0.run(terms=[])

# Generated at 2022-06-25 11:38:31.602106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    example_1 = [
        {
            "msg": [
                "qz_1",
                "qz_2"
            ]
        }
    ]

    example_2 = [
        {
            "msg": [
                "qz_1",
                "qz_2",
                "qa_1",
                "qz_"
            ]
        }
    ]

    example_3 = [
        {
            "msg": [
                "ansible_hosts",
                "ansible_play_hosts",
                "inventory_hostname"
            ]
        }
    ]

    example_4 = [
        {
            "msg": [
                "qz_1_zone",
                "qz_2_location",
            ]
        }
    ]

    lookup_module_

# Generated at 2022-06-25 11:38:37.193919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['^qz_.+'], {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"})
    #assertEqual(result_1, result_1)



# Generated at 2022-06-25 11:38:46.570514
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_run_0 = dict()
    test_run_0['terms'] = ['ansible_.*']

    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module_0.run(**test_run_0)

# Generated at 2022-06-25 11:38:51.941105
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test #1: Variables list
    lookup_module_1.run(terms, variables=variables, **kwargs)

test_LookupModule_run()


# Generated at 2022-06-25 11:39:02.874255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "^qz_.+"

# Generated at 2022-06-25 11:39:13.708936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(
            terms=['^qz_.+'],
            variables={
                'qz_1': 'hello',
                'qz_2': 'world',
                'qa_1': "I won't show",
                'qz_': "I won't show either"
            },
        ) == [
            'qz_1',
            'qz_2'
        ]

# Generated at 2022-06-25 11:39:17.276322
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:39:27.346062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    expected_var_0 = {'qz_1': 'hello','qz_2': 'world','qa_1': "I won't show",'qz_': "I won't show either"}
    terms_var_0 = ['^qz_.+']
    results_var_0 = lookup_module_0.run(terms=terms_var_0, variables=expected_var_0)
    assert results_var_0 == ["qz_1","qz_2"]

# Generated at 2022-06-25 11:39:28.694654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:39:40.464732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ["^qz_.+"]
    kwargs = {'_ansible_check_mode': False, '_ansible_debug': False, '_ansible_diff': False, '_ansible_keep_remote_files': False, '_ansible_no_log': False, '_ansible_remote_tmp': None, '_ansible_selinux_special_fs': ['/dev/shm', '/run', '/sys/fs/cgroup']}
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won t show",
        "qz_": "I won t show either"
    }

# Generated at 2022-06-25 11:39:49.547195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # these should compile to:
    # ['fizz', 'foo', 'foobar']
    lookup_module = LookupModule()
    assert lookup_module.run(['foo'], variables={'foo': 1, 'fizz': 2, 'foobar': 3}) == ['foo', 'foobar']

    # now, with a set of matching patterns
    assert lookup_module.run(['foo', 'f.+'], variables={'foo': 1, 'fizz': 2, 'foobar': 3}) == ['foo', 'fizz', 'foobar']



# Generated at 2022-06-25 11:39:59.066650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print ("Testing Ansible lookup plugin varnames.py\n")
    print ("Tests for class LookupModule\n")
    print ("Testing method run")
    lookup_module_0 = LookupModule()
    check = True
    search_patterns = ['^qz_.+', '^abc']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either', 'abcd': 'something'}
    terms = ['^qz_.+', '^abc']
    result = lookup_module_0.run(terms, variables)
    print ("output : " + str(result))

# Generated at 2022-06-25 11:40:07.947582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:40:17.075846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instanciation of the object
    lookup_module_0 = LookupModule()

    # Initialization of the object
    # Set the variable private __loader of the object lookup_module_0 to None
    lookup_module_0.set_loader(loader=None)

    # Set the variable private __templar of the object lookup_module_0 to None
    lookup_module_0.set_templar(templar=None)

    # Set the variable private _options of the object lookup_module_0 to {}
    lookup_module_0.set_options(options={})

    # Test of the method run of the class LookupModule
    terms_0 = ['^qz_.+']

# Generated at 2022-06-25 11:40:22.827095
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of run
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=['^qz_.+'], variables= {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})


# Generated at 2022-06-25 11:40:32.521014
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Values provided by caller
    terms=[
        '^qz_.+',
        'hosts',
        '.+_zone$',
        '.+_location$'
        ]

    vars_dict = {
            'azure_conf_file': '/home/gaurav/.azure/credentials',
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
            'hosts': [
                'localhost1',
                'localhost2',
                'localhost3'
                ],
            'default_zone': '',
            'default_location': '',
            'default_user': ''
            }

    # Expected return values

# Generated at 2022-06-25 11:40:38.691633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either"
            }
    terms = ['^qz_.+']
    result = lookup_module.run(terms, variables)
    assert len(result) == 2
    assert result[0] == 'qz_1'
    assert result[1] == 'qz_2'

# Generated at 2022-06-25 11:40:45.104164
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0._templar = None
    lookup_module_0._loader = None
    lookup_module_0._ds = None
    lookup_module_0._basedir = u'/home/ansibot/ansible/new/lib/ansible/plugins/lookup'
    lookup_module_0._display.verbosity = 3

    r = lookup_module_0.run([u'^qz_.+'], {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})

    assert r == [u'qz_1', u'qz_2']

# Generated at 2022-06-25 11:40:49.098782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    texts = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    lookup_module.run(texts, variables)

# Generated at 2022-06-25 11:41:02.091768
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:41:08.328307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Class test method run is called with one argument, arguments "n"
    # The method run returns an object of type list
    assert isinstance(lookup_module_0.run(terms="n"), list)

# Generated at 2022-06-25 11:41:16.652956
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {'qa_1': 'hello', 'qz_1': 'hello', 'qa_2': 'world', 'qz_2': 'world'}
    lookup_module_0 = LookupModule()
    field_0 = '^qz_.+'
    field_1 = variables
    field_2 = {}
    var_ret = lookup_module_0.run(field_0, field_1, **field_2)
    assert var_ret == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:41:39.357971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args_0 = [
        '^qz_.+'
    ]
    kwargs_0 = {}
    assert lookup_module_1.run(args_0, **kwargs_0) == ['qz_2', 'qz_1']
    args_1 = [
        '.+'
    ]
    kwargs_1 = {}
    assert lookup_module_1.run(args_1, **kwargs_1) == ['qz_2', 'qz_1', 'qa_1', 'qz_']
    args_2 = [
        'hosts'
    ]
    kwargs_2 = {}
    assert lookup_module_1.run(args_2, **kwargs_2) == []

# Generated at 2022-06-25 11:41:46.834837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit: Simple test using the simple example to ensure it really does it's job.
    lookup_module_0 = LookupModule()
    kwargs_1 = {"_terms": ["^qz_.+"]}
    variables_2 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    _terms_3 = kwargs_1.get('_terms')
    lookup_module_0.run(_terms_3, variables_2)


# Generated at 2022-06-25 11:41:55.845457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  term1 = "^qz_.+"
  terms = [term1]
  variables = {"qz_1" : "hello", "qz_2" :"world", "qa_1" : "I won't show", "qz_" : "I won't show either"}
  variable_names = list(variables.keys())
  ret = []
  for term in terms:
    name = re.compile(term)
    for varname in variable_names:
      if name.search(varname):
        ret.append(varname)
  print(ret)
test_LookupModule_run()

# Generated at 2022-06-25 11:42:04.446357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1
    lookup_module_1 = LookupModule()
    vars_1 = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    terms_1 = [u'^qz_.+']
    ret = lookup_module_1.run(terms_1, vars_1)
    assert ret == [u'qz_1', u'qz_2']


# Generated at 2022-06-25 11:42:12.797754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with correct parameters
    terms = ['^qz_.+', 'hosts']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either" }
    result = lookup_module.run(terms, variables)
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert len(result) == 2
    # Test with incorrect terms
    terms = ['^incorrect term']
    variables = {'test': 'test'}
    result = lookup_module.run(terms, variables)
    assert result == []

# Generated at 2022-06-25 11:42:20.895058
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  myVars = {
    "ansible_host": "hostname",
    "ansible_port": "22",
    "ansible_user": "username",
    "ansible_connection": "ssh",
    "ansible_ssh_pass": "password"
  }

  # Test that a list of terms is returned as expected
  terms = ["ansible_host", "ansible_port"]
  myReturn = lookup_module_0.run(terms, myVars)
  assert "ansible_host" in myReturn
  assert "ansible_port" in myReturn
  assert len(myReturn) == 2

  # Test that a single term is returned as expected
  terms = ["ansible_host"]
  myReturn = lookup_module_0.run(terms, myVars)
  assert "ansible_host"

# Generated at 2022-06-25 11:42:28.026155
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test set-up
    terms = [
        '^qz_.+',
        '^qa_.+'
    ]

    variables = {
        'qz_1': 'foo',
        'qz_2': 'bar',
        'qa_1': 'baz',
        'qz_': 'foo_bar'
    }

    # Test execution
    lookup_module = LookupModule()
    value = lookup_module.run(terms=terms, variables=variables)

    # Test results
    assert value == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:42:38.085960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['hosts']


# Generated at 2022-06-25 11:42:45.971431
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    terms_1 = [
        '^qz_.+',
    ]

    variables_1 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }

    ret_1 = lookup_module_1.run(terms_1, variables_1)

    assert ret_1 is not None
    assert len(ret_1) == 2
    assert 'qz_1' in ret_1
    assert 'qz_2' in ret_1


# Generated at 2022-06-25 11:42:52.412519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Setup Mock
  lookup_module_0 = LookupModule()
  lookup_module_0.set_options(var_options={'boot_mode': 'BIOS', 'public_ip': '192.168.0.21', 'private_ip': '192.168.4.21'}, direct={'_terms': ['^pub.+'], '_hash_behavior': 'replace'})
  lookup_module_0._get_plugin_options = lambda: None

  # Invoke method run
  result = lookup_module_0.run(['^pub.+'])
  assert result == '192.168.0.21'

# Generated at 2022-06-25 11:43:23.737307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run("^qz_.+", {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
  lookup_module_0.run(".+", {})
  lookup_module_0.run("hosts", {})
  lookup_module_0.run(".+_zone$", {})

# Generated at 2022-06-25 11:43:31.663131
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeModule(object):
        def __init__(self):
            self.params = {}

    class FakeResult(object):
        def __init__(self):
            self.result = dict(
                qz_1='hello',
                qz_2='world',
                qa_1='I wont show',
                qz_='I wont show either'
            )

    lookup_module_0 = LookupModule()

    objModule = FakeModule()
    objResult = FakeResult()

    # List variables that start with qz_
    terms = ['^qz_.+']
    result = lookup_module_0.run(terms, objResult.result)
    assert result == ['qz_1', 'qz_2']

    # Show all variables
    terms = ['.+']
    result = lookup_module_

# Generated at 2022-06-25 11:43:37.871970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.run(terms=['^qz_.+'], variables=None, **None)


# Generated at 2022-06-25 11:43:43.599058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = lookup_module_0.run(terms, variables=variables, **{})
    assert ret == ['qz_1', 'qz_2']

#

# Generated at 2022-06-25 11:43:49.424990
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Case 1
    terms_1 = ['^qz_.+']
    variables_1 = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    kwargs_1 = {}
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert result_1 == ['qz_1', 'qz_2']

    # Case 2
    lookup_module_2 = LookupModule()
    terms_2 = ['.+']
    variables_2 = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    kwargs_2 = {}

# Generated at 2022-06-25 11:43:56.424658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    r = lookup_module_run.run('^qz_.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert r == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:43:59.815700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_terms = [
        '.',
        '^a',
    ]
    mock_variables = dict(
        a=1,
        b=2,
        ab=3,
    )
    expected_result = [
        'a',
        'ab',
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(mock_terms, mock_variables)
    assert result == expected_result

# Generated at 2022-06-25 11:44:04.919768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module_0.run(['^qz_.+'], vars)


# Generated at 2022-06-25 11:44:10.205511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  lookup_module_1.run([('.+_zone$', '.+_location$',),])

# Generated at 2022-06-25 11:44:18.398404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '^qz_.+'
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    test_run_0 = lookup_module_0.run(terms_0, variables_0)
    assert test_run_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:45:16.734301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'alpha_int': 10, 'beta_str': 'beta', 'gamma_bool': True, 'gamma_none': None, 'alpha_str': 'alpha', 'delta_int': 20, 'gamma_str': 'gamma'}
    kwargs_0 = {}
    # Returned value should be of type list
    ret = lookup_module_0._flatten(lookup_module_0.run(terms_0, variables_0, **kwargs_0))
    assert isinstance(ret, list)
    # Number of element in return value should be 0.
    assert len(ret) == 0


# Generated at 2022-06-25 11:45:25.400096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule() # instantiate
    vars_1 = {}
    term_1 = ''
    kwargs_1 = {}
    # Test with param for terms (list of strings)
    terms_1 = ['^qz_.+']
    assert_equal(lookup_module_1.run(terms_1, vars_1, **kwargs_1), [])

# Generated at 2022-06-25 11:45:29.780142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["^qz_.+"]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
    }
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:45:36.337648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = {'ec2_access_key': 'hello', 'ec2_secret_key': 'world'}
    terms = ['ec2.+']
    try:
        ret = lookup_module.run(terms, variables=var)
    except AnsibleError as error:
        assert error.message == 'No variables available to search'
    else:
        assert ret == ['ec2_access_key', 'ec2_secret_key']


# Generated at 2022-06-25 11:45:37.603804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run(['^qz_.+'])

# Generated at 2022-06-25 11:45:38.827741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Place your code here
    raise Exception("Test not implemented")



# Generated at 2022-06-25 11:45:45.292803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run method of LookupModule
    """
    lookup_module = LookupModule()
    
    #assert_raises = __tracebackhide__
    #assert_raises(AnsibleError, lookup_module.run, None, {'a': 'a'})
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+'], {'a': 1, 'b': 2}) == ['a', 'b', 'dummy_hosts']

# Generated at 2022-06-25 11:45:47.352653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = {u'qz_2': 'world', u'qz_1': 'hello'}
    terms_0 = [u'^qz_.+']
    result_0 = LookupModule().run(terms_0, variables=vars_0)
    assert result_0 == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:45:48.909516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # init with stubs for variables
    variables = {'a':'b'}
    terms = ['^a$']
    lookup_module_0.run(terms, variables=variables)


# Generated at 2022-06-25 11:45:57.526416
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 0
    lookups = lookup_module_0.run(['^qz_.+'])
    print(lookups)

if __name__ == '__main__':
    test_LookupModule_run()
    print("OK")