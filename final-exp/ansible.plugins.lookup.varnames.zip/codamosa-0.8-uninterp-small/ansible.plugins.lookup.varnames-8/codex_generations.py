

# Generated at 2022-06-25 11:37:47.184735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either" }
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=None)

    # Act
    result = lookup_module.run(terms, variables)

    # Assert
    assert result == ['qz_1', 'qz_2']


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:37:53.774588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_vars = {}
    my_vars.update({
        'env_1': 'foo',
        'env_2': 'bar',
        'env_3': 'baz'
    })
    result_0 = lookup_module_0.run(terms=['env_.+'], variables=my_vars)
    assert len(result_0) == 3

# Generated at 2022-06-25 11:38:00.108051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    table = {
        'foo': '1',
        'bar': '2',
        'baz': '3',
        'qux': '4',
        'quux': '5',
    }
    exp = ['foo', 'bar', 'baz', 'qux', 'quux']
    variable_names = list(table.keys())
    terms = ['.+']
    act = lookup_module.run(terms, table, variable_names=variable_names)
    assert act == exp

# Generated at 2022-06-25 11:38:05.931933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:38:10.423351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    var_0 = lookup_module_0.run('qz_.+')
    assert len(var_0) == 2
    assert var_0[0] == 'qz_1'


# Generated at 2022-06-25 11:38:16.763119
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Assign parameter before calling run method of LookupModule
    lookup_module = LookupModule()
    import sys
    terms = '^qz_.+'
    variables = {"qz_1": "a", "qz_2": "b", "qz_3": "c"}
    lookup_module.run(terms, variables=variables)

# Generated at 2022-06-25 11:38:19.708302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with required arguments
    assert lookup_module_0.run(['^qz_.+']) is not None

# Generated at 2022-06-25 11:38:29.462981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with valid terms
    terms = ['', '', '']
    variables = 'foo'
    result = lookup_module_0.run(terms, variables)

    assert result == []

    # Test with invalid 'terms'
    terms = 'error'
    # Specify variables
    variables = 'foo'
    result = None
    try:
        result = lookup_module_0.run(terms, variables)
    except Exception as e:
        pass

    assert result is None

# Generated at 2022-06-25 11:38:40.298745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test of variable options
    variables = {}
    options = None
    # Test of variable terms
    terms_0 = ["^qz_.+"]
    terms_1 = [".+"]
    terms_2 = ["hosts"]
    terms_3 = [".+_zone$", ".+_location$"]
    assert lookup_module_0.run(terms=terms_0, variables=variables, **options) is not None
    assert lookup_module_0.run(terms=terms_1, variables=variables, **options) is not None
    assert lookup_module_0.run(terms=terms_2, variables=variables, **options) is not None
    assert lookup_module_0.run(terms=terms_3, variables=variables, **options) is not None

# Generated at 2022-06-25 11:38:45.409934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [ '^qz_.+' ]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_' : "I won't show either",
    }
    ret_expected = [ 'qz_1', 'qz_2' ]
    ret_actual = lookup_module_1.run(terms, variables)
    assert ret_expected == ret_actual


# Generated at 2022-06-25 11:39:00.778320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Test main code path
    vars_content = dict()
    vars_content["qz_1"] = "hello"
    vars_content["qz_2"] = "world"
    vars_content["qa_1"] = "I wont show"
    vars_content["qz_"] = "I wont show either"
    assert lookup_module_1.run(["^qz_.+"], vars_content) == ["qz_1", "qz_2"]
    # Test main code path with empty match
    assert lookup_module_1.run([""], vars_content) == []
    # Test main code path with empty dict
    vars_content = dict()
    assert lookup_module_1.run([""], vars_content) == []

# Generated at 2022-06-25 11:39:06.977573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run("^qz_.+", {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})


# Generated at 2022-06-25 11:39:14.242564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        '^qz_.+',
    ]
    variables_1 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    kwargs_1 = {}
    ret_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert ret_1 == [
        'qz_1',
        'qz_2',
    ]


# Generated at 2022-06-25 11:39:22.327744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run(['.+']) == []
    assert lookup_module_0.run(['^qz_.+']) == []
    assert lookup_module_0.run(['qz_.']) == []
    assert lookup_module_0.run(['.+']) == []
    assert lookup_module_0.run(['.+']) == []
    assert lookup_module_0.run(['^qz_.+']) == []
    assert lookup_module_0.run(['^qz_.+']) == []
    assert lookup_module_0.run(['^qz_.+']) == []
    assert lookup_module_0.run(['^qz_.+']) == []

# Generated at 2022-06-25 11:39:25.880824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert lookup_module_run.run() == "LookupModule.run"

# Generated at 2022-06-25 11:39:31.579836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {'var_options': variables, 'direct': kwargs}
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:38.180833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ 'qz_.+' ]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
    }
    assert lookup_module.run(terms, variables) == [ "qz_1", "qz_2" ]


# Generated at 2022-06-25 11:39:40.205371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['']
    variables = {}
    assert lookup_module_0.run(terms, variables) == []


# Generated at 2022-06-25 11:39:47.012071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'qz_1': hello, 'qz_2': world, 'qa_1':"I won't show", 'qz_':"I won't show either"}
    terms = '^qz_.+'
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 11:39:54.048900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Run a test against LookupModule.run
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    lookup_module_0.set_environment()
    lookup_module_0.set_vars()
    
    # Use run to check for the presence of a specific variable
    assert(lookup_module_0.run(['MY_VAR'], lookup_module_0.get_vars()) == ['MY_VAR'])

    # Use run to check for the absence of a specific variable
    assert(lookup_module_0.run(['NOT_A_VAR'], lookup_module_0.get_vars()) == [])

# Generated at 2022-06-25 11:40:05.303104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        '^qz_.+',
    ]
    variables = {'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'qz_1': 'hello'}
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)



# Generated at 2022-06-25 11:40:12.664769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    vars_0 = {'hq_1': 'hello', 'hq_2': 'world', 'ha_1': "I won't show", 'hq_': "I won't show either"}
    terms_0 = ['^hq_.+']
    lookup_module.set_options(var_options=vars_0, direct={})
    valid_result = ['hq_1', 'hq_2']
    assert lookup_module.run(terms_0, variables=vars_0) == valid_result
    vars_1 = {'hq_1': 'hello', 'hq_2': 'world', 'ha_1': "I won't show", 'hq_': "I won't show either"}

# Generated at 2022-06-25 11:40:16.737650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Tests that given a list of terms where each is a valid Python regex, the
    return value is a list of all variable names that match one of the terms.
    """
    lookup_module_0 = LookupModule()
    terms_0_0 = ['^qz_.+']
    variables_0_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_0_0 = ['qz_1', 'qz_2']
    assert lookup_module_0.run(terms_0_0, variables_0_0) == expected_0_0
    terms_0_1 = ['.+']

# Generated at 2022-06-25 11:40:19.348502
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:40:24.317655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance
    lookup_module_1 = LookupModule()

    # Invoke method
    try:
        lookup_module_1.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except TypeError:
        print(TypeError)


# Generated at 2022-06-25 11:40:28.751263
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test 1, assert a return value is set
    assert isinstance(lookup_module_0, LookupModule)

    # Test 2, assert len is 1
    assert len(lookup_module_0, terms=[]) == 1


# Generated at 2022-06-25 11:40:34.635275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = (
        ['^qz_.+'],
        {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"},
    )
    kwargs = {
        '_terms': '^qz_.+',
    }
    ret = ['qz_1', 'qz_2']
    assert lookup_module_0.run(*args, **kwargs) == ret


# Generated at 2022-06-25 11:40:39.719484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # variables
    test_terms = ['hosts_.*']
    test_variables = None
    test_kwargs = {}
    # expected
    test_expected = [AnsibleError('No variables available to search')]
    # pre-test
    lookup_module_0 = LookupModule()
    # test
    try:
        lookup_module_0.run(terms=test_terms, variables=test_variables, **test_kwargs)
    except Exception as e:
        # verify test
        assert type(e) == type(test_expected[0])



# Generated at 2022-06-25 11:40:44.753099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
#    terms_0 = ["^qz_.+"]
    terms_0 = [".+"]
    variables_0 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    assert lookup_module_0.run(terms=terms_0, variables=variables_0, _terms=terms_0) == ["qz_", "qz_1", "qz_2", "qa_1"]


# Generated at 2022-06-25 11:40:53.746557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_map = {}
    args_map['variables'] = {'var_0':'var_0 value', 'var_1':'var_1 value', 'var_2':'var_2 value', 'var_3':'var_3 value', 'var_4':'var_4 value', 'var_5':'var_5 value', 'var_6':'var_6 value', 'var_7':'var_7 value', 'var_8':'var_8 value', 'var_9':'var_9 value', 'var_10':'var_10 value'}
    args_map['terms'] = ['var_.+']
    result = lookup_module_0.run(**args_map)

# Generated at 2022-06-25 11:41:07.683825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['hosts']
    variables = {'hosts': 'hosts'}
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 11:41:18.801012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = {
        (('variable1',),):
            'variable1_value',
        ('variable2',):
            'variable2_value',
        ('variable3',):
            'variable3_value',
        ('variable4',):
            'variable4_value',
        ('variable5',):
            'variable5_value',
    }
    parameter_0 = False
    parameter_1 = False
    kwargs_0 = {
        '_variable_name': 'ansible_facts',
        '_lookup_plugin': 'ansible.plugins.lookup.vars',
        '_lookup_module': 'ansible.plugins.lookup.vars'
    }

# Generated at 2022-06-25 11:41:22.131367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["abc"]
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:41:28.205979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['qz_']
    variables_1 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs_1 = {}
    result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert result_1 == ['qz_1', 'qz_2', 'qz_']


# Generated at 2022-06-25 11:41:32.047545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['[^qz_].+', 'qz_']) == ['qa_1']

# Generated at 2022-06-25 11:41:32.570323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mo

# Generated at 2022-06-25 11:41:42.063659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up
    lookup_module = LookupModule()
    lookup_module.module = MockModule()
    lookup_module.module.params = {
        '_original_basename': 'my_playbook',
        '_original_file': 'path/to/my_playbook',
        '_uses_shell': False
    }

    # Exercise
    result = lookup_module.run(terms=['term_0', 'term_1'], variables={'key': 'value'})

    # Assert
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0] == 'value'
    assert result[1] == 'value'


# Generated at 2022-06-25 11:41:45.231311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()
    lookup_module_1.run(terms=None)
    lookup_module_1.run(terms="")

# Generated at 2022-06-25 11:41:49.374076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        '^qz_.+',
    ]
    variables_0 = {
        'qz_1': 'hello',
        'qz_': 'I won\'t show either',
        'qa_1': 'I won\'t show',
        'qz_2': 'world',
    }
    assert lookup_module_0.run(terms=terms_0, variables=variables_0) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:41:54.055074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show"}
    ret = lookup_module_0.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:42:20.797563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    terms_0 = {"^qz_.+"}
    variables_0 = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    values_0 = lookup_module_0.run(terms_0, variables_0)
    print(values_0)

# Generated at 2022-06-25 11:42:31.443062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['^qz_.+']
    variables_1 = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u'I won\'t show', u'qz_': u'I won\'t show either'}
    try:
        value_1 = lookup_module_1.run(terms=terms_1, variables=variables_1)
        assert value_1 == [u'qz_1', u'qz_2']
    except AnsibleError:
        print('AnsibleError raised for variables: %s' % variables_1)
    lookup_module_2 = LookupModule()
    terms_2 = ['.+']

# Generated at 2022-06-25 11:42:44.511961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  f = open("test_LookupModule_run_0.txt", 'w+')
  lookup_module_0 = LookupModule()
  terms_0 = "^qz_.+"
  variables_0 = dict()
  variables_0['qz_1'] = 'hello'
  variables_0['qz_2'] = 'world'
  variables_0['qa_1'] = "I won\'t show"
  variables_0['qz_'] = "I won\'t show either"
  f.write(str(lookup_module_0.run(terms_0, variables_0)))
  f.close()
  f = open("test_LookupModule_run_1.txt", 'w+')
  lookup_module_1 = LookupModule()
  terms_1 = ".+"
  variables_

# Generated at 2022-06-25 11:42:45.959252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    match_obj_0 = re.search("qz_", "qz_2")


# Generated at 2022-06-25 11:42:48.249854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "^qz_.+"
    result = lookup_module_0.run(terms, 'variables')

# Generated at 2022-06-25 11:42:56.934921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    # Test setup
    mock_terms = ['^qz_.+']
    mock_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ansible_results = lookup_module_run.run(mock_terms, mock_variables)
    assert ansible_results == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:42:58.478965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([[]])

# Generated at 2022-06-25 11:43:07.233534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []
    assert lookup_module_1.run([""]) == []
    assert lookup_module_1.run([" ", ""]) == []
    assert lookup_module_1.run(["abc"]) == []
    assert lookup_module_1.run(["abc", ""]) == []
    assert lookup_module_1.run(["abc", "def"]) == []
    assert lookup_module_1.run([".+"]) == []
    obj_1 = {" ": [], "": [], "xyz": [], "abc_xyz": [1], "xyz_abc": [1], "xyz_": [], "xyz_abc_": [1]}

# Generated at 2022-06-25 11:43:12.526411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test environment
    # Define expected values for method run for test case 0
    test_terms_0 = ['^qz_.+']
    test_variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    test_ret_0 = ['qz_1', 'qz_2']

    # Executing LookupModule.run with arguments: test_terms_0, test_variables_0
    # Executing call to method run of class LookupModule
    ret = LookupModule().run(test_terms_0, test_variables_0)

    # Verifying that the returned value of method run of class LookupModule equals the expected value

# Generated at 2022-06-25 11:43:13.941666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_string = "qz_.+"
    lookup_module_object = LookupModule()
    lookup_module_object.run(input_string)

# Generated at 2022-06-25 11:44:11.149990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {"a":"foo", "b":"bar"}
    terms = []
    ret = lookup_module._flatten(terms)
    ret = lookup_module.run(terms, variables, {'other': 'value'})

# Generated at 2022-06-25 11:44:16.660476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'qz_1' in lookup_module_0.run("^qz_.+",vars)

# Another unit test for method run of class LookupModule

# Generated at 2022-06-25 11:44:22.438733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test AnsibleError cases
    try:
        lookup_module_0 = LookupModule()
        ret = lookup_module_0.run([''], variables={})
        assert False # Shouldn't get here
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test for empty terms
    try:
        lookup_module_0 = LookupModule()
        ret = lookup_module_0.run([], variables={'a': 'aaa', 'b': 'bbb'})
        assert ret == []
    except:
        assert False # Shouldn't get here

    # Test for invalid term

# Generated at 2022-06-25 11:44:32.318170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={u'foo': u'bar'}, direct={})
    lookup_module_0.run([u'^qz_.+'])
    lookup_module_0.run([u'.+'])
    lookup_module_0.run([u'hosts'])
    lookup_module_0.run([u'.+_zone$', u'.+_location$'])


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:44:41.208497
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:44:51.367212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=[1, 2, 3]) == []
    assert lookup_module_0.run(terms=['^qz_.+']) == []
    assert lookup_module_0.run(terms=['^qz_.+', '^qz_.+']) == []
    assert lookup_module_0.run(terms=['^qz_.+', '^qz_.+'], variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:44:54.357387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = {'foo':'', 'foobar':''}
    terms_0 = ['foo', 'bar']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms_0, vars_0) == ['foo']

# Generated at 2022-06-25 11:45:05.101587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = '^qz_.+'
    lookup_module_1.run(terms_2, variables={'qz_': 'I won\'t show either', 'qa_1': 'I won\'t show', 'qz_2': 'world', 'qz_1': 'hello'})
    terms_3 = '.+'
    lookup_module_1.run(terms_3, variables={'qz_': 'I won\'t show either', 'qa_1': 'I won\'t show', 'qz_2': 'world', 'qz_1': 'hello'})
    terms_4 = 'hosts'

# Generated at 2022-06-25 11:45:06.951866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['.+_zone$', '.+_location$'], {'ansible_zone': 'foobar', 'ansible_location': 'kazoo'})

# Generated at 2022-06-25 11:45:15.477500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(direct={'_terms': ['^qz_.+'], 'variables': {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}})
    assert ['qz_1', 'qz_2'] == lookup_module_1.run(['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})


# Generated at 2022-06-25 11:46:24.388275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret_len_0 = len(lookup_module_0.run(terms=[''], variables={"a": "a", "b": "b", "c": "c"}))
    print(ret_len_0)
    assert ret_len_0 == 3


# Generated at 2022-06-25 11:46:34.300027
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = [u'^qz_.+']
    variables_0 = {u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either", u'qz_1': u'hello'}
    kwargs = {}
    result = lookup_module_0.run(terms_0, variables_0, **kwargs)
    assert result == [u'qz_2', u'qz_1']

    lookup_module_1 = LookupModule()
    terms_1 = [u'^qz_.+']

# Generated at 2022-06-25 11:46:35.036094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run(terms=terms)


# Generated at 2022-06-25 11:46:41.132512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ALIAS_DICT = dict(key='val')
    lookup_mock = LookupModule()
    result = []
    result.append(lookup_mock.run(['.+_zone$', '.+_location$'], ALIAS_DICT))
    assert result == [[]]

# Generated at 2022-06-25 11:46:41.567575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 11:46:47.999525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestAnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=True,
                     mutually_exclusive=None, required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.__dict__.update(locals())

        def fail_json(self, *args, **kwargs):
            raise AnsibleError(kwargs['msg'])

    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:46:51.252930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    e = None
    try:
        lookup_module_1.run(terms=[], variables=None)
    except Exception as e_:
        e = e_
    assert isinstance(e, AnsibleError)


# Generated at 2022-06-25 11:46:55.536913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Check if the run method works when given parameters are in use
    """
    lookup_module_1 = LookupModule()
    terms = ['qz_2']
    variables = {'qz_1': '1', 'qz_2': '2'}
    lookup_module_1.run(terms, variables)

    """
    Check if the run method works when given parameters are not in use
    """
    lookup_module_2 = LookupModule()
    terms = []
    variables = {'qz_1': '1', 'qz_2': '2'}
    lookup_module_2.run(terms, variables)

# Generated at 2022-06-25 11:46:56.949010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    vars_1 = dict()
    lookup_module_1.run(terms=['^qz_.+'], variables=vars_1)

# Generated at 2022-06-25 11:47:04.009904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '^qz_.+'
    vars_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs_0 = {'direct': {'var': 'qz_1'}}
    assert lookup_module_0.run(terms=term_0, **kwargs_0) == ['qz_1', 'qz_2']
    assert lookup_module_0.run(terms=term_0, **kwargs_0) == ['qz_1', 'qz_2']