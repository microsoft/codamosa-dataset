

# Generated at 2022-06-25 11:37:49.639825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs_0 = {}
    ret = lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0)
    assert type(ret) is list, 'Expected return value to be of type list, but is not.'
    assert ret, ("Expected %s, but got %s" % ('list', ret))
    assert 'qz_1' in ret, ("Expected %s to be in %s, but is not." % ('qz_1', ret))

# Generated at 2022-06-25 11:37:54.555682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})


# Generated at 2022-06-25 11:38:03.013604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test case for "run" method of class LookupModule

    Verify:
    * correct return when required parameters provided
    * correct error message raised when required parameters not provided
    * correct error message and type for invalid parameters
    """

    # Test case for method run
    # Case with required parameters provided
    lookup_module_0 = LookupModule()
    terms_1 = ['^qz_.+']
    variables_1 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
        'qz_': 'I wont show either'
    }
    if lookup_module_0.run(terms_1, variables_1) != ['qz_1', 'qz_2']:
        return False # Incorrect return of "run" method

# Generated at 2022-06-25 11:38:13.669725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, direct={})
    v = lookup_module_0.run(terms=['^qz_.+'],variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert v == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:38:21.293359
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = {
        '_terms': 'hosts'
    }

    variables = {
        'somthing': 'nothing',
        'somehosts': 'something',
        'main.yml': 'main.yml',
        'inventory_hosts': 'inventory_hosts'
    }
    
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=args['_terms'], variables=variables) == ['somehosts', 'inventory_hosts']

# Generated at 2022-06-25 11:38:31.545646
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Test with empty arguments
    try:
        lookup_module_1.run([], None)
    except AnsibleError as exception:
        assert str(exception) == 'No variables available to search', exception

    # Test with invalid arguments
    try:
        lookup_module_1.run([{}], None)
    except AnsibleError as exception:
        assert str(exception) == 'Invalid setting identifier, "{}" is not a string, it is a <class \'dict\'>', exception

    # Test with valid arguments

# Generated at 2022-06-25 11:38:41.719667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert lookup_module_0.run(terms = ['^qz_.+'], variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won'}) 
  assert lookup_module_0.run(terms = ['.+'], variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won'}) 
  assert lookup_module_0.run(terms = ['hosts'], variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won'}) 

# Generated at 2022-06-25 11:38:51.407802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with vars
    lookup = LookupModule()
    result = lookup.run(terms=['^qz_.+'],
                        variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']

    # Testing without vars
    lookup = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        result = lookup.run(terms=['^qz_.+'], variables=None)
    assert 'No variables available to search' in str(excinfo.value)

    # Testing with invalid regex
    lookup = LookupModule()

# Generated at 2022-06-25 11:39:00.297094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Should pass if:
    # 1. creating instance of lookup class
    # 2. the returned value is not None
    try:
        terms = ['^qz_.+']
        variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
        lookup_module = LookupModule()
        lookup_module.run(terms, variables=variables)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 11:39:12.700681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys
    import os


# Generated at 2022-06-25 11:39:20.598476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms=terms_0, variables=variables_0)
        lookup_module_0.run(terms=terms_1, variables=variables_1)
        lookup_module_0.run(terms=terms_2, variables=variables_2)
    except Exception as e:
        print(e)
        raise Exception

terms_0 = ['^qz_.+']

variables_0 = {
    'qz_1': 'hello',
    'qz_2': 'world',
    'qa_1': 'I won\'t show',
    'qz_': 'I won\'t show either'
}


# Generated at 2022-06-25 11:39:21.970339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 11:39:27.045413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run

    # dummy variables and terms for the test
    variables = {}
    terms = []

    try:
        lookup_module_run(terms, variables)
    except AnsibleError:
        pass

# Generated at 2022-06-25 11:39:38.237290
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockVariables:
        pass

    # this testcase is an example when there is no varaibles to search
    # case when no variables to search
    #assert test_case_0() == False

    # case when there are variables to search
    lookup_module = LookupModule()
    var = MockVariables()
    var.term = "varname"
    var.var1 = "value1"
    var.var2 = "value2"
    var.var3 = "value3"
    var.var4 = "value4"
    var.var5 = "value5"
    var.var6 = "value6"
    var.var7 = "value7"
    var.var8 = "value8"
    var.var9 = "value9"
    var.var10 = "value10"
   

# Generated at 2022-06-25 11:39:39.302909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 11:39:44.927549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(lookup_module_1)


# Generated at 2022-06-25 11:39:52.795891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:39:54.593235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms, variables=None, kwargs=None)

# Generated at 2022-06-25 11:39:58.726765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, lookup_module_1)


# Generated at 2022-06-25 11:40:08.084957
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with invalid terms
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    res_0 = [ 'var_0' ]

    # Test case with valid terms
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, lookup_module_1)
    res_1 = [ 'var_1' ]

    # Test case with missing terms
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2, lookup_module_2)
    res_2 = [ 'var_2' ]

    # Test case with empty terms
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:40:19.576081
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_case_0():
        lookup_module_0 = LookupModule()
        var_0 = lookup_run(lookup_module_0, lookup_module_0)

    def test_case_1():
        lookup_module_1 = LookupModule()
        var_1 = lookup_run(lookup_module_1, lookup_module_1)

    def test_case_2():
        lookup_module_2 = LookupModule()
        var_2 = lookup_run(lookup_module_2, lookup_module_2)

    def test_case_3():
        lookup_module_3 = LookupModule()
        var_3 = lookup_run(lookup_module_3, lookup_module_3)

# Generated at 2022-06-25 11:40:22.281652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 11:40:24.970935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == None


# Generated at 2022-06-25 11:40:26.405837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run')
    test_case_0()

# Test for class LookupModule

# Generated at 2022-06-25 11:40:36.255081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Assigning some test values to variables.

# Generated at 2022-06-25 11:40:45.978943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=test_1_terms, variables=test_1_variables)
    assert lookup_module_1.run(terms=test_1_terms, variables=test_1_variables) == test_1_ret_lookup_run
    # Test 2
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms=test_2_terms, variables=test_2_variables)
    assert lookup_module_2.run(terms=test_2_terms, variables=test_2_variables) == test_2_ret_lookup_run
    # Test 3
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:40:47.923774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    var = lookup_run(lookup_module_run, lookup_module_run)
    assert var == dict()


# Generated at 2022-06-25 11:40:53.206092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["foo", "bar"], "baz") == "baz"

# Generated at 2022-06-25 11:40:55.314287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms='')


# Generated at 2022-06-25 11:40:57.466207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, lookup_module_1)

# Generated at 2022-06-25 11:41:07.526674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run('^qz_.+', {})
    assert var_1 == []



# Generated at 2022-06-25 11:41:09.590107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module, lookup_module)
    assert len(var) == 2
    assert isinstance(var, list)

# Generated at 2022-06-25 11:41:18.961882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = (
        ('^qz_.+',),  # terms
        {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'},  # variables
        {}  # kwargs
    )

# Generated at 2022-06-25 11:41:26.703534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ u'^qz_.+' ]
    var_0 = {
        u'qz_1': u'hello' ,
        u'qz_2': u'world' ,
        u'qa_1': u'I won\'t show' ,
        u'qz_': u'I won\'t show either' ,
    }
    var_0 = lookup_run(lookup_module_0, lookup_module_0, terms=terms_0, variables=var_0)
    assert var_0 == [ u'qz_1', u'qz_2' ]


# Generated at 2022-06-25 11:41:36.384798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1: lookup_module_0 = lookkup('varnames', '^qz_.+', 'qa_1')
    # Test case 1: lookup_module_0 = lookkup('varnames', '^qz_.+', 'qa_1')
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0[0] == 'qz_1'
    assert var_0[1] == 'qz_2'

# Generated at 2022-06-25 11:41:40.882016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert len(var_0) == 2
    assert var_0[0] == 'qz_1'
    assert var_0[1] == 'qz_2'


# Generated at 2022-06-25 11:41:48.291821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run(LookupModule(), LookupModule()) == []
    assert lookup_run(LookupModule(), LookupModule(), []) == []
    assert lookup_run(LookupModule(), LookupModule(), ["1"]) == ["1"]
    assert lookup_run(LookupModule(), LookupModule(), ["1", "2"]) == ["1", "2"]
    assert lookup_run(LookupModule(), LookupModule(), ["1", "2"], ["3"]) == ["1", "2", "3"]
    assert lookup_run(LookupModule(), LookupModule(), ["1", "2"], ["3"], ["4"]) == ["1", "2", "3", "4"]


# Generated at 2022-06-25 11:41:50.864650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[], variables={}, **{})

test_case_0()

# Generated at 2022-06-25 11:41:51.969325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.run()

# Generated at 2022-06-25 11:41:54.030562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:42:08.804461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params
    terms = None

    # Output params
    # Return value
    try:
        lookup_module = LookupModule()
        lookup_module.run(terms)
    except Exception as e:
        assert type(e) == AnsibleError
        assert str(e) == 'No variables available to search'



# Generated at 2022-06-25 11:42:13.902610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # This unit test is pending
    var_1 = lookup_run(lookup_module_1, lookup_module_1)

    assert var_1 == None #, 'Unexpected value for lookup_module_1.run(). Expected None and got ' + str(var_1) + '.'


# Generated at 2022-06-25 11:42:15.836864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run({'terms':'terms'}, {'variables':'variables'},{'':'.'}, )

# Generated at 2022-06-25 11:42:20.529762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ["^qz_.+"]
    variables_0 = {"qa_1": "I won't show", "qz_2": "world", "qz_1": "hello", "qz_": "I won't show either"}
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    print(ret_0)


# Generated at 2022-06-25 11:42:22.280428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 11:42:33.483233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    name = '^qz_.+'
    terms = []
    terms.append(name)
    lookup_options = dict()
    lookup_options['_terms'] = terms
    variables = dict()
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"
    lookup_options['variables'] = variables
    lookup_module = LookupModule()
    result = lookup_module.run(terms=lookup_options['_terms'], variables=lookup_options['variables'], **lookup_options)
    assert len(result) == 2
    assert result[0] == 'qz_1'

# Generated at 2022-06-25 11:42:34.786756
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)



# Generated at 2022-06-25 11:42:38.053868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  input_var_0 = "ansible_eth0"
  if not lookup_module_0.run(input_var_0) == expected_output_0:
    raise Exception("Test case 0 failed")

# This function is called by the test function above

# Generated at 2022-06-25 11:42:43.788022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'qz_1'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': "I won't show either"}
    kwargs = {'vars': variables}
    lookup_module_0 = LookupModule()
    lookup_run(lookup_module_0, lookup_module_0, terms, **kwargs)

# Generated at 2022-06-25 11:42:51.241639
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:43:15.503553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = var_0
    var_2 = None
    var_1 = lookup_module_1.run(var_1, var_2)
    assert var_1 is not None
    assert var_1 == []


# Generated at 2022-06-25 11:43:25.725804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = dict()
    vars_0['qz_2'] = 'world'
    vars_0['qz_'] = "I won't show either"
    vars_0['qz_1'] = 'hello'
    vars_0['qa_1'] = "I won't show"
    lookup_module_1 = LookupModule()
    lookup_module_1._load_name = 'ansible.plugins.lookup.varlookup'
    lookup_module_1._display.warning = lambda x: None
    lookup_module_1.set_options(var_options=vars_0)
    var_1 = lookup_run(lookup_module_1, lookup_module_1)
    assert var_1 == ['qz_1', 'qz_2', 'qz_']



# Generated at 2022-06-25 11:43:34.024121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test case 1
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    term = 'qz_.+'
    expected_result = ['qz_1', 'qz_2']

    actual_result = lookup_module.run(term, variables)

    assert actual_result == expected_result

    # Test case 2
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    term = '.+'

# Generated at 2022-06-25 11:43:45.453172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'qz_1': 'hello',
             'qz_2': 'world',
             'qa_1': "I won't show",
             'qz_': "I won't show either"}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=var_0, direct=None)
    terms_0 = ['^qz_.+']
    lookup_module_0.run(terms_0, var_0)
    assert var_0 == {'qz_1': 'hello',
                     'qz_2': 'world',
                     'qa_1': "I won't show",
                     'qz_': "I won't show either"}
    assert term == '^qz_.+'


# Generated at 2022-06-25 11:43:46.593664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    assert lookup_instance.run(terms, variables=None, **kwargs) == ret

# Generated at 2022-06-25 11:43:47.895031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)



# Generated at 2022-06-25 11:43:49.366548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Unit test fixture for method run of class LookupModule

# Generated at 2022-06-25 11:43:59.452517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = None
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(terms, variables=var_0, **kwargs)
    assert var_1 == ['qz_1', 'qz_2', 'qz_']
    var_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    var_1 = lookup_module_0.run(terms, variables=var_0, **kwargs)
    assert var_1 == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-25 11:44:02.285783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Indirection for Ansible lookup plugins

# Generated at 2022-06-25 11:44:04.076828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)




# Generated at 2022-06-25 11:44:53.542428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 11:44:56.230516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['']
    variables = {'a': 1, 'b': 2, 'c': 3}
    kwargs = {}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['']


# Generated at 2022-06-25 11:44:59.693611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert jceks_file == '/path/to/file.jceks'

# Generated at 2022-06-25 11:45:09.829394
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Output should be the same as input
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'],'qz_1') == 'qz_1'

    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'],'qz_2') == 'qz_2'

    lookup_module = LookupModule()
    assert lookup_module.run(['^zz_.+'],'qz_1') == ''

    lookup_module = LookupModule()
    assert lookup_module.run(['^zz_.+'],'qz_2') == ''

    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+', '^qa_.+'],'qz_1') == 'qz_1'



# Generated at 2022-06-25 11:45:17.005167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, '^qz_.+')
    assert len(var_0) == 2
    var_1 = lookup_run(lookup_module_0, '.+')
    assert len(var_1) == 4
    var_2 = lookup_run(lookup_module_0, 'hosts')


# Generated at 2022-06-25 11:45:20.353781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert var_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:45:25.430319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None, None)
    var_0 = lookup_module_0.run(1, 2)
    var_0 = lookup_module_0.run('a', 'b')


# Generated at 2022-06-25 11:45:31.871538
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:45:40.251145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'var_0': 'var_1'}
    terms_0 = ['var_0']
    # Verify if an exception is raised for an instance of class LookupModule
    with pytest.raises(AnsibleError):
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms_0, var_0)
    # Verify if an exception is raised for an instance of class LookupModule
    with pytest.raises(AnsibleError):
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:45:46.674273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([''], {'var_0': 'var_0_value'}, direct={'var_1': 'var_1_value'})
    assert len(var_0) == 0
    var_1 = lookup_module_0.run(['.+'], {'var_0': 'var_0_value'}, direct={'var_1': 'var_1_value'})
    assert var_1[0] == 'var_0'
    var_2 = lookup_module_0.run(['.+'], {'var_0': 'var_0_value'}, direct={'var_1': 'var_1_value'})
    assert var_2[0] == 'var_0'
