

# Generated at 2022-06-25 11:37:42.124953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # LookupModule.run(terms, variables=None, **kwargs)
    lookup_module_0.run("")


# Generated at 2022-06-25 11:37:46.894999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  expected = ['qz_1', 'qz_2']
  actual = lookup_module_0.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
  assert actual == expected

# Generated at 2022-06-25 11:37:49.853485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms=[],variables=None,**{})
        raise Exception("It should be an error")
    except AnsibleError as e:
        print(e.message)


# Generated at 2022-06-25 11:37:58.325047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = dict()
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"
    result = lookup_module_0.run(terms, variables)
    assert result == ['qz_1', 'qz_2']
    assert result[0] == 'qz_1'
    assert result[1] == 'qz_2'


# Generated at 2022-06-25 11:38:10.110350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid inputs
    assert lookup_module_0.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup_module_0.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-25 11:38:21.962702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:38:31.574017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 1:
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(['^qz_.+'])
    assert (result == ['qaz.qaz'])
    # Case 2:
    lookup_module_2 = LookupModule()
    result = lookup_module_2.run(['^qz_.+'])
    assert (result == ['qaz.qaz'])
    # Case 3:
    lookup_module_3 = LookupModule()
    result = lookup_module_3.run(['^qz_.+'])
    assert (result == ['qaz.qaz'])
    # Case 4:
    lookup_module_4 = LookupModule()
    result = lookup_module_4.run(['^qz_.+'])

# Generated at 2022-06-25 11:38:41.719153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test if correct list of variable names is returned
    """
    lookup_module_0 = LookupModule()
    # Test string inputs
    input_string = 'qz_'
    result_string = lookup_module_0.run(terms=input_string, variables={'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"})
    assert isinstance(result_string, list)
    assert result_string == ["qz_1", "qz_2"]
    # Test list inputs
    input_list = ['qz_', 'qz_']

# Generated at 2022-06-25 11:38:44.844861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^hello$']
    variables = {'hello': 'world', 'not hello': 'a string'}
    assert lookup_module.run(terms, variables=variables) == ['hello']



# Generated at 2022-06-25 11:38:49.105244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ''
    variables = ''
    lookup_module_0 = LookupModule()
    
    assert lookup_module_0.run(terms,variables) == []

# Generated at 2022-06-25 11:38:56.606941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run([])
    except AnsibleError as e:
        assert "No variables available to search" in e.error

    lookup_module_1 = LookupModule()
    var_1 = { 'test_value': 'test_value'}
    lookup_module_1.set_options(var_options=var_1, direct={'test_direct': 'test_direct'})
    assert lookup_module_1.run([]) == []

# Generated at 2022-06-25 11:39:02.466573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "qz_.+"
    variables_0 = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
    }
    ret_0 = lookup_module_0.run(terms_0, variables=variables_0)
    assert ret_0 == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:39:09.169954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["^qz_.+"]
    variables_0 = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    assert lookup_module_0.run(terms_0, variables_0) == ["qz_1", "qz_2"]



# Generated at 2022-06-25 11:39:18.712398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {
        'qa_1': "I won't show",
        'qz_1': "I will show",
        'qz_2': "I will show too",
        'qz_': "I won't show either"
    }

    terms = [
        '^qz_.+',
        '^qa_.+'
    ]

    lookup_module_1 = LookupModule()
    results = lookup_module_1.run(terms, variables=vars)
    assert results == ['qz_1', 'qz_2'], results
    assert isinstance(results, list)

# Generated at 2022-06-25 11:39:26.510792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'a_1': 1, 'a_2': 2, 'b_1': 100, 'c_1': 'lol'}
    terms = ['^a_.', '^b_.']
    expected_result = ['a_1', 'a_2', 'b_1']
    result = LookupModule().run(terms, variables=vars)
    assert result == expected_result

# Generated at 2022-06-25 11:39:31.080419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        None,
    ]
    variables_0 = {
        str(): None,
    }
    kwargs_0 = {
        str(): None,
    }
    assert_expect(lookup_module_0.run(terms_0, variables_0, **kwargs_0))



# Generated at 2022-06-25 11:39:38.032208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_module_0.run(terms, variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:39:41.263828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-25 11:39:48.127179
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 0
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    terms = ['^qz_.+']
    assert lookup_module_0.run(terms, variables) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:53.368836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms='test')
    assert not lookup_module.run(terms='test_fail')
    assert lookup_module.run(terms='test_fail', variables={'test_fail': 'test_fail'})
    assert not lookup_module.run(terms={})

# Generated at 2022-06-25 11:40:08.312623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["^qz_.+"], {"qz_1":"hello","qz_2":"world","qa_1":"I won't show","qz_":"I won't show either"}) ==  ['qz_1', 'qz_2']
    assert lookup_module_0.run([".+"], {"qz_1":"hello","qz_2":"world","qa_1":"I won't show","qz_":"I won't show either"}) ==  ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-25 11:40:17.307345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We'll assume the variables are named 'variable_[0-9]+'
    # and the names of the variables are accessed in lookup_module.py using the
    # term 'variable [0-9]+'.
    variables_0 = dict()
    for i in range(20):
        name = 'variable_' + str(i)
        variables_0[name] = 'name of variable ' + str(i)
    terms_0 = ['variable [0-9]+']
    lookup_module_0 = LookupModule()
    try:
        ret_value = lookup_module_0.run(terms_0, variables=variables_0)
    except Exception as e:
        # Uncomment the next line to debug the issue
        # print(e)
        raise e

    # Test for desired return value

# Generated at 2022-06-25 11:40:23.456102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['"^qz_.+"', '".+"', '"hosts"', '".+_zone$", ".+_location$"']

    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    expected_result = [['qz_1', 'qz_2'], ['qz_1', 'qz_', 'qz_2', 'qa_1'], ['qz_1', 'qz_', 'qz_2'], ['qz_1', 'qz_']]

    for term in terms:
        result = lookup_module.run(terms=[term], variables=variables)
        assert result == expected_

# Generated at 2022-06-25 11:40:25.302328
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initializing object
    lookup_module_0 = LookupModule()

    # call method
    lookup_module_0.run(terms=[])



# Generated at 2022-06-25 11:40:35.191392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test exceptions
    lookup_module_0.set_options()
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    # Test with simple regex.
    lookup_module_0.run(terms, variables)
    # Test with .+* regex.
    terms = ['.+']
    lookup_module_0.run(terms, variables)
    # Test with mid regex.
    terms = ['hosts']

# Generated at 2022-06-25 11:40:45.901469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        '^qz_.+',
        '.+',
        'hosts',
        '.+_zone$',
        '.+_location$',
    ]

# Generated at 2022-06-25 11:40:48.430829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    helptext = """Retrieves a list of matching Ansible variable names."""
    assert test_case_0.run.__doc__ == helptext

    assert test_case_0.run(terms=["terms"]) == []



# Generated at 2022-06-25 11:40:53.206099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=["abc"], variables={"abc": "abc_variable"})

# Generated at 2022-06-25 11:40:56.676321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # 1. Create a new instance of LookupModule class
    # 2. Run method 'run' of lookup_module_0
    # 3. Run method 'set_options' of lookup_module_0
    # 4. Verify 'ret' is a type of list
    ret = lookup_module_0.run(terms_arg = [u'^qz_.+'], variables_arg = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})
    assert (isinstance(ret, list)), 'Expected type of variable is list instead of {}'.format(type(ret))


# Generated at 2022-06-25 11:41:04.858369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Empty values for args
    ret = lookup_module_0.run()
    assert ret == [], "Empty values for args"
    # Empty values for args
    ret = lookup_module_0.run(None, None)
    assert ret == [], "Empty values for args"
    # Empty values for args
    ret = lookup_module_0.run([], {})
    assert ret == [], "Empty values for args"

# Generated at 2022-06-25 11:41:23.345105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   terms = '^qz_.+'
   variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
   kwargs = {}
   lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:41:27.273040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = '^qz_.+'
    variables = {"qz_1":"hello", "qz_2":"world", "qa_1":"I won't show", "qz_":"I won't show either"}
    ret = ['qz_1', 'qz_2']
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([term], variables) == ret


# Generated at 2022-06-25 11:41:37.189477
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['^qz_.+']
    variables={'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=None)
    result = lookup_module_0.run(terms)

    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'qa_1' not in result
    assert 'qz_' not in result

# Generated at 2022-06-25 11:41:45.976279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert (not lookup_module_0.run(['^qz_.+', '.+_location$'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'one_zone': 'one_zone', 'two_zone': 'two_zone', 'three_zone': 'three_zone', 'one_location': 'one_location', 'two_location': 'two_location', 'three_location': 'three_location'}, direct={}))

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:41:48.275466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=None)
    lookup_module_1.run(terms=[], variables=None)

# Generated at 2022-06-25 11:42:00.753374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_terms = ["^qz_.+"]
    var_variables = {u'qz_2': u'world', u'qz_1': u'hello'}
    var_add_variables = {u'qz_2': u'world', u'qz_1': u'hello'}
    expected_result = [u'qz_2', u'qz_1']
    try:
        result = lookup_module_0.run(var_terms, var_variables)
    except Exception as e:
        var_msg = "Unable to use \"%s\" as a search parameter: %s" % (var_terms, to_native(e))
        raise AnsibleError(var_msg)
    assert result == expected_result

# Generated at 2022-06-25 11:42:08.285626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    lookup_module_run_0 = LookupModule()

    try:
        result = lookup_module_run_0.run(["^qz_.+"], variables=vars)
    except Exception as e:
        raise AnsibleError(e)

    return result



# Generated at 2022-06-25 11:42:17.686332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Testing the return type of function run
    # Testing when parameter 'terms' is of type list
    assert isinstance(lookup_module.run(terms=['^qz_.+']), list)

    # Testing when parameter 'terms' is of type tuple
    assert isinstance(lookup_module.run(terms=('^qz_.+',)), list)

    # Testing when parameter 'terms' is of type set
    assert isinstance(lookup_module.run(terms={'^qz_.+'}), list)

    # Testing when parameter 'terms' is of type immutable set
    assert isinstance(lookup_module.run(terms=frozenset(('^qz_.+',))), list)

    # Testing when parameter 'terms' is of type str

# Generated at 2022-06-25 11:42:22.935571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    from ansible.plugins import lookup_loader
    LookupModule._lookup_name = 'varnames'
    LookupModule._loaders = lookup_loader._get_loaders()
    terms = [u'^qz_.+']
    variables = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    kwargs = {}
    lookup_module_0 = LookupModule()
    # Test execution
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == [u'qz_1', u'qz_2']


# Generated at 2022-06-25 11:42:26.975072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variable_names = {"a":"a","b":"b","c":"c","d":"d"}
    terms = ["a","b","c","d"]
    variable = {"param":"param"}



# Generated at 2022-06-25 11:42:59.335257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(['qz_1', 'qa_1'], {'qz_1': 'hello', 'qa_1': 'world'})
    assert results[0] == 'qz_1'
    assert results[1] == 'qa_1'

    results = lookup_module.run(['qa_1', 'qz_1'], {'qz_1': 'hello', 'qa_1': 'world'})
    assert results[0] == 'qa_1'
    assert results[1] == 'qz_1'

# Generated at 2022-06-25 11:43:04.885614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(
        terms=[
            '^qz_.+'],
        variables=dict(
            qz_1='hello',
            qz_2='world',
            qa_1="I won't show",
            qz_="I won't show either"
        )
    ) == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:43:13.640960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args = dict(
        _terms=[
            '^qz_.+'
        ],
        vars={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either"
        }
    )
    expected = ['qz_', 'qz_1', 'qz_2']

    lookup_module_0 = LookupModule()
    actual = lookup_module_0.run(**module_args)

    assert actual == expected

# Generated at 2022-06-25 11:43:23.134313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize search terms
    term_0 = '^qz_.+'
    term_1 = '.+'
    term_2 = 'hosts'
    term_3 = '.+_zone$'
    term_4 = '.+_location$'
    # initialize variables
    variable_0 = 'qz_1'
    variable_1 = 'qz_2'
    variable_2 = 'qa_1'
    variable_3 = 'qz_'
    value_0 = 'hello'
    value_1 = 'world'
    value_2 = "I won't show"
    value_3 = "I won't show either"

# Generated at 2022-06-25 11:43:27.312967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [".*ip.*"]
    variables = {'ansible_default_ipv4': {'aliases': ['ansible_ssh_host'], 'address': '192.168.1.101'}}
    assert lookup_module.run(terms, variables) == [u'ansible_default_ipv4']

# Generated at 2022-06-25 11:43:30.313355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    value = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert value == []



# Generated at 2022-06-25 11:43:36.640893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([],{}) == []
    assert lookup_module.run(['c'],{'aa': 'aa', 'bb': 'bb', 'cc': 'cc'}) == ['cc']
    assert lookup_module.run(['^c'],{'aa': 'aa', 'bb': 'bb', 'cc': 'cc'}) == ['cc']
    assert lookup_module.run(['c$'],{'aa': 'aa', 'bb': 'bb', 'cc': 'cc'}) == ['cc']
    assert lookup_module.run(['a'],{'aa': 'aa', 'bb': 'bb', 'cc': 'cc'}) == ['aa']

# Generated at 2022-06-25 11:43:45.685910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms = '^qz_.+', variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    lookup_module_1.run(terms = '.+', variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    lookup_module_1.run(terms = 'hosts', variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    lookup_module_

# Generated at 2022-06-25 11:43:48.581434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=[to_native('^qz_.+')])
    assert ret == [to_native('qz_1'), to_native('qz_2'), to_native('qz_')], 'Unexpected return from LookupModule.run: %s' % ret


# Generated at 2022-06-25 11:43:53.617463
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with variable name is not a string
    with pytest.raises(AnsibleError, match='Invalid setting identifier, "10" is not a string, it is a <class \'int\'>'):
        terms = [10]
        lookup_module_0.run(terms, variables)
    
    # Test case with variable name is not a string
    with pytest.raises(AnsibleError, match='Invalid setting identifier, "10" is not a string, it is a <class \'int\'>'):
        terms = ['^qz_.+', 10]
        lookup_module_0.run(terms, variables)
    
    # Test case with variables is None
    with pytest.raises(AnsibleError, match="No variables available to search"):
        terms = ['^qz_.+']
        lookup

# Generated at 2022-06-25 11:44:57.462156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test AnsibleError thrown with direct access of private variable _options
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    try:
        lookup_module_0.run(terms_0)
    except Exception as exception_instance:
        if type(exception_instance) is not AnsibleError:
            raise AssertionError(
                'Expected exception of type {0}, got {1}'.format(
                    AnsibleError, type(exception_instance)
                )
            )
        assert exception_instance.message == 'No variables available to search'


# Generated at 2022-06-25 11:44:59.773924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run of LookupModule")


# Generated at 2022-06-25 11:45:06.508861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=['^qz_.+'], 
          variables={"qz_1": "hello",
                     "qz_2": "world",
                     "qa_1": "I won't show",
                     "qz_": "I won't show either"})

# Generated at 2022-06-25 11:45:08.812153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['2']
    variables = {
        '1': '2'
    }
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) == ['1']


# Generated at 2022-06-25 11:45:14.392036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "var"
    var1 = "var1"
    var2 = "var2"
    var_dict = {var1: "asd", var2: "asd"}
    lookup_module = LookupModule()
    result = lookup_module.run(terms=[term], variables=var_dict)
    assert result == [var1, var2]  # PASS



# Generated at 2022-06-25 11:45:20.564454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['.+_zone$', '.+_location$']
    variables_0 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    kwargs_0 = {}
    # result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    # assert result == ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-25 11:45:25.460756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0=''
    variables_0=''
    # Run the test
    ret_0 = lookup_module_0.run(terms_0, variables_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:45:31.891361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = '^qz_.+'
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    kwargs_0 = {}
    result_0 = ['qz_1', 'qz_2']
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result == result_0
    terms_1 = '.+'
    variables_1 = {}
    kwargs_1 = {}
    result_1 = []
    result = lookup_module_0.run(terms_1, variables_1, **kwargs_1)
    assert result == result_1

# Generated at 2022-06-25 11:45:33.100089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  LookupModule.run(None, None, vars={"k1":1, "k2":2, "k3":3})

# Generated at 2022-06-25 11:45:40.837364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    test_terms = [
        '^qz_.+',
        '.+'
    ]
    test_variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
        'qz_': 'I wont show either'
    }
    assert lookup_plugin.run(terms=test_terms, variables=test_variables) == ['qz_1', 'qz_2']