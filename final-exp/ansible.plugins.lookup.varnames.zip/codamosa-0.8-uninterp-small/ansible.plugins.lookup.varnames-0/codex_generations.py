

# Generated at 2022-06-25 11:37:42.907706
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0 = ['^qz_.+']
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}

    ret = lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:37:48.056146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = ['qz_.*']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module_0.run(terms, variables=variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:37:59.167914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.variables = {}
    lookup_module_0.set_options(var_options={})
    lookup_module_0.get_basedir.return_value = u'/path/to/ansible/files'
    lookup_module_0.get_basedir.return_value = u'/path/to/ansible/files'
    lookup_module_0.set_options(direct={})
    lookup_module_0.get_basedir.return_value = u'/path/to/ansible/files'
    lookup_module_0.get_basedir.return_value = u'/path/to/ansible/files'
    lookup_module_0.set_options(direct={})

# Generated at 2022-06-25 11:38:05.471615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'var1': 'val1', 'var2': 'val2'})
    results = lookup_module.run(terms=['var2'])
    assert results == ['var2']
    results = lookup_module.run(terms=['var1', 'var2'])
    assert results == ['var1', 'var2']
    results = lookup_module.run(terms=['var2', 'var1'])
    assert results == ['var1', 'var2']
    results = lookup_module.run(terms=['undefined'])
    assert results == []
    results = lookup_module.run(terms=['var2', 'undefined'])
    assert results == ['var2']

# Generated at 2022-06-25 11:38:10.966980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['', '^qz_.+']
    variables_0 = {'ansible_facts': {'ansible_network_resources': {'vlans': {}}}}
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:38:18.690463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        '^qz_.+',
    ]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    assert lookup_module_0.run(terms, variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:38:21.294375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
#    result = lookup_module_0.run(terms=["^qz_.+"])
#    assert result == ['']

# Generated at 2022-06-25 11:38:29.067162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module_0.run(terms_0, variables_0)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:34.610004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["^qz_.+"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:38:40.475376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_terms_0 = ['^qz_.+']
    var_variables_0 = {'qz_2': 'world', 'qz_1': 'hello'}
    ret_0 = lookup_module_0.run(terms=var_terms_0, variables=var_variables_0)
    assert ret_0 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:49.842847
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()

    # Test error conditions
    with pytest.raises(TypeError) as error1:
        lookup_module_1.run()

    # Test AnsibleError conditions
    with pytest.raises(AnsibleError) as excinfo1:
        lookup_module_1.run(None, None)

    # Test AnsibleError conditions
    with pytest.raises(AnsibleError) as excinfo2:
        lookup_module_1.run(None, 123)

    # Test AnsibleError conditions
    with pytest.raises(AnsibleError) as excinfo3:
        lookup_module_1.run(None, [])

    # Test AnsibleError conditions
    with pytest.raises(AnsibleError) as excinfo4:
        lookup_module_

# Generated at 2022-06-25 11:38:58.538857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Try parsing a valid term
    try:
        lookup_module_0.run(terms=['^qz_.+'])
    except Exception as e:
        raise AssertionError('caught an error when parsing a valid term: %s' % e)
    # Try parsing an invalid term
    try:
        lookup_module_0.run(terms=['^qz_+.+'])
        raise AssertionError('no error when parsing an invalid term')
    except AnsibleError as e:
        pass

# Generated at 2022-06-25 11:39:04.961311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=["foo"], variables={})
    lookup_module.run(terms=["foo"], variables={"foo": "bar"})
    lookup_module.run(terms=["^baz.+"], variables={"foo": "bar", "baz1": "baz2"})

# Generated at 2022-06-25 11:39:10.109848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    varnames_0_expected = [ 'qz_1', 'qz_2' ]
    varnames_0_actual = lookup_module_0.run( ['^qz_.+'], variables={ 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either' } )
    assert varnames_0_actual == varnames_0_expected


# Generated at 2022-06-25 11:39:17.538732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup
    lookup_module_0 = LookupModule()
    terms_0 = ['']
    variables_0 = {}
    kwargs_0 = {}

    # test
    try:
        lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    except Exception as e:
        pass
    else:
        #assert False
        pass

test_LookupModule_run()

# Generated at 2022-06-25 11:39:27.345743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_args = ["^qz_.+"]
    my_kwargs = {"variables": {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}}
    lookup_module_0 = LookupModule()
    my_ret = lookup_module_0.run(my_args, **my_kwargs)
    assert my_ret == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:39:33.348008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']

    variables = {
        'qz_1': "hello",
        'qz_2': "world",
        'qa_1': 'I won\'t show',
        'qz_': "I won't show either"
    }

    kwargs = {}

    result = {'msg': ['qz_1', 'qz_2']}

    lookup_module_1 = LookupModule()

    assert(result == lookup_module_1.run(terms, variables, **kwargs))


# Generated at 2022-06-25 11:39:44.216346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {}
    variables_0['qz_1'] = 'hello'
    variables_0['qz_2'] = 'world'
    variables_0['qa_1'] = "I won't show"
    variables_0['qz_'] = "I won't show either"

    # If the term is a string, then the output should be a
    # list of names matching the regex.
    assert lookup_module_0.run(terms_0, variables_0) == ['qz_1', 'qz_2']

    # If the term is a list of terms, they should be concatenated
    # into one list.
    terms_1 = ['^qz_.+', '^qa_.+']



# Generated at 2022-06-25 11:39:44.697554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0 == 0

# Generated at 2022-06-25 11:39:52.712639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['ansible_connection'] = 'local'
    dict_0['ansible_facts'] = dict()
    dict_0['ansible_facts']['distribution'] = 'CentOS'
    dict_0['ansible_facts']['distribution_file_parsed'] = False
    dict_0['ansible_facts']['distribution_file_path'] = '/etc/issue'
    dict_0['ansible_facts']['distribution_file_variety'] = 'SuSE'
    dict_0['ansible_facts']['distribution_major_version'] = '8'
    dict_0['ansible_facts']['distribution_release'] = 'Core'

# Generated at 2022-06-25 11:39:59.601859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[])
    assert Equals(var_0, [])


# Generated at 2022-06-25 11:40:02.343103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    pass

# Generated at 2022-06-25 11:40:02.767037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 11:40:12.580260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # matches: ['qz_1', 'qz_2']
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

    # missing ansible_vault__vault_password in the context
    # matches: []
    var_1 = lookup_run(lookup_module_0, lookup_module_0)

    # matches: ['qz_1', 'qz_2', 'qa_1', 'qz_']
    var_2 = lookup_run(lookup_module_0, lookup_module_0)

    # matches: []
    var_3 = lookup_run(lookup_module_0, lookup_module_0)

    # matches: []

# Generated at 2022-06-25 11:40:16.646388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()

    # set up params
    terms_0 = ['^^']
    terms_1 = ['.*']
    variables_0 = {'Foo': 'Bar', 'Ansible': 'AWX'}
    direct_0 = {}

    # Call method run of class LookupModule with params
    var_0 = lookup_module_0

# Generated at 2022-06-25 11:40:22.520275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variable supplied.
    lookup_module_2 = LookupModule()
    terms_2 = []
    variables_2 = None
    kwargs_2 = {}
    ret_2 = lookup_module_2.run(terms_2, variables_2, **kwargs_2)
    assert ret_2 == []


# Generated at 2022-06-25 11:40:32.254806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    lookup_module_0.set_options(var_4, var_5, var_6, var_7, var_8)
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
   

# Generated at 2022-06-25 11:40:39.900620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = AnsibleCollectionLoader()

    path = os.path.join(os.path.dirname(__file__), 'data/playbooks/lookup_collection_test.yml')
    play = Play.load(path, variable_manager=VariableManager(), loader=loader)
    qm = TaskQueueManager(inventory=play.inventory, variable_manager=play.variable_manager, loader=play.loader)
    qm._final_q = queue.Queue()

    qm.run(play)


# Generated at 2022-06-25 11:40:49.618201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_args = 'args'
    var_app = 'app'
    var_app_kwargs = 'app_kwargs'
    var_direct = 'direct'
    var_result = 'result'
    var_terms = 'terms'
    var_self = 'self'
    var_variables = 'variables'
    var_kwargs = 'kwargs'
    var_e = 'e'
    var_to_native = 'to_native'
    var_AnsibleError = 'AnsibleError'
    var_isinstance = 'isinstance'
    var_type = 'type'
    var_term = 'term'
    var_string_types = 'string_types'
    var_re = 're'
    var_compile = 'compile'
    var_name = 'name'


# Generated at 2022-06-25 11:40:59.206902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = LookupModule()
    ex = LookupModule()
    ex.set_options()
    var.set_options(var_options=ex, direct=ex)
    rv = var.run(terms=["terms", "terms", "terms", "terms"], variables=dict)
    assert rv == ["terms", "terms", "terms", "terms"], "Expected call to LookupModule().run() to return '['terms', 'terms', 'terms', 'terms']', but got '%s'" % (rv)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:41:12.648847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()


# Generated at 2022-06-25 11:41:19.988605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:41:26.365121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v = ansible.parsing.dataloader.DataLoader()
    v.set_basedir('./test/unit/data')
    lookup_module_2 = lookup_module_run(v.get_basedir())
    var_1 = lookup_module_run(lookup_module_2, lookup_module_2)
    assert var_1 == ['qz_1', 'qz_2']
    return var_1



# Generated at 2022-06-25 11:41:31.370301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == []



# Generated at 2022-06-25 11:41:37.846738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_options(var_options=None, direct=None)

# Generated at 2022-06-25 11:41:47.336193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get input arguments from file
    search1 = '^qz_.+'
    search2 = '.+_zone$'
    search3 = '.+_location$'
    terms_data = [search1,search2,search3]

    # Create temporary variables
    var1 = 'hello'
    var2 = 'world'
    var3 = "I won't show"
    var4 = "I won't show either"
    lookup_module = LookupModule()
    var_options = {}
    var_options['qz_1'] = var1
    var_options['qz_2'] = var2
    var_options['qa_1'] = var3
    var_options['qz_'] = var4
    direct = {}
    kwargs = {}
    kwargs['var_options'] = var_options

# Generated at 2022-06-25 11:41:53.747717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    (vars_0,_) = generate_test_params(var_name="varname_0", var_value="var_value_0")
    lookup_module_0.unfrackpath(vars_0, vars_0)


# Generated at 2022-06-25 11:41:55.987049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _lookup_module_0 = LookupModule()
    var_0 = _lookup_module_0.run(terms=[])
    assert isinstance(var_0, list)
    assert var_0 == []

# Generated at 2022-06-25 11:41:59.342982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:42:05.537785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # setup args
    args = {}
    args['terms'] = '^qz_.+'
    args['variables'] = 'qz_1,qz_2,qa_1,qz_'

    # expected return value
    expected_ret = 'qz_1,qz_2'

    # call the run function
    ret = lookup_module_0.run(**args)

    # assert the return value
    assert ret == expected_ret

# Generated at 2022-06-25 11:42:27.871750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        var_0 = lookup_run(lookup_module_0, [])
        var_1 = lookup_run(lookup_module_0, [])
    except Exception:
        assert False


# Generated at 2022-06-25 11:42:32.159186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['^qz_.+'], {})
    assert var_0 == [], 'Expected [], got {}'.format(var_0)

# Generated at 2022-06-25 11:42:44.555999
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:42:47.115296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([''], variables=None)
    assert var_1 == []


# Generated at 2022-06-25 11:42:48.958566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, lookup_module_1)
    assert var_1 == result_1

# Generated at 2022-06-25 11:42:49.931731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var_0 = test_case_0()
  assert var_0



# Generated at 2022-06-25 11:42:57.465153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  lookup_module_1.set_options(var_options={"key_0": "value_0"}, direct={"key_1": "value_1"})
  assert lookup_module_1.run(["key_0"]) == ["key_0"]
  assert lookup_module_1.run(["value_0"]) == []
  assert lookup_module_1.run(["key"]) == []

# Generated at 2022-06-25 11:43:06.375818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=terms_0, variables=variables_0, var_options=var_options_0, direct=direct_0)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=terms_1, variables=variables_1, var_options=var_options_1, direct=direct_1)
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms=terms_2, variables=variables_2, var_options=var_options_2, direct=direct_2)


if __name__ == '__main__':
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:43:10.282938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_args = {
    'vars': {
      'var_name': 'value'
    }
  }
  lookup_run(lookup_module_0, lookup_module_0.run, 'var_name', var_args)

# Generated at 2022-06-25 11:43:14.216201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables=None, direct=kwargs)
    assert var_0 is None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:44:01.826342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 11:44:09.325474
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Run method on class LookupModule to get the value,
  # which is returned by the function run
  # Run checked for False
  assert False == lookup_module_0.run(terms, variables=None, **kwargs)

  # Run method on class LookupModule to get the value,
  # which is returned by the function run
  # Run checked for True
  assert True == lookup_module_0.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 11:44:11.694589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=['^qz_.+'], variables={'var_0': 'var_0'})
    assert var_0 == ['var_0']


# Generated at 2022-06-25 11:44:17.385775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {}
    terms = ['^qz_.+']
    lookup_module = LookupModule()
    lookup_module.run(terms, vars)
    
    

# Generated at 2022-06-25 11:44:22.890426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 11:44:35.073642
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case0:
    # Some example case with no matching variables
    lookup_module_0 = LookupModule()
    ret_0 = set(lookup_run(lookup_module_0, lookup_module_0, "qz_", "qa_"))
    assert(ret_0 == {"qa_", "qz_"})

    # Case1:
    # Some example case with matching variables
    lookup_module_1 = LookupModule()
    ret_1 = set(lookup_run(lookup_module_1, lookup_module_1, "qz_"))
    assert(ret_1 == {"qz_1", "qz_2"})

    # Case2:
    # Another example case with matching variables
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:44:36.230642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:44:46.676891
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:44:51.965582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    argy = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(argy)


# Generated at 2022-06-25 11:44:53.243076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check if variable_names starts with '_'
    assert test_case_0()
    return True

# Generated at 2022-06-25 11:46:41.763573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['^qz_.+'])

# Generating random data for method run of class LookupModule
import random
import string

# Generated at 2022-06-25 11:46:46.605657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)
    assert True


# Python 2:
# class LookupModule(object):
#     def run(self, terms, variables=None, **kwargs):
#         pass
#
#
# def test_LookupModule_run():
#     pass
#
#

# Python 2:
# class LookupBase(object):
#     def get_basedir(self, variables):
#         pass
#
#
# def test_LookupBase_get_basedir():
#     pass
#



# Generated at 2022-06-25 11:46:53.309220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # AssertionError: Invalid setting identifier, "^qz_.+" is not a string, it is a <type 'list'>
    # assert 'run method of class LookupModule raised Expected failure' in lookup_run(lookup_module_0, lookup_module_0)
    # AssertionError: Invalid setting identifier, "^qz_.+" is not a string, it is a <type 'list'>
    # assert 'run method of class LookupModule raised Expected failure' in lookup_run(lookup_module_0, lookup_module_0)
    # AssertionError: Invalid setting identifier, "^qz_.+" is not a string, it is a <type 'list'>
    # assert 'run method of class LookupModule raised Expected failure' in lookup_run(

# Generated at 2022-06-25 11:46:57.967486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)


# Generated at 2022-06-25 11:47:01.212831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_run(lookup_module_1, lookup_module_1)
    var_1 = '0'
    assert var_0 == var_1

# Generated at 2022-06-25 11:47:09.563987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=['^qz_.+', '^qa_.+'], variables={"qz_1" : "hello", "qz_2" : "world", "qa_1" : "I won't show", "qz_" : "I won't show either" })
    assert var_0 == [u'qz_1', u'qz_2', u'qa_1']

test_case_0()

# Generated at 2022-06-25 11:47:15.118202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(None, None)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(None, None)

# Generated at 2022-06-25 11:47:16.962809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=variables, **kwargs)



# Generated at 2022-06-25 11:47:20.909598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_run()


# Generated at 2022-06-25 11:47:25.593547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == None, "lookup_run returned unexpected result"
