

# Generated at 2022-06-25 11:37:49.601460
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible_collections.ansible.builtin.plugins.modules import varnames

# Generated at 2022-06-25 11:37:54.910873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['^qz_.+'])
    lookup_module_1.run(['.+'])
    lookup_module_1.run(['hosts'])
    lookup_module_1.run(['.+_zone$', '.+_location$'])

# Generated at 2022-06-25 11:37:55.475990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:38:00.377016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    parm_terms = ["^qz_.+"]
    parm_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module_0.run(parm_terms, parm_variables)


# Generated at 2022-06-25 11:38:08.180161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = None
    variables = {}
    kwargs = {}
    good_varnames = [
        'qz_1',
        'qz_2',
    ]
    ret = lookup_module.run(terms=term, variables=variables, **kwargs)
    assert ret == good_varnames

# Generated at 2022-06-25 11:38:09.506661
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # AnsibleError: No variables available to search
    assert False, "Not implemented"

# Generated at 2022-06-25 11:38:17.255097
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = [u'qz_1', u'qz_2']
    result = lookup_module_0.run(terms=terms, variables=variables)
    assert result == ret


# Generated at 2022-06-25 11:38:28.049832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(terms="", variables="", *[], **{"":""})) == 0
    assert len(lookup_module_0.run(terms="", variables="", *[], **{"":0})) == 0
    assert len(lookup_module_0.run(terms="", variables="", *[], **{"":None})) == 0
    assert len(lookup_module_0.run(terms="", variables="", *[], **{"":{}})) == 0
    assert len(lookup_module_0.run(terms="", variables="", *[], **{"":1.0})) == 0
    assert len(lookup_module_0.run(terms="", variables="", *[], **{"":{0}})) == 0

# Generated at 2022-06-25 11:38:32.270836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+', 'qa_1', 'qz_']
    #TODO
    #variables_0 = {}
    #assert lookup_module_0.run(terms_0, variables_0) == ['^qz_.+', 'qa_1', 'qz_']
    assert lookup_module_0.run(terms_0) == ['^qz_.+', 'qa_1', 'qz_']

# Generated at 2022-06-25 11:38:40.300051
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Params:
    # terms:
    terms = ['^qz_.+', '^qz_']
    # variables:
    variables = {'qz_1': 'hello',
                 'qz_2': 'world',
                 'qa_1': "I won't show",
                 'qz_': "I won't show either",
                 }
    # **kwargs:
    kwargs = None
    # Result:
    result = ['qz_1', 'qz_']

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables, **kwargs) == result

# Generated at 2022-06-25 11:38:44.268006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:38:47.150629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = dict()
    term_0 = []
    lookup_mod_0 = LookupModule()

    # Call method run of lookup_mod_0
    try:
        lookup_mod_0.run(terms=term_0, variables=variables)
    # Assertion error raised
    except AssertionError as e:
        assert error_message_0 == str(e)

# Generated at 2022-06-25 11:38:51.654404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 11:38:59.644728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {
        'k1': 'v1',
        'k2': 'v2'
    }
    lookup_module_0.set_options()
    lookup_module_0.set_options(direct={})
    lookup_module_0.run(terms=[
        '^qz_.+'
    ], variables=vars_0)



# Generated at 2022-06-25 11:39:07.243862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0)


# field definitions
data = [["A", 30], ["B", 40], ["C", 50], ["D", 55 ], ["E", 60]]

# field names
fields = ("name", "age")


# Generated at 2022-06-25 11:39:13.427369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'qz_1': 'hello',
                                             'qz_2': 'world',
                                             'qa_1': 'I won\'t show',
                                             'qz_': ' I won\'t show either'},
                                direct={})
    assert lookup_module_0.run(terms=['^qz_.+']) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:39:15.508663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:39:20.224926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    assert lookup_module_2.run() == ['1', '2']

# Generated at 2022-06-25 11:39:23.102800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:27.562062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    test_assert_equal(var_0, "chr")



# Generated at 2022-06-25 11:39:40.642678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test object
    lookup_module = LookupModule()

    # Case 0
    terms = ["^qz_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    lookup_run(lookup_module, terms, variables)

# Execute run method of a lookup_module

# Generated at 2022-06-25 11:39:43.301606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['^qz_.+'],['qz_1'])
    assert var_0 == ['qz_1']

# Generated at 2022-06-25 11:39:48.617519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_options_0 = dict([("N", "O"), ("A", "B")])
    direct_0 = dict([("D", "E"), ("E", "F")])
    var_0 = lookup_module_0.run("N", "O", var_options=var_options_0, direct=direct_0)
    assert(var_0 == "B")


# Generated at 2022-06-25 11:39:52.870837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variable_names = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    variables = {'qz_1': 'hello',
                 'qz_2': 'world',
                 'qa_1': "I won't show",
                 'qz_': "I won't show either"}
    lookup_run(lookup_module_0, variable_names, variables)


# Generated at 2022-06-25 11:39:54.808970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:40:02.762861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([]) == []

    # Test with an empty string
    assert lookup.run(['']) == []

    # Test with an integer
    assert lookup.run([1]) == []

    # Test with an invalid re
    terms = ['(/']
    try:
        lookup.run(terms)
        assert False
    except AnsibleError:
        pass

    # Test with a valid re
    terms = ['a']
    assert lookup.run(terms, {'a': 'a'}) == ['a']

    # Test the default variables
    assert lookup.run(['^qz_.+']) == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-25 11:40:03.846674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run()


# Generated at 2022-06-25 11:40:09.904967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # _terms
    var_0 = ["^qz_.+"]
    # _terms: List of Python regex patterns to search for in variable names.
    var_1 = None
    var_2 = lookup_module_0.run(var_0, var_1)
    # list
    assert type(var_2) == list


# Generated at 2022-06-25 11:40:19.963467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([], {"qa1":"hello", "qa2":"world"})
    lookup_module_0.run([""], {"qa1":"hello", "qa2":"world"})
    lookup_module_0.run(["^q.+"], {"qa1":"hello", "qa2":"world"})
    lookup_module_0.run(["hello"], {"qa1":"hello", "qa2":"world"})
    lookup_module_0.run(["hello"], {})
    lookup_module_0.run([".*"], {})
    lookup_module_0.run(["(hello)"], {})
    lookup_module_0.run(["(hello)"], {"qa1":"hello", "qa2":"world"})
    lookup_module_0.run

# Generated at 2022-06-25 11:40:28.476944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In order to test run, we need to initialize a LookupModule object, which
    # will be used as input in run.
    lookup_module_0 = LookupModule()
    # Now we have the input, lets call the run method
    var_0 = lookup_run(lookup_module_0)

    # Now check the value of ret
    #   ret == [u'qz_1', u'qz_2']
    assert [u'qz_1', u'qz_2'] == var_0, "output of run is wrong"

    # This test checks if the exception is raised when term has wrong type
    #   term == {'ansible': 'variable'}
    # As we saw in source code, there is an error happening if the type of
    # term is not string. Thus, the test should pass.



# Generated at 2022-06-25 11:40:43.904111
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    lookup_module_0 = LookupModule()
    terms_0=['^qz_.+']

    # Act
    var_0 = lookup_module_0.run(terms=terms_0)

    # Assert


# Generated at 2022-06-25 11:40:48.143244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = list()
    variables_0 = dict()
    lookup_run(lookup_module_0)
    assert isinstance(var_0, list)


# Generated at 2022-06-25 11:40:51.456173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Add your test logic here
    assert True


# Generated at 2022-06-25 11:40:55.358690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Testcase for testing that run method of class LookupModule works as expected

# Generated at 2022-06-25 11:40:57.899178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = dict()
    var_2 = var_0.run(var_1)
    assert var_2 == None



# Generated at 2022-06-25 11:40:59.711517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)

# Generated at 2022-06-25 11:41:00.263756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert func() == 1

# Generated at 2022-06-25 11:41:04.333136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run('foo', '^qz_.+')


# Generated at 2022-06-25 11:41:07.022872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:41:14.831617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = '^qz_.+'
    variables_1 = dict()
    variables_1["qz_1"] = 'hello'
    variables_1["qz_2"] = 'world'
    variables_1["qa_1"] = "I won't show"
    variables_1["qz_"] = "I won't show either"
    kwargs_1 = dict()
    try:
        test_result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    except Exception as e:
        test_result_1 = str(e)
    assert test_result_1 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:41:47.062197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(["qz_2"])[0] == "qz_2"
    assert len(lookup_module_0.run(["^qz_.+"])) == 2
    assert lookup_module_0.run(["^qz_.+"])[0] == "qz_1"
    assert lookup_module_0.run(["^qz_.+"])[1] == "qz_2"
    assert len(lookup_module_0.run(["^qz_.+", "^qz_.+"])) == 2
    assert lookup_module_0.run(["^qz_.+", "^qz_.+"])[0] == "qz_1"

# Generated at 2022-06-25 11:41:52.621785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert any(lookup_run(LookupModule(), terms=any(), variables=any(),
                          var_options=any(), direct=any(),
                          templar=any(), loader=any(),
                          basedir=any(), inject=any()))

# Generated at 2022-06-25 11:41:54.148968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0 is not None
    assert var_0 is not None


# Generated at 2022-06-25 11:41:58.982914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


if __name__ == '__main__':
    print("Running unit tests for Ansible lookup module varnames")
    print("Testing class LookupModule")
    print("Tests include example cases from documentation")
    test_LookupModule_run()

    print("Tests Complete")

# Generated at 2022-06-25 11:42:00.601175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)




# Generated at 2022-06-25 11:42:05.761732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Helper function to create a lookup_module object

# Generated at 2022-06-25 11:42:15.207500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if not hasattr(lookup_module_0, 'run'):
        raise Exception(
            "Class `LookupModule` does not have a method `run`")

    # Test exception raised is matching
    # Test empty or missing args raise
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None
    arg8 = None

    with pytest.raises(TypeError) as excinfo:
        lookup_module_0.run(arg1, arg2, arg3, arg4, arg5, arg6, arg7)
    assert excinfo.match(r"not enough arguments")

    with pytest.raises(TypeError) as excinfo:
        lookup_module

# Generated at 2022-06-25 11:42:18.708882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['qa_1', 'qz_', 'qz_1', 'qz_2']
    assert lookup_module_0.run('^qz_.+', var_0) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:42:25.107286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run")
    term_0 = "^qz_.+"
    var_0 = dict()
    var_0["qz_1"] = "hello"
    var_0["qz_2"] = "world"
    var_0["qa_1"] = "I won't show"
    var_0["qz_"] = "I won't show either"
    lookup_module_0 = LookupModule()
    expected_ret = list()
    expected_ret.append("qz_1")
    expected_ret.append("qz_2")
    actual_ret = lookup_module_0.run(terms = term_0, variables = var_0)
    assert actual_ret == expected_ret, "Expected: %s\nActual: %s" % (expected_ret, actual_ret)

# Generated at 2022-06-25 11:42:27.598264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables=None) == [], 'Expected call to LookupModule.run() to return: [].'

# Generated at 2022-06-25 11:43:24.190896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms='^qz_.+')
    lookup_module_0.run(terms='.+')
    lookup_module_0.run(terms='hosts')

# Generated at 2022-06-25 11:43:32.047812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])
    assert_equal(lookup_module_0.run([]), [])

# Generated at 2022-06-25 11:43:37.155012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:43:41.204974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    varnames = LookupModule()
    test_data = ['foo=bar', 'baz=bar']
    assert varnames.run(test_data) == ['foo', 'baz']

# Generated at 2022-06-25 11:43:42.356827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run() == None


# Generated at 2022-06-25 11:43:47.155901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Basic test
    kwargs = {'_terms': [
        'test1',
        'test2',
    ]}

    # Construct object
    obj = LookupModule()

    lookup_run(obj, **kwargs)



# Generated at 2022-06-25 11:43:48.216443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options
    lookup_module_0.run


# Generated at 2022-06-25 11:43:49.223022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:43:54.154778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v0 = {}
    t0 = []
    kw0 = {'variables': v0}
    assert lookup_module_0.run(t0, v0, **kw0) == []
    lookup_mockup_run_0 = mock.patch('ansible.plugins.action.debug.ActionModule.run')
    lookup_mockup_run_2 = lookup_mockup_run_0.start()
    lookup_mockup_run_3 = mock.PropertyMock(return_value=1)
    lookup_mockup_run_4 = type(lookup_module_0).run = lookup_mockup_run_3
    lookup_mockup_run_1 = lookup_mockup_run_0.start()

# Generated at 2022-06-25 11:43:56.895770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mocha_setup.setup()

    var_0 = lookup_run(LookupModule)

    mocha_teardown.teardown()


# Generated at 2022-06-25 11:46:01.825563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:46:03.414815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert bool(lookup_module.run(terms, variables)) == True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:46:13.170524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '^qz_.+'
    expected_0 = ['qz_1', 'qz_2']
    print('Actual : ' + str(expected_0))
    print('Expected : ' + str(expected_0))
    assert(var_0 == expected_0)
    var_1 = '.+'
    expected_1 = ['qz_1', 'qz_2', 'qa_1']
    print('Actual : ' + str(expected_1))
    print('Expected : ' + str(expected_1))
    assert(var_1 == expected_1)
    var_2 = 'hosts'
    expected_2 = ['qz_1', 'qz_2']
    print('Actual : ' + str(expected_2))

# Generated at 2022-06-25 11:46:19.389967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, '^qz_.+')
    assert var_0 == ['qz_1', 'qz_2']
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, '.+')
    assert var_1 == ['a', 'b', 'foo', 'qz_2', 'qz_1']
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2, 'hosts')
    assert var_2 == ['hosts']
    lookup_module_3 = LookupModule()
    var_3 = lookup_run(lookup_module_3, '.+_zone$', '.+_location$')

# Generated at 2022-06-25 11:46:26.594434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    variables_0={"ms": ""}
    terms_0 = {"ms"}
    kwargs_0 = {"varname": "name", "self": "self"}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)

    try:
        assert ret_0 is not None
    except AssertionError as e:
        print('Expected: ' + str(expected))
        print('Actual: ' + str(actual))
        raise e

# Generated at 2022-06-25 11:46:28.960673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:46:34.590521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummy_obj = {
        'qz_1': 'hello', 
        'qz_2': 'world', 
        'qa_1': 'I won\'t show', 
        'qz_': 'I won\'t show either', 
    }
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=dummy_obj, direct={})
    terms_1 = ['^qz_.+']
    var_1 = lookup_run(lookup_module_1) # Expected to return ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:46:37.948107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    try:
        lookup_module_0.run(['', '', '', '', '', '', '', ''], {'name': 'value'})
    except AnsibleError:
        pass
    finally:
        pass

    try:
        lookup_run(lookup_module_0)
    except AnsibleError:
        pass
    finally:
        pass

    try:
        lookup_module_0.run(terms=['hosts'], variables={'hosts': 'value'})
    except AnsibleError:
        pass
    finally:
        pass



# Generated at 2022-06-25 11:46:46.317176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    def test_case_1():
        # This testing code is from, https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/varnames.py
        # We are testing for the line 149
        # def run(self, terms, variables=None, **kwargs):
        # This is testing case 1 or 2

        if variables is None:
            # Testing case 1
            pass
        if variables is not None:
            # Testing case 1
            pass


# Generated at 2022-06-25 11:46:48.287568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert not lookup_run(lookup_module_0)
    assert lookup_run(lookup_module_0) == ['some_variable_0', 'some_variable_1']
