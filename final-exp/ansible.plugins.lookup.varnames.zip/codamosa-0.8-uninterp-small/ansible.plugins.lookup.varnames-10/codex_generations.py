

# Generated at 2022-06-25 11:37:40.563885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
#     assert lookup_module_0.run(terms) == "expected_result"
    pass

# Generated at 2022-06-25 11:37:50.368068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    parameters_2 = []
    parameters_2.append('^qz_.+')
    variables_2 = {'qz_1': 'hello', 'qz_': 'I won\'t show either', 'qz_2': 'world', 'qa_1': 'I won\'t show'}
    assert lookup_module_2.run(parameters_2, variables=variables_2) == ['qz_', 'qz_1', 'qz_2']
    parameters_2 = []
    parameters_2.append('.+')
    variables_2 = {'qz_1': 'hello', 'qz_': 'I won\'t show either', 'qz_2': 'world', 'qa_1': 'I won\'t show'}
    assert lookup_module

# Generated at 2022-06-25 11:37:55.388111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['^qz_.+'], variables={u'qz_2': u'world', u'qz_1': u'hello', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})

# Generated at 2022-06-25 11:37:59.989771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["^qz_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    lookup_module_0.run(terms, variables)
    return True


# Generated at 2022-06-25 11:38:01.388417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['test_regex']) == []

# Generated at 2022-06-25 11:38:09.497633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Init
    terms = [ '^qz_.+', ]
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = ['qz_1', 'qz_2']

    assert lookup_module.run(terms, variables) == ret

# Generated at 2022-06-25 11:38:12.169891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run is not None


# Generated at 2022-06-25 11:38:23.063712
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:38:31.652980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []

    # test with no variables

# Generated at 2022-06-25 11:38:40.476112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    actual = lookup_module_0.run(terms, variables, **kwargs)
    print("type:", type(actual))
    print("actual:", actual)
    assert type(actual) == list
    assert actual == ['qz_1', 'qz_2']


if __name__ == '__main__':
    #test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:38:44.820906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    assert var_0 == ret

# Generated at 2022-06-25 11:38:48.451241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert(lookup_module)


# Generated at 2022-06-25 11:38:52.413294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)

# Definition of function lookup_run

# Generated at 2022-06-25 11:38:59.084725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'warn' : False})
    var_0 = lookup_module_0.run(terms=[var_1], vars=var_2)
    assert(var_0 == var_3)

#Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:39:06.487251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('^qz_.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'})


# Generated at 2022-06-25 11:39:11.267530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('^qz_.+')
    lookup_module_0.run('.+')
    lookup_module_0.run('hosts')
    lookup_module_0.run('.+_zone$', '.+_location$')

test_LookupModule_run()

# Generated at 2022-06-25 11:39:17.077020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0['changed'] == False
    assert var_0['rc'] == 0
    assert var_0['stderr'] == ''
    assert var_0['stdout'] == ''
    assert var_0['stdout_lines'] == ['']

# Generated at 2022-06-25 11:39:23.885378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Testing for case where <terms> is empty
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0, [''], {'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2'})
  var_1 = lookup_run(lookup_module_0, [], {'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2'})
  assert var_0 == var_1
  assert var_0 == []


# Generated at 2022-06-25 11:39:35.499408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '^qz_.+'
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    terms_1 = '.+'
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    terms_2 = 'hosts'
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    terms_3 = '.+_zone$'
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()

# Generated at 2022-06-25 11:39:44.941720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    variable_0 = dict(key_0='dict_v', key_1='dict_v2', key_2='dict_v3', key_3='dict_v4')
    term_0 = 'dict_v'
    term_1 = 'dict_v2'
    term_2 = 'dict_v3'
    term_3 = 'dict_v4'
    var_0 = lookup_module_1.run(terms=[term_0, term_1, term_2, term_3], variables=variable_0)
    assert type(var_0) is list
    assert len(var_0) == 4
    var_1 = var_0[0]
    assert var_1 == 'key_0'
    var_2 = var_0[1]
   

# Generated at 2022-06-25 11:39:52.718143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert var[0] == 'qz_1'
    assert var[1] == 'qz_2'


# Generated at 2022-06-25 11:39:54.808737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = "^qz_.+"

  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:39:56.356101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables=None)


# Generated at 2022-06-25 11:39:58.567437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:40:01.189458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:40:03.293035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('.+')
    assert var_0



# Generated at 2022-06-25 11:40:05.454710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

test_LookupModule_run()


# Generated at 2022-06-25 11:40:08.985846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import types
    lookup_module_0 = LookupModule()
    lookup_module_0.run = types.MethodType(lambda s, x, y, **z: print('hello'), lookup_module_0)
    var_0 = lookup_module_0.run('hello')


# Generated at 2022-06-25 11:40:17.596443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_case_0
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert type(var_0) is list
    assert len(var_0) == 0
    # test_case_1
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert type(var_1) is list
    assert len(var_1) == 0
    # test_case_2
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2)
    assert type(var_2) is list
    assert len(var_2) == 0
    # test_case_3
    lookup_module_3 = LookupModule()
    var

# Generated at 2022-06-25 11:40:26.164595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['fz_1','a'],dict()) == []

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    if not basic._ANSIBLE_ARGS:
        args = to_text(dict(
            connection='ssh',
            module_path=os.path.abspath(os.path.join(os.path.dirname(__file__), '..')),
            forks=10,
            become=None,
            become_method=None,
            become_user=None,
            check=False,
            diff=False))
        basic._ANSIBLE_ARGS = to_native(json.loads(args),
                                        non_string_keys=False)

    # assert

# Generated at 2022-06-25 11:40:45.927049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_run(lookup_module_0, terms=[""])
    var_2 = lookup_run(lookup_module_0, terms=["", ""])
    var_3 = lookup_run(lookup_module_0, terms=["", "", ""])
    var_4 = lookup_run(lookup_module_0, terms=["", "", "", ""])
    var_5 = lookup_run(lookup_module_0, terms=["", "", "", "", ""])
    var_6 = lookup_run(lookup_module_0, terms=["", "", "", "", "", ""])
    var_7 = lookup_run

# Generated at 2022-06-25 11:40:51.000683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(['^qz_.+'], {"qz_1":"hello", "qz_2":"world", "qa_1":"I won't show", "qz_":"I won't show either"})
    lookup_module_1.run(['.+'], {"a":"b"})
    lookup_module_1.run(['hosts'], {"a":"b"})
    lookup_module_1.run(['.+_zone$', '.+_location$'], {"a":"b"})

# Generated at 2022-06-25 11:40:54.181078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:41:05.805692
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:41:10.567090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # expected return from run method
    expected = None
    # expected return from run method
    expected_1 = None
    # initialize object
    lookup_module_0 = LookupModule()
    # call run with parameters
    returned = lookup_module_0.run(expected, expected_1)
    # check that expected == returned
    assert returned == expected
    # check that expected == returned
    assert returned == expected_1


# Generated at 2022-06-25 11:41:19.007226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'mswin':False, 'ansible_winrm_transport':'plaintext', 'ansible_user':u'vagrant', 'ansible_connection':'winrm', 'ansible_ssh_port':22, 'ansible_winrm_server_cert_validation':'ignore', 'ansible_winrm_port':5985, 'ansible_password':u'vagrant', 'ansible_winrm_scheme':'http', 'ansible_winrm_path':'/wsman', 'ansible_shell_type':'powershell', 'ansible_port':5985, 'ansible_winrm_https_port':443, 'ansible_winrm_server_cert_validation':'ignore', 'ansible_winrm_transport':'plaintext'}
    lookup_module_0 = LookupModule

# Generated at 2022-06-25 11:41:20.383882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 11:41:26.821843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=terms)


# Find matching variable names
lookup('varnames', '.+_zone$', '.+_location$')


# Find variable names that contain 'hosts'
lookup('varnames', 'hosts')


# Find variable names that start with 'foo_'
lookup('varnames', '^foo_.+')

# Generated at 2022-06-25 11:41:30.233115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:41:32.078236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:41:52.246906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('', '', '', '', '', '')
    lookup_module_0.run('', '', '', '', '', '', '')

# Generated at 2022-06-25 11:41:55.126823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()

# Generated at 2022-06-25 11:42:00.175525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ["^qz_.+"]
    variables_0 = {"qz_2": "world", "qz_1": "hello"}
    kwargs_0 = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:42:05.333686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:42:12.478562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = dict(a='a', b='b')
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=['.'], variables=result)
    assert result_0 == [u'a', u'b']

    result = dict(a='a', b='b')
    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=['a'], variables=result)
    assert result_0 == [u'a']



# Generated at 2022-06-25 11:42:18.828512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    qa_1 = "I won't show"
    qa_2 = "I won't show either"
    qz_1 = "hello"
    qz_2 = "world"
    qz_3 = "qz_3"
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_run1(lookup_module_0)
    var_2 = lookup_run2(lookup_module_0)
    var_3 = lookup_run3(lookup_module_0)


# Generated at 2022-06-25 11:42:22.186325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = "test_string_0"
    var_0 = lookup_module_0.run(arg_0)


# Generated at 2022-06-25 11:42:27.637733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run([]) == []
    assert lookup_run(['a']) == ['a']
    assert lookup_run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_run(['^qz_.+'], variables={'qz_1': 'a', 'qz_2': 'b', 'a': 'c'}) == ['qz_1', 'qz_2']
    assert lookup_run(['^qz_.+'], variables={'qz_1': 'a', 'qz_2': 'b'}) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:42:34.083140
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    params = {
        'terms': '',
        'variables': {
            'not_empty': '',
        },
    }

    expected_return = {
        '_value': [],
    }

    # perform test
    lookup_module = LookupModule()
    actual_return = lookup_run(lookup_module, params)

    # assert
    assert expected_return == actual_return


# Generated at 2022-06-25 11:42:36.421397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module = LookupModule()
   var = lookup_run()

   assert result == expected
   assert result != expected


# Generated at 2022-06-25 11:43:23.022576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert True == lookup_module.run()


# Generated at 2022-06-25 11:43:24.706643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run('test')


# Generated at 2022-06-25 11:43:33.970631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0

    # Assert lookup_module_0.run()
    exception = None
    try:
        lookup_run(lookup_module_0)
    except Exception as e:
        exception = e
    assert exception
    assert isinstance(exception, AnsibleError)
    assert 'No variables available to search' in str(exception)

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
    }

    # Assert lookup_module_0.run(terms=['^qz_.+'], variables=variables)

# Generated at 2022-06-25 11:43:40.303942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:43:46.801304
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Run with variables = {} (default)
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == []

    # Run with variables = {"line_v":"Testing term"}
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, variables = {"line_v":"Testing term"})
    assert var_1 == []

    # Run with variables = {"line_1":"Testing term"}
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2, variables = {"line_1":"Testing term"})
    assert var_2 == ["line_1"]

    # Run with variables = {"line_1":"Testing term", "line_2":"Testing term

# Generated at 2022-06-25 11:43:50.588778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:43:54.254939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, term)
    assert var_0 == var_1

# Generated at 2022-06-25 11:43:58.653186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    assert not lookup_module_1.run()

    assert not lookup_module_1.run(terms=['qz_1'])

    assert lookup_module_1.run(terms=['qz_1'], variables={'qz_1': 1, 'qa_1': 2}) == ['qz_1']

# test case for the python regex search

# Generated at 2022-06-25 11:44:01.865289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['qz_1'], variables)

# Generated at 2022-06-25 11:44:10.256061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {'qz_2': 'world', 'qz_1': 'hello', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    var_1 = {'qz_2': 'world', 'qz_1': 'hello', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(var_0, var_1)

# Generated at 2022-06-25 11:45:51.576355
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:46:01.215674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test case with simple arguments.
    params_0 = ('some_var',)
    received_0 = lookup_run(lookup_module_0, *params_0)
    expected_0 = [lookup_module_0.get_option('some_var')]
    assert received_0 == expected_0
    # Test case with simple arguments.
    params_1 = ('some_var',)
    received_1 = lookup_run(lookup_module_0, *params_1)
    expected_1 = [lookup_module_0.get_option('some_var')]
    assert received_1 == expected_1
    # Test case with simple arguments.
    params_2 = ('some_var',)

# Generated at 2022-06-25 11:46:04.625428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = lookup_module_0.run(terms=['.+_zone$', '.+_location$'],
                                variables={"zone_id": [4, 5, 6],
                                           "zone_location": "default",
                                           "zone_name": "default-1-2-3",
                                           "zone_number": 1}
                                )
    assert ['zone_id', 'zone_location', 'zone_name'] == var_0

# Generated at 2022-06-25 11:46:10.458072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  local_vars_0 = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
  lookup_run(lookup_module_0, local_vars_0)
  pass


# Generated at 2022-06-25 11:46:15.887301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['term_0'], {})


# Generated at 2022-06-25 11:46:19.693069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Load tests for class LookupModule
    var_1 = to_native({'list_1': [1, 2, 3], 'list_3': [3, 4, 5]})
    var_2 = to_native({'regex_1': 'hello'})
    lookup_module_1 = LookupModule()
    var_3 = lookup_run(lookup_module_1)
    var_4 = [1, 2, 3]
    lookup_module_2 = LookupModule()
    var_5 = lookup_run(lookup_module_2)
    assert var_3 == var_4
    assert var_3 == var_5

lookup_run = LookupModule().run



# Generated at 2022-06-25 11:46:23.315895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(terms=None, variables=None, kwargs={})


# Generated at 2022-06-25 11:46:27.156112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert len(var_0) == 2
    assert type(var_0[0]) == str
    assert var_0[0] == 'qz_1'
    assert type(var_0[1]) == str
    assert var_0[1] == 'qz_2'



# Generated at 2022-06-25 11:46:29.378948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert var == ["qz_1", "qz_2"], 'Unexpected var returned by LookupModule.run()'

# Generated at 2022-06-25 11:46:32.517535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.module_loader = MockLoader()
    var_0 = lookup_run(lookup_module_0)
