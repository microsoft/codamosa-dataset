

# Generated at 2022-06-25 11:37:41.959935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {}
    terms = []
    assert return_LookupModule_run(terms, variables) == []


# Generated at 2022-06-25 11:37:47.085523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [1]
    variables = {}
    kwargs = {}
    result = lookup_module_0.run(terms=terms, variables=variables, **kwargs)
    assert result == [], "Expected {}, but got {}".format([], result)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:37:50.074750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], variables=None) == [], 'Failed test_LookupModule_run'

# Generated at 2022-06-25 11:37:56.680057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    lookup_module = LookupModule()
    terms = '^qz_.+'
    result = lookup_module.run(terms, variables)
    assert (result == ['qz_1', 'qz_2'])


# Generated at 2022-06-25 11:38:01.969738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_ = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    lookup_module = LookupModule()
    result = lookup_module.run(['^qz_.+'], variables=vars_)
    assert result == ['qz_1', 'qz_2']



# Generated at 2022-06-25 11:38:09.862983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"}
    result = lookup_module.run(terms, variables=variables)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:14.549869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'qz_2': 'world', 'qz_1': 'hello'}
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:38:16.974133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['^qz_.+'], variables={"qz_1":"hello","qz_2":"world","qa_1":"I won't show","qz_":"I won't show either"}) == ["qz_1", "qz_2"]

# Test to see that the number of arguments is correct

# Generated at 2022-06-25 11:38:23.183044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Unit test for run with 'Invalid setting identifier, "%s" is not a string, it is a %s' % (term, type(term))
    # Input data
    terms = 1

    # Expected Return
    expected_ret = 'AnsibleError'

    # Run method
    try:
        lookup_module_0.run(terms)
    except Exception as ret:
        pass

    # Assert
    assert type(ret).__name__ == expected_ret

# Generated at 2022-06-25 11:38:26.921697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == []


# Generated at 2022-06-25 11:38:34.149900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module_0.run(terms, variables)
    assert result == expected

# Generated at 2022-06-25 11:38:40.727822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    vars_1 = dict()
    terms_1 = ['^qz_.+']
    lookup_module_1.variables = vars_1
    lookup_module_1.set_options({'var_options' : vars_1, 'direct' : {}})

    ret_1 = lookup_module_1.run(terms_1)
    assert ret_1 == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:46.316670
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0 = [
        '^qz_.+',
    ]

    variables_0 = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }

    kwargs_0 = {}

    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:38:55.265768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_2 = ['^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$']
    variables_2 = ['hello']
    kwargs_2 = {}
    x_2 = lookup_module_2.run(terms_2, variables_2, **kwargs_2)
    assert x_2 == []
    # assert 'variable in variables_2' in lookup_module_2.run(terms_2, variables_2, **kwargs_2)


# Generated at 2022-06-25 11:39:02.822050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixture = [{'terms': [
        '^qz_.+'
    ], 'variables': {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }}]
    fixture[0].update({'expected': ['qz_1', 'qz_2']})
    lookup_module_0 = LookupModule()
    for entry in fixture:
        assert lookup_module_0.run(**entry) == entry['expected']

# Generated at 2022-06-25 11:39:13.678590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_result = lookup_module_1.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'})
    test_expect = ['qz_1', 'qz_2']
    assert test_result == test_expect, 'test_LookupModule_run test_case 1 failed'
    test_result = lookup_module_1.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'})

# Generated at 2022-06-25 11:39:21.839401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '^qz_.+'
    variables_0 = dict()
    kwargs_0 = dict()
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs_0 = {'var_options': variables_0, 'direct': var_2}
    var_

# Generated at 2022-06-25 11:39:28.355167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}, direct={'_ansible_verbosity': 4})
    lookup_module_0.run(terms=['^qz_.+'])


# Generated at 2022-06-25 11:39:40.424005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'ansible_module_name': 'debug', 'module_args': "'msg': '{{ lookup('varnames', '^qz_.+')}}'", 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}, direct={})


# Generated at 2022-06-25 11:39:45.948284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    result = lookup_module_run.run()
    assert result == [], 'Unit test for method run of class LookupModule, result is not equal to expected result'

# Generated at 2022-06-25 11:39:59.753973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # vars used by tests
    vars = dict()
    vars["a"] = "hello"
    vars["b"] = "world"
    vars["c"] = "list"
    vars["d"] = "of"
    vars["e"] = "words"
    vars["f"] = "in"
    vars["g"] = "a"
    vars["h"] = "sentence"
    vars["i"] = "with"
    vars["j"] = "punctuation"
    vars["k"] = "!"

# Case 0 - all terms that end with 'a' or begin with 'b'.
    testcase_0 = {'terms': ['^b.+', '.+a$'], 'variables': vars}
    expected_0 = ["a", "b"]

# Generated at 2022-06-25 11:40:09.465312
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    result = lookup.run(['foo\\.'], {'foo.': 'bar'})
    assert result == ['foo.']

    result = lookup.run(['foo\\.'], {'foo': 'bar'})
    assert result == []

    result = lookup.run(['foo\\.'], {'foo': 'bar', 'bar': 'foo'})
    assert result == []

    result = lookup.run(['foo\\.'], {'foo.bar': 'foo.bar'})
    assert result == ['foo.bar']

    result = lookup.run(['^foo\\.'], {'foo.': 'bar'})
    assert result == ['foo.']

    result = lookup.run(['^foo\\.'], {'bar.': 'foo'})
    assert result == []

    result = lookup

# Generated at 2022-06-25 11:40:19.937710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {}
    assert lookup_module_0.run(terms=[], variables=variables) == []
    variables = {'var_1':'Hello'}
    assert lookup_module_0.run(terms=[], variables=variables) == []
    assert lookup_module_0.run(terms=['^var_.+$'], variables=variables) == []
    variables = {'var_1':'Hello', 'var_2':'World'}
    assert lookup_module_0.run(terms=['^var_.+$'], variables=variables) == ['var_1', 'var_2']
    variables = {'var_1':'Hello', 'var_2':'World', 'not_var_123':'Some value'}

# Generated at 2022-06-25 11:40:25.687286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {u'key_2': 1, u'key_1': 1}
    terms_0 = [u'.+']
    result_0 = lookup_module_0.run(terms_0, variables=vars_0)
    print(type(result_0))
    print(result_0)


test_LookupModule_run()

# Generated at 2022-06-25 11:40:35.616779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    
    variables = {}
    lookup_module.set_options(var_options=variables, direct=None)
    
    # test without variables
    term = "run"
    try:
        lookup_module.run(terms=term)
    except Exception as e:
        assert "No variables available to search" in str(e)
    
    # test with terms is not string
    variables = {"a":1,"b":2,"c":3}
    lookup_module.set_options(var_options=variables, direct=None)
    
    term = [1,2,3]
    try:
        lookup_module.run(terms=term)
    except Exception as e:
        assert "Invalid setting identifier" in str(e)
    

# Generated at 2022-06-25 11:40:45.923993
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 0:
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    result = lookup_module_0.run(terms, variables, **kwargs)
    expected = ['qz_1', 'qz_2']

    # Case 1:
    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    result = lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:40:50.988674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['^qz_.+']
    variables_0 = {'qz_2': 'world', 'qz_1': 'hello', 'qz_': "I won't show either", 'qa_1': "I won't show"}
    kwargs_0 = {'vault_password': 'abc123'}
    assert lookup_module_0.run(terms=terms_0, variables=variables_0, **kwargs_0) == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:40:57.176428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    terms = ["^qz_.+"]
    res = lookup_module_0.run(terms, vars)
    assert res == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:41:08.284289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Create a variable named test_variable
    variable = {'test_variable': 'test_var_value'}

    # Example of valid identifier
    search_term = '^test_v.+'
    result = lookup_module.run([search_term], variable)
    assert type(result) is list
    assert len(result) == 1
    assert result[0] == 'test_variable'

    # Example of invalid identifier (not a string)
    search_term = 2
    with pytest.raises(AnsibleError):
        result = lookup_module.run([search_term], variable)

    # Example of invalid identifier (cannot be compiled)
    search_term = 'test_var(?'
    with pytest.raises(AnsibleError):
        result = lookup_

# Generated at 2022-06-25 11:41:16.656342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # TODO: AnsibleVariables(dict)
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module.set_options(var_options=variables, direct={})
    
    terms = ['^qz_.+']
    result = lookup_module.run(terms, variables)

    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:41:33.134482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    import ansible.parsing.yaml.objects
    # test with additional parameters
    terms = ['^qz_.+']
    variables = ansible.parsing.yaml.objects.AnsibleVars(dict(qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either"))
    ret = lookup_module_0.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:41:35.724121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('^qz_.+')

# Generated at 2022-06-25 11:41:38.539373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ''
    variables = {}
    ret1 = lookup_module_0.run(terms, variables)
    assert ret1 == [], str(ret1)


# Generated at 2022-06-25 11:41:46.224245
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show",
        "test1": "test1",
        "test2": "test2"
    }

    lookup_module = LookupModule()

    # Test valid parameter passed
    assert lookup_module.run(['^qz_.+'], variables) == ["qz_1", "qz_2"]

    # Test invalid parameter passed
    assert lookup_module.run([1], variables) == ['test1', 'test2']

    # Test invalid parameter passed
    assert lookup_module.run([None], variables) == ['test1', 'test2']

# Generated at 2022-06-25 11:41:47.954386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test case for pylint complaint
    test_case_0()

    return

# Generated at 2022-06-25 11:41:48.727098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_0(LookupModule())


# Generated at 2022-06-25 11:42:01.192245
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Run method with an empty variable list
    try:
        lookup_module_1 = LookupModule()
        lookup_module_1.run(['test1'], variables=dict())
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Run method with a list of invalid search terms
    try:
        lookup_module_2 = LookupModule()
        lookup_module_2.run([1, 2, 0], variables=dict())
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <type \'int\'>'

    # Run method with a list of search terms

# Generated at 2022-06-25 11:42:09.562588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = ['^qz_.+']
    variables_3 = {'qz_2': 'world', 'qz_1': 'hello', 'qz_': "I won't show either", 'qa_1': "I won't show"}
    kwargs_4 = {}
    var_options_5 = variables_3
    direct_6 = kwargs_4
    lookup_module_1.set_options(var_options=var_options_5, direct=direct_6)
    ret_7 = []
    variable_names_8 = list(variables_3.keys())

# Generated at 2022-06-25 11:42:16.468458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '^qz_.+'
    variables_0 = {}
    variables_0['qz_1'] = 'hello'
    variables_0['qz_2'] = 'world'
    variables_0['qa_1'] = 'I won\'t show'
    variables_0['qz_'] = 'I won\'t show either'
    assert lookup_module_0.run(terms_0, variables_0) == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:42:21.173411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run of LookupModule
    """
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["^qz_.+"]) == []
    assert lookup_module_0.run(["^qz_.+"]) is not None
    assert lookup_module_0.run(["^qz_.+"]) != []
    assert lookup_module_0.run(["^qz_.+"]) != []

# Generated at 2022-06-25 11:42:42.083334
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True


# Generated at 2022-06-25 11:42:50.026119
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = "^qz_.+"
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Set the kwargs
    kwargs = {
        "warnings": "qz_1,qz_2"
    }
    # Add the kwargs to configuration
    configuration = {
        "warnings": "qz_1,qz_2"
    }

    # Instantiate the class
    lookup_module_0 = LookupModule()

    # Assign the variables
    lookup_module_0.set_options({'var_options': variables, 'direct': kwargs})

    # Expected result

# Generated at 2022-06-25 11:42:57.582834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-25 11:43:02.763456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    try:
        ret = lookup_module_0.run(None, None)
    except AnsibleError as e:
        assert(e.message == 'Invalid setting identifier, "None" is not a string, it is a {}'.format(type(None)))


# Generated at 2022-06-25 11:43:03.789052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
# Not Implemented yet
    pass
#    assert True


# Generated at 2022-06-25 11:43:10.572664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}
    result = LookupModule().run(term, variables)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-25 11:43:15.051197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    testdata = {'key1': 'value1'}
    terms = ['.+_zone$', '.*_location$']
    result = lookup_module_0.run(terms, testdata)
    assert sorted(result) == sorted(['key1'])


# Generated at 2022-06-25 11:43:16.643541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 11:43:22.546855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['.*zone$']
    variables = {'ANSIBLE_INVENTORY': 'ansible-hosts',
                 'ansible_zone': 'lab'}
    result = lookup.run(terms, variables)
    assert result == ['ansible_zone'], "unexpected result, expected ['ansible_zone'], got %s" % result

# Generated at 2022-06-25 11:43:25.616314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["\\.+"],None)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:43:53.997939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_dic = {}
  var_terms = ""
  var_value = lookup_module_0.run(var_terms, var_dic)


# Generated at 2022-06-25 11:43:59.298811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ----------------------------------------------------------------------
    # Setup test objects
    lookup_module_0 = LookupModule()

    # ----------------------------------------------------------------------
    # Execute the run() method
    variables_0 = dict({u'args': u'', u'failed': False, u'changed': False, u'ping': u'pong'})
    terms_0 = []
    run_0_return = lookup_module_0.run(terms_0, variables_0)

    # ----------------------------------------------------------------------
    # Assert the return value of run
    assert run_0_return == []


# Generated at 2022-06-25 11:44:01.878681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule().run
    assert True == isinstance(lookup_run, object)


# Generated at 2022-06-25 11:44:04.198562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ["qz_1", "qz_2"]

# Generated at 2022-06-25 11:44:13.739768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup verification
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    # Assertion verification
    msg = 'The object lookup_module_0 is not a instance of class LookupModule'
    assert isinstance(lookup_module_0, LookupModule), msg
    msg = 'The object var_0 is not a list'
    assert isinstance(var_0, list), msg
    msg = 'Expected the list is not empty'
    assert var_0 != [], msg
    msg = 'The object lookup_module_0 is not a instance of class LookupModule'
    assert isinstance(lookup_module_0, LookupModule), msg
    msg = 'The object var_0 is not a list'
    assert isinstance(var_0, list), msg

# Generated at 2022-06-25 11:44:18.003873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert len(var_0) == 2
    assert str(var_0) == "['qz_1', 'qz_2']"


# Generated at 2022-06-25 11:44:22.920283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_var = LookupModule()
    var = lookup_module_run()
    assert var == 'variable_name'

# Generated at 2022-06-25 11:44:31.681646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = {'direct': {}, 'var_options': {}}
    terms_0 = ['^qz_.+']
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0, **args_0)

    assert 'qz_1' in ret_0
    assert 'qz_2' in ret_0
    assert 'qa_1' not in ret_0
    assert 'qz_' not in ret_0


# Generated at 2022-06-25 11:44:37.821184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms, variables, direct=kwargs)
    except AnsibleError:
        pass

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:44:46.452073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('^qz_.+')
    test_variables_0 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    test_terms_0 = [{'term': '^qz_.+', 'direct': True, 'var_options': test_variables_0}]
    test_kwargs_0 = {'undefined_var': 'test_value_1'}
    test_run_0 = lookup_module_0.run(test_terms_0, test_variables_0, **test_kwargs_0)


# Generated at 2022-06-25 11:45:40.174105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=terms_0, variables=variables_0)
    lookup_module_0.run(terms=terms_1)
    lookup_module_0.run(terms=terms_2, variables=variables_1)
    lookup_module_0.run(terms=terms_3, variables=variables_2)


# Generated at 2022-06-25 11:45:46.611224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # AssertionError: {'_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_version': '2.8.2', '_ansible_version_string': '2.8.2', '_ansible_verbosity': 0, '_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p', 'vfat'], '_ansible_debug': False}
    # Expected: <class 'list'>
    # Actual: <class 'ansible.parsing.dataloader.DataLoader'>
    assert isinstance(lookup_module.run({'_terms': 'test'}), list)


# Generated at 2022-06-25 11:45:50.247846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('^qz_.+', {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert var_0[0] == 'qz_1'
    assert var_0[1] == 'qz_2'


# Generated at 2022-06-25 11:45:55.412069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var1 = dict()
    var1[u'term1'] = u'regex'
    var2 = dict()
    var2[u'vars'] = var1
    lookup_module_0 = LookupModule()
    lookup_module_0.run(u'term1', var2)


# Generated at 2022-06-25 11:45:56.420511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run()) > 0

# Generated at 2022-06-25 11:46:03.077913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert "^qz_.+" in var_0
    assert "qa_1" not in var_0
    assert "qz_" not in var_0
    assert "qz_1" in var_0
    assert "qz_2" in var_0

# Generated at 2022-06-25 11:46:09.542197
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms_0, variables_0)

    for var_1 in range(0, len(var_0)):
        assert var_1 == var_0[var_1]


# Generated at 2022-06-25 11:46:18.648908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 'awesome'

    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert var_1 == 'awesome'

    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2)
    assert var_2 == 'awesome'

    lookup_module_3 = LookupModule()
    var_3 = lookup_run(lookup_module_3)
    assert var_3 == 'awesome'

    lookup_module_4 = LookupModule()
    var_4 = lookup_run(lookup_module_4)
    assert var_4 == 'awesome'

# Generated at 2022-06-25 11:46:25.949688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_vars = dict(ansible_ssh_host='127.0.0.1',ansible_ssh_user='root',ansible_ssh_pass='password')
    lookup_module = LookupModule()
    lookup_module.run('^ansible_.+',variables=my_vars,default_variable_prefix='ansible',variable_prefix='ansible',variable_information=False,variable_data=False)


# Generated at 2022-06-25 11:46:34.396901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=["qz_.*$"])
    var_1 = lookup_module_0.run(terms=[".*"])
    var_2 = lookup_module_0.run(terms=["^qz_.+$"])
    var_3 = lookup_module_0.run(terms=["^qa_.+$"])
    var_4 = lookup_module_0.run(terms=["^qz_$"])
    var_5 = lookup_module_0.run(terms=["hosts"])
    var_6 = lookup_module_0.run(terms=[".+_zone$", ".+_location$"])

    # Assert that the return is a list