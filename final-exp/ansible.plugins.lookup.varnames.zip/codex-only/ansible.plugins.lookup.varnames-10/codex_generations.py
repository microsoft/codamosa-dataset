

# Generated at 2022-06-23 12:30:58.274248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyVars(object):
        _data = {
            'a': 1,
            'b': 2,
            'ABC': 3,
        }
        def get(self, key, default=None):
            if key in self._data:
                return self._data[key]
            return default

    terms = ['^a$', 'bc']
    variables = DummyVars()
    lookup = LookupModule()
    results = lookup.run(terms, variables=variables)
    assert results == ['a', 'ABC']

# Generated at 2022-06-23 12:31:05.033963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import json
    import pytest

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    # Fixture of JSON dump of variable data

# Generated at 2022-06-23 12:31:06.723495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:31:15.582625
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = LookupModule().run(terms = ['^test.+', '^test2.+'], variables = {'test_test': 'value', 'test2': 'value2'})

    assert len(terms) == 2
    assert 'test_test' in terms and 'test2' in terms

    terms = LookupModule().run(terms = ['^test.+', '^test2.+'], variables = {'test2_test': 'value', 'test2': 'value2'})
    
    assert len(terms) == 1
    assert 'test2' in terms


# Generated at 2022-06-23 12:31:21.553591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    ret = lookup.run(terms, variables)
    assert len(ret) == 2
    assert 'qz_1' in ret
    assert 'qz_2' in ret

# Generated at 2022-06-23 12:31:32.506898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    """
    # unit test for missing variables
    terms = ['^qz_.+']
    variables = None
    with pytest.raises(AnsibleError):
        ret = lookup.run(terms, variables)
    """
    # unit test for non-string identifier
    """
    terms = [1,'^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    with pytest.raises(AnsibleError):
        ret = lookup.run(terms, variables)
    """
    # unit test for valid query
    terms = ['^qz_.+']

# Generated at 2022-06-23 12:31:37.617347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._options = {}
    lookup._loader = None
    terms = ['hosts']
    variables = {'hostvars': {'host1':1, 'host2':2}, 'host_group': 'group1'}
    assert ['hostvars', 'host_group'] == lookup.run(terms, variables)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:31:48.840426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.var_names import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from collections import namedtuple
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    import pytest

    # Create the module object under test
    var_names_lookup = LookupModule()

    # Create a fake Ansible spec containing the mock variables
    Variables = namedtuple('Variables', ['allvars'])

# Generated at 2022-06-23 12:31:53.141031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    super(LookupModule, lookup_module)
    # assert lookup_module
    # assert isinstance(lookup_module, LookupBase)
    # assert hasattr(lookup_module, 'run')
    # assert callable(getattr(lookup_module, 'run'))

# Generated at 2022-06-23 12:32:04.344848
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_list = ['string', 2, True]
    my_dict = {'qwerty':1, '12345':2}
    my_tuple = (1, 2, 3, 4)
    my_set = set([1,2,3])

    my_list_json = ['"string"', 2, True]
    my_dict_json = '{"12345": 2, "qwerty": 1}'
    my_tuple_json = '(1, 2, 3, 4)'
    my_set_json = '[1, 2, 3]'

    assert my_list == LookupModule._to_python(LookupModule._to_json(my_list))
    assert my_dict == LookupModule._to_python(LookupModule._to_json(my_dict))
    assert my_tuple == Lookup

# Generated at 2022-06-23 12:32:06.430634
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=redefined-outer-name
    lookup_module = LookupModule()
    assert(isinstance(lookup_module, LookupModule))



# Generated at 2022-06-23 12:32:07.602480
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-23 12:32:09.919104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L1 = LookupModule()
    assert type(L1) == LookupModule


# Generated at 2022-06-23 12:32:17.010281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test data
    variables = {'a': 'a', 'b_c': 'b_c', 'c': 'c', 'd': 'd'}
    terms = ['a']
    test_object = LookupModule()

    # Run the test
    result = test_object.run(terms, variables)

    # Verify expectations
    assert isinstance(result, list), "result is not a list: %r" % result
    assert len(result) == 1, "length of result is not 1: %r" % result
    assert result[0] == 'a', "result does not contain variable a: %r" % result


# Generated at 2022-06-23 12:32:24.106181
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import pwd
    class DummyVars:
        def __init__(self):
            self.test_1 = "value1"
            self.test_2 = "value2"
            return
    variables = DummyVars()

    try:
        lookup_instance = LookupModule()
        lookup_instance.run(terms=['^test_.+'], variables=variables)
    except Exception as e:
        raise Exception('Failed to call run(). Error: %s' % str(e))
    return

# Generated at 2022-06-23 12:32:32.633605
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_obj = LookupModule()
    assert lookup_obj
    url_options = {}
    url_options["ansible_python_interpreter"] = '/bin/python'
    url_options["ansible_user"] = 'user'
    url_options["ansible_user_dir"] = ''
    url_options["ansible_verbosity"] = 1
    url_options["ansible_version"] = '1.0'
    url_options["ansible_version_full"] = '1.0'
    url_options["ansible_version_major"] = '1'
    url_options["ansible_version_minor"] = ''
    url_options["ansible_version_revision"] = ''
    url_options["ansible_verbosity"] = 1

# Generated at 2022-06-23 12:32:40.576854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with variable names
    test_name = {'var1': 'hello', 'var2': 'world', 'var3': '!'}
    test_term = ['var1', 'var2', 'var3']
    test_run = LookupModule().run(terms=test_term, variables=test_name)
    assert test_run == test_term

    # Test with regex
    test_term2 = ['var.*']
    test_run2 = LookupModule().run(terms=test_term2, variables=test_name)
    assert test_run2 == test_term

# Generated at 2022-06-23 12:32:50.987935
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 1: the terms is list of strings
    terms = ['^qz_.+', r'.+_location\$']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either",
                 'z_loc':'here', 'z_location':'there'}
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables=variables)
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'z_location' in result
    assert 'z_loc' in result
    
    # Case 2: the terms is a string
    terms = ['z_location']

# Generated at 2022-06-23 12:32:59.756830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_vars = {
        'qz_1': "hello",
        'qz_2': "world",
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    terms = [
        '^qz_.+',
        '.+_zone$',
        '.+_location$'
    ]

# Generated at 2022-06-23 12:33:07.715697
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_terms = ['^qz_.+', 'hosts', '.+']
    test_variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qz_": "I won't show",
        "qa_1": "I won't show either",
        "hosts": "the hosts",
        "domain": "ansible.com",
        "name": "Ansible",
        "ansible_version": "2.8.0"
    }

# Generated at 2022-06-23 12:33:17.786489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    list_vars = ['qz_1', 'qz_2', 'qa_1', 'qz_', 'dev_vars']
    ans = ['qz_1', 'qz_2']
    res = look.run(['^qz_.+'], variables=dict(zip(list_vars, list_vars)))
    assert res == ans
    ans = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    res = look.run(['.+'], variables=dict(zip(list_vars, list_vars)))
    assert res == ans
    ans = ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-23 12:33:25.853408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class mock_variables(object):
        def __init__(self, mock_names):
            self._mock_names = mock_names

        def keys(self):
            return self._mock_names

    class mock_self(object):
        def __init__(self, mock_variables):
            self.variables = mock_variables

        def set_options(self, *args, **kwargs):
            pass

    # Wrong type of _terms
    terms = 123
    mock_variables = mock_variables(['qz_1', 'qz_2', 'qa_1', 'qz_'])
    mock_self = mock_self(mock_variables)

# Generated at 2022-06-23 12:33:35.862210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(["^test_"], {"test_var_1": "test_value_1", "test_var_2": "test_value_2", "test_var_3": "test_value_3", "test_": "test_value_4"})
    assert(len(result) == 3)
    assert("test_var_1" in result)
    assert("test_var_2" in result)
    assert("test_var_3" in result)
    assert("test_" not in result)

    result = LookupModule().run(["^test_", "var_[12]"])
    assert(len(result) == 2)
    assert("test_var_1" in result)
    assert("test_var_2" in result)

# Generated at 2022-06-23 12:33:47.339594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_vars = {
        's1': 's1',
        's2': 's2',
        's3': 's3',
        's4': 's4',
        's5': 's5',
        's6': 's6',
    }
    lookup_obj = LookupModule()
    # Test patter 1
    result = lookup_obj.run(['s[1-3]'], test_vars)
    assert result == ['s1', 's2', 's3']
    # Test patter 2
    result = lookup_obj.run(['s[2-4]'], test_vars)
    assert result == ['s2', 's3', 's4']
    # Test case-sensitivity

# Generated at 2022-06-23 12:33:49.499361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(terms=['1'], variables={"1": "one", "2": "two"})

# Generated at 2022-06-23 12:34:00.642878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with valid set of parameters
    lookup = LookupModule()
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }
    ret = lookup.run(terms=["^qz_.+"], variables=variables)
    assert "qz_1" in ret, "qz_1 is not in ret"
    assert "qz_2" in ret, "qz_2 is not in ret"
    assert "qa_1" not in ret, "qa_1 is in ret"
    assert "qz_" not in ret, "qz_ is in ret"

    # Testing with invalid set of parameters
    ret = []

# Generated at 2022-06-23 12:34:02.924879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:34:12.232193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    print(sys.argv)

    # Check the case where a search parameter is invalid
    test_lookup = LookupModule()
    test_lookup.set_options(direct={})

    test_terms = ['^qz_{0,1}.+']
    test_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    search_results = test_lookup.run(test_terms, variables=test_variables)
    assert len(search_results) == 2
    assert 'qz_1' in search_results
    assert 'qz_2' in search_results

    # Check the case where no variable names match the search parameter

# Generated at 2022-06-23 12:34:23.909772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Test if method run finds a matching variable name. '''

    import re
    import pytest

    # Test data
    variables = {}
    variables['matching_1'] = 'value'
    variables['matching_2'] = 'value'
    variables['missmatch'] = 'value'

    # Search value and expected result
    search_value = re.compile('matching_.+')
    expected_result = ['matching_1', 'matching_2']

    # Create LookupModule Object
    lookup_module = LookupModule()

    # Set variable name
    lookup_module.set_options(var_options=variables, direct={})
    assert lookup_module.get_options()['var_options'] == variables

    # Search for matching variable names
    result = lookup_module.run([search_value], variables)

# Generated at 2022-06-23 12:34:24.855625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None)

# Generated at 2022-06-23 12:34:37.948302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test case with no variables
    try:
        # No variables should throw an exception
        lookup.run(terms=['x'], variables=None)
        assert False
    except AnsibleError:
        pass

    # Test case with no terms
    try:
        # No terms should throw an exception
        lookup.run(terms=[], variables={'x': 1, 'y': 2, 'z': 3})
        assert False
    except AnsibleError:
        pass

    # Test case with a non-regex term
    try:
        # A non-regex term should throw an exception
        lookup.run(terms=[1], variables={'x': 1, 'y': 2, 'z': 3})
        assert False
    except AnsibleError:
        pass

    # Test case with an invalid regex term

# Generated at 2022-06-23 12:34:44.174694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["^qz_.*"]
    variables = {"qz_1":"hello", "qz_2":"world", "qa_1":"I won't show", "qz_":"I won't show either"}
    ret = lookup_module.run(terms, variables)
    assert(ret == ["qz_1", "qz_2"])

# Generated at 2022-06-23 12:34:45.562024
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:34:46.602497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('module_utils.module_name')

# Generated at 2022-06-23 12:34:55.445309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run(terms=['.'], variables=dict(a='a',b='b',c='c')) == ['a','b','c']
    assert LookupModule().run(terms=['^a'], variables=dict(a='a',b='b',c='c')) == ['a']

    try:
        assert LookupModule().run(terms=['^a'], variables=dict(a={'a','b','c'})) == ['a']
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "^a" is not a string, it is a <class \'set\'>'

# Generated at 2022-06-23 12:35:04.621987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_lookup_class_args(self):
        return self._lookup_kwargs['terms']

    LookupModule._get_terms_original = LookupModule._get_terms
    LookupModule._get_terms = get_lookup_class_args

    lookup_mod = LookupModule()
    terms = ['.+_zone$', '.+_variables$']
    variables = {'vpc_zone': 'us-east-1a', 'vpc_variables': 'test_vpc_variables'}
    ret = lookup_mod.run(terms, variables)

    assert sorted(ret) == sorted(['vpc_zone', 'vpc_variables'])

# Generated at 2022-06-23 12:35:05.405349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-23 12:35:06.671250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert len(module.run(['testing'])) == 0

# Generated at 2022-06-23 12:35:07.460519
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:35:08.986760
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:35:09.963822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:35:10.912839
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:35:11.686889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:35:12.886559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Verify LookupModule constructor
    """
    my_lookup = LookupModule()


# Generated at 2022-06-23 12:35:14.510257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'
    assert LookupModule.__doc__ == "Returns a list of variable names that match a regular expression"

# Generated at 2022-06-23 12:35:16.368413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an instance of class LookupModule
    lookup_module = LookupModule()
    # check if instance was created
    assert lookup_module


# Generated at 2022-06-23 12:35:24.335130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['^qz_.*'])  == []
    assert LookupModule().run(terms=['^qz_.*'], variables={'qz_1':1}) == ['qz_1']
    assert LookupModule().run(terms=['^qz_.*'], variables={'qz_1':1, 'qz_2':1}) == ['qz_1', 'qz_2']


# Generated at 2022-06-23 12:35:30.588864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '.+_zone$', '.+_location$']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'qz_zone': 'somewhere', 'qz_location': 'there'}
    result = {}
    result['_value'] = ['qz_1', 'qz_2', 'qz_zone', 'qz_location']
    res = LookupModule().run(terms, variables)
    assert res == result['_value']


# Generated at 2022-06-23 12:35:39.015453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    try:
        lookup_module.run([], variables = None)
    except Exception as e:
        if str(e) != 'No variables available to search':
            assert 0, 'unexpected exception "%s"' % str(e)

    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qz_3': 'world'}
    assert lookup_module.run(['.+_2'], variables) == ['qz_2']

# Generated at 2022-06-23 12:35:41.138583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'net_intf': {}}
    assert LookupModule().run(['net_intf'], variables) == ['net_intf']

# Generated at 2022-06-23 12:35:50.366388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [ 'qz_.+' ]
    variables =  {
                    "qz_1": "hello",
                    "qz_2": "world",
                    "qa_1": "I won't show",
                    "qz_": "I won't show either"
                }
    lookup_plugin = LookupModule()
    assert(lookup_plugin.run(terms, variables) == ['qz_1', 'qz_2'])

    terms = [ '.+' ]
    assert(lookup_plugin.run(terms, variables) == variables.keys())


# Generated at 2022-06-23 12:35:58.587677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = LookupModule()
    matchers = [
        'foo.+bar',
        '^qz_',
        'foo.[0-9]+',
        'a[[:lower:]]z',
    ]

    matches = a.run(matchers, variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'foo1bar': 'hello world',
        'foo2bar': 'hello world',
        'foo_bar': 'hello world',
        'afoo8bar': 'hello world',
    })


# Generated at 2022-06-23 12:36:09.577178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    class AnsibleModule:
        def __init__(self):
            self.params = dict()
        def fail_json(self, **kwargs):
            raise
    class AnsibleError:
        def __init__(self):
            pass
    class LookupBase:
        def __init__(self):
            self.set_options(var_options=variables, direct=kwargs)

    variables= {'variable_names':['a','b','c','ab','ab','abcd','abc'],'term':['a','b','c','ab','ab','abcd','abc']}
    lm = LookupModule()

    # Execute
    a = lm.run(variables['term'], variables)

    # Verify
    expected = ['a','b','c','ab','ab','abcd','abc']

# Generated at 2022-06-23 12:36:11.795343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        raise AssertionError("test_LookupModule() failed with message: %s" % e)

# Generated at 2022-06-23 12:36:15.616841
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mod = LookupModule()
    mod.run(terms=["^qz_.+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})

# Generated at 2022-06-23 12:36:23.150423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock of class LookupModule
    class MockLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(MockLookupModule, self).run(terms=terms, variables=variables, **kwargs)

    lookup_class = MockLookupModule()
    result = lookup_class.run('^qz_.+')
    assert result == []

# Generated at 2022-06-23 12:36:34.590798
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for invalid terms
    test_terms = ['a', 'b', 'c']
    for test_term in test_terms:
        try:
            lookup_module = LookupModule()
            lookup_module.run(test_term)

        except AnsibleError as e:
            assert test_term in to_native(e)

    # Test for invalid variables
    lookup_module = LookupModule()
    try:
        lookup_module.run('.*')

    except AnsibleError as e:
        assert isinstance(e, AnsibleError)

    # Test for empty variables
    lookup_module = LookupModule()
    try:
        lookup_module.run('.*', {})

    except AnsibleError as e:
        assert isinstance(e, AnsibleError)

    # Test for valid terms and variables
    test_

# Generated at 2022-06-23 12:36:40.346416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    test_vars = {'test_var': 'hello', 'test_varname': 'hello', 'test_var2': 'hello', 'test_var_here': 'hello'}
    terms = ['.*_var$', '.*var.*']
    r = module.run(terms, test_vars)
    assert r == ['test_var', 'test_varname', 'test_var2', 'test_var_here']

# Generated at 2022-06-23 12:36:41.791209
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm


# Generated at 2022-06-23 12:36:48.932939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  l.set_inputs({ 'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"  })
  assert l.run([ '^qz_.+' ]) == [ 'qz_1', 'qz_2' ]
  assert l.run([ '^qz_.+', 'world' ]) == [ 'qz_1', 'qz_2', 'world' ]
  assert l.run([ '.+_hosts$' ]) == []

# Generated at 2022-06-23 12:36:50.754665
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert type(test_obj) is LookupModule



# Generated at 2022-06-23 12:36:52.174060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:37:03.966990
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    names = [
        'hello',
        'world',
        'qz_zone',
        'qz_location',
        'location_zone',
        'zone_location',
    ]

    vars = {'hello':1, 'world':2, 'qz_zone':3, 'qz_location': 4, 'location_zone': 5, 'zone_location': 6}

    class LookupModule_run():
        def __init__(self, vars):
            self.vars = vars

    l = LookupModule_run(vars)

    # test simple search
    assert l.run(['^qz_.+']) == ['qz_zone', 'qz_location']

    # test multi search

# Generated at 2022-06-23 12:37:13.144935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize a LookupModule instance called lm
    lm = LookupModule()

    # Populate the terms list
    terms = ["aaa", "bbb", "ccc"]

    # Populate the variables dictionary
    var1 = "aaa"
    var2 = "bbb"
    var3 = "true"
    variables = {var1:var1, var2:var2, var3:var3}

    # Invoke the run() method with the populated term and variables lists
    ret = lm.run(terms=terms, variables=variables)

    # Validate that the returned list is populated correctly
    assert ret == terms


# Generated at 2022-06-23 12:37:15.816962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module =  LookupModule()
    lookup_module.run(terms = ["qz_1"],
                      variables = {"qz_1": "hello",
                                   "qz_2": "world"})

# Generated at 2022-06-23 12:37:22.487090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look_up = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = dict()
    result = look_up.run(terms, variables, **kwargs)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-23 12:37:32.271390
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class AnsibleModuleMock(object):
        def fail_json(self, **kwargs): pass
        def exit_json(self, **kwargs): pass

    class AnsibleMock(object):
        class AnsibleError(object):
            pass
        class AnsibleModule(object):
            def __init__(self):
                self.params = {}

    def igr(t):
        if isinstance(t, string_types):
            return re.compile(t)
        else:
            raise AnsibleError('Invalid setting identifier, "%s" is not a string, it is a %s' % (t, type(t)))

    class LookupBaseMock(object):
        def set_options(self, var_options, direct):
            self.__dict__.update(direct)

    # Test basic operation
    terms

# Generated at 2022-06-23 12:37:33.241291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 12:37:43.069180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib')))
    from ansible.plugins import loop

    variables = {'a_1': 'hello', 'a_2': 'world', 'b_1': 'I won\'t show', 'a_': 'I won\'t show either'}
    my_lookup = LookupModule()
    my_lookup.set_options(var_options=variables, direct=None)

    result = my_lookup.run(['^a_.+'], variables)
    assert result == ['a_1', 'a_2']

    result = my_lookup.run(['.+'], variables)


# Generated at 2022-06-23 12:37:53.364686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize empty instance of LookupModule class.
    # This instance will be used by other tests
    lookup_instance = LookupModule()

    # Initialize variables dictionary.
    # This dictionary will be used by other tests
    variables = {
        'qa_1': 'hello',
        'qz_1': 'world'
    }

    # Check if module ran successfully when correct and incorrect params are passed
    assert lookup_instance.run(terms=['^qz_.+'], variables=variables) == ['qz_1']
    assert lookup_instance.run(terms=['qz_'], variables=variables) == ['qz_1']
    assert lookup_instance.run(terms=['qz_.+'], variables=variables) == []

# Generated at 2022-06-23 12:37:54.463993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule



# Generated at 2022-06-23 12:37:58.475763
# Unit test for constructor of class LookupModule
def test_LookupModule():
    source = 'Vars/dict/vars_dict.yaml'
    source_type = 'vars_files'
    source_run_once = True

    varnames = LookupModule()

    assert varnames is not None
    assert isinstance(varnames, LookupModule)

# Generated at 2022-06-23 12:37:59.683409
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) == type

# Generated at 2022-06-23 12:38:06.673262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test of LookupModule run method"""

    import sys
    import os
    sys.path.insert(0, '')
    TEST_DIR = os.path.dirname(os.path.abspath(__file__))
    TESTSCRIPT_PATH = os.path.join(TEST_DIR, 'testscript.py')
    lm = __import__(TESTSCRIPT_PATH)
    variables = {'abc_01': 123, 'abc_02': 456, 'abc_03': 789, 'zzz_01':'abc'}
    terms = ['abc_.+', '.+_01']
    ret = lm.LookupModule(variables=variables).run(terms)

# Generated at 2022-06-23 12:38:14.516391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import ansible.module_utils.c_varnames as test_module

    dummy_class = type('DummyClass', (object,), {})()
    dummy_module = type('DummyClass', (object,), {})()
    dummy_module.params = {'_ansible_lookup_parameters': {'test': 'test'}, '_ansible_lookup_values': {'test': 'test'}}
    dummy_module.params['_ansible_lookup_plugin'] = test_module.LookupModule
    dummy_module.fail_json = lambda **args: sys.exit(1)

    try:
        dummy_module.varnames()
    except SystemExit as e:
        if e.code != 1:
            raise


# Generated at 2022-06-23 12:38:15.153356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:38:20.910386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # LookupModule instantiation
    lm = LookupModule()

    # Call run with terms and variables
    terms = ['.+_zone$', '.+_location$']
    variables = {'qa': 'qa1', 'qz_zone': 'qz1', 'qz_location': 'qz2'}
    lm.run(terms, variables)

# Generated at 2022-06-23 12:38:23.608525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dummy = type('Dummy', (object,), {})()
    cls = LookupModule(dummy)
    assert cls.get_options() == {'run_once': False}

# Generated at 2022-06-23 12:38:35.267890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule is abstract, so create a derived class to test run:
    # The derived class is also abstract, but that shouldn't matter here
    class TestClass(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            # Call base method with terms, but not with variables
            return super(TestClass, self).run(terms, **kwargs)

    lookup_plugin = TestClass()

    # Test run with no variables in the variables dictionary
    try:
        lookup_plugin.run(terms=['test1'], variables={})
    except AnsibleError:
        pass
    else:
        raise AssertionError("run method didn't raise AnsibleError")

    # Test run with a variable in the variables dictionary

# Generated at 2022-06-23 12:38:42.485304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    modlook = LookupModule()

    assert modlook

    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show'}

    ret = modlook.run(terms, variables, pattern="")
    assert len(ret) == 2
    assert ret[0] == 'qz_1'
    assert ret[1] == 'qz_2'

# Generated at 2022-06-23 12:38:43.178808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:38:45.932552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.set_options({'vars': {'test_var': 'hello'}})
    assert test._templar.template("{{ test_var }}") == 'hello'


# Generated at 2022-06-23 12:38:57.757353
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Variables:
        def get(self):
            return {
                'wayn_secure': True,
                'wayn_private': True,
                'wayn_ppp': True,
                'wayne': True,
                'wayn_public': True
            }

    lookup_obj = LookupModule()

    variables_obj = Variables()

    # Test success case
    result = lookup_obj.run(terms=['^wayn.*'], variables=variables_obj.get())
    result.sort()
    expected = ['wayn_private', 'wayn_ppp', 'wayn_public', 'wayn_secure', 'wayne']
    assert result == expected

    # Test fail case

# Generated at 2022-06-23 12:39:07.566275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a normal expression
    look = LookupModule()
    ret = look.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert ret == ['qz_1', 'qz_2']

    # Test with an invalid expression
    try:
        look.run(['invalid'], {'qz_1': 'hello', 'qz_2': 'world'})
    except AnsibleError as e:
        assert ('Unable to use "invalid" as a search parameter: nothing to repeat') in str(e)
        pass
    else:
        raise AssertionError('AnsibleError not raised')

    # Test with a non-

# Generated at 2022-06-23 12:39:19.214639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for run method of class LookupModule
    """
    # Check when variables is empty
    module_obj = mock.Mock()
    lookup_instance = LookupModule(loader=module_obj)
    try:
        result = lookup_instance.run(terms="test")
    except Exception as e:
        assert "No variables available to search" in to_native(e)
    else:
        assert "Failed during execution!"

    # Check when terms is empty
    module_obj = mock.Mock()
    lookup_instance = LookupModule(loader=module_obj)
    try:
        result = lookup_instance.run(terms=[])
    except Exception as e:
        assert "No variable names requested" in to_native(e)
    else:
        assert "Failed during execution!"

    # Check

# Generated at 2022-06-23 12:39:30.457092
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    # _terms is required and has no default
    assert (lookup_module.run(["^qz_.+"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})) == ["qz_1", "qz_2"]
    # No matching variables when _terms is empty
    assert (lookup_module.run([], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})) == []
    # No variables available (variables set to None)

# Generated at 2022-06-23 12:39:34.247033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:39:36.284991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Feel free to add your own unit test here
    """
    pass

# Generated at 2022-06-23 12:39:46.247001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVars(dict):
        pass

    class MockLookupModule(object):
        def __init__(self):
            self.options = MockVars()

        def set_options(self, *args, **kwargs):
            pass

    class MockRegex(object):
        def __init__(self, value):
            self.value = value
        def search(self, text):
            return self.value in text

    class MockModule(object):
        def __init__(self):
            self.params = MockVars()
            self.params["terms"] = []

    def run_test(terms, variables, output):
        mock_module = MockModule()
        mock_module.params['terms'] = terms

        mock_lookup = MockLookupModule()

        mock_lookup.options['var_options']

# Generated at 2022-06-23 12:39:55.469150
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule = LookupModule()

    test_terms = ['^qz_.+']
    test_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    test_kwargs = {}

    lookupModule.run(terms = test_terms, variables = test_variables, **test_kwargs)

    assert(test_variables['qz_1'] in lookupModule.run(terms = test_terms, variables = test_variables, **test_kwargs))
    assert(test_variables['qz_2'] in lookupModule.run(terms = test_terms, variables = test_variables, **test_kwargs))

# Generated at 2022-06-23 12:40:06.748810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # From test/units/plugins/lookup/varnames.py of ansible 2.8
    # test_condition
    module = LookupModule()
    # from test/units/plugins/lookup/varnames/test_varnames.py of ansible 2.8
    terms = ['qz_.+']
    variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    variable_names = list(variables.keys())
    ret = module.run(terms, variables=variables)
    assert(ret == ['qz_1', 'qz_2', 'qz_'])
    # test_glob
    terms = ['.+']

# Generated at 2022-06-23 12:40:13.718332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{playbook_dir}}'))),
        ]
    )

    play = Play().load(play_source, variable_manager=vars_manager, loader=loader)

    tqm = None

# Generated at 2022-06-23 12:40:22.108580
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {'job_id': 'job_id_1', 'job_name': 'job_name_1', 'job_name2': 'job_name2_1'}
    terms = ['job_id', 'job_name', 'job_name2']

    # Instantiating LookupModule class
    lookup_module = LookupModule()

    # Calling method run of class LookupModule
    result = lookup_module.run(terms, variables)

    # Asserting final result
    assert result == ['job_id', 'job_name', 'job_name2']

# Generated at 2022-06-23 12:40:31.717910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    loader, inventory, variable_manager = (None, None, None)
    lookup_instance = LookupModule()
    lookup_instance.set_loader(loader)
    lookup_instance.set_inventory(inventory)
    lookup_instance.set_variable_manager(variable_manager)
    terms = ['_zone$', '_location$']
    variables = {
        'this_zone': 'is a zone',
        'this_location': 'is a location',
        'this_is_a_test': 'is a test',
        'this_is_a_test_location': 'is a test'
    }
    res = lookup_instance.run(terms, variables=variables)
    assert len(res) == 2
    assert res[0] == 'this_zone'
    assert res[1] == 'this_location'


# Generated at 2022-06-23 12:40:40.867492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    assert lookup_instance.run(terms=["hello"]) == []
    assert lookup_instance.run(terms=["hello"], variables={'hello': "hello, world"}) == ['hello']
    assert lookup_instance.run(terms=["^hello$"], variables={'hello': "hello, world"}) == ['hello']
    assert lookup_instance.run(terms=["^hello"], variables={'hello': "hello, world"}) == []
    assert lookup_instance.run(terms=["^hello"], variables={'hello': "hello, world", 'hello_world': "foo"}) == ['hello']

# Generated at 2022-06-23 12:40:47.080761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_class = LookupModule()
    my_class.set_options(var_options={'qz_1':'hello', 'qa_1':'foo'})
    assert my_class.run(terms=['^qz_.+'], variables={'qz_1':'hello', 'qa_1':'foo'}) == ['qz_1'], \
        "Method run of class LookupModule returns a different value"

# Generated at 2022-06-23 12:40:53.163109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(dict())
    terms = ['test']
    variables = {
        'test1': 'test1',
        'test2': 'test2',
        'test_test': 'test_test'
    }
    result = lookup.run(terms, variables=variables)
    assert len(result) == 3, 'Number of elements returned'
    assert 'test1' in result, 'test1 is returned'
    assert 'test2' in result, 'test2 is returned'
    assert 'test_test' in result, 'test_test is returned'
