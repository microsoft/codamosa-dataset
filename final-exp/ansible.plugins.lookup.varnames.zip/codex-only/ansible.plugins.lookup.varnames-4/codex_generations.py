

# Generated at 2022-06-23 12:30:54.040193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:31:02.051724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Return a list of all variables
    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}
    assert(['qz_1', 'qz_2', 'qa_1', 'qz_'] == LookupModule().run(terms, variables=variables))
    
    # Return a list of all variables that start with qz_
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}

# Generated at 2022-06-23 12:31:04.221471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:31:06.722875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: abstract this into a base class
    # Done
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-23 12:31:18.143813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup test
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.template import Templar
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{lookup(\'varnames\', var1, var2, var3, var4)}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)

# Generated at 2022-06-23 12:31:23.811702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [
        '^qz_.+'
    ]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either'
    }
    lookup_module.run(terms, variables)


# Generated at 2022-06-23 12:31:34.874308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins import lookup_loader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    loader = lookup_loader._create_loader([])
    lookup_result = loader.get('varnames')
    lookup_obj = lookup_result.get_loader()
    assert lookup_obj.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:31:46.005850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    test_vars = {
        'this_is_a_test': '',
        'another_one': '',
        'this_is_not': '',
    }
    lookup = LookupModule()

    lookup.set_options({
        'var_options': test_vars,
    })

    assert lookup.run(terms=['this.+'], variables=test_vars) == ['this_is_a_test', 'this_is_not']
    assert lookup.run(terms=['.+_one$'], variables=test_vars) == ['another_one']

# Generated at 2022-06-23 12:31:47.025856
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-23 12:31:57.930406
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_vars={
      "qz_1": "hello",
      "qz_2": "world",
      "qa_1": "I won't show",
      "qz_": "I won't show either",
      "var_name_with_hosts": "show me",
      "var_with_hosts": "show me",
      "hello_location": "show me",
      "goodbye_world_location": "show me",
      "hello_zone": "show me",
      "goodbye_world_zone": "show me"
    }

    assert LookupModule().run(
        terms=["^qz_.+"],
        variables=test_vars
    ) == ["qz_1", "qz_2"]


# Generated at 2022-06-23 12:32:06.682733
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of class LookupModule
    lookup_instance = LookupModule()

    # Create empty vars
    variables = dict();

    # Create some variables
    variables['qz_1'] = "hello"
    variables['qz_2'] = "world"
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"

    # Create test_terms
    test_terms = [r'^qz_.+']

    # Run method
    result = lookup_instance.run(test_terms, variables)

    # Check if returned values are ok
    assert result == ["qz_1", "qz_2"], "Unexpected result"

# Generated at 2022-06-23 12:32:15.309147
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import json
    import sys
    import tempfile

    # These imports are required only in this test
    if sys.version_info[0] < 3:
        from io import open
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Instantiate class under test
    lookup_module = LookupModule()

    # Create a temporary file and write JSON values to it
    file_fd, file_path = tempfile.mkstemp()

# Generated at 2022-06-23 12:32:15.673585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:32:25.776031
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test normal path
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I will not show', 'qz_': 'I will not show either'}
    obj = LookupModule()
    ret = obj.run(terms, variables, direct={'plugin_args': ''})
    assert(ret == ['qz_1', 'qz_2'])

    # Test all variables found
    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I will not show', 'qz_': 'I will not show either'}
    ret = obj.run(terms, variables, direct={'plugin_args': ''})

# Generated at 2022-06-23 12:32:33.927731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    def test_helper(variables, terms, expected_output):
        actual_output = lookup_module.run(terms, variables)
        assert sorted(expected_output) == sorted(actual_output)

    test_helper({'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, 
        ['^qz_.+'],
        ['qz_1', 'qz_2'])

# Generated at 2022-06-23 12:32:34.850546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-23 12:32:35.448682
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:32:37.350381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:32:48.202100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    input_data = {u'env': {
                    u'TEST_VAR_1': u'TEST_VAR_VALUE_1',
                    u'TEST_VAR_2': u'TEST_VAR_VALUE_2',
                    u'TEST_VAR_3': u'TEST_VAR_VALUE_3',
                  }
                 }
    # Testing variable lookup
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=['TEST_VAR_1'], variables=input_data['env'], **input_data)
    assert result == ['TEST_VAR_1']

# Generated at 2022-06-23 12:32:56.597299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestLookupModule(unittest.TestCase):

        def test_run_invalid_terms(self):
            lookup_obj = LookupModule()
            terms = [1, 2, 3]
            with self.assertRaises(AnsibleError) as result:
                lookup_obj.run(terms, variables=None, **{})
            self.assertEqual(result.exception.args[0],
                             'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>')

        def test_run_invalid_variable(self):
            lookup_obj = LookupModule()
            terms = ["1"]

# Generated at 2022-06-23 12:33:03.445464
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_r = LookupModule()

    terms = ['^qz_.+']
    variables = dict(
        qz_1='hello',
        qz_2='world',
        qa_1="I won't show",
        qz_="I won't show either"
    )

    # Assert that expected value is returned
    v = my_r.run(terms, variables)
    assert v == ['qz_1', 'qz_2']


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:33:08.983776
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()

    try:
        look.run('some.var', {})
        raise Exception("Unhandled exception was expected")
    except AnsibleError as e:
        # Python 2.6 and 2.7 behave differently in exception handling,
        # so we check for both signatures of the exception
        found_e = e.message.find('No variables available to search') >= 0
        found_e |= e.message.find('No variables available to search') >= 0
        if not found_e:
            raise Exception("Expected exception was not raised")

# Generated at 2022-06-23 12:33:18.825569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test only the name lists
    varnames = [
        "sys_descr", "sys_name", "sys_location", "val1", "val2", "val3",
        "val4", "val5", "val6", "val7", "val8", "val9"
    ]

    # Test only the name lists

# Generated at 2022-06-23 12:33:20.064151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-23 12:33:24.888944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either'
    }
    lu = LookupModule()
    ret = lu.run(terms, variables)
    assert(ret == ['qz_1', 'qz_2'])

# Generated at 2022-06-23 12:33:27.204825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert len(lookup_obj.lookup_type) == 1
    assert lookup_obj.lookup_type[0] == 'varnames'

# Generated at 2022-06-23 12:33:28.466640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:33:29.400144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:33:38.018488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(None, ["^qz_.+"], {}) == []

    assert LookupModule.run(None, ["^qz_.+"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ['qz_1', 'qz_2']

    assert LookupModule.run(None, [".+"], {}) == []

    assert LookupModule.run(None, ["hosts"], {"hosts": {'hosts': ['all']}}) == ['hosts']


# Generated at 2022-06-23 12:33:40.983968
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests that no error is thrown if the constructor is used with
    # no arguments
    module_construction_check = LookupModule()
    assert module_construction_check is not None

# Generated at 2022-06-23 12:33:49.516465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    test_list = ['''^qz_.+''', '''.+''', 'hosts', '''.+_zone$''', '''.+_location$''']
    test_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup.run(test_list, test_variables) == [
        ['qz_1', 'qz_2', 'qz_'],
        ['qz_1', 'qz_2', 'qa_1', 'qz_'],
        [],
        [],
        []]

# Generated at 2022-06-23 12:33:52.482518
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(['hello', 'goodbye'], {'foo': 'bar'})
    assert lookup.get_options() == {}

# Generated at 2022-06-23 12:34:02.668169
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_dict = {
        '1': {'interfaces': ['lo', 'eth0', 'eth1', 'eth2'], 'a': 1},
        '2': {'interfaces': ['lo', 'eth0', 'eth1', 'eth2'], 'b': 2},
        '3': {'interfaces': ['lo', 'eth0', 'eth1', 'eth2'], 'c': 3},
    }

    test_obj = LookupModule()
    test_obj.set_options(var_options=test_dict, direct={})

    # Select 2 variables with interface name
    test_lookup = test_obj.run(['1', '2'], variables=test_dict)
    assert test_lookup == ['1', '2']

    # Select 2 variables with interface name
    test_lookup = test

# Generated at 2022-06-23 12:34:04.405453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:34:05.535925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 12:34:13.736687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '^qz_.+',
        '.+',
        'hosts'
    ]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",

        'db1_name': 'test.db',
        'db1_user': 'admin',
        'db1_pass': 'secret',
        'db1_table': 'table1'
    }
    kwargs = {'wantlist': True}

    # gets results as array
    ret = list(LookupModule(kwargs, variables).run(terms))

# Generated at 2022-06-23 12:34:23.712474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module1 = {'ansible_host': '1.1.1.1', 'ansible_port': 22}
    module2 = {'ansible_host': '2.2.2.2', 'ansible_port': 22, 'ansible_user': 'admin'}
    module3 = {'ansible_host': '3.3.3.3', 'ansible_port': 22, 'ansible_user': 'admin'}
    modules = [module1, module2, module3]

    lu = LookupModule()
    actual = lu.run(terms=['ansible_host', 'ansible_user'], variables=modules)

    assert not actual is None

# Generated at 2022-06-23 12:34:36.699567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #validate regex:
    regex1 = '^qz_.+'
    regex2 = '.+_zone$'
    regex3 = '.+_location$'

    test_vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    out1 = lookup.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})
    assert len(out1) == 2
    assert out1[0] == 'qz_1'

# Generated at 2022-06-23 12:34:37.288515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:34:48.451589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import text_type

    test_data = {
        'hello_world': 'a',
        'world_hello': 'b',
        'hello_world_again': 'c',
        'world_hello_again': 'd',
        'world': 'e',
        'hello': 'f',
    }


# Generated at 2022-06-23 12:34:55.029103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ["k8_config_.*"]

# Generated at 2022-06-23 12:34:57.635785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #assert(variableName == "unit_test")
    print("PASSED")
    #assert(variableName == ExpectString)

# Generated at 2022-06-23 12:35:06.641546
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    vars = dict(
        foo = "bar",
        bar = "foo",
        foo_bar = "baz",
        bar_foo = "foo_bar"
    )
    lm = LookupModule()
    lm.set_options(var_options=vars, direct=None)
    # Check the list of variable names returned by the constructor
    assert len(lm.run(["foo"])) == 2
    assert len(lm.run(["bar"])) == 2
    assert len(lm.run(["foo.+"])) == 4
    assert len(lm.run(["foo.+"])) == len(lm.run(["bar.+"]))

# Generated at 2022-06-23 12:35:16.164988
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def run_test(terms, variables, expected):

        try:
            # Test initialisation
            lm = LookupModule()
            lm.run(terms, variables=variables)

            # Run test
            res = lm.run(terms, variables=variables)
            assert res == expected

        except Exception as e:
            print('AnsibleException>', type(e), str(e))
            raise

    print('Testing method \'run\' of class \'LookupModule\' ...')

    # Positive tests:
    #
    # 1. Test matching strings in a dictionary
    terms = ['^qz_.+', '.+_zone$']

# Generated at 2022-06-23 12:35:27.123720
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert(lm.get_option('_terms') == None)
  assert(lm.get_option('direct') == None)
  assert(lm.get_option('var_options') == None)
  assert(lm.get_option('var_templar') == None)
  assert(lm.get_option('var_vars') == None)
  assert(lm.get_option('_original_file') == None)
  assert(lm.get_option('_filename') == None)
  assert(lm.get_option('_variables') == None)
  assert(lm.get_option('_task') == None)
  assert(lm.get_option('_encoding') == None)

# Generated at 2022-06-23 12:35:40.358935
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check that term cannot be list
    lookup_module = LookupModule()
    lookup_module._display.warning = Mock()
    assert lookup_module.run(terms=[], variables={}) == []
    assert lookup_module._display.warning.call_count == 1

    # Check that term cannot be int
    lookup_module = LookupModule()
    lookup_module._display.warning = Mock()
    assert lookup_module.run(terms=1, variables={}) == []
    assert lookup_module._display.warning.call_count == 1

    # Check that term cannot be dict
    lookup_module = LookupModule()
    lookup_module._display.warning = Mock()
    assert lookup_module.run(terms={}, variables={}) == []
    assert lookup_module._display.warning.call_count == 1

    # Check that term cannot

# Generated at 2022-06-23 12:35:41.786890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test boolean
    assert(LookupModule() is not None)

# Generated at 2022-06-23 12:35:43.826534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert lookupModule is not None

# Generated at 2022-06-23 12:35:55.264534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show"}) == ['qz_1', 'qz_2']
    assert LookupModule().run(['^qz_.+', '.+_zone$'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_zone': 'hello'}) == ['qz_1', 'qz_2', 'qz_zone']

# Generated at 2022-06-23 12:35:56.459404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert "LookupModule" == LookupModule.__name__

# Generated at 2022-06-23 12:36:08.146306
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test normal run
    lookup_plugin = LookupModule()
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
        }

    # Cannot mock entire load_module_utils() content.
    # Just mock out get_plugin_vars() since we aren't testing
    # the other functions and it prevents the test encountering
    # errors because it can't find certain files.
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.params['_terms'] = terms
        def get_plugin_vars(self, basedir):
            ret_dict = {}

# Generated at 2022-06-23 12:36:08.707614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:36:09.871504
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, 'set_options')

# Generated at 2022-06-23 12:36:13.434979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    var_options = {}
    terms = ['.+']
    direct = {}

    lookupMod = LookupModule()
    lookupMod.set_options(var_options=var_options, direct=direct)
    assert lookupMod.run(terms=terms) == []

# Generated at 2022-06-23 12:36:25.244180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # basic
    result = LookupModule().run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "Won't show", 'qz_': "Won't show either"})
    assert result == ['qz_1', 'qz_2']

    # with nested variables
    result2 = LookupModule().run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': dict(world=10, world2=20), 'qa_1': "Won't show", 'qz_': "Won't show either"})
    assert result2 == ['qz_1', 'qz_2']

    # with varargs

# Generated at 2022-06-23 12:36:36.413596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO

    class TestLookupModule(LookupModule):

        def run(self, terms, variables=None, **kwargs):
            self.set_options(var_options=variables, direct=kwargs)
            return list(variables.keys())

    l = TestLookupModule()
    # This is needed because of the way Ansible handles the "__main__" module for test-cases
    l.set_runner(None)

    result = l.run(['no-match'])
    assert result == ['no-match']

    variable_names = {'foo_zone': {'key': 'value'}, 'bar_location': {'key': 'value'}}

    result = l.run(['^foo_.+'], variable_names)

# Generated at 2022-06-23 12:36:46.297990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This will fail unless the import is done inside this method
    from ansible.plugins.lookup import LookupModule


# Generated at 2022-06-23 12:36:47.849308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:36:50.249846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, 'set_options')


# Generated at 2022-06-23 12:36:51.021175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:36:59.543249
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test empty input
    assert [] == LookupModule().run(terms=[])

    # Test one term that matches
    ret = LookupModule().run(
        terms=['^qz_.+'], variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
        })
    assert 'qz_1' in ret
    assert 'qz_2' in ret
    assert 'qa_1' not in ret
    assert 'qz_' not in ret

    # Test one term that matches

# Generated at 2022-06-23 12:37:01.788735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None, "the constructor for class LookupModule failed"

# Generated at 2022-06-23 12:37:02.881432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert False

# Generated at 2022-06-23 12:37:03.513873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:37:06.244768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L.run(terms=['Test'], variables={"Test":"Hello"}) == ['Test']
    assert L.run(terms=['Test'], variables={"Test":"Hello",'Second':'second'}) == ['Test']

# Generated at 2022-06-23 12:37:07.691324
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule('')
    assert test_class is not None

# Generated at 2022-06-23 12:37:14.042967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms = ['hosts'], variables = {'hosts': '1.2.3.4', 'not_hosts': '192.168.10.11'})
    l.run(terms = ['hosts'], variables = {'hosts': '1.2.3.4', 'not_hosts': '192.168.10.11'})

# Generated at 2022-06-23 12:37:19.694708
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    varnames = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    results = varnames.run(terms, variables)

    assert len(results) == 2

# Generated at 2022-06-23 12:37:29.829434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert "a" in lookup.run(["a"], {"a": 1, "b": 2})
    assert "b" in lookup.run(["a"], {"a": 1, "b": 2})
    assert "a" in lookup.run(["^a$"], {"a": 1, "b": 2})
    assert "b" in lookup.run(["^b$"], {"a": 1, "b": 2})
    assert "a" not in lookup.run(["^b$"], {"a": 1, "b": 2})
    assert "b" not in lookup.run(["^a$"], {"a": 1, "b": 2})
    assert "a" in lookup.run([".+"], {"a": 1, "b": 2})

# Generated at 2022-06-23 12:37:38.569504
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    args = {
        '_raw_params': '','_task': '','_templar': '','_loader': '','_params': '','_shared_loader_obj': '','_play_context': '','_display': '','_terms': ['.+_zone$','.+_location$']
    }
    variables = {'qz_zone':'hello','qz_location':'world','qa_1': "I won't show",'qz_': "I won't show either"}
    results = lm.run(**args, variables=variables)
    assert sorted(results) == sorted(['qz_zone','qz_location'])


# Generated at 2022-06-23 12:37:47.837392
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test that a list of variable names is returned.
    variables = {'a': '1', 'bc': '2', 'def': '3'}
    l = LookupModule()
    results = l.run(terms=["[ab]"], variables=variables)
    assert ['a'] == results

    # Test that a variable name is returned.
    variables = {'a': '1', 'b': '2'}
    l = LookupModule()
    results = l.run(terms=["a"], variables=variables)
    assert ['a'] == results

    # Test return empty list when no match.
    variables = {'a': '1', 'b': '2'}
    l = LookupModule()
    results = l.run(terms=["c"], variables=variables)
    assert [] == results

    #

# Generated at 2022-06-23 12:37:50.761455
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ['a', 'b']
    kw = {'other_kw': 'c'}
    lm.run(terms, kw)

# Generated at 2022-06-23 12:38:01.792603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.varnames as varnames
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-23 12:38:02.779769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 12:38:09.953958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(
        terms=["^qz_.+", "something"],
        variables=dict(
            qz_1="hello",
            qz_2="world",
            qa_1="I won't show",
            qz_="I won't show either",
            something="something",
        )
    )

    expected_result = ['qz_1', 'qz_2', 'something']
    l = LookupModule()
    result = l.run(**args)
    assert result == expected_result

# Generated at 2022-06-23 12:38:21.931430
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    globals_for_testing = {}
    def set_globals_for_testing(variable_name, value):
        globals_for_testing[variable_name] = str(value)

    globals_for_testing['foo'] = 'bar'
    globals_for_testing['foo_1'] = 'bar_1'
    globals_for_testing['foo_2'] = 'bar_2'
    globals_for_testing['foa_1'] = 'bar_3'

    ret = LookupModule().run(
        terms=['foo', 'foo_'],
        variables=globals_for_testing
    )
    assert len(ret) == 3
    assert 'foo_1' in ret
    assert 'foo_2' in ret
    assert 'foo' in ret

    ret = LookupModule

# Generated at 2022-06-23 12:38:30.263967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Params(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    my_lookup = LookupModule()
    args = {'_lookup_plugin': 'varnames', '_terms': ['^qz_.+'], 'key': 'value', 'qz_1': 'hello', 'qz_2': 'world', 'qb_1': "I won't show", 'qz_': "I won't show either"}
    args = Params(**args)
    my_lookup.set_options(var_options=args, direct=args)
    result = my_lookup.run(terms=['^qz_.+'], variables=args)
    expected_result = ['qz_1', 'qz_2']
    assert result == expected

# Generated at 2022-06-23 12:38:36.179402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = [
        "^data[0-9]*$",
        "^package[0-9]*$",
        "^address[0-9]*$",
        "^mode[0-9]*$",
    ]
    ret = lm.run(terms=terms)
    assert ret == []

# Generated at 2022-06-23 12:38:43.269932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["^qz_.+", "^qa_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "moon", "qz_": "I won't show either", "q": "world"}
    res = lookup_module.run(terms, variables)
    assert res == ['qz_1', 'qz_2', 'qz_', 'qa_1']

# Generated at 2022-06-23 12:38:46.744988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    xlm = LookupModule()
    xlm.run(terms=['^qz_.+'],variables={'qz_1': "hello", 'qz_2': "world", 'qa_1': "I won't show",'qz_': "I won't show either"})

# Generated at 2022-06-23 12:38:48.836489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run is not None



# Generated at 2022-06-23 12:38:57.756718
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # terms argument validation
    import pytest
    with pytest.raises(AnsibleError) as exec_info:
        LookupModule().run(terms=dict())
    assert str(exec_info.value) == "Invalid setting identifier, \"{}\" is not a string, it is a <class 'dict'>"

    # variables argument validation
    with pytest.raises(AnsibleError) as exec_info:
        LookupModule().run(terms=['some'], variables=None)
    assert str(exec_info.value) == "No variables available to search"

# Generated at 2022-06-23 12:39:07.565674
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1, valid search
    lookup = LookupModule()
    variables = dict(
        test_A= 'hello',
        test_B= 'hello world',
        test_C= 'hello world',
        test_D= 'hello',
        test_E= 'hello world',
        test_F= 'hello world',
    )

    terms = ['^test', '_A$']
    results = lookup.run(terms=terms, variables=variables)
    assert len(results) == 2
    assert results == ['test_A', 'test_F']

    # Test 2, invalid search
    terms = ['^test', '_A$']
    try:
        results = lookup.run(terms=terms)
    except AnsibleError as e:
        assert 'No variables available to search' in e.message

# Generated at 2022-06-23 12:39:11.417201
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Check exception if variables is None
    try:
        LookupModule.run(LookupModule(), 'term', variables=None)
        assert False
    except:
        assert True


# Generated at 2022-06-23 12:39:13.283360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:39:14.982779
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.varnames
    print(ansible.plugins.lookup.varnames.LookupModule())


# Generated at 2022-06-23 12:39:23.906035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock class to init LookupModule
    class Options:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class Variables:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    class StaticVars:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    lookup_instance = LookupModule()
    options = Options(**{'forks': 5, 'verbosity': 0, 'inventory': '/root/.ansible/inventory.txt'})

# Generated at 2022-06-23 12:39:34.353243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(issubclass(LookupModule, LookupBase))
    term1 = '^qz_.+'
    term2 = 'hosts'
    term3 = '.+'
    term4 = '.+_zone$'
    term5 = '.+_location$'
    var1 = 'qz_1'
    var2 = 'qz_2'
    var3 = 'qa_1'
    var4 = 'qz_'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert(LookupModule.run(term1, variables)) == [[var1, var2]]
    assert(LookupModule.run(term2, variables)) == []

# Generated at 2022-06-23 12:39:36.772363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:39:46.589970
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Make a variable variable, which should contain a dictionary of variables
    variables = {}
    variables["network"] = "public"
    variables["network_zone"] = "public_zone"
    variables["network_location"] = "public_zone"
    variables["storage"] = "public"
    variables["storage_zone"] = "public_zone"
    variables["storage_location"] = "public_zone"
    variables["compute"] = "public"
    variables["compute_zone"] = "public_zone"
    variables["compute_location"] = "public_zone"

    # Create a new object of class LookupModule
    obj = LookupModule()

    # Set the required variables
    obj.set_options(var_options=variables, direct={})

    # Make a list of terms to be searched
    terms = []
   

# Generated at 2022-06-23 12:39:56.344527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    lookup_module = LookupModule()

    result = lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']

    result = lookup_module.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']


# Generated at 2022-06-23 12:39:57.547010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-23 12:40:00.605343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:40:01.502772
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:40:06.528593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['^qz_.+']
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
    }
    assert module.run(terms, variables) == ["qz_1", "qz_2"]


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:40:13.597381
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib

    init_args = {}
    variable_args = {
        'var1': 1,
        'var2': 2
    }
    variable_args_dict = ImmutableDict.fromkeys(variable_args.keys(), variable_args.values())

    vault_pass = 'secret'
    vault_lib_object = VaultLib([])
    vault_password_dict = {'vault_password': vault_lib_object.encrypt(vault_pass)}

    lookup_mod = LookupModule(init_args, variable_args_dict, vault_password_dict)


# Generated at 2022-06-23 12:40:19.274601
# Unit test for constructor of class LookupModule
def test_LookupModule():

   print("testing LookupModule")

   terms = 'test'
   variables = None
   kwargs = {}

   try:
      LookupModule.run(terms, variables, kwargs)
   except AnsibleError as e:
      print("Raised an AnsibleError exception with message: %s" % e.message)
      assert("No variables available to search" in e.message)



# Generated at 2022-06-23 12:40:29.591522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup.varnames import LookupModule

    l = LookupModule()
    l.set_options()

    # positive test
    test_data = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ans = ['qz_1', 'qz_2', 'qa_1']
    if l.run("^qz_.+", variables=test_data) != ans:
        pytest.fail("The method run should return all the matching variables")

    # negative test
    ans = ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-23 12:40:37.308960
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:40:39.270077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests if it can be created without arguments
    module = LookupModule()
    assert(module is not None)

# Generated at 2022-06-23 12:40:48.056175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Verify that lookup can find variables.

    :return:
    """
    # Test 1: Ensure that lookup can find a simple variable.
    test1_variables = {'test_var_1': 'test1'}
    test1_terms = ['test_var_1']
    results = LookupModule().run(test1_terms, test1_variables)
    assert len(results) == 1

    # Test 2: Ensure that lookup can find a variable that is a dict.
    test2_variables = {'test_var_2': {'sub_var': 'test2'}}
    test2_terms = ['test_var_2']
    results = LookupModule().run(test2_terms, test2_variables)
    assert len(results) == 1

    # Test 3: Ensure that lookup can find

# Generated at 2022-06-23 12:40:49.167816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 12:40:54.256370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given a LookupModule instance
    lookup = LookupModule()

    # When I call run with _terms and valid variables
    result = lookup.run(terms=["abc", "abc.def"], variables={'abc': 'abc', 'abc.def': 'abc.def'})

    # Then I should get a list of variable names that match the search terms
    assert result == ['abc', 'abc.def']

