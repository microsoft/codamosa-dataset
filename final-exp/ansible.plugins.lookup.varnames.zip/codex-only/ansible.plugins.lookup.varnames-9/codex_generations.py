

# Generated at 2022-06-23 12:30:52.297092
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:31:01.089416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # This is automatically provided by Ansible
    variables = {
        'foo': {'bar': 1},
        'this': 'that',
        'hosts': ['a', 'b', 'c'],
        }

    # Test if the requested term is valid.
    # If yes, return a list of variables that meet the pattern
    # If not, raise an error
    terms = ['foo']
    assert LookupModule().run(terms, variables) == ['foo']

    terms = ['^foo']
    assert LookupModule().run(terms, variables) == []

    terms = ['^this']
    assert LookupModule().run(terms, variables) == ['this']

    terms = ['hosts']
    assert LookupModule().run(terms, variables) == ['hosts']

    terms = ['.+hosts']
    assert Look

# Generated at 2022-06-23 12:31:09.192509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ['^qz_.+']
    variables = dict(
        qz_1="hello",
        qz_2="world",
        qa_1="I won't show",
        qz_="I won't show either"
    )
    assert lookup_plugin.run(terms, variables) == ['qz_1', 'qz_2']

    terms = ['.+']
    assert lookup_plugin.run(terms, variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-23 12:31:20.232365
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # No variables provided, should raise AnsibleError
    try:
        lookup.run(terms=['test'], variables=None)
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'
    variables=dict(testname='testvalue')
    terms=['testname']
    ret0 = lookup.run(terms=terms, variables=variables)
    assert ret0 == terms
    # No variables match provided term, should return empty list
    ret1 = lookup.run(terms=['nonexistent'], variables=variables)
    assert ret1 == []
    # Variables has no type, should return [testname]
    variables=dict(testname=None)
    ret2 = lookup.run(terms=terms, variables=variables)
    assert ret2

# Generated at 2022-06-23 12:31:21.103342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:31:22.839401
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test test_LookupModule")
    LookupModule(None, None, None, None)

# Generated at 2022-06-23 12:31:26.088282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert(lk)
    lk = LookupModule(environ={})
    assert(lk)


# Generated at 2022-06-23 12:31:36.133476
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    c = LookupModule()
    c.set_options({'_ansible_variables': {'my_var1': 15, 'my_var2': '20', 'my_var3': True, 'my_var4': False, 'my_var5': {}}})
    assert c.run(['^my[a-z0-9]+$']) == ['my_var1', 'my_var2', 'my_var3', 'my_var4', 'my_var5']
    assert c.run(['^my[a-z0-9]+$', '^my_var2$']) == ['my_var1', 'my_var2', 'my_var3', 'my_var4', 'my_var5']

# Generated at 2022-06-23 12:31:37.502767
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lp = LookupModule()
    assert lp != None

# Generated at 2022-06-23 12:31:46.140783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test run() method of class LookupModule"""
    lookup_module = LookupModule()

    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world',
                                           'qz_': "I won't show either",
                                           'qa_1': "I won't show"},
                              direct={'_ansible_no_log': 'yes'})
    ret = lookup_module.run([r'^qz_.+'])
    assert(ret == ['qz_1', 'qz_2'])


# Generated at 2022-06-23 12:31:57.043835
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # construct LookupModule object
    lm = LookupModule()

    # construct some variables
    variables = dict()
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"

    # test case 1.1
    # input
    terms = ['^qz_.+']
    # expected output
    expected = ['qz_1', 'qz_2']
    # actual output
    actual = lm.run(terms=terms, variables=variables)
    # test assert
    assert(expected == actual)

    # test case 1.2
    # input
    terms = ['.+']
    # expected output

# Generated at 2022-06-23 12:31:58.572946
# Unit test for constructor of class LookupModule
def test_LookupModule():
    u = LookupModule()
    assert u is not None


# Generated at 2022-06-23 12:32:00.320710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 12:32:04.472051
# Unit test for constructor of class LookupModule
def test_LookupModule():
	assert issubclass(LookupModule, LookupBase)
	lookup_module = LookupModule()
	variables = {'test_variable': 'value'}
	kwargs = dict()
	lookup_module.run([], variables=variables, **kwargs)

test_LookupModule()

# Generated at 2022-06-23 12:32:04.992903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:32:14.537962
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var = dict(
        A = "A",
        B = "B",
        C = "C",
        D = "D",
        ABC = "abc",
        ABD = "abd",
        DBC = "dbc",
        CBC = "cbc",
        CAB = "cab"
    )

    lookup_obj = LookupModule()

    #
    # call method with empty dict as terms.
    #
    expected_result = []
    search_name    = []
    result = lookup_obj.run(search_name, var)
    assert result == expected_result

    #
    # call method with empty list as terms.
    #
    expected_result = []
    search_name    = []
    result = lookup_obj.run(search_name, var)
    assert result == expected_

# Generated at 2022-06-23 12:32:18.239683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^test.+', '.+test.+']

    variables = dict(test1=1, test2=2, test3=3)

    lm = LookupModule()
    ret = lm.run(terms, variables)

    assert(ret == ['test1', 'test2', 'test3'])

# Generated at 2022-06-23 12:32:19.082923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    print(t)

# Generated at 2022-06-23 12:32:20.475722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:32:24.123020
# Unit test for constructor of class LookupModule
def test_LookupModule():

    test_obj = LookupModule()
    # Test ModuleCase is a class

    assert isinstance(test_obj, LookupModule)

    # Test set_options is a subroutine
    assert type(test_obj.set_options) is type(test_obj.run)

# Generated at 2022-06-23 12:32:28.676460
# Unit test for constructor of class LookupModule
def test_LookupModule():
    v = {
        "a": 1,
        "b": "world"
    }
    terms = ["a", "b"]
    lm = LookupModule()
    lm.set_options(var_options=v, direct={})
    assert lm is not None
    assert lm.run(terms=terms) is not None


# Generated at 2022-06-23 12:32:29.814267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:32:38.963269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a test for for the lookup module
    # To run this test this module has to be located in the same directory as the lookup_plugins directory
    # Assumes that the ansible is installed in the user's home folder.
    # $HOME/ansible/hacking/test-module can be used to test modules
    import os
    import sys
    import json
    lookup_plugin_paths = ['./lookup_plugins']
    test_module_paths = ['$HOME/ansible/hacking/test-module']
    sys.path = test_module_paths + lookup_plugin_paths + sys.path
    test_module_path = os.path.expanduser('~/ansible/hacking/test-module')

# Generated at 2022-06-23 12:32:40.235584
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:32:42.473875
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')


# Generated at 2022-06-23 12:32:52.082234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    assert sys.version_info >= (2, 7)

    # Test that run checks that variables is a dict
    test_obj = LookupModule()
    try:
        test_obj.run(['^qz_.+'])
        sys.exit('Failed to verify that variable is required')
    except Exception as e:
        if not isinstance(e, AnsibleError):
            sys.exit('Expected AnsibleError, got %s' % type(e))

    # Test that run checks that terms is a list
    test_obj = LookupModule()

# Generated at 2022-06-23 12:32:55.361132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert c is not None


# Generated at 2022-06-23 12:33:04.854453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Example of data passed to test
    terms = ['^qz_.+', '.+_zone$', '.+_location$']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'proxy_zone': 'test_proxy_zone',
        'web_zone': 'test_web_zone',
        'proxy_location': 'test_proxy_location',
        'web_location': 'test_web_location'
    }
    #
    # Expected result
    expected = ['qz_1', 'qz_2', 'proxy_zone', 'web_zone', 'proxy_location', 'web_location']
    #
    # Create

# Generated at 2022-06-23 12:33:12.244553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    varnamesLookupModule = LookupModule()

    mock_variables = {
        "foo2": "value2",
        "foo": "value",
    }

    mock_kwargs = {"_terms": ["foo"]}
    varnamesLookupModule.run(mock_kwargs["_terms"], mock_variables, **mock_kwargs)
    assert(varnamesLookupModule.templar._available_variables == mock_variables)
    # Can't check the results of set_available_variables() because it's using
    # a type we don't have access to

# Generated at 2022-06-23 12:33:21.394125
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase) # check whether LookupModule is subclass of LookupBase
    lookup = LookupModule()
    assert lookup.run(terms=['^qz_.+'], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ["qz_1", "qz_2"]
    assert lookup.run(terms=['.+'], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ["qz_1", "qz_2", "qa_1", "qz_"]

# Generated at 2022-06-23 12:33:31.891699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module.set_runner(init=False)

    assert lookup_module.run(terms=['.']) == []

    assert lookup_module.run(terms=['qaz']) == []

    assert lookup_module.run(terms=['^qaz'], variables={'qaz': 'value'}) == ['qaz']

    assert lookup_module.run(terms=['^qaz'], variables={'qaz': 'value', 'qa': '1', 'qaa': '2'}) == []

    assert lookup_module.run(terms=['^qaz'], variables={'qaz': 'value', 'qa': '1', 'qaa': '2'}) == []


# Generated at 2022-06-23 12:33:44.077259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test getting the variable names that start with qz_
    lookup_inst = LookupModule()
    variable_names = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    variables = dict()
    terms = ['^qz_.+']
    result = lookup_inst.run(terms, variables)
    assert set(result) == set(variable_names)

    # Test getting the variable names that have 'hosts' in them
    lookup_inst = LookupModule()
    variable_names = ['hosts']
    variables = dict()
    terms = ['hosts']
    result = lookup_inst.run(terms, variables)
    assert set(result) == set(variable_names)

    # Test getting all the variable names
    lookup_inst = LookupModule()

# Generated at 2022-06-23 12:33:49.695220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run method of class LookupModule is tested by integration test
    # this method is only here to make coverage testing happy
    ret = {'var_qz_1': 'hello', 'var_qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']

    lm = LookupModule()
    assert lm.run(terms, ret) == ['var_qz_1', 'var_qz_2']


# Generated at 2022-06-23 12:33:57.014000
# Unit test for constructor of class LookupModule
def test_LookupModule():
  from ansible.module_utils.basic import AnsibleModule
  module = AnsibleModule(
      argument_spec = dict(
          _raw_params = dict(type='str', required=True),
          _terms = dict(type='list', elements='str', required=True),
      ),
      supports_check_mode=True,
  )
  lookup_module = LookupModule()
  lookup_module.run(terms=module.params['_terms'], variables={'a':1})

# Generated at 2022-06-23 12:34:05.696444
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test result when no variables are provided
    def test_no_variables():
        lookup = LookupModule()
        try:
            lookup.run([])
        except Exception as e:
            assert(isinstance(e, AnsibleError))
            msg = e.args[0]
            assert msg == 'No variables available to search'

    test_no_variables()

    # Test result when valid regular expressions for matching
    # variable names are provided
    def test_valid_regexp():
        variable = { "fw_version": "2.2.2", "os_version": "4.4.4" }
        terms = [ "^fw_", "^os_" ]
        lookup = LookupModule()
        res = lookup.run(terms, variable)

# Generated at 2022-06-23 12:34:07.206039
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:34:08.426811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run

# Generated at 2022-06-23 12:34:11.120972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
        raise Exception("No exception")
    except Exception as err:
        assert str(err) == "No variables available to search"


# Generated at 2022-06-23 12:34:23.041441
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1 - passing with correct variable name
    terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}
    lookup_mod = LookupModule()
    result, = lookup_mod.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

    # test case 2 - passing with .+
    terms = ['.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}
    lookup_mod = LookupModule()

# Generated at 2022-06-23 12:34:26.628751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.lookup_type == 'varnames'
    assert lookup.run(terms=['qz_.'], variables={'qz_1': 0}) == ['qz_1']

# Generated at 2022-06-23 12:34:38.697769
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.errors import AnsibleError

    # ansible.plugins.lookup.varnames.LookupModule.run
    #  first use
    lookupModule = LookupModule()
    lookupModule.set_options = lambda x, y: None

    vars = {
        'qz_1': "hello",
        'qz_2': "world",
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': "locals"
    }

    # extract all qz_ variables
    assert lookupModule.run(['^qz_.+'], vars) == ['qz_1', 'qz_2']
    # extract all variables

# Generated at 2022-06-23 12:34:48.931808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar.available_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}

    assert l.run(terms=['^qz_.+']) == ['qz_1', 'qz_2']
    assert l.run(terms=['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert l.run(terms=['hosts']) == []
    assert l.run(terms=['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-23 12:35:01.626983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert lu.run(['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show'}) == ['qz_1', 'qz_2']
    assert lu.run(['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show'}) == ['qz_1', 'qz_2', 'qa_1']
    assert lu.run(['hosts'], variables={'somehosts': 'hello', 'some_hosts': 'world', 'hosts': 'I wont show'}) == ['somehosts', 'some_hosts', 'hosts']

# Generated at 2022-06-23 12:35:12.080852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test when no variables
    with pytest.raises(AnsibleError) as error:
        lookup_module = LookupModule()
    assert error._excinfo[0] is AnsibleError
    assert error._excinfo[1].args[0] == 'No variables available to search'

    # Test when term is a str
    lookup_module = LookupModule()
    terms = 'test_term'
    variables = {'test_term': {'test': 'pass'}}
    ansible_vars = {}
    ansible_vars['_terms'] = terms
    ansible_vars['variables'] = variables
    lookup_module.run(terms, variables)

    # Test when term is a list
    lookup_module = LookupModule()
    terms = ['test_term']

# Generated at 2022-06-23 12:35:18.862699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self, input_data, loader, templar, shared_loader_obj=None):
            super(TestLookupModule, self).__init__(loader, templar, shared_loader_obj=None)
            self.test_data = input_data

        def run(self, terms, variables=None, **kwargs):
            return self.test_data

    class TestVars(dict):
        def __init__(self, test_data):
            super(TestVars, self).__init__(test_data)
            for k, v in test_data.items():
                self[k] = v

        def get(self, key, default=None):
            return self[key]



# Generated at 2022-06-23 12:35:28.252985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # all variable names contain variable "v_"
    variables = {
        'v_0': 1,
        'v_1': 2,
        'v_2': 3,
        'v_3': 4,
    }

    # initialization of test object
    testobj = LookupModule()

    ### test 1: check if all variables are returned with expression "^v_.+"
    checkList = [
        'v_0',
        'v_1',
        'v_2',
        'v_3',
    ]
    testobj.set_options(var_options=variables, direct={})
    ret = testobj.run(['^v_.+'], variables=variables)
    assert set(ret) == set(checkList)
    ### test 1 end

    ### test 2: check if 2 variables are returned

# Generated at 2022-06-23 12:35:36.859677
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        terms = ['^qz_.+', 'world']
        variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show"}
        all = LookupModule()
        r = all.run(terms, variables)
        assert r == ['qz_1', 'qz_2']
    except AssertionError:
        print('Test failed')
    else:
        print('Test passed')

# Generated at 2022-06-23 12:35:39.065315
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    assert LookupModule is not None


# Generated at 2022-06-23 12:35:40.447611
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' in globals()


# Generated at 2022-06-23 12:35:42.322855
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 12:35:54.378370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types

    LookupModule = LookupModule('varnames', None, None, None, None, None)

    try:
        assert isinstance(LookupModule.run('terms', variables='varnames', **kwargs), list)

    except AnsibleError as e:
        raise AssertionError(str(e))

    try:
        assert isinstance(LookupModule.run('terms', variables="", **kwargs), list)

    except AnsibleError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-23 12:36:02.966480
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLookupModule(object):
        def __init__(self):
            self.variable = {}
            self.var_options = {}
            self.direct = {}

        def set_options(self, var_options, direct):
            self.var_options = var_options
            self.direct = direct

    lookup_module = LookupModule()
    lookup_module.set_loader('TestLookupModule')
    assert test_LookupModule_run.__name__ == lookup_module.run([], {'hello': 'world'}, fail_on_undefined=True)[0]



# Generated at 2022-06-23 12:36:04.032856
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:36:05.742256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None
    

# Generated at 2022-06-23 12:36:13.436808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert ['ansible_test_variable'] == lookup.run(
        ['ansible_test_variable'], {'ansible_test_variable': 'yolo'})
    assert [] == lookup.run(['none_variable'], {'ansible_test_variable': 'yolo'})

    res = lookup.run(['^an.*e$'], {'ansible_test_variable': 'yolo'})
    assert res == ['ansible_test_variable']

    assert ['ansible_test_variable', 'ansible_dummy_variable'] == lookup.run(
        ['^ansible_'], {'ansible_test_variable': 'yolo', 'ansible_dummy_variable': 'yolo'})

# Generated at 2022-06-23 12:36:16.979303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert isinstance(lookup, LookupModule)
    assert isinstance(lookup, LookupBase)
    assert isinstance(lookup, object)



# Generated at 2022-06-23 12:36:27.178560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def assert_lookup(name, expected_ret):
        ret = LookupModule().run(name, {
            'ansible_facts': {
                'qz_1': 'hello',
                'qz_2': 'world',
                'qa_1': "I won't show",
                'qz_': "I won't show either",
            },
        }, [])
        assert ret == expected_ret

    # Actual tests
    assert_lookup(['^qz_.+'], ['qz_1', 'qz_2'])
    assert_lookup(['.+'], ['qz_1', 'qz_2', 'qa_1', 'qz_'])
    assert_lookup(['hosts'], [])

# Generated at 2022-06-23 12:36:29.752663
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_name = "varnames"
    module_class = LookupModule
    assert module_class
    assert module_class.run

# Generated at 2022-06-23 12:36:38.550370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check method run returns true if nothing goes wrong
    """
    lookup_module = LookupModule()
    terms = ['.+_zone$', '.+_location$']
    variables = dict(
        dc1_zone='dc1',
        dc1_location='dc1',
        dc2_zone='dc2',
        dc2_location='dc2'
    )
    lookup_module.run(terms,variables)
    # Lookup must return a list
    assert isinstance(lookup_module._result, list)
    # Lookup must return the right number of elements
    assert len(lookup_module._result) == 4
    # Lookup must return only varname, without the value

# Generated at 2022-06-23 12:36:40.840298
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class_instance = LookupModule()
    assert class_instance is not None
    assert isinstance(class_instance, LookupModule)

# Generated at 2022-06-23 12:36:44.748561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Example from LookupModule.run
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('varnames')
    ret = lookup.run(['test'], {'test': 'test'})
    assert ret[0] == 'test'

# Generated at 2022-06-23 12:36:45.689373
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:36:46.592161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tmp = LookupModule()

# Generated at 2022-06-23 12:36:50.754514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["^foo_.+"]
    variables = {"foo_1": "hello", "foo_2": "world", "bar_1": "again"}
    lu = LookupModule()
    result = lu.run(terms, variables)
    assert result == ["foo_1", "foo_2"]

# Generated at 2022-06-23 12:36:52.207026
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' == LookupModule.__name__

# Generated at 2022-06-23 12:37:03.968897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import inspect
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0,parentdir)

    from lib.lookup_plugin import LookupModule

    lookup = LookupModule()

    # assert that these don't throw errors
    lookup.run(['^x1'], {'x1': 1, 'x1a': 2, 'x2': 3, 'x3': 4})
    lookup

# Generated at 2022-06-23 12:37:14.977144
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_ret = ['/usr/bin/ansible', '/foo/bar', '/usr/bin/python']

    class TestClass():
        class Options(object):
            def __init__(self):
                self._get_vars_options = {}
                self.variable_manager = TestVariableManager()

        def get_option(self, k):
            return self.Options()

    # base_class inst
    lookup_instance = LookupModule()
    lookup_instance.set_options(var_options={'test_var': 'test_value'}, direct=[])

    # Test class for variable manager
    class TestVariableManager():

        def get_vars(self, loader, play, host):
            return lookup_instance.get_options().variable_manager.get_vars(loader, play, host)


# Generated at 2022-06-23 12:37:22.262227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testlookup = LookupModule()

    # Test with invalid terms
    terms = [1, "^qz_.+", b"qz_2"]
    with pytest.raises(AnsibleError):
        testlookup.run(terms, _ds={"qz_1": "hello", "qz_2": "world"})

    # Test with invalid regex
    terms = ["[", "^qz_.+", b"qz_2"]
    with pytest.raises(AnsibleError):
        testlookup.run(terms, _ds={"qz_1": "hello", "qz_2": "world"})

    # Test with valid search parameters

# Generated at 2022-06-23 12:37:23.362639
# Unit test for constructor of class LookupModule
def test_LookupModule():

    a = LookupModule()

# Generated at 2022-06-23 12:37:23.974016
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:37:33.747007
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a lookup and set lookup options
    lookup = LookupModule()
    options = {}
    options['_terms'] = []
    options['_terms'].append('^qz_.+')
    options['_terms'].append('^qz_.+')

    # Create a dictionary of variables and set Lookup options
    variables = {}
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"
    lookup.set_options(var_options=variables, direct=options)
    variables = options['_terms']

    # Test the run method with different arguments

# Generated at 2022-06-23 12:37:40.968428
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # We need to mock variables and to_native method because they are not
    # accessible from here.
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
    }
    # Python 2
    to_native.return_value = "Unable to use \"%s\" as a search parameter: %s" % ("hosts", "Exception.")

    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct={})

    # Success case
    assert lookup_module.run(["^qz_.+"], variables=variables) == ["qz_1", "qz_2"]

# Generated at 2022-06-23 12:37:48.644118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testobject = LookupModule()
    terms = ['^qz_.+']
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert testobject.run(terms, variables=vars, **{}) == ['qz_1', 'qz_2']
    terms = ['.+_zone$']
    vars = {'zone_1': 'hello', 'zone_2': 'world', 'zone_3': 'world'}
    assert testobject.run(terms, variables=vars, **{}) == ['zone_1', 'zone_2', 'zone_3']

# Generated at 2022-06-23 12:37:54.758870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    hostvars = {'qz_1':'hello', 'qz_2':'world', 'qa_1':'I won\'t show', 'qz_':'I won\'t show either'}
    result = lm.run(['^qz_.+'], hostvars)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-23 12:38:05.425034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test the run method of LookupModule
    """

    tester = LookupModule()

    # test with no variable
    try:
        tester.run(["^qz_.+"], None)
        assert False
    except AnsibleError:
        assert True

    # test a simple search
    assert tester.run(["^qz_.+"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I wont show", "qz_": "I won't show either"}) == ['qz_1', 'qz_2']

    # test a regular expression search

# Generated at 2022-06-23 12:38:15.986014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy variable to check
    class OptSimple:
        def __init__(self, var_options, direct):
            self.__dict__.update(var_options)
            self.__dict__.update(direct)
            self.basedir = "/path/to/options.basedir"

    # Test 1: Find var with exact name and no regex
    fake_variables = {"IaM_1_vaR": "Yes you are", "IaM_2_vaR": "Yes you are part 2"}
    fake_term = "IaM_1_vaR"
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=fake_variables, direct=OptSimple(basedir=""))

# Generated at 2022-06-23 12:38:21.370484
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys

    if sys.version_info[0] == 2:
        assert str(type(LookupModule().run("^qz_.+"))) == "<type 'list'>"
    else:
        assert str(type(LookupModule().run("^qz_.+"))) == "<class 'list'>"
# End of test

# Generated at 2022-06-23 12:38:28.306481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock objects
    terms = ['qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    # Expected result
    exp = ['qz_1', 'qz_2']

    # Instantiate class
    lm = LookupModule()
    # Call function
    res = lm.run(terms, variables=variables)

    # Assertion
    assert(res == exp)

# Generated at 2022-06-23 12:38:40.870551
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Variables available from dict _options
    variables_available = {
        'my_var1': 'hello',
        'my_var2': 'world',
        'my_var3': 'I want to show',
        'my_var4': 'I want to show either',
        'my_var5': 'I don\'t want to show',
        'my_var6': 'I don\'t want to show',
    }

    # My class with test method run
    class MyClassTest:

        def __init__(self, test_variables):
            self.test_variables = test_variables

        def set_options(self, **kwargs):
            pass


# Generated at 2022-06-23 12:38:41.545264
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:38:42.440347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 12:38:47.318467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_module = LookupModule()

    lookup_module.set_loader(loader)

    search_terms = ('^a_string_value$', '^a_number_value$')
    lookup_module.run(search_terms, variables={'a_string_value': 'Hello', 'a_number_value': '1'})

# Generated at 2022-06-23 12:38:59.177919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert LookupModule().run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-23 12:39:01.052855
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing constructor of class LookupModule")
    LookupModule(None, None)

# Generated at 2022-06-23 12:39:07.493068
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["foo.+", "bar.+"]

    test_LookupModule = LookupModule()

    variables = {
        "foo_test": 1,
        "bar_test_2": 2,
        "foo_test_3": 3,
        "not_foo": 4,
    }

    ret = test_LookupModule.run(terms, variables)

    assert variables["foo_test"] in ret
    assert variables["bar_test_2"] in ret
    assert variables["foo_test_3"] in ret
    assert variables["not_foo"] not in ret

# Generated at 2022-06-23 12:39:10.719729
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l=LookupModule()
    
    try:
        l.run()
    except AnsibleError as e:
        print(type(e))

# Generated at 2022-06-23 12:39:17.962954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_input = '''
        - name: Test
          hosts: all
          gather_facts: True
          tasks:
            - name: Test
              debug:
                msg: "{{ item }}"
              loop: "{{ ansible_facts | variable_names }}"
    '''
    test_path = "/tmp/test_LookupModule"
    with open(test_path,"w") as f:
        f.write(test_input)
    test = LookupModule()
    assert test

# Generated at 2022-06-23 12:39:23.187598
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)
    print(lookup.run(['^qz_.+']))
    print(lookup.run(['hosts'], {'ansible_hosts': 'test.test.test'}))
    # run the test with .+ as term
    print(lookup.run(['.+']))
    # run the test with 'hosts' as term
    print(lookup.run(['hosts']))

# Generated at 2022-06-23 12:39:30.811518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_plugin = LookupModule()
    lookup_plugin.set_options()

    # Test
    result = lookup_plugin.run(['^qz_.+'],
                               {'qz_1': 'hello',
                                'qz_2': 'world',
                                'qa_1': "I won't show",
                                'qz_': "I won't show either"})
    # Verify
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:39:31.604932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:39:32.517794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:39:42.926760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    # create the class instance
    set_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_instance = LookupModule()
    # initialize the class instance
    lookup_instance.set_options(var_options=set_variables, direct={'verbosity': 0})
    # run the method
    ret = lookup_instance.run(
        # the following list contains the args passed in run()
        [
        '^qz_.+',
        '.+_zone$',
        '.+_location$'
        ])
    # check whether the returned value is expected
    assert len(ret) == 2

# Generated at 2022-06-23 12:39:48.955499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["^qz_.+"]
    variables = {"qz_1" : "hello", "qz_2": "world", "qa_1" : "I won't show", "qz_" : "I won't show either"}
    ret = lookup_module.run(terms, variables=variables)
    assert(set(ret) == set(["qz_1", "qz_2"]))


# Generated at 2022-06-23 12:39:52.292138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'c':'d'})
    result = l.run(["c"])
    assert result == ['c']
    result = l.run(["b"])
    assert result == []


# Generated at 2022-06-23 12:39:52.879524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:39:53.838687
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:39:55.088119
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_class = LookupModule()
    assert lookup_module_class

# Generated at 2022-06-23 12:39:58.070105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # The constructor takes no arguments, so it should just return None
    assert LookupModule() == None

# Generated at 2022-06-23 12:40:04.903705
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule

    test_lookup_mod = LookupModule()

    # Test setup_options()
    test_lookup_mod.set_options(terms=[], var_options={'name': 'myname'}, direct={'mykey': 'myvalue'})

    # Test lookup()
    assert isinstance(test_lookup_mod.lookup(['.+'], {'name': 'myname', 'mykey': 'myvalue'}, mykey='myvalue'), list)

# Generated at 2022-06-23 12:40:12.548144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test error when no variables provided
    lookup_instance = LookupModule()

    try:
        lookup_instance.run(terms="", variables=None)
        raise AssertionError("Should have failed trying to lookup without any variables supplied")
    except AnsibleError as err:
        assert "No variables available to search" in err.message

    # Test regex matches
    lookup_instance = LookupModule()
    # Test that the regex match on any variables with the string "host" in it
    assert lookup_instance.run(terms="host", variables={"hosts":{}}) == ["hosts"]
    # Test that the regex match on any variables with the string "zone" on it's end

# Generated at 2022-06-23 12:40:24.201323
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:40:25.201925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)


# Generated at 2022-06-23 12:40:33.120841
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Task for testing

    variable_names = ['qz_1', 'qz_2', 'qa_1', 'qz_', 'ansible_play_batch', 'ansible_play_batch', 'ansible_path']

    variable_values = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'ansible_play_batch': 'myhostname'
    }

    results = [ 'qz_1', 'qz_2', 'ansible_play_batch' ]

    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variable_values, direct={})

    # Test for a single term

# Generated at 2022-06-23 12:40:37.256463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except (TypeError, NameError) as e:
        assert False, "Unexpected error when calling constructor of LookupModule: %s" % e
    assert True

# Generated at 2022-06-23 12:40:38.211803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 12:40:39.222177
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 12:40:40.289753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret.run(terms=[], variables={})

# Generated at 2022-06-23 12:40:44.437138
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert isinstance(a._templar, LookupBase)
    assert isinstance(a._loader, LookupBase)
    assert a._options is None
    assert a._templar.environment is None
    assert a._loader.path_exists is None
    assert a._terms is None

# Generated at 2022-06-23 12:40:54.673972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_host('localhost', group='test_group')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='test_group',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("varnames", "/etc/hosts") }}')))
        ]
    )