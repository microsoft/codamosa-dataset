

# Generated at 2022-06-23 12:30:59.874905
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Case 1
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    expected = ['qz_1', 'qz_2']

    lookup = LookupModule()
    result = lookup.run(terms, variables)

    assert result == expected

# Generated at 2022-06-23 12:31:01.389229
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run([]) == []

# Generated at 2022-06-23 12:31:02.345927
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    return obj

# Generated at 2022-06-23 12:31:14.177045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid and invalid terms
    terms = ['^qz_.+', 'hosts', '.+_zone$', '.+_location$']
    variables = {
        'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show",
        'qz_': "I won't show either", 'hosts': 'testing',
        'space': 'testing', 'invalid_zone': 'testing',
        'invalid_location': 'testing',
    }
    l = LookupModule()
    l.set_options(var_options=variables, direct={})
    # Test with a valid term
    l.run([terms[0]])
    # Test with a invalid term
    result = l.run(['^qz_.'])

# Generated at 2022-06-23 12:31:23.562216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Using a class variable 'fixture' instead of a global variable
    # allows class to inherit from LookupBase
    class MockLookupModule(LookupModule):
        fixture = {
            "foo": "bar",
            "foobar": "foobar",
            "fafoo": "bar"
        }

    lookupModule = MockLookupModule()
    # Using mock_method instead of run directly to allow future
    # changes in API without breaking test
    ret = lookupModule._mock_method("^foo.*")
    assert ret == ["foo", "foobar", "fafoo"]

    ret = lookupModule._mock_method("^bar.*")
    assert ret == ["foobar"]

    ret = lookupModule._mock_method("^foobar.*")
    assert ret == ["foobar"]

    ret = lookupModule._m

# Generated at 2022-06-23 12:31:34.746280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Constructor of class LookupBase requires parameter loader
    # (class defined in ansible.parsing.plugin_loader)
    # To mock the object, we create a subclass of it and override the load_module method
    class LoaderSubclass(object):
        def __init__(self, *args, **kwargs):
            pass

        def load_module(self, *args, **kwargs):
            return None

    # Constructor of class LookupBase requires parameter templar
    # (class defined in ansible.template)
    # To mock the object, we create a subclass of it and override the template method
    class TemplarSubclass(object):
        def __init__(self, *args, **kwargs):
            self.available_variables = {}


# Generated at 2022-06-23 12:31:36.209341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule.run("", {}) is None)

# Generated at 2022-06-23 12:31:47.477599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking variables to use directly
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }

    test_lookup_module = LookupModule()

    # Test 1 : searching for a list of 2 variables that match the expression
    test_lookup_module.set_options(var_options=variables, direct=None)
    test_name = re.compile('^qz_.+')
    assert test_lookup_module.run([test_name], variables) == ['qz_1', 'qz_2']

    # Test 2 : searching for a list of all variables using the expression that matches all strings
    test_lookup_module.set_options

# Generated at 2022-06-23 12:31:48.799364
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm != None

# Generated at 2022-06-23 12:31:59.828834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test.set_options({'_ansible_lookup_plugin': ['varnames']})
    ret = test.run(
        ['^qz_.+'],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
        }
    )
    assert ret == ['qz_1', 'qz_2']

    ret = test.run(
        ['.+'],
        variables={
            'qa_1': "I won't show",
            'qz_': "I won't show either",
        }
    )
    assert ret == ['qa_1', 'qz_']

    ret = test.run

# Generated at 2022-06-23 12:32:08.798288
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test AnsibleError with no variables
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(terms=['a'], variables=None)
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test AnsibleError with invalid term type
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(terms=[1], variables={'a': 1, 'b': 2})
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(e)

    # Test AnsibleError for invalid regular expression
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:32:09.620811
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:32:13.495845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #arrange
    class FakeLookupBase():
        def set_options(self):
            return
    lookupBase = FakeLookupBase()
    lookupBase.set_options()
    lookupModule = LookupModule()
    lookupModule.set_options = lookupBase.set_options
    #act
    lookupModule.run(terms="^qz_.+")

# Generated at 2022-06-23 12:32:14.044212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:32:14.978027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()

# Generated at 2022-06-23 12:32:24.456441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Test LookupModule.run method'''

    var_list = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qb_a': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'qz_3': 'an empty string',
        'qz_4': None,
    }


# Generated at 2022-06-23 12:32:24.997127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:32:33.324281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    variables = {'varnames_first': 123, 'varnames_second': 456, 'varnames_third': 789}
    list_varnames = lm.run(['^varnames_.+'], variables=variables)
    assert 'varnames_first' in list_varnames
    assert 'varnames_second' in list_varnames
    assert 'varnames_third' in list_varnames
    list_varnames = lm.run(['^varnames_.+'], variables=variables)
    assert 'varnames_first' in list_varnames
    assert 'varnames_second' in list_varnames
    assert 'varnames_third' in list_varnames

# Generated at 2022-06-23 12:32:35.673530
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup_plugin = LookupModule()
   assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:32:40.726020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Assign object of class LookupBase to private attribute
    module.set_loader()
    # Create a private method object
    run_method =  module.run

    # create a list to check the output against
    result = ['qz_1', 'qz_2', 'qz_']
    # test the output of the method against the list
    assert run_method(['^qz_.+']) == result

# Generated at 2022-06-23 12:32:47.628303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class mock_LookupBase:
        def __init__(self):
            self.options = {}

        def set_options(self, **kwargs):
            self.options = kwargs

    lookup = mock_LookupBase()
    test_var = {
        'foo': 'bar',
        'baz': 'baz'
    }

    # In this test, the variable ret contain all the vars that begin with foo
    test_result = {
        'foo': 'bar'
    }

    ret = LookupModule.run(lookup, ['foo'], test_var)
    assert ret == test_result.keys()
    assert lookup.options['var_options'] is test_var

# Generated at 2022-06-23 12:32:55.410141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Ansible 2.8.5 added the ability to lookup variables to a list of variable names.
        It is a very useful feature, allowing you to create a list of variables to be
        used in a loop or to do an operation on all of them.

        This test method can be used to unit test that method in isolation.
    """

    variables = {
        'cat': 'hat',
        'abcdefgh': 'ijkl',
        'abc': 'def',
        'abc-def': 'ghi',
    }

    # This test case does not use the standard 'self.assert*' methods because none of them
    # is flexible enough to compare the lists in the way that I need to. I could write
    # my own assert method and call it from here with the 'self' argument, but the
    # normal way of running these tests does not pass in

# Generated at 2022-06-23 12:33:04.943532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['qz_']
    variables = {
        'qz_1': {
            'hosts': 'hosts.yaml',
            'vars': 'overrides.yaml',
            'vars_files': 'vars_files.yaml',
            'children': 'children.yaml',
            'vars_prompt': 'vars_prompt.yaml'
        },
        'qz_2': 'some value'
    }

    terms_fail = ['qz_']
    variables_fail = {'qz_1': 'some value'}

    l = LookupModule()
    l.set_options({})
    result = l.run(terms, variables)
    result_fail = l.run(terms_fail, variables_fail)


# Generated at 2022-06-23 12:33:06.155041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(['hosts'])

# Generated at 2022-06-23 12:33:07.065548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule
    pass

# Generated at 2022-06-23 12:33:08.564001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:33:10.656717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) > 0


# Generated at 2022-06-23 12:33:12.286318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule(runner=None).run(terms=['test'], variables={'test': 'test'})

# Generated at 2022-06-23 12:33:18.623559
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a module for test
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', required=True),
        ),
        supports_check_mode=True,
    )

    # create an instance of LookupModule
    lookup_instance = LookupModule()

    # call the run method of LookupModule with arguments and get result
    result = lookup_instance.run(terms=module.params['_terms'], variables={'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"})

    # assert the result
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:33:23.317575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_name = LookupModule()
    terms = ['.+_zone$', '.+_location$']
    variables = {'q1_zone': 'value1', 'q2_zone': 'value2', 'q1_location': 'value3', 'q2_location': 'value4'}
    assert module_name.run(terms, variables) == ['q2_location', 'q1_location', 'q2_zone', 'q1_zone']

# Generated at 2022-06-23 12:33:29.528683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # TODO: Parameterize with ansible.vars.hostvars.HostVars
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}

    # Test extraction of all variables starting with qz_
    assert module.run(['^qz_.+'], variables) == ['qz_1', 'qz_2']

    # Test extraction of variables using regular expression.
    assert module.run(['.+'], variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    # Test extraction of variables using substring.
    assert module.run(['zone'], variables) == []

    # Test

# Generated at 2022-06-23 12:33:33.617889
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Basic Tests for constructor of LookupModule class"""
    from ansible.plugins.lookup.varnames import LookupModule
    lookup_plugin = LookupModule()
    assert len(lookup_plugin.__doc__) > 10

# Generated at 2022-06-23 12:33:35.425766
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:33:39.725787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return_value = {'hosts': 'localhost,127.0.0.1'}
    expected_value = ['hosts']
    assert LookupModule().run(terms=['hosts'], variables=return_value) == expected_value

# Generated at 2022-06-23 12:33:45.059812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    AnsibleError should be raised when variables is None
    """
    import pytest

    lookup_module = LookupModule()
    # Variables is neccessary parameter so it cannot be None
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=["test_term"], variables=None)


# Generated at 2022-06-23 12:33:51.559125
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test data
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    test_obj = LookupModule()
    results = test_obj.run(terms=terms, variables=variables, direct={})

    assert results == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:33:57.195486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'a': 'foo', 'b': 'bar', 'c': 'baz', 'qux': 'quux'}
    terms = ['\\w\\w\\w']
    assert lookup.run(terms, variables) == ['foo', 'bar', 'baz']


# Generated at 2022-06-23 12:33:57.814000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:34:06.271284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule"""

    # ------------------------------
    # Test with a valid input
    # ------------------------------
    lookup_module = LookupModule()

    terms = ["^qz_.+"]
    variables = { "qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_" : "I won't show either" }
    actual_result = lookup_module.run(terms, variables)
    actual_result.sort()

    expected_result = ["qz_1", "qz_2"]
    expected_result.sort()

    error_msg = "Expected result: %s, Actual result: %s" % (expected_result, actual_result)
    assert actual_result == expected_result, error_msg

    # ------------------------------

# Generated at 2022-06-23 12:34:06.993897
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:34:08.674747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Exercise logic in LookupModule constructor
    lm = LookupModule()
    assert(lm)

# Generated at 2022-06-23 12:34:15.978614
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:34:20.803288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import lookup_loader, lookup_loader_templates
    from ansible.module_utils._text import to_native
    import sys

    class LookupModule(LookupBase):

        class Result:
            pass

        def run(self, terms, variables=None, **kwargs):
            '''
            [
                { u'a' : { u'a1' : 'v1' } },
                { u'b' : { u'b1' : 'v2' } }
            ]
            '''
            self.set_options(var_options=variables, direct=kwargs)
            r = LookupModule.Result()
            if terms[0] == 'a':
                set

# Generated at 2022-06-23 12:34:24.181993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    vars = {'test1': 'bla' }
    return_value = LookupModule().run(['test.+'], variables=vars)
    assert len(return_value) == 1

# Generated at 2022-06-23 12:34:37.277570
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule
    lookup = lookup_class()

    assert_error = AnsibleError('No variables available to search')
    try:
        lookup.run(['.'])
    except Exception as e:
        assert_error = str(e)

    assert assert_error == str(AnsibleError('No variables available to search'))

    assert_error = AnsibleError('Invalid setting identifier, ".+" is not a string, it is a <class \'list\'>')
    try:
        lookup.run(['.'], [])
    except Exception as e:
        assert_error = str(e)

    assert assert_error == str(AnsibleError('Invalid setting identifier, ".+" is not a string, it is a <class \'list\'>'))


# Generated at 2022-06-23 12:34:38.138441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule()) == 0

# Generated at 2022-06-23 12:34:39.064456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-23 12:34:50.374409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummyAPI = {}
    dummyAPI['options'] = {}
    dummyAPI['options']['tmp_path'] = ''
    dummyAPI['options']['connection'] = 'local'
    dummyAPI['remote_addr'] = 'test'
    dummyAPI['module_name'] = 'command'
    dummyAPI['module_args'] = {'_ansible_tmpdir': '', '_ansible_check_mode': False, '_ansible_debug': False, '_ansible_no_log': False, '_ansible_verbosity': 0}
    dummyAPI['module_vars'] = {'ansible_connection': 'local', 'ansible_check_mode': False, 'ansible_debug': False, 'ansible_no_log': False, 'ansible_verbosity': 0}

# Generated at 2022-06-23 12:35:02.789987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import ImmutableDict

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, connect_on_load=False, mutually_exclusive=None, no_log=False, required_together=None, required_one_of=None, add_file_common_args=False, supports_check_mode=False):
            self.params = {}
            self.argument_spec = {}
            self.check_mode = False
            self.fail_json = lambda x: sys.exit(1)
            self.exit_json = lambda x, y: sys.exit(0)

        def params(name):
            return ansible_

# Generated at 2022-06-23 12:35:05.162792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__init__.__code__.co_varnames) <= len(
        LookupModule.__init__.__code__.co_varnames) == 1



# Generated at 2022-06-23 12:35:06.089727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:35:15.739878
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import iteritems

    assert(len(LookupModule().run("^qz_.+", variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})) == 2)
    assert(len(LookupModule().run("^qz_.+", variables=dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either"))) == 2)

# Generated at 2022-06-23 12:35:16.506243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert(x)

# Generated at 2022-06-23 12:35:18.372839
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test

# Generated at 2022-06-23 12:35:25.512208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule

    # arrange
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 1, 'qz_2': 2, 'qa_1': 3}
    expected = ['qz_1', 'qz_2']

    # act
    result = lookup.run(terms, variables)

    # assert
    assert isinstance(result, list)
    assert result == expected

# Generated at 2022-06-23 12:35:30.339249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test empty term
    assert lookup.run() == ['_terms']

    # test no matches
    assert lookup.run('^$') == []

    # test one single match
    assert lookup.run('^test$') == ['_terms']
    assert lookup.run('^test$') == ['_terms']

    # test two matches
    assert lookup.run('^test$', '^foo$') == ['_terms']

    # test multiple matches
    assert lookup.run('^test.*$', '^foo$') == ['_terms']

    # test ambiguous pattern
    assert lookup.run('^.*$') == ['_terms']
    assert lookup.run('.*') == ['_terms']

# Generated at 2022-06-23 12:35:41.985645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    vars = dict(a=3, b=5, c="Hello")
    lm = LookupModule(basedir=".", runner=None, variables=vars)
    assert list(lm.get_options().keys()) == ["ansible_basedir", "ansible_playbook_python", "ansible_verbosity", "no_log", "no_target_syslog"]
    assert lm.get_option("ansible_basedir") == "."
    assert lm.get_option("ansible_playbook_python") == False
    assert lm.get_option("ansible_verbosity") == 0
    assert lm.get_option("no_log") == False
    assert lm.get_option("no_target_syslog") == False
    assert not lm.get_option("undefined")



# Generated at 2022-06-23 12:35:47.594223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['qz_1'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1']

# Generated at 2022-06-23 12:35:53.345574
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_val = LookupModule()
    terms = [
               '.+_zone$',
               '.+_location$'
    ]
    variables = {'hosts_zone': 'z1',
                 'hosts_location': 'l1',
                 'hosts_zone2': 'z2',
                 'hosts_location2': 'l2',
    }
    lookup_val.run(terms, variables)

# Generated at 2022-06-23 12:35:54.622360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Tests class LookupModule constructor
    """
    assert LookupModule is not None

# Generated at 2022-06-23 12:35:55.168264
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:35:57.630756
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == "LookupModule"
    assert LookupModule.__doc__.startswith("Lookup matching variable names")

# Generated at 2022-06-23 12:36:08.704296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    test_variables = {'nw1.key1': 'nw1.value1', 'nw1.key2': 'nw1.value2', 'nw2.key1': 'nw2.value1',
                      'nw2.key2': 'nw2.value2', 'nw2.key3': 'nw2.value3', 'nw3.key1': 'nw3.value1'}

    assert module.run(terms=['^nw3'], variables=test_variables, **{}) == ['nw3.key1']
    assert module.run(terms=['^nw2'], variables=test_variables, **{}) == ['nw2.key1', 'nw2.key2', 'nw2.key3']

# Generated at 2022-06-23 12:36:19.786759
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule(loader=None, basedir=None, run_once=None, enable_loop=None)

    assert lookup.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-23 12:36:20.892719
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()



# Generated at 2022-06-23 12:36:31.521149
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import wrap_var

    # simple test
    lookup = LookupModule()
    lookup.set_options()
    terms = ["^qz_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    result = lookup.run(terms, variables)
    assert result == [u'qz_1', u'qz_2']

    # show all variables
    lookup = LookupModule()
    lookup.set_options()
    terms = [".+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}

# Generated at 2022-06-23 12:36:39.570300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test of method run of class LookupModule
    """
    terms = ['^qz_.+','^qa_.+','^az_.+','^zr_.+','^az_.+','^az_.+']
    variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    check = ['qz_1', 'qz_2']
    lk_module = LookupModule()
    result = lk_module.run(terms, variables)
    assert result == check, "Result is not as expected!"

# Generated at 2022-06-23 12:36:41.391234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-23 12:36:42.175378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    

# Generated at 2022-06-23 12:36:52.303571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    with pytest.raises(AnsibleError):
        # No variables available to search
        obj.run(terms=[], variables=None)
    # No failure with real Ansible variables available
    obj.run(terms=[], variables={'PATH': '/bin:/usr/bin'})
    # Invalid setting identifier, "a" is not a string, it is a <class 'int'>
    with pytest.raises(AnsibleError):
        obj.run(terms=[1], variables={'PATH': '/bin:/usr/bin'})
    # Unable to use ".+" as a search parameter: nothing to repeat at position 0
    with pytest.raises(AnsibleError):
        obj.run(terms=['.'], variables={'PATH': '/bin:/usr/bin'})
    # Object is of

# Generated at 2022-06-23 12:37:02.101386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables
    test_vars = {
        'ansible_connection': 'local',
        'ansible_inventory': 'localhost,'
    }
    terms = ['^ansible_.+'] # 'ansible_connection', 'ansible_inventory'
    # Run
    lm = LookupModule()
    res = lm.run(terms, test_vars)
    # Test
    assert 'ansible_connection' in res
    assert 'ansible_inventory' in res
    assert len(res) == 2

# Main execution
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:37:03.121673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-23 12:37:12.995636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'key1': 'var1', 'key2': 'var2', 'keyone': 'varone'}
    terms = ['^key.', '^var.']

    retArgs = []
    for term in terms:
        try:
            name = re.compile(term)
        except Exception as e:
            raise AnsibleError('Unable to use "%s" as a search parameter: %s' % (term, to_native(e)))

        for varname in variables:
            if name.search(varname):
                retArgs.append(varname)

    lookup_module = LookupModule()
    assert retArgs == lookup_module.run(terms, variables)


# Generated at 2022-06-23 12:37:13.951937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:37:21.641754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_vars = {'var_name_abc': 'abc value', 'var_name_de': 'de value', 'var_name_1': 'first value'}

    # Create instance of class LookupModule
    my_obj = LookupModule(my_vars)

    # Check if the instance is created
    assert isinstance(my_obj, LookupModule)
    assert hasattr(my_obj, "run")

    assert my_obj.run(terms=['^var_name_.+']) == ['var_name_abc', 'var_name_de', 'var_name_1']
    assert my_obj.run(terms=['^var(_name)_.*']) == ['var_name_abc', 'var_name_de', 'var_name_1']


# Generated at 2022-06-23 12:37:31.531369
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest


# Generated at 2022-06-23 12:37:39.468060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest

    # Set to a string
    terms = ['test']
    variables = {'test': 'testing'}

    # Call method
    with pytest.raises(AnsibleError, match=r'No variables available to search'):
        LookupModule.run(terms=terms)

    # Call method
    with pytest.raises(AnsibleError, match=r'Invalid setting identifier, "test" is not a string, it is a .*'):
        LookupModule.run(terms=terms, variables=variables, direct=True)

    # Call method

# Generated at 2022-06-23 12:37:43.253701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    variables = {'Ansible': 'IT automation', 'AWX': 'Ansible Tower'}
    ret = lm.run(terms=['Ansible'], variables=variables)
    assert ret == ['Ansible']


# Generated at 2022-06-23 12:37:53.655441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    os.environ['HOME'] = '/home/abcd'
    l = LookupModule()
    l.set_options(var_options={'a': 'A', 'a.b': 'A.B'}, direct={})
    assert(l.run(terms=['a'], variables={'a': 'A', 'a.b': 'A.B'}) == ['a'])
    assert(l.run(terms=['a.b'], variables={'a': 'A', 'a.b': 'A.B'}) == ['a.b'])
    assert(l.run(terms=['^a$'], variables={'a': 'A', 'a.b': 'A.B'}) == ['a'])

# Generated at 2022-06-23 12:38:00.138029
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestClass(LookupModule):
        def __init__(self):
            super(TestClass, self).__init__
            self.some_property = None

    obj = TestClass()

    assert obj.some_property is None
    assert obj._templar is None
    assert obj._loader is None
    assert obj._basedir is None
    assert obj._connection is None
    assert obj._play_context is None
    assert obj._loader_name == 'python'
    assert obj._errors == []

# Generated at 2022-06-23 12:38:02.328656
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor for class LookupModule
    """
    lookup_mod = LookupModule()
    assert lookup_mod is not None

# Generated at 2022-06-23 12:38:12.040998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils import basic
    from ansible.plugins.loader import lookup_loader

    class Options(object):
        def __init__(self, **kwargs):
            for (k, v) in kwargs.items():
                setattr(self, k, v)

    class MockVariableManager(object):
        def __init__(self, module_vars):
            self.module_vars = module_vars

        def hostvars(self):
            return self.module_vars

    class MockTerminal(object):
        def __init__(self, *args, **kwargs):
            pass

        def tty_height(self):
            return (24, None)


# Generated at 2022-06-23 12:38:23.564792
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import of modules needed for testing
    import sys
    import os

    # Mock of gettext imported to ensure that the return of '_' is a str
    sys.modules['gettext'] = type('', (), {})()
    sys.modules['gettext']._ = lambda x: x

    # Mock module_utils
    class MockAnsibleError(Exception):
        pass

    class MockModuleUtils(object):

        @staticmethod
        def _text():
            class MockText(object):
                @staticmethod
                def to_native(string):
                    return string
            return MockText

        @staticmethod
        def get_module_utils(path):
            return mock_module_utils

    # Mock module_utils for utils. AnsibleError (in utils) raised when an error is detected

# Generated at 2022-06-23 12:38:25.207114
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test']) == []

# Generated at 2022-06-23 12:38:26.131128
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()


# Generated at 2022-06-23 12:38:26.962167
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()


# Generated at 2022-06-23 12:38:39.166214
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = ['^qz_.+', '.+_zone$', '^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': ['host1', 'host2'],
        'hosts_zone': 'prod',
        'hosts_zone_location': '1',
        'hosts2_zone': 'prod2',
        'hosts2_zone_location': '2'
    }
    ret = module.run(terms, variables=variables)

# Generated at 2022-06-23 12:38:40.790340
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None
# Test of lookup() function

# Generated at 2022-06-23 12:38:48.663959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Prepare test data
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("varnames", "qa+") }}')))
        ]
    )


# Generated at 2022-06-23 12:38:49.559117
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:38:55.850665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)

    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-23 12:39:06.413151
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test options set correctly
    lookup = LookupModule()
    lookup.set_options = lambda a, b: None
    lookup.fail = lambda a: None
    lookup.get = lambda a: None

    # Test if lookup term is not string type
    lookup.run([1])
    lookup.run([{}])
    lookup.run([[]])

    # Test if regex pattern is valid
    lookup.run(['['])

    # Test if regex pattern is valid
    lookup.run(['[\\'])

    # Test if regex pattern is valid
    lookup.run(['['])

    # Test not matching variable

# Generated at 2022-06-23 12:39:09.090164
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test that class LookupModule is properly created
    '''
    assert(LookupModule())

# Generated at 2022-06-23 12:39:17.395974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world',
                 'qa_1': "I won't show", 'qz_': "I won't show either"}

    assert lookup.run(['^qz_.+'], variables) == \
            ['qz_1', 'qz_2']
    assert lookup.run(['.+'], variables) == \
            ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup.run(['hosts'], variables) == \
            []

# Generated at 2022-06-23 12:39:18.396051
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:39:25.690089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    import pytest
    from ansible.plugins.lookup.varnames import LookupModule

    module = LookupModule()

    # Assert exception thrown since no variables passed
    with pytest.raises(AnsibleError):
        module.run(terms=['some_var', 'other_var'])

    # Assert exception thrown since 3rd term is not a list or string
    variables = {
        'some_var': 'some value',
        'other_var': 'some other value',
        'third_var': ['some list']
    }
    with pytest.raises(AnsibleError):
        module.run(terms=['some_var', 'other_var', ['third_var']], variables=variables)

    # Assert exception thrown since 3rd term is

# Generated at 2022-06-23 12:39:32.517462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.varnames import LookupModule
    lookup = LookupModule()
    try:
        lookup.run([])
    except AnsibleError as e:
        assert 'No variables available to search' in e.message
    lookup = LookupModule()
    try:
        lookup.run([12,34])
    except AnsibleError as e:
        assert 'Invalid setting identifier' in e.message
# Test run() method of class LookupModule

# Generated at 2022-06-23 12:39:38.694155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['.+_zone$', '.+_location$']
    variables = {
        'foo_zone': 'bar',
        'hostvars': {
            'baz': 'qux_location',
            'quux': 'quuz_zone'
        }
    }

    assert lookup_module.run(terms=terms, variables=variables) == ['foo_zone', 'baz', 'quux']

# Generated at 2022-06-23 12:39:44.267343
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = "*_options"
    test_variables = {'foo_options': {'bar_baz_options': True}}
    test_kwargs = {'unsafe': True}
    test_lm = LookupModule()
    test_lm.run(terms=test_terms, variables=test_variables, **test_kwargs)
    assert test_lm.options == test_variables

# Generated at 2022-06-23 12:39:45.105670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 12:39:45.583105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:39:54.918214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.varnames
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.extra_vars = {'playbook_dir': '.'}
    names = ansible.plugins.lookup.varnames.LookupModule().run([ '^qz_.+' ], variables, variable_manager=variable_manager)

    assert names == [ 'qz_1', 'qz_2', 'qz_' ]

# Generated at 2022-06-23 12:40:03.117378
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing lookups with variables having valid and invalid keys
    # Valid keys:
    #   - Starts with letter '_'
    #   - Starts with letter 'a'-'z' and 'A'-'Z'
    #   - Contains letter '_'
    #   - Contains letter 'a'-'z' and 'A'-'Z'
    #   - Contains digits '0'-'9'
    # Invalid keys:
    #   - Starts with digit '0'-'9'
    #   - Contains characters other than letters, digits and '_'

    # Data structures needed to simulate variables dictionary
    # Variables with valid keys
    data1 = {'var_a12_34': 'hello', 'var_B12_34': 'world'}
    # Variables with invalid keys

# Generated at 2022-06-23 12:40:04.946366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test a json data set
    assert LookupModule({})

# Test for run function

# Generated at 2022-06-23 12:40:12.578993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:40:14.703690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()
# vim: expandtab:sw=4:ts=4

# Generated at 2022-06-23 12:40:25.601347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock the lookup object with a null object
    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            pass
    lookup = TestLookupModule()
    # Test the run method
    assert [] == lookup.run([])
    assert ['example'] == lookup.run(['example'], {'example': 'example'})
    assert ['example', 'example2'] == lookup.run(['example'], {'example': 'example', 'example2': 'example2'})
    assert ['example'] == lookup.run(['example'], {'example': 'example', 'not_example': 'example'})
    assert ['example'] == lookup.run(['example'], {'_example': 'example'})

# Generated at 2022-06-23 12:40:29.581456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Ansible uses a single object for all plugins of a certain type.
    # For any new functionality, extend the plugins in-place.
    #
    # The original object cannot be replaced.
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:40:37.308922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    res = module.run(['^qz_.+'], vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert res == ['qz_1', 'qz_2']
    res = module.run(['^qz_.+'], vars = {'qz_try': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert res == ['qz_try']

# Generated at 2022-06-23 12:40:37.756919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 12:40:42.256127
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # arrange
    _module = 'setup'
    _terms = 'hostname'
    _variables = dict()
    _variables['ansible_hostname'] = 'localhost'

    # act
    test = LookupModule()

    # assert
    assert _module == test._templar._module._name



# Generated at 2022-06-23 12:40:50.024217
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [ '^sh_.+', '^gw_.+', '^ga_.+' ]
    variables = { 'sh_1' : 'hello', 'sh_2' : 'world', 'gw_1' : 'hello', 'gw_2' : 'world', 'ga_1' : 'hello', 'ga_2' : 'world' }
    lookup_module = LookupModule()

    assert lookup_module.run(terms, variables) == ['sh_1', 'sh_2', 'gw_1', 'gw_2', 'ga_1', 'ga_2']

# Generated at 2022-06-23 12:40:53.189357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert callable(LookupModule.run)
    assert hasattr(LookupModule, 'set_options')
    assert callable(LookupModule.set_options)


# Generated at 2022-06-23 12:41:00.115334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule()
    test_vars = {'valid_variable': 'valid'}
    test_terms = ['valid_variable']

    # test for a valid search for a varname
    test_class.run(test_terms, variables=test_vars)

    # test for a search for nonexistent variable
    nonexistent_term = ['non_existent_variable']
    try:
        test_class.run(nonexistent_term, variables=test_vars)
        assert False
    except AnsibleError:
        assert True

    # test for a search for a non-string varname
    non_string_term = ['[1, 2, 3]']