

# Generated at 2022-06-23 12:31:02.382023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = dict(
        qz_1='hello',
        qz_2='world',
        qa_1='I wont show',
        qz_='I wont show either',
        show_1='this will show',
        show_2='this will show too',
        show='this will show too',
        hosts='this will show too',
        admin_zone='hello',
        admin_location='world',
    )


    ret = lookup_module.run(['^qz_.+'], variables=variables)
    assert(sorted(ret) == sorted(['qz_1', 'qz_2']))

    ret = lookup_module.run(['.+'], variables=variables)

# Generated at 2022-06-23 12:31:05.686289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, "Failed to create instance of LookupModule"
    lookup.run(terms=['test'], variables={'test': 1})

# Generated at 2022-06-23 12:31:16.967365
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native

    lookup_plugin = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_plugin.run(terms=[], variables=None)

    with pytest.raises(AnsibleError):
        lookup_plugin.run(terms=[""], variables=None)

    with pytest.raises(AnsibleError):
        lookup_plugin.run(terms=["^qz_.+"], variables=None)

    with pytest.raises(AnsibleError) as exec_info:
        lookup_plugin.run(terms=["NotRegex"], variables=None)
    assert "Unable to use" in exec_info.value.message

    results =  lookup_plugin.run

# Generated at 2022-06-23 12:31:18.830578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test constructor of class LookupModule
    obj = LookupModule()

# Generated at 2022-06-23 12:31:23.582696
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_vars = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
        }
    lookup = LookupModule()
    lookup.run(['^qz_.+'], variables = test_vars)
    return

# Generated at 2022-06-23 12:31:34.746577
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys

    if sys.version_info[0] > 2:
        string_types = str,
    else:
        string_types = basestring,

    class LookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            if isinstance(terms, string_types):
                terms = [terms]
            self.set_options(var_options=variables, direct=kwargs)
            return self._flatten(terms)

    lookup_module = LookupModule()


# Generated at 2022-06-23 12:31:45.841370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarObj:
        def __init__(self, name, val):
            self.name = name
            self.val = val
        def __repr__(self):
            return self.__str__()
        def __str__(self):
            return self.name + ": " + self.val

    var_obj1 = VarObj('cisco_test', 'cisco_test_value')
    var_obj2 = VarObj('cisco_test2', 'cisco_test2_value')
    var_obj3 = VarObj('cisco_test3', 'cisco_test3_value')

    # run: terms given is not a string

    lookup_obj = LookupModule()

# Generated at 2022-06-23 12:31:51.021825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    var_name = "Ansible test variable"
    var_val = 12345
    variables = { var_name : var_val }

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=[var_name], variables=variables)

    assert len(result) == 1
    assert result[0] == var_name

# Generated at 2022-06-23 12:31:58.801782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_args = dict(
        _terms=['qz_.+'])
    fake_vars = dict(
        qz_1='hello',
        qz_2='world',
        qa_1="I won't show",
        qz_="I won't show either")

    res = list(LookupModule().run(module_args, variables=fake_vars))
    assert len(res) == 2
    assert res == ["qz_1", "qz_2"]

# Generated at 2022-06-23 12:32:05.185739
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule object
    lookupMod = LookupModule()

    # Set the variables
    variables = {}
    variables['a'] = 1
    variables['b'] = 2
    variables['c'] = dict(c1=3, c2=4)

    # Test run method
    value = lookupMod.run(['^a$','^b$','^c[1-2]$'], variables)

    # Check result
    assert value == ['a','b','c']

# Generated at 2022-06-23 12:32:13.604913
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create new LookupModule object
    lookup = LookupModule()

    assert lookup.run(['^qz_.+'],{'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup.run(['.+_zone$', '.+_location$'],{'zone_id': 'hello', 'location_id1': 'world', 'zone_id2': "I won't show", 'zone': "I won't show either"}) == ['zone_id', 'location_id1', 'zone_id2']

# Generated at 2022-06-23 12:32:23.024677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    match = 'test'
    no_match = 'no_match'
    dummy_match = 'dummy_match'

    class DummyVars:
        def __init__(self, *args):
            pass

        def get(self, name, default=None):
            if name.startswith(match):
                return name
            else:
                return default

        def __contains__(self, name):
            return name.startswith(match) or name.startswith(dummy_match)

        def __getitem__(self, name):
            if name.startswith(match):
                return name
            elif name.startswith(dummy_match):
                return dummy_match
            else:
                raise KeyError

        def __len__(self):
            return 1


# Generated at 2022-06-23 12:32:30.957538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'a': 1, 'b': 2, 'roles': {'red': 1, 'green': 2, 'blue': 3}}
    terms = ['^a$']
    result = lookup.run(terms, variables)
    assert result == ['a']

    terms = ['^roles']
    result = lookup.run(terms, variables)
    assert result == ['roles']

    terms = ['^roles.*', '^a$']
    result = lookup.run(terms, variables)
    assert result == ['roles', 'a']

    terms = ['^roles.+$']
    result = lookup.run(terms, variables)
    assert result == ['roles']

# Generated at 2022-06-23 12:32:35.280302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up tests
    terms = ['^set_fact_.+', '.+_something']
    variables = {'set_fact_one': 'one', 'set_fact_two': 'two', 'three_something': 'three'}
    # run test
    results = LookupModule().run(terms, variables=variables, **{})
    # test results
    assert results == ['set_fact_one', 'set_fact_two', 'three_something']

# Generated at 2022-06-23 12:32:43.950295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for different input for terms
    lookup_module = LookupModule()
    try:
        lookup_module.run([1])
    except AnsibleError as e:
        assert 'string,' in to_native(e)
    try:
        lookup_module.run([["a", "b"]])
    except AnsibleError as e:
        assert 'string,' in to_native(e)
    # Test for variables=None
    try:
        lookup_module.run(["foobar"])
    except AnsibleError as e:
        assert 'No variables' in to_native(e)

# Generated at 2022-06-23 12:32:44.616697
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:32:53.568865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'a': 1, 'b': 2, 'c': 3, 'd': 4, '12': 'abc'}
    lookup_module = LookupModule()
    # Test to find the variable names starting with 'a'
    lookup_module.run(terms=['^a'], variables=vars)
    # Test to find the variable names with 'b'
    lookup_module.run(terms=['b'], variables=vars)
    # Test to find the variable names ending with '2'
    lookup_module.run(terms=['2$'], variables=vars)
    # Test to find the variable names with 'abc'
    lookup_module.run(terms=['abc'], variables=vars)
    # Test to find the variable names starting with 'a' and ending with '2'
    lookup_module

# Generated at 2022-06-23 12:32:55.473934
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:33:03.652011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Container(object):
        def __init__(self, d):
            self.__dict__ = d
    class MockVariables(object):
        def __getitem__(self, k):
            return True

    variables = {
        'this_is': 1,
        '_this_is_also': 2,
        'this_is_not': 3,
    }
    lookup_m = LookupModule().run(['this_is.+', '_this_is_also'], variables)
    assert len(lookup_m) == 2
    assert 'this_is' in lookup_m
    assert '_this_is_also' in lookup_m

# Generated at 2022-06-23 12:33:05.830036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    plugins = ('varscan',)
    for plugin in plugins:
        lookup_plugin = LookupModule(plugins.find(plugin)).run()
        assert lookup_plugin is not None

# Generated at 2022-06-23 12:33:15.335916
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeVarsModule(object):

        def __init__(self, ansible_vars):
            self.ansible_vars = ansible_vars

        def run(self, *args, **kwargs):
            # ("test", dict(one=dict(key='value')))
            return self.ansible_vars

    test = {
        'one': {'key': 'value'},
        'two': 2,
        'three': None,
        'four': True,
    }

    fv = FakeVarsModule(test)
    lm = LookupModule()

    # test single regex
    assert ['two'] == lm.run(['^t.+'], variables=fv.run()[1])

    # test multiple regex
    assert sorted(['two', 'three', 'four'])

# Generated at 2022-06-23 12:33:24.189431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test calling LookupModule._find_vars() without a variables param

    # Setup test with a LookupModule object
    class Opts(dict):
        def __init__(self, d):
            self.__dict__ = d
    lookup = LookupModule()
    lookup.set_options(Opts({}))

    # Test calling LookupModule._find_vars() without a variables param raises the exception
    try:
        lookup._find_vars(["test"])
        assert False, 'AnsibleError not raised when calling LookupModule._find_vars() without a variables param'
    except AnsibleError:
        assert True
    except:
        assert False, 'Exception raised when calling LookupModule._find_vars() without a variables param was not an AnsibleError'

    # Test calling LookupModule._find_

# Generated at 2022-06-23 12:33:25.071558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-23 12:33:35.347845
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:33:36.632203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    

# Generated at 2022-06-23 12:33:46.404860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test no variable available
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert "No variables available to search" in str(e)

    # Test variables available
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = lookup_module.run(terms=['^qz_.+'], variables=variables)
    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:33:57.984091
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    #  Test with no variables set
    assert l.run(terms=['ansible_os_']) == []

    # Test with ANSIBLE_OS environment set
    env = {'ANSIBLE_OS_FAMILY': 'Linux', 'ANSIBLE_OS': 'RedHat'}
    assert l.run(terms=['ansible_os_'], variables=env) == ['ansible_os_family', 'ansible_os_name']

    # Test search for only 'family'
    assert l.run(terms=['ansible_os_family'], variables=env) == ['ansible_os_family']
    assert l.run(terms=['ansible_os_name'], variables=env) == ['ansible_os_name']

# Generated at 2022-06-23 12:34:05.587321
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    variables = {
        'name': 'lookup_myname_var',
        'name_regex': 'lookup_myname_var_regex',
        'name_zone': 'lookup_myname_var_zone',
        'name_zone_regex': 'lookup_myname_var_zone_regex',
        'name_location': 'lookup_myname_var_location',
        'name_location_regex': 'lookup_myname_var_location_regex'
    }
    lu.set_options(var_options=variables, direct={})
    assert type(lu) == LookupModule


# Generated at 2022-06-23 12:34:06.254269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:34:07.805645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    #assert lm.run(terms, variables)

# Generated at 2022-06-23 12:34:08.675822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

# Generated at 2022-06-23 12:34:15.978857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.plugins.loader import lookup_loader
    import sys

    # Inject fake lookup loader
    lookup_loader.lookup_modules = {'varnames': LookupModule}

    # Create lookup module
    lm = LookupModule()

    # Test setup

# Generated at 2022-06-23 12:34:18.570528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        l = LookupModule()
    except Exception as e:
        assert False, 'Could not instantiate class LookupModule: %s' % to_native(e)



# Generated at 2022-06-23 12:34:28.078012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import constants
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display

    vars_ = {
        'a_string': 'a string',
        'a_number': '1',
        'a_boolean': True,
        'a_list': [1, 2, 3],
        'a_dict': {'a': 1, 'b': 2, 'c': 3},
        'a_tuple': (1,2,3),
        'a_set': set(['a', 'b', 'c']),
        'an_int': 1,
        'a_float': 1.1,
    }

    display_ = Display()
    display_.verbosity = 0

    lookup = LookupBase()

# Generated at 2022-06-23 12:34:35.074757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup = LookupModule()

    # Execute
    ret = lookup.run([".+"], {'qz_1': 'qz_1', 'qz_2': 'qz_2', 'qa_1': 'qa_1'})

    # Assert
    assert ret == ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-23 12:34:38.124870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # lookup_module.set_options(var_options={'hello': 20})
    result = lookup_module.run(['^qz_.+'])

# Generated at 2022-06-23 12:34:39.381063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert hasattr(module, 'run')

# Generated at 2022-06-23 12:34:43.429155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_basedir() == 'lookup_plugins'
    assert l.get_vars()['ansible_version']

# Generated at 2022-06-23 12:34:52.516224
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:34:59.885533
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:35:03.610558
# Unit test for constructor of class LookupModule
def test_LookupModule():

    testoptions = {}
    testterms = ['term1', 'term2']
    testvariables = None

    test = LookupModule()
    test.set_options(var_options=testvariables, direct=testoptions)
    test.run(testterms, testvariables)


# Generated at 2022-06-23 12:35:04.833608
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for the constructor of class LookupModule'''
    return

# Generated at 2022-06-23 12:35:06.089426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO : Add unit tests for method LookupModule.run()
    pass

# Generated at 2022-06-23 12:35:06.827038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-23 12:35:11.054654
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    x = l.run(terms=['^ansible_.+'], variables={"ansible_foo": "bar", "ansible_baz": "bax"}, ansible_foo="bar")
    assert x == ["ansible_foo", "ansible_baz"]

# Generated at 2022-06-23 12:35:12.445351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    with pytest.raises(AnsibleError):
        lm.run([""])


# Generated at 2022-06-23 12:35:13.515345
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None
    assert LookupModule.run

# Generated at 2022-06-23 12:35:24.689814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, direct={})
    results = l.run(terms=["^qz_.+"], variables=None)
    assert results == ['qz_1', 'qz_2']
    # now with the "not a string" check
    try:
        results = l.run(terms=["^qz_.+", 0])
        assert False, "Should have thrown an exception"
    except AnsibleError:
        assert True
    except Exception as e:
        assert False, "Unexpected exception: %s" % str(e)
    # now with the "missing variables" check

# Generated at 2022-06-23 12:35:25.977360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module)

# Generated at 2022-06-23 12:35:32.819631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the test environment
    lookup_module = LookupModule()
    variables = {
        "valid_var": "this is a valid variable",
        "another_valid_var": "another valid var"
    }
    args = {
        "terms": ["^valid_var$", "^other_var$"],
        "variables": variables
    }

    # Expected expected match at the end of the test
    # TODO: Fix this, the key "valid_var" shouldn't be
    # duplicated in the list of expected_matches.
    expected_matches = ["valid_var", "valid_var"]

# Generated at 2022-06-23 12:35:40.713348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule(play_context=None, loader=None, templar=None, shared_loader_obj=None).run(terms=['.+_zone$', '.+_location$']
                                                                                                       ,variables={'host_zone':'1', 'host_location':'2', 'jhgjh':'5'})
    assert result[0] == 'host_zone'
    assert result[1] == 'host_location'
    assert len(result) == 2
    #print(result)

# Generated at 2022-06-23 12:35:41.632175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No unit test for method run condition"

# Generated at 2022-06-23 12:35:53.929390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    r = lu.run(['^test.+'], {'test_aaa':1, 'aaa_test':2})
    assert r == ['test_aaa']
    r = lu.run(['^test.+'], {'test_aaa':1, 'aaa_test':2},wantlist=True)
    assert r == ['test_aaa']
    r = lu.run(['^(?!test).+'], {'test_aaa':1, 'aaa_test':2},wantlist=True)
    assert r == ['aaa_test']
    r = lu.run(['^(?!test).+'], {'test_aaa':1, 'aaa_test':2},wantlist=True)
    assert r == ['aaa_test']

# Generated at 2022-06-23 12:35:55.124102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None).get_options(None) is None

# Generated at 2022-06-23 12:35:56.707170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:35:59.293930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    assert hasattr(lm, 'run')


# Generated at 2022-06-23 12:36:10.140071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '^qz_.+$',
        '.+',
        'hosts',
        '^.+_zone$',
        '^.+_location$',
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'foo_zone': 'bar',
        'abc_zone': 'def',
        'abc_location': 'def',
        'xyz_location': 'zyx',
        'hostname': 'myhost',
        'other_host': 'other_host',
    }


# Generated at 2022-06-23 12:36:16.374065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for LookupModule.run method """
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lu = LookupModule(loader=loader)

    terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}

    ret_list = lu.run(terms, variables)

    assert ret_list == ['qz_1', 'qz_2']

    # Additional test case to test a single term
    terms = ['^qz_1']

    ret_list = lu.run(terms, variables)

    assert ret_list == ['qz_1']

# Generated at 2022-06-23 12:36:26.989368
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    # More than one term
    assert module.run(['^qz_.+', '.+_zone$'], {'qz_1': 'hello',
                                               'qz_2': 'world',
                                               'qa_1': "I won't show",
                                               'qz_': "I won't show either",
                                               'hosts_zone': 'hosts zone',
                                               'hosts_location': 'hosts location'}) == ['qz_1', 'qz_2', 'hosts_zone']
    # One term without variables
    assert module.run(['^qz_.+']) == []
    # One term with variables

# Generated at 2022-06-23 12:36:37.164579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # variables is a dict of key - value pairs that is passed on to the 'run' method of
    # the lookup plugin.
    # 'variables' is a dict of key - value pairs that is passed on to the 'run' method
    # of the lookup plugin. This dict is a reference to the variables that is defined
    # at the time the lookup plugin is invoked.
    variables = dict(qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either")
    # 'terms' is a list of string patterns that are passed on to the 'run' method of
    # the lookup plugin. This list is a reference to the terms that are defined by the
    # lookup plugin user in the playbook. Ex:
    # - debug: msg="{{lookup

# Generated at 2022-06-23 12:36:47.057014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    #initalize
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    ret = [u'eth0', u'lo']
    assert ret == LookupModule().run(terms=[u'^eth0$', u'lo|^eth1$'], variables=dict(ansible_interfaces=ret))

# Generated at 2022-06-23 12:36:47.927438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None)

# Generated at 2022-06-23 12:36:57.651962
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:37:09.297113
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys

# Generated at 2022-06-23 12:37:18.946966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import re
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native

    lookup_module = LookupModule()
    variable_names = {'var1': 'val1', 'var2': 'val2', 'var3': 'val3'}

    # Test invalid settings identifier
    settings_id_1 = 10

# Generated at 2022-06-23 12:37:29.652547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    vars = {
        'a_b': 'hello',
        'a_c': 'world',
        'b_b': '',
        'c_d': 'foo',
        'c_e': 'bar',
        'd_f': 'baz',
        'd_c': 'boom'
    }
    terms = ['a.+']
    ret = lookup.run(terms, vars)
    assert ret == ['a_b', 'a_c']
    terms = ['d.+', 'c.+']
    ret = lookup.run(terms, vars)
    assert ret == ['c_d', 'c_e', 'd_f', 'd_c']
    terms = ['^a.+', '^b.+']
    ret = lookup.run

# Generated at 2022-06-23 12:37:30.788529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-23 12:37:32.943716
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mymodule = LookupModule("any config", None, None)
    assert "LookupModule" == mymodule.__class__.__name__

# Generated at 2022-06-23 12:37:42.841062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        '^qz_.+',
        '.+',
        'hosts',
        '.+_zone$',
        '.+_location$'
    ]

    variables= {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts_in_path': "seen",
        'hosts_in_path_zone': "seen",
        'hosts_in_path_location': "seen",
        'hosts': "seen",
        'group_names': "seen",
        'groups': "seen",
    }


# Generated at 2022-06-23 12:37:53.018122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Valid input
    terms = ['.+_zone$', '.+_location$']
    variables = {'nginx_zone': 'true', 'nginx_location': '80', 'nginx_host': 'localhost'}
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms=terms, variables=variables)
    assert len(result) == 2
    assert result[0] == 'nginx_zone'
    assert result[1] == 'nginx_location'

    # Wrong type for terms
    terms = 123
    variables = {'nginx_zone': 'true'}
    lookup_obj = LookupModule()
    failed = False
    try:
        result = lookup_obj.run(terms=terms, variables=variables)
    except AnsibleError:
        failed = True
   

# Generated at 2022-06-23 12:38:03.526755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world'}) == ["qz_1", "qz_2"]
    assert lookup_module.run(['^qz_.+'], {'qa_1': 'hello', 'qz_2': 'world'}) == ["qz_2"]
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'hello', 'qz_': 'I won\'t show either'}) == ["qz_1", "qz_2"]

# Generated at 2022-06-23 12:38:05.373269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("constructor test: ")
    lookup_module_instance = LookupModule()
    print("success")

# Generated at 2022-06-23 12:38:05.973185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:38:07.356386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # constructor test
    lmd = LookupModule()

# Generated at 2022-06-23 12:38:09.059438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module)


# Generated at 2022-06-23 12:38:15.882755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_test = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show",'qz_': "I won't show either"}
    result = LookupModule_test.run(terms, variables, **variables)
    assert result == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-23 12:38:16.480612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:38:22.739118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    test_vars = {'test': 'hello', 'test_1': 'hello', 'test_2': 'hello', 'test2': 'hello'}
    test_terms = ['^test_.+', 'test2']
    assert test_obj.run(test_terms, variables=test_vars) == ['test_1', 'test_2', 'test2']

# Generated at 2022-06-23 12:38:23.699843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    plugin = LookupModule()
    assert plugin is not None

# Generated at 2022-06-23 12:38:25.376963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #TODO: Add Unit test
    pass

# Generated at 2022-06-23 12:38:29.303055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test setup
    from ansible.module_utils.six.moves import io
    from ansible.module_utils.six import BytesIO
    
    # First test
    testLookupModule_run_1()
    # Second test
    testLookupModule_run_2()


# Generated at 2022-06-23 12:38:41.531933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    class NameParts:
        def __init__(self, module_name):
            self.module_name = module_name
            self.terms = ['hosts']


        def get_name(self):
            return self.module_name

        def get_terms(self):
            return self.terms

        def get_options(self):
            return {}

        def get_vars(self):
            if self.module_name == 'varnames' or self.module_name == 'varnames.py':
                return {'hosts_name': 'hosts_name', 'hosts_test': 'hosts_test'}
            else:
                return {}


# Generated at 2022-06-23 12:38:43.390477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    current_variables = {"varname": "test"}
    lookup_module_instance.run('varname', variables=current_variables)

# Generated at 2022-06-23 12:38:54.233788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from mock import patch, Mock

    lookup = LookupModule(str)

    # patch: var_options, direct
    with patch.multiple(LookupBase, var_options={'test_key1': 'test_value1', 'test_key2': 'test_value2'}, direct={}):
        # terms: invalid type
        invalid_type_term = [1]
        with patch.multiple(LookupModule, set_options=Mock(return_value=None), run=Mock(return_value=[])):
            try:
                lookup.run(invalid_type_term)
            except AnsibleError:
                pass
            else:
                raise Exception('LookupModule should raise an exception if the term is invalid type.')

        # terms: regex pattern
        # test_key1 - match
        # test_key2 -

# Generated at 2022-06-23 12:38:59.662565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys

    # python-2 and python-3 compatible input
    terms = ['.+']
    variables = {'hosts': ['host1'], 'hosts1': ['host2']}
    expected_result = ['hosts', 'hosts1']

    lookup = LookupModule()
    assert lookup.run(terms, variables) == expected_result

# Generated at 2022-06-23 12:39:05.560146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = ['^qz_.+']
    variables= {'qz_1': 'hello', 'qz_2': 'hello'}
    my_list = lookup_plugin.run(terms, variables)
    assert(len(my_list) == 2)
    assert(my_list[0] == 'qz_1')
    assert(my_list[1] == 'qz_2')

# Generated at 2022-06-23 12:39:08.645754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _look = LookupModule(None, None, None)
    assert _look is not None

# Unit test to run the run() method of class LookupModule

# Generated at 2022-06-23 12:39:10.564917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    assert lookup.run is not None

# Generated at 2022-06-23 12:39:20.978770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable = {'A': '1', 'A1': '2', 'A2': '3', 'A3': '4', 'B': '5',
                'C': '6', 'C1': '7', 'C2': '8', 'C3': '9', 'D': '10'}
    terms = ['^A', '2$', 'C']
    ret = LookupModule().run(terms, variables=variable)
    assert set(ret) == set(['A', 'A1', 'A2', 'A3', 'C', 'C1', 'C2', 'C3'])


# Generated at 2022-06-23 12:39:32.355473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up class LookuModule
    lookup_module = LookupModule()

    # first test: LookupModule_run_without_variables
    print("LookupModule_run_without_variables Test")
    try:
        lookup_module.run([])
    except AnsibleError as e:
        assert e.args[0] == "No variables available to search"
    else:
        assert False

    # second test: LookupModule_run_with_non_string_term
    print("LookupModule_run_with_non_string_term Test")
    try:
        lookup_module.run([1])
    except AnsibleError as e:
        assert e.args[0] == "Invalid setting identifier, \"1\" is not a string, it is a <class 'int'>"
    else:
        assert False



# Generated at 2022-06-23 12:39:42.682634
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:39:52.025443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    vars={'some_var': 'Some_value', 'not_some_var': 'Not_some_value'}
    assert lookup.run(["some_var"], variables=vars) == ['some_var']
    assert lookup.run(["some_var", "not_some_var"], variables=vars) == ['some_var', 'not_some_var']
    with pytest.raises(AnsibleError) as exc:
        lookup.run(["some_var", 1], variables=vars)
    assert "Invalid setting identifier" in exc.value.message
    assert "it is a <class 'int'>" in exc.value.message
    with pytest.raises(AnsibleError) as exc:
        lookup.run(["some_[var"], variables=vars)

# Generated at 2022-06-23 12:39:52.612203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:39:53.570596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:39:58.758059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unittest for constructor of class LookupModule
    # Fake Variables
    # _load_name() will return these variables
    some_var = {
        "name": {
            "first": "manis",
            "last": "thangaraj"
        }
    }
    module = LookupModule()
    module.set_options(var_options=some_var)
    assert module is not None

# Unittest for run()

# Generated at 2022-06-23 12:40:00.777384
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    assert mylookup.run(terms=['foo']) == []

# Generated at 2022-06-23 12:40:07.627877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyLookupBase(LookupBase):
        def __init__(self):
            pass

    class DummySelf():
        def __init__(self):
            self.params = {}
            self.lookup = DummyLookupBase()

    terms = ['test']
    variables = {
        'test': 'OK'
    }
    kwargs = {}

    result = LookupModule().run(terms=terms, variables=variables, **kwargs)
    assert result == ['test']

    result = LookupModule().run(terms=terms, **kwargs)
    assert result == []

# Generated at 2022-06-23 12:40:12.777204
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("test_LookUpModule")
    l = LookupModule()
    l.run(terms=['qz_1'], variables={'qz_1': 'val', 'qa_1': 'val'})
    l.run(terms=['qa_1'], variables={'qz_1': 'val', 'qa_1': 'val'})
    try:
        l.run(terms=['qz_1'], variables=None)
        assert False
    except AnsibleError:
        pass
    print("test_LookUpModule passed")


# Generated at 2022-06-23 12:40:14.110991
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()


# Generated at 2022-06-23 12:40:20.383966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    # Invalid setting identifier (not string)
    try:
        module.run(terms=[1])
        assert False
    except Exception as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Unsupported regex pattern
    try:
        module.run(terms=["["])
        assert False
    except Exception as e:
        assert str(e) == 'Unable to use "[" as a search parameter: nothing to repeat'


# Generated at 2022-06-23 12:40:22.107611
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global lookup
    lookup = LookupModule()


# Generated at 2022-06-23 12:40:24.505204
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    test_terms = ['^qz_.+', '.*']
    result = look.run(terms=test_terms)
    assert result == []


# Generated at 2022-06-23 12:40:29.358571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    print("Successfully created an instance of LookupModule")
    raise SystemExit(0)

# The following is how you would call LookupModule from cli
# ansible localhost -m setup -a 'filter=ansible_eth0'
# ansible localhost -m debug -a 'msg="{{lookup("ipv4", "ansible_eth0")}}"'

# Generated at 2022-06-23 12:40:37.108131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_terms = ['^qz_.+', 'hosts', '^qz_.+', '.+_zone$', '.+_location$']
    mock_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either",
                      'some_hosts': 'some hosts', 'some_other_hosts': 'some other hosts', 'zone': 'zone',
                      'location': 'location', 'zone_location': 'zone_location'}


# Generated at 2022-06-23 12:40:38.757638
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:40:49.156401
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_bytes

    lookup = LookupModule()
    variables = dict(
        ansible_all_ipv4_addresses="127.0.0.1",
        ansible_default_ipv4="127.0.0.1",
        ansible_default_ipv6="::1",
    )
    actual_result = lookup.run(terms=["ansible_.*"], variables=variables, **{'_raw_params': 'ansible_.*'})

    # Expected result is just a list of variable names extracted from variables
    expected_result = [key for (key, value) in iteritems(variables)]

    assert len(expected_result) == len(actual_result) == 3

# Generated at 2022-06-23 12:40:50.986337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if not hasattr(LookupModule,"run"):
        raise AssertionError("run() is missing from LookupModule")

# Generated at 2022-06-23 12:40:52.663093
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        instance = LookupModule()
    except Exception:
        assert (False)
    assert instance is not None

# Generated at 2022-06-23 12:40:59.842575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Test 1
    import unittest

    class TestStringMethods(unittest.TestCase):

        def test_varnames(self):

            # Variables dictionary
            variables = {
                "qz_1": "hello",
                "qz_2": "world",
                "qa_1": "I won't show",
                "qz_": "I won't show either",
                "hosts": "hosts-related"
            }

            # Call the module
            ret = LookupModule().run(
                terms=["^qz_.+"],
                variables=variables
            )

            # Assertions
            self.assertTrue(ret)
            self.assertEqual(len(ret), 2)
            self.assertIn(ret, ["qz_1", "qz_2"])