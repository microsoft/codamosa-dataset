

# Generated at 2022-06-23 12:31:01.648443
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    vars = {'host': '127.0.0.1', 'host_ip': '127.0.0.1', 'host_fqdn': 'test.example.com', 'host_port': '8080'}
    terms = ['host', '^host_', '^host$']
    lm = LookupModule()
    results = lm.run(terms, vars)
    assert results is not None
    assert len(results) == len(terms), 'Invalid result length'
    for i in range(len(terms)):
        assert len(results[i]) == 1
        result = results[i][0]
        assert result == terms[i]

# Generated at 2022-06-23 12:31:13.247980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import yaml
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Variable used in test below
    variable_manager.set_nonpersistent_facts(dict(ansible_python_interpreter='/usr/bin/python', ansible_python_version='2.7.15'))

    # Variable used in test below
    variable_manager.set_nonpersistent_facts(dict(a_string='a string', b_string='another string'))

    # Find variables that start

# Generated at 2022-06-23 12:31:23.008139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from units.mock.loader import DictDataLoader
    from units.mock.loader import DictModule
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop as mock_normpath_noop

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }


# Generated at 2022-06-23 12:31:34.075953
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = dict(
        AWS_ACCESS_KEY_ID='123',
        AWS_SECRET_ACCESS_KEY='aaa',
        AWS_REGION='sa-east-1',
        ANSIBLE_HOSTS='aaa',
        ANSIBLE_HOST='bbb',
        ANSIBLE_PORT='ccc',
        ANSIBLE_HOST_VARIABLE='ddd',
        AWS_TAG_ENVIRONMENT='prod',
        AWS_TAG_CREATOR='ansible',
        AWS_TAG_PROJECT='myproject',
    )
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=dict())

    # Test 1

# Generated at 2022-06-23 12:31:44.882578
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # arrange
    test_data = {
        'dummy': 1,
        'hosts': 'all',
        'hosts_zone': 'west1',
        'hosts_location': 'Warsaw, Poland'
    }


# Generated at 2022-06-23 12:31:45.798103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:31:47.477362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:31:55.163539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def get_lookup_plugin(plugin_name):
        return LookupModule()

    ansible_module = Mock()
    ansible_module.get_lookup_plugin = get_lookup_plugin
    ansible_module.params = {"_raw_params": "foo"}
    ansible_module.fail_json.side_effect = AnsibleError
    ansible_module.run_command.return_value = (0, "", "")
    with pytest.raises(AnsibleError):
        ansible_module.run_command(["true"])



# Generated at 2022-06-23 12:31:56.783403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    ret = obj.run(terms=[])

# Generated at 2022-06-23 12:31:58.294246
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule()
    assert test_class is not None

# Generated at 2022-06-23 12:32:07.913956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os, sys
    import pytest
    # ansible_vars_dir = os.path.dirname(os.path.abspath(__file__)) + '/../../../../../ansible/test/integration/default/'
    # I am just not able to import module_utils from ansible/module_utils.
    # So that I copied file stdlib/lookup_plugins/varnames.py to my personal directory
    ansible_vars_dir = os.path.dirname(os.path.abspath(__file__)) + '/../../../../../../ansible_vars/'
    sys.path.append(ansible_vars_dir)
    import ansiblevariables
    ansiblevariables.setup_env()

    # Initialize our test object
    lookup = LookupModule()



# Generated at 2022-06-23 12:32:09.003530
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result


# Generated at 2022-06-23 12:32:10.198023
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance

# Generated at 2022-06-23 12:32:19.180501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_name = "qz_4"
    var_value = "hello"
    var_dict = {var_name : var_value}
    lookup_module = LookupModule()

    # search_term = ".+"
    results = lookup_module.run([".+"], var_dict, wantlist=True)
    assert var_name in results

    # search_term = "qz_4"
    results = lookup_module.run(["qz_4"], var_dict, wantlist=True)
    assert var_name in results

    # search_term = "^qz_.+"
    results = lookup_module.run(["^qz_.+"], var_dict, wantlist=True)
    assert var_name in results

    # search_term = "^q._4"
    results = lookup_module

# Generated at 2022-06-23 12:32:28.675710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import operator
    import ast

    lookup_varnames = LookupModule()

    test_variables = {
        'variable_1': 'value 1',
        'variable_2': 'value 2',
        'variable_a': 'value a',
        'variable_ab': 'value ab'
        }

    test_invalid_terms = [
        [],
        [{}],
        ['[a-z]'],  # invalid regex
        ['variable_'],
        ['variable_a'],
        ['variable_1', 'value 1'],
        ['variable_a', 'value [a-z]'],  # invalid regex
        [1, 2, 3],
        ['a-z'],  # invalid regex
        {'a': 1, 'b': 2}
    ]

    test_output_valid_terms

# Generated at 2022-06-23 12:32:39.222023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Lookup module requires ansible options in order to function
    # but since we are not actually using the options here
    # we can make a fake version of ansbile options
    class FakeAnsibleOptions(object):
        def __init__(self):
            self.connection = None
            self.module_path = None
            self.forks = 0
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.task_uuid = None
            self.timeout = None
            self.lsb_dist = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.verbosity = 0


# Generated at 2022-06-23 12:32:49.706817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':'I wont show either'}
    assert lu.run(terms, variables) == ['qz_1', 'qz_2']

    terms = ['.+']
    variables = {'1':'hello', '2':'world', '3':'I wont show either'}
    assert lu.run(terms, variables) == ['1', '2', '3']

    terms = ['hosts']
    variables = {'inventory_hosts':['hello', 'world', 'I wont show either']}
    assert lu.run(terms, variables) == ['inventory_hosts']



# Generated at 2022-06-23 12:32:51.547617
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        obj = LookupModule()
        assert obj.run(terms=['test'])
    except Exception as e:
        raise e

# Generated at 2022-06-23 12:32:55.176594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:32:56.514081
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:33:04.422654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'a': 'hello', 'ab': 'world', 'abc': 'I won\'t show', 'abcd': 'I won\'t show either'}
    result = lookup.run('^a.+', variables=variables)
    assert result == ['a', 'ab', 'abc']
    result = lookup.run('.+', variables=variables)
    assert result == list(variables.keys())
    result = lookup.run('^abc$', variables=variables)
    assert result == []
    result = lookup.run('^abc.+', variables=variables)
    assert result == []

# Generated at 2022-06-23 12:33:08.425171
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' test constructor for class LookupModule '''

    module = LookupModule()
    variables = {'test_var': 'test'}
    module.run(terms=['test_var'], variables=variables)
    assert module.run(terms=['test_var'], variables=variables) == ['test_var']
    assert module.run(terms=['not_found'], variables=variables) == []

# Generated at 2022-06-23 12:33:11.933697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()
    assert test_class.run(['test', 'hello'], variables={'test': 'test', 'hello': 'world'}) == ['test', 'hello']


# Generated at 2022-06-23 12:33:14.200720
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test module vars are initialized with default values
    lookup = LookupModule()

    assert isinstance(lookup, LookupModule), 'Not an instance of LookupModule'


# Generated at 2022-06-23 12:33:15.171480
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    print(lm)


# Generated at 2022-06-23 12:33:20.320408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create mock_variables
    mock_variables = {'name': 'hello', 'mood': 'hi'}

    # Create instance of LookupModule
    lookup_module = LookupModule()

    # Call method run with mock_variables
    result = lookup_module.run(terms='name', variables=mock_variables)

    # Assert that the run method returns expected result
    assert result == ['name']

# Generated at 2022-06-23 12:33:27.668490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    import yaml
    from io import BytesIO
    lookup = LookupModule()

    var_name = 'This is a test'
    var_value = 'The value of the test'
    var_dict = {var_name: var_value}
    stringio = BytesIO()
    yaml.dump(var_dict, stringio)
    var_yaml = to_bytes(stringio.getvalue())

    term = 'is a test'
    terms = ['is a test']
    variables = {'name': var_name, 'value': var_value, 'dict': var_dict, 'yaml': var_yaml}

    result = lookup.run(terms=terms, variables=variables)

    assert result == [var_name]

# Generated at 2022-06-23 12:33:35.755570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    terms = ['term1', 'term2']
    variables = {'var1': 'val1', 'var2': 'val2', 'nada': 'no match'}
    kwargs = {'variable_name': 'var1'}

    # Assert before
    assert len(lookup_module._match_variables) == 0
    assert lookup_module._options is None

    # Action
    result = lookup_module.run(terms, variables, **kwargs)

    # Assert after
    assert result == ['var1', 'var2']

# Generated at 2022-06-23 12:33:40.479226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    terms = ['term1', 'term2']
    variables = {'item1': 'value1', 'item2': 'value2'}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables)

# Generated at 2022-06-23 12:33:49.900315
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set up the object
    lm = LookupModule()
    lm._options = {'_terms': ['^qz_.+']}
    lm._templar = None
    lm._loader = None
    lm._variables = {"qz_1":"hello","qz_2":"world","qa_1":"I won't show", "qz_":"I won't show either"}
    assert lm.run([]) == ['qz_1', 'qz_2']
    assert lm.run(['incorrect']) == []
    assert lm.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lm.run(['^qz_.+', 'incorrect']) == ['qz_1', 'qz_2']

    lm

# Generated at 2022-06-23 12:33:51.329835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)

# Generated at 2022-06-23 12:33:53.753002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.set_options()

# Generated at 2022-06-23 12:33:54.736056
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None)

# Generated at 2022-06-23 12:33:55.477826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:34:04.269172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # test for invalid re str
    try:
        list(lookup.run(terms=['^_not_a_valid_regex_']))
    except AnsibleError as e:
        assert 'Unable to use "^_not_a_valid_regex_" as a search parameter' in to_native(e)
    else:
        assert False, 'Unable to use "^_not_a_valid_regex_" as a search parameter'

    # test for no variables in run()
    try:
        list(lookup.run(terms=['a_regex_that_will_always_match']))
    except AnsibleError as e:
        assert 'No variables available to search' in to_native(e)

# Generated at 2022-06-23 12:34:06.700108
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:34:10.593586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with not valid term
    terms = [1]
    try:
        LookupModule().run(terms)
        assert False
    except AnsibleError:
        pass

    # Test with valid term
    terms = ['.+']
    try:
        LookupModule().run(terms)
        assert True
    except AnsibleError:
        assert False

# Generated at 2022-06-23 12:34:18.738049
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()
    variables = {}
    lm = LookupModule(loader=None, variables=variables)
    lm.set_options(var_options=variables, direct={})

    terms = ['asdf','qwerty']
    ret = lm.run(terms, variables)
    assert ret == []

    variables['asdf'] = 1
    variables['qwerty'] = 2
    ret = lm.run(terms, variables)
    assert ret == ['asdf', 'qwerty']

# Generated at 2022-06-23 12:34:19.615485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:34:21.284048
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 12:34:25.051404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testvar = {'1': 'one', '2': 'two', '3': 'three', '4': 'four'}
    terms = ['1', '2', '3', '4']
    result = LookupModule().run(terms, testvar)
    assert result == terms

# Generated at 2022-06-23 12:34:38.124556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup for test
    lm = LookupModule()
    terms = ['^qz_', 'hello']
    variables = dict()
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'

# Generated at 2022-06-23 12:34:44.766330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={ 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert(set(lookup.run(['^qz_.+'])) == set(['qz_1', 'qz_2']))

# Generated at 2022-06-23 12:34:47.779818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor class LookupModule
    """

    lookup_module = LookupModule()
    my_data = 'Hello'

    assert lookup_module.run(terms, variable) == my_data

# Generated at 2022-06-23 12:34:54.713929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    display = Display()

    # Test with empty list
    test_obj = LookupModule()
    ret = test_obj.run([])
    assert(ret == [])

    # Test with single term
    ret = test_obj.run(['^qz_.+'], variables={'qz_1':'hi', 'qz_2':'there'})
    assert(ret == ['qz_1','qz_2'])

    # Test with multiple terms
    ret = test_obj.run(['^qz_.+', '.+_zone$'], variables={'qz_1':'hi', 'qz_2':'there', 'my_zone':'here'})
    assert(ret == ['qz_1','qz_2','my_zone'])

# Generated at 2022-06-23 12:35:05.304168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-23 12:35:06.271228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run([])

# Generated at 2022-06-23 12:35:12.169439
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms = ['^qz_']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    ret = lookup.run(terms, variables, **kwargs)
    assert ret == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-23 12:35:16.499511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    variables = dict(name='Test', env='dev', port='8080', ip=['10.0.0.1', '10.0.0.2', '10.0.0.3'])
    terms = ['p', '10.*', '.+_name$']

    actual = obj.run(terms, variables=variables)
    expected = ['port', 'name']

    assert sorted(expected) == sorted(actual)


# Generated at 2022-06-23 12:35:18.373102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 12:35:22.068508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid regex
    variables = {}
    terms = ['!@#$%^&*()']
    assert len(LookupModule(terms, variables).run(terms, variables).keys()) == 0

# Generated at 2022-06-23 12:35:24.506395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # initialize an instance of the LookupModule class
    obj = LookupModule()
    # test that the class is an instance of LookupBase
    assert isinstance(obj, LookupBase)

# Generated at 2022-06-23 12:35:26.750259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert('LookupModule' in globals())
    l = LookupModule()
    assert(l is not None)
    assert(isinstance(l, LookupModule))


# Generated at 2022-06-23 12:35:40.044975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    c = LookupModule()

    # test no variables returns empty list
    ret = c.run(["someregex", "anotherregex"])
    assert ret == [], "Expecting empty list since we don't provide variables"

    # test that we handle a regex that doesn't compile
    variables = dict()
    variables['foo'] = 'bar'
    variables['foobar'] = 'baz'
    variables['foobaz'] = 'baz'
    variables['bar'] = 'foo'
    variables['barfoo'] = 'foo'
    ret = c.run(["asdfa*(asdf", "bar"], variables=variables)
    assert ret == [], "Expecting empty list due to invalid regex"


    # test regex that does something
    ret = c.run(["foo.*"], variables=variables)
   

# Generated at 2022-06-23 12:35:41.239892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-23 12:35:53.481923
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import pytest

    with pytest.raises(AnsibleError, match="No variables available to search"):
        LookupModule().run(terms=["qz_"])

    with pytest.raises(AnsibleError, match="Invalid setting identifier"):
        LookupModule().run(terms=[5], variables=dict())

    with pytest.raises(AnsibleError, match="Unable to use.*as a search parameter"):
        LookupModule().run(terms=["[a-z"], variables=dict())

    variables = dict()
    variables['qz_1'] = "hello"
    variables['qz_2'] = "world"
    variables['qa_1'] = "I won't show"
    variables['qz_'] = "I won't show either"

    test_results = LookupModule

# Generated at 2022-06-23 12:36:04.634001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Passing an invalid term
    try:
        invalid_term = 1
        lookup.run(terms=[invalid_term], variables={})
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError was not raised for invalid term")

    # Passing a valid term, with variables
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = lookup.run(terms=terms, variables=variables)
    assert ret[0] in variables, "Returned value is not a valid key in dictionary variables"

# Generated at 2022-06-23 12:36:05.940810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:36:14.033068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.lookup.varnames import LookupModule
    from six import text_type

    # If terms is empty list, run() method should raise an exception
    lookup = LookupModule()
    lookup.set_options(direct={})
    variables = {'var1': 'foobar'}
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run([], variables=variables)
    assert 'No variable name specified' in to_text(excinfo.value)

    # If variables is None, run() method should raise an exception
    lookup = LookupModule()

# Generated at 2022-06-23 12:36:15.842990
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:36:26.850725
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameter terms is a list of strings to use as regular expressions to look up variables
    # Parameter variables is a dictionary of variables.
    # Upon successful return, the function returns the list of matching variables names found.
    # If a regular expression is invalid, the function throws an exception.
    # If variables is not provided, an exception is thrown.

    # Test 1
    # Unit test for method run with valid parameters.
    # Parameter terms contains a list of regular expressions to look up variables.
    # This test verifies that the function returns the list of variables matching the search parameters.

    terms = ['^qz_.+', '^qa_.+']

# Generated at 2022-06-23 12:36:31.702572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    variable_names = {'_ansible_verbose_always' : 'True', 'ansible_ssh_common_args' : ''}
    lookup_module.run(terms=['ansible_ssh_common_args'], variables=variable_names, **{})

# Generated at 2022-06-23 12:36:41.939016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # create the module object
    #
    lookup_module = LookupModule()

    # Defines the list of terms
    #
    terms = [ '^qz_.+', 'hosts' ]

    # Defines the variables
    #
    variables = { 'qz_1' : 'hello',
                  'qz_2' : 'world',
                  'qa_1' : "I won't show",
                  'qz_' : "I won't show either",
                  'mysql_hosts_name' : 'myhost',
                  'db_host' : "I won't show either" }
    
    # Defines the expected result
    #
    expected = [ 'qz_1', 'qz_2', 'mysql_hosts_name' ]
    
    # Method set_options
   

# Generated at 2022-06-23 12:36:52.062181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import PY3
    lookup = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    with pytest.raises(AnsibleError):
        lookup.run([], variables=None)

    with pytest.raises(AnsibleError):
        lookup.run(['1'], variables=variables)

    assert lookup.run(['^qz_.+'], variables=variables) == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-23 12:36:53.707244
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None

# Generated at 2022-06-23 12:37:01.240102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ test_LookupModule - Unit test for constructor of class LookupModule """
    # pylint: disable=redefined-outer-name

    lookup_module = LookupModule()
    terms = ['dummy']
    variables = {}

    # Test the constructor with valid data
    try:
        lookup_module = LookupModule()
        lookup_module.run(terms, variables)
    except Exception as err:
        print(err)
        assert False

    # Give an object as terms
    class DummyObject(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    terms = DummyObject()
    try:
        lookup_module.run(terms, variables)
        assert False
    except Exception:
        assert True

    # Give a integer as terms
    terms = 12345

# Generated at 2022-06-23 12:37:08.664317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_', '.+_location$']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'random_location': 'rndm_loc',
    }
    test = LookupModule()
    result = test.run(terms=terms, variables=variables)
    assert result == ['qz_1', 'qz_2', 'random_location']

# Generated at 2022-06-23 12:37:10.382667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 12:37:13.580554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert '_terms' in lookup_module.argument_spec
    assert '_terms' in lookup_module.required_one_of


# Generated at 2022-06-23 12:37:19.666048
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This is a test method to instantiate the LookupModule and test
    the methods.
    """

    # Create the LookupModule class
    x = LookupModule()

    # Create the terms and variables
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_2': 'I will not show'}

    # Call the run method
    y = x.run(terms, variables=variables)

    # Test the results
    assert y == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:37:28.013956
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    assert lookup_module.run(terms=['foo'], variables={'foo': 'bar'}) == ['foo']
    assert 'foo' in lookup_module.run(terms=['foo'], variables={'foo': 'bar', 'bar': 'foo'})

    exc = None
    try:
        lookup_module.run(terms=['foo'], variables={'foobar': 'foo'})
    except AnsibleError as e:
        exc = e

    assert exc is not None, "AnsibleError exception not raised"
    assert to_native(exc) == 'No variables available to search'



# Generated at 2022-06-23 12:37:37.665099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    test_vars = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }

    # Query is qz_*
    result = lookup_plugin.run(terms=['^qz_.+'], variables=test_vars)
    assert len(result) == 2
    assert 'qz_1' in result
    assert 'qz_2' in result

    # Query is all variables with _ in their name
    result = lookup_plugin.run(terms=['_'], variables=test_vars)
    assert len(result) == 4
    assert 'qz_1' in result

# Generated at 2022-06-23 12:37:47.098986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import inspect
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

# Generated at 2022-06-23 12:37:48.295182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a LookupModule object
    LookupModule('test')

# Generated at 2022-06-23 12:37:48.866358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:37:59.509277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Case 1: When no variables are provided
    try:
        lm.run(['test'])
        assert False, "Expected AnsibleError"
    except AnsibleError:
        pass

    # Case 2: When some variables are provided
    variables = dict(a=1, b=2, c=3)

    # Case 2.1: When the term is not a string
    try:
        lm.run([1], variables)
        assert False, "Expected AnsibleError"
    except AnsibleError:
        pass

    # Case 2.2: When the term is not a valid regex
    try:
        lm.run('*.a', variables)
        assert False, "Expected AnsibleError"
    except AnsibleError:
        pass

    # Case 2.3:

# Generated at 2022-06-23 12:38:09.912534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    varnames_lookup_module = LookupModule()
    variables = dict(qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either")
    ret_vars = varnames_lookup_module.run(terms=['^qz_.+'], variables=variables)
    assert ret_vars == ['qz_1', 'qz_2', 'qz_']

    ret_vars = varnames_lookup_module.run(terms=['.+'], variables=variables)
    assert ret_vars == list(variables.keys())

    ret_vars = varnames_lookup_module.run(terms=['hosts'], variables=variables)
    assert ret_vars == []

    ret_vars = var

# Generated at 2022-06-23 12:38:21.938832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    value = module.run(terms=["^qz_.+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    assert(value == ['qz_1', 'qz_2'])

    value = module.run(terms=[".+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    assert(sorted(value) == sorted(['qz_1', 'qz_2', 'qa_1', 'qz_']))


# Generated at 2022-06-23 12:38:28.154699
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'})
    assert result == ['qz_1', 'qz_2']

    result = LookupModule().run(['^qz_.+'], {})
    assert result == []

    result = LookupModule().run(['^qz_.+'], None)
    return result

# Generated at 2022-06-23 12:38:28.676445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:38:39.166168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    objectLookupModule = LookupModule()
    # test with valid value
    ret = objectLookupModule.run([".+_zone$", ".+_location$", ".+_ip$"], {"abc_zone": "abc_Zone", "abc_location": "abc_Location", "abc_ip": "abc_Ip"})
    assert(ret == ['abc_ip', 'abc_location', 'abc_zone'])
    # test with invalid value
    try:
        ret = objectLookupModule.run(["abc"], {"abc": "abc"})
    except Exception as e:
        assert(e.message == 'No variables available to search')


# Generated at 2022-06-23 12:38:40.063030
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    return lookup_plugin

# Generated at 2022-06-23 12:38:48.259211
# Unit test for constructor of class LookupModule
def test_LookupModule():
    
    # Constructor without exception
    try:
        LookupModule()
        print("[PASS] No exception in constructor")
    except Exception as e:
        print("[FAIL]: Exception in constructor: " + str(e))

    class Dummy:
        def run(self, terms, variables=None, **kwargs):
            return variables
        
    # Constructor without exception
    try:
        obj = Dummy()
        obj.set_options = LookupModule.set_options
        obj.run(None, None)
        print("[PASS] No exception in call to super class method set_options")
    except Exception as e:
        print("[FAIL]: Exception in call to super class method set_options: " + str(e))

    # Constructor without exception

# Generated at 2022-06-23 12:39:00.179904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Function to test methods of class LookupModule
    """
    lookup_instance = LookupModule()
    terms = ["^qz_.+"]
    variables = {
        "qz_1" : "hello",
        "qz_2" : "world",
        "qa_1" : "I won't show",
        "qz_"  : "I won't show either",
    }
    assert lookup_instance.run(terms=terms, variables=variables) == ['qz_1', 'qz_2']

    terms = [".+"]

# Generated at 2022-06-23 12:39:05.777283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '^qa_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won show',
        'qz_': 'I won show either'}
    lookup_mod = LookupModule()
    result = lookup_mod.run(terms, variables)
    assert isinstance(result, list)
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'qa_1' in result
    assert 'qz_' in result


# Generated at 2022-06-23 12:39:06.284208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:39:17.866293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import yaml
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    collection_dir = os.path.join(os.path.dirname(__file__), '../../../..')
    # AnsibleCollectionModuleCore is the name of the collection containing the lookup module we are testing.
    sys.path.insert(0, os.path.join(collection_dir, 'AnsibleCollectionModuleCore'))
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible_collections.ansible.community.plugins.lookup.varnames import LookupModule

    # Mock the results of get_options() call in AnsibleLoader
   

# Generated at 2022-06-23 12:39:25.384056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_native
    import pytest


# Generated at 2022-06-23 12:39:26.372729
# Unit test for constructor of class LookupModule
def test_LookupModule():
  LookupModule()

# Generated at 2022-06-23 12:39:32.779514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_class = LookupModule
    vars = {'a': 1, 'b': 2, 'c': 3, 'ab': 4, 'bc': 5, 'aa': 6, 'bb': 7, 'cc': 8}
    terms = ['a.*']
    kwargs = {}
    module = module_class()
    assert sorted(module.run(terms, vars, **kwargs)) == sorted(['a', 'aa', 'ab'])


# Generated at 2022-06-23 12:39:34.498228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #test constructor
    aLookupModule = LookupModule()

    #test other methods
    assert aLookupModule != None
    

# Generated at 2022-06-23 12:39:45.337399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test error handling
    def test_exception(terms, variables=None, **kwargs):
        lookup_obj = LookupModule()
        lookup_obj.run(terms, variables, **kwargs)

    # Test normal operation
    def test_normal(terms, variables=None, **kwargs):
        lookup_obj = LookupModule()
        ret = lookup_obj.run(terms, variables, **kwargs)
        return ret

    # Test calling the method with no terms
    terms = []
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = []
    assert test_normal(terms, variables) == result

    # Test calling the method with none terms
    terms = None


# Generated at 2022-06-23 12:39:54.360383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    d = dict(A="1", B="2")
    # run - term is not a string
    lookup = LookupModule()
    terms = ["A"]
    try:
        lookup.run(terms, variables=d)
        assert False, "Expected error"
    except AnsibleError:
        assert True
    # run - term is not a valid regex
    try:
        lookup.run(["(A"], variables=d)
        assert False, "Expected error"
    except AnsibleError:
        assert True
    # run - term not in dictionary
    assert lookup.run(["^.+_x$"], variables=d) == []
    # run - term in dictionary
    assert lookup.run(["^.+_A$"], variables=d) == ["A"]
    # run - 2 terms, only 2nd matches


# Generated at 2022-06-23 12:39:55.256641
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:40:03.405445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [
        '^qz_.+',
        '.+',
        'hosts',
        '.+_zone$',
        '.+_location$',
    ]
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'zone_1': 'US',
        'zone_2': 'IN',
        'region_1': 'US-WEST',
        'region_2': 'US-EAST',
    }

# Generated at 2022-06-23 12:40:10.849267
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myVars = { 'a':123, 'b':456, 'snippet':'foo', 'name':'xyz', 'var_1':'foo2', 'var-2':'bar2' }
    myTerms = [ 'a', 'name', 'snippet', 'var.+' ]
    myKwargs = { '_terms': myTerms }
    myLookupModule = LookupModule()
    assert myLookupModule.run(terms=myTerms, variables=myVars, **myKwargs) == ['a', 'name', 'snippet', 'var_1', 'var-2']

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:40:12.563383
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule().run()
    assert result == []

# Generated at 2022-06-23 12:40:24.200675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['^qz_.+'], {}, qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either") == ['qz_1', 'qz_2']
    assert LookupModule().run(['.+'], {}, qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either") == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-23 12:40:25.993375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-23 12:40:28.938456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test Construction
    try:
        mod = LookupModule()
    except Exception as e:
        assert False
    else:
        assert isinstance(mod, LookupModule)

# Unit test to test the run method of class LookupModule

# Generated at 2022-06-23 12:40:36.783136
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for construction of LookupModule class.
    """
    print("Testing creation of instance of LookupModule")
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup.run(terms, variables)


if __name__ == '__main__':
    # Testing example
    test_LookupModule()
    print('\n')
    print('Testing with examples')
    lookup = LookupModule()
    terms = [('^qz_.+','qz_')]

# Generated at 2022-06-23 12:40:43.343043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader(None)
    l.set_options({'_ansible_check_mode':True})
    my_variables = {'object_1':'foo', 'object_2':'bar', 'object_3':'baz'}
    assert l.run(['object_1'], variables=my_variables) == ['object_1']
    assert l.run(['object_1', 'object_2'], variables=my_variables) == ['object_1', 'object_2']

# Generated at 2022-06-23 12:40:43.942977
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:40:46.158768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert isinstance(lookup_class, LookupModule)

# Generated at 2022-06-23 12:40:47.545695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:40:56.757621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = [ 'xyz.', 'test_' ]
    variables = { 'test_2' : 'test2', 'xyz.123' : 'xyz.123' }

    # Test with first argument (terms)
    try:
        ret = LookupModule().run(terms, variables)
    except:
        raise Exception('Argument "terms" does not work')

    # Test with second argument (variables)
    try:
        ret = LookupModule().run(terms, None)
        raise Exception('Argument "variables" is not validated')
    except:
        pass
    try:
        ret = LookupModule().run(terms, "")
        raise Exception('Argument "variables" is not validated')
    except:
        pass