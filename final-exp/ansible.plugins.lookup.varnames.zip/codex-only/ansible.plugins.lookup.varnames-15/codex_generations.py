

# Generated at 2022-06-23 12:30:55.070991
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:31:00.548124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Arrange
    lookup_module = LookupModule()
    
    # Act
    ret = lookup_module.run(terms=["!@#$%^&*()"], variables={"!@#$%^&*()": "abcdefghijklmnopqrstuvwxyz"})
    
    # Assert
    assert ret == ["!@#$%^&*()"]

# Generated at 2022-06-23 12:31:09.537486
# Unit test for constructor of class LookupModule
def test_LookupModule():

    sample_obj = LookupModule()

    if not sample_obj.run(terms=["one","second"], variables={"one":"Sample_Var"}):
        print("Passed 0")

    if not sample_obj.run(terms=["sample_var"], variables={"sample_var":"Sample_Var"}):
        print("Passed 1")

    if sample_obj.run(terms=["third"], variables={"sample_var":"Sample_Var"}):
        print("Failed 2")

    if sample_obj.run(terms=["sample_var", "third"], variables={"sample_var":"Sample_Var"}):
        print("Failed 3")

# Generated at 2022-06-23 12:31:13.551603
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    test_terms = ['abc', 'def', 'xyz']
    test_variables = {'abc': 'test'}
    lu.run(test_terms, test_variables)


# Generated at 2022-06-23 12:31:14.338358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:31:14.725931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:31:15.644097
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:31:24.486930
# Unit test for constructor of class LookupModule
def test_LookupModule():

    values = {
        'abc': 5,
        'def': 'hello',
        'test': [1, 2, 3],
        '_ignore': True,
    }

    # Create instance of LookupModule
    lookup_module = LookupModule()
    values['__lookup__'] = lookup_module

    # Create list of regexes to search for
    search_list = ['_ignore', 'test']

    # Run LookupModule.run()
    ret = lookup_module.run(search_list, values)

    # Check returned values
    assert ret == ['test'], "Unexpected results."

    # Check that variables have not changed

# Generated at 2022-06-23 12:31:35.246623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.parsing.vault import VaultLib

    lookup = LookupModule()
    assert(lookup != None)
    lookup.set_options({'vault_password': 'dummy', '_ansible_vault_password': 'dummy'})

    vars = {
        'hello': 1,
        'world': 'string',
        'vars': {'x': 'y'},
        'list': [1, 2, 3],
    }

    terms = ['world']
    result = lookup.run(terms, vars)
    assert(result == ['world'])

    terms = ['world$']
    result = lookup.run(terms, vars)
    assert(result == ['world'])



# Generated at 2022-06-23 12:31:37.216368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:31:44.110436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a lookup module object
    lookup = LookupModule()
    # Create test variables
    variables = {'test_var': 'hello', 'test_var_2': 'world'}
    # Method run returns a list
    ret = lookup.run(terms=['.+'], variables=variables)

    # Test list returned
    assert 'test_var' in ret
    assert 'test_var_2' in ret
    assert len(ret) is 2

# Generated at 2022-06-23 12:31:45.408251
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)

# Generated at 2022-06-23 12:31:46.768369
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.run(terms=[])

# Generated at 2022-06-23 12:31:48.057432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:31:48.962003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result != None

# Generated at 2022-06-23 12:32:00.321658
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_list_invalid = [ None, 42, [ 'qz_1', None, 'qz_2', 'qz_3']]
    terms_list_valid = [[ '^qz_.+'], ['^qz_.+', '^qz_.+'], [ '^qz_z.+', '^qz_.+'], ['^.+$']]
    variables_dict = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # initialize lookup object with cache
    lookup_obj = LookupModule()

    # test invalid terms

# Generated at 2022-06-23 12:32:01.583562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:32:11.003246
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    inventory_vars = {
        'var1': 'hello',
        'var2': 'world',
        'var3': 'ciao',
        'var4': 'mondo',
        'var5': 'hola',
        'var6': 'mundo'
    }

    lookup = LookupModule()

    assert sorted(lookup.run(['^va.*'], inventory_vars)) == sorted(list(inventory_vars.keys()))
    assert sorted(lookup.run(['^var[1-3]$'], inventory_vars)) == sorted(list(['var1', 'var2', 'var3']))

# Generated at 2022-06-23 12:32:11.979473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 12:32:18.907674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Loads the raw string direct from the lookup plugin.
    # This works if the test is located inside the same folder as the lookup plugin.
    with open('varnames.py') as f:
        raw = f.read()

    # Creates a class object
    lookup = LookupModule(loader=None, basedir=None, **raw)

    # Assert that the class has the correct variables
    assert type(lookup.options).__name__ == 'dict'
    assert type(lookup._file_cache).__name__ == 'dict'
    assert type(lookup.run).__name__ == 'instancemethod'

# Generated at 2022-06-23 12:32:28.432470
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()

    my_vars = dict(qz_1='hello',
                   qz_2='world',
                   qa_1="I won't show",
                   qz_="I won't show either")

    assert set(lookup_plugin.run(['^qz_.+'], variables=my_vars)) == set(['qz_1', 'qz_2'])

    assert set(lookup_plugin.run(['.+'], variables=my_vars)) == set(['qz_1', 'qz_2', 'qa_1', 'qz_'])

    assert set(lookup_plugin.run(['hosts'], variables=my_vars)) == set()


# Generated at 2022-06-23 12:32:30.749218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' Unit test for the constructor of the class LookupModule '''

    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:32:40.953029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Test vars lookup module method run """
    lm = LookupModule()
    lm.set_options(direct={'_terms': ['^qz_.+', '.*_location$']})
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'true_location': 'showme', 'false_location': 'dontshowme'}
    result = lm.run(terms=[], variables=vars)
    assert result == []
    result = lm.run(terms=['some_string'], variables=vars)
    assert result == []
    result = lm.run(terms=['^qz_.+'], variables=vars)

# Generated at 2022-06-23 12:32:51.149318
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test AnsibleError when variables is None
    try:
        lookup_module = LookupModule()
        lookup_module.run(terms=[], variables=None)
        assert False
    except AnsibleError as error:
        assert str(error) == 'No variables available to search'
        
    # Test AnsibleError when term is not of string type
    try:
        lookup_module = LookupModule()
        lookup_module.run(terms=[(1, 2)], variables={})
        assert False
    except AnsibleError as error:
        assert str(error) == 'Invalid setting identifier, "(1, 2)" is not a string, it is a <class \'tuple\'>'
        
    # Test AnsibleError when term is not a valid regular expression

# Generated at 2022-06-23 12:32:51.697621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:33:01.187275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    from ansible.plugins.lookup import LookupModule, LookupBase
    l = LookupModule()
    l.set_loader = mock.MagicMock()
    l.set_options = mock.MagicMock()
    l.set_loader.load_from_file = mock.MagicMock()
    l.set_options.get_basedir = mock.MagicMock()
    terms = []
    terms.append("^test_pattern")
    variables = {}
    variables['test_pattern1'] = ""
    variables['test_pattern2'] = ""

    # Exercise
    result = l.run(terms=terms, variables=variables)

    # Verify
    assert(result[0] == 'test_pattern1')
    assert(result[1] == 'test_pattern2')

# Generated at 2022-06-23 12:33:02.494738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test that LookupModule constructor gets created successfully
    testLookupModule = LookupModule()
    assert isinstance(testLookupModule, LookupModule)

# Generated at 2022-06-23 12:33:03.264186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, "run")

# Generated at 2022-06-23 12:33:10.572376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests invalid types
    assert LookupModule().run(["term"]).pop() == "term"
    assert LookupModule().run([1]).pop() == "1"

    # Tests invalid regex
    try:
        assert LookupModule().run(["("])
    except Exception as e:
        assert 'Unable to use "(", it is a invalid regex' == to_native(e)

    # Tests regex search, it is ok if the regex match all variables
    # so in this case ["^test.*"]
    assert LookupModule().run(["^test.*"]).pop() == "test_regex"

    # The regex search must be in the variable name
    assert LookupModule().run(["4"]) == []

    # The regex search must be in the variable name
    assert LookupModule().run(["test"]).pop

# Generated at 2022-06-23 12:33:11.980360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print(e)


# Generated at 2022-06-23 12:33:21.160108
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class AnsibleMock(object):

        def __init__(self, error_msg=None, variables=None, **kwargs):
            self.error_msg = error_msg
            self.variables = variables
            self.kwargs = kwargs

        def __getattr__(self, attr):
            if self.error_msg is not None:
                self.fail_json(msg=self.error_msg)

            if attr == 'params':
                try:
                    return self.kwargs['params']
                except KeyError:
                    return None


# Generated at 2022-06-23 12:33:22.277909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule
    """
    assert 1

# Generated at 2022-06-23 12:33:28.906503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native

    host_group_1 = 'zones-1'
    host_group_2 = 'zones-2'
    host_group_3 = 'zones-3'
    host_group_4 = 'zones-4'
    host_group_5 = 'zones-5'
    host_group_6 = 'zones-6'
    host_group_7 = 'zones-7'
    host_group_8 = 'zones-8'
    host_group_9

# Generated at 2022-06-23 12:33:34.692704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = ['^qz_.+']
    variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = ['qz_1', 'qz_2']
    assert l.run(terms, variables=variables) == result

# Generated at 2022-06-23 12:33:46.402790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test
    ############

    # Create a mock module
    mock_module = AnsibleMockModule()
    fake_vars = {
        "test_var": True,
        "test_var_1": True,
        "test_var_2": True,
        "test_var_3": True,
        "test_var_4": True,
        "test_var_5": True,
        "test_var_6": True,
        "other_var_1": True,
        "other_var_2": True,
        "not_interesting": True,
        "really_not_interesting": True
    }

    # Create a mock finder to supply data to the lookup module
    mock_finder = AnsibleMockFinder()

# Generated at 2022-06-23 12:33:47.252764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule) == 3

# Generated at 2022-06-23 12:33:49.023438
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run'), "run not found"

# Generated at 2022-06-23 12:34:00.277463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    lookup_base = LookupBase()

    if not PY2:
        # Python 2 inspect.getargspec is deprecated in Python 3
        # Python 3.0 and 3.1 won't work with the test case
        # Python 3.2 has a problem with inspect.signature
        # This is done to ensure this test case works for Python 3.2 and above
        import sys
        model = sys.version_info

        if (model[0] == 3 and model[1] >= 2):
            import inspect
            signature = inspect.signature(lookup_base.run)
            assert len(signature.parameters) == 3
            assert 'variables' in signature.parameters

# Generated at 2022-06-23 12:34:04.617283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.var_names import LookupModule
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:34:06.006784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:34:13.816377
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create LookupModule object to test
    obj = LookupModule()

    # Get the currect lookup path
    lookup_path = obj._loader._get_paths()

    # Test the to_native function
    obj._low_level_execute_command('echo', 'test', '-i', '/bin/sh', lookup_path, False)
    assert isinstance(obj._low_level_execute_command('echo', 'test', '-i', '/bin/sh', lookup_path, False), string_types)

    # Test the 'run' function
    # Create a test list
    test_list = ['1','2','3']
    # Test if exception is raised
    try:
        obj.run(terms=test_list)
        assert False
    except:
        assert True
    # Test with empty variable list
    assert obj

# Generated at 2022-06-23 12:34:14.931902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    return

# Generated at 2022-06-23 12:34:17.064736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin, "__init__() should return instance"

# Generated at 2022-06-23 12:34:26.597765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    vars = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }

    test_terms = [
        ["^qz_.+"],
        [".+"]
    ]

    result_terms = [
        ["qz_1","qz_2"], 
        ["qa_1","qz_","qz_1","qz_2"]
    ]

    for i, terms in enumerate(test_terms):
        result = lookup.run(terms, variables=vars)
        assert result == result_terms[i]

# Generated at 2022-06-23 12:34:38.697301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_mgr = VariableManager(loader=loader)
    lu = LookupModule()
    lu._templar = None  # This is a hack. Need to modify the LookupModule class to not need this
    lu.set_options(var_options=dict(test_var1='hello', test_var2='world', test_var3='not found'), direct=dict())

    # Check the variable names when the terms is a string list
    terms = ['^test_.+?', '^test_.+']

# Generated at 2022-06-23 12:34:40.277209
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Assert that an object of type LookupModule can be instantiated
    assert LookupModule() is not None

# Generated at 2022-06-23 12:34:51.438028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import merge_hash

    context = PlayContext()
    context.vars = VariableManager()
    context.vars.extend(merge_hash({'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}))
    lm = LookupModule()
    lm.set_options(var_options=context.vars, direct=merge_hash({'myvar': 'myvalue'}))
    assert lm.run(['^qz_.+'], context.vars) == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-23 12:35:03.300125
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:35:04.760701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Assert that LookupModule sets options for variables
    assert lookup.var_options

# Generated at 2022-06-23 12:35:10.209649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}
    lookup = LookupModule()
    assert lookup.run(terms, variables) == ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-23 12:35:18.522623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = module.run(terms, variables)
    assert result == ['qz_1', 'qz_2', 'qz_']
    terms = ['^qz_.+', '^qa_.+']
    result = module.run(terms, variables)
    assert result == ['qz_1', 'qz_2', 'qz_', 'qa_1']
    terms = ['^qz_.+', '^qa_.+', '^ab_.+']

# Generated at 2022-06-23 12:35:21.136580
# Unit test for constructor of class LookupModule
def test_LookupModule():
  result = LookupModule()
  assert result
  assert result.name == "varnames"

# Generated at 2022-06-23 12:35:22.028206
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule))

# Generated at 2022-06-23 12:35:30.292525
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ### Normal run tests
    # Setup
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    # Perform test
    lm = LookupModule()
    try:
        result = lm.run(terms, variables)
    except Exception as e:
        print(to_native(e))
        assert False, "Unexpected Exception"

    # Verify result
    assert result == ['qz_1', 'qz_2'], "Unexpected result: %s" % result


    ### Bad input tests
    # Terms is a list but not a list of strings

# Generated at 2022-06-23 12:35:39.581438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    try:
        results = LookupModule().run(terms=['^qz_.+'], variables=test_vars)
    except AnsibleError as e:
        raise AssertionError('Unexpected AnsibleError raised: %s' % to_native(e))
    assert results == ['qz_1', 'qz_2'], 'Unexpected results returned'

# Generated at 2022-06-23 12:35:45.970482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Standard behaviour
    module = LookupModule()
    assert isinstance(module, LookupModule)

    # Non string input
    try:
        module = LookupModule(123)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert e.args[0] == 'Invalid setting identifier, "123" is not a string, it is a %s' % type(123)

# Generated at 2022-06-23 12:35:49.856812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run('^qz_.+', {'qz_1': 'hello', 'qz_2': 'world'}) == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:35:58.318740
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ## Test module with one term
    # Test assertion where vars is not a dict
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(['password'])
        assert False
    except AnsibleError as e:
        assert "No variables available to search" in e.message
    # Test assertion where term is not a string (Tuple)
    variables = {'test_var' : 'test_value'}
    lookup_obj.set_options({'var_options' : variables, 'direct' : {}})
    try:
        lookup_obj.run([('password',)])
        assert False
    except AnsibleError as e:
        assert "Invalid setting identifier" in e.message
    # Test assertion where term is not a string (Int)

# Generated at 2022-06-23 12:36:02.913290
# Unit test for constructor of class LookupModule
def test_LookupModule():
    looker = LookupModule()
    looker.set_options(var_options={'vars': {'test': 'test1', 'test2': 'test2'}})
    assert type(looker.get_option('vars')['test']) == str

# Generated at 2022-06-23 12:36:03.527367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 12:36:12.671019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    my_vars = {
            'myfoo': { 'bar': 'baz', 'foo_zone': 'hello', },
            'qz_host': { 'bar': 'baz', 'foo_location': 'world', }
            }

    # Unquoted term
    my_terms = [ 'myfoo' ]
    assert lookup.run(terms=my_terms, variables=my_vars) == my_terms

    # Quoted term
    my_terms = ['qz_host']
    assert lookup.run(terms=my_terms, variables=my_vars) == my_terms

    # Invalid regexp
#   my_terms = [ 'my[foo' ]
#   lookup.run(terms=my_terms, variables=my_vars)

    # Unquoted pattern


# Generated at 2022-06-23 12:36:14.415362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    try:
        lookup.run(terms=[])
    except Exception as e:
        assert ('No variables available to search' in str(e))

# Generated at 2022-06-23 12:36:15.466077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert lk

# Generated at 2022-06-23 12:36:22.625531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    test_lookup.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:36:33.874859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    module = AnsibleModule(
        argument_spec = dict(
            _raw_params = dict(type='list', required=True),
            _ansible_variables = dict(type='dict', required=False, default=dict()),
        ),
        supports_check_mode=True,
    )

    lookup_plugin = LookupModule()

    # Prepare the variables argument
    variable_name_1 = 'variable_1'
    variable_name_2 = 'variable_2'
    variable_value_1 = 'value_1'
    variable_value_2 = 'value_2'
    variable_value_3 = 'value_3'
    variable_value_4 = 'value_4'

# Generated at 2022-06-23 12:36:39.375991
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    terms = [re.compile('^qz_.+')]
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}

    # Act
    result = LookupModule().run(terms, variables)

    # Assert
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:36:48.694754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # the code in the rest of this function is a simplified version of
    # https://github.com/ansible/ansible/pull/47196
    # which was fixed in Ansible 2.9
    def __new__(cls, *args, **kwargs):
        self = object.__new__(cls)
        self.__dict__.update(kwargs)
        return self

    LookupModule.__new__ = __new__
    lookup_instance = LookupModule(
        loader=None,
        paths=None,
    )

    # because of https://github.com/ansible/ansible/pull/47196
    # lookup_instance.get_basedir is now a method, not an attribute
    # so we create a stub here
    def get_basedir():
        return None

    lookup_instance.get

# Generated at 2022-06-23 12:36:50.493953
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert isinstance(my_lookup, LookupModule)

# Generated at 2022-06-23 12:36:51.264887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:36:58.631697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method 'run' of class LookupModule"""
    # Define all inputs and outputs
    lookup_module = LookupModule()
    terms = ['qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}

    # Define expected output
    expected = ['qz_1', 'qz_2']

    # Run test
    actual = lookup_module.run(terms, variables, **kwargs)

    # Check if actual and expected are equal
    assert actual == expected

# Generated at 2022-06-23 12:37:08.472984
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check invalid arguments
    lookup_instance = LookupModule()
    try:
        lookup_instance.run(terms=None, variables=None)
    except AnsibleError as e:
        assert "No variables" in str(e)

    # Check invalid setting identifier
    lookup_instance = LookupModule()
    try:
        lookup_instance.run(terms=[None], variables={})
    except AnsibleError as e:
        assert "Invalid setting identifier" in str(e)

    # Check invalid regex
    lookup_instance = LookupModule()
    try:
        lookup_instance.run(terms=['('], variables={})
    except AnsibleError as e:
        assert "Unable to use" in str(e)

# Generated at 2022-06-23 12:37:12.853276
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert 'lookup_plugin.varnames' == mod.__class__.__module__
    assert 'varnames' == mod.__class__.__name__
    assert [] == mod.options



# Generated at 2022-06-23 12:37:20.951571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    variables = {"test1":"", "test2":"", "test3":"", "test4":"", "test5":""}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct={})
    result = lookup_module.run(["^test1$", "^test2$", "^test3$", "^test4$", "^test5$", "^test6$"], variables)
    assert result[0] == "test1"
    assert result[1] == "test2"
    assert result[2] == "test3"
    assert result[3] == "test4"
    assert result[4] == "test5"
    assert len(result) == 5

# Generated at 2022-06-23 12:37:29.915466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'foo': 1, 'bar': 2, 'baz': 3, 'qux': 4, 'quux': 5}

    lookup.run(terms=['foo'], variables=variables)
    assert ['foo'] == lookup.run(terms=['foo'], variables=variables)

    lookup.run(terms=['baz'], variables=variables)
    assert ['baz'] == lookup.run(terms=['baz'], variables=variables)

    lookup.run(terms=['^.*ux$'], variables=variables)
    assert ['qux', 'quux'] == lookup.run(terms=['^.*ux$'], variables=variables)

# Generated at 2022-06-23 12:37:38.630017
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Test with no variables
    try:
        lookup_module.run(['myvar'])
        assert False, 'Should have thrown an exception'
    except AnsibleError as e:
        assert "No variables available to search" in e.args[0]

    # Test with valid variable
    assert lookup_module.run(['myvar'], dict(myvar="hello")) == ['myvar']

    # Test with non-string as term
    try:
        lookup_module.run([5], dict(myvar="hello"))
        assert False, 'Should have thrown an exception'
    except AnsibleError as e:
        assert "Invalid setting identifier, \"5\" is not a string" in e.args[0]

    # Test with regular expression errors

# Generated at 2022-06-23 12:37:40.398267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run(['hello'])
    assert ret == []

# Generated at 2022-06-23 12:37:47.173588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['key1']) == []
    assert LookupModule().run(terms=['key1'], variables={'key1':'value1'}) == ['key1']
    assert LookupModule().run(terms=['key.*'], variables={'key1':'value1', 'key2':'value2'}) == ['key1', 'key2']
    assert LookupModule().run(terms=['key1', 'key.*'], variables={'key1':'value1', 'key2':'value2'}) == ['key1', 'key2']

# Generated at 2022-06-23 12:37:55.240391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize LookupModule object
    lookup_module = LookupModule()

    # Check all possible cases
    assert lookup_module.run(terms=['a']) == []
    assert lookup_module.run(terms=['a'], variables={'a': '1', 'b':'1'}) == ['a']
    assert lookup_module.run(terms=['a'], variables={'a': '1', 'b':'1'}) == ['a']
    assert lookup_module.run(terms=['a'], variables={'a': '1', 'b':'1'}) == ['a']

# Generated at 2022-06-23 12:37:55.779914
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:38:06.716463
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    python_vnames = __import__('python_vnames')
    python_vnames_dir = dir(python_vnames)

    varnames = LookupModule()
    ret = varnames.run(terms=['^qz_.+'], variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    })
    assert ret == ['qz_1', 'qz_2']

    ret = varnames.run(terms=['.+'], variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    })

# Generated at 2022-06-23 12:38:12.005871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    variables = {'test_variable': True, 'variable_1': 'test_test', 'variable_2': 'test'}
    terms = ['test_?ariable', '^var.+_1$']
    assert module.run(terms, variables) == [u'test_variable', u'variable_1'], 'LookupModule._run: should return list of matching variable names'

# Generated at 2022-06-23 12:38:23.519299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # lookup_plugin = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_value = ['qz_1', 'qz_2']
    assert len(lookup_plugin.run(terms, variables)) == len(expected_value), \
           'Expected value: %s , Actual value: %s' \
           % (expected_value, lookup_plugin.run(terms, variables))

# Generated at 2022-06-23 12:38:31.110754
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_instance = LookupModule()
    # As assert_raises doesn't work with py27, we use a try except block
    try:
        lookup_instance.run(terms='abc')
        assert False, "AnsibleError was expected"
    except AnsibleError as e:
        assert "No variables available to search" in to_native(e)

    mocked_variables = {'a': 1, 'b': 2, 'c': 3}
    ret = lookup_instance.run(terms='a', variables=mocked_variables)
    assert len(ret) == 1 and 'a' in ret
    ret = lookup_instance.run(terms='a|b', variables=mocked_variables)
    assert len(ret) == 2 and 'a' in ret and 'b' in ret
    ret = lookup_instance.run

# Generated at 2022-06-23 12:38:32.651121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'hello': 'foo', 'world': 'bar'}
    term = ['hello', 'world']
    result = lookup.run(terms=term, variables=variables)
    assert result == term

# Generated at 2022-06-23 12:38:44.064103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.dl = {}
            self.ba = {}
            self.task_vars = {}
            self.dep_chain = []
            self.static = True
            self.module_vars = {}
            self.tmpdir = None
            self.paths = []
            self.basedir = None
            self.content = None
            self.backup_name = None
            self.no_log = []

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs.get('msg'))

    import __builtin__
    __builtin__.__dict__['__salt__'] = None
    __builtin__.__dict__['__grains__'] = {}
    __builtin__

# Generated at 2022-06-23 12:38:49.257085
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = {
        'ansible_facts': {
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': 'I won\'t show',
            'qz_': 'I won\'t show either'
        }
    }

    lookup = LookupModule()
    lookup.run(['^qz_.+'], variables=module)

# Generated at 2022-06-23 12:38:58.141219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    LookupModule = lookup_loader.get('varnames', class_only=True)
    lookup_obj = LookupModule()
    result = lookup_obj.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2'], 'LookupModule.run() failed to find variables starting with qz_'

# Generated at 2022-06-23 12:39:07.738214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Given a list of variable names and a dictionary of variables, return
    the list of variable names that match the regular expressions given
    to the run method."""

    def run_module(terms, variables):
        """Helper function to run the module function under test
        and set up variables."""
        lm = LookupModule()
        lm._options = {}
        lm.set_options(var_options=variables, direct={})
        return lm.run(terms=terms, variables=variables)


# Generated at 2022-06-23 12:39:10.299305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, dict(), dict()).run(
        term='term'
    ) == []

# Generated at 2022-06-23 12:39:13.801156
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Create the object by instantiating the class
    lookup_module_obj = LookupModule()
    assert lookup_module_obj is not None, "LookupModule object not created"


# Generated at 2022-06-23 12:39:19.296422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert look.run(terms, variables) == ['qz_1', 'qz_2']

    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']

# Generated at 2022-06-23 12:39:20.414615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 12:39:32.003219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that it raises error when variables is None
    lookup_module = LookupModule()
    variables = None
    terms = ['.']
    try:
        lookup_module.run(terms, variables)
    except Exception as e:
        assert type(e) == AnsibleError
  
    # Test that it does not raise error when variables is not None
    variables = {'a': 1, 'b': 2, 'c': 3}
    lookup_module.run(terms, variables)
  
    # Test that it returns a list for a valid regular expression
    ret = lookup_module.run(terms, variables)
    assert type(ret) == list
  
    # Test that it returns a list of correct size for valid terms list
    terms = ['.']
    ret = lookup_module.run(terms, variables)

# Generated at 2022-06-23 12:39:34.089785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class_test = LookupModule()
    assert class_test.run(terms=['test.+']) == []
    assert class_test.run(terms=['master'], variables={}) == []



# Generated at 2022-06-23 12:39:44.916849
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # pylint: disable=protected-access,import-error
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.module_utils._text import to_native

    # test for empty dict (no variables)
    lookup = LookupModule()
    try:
        lookup.run(terms=["test"])
    except AnsibleError as e:
        assert 'No variables available to search' in to_native(e)

    # test invalid term
    lookup = LookupModule()
    try:
        lookup.run(terms=[1], variables={"test": "test"})
    except AnsibleError as e:
        assert "Invalid setting identifier, \"1\" is not a string, it is a <class 'int'>" in to_native(e)

    # test invalid regex pattern
    lookup = Look

# Generated at 2022-06-23 12:39:45.994736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:39:55.469629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'vars': {'qz_1':'hello',
                                                 'qz_2':'world',
                                                 'qa_1':"I won't show",
                                                 'qz_':"I won't show either"}})

    # Method run of class LookupModule
    # should return empty list for non string term
    non_string_term = 1
    result = lookup_instance.run([non_string_term])
    assert result == []

    term = '^qz_.+'
    result = lookup_instance.run([term])
    assert result == ['qz_2', 'qz_1']

    term = '.+'
    result = lookup_instance.run([term])

# Generated at 2022-06-23 12:40:06.435537
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms = ['^qz_.+', '.+_zone$', '.+_location$']

    vars = {
        'foo': 'bar',
        'baz': 'quux',
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'something_zone': '',
        'something_location': '',
        'something_else': '',
    }

    result = lookup.run(terms, variables=vars, **{})

    assert set(result) == set(['qz_1', 'qz_2', 'something_zone', 'something_location'])



# Generated at 2022-06-23 12:40:12.478947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = '^qz_.+'
    ret1 = LookupModule(None, variables=variables).run(terms=terms)
    print('ret1 = ', ret1)
    assert ret1 == ['qz_1', 'qz_2']

    # Test 2
    terms = '.+'
    ret2 = LookupModule(None, variables=variables).run(terms=terms)
    print('ret2 = ', ret2)
    assert ret2 == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    # Test 3
    terms = 'hosts'


# Generated at 2022-06-23 12:40:24.152706
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class FakeVariableManager(object):

        def __init__(self):

            self.variable_manager = dict(
                var1='',
                var2='',
                var3='',
                var4=''
            )

        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=True):
            return dict(self.variable_manager)

        @staticmethod
        def _get_hostvars():
            return dict()

    class FakeDisplay(object):

        def deprecate(self, *args, **kwargs):
            pass

    lookup_plugin = LookupModule()
    lookup_plugin._display = FakeDisplay()

    variable_manager = FakeVariableManager()
    lookup_plugin.set_loader(variable_manager)

    # Test variable name is not

# Generated at 2022-06-23 12:40:29.674030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert "ansible_path" in module.run(
        terms=[
            'ansible_path'
        ],
        variables={
            'ansible_path': '/home/user/.local/bin:/home/user/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
        }
    )


# Generated at 2022-06-23 12:40:37.362416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(sys.modules[__name__].__file__), '../..'))
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.common._collections_compat import MutableMapping
    import json, os

    basic._ANSIBLE_ARGS = json.loads(to_bytes(os.environ['ANSIBLE_MODULE_ARGS']))

    print(basic._ANSIBLE_ARGS)


# Generated at 2022-06-23 12:40:45.943452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest


# Generated at 2022-06-23 12:40:55.581898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    map = {'a': 1, 'b': 2, 'c': 3}