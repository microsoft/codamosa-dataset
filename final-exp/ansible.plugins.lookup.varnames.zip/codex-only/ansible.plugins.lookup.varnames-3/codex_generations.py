

# Generated at 2022-06-23 12:30:58.341119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global_variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    lookup_obj = LookupModule()
    assert lookup_obj.run(['^qz_.+'], global_variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:31:09.792761
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Expected to return only one value
    lookup = LookupModule()
    result = lookup.run(['.+_zone$'], {
        'zone_1': 'abc',
        'zone_2': 'abcd',
        'location_1': 'abcd',
        'location_2': 'abcde',
        'region_1': 'abcd',
        'region_2': 'abcde',
    })

    assert(result == ['zone_1', 'zone_2'])

    # Expected to return two values

# Generated at 2022-06-23 12:31:20.718059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor import task_queue_manager

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 1
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.diff = False



# Generated at 2022-06-23 12:31:21.273873
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 12:31:30.751674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test run method with no parameters
    module = LookupModule()
    try:
        module.run(None, None)
        assert False
    except AnsibleError as e:
        assert True

    # test run method with invalid parameters
    module = LookupModule()
    try:
        module.run([1], {'test1': 'test1'})
        assert False
    except AnsibleError as e:
        assert True

    # test run method with valid parameters
    module = LookupModule()
    module.run(['^qz_.+'], {'qz_1': 123, 'qz_2': '456', 'qa_1': 123})

# Generated at 2022-06-23 12:31:32.506214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("testing constructor of class LookupModule")
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:31:37.025505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_module = LookupModule()
    assert [u'qz_1', u'qz_2'] == var_module.run([u'^qz_.+'], {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"})

# Generated at 2022-06-23 12:31:44.338814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_value = ['qz_1', 'qz_2']
    lookup_module = LookupModule()
    actual_value = lookup_module.run(terms, variables)
    assert actual_value == expected_value


# Generated at 2022-06-23 12:31:46.399981
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_instance = LookupModule()
    lookup_instance._options = dict()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 12:31:50.052465
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    terms = ['ansible']
    variables = {'myhosts_a': 'test', 'ansible': 'test2'}

    ret = lookup.run(terms, variables)
    assert(ret[0] == 'ansible')

# Generated at 2022-06-23 12:31:50.978275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-23 12:31:58.241613
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_instance = LookupModule()

    # Retrieve list of variable names that match a pattern
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    result = lookup_instance.run(terms=terms, variables=variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:32:04.429219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ '^qz_.+', '.+_location$' ]
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either", 'hosts_location':'planet Mars'}
    assert LookupModule().run(terms, variables) == ['qz_1', 'qz_2', 'hosts_location']

# Generated at 2022-06-23 12:32:14.212665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError

    # Setup
    test_vars = {
        'hello': 'world',
        'hi_there': 'moon',
        'do_out': 'there',
    }
    test_terms = 'he'
    test_obj = LookupModule()

    # Test for exception for invalid setting identifier
    with pytest.raises(AnsibleError) as error:
        test_obj.run(test_terms, test_vars, direct={'wantlist': False})
    assert 'Invalid setting identifier, "he" is not a string' in error.value.message

    # Test for exception for invalid regex in term
    test_regex = '[0-9'

# Generated at 2022-06-23 12:32:23.628587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}) == [u'qz_1', u'qz_2']
    assert lookup_module.run(['.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}) == [u'qz_1', u'qz_2', u'qa_1', u'qz_']

# Generated at 2022-06-23 12:32:32.351143
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:32:42.015499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    variables = {
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
        'f': 6,
        'zone_a': 'A',
        'zone_b': 'B',
        'zone_c': 'C',
        'location_a': 'A',
        'location_b': 'B',
        'location_c': 'C',
        'zone_a_a1': 'A',
        'zone_a_b1': 'B',
        'zone_a_c1': 'C',
        'location_a_a1': 'A',
        'location_a_b1': 'B',
        'location_a_c1': 'C'
    }


# Generated at 2022-06-23 12:32:45.190330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DummyLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return ['']

    assert DummyLookupModule('').run is not None

# Generated at 2022-06-23 12:32:51.309322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({"_terms": ['^qz_.+']})
    assert l._options["_terms"] == ['^qz_.+']
    assert l.run(['^qz_.+'], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}) == ['qz_1', 'qz_2']


# Generated at 2022-06-23 12:32:57.286111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(dict())

    # variables is not None
    variables = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    terms = ['key1', 'key2', 'key3']
    assert lookup_module.run(terms, variables=variables) == terms

    # variables is None
    variables = None
    try:
        lookup_module.run(terms, variables=variables)
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # term is not `string_types`
    variables = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-23 12:32:57.979897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:33:07.021678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # not testing with variables because they can contain arbitrary characters
    # which makes it hard to search.

    terms = ["test"]
    variables = {"test": 1}
    assert(LookupModule().run(terms, variables=variables) == ["test"])

    terms = ["test"]
    variables = {"test": 1, "test2": 2}
    assert(LookupModule().run(terms, variables=variables) == ["test"])

    terms = ["test"]
    variables = {"test": 1, "test2": 2, "other": 3}
    assert(LookupModule().run(terms, variables=variables) == ["test"])

    terms = ["test", "test2"]
    variables = {"test": 1, "test2": 2, "other": 3}

# Generated at 2022-06-23 12:33:14.891291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_terms = ['^qz_.+', '.+_zone$', '.+_location$']
    mock_vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either",
                 'zone': 'thezone', 'hosts_zone': 'thezone', 'hosts_location': 'thelocation'}

    ret = LookupModule().run(terms=mock_terms, variables=mock_vars)
    assert 'qz_1' in ret, 'Missing qz_1 from return'

# Generated at 2022-06-23 12:33:23.774799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def check_run(validate_func, terms, variables=None, kwargs=None, result=None):
        lookup = LookupModule()
        try:
            ret = lookup.run(terms, variables, kwargs)
            validate_func(ret)
        except Exception as ex:
            print(ex, file=sys.stderr)
            return False

    def validate_ret1(ret):
        assert len(ret) == 1
        assert ret[0] == 'qz_2'

    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}
    terms = ['^qz_.+']
    result = ['qz_2']
    assert check

# Generated at 2022-06-23 12:33:34.275981
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3

    lm = LookupModule()

    assert PY3, "Test not compatible with Python 2"

    # simple example
    terms = ['^qz_.+']
    variables = { 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either" }
    ret = lm.run(terms, variables)
    assert ret == ['qz_1', 'qz_2'], "Should find two variables starting with 'qz_'"

    # show all variables
    terms = ['.+']
    ret = lm.run(terms, variables)
    assert ret == ['qz_1', 'qz_2', 'qa_1', 'qz_']



# Generated at 2022-06-23 12:33:36.062984
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule({'terms': 'foo', 'variables': 'bar'})) == LookupModule

# Generated at 2022-06-23 12:33:47.538616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = LookupModule()
    variables = {"random": "weird", "govt": "bureaucracy", "govt_official": "hard time maker", "govt_office": "filing", "govt_office_file": "filing"}

    # test for variable
    terms = ["random"]
    result = looker.run(terms, variables)
    assert result == ["random"]

    # test for variable with regex
    terms = ["^govt.+"]
    result = looker.run(terms, variables)
    assert result == ['govt', 'govt_official', 'govt_office', 'govt_office_file']

    # test for variable with regex
    terms = ["^govt.+", "random"]
    result = looker.run(terms, variables)

# Generated at 2022-06-23 12:33:48.406982
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:33:49.775732
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert (issubclass(LookupModule, LookupBase))

# Generated at 2022-06-23 12:33:50.915369
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 12:33:54.390511
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    result = lookup.run(['.+'])
    assert(isinstance(result, list))
    assert(isinstance(result[0], str))

# Generated at 2022-06-23 12:33:56.336482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj._plugins is not None
    assert obj._templar is not None

# Generated at 2022-06-23 12:34:02.951036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # example variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # term to search for
    terms = ['^qz_.+']

    lm = LookupModule()
    result = lm.run(terms, variables)
    assert result == ['qz_1', 'qz_2'], "Failed to match expected result."
    assert len(result) == 2, "Failed to match expected number of results."

# Generated at 2022-06-23 12:34:03.928509
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-23 12:34:12.885977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()

    terms = [
        '^qz_.+',
        'hosts',
        '.+_zone$',
        '.+_location$',
    ]

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'qaz_zone': 'qaz_zone',
        'qaz_location': 'qaz_location'
    }


# Generated at 2022-06-23 12:34:17.210393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test non-string types
    obj = LookupModule()
    try:
        obj.run([{}])
        raise AssertionError("test_LookupModule: Test non-string types failed.")
    except AnsibleError:
        pass


# Generated at 2022-06-23 12:34:27.255157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    # @staticmethod
    # def run(terms, variables=None, **kwargs):

    lookup = LookupModule()

    ret = lookup.run(
        terms=[
            r'^qz_.+'
        ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either"
        }
    )

    assert len(ret) == 2, 'LookupModule.run should return 2 variables'
    assert 'qz_1' in ret, 'LookupModule.run should find qz_1'
    assert 'qz_2' in ret, 'LookupModule.run should find qz_2'




# Generated at 2022-06-23 12:34:37.591049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    module = __import__('ansible.plugins.lookup.varnames',globals(), locals(), ['LookupModule'], 0)
    lookup = module.LookupModule()
    terms = ['^test_', '.+_test']
    variables = {'test_1': 'Hello', 'test_2': 'World', 'a_test': 'Ansible', 'test':'python', 'unittest_1': 'Unit test'}
    expected_ret = ['test_1', 'test_2', 'a_test', 'unittest_1']
    ret = lookup.run(terms, variables)
    assert ret == expected_ret

# Generated at 2022-06-23 12:34:48.812912
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    with pytest.raises(AnsibleError) as e:
        lookup_mod = LookupModule()
        lookup_mod.run("hello", variables=None)
    assert e.value.args[0] == "No variables available to search"

    with pytest.raises(AnsibleError) as e:
        lookup_mod = LookupModule()
        lookup_mod.run(["hello", {'1': '2'}], variables={})
    assert "Invalid setting identifier, \"{'1': '2'}\" is not a string, it is a <class 'dict'>" == e.value.args[0]

    with pytest.raises(AnsibleError) as e:
        lookup_mod = LookupModule()

# Generated at 2022-06-23 12:34:53.808593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    terms = ['var1', 'var2']
    lookup_obj = LookupModule()
    assert(lookup_obj.run(terms, variables=vars) == terms)


# Generated at 2022-06-23 12:34:55.235427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:34:56.450368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 12:35:06.479372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test single input
    results = LookupModule().run(['^qz_.+'], {'qz_1': 1, 'qz_2': 2, 'qz_3': 3})
    assert results == ['qz_1', 'qz_2', 'qz_3']

    # Test multiple inputs
    results = LookupModule().run(['^qz_.+', '^qa_.+'], {'qz_1': 1, 'qz_2': 2, 'qz_3': 3, 'qa_1': 1})
    assert results == ['qz_1', 'qz_2', 'qz_3', 'qa_1']

    # Test non-matching input

# Generated at 2022-06-23 12:35:16.088696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 12:35:27.054270
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    if sys.version_info >= (3, 0):
        from unittest.mock import patch
    else:
        from mock import patch

    def _mock_vars(self, varname, *args, **kwargs):
        return {'var1': 'hello', 'var2': 'world', 'var3': 'ansible'}


# Generated at 2022-06-23 12:35:29.101227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:35:36.087837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Tests for the constructor of the LookupModule class.

    .. note::
        This test is not ran by ``python setup.py test``. It needs to be ran separately with:

        python -m pytest tests/test_lookup_plugins/test_lookup_varnames.py

    """
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:35:36.707217
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return

# Generated at 2022-06-23 12:35:41.734445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert m.run(terms, variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:35:44.207944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:35:55.533323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    os.environ['ANSIBLE_VARIABLES_PREFIX'] = 'ANSIBLE_VAR'
    mylookup = LookupModule({})
    mylookup.set_options(var_options=dict(ANSIBLE_VAR_hello='world',
                                          ANSIBLE_VAR_ignore='me',
                                          ANSIBLE_VAR_ignore_me_too='me',
                                          ANSIBLE_VAR_particular_zone='us-east-1b',
                                          ANSIBLE_VAR_we_ignore_this='too'),
                         direct={})
    terms = ['^ANSIBLE_VAR_ignore.+', '^ANSIBLE_VAR_particular.+$']
    result = mylookup.run(terms)

# Generated at 2022-06-23 12:36:06.319532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_list = ['B', 'C', 'D', 'A']

    # Test to get all the variables
    test_Lookup = LookupModule()
    assert test_Lookup.run(['.']) == test_list

    # Test to get variables that start with 'Q'
    assert test_Lookup.run(['^Q']) == ['Q']

    # Test to get variables that end with '_zone'
    assert test_Lookup.run(['.+_zone$']) == [ 'Q_zone' ]

    # Test to get variables that end with '_location' or '_zone'
    assert test_Lookup.run(['.+_location$', '.+_zone$']) == ['Q_location', 'Q_zone']

# Generated at 2022-06-23 12:36:11.993253
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:36:24.067376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    # Test with no matches

    terms = ['^qz_.+']
    variables = {
        'qa_1': "I won't show"
    }
    my_ret = l.run(terms=terms, variables=variables)
    assert my_ret == []

    # Test with one match

    terms = ['^qz_.+']
    variables = {
        'qz_1': "hello",
        'qz_2': "world"
    }
    my_ret = l.run(terms=terms, variables=variables)
    assert my_ret == ['qz_1', 'qz_2']

    # Test with two matches

    terms = ['^qz_.+', '^qa_.+']

# Generated at 2022-06-23 12:36:31.131490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arranges
    module = LookupModule()

    terms = ['.+']
    variables = dict(qz_1='hello', qz_2='world')

    # acts
    actual_result = module.run(terms, variables)

    # asserts
    assert actual_result is not None
    assert len(actual_result) == 2
    assert 'qz_1' in actual_result
    assert 'qz_2' in actual_result

# Generated at 2022-06-23 12:36:32.546001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 12:36:42.673914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import the plugin code into a module object
    import sys
    sys.path.append('../lib/ansible/plugins/lookup')
    import varnames
    module = varnames.LookupModule()

    # call the run method directly and check the result
    assert module.run(["^qz_.+"], {"qz_1":'hello', "qz_2":"world", "qa_1":"I won't show", "qz_":"I won't show either"}) == ['qz_1', 'qz_2']
    assert module.run([".+"], {"qz_1":'hello', "qz_2":"world", "qa_1":"I won't show", "qz_":"I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-23 12:36:52.612240
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test 'direct' param is not supported
    module = LookupModule()
    try:
        module.run([], direct={})
        assert False
    except AnsibleError as e:
        assert 'direct argument is not supported' in str(e)

    # Test 'variable' param is required
    module = LookupModule()
    try:
        module.run([])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test regular expression error is handled correctly
    module = LookupModule()
    try:
        module.run(['*'])
        assert False
    except AnsibleError as e:
        assert 'Unable to use "*" as a search parameter: nothing to repeat' in str(e)

# Generated at 2022-06-23 12:36:58.926256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockVariableManager(object):
        def __init__(self):
            self.vars = dict()

    variable_manager = MockVariableManager()
    variable_manager.vars = { 'a': 'A', 'b': 'B'}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variable_manager.vars, direct=dict())


# Generated at 2022-06-23 12:37:10.293799
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing run with no variables passed in
    test_instance = LookupModule()
    result = test_instance.run(['foo'])
    assert result == []

    # Testing run with one term passed in
    test_instance = LookupModule()
    result = test_instance.run(['foo'], variables={'foo1': 'bar', 'foo2': 'baz'})
    assert len(result) == 2
    assert result[0] == 'foo1'
    assert result[1] == 'foo2'

    # Testing run with two terms passed in (second term has no matches)
    test_instance = LookupModule()
    result = test_instance.run(['foo', 'bar'], variables={'foo1': 'bar', 'foo2': 'baz'})
    assert len(result) == 2
    assert result

# Generated at 2022-06-23 12:37:19.736114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_list = [
        '^qz_.+',
        '.+',
        'hosts',
        '.+_zone',
        '.+_location'
        ]

    dict_set_one = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
        }


# Generated at 2022-06-23 12:37:26.286328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    
    # Act
    result = lookup.run(terms, variables)

    # Assert
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-23 12:37:35.616222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    terms = ["^[A-Z].*"]
    variables = {
        "ANSIBLE_VARIABLE": "ansible",
        "my_variable": "my_value"
    }

    # no variables
    try:
        obj.run(terms)
        assert False, "AnsibleError exception not raised"
    except AnsibleError:
        pass

    # invalid term type
    try:
        obj.run(123, variables)
        assert False, "AnsibleError exception not raised"
    except AnsibleError:
        pass

    # invalid term value
    try:
        obj.run("+", variables)
        assert False, "AnsibleError exception not raised"
    except AnsibleError:
        pass

    # 1 term

# Generated at 2022-06-23 12:37:37.559572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, LookupModule)

# Unit tests regex patterns

# Generated at 2022-06-23 12:37:40.087114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(['^qz_.+'], {'qz_1': 'hello'})
    assert result == ['qz_1']

# Generated at 2022-06-23 12:37:45.263032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['^qz_.+']
    variables = { 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = lm.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']


# Generated at 2022-06-23 12:37:54.470902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # prepare LookupModule object and variables
    lu = LookupModule()
    variables = dict(var_1 = "value_1", var_2 = "value_2", _var_3 = "value_3")
    # expected result if term is equal to first key of dictionary variables
    expected_result_1 = ["var_1"]
    # expected result if term is equal to second key of dictionary variables
    expected_result_2 = ["var_2"]
    # expected result if term is equal to value of the first key of dictionary variables
    expected_result_3 = ["var_1", "var_2"]
    # expected result if term is equal to value of the second key of dictionary variables
    expected_result_4 = ["var_1", "var_2"]
    # expected result if term is equal to value of the third key of dictionary variables (

# Generated at 2022-06-23 12:37:54.990556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:38:05.721940
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    # Check the creation of a list of variables names with prefix 'qz_'
    # Expected result
    result = ['qz_1', 'qz_2']

    # Create the LookupModule instance
    lkup = LookupModule()

    # Setting the variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    kwargs = {}
    lkup.set_options(var_options=variables, direct=kwargs)

    # Run the lookup module
    terms = ['^qz_.+']
    result_obtained = lkup.run(terms, variables)

    # Check result

# Generated at 2022-06-23 12:38:06.715303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()

# Generated at 2022-06-23 12:38:12.976620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ["^qz_.+", "^qa_.+"]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }

    test_ret = lookup.run(terms=terms, variables=variables)
    assert len(test_ret) == 2
    assert "qz_1" in test_ret
    assert "qz_2" in test_ret

# Generated at 2022-06-23 12:38:20.508809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = [
        '^qz_.+',
        'hosts',
        '.+_zone$',
        '.+_location$'
    ]
    values = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either'
    }
    assert lookup.run(terms=terms, variables=values)

# Generated at 2022-06-23 12:38:23.654295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = {'test_var': 'test_val'}
    lu = LookupModule().run('^test_.+', variables)
    assert lu[0] == 'test_var'


# Generated at 2022-06-23 12:38:27.026396
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    d = {'a': '1', 'b': '2', 'c': '3'}
    ret = lookup.run(['a'], variables=d)

    assert len(ret) == 1
    assert ret == ['a']

# Generated at 2022-06-23 12:38:32.875874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    result = test_LookupModule.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']
    result = test_LookupModule.run(['.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-23 12:38:36.308108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.six import string_types

    print("Checking method run of class LookupModule")

    class FakeVars:
        def __init__(self):
            self._data = {}

        def get(self, key, default=None):
            return self._data[key]

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

        def __contains__(self, key):
            return key in self._data

        def __iter__(self):
            return iter(self._data)

    class FakeSelf:
        def __init__(self):
            self.options = {}
            self.shared_loader

# Generated at 2022-06-23 12:38:38.388554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run is not None

# Generated at 2022-06-23 12:38:39.629473
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:38:45.349509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test parameters
    terms = ['actual_value', 'dummy_value']
    variables = {'actual_value': 1, 'value': 2}

    # Expected results
    expected = ['actual_value']

    # Unit test
    lookup = LookupModule()
    results = lookup.run(terms, variables)
    assert results == expected, 'Retrieved variables do not match expected.'

if __name__ == '__main__':
    print(test_LookupModule_run())

# Generated at 2022-06-23 12:38:46.535895
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run("^qz_.")

# Generated at 2022-06-23 12:38:47.796432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



# Generated at 2022-06-23 12:38:59.664670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml import objects
    
    def assert_list_equal(list1, list2):
        if len(list1) != len(list2):
            raise AssertionError("lists do not have the same lenght (%d != %d)" % (len(list1), len(list2)))
        
        for i, v in enumerate("".join(list1)):
            if v != "".join(list2[i]):
                raise AssertionError("lists do not have the same content (%s != %s)" % ("".join(list1), "".join(list2)))
    
    class MockVarsModule(object):
        def __init__(self, variables):
            self.__dict__ = objects.AnsibleVars(variables)


# Generated at 2022-06-23 12:39:06.846487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    import pytest
    # Set LookupModule.run() arguments
    terms = ['^qz_.+', 'hosts', re.compile('^ec2_.*')]
    variables = {'ec2_access_key': 'xxx', 'ec2_secret_key': 'xxx', 'hosts': []}
    # Run the lookup module
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, variables)
    # Check result
    assert result == ['ec2_access_key', 'ec2_secret_key', 'hosts']

# Generated at 2022-06-23 12:39:18.627485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test 1
    module = LookupModule()
    assert module

    # Test 2
    pattern = r'^qz_.+'
    result = module.run(terms=[pattern], variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    })
    assert result == ['qz_1', 'qz_2']

    # Test 3
    pattern = r'.+'
    result = module.run(terms=[pattern], variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    })
    assert result

# Generated at 2022-06-23 12:39:20.604275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=protected-access
    # TODO: test constructor
    obj = LookupModule()


# Generated at 2022-06-23 12:39:32.183111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lm = LookupModule()
    terms = ['^qz_.+']
    try:
        lm.run(terms)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert 'No variables' in str(e)
    else:
        raise AssertionError('Run should have throw an exception')


    # Test with no terms
    lm = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = []
    try:
        lm.run(terms, variables)
    except Exception as e:
        assert isinstance(e, AnsibleError)

# Generated at 2022-06-23 12:39:42.398768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys, os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../')
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    
    results = []


# Generated at 2022-06-23 12:39:43.446032
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert hasattr(LookupModule, "run")
   

# Generated at 2022-06-23 12:39:50.392560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_vars = dict(
        a=1,
        b=2,
        c=3,
        d=4,
        e=5,
        f=5
    )
    terms = ['a', 'b', 'c', 'd', 'e', 'f']
    expected_list = ['a', 'b', 'c', 'd', 'e', 'f']
    lm = LookupModule()
    ret = lm.run(terms, variables=my_vars)
    assert ret == expected_list

# Generated at 2022-06-23 12:39:52.584964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instances = LookupModule()
    assert(isinstance(instances, LookupModule))

# Generated at 2022-06-23 12:40:00.908266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #method run should return the names of all the variables that match the given regex terms
    terms = ['^qz_.+', '.+_zone$']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'qz_3_zone': 'zone3',
        'qz_3_location': 'location3',
        'qz_4_zone': 'zone4',
        'qz_4_location': 'location4',
    }

    # result does not have each varname exactly once
    result = LookupModule().run(terms, variables)


# Generated at 2022-06-23 12:40:02.467581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' Unit test for constructor of class LookupModule '''
    lookup_obj = LookupModule()


# Generated at 2022-06-23 12:40:03.278515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global LookupModule
    LookupModule

# Generated at 2022-06-23 12:40:11.565833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['term1', 'term2']
    variables = {}
    variables['var1'] = 'var1'
    variables['var2'] = 'var2'
    variables['var3'] = 'var3'
    variables['var4'] = 'var4'
    variables['var5'] = 'var5'
    variables['var6'] = 'var6'
    variables['var7'] = 'var7'
    variables['var8'] = 'var8'

    results1 = ['var1', 'var2', 'var3', 'var4', 'var5', 'var8']
    results2 = ['var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'var8']

    lookup_instance = LookupModule()

# Generated at 2022-06-23 12:40:13.371430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L


# Generated at 2022-06-23 12:40:19.913746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    module = LookupModule()
    variables = {
        "guest": "ubuntu",
        "distro": "ubuntu"
    }
    terms = [
        "^guest",
        "^dist",
        "^linux"
    ]

    # Act
    got = module.run(terms, variables)

    # Assert
    assert("guest" in got)
    assert("distro" in got)
    assert("linux" not in got)

# Generated at 2022-06-23 12:40:21.199792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:40:30.587882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    dummy_result_dict = {
        'key1': 'value1',
        'key2': 'value2'
    }

    dummy_ansible_module = DummyAnsibleModule()
    test_lookup_module = LookupModule()
    test_lookup_module.set_options(direct={'_ansible_module': dummy_ansible_module})
    result = test_lookup_module.run(['.*'], dummy_result_dict)

    if PY3:
        builtin_open = 'builtins.open'
    else:
        builtin_open = '__builtin__.open'


# Generated at 2022-06-23 12:40:37.490433
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test when passed good a string
    terms = ["^qz_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}
    lookup_pattern = LookupModule()
    result = lookup_pattern.run(terms, variables)
    assert len(result) == 2
    assert "qz_1" in result
    assert "qz_2" in result

    # Test when passed a bad string
    terms = ["not-a-real-variable-name"]
    lookup_pattern = LookupModule()
    result = lookup_pattern.run(terms, variables)
    assert len(result) == 0


# Generated at 2022-06-23 12:40:45.396731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    lookup_module.run(terms=terms, variables=variables)
    assert lookup_module._plugin_options['variable_terms'] == terms
    assert lookup_module._plugin_options['variable_values'] == variables
    assert lookup_module.run(terms=terms, variables=variables) == ['qz_1', 'qz_2']
    assert isinstance(lookup_module.run(terms=terms, variables=variables), list)



# Generated at 2022-06-23 12:40:55.503294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object to avoid errors
    testlook = LookupModule()
    # Set options
    testlook.set_options(dict())
    # Test 1
    assert testlook.run(["^qz_.+"]) == [], "Should be '[]' but it is '%s'" % testlook.run(["^qz_.+"])
    # Test 2
    assert testlook.run([".+"]) == [], "Should be '[]' but it is '%s'" % testlook.run([".+"])
    # Test 3
    assert testlook.run(["hosts"]) == [], "Should be '[]' but it is '%s'" % testlook.run(["hosts"])
    # Test 4