

# Generated at 2022-06-17 13:40:54.528472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:41:05.227520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}, direct={})
    assert lookup_module.run(terms=['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module.run(terms=['^qz_.+', '^qa_.+']) == ['qz_1', 'qz_2', 'qa_1']
    assert lookup_module.run(terms=['^qz_.+', '^qa_.+', '^qz_$']) == ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-17 13:41:17.334754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['*'], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with valid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:27.178249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:38.394393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleError
    import re

    # Test with no variables
    lookup = LookupModule()
    try:
        lookup.run(terms=['test'], variables=None)
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid terms
    lookup = LookupModule()
    try:
        lookup.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

   

# Generated at 2022-06-17 13:41:49.515727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:01.682568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dictionary of variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Create a list of terms
    terms = ['^qz_.+']

    # Test the run method
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']

    # Create a list of terms
    terms = ['.+']

    # Test the run method
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    # Create a list of terms
    terms = ['hosts']

# Generated at 2022-06-17 13:42:10.519508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:22.680219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables=variables)
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup

# Generated at 2022-06-17 13:42:32.489358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['^qz_.+'], variables=None) == []

    # Test with no terms
    assert lookup_plugin.run(terms=[], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == []

    # Test with no matching variables
    assert lookup_plugin.run(terms=['^qz_.+'], variables={'qa_1': "I won't show", 'qz_': "I won't show either"}) == []

    # Test with matching variables

# Generated at 2022-06-17 13:42:48.274117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty terms
    lookup_module = LookupModule()
    assert lookup_module.run([], variables={}) == []

    # Test with empty variables
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], variables={}) == []

    # Test with empty variables and empty terms
    lookup_module = LookupModule()
    assert lookup_module.run([], variables={}) == []

    # Test with empty variables and empty terms
    lookup_module = LookupModule()
    assert lookup_module.run([], variables={}) == []

    # Test with empty variables and empty terms
    lookup_module = LookupModule()
    assert lookup_module.run([], variables={}) == []

    # Test with empty variables and empty terms
    lookup_module = LookupModule()
    assert lookup

# Generated at 2022-06-17 13:42:55.669626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(['a'])
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run([1], {'a': 1})
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:07.310236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with no matching variables
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:20.431714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid search parameter
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:30.711157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for invalid setting identifier
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'a': 'b'}, direct={})
    try:
        lookup_module.run([1])
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)
    else:
        assert False, 'AnsibleError not raised'

    # Test for invalid regex
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'a': 'b'}, direct={})
    try:
        lookup_module.run(['['])
    except AnsibleError as e:
        assert 'Unable to use' in str(e)
    else:
        assert False, 'AnsibleError not raised'

    # Test for no variables
   

# Generated at 2022-06-17 13:43:43.581104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=["test"])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid search parameter
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={"test": "test"})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:52.242257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dictionary of variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Create a list of terms
    terms = ['^qz_.+']

    # Call the run method of the LookupModule object
    result = lookup_module.run(terms, variables)

    # Assert the result
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:44:03.828937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'], variables=None)
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()


# Generated at 2022-06-17 13:44:11.638002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'
    else:
        assert False, 'AnsibleError not raised'

    # Test with invalid term
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run([1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <type \'int\'>'
    else:
        assert False, 'AnsibleError not raised'

    # Test with invalid regex
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 13:44:22.023543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], variables) == ['qz_1', 'qz_2']

    # Test with no terms
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []

    # Test with invalid term
    lookup_module = LookupModule()
    assert lookup_module.run([1]) == []

    # Test with invalid term
    lookup_

# Generated at 2022-06-17 13:44:44.407664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'], variables=None)
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with no terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert e.message == 'Missing required arguments: _terms'

    # Test with invalid term
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:44:47.317974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:44:51.468474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+', '^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    ret = lookup.run(terms, variables)
    assert ret == ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-17 13:45:02.245123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid setting identifier
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:12.344513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'value'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'value'})
        assert False
    except AnsibleError:
        assert True

    # Test with no matches
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:24.689332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
        assert False
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
        assert False
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = Look

# Generated at 2022-06-17 13:45:31.001163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:42.455090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:47.219494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:45:58.245692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that matches the term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'test_var': 'test_value'}, direct={})
    assert lookup_module.run(['^test_.+']) == ['test_var']

    # Test with a variable that does not match the term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'test_var': 'test_value'}, direct={})
    assert lookup_module.run(['^not_test_.+']) == []

    # Test with multiple variables that match the term
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:46:29.082055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dictionary of variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Create a list of terms
    terms = ['^qz_.+']

    # Call the run method of LookupModule
    result = lookup_module.run(terms, variables)

    # Assert the result
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:46:42.679948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']
    terms = ['.+']
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    terms = ['hosts']
    assert lookup_module.run(terms, variables) == []
    terms = ['.+_zone$', '.+_location$']
    assert lookup_module.run(terms, variables) == []

# Generated at 2022-06-17 13:46:49.689414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    terms = ['^qz_.+']
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:46:56.690558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    # Input:
    #   terms = ['^qz_.+']
    #   variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    # Expected output:
    #   ['qz_1', 'qz_2']
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_output = ['qz_1', 'qz_2']
    actual_output = LookupModule().run(terms, variables)
    assert actual_output == expected_output

    # Test

# Generated at 2022-06-17 13:47:03.923874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
        assert False, 'AnsibleError should be raised'
    except AnsibleError:
        assert True

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:47:15.372489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:24.033827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(['^qz_.+'])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid search parameter
    lookup_module = LookupModule()
    try:
        lookup_module.run(['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
        assert False
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid search parameter
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:35.417757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:43.846970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'a': 1, 'b': 2, 'c': 3}, direct={})
    assert l.run(['a']) == ['a']
    assert l.run(['b']) == ['b']
    assert l.run(['c']) == ['c']
    assert l.run(['a', 'b']) == ['a', 'b']
    assert l.run(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert l.run(['a', 'b', 'c', 'd']) == ['a', 'b', 'c']

# Generated at 2022-06-17 13:47:52.048626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+']) == []

    # Test with variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:48:52.768161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], variables) == ['qz_1', 'qz_2']

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:03.049086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(['hosts']) == []
    assert lookup_module.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:49:13.150956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:21.796046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e)

# Generated at 2022-06-17 13:49:32.506430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with no terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with no matching variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test1': 'test'}) == []

    # Test with matching variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'test'}) == ['test']

    # Test

# Generated at 2022-06-17 13:49:40.460073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['a'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'a': 1})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:51.341429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(['hosts']) == []
    assert lookup_module.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:50:02.555444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'], variables=None)
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()


# Generated at 2022-06-17 13:50:10.087502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:50:20.618101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup_module.run(terms=['.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']