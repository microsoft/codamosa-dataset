

# Generated at 2022-06-17 13:40:58.523699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world'})
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "^qz_.+" is not a string, it is a <class \'list\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:07.546327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Unable to use' in str(e)

    # Test with valid regex
    lookup_

# Generated at 2022-06-17 13:41:19.923784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
        assert False, "Should have thrown an exception"
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:28.661254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:42.173829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    ret = lookup_module.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']

    # Test with multiple terms
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+', '^qa_.+']
    ret = lookup_module.run(terms, variables)

# Generated at 2022-06-17 13:41:51.830521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:04.168858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock variables object
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'hosts': 'I will show',
        'hosts_zone': 'I will show',
        'hosts_location': 'I will show',
        'hosts_zone_location': 'I will show',
    }

    # Create a mock lookup module object
    lookup_module = LookupModule()

    # Create a mock terms object
    terms = ['^qz_.+', 'hosts', '.+_zone$', '.+_location$']

    # Call the run method of the lookup module
    result = lookup_module.run(terms, variables)

   

# Generated at 2022-06-17 13:42:09.921444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(terms=['test'])
        assert False, "Should have raised an exception"
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_plugin = LookupModule()
    try:
        lookup_plugin.run(terms=[1], variables={'test': 'value'})
        assert False, "Should have raised an exception"
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(e)

    # Test with invalid regex
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 13:42:22.302803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    lookup = LookupModule()
    lookup.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup.run(['^qz_.+']) == ['qz_1', 'qz_2']

    # Test with multiple terms
    lookup = LookupModule()
    lookup.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-17 13:42:32.337047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_result = ['qz_1', 'qz_2']
    result = LookupModule().run(terms, variables)
    assert result == expected_result

    # Test 2
    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_result = ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-17 13:42:47.999618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(['^qz_.+'])
        assert False
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with no terms
    lookup_module = LookupModule()
    try:
        lookup_module.run([], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
        assert False
    except AnsibleError as e:
        assert str(e) == 'Missing required arguments: _terms'

    # Test with invalid term
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:54.434593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e)

# Generated at 2022-06-17 13:43:05.705971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(['hosts']) == []
    assert lookup_module.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:43:18.965242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str

    # Create a dummy class for LookupBase
    class DummyLookupBase(object):
        def __init__(self):
            self.basedir = None
            self.runner = None
            self.templar = None
            self.vars = None
            self.current_path = None
            self.playbook_dir = None

        def set_options(self, var_options=None, direct=None):
            self.vars = var_options
            self.direct = direct

    # Create a dummy class for AnsibleModule
    class DummyAnsibleModule(object):
        def __init__(self):
            self

# Generated at 2022-06-17 13:43:29.581125
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:43:43.008776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['term'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'a': 1})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:47.656072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    ret = lookup.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:43:57.906549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'], variables=None)
        assert False
    except AnsibleError:
        assert True

    # Test with invalid terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with valid terms
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'test'}) == ['test']

# Generated at 2022-06-17 13:44:05.218412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with variables
    lookup_module = LookupModule()
    variables = {'test': 'test'}
    assert lookup_module.run(terms=['test'], variables=variables) == ['test']

    # Test with variables and regex
    lookup_module = LookupModule()
    variables = {'test': 'test', 'test2': 'test2'}
    assert lookup_module.run(terms=['test'], variables=variables) == ['test', 'test2']

    # Test with variables and regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:44:12.351669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid search parameter
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with valid search parameter
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'test'}) == ['test']

    # Test with valid search parameter that doesn't match
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-17 13:44:31.410141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with no matches
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:44:44.211476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

    # Test with variables and multiple terms
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_plugin = Lookup

# Generated at 2022-06-17 13:44:53.570258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:05.207048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}) == ['qz_1', 'qz_2']
    assert l.run(['.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-17 13:45:14.455833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1: Test with terms as a string
    lookup_module = LookupModule()
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

    # Test 2: Test with terms as a list
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

# Generated at 2022-06-17 13:45:24.835175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup.run(['hosts']) == []
    assert lookup.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:45:31.063711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:42.478729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:47.584316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-17 13:45:58.734296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test 1
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']
    # Test 2
    terms = ['.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)

# Generated at 2022-06-17 13:46:34.823382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['qz_1'])
        assert False
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello'})
        assert False
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:46:43.118309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:46:49.941493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']


# Generated at 2022-06-17 13:46:56.873808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e)

# Generated at 2022-06-17 13:47:05.332142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:16.833225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:25.770813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'
    else:
        assert False, 'AnsibleError not raised'

    # Test with invalid terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'], variables={'test': 'value'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "test" is not a string, it is a <class \'str\'>'
    else:
        assert False, 'AnsibleError not raised'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:36.697293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:47:47.054701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['a'])
        assert False
    except AnsibleError:
        assert True

    # Test with variables
    lookup_module = LookupModule()
    variables = {'a': '1', 'b': '2', 'c': '3'}
    assert lookup_module.run(terms=['a'], variables=variables) == ['a']
    assert lookup_module.run(terms=['a', 'b'], variables=variables) == ['a', 'b']
    assert lookup_module.run(terms=['a', 'b', 'c'], variables=variables) == ['a', 'b', 'c']

# Generated at 2022-06-17 13:47:54.471018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(['^qz_.+'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert 'Unable to use "^qz_.+" as a search parameter' in str(e)

    # Test with valid regex
    lookup_module = LookupModule()
    assert lookup_module.run

# Generated at 2022-06-17 13:49:00.994431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:09.672407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

    # Test with invalid term
    lookup_module = LookupModule()
    assert lookup_module.run([1], variables=variables) == []

    # Test with invalid term
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:18.783157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:29.666380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_result = ['qz_1', 'qz_2']
    assert LookupModule().run(terms, variables) == expected_result

    # Test with multiple terms
    terms = ['^qz_.+', '^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_result = ['qz_1', 'qz_2', 'qa_1']

# Generated at 2022-06-17 13:49:43.342966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in to_native(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in to_native(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:55.281645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'], variables={'test': 'value'})
        assert False
    except AnsibleError:
        assert True

    # Test with valid term
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'value'}) == ['test']

    # Test with valid term and multiple variables
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:50:05.540977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:50:16.027386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:50:25.169074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
        assert False
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module

# Generated at 2022-06-17 13:50:34.054472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1:
    #   - terms = ['^qz_.+']
    #   - variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    #   - kwargs = {}
    #   - expected result = ['qz_1', 'qz_2']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    kwargs = {}
    expected_result = ['qz_1', 'qz_2']
    lookup_module = LookupModule()
    result = lookup_module.run