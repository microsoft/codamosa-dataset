

# Generated at 2022-06-17 13:41:00.952292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello'})
        assert False
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:08.639901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=["^qz_.+"])
        assert False
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module

# Generated at 2022-06-17 13:41:19.712365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(['hosts']) == []
    assert lookup_module.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:41:28.544424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:41:42.173773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'a': '1', 'b': '2', 'c': '3'})
    assert lookup_module.run(['a']) == ['a']
    assert lookup_module.run(['a', 'b']) == ['a', 'b']
    assert lookup_module.run(['^a$']) == ['a']
    assert lookup_module.run(['^a$', '^b$']) == ['a', 'b']
    assert lookup_module.run(['^a$', '^b$', '^c$']) == ['a', 'b', 'c']

# Generated at 2022-06-17 13:41:51.830097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    lookup_module = LookupModule()
    lookup_module._options = {'var_options': {'a': 'b'}}
    assert lookup_module.run(['a']) == ['a']
    assert lookup_module.run(['a', 'b']) == ['a']
    assert lookup_module.run(['^a$']) == ['a']
    assert lookup_module.run(['^b$']) == []
    assert lookup_module.run(['^b$'], {'a': 'b', 'b': 'c'}) == ['b']
    assert lookup_module.run(['^b$'], {'a': 'b', 'b': 'c'}, direct={'a': 'b'}) == ['b']
    assert lookup_module.run

# Generated at 2022-06-17 13:42:04.169592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:08.855188
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Create a dictionary of variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    # Create a list of terms
    terms = ['^qz_.+']

    # Call method run of class LookupModule
    result = lookup_module.run(terms, variables)

    # Assert the result
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:42:20.960991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': 'localhost',
        'hosts_zone': 'localhost',
        'hosts_location': 'localhost',
        'hosts_zone_location': 'localhost',
        'hosts_location_zone': 'localhost',
    }
    terms = ['^qz_.+']
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

    terms = ['.+']
    result = lookup_module.run(terms, variables)
    assert result == list(variables.keys())

# Generated at 2022-06-17 13:42:27.474670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup.run(['hosts']) == []
    assert lookup.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:42:39.918627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:42:46.170605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    result = lookup.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:42:53.766893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with no terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['])
        assert False
    except AnsibleError:
        assert True

    # Test with no

# Generated at 2022-06-17 13:43:06.084710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid regex
    try:
        lookup_module.run(terms=['test'], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Unable to use "test" as a search parameter: nothing to repeat'

    # Test with valid regex
    assert lookup_module.run(terms=['^test$'], variables={'test': 'test'}) == ['test']

    # Test with invalid regex

# Generated at 2022-06-17 13:43:19.421763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = None
    kwargs = {}
    try:
        lookup_module.run(terms, variables, **kwargs)
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    terms = ['^qz_.+', 1]
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    kwargs = {}

# Generated at 2022-06-17 13:43:30.061065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=[])

    # Test with invalid terms
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module.run(terms=[1], variables={'a': 1})

    # Test with valid terms
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['a'], variables={'a': 1}) == ['a']
    assert lookup_module.run(terms=['a', 'b'], variables={'a': 1, 'b': 2}) == ['a', 'b']

# Generated at 2022-06-17 13:43:43.280717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

    # Test with invalid term
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:54.840562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Unable to use' in str(e)

    # Test with valid regex
    lookup_

# Generated at 2022-06-17 13:44:06.072090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "^qz_.+" is not a string, it is a <class \'str\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:44:09.985483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:44:25.459185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:44:32.153258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    result = lookup_module.run(terms=terms, variables=variables)
    assert result == ['qz_1', 'qz_2']
    terms = ['.+']
    result = lookup_module.run(terms=terms, variables=variables)
    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    terms = ['hosts']
    result = lookup_module.run(terms=terms, variables=variables)
    assert result == []

# Generated at 2022-06-17 13:44:44.477915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    #   - terms: ['^qz_.+']
    #   - variables: {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    #   - expected: ['qz_1', 'qz_2']
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected = ['qz_1', 'qz_2']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == expected

    # Test case 2:


# Generated at 2022-06-17 13:44:49.744335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

    # Test with multiple terms
    terms = ['^qz_.+', '^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)

# Generated at 2022-06-17 13:44:56.888414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError

    lookup = LookupModule()

    # Test with no variables
    try:
        lookup.run(terms=['test'])
        assert False
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid terms
    try:
        lookup.run(terms=[1])
        assert False
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex

# Generated at 2022-06-17 13:45:08.706532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False, "Expected AnsibleError"
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False, "Expected AnsibleError"
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:15.859869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with empty variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'], variables={})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:45:22.211428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup.run(terms, variables) == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:45:30.080644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+']) == ['qz_1', 'qz_2']

    # Test with multiple terms
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+', '^qa_.+'])

# Generated at 2022-06-17 13:45:42.130223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with no terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:46:08.605998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+']) == []

    # Test with variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

    # Test with invalid setting identifier
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:46:17.623934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']
    terms = ['.+']
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    terms = ['hosts']
    assert lookup_module.run(terms, variables) == []
    terms = ['.+_zone$', '.+_location$']
    assert lookup_module.run(terms, variables) == []

# Generated at 2022-06-17 13:46:28.053531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with invalid terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'value'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'value'})
        assert False
    except AnsibleError:
        assert True

    # Test with valid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:46:37.527857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2']
    terms = ['.+']
    assert lookup_module.run(terms, variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    terms = ['hosts']
    assert lookup_module.run(terms, variables) == []
    terms = ['.+_zone$', '.+_location$']
    assert lookup_module.run(terms, variables) == []

# Generated at 2022-06-17 13:46:44.991015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty terms
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []

    # Test with invalid terms
    lookup_module = LookupModule()
    assert lookup_module.run([1]) == []

    # Test with invalid terms
    lookup_module = LookupModule()
    assert lookup_module.run(['1']) == []

    # Test with invalid terms
    lookup_module = LookupModule()
    assert lookup_module.run(['1']) == []

    # Test with invalid terms
    lookup_module = LookupModule()
    assert lookup_module.run(['1']) == []

    # Test with invalid terms
    lookup_module = LookupModule()
    assert lookup_module.run(['1']) == []

    # Test with invalid terms

# Generated at 2022-06-17 13:46:57.064173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

    terms = ['.+']
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    terms = ['hosts']
    result = lookup_module.run(terms, variables)
    assert result == []

    terms = ['.+_zone$', '.+_location$']

# Generated at 2022-06-17 13:47:05.403185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock variables object
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': 'localhost',
        'hosts_zone': 'us-east-1',
        'hosts_location': 'us-east-1a',
        'hosts_zone_location': 'us-east-1a',
        'hosts_location_zone': 'us-east-1a',
    }

    # Create a mock lookup object
    lookup = LookupModule()

    # Create a mock terms object
    terms = ['^qz_.+']

    # Call the run method of the lookup object
    result = lookup.run(terms, variables)



# Generated at 2022-06-17 13:47:14.458144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dictionary of variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    # Create a list of terms
    terms = ['^qz_.+']

    # Run the run method of LookupModule
    result = lookup_module.run(terms, variables)

    # Assert the result
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:47:19.912201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms, variables)
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-17 13:47:25.620900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert lookup_module.run(['^qz_.+']) == ['qz_1', 'qz_2']
    assert lookup_module.run(['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lookup_module.run(['hosts']) == []
    assert lookup_module.run(['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-17 13:48:18.134536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid search parameter
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:48:27.974729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1:
    # Test with no variables
    # Expected result:
    #   AnsibleError
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['^qz_.+'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test 2:
    # Test with invalid setting identifier
    # Expected result:
    #   AnsibleError
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str

# Generated at 2022-06-17 13:48:34.546908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lm = LookupModule()

    # Create a dictionary of variables
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Test the run method
    assert lm.run(['^qz_.+'], variables) == ['qz_1', 'qz_2']
    assert lm.run(['.+'], variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert lm.run(['hosts'], variables) == []
    assert lm.run(['.+_zone$', '.+_location$'], variables) == []

# Generated at 2022-06-17 13:48:46.947537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test with no terms
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
        assert False
    except AnsibleError:
        assert True

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:48:59.349527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test': 'test'})
    except AnsibleError as e:
        assert str(e)

# Generated at 2022-06-17 13:49:08.274054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:17.622300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dictionary of variables

# Generated at 2022-06-17 13:49:23.857899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test': 'test'})
    except AnsibleError as e:
        assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:49:33.994734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_plugin = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plugin.run(terms=['^qz_.+'])
    assert 'No variables available to search' in str(excinfo.value)

    # Test with invalid term
    lookup_plugin = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plugin.run(terms=[1], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>' in str(excinfo.value)

    # Test

# Generated at 2022-06-17 13:49:41.460954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['test_term'])
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)

    # Test with invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[1], variables={'test_term': 'test_value'})
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)

    # Test with invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=['['], variables={'test_term': 'test_value'})
    except AnsibleError as e:
        assert 'Unable to use' in str(e)

