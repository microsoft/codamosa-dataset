

# Generated at 2022-06-21 06:58:37.009840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    assert look.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert look.run(terms=['.+_zone$', '.+_location$'], variables={'z_zone': 'hello', 'z_location': 'world', 'a_zone': "I won't show", 'z_zone_': "I won't show either"}) == ['z_zone', 'z_location']

# Generated at 2022-06-21 06:58:41.506978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Init
    lookup_plugin = LookupModule()

    # Test
    result = lookup_plugin.run(terms=['^qz_.+'])

    # Verify
    assert result is None

# Generated at 2022-06-21 06:58:42.051914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 2

# Generated at 2022-06-21 06:58:42.873153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:58:46.089871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._terms == [], "should be no terms"
    assert lookup_module._variables == {}, "should be no variables"

# Generated at 2022-06-21 06:58:56.025743
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initializing test objects
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options={'qz_var_1':'var_1', 'qz_var_2':'var_2', 'qa_var':'var_3'}, direct={})

    # Executing method
    assert lookup_obj.run(terms=['^qz_.+']) == ['qz_var_1', 'qz_var_2']

# Generated at 2022-06-21 06:59:07.559479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Default dict
    variables = dict()
    foo = LookupModule(variables=variables)

    # Create custom
    variables = dict(qz_1=1, qz_2=2, qa_1=3, qz_4=4)
    foo = LookupModule(variables=variables)

    # exception
    try:
        variables = dict(qz_1=1, qz_2=2, qa_1=3, qz_4=4)
        foo = LookupModule(variables=variables)
        terms = None
        foo.run(terms=terms)
    except Exception as e:
        pass

# Generated at 2022-06-21 06:59:10.222690
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _l = LookupModule()
    assert _l is not None

# Generated at 2022-06-21 06:59:12.279918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 06:59:15.140284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # Check that lm is a LookupModule object
    assert isinstance(lm, LookupModule)
    # Check that lm has a run method
    assert hasattr(lm, "run")

# Generated at 2022-06-21 06:59:28.256738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()
    test_terms = ['^qz_.+']
    
    qz_1 = "hello"
    qz_2 = "world"
    qa_1 = ""
    qz_ = ""

    expected = ['qz_1', 'qz_2']
    test_variables = {
            'qz_1': qz_1,
            'qz_2': qz_2,
            'qa_1': qa_1,
            'qz_' : qz_
            }
    result = test_module.run(test_terms, test_variables)
    
    assert result == expected

# Generated at 2022-06-21 06:59:29.089158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No test written"



# Generated at 2022-06-21 06:59:38.689243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if variables not a dict raise AnsibleError
    module = LookupModule()
    with pytest.raises(AnsibleError):
        module.run(terms=None, variables=None)
    # Test with no terms given
    with pytest.raises(AnsibleError):
        module.run(terms=[], variables=dict(variable='yeah'))
    # Test with wrong type of name:
    with pytest.raises(AnsibleError):
        module.run(terms=[1], variables=dict(variable='yeah'))
    # Test if dict of variables is not passed raise AnsibleError
    with pytest.raises(AnsibleError):
        module.run(terms=['^a'], variables=None)
    # Test with 1 term given

# Generated at 2022-06-21 06:59:40.012668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check that the constructor works
    LookupModule()

# Generated at 2022-06-21 06:59:42.382935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test to see if class is defined
    assert(hasattr(LookupModule, 'run'))

# Generated at 2022-06-21 06:59:42.885121
# Unit test for constructor of class LookupModule
def test_LookupModule():
    varlookup = LookupModule()



# Generated at 2022-06-21 06:59:47.669961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # creates new LookupModule object
    testlookup = LookupModule()

    # creates a dict for testing
    dict1 = dict()

    dict1['val1'] = 'hello'
    dict1['val2'] = 'hey'

    # run function without the arguments
    testlookup.run()

    # run function with incorrect arguments
    testlookup.run(terms=None, variables=dict1)
    testlookup.run(terms=dict1, variables=None)
    testlookup.run(terms=None, variables=None)
    testlookup.run(terms=dict1, variables=dict1)

    # run the function with correct arguments
    testlookup.run(terms=['val1'], variables=dict1)

# Generated at 2022-06-21 06:59:59.852849
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    x = dict()
    x["one"] = "world 1"
    x["two"] = "world 2"
    x["three"] = "world 3"
    x["four"] = "world 4"
    x["five"] = "world 5"
    x["six"] = "world 6"
    x["seven"] = "world 7"

    lookuper = LookupModule()
    lookuper.set_options(var_options=x)

    # Testing for all variables starting with 'o'
    assert lookuper.run(["o.+"]) == ["one"]

    # Testing for all variables
    assert lookuper.run([".+"]) == ["one", "two", "three", "four", "five", "six", "seven"]

    # Testing for all variables with 'o' in them

# Generated at 2022-06-21 07:00:02.788168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lcm = LookupModule()
    terms = ['hosts']
    variables = {"hosts_list": "test"}
    result = lcm.run(terms, variables)
    assert result == ['hosts_list']

# Generated at 2022-06-21 07:00:04.842755
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 07:00:17.232015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    def _search(result_list, term, var_list, variables):
        result_list.append(LookupModule().run(terms=[term], variables=variables)[0])

    result_list = []
    variables = {'connect': 'yes', 'not_connect': 'no', 'connect_': 'yes'}
    _search(result_list, '^connect$', [], variables)
    assert len(result_list) == 1
    assert result_list.pop() == 'connect'

    result_list = []
    _search(result_list, '^con+ect$', [], variables)
    assert len(result_list) == 1
    assert result_list.pop() == 'connect'

    result_list = []
    _search(result_list, '^connect_$', [], variables)
   

# Generated at 2022-06-21 07:00:25.647262
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Load up a fake module to test with
    fake_mod = type('FakeModule',(object,),{})
    results = LookupModule(fake_mod, 'var').run(['^qz_.+'], {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"})
    # Search for a term that doesn't match any variables
    assert(len(results)==2)
    assert('qz_1' in results)
    assert('qz_2' in results)
    assert('qa_1' not in results)
    assert('qz_' not in results)

# Generated at 2022-06-21 07:00:26.330668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 07:00:34.304202
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugin.loader import lookup_loader, get_loader

    # Create a LookupPlugin
    class Plugin1(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return [terms, variables]

    # Inject the plugin into the lookup plugin index
    lookup_loader.add('plugin1', Plugin1)
    loader, lookupcls, lookupterms = get_loader('plugin1')

    # Sample data
    variables_data = {'var1': 'test1', 'var2': 'test2'}
    # Create the lookup object
    lp = lookupcls()

    # Run the method that is under test
    result = lp.run(terms='var', variables=variables_data)
    assert result == [['var1', 'var2'], variables_data]

   

# Generated at 2022-06-21 07:00:38.114648
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert getattr(lookup_plugin,'_options','_options') == '_options'

# Generated at 2022-06-21 07:00:51.672388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.vars import merge_hash
    from ansible.template import Templar

    # Variables for making a fake templar
    loader_mock = MagicMock()
    loader_mock.load_from_file.return_value = {}
    templar_args = [loader_mock]

    # Make a fake templar object
    templar = Templar(*templar_args)

    # Make the needed inputs for a LookupModule object
    set_options = {'var_options': {'a': '1', 'b': '2', 'c': '3', 'd': '4'},
                   '_templar': templar,
                   '_loader': loader_mock}

    # Make the LookupModule object
    lm = LookupModule(**set_options)


# Generated at 2022-06-21 07:00:55.070678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 07:01:02.526344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    variables = {'hosts': 'www.google.com', 'networks': '192.168.0.0'}
    lookup_plugin.run(terms=['host.+'], variables=variables)
    lookup_plugin.run(terms=['net'], variables=variables)

# Generated at 2022-06-21 07:01:09.880171
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a non string term
    lookup_module = LookupModule()
    try:
        lookup_module._run('varnames', [], 123, variables={'abc': 'DEF'})
    except AnsibleError as e:
        assert e.msg == 'Invalid setting identifier, "123" is not a string, it is a <type \'int\'>'

    # Test with an invalid regex
    lookup_module = LookupModule()
    try:
        lookup_module._run('varnames', [], 'ab(c', variables={'abc': 'DEF', 'def': 'GHI'})
    except AnsibleError as e:
        assert e.msg == 'Unable to use "ab(c" as a search parameter: unbalanced parenthesis'

    # Test with a valid regex
    lookup_module = LookupModule()
   

# Generated at 2022-06-21 07:01:11.655451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run(terms=['^qz_.+'])

# Generated at 2022-06-21 07:01:21.369105
# Unit test for constructor of class LookupModule
def test_LookupModule():
     assert True

# Generated at 2022-06-21 07:01:29.178825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    if not os.path.exists('./test/units/plugins/lookup/varnames/lookup_plugins/varnames.py'):
        raise Exception('No path to lookup plugins')

    # noinspection PyUnresolvedReferences
    import sys
    sys.path.append('./test/units/plugins/lookup/varnames/lookup_plugins/')

    display = Display()


# Generated at 2022-06-21 07:01:30.629947
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 07:01:42.786075
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:01:50.573122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of LookupModule
    lookup_module_obj = LookupModule()
    # Invoke the run method of class LookupModule with different parameters
    assert lookup_module_obj.run(terms=['qz_1', 'qz_2'], variables={'qz_1': 'hello',
                                                                     'qz_2': 'world',
                                                                     'qa_1': 'I won\'t show',
                                                                     'qz_': 'I won\'t show either'}) == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:01:52.115020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l

# Generated at 2022-06-21 07:01:52.935784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-21 07:02:04.713096
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var1 = 'qz_1'
    var2 = 'qz_2'
    var3 = 'qa_1'
    var4 = 'qz_'
    var5 = 'qz_3'
    var6 = 'qz_4'
    vars = {var1: 'hello',
            var2: 'world',
            var3: "I won't show",
            var4: "I won't show either",
            var5: "I won't show either"}

    # Testing a simple pattern
    def test_run_method_1(qz_1, qz_2, var3, var4, var5, terms, variables):

        lookup_plugin = LookupModule()
        result = lookup_plugin.run(terms, variables, 'qz_1')

# Generated at 2022-06-21 07:02:13.703709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import re
    class TestVars(object):
        var_1 = 'hello'
        var_2 = 'world'
        var_3 = 'this'
        var_4 = 'that'

    # set up test environment
    lm = LookupModule()
    terms = ['^var_1$', '^var_2$', '^var_3$']
    variable_names = list(TestVars.__dict__.keys())

    # test
    lm.run(terms, variables=TestVars.__dict__)
    for term in terms:
        name = re.compile(term)
        for varname in variable_names:
            if name.search(varname):
                print(varname)

# Generated at 2022-06-21 07:02:18.583839
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup.set_options({'_ansible_check_mode': True})

    # Empty search
    assert lookup.run([''], {'var': 'test'}) == []
    assert lookup.run(['bad'], {'var': 'test'}) == []
    assert lookup.run(['test'], {'var': 'test'}) == ['var']


# Generated at 2022-06-21 07:02:39.502255
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert hasattr(module, 'set_options')
    assert hasattr(module, 'run')

# Generated at 2022-06-21 07:02:51.345254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule
    test_lookup_module = LookupModule()
    # Assert for the return of function run
    assert test_lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_' : 'I won\'t show either'}) == ['qz_1', 'qz_2']
    # Assert for the return of function run
    assert test_lookup_module.run([''], {'a1': 'hello', 'a2': 'hello', 'a3': 'hello', 'a4': 'hello'}) == []
    # Assert for the return of function run

# Generated at 2022-06-21 07:02:57.485433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.varnames as varnames

    # Setup
    lookup_instance = varnames.LookupModule()

    # Note: The above code is not needed in a normal playbook. The lookup plugin loader will create and call
    # run() automatically. The statement above is only needed in a unit test.

    terms = ["^v1_.+", "^v2_.+"]
    variables = {
        "v1_1": "value1_1",
        "v1_2": "value1_2",
        "v2_1": "value2_1",
        "v2_2": "value2_2",
        "v3_1": "value3_1",
    }

    # Execute
    ret = lookup_instance.run(terms, variables)

    # Verify

# Generated at 2022-06-21 07:02:59.833274
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 07:03:10.617975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['^qz_.+', 'hosts', '.+_zone$', '.+_location$']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either",
                 'hosts': 'test',  'test_zone': 'zone1', 'test_location': 'loc1'}
    try:
        ret = lookup_module.run(terms, variables)
        assert ret == ['qz_1', 'qz_2', 'hosts', 'test_zone', 'test_location']
    except Exception as e:
        ret = None
        assert False, 'unexpected exception  %s' % to_native(e)

# Generated at 2022-06-21 07:03:13.542307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # This call is the same as what the Ansible engine makes:
    l.run(['hosts'], { 'hosts': [], 'hosts_qwer': []})
    l.run(['^hosts_'], { 'hosts': [], 'hosts_qwer': []})
    l.run(['qwer'], { 'qwer': [], 'qwerty': [], 'something': []})
    # TBD: Can we test the exceptions?

# Generated at 2022-06-21 07:03:15.554741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule

    lookup_instance = LookupModule()
    assert(isinstance(lookup_instance, LookupBase))

# Generated at 2022-06-21 07:03:19.889803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['^qz_.+']
  variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
  testResult = LookupModule().run(terms, variables)
  assert testResult == ['qz_2', 'qz_1']

# Generated at 2022-06-21 07:03:21.878278
# Unit test for constructor of class LookupModule
def test_LookupModule():

    my_module = LookupModule()
    print(my_module)

# Generated at 2022-06-21 07:03:24.897349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lol = LookupModule()
    assert(lol)


# Generated at 2022-06-21 07:04:13.715891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lookup_plugin = LookupModule()

    # create a mock variables argument
    variables = {
        'my_var_1': 'This is my var 1 value',
        'my_var_2': 'This is my var 2 value',
        'your_var_1': 'This is your var 1 value',
        'your_var_2': 'This is your var 2 value'
    }

    # run the lookup plugin, only search for the 'my' varialbes
    result = lookup_plugin.run(terms='my_var', variables=variables)
    assert result == ['my_var_1', 'my_var_2']

    # run the lookup plugin, search all variables
    result = lookup_plugin.run(terms='^.*', variables=variables)

# Generated at 2022-06-21 07:04:19.192927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test the run method of class LookupModule, which returns a list of Ansible variable names which
    match a regex (or several regexes) which the user provides.
    '''
    # Import modules needed to run the test
    import doctest

    # Instantiate the LookupModule class
    lm = LookupModule()

    # Create a test variables dict, since in production lookup() gets this as an argument
    vars = {
        'hosts_list': 'hosts.hosts',
        'hosts_group_list': 'hosts.hostsgroups',
        'hosts_list_groups': 'hosts.hostsgroups',
    }

    # Create test cases, in the form of a list of tuples (input_terms, expected_output_list)
    # Also test out the optional 'variables' and '

# Generated at 2022-06-21 07:04:20.880448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 07:04:22.971615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert isinstance(my_lookup, LookupBase)


# Generated at 2022-06-21 07:04:25.256104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 07:04:27.599398
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    print("Successfully instantiated LookupModule class")

# Generated at 2022-06-21 07:04:30.291798
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 07:04:38.298776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var

    vars_manager=VariableManager()
    templar = Templar(variables=vars_manager)

    # Build some variables
    vars_manager.set_nonpersistent_facts(dict())
    vars_manager._fact_cache = dict()
    vars_manager._host_cache = dict()

    # set a few vars
    vars_manager._host_cache["localhost"] = dict()
    vars_manager._host_cache["localhost"]["my_fav_num"] = 5

# Generated at 2022-06-21 07:04:47.249017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=E1123
    from ansible.utils.display import Display
    display = Display()

    lookup_module = LookupModule()

    # test valid regex
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
        "hosts": "something to match"
    }
    lookup_module.Display = display
    results = lookup_module.run(['^qz_.+'], variables)
    assert results == ['qz_1', 'qz_2']

    # test invalid regex
    results = lookup_module.run(['****.#++'], variables)
    assert len(results) == 0

    # test valid regex and match

# Generated at 2022-06-21 07:04:48.135900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 07:06:25.329714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    variables = {'a': 1, 'b': 2}
    terms = ["a", "d"]
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule.run(terms, variables)
    assert 'No variables available to search' in str(excinfo.value)


# Generated at 2022-06-21 07:06:37.962606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    i = {'one': 1, 'two': 2, 'three': 3}
    assert l.run(['one'], variables=i) == ['one']
    assert l.run(['.+'], variables=i) == ['one', 'two', 'three']
    assert l.run(['t.+'], variables=i) == ['two', 'three']
    assert l.run(['^t.+'], variables=i) == ['three']
    assert l.run(['two|three'], variables=i) == ['two', 'three']
    assert l.run(['four'], variables=i) == []
    assert l.run([''], variables=i) == []

# Generated at 2022-06-21 07:06:45.583602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule
    """
    class Options(object):
        """Options class
        """

# Generated at 2022-06-21 07:06:57.825428
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test that it throws an error if no variables are provided
    lookup_module = LookupModule()
    try:
        lookup_module.run(['foo'])
        assert False, 'Should error if no variables provided'
    except AnsibleError:
        pass

    # Test that it can list all variables
    variables = {
        'foo': 'bar',
        'one_thing': 'another thing'
    }
    lookup_module = LookupModule()
    result = lookup_module.run(['.'], variables=variables)
    assert len(result) == 2
    assert 'foo' in result
    assert 'one_thing' in result

    # Test that it can use regex to find a term
    lookup_module = LookupModule()
    result = lookup_module.run(['^f.+'], variables=variables)

# Generated at 2022-06-21 07:07:06.418543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert l.run(terms=['^qz_.+']) == ['qz_1', 'qz_2']
    assert l.run(terms=['.+']) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert l.run(terms=['hosts']) == []
    assert l.run(terms=['.+_zone$', '.+_location$']) == []

# Generated at 2022-06-21 07:07:08.870353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys

    sys.path.append(os.getcwd() + "/tests/integration/testdata")
    from variables import TEST_VARIABLES

    test_object = LookupModule()
    result = test_object.run(["^qz_.+"], TEST_VARIABLES)
    assert result == ["qz_1", "qz_2"]

# Generated at 2022-06-21 07:07:12.926748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test LookupModule is instantiated correctly
    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-21 07:07:15.570858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for the constructor
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 07:07:22.089666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of lookup module
    lookup_module = LookupModule()

    # Setup the variable for lookup_module

# Generated at 2022-06-21 07:07:29.062216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_options(var_options={'ansible_distribution': 'CentOS'}, direct={'what': 'nothing'})
    assert mod.run(['.+_distribution']) == ['ansible_distribution']
    assert mod.run(['^ansible_', '_distribution$']) == ['ansible_distribution']
    assert mod.run(['nonexistent']) == []