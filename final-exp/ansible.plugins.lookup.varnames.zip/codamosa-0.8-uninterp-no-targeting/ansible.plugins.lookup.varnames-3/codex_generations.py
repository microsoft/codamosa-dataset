

# Generated at 2022-06-21 06:58:33.573951
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = dict(a=1, b=2, c=3, d=4, e=None)

    terms = ['^a$', '^b$', '^c$', '^d$', '^e$']
    expected_results = [1, 2, 3, 4, None]

    test_lookup = LookupModule()
    results = test_lookup.run(terms=terms, variables=variables, direct={})

    assert results == expected_results

# Generated at 2022-06-21 06:58:39.574500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    assert module.run(['^qz_.+'], variables=variables) == ['qz_1', 'qz_2', 'qz_']
    assert module.run(['.+'], variables=variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    assert module.run(['hosts'], variables={'hosts': 'example.com'}) == ['hosts']

# Generated at 2022-06-21 06:58:47.724641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check the case that invalid variables is provided.
    terms = ['^qz_.+']
    variables = None
    lkp = LookupModule()
    lkp.set_options()
    try:
        lkp.run(terms, variables)
    except Exception as e:
        assert 'No variables available to search' in to_native(e)

    # Check the case that invalid term is provided.
    terms = 1
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lkp = LookupModule()
    lkp.set_options()

# Generated at 2022-06-21 06:58:56.798953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    varnames_lookup_mod = LookupModule()
    vars1 = {'qa_1': 'I wont show', 'qz_1': 'hello', 'qz_2': 'world', 'qz_': 'I wont show either'}
    terms = ['^qz_.+']

    test_return = varnames_lookup_mod.run(terms, variables=vars1)
    assert test_return == ['qz_1', 'qz_2']

# Generated at 2022-06-21 06:58:58.022587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:59:02.828031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing init of LookupModule
    module = LookupModule()
    assert module is not None, "Problem in instantiating LookupModule"
    assert isinstance(module, LookupModule), "Problem in instantiating LookupModule"

# Generated at 2022-06-21 06:59:09.718407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    result = l.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_1', 'qz_2']

    l = LookupModule()
    result = l.run(terms=['.+_zone$'], variables={'host_1': {'host_zone': 'hello'}, 'host_2': {'host_zone': 'world'}})
    assert result == ['host_1', 'host_2']

    l = LookupModule()

# Generated at 2022-06-21 06:59:15.454602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    class_instance = LookupModule()
    assert json.loads(json.dumps(class_instance, default = lambda o: o.__dict__, sort_keys=True)) == {"_options": {"direct": {}, "var_options": {}}}

# Generated at 2022-06-21 06:59:23.149612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = dict()
    variables["ansible_os_family"] = "RedHat"
    variables["ansible_distribution_version"] = "7.3"
    variables["ansible_architecture"] = "x86_64"
    assert LookupModule().run(terms=['ansible_os_family'], variables=variables) == ["ansible_os_family"]
    assert LookupModule().run(terms=['ansible_os_family', 'ansible_architecture'], variables=variables) == ["ansible_os_family", "ansible_architecture"]
    assert LookupModule().run(terms=['ansible_os_family', 'ansible_architecture', 'ansible_architecture'], variables=variables) == ["ansible_os_family", "ansible_architecture"]

# Generated at 2022-06-21 06:59:35.610053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class options():
        def __init__(self):
            self.variable_start_string = ''
            self.variable_end_string = ''
            self.block_start_string = ''
            self.block_end_string = ''
            self.group_start_string = ''
            self.group_end_string = ''
            self.jinja2_extensions = ''

    class variableManager():
        def __init__(self):
            self.vars = {'test': 'var'}

    lookup = LookupModule()
    lookup.set_options(var_options=variableManager(), direct=options())

    assert len(lookup.run(['test'], variables={'test': 'var'})) == 1

# Generated at 2022-06-21 06:59:42.849067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = {'abc': 123, 'yzyzyz': 999}
    l = LookupModule()
    l.set_options(var_options=variables, direct=None)
    assert l

# We use the same test for LookupModule.run

# Generated at 2022-06-21 06:59:44.330220
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)

# Generated at 2022-06-21 06:59:46.079776
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Constructor for class LookupModule
    '''
    assert LookupModule()

# Generated at 2022-06-21 06:59:46.574317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:59:59.317337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    input_data = """
    qz_1: hello
    qz_2: world
    qa_1: "I won't show"
    qz_: "I won't show either"
    """

    loader = DataLoader()
    vars_data = loader.load(input_data)

    lm = LookupModule()
    terms = ['^qz_.+']
    results = lm.run(terms, variables=vars_data)
    assert results == [b'qz_1', b'qz_2']
    terms = ['.+']

# Generated at 2022-06-21 07:00:12.183347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = []
    lu = LookupModule()
    try:
        lu.run(ret)
    except Exception as e:
        ret.append(to_native(e))
    assert ret[0] == "No variables available to search"

    ret = []
    variables = {"hello": "world", "derp": "herp", "server": "world"}
    term = []
    try:
        lu.run(term, variables)
    except Exception as e:
        ret.append(to_native(e))
    assert ret[0] == "Invalid setting identifier, \"derp\" is not a string, it is a <class 'str'>"

    ret = []
    variables = {"hello": "world", "derp": "herp", "server": "world"}
    term = "abc123"

# Generated at 2022-06-21 07:00:13.304791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 07:00:24.520591
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(terms=["test"], variables=None)
    assert 'No variables available to search' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(terms=["test"], variables={})
    assert 'No variables available to search' in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(terms=[None], variables={'var': 'test'})
    assert 'Invalid setting identifier, "None" is not a string, it is a <type \'NoneType\'>' in str(excinfo.value)


# Generated at 2022-06-21 07:00:27.090888
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """My test"""
     # pylint: disable=no-self-use
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 07:00:37.342432
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = None
    terms = ['^qz_.*']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    lookup_modl = LookupModule()

    expected_result = ['qz_1', 'qz_2']
    result = lookup_modl.run(terms, variables, module=module)
    assert result == expected_result

# Generated at 2022-06-21 07:00:45.074054
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.get_options({}) == {'_terms': []}

# Generated at 2022-06-21 07:00:55.070484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Testing default value of variables
    try:
        lookup.run(None, None)
    except AnsibleError:
        pass
    # Testing with no variables and terms
    terms = []
    variables = {}
    result = lookup.run(terms, variables)
    assert result == []
    # Testing empty terms
    terms = []
    variables = {'a.b.c': 1}
    result = lookup.run(terms, variables)
    assert result == []
    # Testing no matching terms
    terms = ['non_matching_term']
    variables = {'a.b.c': 1}
    result = lookup.run(terms, variables)
    assert result == []
    # Testing with matching terms but no variables
    terms = ['^qz_.+']
    variables = {}
    result

# Generated at 2022-06-21 07:00:56.353808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:01:04.594139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    lu = LookupModule()
    terms = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    res = lu.run(terms, variables)
    assert res == ['qz_1', 'qz_2']

    terms = '.+'
    variables = {'item1': 'hello', 'item2': 'world'}
    res = lu.run(terms, variables)
    assert res == ['item1', 'item2']

    terms = 'hosts'
    variables = {'item1': 'hello', 'item2': 'world', 'hosts': 'localhost'}
   

# Generated at 2022-06-21 07:01:13.882169
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    vars_dict = {
      "test": "string",
      "test_string": "string",
      "test_dict": {
        "key1": "value1",
        "key2": "value2"
      },
      "test_list": [
        "str1",
        "str2"
      ]
    }

    test = LookupModule()

    assert set(test.run(["test_dict"], variables=vars_dict)) == set(["test_dict"])
    assert set(test.run(["test"], variables=vars_dict)) == set(["test"])
    assert set(test.run([".+"], variables=vars_dict)) == set(["test", "test_string", "test_dict", "test_list"])

# Generated at 2022-06-21 07:01:17.678138
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        module = LookupModule()
        assert False, "Error in constructor of class LookupModule"
    except NotImplementedError as e:
        assert True, "Pass: Error raised in constructor of class LookupModule"


# Generated at 2022-06-21 07:01:25.503721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    result = ["debug", "msg", "lookup('varnames', '^qz_.+')", "vars", "qz_1", "qz_2", "qa_1", "qz_"]
    result_list = module.run(["^qz_.+"], {"msg": "Hello world"})
    assert result == result_list

# Generated at 2022-06-21 07:01:30.115783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.loader import DumperLoader

    class DummyDisplay:
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            return msg

    display = DummyDisplay()
    my_lookup = LookupModule(display=display)
    my_lookup.set_loader(DumperLoader())

# Generated at 2022-06-21 07:01:42.516494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.module_utils.six import PY2

    FakeModule = namedtuple('FakeModule', [
        'params',
        'check_mode',
        'no_log',
    ])

    FakeModule.params = {}
    FakeModule.no_log = False
    FakeModule.check_mode = False
    lookup = LookupModule()

    #test invalid term
    terms = [5]
    try:
        lookup.run(terms)
    except Exception as e:
        assert(isinstance(e, AnsibleError))

    #test invalid variables
    terms = ['^qz_.+']
    try:
        lookup.run(terms, variables=None)
    except Exception as e:
        assert(isinstance(e, AnsibleError))

    #test run_single


# Generated at 2022-06-21 07:01:45.685325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()
    assert lookup.get_loader() == DataLoader()

# Generated at 2022-06-21 07:02:01.062958
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_from_var = LookupModule()
    var_dict={'a':1, 'b':2, 'c':3}
    assert(lookup_from_var.run(["a", "c"], variables=var_dict)==['a', 'c'])

# Generated at 2022-06-21 07:02:12.616118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    terms = ['^qz_.+', '.+_zone$']
    variables_dict = {'qz1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    variables = None
    result_ret = test_LookupModule.run(terms, variables)
    assert result_ret == []
    result_ret = test_LookupModule.run(terms, variables_dict)
    assert result_ret == ['qz_2']
    assert result_ret != ['qz_1']
    result_ret = test_LookupModule.run(['abc_zone'], variables_dict)
    assert result_ret == []

# Generated at 2022-06-21 07:02:16.828174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert ret == ['qz_1', 'qz_2']
    ret = LookupModule().run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:02:17.527447
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:02:26.519201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test void terms
    terms = []
    variables = {
        "INVENTORY_foo" : None,
        "INVENTORY_bar" : None,
        }
    result = lookup.run(terms, variables)
    assert result == [], "Invalid result: %s" % result

    # Test single term
    terms = ["INVENTORY_foo"]
    variables = {
        "INVENTORY_foo" : None,
        "INVENTORY_bar" : None,
        }
    result = lookup.run(terms, variables)
    assert result == ["INVENTORY_foo"], "Invalid result: %s" % result

    # Test multiple terms (regex)
    terms = ["INVENTORY_.+"]

# Generated at 2022-06-21 07:02:35.379985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'test': 'what',
        'test_zone': 'hello',
        'test_location': 'world',
        'test_zones': 'not me',
        'test_locations': 'not me',
    }

# Generated at 2022-06-21 07:02:43.776790
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Generate text to be used in a test
    terms = ['^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Test method run
    assert(LookupModule().run(terms, variables) == ['qz_1', 'qz_2', 'qz_1', 'qz_2', 'qa_1', 'qz_', 'qz_1', 'qz_2', 'qa_1', 'qz_'])



# Generated at 2022-06-21 07:02:45.765034
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert did_run == 1

# Run the test
lookup = LookupModule()
did_run = 0

if __name__ == '__main__':
    test_LookupModule()
    did_run = 1

# Generated at 2022-06-21 07:02:54.387392
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_varnames = LookupModule()

    #
    # Normal use
    #
    mock_variables = dict(
        qz_1 = 'value1',
        qz_2 = 'value2',
        qa_1 = 'value3',
        qz_  = 'value4',
    )

    # Get all variables that start with "qz_"
    terms = ['^qz_.+']
    ret = lookup_varnames.run(terms, variables=mock_variables)

    assert ret == ['qz_1', 'qz_2']

    # Get all variables
    terms = ['.+']
    ret = lookup_varnames.run(terms, variables=mock_variables)

    assert ret == mock_variables.keys()

    # Get variables with "hosts

# Generated at 2022-06-21 07:02:54.776910
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 07:03:22.610920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup = LookupModule()

# Generated at 2022-06-21 07:03:32.794848
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:03:35.369913
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin,LookupModule)


# Generated at 2022-06-21 07:03:43.388509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run(terms, variables=None, **kwargs):
        lookup_obj = LookupModule()
        return lookup_obj.run(terms, variables, **kwargs)

    terms = ['a_string', 'another_string', '^string']
    variables = {'a_string': 'a', 'another_string': 'b', 'string': 'c'}
    # comment the line above to test the error
    # variables = None

    try:
        assert run(terms, variables) == ['a_string', 'another_string', 'string']
    except AnsibleError as e:
        print(e)
        if e.args[0] != "No variables available to search":
            raise

if __name__ == '__main__':
    # for unit test
    test_LookupModule_run()

# Generated at 2022-06-21 07:03:52.854493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule
    lookup_module = LookupModule()
    # Check the parameters
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup_module.run(['^qa_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == []

# Generated at 2022-06-21 07:04:03.870328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import unittest

    class TestAnsibleVarnames(unittest.TestCase):

        def setUp(self):
            global lookup_plugin
            lookup_plugin = LookupModule()
            self.vars_in_playbook = {}
            self.terms_in_playbook = []

        def tearDown(self):
            del os.environ['ANSIBLE_VAR_A']
            del os.environ['ANSIBLE_VAR_B']

        def set_environment_vars(self):
            os.environ['ANSIBLE_VAR_A'] = 'foo'
            os.environ['ANSIBLE_VAR_B'] = 'bar'


# Generated at 2022-06-21 07:04:05.253538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 07:04:15.131799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    lookup_plugin.varname.LookupModule.run test methods
    """
    import pytest
    # pylint: disable=no-member
    module = pytest.importorskip("ansible.plugins.lookup")
    # pylint: enable=no-member
    module.lookup_loader._lookup_cache.clear()
    module.lookup_loader.add_directory(module.__path__[0])
    lookup = module.lookup_loader.get('varname')
    assert lookup


# Generated at 2022-06-21 07:04:25.006051
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ############################
    # Test case 1:
    #
    # In this test case, a list of variables that start with 'qa' is retrieved.
    # The term used is '^qa'. Note that the regex pattern is to search for the
    # beginning of the string.
    ############################
    print('Test case 1')
    terms = ['^qa']
    variables = {'qa_1': 123, 'qa_2': 456, 'qb': 789}
    lm = LookupModule()
    results = lm.run(terms, variables)
    print('The results are:')
    print(results)
    if results == ['qa_1', 'qa_2']:
        print('Test case 1 passed.')
    else:
        print('Test case 1 failed!')
        sys.exit(1)

# Generated at 2022-06-21 07:04:36.864536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile

    l = LookupModule()
    l.environment = os.environ.copy()
    fd, path = tempfile.mkstemp()
    l.environment["_ANSIBLE_VAR_BASEDIR"] = path
    l.environment["_ANSIBLE_VAR_CACHE"] = '1'
    l.environment["_ANSIBLE_VAR_FILE_CACHE"] = '1'
    l.get_basedir = lambda t: path
    l.get_basedir_dynamically = lambda t: path
    l.set_options({}, [{'_terms': ['^qz_.+'], '_params': {}, '_ansible_positional_args': []}])
    l.run([])
    l.run(['^qz_.+'])

# Generated at 2022-06-21 07:05:32.522764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 07:05:34.080807
# Unit test for constructor of class LookupModule
def test_LookupModule():
    temp = LookupModule()

# Unit test to check the kind of information 'LookupModule' class returns

# Generated at 2022-06-21 07:05:45.104520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with required values
    lookup_plugin = LookupModule()
    terms = ['test1', 'test2']
    variables = {'test1': 'Hello', 'test2': 'World', 'test3': 'Ansible'}
    ret = lookup_plugin.run(terms, variables)
    assert ret == terms

    # Testing with regex pattern
    regex_pattern = '^test1'
    ret = lookup_plugin.run([regex_pattern], variables)
    assert ret == ['test1']

    # Testing with invalid type in terms
    try:
        lookup_plugin.run({'test': 'Hello'}, variables)
    except AnsibleError as err:
        assert err.message == 'Invalid setting identifier, "test" is not a string, it is a <class \'dict\'>'

    # Testing with invalid regex
   

# Generated at 2022-06-21 07:05:46.899508
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:05:47.784852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-21 07:05:57.224018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    test_vars = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I will not show',
        'qz_': 'I will not show either',
    }
    assert test_lookup.run(['^qz_.+'], test_vars) == ['qz_1', 'qz_2']
    assert test_lookup.run(['.+'], test_vars).sort() == ['qz_', 'qz_1', 'qz_2', 'qa_1'].sort()
    assert test_lookup.run(['.+[^_]'], test_vars).sort() == ['qz_1', 'qz_2', 'qa_1'].sort()


# Generated at 2022-06-21 07:06:08.164765
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_run(terms, variables, expected):
        lookup_instance = LookupModule()
        result = lookup_instance.run(terms, variables, **{})
        return result == expected

    # Can't use assert here, since it returns a boolean
    print('Test 1: Pass') if test_run(['^qa_.+'], {'qa_1': 'hello', 'qa_2': 'world', 'qb_1': 'I won\'t show'}, ['qa_1', 'qa_2']) else print('Test 1: Fail')

# Generated at 2022-06-21 07:06:18.598356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert LookupModule().run(['.+'], {'test': 'hello', 'test2': 'world'}) == ['test', 'test2']
    assert LookupModule().run(['hosts'], {'hosts': 'hello', 'test2': 'world'}) == ['hosts']

# Generated at 2022-06-21 07:06:28.152264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = { 'quz_1': 'hello', 'quz_2': 'world', 'qa_1': "I won't show", 'qz_': 'I wont show either' }
    looku = LookupModule()
    terms = ['^quz_.+']
    result1 = looku.run(terms, variables)
    assert result1 == ['quz_1', 'quz_2']

    terms = ['qa_1']
    result2 = looku.run(terms, variables)
    assert result2 == []

    terms = ['qa_']
    result3 = looku.run(terms, variables)
    assert result3 == ['qa_1']

    terms = ['^qz_']
    result4 = looku.run(terms, variables)
    assert result4 == ['qz_']


# Generated at 2022-06-21 07:06:31.418074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Construct an instance of LookupModule class
    lookup = LookupModule()
    # Check constructor
    assert lookup.set_options
    assert lookup.run