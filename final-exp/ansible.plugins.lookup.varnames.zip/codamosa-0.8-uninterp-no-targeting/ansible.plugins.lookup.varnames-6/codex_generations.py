

# Generated at 2022-06-21 06:58:24.081860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-21 06:58:36.437554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variable_names = {
        'hosts': [],
        'myhosts': [],
        'myhosts_groups': [],
        'myhosts_zone': 'us-east-1c',
        'myhosts_location': 'us-east-1c',
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'my_var': {'i': 'am_not_a_str', 'nested': 'nested_str'}
    }

# Generated at 2022-06-21 06:58:39.017631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testlookup = LookupModule()
    assert isinstance(testlookup, LookupModule)


# Generated at 2022-06-21 06:58:50.108384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    term = '^qz_.+'
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}
    n_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either', 'qz_3': 'another one'}
    terms = ['^qz_.+']
    n_terms = ['^qz_.+', '.+_zone$', '.+_location$']
    result = lookup.run(terms, variables)
    n_result = lookup.run(n_terms, n_variables)
    assert term in result

    #Test with

# Generated at 2022-06-21 06:58:56.774967
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lk = LookupModule()

    # Test matching variables
    variables = {'host_zone': 'us-1', 'host_location': 'us-2', 'db_zone': 'us-1'}
    vars_result = lk.run(['^[a-z]_zone'], variables)

    assert vars_result == ['host_zone', 'db_zone'], vars_result

    # Test no variables
    variables = {}
    vars_result = lk.run(['^[a-z]_zone'], variables)

    assert vars_result == [], vars_result

# Generated at 2022-06-21 06:59:07.055335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 'AnsibleError' in str(l.run(["^qz_.+"], {}))
    assert 'Invalid setting identifier' in str(l.run([{}, 1, 3.2, [], (1, 2, 3)]))
    assert 'Unable to use' in str(l.run(['*']))
    assert 'Unable to use' in str(l.run(['(a+']))
    assert 'Unable to use' in str(l.run(['(ab)+']))


# Generated at 2022-06-21 06:59:19.612266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    n = LookupModule()

    # Test no variable
    try:
        n.run([])
        assert False
    except AnsibleError as e:
        assert str(e) == 'No terms provided to lookup vars'
    except:
        assert False

    # Test invalid terms
    try:
        n.run(['invalid'])
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "invalid" is not a string, it is a <class \'str\'>'
    except:
        assert False

    # Test invalid search
    try:
        n.run(['[abc'])
        assert False
    except AnsibleError as e:
        assert str(e) == 'Unable to use "[abc" as a search parameter: unexpected end of regular expression'
   

# Generated at 2022-06-21 06:59:24.453862
# Unit test for constructor of class LookupModule
def test_LookupModule():
  a = ['a', 'b', 'c']
  b = {'a': 1, 'b': 2, 'c': 3}
  p = LookupModule()
  p.run(a, variables=b)

# Generated at 2022-06-21 06:59:28.228874
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This function is used to test the constructor of class LookupModule
    """
    obj = LookupModule()
    assert isinstance(obj, LookupModule)


# Generated at 2022-06-21 06:59:29.586604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    plugin = LookupModule()
    assert isinstance(plugin, LookupModule)

# Generated at 2022-06-21 06:59:39.303376
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test without variables, no exception
    try:
        module = LookupModule()
        module.run(['**'])
    except Exception:
        assert False

    # Test with variables, no exception
    try:
        module = LookupModule()
        module.run(['**'], variables={'a':'b'})
    except Exception:
        assert False

    # Test with list of variables, no exception
    try:
        module = LookupModule()
        module.run(['**'], variables=[{'a':'b'}])
    except Exception:
        assert False

# Generated at 2022-06-21 06:59:40.168685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 06:59:49.921248
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    '''
    This method tests the run method of LookupModule.

    :return: None
    '''

    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Create an instance of AnsibleError
    ansible_error = AnsibleError()

    # Create variables dictionary

# Generated at 2022-06-21 06:59:54.206413
# Unit test for constructor of class LookupModule
def test_LookupModule():
  result = LookupModule()
  assert isinstance(result, LookupModule)
  assert hasattr(result, 'run')
  assert callable(result.run)



# Generated at 2022-06-21 07:00:01.735598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '.+_zone$', '.+_location$']
    variables = {'qz_1': "hello", 'qz_2': "world", 'qa_1': "I won't show", 'qz_': "I won't show either",
                 'my_zone': "my zone", 'my_location': "my location", 'my_loc': "my loc", 'my_zone2': "my zone2" }

    expected_result = ['qz_1', 'qz_2', 'my_zone', 'my_location']

    lookup_obj = LookupModule()
    result = lookup_obj.run(terms, variables)

    assert result == expected_result

# Generated at 2022-06-21 07:00:04.513976
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import re
    assert re.search('ansible.plugins.lookup.varnames', str(LookupModule))

# Unit tests for methods in LookupModule

# Generated at 2022-06-21 07:00:08.435132
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.plugins.lookup.varnames import LookupModule

    lookup_object = LookupModule()
    assert lookup_object is not None

# Generated at 2022-06-21 07:00:16.363962
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create test object
    l = LookupModule()

    # test if runs for version Ansible < 2.8
    class LookupModule_class(object):
        def __init__(self):
            self.params = {"__ansible_module__": "random name"}
    l.set_connection_info({"ad_hoc_context": {"loader": LookupModule_class()}})
    assert isinstance(l.run(terms=["^qz_.+"]), list) is True

    # test if raises error if terms is not of type list
    try:
        l.run(terms="^qz_.+")
    except AnsibleError as e:
        assert "must be a list" in to_native(e)

    # test if raises error if variables is not defined

# Generated at 2022-06-21 07:00:25.787018
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Assert variables are None
    lookup = LookupModule()
    variables = None
    assert lookup.run(terms='not_a_number', variables=variables) == []

    # Assert types are valid
    lookup = LookupModule()
    variables = {'0': 'zero', '1': 'one', '2': 'two'}
    assert lookup.run(terms=None, variables=variables) == []
    assert lookup.run(terms='not_a_number', variables=variables) == []

    # Assert regex search terms
    lookup = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

# Generated at 2022-06-21 07:00:33.973714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

# Generated at 2022-06-21 07:00:47.505853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockLookupModule(LookupModule):
        # override run method
        def run(self, terms, variables=None, **kwargs):
            return terms

    # ansible.parsing.dataloader.Loader adds a '_original_file' variable to
    # variables. So, we must add this variable for the test purpose.
    variables = {'_original_file': 'some_file'}

    LookupModule = MockLookupModule()
    assert LookupModule.run(['a'], variables) == ['a']



# Generated at 2022-06-21 07:00:48.624581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()

    assert isinstance(test_instance, LookupModule)


# Generated at 2022-06-21 07:00:52.318447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # simple search of name
    assert(lookup.run(['.+_zone$']) == ['ip_zone'])
    # search with multiple regex
    assert(lookup.run(['.+_zone$', '.+_location$']) == ['ip_zone', 'ip_location'])

# Generated at 2022-06-21 07:00:58.016468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={})
    assert l.run(['invalid'], {}) == []
    assert l.run(['invalid'], {'specific': 'value'}) == []
    assert l.run(['^specific'], {'specific': 'value'}) == ['specific']
    assert l.run(['^not'], {'specific': 'value'}) == []

# Generated at 2022-06-21 07:01:00.766000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-21 07:01:09.444548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a lookup module with a set of variables.
    variables = {
        'test_1': 'var1',
        'test_2': 'var2',
        'test_3': 'var3',
        'test_4': 'var4',
    }
    lookup = LookupModule()

    # Set the options of the constructor to include the variables, and kill direct.
    # Direct is unused, but needs to be killed.
    lookup.set_options(var_options=variables, direct={})

    # test_1, test_2, test_3 and test_4 are all included in this case.
    result = lookup.run(terms=['test_.+'])


# Generated at 2022-06-21 07:01:11.130457
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    term = 'hosts'
    assert lookup.run(term)

# Generated at 2022-06-21 07:01:11.956896
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


# Generated at 2022-06-21 07:01:19.540980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    import sys
    import inspect
    # Check that the class write_debug is a subclass of PlayBase
    assert issubclass(lookup_module.__class__, lookup_module),   "class PlayBase not subclass of itself"
    # Check that the constructor of class PlayBase takes no arguments
    assert inspect.getargspec(lookup_module.__init__).args == ['self'], "class PlayBase mismatch in arguments to constructor"
    # Check that the constructor of class PlayBase takes no arguments
    assert inspect.getargspec(lookup_module.__init__).varargs == None, "class PlayBase mismatch in arguments to constructor"
    # Check that the constructor of class PlayBase takes no arguments

# Generated at 2022-06-21 07:01:30.718630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Test detecting wrong variable types and regex errors'''

    import sys

    # Patch sys.argv
    # Use the specified argv otherwise the test fails when using --failed-when-no-hosts
    if 'sys.argv' in sys.modules['__main__'].__dict__:
        sys_argv_backup = sys.argv
    sys.argv = sys.modules['__main__'].__dict__['sys.argv']

    # Use the real main function from the lookup plugin
    main = sys.modules['ansible.plugins.lookup.varnames'].main

    # Silence the deprecation warnings
    sys.modules['ansible.utils.display'].deprecated = lambda *args, **kwargs: None


# Generated at 2022-06-21 07:01:56.151878
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['^qz_.+', 'hosts', '.+']
    variables = {'qz_1': 'hello',
                 'qz_2': 'world',
                 'qa_1': "I won't show",
                 'qz_': "I won't show either",
                 'some_value': 'Ansible',
                 'some_other_value': 'Ansible',
                 'some_other_value_hosts': 'Ansible',
                 'ansible_hosts': 'Ansible',
                 'target_hosts': 'Ansible',
                 'all_hosts': 'Ansible'}

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)

# Generated at 2022-06-21 07:02:01.930008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run(terms=['^qz_.+'], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})) == 2

# Unit tests for constructor of class LookupBase

# Generated at 2022-06-21 07:02:05.341048
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert isinstance(lm, LookupModule)
  assert isinstance(lm, object)


# Generated at 2022-06-21 07:02:06.204626
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert LookupModule()

# Generated at 2022-06-21 07:02:15.752081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    sys.path.append(os.path.dirname(__file__))
    from ansible.plugins.lookup import python_vars

    # Set up vars dict
    vars = {
        'admin_user': 'admin',
        'admin_password': 'Cl3v3rP@ssw0rd',
        'db_root_password': 'hard2Gu3ss',
        'db_backup_password': 'h@rd2Gu3ss',
        'db_log_dump_passwd': 'hard@Gu3ss',
        'db_backup_public_password': 'hrd2Gu3ss1',
        'db_backup_private_password': 'hrd2Gu3ss2'}

    lookup_mod = LookupModule()
    ret = []

   

# Generated at 2022-06-21 07:02:27.606558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run of class LookupModule
    """

    # Create an instance of class LookupModule
    lookup_module = LookupModule()

    # Create a dictionary with the variables
    variables = { "amq_port" : "8080", "amq_version" : "5.6.0" }

    # Call the method run
    ret = lookup_module.run(terms=["^amq_port$"], variables=variables, direct=False)

    # Assert the result
    assert ret == ["amq_port"]

    # Call the method run with a term that does not match any variables
    ret = lookup_module.run(terms=["^amq_port2$"], variables=variables, direct=False)

    # Assert the result
    assert ret == []

    # Call the method run with an invalid

# Generated at 2022-06-21 07:02:28.961531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule(), 'run')

# Generated at 2022-06-21 07:02:30.711892
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None

# Test that the run() function requires terms to be set - use BaseException to raise exception

# Generated at 2022-06-21 07:02:33.861847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    r = LookupModule()
    assert type(r) is LookupModule


# Generated at 2022-06-21 07:02:35.283537
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:03:19.213938
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    input_terms = ['^qz_.+', r'hosts', ['hosts', '.+_zone$', '.+_location$'], '^qz_.+', 'hosts', '.+_zone$', '.+_location$', r'hosts']


# Generated at 2022-06-21 07:03:26.689651
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(AnsibleError) as excinfo:
        l = LookupModule()
    assert "No variables available to search" in str(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        l = LookupModule(variables=None)
    assert "No variables available to search" in str(excinfo.value)

# Generated at 2022-06-21 07:03:34.159877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for LookupModule run method"""
    import os
    import sys
    from unittest.mock import patch

    from ansible.module_utils.basic import AnsibleModule

    from ansible.plugins.loader import lookup_loader

    # Fake ansible module arguments

# Generated at 2022-06-21 07:03:43.128056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for empty variable list
    class FakeVariableManager(dict):
        def get_vars(self):
            return self

        def __init__(self, variables_dict):
            super(FakeVariableManager, self).__init__(variables_dict)
            self.vars = self

    obj = LookupModule(None, loader=None, templar=None, shared_loader_obj=None)
    obj.set_environment(environment=FakeVariableManager({}))
    try:
        result = obj.run(None)
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError expected, no exception raised"

    class FakeVariableManager(dict):
        def get_vars(self):
            return self


# Generated at 2022-06-21 07:03:50.648676
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for constructor of class LookupModule.
    """
    module = LookupModule()

    # Make sure constructor sets attribues to the right types
    assert type(module._options) is dict
    assert type(module._templar) is object
    assert type(module._loader) is object
    assert type(module._templar) is object
    assert type(module._basedir) is string_types
    assert type(module._runner) is object
    assert type(module._datastore) is object

# Generated at 2022-06-21 07:04:01.822056
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test setup
    dummy_lookup = LookupModule()

    # test with good regex
    res1 = dummy_lookup.run(terms=['^qz_.+'])
    assert(res1 == [])

    # test with bad regex
    try:
        dummy_lookup.run(terms=['^qz_.'])
    except AnsibleError as e:
        print(type(e))
        print(e)
        assert(isinstance(e, AnsibleError))
    else:
        assert(False)

    # test with bad type
    try:
        dummy_lookup.run(terms=['qz_.', ['hello']])
    except AnsibleError as e:
        print(type(e))
        print(e)
        assert(isinstance(e, AnsibleError))
   

# Generated at 2022-06-21 07:04:13.748406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_vars = dict()
    test_vars['str_var'] = 'foo'
    test_vars['list_var'] = [1,2,3]
    test_vars['bool_var'] = True
    test_vars['dict_var'] = dict(foo=1,bar=2)

    l = LookupModule()
    l.set_options(var_options=test_vars, direct=dict())

    assert l.run(['.+']) == ['bool_var', 'dict_var', 'list_var', 'str_var']
    assert l.run(['bool_var']) == ['bool_var']
    assert l.run(['dict_var']) == ['dict_var']
    assert l.run(['list_var']) == ['list_var']
    assert l

# Generated at 2022-06-21 07:04:15.206352
# Unit test for constructor of class LookupModule
def test_LookupModule():
	module = LookupModule()

# Generated at 2022-06-21 07:04:25.018347
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ret = []
    lookup_module = LookupModule()
    ret.append(lookup_module.run(terms=['^qz_.+'], variables={'foo': 'bar'}))
    ret.append(lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'bar'}))
    ret.append(lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'bar', 'qa_1': 'baz'}))
    ret.append(lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'bar', 'qa_1': 'baz', 'qz_2': 'bar'}))

# Generated at 2022-06-21 07:04:36.864845
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock plugins.lookup.LookupBase.run()
    mock_plugins_lookup_LookupBase_run = mocker.patch.object(LookupBase, 'run', autospec=True)

    # Set the return value of plugins.lookup.LookupBase.run()
    mock_plugins_lookup_LookupBase_run.return_value = 'LookupBase.run'

    # Mock plugins.lookup.LookupBase.set_options()
    mock_plugins_lookup_LookupBase_set_options = mocker.patch.object(LookupBase, 'set_options', autospec=True)

    # Object to be tested
    lookup_module = LookupModule()

    # Test parameters

# Generated at 2022-06-21 07:06:08.164899
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    term1 = '^qz_.+'
    term2 = '^qa_.+$'
    term3 = '.+_zone$'
    term4 = '.+_location$'
    term5 = 'hosts'
    term6 = '.+'
    term7 = '^fail$'

    # Test for a list of valid terms
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'First_zone': 'foo',
        'Second_zone': 'bar',
        'Third_zone': 'baz',
        'Another_location': 'qux',
        'Something_else': 'quux'
    }
    lookup_obj

# Generated at 2022-06-21 07:06:10.756753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(None, None, None, None, None), LookupModule)

# Generated at 2022-06-21 07:06:12.755482
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 07:06:20.328312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests import mock

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.lookup1 = LookupModule()
            self.lookup2 = LookupModule()
            self.lookup3 = LookupModule()
            self.lookup4 = LookupModule()
            self.lookup5 = LookupModule()
            self.lookup6 = LookupModule()

        def tearDown(self):
            pass


# Generated at 2022-06-21 07:06:22.097205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:06:25.069208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
        assert False
    except SystemExit as e:
        assert e.code == 1
    except Exception as e:
        assert False


# Generated at 2022-06-21 07:06:35.701903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  from ansible.playbook.play_context import PlayContext
  vars = {'controller_ip': '10.0.0.2', 'api_servers':'localhost'}
  ctx = PlayContext()
  ctx.vars = vars
  result = lookup.run(['^.*_ip$'], variables=ctx.vars)
  assert(sorted(result) == sorted(['controller_ip']))

# Generated at 2022-06-21 07:06:40.952439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()
    assert test_instance is not None

# Generated at 2022-06-21 07:06:46.390507
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    try:
        my_obj = LookupModule()
    except Exception as e:
        assert False

# Generated at 2022-06-21 07:06:49.009333
# Unit test for constructor of class LookupModule
def test_LookupModule():
    list_of_variable_names = ['var1', 'var2']
    list_of_terms = ['var2']
    module_class = LookupModule()
    module_class.run(list_of_terms, list_of_variable_names)