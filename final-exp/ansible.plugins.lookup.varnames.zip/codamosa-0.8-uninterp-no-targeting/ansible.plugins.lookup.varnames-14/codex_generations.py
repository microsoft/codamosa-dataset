

# Generated at 2022-06-21 06:58:36.078529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    import logging

    # Create a MockModule to hold the module class
    class MockModule(object):
        def __init__(self, argument_spec=dict(), params={}):
            self.params = params
            self.params['dict'] = dict()
            self.argument_spec = argument_spec
            self.failjson = basic.fail_json
            self.log = logging.getLogger()
            if not hasattr(self.log, 'debug'):
                self.log.debug = lambda x: None
            if not hasattr(self.log, 'info'):
                self.log.info = lambda x: None
            if not hasattr(self.log, 'warning'):
                self.log.warning = lambda x: None

# Generated at 2022-06-21 06:58:37.475950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-21 06:58:39.284454
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.__class__.__name__ == 'LookupModule'

# Generated at 2022-06-21 06:58:49.115126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'VAR_OUTPUT': 'VAR_OUTPUT_VALUE', 'VAR1': 'VAR1_VALUE', 'VAR2': 'VAR2_VALUE', 'VAR3': 'VAR3_VALUE'}
    lookup = LookupModule()
    result = lookup.run(['VAR_OUTPUT', 'VAR1'], variables)
    assert result == ['VAR_OUTPUT', 'VAR1']

    result = lookup.run(['VAR_.+'], variables)
    assert result == ['VAR_OUTPUT']

    result = lookup.run(['VAR_.'], variables)
    assert result == []

# Generated at 2022-06-21 06:58:54.402568
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import os
    import sys
    import pytest
    from ansible.utils.path import unfrackpath
    from ansible.parsing.dataloader import DataLoader

    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    # mock some imports and dependencies for LookupModule
    # Mock is not used everywhere to keep the code readable
    loader = DataLoader()
    mock_vars = {
        'test_var': {'a': "hello"}
    }

    terms = ['test_var', '^test_var']

    mocked_module = mock.MagicMock()
    mocked_module.params = {
        '_terms': terms
    }

    lookup_m = Look

# Generated at 2022-06-21 06:59:01.622023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = lookup_loader.get('varnames')
    terms = ['^qz_.+']
    variables = {u'qz_1': u'hello', u'qz_2': u'world', u'qa_1': u"I won't show", u'qz_': u"I won't show either"}
    result = lookup.run(terms, variables)
    assert result is not None
    assert type(result) is list
    assert len(result) == 2
    assert result == [u'qz_1', u'qz_2']

# Generated at 2022-06-21 06:59:02.433404
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 06:59:09.879525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod_params = {}

    assert LookupModule.run({"_terms": ['.+_zone$', '.+_location$']}, mod_params) == []

    mod_params = {'zone_name': 'us-east-1',
                  'zone_location': 'us-east-1'}
    assert LookupModule.run({"_terms": ['.+_zone$', '.+_location$']}, mod_params) == ['zone_name', 'zone_location']


# Generated at 2022-06-21 06:59:20.442474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    terms = ['^qz_.+']
    variables = {
        'qz_1':'hello',
        'qz_2':'world',
        'qa_1':"I won't show",
        'qz_':"I won't show either",
    }
    lookup = LookupModule()

# Generated at 2022-06-21 06:59:21.421956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    return l

# Generated at 2022-06-21 06:59:29.535524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test default run method
    class TestClass(LookupModule):
        def run(self, *args, **kwargs):
            return args[1]
    obj = TestClass()
    varname = "ansible_local"
    assert(obj.run(varname) == varname)

# Generated at 2022-06-21 06:59:34.733395
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Instantiate with term as argument, verify that error is raised
    lm1 = LookupModule(create_lookup_plugin=False)
    try:
        lm1.run('*')
        assert False # Shouldn't get here
    except AnsibleError as e:
        assert 'No variables available to search' in str(e)



# Generated at 2022-06-21 06:59:42.551025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    lookup = LookupModule()

    terms = ["^qz_.+"]
    variables = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }

    assert lookup.run(terms, variables) == ["qz_1", "qz_2"]

# Generated at 2022-06-21 06:59:46.378944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {'abc_def':'abc_def_value'}
    terms = [r'^abc_.+$']
    lookup_module._display.vvvv = True
    result = lookup_module.run(terms, variables=variables)
    print(result)
    assert result == ['abc_def']

# Generated at 2022-06-21 06:59:49.705626
# Unit test for constructor of class LookupModule
def test_LookupModule():

    members = [attr for attr in dir(LookupModule) if not callable(getattr(LookupModule,attr)) and not attr.startswith('_')]

    assert 'run' in members

# Generated at 2022-06-21 07:00:00.456446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestClass():
        def __init__(self, test_variables):
            self.test_variables = test_variables
        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct
        def run(self, terms, variables=None, **kwargs):
            return(super().run(terms, variables=variables, **kwargs))
    test_variables = {'test1': 'hello', 'test2': 'world', 'test3': 'I won\'t show',
                      '1test': 'I won\'t show either', 'hosts': 'the hosts list'}
    test_class = TestClass(test_variables)
    test_terms = ['^test.+', 'hosts']
    results = test_class

# Generated at 2022-06-21 07:00:09.036001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid arguments
    lookup = LookupModule()
    variables = {'test1': 'test1', 'test2': 'test2'}
    term = ['test.+', 'test[0-9]+']
    # Now run the run() method of LookupMoudle class
    ret = lookup.run(term, variables)
    assert len(ret) == 2, "The test_LookupModule_run() method has failed"

    # Test with invalid arguments
    variables = {'test1': 'test1', 'test2': 'test2'}
    term = [1.0, 2]

# Generated at 2022-06-21 07:00:11.930446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """

    lookup_plugin = LookupModule()
    lookup_plugin.run('^qz_.+')

# Generated at 2022-06-21 07:00:23.545167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = dict()
    variables['ha_master'] = 'true'
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    ret = lookup.run(['^qz_.+'], variables)
    assert ret == ['qz_2', 'qz_1']
    try:
        lookup.run([5], variables)
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "5" is not a string, it is a <type \'int\'>'
    ret = lookup.run(['^qz_.*'], variables)
    assert ret == ['qz_2', 'qz_1']
    ret = lookup.run(['.+'], variables)

# Generated at 2022-06-21 07:00:24.767096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lobj = LookupModule()
    assert lobj is not None


# Generated at 2022-06-21 07:00:39.661583
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # These are the original values
    terms = ['^qz_.+','^qz_','hosts','.+_zone$','.+_location$']
    variables = {
        'qz_1':'hello',
        'qz_2':'world',
        'qa_1':"I won't show",
        'qz_':"I won't show either",
        'host_port':'not for me',
        'host_name':'I am for you',
        'hosts_name':'I am for you'
    }

    # This will be the results

# Generated at 2022-06-21 07:00:52.483237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    vars = {
       "test": "A",
       "test1": "AB",
       "test2": "ABC"
    }

    print('****** Test 1 ******')
    print('No var names specified')
    try:
        l.run([], vars)
    except Exception as err:
        print(err)
    
    print('****** Test 2 ******')
    print('Invalid search parameter type')
    try:
        l.run([1,2], vars)
    except Exception as err:
        print(err)
    
    print('****** Test 3 ******')
    print('Term is not a string')
    try:
        l.run(["a", 1, 2], vars)
    except Exception as err:
        print(err)

   

# Generated at 2022-06-21 07:01:01.993796
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import module LookupModule
    from ansible.plugins.lookup.varnames import LookupModule

    # Create temp object "lookup" of LookupModule
    lookup = LookupModule()

    # Create temp object of class dict for test
    class Dict(dict):
        def __init__(self, *args, **kwargs):
            return dict.__init__(self, *args, **kwargs)

        def __getitem__(self, item):
            return dict.__getitem__(self, item)

    # Create temp object "variable" of Dict.
    variable = Dict()
    variable["test_key_01"] = "test_value_01"
    variable["test_key_02"] = "test_value_02"

# Generated at 2022-06-21 07:01:14.181273
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import StringIO
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    l = LookupModule()
    l.set_options(var_options=dict(
        log_file=open('/tmp/ansible_testfile.log', 'rb')
    ))
    assert l.get_option('log_file') is not None
    assert isinstance(l.get_option('log_file').name, str)
    l.set_options(var_options=dict(
        log_file=AnsibleUnsafeText(b'/tmp/ansible_testfile.log')
    ))
    assert l.get_option('log_file') is None

# Generated at 2022-06-21 07:01:22.020655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModule_Run(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return [terms, variables, kwargs]
    lmr = LookupModule_Run()
    assert lmr.run([1,2], a=1) == [[1,2], None, {'a': 1}]
    assert lmr.run([1,2], variables={1:1, 2:2}, a=1) == [[1,2], {1:1, 2:2}, {'a': 1}]

# Generated at 2022-06-21 07:01:23.449441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-21 07:01:30.219810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys
    import os

    # set up python path so ansible from source can be imported
    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    sys.path.append(ansible_path)
    sys.path.append(os.path.join(ansible_path, "lib"))

    from ansible.module_utils.basic import AnsibleModule

    vars = {
        "hostvar1": "variable1",
        "hostvar2": "variable2",
        "hostvar3": "variable3",
        "hostvar4": "variable4",
        "hostvar5": "variable5"
    }


# Generated at 2022-06-21 07:01:31.911036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    dummy test.
    """
    assert True

# Generated at 2022-06-21 07:01:43.355300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    # Test if variables is None
    try:
        lm.run(['qz_1'])
    except AnsibleError:
        pass
    else:
        raise AssertionError("Should have gotten an error when variables is None")

    # Test if the 'term' is not a string
    try:
        lm.run([1, 2, 3], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    except AnsibleError:
        pass
    else:
        raise AssertionError("Should have gotten an error when 'term' is not a string")

    # Test if the 'term' is a valid regex

# Generated at 2022-06-21 07:01:52.463376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test object of class LookupModule
    lookup_module = LookupModule()

    # Set up a list of regex terms
    regex_terms = ['^qz_.+', '.+_zone$', '.+_location$']

    # Set up a dictionary of variables
    # Note that the qa_1 and qz_ variables don't match any of the regexes, so they are not expected
    # to show in the output of lookup_module.run()

# Generated at 2022-06-21 07:02:00.405460
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.varnames
    ansible.plugins.lookup.varnames.LookupModule(None)



# Generated at 2022-06-21 07:02:02.801500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run([]) == []

# Generated at 2022-06-21 07:02:11.811630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    fake_variable = {"var1": "value1", "var2": "value2", "var3": "value3"}
    print(fake_variable)
    print(type(fake_variable))
    # Test _terms
    terms = ['var1', 'var4']
    try:
        lookup_module = LookupModule()
        ret = lookup_module.run(terms, fake_variable)
        print(ret)
    except:
        pass
    print(type(ret))

    # Test _variables
    # ret = lookup_module.run(terms)
    # print(ret)

# Test for _terms and _variables

# Generated at 2022-06-21 07:02:16.053925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_options() == {}
    assert len(list(lookup.run(['.+']))) > 0

# Generated at 2022-06-21 07:02:25.411350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    options = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    result = lookup_module.run(terms=['^qz_.+'], variables=options)
    assert result == ['qz_1', 'qz_2']

    result = lookup_module.run(terms=['.+'], variables=options)
    assert result == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-21 07:02:26.365644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 07:02:29.043228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert hasattr(instance, 'run')

# Generated at 2022-06-21 07:02:41.702307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a test class
    my_test = LookupModule()
    # Set the variables to search in
    my_test.set_options(var_options={'hosts': 'localhost', 'hosts_file': 'hosts.txt', 'hosts_time': '10'}, direct={})
    # Get the variables that match the term
    results = my_test.run(['hosts_'],{})
    # Get the variables that match the term
    assert results == ['hosts_file', 'hosts_time']
    # Get the variables that match the term
    results = my_test.run(['^hosts_'],{})
    # Get the variables that match the term
    assert results == ['hosts_file', 'hosts_time']

    # Get the variables that match the term
    results = my_

# Generated at 2022-06-21 07:02:45.031151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_args = {'_loader': loader, '_templar': templar, 'vars': variables}
    test_obj = LookupModule(**test_args)
    assert test_obj._loader == loader
    assert test_obj._templar == templar
    assert test_obj._options == test_args


# Generated at 2022-06-21 07:02:54.162442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test start")
    # Test case 1
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    value_expected = ['qz_1', 'qz_2']
    value_result = LookupModule().run(terms, variables)
    if value_result == value_expected:
        print("Test case 1 PASSED!")
    else:
        print("Test case 1 FAILED!")

    # Test case 2
    terms = ['.+']

# Generated at 2022-06-21 07:03:08.118062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    """
    # FIXME: there is currently no way to pass in a fake variables object
    # without this object existing if this object doesn't exist a KeyError is raised
    # but it is unclear where the the appropriate place to create this is
    # See the comments in the 'def run' method
    my_vars = {'hosts': [{'host_name': 'host_name'}]}
    lm.run('hosts', variables=my_vars)
    """

# Generated at 2022-06-21 07:03:13.196584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for term in ['^q.+', 'hosts', '.+_zone$', '.+_location$']:
        for varname in ['qz_1', 'qz_2', 'qa_1', 'qz_']:
            pass

# Generated at 2022-06-21 07:03:13.963540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 07:03:21.899037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up the look up module
    l = LookupModule()

    # Test with missing variables
    try:
        l.run(['a'])
    except AnsibleError as e:
        assert(str(e) == 'No variables available to search')

    # Test with non string identifier
    try:
        l.run([1],[])
    except AnsibleError as e:
        assert(str(e) == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>')

    # Test with an unparsable regexp identifier
    try:
        l.run(['(['],[])
    except AnsibleError as e:
        assert(str(e) == 'Unable to use "([" as a search parameter: nothing to repeat')

    # Test with expected results

# Generated at 2022-06-21 07:03:29.811410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    inventory_variables = {'qz_1': 'value1', 'qz_2': 'value2', 'qa_1': 'value3', 'qz_': 'value4'}
    terms = ['^qz_.+$']
    expected_result = ['qz_1', 'qz_2']
    result = lookup_module.run(terms, inventory_variables)
    assert isinstance(result, list)
    assert result == expected_result

# Generated at 2022-06-21 07:03:41.663391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''
    #Create a LookupBase with real methods
    lookup_plugin = LookupModule()
    lookup_plugin.set_options = LookupBase.set_options
    lookup_plugin.get_basedir = LookupBase.get_basedir
    lookup_plugin.runner = LookupBase.runner

    #Test for exception in case of no variable available
    with pytest.raises(AnsibleError):
        lookup_plugin.run([],None)

    #Test for exception in case of invalid search parameter
    variable = {'name':'ansible'}
    with pytest.raises(AnsibleError):
        lookup_plugin.run([100],variable)

    #Test for exception in case of wrong regex format

# Generated at 2022-06-21 07:03:53.625564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^abc_.+', '_xyz$', 'key_value']

    test_variables = {
        'key_value': 'test',
        'zzz_xyz': 'test',
        'abc_def': 'test',
        'abc_def_ghi': 'test',
        'xyz_key_value': 'test',
    }

    expected_result = [
        'abc_def',
        'abc_def_ghi',
        'key_value',
        'zzz_xyz',
    ]

    module = LookupModule()
    result = module.run(terms=terms, variables=test_variables)
    assert set(result) == set(expected_result)

# Generated at 2022-06-21 07:04:04.972232
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class MockVars(dict):
        def __init__(self, dic):
            super(MockVars, self).__init__()
            self.update(dic)

    # Get expected result
    terms = ["items_.*", "^q.+", "^vm_"]
    mock_vars = MockVars({"items_1": 1, "items_2": 2, "items_3": 3, "qz_1": "hello", "qz_2": "world", "vm_0": 0})
    expected = {"qz_1", "qz_2", "vm_0", "items_1", "items_2", "items_3"}

    # Calculate actual result
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:04:10.964974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Defining variables
    terms = ['hello', 'world']
    variables = {'hello': 'world', 'world': 'hello'}
    kwargs={}

    # Defining LookupModule object
    lmu = LookupModule()

    # Testing
    lmu.run(terms, variables, **kwargs)

# Generated at 2022-06-21 07:04:23.562364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert [] == LookupModule().run(terms=[], variables=dict())
    assert ['a'] == LookupModule().run(terms=['a'], variables=dict(a='a'))
    assert ['a', 'aa'] == LookupModule().run(terms=['a'], variables=dict(a='a', aa='aa'))

    assert ['a'] == LookupModule().run(terms=['\\.a$'], variables=dict(a='a'))
    assert ['a.a'] == LookupModule().run(terms=['\\.a$'], variables=dict(a='a', aa='aa', a_a='a.a'))

# Generated at 2022-06-21 07:04:55.481712
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use all the words from the first sentence of the Bible.
    words = 'In the beginning God created the heaven and the earth'.split()

    # Build a dictionary of variables, with variable names that match the regex
    # pattern "go" and "od" (singular and plural of god).
    variables = dict()
    for word in words:
        word_singular = word   # Singular of word
        word_plural = word + 's'
        variables[word_singular] = '%s_VALUE' % word_singular
        variables[word_plural] = '%s_VALUE' % word_plural

    # Instantiate the lookup module.
    module = LookupModule()

    # Lookup variable names matching the regex pattern "go".
    assert 'go_VALUE' in module.run(['go'], variables)



# Generated at 2022-06-21 07:04:57.154560
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert(callable(LookupModule))

# Generated at 2022-06-21 07:05:03.608029
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import platform
    from ansible.module_utils.six import PY3
    if PY3:
        unicode = str
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert hasattr(lookup, 'run')
    assert hasattr(lookup, 'set_options')
    assert hasattr(lookup, 'get_all_plugin_loaders')


# Generated at 2022-06-21 07:05:05.464323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 07:05:16.113659
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ##############
    ## Unit tests for void run()
    ## There are 3 methods to test with this run() method
    ##  1. one term provided
    ##  2. more than one term provided
    ##  3. one none type term provided
    ##############

    # Testing non-existant term
    variables = LookupModule().run(['foo_bar'], {'ansible_date_time': {'date': '2018-06-06', 'time': '16:00:00', 'timezone': 'UTC'}})
    assert variables == []

    # Testing one existing term

# Generated at 2022-06-21 07:05:16.910427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:05:17.793046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.set_options()

# Generated at 2022-06-21 07:05:19.139698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 07:05:24.727261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test being called with no parameters
    lookup_module = LookupModule()
    lookup_module.set_options()

    # Test being called with parameters
    lookup_module = LookupModule()
    options = dict(
        var_options=dict(
            foo="bar"
        ),
        direct=dict(
            foo1="bar1"
        )
    )
    lookup_module.set_options(**options)

# Generated at 2022-06-21 07:05:34.968662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule

    lookup = LookupModule()
    result = lookup.run(terms=["^qz_.+"], variables={
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
        "qw_": "I won't show either too"
    }, direct=None)

    assert result == ['qz_1', 'qz_2', 'qz_']


# Generated at 2022-06-21 07:06:22.677163
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    lookup = LookupModule()
    print(dir(lookup))
    assert lookup is not None

test_LookupModule()

# Generated at 2022-06-21 07:06:24.916785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    test_lookup = LookupModule()

# Generated at 2022-06-21 07:06:37.585637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = dict()
    hostvars['my_variable'] = 'my_value'
    hostvars['my_variable2'] = 'my_value2'
    hostvars['my_variable3'] = 'my_value3'

    # empty search
    result = LookupModule().run(terms=list(), variables=hostvars)
    assert result == []

    # one non empty search
    result = LookupModule().run(terms=['my_variable'], variables=hostvars)
    assert result == ['my_variable']

    # 2 non empty search
    result = LookupModule().run(terms=['my_variable','my_variable.'], variables=hostvars)
    assert result == ['my_variable', 'my_variable2', 'my_variable3']

# Generated at 2022-06-21 07:06:42.502025
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()
    # unit test for constructor of class LookupModule
    assert lookup_module_instance.DEFAULT_TERMS is None
    assert lookup_module_instance.DEFAULT_VARIABLE_NAME != ""
    assert lookup_module_instance.DEFAULT_VARIABLE_NAME != None


# Generated at 2022-06-21 07:06:44.580872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 07:06:49.962158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    class MockVars(dict):
        def __init__(self):
            self = dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")

    # When
    result = LookupModule().run(['^qz_.+'], variables=MockVars())
    # Then
    assert result == ["qz_1", "qz_2"], result

# Generated at 2022-06-21 07:06:52.750256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert type(L) == LookupModule


# Generated at 2022-06-21 07:07:02.801805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Initialize variables
    terms = ['^qz_.+', '^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'}
    expected = ['qz_1', 'qz_2']

    # Run the run method of lookup module
    result = lookup.run(terms, variables=variables)

    # Assert equality of result and expected
    assert result == expected, "Got '%s' instead of '%s'" % (result, expected)

# Generated at 2022-06-21 07:07:08.156817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_variables = {
        'a': 1,
        'b': 2,
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_':  "I won't show either",
        'hosts': 'hostsfile'
    }
    # test case where the variable name is not a string
    try:
        terms=None
        l = LookupModule()
        l.run(terms, test_variables)
        assert False
    except AnsibleError as e:
        pass

    # test match
    terms=['^qz_.+']
    expected = ['qz_1', 'qz_2']
    l = LookupModule()

# Generated at 2022-06-21 07:07:20.160936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    # Test #1 - Variable not provided
    lookup_module = LookupModule()
    assert 'No variables available to search' in lookup_module.run(terms=['test'])

    # Test #2 - term is not a string
    lookup_module = LookupModule()
    assert "is not a string, it is a <class 'int'>" in lookup_module.run(terms=['test', 2])

    # Test #3 - term is not a valid regular expression
    lookup_module = LookupModule()
    assert 'Invalid setting identifier' in lookup_module.run(terms=['test', '*'])

    # Test #4 - Found match
    variables = {'test': 'variable'}
    lookup_module = LookupModule()
    assert ['test'] == lookup_module