

# Generated at 2022-06-21 06:58:25.321309
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule


# Generated at 2022-06-21 06:58:36.972348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests if run is working properly
    test_LookupModule = LookupModule()

    terms = ['^qz_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}
    assert test_LookupModule.run(terms, variables) == ['qz_1', 'qz_2']

    terms = ['^qz_.+', 'qa_.+']
    variables = {'qz_1':'hello', 'qz_2':'world', 'qa_1':"I won't show", 'qz_':"I won't show either"}

# Generated at 2022-06-21 06:58:40.185086
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert len(lookup_module.run(["test"], variables={'test': 'test_value'})) == 1

# Generated at 2022-06-21 06:58:50.625385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run(["^qz_.+"], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}) == ['qz_1', 'qz_2']
    assert x.run([".+"], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-21 06:58:58.988356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Empty terms, variables should throw error
    try:
        lookup.run(terms=[], variables=None)
    except AnsibleError:
        pass
    else:
        assert False, "Empty variable list, should return error"

    # Invalid setting identifier, not string should throw error
    try:
        lookup.run(terms=['test_re'], variables={0: 'test'})
    except AnsibleError:
        pass
    else:
        assert False, "Invalid setting identifier, not string, should return error"

    # Invalid setting identifier, regex should throw error
    try:
        lookup.run(terms=['[abc]'], variables={'abc': 'test'})
    except AnsibleError:
        pass
    else:
        assert False, "Invalid setting identifier, regex should return error"

   

# Generated at 2022-06-21 06:59:00.982385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    a.run('test')

# Generated at 2022-06-21 06:59:06.353890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = '^qz_.+'
    variables = {'qz_1': None, 'qz_2': None, 'qa_1': None, 'qz_': None}
    l = LookupModule()
    l.run(terms=terms, variables=variables)

# Generated at 2022-06-21 06:59:19.275831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test a valid case
    lookmodule = LookupModule()
    variable_names = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won t show', 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    variables = variable_names
    ret = lookmodule.run(terms, variables)
    assert ret == ['qz_1', 'qz_2']

    # Test different terms
    lookmodule = LookupModule()
    variable_names = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won t show', 'qz_': "I won't show either"}
    terms = ['^qz_.+', 'qa_.+']
    variables = variable_names
   

# Generated at 2022-06-21 06:59:29.771054
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    """
    Args:
        name: qz_1
        vars:
            qz_1: hello
            qz_2: world
            qa_1: "I won't show"
            qz_: "I won't show either"

    Expected result:
        qz_1: hello
        qz_2: world
    """
    lookup_obj = LookupModule()
    term1 = "^qz_.+"
    variables1 = {"qz_1": "hello", "qz_2": "world", "qa_1": "\"I won't show\"", "qz_": "\"I won't show either\""}
    results1 = lookup_obj.run(terms=[term1], variables=variables1)

# Generated at 2022-06-21 06:59:36.272992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = ['^qz_.+']
    vars = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    result = lookup.run(terms, vars)
    assert len(result) == 2
    assert 'qz_1' in result
    assert 'qz_2' in result

# Generated at 2022-06-21 06:59:40.408694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:59:41.721520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a != None

# Generated at 2022-06-21 06:59:44.087886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test constructor of class LookupModule
    result = LookupModule()
    # assert
    assert result

# Generated at 2022-06-21 06:59:46.224418
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule), 'Object should be a LookupModule instance'

# Generated at 2022-06-21 06:59:47.333737
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 06:59:49.102284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule()

# Generated at 2022-06-21 06:59:59.790863
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['^qz_.+', 'hosts', '.+', '.+_zone$', '.+_location$']

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': 'list of hosts'
        }

    expected = ['qz_1', 'qz_2', 'qz_', 'hosts', 'qz_1', 'qz_2', 'qz_', 'hosts']

    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=variables)

    assert result == expected


# Generated at 2022-06-21 07:00:08.435198
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Needs a better test. This will simply test for no errors.
    look = LookupModule()
    ret = look.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:00:16.363149
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Test check for variables parameter
    try:
        lookup_module.run(terms='test_term')
    except AnsibleError as e:
        assert e.message == 'No variables available to search'

    # Test check for pattern
    try:
        lookup_module.run(terms=[1], variables={})
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "1" is not a string, it is a <class \'int\'>'

    # Test check for regexp
    try:
        lookup_module.run(terms=['[a-z'], variables={})
    except AnsibleError as e:
        assert e.message == 'Unable to use "[a-z" as a search parameter: unterminated character set at position 3'



# Generated at 2022-06-21 07:00:17.294665
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test Nothing to check since nothing implemented
    assert True

# Generated at 2022-06-21 07:00:27.032778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options={'test': 'value', 'test_test': 'value'}, direct={})
    assert lookup_obj.run(['test']) == ['test']
    assert lookup_obj.run(['test', 'test']) == ['test', 'test']
    assert lookup_obj.run(['test', 'test_test']) == ['test', 'test_test']
    assert lookup_obj.run(['^t.+']) == ['test', 'test_test']

# Generated at 2022-06-21 07:00:39.596048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import json

    if not os.path.isfile('tests/vars.json'):
        print('ERROR: no test vars file found')
        sys.exit(1)

    test_vars = json.load(open('tests/vars.json'))

    from ansible.plugins.lookup.varnames import LookupModule
    l = LookupModule()

    # List variables that start with qz_
    terms = '^qz_.+'
    variables = test_vars
    ret = l.run(terms, variables)
    assert ret == [u'qz_1', u'qz_2']

    # Show all variables
    terms = '.+'
    variables = test_vars
    ret = l.run(terms, variables)

# Generated at 2022-06-21 07:00:48.998682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    try:
        lookupModule.run(['qz_1', 'qz_2'], {'qz_1': 'hello', 'qz_2': 'world'})
    except AnsibleError:
        # TODO: We should have some mock framework for this kind of test.
        # AnsibleError is raised because no variables are set.
        pass

    assert lookupModule._display.display_deprecation_warning.called

# Generated at 2022-06-21 07:00:59.535872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["(.+_env$)"], {"foo_env": "bar"}) == ["foo_env"]
    assert lookup_module.run(["(.+_env$)"], {"foo_env": "bar", "baz_env": "foo"}) == ["foo_env", "baz_env"]
    assert lookup_module.run(["(.+_env$)"], {"foo": "bar", "baz": "foo"}) == []
    assert lookup_module.run(["(.+_env$)"], {"foo_env": "bar", "baz_env": "foo", "foo_bar": "baz"}) == ["foo_env", "baz_env"]

# Generated at 2022-06-21 07:01:08.566525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kv = {'Y': 1, 'Z': 2}
    lookup = LookupModule()

    assert lookup.run(['Y'], **kv) == ['Y']
    assert lookup.run(['Z'], **kv) == ['Z']
    assert lookup.run(['X'], **kv) == []
    assert lookup.run(['.*'], **kv) == ['Y', 'Z']
    assert lookup.run('Y', **kv) == ['Y']
    assert lookup.run('Z', **kv) == ['Z']
    assert lookup.run('X', **kv) == []
    assert lookup.run('.*', **kv) == ['Y', 'Z']

# Generated at 2022-06-21 07:01:18.037430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    # LookupModule class object
    lm = LookupModule()

    # Simple arguments for the LookupModule class
    terms = 'hello'
    variables = {'hello': 'world'}
    lm.run(terms, variables)

    # Invalid terms
    terms = ['hello', 3] # 3 is not a string
    try:
        lm.run(terms, variables)
    except AnsibleError as e:
        pass

    # Invalid variable name
    variables = {2: 3} # 2 is not a string
    try:
        lm.run(terms, variables)
    except AnsibleError as e:
        pass

    # No variables
    variables = None
    try:
        lm.run(terms, variables)
    except AnsibleError as e:
        pass

# Generated at 2022-06-21 07:01:18.887990
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 07:01:29.974185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-argument
    lookup_module = LookupModule(loader=None, variables={'a': 'A', 'b': 'B', 'cd': 'CD', 'c': 'C'})
    assert sorted(['a', 'b', 'c', 'cd']) == sorted(lookup_module.run(['.+'], variables={'a': 'A', 'b': 'B', 'cd': 'CD', 'c': 'C'}))
    assert sorted(['a', 'c', 'cd']) == sorted(lookup_module.run(['.+', '^c.+'], variables={'a': 'A', 'b': 'B', 'cd': 'CD', 'c': 'C'}))

# Generated at 2022-06-21 07:01:41.166861
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    variables = dict(pref_timeout=4, pref_hello="hello world", pref_goodbye="goodbye cruel world")
    terms = ["^pref_.+", "^non_existing_var"]

    ret= lookup.run(terms=terms, variables=variables)
    assert len(ret) == 2
    assert ret == ['pref_timeout', 'pref_hello'] or ret == ['pref_timeout', 'pref_goodbye']

    # When only one term is given, it returns an empty list
    ret= lookup.run(terms=["^non_existing_var"], variables=variables)
    assert len(ret) == 0

# Generated at 2022-06-21 07:01:51.594738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule

    args = dict(
        terms=['.*host.*', '^host_.*'],
        variables=dict(
            apple=10,
            host=dict(name='HOST'),
            host_to_ip=dict(name='H2I'),
            host_ip=dict(name='HIP'),
            hosts=dict(name='HOSTS'),
            banan=dict(name='BANAN')
        )
    )

    module = AnsibleModule(argument_spec=dict())
    result = LookupModule().run(**args)
    assert result == ['host', 'host_to_ip', 'host_ip', 'hosts']

# Generated at 2022-06-21 07:02:07.216982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'abc1':'def1', 'abc2':'def2', 'abc3':'def3'}, direct={})
    result = lookup_module.run(['^abc.+'], {} )
    assert result == ['abc1', 'abc2', 'abc3']

# Generated at 2022-06-21 07:02:15.358003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    var_mock = {
        "qa_1": "hello",
        "qz_1": "world",
        "qz_2": "world",
        "qz_3": "world"
    }
    terms_mock = [
        "^qz_.+",
        ".+_zone$",
        ".+_location$"
    ]
    obj_mock = {
        "var_options": var_mock,
        "direct": {}
    }
    test_obj = LookupModule()
    assert test_obj.run(terms_mock, **obj_mock) == ["qz_1", "qz_2", "qz_3"]

# Generated at 2022-06-21 07:02:15.859367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:02:27.740069
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test1(terms, variables, result):
        l = LookupModule()
        r = l.run(terms, variables)
        assert r == result

    # test1: no terms, no variables
    test1([], {}, [])

    # test2: simple variable
    variables = {'a' : 1}
    test1(['a'], variables, ['a'])

    # test3: variable does not exists
    test1(['b'], variables, [])

    # test4: variable exists and does not
    test1(['a', 'b'], variables, ['a'])

    # test5: variable expression
    variables = {'a' : 1, 'b': 2, 'aa' : 3}
    test1(['a.*'], variables, ['a', 'aa'])

# Generated at 2022-06-21 07:02:31.553224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = {
        'var1': 'foo',
        'var2': 'bar',
    }
    lookup_module.run(['var1'], variables=variables)
    lookup_module.run(['var2'], variables=variables)
    lookup_module.run(['var3'], variables=variables)

# Generated at 2022-06-21 07:02:41.219492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.run() will fail if parameters are in wrong order.
    # This is a test for parameter order.

    from ansible.plugins.lookup import LookupBase
    import ansible.plugins.lookup.varnames

    terms = ['hosts']
    variables = {'hosts': 'localhost', 'hosts_ip': '127.0.0.1'}
    result = ansible.plugins.lookup.varnames.LookupModule().run(terms, variables)
    assert result == terms, "test result should be: %s, actual result: %s" % (terms, result)

# Generated at 2022-06-21 07:02:43.603367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert type(module.run) == type(test_LookupModule)

# Generated at 2022-06-21 07:02:45.122944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 07:02:45.823362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run([], {}) == []

# Generated at 2022-06-21 07:02:54.413780
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    try:
        lookup.run(None)
    except AnsibleError as e:
        assert(to_native(e) == 'No variables available to search')

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': '127.0.0.1',
        'ceph_cluster_zone': 'ru-1',
        'ceph_cluster_location': 'poland',
        'cluster_location': 'russia',
    }

    terms = ['^qz_.+']
    ret = lookup.run(terms, variables=variables)

# Generated at 2022-06-21 07:03:13.994266
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert hasattr(lookup_module, 'run')


# Generated at 2022-06-21 07:03:19.345474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected = ['qz_1', 'qz_2']
    lookup = LookupModule()

    # Act
    actual = lookup.run(terms, variables)

    # Assert
    assert actual == expected

# Generated at 2022-06-21 07:03:31.260290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test retrieval of variable names with regex search

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3

    # Dummy class with safe_load method that can be used as VaultSecret
    class DummyVaultSecret(object):
        def __init__(self, password):
            self.password = password

        def load(self, data):
            if PY3:
                return data
            else:
                return data.encode('utf-8')

    dummy_vault_secret = DummyVaultSecret('')
    encrypted_variable = AnsibleVaultEncryptedUnicode('This is encrypted', vault_secret=dummy_vault_secret)


# Generated at 2022-06-21 07:03:33.983968
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 07:03:36.133161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    name = lm
    assert name is not None

# Generated at 2022-06-21 07:03:37.604846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-21 07:03:40.652644
# Unit test for constructor of class LookupModule
def test_LookupModule():

    d = {'qz_1': 'hello', 'qz_2': 'world'}

    l = LookupModule()
    l.set_options(var_options=d, direct='')

    assert l.get_options()['var_options'] == d

# Generated at 2022-06-21 07:03:51.964293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Basic operations
    lookup_module = LookupModule()
    assert lookup_module.run(["^qz_.+"], {'qz_1':'test1', 'qz_2':'test2', 'qa_1':'test3'}) == ['qz_1', 'qz_2']
    assert lookup_module.run([".+"], {'qz_1':'test1', 'qz_2':'test2', 'qa_1':'test3'}) == ['qz_1', 'qz_2', 'qa_1']
    assert lookup_module.run([".+_zone$", ".+_location$"], {'zone1':'test1', 'zone2':'test2', 'location1':'test3'}) == ['zone1', 'zone2', 'location1']

    # Invalid

# Generated at 2022-06-21 07:03:56.324024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # match variable1 and variable2
    assert len(LookupModule().run(['variable[0-9]'])) == 2
    # match variable1 only
    assert len(LookupModule().run(['^variable1$'])) == 1

# Generated at 2022-06-21 07:04:05.235229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fields = dict(
        _ansible_no_log=False,
        ansible_facts=dict(
            os_facts=dict(
                network_gw='192.168.122.1',
                network_ip_addresses=['192.168.122.100/24'],
                network_interface='eth0',
            ),
        ),
    )
    testFields = dict(
        (k, fields[k]) for k in ('ansible_facts',)
    )
    setattr(fields, 'ansible_facts', testFields)
    mod = LookupModule()
    mod.run(["os_facts"], variables=fields)

# Generated at 2022-06-21 07:04:40.416218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:04:47.981041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.varnames as test_class

    class AnsibleModule():
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False):
            self.params = {}

    class LookupModuleTest(test_class.LookupModule):
        def __init__(self, loader=None, templar=None, **kwargs):
            self.loader = loader
            self.templar = templar

    lookup_obj = LookupModuleTest(loader=None, templar=None)
    test_variables = {}

    test_variables['greeting'] = "Hello World"
    test_variables['qz_1'] = "qz_1-hello"

# Generated at 2022-06-21 07:04:56.402639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule

    lookup = LookupModule()
    # fix return values
    lookup.get_basedir = lambda x: ""

    # set variable for lookup
    variables = dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")

    # test: self.run(terms, variables=None, **kwargs)
    assert lookup.run(["^qz_.+"], variables=variables) == ['qz_1', 'qz_2']

    # test: empty term list
    assert lookup.run([], variables=variables) == []

    # test: empty variable dict
    assert lookup.run(["^qz_.+"], variables={}) == []

    # test: no variable

# Generated at 2022-06-21 07:05:03.089293
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Setup test
    def mock_set_options(self, var_options=None, direct=None):
        pass
    LookupModule.set_options = mock_set_options

    # Exercise
    lookup_module = LookupModule()

    # Assert
    assert lookup_module.run is not None
    assert lookup_module.run_terms([""]) == []

# Generated at 2022-06-21 07:05:13.086870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['^qz_.+', '^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected = ['qz_1', 'qz_2']
    ret = lookup_module.run(terms, variables)
    assert ret == expected, 'Expected %s, Got %s' % (expected, ret)

# Generated at 2022-06-21 07:05:25.625295
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create LookupModule object
    lookup = LookupModule()
    lookup._options = {
        'var_options': {}
    }

    # Example search for all variables
    assert lookup.run(terms=['.+']) == []
    assert lookup.run(terms=['.+'], variables={'test_one': 'whatever'}) == ['test_one']
    lookup._options['var_options'] = {}
    assert lookup.run(terms=['.+'], variables={'test_two': 'whatever'}) == ['test_two']
    assert lookup.run(terms=['.+'], variables={'test_one': 'whatever', 'test_two': 'whatever'}) == ['test_one', 'test_two']
    lookup._options['var_options'] = {'test_three': 'whatever'}

# Generated at 2022-06-21 07:05:29.392436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()
    assert test_object is not None



# Generated at 2022-06-21 07:05:37.450667
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create class instance
    lookmodule = LookupModule()

    assert lookmodule.run(
        [ '^qz_.+' ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': '"I won\'t show"',
            'qz_': '"I won\'t show either"'
        }
    ) == ['qz_1', 'qz_2']

    assert lookmodule.run(
        [ 'hi' ],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': '"I won\'t show"',
            'qz_': '"I won\'t show either"'
        }
    ) == []


# Generated at 2022-06-21 07:05:44.108400
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_options = {}

    # Initialize variables
    variables = {'foo': 'bar'}

    # Initialize options
    options = {}
    options.update(variables)

    lookup_options.update(options)

    # Create object
    my_lookup = LookupModule()
    my_lookup.set_options(lookup_options)

    # Run the lookup
    terms = ['.+']
    result = my_lookup.run(terms, variables=variables)

    # Assert that the results match
    assert result == ['foo']

# Generated at 2022-06-21 07:05:45.916908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:07:03.123562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ["test"]
    variables = {"test": "hi"}
    value = lookup_module.run(terms, variables)
    assert value == ["test"]

# Generated at 2022-06-21 07:07:11.262262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupModule().run(['^qz_.+'], {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"}) == ['qz_1', 'qz_2'])
    assert (LookupModule().run(['.+'], {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"}) ==
        ['qz_1', 'qz_2', 'qa_1', 'qz_'])

# Generated at 2022-06-21 07:07:12.859835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    string_types(LookupModule)

# Generated at 2022-06-21 07:07:14.957428
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 07:07:21.947255
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # First, test cannot run without a variable dictionary
    # This will be executed in the context of the context of __main__, but we need to get at the object
    lookout = LookupModule()

    try:
        lookout.run(['x'])
        assert False, 'AnsibleError not raised when variable dictionary not passed'
    except AnsibleError as e:
        assert str(e) == 'No variables available to search', 'Wrong error message, expected "No variables available to search", got "%s"' % str(e)

    # Now test for a variable not having the name passed in
    variable_dict = {'abc': 123}

    ret = lookout.run(['xyz'], variable_dict)
    assert ret == [], 'Found variable name "xyz", should not have, since variable dictionary does not contain it'

    # Now test

# Generated at 2022-06-21 07:07:32.973690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The method run of class LookupModule has a number of required parameters
    # We set them - terms, variables
    # We set variables to a mock ansible variable
    # We expect that 'ret' will contain our mock variable
    my_variable="MyTestVariable"
    class mock_variables:
        def __init__(self):
            self.dict = {my_variable: "MyTestValue"}
        def keys(self):
            return self.dict.keys()
    my_variables = mock_variables()
    lookup = LookupModule()
    ret = lookup.run(terms=["^.+Test.+$"], variables=my_variables)
    assert ret == [my_variable]

# Generated at 2022-06-21 07:07:38.730864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^any_prefix_.+']
    variables = {'any_prefix_A': 'value_A', 'any_prefix_B': 'value_B', 'different': 'value_different'}
    kwargs = {}
    expected_result = ['any_prefix_A', 'any_prefix_B']

    lm = LookupModule()
    result = lm.run(terms, variables, **kwargs)
    assert result == expected_result

# Generated at 2022-06-21 07:07:41.930935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 07:07:52.377071
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:08:02.487376
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = {
        '_terms' : [ '^qz_.+' ],
        'vars' : {
            'qz_1' : 'hello',
            'qz_2' : 'world',
            'qa_1' : "I won't show",
            'qz_' : "I won't show either",
            }
        }

    lookup = LookupModule()
    result = lookup.run(**args)

    assert(0 == len(result))
