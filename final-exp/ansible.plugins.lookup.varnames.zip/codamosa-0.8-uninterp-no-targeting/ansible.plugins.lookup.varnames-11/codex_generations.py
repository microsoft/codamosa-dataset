

# Generated at 2022-06-21 06:58:26.238959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    lk.run(['test'])

# Generated at 2022-06-21 06:58:33.185835
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test valid no option constructor
    try:
        test = LookupModule()
    except Exception as e:
        assert False, 'Failed to instantiate valid LookupModule object'

    # Test invalid constructor
    try:
        test = LookupModule(junk='junk')
    except TypeError as e:
        assert True, 'Failed to instantiate invalid LookupModule object'

    return True


# Generated at 2022-06-21 06:58:41.439410
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    var1 = {'test': 'test'}
    var2 = {'test2': 'test2'}
    var3 = {'test3': 'test3'}
    lookup_module.run(terms=['test'], variables=var1)
    lookup_module.run(terms=['test2'], variables=var2)
    lookup_module.run(terms=['test3'], variables=var3)
    assert var1 in lookup_module.run(terms=['test'])
    assert var2 in lookup_module.run(terms=['test2'])
    assert var3 in lookup_module.run(terms=['test3'])

# Generated at 2022-06-21 06:58:45.556104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Importing class LookupBase for testing
    from ansible.plugins.lookup import LookupBase

    # Creating instance of LookupModule
    lookup_module = LookupModule()

    # Check that LookupModule is instance of LookupBase
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-21 06:58:48.938919
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    #Debugging
    #print 'lookup: ' + str(lookup)

# Generated at 2022-06-21 06:58:55.798627
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests that no errors are raised
    class DummyVariables(object):
        def __init__(self):
            self.keys = lambda: [1, 2, 3]
    l = LookupModule()
    l.set_options(var_options=DummyVariables())
    l.run([])


# Generated at 2022-06-21 06:58:57.225088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-21 06:58:59.057936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['.+']) == []

# Generated at 2022-06-21 06:59:01.066911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:59:12.203718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_values = {'a':1, 'aa':2, 'ab':3}

    l = LookupModule()
    try:
        l.run(None, variables=var_values)
        assert False
    except AnsibleError as e:
        assert str(e) == '_terms must be a list of strings'

    try:
        l.run('a', variables=var_values)
        assert False
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "a" is not a string, it is a <class \'str\'>'


# Generated at 2022-06-21 06:59:16.968382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import six
    lookup = LookupModule()
    assert isinstance(lookup, six.class_types)

# Generated at 2022-06-21 06:59:17.784555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:59:18.600551
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:59:29.543154
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:59:39.297284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testcase1 = {
        '_terms': ['^a.+'],
        'variables': {
            'a': 1,
            'ada': 1,
            'b': 2,
            'c': 3,
            'd': 4,
            'e': 5,
            'f': 6
        },
        'expected': [
            'a',
            'ada'
        ]
    }

# Generated at 2022-06-21 06:59:48.451856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Check for method run of class LookupModule
    """
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six.moves import cStringIO

    class Options(object):
        """
        Options class stub
        """
        lookup_plugins = None
        terminus = None

    class AnsibleModuleStub(object):
        """
        AnsibleModuleStub class stub
        """

# Generated at 2022-06-21 06:59:57.981374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    ret = LookupModule().run(
        terms=['.+'],
        variables={
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
        }
    )
    assert ret == ['qz_', 'qz_1', 'qz_2', 'qa_1'], '%r' % ret


# Generated at 2022-06-21 07:00:01.070081
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert isinstance(ret, LookupModule)

# Generated at 2022-06-21 07:00:03.525443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')
    assert hasattr(l, 'run')

# Generated at 2022-06-21 07:00:13.917294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for LookupModule.run
    AnsibleError is raised in cases below:
        - when variables is None
        - when term is not a string
        - when term is not a valid regexp
    '''

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_3': "I won't show either",
    }
    lookup = LookupModule()

    # Test not allowed values of variables
    for not_allowed_variables in (None, {}):
        try:
            lookup.run('^qz_.+', variables=not_allowed_variables)
        except AnsibleError as e:
            assert e.message == 'No variables available to search'

    # Test not allowed values of

# Generated at 2022-06-21 07:00:21.508029
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = {'test_variable': True}
    lookupModule = LookupModule()
    lookupModule.run(terms=['test_variable'], variables=variables)

# Generated at 2022-06-21 07:00:24.264540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {}
    module = LookupModule()
    module.run(['^qz_.+'], variables = data)
    assert module.set_options(var_options = data, direct = {}) is None

# Generated at 2022-06-21 07:00:29.383424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   l = LookupModule()
   l.set_options(direct={})

   variables = {'qz_1': 'hello',\
                'qz_2': 'world'}
   terms = ['^qz_.+']
   result = l.run(terms, variables=variables)
   assert 'qz_1' in result and 'qz_2' in result


# Generated at 2022-06-21 07:00:38.114447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={})
    # Test with invalid search term
    try:
        list_vars = l.run(terms=["not_a_valid_term"], variables={'var1': 'abc'})
        assert False
    except AnsibleError as e:
        assert str(e) == 'Unable to use "not_a_valid_term" as a search parameter: nothing to repeat'

    # Test with no matching var
    try:
        list_vars = l.run(terms=['^qz_.+'], variables={'var1': 'abc'})
        assert False
    except AnsibleError as e:
        assert str(e) == 'Unable to use "^qz_.+" as a search parameter: nothing to repeat'

    # Test with valid var


# Generated at 2022-06-21 07:00:51.671324
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock a dict of variables
    variables = dict()
    variables['qz_1'] = 'hello'
    variables['qz_2'] = 'world'
    variables['qz_3'] = 'something'
    variables['qa_1'] = 'I wont show'
    variables['qz_'] = 'I wont show either'

    # Mock LookupModule object for testing
    lookup_module = LookupModule()

    # Test case 1: Return variables with qz_ at the start
    assert lookup_module.run(["^qz_.+"], variables) == ['qz_1', 'qz_2', 'qz_3']

    # Test case 2: Return all variables

# Generated at 2022-06-21 07:00:57.462909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lookup_module = LookupModule()
    terms = ['^qz_.+']
    result = lookup_module.run(terms, variables=vars)
    
    assert ['qz_1', 'qz_2'] == result

# Generated at 2022-06-21 07:01:05.501686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.lookup.varnames  # noqa

    module = ansible.plugins.lookup.varnames.LookupModule()

    # Test with one term at a time and two terms together

    # Test with no variables passed in
    # This must throw an AnsibleError with message "No variables available to search"
    try:
        no_variables = None
        terms = ["^qz_.+"]
        ret = module.run(terms=terms, variables=no_variables, **dict())
        assert False
    except Exception as e:
        assert "No variables available to search" in str(e)

    # Test with a single term

# Generated at 2022-06-21 07:01:12.208784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupmodule = LookupModule()
    assert lookupmodule.get_options(var_options=None, direct=None) is None
    assert lookupmodule.set_options(var_options=None, direct=None) is None
    assert lookupmodule.run(terms='', variables=None, **kwargs) is None

# Generated at 2022-06-21 07:01:22.680927
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule()
    assert test_class.name == 'varnames'
    assert test_class.author == 'Ansible Core Team'
    assert test_class.version_added == '2.8'
    assert test_class.short_description == 'Lookup matching variable names'
    assert test_class.description == 'Retrieves a list of matching Ansible variable names.'
    assert test_class.options == {'_terms': {'description': 'List of Python regex patterns to search for in variable names.', 'required': True}}

# Generated at 2022-06-21 07:01:23.916920
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:01:45.013571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .lookup_plugins.varnames import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    '''
    This class is called by ansible-playbook and only partially emulates its behavior.
    In particular, self.get_option is predefined, self.get_vars is partially emulated and self.templar is not emulated.
    '''
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    lookup_module

# Generated at 2022-06-21 07:01:52.712178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""

    # Arrange
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    lookup_module = LookupModule()

    # Act
    result = lookup_module.run(terms, variables=variables, warn_only=True)

    # Assert
    assert result == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:01:55.093344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Return a string for testing purposes"""
    return "Unit test for LookupModule"


# Generated at 2022-06-21 07:01:56.902152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    s = LookupModule()
    assert s.run(terms=[], variables=None) == []

# Generated at 2022-06-21 07:02:07.014768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def TestLookupModule(LookupBase):
        lookup_instance = LookupBase()

        fake_vars = {
            'test_variable': 'test_variable.value',
            'test_variable.1': 'test_variable.1.value',
            'test_variable.2': 'test_variable.2.value',
            'test_variable.3': 'test_variable.3.value',
            'test_variable.3.1': 'test_variable.3.1.value',
            'test_variable.4': 'test_variable.4.value',
            'test_variable.4.1': 'test_variable.4.1.value',
            'none_match_variable': 'none_match_variable',
            'other_variable': 'other_variable'
        }


# Generated at 2022-06-21 07:02:07.958840
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    assert foo is not None


# Generated at 2022-06-21 07:02:13.886128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    terms = ['qz_.+', 'qb_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'qb_1': 'hello',
        'qb_2': 'world'
    }
    assert lm.run(terms, variables)  == ['qz_1', 'qz_2', 'qb_1', 'qb_2']

# Generated at 2022-06-21 07:02:25.212556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test - Testing lookup module and method
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleError

    lookup_plugin = LookupModule()

    assert lookup_plugin is not None

    # testing LookupModule class
    terms = ['^qz_.+', 'hosts', '.+_zone$', '.+_location$']
    variables1 = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either",
                 'hosts': '127.0.0.1', 'host_zone': 'europe-west1-d', 'host_location': 'europe-west1'}

# Generated at 2022-06-21 07:02:31.671371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    listOfVariableNames = ['var1', 'var2', 'var3', 'var4', 'var5']
    listOfMatchingVariableNames = ['var1', 'var2', 'var5']
    listOfTerms = ['.*var[12].*', '^var5$']
    actualListOfMatchingVariableNames = LookupModule.run(listOfTerms, listOfVariableNames)
    assert listOfMatchingVariableNames == actualListOfMatchingVariableNames

# Generated at 2022-06-21 07:02:43.096741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test 1
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello',
                'qz_2': 'world',
                'qa_1': 'I won\'t show',
                'qz_': 'I won\'t show either'}

    ret = LookupModule().run(terms, variables)
    assert ret == ['qz_1', 'qz_2'], 'test 1 failed'

    # test 2
    terms = ['.+']
    variables = {'qz_1': 'hello',
                'qz_2': 'world',
                'qa_1': 'I won\'t show',
                'qz_': 'I won\'t show either'}

    ret = LookupModule().run(terms, variables)

# Generated at 2022-06-21 07:03:03.633661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    import yaml
    import os
    import json

    # Since the API is constructed for CLI it expects certain options to always be set, named tuple 'fakes' the args parsing options object
    Options

# Generated at 2022-06-21 07:03:09.937141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Basic test for method run of class LookupModule '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost', 'other'])

    variable_manager.set_inventory(inventory)

    variable_manager.extra_vars = {'qz_1': 'hello',
                                   'qz_2': 'world',
                                   'qa_1': "I won't show",
                                   'qz_': "I won't show either"}

    print('\ntesting lookup plugins/varnames')

    lookup_plugin = LookupModule()


# Generated at 2022-06-21 07:03:15.987020
# Unit test for constructor of class LookupModule
def test_LookupModule():
  terms = ['^qz_.+']
  variables = {'qz_1':'hello', 'qz_2': 'world'}
  obj = LookupModule()
  print(obj.run(terms, variables))


if __name__ == '__main__':
  test_LookupModule()

# Generated at 2022-06-21 07:03:17.357008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:03:21.439383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(["^qz_.*"], {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    assert result == ['qz_1', 'qz_2']

    result = lookup.run(["hosts"], {"hosts": "hosts", "host_1": "host_1"})
    assert result == ['hosts']

# Generated at 2022-06-21 07:03:22.906253
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None

# Generated at 2022-06-21 07:03:32.877784
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Try variable names that start with 'qaz'
    test_object = LookupModule()
    mock_variables = {
        'qaz_1': 'hello',
        'qaz_2': 'world',
        'qa': 'I will not show',
    }
    terms = '^qaz_.+'
    results = test_object.run(terms=terms, variables=mock_variables)

    # For this test, there should be only two results
    assert len(results) == 2

    # The first result should be the first key we added
    assert results[0] == 'qaz_1'

    # The second result should be the second key we added
    assert results[1] == 'qaz_2'

    # The third key we added should not be in the results
    assert 'qa' not in results



# Generated at 2022-06-21 07:03:35.445613
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test_defaults
    obj = LookupModule()
    assert obj != None


# Generated at 2022-06-21 07:03:35.772004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:03:40.088491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(['^qz_.+'], {"qz_1": "hello", "qz_2": "world", "qa_1": "not shown", "qz_": "not shown either"}) == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:04:13.403788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup import LookupBase
    import ansible.plugins.lookup.varnames
    class MockLookupBase(LookupBase):
        result = []
        def lookup(self, variable_name, variables=None, **kwargs):
            #print('lookup: %s %s %s' % (variable_name, variables, kwargs))
            return list(variables.keys())

        def set_options(self, var_options=None, direct=None):
            #print('set_options: %s %s' % (var_options, direct))
            self.result = var_options

    m = MockLookupBase()
    result = []

    # run single term regex search

# Generated at 2022-06-21 07:04:22.557626
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()

  # Verify that the constructor throws an error if the variables are set to Null.
  try:
    lookup_module.run(terms="abc", variables=None)
    assert False, "An exception should have been thrown"
  except AnsibleError as e:
    assert True

  # Verify that the constructor throws an error if the variable name is not a string.
  try:
    lookup_module.run(terms=1, variables="abc")
    assert False, "An exception should have been thrown"
  except AnsibleError as e:
    assert True

# Generated at 2022-06-21 07:04:25.341857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run

# Generated at 2022-06-21 07:04:29.507833
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Implementing unit test for constructor of class LookupModule")
    lookup_module = LookupModule()
    assert (lookup_module is not None)


# Generated at 2022-06-21 07:04:38.234710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    terms = ['^qz_.+']
    assert lm.run(terms, variables)[0] == 'qz_1'
    assert lm.run(terms, variables)[1] == 'qz_2'
    assert len(lm.run(terms, variables)) == 2
    variables = {'all_1': 'hello', 'all_2': 'world', 'all_3': "I won't show", 'all_4': "I won't show either"}
    terms = ['.+']
    assert lm.run(terms, variables)[0] == 'all_1'
    assert l

# Generated at 2022-06-21 07:04:47.227066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        '_terms': dict(type='list', required=True),
        'var': dict(type='dict', required=True)
    })
    module.params['var'] = {'hosts': 'localhost', 'hosts_count': 1, 'host_zone': 'localhost'}
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['hosts'], variables=module.params['var'], **{'_direct_terms':True}) == ['hosts', 'hosts_count']

# Generated at 2022-06-21 07:04:55.798197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test1: success case where 'terms' is a list of valid regexes and 'variables' is a valid dictionary
    terms = ['^qz_.+','^qa_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'goodbye', 'qa_2': 'cruel world'}
    assert(LookupModule().run(terms, variables) == ['qz_1', 'qz_2', 'qa_1', 'qa_2'])
    # test2: when 'variables' is None and 'terms' is a valid list of regexes
    variables = None
    assert(LookupModule().run(terms, variables) == 'No variables available to search')


# Generated at 2022-06-21 07:05:02.795603
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(var_options={'hosts': 1, 'hosts_file': 'hosts'})

    result = lookup.run(['hosts'])

    assert len(result) > 0

    result = lookup.run(['hosts_file'])

    assert result[0] == 'hosts_file'

# Generated at 2022-06-21 07:05:15.356375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    class DummyVars(object):
        ansible_hostname = 'localhost'
        ansible_fqdn = 'localhost.localdomain'
        ansible_default_ipv4 = '10.0.2.15'
        ansible_all_ipv4_addresses = [u'10.0.2.15']

    terms = ['ansible_hostname', 'ansible_fqdn', 'ansible_default_ipv4', 'ansible_all_ipv4_addresses']


# Generated at 2022-06-21 07:05:19.272561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    #Has to be a dictionary for the test to pass.
    assert(type(lookup.get_options()) == dict)

# Generated at 2022-06-21 07:06:10.788397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    T = LookupModule()
    raise AssertionError()

# Generated at 2022-06-21 07:06:12.754059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert test_obj.run

# Generated at 2022-06-21 07:06:14.213174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = 'hosts'
    targets = {
        'hosts': 'hosts',
        'hostvars': 'hostvars',
        'localhost': 'localhost',
    }
    lm = LookupModule()
    assert lm.run(terms, targets) == ['hosts']


# Generated at 2022-06-21 07:06:26.877387
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test setup: Define "facts" to test with
    facts = {
        'ansible_facts': {
            'key1': 'val1', 'key2': 'val2', 'key3': 'val3', 'key4': 'val4',
            'Key1': 'Val1', 'Key2': 'Val2', 'Key3': 'Val3', 'Key4': 'Val4'
        }
    }

    # Test setup: Create instance of the LookupModule
    module = LookupModule()

    # Test setup: Mix a bit of regular variables in
    module.set_options(direct={'k1': 'v1', 'k2': 'v2'})

    # Test setup: Inject the facts
    module.set_options(var_options=facts)

    # Test Case: No matches

# Generated at 2022-06-21 07:06:31.914615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')
    assert hasattr(lookup_module, 'set_options')
    assert hasattr(lookup_module, '_display')

# Generated at 2022-06-21 07:06:33.530941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 07:06:41.512877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    matches = ['one', 'two', 'three', 'abc', 'abc_1', 'abc_2', 'abc_3', 'abc_4']
    non_matches = ['', 'a', 'aa', 'aaa', 'aaaa', 'aaaaa', 'ab', 'cab', 'acb', 'cabc',
                   'bcd', 'abd', 'acd', 'abcd', 'abcc', 'ab_5', 'ab_6', 'ab_7']
    m = LookupModule()

    # Try with a search pattern that matches anything
    assert 'abc' in m.run('abc', variables=matches)[0]
    assert len(m.run('.+', variables=matches)[0]) == len(matches)

    # Try with a search pattern that matches the beginning of a string
    assert 'abc' in m

# Generated at 2022-06-21 07:06:50.195256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    ut_vars = {
        'term_one': 'bar',
        'term_two': 'bar',
        'term_three': 'bar',
        'term_four': 'bar',
        'term_five': 'bar'
    }

    ut_terms = ['^term_one$', '^term_two$']
    lookup = LookupModule()

    # Act
    ut_ret = lookup.run(ut_terms, variables=ut_vars)

    # Assert
    assert ut_ret == ut_terms, 'Failed to return the terms passed in'

# Generated at 2022-06-21 07:06:54.715380
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        obj = LookupModule()
        assert True
    except Exception as e:
        assert False, "LookupModule can not be instantiated"

# test_run tests the run method of the class LookupModule

# Generated at 2022-06-21 07:06:57.106060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)
