

# Generated at 2022-06-21 06:58:37.333006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Parametrize test cases, run_method is the first parameter, others are the
    # arguments for run_method.
    test_cases = [
        # 01 test on valid argument of terms
        ['__exists_in_variable_names_01', ['^s.+', '.+s$'], {'s1': 1, '1s':1}, [['s1'], ['1s']]],
        # 02 test on invalid argument of terms
        ['__exists_in_variable_names_02', [1, 2], {'s1': 1, '1s':1}, None],
    ]


# Generated at 2022-06-21 06:58:49.326787
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Assert None is returned for invalid variables
    vars = None
    terms = ['test']
    lookup_module = LookupModule()
    returned_value = lookup_module.run(terms, variables=vars)
    assert returned_value == None

    # Assert None is returned for invalid names
    terms = [1]
    returned_value = lookup_module.run(terms, variables=vars)
    assert returned_value == None

    # Assert a list of names is returned
    variables = {'var1': 'a', 'var2': 'b'}
    vars = {'var3': 'c', 'var4': 'd'}
    terms = ['var[12]']
    returned_value = lookup_module.run(terms, variables=variables)

# Generated at 2022-06-21 06:58:51.482116
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    This test case is to test the instance creation of LookupModule class.
    :return:
    '''
    lm = LookupModule()
    assert isinstance(lm, LookupModule)



# Generated at 2022-06-21 06:59:00.495539
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of the LookupModule
    test_obj = LookupModule()

    # Store the long name of this class for use as a string later
    class_name = __name__ + ".LookupModule"

    # Create vars for use in the tests
    # One with a matching regex
    matching_variable_name = 'qz_1'
    # One with a non-matching regex
    non_matching_variable_name = 'qa_1'
    # One that matches but has a value of None
    null_variable_name = 'qz_2'

    # TODO: Add test case to ensure that passing null/None variables causes
    #       An error to be raised

    # TODO: Add test case to ensure that passing a term that can't be converted
    #       into a regex causes an error to be raised

   

# Generated at 2022-06-21 06:59:11.915143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for method run of class LookupModule
    # Setup test data
    test_data = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    # Intantiate the class
    var_lookup = LookupModule()

    # Test 1: Test when variables is a valid dictionary
    result = var_lookup.run(['^qz_.+'], test_data)
    assert result == ['qz_1', 'qz_2']

    # Test 2: Test when variables is an empty dictionary
    result = var_lookup.run(['^qz_.+'], {})
    assert result == []

    # Test 3: Test when variables is None

# Generated at 2022-06-21 06:59:18.033045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check that we're setting variables correctly and we're getting them back.
    variables = dict()
    variables['a'] = 'Hello World!'
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=variables, direct={})
    assert lookup_plugin.get_options()["var_options"] == variables, "%r != %r" % (lookup_plugin.get_options()["var_options"], variables)


# Generated at 2022-06-21 06:59:19.439562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-21 06:59:22.268611
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupBase)

# Generated at 2022-06-21 06:59:23.268294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:59:29.493328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    py_obj = LookupModule()
    variables = {'ansible_check_mode': True, 'ansible_no_log': True, 'ansible_verbosity': 0, 'variable_prefix': 'ansible_'}
    py_obj.run(terms='^ansible_.+', variables=variables)

# Generated at 2022-06-21 06:59:35.019686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("start test_LookupModule")

    print("end test_LookupModule")

# Generated at 2022-06-21 06:59:46.075832
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  terms = ['.+_zone$', '.+_location$']
  variables = {
    'zone': 'somezone',
    'location': 'somelocation',
    'zone1': 'somezone1',
    'location1': 'somelocation1',
    'something_zone': 'something_zone_value',
    'something_location': 'something_location_value',
    'something_zone1': 'something_zone1_value',
    'something_location1': 'something_location1_value',
    'something_zone2': 'something_zone2_value',
    'something_location2': 'something_location2_value',
  }
  l = LookupModule()
  l.set_options(var_options=variables, direct={})
  ret = l.run(terms, variables)


# Generated at 2022-06-21 06:59:47.860131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule(loader=None, variables=None)
    assert lookup_module != None



# Generated at 2022-06-21 06:59:50.307491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule(None, None)) is LookupModule

# Generated at 2022-06-21 06:59:55.694347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is unsatisfactory because it only tests for presence of the module - it doesn't test the output
    # Also, we should have a test that checks that it doesn't fail in the case where var_options is None.
    assert True is not None

# Generated at 2022-06-21 06:59:56.969810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    temp = LookupModule()
    assert isinstance(temp, LookupModule)

# Generated at 2022-06-21 06:59:59.327265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 07:00:01.637905
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:00:03.050265
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()

# Generated at 2022-06-21 07:00:13.423930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy

    lookup = LookupModule()
    # I need to make some fake variables to use, which are the same format as 'variables'
    fake_variables = {'test_var': 'test_val', 'test_var2': 'test_val2', 'test_var3': 'test_val3'}
    unsafefake_variables = ansible.utils.unsafe_proxy.wrap_var(fake_variables)
    # Fake terms
    terms = ['test_var', 'test_var2', 'test_var3']

    result = lookup.run(terms, variables=unsafefake_variables)

    assert result == ['test_var', 'test_var2', 'test_var3']


# Generated at 2022-06-21 07:00:19.357078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(getattr(LookupModule, 'run'))

# Generated at 2022-06-21 07:00:27.724157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    test_env = os.environ.copy()
    test_env['ANSIBLE_CONFIG'] = './test_LookupModule.cfg'
    module = __import__("ansible.plugins.lookup.varnames", fromlist=["LookupModule"])
    lookup = module.LookupModule()
    result = lookup.run(["qz_.+"], variables = {'qz_1':'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
    assert result == ['qz_2', 'qz_1']
    module = __import__("ansible.plugins.lookup.varnames", fromlist=["LookupModule"])
    lookup = module.LookupModule()

# Generated at 2022-06-21 07:00:31.962427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Test constructor of class LookupModule')
    lookup_module = LookupModule()
    assert type(lookup_module) is LookupModule


# Generated at 2022-06-21 07:00:35.799911
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test initialization of object.
    """
    # Initialize object and check result
    lookup = LookupModule()
    assert lookup is not None
    assert lookup._options == {}

# Generated at 2022-06-21 07:00:38.601968
# Unit test for constructor of class LookupModule
def test_LookupModule():
    for x in [1, [1], {'a': 1}]:
        try:
            LookupModule(x, dict())
            assert False
        except AnsibleError:
            pass


# Generated at 2022-06-21 07:00:51.592319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for the method run of class LookupModule
    """
    from ansible.plugins.lookup.varnames import LookupModule
    lookup = LookupModule()
    # Test for the method run in case the variables are not given
    with pytest.raises(AnsibleError):
        lookup.run(['ansible_facts'])
    # Test for the method run in case the invalid regex is given
    with pytest.raises(AnsibleError):
        lookup.run(['(a*'], variables={'ansible_facts': {}})
    # Test for the method run in case the valid regex is given
    assert lookup.run(['ansible_facts'], {'ansible_facts': {'version': 1}}) == ['ansible_facts']

# Generated at 2022-06-21 07:00:52.068626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:01:00.846889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "foo"
    variables = dict(items=list(range(1,4)))
    exp_res = [ 'foo' ]
    test_obj = LookupModule()
    res = test_obj.run(terms, variables=variables)
    assert res == exp_res

    variables = dict(items=list(range(1,4)))
    exp_res = [ 'noise', 'foo', 'blahnoise' ]
    test_obj = LookupModule()
    res = test_obj.run(terms, variables=variables)
    assert res == exp_res

# Generated at 2022-06-21 07:01:02.795670
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assertLookupModule(lookup)


# Generated at 2022-06-21 07:01:04.119849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert repr(LookupModule())

# Generated at 2022-06-21 07:01:15.352037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert_equal(lm.run, LookupModule.run)

# Generated at 2022-06-21 07:01:25.260108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ["^qz_", "hosts", ".+_zone$", ".+_location$"]
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qz_3': 'hello world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either', 'hosts': 'ansible'}

    # This test is to check if method run returns the same value as the method lookup_plugin.run
    # Given
    l = LookupModule()
    l.set_options(direct={'_terms': terms})
    # When
    ret = l.run(terms, variables)
    # Then
    assert ret == ["qz_1", "qz_2", "qz_3", "hosts"]
    # When

# Generated at 2022-06-21 07:01:30.009429
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create the lookup module object
    my_var = {'q1': 'val1', 'q2': 'val2'}
    my_obj = LookupModule()

    # Call the run method of class LookupModule
    terms = ['q1','q2']
    result = my_obj.run(terms, my_var)

    # Test the result
    assert result == ['q1','q2']

# Generated at 2022-06-21 07:01:35.449890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run(['^qz_.+'], dict(qz_1='hello', qz_2='world')) == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:01:40.678623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    res = LookupModule().run(['^t.+', '^.+_2$'])
    assert type(res) == list
    assert set(res) == set(['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8', 't9', 't_2', 't_21'])

# Generated at 2022-06-21 07:01:41.479621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:01:48.378583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["up_", "counter"]
    variables = {'up_1': 24, 'down_1': 24, 'counter': 1515, 'eggs': 'ham'}
    expected = ['up_1', 'counter']
    actual = lookup.run(terms, variables)
    assert expected == actual

# Generated at 2022-06-21 07:01:51.424445
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, dict())

# Generated at 2022-06-21 07:01:53.666975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 07:01:59.502379
# Unit test for constructor of class LookupModule
def test_LookupModule():
    var_dict = {"foo_bar": "foobar",
                "foo_baz": "foobaz",
                "bar_baz": "barbaz"}
    lookup = LookupModule()
    lookup.set_options(var_options=var_dict, direct={})
    assert lookup.get_option('foo_bar') == "foobar"


# Generated at 2022-06-21 07:02:18.528122
# Unit test for constructor of class LookupModule
def test_LookupModule():
    abc = LookupModule()
    print(abc)

# Generated at 2022-06-21 07:02:19.722328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert lookupModule

# Generated at 2022-06-21 07:02:21.605100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert
    assert not LookupModule().run([''])

# Generated at 2022-06-21 07:02:32.231956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockVars:
        def __init__(self, vars):
            self.vars = vars
        def __getitem__(self, name):
            return self.vars[name]
    lookup = LookupModule()
    variables = MockVars({"foo_123": "Hello", "bar": "World", "q1": "Won't show"})

    # test 'foo' pattern
    assert lookup.run(["^foo.+$"], variables=variables) == ["foo_123"]

    # test '.*' pattern
    assert lookup.run([".+"], variables=variables) == ["foo_123", "bar", "q1"]

    # test invalid pattern

# Generated at 2022-06-21 07:02:36.465870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    terms = ['a']
    variables = {
        "a": "b"
    }

    assert lookup.run(terms, variables) == ['a']

# Generated at 2022-06-21 07:02:42.329508
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    # read return value
    print("LookupModule.run")
    for i in l.run(terms=['.+_zone$', '.+_location$'], variables={'ansible_ssh_host': 'localhost', 'ansible_ssh_port': 2222, 'ansible_connection': 'ssh'}):
        print(i)

if __name__ == "__main__":
    print("test")
    test_LookupModule()

# Generated at 2022-06-21 07:02:52.832420
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def FakeLookupModule(*args, **kwargs):
        #print("FakeLookupModule: args: %s, kwargs: %s" % (args, kwargs))
        self = LookupModule()
        self.run = LookupModule.run
        return self

    lookup_plugin = FakeLookupModule()

    # The return value for the test
    ret = []

    # Test 1
    # Test that something is returned. For this test, just call the method to see if there
    # are any error and if something is in the returned value

# Generated at 2022-06-21 07:03:03.333260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    returned_value = lm.run("hello", variables={"one":"two","three":"four"})
    assert returned_value == []
    returned_value = lm.run("three", variables={"one":"two","three":"four"})
    assert returned_value == ['three']
    returned_value = lm.run("o", variables={"one":"two","three":"four"})
    assert returned_value == ['one','three']
    returned_value = lm.run("^t", variables={"one":"two","three":"four"})
    assert returned_value == ['three']
    returned_value = lm.run(".", variables={"one":"two","three":"four"})
    assert returned_value == ['one','three']

# Generated at 2022-06-21 07:03:15.287804
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def fake_get_basedir(self, terms):
        return os.path.join(os.path.dirname(__file__), "../lookup_plugins/files")

    def fake_get_basedir_terms(self, terms):
        return os.path.join(os.path.dirname(__file__), "../lookup_plugins/files", terms[0])

    LookupBase.get_basedir = fake_get_basedir
    LookupBase.get_basedir_terms = fake_get_basedir_terms

    import os
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lookup_module = LookupModule()

    # test environment
    env = {}
    env[u'env_a'] = u'env_a'

# Generated at 2022-06-21 07:03:16.674843
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None)

# Generated at 2022-06-21 07:03:54.149581
# Unit test for constructor of class LookupModule
def test_LookupModule():
	assert True == True

# Generated at 2022-06-21 07:04:02.226644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    l.set_options(
        var_options={},
        direct={}
    )
    assert l.run(['']) == []

    l.set_options(
        var_options={'a': 1},
        direct={}
    )
    assert l.run(['^a$']) == ['a']

    l.set_options(
        var_options={'a': 1, 'b': 2},
        direct={'a': 3, 'b': 4}
    )
    assert l.run(['^a$', 'b']) == ['a', 'b']

    try:
        l.run([1])
        assert False
    except AnsibleError:
        pass


# Generated at 2022-06-21 07:04:04.131685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert 'msg' in l.run(['msg'])

# Generated at 2022-06-21 07:04:07.202826
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # We need to feed dummy options for instantiation
    lookup_instance = LookupModule(None, dict(), dict())
    assert lookup_instance is not None

# Generated at 2022-06-21 07:04:13.332426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['^qz_.+', 'wrong', 'nothing']
    #vars = dict(qz_zone='zone')
    vars = {'qz_zone': 'zone', 'qz_provider': 'gcp', 'wrong': 'nothing'}

    result = lookup.run(terms, vars)
    
    assert result == ['qz_zone', 'qz_provider']

# Generated at 2022-06-21 07:04:24.355122
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ret = []
    test_terms = ["^qz_.+", ".+", "hosts", "^[^_]{1,}",
                  ".+_zone$", ".+_location$"]
    # Set some variables
    test_variables = {'qz_1': 'hello',
                      'qz_2': 'world',
                      'qa_1': "I won't show",
                      'qz_': "I won't show either",
                      'hosts': 'localhost'
                      }

    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Gets all variables matching the given regex pattern
    for term in test_terms:
        ret = lookup_module.run(terms=[term], variables=test_variables)

# Generated at 2022-06-21 07:04:27.298330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert test_obj is not None

# Generated at 2022-06-21 07:04:29.342610
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert lookup_mod is not None

# Generated at 2022-06-21 07:04:38.210614
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()
    class PluginOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # setup some variables to use for testing

# Generated at 2022-06-21 07:04:41.581008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)
    lookup.run(terms=["qa_1"])

# Generated at 2022-06-21 07:06:15.752890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {'my_var': 'my value',
                 'my2_var': 'my second value'}
    terms = ['^my_.+$']
    look = LookupModule()
    ret = look.run(terms, variables)
    assert ret == ['my_var', 'my2_var']


# Generated at 2022-06-21 07:06:27.311698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_plugin = lookup_loader.get('varnames')
    except Exception as e:
        raise AnsibleError('Unable to create LookupModule: %s' % to_native(e))

    # Create a class for testing purpose. If we would instantiate the
    # original class LookupBase here, the attributes like self.options
    # would not be readable.
    class class_for_methods_only(object):
        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct
            self.options = None

    # Instantiate the test class and call the run method.
    test_obj = class_for_methods_only()

# Generated at 2022-06-21 07:06:39.457723
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # example from the documentation
    variables = dict(qz_1="hello", qz_2="world", qa_1="I won't show", qz_="I won't show either")
    lookup_name = 'varnames'
    terms = ['^qz_.+']
    lookup = LookupModule()
    result = lookup.run(terms, variables)
    assert result == ['qz_1', 'qz_2'], result

    # example from the documentation
    variables = dict(qz_3="hello", qz_4="world", qa_2="I won't show", qz_="I won't show either")
    lookup_name = 'varnames'
    terms = ['.+']
    lookup = LookupModule()
    result = lookup.run(terms, variables)

# Generated at 2022-06-21 07:06:45.696207
# Unit test for constructor of class LookupModule
def test_LookupModule():

    def test_init():
        lookup = LookupModule()
        assert hasattr(lookup, 'run')
        assert lookup.run   # Make sure run is not None

    # test_init()

    def test_run():
        lookup = LookupModule()

        lookup.set_options(direct={'_terms': ['one', 'two'], '_variables': {'one': 1, 'two': 2, 'three': 3}})
        results = lookup.run(['.*'])
        assert results == ['one', 'three', 'two']

        lookup.set_options(direct={'_terms': ['^t.+'], '_variables': {'one': 1, 'two': 2, 'three': 3}})
        results = lookup.run(['.*'])
        assert results == ['three', 'two']

       

# Generated at 2022-06-21 07:06:48.416381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule'''
    # Constructor with no capacity
    lookup = LookupModule()

    assert lookup, 'Failed to initialize LookupModule'

    return 0


# Generated at 2022-06-21 07:06:58.620711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class DummyLookupModule(LookupModule):
        def run(self, *args, **kwargs):
            return super(DummyLookupModule, self).run(*args, **kwargs)

    lm = DummyLookupModule()

    terms = ['.*']
    variables = {
        'test1': AnsibleUnicode('test'),
        'test2': AnsibleUnicode('test')
    }

    assert lm.run(terms, variables) == ['test1', 'test2']

# Generated at 2022-06-21 07:07:07.777549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    class_to_test = LookupModule()
    terms = ["^qz_.+", ".+", "hosts", ".+_zone$", ".+_location$"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either", "hosts_zone": "zone_value", "hosts_location": "location_value"}
    kwargs = {}

# Generated at 2022-06-21 07:07:11.956531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()


if __name__ == '__main__':
    # Unit test for constructor
    test_LookupModule()

# Generated at 2022-06-21 07:07:21.096561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit tests for method run of class LookupModule"""
    terms = ["name1", "name2", "name3"]
    variables = {
        "name1" : "value1",
        "not_name1": "value2",
        "name2" : "value3",
        "name3" : "value4",
        "name4" : "value5"
    }
    l = LookupModule()
    expected = ["name1", "name2", "name3"]
    assert expected == l.run(terms, variables)
    terms = ["name_\d"]
    expected = ["name1", "name2", "name3"]
    assert expected == l.run(terms, variables)
    terms = ["name.$"]
    expected = ["name1", "name2", "name3"]
    assert expected == l

# Generated at 2022-06-21 07:07:25.568746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=["test", "test2"], variables={"test":"testvalue", "test2":"testvalue2"}) == ["test", "test2"]