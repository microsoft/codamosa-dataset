

# Generated at 2022-06-21 06:58:29.252860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Call constructor
    bar = LookupModule()

    # Access private variables
    #assert bar._LookupModule__foo == "foo"

    # Accessing public variables
    #assert bar.fie == "fie"

    # Accessing public functions
    #assert bar.get_foo() == "foo"

# Generated at 2022-06-21 06:58:39.284722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils._text import to_bytes

    lookup = lookup_loader.get('varnames', class_only=True)()

    def pprint(variables):
        return to_bytes('\n'.join(['{}: {}'.format(k, v) for k, v in variables.items()]))

    assert 'bar_a' in lookup.run(terms=['bar_a'], variables={'bar_a': 1, 'bar_b': 2})

    assert 'bar_a' in lookup.run(terms=['bar_a'], variables={'bar_a': 1, 'bar_b': 2})


# Generated at 2022-06-21 06:58:50.246491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test with different terms
    assert lookup_module.run(['^qz_.+'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert lookup_module.run(['hosts'], {'ansible_hosts': 'localhost,127.0.0.1', 'ansible_facts': 'dict'}) == ['ansible_hosts']
    assert lookup_module.run(['.+_zone$', '.+_location$'], {'ansible_location': 'my', 'ansible_zone': 'test'}) == ['ansible_location', 'ansible_zone']

# Generated at 2022-06-21 06:58:53.226077
# Unit test for constructor of class LookupModule
def test_LookupModule():
	# Constructor test
	print("Test 1: Constructor test")
	lookup_module = LookupModule()
	assert lookup_module is not None

# Generated at 2022-06-21 06:59:03.497772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = 'qz_'
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    result = lookup_plugin.run(terms, variables=variables)
    assert sorted(result) == sorted(['qz_1', 'qz_2'])

    terms = '.+'
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    result = lookup_plugin.run(terms, variables=variables)

# Generated at 2022-06-21 06:59:05.550917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({1, 2}).tasks == {1, 2}

# Generated at 2022-06-21 06:59:06.608027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 06:59:07.695016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1

# Generated at 2022-06-21 06:59:19.798038
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
        'qz_' : "I wont show either"
    }

    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options=variables, direct={})
    result_list = [
        lookup_obj.run(terms=['^qz_.+']),
        lookup_obj.run(terms=['.+']),
        lookup_obj.run(terms=['hosts']),
        lookup_obj.run(terms=['.+_zone$', '.+_location$'])
    ]

    # Unordered list comparison
    assert set(result_list[0]) == set(['qz_1', 'qz_2'])

# Generated at 2022-06-21 06:59:30.398560
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3
    if not PY3:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')

    lookup = LookupModule()
    variables = {'ab_cz': 'hello'}
    terms = ['^ab_.+']
    res = lookup.run(terms=terms, variables=variables)
    assert res == ['ab_cz']

    variables = {'ab_cz': 'hello', 'ab_cz_2': 'world'}
    res = lookup.run(terms=terms, variables=variables)
    assert res == ['ab_cz', 'ab_cz_2']

    variables = {'ab_cz': 'hello', 'cd_cz': 'hello', 'ab_cz_2': 'world'}

# Generated at 2022-06-21 06:59:34.499803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:59:45.678885
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import StringIO

    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.utils.display import Display

    # Create the looker-upper
    lu = LookupModule()

    # Create the variables to search through
    variables = {
        'ansible_all_ipv4_addresses': '192.168.1.1',
        'food_is_good': 'yup',
        'food_is_great': 'yep',
        'food_pasta': 'yep',
    }

    # Define the search terms
    # Note: If a term is a string, it is assumed to be a Python regular expression.
    # If a term is a list, it is assumed to

# Generated at 2022-06-21 06:59:48.030401
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    test_lookup.run([''])

# Generated at 2022-06-21 06:59:50.380263
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None



# Generated at 2022-06-21 06:59:58.732783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.plugins.lookup import LookupBase

    class MyLookupModule(LookupBase):

        def run(self, terms, variables=None, **kwargs):
            variables = None
            return super(MyLookupModule, self).run(terms, variables, **kwargs)

    try:
        MyLookupModule().run(terms=["a", "b"])
    except AnsibleError as e:
        result = str(e)

    assert result.startswith('No variables available to search')


# Generated at 2022-06-21 07:00:02.255935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_LookupModule = LookupModule()
    assert my_LookupModule.run is not None

# Generated at 2022-06-21 07:00:13.269153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.parsing.vault import VaultLib

    # Create secret variables for test
    vault_password_file = '~/.vault_pass.txt'
    vault_secret_file = '~/vault_secret.yml'


# Generated at 2022-06-21 07:00:24.479669
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # expected list which is returned by lookup module
    exp_ret_list = ['f1', 'f2']

    # test input dictionary
    variables = {
        'f1': "value1",
        'f2': "value2",
        'f3': "value3",
    }

    # test input pattern
    patterns = [
        '^f[12]',
        '^f3',
    ]

    def test_run(self, terms, variables=None, **kwargs):
        if variables is None:
            raise AnsibleError("No variables available to search")
        self.set_options(var_options=variables, direct=kwargs)

        ret = []
        variable_names = list(variables.keys())

# Generated at 2022-06-21 07:00:25.744821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 07:00:33.972946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup Lookup Module instance
    lookup = LookupModule()

    # Setup LookupBase module input arguments
    # Initialize empty dictionary as 'variables' input
    variables = {}

    # Update/Append 'variables' dictionary with two variables
    variables['ansible_default_ipv4_address'] = '127.0.0.1'
    variables['my_name'] = 'Daniel'

    # Create individual regex patterns for testing
    ipv4_pattern = '^ansible_[a-zA-Z0-9]+_ipv4([a-zA-Z0-9]+)?$'
    name_pattern = '^([a-zA-Z]+)_name$'
    invalid_regex_pattern = '^(?!InvalidRegEx$)$'

    # Create a list of regex patterns
    pattern

# Generated at 2022-06-21 07:00:41.327485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:00:46.610241
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Instantiate class LookupModule and verify it has
        'run' and 'set_options' methods.
    """
    assert hasattr(LookupModule(), 'run')
    assert hasattr(LookupModule(), 'set_options')

# Generated at 2022-06-21 07:00:49.091399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of LookupModule """
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 07:00:57.426615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.constants import DEFAULT_VAULT_IDENTITY_LIST
    from ansible.module_utils.common.collections import ImmutableDict

    variables = {'azure_default': '', 'azure-vm': ''}
    terms = ['azure.*', 'azure-.*']

    LookupModule(variables=variables, vault_ids=DEFAULT_VAULT_IDENTITY_LIST).run(terms=terms)

    # Create expect result
    expect_ret = ['azure_default', 'azure-vm']

    assert variables == {'azure_default': '', 'azure-vm': ''}
    assert expect_ret == ['azure_default', 'azure-vm']

# Generated at 2022-06-21 07:01:06.180649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': 'I won\'t show either'}, direct={})
    assert lookup_module.run(terms=['^qz_.+']) == ['qz_1', 'qz_2'], 'result of lookup with regexp string is wrong'


test_LookupModule_run()

# Generated at 2022-06-21 07:01:08.005795
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ml = LookupModule()

# Generated at 2022-06-21 07:01:10.485879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run is not None
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 07:01:13.165314
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 07:01:18.857895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  variables = {"var1": 1, "var2": 2, "var3": 3}
  terms = ['var1', 'var3', 'var3']
  result = lookup_module.run(terms, variables)
  assert len(result) == 2
  assert result[0] == "var1"
  assert result[1] == "var3"

# Generated at 2022-06-21 07:01:30.508850
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Example variables
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    lookup_obj = LookupModule()

    # Test regex pattern matching
    term = '^qz_.+'
    assert lookup_obj.run(term, variables) == ['qz_1', 'qz_2'] 

    # Test string matching
    term = 'hosts'
    assert lookup_obj.run(term, variables) == ['hosts']

    # Test multiple patterns
    terms = ['^qz_.+', 'qa_1']

# Generated at 2022-06-21 07:01:55.093487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['azure_*/facts.location', 'azure_*/facts.vmsize']

# Generated at 2022-06-21 07:01:56.350621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run('abc', 'abc') == []

# Generated at 2022-06-21 07:02:06.741139
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["^qz_.+", ".+", "hosts", ".+_zone$", ".+_location$"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either",
                 "hosts": "foundme", "hosts_hosts": "foundme", "hosts_hosts_hosts": "foundme",
                 "hosts_list": "notfound", "hosts_list_list": "notfound", "hosts_list_list_list": "notfound",
                 "zone_staging": "foundme", "zone_prod": "foundme", "location_staging": "foundme",
                 "location_prod": "foundme"}

# Generated at 2022-06-21 07:02:09.064812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-21 07:02:13.218581
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run(['^qz_.+']) == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:02:16.794771
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run(terms=['.+'])) > 0
    assert len(LookupModule().run(terms=['^qz_.+'])) > 0
    assert len(LookupModule().run(terms=['.+_zone$', '.+_location$'])) > 0

# Generated at 2022-06-21 07:02:17.491455
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:02:18.889186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 07:02:28.801926
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.constants import DEFAULT_MODULE_PATH
    from ansible.module_utils.basic import AnsibleModule

    # Get the arguments for the module

# Generated at 2022-06-21 07:02:35.467282
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [ '^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$' ]
    variables = { 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': 'I won\'t show either', 'ansible_host': 'localhost' }

    lookup = LookupModule()
    result = lookup.run(terms, variables)
    assert result == [ 'qz_1', 'qz_2', 'qz_1', 'qz_2', 'qa_1', 'qz_', 'qz_1', 'qz_2', 'qa_1', 'qz_', 'ansible_host' ]

# Generated at 2022-06-21 07:03:15.568509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    from ansible.plugins.lookup import LookupBase
    import ansible.plugins.lookup as lookup
    import ansible.plugins.lookup.varnames as varnames
    import ansible.parsing.dataloader as dataloader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    
    test_hosts = [Host(name="host1"), Host(name="host2")]
    test_groups = [Group(name="group1"), Group(name="group2")]

    test_inventory = InventoryManager(
        loader=dataloader.DataLoader(),
        sources='localhost,'
    )


# Generated at 2022-06-21 07:03:27.989554
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    import copy
    import sys
    if sys.version_info[0] < 3:
        # iteritems not available in python3
        # use to_native to avoid unicode issues
        myvars = dict([(to_native(k), to_native(v)) for (k, v) in {'testvar1': 'testval1', 'testvar2': 'testval2', 'testvar3': 'testval3'}.iteritems()])
    else:
        myvars = {'testvar1': 'testval1', 'testvar2': 'testval2', 'testvar3': 'testval3'}

    # test single pattern
    assert module.run(['testvar.+'], myvars) == [ 'testvar1', 'testvar2', 'testvar3']



# Generated at 2022-06-21 07:03:40.271760
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_var = {'variable': 'hello world'}
    lu = LookupModule()
    assert lu.run(['variable'], [test_var]) == ['variable']

    # test invalid regexp
    try:
        lu.run(['variable)', test_var])
        assert False
    except AnsibleError as e:
        assert e.message == 'Unable to use "variable)" as a search parameter: unbalanced parenthesis'

    # test invalid regexp
    try:
        lu.run([2, test_var])
        assert False
    except AnsibleError as e:
        assert e.message == 'Invalid setting identifier, "2" is not a string, it is a <class \'int\'>'

# Generated at 2022-06-21 07:03:43.809675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    #pylint: disable=protected-access
    assert l._templar is None
    assert l._loader is None

# Generated at 2022-06-21 07:03:45.196671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None)


# Generated at 2022-06-21 07:03:46.661657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj._options is None
    assert obj._loader is None
    assert obj._templar is None


# Generated at 2022-06-21 07:03:56.470890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['^qz_.+'],
                              variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    assert LookupModule().run(['hosts'], variables={'ansible_hosts': 'ansible.example.org',
                                                    'remote_user': 'ansible_admin'}) == ['ansible_hosts']

# Generated at 2022-06-21 07:03:57.990940
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj.__class__.__name__ == 'LookupModule'

# Generated at 2022-06-21 07:04:07.145076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    variables = { "name" : "n", "name_1" : "1", "name1" : "1", "n" : "n", "n_" : "", "n__" : ""}
    terms = [ "name" ]
    result = obj.run(terms, variables)
    assert result == [ 'name', 'name_1' ]
    assert obj.run(["not found"], variables) == []

    # multiple items
    assert obj.run([ "name", "name_1"], variables) == [ 'name', 'name_1' ]

    # bad terms
    with pytest.raises(AnsibleError):
        obj.run([ 1 ], variables)

# Generated at 2022-06-21 07:04:09.859929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test != None


# Generated at 2022-06-21 07:05:23.938049
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    # assert run() returns a value if lookup_vars is not set
    # when lookup_vars is not set, assert get_options() assumes it is an empty list
    assert LookupModule(None, None).run(terms=["^qz_.+"]) == []

    # Test 2
    # assert run() returns a value if lookup_vars has variables
    # when lookup_vars has variables, assert they are used as the variable namespace
    lookup_vars = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
        }

# Generated at 2022-06-21 07:05:36.166777
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class LookupModuleTest(LookupModule):

        def __init__(self):
            self.variables = {'var1': 'hello world', 'var2': 'bye world', 'var3': 'goodbye world', 'var4': 'adios world'}

    lookup_ret = LookupModuleTest().run(terms=['^var.+$', '^var.+$'], variables=None)
    assert len(lookup_ret) == 0

    lookup_ret = LookupModuleTest().run(terms=['^var.+$'], variables=None, mock_options={'var_options': {}})
    assert len(lookup_ret) == 0


# Generated at 2022-06-21 07:05:43.483816
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # path to playbook being executed
    path = 'path'
    # load lookups
    loader = 'loader'
    # varmanager
    varmanager = 'varmanager'
    # templar
    templar = 'templar'

    # create object of class LookupModule
    lm = LookupModule(loader=loader, var_manager=varmanager, templar=templar)
    assert lm.basedir == path

# Generated at 2022-06-21 07:05:46.403786
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:05:56.764144
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.compat.tests import mock

    # MOCK -----------------------------------------------------------------------
    class MockPluginLoader(object):

        def get(self, name, *args, **kwargs):
            return LookupModule(*args, **kwargs)

        def all(self, *args, **kwargs):
            return []

    def mock_get_plugin_loader(plugin_type):
        return MockPluginLoader()

    # HELPERS --------------------------------------------------------------------
    class VariableManager(object):
        def __init__(self, variables=None):
            self.variables = variables

        def get_vars(self):
            return self.variables

    # TESTS ----------------------------------------------------------------------

# Generated at 2022-06-21 07:06:06.176642
# Unit test for constructor of class LookupModule
def test_LookupModule():
    url = 'https://example.com/api/v2'
    auth = 'abc'
    otp = '123'
    headers = { 'Content-Type': 'application/json' }
    timeout = 10
    module = LookupModule()
    module.set_options(
        var_options = {
            'url': url,
            'auth': auth,
            'otp': otp,
            'headers': headers,
            'timeout': timeout,
        },
        direct = {},
    )
    assert url == module.url
    assert auth == module.auth
    assert otp == module.otp
    assert headers == module.headers
    assert timeout == module.timeout

# Generated at 2022-06-21 07:06:07.780746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 07:06:13.813190
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_variables = {'test_var': 'A variable'}
    my_lookup = LookupModule()
    my_lookup.set_options(var_options=test_variables, direct={})
    assert my_lookup._templar is not None
    assert my_lookup._loader is not None

# Generated at 2022-06-21 07:06:16.309783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    kwargs = dict(variable=dict(key="value"))
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=kwargs, direct=kwargs)
    assert lookup_module

# Generated at 2022-06-21 07:06:18.806386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = LookupModule().run("test")
    assert False