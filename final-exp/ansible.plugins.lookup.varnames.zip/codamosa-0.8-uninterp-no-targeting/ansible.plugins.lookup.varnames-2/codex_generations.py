

# Generated at 2022-06-21 06:58:36.860628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test environment
    import sys; sys.path.append("../../lookup_plugins")
    l = LookupModule()

    # Test datas
    v = {
        'k1': 'v1',
        'k2': 'v2',
    }

    def test_run(terms, expected):
        assert l.run(terms, v) == expected

    # Tests
    test_run('^k1', ['k1'])
    test_run('v1', ['k1'])
    test_run(['^k1', 'v1'], ['k1', 'k1'])
    test_run(['^k1', '^k2'], ['k1', 'k2'])

if __name__ == '__main__':
    # Unit Testing
    test_LookupModule_run()

# Generated at 2022-06-21 06:58:45.783966
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    variables = {
        "abc": "abc",
        "bcd": "bcd",
        "def": "def",
    }

    # Test basic functionality
    assert lookup.run(["a", "b"], variables) == ["abc", "bcd"]

    # Test empty list
    assert lookup.run(["c"], variables) == []

    # Test regex
    assert lookup.run([".*"], variables) == ["abc", "bcd", "def"]

# Generated at 2022-06-21 06:58:56.496685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_mock = 'qz_.+'
    variables_mock = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }
    expected_result = ['qz_1', 'qz_2']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=[term_mock], variables=variables_mock)
    assert result == expected_result

# Generated at 2022-06-21 06:58:58.150055
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj is not None

# Generated at 2022-06-21 06:59:10.636004
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 1
    # LookupModule.run() with a valid term
    # Return value should be a list of matching variables
    lookup_module = LookupModule()
    test_terms = ['^test.+']
    test_variables = {'test_1': 'test_1', 'test_2': 'test_2', 'test_3': 'test_3', 'no_match': 'no_match'}

    expected = ['test_1', 'test_2', 'test_3']
    actual = lookup_module.run(test_terms, test_variables)

    assert (expected == actual)

    # Test 2
    # LookupModule.run() with multiple valid terms
    # Return value should be a list of matching variables
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:59:12.645317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    name = LookupModule('var_name')
    assert name is not None

# Generated at 2022-06-21 06:59:14.633544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-21 06:59:22.570301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test LookupModule run method
    '''
    # Setup arguments
    terms = ['^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'one_zone': '',
        'two_zone': '',
        'one_location': '',
        'two_location': '',
        'one_locations': '',
        'two_locations': '',
    }

# Generated at 2022-06-21 06:59:30.768915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with no terms
    try:
        LookupModule().run(terms=[])
        assert False
    except AnsibleError as e:
        assert to_native(e) == 'Invalid setting identifier, "" is not a string, it is a <class \'list\'>'

    # Test with no variables
    try:
        LookupModule().run(terms=["^qz_.+"])
        assert False
    except AnsibleError as e:
        assert to_native(e) == 'No variables available to search'

    # Test with invalid regex
    try:
        LookupModule().run(terms=["["], variables={"[": "hello world"})
        assert False
    except AnsibleError as e:
        assert to_native(e).startswith("Unable to use")



# Generated at 2022-06-21 06:59:34.008957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for invalid variable identifier
    varnames = LookupModule()
    varnames.run([5], {'test': 123})


# Generated at 2022-06-21 06:59:39.577510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:59:42.982765
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms=['TEST', 'TEST2'], variables={'TEST':1, 'TEST2':2})

# Generated at 2022-06-21 06:59:43.524003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:59:48.464703
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="just a test",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{lookup("varnames", "^qz_.+")}}'))),
        ]
    )


# Generated at 2022-06-21 07:00:00.138854
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test of the function run with valid parameters
    #
    #       Args:
    #           terms: list of search terms
    #           variables: context variable used for the test
    #           kwargs: dictionary with arguments for the function set_options
    #       Returns:
    #           list of variable names matched
    #       Raises:
    #           AnsibleError, when the context variable is None
    #

    terms = [ '^qz_.+' ]
    variables = { 'qz_1':'hello', 'qz_2':'world', 'qa_1':'I will not show', 'qz_':'I will not show either' }

    lookup_obj = LookupModule()
    ret = lookup_obj.run(terms, variables)

    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:00:02.144729
# Unit test for constructor of class LookupModule
def test_LookupModule():
        testObj = LookupModule()
        assert type(testObj) == LookupModule


# Generated at 2022-06-21 07:00:13.233367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if not PY3:
        module_args = {}
        module = AnsibleModule(argument_spec=module_args)

        #
        # setup test data
        #

        vars = {
            'test_1': 1,
            'test_2': 2,
            'test_3': 3,
            'test_4': 4,
            'test_5': 5,
        }

        expected = ['test_1', 'test_2', 'test_3', 'test_4', 'test_5']

        #
        # test
        #

        # test valid pattern
        r = LookupModule().run(['.+'], variables=vars)
        assert r == expected

        #

# Generated at 2022-06-21 07:00:24.436451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify that the constructor fails if variables is None.
    # The first parameter is the lookup name.
    lookup = LookupModule('varnames')
    try:
        lookup.run(['^dev_'])
        assert False
    except AnsibleError:
        assert True

    # No terms are given.
    lookup = LookupModule('varnames')
    assert lookup.run([], {'dev_1': '', 'prod_1': ''}) == []

    # Invalid regexp.
    lookup = LookupModule('varnames')
    try:
        lookup.run(['['], {'dev_1': '', 'prod_1': ''})
        assert False
    except AnsibleError:
        assert True

    # No variables match.
    lookup = LookupModule('varnames')

# Generated at 2022-06-21 07:00:33.247285
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_result = [ 'one_a', 'one_b']

    test_vars = {
        'one_a': 1,
        'one_b': 1,
        'one_c': 1,
        'two_a': 2,
        'two_d': 2,
        'three_e': 3,
        'four_f': 4,
        'five_g': 5,
        'six_g': 6,
    }

    test_terms = [ '^one_$', '^one_.' ]

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    variable_manager.extra_vars = test_vars

    lm = LookupModule()
    lm.set_loader(loader)

# Generated at 2022-06-21 07:00:42.031255
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:00:47.833988
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:00:49.502524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if not LookupModule():
        raise Exception("Test failed, failing to create object LookupModule")


# Generated at 2022-06-21 07:00:50.248261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO
    pass


# Generated at 2022-06-21 07:00:51.822367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None, "LookupModule() failed"

# Generated at 2022-06-21 07:00:57.022693
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test if the constructor of the LookupModule class raises an AnsibleError
    if no variables are provided.
    """
    lookup = LookupModule()
    try:
        lookup.run(terms=[], variables=None, **{})
    except Exception as exc:
        assert isinstance(exc, AnsibleError)
        assert exc.args[0] == 'No variables available to search'

# Generated at 2022-06-21 07:00:58.423063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    return lm

# Generated at 2022-06-21 07:01:01.191213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule
    lookup_module = LookupModule()


# Generated at 2022-06-21 07:01:07.323135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = ['test1', 'test2']
    test_variables = {
        'test1': 1,
        'test2': 2,
        'test3': 3,
    }
    lookup = LookupModule()
    variables = lookup.run(test_terms, test_variables)
    assert len(variables) == 2
    assert test_variables['test1'] == 1
    assert test_variables['test2'] == 2

# Generated at 2022-06-21 07:01:18.139145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run_lookup(name, pattern):
        obj = LookupModule()
        return obj.run(
                terms = pattern,
                variables = { name: '' })

    assert ['abc'] == run_lookup('abc', ['abc'])
    assert ['abc', 'bcd'] == run_lookup('bcd', ['a.+', 'b.+'])
    assert ['abc', 'bcd'] == run_lookup('bcd', ['^a.+', '^b.+'])
    assert ['abc', 'bcd'] == run_lookup('bcd', ['^[ab].+'])
    assert ['abc'] == run_lookup('abc', ['^a'])
    assert ['abc'] == run_lookup('abc', ['^a.+'])

# Generated at 2022-06-21 07:01:30.219708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader

    # Test with one term and matches in the variable name
    terms = ['hello']
    variables = {'hello': 'world'}
    lookup = lookup_loader.get('varnames')
    result = lookup.run(terms, variables)
    assert result == ['hello']

    # Test with a non string term
    terms = ['hello', 123]
    variables = {'hello': 'world'}
    lookup = lookup_loader.get('varnames')
    try:
        lookup.run(terms, variables)
        assert False
    except AnsibleError as e:
        assert "Invalid setting identifier" in str(e)

    # Test with a bad regular expression - expect error
    terms = ['hello', '^[world']
    variables = {'hello': 'world'}


# Generated at 2022-06-21 07:01:51.629401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    import json
    terms = ["some.+", "blah.+"]
    variables = '{"some_var1": "123456", "some_var2": "blah_blah_var2", "some_var3": "1", "some_var4": "Something", "some_var5": {"inner_var1": "1", "inner_var2": "2"}, "some_var6": ["1", 2, 3], "some_var7": 123, "some_var8": ["1", "2", {"inner_var3": "some", "inner_var4": {"inner_inner_var1": "1", "inner_inner_var2": "2", "list": ["1", "2"]}}]}'
    variables2 = json.loads(variables)

# Generated at 2022-06-21 07:01:58.119035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    ret = []
    assert c.run('',{}) == ret
    assert c.run(['',''],{}) == ret
    assert c.run(['',''],{'a':1}) == ['a']
    assert c.run('',{'a':1}) == ['a']


# Generated at 2022-06-21 07:02:06.523724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupBase()
    lm = LookupModule()
    lm.set_options(var_options={'a':'a', 'b':'b', 'd':'d'}, direct={'d': 'd'})
    assert lm.run(['a']) == ['a']
    assert lm.run(['b']) == ['b']
    assert lm.run(['a', 'd']) == ['a', 'd']
    assert lm.run(['.+']) == ['a', 'b', 'd']
    assert lm.run(['^a$']) == ['a']
    assert lm.run(['^s$']) == []


# Generated at 2022-06-21 07:02:10.498011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run(terms='^qz_.+', variables={'qz_1': 'hello','qz_2': 'world','qa_1': 'I won\'t show','qz_': 'I won\'t show either'})

# Generated at 2022-06-21 07:02:23.308393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    sys.modules['__ansible_module_utils__'] = __import__('ansible_collections.ansible.builtin.plugins.module_utils',fromlist=['ansible_collections.ansible.builtin.plugins'])
    test_obj = LookupModule()
    test_terms = ['^qz_.+','^-','^\d','^[abc]','^def','abc','^','abc','(abc)','^1','^a','\d']

# Generated at 2022-06-21 07:02:30.749405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  module = LookupModule()
  terms = ['^qz_.+','x','^zz','^zzz','^zzzz','^zzz$','^zzzz$','^qz_.+','^qz_.+','^qz_.+$','^qz_.+$']
  variables = {'qz_1':'hello','qz_2':'goodbye','qa_1':'I will not show','qz_':'I will not show either'}
  results = module.run(terms,variables)
  print("results: " + str(results))

# Generated at 2022-06-21 07:02:32.107762
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:02:42.776410
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # In ctor of LookupModule, it will call 
    # self.get_basedir
    # self.get_vars, then it will pass vars to plugin_vars
    # self.set_options, then it will set self.basedir, self.plugins_vars
    # get_basedir and get_vars are defined in base class LookupBase
    # set_options are defined in LookupModule
    plugin = LookupModule()
    #test get_basedir with no path in inventory
    assert plugin.basedir == ""
    #test get_basedir with path in inventory
    plugin = LookupModule(inventory={"_basedir":"test_basedir"})
    assert plugin.basedir == "test_basedir"


# Generated at 2022-06-21 07:02:44.137794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-21 07:02:52.664039
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize LookupModule instance
    lookup_module = LookupModule()

    # Check for lookup result for all variables
    variables = {'a': '1', 'b': '2'}
    terms = ['^.+']
    result = lookup_module.run(terms, variables)
    expected_result = ['a', 'b']
    assert result == expected_result

    # Check for lookup result for variable which starts with 'a'
    variables = {'a1': '1', 'b': '2'}
    terms = ['^a.+']
    result = lookup_module.run(terms, variables)
    expected_result = ['a1']
    assert result == expected_result

# Generated at 2022-06-21 07:03:14.187292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Construct a lookup and test to see if it works.
    """
    lookup = LookupModule()
    terms = []
    ret = lookup.run(terms)

# Generated at 2022-06-21 07:03:25.647597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(
        [],
        terms=['^qz_.+']
    ) == []

    assert LookupModule.run(
        {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won\'t show', 'qz_': 'I won\'t show either'},
        terms=['^qz_.+']
    ) == ['qz_1', 'qz_2']


# Generated at 2022-06-21 07:03:29.565393
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    the_data = { "one": 1, "two": 2, "three": 3 }
    obj = LookupModule()
    result = obj.run(terms=["^one$", "^tw"], variables=the_data)
    assert result == ['one', 'two']

# Generated at 2022-06-21 07:03:41.531038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    lookup._loader = DummyLoader()

    lookup.run(['.+_zone$', '.+_location$'], {'myvar_zone': 'mytest', 'myvar_xlocation': 'mytest'})
    lookup.run(['.+_zone$'], {'myvar_zone': 'mytest', 'myvar_xlocation': 'mytest'})
    lookup.run(['.+_zone$'], {'myvar_zone': 'mytest', 'myvar_xlocation': 'mytest'})
    lookup.run(['.+_zone$'], {'myvar_zone': 'mytest', 'myvar_xlocation': 'mytest'})

# Unit

# Generated at 2022-06-21 07:03:52.276496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test Import
    global LookupModule
    from ansible.plugins.lookup import LookupModule

    # Test Execution
    # Test no variable
    try:
        LookupModule().run(terms=[''], variables=None)
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError not raised'

    # Test invalid terms
    try:
        LookupModule().run(terms={}, variables={})
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError not raised'

    # Test valid terms
    vars = {'output_var': 'output_value', 'network_var': 'network_value', 'dns_var': 'dns_value'}
    terms = ['output', 'network', 'dns']
    result = LookupModule

# Generated at 2022-06-21 07:03:54.630186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "No test implemented"


# Generated at 2022-06-21 07:04:05.272882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a dummy lookup module instance
    lookup = LookupModule()

    # Dummy variables to search
    variables = {
        "a1b2c3": "something",
        "aa_bb_cc": "something different",
        "a_very_long_variable_name": "yet something else",
    }

    # Call the run method of the dummy lookup module
    # First term is the search term, second term are the variables to search
    result = lookup.run(["a.+b.+c.+"], variables)
    assert len(result) == 1
    assert "a1b2c3" in result

    result = lookup.run(["bb"], variables)
    assert len(result) == 0

    result = lookup.run([r"a.*long.*able.*name$"], variables)

# Generated at 2022-06-21 07:04:06.269935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule()
    assert test_class is not None

# Generated at 2022-06-21 07:04:15.455349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # initialize variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    # variables to add to variable manager
    variables = dict(qz_1='hello', qz_2='world')
    # set variables
    variable_manager.set_vars(variables)

    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=dict())

    # test that variables are set correctly
    assert lookup_module._options['_variables'] == variables

    # test that the run method works correctly
    terms = ["^qz_.+"]
    results = lookup_module.run(terms)

# Generated at 2022-06-21 07:04:19.508269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    ansible_vars = {'a':'A'}
    lookup.run(['.+'],ansible_vars)

# Generated at 2022-06-21 07:05:16.508807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for testing `LookupModule.run()` method """

    # create a mock AnsibleOptions
    # having `options.vars` and `options.direct` is enough.
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI as BaseAdHocCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class AdHocCLI(BaseAdHocCLI):
        def run(self):
            context.CLIARGS = self.args

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    for k, v in {'foo': 'bar', 'bar': 'baz', 'r': 'r', 'zx': 'zx'}.items():
        variable_

# Generated at 2022-06-21 07:05:23.900753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["^qz_.+"]

    def _is_correct(result):
        assert(type(result) == list)
        assert(len(result) == 2)
        assert(result == ["qz_1", "qz_2"])

    _is_correct(
        lookup.run(
            terms,
            variables={
                "qz_1": "hello",
                "qz_2": "hello",
                "qa_1": "I won't show",
                "qz_": "I won't show either"
            }
        )
    )

    _is_correct(
        lookup.run(
            terms
        )
    )



# Generated at 2022-06-21 07:05:34.332768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_options = dict(varnames=dict(
        _terms=['^qz_.+'],
        _variables=dict(qz_1='hello', qz_2='world', qa_1="I won't show", qz_="I won't show either"),
    ))
    assert lookup_plugin.run(**lookup_options) == ['qz_1', 'qz_2']

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 07:05:42.337832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        import re
    except ImportError:
        print ('Unable to import re module')
        sys.exit(1)

    if re.match('^[a-zA-Z0-9_]*$', 'qz_1'):
        print ('re module imported successfully')
        sys.exit(0)
    else:
        print ('re module imported but fails unit test')
        sys.exit(1)

# Generated at 2022-06-21 07:05:50.400360
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.plugins.lookup.varnames

    # return a list of variable names in variable_names
    # Pattern match the variable names with regex_pattern
    # Append list of matched variable names to return_list
    # return value of return_list
    def mock_func(self, terms, variables=None, **kwargs):
        return_list = []
        variable_names = list(variables.keys())

        for regex_pattern in terms:
            for varname in variable_names:
                if re.search(regex_pattern, varname):
                    return_list.append(varname)

        return return_list

    # Mock method run of class LookupModule
    ansible.plugins.lookup.varnames.LookupModule.run = mock_func

    # Test case 1: return a list of variable names

# Generated at 2022-06-21 07:05:51.301959
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:05:58.385833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test for invalid term
    term = [1234, 5432]
    variables = {
        'hosts': 'hosts.yml',
        'test': 'test',
    }
    with pytest.raises(AnsibleError):
        lookup.run(terms=term, variables=variables)

    # Test for valid terms
    terms = ['^qz_.+', '.+_zone$', '.+_location$']

# Generated at 2022-06-21 07:06:07.637144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_variable = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
        'qz_': 'I wont show either'
    }
    lookup_obj = LookupModule()
    terms = ['^test_.+']
    result = lookup_obj.run(terms,test_variable)
    assert len(result) == 0
    terms = ['^qz_.+']
    result = lookup_obj.run(terms,test_variable)
    assert len(result) == 2
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'qa_1' not in result
    assert 'qz_' not in result
    terms = ['.+']

# Generated at 2022-06-21 07:06:18.397610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule.run() Test function
    """

    from objects.ansible_collections.ansible.builtin.plugins.lookup.test import test_variables
    from objects.ansible_collections.ansible.builtin.plugins.lookup.test import test_variables_2

    lookup_module = LookupModule()

    # This should create a list of one variable name
    test_vars = { "ansible_test_testvar1": "testvar1", "testvar2": "testvar2" }
    ret = [ "ansible_test_testvar1" ]
    test = lookup_module.run(["ansible_test_testvar1"], variables=test_vars)

# Generated at 2022-06-21 07:06:20.360788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    return lookup_plugin

# Generated at 2022-06-21 07:08:10.391063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = dict(
        connection='local',
        module_path='/Users/kakwa/ansible',
        forks=100,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
    )

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='/Users/kakwa/ansible/hosts')

# Generated at 2022-06-21 07:08:16.749346
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    lookup = LookupModule()
    assert lookup != None
    assert isinstance(lookup, LookupModule)

# Unit tests for run() function of class LookupModule

# Generated at 2022-06-21 07:08:26.497414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # hash used to test case when terms are list.
  terms_list = ["ansible_user", "ansible_password", "ansible_port"]
  # hash used to test case when terms are string.
  terms_string = "ansible_user"
  # hash used to test case when terms are None.
  terms_null = None

  # hash used to test case when variables is empty.
  variables_empty = dict()
  # hash used to test case when variables is None.
  variables_null = None

  LookupModule_class = LookupModule()

  # Test case when terms are list of strings, variables is empty.
  assert LookupModule_class.run(terms=terms_list, variables=variables_empty) is None

  # Test case when terms are list of strings, variables is None.