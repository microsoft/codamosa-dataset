

# Generated at 2022-06-21 06:58:31.316680
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            return super(TestLookupModule, self).__init__(*args, **kwargs)
    lookup_module = TestLookupModule()
    assert(lookup_module != None)

# Generated at 2022-06-21 06:58:32.632039
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()

    assert module is not None

# Generated at 2022-06-21 06:58:38.426896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    
    class TestVars:
        def keys(self):
            return ['a1', 'a2', 'a3', 'b1', 'b2', 'b3', 'c1', 'c2', 'c3']

    variables = TestVars()
    terms = ['^a[1-2]$', 'c2']

    ret = lk.run(terms, variables=variables)
    assert ret == ['a1', 'a2', 'c2']

# Generated at 2022-06-21 06:58:40.408818
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lkM = LookupModule()
   assert lkM is not None

# Generated at 2022-06-21 06:58:41.280124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 06:58:48.440645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Test with invalid terms: list of int
    terms = [1, 2]
    variable = dict()
    returned_value = lookup_plugin.run(terms)
    assert returned_value is None

    # Test with invalid terms: string
    term = 'test_term'
    variable = dict()
    returned_value = lookup_plugin.run(term)
    assert returned_value is None

    # Test with invalid terms: int
    term = 1
    variable = dict()
    returned_value = lookup_plugin.run(term)
    assert returned_value is None

    # Test with invalid terms: double
    term = 1.5
    variable = dict()
    returned_value = lookup_plugin.run(term)
    assert returned_value is None

    # Test with invalid terms: regex without

# Generated at 2022-06-21 06:58:50.647104
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    assert look

# Generated at 2022-06-21 06:58:51.291921
# Unit test for constructor of class LookupModule
def test_LookupModule():
   look = LookupModule()

# Generated at 2022-06-21 06:59:00.218819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    vars = {}

    vars["one"] = "yes"
    vars["two"] = "no"
    vars["three"] = "maybe"

    data = [
        {
            "terms": ["^o"],
            "result": ["one"]
        },
        {
            "terms": ["^t"],
            "result": ["two", "three"]
        },
        {
            "terms": ["yes"],
            "result": ["one"]
        },
        {
            "terms": ["maybe"],
            "result": ["three"]
        }
    ]

    for d in data:
        assert sorted(d["result"]) == sorted(test_obj.run(d["terms"], variables = vars))

# Generated at 2022-06-21 06:59:01.316394
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module,LookupModule)

# Generated at 2022-06-21 06:59:04.994110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert test_lookup is not None

# Generated at 2022-06-21 06:59:05.847866
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 06:59:09.604157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    variable_names = {'hello': 'world', 'ansible': 'rocks', 'ansible_v2': 'rocks'}
    terms = ['ansible', 'hello', 'ansible_v2']
    result = test_obj.run(terms, variables=variable_names)
    assert isinstance(result, list)
    assert len(result) == len(terms)
    assert 'hello' in result
    assert 'ansible' in result
    assert 'ansible_v2' in result

# Generated at 2022-06-21 06:59:20.396280
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    l = LookupModule()

    # test missing terms
    try:
        l.run([], variables={})
        assert "missing terms"
    except AnsibleError:
        pass

    # test string terms
    assert l.run(['^qz_.+'], variables={'qz_1':'hello', 'qz_2':'world'}) == ['qz_1', 'qz_2']
    assert l.run(['^qz_.'], variables={'qz_1':'hello', 'qz_2':'world'}) == ['qz_1', 'qz_2']
    assert l.run(['^qz_.+$'], variables={'qz_1':'hello', 'qz_2':'world'}) == []

# Generated at 2022-06-21 06:59:31.595074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    lookup_obj = LookupModule()
    loader_obj = DataLoader()

    # Test retval with one term and matching variables
    retval = lookup_obj.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I won''t show', 'qz_': 'I won''t show either'})
    assert retval == [u'qz_1', u'qz_2']

    # Test retval with one term and non matching variables

# Generated at 2022-06-21 06:59:40.212820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'x': 1, 'y': 2, 'z': 3, 'a': 'b', 'c': 'd'}

    l = LookupModule()
    l.set_options(variable_manager=variable_manager)
    res = l.run('^x')
    assert ['x'] == res

    res = l.run('^[xy]')
    res.sort()
    assert ['x', 'y'] == res

    res = l.run(r'^[(a-z)|(0-9)]$')

# Generated at 2022-06-21 06:59:41.967832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        testClass = LookupModule()
        assert testClass
    except:
        assert False


# Generated at 2022-06-21 06:59:46.952497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create dummy class
    class Vars:
        def get(self, key):
            return 'value of ' + key

    lookup_plugin = LookupModule()
    variables = {
        'app_name': 'myapp',
        'app_root': '/opt/myapp',
        'app_user': 'myapp',
        'app_log': '/var/log/myapp',
    }

    # Test: Returns an empty list if no terms
    terms = []
    results = lookup_plugin.run(terms=terms, variables=variables)
    assert [] == results

    # Test: Returns all variables which a term is part of the name
    terms = ['app']
    results = lookup_plugin.run(terms=terms, variables=variables)

# Generated at 2022-06-21 06:59:47.718430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:59:59.881381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'value', 'b': 'value'}
    loader = DataLoader()
    lookup_module = LookupModule()
    lookup_module.set_loader(loader)
    lookup_module.set_not_found_value('not found')
    lookup_module.set_templar(variable_manager)
    lookup_module.set_basedir('./')
    terms = ['a']
    lookup_module_run_result = lookup_module.run(terms, variables=variable_manager._extra_vars)
    assert lookup_module_run_result == ['a'], "Unable to identify matching variables"

# Generated at 2022-06-21 07:00:08.388323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #call test constructor
    LookupModule()

# Generated at 2022-06-21 07:00:16.333341
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:00:23.545044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert 'AnsibleError' in repr(x.run(terms=[], variables=None, **{}))
    assert 'AnsibleError' in repr(x.run(terms=[1], variables={'a': ''}, **{}))
    assert 'AnsibleError' in repr(x.run(terms=['a[b'], variables={'a': ''}, **{}))
    assert 'b' in repr(x.run(terms=['a'], variables={'a': '', 'b': ''}, **{}))

# Generated at 2022-06-21 07:00:24.137464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:00:32.953335
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2
    from ansible.plugins.lookup import LookupModule
    if PY2:
        import __builtin__ as builtins
    else:
        import builtins

    class MyLookupModule(LookupModule):
        def run(self, terms, inject=None, **kwargs):
            return terms

    mod = MyLookupModule()
    ret = mod.run(terms = [],
                  variables = {'a': 3, 'b': 4, 'c': 5})
    assert ret == []
    ret = mod.run(terms = ['a', 'b', 'c'],
                  variables = {'a': 3, 'b': 4, 'c': 5})

# Generated at 2022-06-21 07:00:33.489199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 07:00:38.114056
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    result = lookup.run(terms=["^qz_.+"], variables={"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"})
    assert result == ["qz_1", "qz_2"]

# Generated at 2022-06-21 07:00:51.672473
# Unit test for constructor of class LookupModule
def test_LookupModule():

    local_path = __file__

    # loading the LookupModule class
    lm = LookupModule()

    # extracting the directory of the current file
    local_path = local_path[::-1]
    local_path = local_path[local_path.index('/') + 1:]
    local_path = local_path[::-1]

    # creating a test list
    test_list = ['test', 'testing', 'random', 'random-test']

    # running the run function of LookupModule class with 'test_list' as a parameter
    # and the relative path to 'test-plugins' directory as second parameter
    res = lm.run(test_list, local_path)

    # verifying if 'res' contains the correct results
    assert res == ['test', 'testing'], '?'

# Generated at 2022-06-21 07:01:04.121028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test for method run of class LookupModule")

    #############
    #  test_1  #
    #############
    # Test 1a: Case with no variables defined (i.e. variables=None):
    #
    # Update: this test has been disabled because, even though the error
    # message on line 62 of lookup_plugins/varnames.py has been changed to
    # 'No variables available to search', it still only raises the
    # 'AnsibleError' exception.
    #
    # Expected error message: "No variables available to search"
    # Note that 'AnsibleError' is printed to the terminal instead of
    # 'No variables available to search'.
    #
    # try:
    #     # data for the test
    #     terms = ['var1', 'var2']
    #

# Generated at 2022-06-21 07:01:13.803731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    string_io = StringIO()
    d = {'a': '1', "b": "2", "c": "3", "d": "4", "e": "5"}
    j = LookupModule().run("[a-z]", variables=d)
    print("Test: Check the results returned by a valid search", file=string_io)
    print("Expected: ['a', 'b', 'c', 'd', 'e']", file=string_io)
    print("Actual: " + str(j), file=string_io)
    assert j == ['a', 'b', 'c', 'd', 'e'], "Test has failed"
    print("Test: Check the results returned by an invalid search", file=string_io)
    print

# Generated at 2022-06-21 07:01:41.610452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create lookup module object
    lu = LookupModule()

    # variables is a dictionary
    variables = {'one_var': 1, 'two_var': 2, 'three_var': 3}

    # term is one variable name
    term_one = 'one_var'

    # invoke method run
    ret = lu.run([term_one])

    # verify result
    assert ret == ['one_var']

    # verify variables was not changed
    assert lu._templar.available_variables == variables

    # term is two variable names
    term_one = 'one_var'
    term_two = 'two_var'

    # invoke method run
    ret = lu.run([term_one, term_two])

    # verify result
    assert ret == ['one_var', 'two_var']



# Generated at 2022-06-21 07:01:43.657749
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup, "Failed to instantiate LookupModule"

# Generated at 2022-06-21 07:01:55.594599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import unittest

    # Run tests against the fixtures in this file
    fixture_dir = os.path.join(os.path.dirname(__file__), 'fixtures')

    # Use the system ansible.cfg
    lookup_base = LookupModule(config={'BASEDIR': fixture_dir})

    # Check that good input works
    assert lookup_base.run(
        ['.+_zone$', '.+_location$'],
        variables={'my_zone': 'my_zone',
                   'my_location': 'my_location',
                   'not_zone': 'not_zone',
                   'not_location': 'not_location'}
    ) == ['my_zone', 'my_location']

    # Check that bad input throws errors

# Generated at 2022-06-21 07:02:00.127451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupBase)
    assert lookup_plugin.lookup_type == 'varnames'
    assert callable(lookup_plugin.run)

# Generated at 2022-06-21 07:02:05.986644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Verify that constructor of class LookupModule works.'''

    # Call constructor of class LookupModule
    lookup_module = LookupModule()

    # Verify that we have a object of class LookupModule
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 07:02:12.222185
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Imports
    import imp
    import os
    import sys
    
    # Test module
    test_module_name = 'test_module_varnames'
    test_module_path = os.path.join('test', 'units', 'modules', 'test_module_varnames.py')
    test_module_args = {
        'test_argument': 'test_argument',
        'test_option': 'test_option'
    }

# Generated at 2022-06-21 07:02:20.596669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'worl',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either'
    }

    res = LookupModule().run(terms, variables)
    assert res == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:02:31.874446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  import ansible.constants as C
  import os
  import os.path
  import sys

  loader = DataLoader()
  variable_manager = VariableManager()
  inventories = []

  class FakeModule(object):
    def __init__(self, **kwargs):
      self.params = kwargs

    def fail_json(self, *args, **kwargs):
      self.exit_args = args
      self.exit_kwargs = kwargs
      raise Exception('FAIL')

    def exit_json(self, *args, **kwargs):
      self.exit_args = args
      self.exit_kwargs = kw

# Generated at 2022-06-21 07:02:33.863416
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()

# Generated at 2022-06-21 07:02:35.962867
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test_terms
    terms = ['a', 'b', 'c', 'd', 'e', 'f']
    test_LookupModule = LookupModule()
    test_LookupModule.run(terms, variables = None, **kwargs)

# Generated at 2022-06-21 07:03:12.990742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms = ['^qz_.+'],variables= {'qz_1':'hello','qz_2':'world','qa_1':'I will not show','qz_':'I will not show either'})
    l.run(terms = ['^qz_.+'],variables= {'qz_1':'hello','qz_2':'world','qa_1':'I will not show','qz_':'I will not show either'})
    l.run(terms = ['^qz_.+'],variables= {'qz_1':'hello','qz_2':'world','qa_1':'I will not show','qz_':'I will not show either'})

# Generated at 2022-06-21 07:03:14.804200
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Verify that constructor of LookupModule is working correctly
    lm = LookupModule()

    assert(type(lm) == LookupModule)

# Generated at 2022-06-21 07:03:26.920310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Testing method run of class LookupModule.'''

    # Testing 'terms' parameter is not a list
    terms_list = [ '^qz_.+', ]
    variables_dict = { 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", }
    terms_not_list = '^qz_.+'
    variables = variables_dict
    kwargs = {}
    lookup_object = LookupModule()
    try:
        lookup_object.run(terms_not_list, variables, **kwargs)
        assert False
    except AnsibleError:
        pass

    # Testing 'variable' parameter is not a dictionary
    terms = terms_list
    variables = list(variables_dict.keys())


# Generated at 2022-06-21 07:03:34.247724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_ins = LookupModule()

    # Test variables
    terms = ["^qz_.+", "hosts", ".+_zone$", ".+_location$"]
    vars = dict()
    vars['qz_1'] = "hello"
    vars['qz_2'] = "world"
    vars['qa_1'] = "I won't show"
    vars['qz_'] = "I won't show either"
    vars['hosts'] = "hosts"
    vars['hosts_zone'] = "hosts_zone"
    vars['hosts_location'] = "hosts_location"
    vars['qa_zone'] = "I don't show"
    vars['qa_location'] = "I don't show either"


# Generated at 2022-06-21 07:03:43.165671
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case: run: no terms
    # Expected result: AnsibleError
    try:
        LookupModule().run([])
    except AnsibleError as e:
        assert str(e) == '_terms is required'
    else:
        raise AssertionError

    # Test case: run: non-string term
    # Expected result: AnsibleError
    try:
        LookupModule().run([123,])
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "123" is not a string, it is a <class \'int\'>'
    else:
        raise AssertionError

    # Test case: run: bad regex
    # Expected result: AnsibleError

# Generated at 2022-06-21 07:03:45.196765
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert hasattr(t, 'run')

# Generated at 2022-06-21 07:03:50.537451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['^qz_.+'], variables={'qz_1': 'hello', 'qz_2': 'world',
                                                          'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:03:54.910784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')


# Generated at 2022-06-21 07:04:02.400691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    import json
    import pytest


# Generated at 2022-06-21 07:04:04.343863
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 07:05:17.100851
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert isinstance(result,LookupModule)


# Generated at 2022-06-21 07:05:25.135228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test empty case
    terms = []
    variables = None
    kwargs = {}

    # Try to run with no variables
    try:
        LookupModule().run(terms, variables=variables, **kwargs)
        # Should never get here
        assert False
    except AnsibleError as e:
        # This is expected
        assert e.message == 'No variables available to search'

    # Test empty case
    terms = []
    variables = {'v1': 'val1', 'v2': 'val2'}
    kwargs = {}

    # Try to run with empty terms

# Generated at 2022-06-21 07:05:36.658506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Valid call
    valid_terms = ['^qz_.+', 'hosts']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'hosts': 'true'}
    ret = lookup_module.run(terms=valid_terms, variables=variables)
    assert sorted(ret) == ['hosts', 'qz_1', 'qz_2']

    # Invalid call
    invalid_terms = ['^qz_.+', 'hosts', ['a', 'b']]

# Generated at 2022-06-21 07:05:46.092730
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # string is not a string
    terms = [1]
    variables = {}
    lookup = LookupModule()
    try:
        lookup.run(terms, variables)
    except AnsibleError as e:
        assert e.args[0] == "Invalid setting identifier, '1' is not a string, it is a <class 'int'>"

    # term is a pattern
    terms = ["^abc"]
    variables = {"abc": {}, "abc_123": {}}
    lookup = LookupModule()
    try:
        result = lookup.run(terms, variables)
    except AnsibleError as e:
        assert False, "Allowed bad regex pattern"
    assert result == ["abc", "abc_123"]

    # term is invalid regex pattern
    terms = ["["]
    variables = {"abc": {}}

# Generated at 2022-06-21 07:05:56.619401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()
    test_variables = {"test1": "test", "scalartest": 1337, "test2": "test"}
    test_expected_output = ['test1', 'test2']

    # Test matching strings
    matching_strings = test_lookup.run(["test.*"], test_variables)
    assert matching_strings == test_expected_output

    # Test matching with int
    matching_strings_with_int = test_lookup.run(["test.*", 1234], test_variables)
    assert matching_strings_with_int == test_expected_output

    # Test matching with wrong regex
    matching_strings_with_wrong_regex = test_lookup.run([1234], test_variables)

# Generated at 2022-06-21 07:06:08.164936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables_dict = {'a': '1', 'b': '2', 'c': '3'}
    lookup_obj = LookupModule()
    # test 1
    lookup_result = lookup_obj.run(['.+'], variables=variables_dict)
    assert sorted(lookup_result) == sorted(list(variables_dict.keys()))
    # test 2
    lookup_result = lookup_obj.run(['a'], variables=variables_dict)
    assert sorted(lookup_result) == sorted(['a'])
    # test 3
    lookup_result = lookup_obj.run(['^[a-z]$'], variables=variables_dict)
    assert sorted(lookup_result) == sorted(variables_dict.keys())
    # test 4
    lookup_result = lookup_obj

# Generated at 2022-06-21 07:06:18.599601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class DictModule(object):

        def __init__(self, params={}):
            self.params = params

        def get(self, key, default=None, type=None, no_convert=False):
            return self.params.get(key, default)

    class FakeVarsModule(object):

        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, loader, path, entities, cache=True):
            return self.vars

    # Test params initialization
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

    # Test basic set_options method

# Generated at 2022-06-21 07:06:27.975700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify that if variables is None, that an error is raised
    module = LookupModule()
    variables = None
    terms = "test"
    try:
        module.run(terms, variables)
    except AnsibleError as err:
        assert err.message == "No variables available to search"


# Verify that if variables is not None and the term matches the variable name, that
# that variable name is returned in the list
    module = LookupModule()
    variables = {"test": "test_value"}
    terms = "test"
    returned_list = module.run(terms, variables)
    assert returned_list == ["test"]

# Verify that if variables is not None and the term does not match the variable name, that
# that variable name is not returned in the list
    module = LookupModule()

# Generated at 2022-06-21 07:06:37.137382
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    x = LookupModule()
    terms = ["^qz_.+"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either"}

    result = x.run(terms, variables)
    assert result == ['qz_1', 'qz_2']



# Generated at 2022-06-21 07:06:40.945854
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None