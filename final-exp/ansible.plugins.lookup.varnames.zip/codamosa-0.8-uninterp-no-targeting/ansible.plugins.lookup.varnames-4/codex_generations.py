

# Generated at 2022-06-21 06:58:24.415312
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:58:25.773748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:58:31.343227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    # __init__ initializes an attribute 'templar' which is an object of class Templar
    assert l.templar is not None

    # constructor initializes an attribute '_templar' which is an object of class Templar
    assert l._templar is not None


# Generated at 2022-06-21 06:58:36.278422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a LookupModule
    test_LookupModule = LookupModule()

    # Create a fake variable variable
    variable = {"test": "variable"}

    # test run with variable as variable
    test_LookupModule.run(["test"], variable)

    # test run with variable as variable and some options
    test_LookupModule.run(["test"], variable, var_options=variable)

# Generated at 2022-06-21 06:58:38.310279
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module is not None)

# Generated at 2022-06-21 06:58:49.756700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test all variables
    terms = ".*"
    variables = dict(key1="value1", key2="value2")
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == list(variables.keys())

    # Test search by the complete name
    terms = "^key.+"
    variables = dict(key1="value1", key2="value2")
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == list(variables.keys())

    # Test search by the partial name
    terms = "key.+"
    variables = dict(key1="value1", key2="value2")
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == list(variables.keys())

# Generated at 2022-06-21 06:58:50.388752
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 06:59:00.080194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test_LookupModule_run: test run method of LookupModule """
    import os
    import sys
    import unittest
    import pytest
    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, my_path + '/../../')
    from ansible.plugins.lookup import varnames
    from ansible.parsing.mod_args import ModuleArgsParser

    class TestLookupModule(unittest.TestCase):
        """ Class: TestLookupModule """
        lookup_mod = varnames.LookupModule()

        def test_varnames_run_normal(self, monkeypatch):
            """ test_varnames_run_normal: test run method of LookupModule with normal options """

# Generated at 2022-06-21 06:59:08.986343
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Expected variables from lookup_module as variable_names, terms, variables
    variable_names = ['key1', 'key2', 'key3']
    terms = ['key1']
    variables = {'key1': ['value1'], 'key2': ['value2'], 'key3': ['value3']}

    # Call run-method of class LookupModule with the given values
    lookup_module = LookupModule()
    lookup_module.run(terms, variables)

    # Call run-method of class LookupModule with invalid terms
    terms = [2]
    lookup_module.run(terms, variables)

# Generated at 2022-06-21 06:59:20.175256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test')
    test_terms = ['^qz_.+', '.+']
    test_var_data = dict(qz1='hello', qz2='world', qa1="I won't show", qz="I won't show either")
    expected_results = ['qz1', 'qz2', 'qz', 'qz1', 'qz2', 'qa1', 'qz']

    lm_inst = LookupModule()
    actual_results = lm_inst.run(test_terms, test_var_data)

    for expected_result in expected_results:
        if expected_result not in actual_results:
            raise Exception('expected %s in actual results (%s)' % (expected_result, actual_results))

    print('ok')


# Generated at 2022-06-21 06:59:30.746767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_data = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'hosts': 'localhost',
        'groups_hosts': 'localhost',
        'inventory_hosts': 'localhost',
        'group_names': 'localhost',
        'inventory_dir': 'path_to_dir',
        'inventory_file': 'path_to_dir/filename',
        'inventory_file_abs': 'path_to_dir/filename'
    }

    input_terms = ['^qz_.+']

    exp_output = ['qz_1', 'qz_2']

    obj = LookupModule()

# Generated at 2022-06-21 06:59:32.455618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:59:33.215941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(None, None), LookupModule))

# Generated at 2022-06-21 06:59:34.135742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:59:45.609347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty term
    result = LookupModule().run(terms=[''], variables={"test1": "test1"})
    assert result == []

    # Test with all variable names matched
    result = LookupModule().run(terms=['test1', 'test2'], variables={"test1": "test1", "test2": "test2", "test3": "test3"})
    assert result == ['test1', 'test2']

    # Test with pattern
    result = LookupModule().run(terms=['^test'], variables={"test1": "test1", "test2": "test2", "test3": "test3"})
    assert result == ['test1', 'test2', 'test3']

    # Test with one variable not matched

# Generated at 2022-06-21 06:59:46.419619
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 06:59:55.133053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['local'])
    variable_manager.set_inventory(inventory)
    play = Play()

    my_lookup = LookupModule(loader=loader, variable_manager=variable_manager, play=play)

    assert isinstance(my_lookup, LookupBase)

# Generated at 2022-06-21 07:00:04.226494
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:00:14.304239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Verify return value of method run of class LookupModule"""

    # Variables needed to setup class LookupModule
    terms = ['^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$']
    variables={
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
        'qz_': 'I wont show either',
        'zone': 'test_zone',
        'location': 'test_location',
        'hosts_zone': 'test_host_zone',
        'hosts_location': 'test_host_location',
        'hosts': 'test_hosts'
    }

    # Verify return value of method run

# Generated at 2022-06-21 07:00:17.236746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)
    lookup_module = LookupModule()
    assert isinstance(lookup_module, object)

# Generated at 2022-06-21 07:00:22.414118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True

# Generated at 2022-06-21 07:00:29.377037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    mock_lookup_module = LookupModule()

    mock_lookup_module.set_options = MagicMock(return_value = None)
    
    # Test with 'variables' is None - raise AnsibleError
    expected_result = AnsibleError('No variables available to search')
    actual_result = mock_lookup_module.run(terms=["hello"], variables = None, **{'ansible_env': {}})
    assert expected_result == actual_result

    # Test with 'term' is not string - raise AnsibleError
    expected_result = AnsibleError('Invalid setting identifier, "123456" is not a string, it is a <class \'int\'>')

# Generated at 2022-06-21 07:00:32.471734
# Unit test for constructor of class LookupModule
def test_LookupModule():
    d = {'q1': 'hello', 'q2': 'world'}
    lm = LookupModule()
    lm.set_options(var_options=d, direct={})
    assert lm.get_option('q1') == 'hello'

# Generated at 2022-06-21 07:00:39.649096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.
    """
    # Create a LookupModule object
    lookup_module = LookupModule()
    # Create a set of test variables
    variables = {}
    variables['hostvars'] = {}
    variables['hostvars']['host1'] = {'ansible_host': '127.0.0.1'}
    variables['hostvars']['host2'] = {'ansible_host': '127.0.0.1'}
    variables['hostvars']['host3'] = {'ansible_host': '127.0.0.1'}
    variables['hostvars']['host4'] = {'ansible_host': '127.0.0.1'}

# Generated at 2022-06-21 07:00:41.825808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__

# Generated at 2022-06-21 07:00:55.070357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    if os.name == 'posix':
        test_varnames = {'http_proxy': 'http://192.168.1.1:3128', 'https_proxy': 'http://192.168.1.1:3128', 'no_proxy': '192.168.1.0/24,localhost'}
    else:
        test_varnames = {'http_proxy': 'http://192.168.1.1:3128'}

    test_terms = '^http.+'
    test_ansible_args = {}

    test_lookup_instance = LookupModule()
    test_lookup_instance.set_options(var_options=test_varnames, direct=test_ansible_args)


# Generated at 2022-06-21 07:01:05.937929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.plugins.lookup.varnames import LookupModule as NewLookupModule
    from ansible.utils.display import Display

    display = Display()
    lookup_plugin = NewLookupModule(display)
    lookup_plugin_old = LookupModule(display)
    terms = [ '.+' ]
    variables = { 'name1': 'value1', 'name2':'value2' }
    assert lookup_plugin.run(terms, variables) == lookup_plugin_old.run(terms, variables)

# Generated at 2022-06-21 07:01:17.798875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Simple test
    #
    lk = LookupModule('varnames')
    vars = {'Foo':'bar', 'Foo_1':'bar1', 'Bar':'foo', 'Bar_1':'foo1'}
    terms = ['^Foo_.*']
    result = lk.run(terms,variables=vars)
    assert 'Foo_1' in result
    #
    # Simple test 2
    #
    lk = LookupModule('varnames')
    vars = {'Foo':'bar', 'Foo_1':'bar1', 'Bar':'foo', 'Bar_1':'foo1'}
    terms = ['^Bar_.*']
    result = lk.run(terms,variables=vars)

# Generated at 2022-06-21 07:01:21.523550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 07:01:31.360962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    # Should raise AnsibleError when variables are not available
    try:
        mod.run(terms = ['a', 'b'], variables = None)
    except AnsibleError as e:
        assert str(e) == 'No variables available to search'
    else:
        assert False

    # Should raise AnsibleError when a search pattern is not a string
    try:
        mod.run(terms = ['a', 1, 'b'], variables={'a':'a', 'b':'b'})
    except AnsibleError as e:
        assert str(e).startswith('Invalid setting identifier, "')
    else:
        assert False

    # Should raise AnsibleError when the regex fails to compile

# Generated at 2022-06-21 07:01:45.774175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['^qz_.+', '.+', 'hosts', '.+_zone$', '.+_location$']
    qz_1_var = 'hello'
    qz_2_var = 'world'
    qa_1_var = "I won't show"
    qz__var = "I won't show either"
    vars = {'qz_1': qz_1_var, 'qz_2': qz_2_var, 'qa_1': qa_1_var, 'qz_': qz__var}

    # Build LookupModule
    lookup = LookupModule()

    # Run method LookupModule.run with variables
    result = lookup.run(terms=terms, variables=vars)

    # Define expected result

# Generated at 2022-06-21 07:01:56.070704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lk = LookupModule()
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
        'hosts': 'should be returned',
        'service_zone': 'should be returned',
        'service_location': 'should be returned',
        'service_fake': 'should not be returned',
    }

# Generated at 2022-06-21 07:02:03.216769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.tried is None
    assert lookup.terms == None
    assert lookup.options is None
    assert lookup.variables == None
    assert lookup.basedir == None
    assert lookup.module_vars == None
    assert lookup.TaskVars is None
    assert lookup.play_context == None
    assert lookup.runner is None
    assert lookup.filename == None
    assert lookup.task_vars is None

# Generated at 2022-06-21 07:02:13.577002
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case for a single term
    mock_variables = {'term_1': 'value', 'term_2': 'value', 'term_3': 'value', 'term_4': 'value'}
    terms = ['term_[0-9]']

    lookup_mock = LookupModule(loader=None, variables=mock_variables)
    result = lookup_mock.run(terms, variables=mock_variables)
    assert result == ['term_1', 'term_2', 'term_3', 'term_4']

    # Test case for a single term that doesn't exists
    mock_variables = {'var_1': 'value', 'var_2': 'value', 'var_3': 'value', 'var_4': 'value'}
    terms = ['term_[0-9]']



# Generated at 2022-06-21 07:02:24.323419
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Use this mock lookup to test the method run of class LookupModule
    class LookupUnitTest(LookupModule):
        def __init__(self):
            self.mock_args = {}
            self.mock_args["terms"] = []
            self.mock_args["variables"] = {}

        def run(self, terms, variables=None, **kwargs):
            self.mock_args["terms"] = terms
            self.mock_args["variables"] = variables
            return super(LookupUnitTest, self).run(terms, variables, **kwargs)

    lut = LookupUnitTest()
    terms = [".+"]
    variables = {"a_1": "hello", "b_2": "world"}
    # Test if a list of variable names will return

# Generated at 2022-06-21 07:02:26.227615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().get_options() == {'direct': {}}

# Generated at 2022-06-21 07:02:32.951904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["^qz_.+"], {"qz_abc": "xyz", "qz_def": "123"}) == ["qz_abc", "qz_def"]
    assert module.run(["^qz_.+"], {"qz_abc": "xyz", "qz_def": "123", "qa_ghi": "jkl"}) == ["qz_abc", "qz_def"]
    assert module.run(["^qz_.+"], {"qz_abc": "xyz", "qz_def": "123", "qz_": "abc"}) == ["qz_abc", "qz_def"]



# Generated at 2022-06-21 07:02:33.923004
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:02:34.606182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 07:02:44.817288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-21 07:02:55.843620
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)


# Generated at 2022-06-21 07:03:02.316318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock data and logic to test run method
    terms = ['^qz_.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected_result = ['qz_1', 'qz_2']
    # lookup module object
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == expected_result

# Generated at 2022-06-21 07:03:03.613422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:03:11.962652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	# Mock variables
	class MockVariables(dict):
		pass

	variables = MockVariables()
	variables['ansible_check_mode'] = True
	variables['ansible_diff_mode'] = True
	variables['ansible_play_hosts'] = ['localhost']
	variables['ansible_play_hosts_all'] = ['localhost']
	variables['ansible_play_batch'] = 10
	variables['ansible_play_hosts_count'] = 1
	variables['ansible_play_hosts_count'] = 1
	variables['ansible_play_hosts_remaining'] = 0
	variables['ansible_play_task'] = 'task name'
	variables['ansible_play_role'] = 'role name'

# Generated at 2022-06-21 07:03:21.288448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["^qz_.+", "hosts", ".+_zone$", ".+_location$"]
    variables = {"qz_1": "hello", "qz_2": "world", "qa_1": "I won't show", "qz_": "I won't show either", "some_hosts": "I'm another variable", "some_zone": "I'm another variable", "some_location": "I'm another variable"}

    ret = lookup_module.run(terms, variables=variables)

    assert ret[0] == 'qz_1'
    assert ret[1] == 'qz_2'
    assert ret[2] == 'qa_1'
    assert ret[3] == 'some_hosts'

# Generated at 2022-06-21 07:03:28.500436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_dict = {
        'test_var_1': 'val1',
        'test_var_2': 'val2',
        'test_vars': 'val3'
    }

    test_terms = [
        'test_var_1',
        'test_var_2',
        'test_vars'
    ]

    LookupModule(test_terms, variables=test_dict)

# Generated at 2022-06-21 07:03:38.390462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test term = list, variables = dict(str:str)
    assert module.run(["^qz_.+"], {'qz_1':"hello",'qz_2':"world"}) == ['qz_1', 'qz_2']
    # Test term = str, variables = dict(str:str), negative
    assert module.run(["^bad_regex"], {'qz_1': "hello", 'qz_2': "world"}) == []

# Generated at 2022-06-21 07:03:51.110755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   oLookupModule = LookupModule()
   ret = oLookupModule.run(['^qz_.+'], { 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
   assert ret == ['qz_1', 'qz_2']
   ret = oLookupModule.run(['.+'], { 'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})
   assert ret == ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-21 07:04:01.855505
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test when no variables are available
    lookup = LookupModule()
    try:
        lookup.run(terms=['test'])
        assert False
    except AnsibleError:
        assert True

    # Test when term is not a string
    try:
        lookup.run(terms=[1])
        assert False
    except AnsibleError:
        assert True

    # Test when invalid regex is provided
    try:
        lookup.run(terms=['*'])
        assert False
    except AnsibleError:
        assert True

    # Test when there are no variables that match
    assert lookup.run(terms=['^missing_var$']) == []

    # Test when 'hello' is a variable
    request = []
    variables = { 'hello': 'hello' }

# Generated at 2022-06-21 07:04:12.025269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''

    lookupplugin = LookupModule()

    terms = ['^qz_.+', '.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I wont show', 'qz_': 'I wont show either'}

    assert lookupplugin.run(terms=terms, variables=variables) == ['qz_1', 'qz_2', 'qz_', 'qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-21 07:04:33.157038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Function to test the LookupModule constructor.
    """
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:04:44.822388
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['^qz_.+', 'hosts', '.+_zone$', '.+_location$']

    variables = {
        'qz_1': 1,
        'qz_2': 2,
        'qa_1': 1,
        'qz_': 1,
        'hosts': '',
        'hosts_zone': '',
        'hosts_location': '',
        'cookie_zone': '',
        'cookie_location': ''
    }

    l = LookupModule()
    result = l.run(terms, variables=variables)
    assert result == ['qz_1', 'qz_2', 'hosts', 'hosts_zone', 'hosts_location', 'cookie_zone', 'cookie_location']


# Generated at 2022-06-21 07:04:48.910858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a new instance of LookupModule named testlookup
    testlookup = LookupModule()
    assert testlookup != None, 'LookupModule instancation failed'

# Generated at 2022-06-21 07:04:50.633022
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), object)

# Generated at 2022-06-21 07:04:56.874253
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    var = {"q_z1": "hello", "q_z2": "world", "q2": "hi", "q3": "bye", "q4": "hola"}
    ret = lookup.run(['q_z.+', 'q.+'], var)
    assert(sorted(ret) == ['q2', 'q3', 'q4', 'q_z1', 'q_z2'])

    ret = lookup.run(['q\\d+'], var)
    assert(sorted(ret) == ['q2', 'q3', 'q4'])

    ret = lookup.run(['q\\d+', 'q_z.+'], var)

# Generated at 2022-06-21 07:05:06.343885
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Build test data
    x = {}
    x['qz_1'] = 'hello'
    x['qz_2'] = 'world'
    x['qa_1'] = "I won't show"
    x['qz_'] = "I won't show either"

    # Test 1
    t1 = LookupModule()
    ret = t1.run(['^qz_.+'], variables=x)
    assert len(ret) == 2
    assert 'qz_1' in ret
    assert 'qz_2' in ret

    # Test 2
    t2 = LookupModule()
    ret = t2.run(['.+'], variables=x)
    assert len(ret) == 4
    assert 'qz_1' in ret
    assert 'qz_2' in ret

# Generated at 2022-06-21 07:05:16.332154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    varnames = {"1": "", "2": "", "3": ""}
    # run with terms = None will raise AnsibleError
    try:
        module.run(None, varnames)
    except AnsibleError as err:
        assert str(err) == 'Unsupported parameters for varnames lookup plugin: ansible_module_generated_var_name'
    else:
        raise AssertionError('AnsibleError was not raised')

    # run with terms = "abcd" will raise AnsibleError
    try:
        module.run("abcd", varnames)
    except AnsibleError as err:
        assert str(err) == 'Invalid setting identifier, "abcd" is not a string, it is a <class \'str\'>'

# Generated at 2022-06-21 07:05:17.404651
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()
    assert my_lookup_module is not None

# Generated at 2022-06-21 07:05:18.888971
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Unit test - testing run function of class LookupModule 

# Generated at 2022-06-21 07:05:27.125273
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    terms = ['^qz_.+']
    result = LookupModule().run(terms, variables=variables)
    assert result == ['qz_1', 'qz_2']


    terms = ['.+']
    result = LookupModule().run(terms, variables=variables)
    assert result == list(variables.keys())


    terms = ['hosts']
    result = LookupModule().run(terms, variables=variables)
    assert result == []


    terms = ['.+_zone$', '.+_location$']

# Generated at 2022-06-21 07:06:14.305022
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    

# Generated at 2022-06-21 07:06:16.916872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, {})

# Generated at 2022-06-21 07:06:21.446566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_var = LookupModule()
        assert(lookup_var.run([], variables={'sample_variable' : 44}))
    except Exception as e:
        assert('should not raise exception')

# Generated at 2022-06-21 07:06:23.605228
# Unit test for constructor of class LookupModule
def test_LookupModule():
   mod = LookupModule()
   mod.run(terms=["name"])

# Generated at 2022-06-21 07:06:24.750388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 07:06:27.686012
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    lookup = LookupModule()
    terms = '.*'
    variables = os.environ
    lookup.run(terms, variables)

# Generated at 2022-06-21 07:06:39.458659
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test without any variables
    lm = LookupModule()
    assert lm.run(['^qz_.+']) == []

    # Test with wrong variable
    lm = LookupModule()
    assert lm.run(['^qz_.+'], variables={}) == []

    # Test with variables
    lm = LookupModule()
    assert lm.run(['^qz_.+'], variables={'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"}) \
            == ['qz_1', 'qz_2']

    # Test with wrong regex
    lm = LookupModule()

# Generated at 2022-06-21 07:06:47.587856
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check function run when no variables
    lookup_module = LookupModule()

    try:
        lookup_module.run(terms=['^qz_.+'])
        assert False
    except AnsibleError as e:
        assert str(e) == r'No variables available to search'

    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Check function run when variables is not None
    ret = lookup_module.run(terms=['^qz_.+'], variables=variables)
    assert isinstance(ret, list)
    assert ret == ['qz_1', 'qz_2']

    # Check function run when term is not a String

# Generated at 2022-06-21 07:06:49.115566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:07:00.693124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variables = {
        "workspace": "/home/user/Documents/Coding/Python/Code/Ansible/",
        "workspace2": "/home/user/Documents/Coding/Python/Code/Ansible/",
        "region": "us-east-1",
        "region2": "us-east-1",
        "region3": "us-east-1",
        "iam_profile": "foo",
        "iam_profile2": "foo",
        "foo": "bar"
    }
    lookup_mod = LookupModule()
    ret = lookup_mod.run(['^workspace.*$'], variables)
    assert ret == ["workspace", "workspace2"]
    ret = lookup_mod.run(['^region.*$'], variables)