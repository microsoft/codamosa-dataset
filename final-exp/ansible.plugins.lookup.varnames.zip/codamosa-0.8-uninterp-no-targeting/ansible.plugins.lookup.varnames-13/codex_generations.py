

# Generated at 2022-06-21 06:58:35.831732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm
    lookup_params = {
        '_terms': ['.+_zone$', '.+_location$']
    }

# Generated at 2022-06-21 06:58:43.375827
# Unit test for constructor of class LookupModule
def test_LookupModule():
    
    var_options = {'test1' : 'hello', 'test2' : 'world'}
    direct = {'test' : 'test'}

    lookup = LookupModule()
    lookup.set_options(var_options=var_options, direct=direct)
    
    assert(lookup.get_options() == (var_options, direct))


# Generated at 2022-06-21 06:58:51.767025
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Construct a class object for testing
    lookup = LookupModule()
    # Construct a terms simulating the return of the Ansible command
    terms = ['^qz_.+']
    # Construct variables simulating the return of Ansible command
    variables = {'qz_1':'hello','qz_2':'world','qa_1':"I won't show",'qz_':"I won't show either"}

    # Call the run method of class LookupModule to get the return value
    ret = lookup.run(terms, variables)
    # Verify that terms input is correct
    assert terms == ['^qz_.+']
    # Verify that variables input is correct

# Generated at 2022-06-21 06:58:52.614915
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:58:53.448547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:59:01.094688
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={"foo": "bar"}, direct={})

    # Check that the constructor returns a valid object
    assert(lookup_plugin is not None)

    # Check that the run method returns a list of variables
    assert(lookup_plugin.run(terms=['jr_test'], variables=variable_manager._vars) == ['jr_test'])

# Generated at 2022-06-21 06:59:12.237628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create class object
    lm = LookupModule()

    # Check that constructor returns expected object type
    assert isinstance(lm, LookupModule)

    # Check that object is initialized as expected
    assert lm.get_options()['var_options'] == {}
    assert lm.get_options()['direct'] == {}

    # Check that config can be changed
    lm.set_options(var_options={'key1':'value1'}, direct={'key2':'value2'})
    assert lm.get_options()['var_options'] == {'key1':'value1'}
    assert lm.get_options()['direct'] == {'key2':'value2'}

    # Check that we cannot set non-string search parameters

# Generated at 2022-06-21 06:59:14.852925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # validate setting of special attributes
    assert lookup_plugin._options is None

# Generated at 2022-06-21 06:59:27.789617
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLookupModule(LookupModule):

        class MockArgs(object):

            def __init__(self, module_name, lookup_plugin_name, terms, variables, return_value):
                self.module_name = module_name
                self.lookup_plugin_name = lookup_plugin_name
                self.terms = terms
                self.variables = variables
                self.return_value = return_value
                self.fail_on_undefined_lookup = False

        def __init__(self, **kwargs):
            self.set_options(var_options=kwargs['variables'], direct=kwargs)

        def run(self, terms, variables=None, **kwargs):
            self.set_options(var_options=kwargs['variables'], direct=kwargs)

            args = TestLookup

# Generated at 2022-06-21 06:59:39.383436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert(l.run(['qz_.+$'], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': 'I will not be a match', 'qz_': 'I will not be a match either'}) == ['qz_1', 'qz_2'])
    assert(l.run(['.+'], {'qz_1': 'hello', 'qz_2': 'world'}) == ['qz_1', 'qz_2'])
    assert(l.run(['hosts'], {'hosts': 'hello', 'hosts_file': 'world'}) == ['hosts'])

# Generated at 2022-06-21 06:59:50.895048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run([
        '^qz_.+',
        '.+',
        'hosts',
        '.+_zone$',
        '.+_location$',
    ], {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'foo_zone': 'US-East',
        'bar_location': 'NYC',
    })

# Generated at 2022-06-21 06:59:52.372488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:00:01.341512
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Dummy(object):
        def __init__(self, vars_dict):
            self._result = {'changed': False, 'ansible_vars': vars_dict}

    # Unit test: No variables
    ctx = {'lookup_plugin': LookupModule()}
    assert ctx['lookup_plugin']._fail_without_lookup_plugin_reports_enabled() is False

    if ctx['lookup_plugin'].run(terms=[], variables=None, **kwargs) is not None:
        assert False

    # Unit test: invalid term
    if ctx['lookup_plugin'].run(terms=[1234], variables={}, **kwargs) is not None:
        assert False

    # Unit test: invalid regex

# Generated at 2022-06-21 07:00:10.860633
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    assert module.run([ 'ansible_host' ], {}) == [], 'Nothing should be returned when there are no variables'
    assert module.run([ 'ansible_host' ], { 'ansible_host': 'localhost' }) == [ 'ansible_host' ], 'ansible_host should be returned when there is a single variable'
    assert module.run([ 'ansible_host' ], { 'ansible_host': 'localhost', 'ansible_connection': 'local' }) == [ 'ansible_host' ], 'ansible_host should be returned when there are two variables'

# Generated at 2022-06-21 07:00:18.059726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    options = None
    loader = None
    inventories = None
    variable_manager = None
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='test lookup plugin')))
            ]
        )

# Generated at 2022-06-21 07:00:19.708267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None


# Generated at 2022-06-21 07:00:27.898861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ut_terms = ["^qz_.+", "hosts", ".+"]
    ut_vars = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either",
        "hosts": "some value",
        "a_1_hosts": "show me"
    }
    expected_value = [
        ["qz_1", "qz_2"],
        ["hosts", "a_1_hosts"],
        ["qz_1", "qz_2", "qa_1", "qz_", "hosts", "a_1_hosts"]
    ]
    ret_value = []
    lm = LookupModule()

# Generated at 2022-06-21 07:00:30.498646
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:00:38.113887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        # This should pass because a config_options is provided
        testmod = LookupModule()
        # This should fail because no config_options is provided
        testmod = LookupModule(config_options={})
        assert True == False, \
            "The constructor should have thrown an error"
    except AnsibleError as e:
        assert "No variables available to search" in str(e), \
            "Unexpected Exception text"

# Generated at 2022-06-21 07:00:42.259330
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lu = LookupModule()
    assert hasattr(lu, 'set_options')
    assert hasattr(lu, 'run')

# Generated at 2022-06-21 07:00:47.996844
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # We don't need to do anything. If this function runs, we can assume the constructor is working.
    return

# Generated at 2022-06-21 07:00:54.894556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib

    # Set up a simple vault object
    vault = VaultLib([])

    vars = {
        "qz_1": "hello",
        "qz_2": "world",
        "qa_1": "I won't show",
        "qz_": "I won't show either"
    }

    terms = [
        '^qz_.+'
    ]

    vars = vault.decrypt(vars)

    l = LookupModule()
    results = l.run(terms=terms, variables=vars)
    assert(results == ["qz_1", "qz_2"])

# Generated at 2022-06-21 07:00:58.352822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 07:01:01.681319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print("Exception: %s" % e)
        assert False

# Generated at 2022-06-21 07:01:09.674885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    options = namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    options = options(connection='local', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)

    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}

    # create inventory, use path to host conf file as source

# Generated at 2022-06-21 07:01:12.105375
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    lookup.set_options(direct={'_terms': ['^qz_.+']})
    assert lookup._terms == ['^qz_.+']

# Generated at 2022-06-21 07:01:15.752062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert hasattr(l, 'run')
    assert hasattr(l, 'set_options')

# Generated at 2022-06-21 07:01:18.303351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module._terms == None

# Generated at 2022-06-21 07:01:30.284645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with no terms
    lm = LookupModule()
    ret = lm.run(terms=[], variables={'abc': 'abc'})
    assert ret == []

    # Test with no matches
    ret = lm.run(terms=['txt'], variables={'abc': 'abc'})
    assert ret == []

    # Test with one match
    ret = lm.run(terms=['a.'], variables={'abc': 'abc'})
    assert ret == ['abc']

    # Test with multiple matches
    ret = lm.run(terms=['.b.'], variables={'abc': 'abc', 'xyz': 'xyz', 'zbc': 'zbc'})
    assert sorted(ret) == ['abc', 'zbc']

    # Test with several terms

# Generated at 2022-06-21 07:01:31.985936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-21 07:01:52.344045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test to check if method run of class LookupModule returns the expected values
    '''

    # Mock the options and variables
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    templar = Templar(loader=DataLoader())
    mOptions = {}
    mVariables = {}
    mVariables['one'] = 1
    mVariables['two'] = 2
    mVariables['five'] = 5
    mVariables['ten'] = 10

    # Set the options and variables
    obj = LookupModule()
    obj.set_options(var_options=mVariables, direct=mOptions)

    # Get the required values
    assert obj.run('one',variables = mVariables) == ['one']

# Generated at 2022-06-21 07:02:04.200724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    # Mock needed builtins
    builtins_save = {}
    for name in dir(builtins):
        if name.startswith('__') and name.endswith('__'):
            continue
        builtins_save[name] = getattr(builtins, name)
        setattr(builtins, name, lambda *args, **kwargs: None)

    import ansible.module_utils._text as text
    import ansible.module_utils.six as six
    def mock_text_to_native(*args, **kwargs):
        return 'text_to_native'
    text.to_native = mock_text_to_native

# Generated at 2022-06-21 07:02:05.475779
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert hasattr(lookup_instance, 'run')

# Generated at 2022-06-21 07:02:15.358475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # if variables is None, then raise AnsibleError
    try:
        module.run([], None)
        assert False
    except AnsibleError:
        assert True

    # if term is not string type, then raise AnsibleError.
    # if term is not regex, then raise AnsibleError.
    try:
        module.run([[]], {'key1': 'xxx', 'key2': 'yyy'})
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-21 07:02:25.241958
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    # Case when variables is None
    try:
        lm.run(terms=["regex"], variables=None)
        assert False
    except AnsibleError as e:
        assert ("No variables available to search" in str(e))

    # Case when reusable variables is not present
    try:
        lm.run(terms=["regex"], variables={"foo": "bar"})
        assert False
    except AnsibleError as e:
        assert ("no such option" in str(e))

    # Case when terms is not a string
    try:
        lm.run(terms=[1], variables={"foo": "bar"})
        assert False
    except AnsibleError as e:
        assert ("not a string" in str(e))

    # Case when terms is not a valid search parameter

# Generated at 2022-06-21 07:02:26.518744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-21 07:02:32.641400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    input_vars = {'qz_1': 'hello', 'qz_12': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    result = lookup_module.run(terms=['^qz_.+'], variables=input_vars)
    assert result == ['qz_1', 'qz_12'], 'Unexpected result %s' % result

# Generated at 2022-06-21 07:02:43.614683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    # test_LookupModule_run: test case 1
    assert lu.run(terms=['^qz_.+'], variables={'qz_1':'hello', 'qz_2':'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2']
    # test_LookupModule_run: test case 2
    assert lu.run(terms=['.+'], variables={'qz_1':'hello', 'qz_2':'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}) == ['qz_1', 'qz_2', 'qa_1', 'qz_']
    # test_Lookup

# Generated at 2022-06-21 07:02:44.879858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # TO DO: Add test cases
    return lookup_module

# Generated at 2022-06-21 07:02:46.026238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing _lookup_plugin.LookupModule...')
    assert(LookupModule)

# Generated at 2022-06-21 07:03:19.534864
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ###########################################################################
    # Init the object
    ###########################################################################
    obj = LookupModule()


    ###########################################################################
    # Test a normal call
    ###########################################################################
    terms = '^qz_.+'
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    expected_return = ['qz_1', 'qz_2']
    assert list(obj.run(terms, variables)) == expected_return


    ###########################################################################
    # Test a failure
    ###########################################################################
    terms = '^qz_.+'
    variables = None

# Generated at 2022-06-21 07:03:31.335439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_ = LookupModule()

    # Check for correct return with empty terms
    assert(test_.run([], {'a': 'b'}) == [])

    assert(test_.run(["^a*.+"], {'ab': 'b', 'a': 'b', 'az': 'a'}) == ['ab', 'az'])

    # Check for correct return with empty variables
    try:
        test_.run(["^a*.+"], {})
    except AnsibleError as e:
        assert(to_native(e) == 'No variables available to search')
    else:
        assert(False)

    # Check for correct return with non-string type for terms

# Generated at 2022-06-21 07:03:34.055200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_class = LookupModule()
    assert my_class is not None

# Generated at 2022-06-21 07:03:43.109300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        ['^qz_.+'],
        {'qz_1':'hello', 'qz_2':'world', 'qa_1':'I won\'t show', 'qz_':'I won\'t show either'}
    )
    assert ret == ['qz_1', 'qz_2']

    ret = LookupModule().run(
        ['.+'],
        {'qz_1':'hello'}
    )
    assert ret == ['qz_1']

    ret = LookupModule().run(
        ['hosts'],
        {'hosts':'hosts', 'hosts_extra':'hosts'}
    )
    assert ret == ['hosts', 'hosts_extra']


# Generated at 2022-06-21 07:03:52.765912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('varnames')
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I won\'t show',
        'qz_': 'I won\'t show either',
    }

    # Check that list of variables starting with qz_ is returned
    assert lookup.run(['^qz_.+'], variables=variables) == ['qz_1', 'qz_2']

    # Check that all variables are returned
    assert lookup.run(['.+'], variables=variables) == ['qz_1', 'qz_2', 'qa_1', 'qz_']

    # Check that variables with 'hosts' in their names are returned
   

# Generated at 2022-06-21 07:03:54.554952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 07:03:56.170522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(isinstance(lookup_module, LookupModule))

# Generated at 2022-06-21 07:04:06.485285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    varnames_options = {
            '_terms': ['^qz_.+']
            }
    varnames_vars = {
            'qz_1': 'hello',
            'qz_2': 'world',
            'qa_1': "I won't show",
            'qz_': "I won't show either",
            '_z': "I won't show either"
            }
    varnames_plugin = LookupModule()
    varnames_plugin.set_options(var_options=varnames_vars, direct=varnames_options)
    assert varnames_plugin.run(terms=['^qz_.+'], variables=varnames_vars) == ['qz_1', 'qz_2', 'qa_1']


# Generated at 2022-06-21 07:04:12.502299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self, terms=None, variables=None, **kwargs):
            self.arguments = terms
            self.variables = variables

    lookup_module = TestLookupModule(['.*', '.+'], {'dummy': '1'})
    result = lookup_module.run(terms=['dummy_.*', 'dummy_.*'], variables={'dummy_1': '1', 'dummy_2': '2'})
    assert (result == ['dummy_1', 'dummy_2'])

# Generated at 2022-06-21 07:04:15.094312
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Test for run method
    lookup.run(['^qa_.+$'])

# Generated at 2022-06-21 07:05:13.709265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_object = LookupModule()

    test_terms = [
        "^qz_.+"
    ]

    test_vars = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either"
    }

    result = lookup_object.run(test_terms, test_vars)

    assert result == [
        "qz_1",
        "qz_2",
    ]

# Generated at 2022-06-21 07:05:15.858933
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:05:26.083769
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_instance = LookupModule()
    
    terms_valid = ['^qz_.+', '^qa_.+']
    ansible_vars = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}

    # Valid lookup module terms and matching ansible_vars
    result = lookup_module_instance.run(terms=terms_valid, variables=ansible_vars)
    assert len(result) == 2
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'qa_1' in result

    # Valid lookup module terms and no matching ansible_vars

# Generated at 2022-06-21 07:05:32.075844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    variables = { "a": 1, "b": 1, "c": 1, "d": 1 }
    assert lookup_module.run(terms=["a", "b"], variables=variables) == ['a', 'b']

# Generated at 2022-06-21 07:05:38.247938
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:05:46.251827
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from nose.tools import ok_

    class Object(object):
        def __init__(self):
            self.variables = {}
        def dump(self):
            return self.variables

    obj = Object()
    test_vars = dict(k1='v1', k2='v2')
    obj.variables = test_vars
    test_terms = '.*'

    obj_lookup = LookupModule()
    ok_(isinstance(obj_lookup, LookupModule))
    obj_lookup.set_options(var_options=obj.dump(), direct=None)
    result = obj_lookup.run(terms=test_terms)
    ok_(isinstance(result, list))
    ok_(set(test_vars.keys()) == set(result))

# Generated at 2022-06-21 07:05:51.759577
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import __main__
    global_vars = vars(__main__)
    lookup = LookupModule()
    lookup.run(terms=['^qz_.+'], variables = global_vars)
    lookup.run(terms=['^qz_.+'])

# Generated at 2022-06-21 07:05:53.782132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """validate the basic constructor of LookupModule
    """
    module = LookupModule()
    assert module

# Generated at 2022-06-21 07:06:08.165201
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with an empty term
    lookup_module = LookupModule()
    var_empty = {}
    test_data = []
    expected = []
    assert lookup_module.run(test_data, variables=var_empty) == expected

    # Test with an item in term
    lookup_module = LookupModule()
    var_one_item_beginning_match = {'test_1': 'value1', 'test_2': 'value2'}
    test_data = ['^test_.+']
    expected = ['test_1', 'test_2']
    assert lookup_module.run(test_data, variables=var_one_item_beginning_match) == expected

    # Test with more items in term
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:06:09.628138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    raise NotImplementedError(__name__)

# Generated at 2022-06-21 07:08:01.895451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    lookup = LookupModule()
    variables = {'qz_variable_1': 'hello', 'qz_variable_2': 'world', 'qa_variable': 'I won\'t show', 'qz_':'I won\'t show either'}

    # When
    result = lookup.run(terms=['^qz_.+'], variables=variables)

    # Then
    assert result == ['qz_variable_1', 'qz_variable_2']



# Generated at 2022-06-21 07:08:06.877323
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 07:08:07.956589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-21 07:08:14.011331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_options = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I wont show',
    }

    terms = [
        '^qz_.+',
        'hello',
        '.+',
    ]

    vars_options = [(k, v) for k, v in var_options.items()]
    lookups = LookupModule()
    ret = lookups.run(terms, var_options)
    assert isinstance(ret, list), 'run() should return a list of varnames'
    assert len(ret) == 2, 'run() should return only the matching vars'
    assert set(ret) == set(['qz_1', 'qz_2']), 'run() should return a list of matchin vars'

#

# Generated at 2022-06-21 07:08:25.850434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)