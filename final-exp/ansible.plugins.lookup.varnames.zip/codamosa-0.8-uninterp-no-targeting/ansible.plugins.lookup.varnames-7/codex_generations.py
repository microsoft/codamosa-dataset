

# Generated at 2022-06-21 06:58:37.264502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_of_module_returns = [
        [u'test_variable'],
        [u'test_variable'],
        [u'test_hosts'],
        [u'var_zone', u'var_location'],
        [u'test_varname1', u'test_varname2'],
        [u'test_varname1', u'test_varname2', u'test_varname3'],
        [u'test_varname2', u'test_varname3', u'test_varname3'],
        [u'test_varname1', u'test_varname2', u'test_varname3', u'test_varname3']
        ]

# Generated at 2022-06-21 06:58:40.527784
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # A simple test
    import ansible.plugins.lookup.varnames
    lookup = ansible.plugins.lookup.varnames.LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:58:47.938064
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test basic case, just find one variable in the list
    terms = ['^qz_.+']
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
    }
    lookup = LookupModule()
    result = lookup.run(terms, variables)
    assert len(result) == 2
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'qa_1' not in result
    assert 'qz_' not in result

    # Test empty case
    terms = ['.+']
    variables = {}
    lookup = LookupModule()
    result = lookup.run(terms, variables)

# Generated at 2022-06-21 06:58:55.459086
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = ['^qz_.+', '.+']
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    lm.run(terms, variables)

# Generated at 2022-06-21 06:59:01.916509
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_var = LookupModule()
    test_terms = [u'^qa_.+', u'.+_zone$', u'.+_location$']
    test_variables = dict(qa_1=u'hello', qa_2=u'world', qb_zone=u'zone B', qb_location=u'location B')
    test_result = lookup_var.run(terms=test_terms, variables=test_variables)
    assert test_result == ['qa_1', 'qa_2', 'qb_zone', 'qb_location']

# Generated at 2022-06-21 06:59:02.762147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:59:13.066687
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with null variables
    class TestLookupModule(LookupModule):
        def __init__(self):
            super(TestLookupModule, self).set_options(var_options = {}, direct = {})

    t = TestLookupModule()
    try:
        t.run(['abc'])
        assert(False)
    except AnsibleError:
        assert(True)

    # Setup the variables
    variables = { 'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5 }

    # Test with a valid regex and one that matches
    t.set_options(var_options = variables)
    assert(t.run(['a']) == ['a'])

    # Test with a valid regex and one that doesn't match

# Generated at 2022-06-21 06:59:23.119727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.test.test_lookup import TestLookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    dl = DataLoader()
    vm = VariableManager()
    var_name = 'varname'
    var_value = 'varvalue'
    terms = var_name
    vm.set_variable(var_name, var_value)
    lookup_obj = LookupModule()
    results = lookup_obj.run(terms, vm.get_vars(), **{})

    assert results == [var_name]

# Generated at 2022-06-21 06:59:26.656435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupBase)

# Generated at 2022-06-21 06:59:29.066886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ test constructor """

    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:59:41.922521
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule()

    # Test that without variables, it raises an error
    with pytest.raises(AnsibleError):
        m.run(terms=['test'])

    variables = {'test': 'test'}
    m.set_options(var_options=variables, direct={})

    # Test that we can retrieve the test variable
    ret = m.run(terms=['test'])
    assert ret == ['test']

    # Test that we can use a regex to retrieve the test
    ret = m.run(terms=['.*'])
    assert ret == ['test']

    # Test that we can use a regex to retrieve the test
    ret = m.run(terms=['te'])
    assert ret == ['test']

    # Test that we can use a regex to retrieve the test
    ret = m

# Generated at 2022-06-21 06:59:46.103015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables
    terms = ['^qz_.+',".+_zone$", ".+_location$"]
    variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either", 'qz_3_zone':'zone_3', 'qz_3_location':'location_3'}

    lkm = LookupModule()
    ret = lkm.run(terms, variables)
    assert ret == ['qz_1', 'qz_2', 'qz_3_location', 'qz_3_zone']



# Generated at 2022-06-21 06:59:59.178815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase

    obj = LookupModule()
    assert isinstance(obj, LookupBase)
    assert type(obj) == LookupModule
    assert 'lookup_plugin.varnames' in str(obj)
    assert 'Ansible Core Team' in str(obj)
    assert 'Retrieves a list of matching Ansible variable names.' in str(obj)
    assert "'_terms', required=True" in str(obj)
    assert '_terms' == obj._options['_terms']['required']
    assert 'vars' == obj._options['_terms']['aliases']
    assert "'_terms': {'description': " in str(obj)

# Generated at 2022-06-21 07:00:12.145260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.varnames import LookupModule
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    fake_variables = {'hello': 'world', 'foo': 'bar', 'x_y': 'test'}

    # Test single search term
    actual = LookupModule().run(('^hello$',), fake_variables)
    assert actual == ['hello']

    # Test multiple search terms
    actual = LookupModule().run(('^hello$', '^foo$'), fake_variables)
    assert actual == ['hello', 'foo']

    # Test no search terms
    # NOTE: lookup_plugins will prevent this, but we'll test anyway
    actual = LookupModule

# Generated at 2022-06-21 07:00:23.587092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.set_options({'var_options': {'qz1': 'hello', 'qz2': 'world', 'qa1': 'I wont show', 'qz': 'I wont show either'}})

    try:
        lm.run([])
        assert False
    except AnsibleError as e:
        assert str(e) == 'Insufficient arguments provided'

    terms = ['^qz_.+']
    results = lm.run(terms)
    expected_results = ['qz1', 'qz2']
    assert results == expected_results

    terms = ['.+']
    results = lm.run(terms)
    expected_results = ['qz1', 'qz2', 'qa1', 'qz']
    assert results == expected_results

    terms

# Generated at 2022-06-21 07:00:32.295804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1: Run the run method with variables that contain keys that matches the terms
    varnames_test = LookupModule()
    variables = {}
    variables['current_matching_var'] = "value"
    variables['other_matching_var'] = "value"
    variables['non_matching_var'] = "value"
    terms = ['current_matching_var', '^other.*', '^non_matching_.*']
    assert varnames_test.run(terms, variables) == ['current_matching_var', 'other_matching_var']
    
    # Test 2: Run the run method with variables that don't contain keys that matches the terms
    varnames_test = LookupModule()
    variables = {}
    variables['current_matching_var'] = "value"

# Generated at 2022-06-21 07:00:34.899248
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.set_options == LookupModule.set_options

# Generated at 2022-06-21 07:00:42.668601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_module = "{\"_ansible_module_name\": \"mock\", \"_ansible_no_log\": false, \"_ansible_module_post_processors\": {\"inventory\": {\"_ansible_module_builtin\": true, \"_ansible_module_name\": \"inventory\"}}, \"_ansible_module_generated\": true, \"_ansible_module_compressor\": \"none\", \"_ansible_module_version\": \"v2.8.7.0\"}"
    test_terms = ['test']
    test_variables = {"test": "test"}
    test_options = {'var_options': test_variables, 'direct': {"test": "test"}}
    LM = LookupModule()
    LM.set_options(test_options)
    assert LM.get_options() == test_options

# Generated at 2022-06-21 07:00:44.706372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert(lu is not None)

# Generated at 2022-06-21 07:00:49.134663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    ret = l.run(['^qz_.+'], {'qz_1':'hello', 'qz_2':'world'})
    assert ret == ['qz_1', 'qz_2']

# Generated at 2022-06-21 07:01:03.626686
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    variables = {'var1': 'This is test', 'var2': 'Test this', 'var3': 'This is'}

    # Empty terms
    terms = []

    res = LookupModule().run(terms, variables)
    assert res == []

    # No match
    terms = ['.+_var2$']
    res = LookupModule().run(terms, variables)
    assert res == []

    # Match
    terms = ['.+_var1$']
    res = LookupModule().run(terms, variables)
    assert res == ['var1']

    # Multiple matches
    terms = ['.+_var1$', '.+_var2$']
    res = LookupModule().run(terms, variables)
    assert sorted(res) == ['var1', 'var2']

    # Multiple matches in a single term

# Generated at 2022-06-21 07:01:16.168225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([]) == []
    assert LookupModule().run(["abc"]) == []
    assert LookupModule().run(["abc"], variables=None) != []
    assert LookupModule().run(["abc"], variables={"abc": 1}) == ["abc"]
    assert LookupModule().run(["^a"], variables={"abc": 1}) == ["abc"]
    assert LookupModule().run(["^ab"], variables={"abc": 1}) == ["abc"]
    assert LookupModule().run(["^abc"], variables={"abc": 1}) == ["abc"]
    assert LookupModule().run(["^o"], variables={"abc": 1}) == []
    assert LookupModule().run(["^o"], variables={"abc": 1, "def": 2}) == ["def"]

# Generated at 2022-06-21 07:01:18.740871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Return true if successful"""
    class_object = LookupModule()
    return True

# Generated at 2022-06-21 07:01:25.356250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj.set_options == LookupBase.set_options
    assert obj.run == LookupBase.run
    assert obj.get_basedir == LookupBase.get_basedir
    assert obj.get_vars == LookupBase.get_vars

# Generated at 2022-06-21 07:01:32.683078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys
    import ansible.utils.module_docs_fragments
    lookup = LookupModule()
    term = '^qz_.+'
    variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': 'I will not show', 
        'qz_': 'I will not show either'
    }
    result = lookup.run(terms=[term],variables=variables)
    assert(result == ['qz_1', 'qz_2'])

    term = '.+'
    result = lookup.run(terms=[term],variables=variables)
    assert(result == [
        'qz_1', 'qz_2', 'qa_1', 'qz_'
    ])


# Generated at 2022-06-21 07:01:37.073897
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()

    # unit test: _terms required
    try:
        lookup_plugin.run([])
        assert False
    except AnsibleError as e:
        assert "No variables available to search" in to_native(e)

    # unit test: non-string member of _terms raises exception
    try:
        lookup_plugin.run([1], {"a": 2}, direct={"_terms": {"a": 3}})
        assert False
    except AnsibleError as e:
        assert "Invalid setting identifier, \"1\" is not a string, it is a <class 'int'>" in to_native(e)

    # unit test: bad regex raises exception

# Generated at 2022-06-21 07:01:38.601903
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 07:01:40.806217
# Unit test for constructor of class LookupModule
def test_LookupModule():
    fw = LookupModule()
    assert fw

# Generated at 2022-06-21 07:01:42.688777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 07:01:52.056419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['abc', 'xyz']
    variables = {'abc_1': 'a', 'abc_2': 'b', 'abc_3': 'c', 'xyz_1': 'w', 'demo': 'demo'}
    ret = run_test(terms, variables)
    assert len(ret) == 4
    assert 'abc_1' in ret
    assert 'abc_2' in ret
    assert 'abc_3' in ret
    assert 'xyz_1' in ret
    assert 'demo' not in ret

    terms = ['abc$', 'xyz$']
    variables = {'abc_1': 'a', 'abc_2': 'b', 'abc_3': 'c', 'xyz_1': 'w', 'demo': 'demo', '1xyz': 'x'}
   

# Generated at 2022-06-21 07:02:13.211877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import unittest
    except ImportError:
        unittest = None

    if unittest is not None:
        class TestLookupModule_run(unittest.TestCase):
            def setUp(self):
                self.varnames = LookupModule()

            def test_run_success(self):
                term1 = "start_with_qz_"
                term2 = "^qz_.+"
                term3 = "hosts"
                term4 = "end_zone"
                term5 = "end_location"
                terms = [term1, term2, term3, term4, term5]
                variables = {}
                variables["qz_1"] = "hello"
                variables["qz_2"] = "world"

# Generated at 2022-06-21 07:02:14.992205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert callable(lookup)

# Generated at 2022-06-21 07:02:25.015876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.run(terms=['test'])

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.run(terms=['test'], variables={})

    with pytest.raises(AnsibleError):
        lm = LookupModule()
        lm.run(terms=['test'], variables={'test_1': '1', 'test_2': '2'})

    # test case:
    #  input:     terms is list of variables, variables is dictionary with matching variables
    #  expected:  list of variables
    lm = LookupModule()

# Generated at 2022-06-21 07:02:27.469812
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass
#    my_look = LookupModule()
#    assert my_look != None


# Generated at 2022-06-21 07:02:33.522436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # lookups are singletons and state is carried over:
    # so we need to reset it for each test
    Checker = LookupModule()

    # Test blank
    Checker.run([''], None)

    # Test no variables
    Checker.run(['^qz_.+'], {})

    # Test not a string
    Checker.run([[], "hello"], {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"})

# Generated at 2022-06-21 07:02:34.637417
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert(module is not None)

# Generated at 2022-06-21 07:02:35.552288
# Unit test for constructor of class LookupModule
def test_LookupModule():
	lm = LookupModule()
	assert lm is not None


# Generated at 2022-06-21 07:02:40.643563
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # Checks that the module returns a dictionary
  test_terms = ('var', 'var2')
  test_var = {'var':'1', 'var2':'2', 'var3':'3'}
  assert type(LookupModule.run(None, test_terms, variables=test_var)) is list


# Generated at 2022-06-21 07:02:43.030437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 07:02:47.909095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m_terms = ['^qz_.+', '.+']
    m_variables = {'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"}
    expected = ['qz_1', 'qz_2', 'qa_1', 'qz_']
    ret = LookupModule().run(
        terms=m_terms,
        variables=m_variables,
    )
    assert ret == expected

# Generated at 2022-06-21 07:03:12.292560
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.run([])

# Generated at 2022-06-21 07:03:19.917767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    host_var = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        'no_match': 'one',
        'no_match_1': 'two',
    }
    results = lookup_plugin.run([u'^qz_.+'], host_var)
    assert results == ['qz_1', 'qz_2', 'qz_']

# Generated at 2022-06-21 07:03:21.266724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()

# Generated at 2022-06-21 07:03:32.225132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Module initialization
    module = LookupModule()
    #Expected Result
    ret = ['qz_1', 'qz_2']
    #Test execution
    result = module.run(terms=['^qz_.+'], variables={'qa_1': 'I won\'t show', 'qz_1': 'hello', 'qz_2': 'world', 'qz_': 'I won\'t show either'})
    #Test assertions
    #assert len(result) == len(ret), "The number of items doesn't match"
    #assert set(result) == set(ret), "The lists differ"
    assert ret == result
    ret = ['qz_1', 'qz_2', 'qa_1', 'qz_']

# Generated at 2022-06-21 07:03:40.485126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    lookup = LookupModule()

    # When
    try:
        result = lookup.run(terms=['^a_.+', '^b_.+'], variables={'a_1': 'val1', 'a_2': 'val2', 'b_1': 'val3', 'c_1': 'val4'})
    # Then
    except Exception:
        assert False, 'Should not fail'

    assert (result == ['a_1', 'a_2', 'b_1']), 'Should match name in terms and variables'

# Generated at 2022-06-21 07:03:42.055041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run('hello') == []

# Generated at 2022-06-21 07:03:53.625885
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock of LookupBase class
    class Mock_LookupBase(object):
        def __init__(self):
            self.var_options = {'e': '5', 'a': '1', 'c': '3'}
            self.options = {}

        def set_options(self, var_options, direct):
            self.var_options = var_options
            self.options = direct

    lookup = Mock_LookupBase()
    lookup_instance = LookupModule()

    terms = ['a']
    assert lookup_instance.run(terms, variables=lookup.var_options) == ['a']

    terms = ['^e$']
    assert lookup_instance.run(terms, variables=lookup.var_options) == ['e']

    terms = ['.+']

# Generated at 2022-06-21 07:03:55.648542
# Unit test for constructor of class LookupModule
def test_LookupModule():
  import ansible.plugins.lookup as lookup
  l = lookup.LookupModule()

# Generated at 2022-06-21 07:04:06.055907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    filename = 'test_lookup_vars.yml'
    vars     = lookup_loader.get('vars', filename=filename)

    terms = ['^qz_']
    test_run = LookupModule(loader=lookup_loader, templar=templar).run(terms, variables=vars)
    assert test_run == ['qz_1', 'qz_2']

    terms = ['^q.']
    test_run = LookupModule(loader=lookup_loader, templar=templar).run(terms, variables=vars)
    assert test_run == ['qa_1', 'qz_1', 'qz_2']

    terms = ['^.a_']

# Generated at 2022-06-21 07:04:10.334983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    result = instance.run(["abc"], {"abc": 1, "xyz": 2, "123": 3})
    assert result == [ "abc" ]

# Generated at 2022-06-21 07:05:15.765876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupBase)
    lookup_obj.set_options(var_options=None, direct=None)
    try:
        lookup_obj.run(terms=["^qz_.+"])
    except AnsibleError:
        pass
    else:
        assert False

    lookup_obj.set_options(var_options={'qz_1': 'hello', 'qz_2': 'world', 'qa_1': "I won't show", 'qz_': "I won't show either"},
                           direct={})
    ret = lookup_obj.run(terms=["^qz_.+"])
    assert isinstance(ret, list)
    assert ret == ['qz_1', 'qz_2']

    ret = lookup_obj

# Generated at 2022-06-21 07:05:23.226162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()
    try:
        lookup_module_instance.run([], None) # Throws assertion error if it's not a list
    except AnsibleError as e:
        assert 'No variables available to search' in to_native(e)
    except Exception as e:
        assert False, 'Expected AnsibleError to be thrown, but instead got a {}'.format(type(e))

# Generated at 2022-06-21 07:05:29.467541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up mock vars, as we don't want to depend on the current contents of a variables dictionary.
    mock_variables = {
        'qz_1': 'hello',
        'qz_2': 'world',
        'qa_1': "I won't show",
        'qz_': "I won't show either",
        }

    # Test for match starting with specified pattern.
    lookup = LookupModule()
    terms = ['^qz_.+']
    result = lookup.run(terms, variables=mock_variables)
    assert 'qz_1' in result
    assert 'qz_2' in result
    assert 'qz_' not in result
    assert 'qa_1' not in result

    # Test for match of all variables
    lookup = LookupModule()

# Generated at 2022-06-21 07:05:33.167019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None)
    terms = ['test1', 'test2']
    lookup_module.run(terms, variables=None, direct=None)

# Generated at 2022-06-21 07:05:41.662004
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Define some test variables
    variables = dict(
        qz_1='hello',
        qz_2='world',
        qa_1='I won\'t show',
        qz_='I won\'t show either',
    )
    # When I call run method of LookupModule
    #   with a valid regex
    # I should get a list of matching variable names
    # Note: It is not possible as of yet to test for the variables with
    #       the same name as invalid regexes.
    assert LookupModule().run(('^qz_.+',), variables=variables) == ['qz_1', 'qz_2']

    # When I call run method of LookupModule
    #   with no regex
    # I should get an exception

# Generated at 2022-06-21 07:05:42.428644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 07:05:50.475544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test class LookupModule with method run"""

    # Test with variables, but no terms.
    lookup_module = LookupModule()
    terms = None
    variables = { "var_1": 31, "var_2": 42 }
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run(terms, variables)
    assert 'No variables available to search' in str(excinfo.value)

    # Test with empty settings.
    lookup_module = LookupModule()
    terms = ""
    variables = { "var_1": 31, "var_2": 42 }
    expected = []
    results = lookup_module.run(terms, variables)
    assert results == expected

    # Test with no variables.
    lookup_module = LookupModule()
    terms = "var_1"


# Generated at 2022-06-21 07:05:54.033276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = ['bad_regex_string']
    variables = {'varname_for_test': 'value'}
    assert lookup_obj.run(terms, variables) is None

# Generated at 2022-06-21 07:05:56.333824
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # True test atm
    assert True

# Generated at 2022-06-21 07:05:58.847502
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup
    assert lookup.run
    assert lookup.run_terms

# Generated at 2022-06-21 07:07:49.466848
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-21 07:08:01.707612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check the return values of the LookupModule class"""
    import pytest
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_native

    lu = LookupBase()
    # Test with two regular expressions to search for in the variable names
    def test_case(variable_names, regex_patterns, expected_output):
        lu.set_options(var_options=variable_names, direct=None)
        ret = lu.run(regex_patterns, variables=variable_names)
        assert len(ret) == len(expected_output)
        assert set(ret) == set(expected_output)
    # Test that inputs that are not strings or lists of strings raise an
    # AnsibleError exception

# Generated at 2022-06-21 07:08:06.513342
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-21 07:08:11.124538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader
    path = ansible.utils.path
    ansible.parsing.dataloader.DataLoader = lambda : 0
    ansible.utils.path = lambda x: 'path'
    lookup.run([])
    ansible.parsing.dataloader.DataLoader = loader
    ansible.utils.path = path
    print('LookupModule created.')

# Generated at 2022-06-21 07:08:23.564102
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # first use
    lookup_module = LookupModule()
    terms = {'terms':['^qz_.+']}
    variables = {
        'qa_1': 1,
        'qz_1': 2,
        'qz_': 1,
        'qz_2': 3
    }
    variables_with_default = {'var_options': variables, 'direct':{}}
    lookup_module.set_options(**variables_with_default)
    result = lookup_module.run(terms['terms'], variables, **variables_with_default)
    assert len(result) == 2
    assert 'qz_1' in result
    assert 'qz_2' in result

    # second use
    lookup_module = LookupModule()
    terms = {'terms':['.+']}
