

# Generated at 2022-06-18 07:07:39.228708
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _test_shell_logger(output):
        """Test shell logger."""
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:07:45.762408
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:07:58.498316
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        def _read_log(output):
            with open(output, 'rb') as f:
                return f.read()

        def _write_to_shell(input):
            os.write(pty.STDIN_FILENO, input)

        def _read_from_shell():
            return os.read(pty.STDOUT_FILENO, 1024)

        def _read_from_shell_until(expected):
            result = b''
            while True:
                result += _read_from_shell()
                if expected in result:
                    return result

        def _write_to_shell_and_read_until(input, expected):
            _write_to_shell(input)
            return _read_from_

# Generated at 2022-06-18 07:08:09.076113
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import sys
    import signal
    import mmap
    import array
    import fcntl
    import termios
    import tty
    import pty
    import os
    import time
    import subprocess
    import sys
    import signal
    import mmap
    import array
    import fcntl
    import termios
    import tty
    import pty
    import os
    import time
    import subprocess
    import sys
    import signal
    import mmap
    import array
    import fcntl
    import termios
    import tty
    import pty
    import os
    import time
    import subprocess
    import sys
    import signal
    import mmap
    import array
    import f

# Generated at 2022-06-18 07:08:20.181030
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def random_string_generator(length):
        while True:
            yield random_string(length)

    def test_shell_logger_with_size(size):
        with tempfile.NamedTemporaryFile() as f:
            p = subprocess.Popen(['python', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(f.name)], stdin=subprocess.PIPE)
            time.sleep(0.1)
            p.stdin.write(b'echo "')

# Generated at 2022-06-18 07:08:27.434496
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'log')
        process = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        time.sleep(1)
        process.send_signal(signal.SIGINT)
        process.wait()
        assert os.path.exists(output)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:08:33.562057
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        _test_shell_logger(output)
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:08:44.163946
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:08:51.649539
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:08:59.916739
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:09:16.274534
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)

    unittest.main()

# Generated at 2022-06-18 07:09:25.764608
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)
    # Create temporary file name
    temp_file_name = temp_file.name
    # Create temporary file name for output
    temp_file_name_output = temp_file_name + ".output"
    # Create temporary file name for output
    temp_file_name_output_2 = temp_file_name + ".output2"
    # Create temporary file name for output
    temp_file_name_output_3 = temp_file_name + ".output3"
    # Create temporary file name for output
    temp_file_name_output_4 = temp_file_

# Generated at 2022-06-18 07:09:31.102015
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')

    try:
        shell_logger(output)
    except SystemExit:
        pass

    with open(output, 'rb') as f:
        assert f.read()

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:09:42.410283
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')

    # Test that shell_logger works
    subprocess.call(['python', '-m', 'shell_logger', output])

    # Test that shell_logger writes to the file
    with open(output, 'rb') as f:
        assert f.read() != b'\x00' * const.LOG_SIZE_IN_BYTES

    # Test that shell_logger truncates the file
    time.sleep(1)
    subprocess.call(['python', '-m', 'shell_logger', output])

# Generated at 2022-06-18 07:09:50.441034
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)

    unittest.main()

# Generated at 2022-06-18 07:10:00.733726
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_env(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_with_env_and_shell(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_with_env_and_shell_and_pwd(output):
        os.environ['SHELL'] = '/bin/bash'
        os.environ['PWD'] = '/tmp'
        shell_logger(output)


# Generated at 2022-06-18 07:10:08.555345
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:10:20.361675
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = os.path.join(tmpdir, 'test.log')
    # Create temporary file with shell logger
    tmpfile_shell_logger = os.path.join(tmpdir, 'test_shell_logger.log')

    # Create subprocess with shell logger
    p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import logs; logs.shell_logger("' + tmpfile_shell_logger + '")'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    #

# Generated at 2022-06-18 07:10:28.849025
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest
    import subprocess

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            subprocess.call(['python', '-m', 'shell_logger', self.output])
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN))

    unittest.main()

# Generated at 2022-06-18 07:10:38.568731
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger
    """
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        """
        Test class for shell_logger
        """
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.log')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_shell_logger(self):
            """
            Test for shell_logger
            """
            # Create a subprocess to run shell_logger

# Generated at 2022-06-18 07:10:54.453828
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import subprocess
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:11:01.994189
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:11:10.294112
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'pwnlib.log', f.name])
        time.sleep(0.1)
        os.write(p.stdin.fileno(), b'echo "Hello world"\n')
        time.sleep(0.1)
        os.write(p.stdin.fileno(), b'exit\n')
        p.wait()
        assert f.read() == b'Hello world\n'

# Generated at 2022-06-18 07:11:17.775339
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:11:27.381256
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_

# Generated at 2022-06-18 07:11:33.922573
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:11:42.281894
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def read_log(path):
        with open(path, 'rb') as f:
            return f.read()

    def write_log(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def spawn_shell(path):
        return subprocess.Popen(['python', '-m', 'pytest_dashboard.logs.shell', path])

    def test_logger(path):
        p = spawn_shell(path)
        p.communicate(b'echo "Hello world!"\n')
        return p.returncode

    def test_logger_with_size(path):
        write_log(path, b'\x00' * const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-18 07:11:51.046751
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:12:00.867231
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.

    """
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen([sys.executable, __file__, f.name])
        time.sleep(1)
        p.send_signal(signal.SIGWINCH)
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:12:12.158454
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output(output, input, output_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error(output, input, output_file, error_file):
        shell_logger(output)


# Generated at 2022-06-18 07:12:38.556084
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import mmap

    def _read_file(filename):
        with open(filename, 'rb') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    def _write_file(filename, data):
        with open(filename, 'wb') as f:
            f.write(data)

    def _run_shell_logger(output):
        return subprocess.Popen(['python', '-m', 'pwnlib.logger.shell', output])

    def _run_shell():
        return subprocess.Popen(['python', '-m', 'pwnlib.logger.shell'])


# Generated at 2022-06-18 07:12:43.192267
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:12:55.610742
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os
    import sys

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, 'tmp_file')

    # Create temporary file
    tmp_file_2 = os.path.join(tmp_dir, 'tmp_file_2')

    # Create temporary file
    tmp_file_3 = os.path.join(tmp_dir, 'tmp_file_3')

    # Create temporary file
    tmp_file_4 = os.path.join(tmp_dir, 'tmp_file_4')

    # Create temporary file
    tmp_file_5 = os.path.join(tmp_dir, 'tmp_file_5')

    #

# Generated at 2022-06-18 07:13:06.572974
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')
    try:
        subprocess.check_call(['python', '-m', 'pwnlib.log', 'shell_logger', tmp_file])
        assert os.path.isfile(tmp_file)
        assert os.path.getsize(tmp_file) == const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:13:14.770743
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import signal
    import sys

    def _test_shell_logger(shell, shell_name):
        logs.info("Testing shell logger with %s" % shell_name)
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:13:21.252524
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    tmpdir = tempfile.mkdtemp()
    try:
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:13:25.969327
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:13:37.882281
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import os

    def _get_output(output):
        with open(output, 'r') as f:
            return f.read()

    def _get_return_code(output):
        return subprocess.call(['script', '-f', output])

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_script(output):
        subprocess.call(['script', '-f', output])

    def _test_script_with_exit(output):
        subprocess.call(['script', '-f', output, '-c', 'exit'])


# Generated at 2022-06-18 07:13:46.418179
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen([sys.executable, __file__, f.name], stdin=subprocess.PIPE)
        time.sleep(0.1)
        p.stdin.write(b'echo "foo"\n')
        time.sleep(0.1)
        p.stdin.write(b'echo "bar"\n')
        time.sleep(0.1)
        p.stdin.write(b'exit\n')
        p.wait()
        assert p.returncode == 0
        f.seek(0)
        assert f.read() == b'foo\nbar\n'



# Generated at 2022-06-18 07:13:56.676243
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')
    shell_logger(output)

    time.sleep(1)
    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    subprocess.call(['echo', 'test'])
    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    subprocess.call(['echo', 'test'])

# Generated at 2022-06-18 07:14:26.185810
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_return_code(output, input, return_code):
        shell_logger(output)

    def _test_shell_logger_with_input_and_return_code_and_error(output, input, return_code, error):
        shell_logger(output)


# Generated at 2022-06-18 07:14:37.372710
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:14:44.220406
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            with open(self.log_file, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:14:55.022133
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN))

    unittest.main()

# Generated at 2022-06-18 07:15:03.058290
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)

    with open(output, 'rb') as f:
        data = f.read()
    assert data == b'\x00' * const.LOG_SIZE_IN_BYTES

    subprocess.call(['echo', 'test'])
    with open(output, 'rb') as f:
        data = f.read()
    assert data.startswith(b'test\n')

    subprocess.call(['echo', 'test'])
    with open(output, 'rb') as f:
        data = f.read()
    assert data.startswith(b'test\n')

   

# Generated at 2022-06-18 07:15:04.014297
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test.log')

# Generated at 2022-06-18 07:15:12.880059
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import sys
    import mmap
    import os
    import array
    import fcntl
    import termios
    import tty
    import pty
    import signal
    import os
    import sys
    import termios
    import tty
    import pty
    import signal
    import os
    import sys
    import termios
    import tty
    import pty
    import signal
    import os
    import sys
    import termios
    import tty
    import pty
    import signal
    import os
    import sys
    import termios
    import tty
    import pty
    import signal
    import os
    import sys
    import termios
    import tty
    import pty

# Generated at 2022-06-18 07:15:24.173465
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:15:34.059950
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        assert return_code == 0


# Generated at 2022-06-18 07:15:43.204331
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-o', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'shell.log')
        _test_shell_logger(output)
        time.sleep(1)
        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:16:10.377489
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(shell):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, 'output')
            subprocess.check_call([shell, '-c', 'echo "hello world" && exit 0'],
                                  env={'SHELL': shell, 'PYTHONPATH': os.path.dirname(__file__)},
                                  stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL)
            time.sleep(0.1)
            with open(output, 'rb') as f:
                assert f.read() == b'hello world\n'
            shutil.rmtree(tmpdir)

    _test_shell_

# Generated at 2022-06-18 07:16:15.814093
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output')
        proc = subprocess.Popen(['python', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(output)])
        time.sleep(1)
        proc.terminate()
        proc.wait()
        with open(output, 'rb') as f:
            assert f.read() != b'\x00' * const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdirname)

# Generated at 2022-06-18 07:16:23.705778
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:16:30.931783
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_TO_CLEAN)



# Generated at 2022-06-18 07:16:39.854373
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import logs; logs.shell_logger("{}")'.format(f.name)])
        time.sleep(1)
        p.send_signal(signal.SIGWINCH)
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        assert p.returncode == 0
        assert f.read()

# Generated at 2022-06-18 07:16:44.825644
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_timeout(output):
        import threading
        thread = threading.Thread(target=_test_shell_logger, args=(output,))
        thread.start()
        time.sleep(1)
        thread.join()

    def _test_shell_logger_with_timeout_and_signal(output):
        import threading
        thread = threading.Thread(target=_test_shell_logger, args=(output,))
        thread.start()
        time.sleep(1)
        os.kill(os.getpid(), signal.SIGWINCH)
        thread.join()


# Generated at 2022-06-18 07:16:50.650177
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    try:
        subprocess.Popen(['python', '-m', 'shell_logger', output])
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:17:00.205390
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    from .. import const
    import os
    import sys
    import mmap
    import signal
    import pty
    import tty
    import termios
    import array
    import fcntl
    import time

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)
        return data


# Generated at 2022-06-18 07:17:12.149913
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    import os
    import sys
    import tempfile
    import unittest
    import shutil

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_IN_BYTES))

    unittest.main()

# Generated at 2022-06-18 07:17:16.326221
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.isfile(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)