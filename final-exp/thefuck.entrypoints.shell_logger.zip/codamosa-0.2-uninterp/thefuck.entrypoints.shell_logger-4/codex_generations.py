

# Generated at 2022-06-18 07:07:38.781723
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        def _test_shell_logger_inner():
            shell_logger(output)
        return _test_shell_logger_inner

    def _test_shell_logger_with_input(input, output):
        def _test_shell_logger_with_input_inner():
            shell_logger(output)
        return _test_shell_logger_with_input_inner

    def _test_shell_logger_with_input_and_output(input, output):
        def _test_shell_logger_with_input_and_output_inner():
            shell_logger(output)
        return _test_shell_logger_with_input_and_output_inner


# Generated at 2022-06-18 07:07:44.979217
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import shutil
    import subprocess

    def _test_shell_logger(shell, output):
        _shell_logger = partial(shell_logger, output)
        _shell_logger.__name__ = 'shell_logger'
        _shell_logger.__doc__ = shell_logger.__doc__
        return _shell_logger

    def _test_shell_logger_with_shell(shell):
        def _test_shell_logger_with_shell(output):
            return _test_shell_logger(shell, output)
        return _test_shell_logger_with_shell


# Generated at 2022-06-18 07:07:54.676225
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:08:05.428751
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import sys

    def _test_shell_logger(shell, output):
        """Test shell_logger function with `shell` and `output`."""
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_shell(shell):
        """Test shell_logger function with `shell`."""
        with tempfile.NamedTemporaryFile() as f:
            _test_shell_logger(shell, f.name)

    def _test_shell_logger_with_output(output):
        """Test shell_logger function with `output`."""
        with tempfile.NamedTemporaryFile() as f:
            _test_shell_log

# Generated at 2022-06-18 07:08:13.009297
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)

    unittest.main()

# Generated at 2022-06-18 07:08:21.802940
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import mmap

    tmpdir = tempfile.mkdtemp()
    try:
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
        time.sleep(1)
        with open(output, 'r+b') as f:
            mm = mmap.mmap(f.fileno(), 0)
            assert mm.find(b'\x00') == -1
            assert mm.find(b'\n') != -1
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:08:28.045330
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def run_shell_logger(output):
        return subprocess.Popen(['python', '-m', 'pwnlib.util.misc.shell_logger', output])

    def test_shell_logger_with_output(output):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, output)
            p = run_shell_logger(output)
            time.sleep(0.1)
            p.terminate()
            p.wait()
            assert os.path.exists(output)
            with open(output, 'rb') as f:
                assert f.read()

    test_shell_logger_with_output('test.log')
    test

# Generated at 2022-06-18 07:08:38.723661
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(shell, output):
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_command(shell, output, command):
        os.environ['SHELL'] = shell
        shell_logger(output)
        subprocess.call(command, shell=True)

    def _test_shell_logger_with_command_and_input(shell, output, command, input):
        os.environ['SHELL'] = shell
        shell_logger(output)
        subprocess.call(command, shell=True, stdin=input)


# Generated at 2022-06-18 07:08:46.708978
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:08:53.143148
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import mmap
    import signal
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:09:08.956925
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import tempfile
    import time
    import subprocess
    import os
    import sys
    import signal
    import select
    import fcntl
    import termios
    import tty
    import array
    import pty
    import mmap

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)

# Generated at 2022-06-18 07:09:16.076666
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap
    import sys

    def _read_file(path):
        with open(path, 'rb') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_file_size(path):
        return os.stat(path).st_size

    def _get_file_content(path):
        with open(path, 'rb') as f:
            return f.read()


# Generated at 2022-06-18 07:09:22.339686
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')

    shell_logger(tmp_file)

    with open(tmp_file, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:09:29.152069
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function."""
    import tempfile
    import shutil
    import os

    def _test_shell_logger(output):
        """Test shell_logger function."""
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:09:38.978793
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'test.log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.temp_file)
            with open(self.temp_file, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:09:47.008735
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log.txt')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)

    unittest.main()

# Generated at 2022-06-18 07:09:58.035174
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _run_shell_logger(output):
        subprocess.check_call(['python', '-m', 'shell_logger', output])

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

        _run_shell_logger(output)

        with open(output, 'rb') as f:
            assert f.read() != b'\x00' * const.LOG_SIZE_IN_BYTES

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:10:04.827757
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.output)

    unittest.main()

# Generated at 2022-06-18 07:10:15.855174
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import subprocess

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

    with tempfile.NamedTemporaryFile() as f:
        _test_shell_logger(f.name)

    with tempfile.NamedTemporaryFile() as f:
        _test_shell_logger(f.name)

    with tempfile.NamedTemporaryFile() as f:
        _test_shell_logger(f.name)


# Generated at 2022-06-18 07:10:25.484987
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import mmap
    import sys

    # Create temp dir
    temp_dir = tempfile.mkdtemp()
    # Create temp file
    temp_file = os.path.join(temp_dir, 'test_shell_logger')
    # Create temp file with size of const.LOG_SIZE_IN_BYTES
    with open(temp_file, 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    # Create subprocess with shell_logger
    p = subprocess.Popen([sys.executable, '-m', 'shell_logger', temp_file])
    # Wait for subprocess to start
    time.sleep(1)
   

# Generated at 2022-06-18 07:10:43.103216
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    try:
        proc = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()
        assert os.path.getsize(output) > 0
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:10:51.505965
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'pytest_dash.shell_logger', f.name])
        time.sleep(1)
        os.kill(p.pid, signal.SIGINT)
        p.wait()
        assert os.path.getsize(f.name) > 0

# Generated at 2022-06-18 07:10:56.847170
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'from shell_logger import shell_logger; shell_logger("%s")' % f.name])
        time.sleep(1)
        p.kill()
        p.wait()
        f.seek(0)
        assert f.read()

# Generated at 2022-06-18 07:11:06.152027
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)
    time.sleep(1)
    with open(output, 'r') as f:
        content = f.read()
    shutil.rmtree(temp_dir)
    assert content.startswith('Script started on')

# Generated at 2022-06-18 07:11:14.330754
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:11:23.927403
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs
    from . import shell_logger

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))
            self.assertTrue(os.path.getsize(self.output) > 0)

    unittest.main()

# Generated at 2022-06-18 07:11:33.372772
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')

    try:
        proc = subprocess.Popen(['python', '-m', 'shell_logger', output])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()

        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(tmpdir)

if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:11:41.966399
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _read_log(log_file):
        with open(log_file, 'rb') as f:
            return f.read()

    def _write_log(log_file, data):
        with open(log_file, 'wb') as f:
            f.write(data)

    def _test_logger(log_file, data):
        _write_log(log_file, data)
        shell_logger(log_file)
        return _read_log(log_file)

    def _test_logger_with_shell(log_file, data):
        _write_log(log_file, data)
        subprocess.call(['python', '-m', 'shell_logger', log_file])
        return

# Generated at 2022-06-18 07:11:53.415858
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:12:01.336021
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:12:19.001282
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:12:30.108239
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            output = os.path.join(self.tmpdir, 'output')
            shell_logger(output)
            self.assertTrue(os.path.exists(output))
            self.assertTrue(os.path.getsize(output) > 0)

    unittest.main()

# Generated at 2022-06-18 07:12:38.746039
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = os.path.join(tmpdir, 'test_shell_logger')
    # Create temporary file with shell logger
    tmpfile_logger = os.path.join(tmpdir, 'test_shell_logger_logger')
    # Create temporary file with shell logger
    tmpfile_logger_size = os.path.join(tmpdir, 'test_shell_logger_logger_size')

    # Create temporary file
    with open(tmpfile, 'w') as f:
        f.write('test_shell_logger')

    # Create temporary file with shell logger

# Generated at 2022-06-18 07:12:47.314750
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pytest', '-s', '-v',
                                       '-c', 'tests/unit/test_shell_logger.py',
                                       '--output', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

        _test_shell_logger(output)

# Generated at 2022-06-18 07:12:57.651204
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)

    time.sleep(1)
    with open(output, 'rb') as f:
        data = f.read()
        assert data.startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN)
        assert data.endswith(b'\x00' * const.LOG_SIZE_TO_CLEAN)

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:13:10.263681
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output):
        shell_logger(output)
        os.write(pty.STDOUT_FILENO, b'hello')

    def _test_shell_logger_with_input_and_resize(output):
        shell_logger(output)
        os.write(pty.STDOUT_FILENO, b'hello')
        _set_pty_size(pty.STDOUT_FILENO)

    def _test_shell_logger_with_input_and_resize_and_exit(output):
        shell_logger(output)

# Generated at 2022-06-18 07:13:19.994367
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output, '--size', '10'])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output, '--size', '10', '--clean', '5'])
        assert return_code == 0


# Generated at 2022-06-18 07:13:28.477727
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os

    def _test_shell_logger(output):
        def _test_shell_logger_inner(output):
            shell_logger(output)
        return _test_shell_logger_inner

    def _test_shell_logger_inner(output):
        shell_logger(output)

    def _test_shell_logger_inner_with_env(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_inner_with_env_and_shell(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)


# Generated at 2022-06-18 07:13:39.061114
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function
    """
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        """
        Test class for shell_logger function
        """

        def setUp(self):
            """
            Setup function for TestShellLogger class
            """
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'test_shell_logger.log')

        def tearDown(self):
            """
            Tear down function for TestShellLogger class
            """
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-18 07:13:47.204658
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        """
        Test shell_logger function.
        """
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            """
            Test shell_logger function.
            """
            from .. import shell_logger

            output = os.path.join(self.temp_dir, 'output')
            shell_logger(output)


# Generated at 2022-06-18 07:14:06.014706
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import mmap
    import sys

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        f.flush()
        p = subprocess.Popen([sys.executable, __file__, f.name], stdin=subprocess.PIPE)
        time.sleep(1)
        p.stdin.write(b'echo "Hello world"\n')
        p.stdin.flush()
        time.sleep(1)
        p.stdin.write(b'exit\n')
        p.stdin.flush()
        p.wait()
        with open(f.name, 'r+b') as f:
            buffer

# Generated at 2022-06-18 07:14:17.123052
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(shell):
        tmpdir = tempfile.mkdtemp()
        try:
            output = os.path.join(tmpdir, 'output')
            subprocess.call([sys.executable, '-m', 'shell_logger', output])
            time.sleep(1)
            with open(output) as f:
                assert f.read()
        finally:
            shutil.rmtree(tmpdir)

    _test_shell_logger('/bin/bash')
    _test_shell_logger('/bin/sh')
    _test_shell_logger('/bin/zsh')
    _test_shell_logger('/bin/ksh')
    _test_shell

# Generated at 2022-06-18 07:14:27.956222
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            return f.read()

    def _test_shell_logger_with_size(output, size):
        with open(output, 'rb') as f:
            f.seek(size)
            return f.read()

    def _test_shell_logger_with_size_and_offset(output, size, offset):
        with open(output, 'rb') as f:
            f.seek(size + offset)
            return f.read()


# Generated at 2022-06-18 07:14:38.252552
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:14:41.263175
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        subprocess.call(['python', '-m', 'pwnlib.log', '-o', f.name])
        assert f.read()

# Generated at 2022-06-18 07:14:47.357421
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        subprocess.call(['python', '-c', 'import sys; sys.path.append(".."); from . import shell_logger; shell_logger("%s")' % output])
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:14:58.888078
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess
    import shutil

    def _test_shell_logger(output):
        def _test_shell_logger_inner(output):
            shell_logger(output)

        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); '
                              'from shell_logger import shell_logger; '
                              'shell_logger("' + output + '")'],
                              stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, close_fds=True)
        p.stdin.write(b'echo "Hello world!"\n')
        time.sleep(0.1)
        p.stdin.write

# Generated at 2022-06-18 07:15:07.383136
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import tempfile
    import subprocess
    import time
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')

    # Run shell_logger
    p = subprocess.Popen([sys.executable, '-c', 'import sys; sys.path.append(".."); import logs; logs.shell_logger("' + tmp_file + '")'], stdin=subprocess.PIPE)

    # Wait for shell_logger to start
    time.sleep(1)

    # Write some data to shell_logger
    p.stdin.write(b'echo "Hello world"\n')

# Generated at 2022-06-18 07:15:16.419997
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'output')
            self.output_size = os.path.getsize(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            time.sleep(1)
            self.assertTrue(self.output_size < os.path.getsize(self.output))

    unittest.main()

# Generated at 2022-06-18 07:15:24.296152
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)

    # Create temporary file with shell_logger
    shell_logger(temp_file.name)

    # Check that file is not empty
    assert os.stat(temp_file.name).st_size > 0

    # Cleanup
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:15:42.543081
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output):
        p = subprocess.Popen(['python', '-c', 'import shell_logger; shell_logger.shell_logger("%s")' % output],
                             stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        p.communicate(input=b'echo "Hello world"\n')


# Generated at 2022-06-18 07:15:50.884191
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import subprocess

    def _test_shell_logger(output):
        sys.argv = ['shell_logger', output]
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        sys.argv = ['shell_logger', output]
        shell_logger(output)

    def _test_shell_logger_with_input_and_output(output, input, expected_output):
        sys.argv = ['shell_logger', output]
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_return_code(output, input, expected_output, expected_return_code):
        sys

# Generated at 2022-06-18 07:16:00.765966
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:16:09.226747
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            output = os.path.join(self.temp_dir, 'output')
            shell_logger(output)
            with open(output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:16:15.732248
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:16:23.378037
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)

    unittest.main()

# Generated at 2022-06-18 07:16:24.858542
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function
    """
    shell_logger('/tmp/test_shell_logger')

# Generated at 2022-06-18 07:16:28.249746
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    try:
        temp_dir = tempfile.mkdtemp()
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:16:40.708335
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def test_shell_logger_helper(output):
        with open(output, 'w') as f:
            f.write('\x00' * const.LOG_SIZE_IN_BYTES)
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0
        with open(output, 'r') as f:
            assert f.read() == '\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-18 07:16:50.057469
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'from pwnlib.log import shell_logger; shell_logger("{}")'.format(f.name)],
                             stdin=subprocess.PIPE)
        time.sleep(0.1)
        p.stdin.write(b'echo hello\n')
        time.sleep(0.1)
        p.stdin.write(b'echo world\n')
        time.sleep(0.1)
        p.stdin.write(b'exit\n')
        p.wait()

        f.seek(0)
        assert f.read().count(b'hello') == 1
        assert f.read

# Generated at 2022-06-18 07:17:04.462721
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)

    time.sleep(1)

    with open(output, 'rb') as f:
        assert f.read()

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:17:09.800535
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', f.name])
        assert f.read() != b''

# Generated at 2022-06-18 07:17:17.214196
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import subprocess
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.output = 'test_shell_logger.log'
            self.proc = subprocess.Popen(['python', '-m', 'shell_logger', self.output])
            time.sleep(0.1)

        def tearDown(self):
            self.proc.terminate()
            os.remove(self.output)

        def test_shell_logger(self):
            self.proc.send_signal(signal.SIGWINCH)
            self.proc.send_signal(signal.SIGWINCH)
            self.proc.send_signal(signal.SIGWINCH)
            self.proc.send

# Generated at 2022-06-18 07:17:27.081925
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger.

    """
    import tempfile
    import shutil
    import os

    def _test_shell_logger(output):
        """Test shell_logger with `output` file.

        """
        shell_logger(output)

    def _test_shell_logger_with_dir(dir_path):
        """Test shell_logger with `dir_path` directory.

        """
        output = os.path.join(dir_path, 'output')
        _test_shell_logger(output)

    def _test_shell_logger_with_file(file_path):
        """Test shell_logger with `file_path` file.

        """
        _test_shell_logger(file_path)
