

# Generated at 2022-06-18 07:07:38.003739
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output, shell):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-o', output, shell])
        assert return_code == 0

        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-o', output, shell])
        assert return_code == 0

        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-18 07:07:46.758337
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import unittest
    import shutil
    import subprocess

    class TestShellLogger(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            output = os.path.join(self.temp_dir, 'output')
            subprocess.call(['python', '-m', 'shell_logger', output])
            self.assertTrue(os.path.exists(output))

    unittest.main()

# Generated at 2022-06-18 07:07:58.810922
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'r') as f:
                self.assertEqual(f.read(), '\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:07:59.936477
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell_logger.log')

# Generated at 2022-06-18 07:08:06.706368
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    shell_logger(tmp_file)
    with open(tmp_file, 'r') as f:
        assert f.read() == '\x00' * const.LOG_SIZE_IN_BYTES
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:08:16.066452
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'test_shell_logger')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.temp_file)
            self.assertTrue(os.path.exists(self.temp_file))

    unittest.main()

# Generated at 2022-06-18 07:08:25.759276
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:08:30.753254
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:08:41.839522
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap
    import sys

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger.log')
    subprocess.Popen([sys.executable, __file__, temp_file])
    time.sleep(1)
    with open(temp_file, 'r+b') as f:
        buffer = mmap.mmap(f.fileno(), 0)
        assert buffer.find(b'\x00') == -1
    shutil.rmtree(temp_dir)

if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:08:48.627119
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:09:04.077743
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        with open(output, 'w') as f:
            f.write('\x00' * const.LOG_SIZE_IN_BYTES)
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        with open(output, 'w') as f:
            f.write('\x00' * const.LOG_SIZE_IN_BYTES)
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-s', '1', output])
        assert return_code

# Generated at 2022-06-18 07:09:12.667099
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        def _test_shell_logger_inner(output):
            shell_logger(output)

        proc = subprocess.Popen(['python', __file__, output], stdin=subprocess.PIPE)
        time.sleep(0.1)
        proc.stdin.write(b'echo "Hello, world!"\n')
        time.sleep(0.1)
        proc.stdin.write(b'exit\n')
        proc.wait()

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:09:21.953079
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'r') as f:
                self.assertEqual(f.read(), '\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:09:28.487221
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.log')

    # Create file with shell_logger
    subprocess.Popen(['python', '-m', 'shell_logger', temp_file])
    time.sleep(1)

    # Check that file is created
    assert os.path.isfile(temp_file)

    # Check that file is not empty
    assert os.stat(temp_file).st_size > 0

    # Remove temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:09:37.553137
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger.log')
    subprocess.Popen([sys.executable, __file__, temp_file])
    time.sleep(1)
    with open(temp_file, 'rb') as f:
        assert f.read()
    shutil.rmtree(temp_dir)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-18 07:09:48.242725
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            return f.read()

    def _test_shell_logger_with_command(command):
        return subprocess.check_output(command, shell=True)

    def _test_shell_logger_with_command_and_output(command, output):
        return subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)

    def _test_shell_logger_with_command_and_output_and_error(command, output, error):
        return subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)


# Generated at 2022-06-18 07:09:53.507632
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)

    with open(output, 'rb') as f:
        assert f.read()

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:09:57.730828
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:10:07.082665
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    from .. import const
    import os
    import mmap
    import sys
    import subprocess
    import time
    import signal
    import pty
    import tty
    import termios
    import array
    import fcntl

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)
        return data


# Generated at 2022-06-18 07:10:14.089114
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)
    time.sleep(1)
    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:10:27.792595
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            return f.read()

    def _test_shell_logger_with_size(output, size):
        with open(output, 'rb') as f:
            f.seek(size)
            return f.read()

    def _test_shell_logger_with_size_and_offset(output, size, offset):
        with open(output, 'rb') as f:
            f.seek(size)
            return f.read(offset)

    def _test_shell_logger_with_offset(output, offset):
        with open(output, 'rb') as f:
            return f.read(offset)


# Generated at 2022-06-18 07:10:36.265601
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import shutil
    import tempfile
    import time

    def _test_shell_logger(output):
        """Test function shell_logger"""
        shell_logger(output)

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output')
        _test_shell_logger(output)
        time.sleep(1)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdirname)

# Generated at 2022-06-18 07:10:45.291453
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')
            self.output_size = os.path.getsize(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            self.assertEqual(self.output_size, 0)

    unittest.main()

# Generated at 2022-06-18 07:10:56.929775
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function."""
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        """Test shell_logger function."""

        def setUp(self):
            """Set up test fixtures."""
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output.log')

        def tearDown(self):
            """Tear down test fixtures."""
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            """Test shell_logger function."""
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertE

# Generated at 2022-06-18 07:11:09.519901
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import subprocess

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code

    with tempfile.NamedTemporaryFile() as f:
        return_code = _test_shell_logger(f.name)

# Generated at 2022-06-18 07:11:16.584025
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)

    # Wait for the shell to exit
    time.sleep(1)

    # Check the output
    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    # Cleanup
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:11:24.666256
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output.log')
        proc = subprocess.Popen(['python', '-m', 'shell_logger', output])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdirname)

# Generated at 2022-06-18 07:11:35.370636
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def read_file_tail(path, size):
        with open(path, 'rb') as f:
            f.seek(-size, os.SEEK_END)
            return f.read()

    def test_shell_logger_with_size(size):
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:11:42.807455
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            time.sleep(1)
            with open(self.log_file, 'rb') as f:
                self.assertTrue(b'\x00' not in f.read())

    unittest.main()

# Generated at 2022-06-18 07:11:50.795197
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen([sys.executable, __file__, 'shell_logger', f.name])
        time.sleep(1)
        p.terminate()
        p.wait()

        f.seek(0)
        assert f.read()


if __name__ == '__main__':
    if len(sys.argv) > 1:
        globals()[sys.argv[1]](*sys.argv[2:])

# Generated at 2022-06-18 07:12:13.498271
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for function shell_logger
    """
    import os
    import shutil
    import tempfile

    def _test_shell_logger(shell, output):
        """
        Test for function shell_logger
        """
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_size(shell, output, size):
        """
        Test for function shell_logger
        """
        os.environ['SHELL'] = shell
        shell_logger(output)
        assert os.path.getsize(output) == size

    def _test_shell_logger_with_content(shell, output, content):
        """
        Test for function shell_logger
        """
        os.environ['SHELL'] = shell


# Generated at 2022-06-18 07:12:20.148835
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)

    # Wait for the shell to start
    time.sleep(1)

    # Write something to the shell
    subprocess.Popen(['echo', 'test'], stdout=subprocess.PIPE).communicate()

    # Wait for the shell to write to the file
    time.sleep(1)

    # Check if the file contains the output
    with open(output) as f:
        assert f.read().find('test') != -1

    # Cleanup
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:12:32.600284
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')

    # Start shell logger
    process = subprocess.Popen([sys.executable, '-m', 'shell_logger', output])

    # Wait for shell logger to start
    time.sleep(1)

    # Send some commands to shell
    subprocess.call(['echo', 'test'])
    subprocess.call(['echo', 'test2'])

    # Wait for shell logger to finish
    process.wait()

    # Check if shell logger worked
    with open(output, 'rb') as f:
        assert f.read().endswith(b'test\ntest2\n')

    # Cleanup
   

# Generated at 2022-06-18 07:12:37.488948
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')
    shell_logger(output)
    time.sleep(1)
    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:12:46.393904
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess

    def run_shell_logger(output):
        return subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output])

    def run_shell_logger_with_env(output):
        env = os.environ.copy()
        env['SHELL'] = '/bin/bash'
        return subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output], env=env)

    def run_shell_logger_with_env_and_script(output):
        env = os.environ.copy()
        env['SHELL'] = '/bin/bash'
        return subprocess.call(['script', '-f', output], env=env)

# Generated at 2022-06-18 07:12:58.583349
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        def _test_shell_logger_inner():
            shell_logger(output)
        return _test_shell_logger_inner

    def _test_shell_logger_output(output):
        with open(output, 'rb') as f:
            return f.read()

    def _test_shell_logger_output_size(output):
        return os.path.getsize(output)

    def _test_shell_logger_output_size_in_bytes():
        return const.LOG_SIZE_IN_BYTES

    def _test_shell_logger_output_size_to_clean():
        return const.LOG_SIZE_TO_CLEAN


# Generated at 2022-06-18 07:13:03.725660
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00'))

    unittest.main()

# Generated at 2022-06-18 07:13:13.067948
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import mmap

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import shell_logger; shell_logger.shell_logger("{}")'.format(f.name)])
        time.sleep(1)
        os.kill(p.pid, signal.SIGWINCH)
        time.sleep(1)
        os.kill(p.pid, signal.SIGTERM)
        p.wait()
        assert p.returncode == 0
        f.seek(0)
        assert mmap.mmap(f.fileno(), 0).read()

# Generated at 2022-06-18 07:13:23.798313
# Unit test for function shell_logger

# Generated at 2022-06-18 07:13:30.420059
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:14:09.446104
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import sys
    import mmap
    import os
    import pty
    import signal
    import termios
    import tty
    import array
    import fcntl
    from functools import partial
    import mmap
    import os
    import pty
    import signal
    import sys
    import termios
    import tty
    from .. import logs, const

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN

# Generated at 2022-06-18 07:14:21.190187
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import mmap
    import re

    def _get_log_file_content(log_file):
        with open(log_file, 'r') as f:
            return f.read()

    def _get_log_file_size(log_file):
        return os.path.getsize(log_file)

    def _get_log_file_last_line(log_file):
        with open(log_file, 'r') as f:
            return f.readlines()[-1]

    def _get_log_file_last_line_size(log_file):
        return len(_get_log_file_last_line(log_file))


# Generated at 2022-06-18 07:14:32.396417
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile

    def _test_shell_logger(output):
        return_code = shell_logger(output)
        assert return_code == 0
        assert os.path.isfile(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        assert os.path.isfile(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

        os.remove(output)
        _test_shell_logger(output)
        assert os.path.isfile(output)
        assert os.path

# Generated at 2022-06-18 07:14:42.230043
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:14:52.659402
# Unit test for function shell_logger
def test_shell_logger():
    """
    Unit test for function shell_logger
    """
    import os
    import shutil
    import subprocess
    import tempfile
    import time

    def _test_shell_logger(shell, output):
        """
        Unit test for function shell_logger
        """
        # Create a temporary directory
        temp_dir = tempfile.mkdtemp()
        # Change the current directory to the temporary directory
        os.chdir(temp_dir)
        # Create a temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False)
        # Close the temporary file
        temp_file.close()
        # Run the shell logger

# Generated at 2022-06-18 07:15:02.420299
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.log')

# Generated at 2022-06-18 07:15:10.341721
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'shell_logger_test.log')
    try:
        subprocess.check_call(['python', '-m', 'pytest', '-c', 'pytest.ini', '--shell-logger', tmp_file])
        time.sleep(1)
        with open(tmp_file, 'r') as f:
            assert 'test_shell_logger.py' in f.read()
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:15:21.420289
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import signal
    import sys

    def _kill_process(pid):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass

    def _get_process_pid(process):
        return process.pid

    def _get_process_return_code(process):
        return process.returncode

    def _get_process_output(process):
        return process.communicate()[0]

    def _get_process_output_size(process):
        return len(_get_process_output(process))

    def _get_process_output_lines(process):
        return _get_process_output(process).splitlines()


# Generated at 2022-06-18 07:15:29.209486
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test(cmd):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, 'output')
            subprocess.check_call([sys.executable, '-m', 'shell_logger', output])
            with open(output, 'rb') as f:
                return f.read()

    assert _test(b'echo "Hello world"') == b'Hello world\n'
    assert _test(b'echo "Hello world" > /dev/null') == b''
    assert _test(b'echo "Hello world" > /dev/null; echo "Hello world"') == b'Hello world\n'
    assert _test(b'echo "Hello world" | cat') == b'Hello world\n'

# Generated at 2022-06-18 07:15:36.090568
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'pwnlib.log', '-o', f.name])
        time.sleep(0.1)
        p.send_signal(signal.SIGINT)
        p.wait()
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
        os.remove(f.name)

# Generated at 2022-06-18 07:16:16.302552
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _read_file(filename):
        with open(filename, 'rb') as f:
            return f.read()

    def _write_file(filename, data):
        with open(filename, 'wb') as f:
            f.write(data)

    def _get_file_size(filename):
        return os.stat(filename).st_size

    def _get_file_mtime(filename):
        return os.stat(filename).st_mtime

    def _get_file_ctime(filename):
        return os.stat(filename).st_ctime

    def _get_file_atime(filename):
        return os.stat(filename).st_atime


# Generated at 2022-06-18 07:16:26.065013
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        with open(output, 'w') as f:
            f.write('\x00' * const.LOG_SIZE_IN_BYTES)

        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tempdir:
        output = os.path.join(tempdir, 'output')
        _test_shell_logger(output)

        output = os.path.join(tempdir, 'output.gz')
        _test_shell_logger(output)

        output = os.path.join(tempdir, 'output.bz2')
        _test_shell_logger

# Generated at 2022-06-18 07:16:37.521889
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(command):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            shell_logger(f.name)
            assert os.path.getsize(f.name) == const.LOG_SIZE_IN_BYTES
            assert subprocess.check_output(command, shell=True) == b'\x00' * const.LOG_SIZE_TO_CLEAN

    _test_shell_logger('echo -n "a" > /dev/null')
    _test_shell_logger('echo -n "a" > /dev/null')
    _test_shell_logger('echo -n "a" > /dev/null')

# Generated at 2022-06-18 07:16:45.124130
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.isfile(self.output))

    unittest.main()

# Generated at 2022-06-18 07:16:52.445557
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time

    with tempfile.TemporaryDirectory() as temp_dir:
        output = os.path.join(temp_dir, 'output')
        process = subprocess.Popen(['python3', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(output)])
        time.sleep(1)
        process.send_signal(signal.SIGINT)
        process.wait()

        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-18 07:16:53.021731
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-18 07:17:03.274088
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        with open(output, 'wb') as f:
            f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        with open(output, 'rb') as f:
            return f.read()

    def _test_shell_logger_with_size(output, size):
        with open(output, 'wb') as f:
            f.write(b'\x00' * size)
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])

# Generated at 2022-06-18 07:17:14.117365
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    def _test_shell_logger(shell):
        with tempfile.TemporaryDirectory() as temp_dir:
            output = os.path.join(temp_dir, 'output')
            proc = subprocess.Popen([shell, '-c', 'echo "test" > {}'.format(output)],
                                    stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
            time.sleep(1)
            proc.terminate()
            proc.wait()
            with open(output, 'rb') as f:
                assert f.read() == b'test\n'

    _test_shell_logger('/bin/sh')
    _test

# Generated at 2022-06-18 07:17:24.391658
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap

    def _read_file(filename):
        with open(filename, 'r') as f:
            return f.read()

    def _write_file(filename, content):
        with open(filename, 'w') as f:
            f.write(content)

    def _read_mmap(filename):
        with open(filename, 'r') as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            return mm.read()

    def _write_mmap(filename, content):
        with open(filename, 'w') as f:
            mm = mmap.mmap(f.fileno(), 0)
            mm.write(content)