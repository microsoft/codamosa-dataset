

# Generated at 2022-06-18 07:07:37.262375
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import sys
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:07:47.528532
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log.txt')
            self.log_file_size = os.path.getsize(self.log_file)

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            time.sleep(1)
            self.assertGreater(os.path.getsize(self.log_file), self.log_file_size)

    unittest

# Generated at 2022-06-18 07:08:00.132522
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        def _test_shell_logger_inner():
            shell_logger(output)
        return _test_shell_logger_inner

    def _test_shell_logger_with_input(input, output):
        def _test_shell_logger_with_input_inner():
            shell_logger(output)
        return _test_shell_logger_with_input_inner

    def _test_shell_logger_with_input_and_output(input, output):
        def _test_shell_logger_with_input_and_output_inner():
            shell_logger(output)
        return _test_shell_logger_with_input_and_output_inner


# Generated at 2022-06-18 07:08:10.910197
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile(delete=False) as f:
        output = f.name

    proc = subprocess.Popen([sys.executable, __file__, output])
    time.sleep(1)
    proc.send_signal(signal.SIGWINCH)
    time.sleep(1)
    proc.send_signal(signal.SIGINT)
    proc.wait()

    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    os.remove(output)


if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:08:21.758226
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(shell_command, expected_output):
        with tempfile.NamedTemporaryFile() as temp:
            subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', temp.name])
            temp.seek(0)
            output = temp.read()
            assert output == expected_output

    def _test_shell_logger_with_shell(shell_command, expected_output):
        with tempfile.NamedTemporaryFile() as temp:
            subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', temp.name, shell_command])
            temp.seek(0)
            output = temp.read()

# Generated at 2022-06-18 07:08:29.375259
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import mmap
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create temporary file
    temp_file = tempfile.mkstemp()[1]

    # Run shell logger
    p = subprocess.Popen([sys.executable, '-m', 'shell_logger', temp_file])

    # Wait for shell logger to start
    time.sleep(1)

    # Write some data to the shell
    os.write(sys.stdin.fileno(), b'echo "Hello world!"\n')

    # Wait for shell logger to finish
    time.sleep(1)

    # Check if the data is written to the file
   

# Generated at 2022-06-18 07:08:39.278521
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))
            self.assertTrue(os.path.getsize(self.output) > 0)

    unittest.main()

# Generated at 2022-06-18 07:08:46.506154
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output')
        subprocess.call(['python', '-m', 'shell_logger', output])
        assert os.path.isfile(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES


if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:08:53.045922
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        with open(output, 'wb') as f:
            f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        return_code = _spawn(os.environ['SHELL'], partial(_read, f))
        return return_code

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:09:02.393414
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'test_shell_logger')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.temp_file)
            self.assertTrue(os.path.isfile(self.temp_file))

    unittest.main()

# Generated at 2022-06-18 07:09:17.720603
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log.txt')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:09:26.692482
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function."""
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        """Test shell_logger function."""

        def setUp(self):
            """Create temporary directory."""
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            """Remove temporary directory."""
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            """Test shell_logger function."""
            shell_logger(self.output)

# Generated at 2022-06-18 07:09:37.902400
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import tempfile
    import shutil

    def _test_shell_logger(output):
        try:
            subprocess.check_call(['python', '-m', 'pwnlib.log', output])
        except subprocess.CalledProcessError:
            pass

    def _test_shell_logger_with_size(output, size):
        try:
            subprocess.check_call(['python', '-m', 'pwnlib.log', '-s', str(size), output])
        except subprocess.CalledProcessError:
            pass


# Generated at 2022-06-18 07:09:48.633037
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:09:57.693749
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:10:07.049176
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')

    def run_shell_logger():
        return subprocess.Popen(
            [sys.executable, '-m', 'shell_logger', output],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

    # Test that shell_logger works
    proc = run_shell_logger()
    proc.stdin.write(b'echo "Hello, world!"\n')
    proc.stdin.write(b'exit\n')
    proc.stdin.flush()
    proc.wait()

# Generated at 2022-06-18 07:10:15.755936
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log.txt')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)

    unittest.main()

# Generated at 2022-06-18 07:10:25.308636
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:10:31.460699
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import sys

    def test_shell_logger_helper(output):
        shell_logger(output)

    with tempfile.NamedTemporaryFile() as f:
        output = f.name
        pid = os.fork()
        if pid == 0:
            test_shell_logger_helper(output)
        else:
            time.sleep(1)
            os.kill(pid, signal.SIGINT)
            os.waitpid(pid, 0)
            with open(output, 'rb') as f:
                assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    with tempfile.NamedTemporaryFile() as f:
        output = f.name
        pid = os.fork()
       

# Generated at 2022-06-18 07:10:39.509553
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import re

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            return f.read()

    def _test_shell_logger_with_size(output, size):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - size)
            return f.read()


# Generated at 2022-06-18 07:10:49.331493
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-18 07:10:55.978959
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test')
    shell_logger(tmp_file)
    assert os.path.isfile(tmp_file)
    assert os.path.getsize(tmp_file) == const.LOG_SIZE_IN_BYTES
    with open(tmp_file, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    # Test if shell logger works like unix script command
    # with `-f` flag.
    shell_logger(tmp_file)
    assert os.path.isfile(tmp_file)

# Generated at 2022-06-18 07:11:02.805923
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:11:12.974302
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:11:22.913679
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:11:30.394797
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:11:40.539838
# Unit test for function shell_logger

# Generated at 2022-06-18 07:11:48.820399
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        assert return_code == 0
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:11:58.560462
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:12:09.224198
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import os
    import re
    import shutil

    log_file = 'test_shell_logger.log'
    if os.path.exists(log_file):
        os.remove(log_file)

    proc = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', log_file])
    time.sleep(1)
    proc.send_signal(signal.SIGINT)
    proc.wait()

    with open(log_file, 'rb') as f:
        data = f.read()

# Generated at 2022-06-18 07:12:30.506953
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import shutil
    import tempfile

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-s', '1', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-s', '1', '-c', '1', output])
        assert return_code == 0


# Generated at 2022-06-18 07:12:35.867728
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test')

    try:
        subprocess.check_call(['python', '-m', 'pwnlib.log', 'shell', tmp_file])
    except subprocess.CalledProcessError:
        pass
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:12:39.184567
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    try:
        tmpdir = tempfile.mkdtemp()
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
    except:
        raise
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:12:47.008229
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import tempfile
    import subprocess
    from .. import logs

    logs.set_level(logs.DEBUG)

    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.close()
        p = subprocess.Popen(['python', '-m', 'pwnlib.log', f.name],
                             stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        time.sleep(0.1)
        p.stdin.write(b'echo hello\n')
        p.stdin.flush()
        time.sleep(0.1)
        p.stdin.write(b'echo world\n')
        p.stdin.flush()

# Generated at 2022-06-18 07:12:59.045433
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _read_log(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_log(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _assert_log(path, data):
        assert _read_log(path) == data

    def _assert_log_size(path, size):
        assert os.path.getsize(path) == size

    def _assert_log_size_in_bytes(path, size):
        assert os.path.getsize(path) == size * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-18 07:13:11.088852
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:13:14.343777
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    try:
        shell_logger(os.path.join(temp_dir, 'test.log'))
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:13:24.828500
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log.txt')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            with open(self.log_file, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:13:30.818654
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function
    """
    import os
    import shutil
    import tempfile
    import subprocess
    import time
    import mmap
    import pty
    import tty
    import termios
    import array
    import fcntl
    import signal

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)

# Generated at 2022-06-18 07:13:37.210401
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', f.name])
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        assert p.returncode == 0
        assert f.read()

# Generated at 2022-06-18 07:13:53.240325
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:14:04.222236
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:14:13.656796
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import subprocess
    import time
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    # Create temporary file
    tmp_file_2 = os.path.join(tmp_dir, 'tmp_file_2')
    # Create temporary file
    tmp_file_3 = os.path.join(tmp_dir, 'tmp_file_3')

    # Create subprocess

# Generated at 2022-06-18 07:14:25.881049
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _read_log(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_log(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_log_size(path):
        return os.stat(path).st_size

    def _get_log_size_to_clean(path):
        return const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN

    def _get_log_position(path):
        return const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN


# Generated at 2022-06-18 07:14:37.071253
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output(output, input, output_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error(output, input, output_file, error_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error_and_return_code(output, input, output_file, error_file, return_code):
        shell_logger

# Generated at 2022-06-18 07:14:44.920090
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:14:56.424092
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _run_shell_logger(output):
        return subprocess.Popen([sys.executable, __file__, output])

    def _check_output(output, expected):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            assert f.read() == expected

    def _test_shell_logger(output):
        proc = _run_shell_logger(output)
        time.sleep(0.1)
        proc.terminate()
        proc.wait()
        _check_output(output, b'\x00' * const.LOG_SIZE_TO_CLEAN)


# Generated at 2022-06-18 07:15:04.009259
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap
    import sys

    def _read_log(log_file):
        with open(log_file, 'r+b') as f:
            buffer = mmap.mmap(f.fileno(), 0, mmap.MAP_SHARED, mmap.PROT_READ)
            return buffer.read()

    def _write_log(log_file, data):
        with open(log_file, 'r+b') as f:
            buffer = mmap.mmap(f.fileno(), 0, mmap.MAP_SHARED, mmap.PROT_WRITE)
            buffer.write(data)

    def _write_log_and_read(log_file, data):
        _write_log

# Generated at 2022-06-18 07:15:12.840290
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    from .. import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.output)

            time.sleep(1)
            self.assertTrue(os.path.isfile(self.output))


# Generated at 2022-06-18 07:15:19.857117
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import subprocess
    import tempfile
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'shell_logger', f.name])
        time.sleep(1)
        os.kill(p.pid, signal.SIGINT)
        p.wait()
        assert os.path.getsize(f.name) > 0

# Generated at 2022-06-18 07:15:38.718189
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import re

    def _test_shell_logger(log_size, log_size_to_clean, log_size_in_bytes):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_file = os.path.join(temp_dir, 'log')
            with open(log_file, 'w') as f:
                f.write('\x00' * log_size_in_bytes)
            with open(log_file, 'r+b') as f:
                buffer = mmap.mmap(f.fileno(), log_size_in_bytes, mmap.MAP_SHARED, mmap.PROT_WRITE)
                _read(buffer, 0)

# Generated at 2022-06-18 07:15:42.019060
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)
        assert os.path.getsize(f.name) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-18 07:15:50.568239
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:15:51.064723
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-18 07:16:00.935836
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code

    def _test_shell_logger_with_size(size):
        tempdir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:16:10.418123
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'w') as f:
        f.write('test')

    # Create temporary script
    temp_script = os.path.join(temp_dir, 'temp_script')
    with open(temp_script, 'w') as f:
        f.write('#!/bin/bash\n')
        f.write('cat {0}\n'.format(temp_file))

    # Make script executable
    os.chmod(temp_script, 0o755)

    # Create

# Generated at 2022-06-18 07:16:16.571939
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import tempfile
    import time
    import subprocess
    import shutil
    import os
    import sys
    import signal
    import mmap

    def _read_file(filename):
        with open(filename, 'rb') as f:
            return f.read()

    def _write_file(filename, data):
        with open(filename, 'wb') as f:
            f.write(data)

    def _read_mmap(mm):
        return mm[:mm.size()]

    def _write_mmap(mm, data):
        mm[:len(data)] = data


# Generated at 2022-06-18 07:16:25.651078
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:16:33.194298
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append("."); import shell_logger; shell_logger.shell_logger("%s")' % f.name])
        time.sleep(1)
        os.kill(p.pid, signal.SIGINT)
        p.wait()
        assert os.path.getsize(f.name) > 0

# Generated at 2022-06-18 07:16:42.035948
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:17:00.527796
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_return_code(output, input, return_code):
        shell_logger(output)

    def _test_shell_logger_with_input_and_return_code_and_error(output, input, return_code, error):
        shell_logger(output)


# Generated at 2022-06-18 07:17:09.342830
# Unit test for function shell_logger
def test_shell_logger():
    """Test for function shell_logger"""
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:17:15.303131
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    tmp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(tmp_dir, 'output')
        shell_logger(output)
        time.sleep(1)
        assert os.path.exists(output)
        assert _read_file(output)
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:17:25.984738
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'test.log')
            self.test_string = 'test'

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            with open(self.log_file, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()