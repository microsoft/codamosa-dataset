

# Generated at 2022-06-18 07:07:37.648593
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function.
    """
    import subprocess
    import time
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.log')
    subprocess.Popen(['python', '-m', 'pwnlib.log', '-f', temp_file])
    time.sleep(1)
    with open(temp_file, 'r') as f:
        assert f.read()
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:07:47.429747
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    subprocess.Popen(['python', '-m', 'shell_logger', output])
    time.sleep(1)
    subprocess.Popen(['echo', 'hello'])
    time.sleep(1)
    subprocess.Popen(['echo', 'world'])
    time.sleep(1)
    subprocess.Popen(['exit'])
    time.sleep(1)
    with open(output, 'r') as f:
        assert f.read() == 'hello\nworld\n'
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:08:00.053432
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import signal
    import sys

    def _test_shell_logger(shell, output):
        """Runs shell_logger function with given shell and output."""
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_signal(shell, output, signal):
        """Runs shell_logger function with given shell and output."""
        os.environ['SHELL'] = shell
        process = subprocess.Popen([sys.executable, __file__, shell, output])
        time.sleep(1)
        os.kill(process.pid, signal)
        process.wait()


# Generated at 2022-06-18 07:08:10.422748
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        cmd = ['python3', '-c', 'import sys; sys.path.append(".."); import shell_logger; shell_logger.shell_logger("%s")' % output]
        subprocess.Popen(cmd, stdin=subprocess.PIPE).communicate(b'echo "Hello world"\n')
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read() == b'Hello world\n'

        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:08:21.312894
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _write_file_with_size(path, size):
        _write_file(path, b'\x00' * size)

    def _get_file_size(path):
        return os.path.getsize(path)

    def _get_file_mtime(path):
        return os.path.getmtime(path)

    def _get_file_ctime(path):
        return os.path.getctime(path)


# Generated at 2022-06-18 07:08:27.691537
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:08:38.184507
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys
    import signal

    def _test_shell_logger(output, cmd):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(cmd, partial(_read, buffer))
        return return_code

    def _test_shell_logger_with_size(output, cmd, size):
        fd = os.open

# Generated at 2022-06-18 07:08:45.962525
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); from . import shell_logger; shell_logger.shell_logger("{}")'.format(f.name)])
        time.sleep(1)
        os.kill(p.pid, signal.SIGINT)
        p.wait()
        f.seek(0)
        assert f.read()

# Generated at 2022-06-18 07:08:52.734979
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest
    import subprocess

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', self.output])
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN))

    unittest

# Generated at 2022-06-18 07:09:02.492365
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))
            self.assertTrue(os.path.getsize(self.output) > 0)

    unittest.main()

# Generated at 2022-06-18 07:09:20.511029
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import os
    import time
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir)
    # Create temporary file name
    temp_file_name = temp_file.name

    # Create subprocess
    p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append("../"); import shell_logger; shell_logger.shell_logger("%s")' % temp_file_name], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # Wait for subprocess to start
    time.sleep(1)


# Generated at 2022-06-18 07:09:29.203700
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        try:
            shell_logger(output)
        except SystemExit:
            pass

    def _test_shell_logger_with_input(output, input):
        try:
            shell_logger(output)
        except SystemExit:
            pass

    with tempfile.TemporaryDirectory() as temp_dir:
        output = os.path.join(temp_dir, 'output')
        input = os.path.join(temp_dir, 'input')

        with open(input, 'w') as f:
            f.write('echo "test"')


# Generated at 2022-06-18 07:09:40.834603
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import random
    import string
    import subprocess
    import time
    import shutil

    def random_string(length):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(length))

    def test_logger(output):
        return_code = subprocess.call(['python', '-m', 'logs', 'shell', output])
        return return_code

    def test_script(output):
        return_code = subprocess.call(['script', '-f', output])
        return return_code

    def test_logs(output):
        with open(output, 'r') as f:
            logs = f.read()
        return logs


# Generated at 2022-06-18 07:09:52.025679
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:10:02.272913
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            pid = os.fork()
            if pid == 0:
                shell_logger(self.output)
            else:
                time.sleep(1)
                os.kill(pid, signal.SIGTERM)
                os.waitpid(pid, 0)

                with open(self.output, 'rb') as f:
                    self.assertEqual

# Generated at 2022-06-18 07:10:09.920049
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:10:17.739008
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', f.name])
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        assert p.returncode == 0
        assert f.read()

# Generated at 2022-06-18 07:10:22.216377
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-m', 'pwnlib.log', f.name])
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        assert f.read()

# Generated at 2022-06-18 07:10:30.012350
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:10:39.237430
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import signal
    import sys

    def _read_log(log_file):
        with open(log_file, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            return f.read()

    def _write_log(log_file, data):
        with open(log_file, 'wb') as f:
            f.write(data)

    def _write_log_and_read(log_file, data):
        _write_log(log_file, data)
        return _read_log(log_file)


# Generated at 2022-06-18 07:10:52.388974
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)

    time.sleep(1)
    with open(output, 'r') as f:
        assert f.read().startswith('#!/bin/bash')

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:11:00.565560
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import time
    import subprocess
    import tempfile
    import unittest
    from . import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.output = tempfile.mktemp()
            self.process = subprocess.Popen(
                [sys.executable, '-m', 'shell_logger', self.output],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )
            time.sleep(1)

        def tearDown(self):
            self.process.terminate()
            self.process.wait()
            os.remove(self.output)


# Generated at 2022-06-18 07:11:11.422848
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        # Create a temporary directory
        tmpdir = tempfile.mkdtemp()
        # The path to the temporary file
        path = os.path.join(tmpdir, output)
        # The path to the script
        script = os.path.join(os.path.dirname(__file__), '..', '..', 'bin', 'shell_logger')
        # Run the script
        subprocess.check_call([script, path])
        # Read the file
        with open(path, 'rb') as f:
            data = f.read()
        # Remove the directory
        shutil.rmtree(tmpdir)
        # Return the data
        return data

    # Test the function


# Generated at 2022-06-18 07:11:21.170800
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        process = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import shell_logger; shell_logger.shell_logger("%s")' % output])
        time.sleep(1)
        process.send_signal(signal.SIGINT)
        process.wait()
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:11:29.892258
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output')
        proc = subprocess.Popen(['python', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(output)])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()
        with open(output, 'rb') as f:
            assert f.read() != b'\x00' * const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdirname)

# Generated at 2022-06-18 07:11:40.183924
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_error(output):
        try:
            shell_logger(output)
        except OSError:
            pass

    def _test_shell_logger_with_error_and_file(output):
        try:
            shell_logger(output)
        except OSError:
            pass
        finally:
            os.remove(output)

    def _test_shell_logger_with_file(output):
        shell_logger(output)
        os.remove(output)


# Generated at 2022-06-18 07:11:50.625730
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import signal
    import psutil
    import pty
    import termios
    import tty
    import array

    def _set_pty_size(master_fd):
        buf = array.array('h', [0, 0, 0, 0])
        fcntl.ioctl(pty.STDOUT_FILENO, termios.TIOCGWINSZ, buf, True)
        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, buf)

    def _spawn(shell, master_read):
        """Create a spawned process.

        Modified version of pty.spawn with terminal size support.

        """
        pid, master_fd = pty.fork()


# Generated at 2022-06-18 07:12:01.590340
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_env(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_with_env_and_size(output):
        os.environ['SHELL'] = '/bin/bash'
        const.LOG_SIZE_IN_BYTES = 1024
        shell_logger(output)

    def _test_shell_logger_with_env_and_size_and_clean(output):
        os.environ['SHELL'] = '/bin/bash'
        const.LOG_SIZE_IN_BYTES = 1024


# Generated at 2022-06-18 07:12:12.869018
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import sys

    def get_output(output):
        with open(output, 'rb') as f:
            return f.read()

    def get_output_size(output):
        return os.stat(output).st_size

    def get_output_lines(output):
        return get_output(output).splitlines()

    def get_output_line(output, line):
        return get_output_lines(output)[line]

    def get_output_line_count(output):
        return len(get_output_lines(output))

    def get_output_line_count_with_size(output, size):
        return (get_output_size(output) - size) / const.LOG_SIZE_TO_CLEAN



# Generated at 2022-06-18 07:12:19.832344
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function.
    """
    import tempfile
    import time
    import subprocess

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile()

    # Create a subprocess to run shell_logger
    sub_process = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', temp_file.name])

    # Wait for the subprocess to finish
    time.sleep(1)

    # Kill the subprocess
    sub_process.kill()

    # Read the content of the temporary file
    temp_file.seek(0)
    content = temp_file.read()

    # Check if the content is not empty
    assert content != ''

# Generated at 2022-06-18 07:12:35.948277
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:12:43.021677
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys
    import re

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_shell_logger_path():
        return os.path.join(os.path.dirname(__file__), 'shell_logger.py')

    def _get_test_shell_logger_path():
        return os.path.join(os.path.dirname(__file__), 'test_shell_logger.py')

    def _get_test_shell_logger_output_path():
        return

# Generated at 2022-06-18 07:12:50.330079
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            return f.read()

    def _test_shell_logger_with_size(output, size):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - size)
            return f.read()

    def _test_shell_logger_with_size_and_offset(output, size, offset):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - size - offset)

# Generated at 2022-06-18 07:13:00.637043
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess

    def _test_shell_logger(shell):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
            f.close()
            subprocess.check_call([sys.executable, '-m', 'pwnlib.log', 'shell', f.name], shell=True)
            with open(f.name, 'rb') as f:
                assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-18 07:13:10.343240
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.logfile = os.path.join(self.tmpdir, 'logfile')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.logfile)
            self.assertTrue(os.path.exists(self.logfile))

    unittest.main()

# Generated at 2022-06-18 07:13:18.519367
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        proc = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import shell_logger; shell_logger.shell_logger("%s")' % f.name])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()
        assert b'\x00' * const.LOG_SIZE_IN_BYTES != f.read()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-18 07:13:27.539442
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_file_size(path):
        return os.stat(path).st_size

    def _get_file_mtime(path):
        return os.stat(path).st_mtime

    def _get_file_atime(path):
        return os.stat(path).st_atime

    def _get_file_ctime(path):
        return os.stat(path).st_ctime


# Generated at 2022-06-18 07:13:38.742065
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_shell(shell, output):
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_shell_and_size(shell, output, size):
        os.environ['SHELL'] = shell
        const.LOG_SIZE_IN_BYTES = size
        shell_logger(output)

    def _test_shell_logger_with_shell_and_size_and_clean(shell, output, size, clean):
        os.environ['SHELL'] = shell
        const.LOG_SIZE_IN_BY

# Generated at 2022-06-18 07:13:47.007770
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import tempfile
    import subprocess
    import shutil
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')
            self.shell_logger = os.path.join(self.temp_dir, 'shell_logger.py')
            self.script = os.path.join(self.temp_dir, 'script.sh')
            self.script_output = os.path.join(self.temp_dir, 'script_output')
            self.script_output_size = os.path.join(self.temp_dir, 'script_output_size')

# Generated at 2022-06-18 07:13:57.407754
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')

    def run_shell_logger():
        return subprocess.Popen(['python', '-m', 'shell_logger', output])

    def run_shell_logger_with_timeout():
        return subprocess.Popen(['python', '-m', 'shell_logger', output],
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE)


# Generated at 2022-06-18 07:14:11.897587
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        proc = subprocess.Popen(['python3', '-m', 'pwnlib.util.misc.shell_logger', f.name])
        time.sleep(0.1)
        proc.terminate()
        proc.wait()
        f.seek(0)
        assert f.read()

# Generated at 2022-06-18 07:14:23.557831
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    def _test_shell_logger(shell, output):
        with tempfile.TemporaryDirectory() as temp_dir:
            output = os.path.join(temp_dir, output)
            subprocess.run([shell, '-c', 'echo "Hello world!"'], env={'SHELL': shell})
            shell_logger(output)
            time.sleep(0.1)
            with open(output, 'rb') as f:
                assert f.read().endswith(b'Hello world!\n')

    for shell in ('/bin/bash', '/bin/zsh'):
        _test_shell_logger(shell, 'output')
        _test_shell_logger(shell, 'output.log')

# Generated at 2022-06-18 07:14:34.976705
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _read_file(filename):
        with open(filename, 'rb') as f:
            return f.read()

    def _read_file_from_end(filename):
        with open(filename, 'rb') as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(size - const.LOG_SIZE_IN_BYTES, 0), 0)
            return f.read()

    def _write_file(filename, data):
        with open(filename, 'wb') as f:
            f.write(data)

    def _write_file_from_end(filename, data):
        with open(filename, 'r+b') as f:
            f.seek

# Generated at 2022-06-18 07:14:43.640074
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import os
    import shutil
    import tempfile
    import unittest
    import unittest.mock

    from .. import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')
            self.shell = os.environ['SHELL']

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-18 07:14:55.123969
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')
            self.fd = os.open(self.output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
            os.write(self.fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
            self.buffer = mmap.mmap(self.fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)


# Generated at 2022-06-18 07:15:01.567763
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
        assert subprocess.call(['tail', '-c', str(const.LOG_SIZE_IN_BYTES), output]) == 0
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:15:10.912089
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0


# Generated at 2022-06-18 07:15:22.072685
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import sys
    import time
    import subprocess
    import signal

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_pid(path):
        with open(path, 'r') as f:
            return int(f.read())

    def _get_shell_pid(path):
        return _get_pid(os.path.join(path, 'shell.pid'))

    def _get_logger_pid(path):
        return _get_pid(os.path.join(path, 'logger.pid'))


# Generated at 2022-06-18 07:15:28.416417
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.insert(0, ".."); import shell_logger; shell_logger.shell_logger("%s")' % f.name])
        time.sleep(1)
        os.kill(p.pid, signal.SIGINT)
        p.wait()
        f.seek(0)
        assert f.read().startswith(b'\x00' * const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-18 07:15:36.063325
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')
    try:
        subprocess.call(['python', '-m', 'shell_logger', tmp_file])
        assert os.path.isfile(tmp_file)
    finally:
        shutil.rmtree(tmp_dir)

if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:15:53.218811
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        def _test_shell_logger_subprocess(output):
            os.environ['SHELL'] = '/bin/bash'
            subprocess.call(['python', '-m', 'pwnlib.log', output])

        def _test_shell_logger_subprocess_with_command(output, command):
            os.environ['SHELL'] = '/bin/bash'
            subprocess.call(['python', '-m', 'pwnlib.log', output, command])

        def _test_shell_logger_subprocess_with_command_and_args(output, command, args):
            os.environ['SHELL'] = '/bin/bash'
           

# Generated at 2022-06-18 07:16:02.492706
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import mmap
    import re

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create temporary file name
    temp_file_name = temp_file.name
    # Close temporary file
    temp_file.close()
    # Create temporary file name for output
    temp_file_name_output = temp_file_name + '_output'
    # Create temporary file for output
    temp_file_output = open(temp_file_name_output, 'w')
    # Create temporary file name for output
    temp_file_name_output_log = temp_file_name

# Generated at 2022-06-18 07:16:07.810511
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function."""
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.exists(output)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:16:16.362951
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test.log')


# Generated at 2022-06-18 07:16:26.144688
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import mmap
    import sys

    def get_file_size(file_path):
        return os.stat(file_path).st_size

    def get_file_content(file_path):
        with open(file_path, 'r') as f:
            return f.read()

    def get_file_content_mmap(file_path):
        with open(file_path, 'r') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    def get_file_content_mmap_from_fd(fd):
        return mmap.mmap(fd, 0, access=mmap.ACCESS_READ)


# Generated at 2022-06-18 07:16:35.560230
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:16:38.306452
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)

    unittest.main()

# Generated at 2022-06-18 07:16:45.122988
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'from ptylogger import shell_logger; shell_logger("{}")'.format(f.name)])
        time.sleep(1)
        p.terminate()
        p.wait()
        assert p.returncode == 0
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-18 07:16:50.297624
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')

    try:
        shell_logger(tmp_file)
    except SystemExit:
        pass

    time.sleep(1)
    assert os.path.exists(tmp_file)

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:17:00.089294
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _run_shell_logger(output):
        return subprocess.Popen(
            [sys.executable, '-m', 'pysh.logs.shell', output],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            close_fds=True,
            preexec_fn=os.setsid,
        )

    def _write_to_shell(process, data):
        process.stdin.write(data)
        process.stdin.flush()

    def _read_from_shell(process):
        return process.stdout.read()


# Generated at 2022-06-18 07:17:17.541522
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import tempfile
    import subprocess
    import time
    import os
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create temporary file
    tmp_file = os.path.join(tmp_dir, 'test_shell_logger.log')
    # Create temporary file
    tmp_file_2 = os.path.join(tmp_dir, 'test_shell_logger_2.log')

    # Create subprocess
    p = subprocess.Popen(['python', '-m', 'shell_logger', tmp_file])
    # Wait for subprocess to start
    time.sleep(0.1)
    # Send command to subprocess

# Generated at 2022-06-18 07:17:27.378318
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test(command):
        with tempfile.NamedTemporaryFile() as f:
            subprocess.call(['python', '-m', 'pwnlib.shellcraft.logger', f.name])
            time.sleep(0.1)
            subprocess.call(['python', '-m', 'pwnlib.shellcraft.logger', f.name])
            time.sleep(0.1)
            subprocess.call(['python', '-m', 'pwnlib.shellcraft.logger', f.name])
            time.sleep(0.1)
            subprocess.call(['python', '-m', 'pwnlib.shellcraft.logger', f.name])
            time.sleep(0.1)
           