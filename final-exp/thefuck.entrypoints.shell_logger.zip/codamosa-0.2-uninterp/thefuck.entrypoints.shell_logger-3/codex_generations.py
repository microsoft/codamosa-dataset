

# Generated at 2022-06-18 07:07:35.430041
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:07:46.685205
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import tempfile
    import os
    import shutil

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger')

    try:
        subprocess.Popen(['python3', '-c', 'import shell_logger; shell_logger.shell_logger("{}")'.format(temp_file)])
        time.sleep(1)
        subprocess.Popen(['echo', 'test_shell_logger'])
        time.sleep(1)
        with open(temp_file, 'rb') as f:
            assert f.read().find(b'test_shell_logger') != -1
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:07:59.355802
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import subprocess
    import tempfile
    import shutil

    def _test_shell_logger(output):
        import os
        import time
        import subprocess
        import tempfile
        import shutil

        def _test_shell_logger(output):
            shell_logger(output)

        def _test_shell_logger_with_shell(shell):
            with tempfile.NamedTemporaryFile() as f:
                os.environ['SHELL'] = shell
                _test_shell_logger(f.name)

        def _test_shell_logger_with_output(output):
            with tempfile.NamedTemporaryFile() as f:
                _test_shell_logger(f.name)


# Generated at 2022-06-18 07:08:10.316166
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_exception(output):
        try:
            shell_logger(output)
        except Exception:
            pass

    def _test_shell_logger_with_exception_and_cleanup(output):
        try:
            shell_logger(output)
        except Exception:
            pass
        finally:
            os.remove(output)

    def _test_shell_logger_with_cleanup(output):
        shell_logger(output)
        os.remove(output)


# Generated at 2022-06-18 07:08:21.216115
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import signal
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:08:28.565876
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:08:39.377755
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import subprocess
    import time
    import shutil

    with tempfile.TemporaryDirectory() as tempdir:
        output = os.path.join(tempdir, 'output')
        proc = subprocess.Popen(['python3', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(output)])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()
        with open(output, 'rb') as f:
            assert f.read()

    with tempfile.TemporaryDirectory() as tempdir:
        output = os.path.join(tempdir, 'output')

# Generated at 2022-06-18 07:08:49.060583
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')

    # Create subprocess
    p = subprocess.Popen(['python', '-c', 'from pwnlib.logger import shell_logger; shell_logger("%s")' % output],
                         stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         shell=True)

    # Write some data to the subprocess
    p.stdin.write('echo "Hello World!"\n')
    time.sleep(1)
    p.stdin.write('exit\n')

    #

# Generated at 2022-06-18 07:08:58.561244
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import subprocess

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Start the shell logger
    p = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', path])

    # Wait for the logger to start
    time.sleep(1)

    # Write some data to the logger
    os.system('echo "test"')

    # Wait for the logger to finish
    time.sleep(1)

    # Kill the logger
    p.kill()

    # Read the data from the file
    with open(path, 'rb') as f:
        data = f.read()

    # Clean up
    os.unlink(path)

    # Check

# Generated at 2022-06-18 07:09:03.566121
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.exists(output)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:09:15.877920
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            with open(self.log_file, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:09:25.472324
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import tempfile
    import subprocess
    import time
    import shutil

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        proc = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

        proc = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', output])

# Generated at 2022-06-18 07:09:36.329936
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:09:39.696214
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time


# Generated at 2022-06-18 07:09:48.538145
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:09:59.542454
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(command):
        with tempfile.NamedTemporaryFile() as f:
            subprocess.call(['python', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(f.name)])
            time.sleep(0.1)
            subprocess.call(command, shell=True)
            time.sleep(0.1)
            return f.read()


# Generated at 2022-06-18 07:10:07.803447
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:10:19.631323
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0

        with open(output, 'rb') as f:
            data = f.read()
            assert len(data) == const.LOG_SIZE_IN_BYTES
            assert data.count(b'\x00') == const.LOG_SIZE_IN_BYTES - len(b'pwnlib.log')

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)

        # Test if the logger works when the output file is full


# Generated at 2022-06-18 07:10:28.285822
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_shell_logger_path():
        return os.path.join(os.path.dirname(__file__), 'shell_logger.py')

    def _run_shell_logger(output):
        return subprocess.Popen([sys.executable, _get_shell_logger_path(), output])


# Generated at 2022-06-18 07:10:38.177058
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_

# Generated at 2022-06-18 07:10:52.320731
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:11:00.421647
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))
            with open(self.log_file, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    un

# Generated at 2022-06-18 07:11:11.345400
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:11:21.443346
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_return_code(output, input, return_code):
        shell_logger(output)

    def _test_shell_logger_with_return_code(output, return_code):
        shell_logger(output)

    def _test_shell_logger_with_return_code_and_input(output, return_code, input):
        shell_logger(output)


# Generated at 2022-06-18 07:11:31.107656
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:11:41.003153
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:11:51.448863
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import tempfile
    import subprocess
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_file = tempfile.NamedTemporaryFile()
            self.tmp_file_name = self.tmp_file.name
            self.tmp_file.close()

        def test_shell_logger(self):
            cmd = 'echo "test" | python -m pwnlib.logger.shell_logger {}'.format(self.tmp_file_name)
            subprocess.check_call(cmd, shell=True)
            time.sleep(1)
            with open(self.tmp_file_name, 'rb') as f:
                self.assertEqual(f.read(), b'test\n')



# Generated at 2022-06-18 07:11:59.189156
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)

    # Wait until shell_logger is finished
    time.sleep(1)

    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:12:08.974037
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN))

    unittest.main()

# Generated at 2022-06-18 07:12:18.109146
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:12:36.872090
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:12:45.380998
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:12:48.954208
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:12:57.673478
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'shell_logger')

    # Run shell_logger in a subprocess
    proc = subprocess.Popen(['python', '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(tmp_file)])

    # Wait for shell_logger to start
    time.sleep(1)

    # Send some commands to the shell
    subprocess.call(['python', '-c', 'import os; os.system("echo test")'], shell=True)

    # Wait for shell_logger to finish
    time.sleep(1)

    # Check if the output is correct
   

# Generated at 2022-06-18 07:13:09.616254
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:13:14.123064
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)
    time.sleep(1)

    with open(output, 'rb') as f:
        assert f.read() != b'\x00' * const.LOG_SIZE_IN_BYTES

    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:13:23.876501
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess
    import os
    import sys

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')

    # Run shell logger
    proc = subprocess.Popen([sys.executable, '-m', 'pwnlib.log', 'shell_logger', output])
    time.sleep(1)
    proc.terminate()

    # Check if output file exists
    assert os.path.isfile(output)

    # Check if output file is not empty
    assert os.path.getsize(output) > 0

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:13:30.146758
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:13:38.378006
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:13:46.763605
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import shutil
    import subprocess
    import mmap
    import sys

    def _read_file(path):
        with open(path, 'rb') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _get_file_size(path):
        return os.stat(path).st_size

    def _get_file_content(path):
        with open(path, 'rb') as f:
            return f.read()


# Generated at 2022-06-18 07:14:05.967104
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:14:17.124359
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'log')
    print(tmp_file)

    # Start shell logger
    p = subprocess.Popen([sys.executable, '-m', 'pwnlib.util.misc.shell_logger', tmp_file])
    time.sleep(0.1)

    # Write some data to the shell
    os.system('echo "Hello world"')
    time.sleep(0.1)

    # Stop shell logger
    os.kill(p.pid, signal.SIGINT)
    p.wait()

    # Check if the data was written to the file

# Generated at 2022-06-18 07:14:27.956369
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    from .. import const
    import os
    import mmap
    import array
    import fcntl
    import pty
    import termios
    import tty
    import signal
    import sys
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os
    import os


# Generated at 2022-06-18 07:14:38.961907
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import subprocess
    import shutil
    import re

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:14:45.993710
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    def read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def read_file_size(path, size):
        with open(path, 'rb') as f:
            return f.read(size)

    def read_file_offset(path, offset):
        with open(path, 'rb') as f:
            f.seek(offset)
            return f.read()

    def get_file_size(path):
        return os.path.getsize(path)


# Generated at 2022-06-18 07:14:57.565116
# Unit test for function shell_logger
def test_shell_logger():
    """Test for shell_logger function.

    Tested on Linux.

    """
    import tempfile
    import subprocess
    import time

    def _test_shell_logger(output):
        """Test shell_logger function."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, output)
            shell_logger(output)

    def _test_shell_logger_with_input(input_, output):
        """Test shell_logger function with input."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, output)
            shell_logger(output)
            time.sleep(0.1)
            subprocess.call(input_, shell=True)


# Generated at 2022-06-18 07:15:04.736364
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_size(output):
        shell_logger(output)

    def _test_shell_logger_with_size_and_clean(output):
        shell_logger(output)

    def _test_shell_logger_with_size_and_clean_and_write(output):
        shell_logger(output)

    def _test_shell_logger_with_size_and_clean_and_write_and_read(output):
        shell_logger(output)

    def _test_shell_logger_with_size_and_clean_and_write_and_read_and_move(output):
        shell

# Generated at 2022-06-18 07:15:13.483727
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell logger.

    """
    import tempfile
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        subprocess.call(['python', '-m', 'pytest', '-q', 'tests/test_shell_logger.py', '-s'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        env={'PYTEST_SHELL_LOGGER_OUTPUT': f.name})
        f.seek(0)
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES



# Generated at 2022-06-18 07:15:24.781457
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import mmap
    import sys
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:15:34.953879
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'test.log')
            self.log_file_size = os.path.getsize(self.log_file)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(self.log_file_size < os.path.getsize(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:15:51.249100
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import mmap

    def _read_log(log):
        with open(log, 'r') as f:
            return f.read()

    def _read_log_mmap(log):
        with open(log, 'r') as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            return mm.read()

    def _write_log(log, data):
        with open(log, 'w') as f:
            f.write(data)

    def _write_log_mmap(log, data):
        with open(log, 'r+') as f:
            mm = mmap.mmap(f.fileno(), 0)
            mm

# Generated at 2022-06-18 07:16:01.048035
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:16:09.880578
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_IN_BYTES))

    unittest.main()

# Generated at 2022-06-18 07:16:16.023428
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:16:24.154526
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log.txt')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:16:31.912189
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time

    with tempfile.NamedTemporaryFile() as f:
        proc = subprocess.Popen([sys.executable, __file__, f.name])
        time.sleep(1)
        proc.send_signal(signal.SIGINT)
        proc.wait()

        f.seek(0)
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES


if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-18 07:16:42.583012
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import unittest
    from . import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_file = tempfile.NamedTemporaryFile()
            self.tmp_file.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
            self.tmp_file.flush()

        def test_shell_logger(self):
            shell_logger(self.tmp_file.name)
            self.tmp_file.seek(0)
            self.assertTrue(self.tmp_file.read().startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN))

    unittest.main()

# Generated at 2022-06-18 07:16:51.517389
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from . import logs
    from . import const

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')
            self.log_file_size = const.LOG_SIZE_IN_BYTES
            self.log_file_size_to_clean = const.LOG_SIZE_TO_CLEAN

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)

# Generated at 2022-06-18 07:16:59.712631
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')
    shell_logger(output)

    # Wait for the shell to be closed
    time.sleep(1)

    # Check if the output file is not empty
    assert os.path.getsize(output) > 0

    # Check if the output file is a valid log file
    assert subprocess.call(['log_tool', '-t', 'shell', output]) == 0

    # Clean up
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:17:11.669087
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import shutil
    import tempfile
    import subprocess

    def _test_shell_logger(shell, output):
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_size(shell, output, size):
        os.environ['SHELL'] = shell
        const.LOG_SIZE_IN_BYTES = size
        shell_logger(output)

    def _test_shell_logger_with_clean_size(shell, output, size, clean_size):
        os.environ['SHELL'] = shell
        const.LOG_SIZE_IN_BYTES = size
        const.LOG_SIZE_TO_CLEAN = clean_size
        shell_logger(output)
