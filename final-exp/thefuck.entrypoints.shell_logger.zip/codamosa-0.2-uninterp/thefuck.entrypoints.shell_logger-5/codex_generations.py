

# Generated at 2022-06-18 07:07:35.052136
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')
    shell_logger(output)

    # Wait for the shell to exit
    time.sleep(1)

    # Check the output
    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:07:42.713915
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)
    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:07:48.822570
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess
    import os

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        f.flush()
        subprocess.Popen(['python', '-m', 'shell_logger', f.name])
        time.sleep(1)
        os.system('echo "Hello, world!"')
        time.sleep(1)
        os.system('exit')
        time.sleep(1)
        f.seek(0)
        assert f.read().find(b'Hello, world!') != -1

# Generated at 2022-06-18 07:07:54.895920
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)
    time.sleep(1)
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:07:56.942943
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:08:07.333487
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _test_shell_logger(shell, data):
        tmpdir = tempfile.mkdtemp()
        try:
            path = os.path.join(tmpdir, 'log')
            _write_file(path, data)
            os.environ['SHELL'] = shell
            shell_logger(path)
            time.sleep(0.1)
            assert _read_file(path) == data
        finally:
            shutil.rmtree(tmpdir)

    _test_shell

# Generated at 2022-06-18 07:08:18.535483
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    temp_dir = tempfile.mkdtemp()
    log_file = os.path.join(temp_dir, 'log.txt')
    shell_logger(log_file)
    # Wait for the logger to start
    time.sleep(0.1)
    # Write some data to the logger
    subprocess.call(['echo', 'test'], stdout=sys.stdout)
    # Wait for the logger to finish
    time.sleep(0.1)
    # Check the output
    with open(log_file, 'r') as f:
        assert f.read() == 'test\n'
    # Cleanup
    shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:08:21.802153
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)
        assert os.path.getsize(f.name) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-18 07:08:28.045645
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:08:37.768335
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:08:49.060546
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Run shell_logger
    shell_logger(tmpfile)

    # Check if file is not empty
    assert os.stat(tmpfile).st_size > 0

    # Remove temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:08:58.562183
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import signal
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:09:06.831727
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output_file = os.path.join(self.tmp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output_file)
            self.assertTrue(os.path.exists(self.output_file))

    unittest.main()

# Generated at 2022-06-18 07:09:14.640645
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    from .. import logs

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')
            self.log_file = os.path.join(self.tempdir, 'log')
            self.logs = logs.Logs(self.log_file)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            pid = os.fork()
            if pid == 0:
                shell_logger(self.output)
            else:
                time.sleep(1)

# Generated at 2022-06-18 07:09:21.209911
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:09:22.866005
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)

# Generated at 2022-06-18 07:09:28.221775
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')
    shell_logger(tmp_file)

    # Wait for shell_logger to finish
    time.sleep(1)

    with open(tmp_file, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:09:37.705357
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:09:47.615297
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:09:58.611367
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:10:18.243291
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.log')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_shell_logger(self):
            shell_logger(self.test_file)
            with open(self.test_file, 'rb') as f:
                self.assertEqual(f.read(), b'\x00' * const.LOG_SIZE_IN_BYTES)

    unittest.main()

# Generated at 2022-06-18 07:10:24.457736
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmpdir = tempfile.mkdtemp()
    try:
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
    finally:
        shutil.rmtree(tmpdir)

    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    # Test that shell_logger works like unix script command with `-f` flag.
    with open(output, 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-18 07:10:27.988538
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')

    try:
        shell_logger(output)
        assert os.path.exists(output)
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:10:37.915367
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            return f.read()

    def _test_shell_logger_with_size(output):
        with open(output, 'rb') as f:
            return f.read()

    def _test_shell_logger_with_size_and_truncate(output):
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            return f.read()


# Generated at 2022-06-18 07:10:47.577819
# Unit test for function shell_logger
def test_shell_logger():
    """Test for shell_logger function."""
    import tempfile
    import shutil
    import subprocess
    import time

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # Create a temporary script
    temp_script = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_script.write(b'#!/bin/bash\n')
    temp_script.write(b'echo "Hello World!"\n')
    temp_script.write(b'exit 0\n')
    temp_script.close()
    os.chmod(temp_script.name, 0o755)

    # Run the script
    sub

# Generated at 2022-06-18 07:10:54.370251
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:11:00.796840
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:11:09.896495
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:11:19.844873
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess

    def _test_shell_logger(shell, expected_return_code):
        with tempfile.NamedTemporaryFile() as f:
            return_code = subprocess.call(['python', '-m', 'pwnlib.log', f.name])
            assert return_code == expected_return_code

            with open(f.name, 'rb') as f:
                assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    _test_shell_logger('/bin/sh', 0)
    _test_shell_logger('/bin/bash', 0)
    _test_shell_logger('/bin/zsh', 0)

# Generated at 2022-06-18 07:11:29.145021
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import sys

    def _test_shell_logger(output, command):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            with open(output, 'w') as f:
                f.write('\x00' * const.LOG_SIZE_IN_BYTES)
            p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            time.sleep(1)
            p.stdin.write(b'echo "test"\n')
            p.stdin.flush()
            time.sleep(1)
            p.stdin.write

# Generated at 2022-06-18 07:11:45.425220
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:11:56.094181
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_timeout(output, input, timeout):
        shell_logger(output)

    def _test_shell_logger_with_input_and_timeout_and_return_code(output, input, timeout, return_code):
        shell_logger(output)

    def _test_shell_logger_with_input_and_timeout_and_return_code_and_stdout(output, input, timeout, return_code, stdout):
        shell_logger(output)



# Generated at 2022-06-18 07:12:06.796940
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import os
    import shutil
    import tempfile
    import time

    from .. import logs

    logs.set_level(logs.DEBUG)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    logs.debug("Created temporary directory: %s", tmpdir)

    # Change to temporary directory
    old_dir = os.getcwd()
    os.chdir(tmpdir)

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    logs.debug("Created temporary file: %s", tmpfile)

    # Write data to file
    os.write(fd, b"Hello World!\n")
    os.close(fd)

    # Create a temporary output file

# Generated at 2022-06-18 07:12:14.503607
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')

    try:
        subprocess.check_call(['python', '-c', 'import sys; sys.path.append(".."); import logs; logs.shell_logger("%s")' % output])
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:12:24.069992
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import signal

    def _test_shell_logger(output):
        def _test_shell_logger_child(output):
            shell_logger(output)

        pid = os.fork()
        if pid == 0:
            _test_shell_logger_child(output)

        time.sleep(1)
        os.kill(pid, signal.SIGINT)
        os.waitpid(pid, 0)

    def _test_shell_logger_with_output(output):
        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read()


# Generated at 2022-06-18 07:12:35.396344
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import subprocess
    import tempfile
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code

    def _test_shell_logger_with_size(size):
        output = tempfile.mktemp()

# Generated at 2022-06-18 07:12:42.697465
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import mmap

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'output')


# Generated at 2022-06-18 07:12:50.191469
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:12:56.994695
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:13:07.512182
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:13:26.831807
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile

    def _test_shell_logger(output):
        shell_logger(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        shutil.copy(output, output + '.bak')
        _test_shell_logger(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
        assert os.path.getsize(output + '.bak') == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-18 07:13:38.467637
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        assert return_code == 0


# Generated at 2022-06-18 07:13:45.452001
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:13:55.022607
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output, command):
        """Test shell logger with `command`."""
        with tempfile.TemporaryDirectory() as temp_dir:
            output = os.path.join(temp_dir, output)
            process = subprocess.Popen(
                [sys.executable, '-m', 'shell_logger', output],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
            )
            process.stdin.write(command)
            process.stdin.close()
            process.wait()
            assert process.returncode == 0

# Generated at 2022-06-18 07:14:05.740047
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tempdir, 'shell.log')
            self.shell_logger = os.path.join(os.path.dirname(__file__), 'shell_logger.py')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            command = 'python {} {}'.format(self.shell_logger, self.log_file)

# Generated at 2022-06-18 07:14:17.044249
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    def _test_shell_logger(output):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, output)
            shell_logger(output)

    def _test_shell_logger_with_command(command, output):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, output)
            subprocess.run(['python', '-m', 'shell_logger', output, '--', command])

    def _test_shell_logger_with_command_and_sleep(command, output, sleep):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, output)
            subprocess.run

# Generated at 2022-06-18 07:14:27.862893
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output(output, input, output_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error(output, input, output_file, error_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error_and_return_code(output, input, output_file, error_file, return_code):
        shell_logger(output)



# Generated at 2022-06-18 07:14:38.865964
# Unit test for function shell_logger
def test_shell_logger():
    """
    Unit test for function shell_logger
    """
    import subprocess
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile()
            self.output = self.temp_file.name

        def tearDown(self):
            self.temp_file.close()

        def test_shell_logger(self):
            """
            Test shell_logger
            """
            process = subprocess.Popen(["python", "-m", "pwnlib.log", "shell_logger", self.output])
            time.sleep(1)
            process.send_signal(signal.SIGINT)
            process.wait()


# Generated at 2022-06-18 07:14:44.281594
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)

    unittest.main()

# Generated at 2022-06-18 07:14:55.791015
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function
    """
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs
    from .. import const

    class TestShellLogger(unittest.TestCase):
        """
        Test shell_logger function
        """
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, "output")

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            """
            Test shell_logger function
            """
            shell_logger(self.output)

# Generated at 2022-06-18 07:15:24.254558
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest
    import subprocess

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            subprocess.call(['python', '-m', 'shell_logger', self.output])
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:15:34.182911
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap

    def _read_from_file(file_name):
        with open(file_name, 'rb') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    def _get_file_size(file_name):
        return os.stat(file_name).st_size

    def _get_file_content(file_name):
        with open(file_name, 'rb') as f:
            return f.read()

    def _get_file_content_from_offset(file_name, offset):
        with open(file_name, 'rb') as f:
            f.seek(offset)
            return f.read()


# Generated at 2022-06-18 07:15:42.843142
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs
    from . import shell_logger

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmpdir, 'output')
            self.log = os.path.join(self.tmpdir, 'log')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            logs.init(self.log)
            shell_logger(self.output)

    unittest.main()

# Generated at 2022-06-18 07:15:51.055947
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:16:00.926468
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:16:04.467304
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:16:13.132826
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:16:18.013255
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    from .. import const
    import os
    import mmap
    import sys
    import signal
    import pty
    import array
    import fcntl
    import termios
    import tty
    import os
    import mmap
    import sys
    import signal
    import pty
    import array
    import fcntl
    import termios
    import tty
    import os
    import mmap
    import sys
    import signal
    import pty
    import array
    import fcntl
    import termios
    import tty
    import os
    import mmap
    import sys
    import signal
    import pty
    import array
    import fcntl
    import termios
    import tty
    import os
    import mmap
    import sys

# Generated at 2022-06-18 07:16:27.333839
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        time.sleep(1)
        _test_shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:16:33.201920
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess
    import os

    with tempfile.NamedTemporaryFile() as tmp:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import shell_logger; shell_logger.shell_logger("%s")' % tmp.name], stdin=subprocess.PIPE)
        time.sleep(1)
        p.stdin.write(b'echo "test"\n')
        p.stdin.flush()
        time.sleep(1)
        p.stdin.write(b'exit\n')
        p.stdin.flush()
        p.wait()
        assert os.path.getsize(tmp.name) == const.LOG_SIZE_IN_BYTES
        assert open

# Generated at 2022-06-18 07:17:18.600367
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger')
    shell_logger(temp_file)
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)

# Generated at 2022-06-18 07:17:28.403604
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-s', '1', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', '-s', '1', '-c', '1', output])
        assert return_code == 0