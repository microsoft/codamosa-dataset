

# Generated at 2022-06-18 07:07:37.406033
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:07:47.585585
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:08:00.168899
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_shell(shell, output):
        os.environ['SHELL'] = shell
        shell_logger(output)

    def _test_shell_logger_with_shell_and_command(shell, command, output):
        os.environ['SHELL'] = shell
        os.environ['SHELL_LOGGER_COMMAND'] = command
        shell_logger(output)

    def _test_shell_logger_with_command(command, output):
        os.environ['SHELL_LOGGER_COMMAND'] = command
        shell_logger(output)


# Generated at 2022-06-18 07:08:11.326809
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger')
    shell_logger(temp_file)
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)
    subprocess.call(['echo', 'test'])
    time.sleep(1)

# Generated at 2022-06-18 07:08:22.080372
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.tmpdir, 'log.txt')
            self.log_file_size = os.path.getsize(self.log_file)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_shell_logger(self):
            # Run shell logger
            process = subprocess.Popen(['python', '-m', 'logs.shell_logger', self.log_file])
            time.sleep(1)
            process.send_

# Generated at 2022-06-18 07:08:25.326577
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess

    tmpdir = tempfile.mkdtemp()
    output = os.path.join(tmpdir, 'output')
    shell_logger(output)
    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:08:30.716990
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = os.path.join(temp_dir, 'test_shell_logger.log')

    # Create temporary script
    temp_script = os.path.join(temp_dir, 'test_shell_logger.sh')
    with open(temp_script, 'w') as f:
        f.write('#!/bin/bash\n')
        f.write('echo "Hello world!"\n')
        f.write('exit 0\n')
    os.chmod(temp_script, 0o755)

    # Run script
    subprocess.check_call([temp_script])

    #

# Generated at 2022-06-18 07:08:37.410717
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    temp_dir = tempfile.mkdtemp()
    try:
        output = os.path.join(temp_dir, 'output')
        shell_logger(output)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:08:45.705645
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:08:52.580301
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger."""
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(shell):
        """Unit test for function shell_logger."""
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:09:08.549888
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger():
        os.system('echo "test"')

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test')

# Generated at 2022-06-18 07:09:18.817905
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function."""
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs

    class TestShellLogger(unittest.TestCase):
        """Test shell_logger function."""

        def setUp(self):
            """Create temporary directory."""
            self.temp_dir = tempfile.mkdtemp()
            logs.init(self.temp_dir)

        def tearDown(self):
            """Remove temporary directory."""
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            """Test shell_logger function."""
            from .. import shell_logger

            shell_logger(os.path.join(self.temp_dir, 'test_shell_logger'))

    un

# Generated at 2022-06-18 07:09:27.416345
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', output])
        assert return_code == 0

    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, 'output')
        _test_shell_logger(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

        # Test if it works with a file that already exists
        _test_shell_logger(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

        # Test if it

# Generated at 2022-06-18 07:09:37.055699
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from .. import logs

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:09:47.818162
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import subprocess
    import shutil
    import mmap

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code

    def _test_shell_logger_with_input(output, input):
        fd = os.open

# Generated at 2022-06-18 07:09:58.833157
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    def _test_shell_logger(output):
        def _test_shell_logger_inner():
            shell_logger(output)

        return _test_shell_logger_inner

    with tempfile.NamedTemporaryFile() as f:
        subprocess.call(['python', '-c', 'import time; time.sleep(1)', '&'])
        subprocess.call(['python', '-c', 'import time; time.sleep(1)', '&'])
        subprocess.call(['python', '-c', 'import time; time.sleep(1)', '&'])
        subprocess.call(['python', '-c', 'import time; time.sleep(1)', '&'])

# Generated at 2022-06-18 07:10:07.872010
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess

    def _test(command):
        with tempfile.TemporaryDirectory() as tmpdir:
            output = os.path.join(tmpdir, 'output')
            subprocess.call([sys.executable, '-c', 'from shell_logger import shell_logger; shell_logger("{}")'.format(output)], env={'SHELL': '/bin/bash', 'PS1': '$ '})
            with open(output, 'rb') as f:
                return f.read()

    assert _test('echo "Hello world"') == b'$ echo "Hello world"\r\nHello world\r\n$ '

# Generated at 2022-06-18 07:10:19.716256
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:10:28.356250
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess
    import sys

    temp_dir = tempfile.mkdtemp()
    output_file = os.path.join(temp_dir, 'output')

# Generated at 2022-06-18 07:10:38.233406
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import shutil
    import subprocess
    import os

    def _write_to_file(filename, data):
        with open(filename, 'w') as f:
            f.write(data)

    def _read_from_file(filename):
        with open(filename, 'r') as f:
            return f.read()

    def _test_shell_logger(shell, data):
        tmpdir = tempfile.mkdtemp()
        filename = os.path.join(tmpdir, 'test.log')
        _write_to_file(filename, data)
        subprocess.call([shell, '-c', 'from shell_logger import shell_logger; shell_logger("%s")' % filename])
        time.sleep(1)
        result = _read_

# Generated at 2022-06-18 07:10:52.606052
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        subprocess.Popen(['python', '-m', 'pyshell.logs', 'shell_logger', f.name])
        time.sleep(1)
        assert b'\x00' * const.LOG_SIZE_IN_BYTES == f.read()

# Generated at 2022-06-18 07:11:00.768384
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:11:10.189006
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'test_shell_logger')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.temp_file)
            self.assertTrue(os.path.isfile(self.temp_file))

    unittest.main()

# Generated at 2022-06-18 07:11:20.157275
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import re

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'log')

# Generated at 2022-06-18 07:11:29.463435
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function.
    """
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(shell_command):
        """
        Test for shell_logger function.
        """
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 07:11:35.790240
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time

    try:
        tmpdir = tempfile.mkdtemp()
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-18 07:11:43.169778
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        # Create temporary directory
        tmp_dir = tempfile.mkdtemp()
        os.chdir(tmp_dir)

        # Create temporary file
        tmp_file = tempfile.NamedTemporaryFile(delete=False)
        tmp_file.close()

        # Create temporary script
        tmp_script = tempfile.NamedTemporaryFile(mode='w', delete=False)
        tmp_script.write("""#!/bin/sh
echo "test"
""")
        tmp_script.close()
        os.chmod(tmp_script.name, 0o755)

        # Create temporary shell

# Generated at 2022-06-18 07:11:54.521177
# Unit test for function shell_logger
def test_shell_logger():
    """Test function shell_logger"""
    import tempfile
    import shutil
    import time
    import subprocess

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger.log')

# Generated at 2022-06-18 07:12:05.147829
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import mmap
    import sys
    import signal

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)
        return data

    def _set_pty_size(master_fd):
        buf = array.array('h', [0, 0, 0, 0])
        fc

# Generated at 2022-06-18 07:12:15.816144
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    # Create temporary script
    temp_script = tempfile.NamedTemporaryFile(delete=False)
    temp_script.write(b'#!/bin/bash\n')
    temp_script.write(b'echo "Hello world!"\n')
    temp_script.write(b'echo "Hello world!"\n')
    temp_script.write(b'echo "Hello world!"\n')

# Generated at 2022-06-18 07:12:35.826916
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '-s', '1', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '-s', '1', '-c', '1', output])
        assert return_code == 0


# Generated at 2022-06-18 07:12:42.950970
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')

    # Create temporary log file
    temp_log_file = os.path.join(temp_dir, 'temp_log_file')

    # Create temporary file
    with open(temp_file, 'w') as f:
        f.write('Hello World!')

    # Create temporary log file
    with open(temp_log_file, 'w') as f:
        f.write('Hello World!')

    # Run shell_logger

# Generated at 2022-06-18 07:12:50.252694
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import os
    import subprocess
    import shutil

    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, 'log')

    def _test_shell_logger(command):
        proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.wait()
        return proc.returncode

    def _test_shell_logger_with_log(command):
        proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.wait()
        with open(output) as f:
            return proc.returncode, f.read()

   

# Generated at 2022-06-18 07:13:00.430714
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(command):
        with tempfile.NamedTemporaryFile() as f:
            subprocess.call(['python', '-m', 'pwnlib.log', f.name, command])
            f.seek(0)
            return f.read()

    def _test_shell_logger_with_size(command, size):
        with tempfile.NamedTemporaryFile() as f:
            subprocess.call(['python', '-m', 'pwnlib.log', f.name, str(size), command])
            f.seek(0)
            return f.read()


# Generated at 2022-06-18 07:13:09.911377
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess

    try:
        tmpdir = tempfile.mkdtemp()
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
    except SystemExit:
        pass
    finally:
        shutil.rmtree(tmpdir)

    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    assert subprocess.call(['grep', '-q', 'test', output]) == 0

# Generated at 2022-06-18 07:13:16.393200
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest
    import subprocess

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'shell.log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            subprocess.call(['python', '-m', 'shell_logger', self.log_file])
            self.assertTrue(os.path.exists(self.log_file))

    unittest.main()

# Generated at 2022-06-18 07:13:26.797952
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _check_log(log_file, expected_log):
        with open(log_file, 'rb') as f:
            assert f.read() == expected_log

    def _check_log_with_delay(log_file, expected_log):
        time.sleep(1)
        _check_log(log_file, expected_log)

    def _check_log_with_delay_and_clean(log_file, expected_log):
        time.sleep(1)
        _check_log(log_file, expected_log)
        os.remove(log_file)

    def _check_log_with_delay_and_clean_and_exit(log_file, expected_log):
        _check_log_with_delay_

# Generated at 2022-06-18 07:13:38.423193
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        try:
            shell_logger(output)
        except SystemExit:
            pass

    def _test_shell_logger_with_input(output, input):
        try:
            shell_logger(output)
        except SystemExit:
            pass

    def _test_shell_logger_with_input_and_output(output, input, expected):
        try:
            shell_logger(output)
        except SystemExit:
            pass


# Generated at 2022-06-18 07:13:46.794656
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import random

    def _test_shell_logger(shell):
        logs.info("Testing shell logger with shell: %s" % shell)

        temp_dir = tempfile.mkdtemp()
        output = os.path.join(temp_dir, 'output')

        # Run shell logger
        process = subprocess.Popen([shell, '-c', 'import sys; sys.path.append("%s"); import shell_logger; shell_logger.shell_logger("%s")' % (os.path.dirname(__file__), output)])

        # Wait for shell logger to start
        time.sleep(1)

        # Write some random data to stdin
        for i in range(10):
            os.write

# Generated at 2022-06-18 07:13:56.085530
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import time
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')
    try:
        shell_logger(tmp_file)
    except SystemExit:
        pass
    time.sleep(1)
    assert os.path.exists(tmp_file)
    assert os.path.getsize(tmp_file) == const.LOG_SIZE_IN_BYTES
    with open(tmp_file, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:14:14.880789
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_file = os.path.join(self.tmp_dir, 'test_shell_logger')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.tmp_file)
            self.assertTrue(os.path.exists(self.tmp_file))

    unittest.main()

# Generated at 2022-06-18 07:14:26.298732
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:14:37.503248
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    from . import logs
    from . import const

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log.txt')
            self.log_file_size = const.LOG_SIZE_IN_BYTES
            self.log_file_size_to_clean = const.LOG_SIZE_TO_CLEAN
            self.log_file_size_to_write = self.log_file_size - self.log_file_size_to_clean

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

# Generated at 2022-06-18 07:14:39.590558
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    assert shell_logger('/tmp/shell_logger_test') == 0

# Generated at 2022-06-18 07:14:46.234535
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess
    import shutil
    import os
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:14:57.814082
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess

    def _test_shell_logger(shell):
        temp_dir = tempfile.mkdtemp()
        try:
            output = os.path.join(temp_dir, 'output')
            os.environ['SHELL'] = shell
            shell_logger(output)
            with open(output, 'rb') as f:
                data = f.read()
            assert data == b'\x00' * const.LOG_SIZE_IN_BYTES
        finally:
            shutil.rmtree(temp_dir)

    _test_shell_logger('/bin/bash')
    _test_shell_logger('/bin/sh')
    _test_shell_logger('/bin/zsh')

    # Test for non

# Generated at 2022-06-18 07:15:04.893431
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output(output):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error(output):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error_and_exit(output):
        shell_logger(output)


# Generated at 2022-06-18 07:15:13.596804
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        with open(output, 'wb') as f:
            f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

        fd = os.open(output, os.O_RDWR)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:15:22.822194
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.tmp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:15:29.926079
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'logs.shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output, size):
        return_code = subprocess.call(['python', '-m', 'logs.shell_logger', output, size])
        assert return_code == 0

    def _test_shell_logger_with_size_and_offset(output, size, offset):
        return_code = subprocess.call(['python', '-m', 'logs.shell_logger', output, size, offset])
        assert return_code == 0


# Generated at 2022-06-18 07:15:48.864104
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:15:56.277384
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:16:05.736411
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            proc = subprocess.Popen(['python', '-m', 'shell_logger', self.output])
            time.sleep(1)
            proc.send_signal(signal.SIGINT)
            proc.wait()

# Generated at 2022-06-18 07:16:14.043855
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    log_file = os.path.join(temp_dir, 'log')

    def run_shell_logger():
        subprocess.Popen(['python', '-m', 'shell_logger', log_file])

    run_shell_logger()
    time.sleep(1)
    os.kill(os.getpid(), signal.SIGINT)
    time.sleep(1)
    run_shell_logger()
    time.sleep(1)
    os.kill(os.getpid(), signal.SIGINT)
    time.sleep(1)


# Generated at 2022-06-18 07:16:18.539166
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_exception(output):
        try:
            shell_logger(output)
        except Exception as e:
            print(e)

    def _test_shell_logger_with_exception_and_exit(output):
        try:
            shell_logger(output)
        except Exception as e:
            print(e)
            sys.exit(1)

    def _test_shell_logger_with_exception_and_exit_and_logs(output):
        try:
            shell_logger(output)
        except Exception as e:
            print(e)

# Generated at 2022-06-18 07:16:27.861518
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'log')

    def _test_shell_logger():
        shell_logger(tmp_file)

    proc = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); from . import shell_logger; shell_logger.test_shell_logger()'],
                            stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            cwd=os.path.dirname(__file__))

    time.sleep(1)

# Generated at 2022-06-18 07:16:38.081556
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'from shell_logger import shell_logger; shell_logger("%s")' % f.name])
        time.sleep(0.5)
        os.kill(p.pid, signal.SIGWINCH)
        time.sleep(0.5)
        os.kill(p.pid, signal.SIGTERM)
        p.wait()

        assert os.path.getsize(f.name) > 0

# Generated at 2022-06-18 07:16:47.842403
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output')
        return_

# Generated at 2022-06-18 07:16:48.597083
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: write unit test
    pass

# Generated at 2022-06-18 07:16:58.073685
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    from . import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')
            logs.set_logger('shell_logger', self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            logs.info('test')
            with open(self.output, 'rb') as f:
                self.assertEqual(f.read().strip(), b'test')

    unittest.main()

# Generated at 2022-06-18 07:17:15.980226
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil
    import os

    def _test_shell_logger(output):
        def _test_shell_logger_inner():
            shell_logger(output)

        return _test_shell_logger_inner

    def _test_shell_logger_with_pty(output):
        def _test_shell_logger_with_pty_inner():
            p = subprocess.Popen(['python', '-m', 'pwnlib.logger', '-f', output],
                                 stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 shell=True)
            p.stdin.write(b'echo "test"\n')

# Generated at 2022-06-18 07:17:26.252179
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '--size', '1', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '--size', '1', '--clean', '1', output])
        assert return_code == 0
