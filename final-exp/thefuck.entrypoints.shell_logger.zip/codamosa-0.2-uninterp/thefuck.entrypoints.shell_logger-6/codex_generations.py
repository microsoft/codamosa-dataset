

# Generated at 2022-06-18 07:07:39.149890
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time

    def _read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def _write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def _write_file_with_size(path, size):
        with open(path, 'wb') as f:
            f.write(b'\x00' * size)

    def _get_file_size(path):
        return os.stat(path).st_size

    def _get_file_size_in_bytes(path):
        return os.stat(path).st_size * os.stat(path).st_blksize


# Generated at 2022-06-18 07:07:44.169038
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            time.sleep(1)
            with open(self.output, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:07:50.957144
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import tempfile

    def _test_shell_logger(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    with tempfile.NamedTemporaryFile() as f:
        _test_shell_logger(f.name)
        time.sleep(1)
        assert os.path.getsize(f.name) > 0

# Generated at 2022-06-18 07:08:02.245314
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import signal

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:08:13.876456
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function.
    """
    import tempfile
    import shutil
    import subprocess
    import time

    def test_logger(output):
        """
        Test for shell_logger function.
        """
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:08:24.088617
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_shell_logger(self):
            process = subprocess.Popen(['python', '-m', 'shell_logger', self.output])
            time.sleep(1)
            process.terminate()
            process.wait()

# Generated at 2022-06-18 07:08:29.689461
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import mmap
    import sys

    def _read_file(filename):
        with open(filename, 'r') as f:
            return f.read()

    def _read_mmap(filename):
        with open(filename, 'r') as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            return mm.read()

    def _test_shell_logger(shell, output):
        with open(output, 'w') as f:
            f.write('\x00' * const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-18 07:08:41.342628
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        return return_code


# Generated at 2022-06-18 07:08:50.000666
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import subprocess
    import tempfile
    import time
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'log.txt')

    # Run shell_logger in a subprocess
    p = subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', tmp_file])

    # Wait for the subprocess to start
    time.sleep(1)

    # Send some commands to the subprocess
    os.system('echo "test1" > /dev/pts/1')
    os.system('echo "test2" > /dev/pts/1')

    # Wait for the subprocess to finish

# Generated at 2022-06-18 07:08:59.916158
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function
    """
    import subprocess
    import time
    from .. import logs
    from .. import const
    import os
    import mmap

    logs.set_level(logs.DEBUG)
    logs.debug("Test shell_logger")

    # Create a file for test
    fd = os.open("test_shell_logger.txt", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

    # Create a subprocess to test shell_logger


# Generated at 2022-06-18 07:09:13.698996
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os
    import shutil
    import re

    def _get_log_file_size(log_file):
        return os.stat(log_file).st_size

    def _get_log_file_content(log_file):
        with open(log_file, 'r') as f:
            return f.read()

    def _get_log_file_content_size(log_file):
        return len(_get_log_file_content(log_file))

    def _get_log_file_content_lines(log_file):
        return _get_log_file_content(log_file).splitlines()


# Generated at 2022-06-18 07:09:24.149838
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:09:31.958028
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.log')

    def run_shell_logger():
        subprocess.call(['python', '-m', 'shell_logger', tmp_file])

    proc = subprocess.Popen(['python', '-m', 'shell_logger', tmp_file])
    time.sleep(1)
    proc.terminate()

    assert os.path.getsize(tmp_file) > 0

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:09:43.314857
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import sys

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'shell.log')

    def _test_shell_logger():
        shell_logger(tmp_file)


# Generated at 2022-06-18 07:09:54.879929
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Run shell_logger
    subprocess.Popen(['python', '-m', 'pwnlib.log', 'shell_logger', temp_file.name])

    # Wait for shell_logger to start
    time.sleep(1)

    # Write to the shell
    subprocess.Popen(['echo', 'hello'])

    # Wait for shell_logger to finish
    time.sleep(1)

    # Read the output

# Generated at 2022-06-18 07:10:04.869923
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _get_output(output):
        with open(output, 'rb') as f:
            return f.read()

    def _get_output_size(output):
        return os.stat(output).st_size

    def _get_output_content(output):
        return _get_output(output).decode('utf-8').strip()

    def _get_output_tail(output):
        return _get_output_content(output)[-const.LOG_SIZE_TO_CLEAN:]

    def _get_output_head(output):
        return _get_output_content(output)[:const.LOG_SIZE_TO_CLEAN]

    def _get_output_middle(output):
        return _get_output_

# Generated at 2022-06-18 07:10:15.907068
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:10:21.999518
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil

    def _test(output):
        shell_logger(output)

    with tempfile.TemporaryDirectory() as temp_dir:
        output = os.path.join(temp_dir, 'output')
        _test(output)
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:10:28.555615
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class ShellLoggerTest(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:10:38.366208
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import time

    def _test_shell_logger(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_with_empty_output(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_with_empty_shell(output):
        os.environ['SHELL'] = ''
        shell_logger(output)

    def _test_shell_logger_with_empty_shell_and_empty_output(output):
        os.environ['SHELL'] = ''
        shell_logger(output)


# Generated at 2022-06-18 07:10:56.435628
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import time
    import unittest

    from .. import logs
    from .. import const

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.output = 'shell_logger.test'
            self.fd = os.open(self.output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
            os.write(self.fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
            self.buffer = mmap.mmap(self.fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

        def tearDown(self):
            self.buffer.close()

# Generated at 2022-06-18 07:11:09.153755
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_args(output, args):
        shell_logger(output)

    def _test_shell_logger_with_args_and_env(output, args, env):
        shell_logger(output)

    def _test_shell_logger_with_args_and_env_and_cwd(output, args, env, cwd):
        shell_logger(output)

    def _test_shell_logger_with_args_and_env_and_cwd_and_shell(output, args, env, cwd, shell):
        shell_logger(output)


# Generated at 2022-06-18 07:11:18.723309
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_input(output, input):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output(output, input, output_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error(output, input, output_file, error_file):
        shell_logger(output)

    def _test_shell_logger_with_input_and_output_and_error_and_return_code(output, input, output_file, error_file, return_code):
        shell_logger(output)



# Generated at 2022-06-18 07:11:28.258401
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    def _test_shell_logger(output):
        subprocess.call(['python', '-m', 'shell_logger', output])

    def _test_shell_logger_with_input(output, input):
        subprocess.call(['python', '-m', 'shell_logger', output], input=input)

    def _test_shell_logger_with_input_and_timeout(output, input, timeout):
        subprocess.call(['python', '-m', 'shell_logger', output], input=input, timeout=timeout)

    def _test_shell_logger_with_timeout(output, timeout):
        subprocess.call(['python', '-m', 'shell_logger', output], timeout=timeout)



# Generated at 2022-06-18 07:11:39.041107
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function.
    """
    import subprocess
    import time
    import os
    import shutil
    import tempfile
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file name
    tmpfilename = tmpfile.name
    # Close the temporary file
    tmpfile.close()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file name
    tmpfilename2 = tmpfile.name
    # Close the temporary file
    tmpfile.close()

    # Create a temporary file

# Generated at 2022-06-18 07:11:49.393829
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile

    def _test_shell_logger(output):
        shell_logger(output)

    def _test_shell_logger_with_exception(output):
        try:
            shell_logger(output)
        except Exception:
            pass

    def _test_shell_logger_with_exception_and_cleanup(output):
        try:
            shell_logger(output)
        except Exception:
            pass
        finally:
            os.remove(output)

    def _test_shell_logger_with_cleanup(output):
        shell_logger(output)
        os.remove(output)


# Generated at 2022-06-18 07:12:00.099453
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import mmap

    def get_output(output):
        with open(output, 'r') as f:
            return f.read()

    def get_output_mmap(output):
        with open(output, 'r') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    def get_output_size(output):
        return os.stat(output).st_size

    def get_output_size_mmap(output):
        with open(output, 'r') as f:
            return mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ).size()


# Generated at 2022-06-18 07:12:10.658378
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import sys
    import signal
    import mmap
    import pty
    import termios
    import tty
    import array
    import fcntl

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)
        return data


# Generated at 2022-06-18 07:12:19.522740
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '-s', '1', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '-s', '1', '-c', '1', output])
        assert return_code == 0


# Generated at 2022-06-18 07:12:32.178704
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap

    def _get_output(output):
        fd = os.open(output, os.O_RDONLY)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)
        return buffer.read(const.LOG_SIZE_IN_BYTES)

    def _test_shell_logger(output):
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            subprocess.run(['python', '-m', 'shell_logger', output])
            time.sleep(1)
            return _get_output(output)


# Generated at 2022-06-18 07:12:48.132432
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import time
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')
    shell_logger(output)
    time.sleep(1)
    subprocess.call(['echo', 'hello'])
    time.sleep(1)
    subprocess.call(['echo', 'world'])
    time.sleep(1)
    subprocess.call(['echo', '!'])
    time.sleep(1)
    subprocess.call(['echo', 'hello'])
    time.sleep(1)
    subprocess.call(['echo', 'world'])
    time.sleep(1)
    subprocess.call(['echo', '!'])
    time.sleep(1)

# Generated at 2022-06-18 07:12:59.237883
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for shell_logger"""
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        """Unit test for shell_logger"""

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            """Unit test for shell_logger"""
            shell_logger(self.output)
            self.assertTrue(os.path.isfile(self.output))
            self.assertTrue(os.path.getsize(self.output) > 0)

    un

# Generated at 2022-06-18 07:13:03.698104
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:13:11.887076
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import os

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python3', '-c', 'from ptylogger import shell_logger; shell_logger("{}")'.format(f.name)])
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        f.seek(0)
        assert f.read() != b'\x00' * const.LOG_SIZE_IN_BYTES
        os.remove(f.name)

# Generated at 2022-06-18 07:13:21.163632
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.log_file)
            with open(self.log_file, 'rb') as f:
                self.assertTrue(f.read())

    unittest.main()

# Generated at 2022-06-18 07:13:29.142802
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import io

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_input(output, input):
        return_code = subprocess.call(['python', '-m', 'pwnlib.log', 'shell_logger', output], stdin=input)
        assert return_code == 0


# Generated at 2022-06-18 07:13:37.793504
# Unit test for function shell_logger
def test_shell_logger():
    """
    Unit test for function shell_logger
    """
    import tempfile
    import shutil
    import subprocess
    import time

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'test_shell_logger.log')
    try:
        subprocess.Popen([sys.executable, '-m', 'pwnlib.log', '-o', temp_file])
        time.sleep(1)
        with open(temp_file, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:13:46.352697
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import subprocess
    import time
    import shutil
    import mmap
    import select
    import signal
    import sys
    import pty
    import termios
    import tty
    import array
    import fcntl

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)
        return data

   

# Generated at 2022-06-18 07:13:56.508279
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'log')
    try:
        subprocess.check_call(['python', '-c', 'import sys; sys.path.insert(0, ".."); import shell_logger; shell_logger.shell_logger("%s")' % temp_file], shell=True)
        time.sleep(1)
        with open(temp_file, 'rb') as f:
            assert f.read().count(b'\x00') == shell_logger.const.LOG_SIZE_IN_BYTES - 1
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-18 07:14:06.266291
# Unit test for function shell_logger

# Generated at 2022-06-18 07:14:33.069488
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test for shell_logger function.
    """
    import os
    import time
    import tempfile
    import shutil
    import subprocess

    def get_file_size(file_path):
        """
        Get file size in bytes.
        """
        return os.path.getsize(file_path)

    def get_file_content(file_path):
        """
        Get file content.
        """
        with open(file_path, 'rb') as f:
            return f.read()

    def get_file_content_from_offset(file_path, offset):
        """
        Get file content from offset.
        """
        with open(file_path, 'rb') as f:
            f.seek(offset)
            return f.read()


# Generated at 2022-06-18 07:14:42.698254
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    tmpdir = tempfile.mkdtemp()
    try:
        output = os.path.join(tmpdir, 'output')
        shell_logger(output)
    finally:
        shutil.rmtree(tmpdir)

    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    with open(output, 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    with open(output, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-18 07:14:52.911680
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.output = tempfile.mktemp()

        def tearDown(self):
            os.remove(self.output)

        def test_shell_logger(self):
            shell_logger(self.output)
            time.sleep(1)
            with open(self.output, 'rb') as f:
                f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
                self.assertTrue(f.read().startswith(b'\x00' * const.LOG_SIZE_TO_CLEAN))

    unittest.main()

# Generated at 2022-06-18 07:15:02.571514
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import tempfile
    import subprocess
    import shutil

    def _test_shell_logger(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)

    def _test_shell_logger_with_env(output):
        os.environ['SHELL'] = '/bin/bash'
        os.environ['TEST_ENV'] = 'TEST_ENV'
        shell_logger(output)

    def _test_shell_logger_with_command(output):
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(output)


# Generated at 2022-06-18 07:15:11.073841
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import shutil

    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output')
        subprocess.Popen(['python', '-m', 'shell_logger', output])
        time.sleep(1)
        subprocess.Popen(['echo', 'test'])
        time.sleep(1)
        subprocess.Popen(['exit'])
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
        shutil.rmtree(tmpdirname)

# Generated at 2022-06-18 07:15:22.260550
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:15:29.651139
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import time
    import subprocess
    import sys
    import shutil

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)


# Generated at 2022-06-18 07:15:37.173926
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, 'output')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_shell_logger(self):
            shell_logger(self.output)
            self.assertTrue(os.path.exists(self.output))

    unittest.main()

# Generated at 2022-06-18 07:15:47.095577
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import shutil
    import subprocess
    import time
    import mmap
    import sys

    def get_output_size(output):
        with open(output, 'r+') as f:
            mm = mmap.mmap(f.fileno(), 0)
            return mm.size()

    def get_output_content(output):
        with open(output, 'r+') as f:
            mm = mmap.mmap(f.fileno(), 0)
            return mm.read()

    def get_output_content_from_offset(output, offset):
        with open(output, 'r+') as f:
            mm = mmap.mmap(f.fileno(), 0)
            mm.seek(offset)
            return mm.read()


# Generated at 2022-06-18 07:15:56.772151
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import re

    def _get_log_content(log_file):
        with open(log_file, 'rb') as f:
            return f.read()

    def _get_log_content_without_null_bytes(log_file):
        return re.sub(b'\x00', b'', _get_log_content(log_file))

    def _get_log_content_without_null_bytes_and_new_lines(log_file):
        return re.sub(b'\x00|\n', b'', _get_log_content(log_file))

    def _get_log_content_without_null_bytes_and_new_lines_and_spaces(log_file):
        return

# Generated at 2022-06-18 07:16:22.667691
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import shutil
    import tempfile
    import subprocess
    import unittest
    import unittest.mock

    from .. import logs

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.log_file = os.path.join(self.temp_dir, 'log.txt')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-18 07:16:30.852829
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess

    def _check_file_content(file_path, expected_content):
        with open(file_path, 'rb') as f:
            content = f.read()
        assert content == expected_content

    def _check_file_size(file_path, expected_size):
        assert os.path.getsize(file_path) == expected_size

    def _check_file_content_and_size(file_path, expected_content, expected_size):
        _check_file_content(file_path, expected_content)
        _check_file_size(file_path, expected_size)

    def _check_file_content_and_size_on_timeout(file_path, expected_content, expected_size, timeout):
        start_

# Generated at 2022-06-18 07:16:38.436954
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time
    import os

    tmp_dir = tempfile.mkdtemp()
    output = os.path.join(tmp_dir, 'output')

    try:
        subprocess.Popen(['python', '-m', 'shell_logger', output])
        time.sleep(1)
        with open(output, 'rb') as f:
            assert f.read()
    finally:
        shutil.rmtree(tmp_dir)

# Generated at 2022-06-18 07:16:48.150069
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    def run_shell_logger(output):
        return subprocess.call(['python', '-m', 'shell_logger', output])

    def read_file(path):
        with open(path, 'rb') as f:
            return f.read()

    def write_file(path, data):
        with open(path, 'wb') as f:
            f.write(data)

    def test_shell_logger_with_file(path):
        write_file(path, b'\x00' * const.LOG_SIZE_IN_BYTES)
        assert run_shell_logger(path) == 0
        assert read_file(path) == b'\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-18 07:16:57.919137
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    import time

    def _test_shell_logger(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', output])
        assert return_code == 0

    def _test_shell_logger_with_size(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '--size', '1', output])
        assert return_code == 0

    def _test_shell_logger_with_size_and_clean(output):
        return_code = subprocess.call(['python', '-m', 'shell_logger', '--size', '1', '--clean', '1', output])
        assert return_code == 0


# Generated at 2022-06-18 07:17:09.979924
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    import subprocess
    import os

    def _test_shell_logger(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        return return_code


# Generated at 2022-06-18 07:17:18.678165
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import os
    import subprocess
    import time
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(os.path.join(tmpdir, 'test.txt'), 'w')
    f.write('test')
    f.close()

    # Change to the temporary directory
    os.chdir(tmpdir)

    # Create a subprocess
    p = subprocess.Popen(['python', '-c', 'import shell_logger; shell_logger.shell_logger("test.txt")'],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Wait for the subprocess to

# Generated at 2022-06-18 07:17:26.249853
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        p = subprocess.Popen(['python', '-c', 'import sys; sys.path.append(".."); import shell; shell.shell_logger("%s")' % f.name])
        time.sleep(1)
        p.send_signal(signal.SIGINT)
        p.wait()
        f.seek(0)
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES