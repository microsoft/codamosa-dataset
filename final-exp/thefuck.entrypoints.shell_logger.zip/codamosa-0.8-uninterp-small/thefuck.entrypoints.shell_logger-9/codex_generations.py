

# Generated at 2022-06-26 05:01:43.886146
# Unit test for function shell_logger
def test_shell_logger():
    import request
    import os
    result = shell_logger(request.get_value("output"))
    assert os.path.isfile("/tmp/logs_tmp.txt")
    assert result == os.path.isfile("/tmp/logs_tmp.txt")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:01:46.069698
# Unit test for function shell_logger
def test_shell_logger():
    assert True
    print('Function "test_shell_logger" passed')



# Generated at 2022-06-26 05:01:54.873849
# Unit test for function shell_logger
def test_shell_logger():
    global bytes_0

    # local variables
    bytes_0 = None

    # Initialize test suite
    logs.log_test('Function shell_logger')

    # Initialize test case
    logs.log_test('Unit test for function shell_logger - case 0')
    test_case_0()

    # Finalize test suite
    logs.log_test('End of unit test for function shell_logger')
    logs.log_test_suite()

# Generated at 2022-06-26 05:01:56.737174
# Unit test for function shell_logger
def test_shell_logger():
    value_0 = b'\x12\\Y\xec$\x8e'
    test_case_0()


import inspect

# Generated at 2022-06-26 05:02:06.805626
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('tests/data/output_shell_logger.txt')
    f = open('tests/data/expected_output_shell_logger.txt', 'r')
    f1 = open('tests/data/output_shell_logger.txt', 'r')
    assert f1.read().strip() == f.read().strip()
    f.close()
    f1.close()


if __name__ == "__main__":
    for func in [
        test_case_0,
    ]:
        print(func.__name__)
        func()

# Generated at 2022-06-26 05:02:13.102618
# Unit test for function shell_logger
def test_shell_logger():
    arg0 = ('test')
    ret0 = shell_logger(arg0)
    return ret0

# End of unit tests

if __name__ == "__main__":
    import sys
    ret = test_shell_logger()
    sys.exit(ret)

# Generated at 2022-06-26 05:02:16.739485
# Unit test for function shell_logger
def test_shell_logger():
    assert(shell_logger(b'\x7F') == "")
    assert(shell_logger(b'\x80') == "")

# Test bench
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 05:02:20.639492
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        print("Function shell_logger threw an exception.")


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:22.641853
# Unit test for function shell_logger
def test_shell_logger():
    print ('Test for function "shell_logger" is not implemented yet.')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:02:24.865878
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:35.670992
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('output')

if __name__ == '__main__':
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:02:37.026374
# Unit test for function shell_logger
def test_shell_logger():
    assert False

# Test: shell_logger

# Generated at 2022-06-26 05:02:40.649035
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger("./tmp")
    except Exception as e:
        print("Test case 0 failed")
        print(e)

# Unit tests
if __name__ == '__main__':
    test_shell_logger()
    test_case_0()

# Generated at 2022-06-26 05:02:52.151272
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    # Test 0: 

    def _read(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)

        return data
        # /Test 0: 


# Generated at 2022-06-26 05:02:54.448550
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(test_case_0()) == None

# Test file for function shell_logger

# Generated at 2022-06-26 05:02:56.702751
# Unit test for function shell_logger
def test_shell_logger():
    # Test root
    shell_logger(__file__)


# Generated at 2022-06-26 05:03:01.209807
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./output')
    f = open('./output', 'rb')
    output_0 = f.read()
    assert(output_0 == bytes_0)
    f.close()
    os.remove('./output')

# Test shell_logger function
test_shell_logger()

# Generated at 2022-06-26 05:03:03.121772
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:03:06.841966
# Unit test for function shell_logger
def test_shell_logger():
    output = "/vagrant/test_data/test_shell_logger.txt"
    shell_logger(output)

# Generated at 2022-06-26 05:03:14.716470
# Unit test for function shell_logger
def test_shell_logger():
    
    # Create a dummy environment variable to enable testing
    os.environ['SHELL'] = 'test.sh'

    # Create a dummy shell script in the current directory
    fd = open('test.sh', 'w')
    fd.close()

    # Create test subdirectory
    if not os.path.exists('test'):
        os.makedirs('test')

    # Test function
    shell_logger('test/output.txt')

if __name__ == "__main__":
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:03:24.705850
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-26 05:03:27.267239
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == '__main__':
    test_shell_logger()
    print('shell_logger.py\n')

# Generated at 2022-06-26 05:03:30.750417
# Unit test for function shell_logger
def test_shell_logger():
    '''
    Unit test for function shell_logger
    '''
    logs.clean()
    test_case_0()

# Generated at 2022-06-26 05:03:34.666539
# Unit test for function shell_logger
def test_shell_logger():
    filename = "test.txt"
    test_case_0()
    if os.path.exists(filename):
        os.remove(filename)
    else:
        print("Error: %s file not found" % filename)


# Generated at 2022-06-26 05:03:39.296375
# Unit test for function shell_logger
def test_shell_logger():
    print("Testing function shell_logger")
    print("Insufficient test coverage")
    test_case_0()


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 1:
        test_shell_logger()
    else:
        print("No tests")

# Generated at 2022-06-26 05:03:42.915729
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test')

# Generated at 2022-06-26 05:03:45.387927
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger("/tmp/test_dir/test_file")
    assert var_0 is None


# Generated at 2022-06-26 05:03:47.101325
# Unit test for function shell_logger
def test_shell_logger():
    """
    Usage: python3 test_shell_logger.py
    """
    test_case_0()

# Generated at 2022-06-26 05:03:48.752470
# Unit test for function shell_logger
def test_shell_logger():
    logger = shell_logger(b'/tmp/shell_logger_test.txt')

# Generated at 2022-06-26 05:03:52.224451
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)


# vim: set filetype=python :

# Generated at 2022-06-26 05:04:03.206062
# Unit test for function shell_logger
def test_shell_logger():
    # Test case 0
    test_case_0()

# Main
if __name__ == "__main__":
    logs.init()
    test_shell_logger()

# Generated at 2022-06-26 05:04:11.620932
# Unit test for function shell_logger
def test_shell_logger():
    data_to_log = "a" * 100000
    try:
        fd = os.open('test.log', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    except OSError:
        sys.exit(1)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    logger = partial(_read, buffer)
    logger(data_to_log)
    os.close(fd)

# Generated at 2022-06-26 05:04:21.031763
# Unit test for function shell_logger
def test_shell_logger():
    with open('test_cases/test_shell_logger.txt', 'r') as test_case_file:
        test_cases = test_case_file.read()
        if len(test_cases) == 0:
            print('No test cases found in the test file.')
            sys.exit(1)
        lines = test_cases.split('\n')
        number_of_test_cases = len(lines) / 6
        current_test_case = 0
        while current_test_case < number_of_test_cases:
            test_case_number = int(lines[0 + (current_test_case * 6)].split(' ')[1])
            test_case_input = lines[2 + (current_test_case * 6)].split(' ')[1]

# Generated at 2022-06-26 05:04:23.423685
# Unit test for function shell_logger
def test_shell_logger():
    return_code = test_case_0()
    if return_code != 0:
        print('Test Failed')
        return

    print('Test Succeeded')

# Generated at 2022-06-26 05:04:25.846472
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:04:27.536889
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 05:04:30.514239
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
        logs.info("Function shell_logger() works correctly.")
    except:
        logs.error("Function shell_logger() doesn't work correctly.")
        raise

# Generated at 2022-06-26 05:04:37.926548
# Unit test for function shell_logger
def test_shell_logger():
    import sys
    import unittest

    class Test_shell_logger(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.setup_tests()

        def setup_tests(self):
            # Test case 0
            def test_0():
                bytes_0 = b'\x12\\Y\xec$\x8e'
                self.assertEqual(shell_logger(bytes_0), 0)

            self.test_case_0 = test_0

    test_cases = [
        Test_shell_logger('test_case_0'),
    ]

    suite = unittest.TestSuite()

    for test_case in test_cases:
        suite

# Generated at 2022-06-26 05:04:40.439889
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile('w+b') as f:
        shell_logger(f.name)
        f.seek(0)
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-26 05:04:45.401420
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)
    # Test case 0
    assert True

# Main
if __name__ == '__main__':
    test_shell_logger()


# Mock for pty.fork

# Generated at 2022-06-26 05:05:09.315461
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open(b"/tmp/taco", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(b"ls", partial(_read, buffer))
    os.close(fd)
    return return_code

# Generated at 2022-06-26 05:05:10.558803
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('testfunc_shell_logger.txt') == 0

# Generated at 2022-06-26 05:05:15.392219
# Unit test for function shell_logger
def test_shell_logger():
    """Test case 0 for function shell_logger."""
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)



# Generated at 2022-06-26 05:05:21.548768
# Unit test for function shell_logger
def test_shell_logger():
    from unittest import mock
    from unittest.mock import call
    with mock.patch('shell_logger.os.environ') as patched:
        patched.get.return_value = "SHELL"

# Generated at 2022-06-26 05:05:22.459227
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/13271.shell')

# Generated at 2022-06-26 05:05:27.401089
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger.__code__
        shell_logger_code_flag = True
    except:
        shell_logger_code_flag = False
    assert shell_logger_code_flag == True # Function shell_logger has code

    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)


# Generated at 2022-06-26 05:05:28.354619
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('test') == 0

# Generated at 2022-06-26 05:05:32.817961
# Unit test for function shell_logger
def test_shell_logger():
    assert const.LOG_SIZE_TO_CLEAN == 1024
    test_case_0()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:05:34.798292
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger_test_case_0()


# Generated at 2022-06-26 05:05:38.739479
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:05:55.313921
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() is None, 'test_case_0 failed'

# Generated at 2022-06-26 05:05:59.214900
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        pass
    else:
        raise Exception("Unexpected exception")

# Unit test entry point
if __name__ == "__main__":
    try:
        test_shell_logger()
    except Exception as e:
        print("Caught an exception: " + str(e))

# Generated at 2022-06-26 05:06:02.123997
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)
    assert isinstance(var_0, int)

# Test for function shell_logger with valid test case

# Generated at 2022-06-26 05:06:05.322969
# Unit test for function shell_logger
def test_shell_logger():
    if sys.platform != 'linux':
        logs.warn("shell_logger doesn't support your platform.")
        return
    os.environ['SHELL'] = '/bin/bash'
    test_case_0()
    print('Unit test for function shell_logger - ok')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:06:07.042260
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('test_shell_logger_output.data') is None, 'Return value was incorrect'


# Generated at 2022-06-26 05:06:10.821964
# Unit test for function shell_logger
def test_shell_logger():
    import unittest

    class TestShellLogger(unittest.TestCase):

        def test_0(self):
            bytes_0 = b'\x12\\Y\xec$\x8e'
            var_0 = shell_logger(bytes_0)


    unittest.main()

# Generated at 2022-06-26 05:06:16.210016
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as err:
        logs.debug(err)
        return 1
    return 0

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:06:21.398884
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(b'\x12\\Y\xec$\x8e') == 0

if __name__ == '__main__':
    print('[+] Is shell_logger vulnerable to format string attack?')
    print('[-] No, shell_logger is not vulnerable to format string attack')

# Generated at 2022-06-26 05:06:26.062191
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        logs.exception_err_write()
        sys.exit(1)
    else:
        exitcode = 0
    sys.exit(exitcode)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:06:27.120626
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(b'example')



# Generated at 2022-06-26 05:07:00.767506
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() is not None, 'test_shell_logger() failed!'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 05:07:05.099038
# Unit test for function shell_logger
def test_shell_logger():
    args = ['shell_logger', 'shell_logger']
    if len(args) < 1:
        print('Usage: %s <noargs>' % args[0])
        sys.exit(1)
    test_case_0()


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:07:07.940504
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except NameError:
        print('No such test case')


# Generated at 2022-06-26 05:07:10.383566
# Unit test for function shell_logger
def test_shell_logger():
    tmp_file = tempfile.NamedTemporaryFile()
    try:
        test_case_0()
    finally:
        try:
            tmp_file.close()
        except OSError:
            pass

# Generated at 2022-06-26 05:07:11.306563
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(b'logs/shell.log')

# Generated at 2022-06-26 05:07:14.394373
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('output') == "Shell logger doesn't support your platform."

# Test case for shell_logger

# Generated at 2022-06-26 05:07:22.410818
# Unit test for function shell_logger
def test_shell_logger():
    # This function test if the match between the output and input
    import filecmp
    test_case_0()
    assert filecmp.cmp(b'/tmp/aa', b'/tmp/bb') is True
    print('Success: test_shell_logger')


# Execute unit tests
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:07:26.258575
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test-shell-logger')

# Generated at 2022-06-26 05:07:31.022183
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:07:31.733710
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/logs')

# Generated at 2022-06-26 05:08:03.689762
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('output') == 0

# Generated at 2022-06-26 05:08:04.805603
# Unit test for function shell_logger
def test_shell_logger():
    for i in range(10):
        test_case_0()



# Generated at 2022-06-26 05:08:06.968930
# Unit test for function shell_logger
def test_shell_logger():
    # Test positional arguments
    try:
        shell_logger(bytes_0 = b'\x12\\Y\xec$\x8e')
        
    except TypeError:
        pass


# Generated at 2022-06-26 05:08:07.631764
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:08:11.771069
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:08:15.238044
# Unit test for function shell_logger
def test_shell_logger():
    import random
    # Testcase 0
    try:
        test_case_0()
    except:
        assert False


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:08:19.604114
# Unit test for function shell_logger
def test_shell_logger():
    return_code = shell_logger(bytes_0)
    assert return_code == 0
    assert os.path.exists(bytes_0) == True

# Generated at 2022-06-26 05:08:20.174607
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-26 05:08:24.642672
# Unit test for function shell_logger
def test_shell_logger():
    filename0 = "tmp-shell_logger.txt"
    f = open(filename0, 'w')
    f.close()
    try:
        f = open(filename0, 'rb')
        f.read()
        f.close()
        test_case_0()
        f = open(filename0, 'rb')
        f.read()
        f.close()
    finally:
        os.remove(filename0)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:08:25.237985
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-26 05:09:00.124544
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except TypeError as e:
        logs.warn('Function shell_logger(output) raised {}.'.format(e))


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:09:00.894814
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0()

# Generated at 2022-06-26 05:09:06.767841
# Unit test for function shell_logger

# Generated at 2022-06-26 05:09:13.031521
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)
    assert var_0 == 0, 'AssertionError: {}'.format(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:09:15.694247
# Unit test for function shell_logger
def test_shell_logger():
    assert True == True

# Generated at 2022-06-26 05:09:18.317733
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(b'\x12\\Y\xec$\x8e')

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:09:20.299287
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger([object]) == 1
    assert shell_logger('W4E\xfb\x9a*') == 1
    assert shell_logger('\xeb\xfa\x8a\xf4') == 0

# Generated at 2022-06-26 05:09:23.815832
# Unit test for function shell_logger
def test_shell_logger():
    try:
        assert(shell_logger("/etc/passwd") == 0)
        assert(shell_logger("/etc/shadow") == 0)
    except BaseException as e:
        print("Error in test_shell_logger")
        print("Python says: " + str(e))


# Generated at 2022-06-26 05:09:30.676373
# Unit test for function shell_logger
def test_shell_logger():
    base_0 = shell_logger
    def chained(bytes_0): return base_0(bytes_0)
    try:
        chained(b'\x12\\Y\xec$\x8e')
        assert(False)
    except ValueError:
        pass
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:09:38.598380
# Unit test for function shell_logger

# Generated at 2022-06-26 05:10:42.793641
# Unit test for function shell_logger
def test_shell_logger():
    assert len(shell_logger(b'\x12\\\x9cJ\x0f\x0c')) == 6


# Generated at 2022-06-26 05:10:44.133213
# Unit test for function shell_logger
def test_shell_logger():
    pass

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:10:45.159220
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(b"\x12\\Y\xec$\x8e") == 0

# Generated at 2022-06-26 05:10:47.646949
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)
    assert var_0 == None


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:10:56.592798
# Unit test for function shell_logger
def test_shell_logger():
    buffer = b'\x00' * const.LOG_SIZE_IN_BYTES
    fd = os.open(shell_logger(b'\x00'), os.O_RDONLY)
    mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    if buffer == shell_logger(b'\x00'):
        pass
    else:
        print('[+] shell logger unit test success')



# Generated at 2022-06-26 05:11:06.724305
# Unit test for function shell_logger
def test_shell_logger():
    # Test of the edge cases.
    # That set the arg0 to b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = shell_logger(bytes_0)
    # That set the arg0 to b'\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01

# Generated at 2022-06-26 05:11:16.801724
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import random
    import string
    import os

    class Test(unittest.TestCase):

        def test_case_0(self):
            bytes_0 = b'/tmp/log-shell'
            fd = os.open(bytes_0, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
            os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
            buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
            shell_logger(buffer)

    unittest.main()

# Generated at 2022-06-26 05:11:24.041705
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(b'\x12\\Y\xec$\x8e') == None
    assert shell_logger(b'\xeb\x93\x90\xb9\x10\xac') == None
    assert shell_logger(b'\x10\xdd\xa2\x1b\x9b\xbc\xb1') == None
    assert shell_logger(b'\x12\\Y\xec$\x8e') == None
    assert shell_logger(b'\x18\x0b\xdd\x11f\xa1\x0b\xfa\xa7') == None

# Generated at 2022-06-26 05:11:27.258536
# Unit test for function shell_logger
def test_shell_logger():
    bytes_0 = b'\x12\\Y\xec$\x8e'
    var_0 = shell_logger(bytes_0)
    assert var_0 == -1

# Generated at 2022-06-26 05:11:28.448640
# Unit test for function shell_logger
def test_shell_logger():
    with pytest.raises(TypeError):
        test_case_0()