

# Generated at 2022-06-26 05:01:44.580865
# Unit test for function shell_logger
def test_shell_logger():
    assert 'SHELL_LOGGER' in globals(),\
        'The function shell_logger must be defined'


# Generated at 2022-06-26 05:01:45.851484
# Unit test for function shell_logger
def test_shell_logger():
    #test_case_0()
    pass

# Generated at 2022-06-26 05:01:47.766868
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:01:48.720141
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger()

# Generated at 2022-06-26 05:01:51.303828
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-26 05:01:54.405557
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as e:
        print(e)

test_shell_logger()

# Generated at 2022-06-26 05:02:00.527005
# Unit test for function shell_logger
def test_shell_logger():
    WIDTH = 80
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()


# Generated at 2022-06-26 05:02:01.316305
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(str_0) == return_code, "Function was not able to run"


# Generated at 2022-06-26 05:02:01.957928
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


# Generated at 2022-06-26 05:02:03.953373
# Unit test for function shell_logger
def test_shell_logger():
    for i in range(1):
        test_case_0()

# Generated at 2022-06-26 05:02:12.295902
# Unit test for function shell_logger
def test_shell_logger():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 05:02:13.768311
# Unit test for function shell_logger
def test_shell_logger():
    assert (shell_logger('output') == 0)

# Generated at 2022-06-26 05:02:16.380963
# Unit test for function shell_logger
def test_shell_logger():
    """
    >>> test_case_0()
    Traceback (most recent call last):
        ...
    SystemExit: 1
    """
    pass

# Generated at 2022-06-26 05:02:17.194277
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Main entry point for the file

# Generated at 2022-06-26 05:02:21.051452
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as e:
        logs.error(e)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:22.672776
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:02:23.777085
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:27.308160
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'test0'
    var_0 = shell_logger(str_0)
    str_1 = 'test1'
    var_1 = shell_logger(str_1)

# Generated at 2022-06-26 05:02:32.121468
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    logs.info("Done with unit test for function shell_logger")


# Generated at 2022-06-26 05:02:33.277914
# Unit test for function shell_logger
def test_shell_logger():
    assert True == True

# Generated at 2022-06-26 05:02:48.911077
# Unit test for function shell_logger
def test_shell_logger():
    try:
        import builtins
    except ImportError:
        import __builtin__ as builtins
    builtins.__dict__['__debug__'] = False
    test_case_0()


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:54.653105
# Unit test for function shell_logger
def test_shell_logger():
    str_1 = '#sn2f\rPSZmP'
    var_0 = shell_logger(str_1)
    assert var_0 == 0

# Generated at 2022-06-26 05:02:57.289162
# Unit test for function shell_logger
def test_shell_logger():
    str_v = 'WL34aX9c5'
    var_v = shell_logger(str_v)

# Generated at 2022-06-26 05:02:59.925146
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
    except:
        assert False



# Generated at 2022-06-26 05:03:00.900313
# Unit test for function shell_logger
def test_shell_logger():
    # Test case 0
    test_case_0()
    return


# Run unit tests

# Generated at 2022-06-26 05:03:02.113426
# Unit test for function shell_logger
def test_shell_logger():
    # Case 0
    test_case_0()



# Generated at 2022-06-26 05:03:03.573509
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() == 0

test_shell_logger()

# Generated at 2022-06-26 05:03:06.887369
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()



if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:03:09.352598
# Unit test for function shell_logger
def test_shell_logger():
    logs.info('Testing function shell_logger')
    test_case_0()

# Main function

# Generated at 2022-06-26 05:03:10.374044
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Functions for testing

# Generated at 2022-06-26 05:03:20.214001
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:03:22.446640
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:03:31.515440
# Unit test for function shell_logger
def test_shell_logger():
    import random
    import os
    import shlex

    runs = 100
    for i in range(runs):
        with open('file.txt', 'w') as h:
            h.write("")

        test_case_0()

        with open(os.path.expanduser("file.txt")) as f:
            data = f.readlines()

        try:
            assert data[0] == "#sn2f\n"
            assert data[1] == "PSZmP\n"
            assert len(data) == 2
        except:
            print("failed test {}".format(i))
            raise

# Generated at 2022-06-26 05:03:33.283793
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("huUHv2") == 0

# Generated at 2022-06-26 05:03:39.202258
# Unit test for function shell_logger
def test_shell_logger():

    # Test case 0
    # Normal usage
    test_case_0()

    # Test case 1
    # Test with correct output file
    str_0 = 'test.txt'
    var_0 = shell_logger(str_0)

    # Test case 2
    # Test with no output file
    str_0 = ''
    var_0 = shell_logger(str_0)

# Program entry point

# Generated at 2022-06-26 05:03:44.280153
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '#sn2f\rPSZmP'
    var_0 = shell_logger(str_0)


# Generated at 2022-06-26 05:03:46.269152
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(None)
    test_case_0()

# Generated at 2022-06-26 05:03:48.381851
# Unit test for function shell_logger
def test_shell_logger():
    print('Testing function shell_logger')
    test_case_0()


# Main function

# Generated at 2022-06-26 05:03:52.457762
# Unit test for function shell_logger
def test_shell_logger():
    # var.1
    try:
        str_0 = '#sn2f\rPSZmP'
        var_1 = shell_logger(str_0)
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-26 05:03:54.368325
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        logs.error("Test case failed")
        raise

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:04:12.541805
# Unit test for function shell_logger
def test_shell_logger():
    assert True


# Generated at 2022-06-26 05:04:18.344493
# Unit test for function shell_logger
def test_shell_logger():
    var_1 = '#sn2f\rPSZmP'
    var_0 = shell_logger(var_1)
    logs.info('==> .main() returned: {}'.format(var_0))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:04:23.292471
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'unit-test-0.txt'
    test_case_0()
    if not os.path.isfile(str_0):
        sys.exit(1)
    else:
        os.remove(str_0)


# Generated at 2022-06-26 05:04:30.588289
# Unit test for function shell_logger
def test_shell_logger():
    # Check if the environment is setup properly
    if __package__ is None:
        import sys
        from os import path
        sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
        from shell_logger import shell_logger

    try:
        # If this function raises an exception, the unit test fails
        test_case_0()
    except:
        return False

    return True

# Unit test

# Generated at 2022-06-26 05:04:36.464654
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '#sn2f\rPSZmP'
    var_0 = shell_logger(str_0)


if __name__ == '__main__':
    f = open('/tmp/logs.txt', 'w')

    import traceback
    import sys

    try:
        test_case_0()
    except Exception:
        f.write(traceback.format_exc())
    else:
        f.write('Done\n')

    f.close()
    sys.exit(0)

# Generated at 2022-06-26 05:04:37.777398
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


# Generated at 2022-06-26 05:04:39.052804
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:04:40.051521
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:04:41.682884
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:04:42.678583
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:05:01.961997
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:05:05.041235
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        return False
    return True

test_shell_logger()

# Generated at 2022-06-26 05:05:07.346020
# Unit test for function shell_logger
def test_shell_logger():
    str_1 = 'H\x04\tM%\t^W'
    var_1 = shell_logger(str_1)


# Generated at 2022-06-26 05:05:11.017972
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:05:14.859481
# Unit test for function shell_logger
def test_shell_logger():
    from . import func_shell_logger
    try:
        func_shell_logger
    except NameError:
        return

    test_case_0()

# Generated at 2022-06-26 05:05:18.404234
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        print("Test Failed")
    else:
        print("Test Passed")

test_shell_logger()

# Generated at 2022-06-26 05:05:19.649316
# Unit test for function shell_logger
def test_shell_logger():
    print('Start unit testing function shell_logger.')
    test_case_0()
    print('End unit testing function shell_logger.')

# Generated at 2022-06-26 05:05:32.172572
# Unit test for function shell_logger

# Generated at 2022-06-26 05:05:39.953846
# Unit test for function shell_logger
def test_shell_logger():
    str_1 = '\x16\x00\x00\x00'
    str_2 = '\x00\x00\x00\x00'
    str_3 = '\x00\x00\x00\x00'
    str_4 = '\x00\x01\x00\x00'
    str_5 = '\x00\x00\x00\x00'
    str_6 = '\x00\x00\x00\x00'
    str_7 = '\x00\x00\x00\x01'
    str_8 = '\x00\x00\x00\x00'
    str_9 = '\x00\x00\x00\x00'
    str_10 = '\x00\x00\x00\x00'

# Generated at 2022-06-26 05:05:51.985177
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'A'
    str_1 = '/B'
    str_2 = '/C'
    str_3 = '/D'
    str_4 = '/E'
    str_5 = '/F'
    str_6 = '/G'
    str_7 = '/H'
    str_8 = '/I'
    str_9 = '/J'
    str_10 = '/K'
    str_11 = '/L'
    str_12 = '/M'
    str_13 = '/N'
    str_14 = '/O'
    str_15 = '/P'
    str_16 = '/Q'
    str_17 = '/R'
    str_18 = '/S'
    str_19 = '/T'
    str_20 = '/U'
    str_21 = '/V'
   

# Generated at 2022-06-26 05:06:11.748235
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '#sn2f\rPSZmP'
    var_1 = shell_logger(str_0)


if __name__ == '__main__':
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:06:16.580867
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    #assert shell_logger(str_0) = var_0
    print("Test passed")

#main()
test_shell_logger()

# Generated at 2022-06-26 05:06:23.254757
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '#sn2f\rPSZmP'
    var_0 = shell_logger(str_0)
    test_case_0()


test_shell_logger()

# Generated at 2022-06-26 05:06:24.550328
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# General test for module

# Generated at 2022-06-26 05:06:25.921701
# Unit test for function shell_logger
def test_shell_logger():
    assert True


# Generated at 2022-06-26 05:06:27.741823
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '#sn2f\rPSZmP'
    var_0 = shell_logger(str_0)
    return 0

# Generated at 2022-06-26 05:06:38.206920
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import sys

    def test_infrastructure_0():
        assert os.path.exists(sys.argv[2]) and os.path.exists(sys.argv[1])

    def test_infrastructure_1():
        test_infrastructure_0()
        args = str(sys.argv[3])
        args = args.split(',')
        assert not subprocess.call(args), 'Test shell_logger failed!'

    try:
        test_shell_logger_0()
    except:
        print('Test shell_logger failed!', file=sys.stderr)
        sys.exit(1)

    try:
        test_infrastructure_1()
    except:
        print('Test shell_logger failed!', file=sys.stderr)

# Generated at 2022-06-26 05:06:39.505809
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:06:41.668626
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except AssertionError as e:
        logs.error(e)
        assert 0


if __name__ == '__main__':
    logs.init_logging(logs.DEBUG)
    test_shell_logger()

# Generated at 2022-06-26 05:06:44.518417
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# End of main function

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:07:28.305957
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(shell_logger('\n')) == shell_logger(shell_logger('\n'))
    assert shell_logger(shell_logger('\x00')) == shell_logger(shell_logger('\x00'))
    assert shell_logger(shell_logger('''
    ''')) == shell_logger(shell_logger('''
    '''))
    assert shell_logger(shell_logger('l')) == shell_logger(shell_logger('l'))
    assert shell_logger(shell_logger('\x00')) == shell_logger(shell_logger('\x00'))

# Generated at 2022-06-26 05:07:29.641748
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    assert True

# Generated at 2022-06-26 05:07:31.509892
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except TypeError:
        logs.warn("Unit test")

test_shell_logger()

# Generated at 2022-06-26 05:07:35.216858
# Unit test for function shell_logger

# Generated at 2022-06-26 05:07:36.294650
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('fRLF4') == 0


# Generated at 2022-06-26 05:07:37.748168
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:07:40.270694
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./logs/test_shell_logger')

# Tests output size

# Generated at 2022-06-26 05:07:41.162765
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:07:42.812774
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:07:48.605492
# Unit test for function shell_logger
def test_shell_logger():
    from shell_logger import shell_logger
    from os import system

    func, output = shell_logger, './output'
    system('echo "1" > {}'.format(output))
    with open(output) as f:
        assert f.readline() == '1\n'

    # should not change file content
    func(output)

    with open(output) as f:
        assert f.readline() == '1\n'



# Generated at 2022-06-26 05:08:25.815102
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() == b"logs/shell_logs/log_0.log"

# Generated at 2022-06-26 05:08:32.154468
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as e:
        return False
    return True


if __name__ == '__main__':
    print(shell_logger('/tmp/shell.log'))

# Generated at 2022-06-26 05:08:35.950776
# Unit test for function shell_logger
def test_shell_logger():
    """Test if the shell_logger function works correct
    """

    test_0 = os.path.exists(os.path.abspath("#sn2f\rPSZmP"))
    assert test_0 == True

# Generated at 2022-06-26 05:08:37.901312
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Test case for function shell_logger

# The function shell_logger must not exit.

# Generated at 2022-06-26 05:08:51.169247
# Unit test for function shell_logger
def test_shell_logger():
    from sys import getrefcount as grc
    class A:
        var_0 = 5
    a = A()
    var_0 = 7
    var_1 = 'jF3q0'
    var_2 = '%*j' % (var_0, ord(var_1[2]) + var_0)
    var_3 = '%*j' % (var_0, ord(var_1[0]) + var_0)
    var_1 = var_1[1:-1]
    var_4 = '%*j' % (var_0, ord(var_1[0]) + var_0)
    var_5 = '%*j' % (var_0, ord(var_1[1]) + var_0)

# Generated at 2022-06-26 05:08:59.219799
# Unit test for function shell_logger
def test_shell_logger():
    OUTPUT_FILE = 'shell.log'
    # Remove previous log file
    try:
        os.remove(OUTPUT_FILE)
    except FileNotFoundError:
        pass

    # Spawn a shell
    shell_logger(OUTPUT_FILE)

    # Check log file
    try:
        with open(OUTPUT_FILE, 'r') as f:
            content = f.read()
            assert content, 'Log file is empty'
    except FileNotFoundError:
        assert False, "Log file doesn't exist"

# Generated at 2022-06-26 05:09:00.830888
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        return False
    else:
        return True

# Generated at 2022-06-26 05:09:01.954374
# Unit test for function shell_logger
def test_shell_logger():

    # Test case 0
    test_case_0()


# Code to run if this file is invoked directly
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:09:02.438614
# Unit test for function shell_logger
def test_shell_logger():
    pass # TODO


# Generated at 2022-06-26 05:09:05.466034
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == '__main__':
    # test_shell_logger()
    print("Test for shell_logger - {}".format(test_shell_logger()))

# Generated at 2022-06-26 05:09:41.929063
# Unit test for function shell_logger
def test_shell_logger():
    # Case 1
    test_case_0()


if __name__ == '__main__':
    
    test_shell_logger()

# Generated at 2022-06-26 05:09:43.794759
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = shell_logger('test.txt')
    str_1 = '\r\n'
    assert_equals(str_0, str_1)

# Generated at 2022-06-26 05:09:46.589852
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("/home/yas/pwn/ctf/ctf/tools/logs/shell_logger")


# Generated at 2022-06-26 05:09:48.782364
# Unit test for function shell_logger
def test_shell_logger():
    '''
    If any test case fails, use the following command to debug
    python -m pdb utils/shell_logger.py
    '''
    test_case_0()

# Generated at 2022-06-26 05:09:51.718035
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test_shell_logger')

if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-26 05:09:52.684386
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:09:54.235087
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 05:09:56.685401
# Unit test for function shell_logger
def test_shell_logger():
    # Prepare test
    # Execute function
    try:
        test_case_0()
    # Assert result
    except AssertionError as e:
        logs.error(str(e))



# Generated at 2022-06-26 05:09:58.021924
# Unit test for function shell_logger
def test_shell_logger():
    #
    # This is a simple test to ensure the code will run
    #
    assert True

# Generated at 2022-06-26 05:10:02.174035
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Compiled code
test_case_0()
test_shell_logger()

# Generated at 2022-06-26 05:10:41.709359
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except SystemExit:
        pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:10:46.145007
# Unit test for function shell_logger
def test_shell_logger():
    from unit.test_data.test_logger_data import test_data_0, test_data_1

    initial_data_0 = test_data_0['initial_data']
    expected_data_0 = test_data_0['expected_data']
    initial_data_1 = test_data_1['initial_data']
    expected_data_1 = test_data_1['expected_data']

    assert shell_logger(initial_data_0) == expected_data_0
    assert shell_logger(initial_data_1) == expected_data_1

# Generated at 2022-06-26 05:10:46.766900
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


# Generated at 2022-06-26 05:10:47.381331
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger


# Generated at 2022-06-26 05:10:48.022204
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:10:55.120385
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as exception:
        logs.error("Exception: " + str(exception))
        return 1
    else:
        return 0


if __name__ == "__main__":
    sys.exit(test_shell_logger())

# Generated at 2022-06-26 05:10:57.233703
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:11:01.151172
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = '#sn2f\rPSZmP'
    var_1 = shell_logger(var_0)

    assert var_0 == '#sn2f\rPSZmP'
    assert var_1 == 0

# Generated at 2022-06-26 05:11:08.180689
# Unit test for function shell_logger
def test_shell_logger():

    # Assignments
    str_0 = '#tZPT\rZaKt'
    var_0 = shell_logger(str_0)
    str_1 = '#pXe\'J'
    var_1 = shell_logger(str_1)
    str_2 = '#yiIem6'
    var_2 = shell_logger(str_2)
    str_3 = '#\'YQYHWf0'
    var_3 = shell_logger(str_3)

    # Passing
    assert(var_0 == 0)
    assert(var_1 == 0)
    assert(var_2 == 0)
    assert(var_3 == 0)

# Test functions

# Generated at 2022-06-26 05:11:11.859621
# Unit test for function shell_logger
def test_shell_logger():
    # Print shell_logger(str)
    test_case_0()

if __name__ == '__main__':
    # Print shell_logger(str)
    test_case_0()
    test_shell_logger()