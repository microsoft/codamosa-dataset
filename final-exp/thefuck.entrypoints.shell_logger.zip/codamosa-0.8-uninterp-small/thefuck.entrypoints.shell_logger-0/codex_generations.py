

# Generated at 2022-06-26 05:01:37.355198
# Unit test for function shell_logger
def test_shell_logger():
    assert not shell_logger()

# Generated at 2022-06-26 05:01:45.265265
# Unit test for function shell_logger
def test_shell_logger():
    # Test case 0
    # Adding a file shell.log
    str_0 = 'shell.log'
    var_0 = shell_logger(str_0)
    # Check for the output
    f = open('shell.log', 'rb')
    data = f.read()
    print(data)


if __name__=='__main__':

    test_case_0()

# Generated at 2022-06-26 05:01:46.176524
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:01:51.506095
# Unit test for function shell_logger
def test_shell_logger():
    assert 0 == test_case_0()

if '__main__' == __name__:
    logs.init_logs(True, False)
    logs.set_level(logging.INFO)
    test_shell_logger()

# Generated at 2022-06-26 05:01:56.272770
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# from hypothesis import *
# @settings(max_examples=1000, deadline=None)
# @given(text())
# def test_shell_logger_hypothesis(s):
#     shell_logger(s)

# Generated at 2022-06-26 05:02:06.181289
# Unit test for function shell_logger
def test_shell_logger():
    with open('/tmp/shell_logger.log', 'w+') as fd:
        var_0 = shell_logger('/tmp/shell_logger.log')
        fd.seek(0)
        fd.read()
        assert fd.tell() > 0, 'Expected: %s, Actual: %s' % (0, fd.tell())


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:11.126582
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = './out.txt'
    var_0 = shell_logger(str_0)
    assert var_0 is None, "return value from function shell_logger is incorrect"


# Generated at 2022-06-26 05:02:23.748646
# Unit test for function shell_logger
def test_shell_logger():
    buff = []
    def read(s):
        buff.append(s)
        return s

    r = {
        'exit_status': 0,
        'stdout': '',
        'stderr': '',
    }
    def run_shell_logger(*cmd):
        cmd = ['python', '-m', 'soshell.utils.logger'] + list(cmd)
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        r['stdout'], r['stderr'] = p.communicate()
        r['exit_status'] = p.returncode

    run_shell_logger('test_log')
    if not os.path.exists('test_log'):
        return False

    os.un

# Generated at 2022-06-26 05:02:26.721142
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = ''
    var_0 = shell_logger(str_0)
    assert var_0 == shell_logger(str_0)

# Generated at 2022-06-26 05:02:35.708715
# Unit test for function shell_logger
def test_shell_logger():
    print('Testing function shell_logger:')
    try:
        test_case_0()
        print('Test case 0: PASSED')
    except Exception as e:
        print('Test case 0: FAILED')
        print(e)

################################################################################

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:50.319511
# Unit test for function shell_logger
def test_shell_logger():
    check = constant.check.replace('logger.py', 'shell_logger.py')
    subprocess.check_call(['diff', check, 'shell_logger.py'])
    os.remove('shell_logger.py')

# Generated at 2022-06-26 05:02:52.247086
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-26 05:02:54.537124
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger("/tmp/shell_logger")


# Generated at 2022-06-26 05:02:56.795001
# Unit test for function shell_logger
def test_shell_logger():
    # Replace below with your code...
    test_case_0()

# Generated at 2022-06-26 05:02:57.649834
# Unit test for function shell_logger
def test_shell_logger():
    print(shell_logger())


# Generated at 2022-06-26 05:03:02.113916
# Unit test for function shell_logger
def test_shell_logger():
    try:
        # Given
        
        # When
        test_case_0()
        
        # Then
        assert('return_code' in locals())
    except:
        logs.log_exception(sys.exc_info())
        return False

# Example function that uses `shell_logger`.

# Generated at 2022-06-26 05:03:03.573613
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except SystemExit:
        pass

# Generated at 2022-06-26 05:03:15.375502
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import subprocess
    import tempfile
    import time
    path_to_script = os.path.realpath(__file__)
    path_to_script_dir = os.path.dirname(path_to_script)
    temp_dir = tempfile.mkdtemp()
    outpath = os.path.join(temp_dir, "test.out")
    fd = os.open(outpath, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

# Generated at 2022-06-26 05:03:25.462627
# Unit test for function shell_logger
def test_shell_logger():
    # Test case 0:
    var_0 = _read(buffer, master_read)
    var_1 = _set_pty_size(master_fd)
    var_2 = _spawn(shell, master_read)
    if var_0 == buffer:
        print("Function _read: PASS")
    else:
        print("Function _read: FAIL")
    if var_1 == master_fd:
        print("Function _set_pty_size: PASS")
    else:
        print("Function _set_pty_size: FAIL")
    if var_2 == True:
        print("Function _spawn: PASS")
    else:
        print("Function _spawn: FAIL")

# Generated at 2022-06-26 05:03:26.496175
# Unit test for function shell_logger
def test_shell_logger():
    assert callable(shell_logger)


# Generated at 2022-06-26 05:03:41.772673
# Unit test for function shell_logger
def test_shell_logger():
    # The function accepts one argument:
    try:
        var_0 = shell_logger()
    except TypeError:
        print("Test case 1: passed")
    else:
        print("Test case 1: failed")

    # The value of argument `output` is of an incorrect type
    try:
        var_0 = shell_logger(0)
    except TypeError:
        print("Test case 2: passed")
    else:
        print("Test case 2: failed")

    # The value of `output` is an empty string:
    try:
        var_0 = shell_logger('')
    except TypeError:
        print("Test case 3: passed")
    else:
        print("Test case 3: failed")

    # The value of `output` is a non-empty string:

# Generated at 2022-06-26 05:03:53.753474
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == '__main__':
    test_shell_logger()
    # Compute the model
    def budget_model(size, window_size, filter_size):
        model = 1
        for _ in range(size):
            model += window_size
            model += window_size
            model += filter_size
            model += window_size
            model += window_size
            if size > 1:
                model += filter_size
            model += 1
        return model
    print('Window model: ', budget_model(size, window_size, filter_size))
    print('Input model: ', budget_model(size, filter_size, filter_size))

# Generated at 2022-06-26 05:03:54.712796
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(sys.argv[1])

# Generated at 2022-06-26 05:04:00.543368
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/test_shell_logger') == 0
    assert shell_logger('/tmp/test_shell_logger' + str(0)) == 0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 05:04:10.121103
# Unit test for function shell_logger

# Generated at 2022-06-26 05:04:11.853081
# Unit test for function shell_logger
def test_shell_logger():
    filename = "pwnyshell.txt"
    shell_logger(filename)
    assert os.path.isfile(filename)

# Test case 1

# Generated at 2022-06-26 05:04:14.647160
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == '__main__':

    # Unit test for function shell_logger
    test_shell_logger()

# Generated at 2022-06-26 05:04:16.302394
# Unit test for function shell_logger

# Generated at 2022-06-26 05:04:19.512855
# Unit test for function shell_logger
def test_shell_logger():
    print('Testing function shell_logger')
    test_case_0()
    print('Function shell_logger passed all test cases!')

# Generated at 2022-06-26 05:04:31.090903
# Unit test for function shell_logger
def test_shell_logger():
    file_path = os.path.dirname(__file__) + '/tmp/test_shell_logger/'

    if not os.path.exists(file_path):
        os.makedirs(file_path)

    fd = os.open(file_path + 'log_' + str(int(time.time())), os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
   

# Generated at 2022-06-26 05:04:44.363442
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = ''
    var_0 = shell_logger(str_0)
    assert ((isinstance(var_0, int)), "Expected True, but got '%s'" % str(var_0))

    #print "Test of function shell_logger was passed!"
    #print "Test for function shell_logger was passed!"
    #print "Test for shell_logger was passed!"


# Generated at 2022-06-26 05:04:45.869145
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


# Generated at 2022-06-26 05:04:46.758226
# Unit test for function shell_logger
def test_shell_logger():
    # this just shows the pattern for now
    test_case_0()

# Generated at 2022-06-26 05:04:47.650142
# Unit test for function shell_logger
def test_shell_logger():

    str_0 = ''
    var_0 = shell_logger(str_0)

# Generated at 2022-06-26 05:04:49.122104
# Unit test for function shell_logger
def test_shell_logger():
    with CaptureOutput() as output:
        test_case_0()

    assert_equals(output.get_text(),
        'Warning: Shell logger doesn\'t support your platform.\n'
    )

# Generated at 2022-06-26 05:04:54.158746
# Unit test for function shell_logger
def test_shell_logger():
    counter = 0     # Test 0
    try:
        test_case_0()
        counter += 1
    except SystemExit:
        pass
    assert counter == 1, "%d tests failed." % (1-counter)

# Generated at 2022-06-26 05:04:57.200738
# Unit test for function shell_logger
def test_shell_logger():
    pass
    # Call shell_logger with arguments: [str_0]
    # Assert return_code equals: 0


# Generated at 2022-06-26 05:04:59.944972
# Unit test for function shell_logger
def test_shell_logger():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'argument 1 must be an string' in str(excinfo.value)

# Generated at 2022-06-26 05:05:04.390288
# Unit test for function shell_logger
def test_shell_logger():
    #assert 0 == shell_logger(0)
    assert 0 == test_case_0()

if __name__ == '__main__':
    print(test_shell_logger())

# Generated at 2022-06-26 05:05:07.143395
# Unit test for function shell_logger

# Generated at 2022-06-26 05:05:23.343711
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:05:26.762233
# Unit test for function shell_logger
def test_shell_logger():
    logs.get_logger().setLevel(logs.DEBUG)
    logs.set_log_dir('/tmp/')
    assert logs.get_log_dir() == '/tmp/'
    test_case_0()
    logs.debug("Done!")

# Generated at 2022-06-26 05:05:28.630444
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'unit-test'
    var_0 = shell_logger(str_0)


# Generated at 2022-06-26 05:05:33.240448
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("test_file") == None,\
    "shell_logger() returned {} instead of {}".format(shell_logger("test_file"), None)


# Generated at 2022-06-26 05:05:35.107306
# Unit test for function shell_logger
def test_shell_logger():
    assert False, "TestCase_0"

# Generated at 2022-06-26 05:05:39.266026
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger() == 0



# Generated at 2022-06-26 05:05:41.507153
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/test_shell_logger') == 0

# Generated at 2022-06-26 05:05:48.834991
# Unit test for function shell_logger
def test_shell_logger():
    try:
        temp = open("test1.txt", "w")
        temp.write("")
        temp.close()
        assert shell_logger("test1.txt") == None
    except Exception as e:
        print("shell_logger function failed: " + str(e))
        assert False
    else:
        assert True
    finally:
        os.remove("test1.txt")

# Generated at 2022-06-26 05:05:51.604716
# Unit test for function shell_logger
def test_shell_logger():
    func_0 = shell_logger
    val_0 = './output.1'
    var_0 = func_0(val_0)
    test_case_0()
    var_skipped = True

test_shell_logger()

# Generated at 2022-06-26 05:05:54.394831
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except SystemExit:
        pass
    else:
        raise AssertionError


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:06:17.209176
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = ''
    var_0 = shell_logger(str_0)


if __name__ == '__main__':
    import sys
    sys.path.append('..')
    import logs
    from tests.check_result import check_result

    with open('tests/shell_logger.res', 'w') as f:
        check_result(test_case_0, [], f)

# Generated at 2022-06-26 05:06:20.542759
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger()

# Generated at 2022-06-26 05:06:23.152948
# Unit test for function shell_logger
def test_shell_logger():
    # initialize arguments
    arg_0 = ''
    ret = shell_logger(arg_0)
    print(ret)


# Generated at 2022-06-26 05:06:25.470590
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = ''
    var_1 = shell_logger(var_0)


# Generated at 2022-06-26 05:06:27.334241
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = ''
    var_0 = shell_logger(str_0)


# Run test
test_shell_logger()

# Generated at 2022-06-26 05:06:28.318828
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# vim: set sts=4 sw=4 et :

# Generated at 2022-06-26 05:06:38.948617
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('abc') == None, 'shell_logger #0 failed'
    assert shell_logger('abc') == None, 'shell_logger #1 failed'
    assert shell_logger('abc') == None, 'shell_logger #2 failed'
    assert shell_logger('abc') == None, 'shell_logger #3 failed'
    assert shell_logger('abc') == None, 'shell_logger #4 failed'
    assert shell_logger('abc') == None, 'shell_logger #5 failed'
    assert shell_logger('abc') == None, 'shell_logger #6 failed'
    assert shell_logger('abc') == None, 'shell_logger #7 failed'
    assert shell_logger('abc') == None, 'shell_logger #8 failed'
   

# Generated at 2022-06-26 05:06:43.537958
# Unit test for function shell_logger
def test_shell_logger():

    test_case_0()


# Test for shell_logger
#test_shell_logger()


# Run the shell_logger
shell_logger(output='log.txt')

# Generated at 2022-06-26 05:06:51.282369
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'test_shell_logger_file.txt'
    try:
        os.remove(str_0)
    except OSError:
        pass
    var_0 = shell_logger(str_0)
    var_1 = os.path.isfile(str_0)
    if (var_1 != True):
        sys.exit(1)
    var_2 = os.path.getsize(str_0)
    var_3 = const.LOG_SIZE_IN_BYTES
    if (var_2 != var_3):
        sys.exit(1)
    var_4 = open(str_0, 'rb')
    var_5 = var_4.read()
    var_6 = b'\x00' * const.LOG_SIZE_IN_BYTES
   

# Generated at 2022-06-26 05:07:03.413429
# Unit test for function shell_logger

# Generated at 2022-06-26 05:07:39.815221
# Unit test for function shell_logger
def test_shell_logger():
    log_file_path = "test.log"
    if os.path.isfile(log_file_path):
        os.remove(log_file_path)
    shell_logger(log_file_path)
    with open(log_file_path, 'rb') as f:
        content = f.read()
        assert len(content) == const.LOG_SIZE_IN_BYTES
        assert all(c == 0 for c in content)

# Generated at 2022-06-26 05:07:40.859681
# Unit test for function shell_logger
def test_shell_logger():
    # Possible inputs
    None

    # Outputs



# Generated at 2022-06-26 05:07:43.005332
# Unit test for function shell_logger
def test_shell_logger():
    # Setup
    output = sys.stderr

    # Invoke function
    shell_logger(output)

    # Return
    return True

# Generated at 2022-06-26 05:07:44.253004
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('log_0.txt') == None

# Generated at 2022-06-26 05:07:45.299982
# Unit test for function shell_logger

# Generated at 2022-06-26 05:07:49.377804
# Unit test for function shell_logger
def test_shell_logger():
    try:
        with open('test_shell_logger.log', 'w') as f:
            logs.debug('Test case #0')
            test_case_0()

    except:
        logs.error('test_shell_logger FAILED!')
        raise


test_shell_logger()

# Generated at 2022-06-26 05:07:55.581116
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(sys.stderr.write)
    assert shell_logger(sys.stderr.flush)
    assert shell_logger(sys.stderr.isatty)

if __name__ == "__main__":
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:07:56.927038
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('')

    assert (var_0 == 0)



# Generated at 2022-06-26 05:07:59.558157
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('shell_logger.tmp')
    # assert file is created
    assert os.access('shell_logger.tmp', os.R_OK)

    # remove created file
    os.remove('shell_logger.tmp')



# Generated at 2022-06-26 05:08:01.653083
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'python3'
    var_0 = shell_logger(str_0)

# Change the function name here if you want to test shell_logger(str_0) with another name.
test_shell_logger()

# Generated at 2022-06-26 05:08:35.367528
# Unit test for function shell_logger
def test_shell_logger():
    tester = lambda : shell_logger('/tmp/output')
    assert tester() == None

# O.K.
#------------------------------------------------------------------------------

# Generated at 2022-06-26 05:08:37.145149
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        assert False


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:08:38.041820
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('/dev/null')


# Generated at 2022-06-26 05:08:42.356969
# Unit test for function shell_logger
def test_shell_logger():
    # test case 0
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0: Failed")
        raise e

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:08:42.948568
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-26 05:08:46.735250
# Unit test for function shell_logger
def test_shell_logger():
    print('test_shell_logger')
    test_case_0()

# Generated at 2022-06-26 05:08:49.790873
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = './test.log'
    var_1 = shell_logger(var_0)
    assert(var_1 == 0)


# Generated at 2022-06-26 05:08:50.807671
# Unit test for function shell_logger
def test_shell_logger():
    print('Executing unit test for function shell_logger')


# Generated at 2022-06-26 05:08:54.420215
# Unit test for function shell_logger
def test_shell_logger():
    try:
        with open('/tmp/fuzzy.log', 'ab') as f:
            orig_stdout = sys.stdout
            sys.stdout = f
            test_case_0()
            sys.stdout = orig_stdout
    except IOError:
        logs.error('Could not open file!')

# Generated at 2022-06-26 05:08:55.836589
# Unit test for function shell_logger
def test_shell_logger():
    import os

    if os.environ.get('SHELL'):
        test_case_0()
    else:
        logs.warn("Shell logger doesn't support your platform.")

# Generated at 2022-06-26 05:09:31.679582
# Unit test for function shell_logger
def test_shell_logger():
    """
    Testing shell_logger
    >>> test_case_0()
    """
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    import sys
    import os
    import doctest
    docs = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    sys.path.insert(0, docs)
    doctest.testmod()

# Generated at 2022-06-26 05:09:33.384630
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'end-of-story'
    var_1 = shell_logger(str_0)

# Generated at 2022-06-26 05:09:37.218535
# Unit test for function shell_logger
def test_shell_logger():
    # Setup
    output = "file"

    # Test
    out = shell_logger(output)

    # Verify
    assert open(output).read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    assert os.path.isfile(output)
    assert out == 0
    # Cleanup
    os.remove(output)



# Generated at 2022-06-26 05:09:38.791278
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    str_0 = ''
    var_0 = shell_logger(str_0)


# Generated at 2022-06-26 05:09:41.286338
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() == None, 'Test Failed'


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:09:44.997832
# Unit test for function shell_logger
def test_shell_logger():
    val_0 = 0
    var_0 = test_case_0()
    if var_0 == val_0:
        print('Test Case 0: Success!')
    else:
        print('Test Case 0: Failure.')

test_shell_logger()

# Generated at 2022-06-26 05:09:46.857321
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
        return 1
    except:
        return 0

# Unit test main

# Generated at 2022-06-26 05:09:50.383075
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('/tmp/mim-shell-logger')
    var_1 = False
    if type(var_0) == int:
        var_1 = True
    assert var_1

# Generated at 2022-06-26 05:09:55.399117
# Unit test for function shell_logger
def test_shell_logger():
    # Input
    output = "output.txt"
    # Expected output
    expected_var_0 = 0

    try:
        # Call function
        var_0 = shell_logger(output)

        # Check if output is expected
        assert var_0 == expected_var_0
    except AssertionError:
        # Print error message
        print("Test Case 0 Failed")

# Test function

# Generated at 2022-06-26 05:09:56.158783
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()



# Generated at 2022-06-26 05:11:00.986908
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

    print('\nDone!')

# Generated at 2022-06-26 05:11:07.660621
# Unit test for function shell_logger
def test_shell_logger():
    var_4 = ' '
    try:
        test_case_0()
    except:
        os.write(2, var_4)
    else:
        try:
            var_1 = 'shell_logger'
            try:
                var_2 = __name__
            except:
                var_2 = '__main__'
            if var_1 != var_2:
                os.write(2, var_4)
        except:
            os.write(2, var_4)
            raise
        else:
            pass


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:11:17.608633
# Unit test for function shell_logger
def test_shell_logger():
    try:
        assert (shell_logger('test_shell_logger.txt')) == 0
        fd = os.open('test_shell_logger.txt', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
        assert (return_code == 0)
    except AssertionError:
        return False

test_case_0()

# Generated at 2022-06-26 05:11:20.144326
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger() == 0

# Generated at 2022-06-26 05:11:26.226315
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()

    except TypeError:
        logs.error("TypeError: test_shell_logger")


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:11:31.198839
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    import sys

    output = tempfile.mktemp()
    code = shell_logger(output)
    # Check that shell exited with return code 0
    assert code == 0

    # Check that shell output is not empty
    assert len(open(output, 'rb').read()) > 0