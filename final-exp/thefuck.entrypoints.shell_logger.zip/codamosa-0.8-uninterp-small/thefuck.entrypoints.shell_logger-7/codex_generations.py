

# Generated at 2022-06-26 05:01:45.486035
# Unit test for function shell_logger
def test_shell_logger():
    assert True == True



# Generated at 2022-06-26 05:01:48.041181
# Unit test for function shell_logger
def test_shell_logger():
    # Make sure the function is callable.
    try:
        shell_logger()
    except TypeError:
        print('\nERROR: Cannot call the function "shell_logger"')
        return False

    return True


# Start the unit tests.

# Generated at 2022-06-26 05:01:50.254240
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/dev/null') == 0


# Generated at 2022-06-26 05:01:51.641654
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() == 'Success'

# Generated at 2022-06-26 05:01:54.801220
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0d`'
    var_0 = shell_logger(str_0)
    assert var_0 == 0

# Generated at 2022-06-26 05:01:57.388310
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)
    assert( var_0 == None)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:01:58.768189
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:00.670762
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


# Main Entry

# Generated at 2022-06-26 05:02:05.417425
# Unit test for function shell_logger
def test_shell_logger():
    # Execution of function shell_logger
    try:
        test_case_0()
    except Exception as e:
        print('Execution of function shell_logger raised exception: %s' % e)
        return False

    return True

# Generated at 2022-06-26 05:02:06.838021
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:15.040953
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:19.267704
# Unit test for function shell_logger
def test_shell_logger():
    """test_shell_logger"""

    print('\n\n---- TEST shell_logger ----\n')

    test_case_0()

# Test function shell_logger if executed as main
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:02:22.642762
# Unit test for function shell_logger
def test_shell_logger():
    test_cases = [
        ('\x0cF(v',)
    ]
    for test in test_cases:
        assert test_case_0(*test) == shell_logger(*test)

# Generated at 2022-06-26 05:02:24.193469
# Unit test for function shell_logger
def test_shell_logger():
    assert test_case_0() == 0, 'Failed test_case_0'

# Generated at 2022-06-26 05:02:29.777855
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('\x0cF(v') == None, \
        'function shell_logger not implemented.'
    assert shell_logger('\x04\x00\x00\x00\x00\xff\xff\xff\xff\xff\xff\xff') == None, \
        'function shell_logger not implemented.'
    assert shell_logger('\x01') == None, \
        'function shell_logger not implemented.'
# End of test_shell_logger


# Generated at 2022-06-26 05:02:33.627049
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger("/tmp/test")

test_case_0()
test_shell_logger()

# Generated at 2022-06-26 05:02:36.010268
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('\x0cF(v') == sys.exit(1)

# Unit tests for function test_case_0

# Generated at 2022-06-26 05:02:39.253387
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as exception_0:
        logs.error("In function shell_logger: {}".format(exception_0))


# Generated at 2022-06-26 05:02:41.099750
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:42.331626
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:52.867000
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(str) == None, 'returned value does not match'

# Generated at 2022-06-26 05:02:53.543425
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:02:54.785721
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = "input.txt"
    shell_logger(str_0) # We expect no errors or exceptions


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:02:56.655072
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: add test cases later
    pass

# Generated at 2022-06-26 05:02:57.542094
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("") == 0

# Generated at 2022-06-26 05:03:02.457114
# Unit test for function shell_logger
def test_shell_logger():
    # Test case 0
    try:
        test_case_0()
        logs.test_success(test_name="test_case_0")
    except Exception:
        logs.test_failure(test_name="test_case_0")


# Prints to the error stream: (PASSED) or (FAILED)

# Generated at 2022-06-26 05:03:03.795000
# Unit test for function shell_logger
def test_shell_logger():
    print('\nUnit Test for function shell_logger')
    test_case_0()

# Generated at 2022-06-26 05:03:06.886852
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = '\x0cF(v'
    shell_logger(var_0)

# Generated at 2022-06-26 05:03:08.554836
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('/dev/null')


# Generated at 2022-06-26 05:03:16.691564
# Unit test for function shell_logger
def test_shell_logger():
    buffer = mmap.mmap(os.open('/tmp', os.O_CREAT | os.O_TRUNC | os.O_RDWR), 1024, mmap.MAP_SHARED, mmap.PROT_WRITE)
    assert _read(buffer, 0) == b''
    buffer.close()

    buffer = mmap.mmap(os.open('/tmp', os.O_CREAT | os.O_TRUNC | os.O_RDWR), 1024, mmap.MAP_SHARED, mmap.PROT_WRITE)
    os.write(buffer.fileno(), b'\x00' * 1024)
    buffer.seek(512)
    assert _read(buffer, 0) != b''
    buffer.close()

# Generated at 2022-06-26 05:03:26.880366
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)

# Generated at 2022-06-26 05:03:29.617797
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

test_shell_logger()

# Generated at 2022-06-26 05:03:32.253860
# Unit test for function shell_logger
def test_shell_logger():
    logs.info('Test shell_logger')
    test_case_0()

# Generated at 2022-06-26 05:03:33.686865
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    pass


# Generated at 2022-06-26 05:03:35.495253
# Unit test for function shell_logger
def test_shell_logger():
    assert callable(shell_logger)
    test_case_0()


# Generated at 2022-06-26 05:03:38.944167
# Unit test for function shell_logger
def test_shell_logger():
    v1 = 'testfile.txt'
    var_0 = shell_logger(v1)
    v2 = os.path.isfile(v1)
    print(v2)


# Generated at 2022-06-26 05:03:42.787840
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:03:44.876696
# Unit test for function shell_logger
def test_shell_logger():
    assert 'shell_logger' in globals(), "Function shell_logger not defined"
    return 0


# Generated at 2022-06-26 05:03:50.723806
# Unit test for function shell_logger
def test_shell_logger():
    # The "assert" keyword will be used in a later lecture
    assert shell_logger('/dev/null'), -1
    assert shell_logger('/dev/tty'), 0
    assert shell_logger('/proc/version'), 0
    assert shell_logger('/proc/cpuinfo'), 0
    assert shell_logger('/proc/meminfo'), 0
    assert shell_logger('/proc/loadavg'), 0
    assert shell_logger('/proc/mounts'), 0
    assert shell_logger('/proc/partitions'), 0
    assert shell_logger('/proc/self/mountstats'), 0
    assert shell_logger('/proc/self/status'), 0
    assert shell_logger('/proc/self/limits'), 0
    assert shell_logger('/proc/cmdline'), 0
   

# Generated at 2022-06-26 05:03:52.422918
# Unit test for function shell_logger
def test_shell_logger():
    filename = 'file.txt'
    shell_logger(filename)
    # Test if the test environment is properly setup
    try:
        os.remove(filename)
    except FileNotFoundError:
        assert False, "Unit test for shell_logger ran in a bad testing environment"

# Generated at 2022-06-26 05:04:10.095918
# Unit test for function shell_logger
def test_shell_logger():
    def test_shell_logger_0():
        num_0 = 0
        assert(num_0 == 0)

    def test_shell_logger_1():
        num_0 = 1
        assert(num_0 == 1)

    def test_shell_logger_2():
        num_0 = 2
        assert(num_0 == 2)

    def test_shell_logger_3():
        num_0 = 3
        assert(num_0 == 3)

    def test_shell_logger_4():
        num_0 = 4
        assert(num_0 == 4)

    def test_shell_logger_5():
        num_0 = 5
        assert(num_0 == 5)

    def test_shell_logger_6():
        num_0 = 6

# Generated at 2022-06-26 05:04:11.341760
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:04:12.024017
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
#     return 0

# Generated at 2022-06-26 05:04:19.634099
# Unit test for function shell_logger
def test_shell_logger():
    # 'shell' variable is used instead of the actual argument
    with pytest.raises(TypeError) as exc_info:
        shell_logger(shell)
    assert str(exc_info.value) == "shell_logger() missing 1 required positional argument: 'output'"

    # Empty string is passed as an argument
    with pytest.raises(ValueError) as exc_info:
        shell_logger('')
    assert str(exc_info.value) == "Safe `output` argument is required"

# Generated at 2022-06-26 05:04:22.085455
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:04:23.226863
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Shell logger does not support windows.

# Generated at 2022-06-26 05:04:26.647777
# Unit test for function shell_logger
def test_shell_logger():

    import pathlib

    shell_logger('/dev/null')

    test_case_0()

    return True



# Generated at 2022-06-26 05:04:27.924664
# Unit test for function shell_logger
def test_shell_logger():
    print("Test shell_logger")
    test_case_0()


# Generated at 2022-06-26 05:04:30.891235
# Unit test for function shell_logger
def test_shell_logger():
    # Execute function
    str_0 = 'test'
    var_0 = shell_logger(str_0)
    # Check results
    assert var_0 == -1



# Generated at 2022-06-26 05:04:35.048538
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as err:
        var_2 = err.message
        print('Exception caught: ' + repr(var_2) )
    sys.exit()

# Start of the program
if (__name__ == "__main__"):
    test_shell_logger()

# Generated at 2022-06-26 05:04:56.805883
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('/home/nemo/dev/bors/bors-ng/output')

# Generated at 2022-06-26 05:05:08.990612
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    from unittest import mock

    class TestShellLogger(unittest.TestCase):
        def test_0(self):
            with mock.patch('os.environ', {'SHELL': '/bin/bash'}):
                with mock.patch('pty.fork') as mock_fork:
                    mock_fork.side_effect = Exception()
                    with mock.patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
                        with self.assertRaises(Exception):
                            shell_logger('output.log')
                    self.assertEqual(mock_stdout.getvalue(), 'output.log -> /bin/bash\n')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestShellLogger)
    unittest.Text

# Generated at 2022-06-26 05:05:11.501407
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)

if __name__ == '__main__':
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:05:17.083808
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)



if __name__ == '__main__':
    test_case_0()
    test_shell_logger()
    sys.exit(0)

# Generated at 2022-06-26 05:05:26.070020
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = 'r\x0b('
    var_0 = shell_logger(str_0)
    assert var_0 == 0

    str_1 = '\x0cF(v'
    var_1 = shell_logger(str_1)
    assert var_1 == 0

    str_2 = 'D\x00\x0f\x17'
    var_2 = shell_logger(str_2)
    assert var_2 == 0

    str_3 = '\x0b\x00\x0c(S'
    var_3 = shell_logger(str_3)


# Generated at 2022-06-26 05:05:28.585992
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        import sys

# Generated at 2022-06-26 05:05:39.220857
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except NameError:
        print("Name error during testing. Probably missing function.")
        print(sys.exc_info())
    except TypeError:
        print("Type error during testing")
        print(sys.exc_info())
    except ValueError:
        print("Value error during testing")
        print(sys.exc_info())
    except AttributeError:
        print("Attribute error during testing.")
        print(sys.exc_info())
    except EOFError:
        print("EOF error during testing")
        print(sys.exc_info())
    except ImportError:
        print("Import error during testing")
        print(sys.exc_info())
    except IndentationError:
        print("Indentation error during testing")
        print(sys.exc_info())
   

# Generated at 2022-06-26 05:05:42.586628
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./shell_logger.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:05:53.430574
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("\x0cF(v") == None
    assert shell_logger("") == None
    assert shell_logger("\x02/h") == None
    assert shell_logger("\x06\x17\x1c") == None
    assert shell_logger("\x16Ke\x0c") == None
    assert shell_logger("\x1al") == None
    assert shell_logger("\x0c") == None
    assert shell_logger("\x1c") == None
    assert shell_logger("\x1c\x02\x1e") == None
    assert shell_logger("c\x0b") == None
    assert shell_logger("\x07") == None
    assert shell_logger("") == None
    assert shell_logger

# Generated at 2022-06-26 05:05:59.429194
# Unit test for function shell_logger
def test_shell_logger():
    path = 'shell.log'
    if os.path.isfile(path):
        os.remove(path)
    sys.argv = ['shell_logger.py', 'shell.log']
    test_case_0()
    assert os.path.isfile(path)
    with open(path) as f:
        data = f.read()
    assert data.find('Shell logger doesn\'t support your platform.') != -1
    os.remove(path)

# Generated at 2022-06-26 05:06:17.860997
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:06:21.052743
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()
    assert True

# Generated at 2022-06-26 05:06:27.772797
# Unit test for function shell_logger
def test_shell_logger():
    if (not os.path.exists(const.LOG_PATH) or
            not os.path.isfile(const.LOG_PATH)):
        logs.warn("Test requires a file '{}' to be present.".format(const.LOG_PATH))
        return
    if not os.environ.get('SHELL'):
        logs.warn("Test requires $SHELL env variable to be defined.")
        return

    test_case_0()

    logs.debug("Test function shell_logger completed")
    return True

# Generated at 2022-06-26 05:06:38.260136
# Unit test for function shell_logger
def test_shell_logger():
    # Strings
    str_0 = '\x0cF(v'
    str_1 = 'Proc'
    str_2 = 'Deb'
    str_3 = 'Processes:'
    str_4 = '\x00'
    str_5 = 'Htop'
    str_6 = '\x0cF'
    str_7 = '$'
    str_8 = 'Ls'

# Generated at 2022-06-26 05:06:45.308906
# Unit test for function shell_logger
def test_shell_logger():

    args_0 = '\x0cF(v'
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)
    assert list(args_0) == list(str_0)
    assert var_0 == 0



# Generated at 2022-06-26 05:06:46.452428
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


# Generated at 2022-06-26 05:06:47.612468
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Unit tests for function test_case_0

# Generated at 2022-06-26 05:06:56.655780
# Unit test for function shell_logger
def test_shell_logger():
    from random import random
    from string import printable

    for i in range(1000):
        str_0 = ''.join(random.choice(printable) for _ in range(random.randint(1, 100)) )
        var_0 = shell_logger(str_0)


if __name__ == '__main__':
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:07:02.424431
# Unit test for function shell_logger
def test_shell_logger():
    path_0 = os.path.join(const.TEST_DIR_PATH_0, 'test_file_0')
    shell_logger(path_0)
    test_f = open(path_0, 'r')
    data_0 = test_f.read()
    test_f.close()
    assert (data_0 == b'\x00' * const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-26 05:07:03.106253
# Unit test for function shell_logger
def test_shell_logger():
    pass



# Generated at 2022-06-26 05:07:20.406496
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    test_case_0()



# Generated at 2022-06-26 05:07:25.726534
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        logs.exception("Test case 0 failed")
        raise

# Generated at 2022-06-26 05:07:28.247686
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('logs/shell/case_0')

if __name__ == '__main__':
    test_case_0()
    test_shell_logger()

# Generated at 2022-06-26 05:07:30.368920
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:07:31.198801
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('shell.log') == 0

# Generated at 2022-06-26 05:07:32.302726
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)

# Generated at 2022-06-26 05:07:35.494018
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = '\x0cF(v'
    var_1 = shell_logger(var_0)
    assert var_1 == 0

# Generated at 2022-06-26 05:07:36.819338
# Unit test for function shell_logger
def test_shell_logger():
    from test_case import TestCase as tc
    # SubCase1
    test_case_0()


# Generated at 2022-06-26 05:07:40.310124
# Unit test for function shell_logger
def test_shell_logger():
    '''
    Executes first test case for shell_logger
    '''
    test_case_0()
    # Assert statement(s) here.
    # Example: assert var_0 == 'var_0'

# Generated at 2022-06-26 05:07:47.407438
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = logs.tmp_file()
    str_1 = logs.tmp_file()
    var_0 = shell_logger(str_0)
    logs.compare_file_content(str_0, str_1)
    logs.remove_file(str_0)
    logs.remove_file(str_1)
    var_1 = shell_logger('  ')
    var_2 = shell_logger('  ')
    var_3 = shell_logger('  ')
    var_4 = shell_logger('  ')

# Generated at 2022-06-26 05:08:06.419597
# Unit test for function shell_logger
def test_shell_logger():
    logger = logging.getLogger("scapy.runtime")
    logger.setLevel(logging.ERROR)
    var_0 = shell_logger("/dev/null")
    print(var_0)

# Generated at 2022-06-26 05:08:07.552540
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:08:10.313024
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as exception:
        logs.exception(exception)
        sys.exit(1)

# Generated at 2022-06-26 05:08:13.951893
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except AssertionError:
        print("Test case 0 failed.")
        raise

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:08:20.801199
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = shell_logger('/var/log/debug')
    var_1 = shell_logger('/var/log/messages')
    var_2 = shell_logger('/var/log/syslog')
    var_3 = shell_logger('/var/log/kern.log')

# Generated at 2022-06-26 05:08:23.987232
# Unit test for function shell_logger
def test_shell_logger():
    # If run without argument
    sys.argv = [sys.argv[0]]
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

# Generated at 2022-06-26 05:08:31.185130
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    try:
        shell_logger(str_0)
    except (TypeError, ValueError) as err:
        assert str(err) == 'This function takes one argument.'
    except Exception:
        assert False


# Generated at 2022-06-26 05:08:32.200041
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:08:35.404959
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except Exception as var_4:
        logs.warn(str(var_4))
        assert False


# Generated at 2022-06-26 05:08:37.672253
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
        sys.exit(0)
    except:
        sys.exit(1)
    
    
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:09:18.138349
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\n'
    str_1 = ''
    str_2 = '\x00'
    str_3 = '\n'
    str_4 = '\n'
    str_5 = '\x01'
    str_6 = '\n'
    str_7 = '\x00'
    str_8 = '\n'
    str_9 = '\x00'
    str_10 = '\n'
    str_11 = '\x00'
    str_12 = '\n'
    str_13 = '\n'
    str_14 = '\n'
    str_15 = '\n'
    str_16 = '\n'
    str_17 = '\x00'
    str_18 = '\n'

# Generated at 2022-06-26 05:09:23.816829
# Unit test for function shell_logger
def test_shell_logger():
    var_0 = const.LOG_SIZE_IN_BYTES
    str_0 = os.environ['SHELL']
    var_1 = os.environ['SHELL']
    var_2 = os.environ['SHELL']
    var_3 = const.LOG_SIZE_IN_BYTES
    str_1 = os.environ['SHELL']
    var_4 = os.environ['SHELL']


# Generated at 2022-06-26 05:09:25.905948
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/shellstart.log') == 0
    sys.exit(0)

# Generated at 2022-06-26 05:09:27.234978
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/dev/null') == 0

# Generated at 2022-06-26 05:09:28.914093
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except SystemExit as exception:
        assert exception.code == 1


# Generated at 2022-06-26 05:09:37.022964
# Unit test for function shell_logger
def test_shell_logger():
    try:
        test_case_0()
    except:
        return False
    return True

test_cases = {
    'test_shell_logger': test_shell_logger,
}

# Run unit tests when executing this file
if __name__ == '__main__':
    import sys
    import imp
    import os
    import random

    file_path = os.path.abspath(__file__)
    dir_path = os.path.dirname(file_path)
    module_name = file_path[len(dir_path):]
    module_name = module_name[:module_name.rfind('.')]

    if module_name in sys.modules:
        module = sys.modules[module_name]

# Generated at 2022-06-26 05:09:37.845191
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:09:39.936418
# Unit test for function shell_logger
def test_shell_logger():
    with pytest.raises(FileNotFoundError):
        shell_logger('что-то')
    #test_case_0()

# Generated at 2022-06-26 05:09:43.329830
# Unit test for function shell_logger
def test_shell_logger():
    testcase_0 = [0x0, 0x0]
    testfunc_0 = lambda: shell_logger(testcase_0[0])
    test_runner(testcase_0, testfunc_0)


# Program entry point
if __name__ == "__main__":
    test_case_0()


# Generator ID: 6
# Bound: 8
# Cyclomatic: 3
# Maximum symbol ID: 1
# Grammar rule count: 1
# Number of nonterminals: 0
# Number of terminals: 5
# Number of productions: 7
# Symbols: ['0x0', '0x0', '0x0', '0x0', '0x0']

# Generated at 2022-06-26 05:09:45.483310
# Unit test for function shell_logger
def test_shell_logger():
    pass

# call the unit test
test_shell_logger()

# Generated at 2022-06-26 05:10:20.057525
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Shutdown script
import os
import subprocess
import sys


# Generated at 2022-06-26 05:10:23.585732
# Unit test for function shell_logger
def test_shell_logger():
    print(shell_logger.__doc__ + '\n')
    try:
        test_case_0()
    except ValueError as e:
        print('Test case passed. Exception message: ' + str(e))

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:10:29.814886
# Unit test for function shell_logger
def test_shell_logger():
    logs.info("Testing shell_logger")
    test_case_0()
    logs.info("Passed")

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-26 05:10:32.686224
# Unit test for function shell_logger
def test_shell_logger():
    logs.info("Calling shell_logger")
    test_case_0()
    logs.info("Done")


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:10:35.064082
# Unit test for function shell_logger
def test_shell_logger():
    import ctypes
    ctypes.CFUNCTYPE(None)(test_case_0)()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:10:38.789596
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)

test_case_0()

# Generated at 2022-06-26 05:10:42.398595
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x7f'
    var_0 = shell_logger(str_0)


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_case_0()

# Generated at 2022-06-26 05:10:43.352193
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    shell_logger(str_0)

# Generated at 2022-06-26 05:10:46.169994
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x1a\xd6\x00\x8c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = shell_logger(str_0)



# Generated at 2022-06-26 05:10:46.792704
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()

# Generated at 2022-06-26 05:11:24.517080
# Unit test for function shell_logger
def test_shell_logger():
    test_case_0()


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-26 05:11:26.574642
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = ''
    var_0 = shell_logger(str_0)



# Generated at 2022-06-26 05:11:29.428429
# Unit test for function shell_logger
def test_shell_logger():
    # NOTE: This test requires a working shell with the SHELL environment
    # variable set. 
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 05:11:34.209915
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('shell.log') == 0


# Generated at 2022-06-26 05:11:36.157137
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = shell_logger(str_0)

# Generated at 2022-06-26 05:11:39.271212
# Unit test for function shell_logger
def test_shell_logger():
    str_0 = '\x0cF(v'
    var_0 = str_0
    return var_0

if __name__ == "__main__":
    test_case_0()