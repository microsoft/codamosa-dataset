

# Generated at 2022-06-24 05:32:12.173699
# Unit test for function shell_logger
def test_shell_logger():
    pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:32:22.902222
# Unit test for function shell_logger
def test_shell_logger():
    try:
        import psutil
    except ImportError:
        raise RuntimeError("psutil package is required to run the tests.")

    log = '__pyscript__.tmp'
    fd = os.open(log, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    os.close(fd)

    child_pid = os.fork()

    if child_pid == 0:
        try:
            shell_logger(log)
            os._exit(1)
        except:
            os._exit(2)


# Generated at 2022-06-24 05:32:27.528864
# Unit test for function shell_logger
def test_shell_logger():
    output = os.popen("python3 -m bl.logger shell_logger.log")
    ps_pid = str(output.readline()).split(" ")[1].strip("\n")
    with open("shell_logger.log", "r+") as f:
        if f.read() == "":
            return False
        print("Shell process %s output is logger into %s" % (ps_pid, f.name))
        return True


# Generated at 2022-06-24 05:32:33.896134
# Unit test for function shell_logger
def test_shell_logger():
    """Test for function shell_logger"""
    with open('./test_shell_logger.log', 'w') as f:
        f.write('')
    shell_logger('./test_shell_logger.log')
    with open('./test_shell_logger.log', 'r') as f:
        assert f.read() != ''
    os.remove('./test_shell_logger.log')

# Generated at 2022-06-24 05:32:41.765019
# Unit test for function shell_logger
def test_shell_logger():
    import pytest

    def my_shell(): return 42

    def shell_logger_patched(*args, **kwargs):
        pass

    old_shell = os.environ['SHELL']
    os.environ['SHELL'] = "/bin/sh"

    import mock
    from . import scripts
    with mock.patch('sys.exit', new=my_shell):
        with mock.patch('scripts.shell_logger', new=shell_logger_patched):
            result = scripts.shell_logger(".test_logger.patched")
    assert result == 42

    with mock.patch('sys.exit', new=my_shell):
        with mock.patch('scripts.shell_logger') as mock_shell_logger:
            result = scripts.shell_logger(".test_logger.patched")

# Generated at 2022-06-24 05:32:51.392120
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import random
    from .. import const

    LOG_FILENAME = "/tmp/logger-test.log"
    FILE_SIZE_IN_BYTES = const.LOG_SIZE_IN_BYTES
    FILE_SIZE_TO_CLEAN = const.LOG_SIZE_TO_CLEAN

    # Remove previous log
    try:
        os.remove(LOG_FILENAME)
    except:
        pass

    # Create empty file
    with open(LOG_FILENAME, 'w+') as f:
        f.write("\0" * FILE_SIZE_IN_BYTES)
        f.flush()

    # Run logger
    shell_logger(LOG_FILENAME)
    time.sleep(1)

    # Test if file is not empty

# Generated at 2022-06-24 05:32:58.347336
# Unit test for function shell_logger
def test_shell_logger():
    m = Mocker()
    logs_mock = logs.__getattr__
    logs.warn = MagicMock()
    sys.exit = MagicMock()
    os_mock = os.__getattr__
    os.environ = {'SHELL': 'test_shell'}
    os.O_CREAT = MagicMock(return_value=0)
    os.O_TRUNC = MagicMock(return_value=0)
    os.O_RDWR = MagicMock(return_value=0)
    os.open = MagicMock(return_value=100)
    os.write(100, b'\x00' * const.LOG_SIZE_IN_BYTES)
    mmap.mmap = MagicMock(return_value=1)
    pty.fork = MagicMock

# Generated at 2022-06-24 05:32:59.899571
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    # Just run function!
    shell_logger(os.devnull)

# Generated at 2022-06-24 05:33:11.080555
# Unit test for function shell_logger
def test_shell_logger():

    from testserver import TestServer
    from testclient import TestClient
    from testtelnet import TestTelnet
    from struct import unpack
    from io import BytesIO

    for _ in range(int(os.environ.get('TEST_LOOP_COUNT', '1'))):

        with TestServer('127.0.0.1') as server:
            server.start()
            server.wait_until_ready()

            with TestClient(server) as client:
                client.start()

                with BytesIO() as buffer:

                    with TestTelnet(buffer) as telnet:
                        telnet.start()

                        os.write(telnet.master, b'echo hello\n')
                        data = os.read(client.master, 1024)
                        assert unpack('>I', data[:4])[0]

# Generated at 2022-06-24 05:33:20.218945
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function.
    """
    import tempfile

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            self._stderr = sys.stderr
            sys.stdout = self._stringio = StringIO()
            sys.stderr = self._stringio
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            sys.stdout = self._stdout
            sys.stderr = self._stderr

    with Capturing() as output:
        with tempfile.NamedTemporaryFile() as f:
            # Test default behavior
            shell_logger(f.name)
            f.seek(0)

# Generated at 2022-06-24 05:33:27.103466
# Unit test for function shell_logger
def test_shell_logger():  # pragma: no cover
    import io
    import ioctl_opt

    def _read(f, fd):
        position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
        f.move(0, const.LOG_SIZE_TO_CLEAN, position)
        f.seek(position)
        f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
        f.seek(position)
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            pass
        return data

    def _set_pty_size(master_fd):
        buf = array.array('h', [0, 0, 0, 0])
        fd = io.BytesIO(buf)
       

# Generated at 2022-06-24 05:33:33.828418
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import time
    import shutil
    import tempfile
    from .. import logs

    def remove_file():
        raise IOError

    shutil.copyfile('/bin/sh', '/bin/tempsh')
    os.chmod('/bin/tempsh', 0o755)

    temp_dir = tempfile.mkdtemp()

    try:
        os.environ['SHELL'] = '/bin/tempsh'
        shell_logger(temp_dir + '/output.log')
    except IOError:
        pass
    finally:
        shutil.copyfile('/bin/sh', '/bin/tempsh')
        os.chmod('/bin/tempsh', 0o755)
        shutil.rmtree(temp_dir)


# Generated at 2022-06-24 05:33:35.622246
# Unit test for function shell_logger
def test_shell_logger():
    """Test for function shell_logger"""
    shell_logger('/tmp/output.tst')

# Generated at 2022-06-24 05:33:42.982739
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import tempfile
    import time

    tfile = tempfile.NamedTemporaryFile(delete=False, suffix='.log')
    tfile.close()
    process = None


# Generated at 2022-06-24 05:33:53.559945
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time

    def _clean():
        os.remove(file_path)

    file_path = tempfile.mktemp()
    shell_logger(file_path)

    time.sleep(0.1)
    with open(file_path, 'rb') as handler:
        data = handler.read()

    _clean()
    assert data


if __name__ == '__main__':
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)

    fd = os.open('logs/shell-log', os.O_CREAT | os.O_TRUNC | os.O_RDWR)

# Generated at 2022-06-24 05:33:55.949238
# Unit test for function shell_logger
def test_shell_logger():
    file = '/tmp/shell_logger_test'
    try:
        shell_logger(file)
    except SystemExit:
        os.remove(file)
    else:
        assert False

# Generated at 2022-06-24 05:34:02.843355
# Unit test for function shell_logger
def test_shell_logger():
    log_file = os.path.join(const.LOG_DIR, 'shell_logger_test')
    if os.path.exists(log_file):
        os.unlink(log_file)

    original_argv, sys.argv = sys.argv, ['shell_logger']
    logs.init('shell_logger', log_file, 0)
    shell_logger(log_file)
    logs.close()

    if os.path.exists(log_file):
        with open(log_file) as f:
            output = f.read()
        assert output == 'shell_logger\n'
        os.unlink(log_file)
        sys.argv = original_argv
    else:
        raise Exception('log file cannot be found')


# Generated at 2022-06-24 05:34:04.226947
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("dump")

# Generated at 2022-06-24 05:34:09.239579
# Unit test for function shell_logger
def test_shell_logger():
    # Imports
    import subprocess
    import shutil
    import time
    import re

    # Regex pattern
    pattern = r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{6}) {0,}(.*)"

    # File path
    log_file = "/tmp/debug.log"

    # Cleanup
    shutil.rmtree("/tmp/test", ignore_errors=True)
    os.makedirs("/tmp/test")

    # Change current directory
    os.chdir("/tmp/test")

    # Compute the execution time of a command
    def command_execution_time(cmd):
        start = time.time()
        subprocess.check_call(cmd, shell=True)

# Generated at 2022-06-24 05:34:15.365305
# Unit test for function shell_logger
def test_shell_logger():
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)

    fd = os.open("shell_logger.log", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

    sys.exit(return_code)

# Generated at 2022-06-24 05:34:20.325455
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open("/tmp/test.txt", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.close(fd)
    return_code = _spawn("/bin/bash", partial(_read, open("/tmp/test.txt")))
    assert return_code == 0

# Generated at 2022-06-24 05:34:24.149268
# Unit test for function shell_logger
def test_shell_logger():
    """
    Check if shell logger works as expected.

    """
    assert shell_logger
    assert 'test_shell_logger' in shell_logger.__doc__
    assert isinstance(shell_logger, types.FunctionType)

# Generated at 2022-06-24 05:34:34.362399
# Unit test for function shell_logger
def test_shell_logger():
    def test_spawn(buffer):
        for i in range(const.DEFAULT_CONTENT_CHECKS):
            os.write(pty.STDOUT_FILENO, b'#' * const.LOG_SIZE_IN_BYTES)
        sys.exit(const.SUCCESS_EXIT_CODE)

    path = logs.get_temp_log_path('test.log')
    buffer = None

# Generated at 2022-06-24 05:34:41.383190
# Unit test for function shell_logger
def test_shell_logger():
    path = 'test_shell_logger'
    pid = os.fork()
    if pid == 0:
        shell_logger(path)
    else:
        input_ = 'test_\ntest_\ntest_\n'
        os.write(pty.STDOUT_FILENO, input_)
        return_code = os.waitpid(pid, 0)[1]
        with open(path, 'rb') as f:
            out = filter(lambda x: len(x) == 8, f.read().split(b'\x00'))
        assert out[0] == input_
        assert return_code == 0
        os.remove(path)

# Generated at 2022-06-24 05:34:46.519140
# Unit test for function shell_logger
def test_shell_logger():
    import random
    import string
    random_file = ''.join(random.choice(string.ascii_uppercase + string.digits) for i in range(10))
    shell_logger('/tmp/' + random_file)
    assert os.path.exists('/tmp/' + random_file)

# Generated at 2022-06-24 05:34:55.330328
# Unit test for function shell_logger
def test_shell_logger():
    from . import helpers
    from .helpers import test_logger
    from .unit import unit
    import time

    # Simple test
    log = test_logger(__name__)

    with helpers.temp_file() as tmp_file:
        unit(['shell_logger', tmp_file], log=log)
        for i in range(8):
            if os.stat(tmp_file).st_size:
                break
            time.sleep(0.1)

        assert os.stat(tmp_file).st_size > 0,  "log file is empty"

    # Logging of huge text
    with helpers.temp_file() as tmp_file:
        unit(['shell_logger', tmp_file], log=log)

# Generated at 2022-06-24 05:34:58.807745
# Unit test for function shell_logger
def test_shell_logger():
    pid = os.fork()
    if not pid:
        shell_logger('/tmp/pty.static.log')
    else:
        os.waitpid(pid, 0)
        logs.warn("Shell logger done.")
    return pid

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:35:00.719267
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/shell_logger')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:35:01.293007
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:35:08.404940
# Unit test for function shell_logger
def test_shell_logger():
    """Check if shell logger can be executed and can be closed."""
    import subprocess
    from time import sleep

    def _kill(pid):
        try:
            os.kill(pid, 15)
            sleep(3)
        except OSError:
            pass

    tests = [('ls', 0),
             ('ls -a', 0),
             ('ls -a --', 0),
             ('lss', 1)]
    for test, expected_return in tests:
        command = ['python', '-m', 'neuron.cli', 'shelllogger', '-o', '/tmp/shell_logger']
        args = ['ls']
        neuron = subprocess.Popen(command)
        sleep(1)
        neutron = subprocess.Popen(args)

# Generated at 2022-06-24 05:35:16.681246
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function
    """
    import time
    import shutil
    import subprocess

    temp_dir, temp_file = 'temp', 'temp.log'
    os.mkdir(temp_dir)
    os.chdir(temp_dir)
    shutil.copy(__file__, temp_file)
    cmd = ['python', temp_file, temp_file]
    f = open(temp_file, 'w')
    subprocess.Popen(cmd, stdin=f, stdout=f, stderr=f)
    time.sleep(2)
    os.chdir('..')
    shutil.rmtree(temp_dir)
    # assert True

# Generated at 2022-06-24 05:35:25.251850
# Unit test for function shell_logger
def test_shell_logger():
    import logging
    import tempfile
    import shutil

    class LogMock(object):
        def __init__(self):
            self.warn = logging.warn

    def mock_exit(rc):
        assert False, "exit should not be called"

    tempdir = tempfile.mkdtemp()
    try:
        logs.Log = LogMock()
        orig_exit = sys.exit
        sys.exit = mock_exit
        shell_logger(os.path.join(tempdir, "output"))
    finally:
        sys.exit = orig_exit
        shutil.rmtree(tempdir)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:35:28.033916
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:35:29.328351
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger() == None

# Generated at 2022-06-24 05:35:31.943714
# Unit test for function shell_logger
def test_shell_logger():
    buffer = io.StringIO()
    shell_logger(buffer)
    logs.info('Shell logger: %s' % buffer.getvalue())

# Generated at 2022-06-24 05:35:41.165357
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import threading
    from test_utils import find_generated_file
    from os import remove

    filename = 'shell-logger-test.txt'

    def inp(text):
        for i in text:
            time.sleep(0.1)
            os.write(pty.STDOUT_FILENO, i)
        os.write(pty.STDOUT_FILENO, '\r')

    th = threading.Thread(target=inp, args=('echo "passed"', ))
    th.start()

    shell_logger(filename)
    th.join()

    try:
        with open(filename) as f:
            assert f.read(len('passed')) == 'passed'
    finally:
        remove(filename)

# Generated at 2022-06-24 05:35:42.636988
# Unit test for function shell_logger
def test_shell_logger():
    for i in range(10):
        shell_logger('/tmp/shell_log.txt')


# Generated at 2022-06-24 05:35:43.448952
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('log.out')

# Generated at 2022-06-24 05:35:44.895281
# Unit test for function shell_logger
def test_shell_logger():
    # Check if shell logger works
    assert shell_logger('test') in [0, 1]

# Generated at 2022-06-24 05:35:49.349106
# Unit test for function shell_logger
def test_shell_logger():
    import my_env
    import tempfile
    import subprocess

    def file_get_contents(filename):
        f = open(filename, 'r')
        return f.read()

    temp = tempfile.NamedTemporaryFile(delete=False)
    my_env.setenv('SHELL', '/bin/sh')
    shell_logger(temp.name)
    result = file_get_contents(temp.name)
    os.remove(temp.name)
    assert result != ""

# Generated at 2022-06-24 05:35:59.939729
# Unit test for function shell_logger
def test_shell_logger():
    """
    Simulate the output of "ls -l"

    """
    import time
    import subprocess
    import unittest
    import tempfile
    import codecs

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.gettempdir()
            self.temp_file = tempfile.mkstemp()[1]

# Generated at 2022-06-24 05:36:05.910238
# Unit test for function shell_logger
def test_shell_logger():
    from . import tempdir
    import io
    import random

    try:
        from io import StringIO
    except ImportError:
        class StringIO(io.StringIO):
            def write(self, data):
                if isinstance(data, str):
                    data = data.encode('utf-8')
                super(StringIO, self).write(data)

    with tempdir.TemporaryDirectory() as td:
        shell_file = os.path.join(td, 'shell_logger')
        stdout = StringIO()
        stderr = StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout
        old_stderr = sys.stderr
        sys.stderr = stderr
        shell_logger(shell_file)

# Generated at 2022-06-24 05:36:12.893689
# Unit test for function shell_logger
def test_shell_logger():
    import glob
    import os
    import time
    import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.log_file = 'shell-logger-test.log'
            self.cmd = 'shell_logger({})'.format(self.log_file)

        def tearDown(self):
            os.remove(self.log_file)
            for f in glob.glob('shell-logger-test-*.log'):
                os.remove(f)
            for f in glob.glob('shell-logger-test-*-trans.log'):
                os.remove(f)

        def test_shell_logger_function(self):
            os.system(self.cmd)


# Generated at 2022-06-24 05:36:16.932478
# Unit test for function shell_logger
def test_shell_logger():
    from .. import utils

    out = '/tmp/shell_logger'
    try:
        os.remove(out)
    except FileNotFoundError:
        pass

    utils.run_function(shell_logger, out) is None
    assert 'exit' in open(out, 'r').read()

# Generated at 2022-06-24 05:36:25.072508
# Unit test for function shell_logger
def test_shell_logger():
    pid = os.fork()

    if pid == 0:
        sys.stdout.write("\x00" * const.LOG_SIZE_IN_BYTES)
        shell_logger("/tmp/test_logger.log")
        sys.exit(0)
    else:
        os.wait()
        assert os.path.exists("/tmp/test_logger.log")
        assert os.path.getsize("/tmp/test_logger.log") == const.LOG_SIZE_IN_BYTES


# vim:sts=4:sw=4:ts=4:et:

# Generated at 2022-06-24 05:36:29.536649
# Unit test for function shell_logger
def test_shell_logger():
    with open('shell.log', 'w') as shell_file:
        shell_logger('shell.log')
    # Check file size
    assert os.stat('shell.log').st_size == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-24 05:36:36.203386
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import subprocess

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'log')

    if os.environ.get('SHELL'):
        p = subprocess.Popen(['python', '-m', 'noseeker', 'shell_logger', tmp_file])
        p.wait()

        with open(tmp_file, 'r') as f:
            assert f.readline() == 'nosetests\n'

    shutil.rmtree(tmp_dir)

# Generated at 2022-06-24 05:36:36.677613
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:36:37.861363
# Unit test for function shell_logger
def test_shell_logger():
    logfile = '/tmp/logs'
    shell_logger(logfile)

# Generated at 2022-06-24 05:36:43.668936
# Unit test for function shell_logger
def test_shell_logger():
    path = '/tmp/hop_test'
    fd = os.open(path, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED,
                       mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
    assert return_code == 0
    buffer.close()
    os.close(fd)
    os.remove(path)


# vim: ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-24 05:36:44.609743
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test')

# Generated at 2022-06-24 05:36:45.244267
# Unit test for function shell_logger
def test_shell_logger():
    assert False

# Generated at 2022-06-24 05:36:54.860483
# Unit test for function shell_logger
def test_shell_logger():
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)

    fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
    print ("test_shell_logger: return_code:", return_code)


if __name__ == '__main__':
    import sys


# Generated at 2022-06-24 05:37:01.284928
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    fname = tempfile.mktemp()
    my_env = os.environ.copy()
    my_env["SHELL"] = "/bin/bash"
    p1 = subprocess.Popen([sys.executable, "-m", "pyinfra.cli.util", "shell_logger", fname], env=my_env)
    p1.communicate()
    print(open(fname).read())

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:37:10.528038
# Unit test for function shell_logger
def test_shell_logger():
    # Test if shell_logger() works properly
    from StringIO import StringIO
    import sys
    import tempfile

    # This is only for test purpose
    sys.argv = ['script', '-f', sys.stderr]

    # This is a trick
    # Because we have to use `output` in test_shell_logger()
    # But shell_logger() requires a file name
    # So, create a temp file and remember that name
    # And then replace the file object with a `StringIO` object
    # Thus `shell_logger()` will write to `StringIO`
    # And we can assert in the test function
    _, output = tempfile.mkstemp()
    buffer = StringIO()
    with open(output, 'w') as f:
        f.write(buffer)
    shell_

# Generated at 2022-06-24 05:37:14.889686
# Unit test for function shell_logger
def test_shell_logger():
    logs.info("Test shell_logger")
    import subprocess
    import time
    import shutil
    import tempfile

    time.sleep(0.1)
    with tempfile.NamedTemporaryFile() as log:
        log.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        log.seek(0)

        proc = subprocess.Popen(
            "python3 -m luigi_pipeline.unix.shell_logger %s" % log.name,
            stdin=subprocess.PIPE,
            shell=True
        )

        proc.communicate(b'text')

        with tmpfile() as m:
            shutil.copy(log.name, m.name)

# Generated at 2022-06-24 05:37:16.997179
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('test_shell_logger.log') is None

# Generated at 2022-06-24 05:37:20.648142
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil

    try:
        output = tempfile.NamedTemporaryFile(delete=False)
        output.close()
        shell_logger(output.name)
    finally:
        shutil.rmtree(output.name)

# Generated at 2022-06-24 05:37:25.413865
# Unit test for function shell_logger

# Generated at 2022-06-24 05:37:27.377245
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('/tmp/shell_logger_test.log')
    except OSError:
        pass
    except SystemExit:
        pass

# Generated at 2022-06-24 05:37:28.422989
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(output='/tmp/output.log')

# Generated at 2022-06-24 05:37:28.893528
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:37:37.924432
# Unit test for function shell_logger
def test_shell_logger():
    logs.disable()

    file_name = 'test.log'
    pid = os.fork()

    if pid == 0:
        import os
        os.environ['SHELL'] = 'sh'
        shell_logger(file_name)

    os.waitpid(pid, 0)

    assert os.path.exists(file_name)
    assert os.path.getsize(file_name) <= const.LOG_SIZE_IN_BYTES

    try:
        with open(file_name, 'r') as f:
            assert f.readline() == '$ '
    finally:
        os.unlink(file_name)

# Generated at 2022-06-24 05:37:38.933916
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger


# Generated at 2022-06-24 05:37:47.124436
# Unit test for function shell_logger
def test_shell_logger():
    logs.info('Test for function shell_logger start')

    try:
        os.environ['SHELL']
    except:
        logs.warn("Shell logger doesn't support your platform.")
    try:
        os.close(1)
        os.close(2)
        os.close(3)
    except:
        pass

    # Initialize the file name
    output = '/home/nao/nplus_logs/test_shell_logger.txt'

    # Initialize the terminal status
    pty_flag = False
    mode_flag = False
    fd_flag = False

    # Test for the module pty
    try:
        import pty
        pty_flag = True
    except:
        logs.warn('The module pty is not available')

    # Test for the module tty


# Generated at 2022-06-24 05:37:48.154619
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_log')


# Generated at 2022-06-24 05:37:57.291118
# Unit test for function shell_logger
def test_shell_logger():
    """Unit tests for shell logger.

    Run this file to test shell logger. It will create a /tmp directory
    with log file in it.

    """

    with open('/tmp/shell_logger_test.txt', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    fd = os.open('/tmp/shell_logger_test.txt', os.O_RDWR)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

    pid, master_fd = pty.fork()

    if pid == pty.CHILD:
        os.execlp('/bin/bash', '/bin/bash')


# Generated at 2022-06-24 05:38:01.851699
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    def fetch_log(output):
        with open(output, 'rb') as f:
            return f.read().decode('utf-8').strip()

    tmp_file = tempfile.mktemp(prefix="shell_logger-")
    with open(os.devnull, 'w') as devnull:
        sys.stdout = devnull
        try:
            shell_logger(tmp_file)
            assert False
        except SystemExit as e:
            assert e.code == 0
            log = fetch_log(tmp_file)
            assert '$' in log
            assert '#' in log
            assert log.endswith('exit')

# Generated at 2022-06-24 05:38:05.486427
# Unit test for function shell_logger
def test_shell_logger():
    """If output file doesn't exist, it should be created."""
    path = 'test/.log_output.txt'
    if os.path.isfile(path):
        os.remove(path)

    shell_logger(path)

    assert os.path.isfile(path)
    os.remove(path)

# Generated at 2022-06-24 05:38:08.907190
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile(mode='w+') as f:
        return_code = shell_logger(f.name)
        assert return_code == os.EX_OK
        f.seek(0)
        assert len(f.read().encode()) == const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-24 05:38:14.889600
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('./data.txt', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
    buffer.seek(0)
    print(buffer.readline())
    print(buffer.readline())
    print(buffer.readline())
    print(buffer.readline())
    buffer.close()
    os.close(fd)
    sys.exit(return_code)



# Generated at 2022-06-24 05:38:20.563519
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/shell-logger.bin'
    shell_logger(output)

    try:
        assert os.path.exists(output)
        assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    finally:
        os.remove(output)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:38:27.265685
# Unit test for function shell_logger
def test_shell_logger():
    import os, pty, tempfile, mmap
    from contextlib import contextmanager

    @contextmanager
    def temp_file(size):
        temp = tempfile.mktemp()
        fd = os.open(temp, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * size)
        buffer = mmap.mmap(fd, size, mmap.MAP_SHARED, mmap.PROT_WRITE)
        yield temp, buffer
        os.close(fd)
        os.remove(temp)

    def shell_logger(output):
        if not os.environ.get('SHELL'):
            logs.warn("Shell logger doesn't support your platform.")
            sys.exit(1)

        fd

# Generated at 2022-06-24 05:38:29.582575
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: test shell_logger()
    pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:38:30.059598
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:38:32.403185
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(os.path.join(os.getcwd(), 'test', 'data', 'logger.txt'))


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:38:32.883018
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:38:39.020697
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open(const.SHELL_LOG_PATH, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    # Testing if the function can be called
    try:
        shell_logger(const.SHELL_LOG_PATH)
    except:
        return -1
    return 0


# Generated at 2022-06-24 05:38:39.918376
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-24 05:38:43.172695
# Unit test for function shell_logger
def test_shell_logger():
    file_name = os.path.join(os.path.dirname(__file__), "test.dat")
    # overwrite old file content
    if os.path.exists(file_name):
        os.remove(file_name)

    shell_logger(file_name)

# Generated at 2022-06-24 05:38:46.748252
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import shutil
    import tempfile
    class TestShellLogger(unittest.TestCase):
        def testProperExitCode(self):
            with tempfile.NamedTemporaryFile() as tmp_file:
                shell_logger(tmp_file.name)

    unittest.main(verbosity=2)
# Define function clean_log if running as unit test
test_shell_logger.clean_log = clean_log

# Generated at 2022-06-24 05:38:57.909153
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('tmp_shell.log', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn('/bin/sh', partial(_read, buffer))
    print ('\nParsing the command line output: \n')
    with open('tmp_shell.log', 'r') as file_handle:
        print (file_handle.read())

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:39:03.958379
# Unit test for function shell_logger
def test_shell_logger():
    # Simulate stdin
    sys.stdin.readline = lambda: b'hello world\n'
    # Simulate stdout
    lines = ['hello world\n', 'hello world\n']
    sys.stdout.isatty = lambda: True
    sys.stdout.fileno = lambda: 1
    def _read(fd):
        return lines.pop()
    sys.stdout.buffer.read = _read
    shell_logger('test.txt')
    with open('test.txt', 'r') as f:
        assert f.read() == 'hello world\n' * 2

# Generated at 2022-06-24 05:39:05.337136
# Unit test for function shell_logger
def test_shell_logger():
    from io import BytesIO

    tmp_file = BytesIO()
    shell_logger(tmp_file)

# Generated at 2022-06-24 05:39:07.470337
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: Implement unit test for function shell_logger
    pass

# Generated at 2022-06-24 05:39:18.643957
# Unit test for function shell_logger
def test_shell_logger():
    def size():
        return os.stat('/tmp/test').st_size

    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)

    os.system('echo -n "echo 123" > /tmp/test && rm /tmp/test')
    assert size() == 0

    shell_logger('/tmp/test')
    assert size() == 0

    os.system('echo -n "echo 123" > /tmp/test && rm /tmp/test')
    shell_logger('/tmp/test')
    assert size() == 7

    const.LOG_SIZE_IN_BYTES = 11
    const.LOG_SIZE_TO_CLEAN = 5


# Generated at 2022-06-24 05:39:22.432750
# Unit test for function shell_logger
def test_shell_logger():
    out_file = tempfile.NamedTemporaryFile() #creates a temporary file for test
    sys.argv = ['shell_logger', out_file.name] #sets arguments for command line
    shell_logger(out_file.name) #executes the function
    out_file.seek(0)
    out_file.read()
    out_file.close()
    #check if tmp file has the expected results

# Generated at 2022-06-24 05:39:28.971211
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import subprocess
    from . import utils

    output = 'tests/fixtures/test_shell_logger'
    cmd = '''
    import os;
    os.execvp(
        '{0}', ['{0}', 'tests/fixtures/test_shell_logger']
    )
    '''.format(sys.executable)
    subprocess.Popen(['/bin/sh', '-i', '-c', cmd])
    while not os.path.exists(output):
        time.sleep(1)
    output = utils.read_file(output)
    assert len(output) == const.LOG_SIZE_IN_BYTES
    assert output.count(b'\x00') == const.LOG_SIZE_IN_BYTES



# Generated at 2022-06-24 05:39:30.027881
# Unit test for function shell_logger
def test_shell_logger():
    """
    Tests shell_logger function.
    """
    assert shell_logger


# Generated at 2022-06-24 05:39:39.843333
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function
    """
    import unittest
    import tempfile
    import shutil
    import subprocess

    class FakeUnittest(unittest.TestCase):
        """
        Fake unittest to run the test.
        """
        def test_shell_logger(self):
            """
            Test shell_logger function
            """
            tmpdir = tempfile.mkdtemp()
            tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
            os.write(tmpfile.file.fileno(), b'\x00' * const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-24 05:39:49.713025
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import time
    import sys
    if not hasattr(sys, 'real_prefix'):
        # Anaconda virtualenv, but running under system Python.
        print('Ignoring test_shell_logger, as system Python is not in a virtualenv')
        return

    if shutil.which('script') is None:
        print('Ignoring test_shell_logger, as script(1) not available')
        return

    temp_output = './test_output.txt'
    import subprocess
    result = subprocess.run(
        [
            'script',
            '-f',
            '-q',
            temp_output,
        ], input='echo foo\nexit\n'.encode('utf-8'), stdout=subprocess.PIPE
    )

# Generated at 2022-06-24 05:39:51.751447
# Unit test for function shell_logger
def test_shell_logger():
    logs.shell.init()
    shell_logger("test.txt")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:39:52.166500
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:39:57.985530
# Unit test for function shell_logger
def test_shell_logger():
    """
    A test for `shell_logger` function.
    """
    # Mock command function.
    def command(cmd, pty=True):
        return b'some data'

    # Mock input.
    def input(prompt):
        return 'some user input'

    # Mock open function.
    def open(filename, mode='w'):
        return MockFile()

    # Mock file class.
    class MockFile:
        def __init__(self):
            self.data = []

        def write(self, data):
            self.data.append(data)

    # Mock mmap class.
    class MockMmap:
        def __init__(self, *args):
            pass

        def __enter__(self):
            return self

        def __exit__(self):
            pass


# Generated at 2022-06-24 05:39:59.095080
# Unit test for function shell_logger
def test_shell_logger():

    # TODO: add unit test
    pass

# Generated at 2022-06-24 05:40:09.665099
# Unit test for function shell_logger
def test_shell_logger():
    import filecmp
    import io
    import os
    import shutil
    import tempfile
    import unittest

    test_data = "foo\nbar\n"
    with tempfile.TemporaryDirectory() as tempdir:
        with tempfile.NamedTemporaryFile(dir=tempdir) as logfile:
            with tempfile.NamedTemporaryFile(mode='w+b', dir=tempdir) as stdin:
                with tempfile.NamedTemporaryFile(mode='w+b', dir=tempdir) as expected:
                    # Write test data to stdin
                    stdin.write(test_data.encode('utf-8'))
                    stdin.flush()
                    # Write expected data to file
                    expected.write(b'\x00' * const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-24 05:40:13.764397
# Unit test for function shell_logger
def test_shell_logger():
    with TemporaryFile(prefix='output_') as f:
        pid = multiprocessing.Process(target=shell_logger, args=(f.name,))
        pid.start()
        time.sleep(1)
        pid.terminate()
        with open(f.name, 'rb') as out:
            assert out.read(const.LOG_SIZE_IN_BYTES) != b'\x00' * const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-24 05:40:14.353428
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:40:17.945066
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: add test for mmap
    os.chdir('/')
    shell_logger('/tmp/out.txt')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:40:27.103116
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import os
    import select
    import time
    import errno
    import stat

    rand = str(int(time.time()))
    filename = rand + '.script'
    output = os.path.abspath(filename)
    if os.path.isfile(output):
        os.remove(output)
    proc = subprocess.Popen(['python2', '-c', 'from agent import runner; runner.shell_logger("' + output + '")'], stdin=subprocess.PIPE)
    time.sleep(3)

    try:
        proc.kill()
    except OSError as e:
        if e.errno != errno.ESRCH:
            raise
    proc.wait()
    time.sleep(1)

    assert stat.S_ISREG

# Generated at 2022-06-24 05:40:33.241313
# Unit test for function shell_logger
def test_shell_logger():
    def _test_shell_logger_output(fd):
        assert os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES) == const.LOG_SIZE_IN_BYTES
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        _spawn(os.environ['SHELL'], partial(_read, buffer))

    with tempfile.TemporaryFile() as tf:
        _test_shell_logger_output(tf.fileno())
    with tempfile.NamedTemporaryFile() as tf:
        _test_shell_logger_output(tf.fileno())

# Generated at 2022-06-24 05:40:42.766769
# Unit test for function shell_logger
def test_shell_logger():
    """
    $ py.test tests/logs/test_logging.py::test_shell_logger
    """

    def run_slave():
        msg = b'foo bar\n'
        fd = os.open(const.LOG_PATH, os.O_CREAT | os.O_RDWR)
        os.write(fd, msg)

        os.close(0)
        os.close(1)
        os.close(2)

        _spawn(os.environ['SHELL'], os.read)
        sys.exit(0)

    def check_result():
        assert os.path.isfile(const.LOG_PATH)

# Generated at 2022-06-24 05:40:48.666178
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    input = tempfile.TemporaryFile()
    input.write(b'Test\n')
    input.flush()
    input.seek(0)

    output = tempfile.TemporaryFile()

    pty.spawn = lambda shell, master_read: master_read(0, output)
    shell_logger(input)
    output.seek(0)
    assert output.read() == b'Test\n'



# Generated at 2022-06-24 05:40:55.971496
# Unit test for function shell_logger
def test_shell_logger():
    import sys
    import subprocess
    old_sys = sys.argv
    sys.argv = ['shell_logger', 'tmp_file']
    with open('tmp_file', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
    subprocess.call('cd .. && python shell_logger.py tmp_file', shell=True)
    sys.argv = old_sys

# Generated at 2022-06-24 05:40:59.812056
# Unit test for function shell_logger
def test_shell_logger():
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        return
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()
    try:
        shell_logger(temp_file.name)
    finally:
        os.unlink(temp_file.name)

# Generated at 2022-06-24 05:41:11.335703
# Unit test for function shell_logger
def test_shell_logger():
    import pytest
    from io import StringIO
    import fcntl

    class File:
        def __init__(self):
            self.count = 0

        def read(self, size):
            self.count += 1
            if self.count % 2 == 0:
                return '#' * (size // 2)
            else:
                return '#' * size

        def move(self, *args):
            pass

        def seek(self, position):
            pass

        def write(self, data):
            pass

    with pytest.raises(SystemExit) as excinfo:
        shell_logger(output='no_existent_file')
    assert excinfo.value.code == 1

    f = File()

# Generated at 2022-06-24 05:41:14.087123
# Unit test for function shell_logger
def test_shell_logger():
    """
    TODO
    """
    logs.info('test_shell_logger')
    return

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:41:22.491469
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import os
    import tempfile
    from . import logs
    from . import const

    def fake_logs_warn(message):
        pass

    logs.warn = fake_logs_warn

    with tempfile.NamedTemporaryFile(delete=False) as temp:
        temp_file_name = temp.name

    process = subprocess.Popen([sys.executable, '-m', 'pywatchman.tools.shell', temp_file_name])
    del process

    with open(temp_file_name) as temp:
        os.remove(temp_file_name)
        assert temp.read().startswith(const.HEADER)

if __name__ == '__main__':
    if len(sys.argv) == 1:
        print('Usage:')

# Generated at 2022-06-24 05:41:23.416667
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    pass

# Generated at 2022-06-24 05:41:28.051980
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import time
    output_filepath = tempfile.mktemp()
    try:
        shell_logger(output_filepath)
    finally:
        shutil.rmtree(output_filepath)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:41:29.574634
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(__file__ + '_1') == 0

# Generated at 2022-06-24 05:41:35.621554
# Unit test for function shell_logger
def test_shell_logger():
    import mock
    import tempfile
    import shutil
    import subprocess
    import time

    TEST_SHELL = '/bin/sh'
    TEST_SHELL_LOG = '/dev/null'
    LOG_SIZE_TO_CLEAN = 1024
    TEST_LOG_SIZE_IN_BYTES = 4096
    TEST_FILE_SIZE = 2048
    TEST_LOG_CONTENT = 'Test log content'

    def _get_mocked_shell_logger(mocked_shell, mocked_logger):
        """Returns patched shell logger function.

        Patches following function:

        * _spawn
        * os.write
        * os.open
        * mmap.mmap

        """
        shell_logger_local = lambda output: shell_logger(output)


# Generated at 2022-06-24 05:41:38.354279
# Unit test for function shell_logger
def test_shell_logger():
    file = os.path.join(os.getcwd(), 'shell_logger_test')
    shell_logger(file)
    assert os.path.isfile(file)
    os.remove(file)

# Generated at 2022-06-24 05:41:39.701550
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/test_shell_logger') == 0

# Generated at 2022-06-24 05:41:41.808644
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("test.txt")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:41:45.982787
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger
    """
    import tempfile
    import time

    temp_write = tempfile.NamedTemporaryFile()
    shell_logger(temp_write.name)

    # Check file contents
    temp_read = open(temp_write.name, "rb")
    # Account for empty bytes at the start of the file
    temp_read.seek(256)
    contents = temp_read.read()
    assert contents.find(b"echo") > 0
    temp_read.close()



# Generated at 2022-06-24 05:41:49.118319
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test.output'
    shell_logger(output)
    with open(output, 'rb') as f:
        assert f.read(1) == b'\x00'
    os.unlink(output)

# Generated at 2022-06-24 05:41:52.614091
# Unit test for function shell_logger
def test_shell_logger():
    try:
        # Don't log shell output in unit test
        shell_logger(_)
    except AssertionError:
        # AssertionError is expected
        return
    raise AssertionError('No AssertionError was raised')

# Generated at 2022-06-24 05:42:03.229234
# Unit test for function shell_logger
def test_shell_logger():
    import pty
    import mmap
    import os
    import os.path
    import sys
    import time

    def _read(fd):
        data = os.read(fd, 1024)
        return data

    def _spawn(master_read):
        """Create a spawned process.

        Modified version of pty.spawn with terminal size support.

        """
        pid, master_fd = pty.fork()

        if pid == pty.CHILD:
            os.execlp('/bin/sh', '/bin/sh')

        try:
            pty._copy(master_fd, master_read, pty._read)
        except OSError:
            pass

        os.close(master_fd)
        return os.waitpid(pid, 0)[1]


# Generated at 2022-06-24 05:42:09.010596
# Unit test for function shell_logger
def test_shell_logger():
    from . import tmpdir
    from . import assert_has_lines
    from . import assert_exists
    tmpdir.setup()
    shell_logger(os.path.join(tmpdir.TMP_DIR, 'shell.log'))
    assert_exists(os.path.join(tmpdir.TMP_DIR, 'shell.log'))
    assert_has_lines(os.path.join(tmpdir.TMP_DIR, 'shell.log'))
    tmpdir.cleanup()

# Generated at 2022-06-24 05:42:10.386534
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('test') == None

# Generated at 2022-06-24 05:42:12.149565
# Unit test for function shell_logger
def test_shell_logger():
    cmd = 'echo $(echo test)'
    output = 'test.log'
    shell_logger(output)
    with open(output) as f:
        assert f.read() == cmd