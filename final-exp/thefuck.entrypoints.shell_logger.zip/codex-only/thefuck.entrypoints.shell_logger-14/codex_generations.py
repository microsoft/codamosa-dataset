

# Generated at 2022-06-24 05:32:01.539967
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger() == 0

# Generated at 2022-06-24 05:32:09.669359
# Unit test for function shell_logger
def test_shell_logger():
    import os
    from . import utils
    from . import tests

    input_text = "\n".join(["abc", "def", "ghi", "jkl", "mnopqrstuvwxyz"])

    def _test_shell(shell_path, input_text):
        test_file = tests.temp_file('test_shell_logger_' + shell_path)
        shell_logger(test_file)
        utils.write_to_stdin(input_text)
        assert utils.read_file(test_file) == input_text

    if os.name == "nt":
        print("Can't be tested on Windows")
        return

# Generated at 2022-06-24 05:32:12.173742
# Unit test for function shell_logger
def test_shell_logger():
    # Ensure out put file is empty before test
    open(const.TEST_OUTPUT, 'w').close()
    code = shell_logger(const.TEST_OUTPUT)
    assert code == 0


# Generated at 2022-06-24 05:32:17.333262
# Unit test for function shell_logger
def test_shell_logger():
    output = "test_shell_logger"
    return_code = shell_logger(output)
    with open(output, "r") as file:
        data = file.read()
    os.remove(output)
    assert data == '\x00'*1024
    assert not return_code

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:32:24.711261
# Unit test for function shell_logger
def test_shell_logger():
    import __main__
    __main__.__file__ = '/usr/local/bin/pil'

    os.environ['SHELL'] = '/bin/bash'

    import tempfile
    fd, file = tempfile.mkstemp()

    try:
        shell_logger(file)
    except SystemExit:
        pass
    os.close(fd)

    if os.path.getsize(file) > const.LOG_SIZE_IN_BYTES:
        assert False

    os.remove(file)

# Generated at 2022-06-24 05:32:30.385297
# Unit test for function shell_logger
def test_shell_logger():
    from . import logs, const
    import os
    import os.path
    import subprocess
    import time
    import unittest
    import sys

    def clean_old_files():
        for test_file in os.listdir():
            if test_file.startswith('test_file') and 'txt' in test_file:
                os.remove(test_file)

    class ShellLoggerTestCase(unittest.TestCase):
        def test_shell_logger(self):
            with open('test_file.txt', 'w') as f:
                f.write("Test log")
            with open('test_file.txt', 'r') as f:
                output = f.read()

            # Run real shell to feed it with input data

# Generated at 2022-06-24 05:32:39.274586
# Unit test for function shell_logger
def test_shell_logger():
    import contextlib
    import subprocess
    import time

    def get_subprocess_output(proc, timeout=5.0):
        """Returns the stdout of the subprocess.

        Raises AssertionError if the process output is empty.

        """
        try:
            out_stream = proc.stdout
            retcode = proc.poll()
            start_time = time.time()
            while retcode is None and (time.time() - start_time < timeout):
                out_stream.flush()
                time.sleep(0.1)
                retcode = proc.poll()
        finally:
            out_stream.close()
        output = proc.stdout.read()
        assert output, "Empty output of subprocess"
        return output


# Generated at 2022-06-24 05:32:45.660855
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import tarfile
    from . import memfs
    from . import utils

    test_fs = memfs.MemFS()

    logs.debug = lambda x: x

    # Create test archive
    output = test_fs.open('output', 'wb')
    utils.add_logs_to_archive(output)
    output.close()

    # Create log file
    with memfs.open('log', 'wb') as output:
        shell_logger(output)

    # Check log file
    log = memfs.open('log', 'rb')
    good_log = io.BytesIO()
    with tarfile.open(fileobj=output, mode='r') as archive:
        good_log.write(archive.extractfile(const.LOG_FILE).read())

# Generated at 2022-06-24 05:32:53.438117
# Unit test for function shell_logger
def test_shell_logger():
    """
    test case:
        check if the function shell_logger is working.
        it will use the const.LOG_OUTPUT_FILE_NAME file to verify the output of the function.
        then it will compare it with const.LOG_EXPECTED_FILE_NAME file,
        if the output content is identical with the expected output, it will return 0, otherwise it will return 1.

    Usage:
        py.test tests/app/logs/test_shell_logger.py
    """
    import filecmp
    shell_logger(const.LOG_OUTPUT_FILE_NAME)
    assert(filecmp.cmp(const.LOG_OUTPUT_FILE_NAME, const.LOG_EXPECTED_FILE_NAME) == True)

# Generated at 2022-06-24 05:33:00.237350
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import tempfile
    import shlex
    import subprocess
    import os
    from subprocess import PIPE
    from .. import logs

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            # create temp file
            fd, self.output = tempfile.mkstemp()
            os.close(fd)

        def tearDown(self):
            # remove temp files
            if os.path.isfile(self.output):
                os.remove(self.output)


# Generated at 2022-06-24 05:33:11.456545
# Unit test for function shell_logger
def test_shell_logger():
    # pylint: disable=W0612
    def run_logger(files, func, *args, **kwargs):
        old_files = {}
        try:
            old_files = {f: open(f, mode) for f, mode in files.items()}
            func(*args, **kwargs)
        finally:
            for name, f in old_files.items():
                f.close()
                os.remove(name)

    def assert_log_file(file_, data):
        assert open(file_).read() == data

    def test_exception():
        files = {'some': 'w'}
        run_logger(files, shell_logger, 'some')

    def test_empty():
        files = {'some': 'w'}

# Generated at 2022-06-24 05:33:14.117853
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for shell_logger"""
    shell_logger('test.log')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:33:22.580471
# Unit test for function shell_logger
def test_shell_logger():
    from .test_utils import TempFile
    from ..const import LOG_SIZE_IN_BYTES

    def check(result, expected):
        assert len(result) == len(expected)
        assert result == expected

    with TempFile() as output:
        shell_logger(output)
        with open(output, 'r') as f:
            result = f.read()
        expected = '\x00' * LOG_SIZE_IN_BYTES
        check(result, expected)

    with open(output, 'w') as f:
        f.write('x' * LOG_SIZE_IN_BYTES)
    shell_logger(output)
    with open(output, 'r') as f:
        result = f.read()

# Generated at 2022-06-24 05:33:23.372399
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/example')

# Generated at 2022-06-24 05:33:30.806540
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import re
    import subprocess
    import sys
    import threading

    import unittest

    try:

        from .. import const, logs, __version__

        from . import shell_logger

    except ImportError:
        # For the test to work localy
        sys.path.insert(1, os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))))
        import const
        import logs
        from shell_logger import shell_logger

    class TestShellLogger(unittest.TestCase):

        def setUp(self):
            """Create a temporary file."""
            import tempfile

            handle, self.path = tempfile.mkstemp()
            os.close(handle)


# Generated at 2022-06-24 05:33:33.214817
# Unit test for function shell_logger
def test_shell_logger():
    path = 'shell_logger_test.txt'
    try:
        shell_logger(path)
    except IOError:
        assert False


# Generated at 2022-06-24 05:33:41.340319
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess

    logger = os.path.join(os.path.dirname(__file__), '..', '..', 'uistore', 'logger')
    cmd = [sys.executable, logger, 'test.log']

    try:
        env = os.environ.copy()
        env['SHELL'] = '/bin/bash'
        return_code = subprocess.call(cmd, env=env)
        with open('test.log', 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    finally:
        try:
            os.remove('test.log')
        except FileNotFoundError:
            pass

# Generated at 2022-06-24 05:33:52.026078
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import os
    import shutil
    import tempfile
    import subprocess
    import textwrap

    # TODO: 5/31/15 - dima - 
    #       This is some ugly code. I just don't know how to test
    #       a function that depends on file descriptors and signals
    #       and stuff.
    class test_shell_logger(unittest.TestCase):

        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_log = os.path.join(self.tmp_dir, "test_log")

        def tearDown(self):
            shutil.rmtree(self.tmp_dir, ignore_errors=True)


# Generated at 2022-06-24 05:33:54.718883
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    _, path = tempfile.mkstemp()
    try:
        os.environ['SHELL'] = '/bin/bash'
        shell_logger(path)
    finally:
        os.remove(path)

# Generated at 2022-06-24 05:34:01.856018
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import os
    import filecmp
    import shutil
    import tempfile
    import pexpect
    import time

    path = tempfile.mkdtemp()
    log_name = 'test_for_shell_logger.log'
    fd, log_path = tempfile.mkstemp()

    child = pexpect.spawn("python3 shell_logger.py %s/%s" % (path, log_name))
    child.sendline("echo 'hello world!'; exit")
    child.expect(pexpect.EOF)
    child.close()

    time.sleep(1)

    child = pexpect.spawn("python3 shell_logger.py %s/%s" % (path, log_name))
    child.sendline("echo 'hello world!'; exit")

# Generated at 2022-06-24 05:34:11.502027
# Unit test for function shell_logger
def test_shell_logger():
    output = 'output.log'
    os.environ['SHELL'] = 'bash'
    os.environ['PS1'] = ' '
    # test log
    shell_logger(output)
    with open(output, 'rb') as output_file:
        output_file.seek(0, 2)
        LOG_LEN = output_file.tell()
    assert LOG_LEN > 0

    # test clean log
    shell_logger(output)
    with open(output, 'rb') as output_file:
        output_file.seek(0, 2)
        LOG_LEN = output_file.tell()
    assert LOG_LEN == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-24 05:34:14.145963
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger."""
    pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:34:23.611159
# Unit test for function shell_logger
def test_shell_logger():
    # create temporary file
    with tempfile.NamedTemporaryFile() as file:
        buffer = mmap.mmap(file.fileno(), const.LOG_SIZE_IN_BYTES,
                           mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = subprocess.call(["python3", "shell_logger.py", file.name])
        assert return_code == 0

        # mkdir and cd to it
        subprocess.call(["mkdir", "temp"])
        subprocess.call(["cd", "temp"])

        # make sure we are in temp directory
        file.seek(0)
        buffer.readline()
        buffer.readline()
        buffer.readline()
        assert b"cd temp" in buffer.readline()

        # go up

# Generated at 2022-06-24 05:34:28.989624
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import time

    file_name = tempfile.mkstemp()[1]
    shell_logger(file_name)
    time.sleep(1)

    print('\nThe following log was written to {}\n'.format(file_name))
    with open(file_name) as f:
        print(f.read())

    os.remove(file_name)

# Generated at 2022-06-24 05:34:31.480068
# Unit test for function shell_logger
def test_shell_logger():
    if os.system("script -qfq ./test/logs.txt /dev/null") == 0:
        assert True
    else:
        assert False

# Generated at 2022-06-24 05:34:32.414311
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test.tmp')
    assert True

# Generated at 2022-06-24 05:34:33.355142
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("/tmp/output") is None

# Generated at 2022-06-24 05:34:38.359751
# Unit test for function shell_logger
def test_shell_logger():
    tmp_filename = 'shell_log_test.txt'
    open(tmp_filename, 'a').close()

    assert os.system('python -m ptpython.repl -m ptpython.contrib.shell_logger {f}'.format(f=tmp_filename)) == 0
    assert os.path.exists(tmp_filename)
    assert os.path.getsize(tmp_filename) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-24 05:34:39.600065
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('/tmp/test')
    except SystemExit as e:
        assert isinstance(e, SystemExit)

# Generated at 2022-06-24 05:34:49.486318
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    from .. import const

    with tempfile.NamedTemporaryFile() as temp:
        for i in range(3):
            shell_logger(temp.name)
            os.write(sys.stdout.fileno(), b'\n')
        os.write(sys.stdout.fileno(), b'\n')
        size = os.path.getsize(temp.name)
        assert size == const.LOG_SIZE_IN_BYTES
        with open(temp.name, 'rb') as f:
            output = os.read(f.fileno(), size)
            assert b'\x00' * (const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN) in output
            assert b'\x00' * const.LOG_SIZE

# Generated at 2022-06-24 05:34:51.290254
# Unit test for function shell_logger
def test_shell_logger():
    assert 0 == shell_logger('/tmp/test.log')

# Generated at 2022-06-24 05:34:59.205449
# Unit test for function shell_logger
def test_shell_logger():
    from . import flags
    import time

    flags.set_flag('logger', shell_logger)
    flags.set_flag('log_size', 128)
    flags.set_flag('log_file', '/tmp/test.txt')
    flags.set_flag('debug', True)

    start = time.time()
    while time.time() - start < 2:
        pass

    with open('/tmp/test.txt', 'r') as f:
        assert 'Hello World' in f.read()

if __name__ == '__main__':
    import sys
    sys.modules['flags'] = sys.modules['logstash.flags']
    sys.modules['logs'] = sys.modules['logstash.logs']
    test_shell_logger()

# Generated at 2022-06-24 05:35:04.791810
# Unit test for function shell_logger
def test_shell_logger():
    path = '/tmp/%s' % id(os)
    shell_logger(path)
    assert os.path.exists(path), "File is not logged"

    try:
        f = open(path, 'rb')
        assert f.read(1) == b'\x00', "File is not empty"
    except IOError:
        assert False, "Can't open logged file"
    finally:
        f.close()

    try:
        os.remove(path)
    except OSError:
        pass

# Generated at 2022-06-24 05:35:06.333492
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test case."""
    status = shell_logger('./shell.log')
    assert status == 0



# Generated at 2022-06-24 05:35:10.174806
# Unit test for function shell_logger
def test_shell_logger():
    output = "shell_logger.out"

    # Max size seems doesn't work so remove the file if exist
    if os.path.isfile(output):
        os.remove(output)

    def _test_shell_logger():
        shell_logger(output)

    proc = threading.Thread(target=_test_shell_logger)
    proc.start()
    proc.join()

    assert os.path.isfile(output)
    os.remove(output)

# Generated at 2022-06-24 05:35:12.367960
# Unit test for function shell_logger
def test_shell_logger():
    fd = open('shell.log', 'w')
    fd.write('\x00' * const.LOG_SIZE_IN_BYTES)
    fd.close()
    shell_logger('shell.log')


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-24 05:35:21.641276
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import os
    import time

    output = '/tmp/test_shell_logger'

    if os.path.exists(output):
        os.remove(output)

    p = subprocess.Popen([
        'python',
        __file__,
        output
    ])

    while not os.path.exists(output):
        pass

    fd = os.open(output, os.O_RDONLY)
    with os.fdopen(fd, 'rb') as f:
        assert f.read(1024) == b'\x00' * 1024

    p.poll()
    p.terminate()

    time.sleep(1)

    fd = os.open(output, os.O_RDONLY)

# Generated at 2022-06-24 05:35:24.615121
# Unit test for function shell_logger
def test_shell_logger():
    out, _ = os.popen2('python -m shell-logger')
    out.write('echo hello\n')
    out.write('exit\n')
    sys.stdout.write(out.read())



# Generated at 2022-06-24 05:35:31.599621
# Unit test for function shell_logger
def test_shell_logger():
    def assert_log(file, expected):
        with open(file, 'rb') as f:
            assert f.read() == expected

    os.environ['SHELL'] = sys.executable
    with tempfile.NamedTemporaryFile(suffix='.log') as file:
        try:
            shell_logger(file.name)
        except SystemExit:
            assert_log(file.name, 'test1\ntest2\n')

# Generated at 2022-06-24 05:35:38.514362
# Unit test for function shell_logger
def test_shell_logger():
    from . import const
    from . import start_shell
    from . import logs

    logs.info("Testing shell_logger:")

    logs.info("Generating a huge shell output")
    output = "tests/shell.log"
    random_data = open("/dev/urandom", "rb").read(const.LOG_SIZE_IN_BYTES * 2)
    shell_cmd = "echo '{}' > /dev/null".format(random_data)

    try:
        open(output, 'w').close()
        start_shell.shell_logger(output)
    finally:
        os.unlink(output)

    logs.info("Shell output genetrated succesfully")
    logs.info("Comparing generated shell output")

    assert len(random_data) > const.LOG_SIZE_IN_

# Generated at 2022-06-24 05:35:45.184852
# Unit test for function shell_logger
def test_shell_logger():
    # Specify a file not exist
    try:
        shell_logger('/not_exist')
    except OSError:
        pass
    except Exception as e:
        print ('test_shell_logger: unexpected exception for file not exist')
        print (e)
        sys.exit(1)

    # Specify a file exist
    try:
        shell_logger('/tmp/test_shell_logger')
    except Exception as e:
        print ('test_shell_logger: unexpected exception')
        print (e)
        sys.exit(1)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:35:47.561788
# Unit test for function shell_logger
def test_shell_logger():
    """Tests function shell_logger.
    """
    return_code = 0
    try:
        shell_logger('/dev/null')
    except OSError:
        return_code = 1

    assert return_code == 1

# Generated at 2022-06-24 05:35:53.722579
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import os
    import subprocess
    import tempfile

    def extract_output(log_file):
        with io.open(log_file, mode='rb', buffering=0) as f:
            return f.read()

    def read_log_size(log_file):
        with io.open(log_file, mode='rb', buffering=0) as f:
            s = f.seek(0, io.SEEK_END)
            return s

    def spawn_shell(shell):
        shell_fd = os.open(shell, os.O_RDWR)

# Generated at 2022-06-24 05:35:55.101289
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("/tmp/shell.log")

# Generated at 2022-06-24 05:36:03.005423
# Unit test for function shell_logger

# Generated at 2022-06-24 05:36:11.461748
# Unit test for function shell_logger
def test_shell_logger():
    import platform

    logs.set_level(logs.Level.DEBUG)
    logs.set_handler(logs.StdErrHandler)

    file_name = 'test_' + str(os.getpid())

    if not os.environ.get('SHELL'):
        # TODO: Create some platform-independent way to run the test.
        logs.info("Shell logger doesn't support your platform.")
        sys.exit(1)

    pid = os.fork()
    if pid == 0:
        shell_logger(file_name)
    else:
        os.waitpid(pid, 0)
        assert os.path.isfile(file_name)
        logs.info("The test was successful.")


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:36:15.244404
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import pytest
    import tempfile
    with io.open(__file__, encoding='utf8') as f:
        payload = f.read()

    with tempfile.NamedTemporaryFile() as tmp:
        shell_logger(output=tmp.name)
        with open(tmp.name, 'rb') as f:
            assert f.read().decode('utf8') == payload


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:36:23.848937
# Unit test for function shell_logger
def test_shell_logger():
    from . import runner
    from . import utils

    tempdir = utils.Tempdir()
    testfile = tempdir.create_file('testfile')

    runner.Runner(shell_logger, testfile).run()
    assert os.stat(testfile).st_size == const.LOG_SIZE_IN_BYTES


if __name__ == '__main__':
    if len(sys.argv) != 2:
        logs.error("Usage: python3 -m psh.commands.plugins.shell_logger <output>")
        sys.exit(1)

    shell_logger(sys.argv[1])

# Generated at 2022-06-24 05:36:34.842012
# Unit test for function shell_logger
def test_shell_logger():
    with open('test_shell_logger.txt', 'a') as output_file:
        output_file.write('\n')
        output_file.write('Unit test has started\n')

    def clear_content_of_file(file_name):
        with open(file_name, 'w'):
            pass

    # Test case 1:
    # This test case is used to validate the case when the size of the output file is lesser than the
    # required size.
    # This case is tested by creating a file with size of 10 Bytes and then executing the shell_logger
    # function.
    output_file_size = 10
    clear_content_of_file('test_shell_logger_output.txt')

# Generated at 2022-06-24 05:36:36.323779
# Unit test for function shell_logger
def test_shell_logger():
    # No test yer, since this method is already tested in tests/test_logs.py
    pass

# Generated at 2022-06-24 05:36:43.048008
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function `shell_logger`."""
    open('output', 'w').close()
    return_code = 1

    shell_logger_process = multiprocessing.Process(target=shell_logger, args=('output',))
    shell_logger_process.start()

    try:
        while shell_logger_process.is_alive():
            sleep(0.2)

            with open('output', 'rb') as f:
                data = f.read()
                if b'[\x1b[1;32m' in data and b'[\x1b[1;31m' in data:
                    return_code = 0
                    break
    finally:
        shell_logger_process.terminate()
        os.remove('output')
    return return_code

# Generated at 2022-06-24 05:36:44.796881
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(output='/tmp/shell.log')

# test_shell_logger()

# Generated at 2022-06-24 05:36:48.060364
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    s = shell_logger(tempfile.mkstemp()[1])
    assert type(s) == int



if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:36:56.927609
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import random
    import string
    import os
    
    def randomString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))
    
    def expectedOutput(output):
        with open(output, 'r') as f:
            out = f.read()
        return out

    randomString = randomString()
    
    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, randomString)

    shell_logger(test_file)
    
    assert randomString in expectedOutput(test_file)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-24 05:37:05.591703
# Unit test for function shell_logger
def test_shell_logger():
    import filecmp

    os.environ['SHELL'] = 'bash'
    with open('tst', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        f.seek(0)
        shell_logger(f)
    with open('tst', 'rb') as f:
        assert os.path.getsize('tst') == const.LOG_SIZE_IN_BYTES, "File size is wrong"
        assert filecmp.cmp('tst', 'tst2', False), "Files are different"

    os.remove('tst')

# Generated at 2022-06-24 05:37:09.030377
# Unit test for function shell_logger
def test_shell_logger():
    from .. import irunner
    import tempfile

    def mock_spawn(shell, master_read):
        pass

    with tempfile.NamedTemporaryFile() as f:
        irunner.pty.spawn = mock_spawn
        shell_logger(f.name)

# Generated at 2022-06-24 05:37:15.086352
# Unit test for function shell_logger
def test_shell_logger():
    """Verifies that the function shell_logger is working properly.
    """
    import os
    import random
    import shutil
    import string
    import sys
    import tempfile
    import time

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 05:37:21.811300
# Unit test for function shell_logger
def test_shell_logger():
    try:
        fd = os.open("test_shell_logger", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES)
        buffer.close()
        os.unlink("test_shell_logger")
        return True
    except:
        return False


if __name__ == "__main__":
    print(test_shell_logger())

# Generated at 2022-06-24 05:37:24.323541
# Unit test for function shell_logger
def test_shell_logger():
    if os.environ.get('SHELL'):
        import time
        import subprocess

        o = '/tmp/t.log'
        shell_logger(o)

        time.sleep(1)
        os.kill(os.getpid(), signal.SIGKILL)
        time.sleep(1)

        out = subprocess.check_output(['cat', o]).decode()
        assert out.endswith('kill -9 %d\nExit 1' % os.getpid())

# Generated at 2022-06-24 05:37:30.576939
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import random

    def random_string(length):
        char_set = "abcdefghijklmnopqrstuvwxyz0123456789"
        return ''.join([random.choice(char_set) for _ in range(length)])

    file_name = 'test_{}.txt'.format(random_string(10))
    shell_logger(file_name)

    # wait for some time to write in the file
    time.sleep(1)
    with open(file_name, 'r') as f:
        content = f.read()

    # remove the file
    os.remove(file_name)

    assert content.strip()

# Generated at 2022-06-24 05:37:39.224095
# Unit test for function shell_logger
def test_shell_logger():
    # Test function shell_logger when called with a parameter
    import tempfile
    def get_content(f):
        f.seek(0)
        return f.read()
    f = tempfile.NamedTemporaryFile()
    shell_logger(f.name)
    buffer = get_content(f)
    assert(buffer == b'\x00' * const.LOG_SIZE_IN_BYTES)
    # Test function shell_logger when called without a parameter
    shell_logger()
    assert(buffer == get_content(f))

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:37:45.033104
# Unit test for function shell_logger
def test_shell_logger():
    from . import test_shell_logger_code

    logs.configure(logger=shell_logger.__name__,
                   format=const.LOG_FORMAT,
                   level=logs.DEBUG,
                   filename='/tmp/story_shell_logger.log')
    test_shell_logger_code.run()
    # TODO compare files with expected output


if __name__ == '__main__':
    test_shell_logger()
    os.unlink('/tmp/story_shell_logger.log')

# Generated at 2022-06-24 05:37:46.530663
# Unit test for function shell_logger
def test_shell_logger():
    return_code = shell_logger("./shell_logger")
    assert(0 <= return_code and return_code <= 255)

# Generated at 2022-06-24 05:37:54.437076
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import shutil
    from . import logs

    expected_log = ['1', '2', '3', '4']
    log_file = '/tmp/tmuxp-shell-logger-test'
    print('shell_logger test')
    print('please type 4 lines of text in log file')
    print('ctrl-D to quit')

    try:
        shell_logger(output=log_file)
    except KeyboardInterrupt:
        pass

    time.sleep(1)
    assert os.path.exists(log_file), 'file not created'
    logs.log_output(log_file)
    assert logs.log_tail(log_file, 4) == expected_log, 'log file test failed. check %s' % log_file



# Generated at 2022-06-24 05:38:03.174723
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('test_file', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    print(_read(buffer, 1))
    assert _read(buffer, 1) == b'\x00' * 1024

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:38:08.600341
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess

    with tempfile.NamedTemporaryFile() as f:
        subprocess.call(['python', '-m', 'envlogger.shell', f.name])

        with open(f.name, 'rb') as f:
            assert f.read()

        subprocess.call(['python', '-m', 'envlogger.shell', f.name])

        with open(f.name, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            assert f.read()


if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-24 05:38:09.630711
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(logs.get_path('output'))



# Generated at 2022-06-24 05:38:15.341533
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import os

    logfile = 'shell_logger_test'
    if os.path.isfile(logfile):
        os.remove(logfile)

    p = subprocess.Popen(
        ['python', '-m', 'tuprolog.text_tools.shell', 'shell_logger', logfile],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    stdout, stderr = p.communicate(input=(b'ls\ncd tuprolog/\nls\nls text_tools/'))

# Generated at 2022-06-24 05:38:15.987146
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:38:22.731634
# Unit test for function shell_logger
def test_shell_logger():
    class MockOutputWriter:
        def __init__(self, data):
            self.data = data
            self.pos = 0
        def write(self, data):
            self.data[self.pos:self.pos+len(data)] = data
            self.pos += len(data)
    data = bytearray(const.LOG_SIZE_IN_BYTES)
    shell_logger(MockOutputWriter(data))

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:38:24.066002
# Unit test for function shell_logger
def test_shell_logger():
    assert len(shell_logger("test_shell_logger")) == 0

# Generated at 2022-06-24 05:38:26.527056
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger."""
    try:
        shell_logger('test.log')
    except OSError:
        pass
    finally:
        try:
            os.remove('test.log')
        except OSError:
            pass

# Generated at 2022-06-24 05:38:32.112104
# Unit test for function shell_logger
def test_shell_logger():
    f = open('tmp', 'a+')
    fd = os.dup(f.fileno())
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn('/bin/bash', partial(_read, buffer))
    assert return_code == 0

# Generated at 2022-06-24 05:38:34.115902
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL']     = './test/sh-with-args'
    shell_logger('./test/test.log')

test_shell_logger()

# Generated at 2022-06-24 05:38:36.117329
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test/tmp/shell_logger.log'
    shell_logger(output)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:38:37.452960
# Unit test for function shell_logger
def test_shell_logger():
    return_code = shell_logger("/tmp/test_shell_logger.log")
    assert return_code == 0

# Generated at 2022-06-24 05:38:41.470608
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("/tmp/test") == None
    with open("/tmp/test") as outputfile:
        output = outputfile.read()
    assert("exit" in output) #If this test fails, check if your shell is supported by shell_logger

# Generated at 2022-06-24 05:38:45.818289
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: it's better to use pytest-mock to mock stdin
    sys.stdin = open(os.devnull, 'r')

    # Fake output file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        shell_logger(f.name)

    with open(f.name, 'rb') as f:
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    os.unlink(f.name)

# Generated at 2022-06-24 05:38:46.667845
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test_file')

test_shell_logger()

# Generated at 2022-06-24 05:38:54.473707
# Unit test for function shell_logger
def test_shell_logger():
    import os
    from . import test_filepath
    from . import logs_test
    from .. import logs
    from .. import const

    logs.set_logger(logs_test.TestLogger())

    filepath = test_filepath()
    shell_logger(filepath)

    assert os.path.isfile(filepath) is True
    def get_size(path):
        return os.stat(path).st_size
    assert get_size(filepath) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-24 05:38:57.778791
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('shell_logger.test')
        print('shell_logger test has passed.')
    except:
        print('shell_logger test has failed.')

# Generated at 2022-06-24 05:39:04.951112
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import subprocess

    if 'SHELL' not in os.environ:
        return

    class TestShellLogger(unittest.TestCase):
        def test_shell_logger(self):
            command = ['python', '-m', 'lumberjack.shell_logger', 'test_shell_logger']
            shell_logger_output = subprocess.check_output(command).decode('utf-8')
            expected_output = 'python -m unittest test_shell_logger\r\n'
            self.assertEqual(expected_output, shell_logger_output)

    unittest.main(exit=False, argv=[__file__, '-v'])

# Generated at 2022-06-24 05:39:08.703277
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test case for shell_logger
    """
    import unittest
    sys.exit(unittest.main())


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-24 05:39:18.981398
# Unit test for function shell_logger
def test_shell_logger():
    import os, sys

    if os.environ.get('SHELL'):
        buffer = os.environ.get('SHELL')
    else:
        buffer = "/bin/bash"
    fd = os.open("/tmp/testlogfile.txt", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(buffer, partial(_read, buffer))
    assert return_code == 0

# Generated at 2022-06-24 05:39:19.605931
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-24 05:39:26.833814
# Unit test for function shell_logger
def test_shell_logger():
    if os.name != 'posix':
        return
    import tempfile
    import subprocess
    import time
    import shutil
    test_dir = tempfile.mkdtemp()
    shutil.copy(__file__, test_dir)
    path = os.path.join(test_dir, 'shell_logger.py')
    file_name = 'output'
    str_log = 'testing'
    cmd = 'python3 %s %s' % (path, file_name)
    output_file = os.path.join(test_dir, file_name)
    # Create a child process that will run the command
    child = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)

# Generated at 2022-06-24 05:39:31.872911
# Unit test for function shell_logger
def test_shell_logger():
    """
    Tests shell_logger function with safe test output file
    """
    try:
        shell_logger('test_output_file')
    except:
        pass
    assert os.path.exists('test_output_file')
    os.remove('test_output_file')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:39:32.452484
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:39:35.172208
# Unit test for function shell_logger
def test_shell_logger():
    sys.argv = ['shell_logger.py', '1234']
    return_code = shell_logger('/tmp/test-shell-logger')
    assert return_code == 0

# Generated at 2022-06-24 05:39:35.746677
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-24 05:39:45.813790
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    from .test_util import assert_eq

    with tempfile.TemporaryDirectory() as test_dir:
        os.environ['SHELL'] = 'bash'
        with open(os.path.join(test_dir, 'input.txt'), 'w') as f:
            f.write('hello\r')
        os.spawnlp(os.P_WAIT, sys.executable, sys.executable,
                   '-c', 'import sys;from adbi import shell_logger;shell_logger("{}")'.format(os.path.join(test_dir, 'input.txt')),
                   stdin=open(os.path.join(test_dir, 'input.txt'), 'r'))

# Generated at 2022-06-24 05:39:49.788501
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger function without raise exception
    """
    import tempfile
    file_name = tempfile.mktemp(suffix='.txt', prefix='output_')
    try:
        shell_logger(file_name)
    except Exception as err:
        print(err)

# Generated at 2022-06-24 05:39:56.369765
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import subprocess

    def run_shell_logger(output):
        return subprocess.Popen(['python3', '-m', 'trafficvis', '--shell-logger', output])

    def wait_for(process):
        max_wait_time = 10
        while process.poll() is None:
            time.sleep(0.1)
            max_wait_time -= 0.1
            if max_wait_time <= 0:
                return False
        return True

    # Test if shell logger works
    log_path = '/tmp/test.log'

    shell_logger = run_shell_logger(log_path)
    assert wait_for(shell_logger)
    assert shell_logger.returncode == 0


# Generated at 2022-06-24 05:40:05.714398
# Unit test for function shell_logger
def test_shell_logger():
    def run(output_file, expected_content=b''):
        def _check_log(content):
            assert content == expected_content

        if os.path.isfile(output_file):
            os.remove(output_file)

        shell_logger(output_file)
        with open(output_file, 'rb') as f:
            _check_log(f.read())

    run.description = 'Tests for function shell_logger'

    run('test')


# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4 fenc=utf-8

# Generated at 2022-06-24 05:40:12.120303
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import random
    import shutil
    import os
    import time

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, "tmp.log")
    shell_logger(tmp_file)
    tmp = open(tmp_file, 'rb')
    tmpsize = tmp.tell()
    tmp.close()

    # Test if log file has been truncated on end
    assert(tmpsize == const.LOG_SIZE_IN_BYTES)

    os.remove(tmp_file)
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-24 05:40:14.875150
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger("/tmp/test_shell_logger.txt")
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:40:15.827340
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-24 05:40:23.076496
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger.

    Test with process that writes some data to stdout and stderr.

    """
    filename = '/tmp/shell_logger_test'
    os.environ['SHELL'] = '/bin/sh'
    shell_logger(filename)

    with open(filename) as f:
        logs = f.read().decode()

    os.remove(filename)

    assert "This is stdout" in logs
    assert "This is stderr" in logs
    assert "DONE" in logs

# Generated at 2022-06-24 05:40:25.138982
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('temp.log')
    except SystemExit:
        pass
    finally:
        os.remove('temp.log')

# Generated at 2022-06-24 05:40:31.327500
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import datetime

    class ShellLoggerTest(unittest.TestCase):
        def test_shell_logger(self):
            from .. import logs
            from ..utils import shell_logger

            class TestLogger(logs.Logger):
                def __init__(self, parent):
                    super().__init__(parent)
                    self.values = []

                def log(self, log_msg):
                    self.values.append(log_msg)

            test_logger = TestLogger(logs.root_logger)
            os.environ['SHELL'] = 'true'
            now = datetime.datetime.now()
            test_output = os.path.join('test', 'shell_logger.test')
            shell_logger(test_output)

# Generated at 2022-06-24 05:40:41.345923
# Unit test for function shell_logger
def test_shell_logger():
    # Test for shell_logger
    # Test for normal output
    class TestShell(object):
        def __init__(self, shell):
            self.shell = shell
        def warn(self, message):
            self.shell = message
    class TestSystem(object):
        def __init__(self, exit_code):
            self.exit_code = exit_code
        def exit(self, code):
            self.exit_code = code

    sys.modules["__main__"].logs = TestShell("")
    sys.modules["__main__"].sys = TestSystem(0)

    fd = os.open("test_shell_logger", os.O_CREAT | os.O_TRUNC | os.O_RDWR)

# Generated at 2022-06-24 05:40:44.876392
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('tests/data/shell_logger') == 0

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    test_shell_logger()

# Generated at 2022-06-24 05:40:48.666094
# Unit test for function shell_logger
def test_shell_logger():
    """Testing that output file is not empty"""
    tmp_name = "/tmp/tmp_logs_test"
    shell_logger(tmp_name)
    assert os.path.getsize(tmp_name) > 0



# Generated at 2022-06-24 05:40:54.417009
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    try:
        output = "/tmp/test.output"
        shell_logger(output)
        assert os.path.exists(output), "File %s not found!" % output
    finally:
        if os.path.exists(output):
            os.remove(output)

# vim: et:ts=4:sw=4

# Generated at 2022-06-24 05:40:56.167636
# Unit test for function shell_logger
def test_shell_logger():
    """Test function shell_logger"""
    # shell_logger('test.log')

# Generated at 2022-06-24 05:41:01.334601
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('./test_output', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    _spawn(os.environ['SHELL'], partial(_read, buffer))
    os.close(fd)

# Generated at 2022-06-24 05:41:06.142741
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as out:
        with tempfile.TemporaryFile() as stdin:
            stdin.write(b'ls -a\n')
            stdin.seek(0)
            code = shell_logger(out.name)
            assert code != 0

# Generated at 2022-06-24 05:41:07.615819
# Unit test for function shell_logger
def test_shell_logger():
    pass
# vim:ts=4 sts=4 sw=4 et

# Generated at 2022-06-24 05:41:14.191592
# Unit test for function shell_logger
def test_shell_logger():
    def test_as_root():
        try:
            os.seteuid(0)
        except OSError:
            print("Error: This script must be run as root")
            return 1
        return 0

    if not test_as_root():
        return
    output = "tmp.out"
    shell_logger(output)
    with open(output) as f:
        assert bool(f.read())
    os.remove(output)

# Generated at 2022-06-24 05:41:20.336575
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: Consider use of a temporary file.
    import time

    test_file = 'test_shell_logger.log'
    shell_logger(test_file)
    time.sleep(0.1)

    with open(test_file) as f:
        ans = f.read()

    os.remove(test_file)
    # `ans` is not empty
    assert ans, 'Ans is empty.'


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-24 05:41:30.064378
# Unit test for function shell_logger
def test_shell_logger():
    """Test for `shell_logger`."""
    import os
    import shutil
    import subprocess
    import tempfile

    try:
        path = tempfile.mkdtemp()
        subprocess.Popen(["logs", "all", "{}/log".format(path)],
                         stdin=subprocess.PIPE).communicate(b"echo '123'")

        with open('{}/log'.format(path), 'r') as log:
            assert "123" in log.read()

        with open('{}/log'.format(path), 'r') as log:
            assert "echo '123'" in log.read()
    finally:
        shutil.rmtree(path)



# Generated at 2022-06-24 05:41:35.857303
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import os.path
    import time
    from random import shuffle

    test_file = '/tmp/shell-logger'
    # unittest for functions in src.utils.logs
    test_shell_logger_functions = ['shell_logger']
    with subprocess.Popen([os.path.join(os.path.dirname(__file__), '..', '..', 'shell-logger'), test_file],
                          stdin=subprocess.PIPE) as proc:
        time.sleep(1)
        proc.communicate(input=b'echo -n abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ; exit\n')
    assert proc.returncode == 0

# Generated at 2022-06-24 05:41:39.032241
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(output="./test_shell_logger")
    with open("./test_shell_logger", "r") as f:
        print(repr(f.read()))
# test_shell_logger()

# Generated at 2022-06-24 05:41:42.125273
# Unit test for function shell_logger
def test_shell_logger():
    """Test for shell_logger()."""
    test_file = 'temp_shell.log'
    shell_logger(test_file)
    assert True == os.path.exists(test_file)
    os.remove(test_file)

# Generated at 2022-06-24 05:41:43.280782
# Unit test for function shell_logger
def test_shell_logger():
    # This function is impossible to unit test, given that it spawns a shell.
    pass

# Generated at 2022-06-24 05:41:49.991523
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as f:
        import subprocess
        p = subprocess.Popen([sys.executable, '-c',
                              'import sys; sys.exit(0)'],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             stdin=subprocess.PIPE, shell=True)
        shell_logger(f.name)

    # todo: test output

# Generated at 2022-06-24 05:41:54.509512
# Unit test for function shell_logger
def test_shell_logger():
    output_file_name = "test_shell_logger.txt"
    shell_logger(output_file_name)
    assert os.path.exists(output_file_name)
    os.remove(output_file_name)

if __name__ == "__main__":
    output = sys.argv[1]
    shell_logger(output)

# Generated at 2022-06-24 05:41:59.881092
# Unit test for function shell_logger
def test_shell_logger():
    import threading
    import tempfile
    import time
    from contextlib import contextmanager

    with tempfile.NamedTemporaryFile() as f:
        def target():
            time.sleep(0.1)
            os.system("pwd")
            time.sleep(0.1)

        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        shell_logger(f.name)
        thread.join()

        buffer = mmap.mmap(f.fileno(), const.LOG_SIZE_IN_BYTES,
                           mmap.MAP_SHARED, mmap.PROT_READ)
        assert os.path.abspath(os.path.curdir) in buffer.readline().decode('utf-8')

# Generated at 2022-06-24 05:42:08.228952
# Unit test for function shell_logger
def test_shell_logger():
    """
    $ python3 -m doctest -v xonsh/logs/shell_logger.py
    Todo:
        1. test.log is not a good name.
        2. need to skip the first line, because it is a byte flag.
           (in case, ctrl + c is used to exit the shell)
        3. need to trim the last line, it is an empty line.
    """
    sys.argv.append('test.log')
    shell_logger(sys.argv[-1])
    with open(sys.argv[-1], 'rb') as f:
        for line in f.readlines():
            print(line.decode(), end='')
    print('test.log created')