

# Generated at 2022-06-12 10:32:19.817803
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import subprocess
    
    # Test if it supports everyday used shells
    if os.path.isfile('/bin/bash'):
        subprocess.Popen(['bash'])
    if os.path.isfile('/bin/sh'):
        subprocess.Popen(['sh'])
    
    # Test if it crashes on none-exist shell file
    try:
        subprocess.Popen(['/none-exist/shell'])
    except OSError as e:
        assert e is not None
    # Test if it crashes on none-exist argument
    try:
        subprocess.Popen(['none-exist-shell'])
    except OSError as e:
        assert e is not None

# Generated at 2022-06-12 10:32:23.752305
# Unit test for function shell_logger
def test_shell_logger():
    """
    Unit test for function shell_logger.
    """
    shell_logger('shell_logger.out')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:32:29.831914
# Unit test for function shell_logger
def test_shell_logger():
    """Ensure shell_logger function works correctly."""
    logs.init('DEBUG')
    fd = os.open(os.path.join(const.CWD, 'shell_logger.out'), os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    pid, master_fd = pty.fork()

    if pid == pty.CHILD:
        os.execlp('echo', 'echo', '1')

# Generated at 2022-06-12 10:32:30.359613
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:32:34.094635
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/shell-logger-test'
    if os.path.exists(output):
        os.remove(output)

    assert not os.path.exists(output)
    shell_logger(output)
    assert os.path.exists(output)
    os.remove(output)

# Generated at 2022-06-12 10:32:35.880147
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/test_shell_logger') in [0, 1]

# Generated at 2022-06-12 10:32:38.901535
# Unit test for function shell_logger
def test_shell_logger():
    output = "./test_shell_logger.txt"
    # Create for test environment
    open(output, 'w').close()
    # Test
    shell_logger(output)
    # Remove for test environment
    os.remove(output)

# Generated at 2022-06-12 10:32:40.657160
# Unit test for function shell_logger
def test_shell_logger():
    result = shell_logger("/tmp/shell_logger_test.log")
    print("Shell exited with code: %d" % result)

# Generated at 2022-06-12 10:32:42.070649
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: add test when os.read will be replaced with stubs
    pass

# Generated at 2022-06-12 10:32:42.632141
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:32:59.349839
# Unit test for function shell_logger
def test_shell_logger():
    import ctypes
    ctypes.CDLL('librt.so.1', use_errno=True).shm_open(b'/', os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
    ctypes.CDLL('librt.so.1', use_errno=True).shm_unlink(b'/')
    fd = ctypes.CDLL('librt.so.1', use_errno=True).shm_open(b'/', os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
    ctypes.cdll.LoadLibrary('libc.so.6').ftruncate(fd, const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-12 10:33:00.407782
# Unit test for function shell_logger
def test_shell_logger():
    # TODO
    pass

# Generated at 2022-06-12 10:33:08.019167
# Unit test for function shell_logger
def test_shell_logger():
    class Logger:
        def __init__(self):
            self.output = b''

        def warn(self, message):
            self.output += message.encode() + b'\n'

    old = logs.warn
    logs.warn = Logger().warn

    if os.environ.get('SHELL'):
        shell_logger('/tmp/shell_logger_test')
    else:
        shell_logger(None)

    logs.warn = old

    assert logs.warn.output == b"Shell logger doesn't support your platform.\n"

test_shell_logger()

# Generated at 2022-06-12 10:33:12.374434
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test: shell_logger"""
    shell_logger('test.log')
    assert os.path.exists('test.log')
    assert os.path.getsize('test.log') == const.LOG_SIZE_IN_BYTES
    os.remove('test.log')

# Generated at 2022-06-12 10:33:12.988578
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:33:16.031972
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test.txt'
    shell_logger(output)
    assert os.path.exists(output)
    assert os.stat(output).st_size > 0
    os.remove(output)

# Generated at 2022-06-12 10:33:20.931037
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        try:
            shell_logger(f.name)
        except SystemExit:
            pass
        finally:
            os.unlink(f.name)

# Generated at 2022-06-12 10:33:28.296366
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import socket

    # Test /tmp/shell.log is created and not empty
    # Also it contains exactly the same output we have sent to the pty
    output = '/tmp/shell.log'
    if os.path.exists(output):
        os.remove(output)
    p = subprocess.Popen("echo -e 'echo test\necho test\nexit' | ./shell_logger %s" % output, shell=True)
    time.sleep(2)
    logs.info("Shell logger logs to %s" % output)
    assert os.path.exists(output)
    with open(output) as f:
        logs = f.read()
        assert "test\n" in logs
        assert "test\n" in logs



# Generated at 2022-06-12 10:33:38.544274
# Unit test for function shell_logger
def test_shell_logger():
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)
    output = 'test-shell-logger'
    fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn('python', partial(_read, buffer))

    f = open(output, 'r')
    a = f.read(const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-12 10:33:42.669313
# Unit test for function shell_logger
def test_shell_logger():
    from ..util import tempdir

    with tempdir() as directory:
        output = os.path.join(directory, 'output')
        return_code = shell_logger(output)
        assert return_code == 0



# Generated at 2022-06-12 10:33:56.477597
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger."""
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test.log')
    with open(test_file, 'ab') as f:
        return _spawn(os.environ['SHELL'], partial(_read, f))

    shutil.rmtree(test_dir)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:57.339754
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: write unit test
    pass



# Generated at 2022-06-12 10:34:03.200088
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for shell_logger"""
    import __main__ as main
    # Expected output
    expected_output = "Shell logger doesn't support your platform."
    # Redirect
    # sys.stdout = io.StringIO()
    # Call function
    shell_logger("Test_file")
    # Obtain output
    actual_output = main.__dict__['_'].pop()
    # Compare
    assert actual_output == expected_output


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:34:05.817459
# Unit test for function shell_logger
def test_shell_logger():
    # simple test
    shell_logger("test.txt")

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:34:07.690512
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/test.log') == None


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:34:12.379245
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    subprocess.check_call(['touch', 'shell_logger_test.log'])
    subprocess.check_call(['rm', 'shell_logger_test.log'])
    shell_logger('shell_logger_test.log')

# vim: foldlevel=0

# Generated at 2022-06-12 10:34:13.678880
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('shell_logger.test') == 0

# Generated at 2022-06-12 10:34:15.038429
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('./test_shell_logger') == None

# Generated at 2022-06-12 10:34:21.241469
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    import os
    import shutil
    pwd = os.path.dirname(os.path.abspath(__file__))
    outdir = os.path.join(pwd, "shell-logger-test")
    if os.path.exists(outdir):
        shutil.rmtree(outdir)
    os.mkdir(outdir)
    output = os.path.join(outdir, "out.log")
    shell_logger(output)
    try:
        import pty
    except ImportError:
        print("Please install pty for test_shell_logger")
        return

# Generated at 2022-06-12 10:34:32.326944
# Unit test for function shell_logger
def test_shell_logger():
    buffer = array.array('b', b'\x00' * 40)
    f = buffer.buffer
    f.read = lambda: f.read1(1)

    _read(f, 0)
    assert buffer == array.array('b', b'\x00' * 40)
    _read(f, 0)
    assert buffer == array.array('b', b'\x00' * 38 + b'\x00\x00')
    _read(f, 0)
    assert buffer == array.array('b', b'\x00' * 36 + b'\x00\x00\x00\x00')
    _read(f, 0)

# Generated at 2022-06-12 10:34:52.477215
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    output = tempfile.mktemp()

    def _test_shell_logger():
        shell_logger(output)

    with logs.log_to_stream('CRITICAL'):
        import threading
        t = threading.Thread(target=_test_shell_logger)
        t.start()
        t.join(timeout=10)

        with open(output, 'rb') as f:
            assert f.read()

    os.unlink(output)

# Generated at 2022-06-12 10:34:55.350007
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test.txt')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:34:58.284501
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger("/tmp/test_shell_logger.log")
    except Exception as e:
        assert e, e


# Generated at 2022-06-12 10:35:08.795959
# Unit test for function shell_logger
def test_shell_logger():
    import threading, time
    from shlex import split
    from subprocess import Popen
    import tempfile

    expectation = "TEST"
    fd, filename = tempfile.mkstemp()
    t = threading.Thread(target=shell_logger, kwargs=dict(output=filename))
    t.daemon = True
    t.start()
    time.sleep(0.5)
    shell_logger.shell_fd = t.fd
    p = Popen(split(expectation))
    p.wait()
    time.sleep(0.5)
    with os.fdopen(fd) as f:
        assert f.read().find(expectation)


if __name__ == '__main__':
    # Unit testing for the module
    test_shell_logger()

# Generated at 2022-06-12 10:35:13.410743
# Unit test for function shell_logger
def test_shell_logger():
    from . import test
    from . import utils

    # Create temp file and shell logger
    f = utils.create_temp_file()
    shell_logger(f.name)

    # Check if the shell logger has stored the output
    lines = f.read().splitlines()
    assert 'exit' in lines[-1].decode('utf-8')

# Generated at 2022-06-12 10:35:18.964147
# Unit test for function shell_logger
def test_shell_logger():
    import doctest
    import sys
    import os
    import cProfile as profile
    import pstats

    sys.argv = sys.argv[:1]
    sys.argv.append('-sx')
    stats = profile.Profile()
    stats.runctx('doctest.testmod()', globals(), locals())
    stats.dump_stats('shell_logger.profile')

    stats = pstats.Stats('shell_logger.profile')
    stats.sort_stats('time')
    stats.print_stats(20)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:35:21.362512
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test case for testing shell_logger() function."""
    shell_logger(output='/tmp/test_output.log')

# Generated at 2022-06-12 10:35:27.495695
# Unit test for function shell_logger
def test_shell_logger():
    from . import testlog

    output = testlog.get_file_name()
    shell_logger(output)

    test_value = b'\x00' * const.LOG_SIZE_IN_BYTES

    assert os.path.isfile(output)
    assert open(output, 'rb').read() == test_value
    os.remove(output)


if __name__ == '__main__':
    import sys
    shell_logger(sys.argv[1])

# Generated at 2022-06-12 10:35:29.292316
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('test_file.log') == 0

test_shell_logger()

# Generated at 2022-06-12 10:35:31.021325
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('./test_shell_logger_output.txt.') == 0

# Generated at 2022-06-12 10:35:46.960023
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/dev/null')


# Generated at 2022-06-12 10:35:51.905224
# Unit test for function shell_logger
def test_shell_logger():
    from ..testing import simulate
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile() as log_file, simulate.input('pwd'):
        shell_logger(log_file.name)
        log_file.flush()
        with open(log_file.name) as f:
            lines = f.read().split('\n')
            assert lines[-1].endswith(os.getcwd())

# Generated at 2022-06-12 10:35:56.813716
# Unit test for function shell_logger
def test_shell_logger():
    def check(log_file_path):
        return os.path.isfile(log_file_path)

    LOG_FILE_PATH = 'log.txt'
    shell_logger(LOG_FILE_PATH)
    assert check(LOG_FILE_PATH)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:35:57.409357
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:36:06.233657
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger
    """
    import subprocess
    import tempfile
    import time

    def _run_cmd(cmd):
        """
        Run command
        """
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        return process.communicate()

    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    _run_cmd([
        'python3',
        '%s/../../scripts/uart_logger.py' % os.path.dirname(os.path.realpath(__file__)),
        '--output',
        tmp_file.name
    ])

    time.sleep(1)
    _run

# Generated at 2022-06-12 10:36:11.890898
# Unit test for function shell_logger
def test_shell_logger():
    return_code = 0

    try:
        shell_logger('.test_shell_logger')
    except SystemExit as exc:
        return_code = exc.code

    with open('.test_shell_logger', 'r') as f:
        result = f.read()

    os.remove('.test_shell_logger')

    assert return_code == 0, 'Command exit with non-zero code'
    assert result, 'No output to the file after command was executed'

# Generated at 2022-06-12 10:36:17.240551
# Unit test for function shell_logger
def test_shell_logger():
    """Test for logger."""
    def test_logger():
        """Function for test."""
        shell_logger('test_file_for_logger.txt')
    try:
        test_logger()
    except SystemExit:
        pass
    file_ = open('test_file_for_logger.txt')
    data = file_.read()
    assert '\x00' not in data
    assert 'exit' in data

# Generated at 2022-06-12 10:36:27.363879
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import random
    import string

    filename = tempfile.mktemp()

    # Spawn our logger in subprocess
    child = subprocess.Popen(['python', '-c', 'import logs; logs.shell_logger("' + filename + '")'])

    # Write some dummy data to STDIN
    for _ in range(random.randint(10, 25)):
        print(''.join(random.choice(string.printable) for _ in range(random.randint(10, 30))))

    child.wait()

    # Read our log
    with open(filename, 'r') as f:
        log = f.read()

    # Check it is not empty
    assert log != ""

    # Check that each line contains \n
    assert "\n" in log

    os.remove

# Generated at 2022-06-12 10:36:35.574020
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function.

    If a shell logger gets spawned, it won't return before the
    shell exits. The unit test only runs the shell, prints something
    and exits. The shell logger, initiated by a call of
    `shell_logger` is supposed to capture the output, write it to
    a log file and return.

    The testing is done by comparing the content of the log file
    with the expected output.

    """

    from . import logs
    import io
    import os
    import tempfile
    import unittest
    import sys

    class TestShellLogger(unittest.TestCase):

        def setUp(self):
            self.fd, self.filename = tempfile.mkstemp()
            os.close(self.fd)
            self.orig_stdout = sys.stdout

# Generated at 2022-06-12 10:36:42.611748
# Unit test for function shell_logger
def test_shell_logger():
    fd, path = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-12 10:36:59.525930
# Unit test for function shell_logger
def test_shell_logger():
    pass


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:37:01.015151
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell_logger.txt')

# Generated at 2022-06-12 10:37:10.203104
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    from tempfile import mkstemp
    from fcntl import fcntl, F_GETFL, F_SETFL
    from os import read, write, O_NONBLOCK, fdopen

    path = mkstemp()[1]
    shell_logger(path)

    def read_nonblock(fd):
        flags = fcntl(fd, F_GETFL)
        fcntl(fd, F_SETFL, flags | O_NONBLOCK)
        return read(fd, 1024)


# Generated at 2022-06-12 10:37:12.402746
# Unit test for function shell_logger
def test_shell_logger():
    """Ensure shell_logger works"""
    shell_logger('test_shell_logger.txt')
    
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:37:13.032207
# Unit test for function shell_logger
def test_shell_logger():
    pass



# Generated at 2022-06-12 10:37:23.388523
# Unit test for function shell_logger
def test_shell_logger():
    import os, sys

    if sys.platform.startswith('win32') or not os.environ.get('SHELL'):
        return

    import atexit
    import time
    import tempfile
    import os.path as p

    PID = 1234
    LOG_ACTION = "log-action"
    LOG_DIRECTORY = tempfile.mkdtemp()
    LOG_FILE = p.join(LOG_DIRECTORY, "{}.log".format(LOG_ACTION))
    LOG_SIZE_IN_BYTES = 5000

    shell = os.environ['SHELL']

    @atexit.register
    def clean_up():
        import shutil

        shutil.rmtree(LOG_DIRECTORY)


# Generated at 2022-06-12 10:37:33.226829
# Unit test for function shell_logger
def test_shell_logger():
    import re
    import os.path
    import errno
    import shutil
    import tempfile
    from subprocess import Popen
    import time
    import unittest.mock

    test_file_name = 'test_shell_logger.log'

    def test_file_exists(file_name):
        return os.path.exists(file_name)

    def test_file_is_empty(file_name):
        return os.path.getsize(file_name) == 0

    def test_file_is_not_empty(file_name):
        return not os.path.getsize(file_name) == 0

    def test_file_contains_text(file_name):
        return os.stat(file_name).st_size > 0


# Generated at 2022-06-12 10:37:41.513398
# Unit test for function shell_logger
def test_shell_logger():
    """The unit test for function.

    If the function shell_logger() is called and the LOG_SIZE_IN_BYTES environmental
    variable is defined, and the file 'shell.log' is not empty, then the function
    should exit with return code 0.

    """
    os.environ['LOG_SIZE_IN_BYTES'] = '1024'
    shell_logger("shell.log")
    f = open("shell.log", "r")
    assert f.read() != ''
    f.close()
    os.unlink("shell.log")
    assert os.path.exists("shell.log") == False

# Generated at 2022-06-12 10:37:47.847691
# Unit test for function shell_logger
def test_shell_logger():
    with open('test_shell_logger.txt', 'wb') as f:
        return_code = _spawn(
            os.environ['SHELL'],
            partial(_read, f)
        )
    with open('test_shell_logger.txt') as f:
        assert return_code == 0
        assert f.read().strip() == b'\x00\x00\x00\x00'
    os.remove('test_shell_logger.txt')

# Generated at 2022-06-12 10:37:51.487106
# Unit test for function shell_logger
def test_shell_logger():
    # test passes if shell logger works correctly
    filename = "/Users/pratik/proj/python/Kush/logger_output"
    shell_logger(filename)


if __name__ == '__main__':
    # execute only if run as a script
    test_shell_logger()

# Generated at 2022-06-12 10:38:27.819598
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger.

    Create a temporary directory and call shell_logger on it.
    To pass the test the function shell_logger must not crash.

    """
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    out_file = os.path.join(temp_dir, 'log.out')
    shell_logger(out_file)
    shutil.rmtree(temp_dir)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:38:33.350228
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'

    output = 'output_shell_logger.txt'

    # Unit test 1: Test that output file is created.
    shell_logger(output)
    assert os.path.exists(output) == True

    # Unit test 2: Test that output file is not empty.
    assert os.stat(output).st_size != 0

# Generated at 2022-06-12 10:38:40.322050
# Unit test for function shell_logger
def test_shell_logger():
    from unittest import TestCase, main

    from . import logs


# Generated at 2022-06-12 10:38:50.174693
# Unit test for function shell_logger
def test_shell_logger():
    assert call('echo -n ""', shell=True) == 0
    assert call('echo -n "Hello World"', shell=True) == 0
    assert call('echo -n "\x00"', shell=True) == 0



# Generated at 2022-06-12 10:38:57.908783
# Unit test for function shell_logger
def test_shell_logger():
    num_of_bytes = 10
    out_file = "test_shell_logger"
    flag = True

    shell_logger(out_file)

    try:
        file = open(out_file, 'rb')
    except IOError:
        flag = False

    if flag:
        data = file.read(num_of_bytes)
        file.close()

    try:
        os.remove(out_file)
    except:
        pass

    assert flag
    assert data.isalnum()

# Generated at 2022-06-12 10:39:01.836349
# Unit test for function shell_logger
def test_shell_logger():
    """
    Unit test for function shell_logger
    """
    
    # create an output file
    shell_logger('test_shell_logger.txt')
    
    
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:39:07.983200
# Unit test for function shell_logger
def test_shell_logger():
    logs.debug('Unit-test: `shell_logger` function.')

    test_log = '/tmp/pyi-debug-shell-logger-test.log'

    # Remove test log in advance
    try:
        os.remove(test_log)
    except OSError:
        pass

    # Test function
    shell_logger(test_log)

    assert os.path.exists(test_log), "Log file is not created"
    assert os.stat(test_log).st_size > 0, "Log file is empty"

    # Cleanup
    os.remove(test_log)
    logs.debug('Unit-test `shell_logger`: OK')

# Generated at 2022-06-12 10:39:11.696733
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger.
    """
    import tempfile

    temp_file = tempfile.NamedTemporaryFile()
    shell_logger(temp_file.name)
    assert True
    temp_file.close()

# Generated at 2022-06-12 10:39:19.177776
# Unit test for function shell_logger
def test_shell_logger():
    from .. import shell
    from . import utils
    import re

    output = utils.create_file('out.txt')
    shell_logger(output)

    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    assert re.match(r'\x00+', open(output, 'rb').read(const.LOG_SIZE_IN_BYTES))

    output = utils.create_file('out.txt')
    shell.main(['--shell-log', output])

    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-12 10:39:27.897363
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('/tmp/test_shell_logger')
    except:
        pass
    n = 10
    with open('/tmp/test_shell_logger', 'r+b') as f:
        f.seek(f.size() - const.LOG_SIZE_IN_BYTES)
        f.write(b'hello, world. ' * n)
        f.seek(f.size() - const.LOG_SIZE_IN_BYTES)
        assert f.read().decode('utf-8') == ('hello, world. ' * n)
    os.remove('/tmp/test_shell_logger')

# Generated at 2022-06-12 10:40:03.710217
# Unit test for function shell_logger
def test_shell_logger():
    # Preparing test environment
    from . import tmpenv
    import shutil
    import time
    import subprocess

    class TestShell(object):
        def __enter__(self):
            self.test_dir = tmpenv.create_dir()
            os.chdir(self.test_dir)

        def __exit__(self, type, value, traceback):
            shutil.rmtree(self.test_dir)

    def write(data):
        process = subprocess.Popen(['script.py', 'shell', '-o', 'output'], stdin=subprocess.PIPE)
        process.communicate(input=bytes(data, 'UTF-8'))
        process.wait()


# Generated at 2022-06-12 10:40:05.541717
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('shell_logger_test.log')

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:40:14.582162
# Unit test for function shell_logger
def test_shell_logger():
    # pylint: disable=E1101
    """Run shell_logger and check that it generates a log file of correct length."""

    shell_logger(os.path.join(const.ROOT, const.LOG_FILE))
    fd = os.open(os.path.join(const.ROOT, const.LOG_FILE), os.O_RDONLY)
    buf1 = array.array('B', os.read(fd, const.LOG_SIZE_IN_BYTES))
    os.close(fd)
    os.remove(os.path.join(const.ROOT, const.LOG_FILE))
    assert len(buf1) == const.LOG_SIZE_IN_BYTES


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:40:24.316573
# Unit test for function shell_logger
def test_shell_logger():
    import os, shutil
    from . import logs

    test_dir = '/tmp/intrigue-test-dir/'
    try:
        os.mkdir(test_dir)
    except OSError:
        assert(0), "Failed to create test dir."

    test_file = os.path.join(test_dir, 'logfile')
    log = shell_logger(test_file)

    assert(os.path.isfile(test_file))
    assert(os.path.getsize(test_file) >= const.LOG_SIZE_IN_BYTES)
    try:
        shutil.rmtree(test_dir)
    except OSError:
        assert(0), "Failed to cleanup test dir."

# Generated at 2022-06-12 10:40:32.539511
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test.log'
    tty.setraw(sys.stdin.fileno())
    with open(os.path.abspath('test_shell_logger_input.txt'), 'rb') as f:
        try:
            tty.setcbreak(sys.stdin.fileno())
            shell_logger(output)
            while True:
                symbol = f.read(1)
                if symbol:
                    sys.stdin.buffer.write(symbol)
                else:
                    break
        finally:
            shell_logger(output)
    with open(output, 'rb') as file:
        buffer = mmap.mmap(file.fileno(), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)

# Generated at 2022-06-12 10:40:33.079783
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:40:42.462137
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import io
    import os
    import sqlite3
    import tempfile

    temp = tempfile.mkdtemp()
    output = os.path.join(temp, 'output')

    with open(output, 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    with open(output, 'r+b') as f:
        buffer = mmap.mmap(f.fileno(), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

        # Transform 'buffer' back to a file stream
        file_ = io.FileIO(buffer.fileno())
        file_.seek(0)

        assert file_.read() == b'\x00' * const.LOG

# Generated at 2022-06-12 10:40:51.463672
# Unit test for function shell_logger
def test_shell_logger():
    import mock
    import random
    import string
    import tempfile
    from os import read, write, close

    for _ in xrange(100):
        fd, output = tempfile.mkstemp()
        close(fd)

        with mock.patch.object(sys, 'exit') as mocked_exit:
            with open(output, 'w') as w:
                w.write(random.choice(string.printable) * 5)

            with mock.patch.object(os, 'environ', {'SHELL': '/bin/bash'}):
                shell_logger(output)

            result = len(read(fd, 1024))
            write(fd, b'\x00' * result)

            assert mocked_exit.call_args[0][0] == 0
            assert result == const.LOG_SIZE_IN_

# Generated at 2022-06-12 10:41:02.501668
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def test(self):
            file = io.StringIO()

            with open(os.devnull, 'w') as devnull:
                with tempfile.TemporaryFile(mode='w+') as temp:
                    temp_fd = temp.fileno()
                    os.write(temp_fd, 'echo "Hello, World!"')
                    temp.flush()
                    temp.seek(0)

                    code = shell_logger(temp_fd)

                    temp.flush()
                    temp.seek(0)

                    fd = temp.fileno()
                    os.write(fd, 'exit\n')
                    temp.flush()
                    temp.seek(0)


# Generated at 2022-06-12 10:41:10.697651
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import os
    import subprocess
    import shutil

    dummy_log_file = os.path.join(const.TMP_LOGS_DIR, 'dummy-log')
    if os.path.exists(dummy_log_file):
        os.remove(dummy_log_file)

    subprocess.call(['python3', '-m', 'tools.logs.shell_logger', dummy_log_file])
    time.sleep(1)

    with open(dummy_log_file) as f:
        logs = f.read()

    # pty truncate logs when logs overflow
    assert logs.count('\0') == 0

    # clean test files
    shutil.rmtree(const.TMP_LOGS_DIR, ignore_errors=True)



# Generated at 2022-06-12 10:41:40.826932
# Unit test for function shell_logger
def test_shell_logger():
    # TODO
    shell_logger("")

# Generated at 2022-06-12 10:41:44.340514
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import sys
    import termios
    import tty
    import time
    shell_logger('tmp')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:41:51.449758
# Unit test for function shell_logger
def test_shell_logger():
    output = 'output.log'
    try:
        shell_logger(output)
    except SystemExit:
        pass
    output_fd = os.open(output, os.O_RDWR)
    output_buffer = mmap.mmap(output_fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)
    assert output_buffer[-1] == '\x07'
    assert output_buffer.count('\x00\x0a') == 1
    logs.info("Unit test for function shell_logger() is completed.")

# Generated at 2022-06-12 10:41:52.339458
# Unit test for function shell_logger
def test_shell_logger():
    pass


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:41:52.777681
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:41:55.102820
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./output')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:42:01.380424
# Unit test for function shell_logger
def test_shell_logger():
    def fake_spawn(shell, master_read):
        return 42

    def fake_read(f, fd):
        return b'Lorem ipsum'

    pty_copy = pty._copy
    write = os.write
    os.write = lambda fd, buf: fd
    pty._copy = lambda *_: None

    with open('output.txt', 'wb') as f:
        os.environ['SHELL'] = '/bin/sh'
        output = 'output.txt'
        shell_logger(output)
        os.environ.pop('SHELL')
        assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES, "File size should be equal 0"

# Generated at 2022-06-12 10:42:10.769801
# Unit test for function shell_logger
def test_shell_logger():
    # Configure testing environment
    import fake_filesystem
    from common.fake_subprocess import FakePopen

    fs = fake_filesystem.FakeFilesystem()
    fake_open = fake_filesystem.FakeFileOpen(fs)
    fake_subprocess = FakePopen(fs)

    sys.modules['os'] = fake_filesystem.FakeOsModule(fs)
    sys.modules['os.path'] = fake_filesystem.FakePathModule(fs)
    sys.modules['subprocess'] = fake_subprocess
    sys.modules['__builtin__'].open = fake_open

    # Test
    shell_logger("/output")