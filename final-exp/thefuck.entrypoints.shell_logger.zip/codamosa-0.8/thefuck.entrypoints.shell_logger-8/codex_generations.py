

# Generated at 2022-06-12 10:32:14.454903
# Unit test for function shell_logger
def test_shell_logger():
    assert len(shell_logger(sys.argv[0])) == len(sys.argv[0])

# Generated at 2022-06-12 10:32:24.223017
# Unit test for function shell_logger
def test_shell_logger():
    def read(path):
        with open(path, 'r') as f:
            return f.read()

    def write(fd):
        os.write(fd, b'123')

    shell_logger('/tmp/output')
    assert read('/tmp/output') == '\x00' * const.LOG_SIZE_IN_BYTES

    shell_logger('/tmp/output')
    assert read('/tmp/output') == '\x00' * const.LOG_SIZE_IN_BYTES

    shell_logger('/tmp/output')
    os.close(os.open('/tmp/output2', os.O_CREAT, 0o644))
    assert read('/tmp/output') == '\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-12 10:32:27.892933
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os

    path = os.path.join(tempfile.gettempdir(), "shell_logger.txt")
    shell_logger(path)
    with open(path, 'r') as f:
        print(f.read())

# Generated at 2022-06-12 10:32:28.692090
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test.log')

# Generated at 2022-06-12 10:32:34.387034
# Unit test for function shell_logger
def test_shell_logger():
    import sys
    import pytest
    if sys.version_info[:2] < (3, 4):
        pytest.importorskip('mmap')

    def test():
        import os
        import shutil

        output = 'test_shell_logger.txt'
        shell_logger(output)
        assert os.stat(output).st_size == const.LOG_SIZE_IN_BYTES
        shutil.rmtree(output)

    test()

# Generated at 2022-06-12 10:32:42.620823
# Unit test for function shell_logger

# Generated at 2022-06-12 10:32:48.502971
# Unit test for function shell_logger
def test_shell_logger():
    """A unit test for shell_logger.
    
    It checks for correct recording of shell output
    to the file `shell_out`.
    """
    os.system('echo "Hello!" > shell_out')
    import shell_logger
    shell_logger.shell_logger('shell_out')
    assert os.system('echo "Hello!" > shell_out') == os.system('echo "Hello!" > shell_out')

# Generated at 2022-06-12 10:32:58.581097
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import os
    import unittest
    import tempfile

    class ShellLoggerTest(unittest.TestCase):
        """Logs shell output to the `output`."""

        def test_shell_logger(self):
            """Test method shell_logger."""
            tmp_dir = tempfile.mkdtemp()
            os.chdir(tmp_dir)
            output = "output.log"
            shell_logger(output)
            directory = os.listdir(tmp_dir)
            self.assertTrue(output in directory)
            with io.open(output, 'r') as output:
                output = output.read()
                self.assertTrue('test' in output)
            os.remove(os.path.join(tmp_dir, output))
            os.chdir('..')



# Generated at 2022-06-12 10:33:08.392983
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil

    def get_temp_dir():
        return os.path.join(os.getcwd(), 'temp')

    def get_temp_file(dir):
        return os.path.join(dir, 'shell_logger.log')

    def create_temp_dir():
        temp_dir = get_temp_dir()
        os.mkdir(temp_dir, 0o755)
        return temp_dir

    def create_temp_file(dir):
        temp_file = get_temp_file(dir)
        open(temp_file, 'w').close()
        return temp_file

    def remove_temp_dir(temp_dir):
        shutil.rmtree(temp_dir)


# Generated at 2022-06-12 10:33:11.591456
# Unit test for function shell_logger
def test_shell_logger():
    """test the shell_logger function in the logger.py file"""
    assert shell_logger("test_env_shell") == 1

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:17.240744
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: implement unit test for shell_logger
    pass

# Generated at 2022-06-12 10:33:18.608554
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger.__name__ == "shell_logger"

# Generated at 2022-06-12 10:33:22.024817
# Unit test for function shell_logger
def test_shell_logger():
    process = subprocess.Popen(['sh', '-i'])

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:24.532819
# Unit test for function shell_logger
def test_shell_logger():
    import tests
    import tempfile
    import contextlib
    import os
    output = tempfile.NamedTemporaryFile().name
    with contextlib.suppress(SystemExit):
        shell_logger(output)

    os.unlink(output)
    assert os.path.exists(output)

# Generated at 2022-06-12 10:33:32.618623
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os
    # for some reason this test can't run in another directory, so we use tempfile.mkdtemp()
    temp_path = tempfile.mkdtemp()
    shell_logger(os.path.join(temp_path, 'output'))
    # delete files
    os.remove(os.path.join(temp_path, 'output'))
    # delete file directory
    os.remove(temp_path)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:33.961673
# Unit test for function shell_logger
def test_shell_logger():
    assert os.path.isfile('test.log')
    assert os.path.getsize('test.log') > 0
    os.remove('test.log')

# Generated at 2022-06-12 10:33:34.829585
# Unit test for function shell_logger
def test_shell_logger():
    pass

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:45.539114
# Unit test for function shell_logger
def test_shell_logger():
    import os
    from ..logs import logger
    from .common import create_dirs, cleanup
    from ..const import LOG_SIZE_TO_CLEAN, LOG_SIZE_IN_BYTES


# Generated at 2022-06-12 10:33:47.492312
# Unit test for function shell_logger
def test_shell_logger():
    assert 0 == shell_logger(os.path.join(const.TEST_DIR, 'test.log'))

# Generated at 2022-06-12 10:33:48.300396
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:33:58.309358
# Unit test for function shell_logger
def test_shell_logger():
    f = open(const.TEST_LOG_PATH, 'w+')
    buffer = mmap.mmap(f.fileno(), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    _set_pty_size(f.fileno())
    _read(buffer, f.fileno())

# Generated at 2022-06-12 10:34:05.365924
# Unit test for function shell_logger
def test_shell_logger():
    import io

    return_code = 0

    def fake_spawn(*args, **kwargs):
        return return_code

    builtins_module = __import__('builtins')
    old_open = getattr(builtins_module, 'open')
    old_spawn = pty.spawn
    pty.spawn = fake_spawn

    def cleanup():
        setattr(builtins_module, 'open', old_open)
        pty.spawn = old_spawn

    for i in range(1, 7):
        return_code = i
        logs.io = io.StringIO()
        try:
            shell_logger(i)
        except SystemExit as e:
            assert e.code == i
        assert logs.io.getvalue() == ''


# Generated at 2022-06-12 10:34:15.546892
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/test_shell_logger'
    try:
        os.unlink(output)
    except IOError:
        pass

    import multiprocessing
    p = multiprocessing.Process(target=shell_logger, args=(output,))
    p.start()
    p.join(3)

    assert os.path.isfile(output), 'Output file was not created'
    assert os.path.getsize(output) > 0, 'Output file has zero size'

    with open(output) as f:
        assert b'\x00' not in f.read(const.LOG_SIZE_TO_CLEAN), 'Output file was not cleaned'
        assert f.read(const.LOG_SIZE_TO_CLEAN) == b'\x00' * const.LOG_SIZE_TO_CLEAN

# Generated at 2022-06-12 10:34:18.109089
# Unit test for function shell_logger
def test_shell_logger():
    """Tests that the function shell_logger() works as expected."""
    output = 'tests/output'
    shell_logger(output)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:34:19.212650
# Unit test for function shell_logger
def test_shell_logger():
    """
    >>> shell_logger('shell.log')
    """

# Generated at 2022-06-12 10:34:29.619944
# Unit test for function shell_logger
def test_shell_logger():
    cmd = "python3 -c 'from sys import exit; from time import sleep; print(\"hello\\n\"); sleep(3); print(\"world\\n\"); exit(1)'"
    path = "./test_shell_logger.txt"
    pid = os.fork()
    if pid == 0:
        shell_logger(path)
    else:
        os.system(cmd)
        os.waitpid(pid, 0)
        with open(path, "r") as f:
            data = f.read()
        os.remove(path)
        # The first two lines of output should be /dev/null
        assert data[0:70] == "\x00" * 70
        assert data[70:].replace("\x00", "") == "helloworld"
    return

# Generated at 2022-06-12 10:34:31.900808
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./log1.txt')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:34:34.409509
# Unit test for function shell_logger
def test_shell_logger():
    """test_shell_logger - test for shell_logger function"""
    try:
        import pty
        my_file_name = 'tests/output'
        f = open(my_file_name, 'w+')
        shell_logger(my_file_name)
        f.close()
        assert os.stat(my_file_name).st_size > 0
    except Exception:
        print("test_shell_logger - failed")


# Generated at 2022-06-12 10:34:37.082397
# Unit test for function shell_logger
def test_shell_logger():
    """Test function shell_logger.

    This function is not really unit testable. But it's very easy to test it manually.

    """
    pass


__all__ = ('shell_logger', )

# Generated at 2022-06-12 10:34:43.767766
# Unit test for function shell_logger
def test_shell_logger():
    tmp_path = os.path.join(const.TMP_DIR_PATH, "shell_logger.tmp")
    try:
        from . import test_logs
        with test_logs.capture() as logs:
            shell_logger(tmp_path)
        logs.flush(sys.stdout)
        logs.check("Shell logger doesn't support your platform.")
    finally:
        if os.path.isfile(tmp_path):
            os.remove(tmp_path)


# Generated at 2022-06-12 10:34:59.793829
# Unit test for function shell_logger
def test_shell_logger():
    from .. import mock
    from . import utils
    import filecmp

    filename = 'test.file'
    with mock.patch('os.open') as open_mock:
        open_mock.return_value = 1
        with mock.patch('os.write') as write_mock:
            write_mock.return_value = 1
            with mock.patch('mmap.mmap') as mmap_mock:
                mmap_mock.return_value = mock.MagicMock()
                with mock.patch('os.environ', {'SHELL': '/bin/bash'}):
                    with mock.patch('os.waitpid') as waitpid_mock:
                        waitpid_mock.return_value = [0, 0]

# Generated at 2022-06-12 10:35:08.762739
# Unit test for function shell_logger
def test_shell_logger():
    """
    Testing logger (just parsing and checking for exceptions)
    """
    import os
    import shutil
    # Create file and directory
    try:
        os.mkdir("test_logs")
        try:
            shutil.copy("/bin/sh", "test_sh")
            os.environ["SHELL"] = "./test_sh"
            shell_logger("test_logs/test.txt")
        finally:
            os.remove("test_sh")
    finally:
        shutil.rmtree("test_logs")
    assert True


if __name__ == '__main__':
    sys.exit(test_shell_logger())

# Generated at 2022-06-12 10:35:12.338938
# Unit test for function shell_logger
def test_shell_logger():
    logs.init()

    os.environ['SHELL'] = 'bash'
    output_file = 'test_output.txt'
    shell_logger(output_file)
    assert os.path.isfile(output_file)

    os.remove(output_file)

# Generated at 2022-06-12 10:35:14.955893
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)
        tty_log = f.read()

        assert(len(tty_log) > 0)


# Generated at 2022-06-12 10:35:17.352006
# Unit test for function shell_logger
def test_shell_logger():
    filename = '/tmp/output_log.txt'
    shell_logger(filename)
    with open(filename, 'r') as fd:
        assert fd.read()

# Generated at 2022-06-12 10:35:20.377040
# Unit test for function shell_logger
def test_shell_logger():
    from tempfile import mktemp
    filename = mktemp()
    shell_logger(filename)
    os.remove(filename)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:35:29.481582
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)
        logs.debug("File size:", os.fstat(f.fileno()).st_size)
        logs.debug("File content:", f.read().decode("utf-8"))

        logs.debug("\nFile size:", os.fstat(f.fileno()).st_size)
        logs.debug("File content:", f.read().decode("utf-8"))

        f.flush()
        os.fsync(f.fileno())
        os.lseek(f.fileno(), 0, os.SEEK_SET)
        logs.debug("\nFile size:", os.fstat(f.fileno()).st_size)
        logs.debug

# Generated at 2022-06-12 10:35:40.180901
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/test.log'
    return_code = shell_logger(output)
    assert return_code == 0
    # File should be exist and has right size
    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    # File should be clean if only log was started in new shell
    with open(output) as f:
        data = f.read()
        assert data == '\x00' * const.LOG_SIZE_IN_BYTES
    # File should be clean if only log was stopped in new shell
    return_code = shell_logger(output)
    with open(output) as f:
        data = f.read()
        assert data == '\x00' * const.LOG_SIZE_IN_BY

# Generated at 2022-06-12 10:35:41.134497
# Unit test for function shell_logger
def test_shell_logger():
    """ Function is working as expected. """
    pass

# Generated at 2022-06-12 10:35:43.575361
# Unit test for function shell_logger
def test_shell_logger():
    output = 'tests/files/output.log'
    shell_logger(output)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:35:59.152800
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('output.log')
test_shell_logger.fun = shell_logger



# Generated at 2022-06-12 10:36:07.055735
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger.
    """
    import shutil
    from .. import logs
    from pycloak.shell import shell_logger

    try:
        fd, output = logs.create_log_file(logs.LOGGING_PATH, logs.LOGGING_PREFIX)
        shell_logger(output)
    except (OSError, EnvironmentError) as err:
        logs.info("Unable to run unit test for shell_logger. {0}".format(err))
    finally:
        if os.path.exists(output):
            os.remove(output)
        if os.path.exists(logs.LOGGING_PATH):
            shutil.rmtree(logs.LOGGING_PATH)

# Generated at 2022-06-12 10:36:14.816732
# Unit test for function shell_logger
def test_shell_logger():
    from . import test_utils
    import tempfile

    logs.default_level = logs.DEBUG
    logs.default_out = sys.stderr

    with tempfile.NamedTemporaryFile() as f:
        mock_stdout = '俱乐部\n活动\n房间\n'
        mock_stdin = 'foo\nbar\n'
        mock_stdin += 'foobar' + 'z' * const.LOG_SIZE_TO_CLEAN + '\n'
        mock_stdin += 'done\n'
        with test_utils.patch_stdin(mock_stdin):
            with test_utils.patch_stdout(mock_stdout):
                shell_logger(f.name)

        f.seek(0)
        result = f

# Generated at 2022-06-12 10:36:24.953546
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.TemporaryDirectory() as dirname:
        filename = os.path.join(dirname, "test.log")
        assert os.path.isfile(filename) == False

        buffer = create_autospec(mmap.mmap)
        buffer.write.side_effect = lambda d: print(d)

        with patch('os.open') as os_open:
            os_open.return_value = 2
            with patch('os.write') as os_write:
                with patch('mmap.mmap') as mmap_mmap:
                    mmap_mmap.return_value = buffer

# Generated at 2022-06-12 10:36:33.874720
# Unit test for function shell_logger
def test_shell_logger():
    """
    $ python xshell/utils.py test_shell_logger
    shell_logger():
    <BLANKLINE>
    """
    print("shell_logger():")
    import pkgutil
    import xshell

    output = '/tmp/xshell.test.log'
    #output = '/tmp/xshell.log'
    if os.path.isfile(output):
        os.remove(output)
    #shell_logger(output)
    code = pkgutil.get_loader("xshell.utils").get_code("utils")
    exec(code, { 'shell_logger':shell_logger, 'output':output })
    print("\nFile %s exists: %s" % (output, os.path.isfile(output)))
    print("")


# Generated at 2022-06-12 10:36:42.673168
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile

    def setUp():
        global temporary_directory
        if os.path.exists(temporary_directory):
            shutil.rmtree(temporary_directory)
        os.mkdir(temporary_directory)

    def tearDown():
        if os.path.exists(temporary_directory):
            shutil.rmtree(temporary_directory)

    temporary_directory = tempfile.mkdtemp()
    temporary_file = os.path.join(temporary_directory, 'log')

    setUp()
    print(os.getcwd())
    shell_logger(temporary_file)
    tearDown()
    print(temporary_file)

#if __name__ == "__main__":
#    import unittest
#    un

# Generated at 2022-06-12 10:36:45.234645
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    shell_logger('test_shell_logger')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:36:45.777071
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-12 10:36:47.208097
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("output/shell_logger.test")
    assert(True)

test_shell_logger()

# Generated at 2022-06-12 10:36:56.290986
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import tests
    import os

    logs.config_logging(logs.DEBUG)

    cmd = tests.python_executable() + [
        '-m', 'pwnlib.shellcraft.i386.linux.sh',
        '--unbuffered',
        '--command=%s -m pwnlib.shellcraft.i386.linux.echo --args=HelloWorld' % tests.python_executable()
    ]
    filename = 'test_shell_logger'
    proc = subprocess.Popen(cmd, shell=False)
    subprocess.Popen([tests.python_executable(), '-m', 'pwnlib.log', filename], shell=False)
    time.sleep(1)

# Generated at 2022-06-12 10:37:18.199423
# Unit test for function shell_logger
def test_shell_logger():
    with open('shell_logger_test.out', 'w+') as f:
        f.write('\x00' * const.LOG_SIZE_IN_BYTES)
    sys.exit = sh_log_func = shell_logger
    sh_log_func('shell_logger_test.out')

test_shell_logger()

# Generated at 2022-06-12 10:37:27.580721
# Unit test for function shell_logger
def test_shell_logger():
    from io import BytesIO
    from prompter import ENVIRON, PROMPTER_LOGS
    
    main_stdout = sys.stdout
    out = BytesIO()
    sys.stdout = out
    environ_backup = ENVIRON.copy()
    if "SHELL" not in ENVIRON:
        ENVIRON["SHELL"] = 'bash'
    ENVIRON["PROMPTER_LOGS"] = PROMPTER_LOGS + '.tmp'
    shell_logger(PROMPTER_LOGS + '.tmp')
    ENVIRON = environ_backup
    sys.stdout = main_stdout

# Generated at 2022-06-12 10:37:28.189676
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:37:36.181953
# Unit test for function shell_logger
def test_shell_logger():
    """
    This test cannot be invoked directly.
    Please, use tox -e example
    """

    class FDStub:
        class Exception(Exception):
            pass

        def __init__(self, *args):
            pass

        def close(self):
            FDStub.close_count += 1

        def write(self, data):
            FDStub.write_count += 1
            if FDStub.write_count == 1:
                raise FDStub.Exception()

        def move(self, offset, length, dest):
            FDStub.move_count += 1

        def seek(self, offset):
            FDStub.seek_count += 1

    class OSStub:
        @staticmethod
        def open(*args):
            return 1

        @staticmethod
        def write(fd, data):
            OS

# Generated at 2022-06-12 10:37:46.195520
# Unit test for function shell_logger
def test_shell_logger():
    """Test function shell_logger.

    This function tests output of the shell_logger function for normal
    execution.

    """
    import time
    import tempfile
    import subprocess
    from . import helpers
    from .helpers import LOG_FILENAME

    logs.set_verbosity(logs.DEBUG)
    logs.log_to_stderr()

    assert not os.path.exists(LOG_FILENAME)
    assert not os.path.exists(helpers.LOG_FILENAME)

    os.environ['SHELL'] = '/bin/bash'

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, LOG_FILENAME)
        assert not os.path.exists(tmp_file)

        shell_log

# Generated at 2022-06-12 10:37:54.673226
# Unit test for function shell_logger
def test_shell_logger():
    import mock
    import subprocess
    import tempfile

    old_sys_exit = sys.exit
    old_open = os.open
    old_fork = pty.fork
    old_exec = os.execlp
    old_wait = os.waitpid
    old_copy = pty._copy


# Generated at 2022-06-12 10:38:04.547674
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger.

    Run test executable and exit, then check if it created expected log file.

    """
    import shutil
    import subprocess
    import time


# Generated at 2022-06-12 10:38:15.324381
# Unit test for function shell_logger
def test_shell_logger():
    default_shell = os.environ.get('SHELL')
    os.environ['SHELL'] = 'cat'
    output = 'test.txt'
    fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

    os.environ['SHELL'] = default_shell
    os.close(fd)
    assert return_code == 0


# Generated at 2022-06-12 10:38:21.480226
# Unit test for function shell_logger
def test_shell_logger():
    _shell_logger = shell_logger
    shell_logger = lambda : print('shell_logger')
    import nose.tools as nose
    import tempfile

    with tempfile.NamedTemporaryFile() as log:
        _shell_logger(log.name)
        nose.assert_equal(os.stat(log.name).st_size, const.LOG_SIZE_IN_BYTES)

    shell_logger = _shell_logger

# Generated at 2022-06-12 10:38:30.807269
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/usr/bin/env python'

    stream = io.StringIO()
    sys.stdout = stream
    shell_logger('test_output')
    sys.stdout = sys.__stdout__

    lines = stream.getvalue().splitlines()

    assert lines[-1] == 'SHELL LOGGER: Use ^D to stop logging...'
    assert lines[0].startswith('SHELL LOGGER: Logging to')

    # In fact, this is not unit test at all
    # but we need to test that the
    # logger can handle the whole bash output
    # and write it to the `test_output` file.
    #
    # The main issue is to test the
    # `script` like functionality of the logger.

# Generated at 2022-06-12 10:39:07.602674
# Unit test for function shell_logger
def test_shell_logger():
    logs.LOG_FILE = './logs/test_shell_logger.dat'
    shell_logger(logs.LOG_FILE)
    logs.LOG_FILE = './logs/default.dat'

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:39:13.022501
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    print(temp_file.name)
    temp_file.close()
    if os.environ.get('SHELL'):
        sys.path.append(os.path.join(__file__, '../'))
        shell_logger(temp_file.name)
    else:
        print("Shell logger doesn't support your platform.")

# Generated at 2022-06-12 10:39:14.618431
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger


# Generated at 2022-06-12 10:39:22.270546
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import sh

    assert 'SHELL' in os.environ

    temp = tempfile.mkdtemp()
    shell_logger(temp + '/output.txt')

    assert os.path.getsize(temp + '/output.txt') == const.LOG_SIZE_IN_BYTES
    assert b'\x00' not in sh.cat(temp + '/output.txt')
    assert sh.bash('--version') in sh.cat(temp + '/output.txt')

    shutil.rmtree(temp)

# Generated at 2022-06-12 10:39:30.552059
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import time
    import unittest

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile(
                prefix='shell_logger_test_',
                delete=False
            )
            self.addCleanup(self.temp_file.close)
            self.addCleanup(shutil.rmtree, tempfile.mkdtemp())
            self.log_file_name = self.temp_file.name

        def test_logger(self):
            with open(self.log_file_name, 'wb') as f:
                f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-12 10:39:40.709803
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import random
    import string
    import subprocess
    import time

    # Make random string
    # https://stackoverflow.com/a/2257449/145400
    def _id_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for _ in range(size))

    # Make random string and sleep to make sure that we don't miss anything
    rand_string = _id_generator()
    time.sleep(0.4)

    # Start external process
    logs.warn(rand_string)

    # Spawn shell logger
    out = 'test_debug_log.log'

# Generated at 2022-06-12 10:39:44.116094
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile

    with tempfile.NamedTemporaryFile(prefix='typeracer_') as tmp_file:
        try:
            shell_logger(tmp_file.name)
        except SystemExit:
            pass
        assert os.stat(tmp_file.name).st_size == const.LOG_SIZE_IN_BYTES


# Compatibility with Python 2
del partial

# Generated at 2022-06-12 10:39:44.659348
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:39:54.832302
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time

    fd, shell_log_file = tempfile.mkstemp()
    os.write(fd, 'M' * const.LOG_SIZE_IN_BYTES)
    os.close(fd)
    return_code = shell_logger(shell_log_file)

    fd = os.open(shell_log_file, os.O_RDONLY | os.O_CREAT)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)
    assert buffer[0] != b'M'
    buffer.close()
    os.close(fd)

    os.unlink(shell_log_file)
    assert return_code == 0



# Generated at 2022-06-12 10:40:02.013049
# Unit test for function shell_logger
def test_shell_logger():
    '''
    Test shell_logger function from shell.py
    '''
    import subprocess
    import shlex

    cmd = 'python -m vee.shell --output=output.txt'
    p = subprocess.Popen(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    assert p.returncode == 0
    # if termios.TIOCGWINSZ return bigger than 0, pass test
    assert bool(stderr) == False
    logs.info('Test shell_logger pass')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:40:35.698382
# Unit test for function shell_logger
def test_shell_logger():
    logs.init(None, const.TEST_LOG_LEVEL)
    shell_logger(const.TEST_LOG_PATH)

# Generated at 2022-06-12 10:40:37.121786
# Unit test for function shell_logger
def test_shell_logger():
    """Function for shell_logger was not tested."""
    pass

# Generated at 2022-06-12 10:40:40.389743
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import shutil
    import time
    import random
    import string

    logs_dir = 'logs/'

# Generated at 2022-06-12 10:40:44.000190
# Unit test for function shell_logger
def test_shell_logger():
    def print_hello():
        print('hello')

    with open('log.txt', 'w') as f:
        print_hello()
        shell_logger(f.name)
    with open('log.txt') as f:
        logs.debug(f.read())

# Generated at 2022-06-12 10:40:52.939978
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('.test.log', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * 1024)
    buffer = mmap.mmap(fd, 1024, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn('/bin/bash', partial(_read, buffer))

    with open('.test.log', 'r+') as f:
        f.seek(512)
        assert f.read(8) == '\x00' * 8
        f.seek(512)
        f.write('lolilol\n')

        f.seek(1024)

# Generated at 2022-06-12 10:41:04.016819
# Unit test for function shell_logger
def test_shell_logger():
    import random
    import string
    from subprocess import Popen, PIPE, STDOUT

    def test_log_size():
        if const.LOG_SIZE_IN_BYTES > 30:
            return const.LOG_SIZE_IN_BYTES - 30
        else:
            return 10

    def get_random_string(size=10):
        alphabet = string.ascii_letters + string.digits
        return ''.join(random.choice(alphabet) for _ in range(size))

    file_name = 'shell_logger_test_file__%s' % get_random_string()
    p = Popen(['python', '-m', 'pynguin.shell_logger', file_name], stdout=PIPE, stdin=PIPE, stderr=STDOUT)

    #

# Generated at 2022-06-12 10:41:11.722464
# Unit test for function shell_logger
def test_shell_logger():
    from .. import main
    import subprocess

    with logs.temp_file() as f:
        p = subprocess.Popen(['env', 'PYTHONPATH=%s' % os.environ['PYTHONPATH'], 
                              sys.executable, main.__file__, 'shell', '-o', f, 
                              '-s', '-c', 'echo 2 > /dev/null'], 
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, universal_newlines=True)
        (out, err) = p.communicate('2') # Send 2 characters to the predict
        p.wait()


# Generated at 2022-06-12 10:41:21.294326
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile

    return_code = 1

    with tempfile.NamedTemporaryFile() as f:
        def _fake_exit(status):
            nonlocal return_code
            return_code = status

        def _fake_spawn(shell, master_read):
            with open(f.name, 'wb') as w_file:
                w_file.write(b'hello world')
            master_read(w_file, 1)

        try:
            logs.warn = _fake_exit
            pty.fork = _fake_spawn
            shell_logger(f.name)
        except ValueError:
            assert False
        assert return_code == 0


# Generated at 2022-06-12 10:41:26.477553
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import os


    print(os.getcwd())
    shell_logger('output')

    from abot.misc import get_log_from_bytes
    time.sleep(0.2)
    f = open('output', 'r')
    log = get_log_from_bytes(f.read().encode())
    print(log)

# Generated at 2022-06-12 10:41:28.161980
# Unit test for function shell_logger
def test_shell_logger():
    file = os.path.join(const.OUTPUT_DIR, 'shell.log')
    shell_logger(file)

