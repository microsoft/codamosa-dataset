

# Generated at 2022-06-12 10:32:14.306530
# Unit test for function shell_logger
def test_shell_logger():
    output = 'logger.out'

    try:
        shell_logger(output)
    except Exception as e:
        logs.error(e, exc_info=True)
        assert False

    os.remove(output)

# vim: filetype=python

# Generated at 2022-06-12 10:32:19.093883
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    from . import test_logs
    from . import test_const

    logs.configure(logging_level=logging.CRITICAL)
    shell_logger('/tmp/script.log')

    test_logs.test_warning('Shell logger doesn\'t support your platform.')
    test_const.test_LOG_SIZE_IN_BYTES(1048576)
    test_const.test_LOG_SIZE_TO_CLEAN(8388608)

# Generated at 2022-06-12 10:32:20.497699
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test_shell_logger.log')

# Generated at 2022-06-12 10:32:29.402379
# Unit test for function shell_logger
def test_shell_logger():
    import logging
    import unittest
    import os

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.output = 'output.txt'
            logging.disable(logging.CRITICAL)

        def tearDown(self):
            try:
                os.remove(self.output)
            except OSError:
                pass

        def test_shell_logger(self):
            shell_logger(self.output)

        def test_shell_logger_fail(self):
            self.assertRaises(OSError, shell_logger, '/some/nonexistent/output.txt')

    unittest.main()

# Generated at 2022-06-12 10:32:30.773032
# Unit test for function shell_logger
def test_shell_logger():
    """
    >>> shell_logger('test.log')
    """

# Generated at 2022-06-12 10:32:39.913260
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import unittest
    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.output = io.BytesIO()
            self.fd = self.output.fileno()
        def test_log_without_log_size_clean(self):
            os.write(self.fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
            buffer = mmap.mmap(self.fd, const.LOG_SIZE_IN_BYTES,
                               mmap.MAP_SHARED, mmap.PROT_WRITE)
            return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
            self.assertEqual(return_code, 0)

    unittest.main()

# Unit

# Generated at 2022-06-12 10:32:43.934370
# Unit test for function shell_logger
def test_shell_logger():
    from .cmdline_args import parse_args
    from .. import main
    from ..logs import set_logger

    set_logger(logs.print_logger)
    main.main(parse_args(['shell_logger', '-f', 'out.log']))

# vim:set sw=4 ts=4 et:

# Generated at 2022-06-12 10:32:46.054461
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL']='/bin/sh'
    shell_logger('./test_logs_shell_logger.logs')

# Generated at 2022-06-12 10:32:50.307198
# Unit test for function shell_logger
def test_shell_logger():
    from os.path import exists, getsize
    from sys import executable as PY

    output = 'test_shell_logger.log'

    if exists(output):
        os.remove(output)

    try:
        shell_logger(output)
    except SystemExit:
        pass

    assert getsize(output) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-12 10:32:52.863787
# Unit test for function shell_logger
def test_shell_logger():
    # os.environ['SHELL'] = "/bin/bash"
    # shell_logger('/tmp/log')
    pass

# Generated at 2022-06-12 10:33:01.842133
# Unit test for function shell_logger
def test_shell_logger():
    """
    Tests shell_logger function.
    """
    from .. import log

    assert shell_logger('/tmp/shell_logger.txt') == 0

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:05.283704
# Unit test for function shell_logger
def test_shell_logger():
    output = "test.txt"
    shell_logger(output)
    assert os.path.exists(output)
    os.remove(output)

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:33:11.845620
# Unit test for function shell_logger
def test_shell_logger():
    from . import tmp
    from . import const
    import errno
    import os
    import subprocess
    import sys
    import tty
    import termios
    import fcntl
    import array
    import io
    import pty

    def test_pty_size():
        buf = array.array('h', [0, 0, 0, 0])
        fcntl.ioctl(pty.STDOUT_FILENO, termios.TIOCGWINSZ, buf, True)
        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, buf)

    def _test_spawn(master_read):
        """Create a spawned process.

        Modified version of pty.spawn with terminal size support.

        """
        pid, master_fd = pty.fork()


# Generated at 2022-06-12 10:33:12.425976
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:33:13.129769
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('output') == 30

# Generated at 2022-06-12 10:33:14.544589
# Unit test for function shell_logger
def test_shell_logger():
    pass


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-12 10:33:25.751579
# Unit test for function shell_logger
def test_shell_logger():
    with open('test_log.bin', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        fd = f.fileno()
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(' '.join([sys.executable, '-c', 'print("123")']), partial(_read, buffer))
        assert return_code == 0
        buffer.flush()
        f.close()

# Generated at 2022-06-12 10:33:27.486636
# Unit test for function shell_logger
def test_shell_logger():
    return_code = shell_logger('/tmp/_.log')
    assert return_code == os.EX_OK

# Generated at 2022-06-12 10:33:31.339060
# Unit test for function shell_logger
def test_shell_logger():
    """
    './tests/output.log' file should be empty otherwise
    """
    shell_logger('./tests/output.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:37.613159
# Unit test for function shell_logger
def test_shell_logger():
    if os.environ.get('SHELL'):
        output = 'test.txt'
        command = 'echo "test shell logger"'

        try:
            shell_logger(output)
        except SystemExit:
            pass

        with open(output, 'rb') as f:
            assert bytes(command, 'utf-8') in f.read()

        os.remove(output)
    else:
        pass

# Generated at 2022-06-12 10:33:46.169586
# Unit test for function shell_logger
def test_shell_logger():
    sys.argv = ['logger.py', 'shell', 'test_output']
    shell_logger(sys.argv[2])

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:33:47.842282
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell_logger')



# Generated at 2022-06-12 10:33:57.355949
# Unit test for function shell_logger
def test_shell_logger():
    """Tests if it works in the same way as normal shell with logging."""
    if not os.environ.get('SHELL'):
        logs.warn("This unit test doesn't work on your platform.")
        return
    import time
    import shutil
    dummy_output = 'dummy_output'
    shutil.copy('/bin/bash', dummy_output)
    os.chmod(dummy_output, os.stat(dummy_output).st_mode | stat.S_IEXEC)
    os.environ['SHELL'] = './' + dummy_output
    shell_logger('test_shell_logger')
    time.sleep(1)
    with open('test_shell_logger', 'r') as output:
        shell_log = output.read()

# Generated at 2022-06-12 10:33:59.760982
# Unit test for function shell_logger
def test_shell_logger():
    log_file = 'shell_logger.test'
    shell_logger(log_file)
    assert os.stat(log_file).st_size > 0

# Generated at 2022-06-12 10:34:08.050782
# Unit test for function shell_logger
def test_shell_logger():
    # Test for normal exit code
    sys.argv = ['nixio', 'shell-logger']
    with patch('builtins.os.environ', {'SHELL': 'shell'}):
        with patch('builtins.os.open', Mock(return_value=1)):
            with patch('builtins.os.write', Mock(return_value=1)):
                with patch('mmap.mmap', Mock(return_value=1)):
                    with patch('builtins.sys.exit', Mock(return_value=1)):
                        with patch('shutil.copyfile', Mock(return_value=1)):
                            with patch('subprocess.call', Mock(return_value=1)):
                                with patch('subprocess.Popen', Mock(return_value=True)):
                                    shell_logger

# Generated at 2022-06-12 10:34:15.413102
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess, os

    try:
        with open('/tmp/test', 'w') as f:
            subprocess.check_call([sys.executable, __file__, 'test'], stdout=f)
        with open('/tmp/test', 'r') as f:
            assert f.read() == 'Test!'
    finally:
        os.unlink('/tmp/test')

if __name__ == '__main__':
    if sys.argv[1] == 'test':
        print('Test!')

# Generated at 2022-06-12 10:34:21.432577
# Unit test for function shell_logger
def test_shell_logger():
    import os
    from .. import const
    from . import runner
    os._exit = sys.exit
    sys.exit = lambda x: None

    os.environ.update({'SHELL': 'cat'})
    os.access = lambda x, y: x != 'aaaaaaaa'

    with runner.StringIO() as output:
        shell_logger(output.name)

        assert os.path.exists(output.name)
        assert len(output.buflist) == 2
        assert output.buflist[0] == 'script starting on'
        assert output.buflist[1] == 'script done on'

        with open(output.name, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-12 10:34:23.111924
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: add
    pass

# Generated at 2022-06-12 10:34:24.159425
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test_shell_logger')

# Generated at 2022-06-12 10:34:34.730231
# Unit test for function shell_logger
def test_shell_logger():
    """Runs unit tests."""
    import pytest
    from . import tests
    from . import console
    from . import mocks
    from . import logs
    from . import shell

    mocks.setup()

    with pytest.raises(SystemExit):
        logs.disable()
        mocks.sys.environ['SHELL'] = False
        shell.shell_logger('/tmp/test-script.log')

    with pytest.raises(SystemExit):
        logs.disable()
        mocks.sys.environ['SHELL'] = '/bin/sh'
        mock_open = tests.mock_open()
        with mocks.open('/tmp/test-script.log', 'w') as mock_file:
            mock_open.return_value = mock_file

# Generated at 2022-06-12 10:34:50.834493
# Unit test for function shell_logger
def test_shell_logger():
    import logging
    import shlex
    import subprocess
    import os
    import tempfile
    import time
    import shutil
    import mock

    def run_command_in_shell(command, expected_ret_code=0, shell=os.environ.get('SHELL', 'bash')):
        # run process in a shell
        shell_process = subprocess.Popen(shell, stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
        shell_process.stdout.flush()
        shell_process.stdin.flush()

        # run the command in the shell we just created
        shell_process.stdin.write(command.encode())
        shell_process.stdin.flush()
        shell_process.stdin.close()
        output, error = shell_process

# Generated at 2022-06-12 10:34:56.818663
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time

    filepath_output = '/tmp/output'
    if os.path.isfile(filepath_output):
        os.remove(filepath_output)

    process = subprocess.Popen('python3.5 -m wfuzz.shell_logger {0} &'.format(filepath_output), shell=True, preexec_fn=os.setsid)
    time.sleep(1) # wait for shell started
    os.system("ps -ef | grep '{0}' | grep -v grep | awk '{{print $2}}' | xargs kill -s 9".format(filepath_output))
    time.sleep(1)
    process.wait()

    assert os.path.isfile(filepath_output)

# Generated at 2022-06-12 10:35:06.317191
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess

    with open('test.log', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    subprocess.check_call(['python3', '-c', 'from __future__ import print_function;'
                                            'import sys;'
                                            'print("test", file=sys.stderr);',
                           '--shell-logger', 'test.log'])

    with open('test.log', 'rb') as f:
        assert const.LOG_SIZE_IN_BYTES == f.read().index(b'test\n')

    os.unlink('test.log')

# Generated at 2022-06-12 10:35:07.692191
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("/tmp/test.log") == 0

# Generated at 2022-06-12 10:35:10.899271
# Unit test for function shell_logger
def test_shell_logger():
    import time
    shell_logger("/tmp/tmp.log")
    time.sleep(1)
    print("TEST DONE")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:35:18.608465
# Unit test for function shell_logger
def test_shell_logger():
    buf = ''
    buf_size = 20
    output = 'shell_logger'

    def shell_logger_test(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * buf_size)
        buffer = mmap.mmap(fd, buf_size, mmap.MAP_SHARED, mmap.PROT_WRITE)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

    test_log = 'test_shell_logger'
    os.environ['SHELL'] = 'echo'
    shell_logger_test(output)

# Generated at 2022-06-12 10:35:21.028577
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("") == 1

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:35:28.364425
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile
    import time

    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    output = os.path.join(tempdir, 'shell_logger.log')
    pid = os.fork()

    if pid == 0:
        os.environ['SHELL'] = '/bin/sh'
        shell_logger(output)
    else:
        time.sleep(2)
        os.kill(pid, signal.SIGKILL)
        os.waitpid(pid, 0)
        assert os.path.exists(output)

# Generated at 2022-06-12 10:35:32.249727
# Unit test for function shell_logger
def test_shell_logger():
    with TemporaryDirectory() as d:
        output = os.path.join(d, 'out.log')
        logger = shell_logger(output)
        logger.run(None)

        # Checking the result
        with open(output, 'r') as f:
            assert len(f.readlines()) == 1

# Generated at 2022-06-12 10:35:40.725934
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./shell_log.txt')
    test_log_file = open('./shell_log.txt', 'rb')
    test_log_file.seek(const.LOG_SIZE_IN_BYTES - 1024)
    test_log = test_log_file.read()
    if not test_log.startswith(b'\x00' * (const.LOG_SIZE_IN_BYTES - 1024)):
        print(b'Test Failed')
    else:
        print(b'Test Passed')
    test_log_file.close()
test_shell_logger()

# Generated at 2022-06-12 10:35:51.692651
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile

    output = tempfile.mkdtemp()
    tmp = os.path.join(output, 'test.txt')
    shell_logger(tmp)
    with open(tmp) as f:
        data = f.read()

    assert data
    shutil.rmtree(output)

# Generated at 2022-06-12 10:35:52.736071
# Unit test for function shell_logger
def test_shell_logger():
    #TODO: Add tests
    return True

# Generated at 2022-06-12 10:36:02.827435
# Unit test for function shell_logger
def test_shell_logger():
    def shell_logger_test(output):
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

        def _read_test(f, fd):
            data = os.read(fd, 100)
            f.write(data)

        _spawn(os.environ['SHELL'], partial(_read_test, buffer))


# Generated at 2022-06-12 10:36:11.666474
# Unit test for function shell_logger
def test_shell_logger():
    # test the clean log part
    buffer = [b'\x00' * const.LOG_SIZE_IN_BYTES]
    write_at = 0
    def _read_mock(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN
            for i in range(position):
                f[0][i] = f[0][i + const.LOG_SIZE_TO_CLEAN]
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
        return data


# Generated at 2022-06-12 10:36:16.268385
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import time

    fd, fname = tempfile.mkstemp()
    shell_logger(fname)
    time.sleep(1)
    f = open(fname, 'rb')
    shell = f.read()
    f.close()
    os.close(fd)
    shutil.remove(fname)
    assert shell

# Generated at 2022-06-12 10:36:26.412912
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import tempfile
    import time
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self._temp_output = tempfile.mktemp()
            self._script = 'from deoplete import loggers; loggers.shell_logger("' + self._temp_output + '")'

        def tearDown(self):
            os.remove(self._temp_output)

        def test_normal(self):
            subprocess.check_call(['python2', '-c', self._script + '; echo Hello'])
            time.sleep(1) # wait for writing to file
            with open(self._temp_output, 'r') as f:
                self.assertTrue('Hello' in f.read())


# Generated at 2022-06-12 10:36:34.906657
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test."""
    import tempfile
    import os
    import shutil
    import time

    # Create temporary dir
    work_dir = tempfile.mkdtemp()

    # Log file name
    log_file = '/log-{}'.format(time.time())

    # Test pass
    shell_logger(work_dir + log_file)

    # Count log lines
    try:
        with open(work_dir + log_file) as f:
            log_lines = f.readlines()
    except IOError:
        log_lines = []

    # Test pass
    assert len(log_lines) > 0

    # Remove temp dir
    shutil.rmtree(work_dir)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:36:36.267430
# Unit test for function shell_logger
def test_shell_logger():
    print('This is a test')


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:36:39.070389
# Unit test for function shell_logger
def test_shell_logger():
    sys.argv = ['', '-o', 'shell_logger.log']
    shell_logger(sys.argv[1])
    assert(os.path.isfile(sys.argv[1]))
    os.remove(sys.argv[1])

# Generated at 2022-06-12 10:36:41.140420
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile(prefix='shell-logger-') as f:
        shell_logger(f.name)

# Generated at 2022-06-12 10:37:03.397035
# Unit test for function shell_logger
def test_shell_logger():
    buffer = mmap.mmap(os.open('shell_logger.data', os.O_CREAT | os.O_TRUNC | os.O_RDWR),
                       const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    try:
        _spawn('echo', partial(_read, buffer))
    except pty.ChildProcessError:
        buffer.close()
        return

    buffer.close()
    os.remove('shell_logger.data')

    raise Exception('Shell logger has not been tested yet!')

# Generated at 2022-06-12 10:37:05.654777
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger function."""
    try:
        os.unlink("test_shell.txt")
    except:
        pass
    shell_logger("test_shell.txt")

# Generated at 2022-06-12 10:37:13.435477
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import time

    def clear_file(file_name):
        with open(file_name, 'wb') as output_file:
            output_file.write(b'\x00' * const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-12 10:37:23.812954
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil

    from . import const

    from .shell import shell_logger

    # Make sure we have a clean working directory
    log_file = 'shell.log'
    if os.path.exists(log_file):
        os.remove(log_file)

    # Point to the log file
    os.environ['SHELL_LOG_FILE'] = log_file

    # Run shell_logger
    shell_logger(log_file)

    # Make sure the log file is present
    assert os.path.exists(log_file)

    # Make sure the file has some json.dumps
    # TODO: move this to a separate test

# Generated at 2022-06-12 10:37:30.706981
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = 'echo '

    assert shell_logger('test') == 0
    assert os.path.exists('test')
    assert os.path.getsize('test') == const.LOG_SIZE_IN_BYTES
    with open('test', 'rb') as f:
        assert f.read().endswith(b'foobar')
    os.remove('test')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:37:39.439344
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import random
    import string
    import unittest

    def random_string(length):
        return ''.join(random.choice(string.ascii_uppercase) for _ in range(length))

    class TestShellLogger(unittest.TestCase):

        def setUp(self):
            self.output = self.mktemp()
            self.command = 'echo %s' % random_string(const.LOG_SIZE_TO_CLEAN)

        def test_shell_logger(self):
            os.putenv('SHELL', '/bin/bash')
            pid = os.fork()

            if pid == 0:
                shell_logger(self.output)

            os.waitpid(pid, 0)

            with open(self.output, 'r') as f:
                result = f

# Generated at 2022-06-12 10:37:49.617862
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import os
    import unittest.mock as mock

    class TestBashLogger(unittest.TestCase):
        @mock.patch('pty.fork')
        @mock.patch('os.open')
        @mock.patch('os.write')
        @mock.patch('mmap.mmap')
        @mock.patch('os.environ.get')
        @mock.patch('pytty.utils.shell.logs.warn')
        def test_bash_no_shell(self, mock_warn, mock_get, mock_mmap, mock_write, mock_open, mock_fork):
            mock_get.return_value = None

            shell_logger('tmp')
            self.assertEqual(mock_warn.call_count, 1)



# Generated at 2022-06-12 10:37:58.229511
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import time

    def get_log(output):
        with open(output, 'rb') as f:
            for line in iter(f.readline, b''):
                line = line.decode().strip()
                if line:
                    yield line

    output = './test-output'
    try:
        shell_logger(output)
    except KeyboardInterrupt:
        pass
    finally:
        shutil.rmtree(output)

    assert os.path.exists(output)
    os.remove(output)
    assert not os.path.exists(output)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:38:03.398048
# Unit test for function shell_logger
def test_shell_logger():
    """Runs shell_logger with specified output and checks the result.

    """
    import shutil
    import tempfile
    import time

    output = tempfile.mkstemp()[1]
    shell_logger(output)
    time.sleep(1)
    assert(const.LOG_SIZE_IN_BYTES == os.path.getsize(output))
    shutil.rmtree(output)

# Generated at 2022-06-12 10:38:08.852864
# Unit test for function shell_logger
def test_shell_logger():
    """Logs shell output to the `output`."""

    import filecmp
    import tempfile

    output = tempfile.mkstemp()[1]
    buffer = tempfile.mkstemp()[1]
    shell_logger(output)
    with open(output, 'rb') as f:
        buffer = f.read(const.LOG_SIZE_IN_BYTES)
    assert filecmp.cmp('%s.expected' % __file__[:-3], buffer, shallow=False)
    os.remove(output)


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:38:29.572195
# Unit test for function shell_logger
def test_shell_logger():
    from .text import read
    import os
    import tempfile
    import subprocess

    _, output = tempfile.mkstemp()
    try:
        os.unlink(output)
    except FileNotFoundError:
        pass
    p = subprocess.Popen(['shell-logger', output])
    p.wait()
    p = subprocess.Popen(['shell-logger', output])
    p.wait()
    assert read(output) == read(output)

# Generated at 2022-06-12 10:38:33.656835
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    output = tempfile.mktemp(suffix='.log')
    shell_logger(output)
    shutil.rmtree(output)
    return True


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:38:39.738680
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('output', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
    print(buffer)

    sys.exit(return_code)
if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:38:40.966261
# Unit test for function shell_logger
def test_shell_logger():
    # ToDo: implement unit test for function shell_logger
    pass

# Generated at 2022-06-12 10:38:46.525369
# Unit test for function shell_logger
def test_shell_logger():
    from . import test_helpers

    os.environ['SHELL'] = '/bin/bash'
    shell_logger(output='/tmp/shell.log')
    log = test_helpers.tail_log('/tmp/shell.log')
    assert b'\x1B[1;32m' in log
    assert b'\x1B[m' in log

# Generated at 2022-06-12 10:38:49.211624
# Unit test for function shell_logger
def test_shell_logger():
    returncode_expected = 1
    returncode_real = shell_logger(const.LOG_FILENAME);
    assert returncode_real == returncode_expected, "Return code is different from expected"


# Generated at 2022-06-12 10:38:54.843638
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        with open(f.name, 'rb') as g:
            shell_logger(f.name)
            g.seek(const.LOG_SIZE_IN_BYTES - 1)
            assert g.read() == b'\x00'

# Generated at 2022-06-12 10:38:57.467221
# Unit test for function shell_logger
def test_shell_logger():
    test_file = 'test_file'
    shell_logger(test_file)
    with open(test_file, 'r') as f:
        assert bool(f.read())

# Generated at 2022-06-12 10:39:06.456990
# Unit test for function shell_logger
def test_shell_logger():
    try:
        if sys.platform == 'darwin':
            os.environ['SHELL'] = '/bin/bash'
            sys.stderr.write('The OS is OS X!')
        elif sys.platform == 'linux2':
            os.environ['SHELL'] = '/bin/sh'
            sys.stderr.write('The OS is Linux!')
        elif sys.platform == 'win32':
            os.environ['SHELL'] = 'C:/Windows/System32/cmd.exe'
            sys.stderr.write('The OS is Windows!')
        shell_logger(sys.argv[1])
    except Exception as e:
        sys.stderr.write(str(e))
        sys.exit(1)


# Generated at 2022-06-12 10:39:10.860141
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    temp = tempfile.NamedTemporaryFile()
    output_path = temp.name
    shell_logger(output_path)
    assert os.path.exists(output_path)
    assert os.path.isfile(output_path)
test_shell_logger

# Generated at 2022-06-12 10:39:26.995141
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: write unit test for function
    # shell_logger
    pass

# Generated at 2022-06-12 10:39:28.254255
# Unit test for function shell_logger
def test_shell_logger():
    pass


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-12 10:39:30.412041
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/shell.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:39:35.972934
# Unit test for function shell_logger
def test_shell_logger():
    """Test for function shell_logger"""
    output = 'test.txt'
    shell_logger(output)
    f = open(output, 'rb')
    data = f.read()
    f.close()
    os.remove(output)
    assert data == b'\x00' * const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-12 10:39:42.681603
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess

    logs.debug('Testing [utils.shell_logger].')
    temp_dir = tempfile.mkdtemp()
    file_path = temp_dir + '/test.log'
    proc = subprocess.Popen(['python3', '-c',
                             'from shell_logger import utils;'
                             'utils.shell_logger("{}")'.format(file_path)])
    proc.wait()

    output = open(file_path, 'rb').read()
    shutil.rmtree(temp_dir)

    assert b'Python' in output or b'python' in output

# Generated at 2022-06-12 10:39:52.207293
# Unit test for function shell_logger
def test_shell_logger():
    from .shell import shell_logger, open_log
    import subprocess, tempfile
    import os

    def mock_spawn(shell, master_read):
        master_read('abc\n')
        master_read('def\n')

    old_spawn = _spawn
    _spawn = mock_spawn
    try:
        output = tempfile.NamedTemporaryFile().name
        subprocess.check_output([sys.executable, '-c', 'from shell import shell_logger; '
                                'shell_logger("{}")'.format(output)])
        with open(output) as f:
            assert 'abc' in f.read()
    finally:
        _spawn = old_spawn
        os.unlink(output)

# Generated at 2022-06-12 10:39:54.371752
# Unit test for function shell_logger
def test_shell_logger():
    output = str(random.randint(0, 32767))
    return_code = shell_logger(output)
    assert return_code == 0
    f = open('test_shell_logger.txt', 'w')
    f.write('test_shell_logger')
    f.close()
    sys.exit()


# Generated at 2022-06-12 10:40:02.354766
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import shutil

    # Create a temp dir and navigate to it.
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Prepare the shell logger function and start it
    log_file = 'output.log'
    func = partial(shell_logger, log_file)
    func_proc = subprocess.Popen(
        'python2 -c "from sarg.loggers import shell_logger; shell_logger(\\"output.log\\")"',
        shell=True)

    # Wait a bit before executing the next command.
    time.sleep(1)

    # Write some data to the terminal
    subprocess.call('echo foo', shell=True)

    # Wait a bit before executing the next command.
    time.sleep(1)

   

# Generated at 2022-06-12 10:40:04.816007
# Unit test for function shell_logger
def test_shell_logger():
    try:
        if os.environ.get('SHELL'):
            shell_logger('/tmp/pty-logger-test.out')
    except KeyboardInterrupt:
        pass


# Generated at 2022-06-12 10:40:14.033381
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    try:
        os.remove('/tmp/test_file')
    except OSError:
        pass
    p = subprocess.Popen([sys.executable, '-m', __package__, 'shell_logger', '/tmp/test_file'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # send pw
    p.stdin.write(b'bodydna\n')
    p.stdin.flush()
    # send ls
    p.stdin.write(b'ls\n')
    p.stdin.flush()
    # send exit
    p.stdin.write(b'exit\n')
    p.stdin.flush()
    p.wait()

# Generated at 2022-06-12 10:40:35.024193
# Unit test for function shell_logger
def test_shell_logger():
    def write_to_file(filename):
        f = open(filename, 'wb')
        f.write(b"foobar")
        f.close()

    # test shell logger with existing file
    output = "somefile.txt"
    write_to_file(output)
    shell_logger(output)
    assert open(output, 'rb').read() == b'foobar'

    # test shell logger without existing file
    output = "somefile_2.txt"
    assert not os.path.exists(output)
    shell_logger(output)
    assert open(output, 'rb').read() == b''

# Generated at 2022-06-12 10:40:39.093751
# Unit test for function shell_logger
def test_shell_logger():
    import atexit
    from tempfile import mkstemp
    import os

    fd, name = mkstemp()
    os.close(fd)
    shell_logger(name)

    atexit.unregister(shell_logger)
    os.unlink(name)
    assert True

# test_shell_logger()

# Generated at 2022-06-12 10:40:48.592561
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger."""
    import tempfile
    import shutil
    expected = u""">>> ls
__init__.py
__init__.pyc
conftest.py
conftest.pyc
logs.py
logs.pyc
setup.cfg
setup.py
tests
>>> pwd
/Users/yakovlev-p/workspace/python/shell-prt/shell_prt
>>> echo hello
hello
>>> exit

yakovlev-p-mbp:shell_prt yakovlev-p$ """
    temp_dir = tempfile.mkdtemp()
    temp_file = temp_dir + "log.txt"
    shell_logger(temp_file)
    with open(temp_file, "r") as output:
        lines = output.read()



# Generated at 2022-06-12 10:40:51.341845
# Unit test for function shell_logger
def test_shell_logger():
    # Create a tmpfile
    outfile = tempfile.mkstemp()[1]
    # Run shell_logger
    shell_logger(outfile)
    # Remove tmpfile
    os.remove(outfile)

# Generated at 2022-06-12 10:40:56.474930
# Unit test for function shell_logger
def test_shell_logger():
    file = open('/tmp/test_shell', 'w+')
    pty._spawn = _spawn
    shell_logger('/tmp/test_shell')
    assert os.path.getsize('/tmp/test_shell') == const.LOG_SIZE_IN_BYTES
    file.close()
    os.remove('/tmp/test_shell')

# Generated at 2022-06-12 10:41:03.701236
# Unit test for function shell_logger
def test_shell_logger():
    from io import BytesIO
    from contextlib import redirect_stdout
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(delete=False) as f, redirect_stdout(f):
        stream = BytesIO()
        logger = logs.Logger()
        logger.info('foobar', file=stream)
        sys.stdout.write(stream.getvalue())

    os.unlink(f.name)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:41:08.266170
# Unit test for function shell_logger
def test_shell_logger():
    import re
    import subprocess
    from .. import logs
    from ..utils import log_reader

    fd, filename = logs.get_fd_and_filename(__name__, __file__)
    try:
        shell_logger(filename)
    except OSError:
        # If this test has been executed on an unsupported platform
        return
    with open(filename, 'rb') as f:
        f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
        data = ''.join(chr(b) for b in f.read(const.LOG_SIZE_TO_CLEAN))

    print('Logfile:')
    print(data)

    assert data

# Generated at 2022-06-12 10:41:09.057974
# Unit test for function shell_logger
def test_shell_logger():
    pass
# Finished unit test for function shell_logger

# Generated at 2022-06-12 10:41:15.038553
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import io
    import termios

    output = io.BytesIO()
    size_of_buf = 5

    def _read(f, fd):
        data = os.read(fd, size_of_buf)
        try:
            f.write(data)
        except ValueError:
            f.truncate(size_of_buf)
            f.seek(0)
            f.write(b'\x00' * size_of_buf)
            f.seek(0)
        return data

    # need to patch because tty.setraw is not available in python 2.6
    def setraw(fd):
        mode = tty.tcgetattr(pty.STDIN_FILENO)

# Generated at 2022-06-12 10:41:16.937266
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('abc')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:41:32.754617
# Unit test for function shell_logger
def test_shell_logger():
    pass


# Generated at 2022-06-12 10:41:34.876728
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""

    assert shell_logger
    print ("test_shell_logger passed")


if __name__ == "__main__":

    test_shell_logger()

# Generated at 2022-06-12 10:41:38.109074
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/sh'
    buffer = os.path.join(os.path.dirname(__file__), 'logger.txt')
    shell_logger(buffer)
# End of testing

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-12 10:41:48.300336
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger."""
    import shutil
    #import tempfile
    #from .. import cli
    #from .. import execution
    #from functools import partial
    #from ctypes import CDLL
    #from ctypes.util import find_library

    tmp = '/tmp/test_shell_logger.txt'
    #libc = CDLL(find_library('c'))
    #pid = libc.getpid()

    def cleanup():
        shutil.rmtree(tmp)

    #with tempfile.NamedTemporaryFile(suffix='.log', prefix='shell-%s-' % pid) as f:
    #tmp = f.name
    #cli.execute_command(
    #partial(execution.execute_command, command=partial(shell_logger, output=

# Generated at 2022-06-12 10:41:56.516406
# Unit test for function shell_logger
def test_shell_logger():
    log = 'log.txt'
    file = open(log, 'w')
    file.close()

    def get_last(file):
        fd = os.open(file, os.O_RDONLY)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        buffer.read(buffer.rindex(b'\n')).split(b'\n')[-2]
    with open(log, 'w') as file:
        file.write('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n')

# Generated at 2022-06-12 10:41:56.986612
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-12 10:42:03.056621
# Unit test for function shell_logger
def test_shell_logger():
    def do_test():
        import tempfile
        with tempfile.TemporaryDirectory() as tempdir:
            with open(tempdir + '/test_shell_logger.txt', 'w') as tfile:
                tfile.write('/bin/true')
            shell_logger(tempdir + '/test_shell_logger.txt')

    import unittest
    class TestShellLogger(unittest.TestCase):
        def test(self):
            self.assertEqual(do_test(), 0)

    unittest.main(verbosity=2)