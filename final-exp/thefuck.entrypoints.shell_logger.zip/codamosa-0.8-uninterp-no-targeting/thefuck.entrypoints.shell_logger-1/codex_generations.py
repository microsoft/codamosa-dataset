

# Generated at 2022-06-22 00:37:59.174671
# Unit test for function shell_logger
def test_shell_logger():
    from unittest import mock
    import tempfile
    from shlex import quote

    def mock_spawn(shell, master_read):
        if shell != '/bin/bash':
            raise Exception('Unexpected shell')
        master_read(pty.STDOUT_FILENO)
        return 0

    with tempfile.NamedTemporaryFile() as f:
        with mock.patch('pty.spawn', mock_spawn):
            shell_logger(f.name)

    with open(f.name, 'r') as f:
        assert f.read() == 'logs.py'

# Generated at 2022-06-22 00:38:08.518690
# Unit test for function shell_logger
def test_shell_logger():
    """test_shell_logger"""
    pass

# Generated at 2022-06-22 00:38:12.409387
# Unit test for function shell_logger
def test_shell_logger():
    """ Unit test for function shell_logger
    """
    from . import _test_shell_logger
    _test_shell_logger.test_shell_logger()

# Generated at 2022-06-22 00:38:20.142302
# Unit test for function shell_logger
def test_shell_logger():
    os.mkfifo('test.pipe', mode=0o600)
    p = Process(target=shell_logger, args=('test.pipe',))
    p.start()
    sleep(0.1)
    logger = ShellLogger('test.pipe')
    logger.start()

    # Check if all is well
    assert logger.output == list()
    assert len(logger.output) == 0

    # Stop logger and proc, remove the pipe
    logger.stop()
    p.terminate()
    os.remove('test.pipe')
    sleep(0.1)

# Generated at 2022-06-22 00:38:23.261061
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test_output.txt')

if __name__ == '__main__':
    # test_shell_logger()
    pass

# Generated at 2022-06-22 00:38:28.287188
# Unit test for function shell_logger
def test_shell_logger():
    os.system("python3 -m shlogger test/test.log")
    assert os.path.exists("test/test.log")

if __name__ == '__main__':
    shell_logger(sys.argv[1])

# Generated at 2022-06-22 00:38:28.931099
# Unit test for function shell_logger
def test_shell_logger():
    assert 1 == 0

# Generated at 2022-06-22 00:38:36.602911
# Unit test for function shell_logger
def test_shell_logger():
    # Test with file not existent
    try:
        logging_file = '/tmp/notexistentfile'
        os.remove(logging_file)
    except OSError as e:
        if e.errno != 2:
            raise e
    finally:
        shell_logger(logging_file)

    # Test with file existent
    fd = open(logging_file, 'wb+')
    for i in range(1000):
        fd.write(b'a')
    fd.flush()
    shell_logger(logging_file)
    fd.close()

# vim:ts=4 sts=4 sw=4 et

# Generated at 2022-06-22 00:39:06.747705
# Unit test for function shell_logger

# Generated at 2022-06-22 00:39:08.004399
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("shell_logger_test")



# Generated at 2022-06-22 00:39:22.191794
# Unit test for function shell_logger
def test_shell_logger():
    STDOUT_FILENO = 1
    sys.argv = ["shell_logger", "shell_logger_test"]
    if sys.version_info[0] == 2:
        sys.stdout = os.fdopen(sys.stdout.fileno(), 'wb', 0)
    # Make sure that shell_logger_test is empty
    fp = open('shell_logger_test', 'wb')
    fp.close()
    try:
        shell_logger('shell_logger_test')
    except:
        return
    raise Exception('shell_logger should have failed but it did not')

# Generated at 2022-06-22 00:39:31.598191
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function `shell_logger`."""
    output = 'test.log'
    try:
        os.remove(output)
    except FileNotFoundError:
        pass
    assert not os.path.exists(output)

    shell_logger(output)

    assert os.path.exists(output)
    assert os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    with open(output, 'rb') as f:
        assert f.read(const.LOG_SIZE_IN_BYTES - 1) != b'\x00' * (const.LOG_SIZE_IN_BYTES - 1)

# Generated at 2022-06-22 00:39:37.630247
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.dir_name = tempfile.mkdtemp()
            self.file_name = os.path.join(self.dir_name, "test.txt")
            self.tearDown()

        def tearDown(self):
            try:
                os.remove(self.file_name)
            except OSError:
                pass
            shutil.rmtree(self.dir_name)


        def test_shell_logger(self):
            """ It tests that shell_logger is writing its output to the file. """
            import os
            import subprocess
            import time

            def get_count(file_name):
                return

# Generated at 2022-06-22 00:39:41.014205
# Unit test for function shell_logger
def test_shell_logger():
    (master_fd, slave_fd) = pty.openpty()
    pid = os.fork()

    if pid == pty.CHILD:
        os.close(master_fd)
        tty.setraw(slave_fd)
        pty.dup2(slave_fd, pty.STDIN_FILENO)
        pty.dup2(slave_fd, pty.STDOUT_FILENO)
        pty.dup2(slave_fd, pty.STDERR_FILENO)
        os.execlp('sh', 'sh')

    try:
        cmd = b'echo "Some text"\n'
        os.write(master_fd, cmd)
        os.waitpid(pid, 0)
    finally:
        os.close(master_fd)
        os.close

# Generated at 2022-06-22 00:39:48.847936
# Unit test for function shell_logger
def test_shell_logger():
    try:
        os.environ['ENV_SHELL'] = os.environ['SHELL']
        os.environ['SHELL'] = 'cat'
        shell_logger('output.log')
    finally:
        os.environ['SHELL'] = os.environ['ENV_SHELL']
        if 'ENV_SHELL' in os.environ:
            del os.environ['ENV_SHELL']
        if os.path.exists('output.log'):
            os.remove('output.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:39:49.635698
# Unit test for function shell_logger
def test_shell_logger():
    print(shell_logger('test.txt'))

# Generated at 2022-06-22 00:39:59.089660
# Unit test for function shell_logger
def test_shell_logger():
    read_data = b''
    with open('/tmp/test_shell_logger', 'wb') as f:
        f.write(b'\x00' * 128)
        fd = f.fileno()
        buffer = mmap.mmap(fd, 128, mmap.MAP_SHARED, mmap.PROT_WRITE)
        _read(buffer, sys.stdin.fileno())
        buffer.close()
        f.close()
    with open('/tmp/test_shell_logger', 'rb') as f:
        read_data = f.read()
    return read_data == b'\x00' * 127 + b'\n'

# Generated at 2022-06-22 00:40:04.039348
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import unittest
    import os
    import tempfile
    import shutil


    class TestShellLogger(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestShellLogger, self).__init__(*args, **kwargs)
            self.temp_dir = tempfile.mkdtemp()
            self.output = os.path.join(self.temp_dir, "output")
            os.environ["SHELL"] = "/bin/sh"

        def test_1(self):
            shell_logger(self.output)
            with open(self.output) as f:
                content = f.read()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-22 00:40:06.674917
# Unit test for function shell_logger
def test_shell_logger():
    file = './log.txt'

    if os.path.exists(file):
        os.remove(file)
    shell_logger(file)

# Generated at 2022-06-22 00:40:10.857783
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    shell_logger('./tests/data/tmp/shell_log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:17.659520
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(const.TEST_LOG_FILE)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:18.207865
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:40:26.419544
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import subprocess

    try:
        # Suppress error messages.
        with open(os.devnull, 'w') as devnull:
            subprocess.check_call(['script', '-f', 'test_shell_logger.log'], stdout=devnull, stderr=devnull)
    finally:
        subprocess.call(['pkill', '-P', str(os.getpid())])
        shutil.rmtree('test_shell_logger.log')

# Generated at 2022-06-22 00:40:37.135791
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        output = os.path.join(tmpdirname, 'output.log')
        with open(output, 'wb') as file:
            file.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        with open('test_shell_logger.py', 'r') as file:
            str = file.read()
        print(b'ls\n' + str.encode() + b'\nls\n')
        sys.stdin = open('/dev/stdin', 'rb')
        shell_logger(output)
        with open(output, 'rb') as file:
            content = file.read()
        print(content)
        assert content.find(b'ls\n') != -1

# Generated at 2022-06-22 00:40:43.058390
# Unit test for function shell_logger
def test_shell_logger():
    log_file = tempfile.NamedTemporaryFile(delete=False)
    log_file_name = log_file.name
    log_file.close()
    shell_logger(log_file_name)
    f = open(log_file_name, "r")
    log_data = f.read()
    f.close()
    os.remove(log_file_name)
    assert log_data == ''

# Generated at 2022-06-22 00:40:53.723345
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import tempfile

    fd, output = tempfile.mkstemp()
    tty, master_fd = pty.openpty()

    pid = subprocess.Popen(['python', '-m', 'trapdoor.shell.logger', output],
                           stdout=master_fd, stdin=master_fd).pid

    def send(data):
        os.write(tty, data)
        read = ''
        while True:
            data = os.read(tty, 1024)
            if not data:
                break
            read += data

        return read.strip()

    send('for i in {1..5}; do echo "Hello: $i"; sleep 0.2; done\n')
    with open(output, 'r') as f:
        text = f.read()

# Generated at 2022-06-22 00:41:03.823519
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger."""
    print("Started shell logger test...")
    TEST_FILE_PATH = "test_file.out"
    os.system("rm -f " + TEST_FILE_PATH)
    os.system("echo 'test' >> " + TEST_FILE_PATH)
    shell_logger(TEST_FILE_PATH)
    file=open(TEST_FILE_PATH, "rb")
    if not file.seek(0, 2):
        return
    file.seek(0, 0)
    content = file.read(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN + 5)
    file.close()
    res = content.find(b"test", 0, len(content))
    assert res != -1

# Generated at 2022-06-22 00:41:12.027323
# Unit test for function shell_logger
def test_shell_logger():
    from . import utils

    with utils.TemporaryDirectory(prefix='bpython.') as directory:
        with utils.RedirectStdIO(directory, directory) as stdio:
            path = stdio.get_redirected_path('output')
            shell_logger(path)
            stream = stdio.open(directory)
            assert stream.read() == '/bin/sh\n'

# Generated at 2022-06-22 00:41:12.579743
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:41:20.231263
# Unit test for function shell_logger
def test_shell_logger():
   import unittest
   import tempfile
   import shutil
   import os
   import pty

   class TestShellLogger(unittest.TestCase):
       '''Test shell logger.
       '''
       @classmethod
       def setUpClass(self):
           logs_path = '/tmp/logs'
           self.logs_path = logs_path
           if os.path.isdir(logs_path):
               shutil.rmtree(logs_path)

           os.makedirs(logs_path)
           tty.setraw(pty.STDIN_FILENO)

       @classmethod
       def tearDownClass(self):
           shutil.rmtree(self.logs_path)


# Generated at 2022-06-22 00:41:27.062222
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test.log')

# Generated at 2022-06-22 00:41:32.170915
# Unit test for function shell_logger
def test_shell_logger():
    for log_size in const.LOG_SIZE_IN_BYTES, const.LOG_SIZE_TO_CLEAN:
        with open('.test_shell_logger', 'wb') as f:
            f.write(b'\x00' * log_size)
        shell_logger('.test_shell_logger')
        os.remove('.test_shell_logger')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:33.603387
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(const.OUTPUT_FILE)

# Generated at 2022-06-22 00:41:39.826551
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import logging
    import tempfile

    ec = io.StringIO()
    logger = logging.getLogger('pytest')
    logger.setLevel(logging.INFO)
    logger.addHandler(logging.StreamHandler(ec))

    with tempfile.NamedTemporaryFile() as output:
        shell_logger(output.name)

    assert ec.getvalue() == ""

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:51.091566
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function."""
    import tempfile
    import os
    import subprocess
    import shutil

    dirname = tempfile.mkdtemp()
    with open(os.path.join(dirname, 'test.log'), 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    return_code = subprocess.call([sys.executable, '-c', 'import sys; import time; time.sleep(1); sys.exit(1)'], env={'SHELL': '/bin/bash', 'TERM': 'xterm'})
    assert return_code == 1


# Generated at 2022-06-22 00:41:53.480983
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('build/test.log')
    except SystemExit as e:
        assert e.code == 0

# Generated at 2022-06-22 00:42:02.770624
# Unit test for function shell_logger
def test_shell_logger():
    logger = logs.logger_unit_test(shell_logger, 'test_shell_logger',
                                   'test_shell_logger.log')
    assert logger.exists()
    assert logger.size() == const.LOG_SIZE_IN_BYTES
    assert logger.get_bytes() == b'\x00' * const.LOG_SIZE_IN_BYTES
    assert logger.read() == ''

    assert not os.environ.get('SHELL')
    logger = logs.logger_unit_test(shell_logger, 'test_shell_logger',
                                   'test_shell_logger.log')
    assert logger.read() == 'Shell logger doesn\'t support your platform.\n'

# Generated at 2022-06-22 00:42:04.438016
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-22 00:42:13.296128
# Unit test for function shell_logger
def test_shell_logger():
    from datetime import datetime
    import pytest
    from threading import Timer
    import time

    def _test_shell_logger(output):
        def _tmp_shell(path):
            fd = os.open(path, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
            os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
            buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
            return_code = _spawn('/bin/sh', partial(_read, buffer))
            return return_code

        def _test(output):
            return _tmp_shell(output)

# Generated at 2022-06-22 00:42:22.260560
# Unit test for function shell_logger
def test_shell_logger():
    # Prep
    from os.path import exists
    from tempfile import mkdtemp
    from shutil import rmtree
    from . import const, logs

    tmpdir = mkdtemp()
    logs.init(tmpdir)
    out = tmpdir + '/file'
    assert not exists(out)

    # Run
    shell_logger(out)

    # Assert
    assert exists(out)
    assert open(out, 'rb').read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    # Cleanup
    rmtree(tmpdir)

# Generated at 2022-06-22 00:42:30.971857
# Unit test for function shell_logger
def test_shell_logger():
    assert callable(shell_logger)
    assert shell_logger("a")

# Generated at 2022-06-22 00:42:32.727068
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("shell.log")

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-22 00:42:33.515794
# Unit test for function shell_logger
def test_shell_logger():
    # TODO
    pass

# Generated at 2022-06-22 00:42:36.422446
# Unit test for function shell_logger
def test_shell_logger():
    import pytest
    with pytest.raises(SystemExit) as error:
        shell_logger("./shell_logger.log")
    assert error.value.code == 0

# Generated at 2022-06-22 00:42:36.925805
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:42:42.640006
# Unit test for function shell_logger
def test_shell_logger():
    try:
        os.remove('shell_logger_test.txt')
    except OSError:
        pass
    shell_logger('shell_logger_test.txt')
    logs.info('Exit code: %d' % sys.exc_info()[1].code)
    with open('shell_logger_test.txt') as f:
        logs.info(f.read())

# Generated at 2022-06-22 00:42:48.507655
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile(mode="r+b") as tf:
        return_code = subprocess.call(
            [sys.executable, __file__, 'shell_logger', tf.name]
        )
        assert return_code == 1
        assert tf.read() == '\x00' * const.LOG_SIZE_IN_BYTES



# Generated at 2022-06-22 00:43:00.000216
# Unit test for function shell_logger
def test_shell_logger():
    def get_log_content():
        with open(output, 'rb') as f:
            f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
            return f.read()

    output = '/tmp/shell_logger_test.log'
    if os.path.exists(output):
        os.unlink(output)

    try:
        shell_logger(output)
    except OSError as e:
        logs.warn(e)
    else:
        content = get_log_content()
        assert content.endswith(b'$ exit\n')
        assert content.startswith(b'$ exit\n')
    finally:
        if os.path.exists(output):
            os.unlink(output)



# Generated at 2022-06-22 00:43:11.699391
# Unit test for function shell_logger
def test_shell_logger():
    from subprocess import check_call
    from tempfile import NamedTemporaryFile
    from .test import CharDevice
    from .test import Pipe

    with NamedTemporaryFile(delete=False) as log_file:
        assert check_call([sys.executable,
                           '-c',
                           'from shellexpand.logs import shell_logger; shell_logger("' + log_file.name + '")']) == 0
        log_file.close()

    with CharDevice() as char_device:
        with Pipe(char_device) as pipe:
            shell_logger(log_file.name)
            pipe.write(b'echo 1\n')
            pipe.write(b'echo 2\n')
            pipe.write(b'exit\n')


# Generated at 2022-06-22 00:43:22.761291
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import io as io_module
    from io import BytesIO
    from io import UnsupportedOperation
    import os as os_module
    import platform
    import sys as sys_module
    import tempfile
    import termios as termios_module
    import tty as tty_module
    import unittest
    from unittest import mock

    from . import shells
    from . import const

    class OpenMock(io_module.IOBase):
        def __init__(self, *args, **kwargs):
            pass

        def write(self, data):
            if len(data) > const.LOG_SIZE_TO_CLEAN:
                self.seek(0, io_module.SEEK_END)
                position = self.tell() - const.LOG_SIZE_TO_CLEAN

# Generated at 2022-06-22 00:43:31.127019
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:43:32.238013
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell_logger')

# Generated at 2022-06-22 00:43:39.717657
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test_shell_output'
    shell_logger(output)
    expected = 'test\n'
    with open(output, 'rb') as f:
        assert f.read(4) == b'\x00\x00\x00\x00'
        assert f.read(4) == b'\x00\x00\x00\x00'
        assert f.read(4) == b'\x00\x00\x00\x00'
        assert f.read(4) == b'test'

# Generated at 2022-06-22 00:43:48.017979
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    from unittest.mock import patch, MagicMock

    class TestShellLogger(unittest.TestCase):
        @patch('builtins.sys.exit')
        @patch('builtins.print')
        def test_shell_not_found(self, mock_print, mock_exit):
            with patch.dict('os.environ', {'SHELL': None, 'PWD': 'pwd'}, clear=True):
                shell_logger('output')
                mock_print.assert_called_once_with("Shell logger doesn't support your platform.")
                mock_exit.assert_called_once_with(1)


# Generated at 2022-06-22 00:43:48.654786
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:43:59.620403
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import textwrap
    from .. import logs, const

    # Generate test function for different shell types
    for shell in ['bash', 'zsh', 'fish', 'tcsh', 'csh']:
        def test(shell):
            logs.debug('Testing %s shell' % shell)

            temp_dir = tempfile.mkdtemp()
            output = os.path.join(temp_dir, 'output.log')
            expected_output = os.path.join(temp_dir, 'expected_output.log')

            # Run shell command
            os.environ['SHELL'] = shell
            shell_logger(output)

            # Get user stdin

# Generated at 2022-06-22 00:44:05.784998
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as f:
        old_stdout = sys.stdout
        sys.stdout = f
        shell_logger(os.path.join(os.path.dirname(f.name), "logfile.txt"))
        sys.stdout = old_stdout

        with open(f.name, 'r') as log_file:
            assert "Script started on" in log_file.read()

# Generated at 2022-06-22 00:44:15.690352
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile

    temp_file_fd, temp_file_name = tempfile.mkstemp()
    try:
        shell_logger(temp_file_name)
    except SystemExit as e:
        assert e.code == 0
        assert os.path.getsize(temp_file_name) > 0
    finally:
        os.close(temp_file_fd)
        os.remove(temp_file_name)

    # Corner case when log file has to be cleaned up
    temp_file_fd, temp_file_name = tempfile.mkstemp()
    os.write(temp_file_fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    os.close(temp_file_fd)
    shell_logger(temp_file_name)

# Generated at 2022-06-22 00:44:16.713538
# Unit test for function shell_logger
def test_shell_logger():
    assert 1 == 2, 'Test not implemented'

# Generated at 2022-06-22 00:44:22.792037
# Unit test for function shell_logger
def test_shell_logger():
  try:
    with open('/tmp/logger-test.txt', 'w') as testfile:
      shell_logger(testfile.name)
  except OSError as e:
    #  Only root can write to logger
    if e.errno == 1:
      print('Test passed')
    else:
      print('Test failed')
  finally:
    if os.path.isfile('/tmp/logger-test.txt'):
      os.remove('/tmp/logger-test.txt')

# Generated at 2022-06-22 00:44:37.602961
# Unit test for function shell_logger
def test_shell_logger():

    # Write output to non existing file
    shell_logger("test.log")

    # Read output from file
    fd = os.open("test.log", os.O_RDONLY)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)
    assert buffer.readline() != const.EXIT_COMMAND
    assert buffer.readline().decode() == const.EXIT_OUTPUT

# Generated at 2022-06-22 00:44:47.204558
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('./unit_test_shell_logger.txt', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

    # Unit test
    assert return_code == 0


if __name__ == '__main__':
    test_shell_logger()
    sys.exit(0)

# Generated at 2022-06-22 00:44:53.774412
# Unit test for function shell_logger
def test_shell_logger():
    import contextlib
    from .common import TEST_OUT_LOG
    from .common import read_log, delete

    with delete(TEST_OUT_LOG):
        with contextlib.redirect_stdout(sys.stdout):
            shell_logger(TEST_OUT_LOG)
    assert read_log(TEST_OUT_LOG)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:45:01.812324
# Unit test for function shell_logger
def test_shell_logger():
    from .. import const
    from io import open

    const.LOG_SIZE_IN_BYTES = const.LOG_SIZE_IN_BYTES_TEST
    const.LOG_SIZE_TO_CLEAN = const.LOG_SIZE_TO_CLEAN_TEST

    test_log = b'test123\n'

    import subprocess
    import os
    import mmap

    file_name = 'test-file'

    # If file exists, just delete it.
    try:
        os.unlink(file_name)
    except OSError:
        pass

    # Start the shell logger

# Generated at 2022-06-22 00:45:09.891210
# Unit test for function shell_logger
def test_shell_logger():

    def tester(filename):
        assert os.path.exists(filename)
        assert os.path.getsize(filename) == const.LOG_SIZE_IN_BYTES
        with open(filename, 'r') as f:
            assert len(f.read()) == 0
        os.remove(filename)

    with logs.use_stream('stdout') as stdout, \
            logs.use_stream('stderr'):
        tester(stdout.name)
        tester(stderr.name)

# Generated at 2022-06-22 00:45:20.307734
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open(':/tmp/test_shell_logger.out', os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o666)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    _read(buffer, fd)
    buffer.close()
    os.close(fd)
    os.remove('/tmp/test_shell_logger.out')
if __name__ == '__main__':
    test_shell_logger()


# Generated at 2022-06-22 00:45:27.482574
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs, tests
    from contextlib import ExitStack
    from . import shell_logger

    with tests.tests_dir() as dir_:
        path = os.path.join(dir_, 'shell_logger.txt')
        size = const.LOG_SIZE_IN_BYTES
        with ExitStack() as ctx:
            buffer_ = ctx.enter_context(mmap.mmap(os.open(path, os.O_CREAT | os.O_TRUNC | os.O_RDWR), size))
            mock_print = ctx.enter_context(tests.mock_exit(0))
            ctx.enter_context(tests.mock_logger())
            ctx.enter_context(tests.mock_detached_tty())

# Generated at 2022-06-22 00:45:33.755366
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function.

    If this test won't pass - check your permissions to read/write in
    temporary directory.

    """
    with open('./log', 'w') as f:
        f.write('Test')
    try:
        shell_logger('./log')
        with open('./log', 'r') as f:
            assert f.read() == 'Test'
    finally:
        os.remove('./log')

# Generated at 2022-06-22 00:45:34.315204
# Unit test for function shell_logger
def test_shell_logger():
    pass



# Generated at 2022-06-22 00:45:39.604934
# Unit test for function shell_logger
def test_shell_logger():
    old_argv = sys.argv
    sys.argv = ['shell_logger', '/tmp/log.txt']
    shell_logger(sys.argv[1])
    sys.argv = old_argv


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:45:53.230117
# Unit test for function shell_logger
def test_shell_logger():
    f = open('test_shell_logger.log', 'wb')
    f.close()
    shell_logger('test_shell_logger.log')
    f = open('test_shell_logger.log', 'rb')
    f.seek(0, 2)
    assert(f.tell() > const.LOG_SIZE_IN_BYTES)
    f.close()
    os.remove('test_shell_logger.log')

# Generated at 2022-06-22 00:46:00.468870
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    tmpdir = tempfile.mkdtemp('shell_logger')
    log_file = os.path.join(tmpdir, 'log')

    shell_logger(log_file)

    buffer = mmap.mmap(os.open(log_file, os.O_RDONLY), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)
    buffer.seek(0)
    for line in buffer:
        if line == b'\x00':
            break
        else:
            print(line)



# Generated at 2022-06-22 00:46:08.821099
# Unit test for function shell_logger
def test_shell_logger():
    '''
    Tests if shell_logger works.

    '''
    # We don't expect any output, so we redirect stdout to /dev/null.
    # Note: sys.stdout is a wrapper around the real stdout, so all writes
    #  to sys.stdout actually go to the underlying file descriptor.
    #  With sys.stdout.flush() we flush all earlier data.
    sys.stdout.flush()
    original_stdout_fd = os.dup(1)
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, 1)
    os.close(devnull)

    # We also suppress stderr temporarily
    original_stderr_fd = os.dup(2)

# Generated at 2022-06-22 00:46:10.691864
# Unit test for function shell_logger
def test_shell_logger():
    f = open('tmp', 'w')
    shell_logger(f)

# Generated at 2022-06-22 00:46:19.107162
# Unit test for function shell_logger
def test_shell_logger():
    """Tests that the output file has been created in the current directory and is not
    empty.

    """
    output = 'output.log'
    shell_logger(output)
    assert os.path.isfile(output) and os.path.getsize(output) != 0

    with open(output, 'rb') as f:
        assert f.read(13) == b'Script started on'
        assert f.read() == b'\x00' * (const.LOG_SIZE_IN_BYTES - 13)

    os.remove(output)


if __name__ == '__main__':
    shell_logger('output.log')

# Generated at 2022-06-22 00:46:29.607211
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import mock

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.spawn = mock.patch.object(
                sys.modules[__name__], '_spawn', return_value=0).start()
            self.warn = mock.patch.object(
                sys.modules[__name__], 'logs',
                return_value=logs.warn("Shell logger doesn't support your platform.")).start()

        def tearDown(self):
            self.spawn.stop()
            self.warn.stop()

        def test_shell_logger_spawn(self):
            class FakeMmap(object):
                def __init__(self, *args, **kwargs):
                    pass

                def write(self, text):
                    self.text = text


# Generated at 2022-06-22 00:46:39.764119
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger()"""
    from unittest.mock import patch
    from . import fake_os, fake_sys
    from .test_utils_tty import fake_pty

    def test_spawn(shell, master_read):
        """Fake spawn."""
        return 0


# Generated at 2022-06-22 00:46:45.676364
# Unit test for function shell_logger
def test_shell_logger():

    # remove file after test
    test_file = 'test_shell_logger.log'
    if os.path.isfile(test_file):
        os.remove(test_file)

    # execute function
    shell_logger(test_file)

    # assert
    assert os.path.isfile(test_file)
    assert os.stat(test_file).st_size > 0

# Generated at 2022-06-22 00:46:47.206338
# Unit test for function shell_logger
def test_shell_logger():
    """
    Check shell_logger function
    :return: assertion
    """
    assert logs.INFO == "INFO"

# Generated at 2022-06-22 00:46:54.121543
# Unit test for function shell_logger
def test_shell_logger():
    """Tests shell_logger function.

    Sets SHELL environment variable to `cat`
    and runs shell_logger with `-f` flag
    and read data from the output file.

    """
    import shutil
    import tempfile

    if sys.platform == 'win32':
        print("Test doesn't support Windows platform.")
        sys.exit(0)

    shell = os.environ['SHELL']
    os.environ['SHELL'] = 'cat'
    output = tempfile.mkstemp()[1]
    try:
        shell_logger(output)
        with open(output) as f:
            data = f.read()
    finally:
        shutil.rmtree(os.path.dirname(output))
        os.environ['SHELL'] = shell
    assert not data

# Generated at 2022-06-22 00:47:02.986259
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:47:05.630026
# Unit test for function shell_logger
def test_shell_logger():
    """Tests for shell_logger function.

    All logs are stored in 1000 bytes buffer and rewrites from 100th byte.

    """
    # TODO: using subprocess with pty
    pass

# Generated at 2022-06-22 00:47:17.126782
# Unit test for function shell_logger
def test_shell_logger():
    _read.restype = ctypes.c_char_p
    _read.argtypes = [ctypes.py_object, ctypes.c_int]

    _spawn.restype = ctypes.c_int
    _spawn.argtypes = [ctypes.c_char_p, ctypes.CFUNCTYPE(ctypes.c_char_p, ctypes.c_int)]

    def _create_file(filename, size):
        f = open(filename, 'w')
        f.write('\x00' * size)
        f.close()

    def _destroy_file(filename):
        if os.path.isfile(filename):
            os.remove(filename)

    def _create_process():
        pipe = os.pipe()
        pid = os.fork()

# Generated at 2022-06-22 00:47:21.375699
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    import time, os

    def file_content(file):
        with open(file, 'rb') as f:
            return f.read()

    with open('.wrapper.log', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
    logs.file_meta['.wrapper.log'] = {'time': time.time()}
    logs.unit_tests = True

    try:
        shell_logger('.wrapper.log')
        assert False, 'Not exit on wrong shell environment'
    except SystemExit:
        assert True

    os.environ['SHELL'] = '/bin/bash'
    import subprocess
    subprocess.Popen('echo "test"', shell=True).wait()

# Generated at 2022-06-22 00:47:33.616790
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    from . import _utils_for_testing

    _utils_for_testing.modify_fixtures(
        'a' * (const.LOG_SIZE_IN_BYTES + 10),
        'b' * (const.LOG_SIZE_IN_BYTES + 10),
    )
    with open('/tmp/test_logs_shell.log', 'w') as f:
        f.write('')
    result = os.system('python3 -m logs shell /tmp/test_logs_shell.log')
    assert result == 0, 'result {} is not zero!'.format(result)
    with open('/tmp/test_logs_shell.log', 'r') as f:
        data1 = f.read()

# Generated at 2022-06-22 00:47:36.964558
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open("/tmp/util_test.log", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn("/bin/bash", partial(_read, buffer))

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:47:43.171485
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    fd = tempfile.NamedTemporaryFile(delete=False, prefix='shell-')
    try:
        shell_logger(fd.name)
    except SystemExit:
        pass
    else:
        raise AssertionError('test shell_logger(): the shell exists')
    os.unlink(fd.name)

# Generated at 2022-06-22 00:47:44.161270
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test.log')

# Generated at 2022-06-22 00:47:55.593055
# Unit test for function shell_logger
def test_shell_logger():
    from contextlib import contextmanager

    @contextmanager
    def env(**kwargs):
        original = os.environ.copy()
        os.environ.update(kwargs)
        yield
        os.environ.clear()
        os.environ.update(original)

    import io
    import subprocess
    import tempfile

    with env(SHELL='/bin/sh'):
        output = tempfile.NamedTemporaryFile()
        proc = subprocess.Popen(('python3', __file__, output.name),
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE)

        proc.stdin.write(b'echo "hello"\nexit\n')
        proc.stdin.flush()
        proc.wait()
