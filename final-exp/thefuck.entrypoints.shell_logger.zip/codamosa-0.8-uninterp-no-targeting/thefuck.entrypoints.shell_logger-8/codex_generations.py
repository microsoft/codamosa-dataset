

# Generated at 2022-06-22 00:37:56.335569
# Unit test for function shell_logger
def test_shell_logger():
    assert False


# Generated at 2022-06-22 00:38:06.172244
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import subprocess
    # Run shell logger with stdout and stderr redirected
    shell_logger_process = subprocess.Popen(['python3', '-m', 'phantompy.shell_logger'],
                                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # Wait for the shell logger to finish
    stdout, stderr = shell_logger_process.communicate()
    # Check if the return code of the shell logger is as expected
    print(stdout, stderr)
    assert shell_logger_process.returncode == 0

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:38:17.713241
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger function."""
    text_in = "Hello world!"
    text_out = "Hello world!\r\n"
    def _test_func():
        """Test function"""
        fd = os.open("/tmp/test.txt", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        _spawn("printf \"" + text_in + "\"", partial(_read, buffer))

    def _test():
        """Test function"""
        import subprocess
        subprocess.call

# Generated at 2022-06-22 00:38:18.344688
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:38:22.655709
# Unit test for function shell_logger
def test_shell_logger():
    from io import StringIO
    from contextlib import redirect_stdout
    from . import tests

    with tests.temp_file_name() as f, redirect_stdout(StringIO()) as buf:
        shell_logger(f)
        with open(f, 'r', encoding='utf-8') as out:
            assert 'Shell logger doesn\'t support your platform.' in buf.getvalue()


# Generated at 2022-06-22 00:38:24.486123
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger("/tmp/foo.log") == 0

# Generated at 2022-06-22 00:38:28.481735
# Unit test for function shell_logger
def test_shell_logger():
    # TODO(mkosiba): check if the logger works under travis-ci
    logs.init_logger()
    shell_logger('shell_logger_test.test')

# Generated at 2022-06-22 00:38:30.523508
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as fp:
        shell_logger(fp.name)

# Generated at 2022-06-22 00:38:39.555309
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import termios
    import tempfile
    import unittest

    if not os.environ.get('SHELL'):
        print("Shell logger doesn't support your platform.")
        sys.exit(1)

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.fd, self.path = tempfile.mkstemp(prefix='tmp_')

        def tearDown(self):
            os.close(self.fd)
            os.unlink(self.path)

        def test1(self):
            os.write(self.fd, b'\x00' * 1024)
            buffer = mmap.mmap(self.fd, 1024, mmap.MAP_SHARED, mmap.PROT_WRITE)
            return_code

# Generated at 2022-06-22 00:38:44.289466
# Unit test for function shell_logger
def test_shell_logger():
    from subprocess import Popen, PIPE
    import time

    try:
        Popen(['/bin/true'], stdout=PIPE)
    except OSError:
        return

    fd = os.open('shell_output.log', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)

    p = Popen(['/bin/true'], stdout=fd, stderr=fd)
    p.communicate()
    assert p.returncode == 0

    p = Popen(['/bin/false'], stdout=fd, stderr=fd)
    p.communicate()
    assert p.returncode == 1


# Generated at 2022-06-22 00:38:56.911534
# Unit test for function shell_logger
def test_shell_logger():
    from unittest.mock import patch
    from . import const
    from .shell_logger import shell_logger

    @patch('sys.exit')
    @patch('os.system')
    @patch('os.environ')
    def test(*args):
        os.environ['SHELL'] = '/bin/bash'
        sys.exit.return_code = 1
        os.system.return_code = 0
        shell_logger('/dev/null')
        sys.exit.assert_called_with(0)
        os.system.assert_called_with('script -f /dev/null')

    test()

# Generated at 2022-06-22 00:38:59.707608
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test class to test the shell_logger function."""
    consoleOutput = "Shell logger has been called."
    assert "Shell logger has been called."



# Generated at 2022-06-22 00:39:09.207554
# Unit test for function shell_logger
def test_shell_logger():
    dirname = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(dirname, 'logs', 'shell.log')
    try:
        process = subprocess.Popen(
            [sys.executable, __file__, 'shell_logger', log_file],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        process.communicate('echo logging & exit\n')
    except OSError as e:
        if e.errno == 2:
            return
    finally:
        try:
            process.kill()
        except AttributeError:
            pass


# Generated at 2022-06-22 00:39:13.096821
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/shell-logger-test.log'
    shell_logger(output)
    with open(output, 'r') as f:
        assert len(f.read()) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-22 00:39:18.183631
# Unit test for function shell_logger
def test_shell_logger():
    pass
    #import shutil
    #shutil.copy2(os.environ['SHELL'], "C:/Users/Test/Desktop/bash.exe")
    #os.environ['SHELL'] = "C:/Users/Test/Desktop/bash.exe"
    #shell_logger("C:/Users/Test/Desktop/output.txt")

# Generated at 2022-06-22 00:39:29.620374
# Unit test for function shell_logger
def test_shell_logger():
    from tempfile import NamedTemporaryFile
    from subprocess import Popen, PIPE, CalledProcessError
    assert shell_logger.__doc__ is not None
    assert len(shell_logger.__doc__) > 0
    with NamedTemporaryFile() as f:
        Popen([sys.executable, '-c', 'import shell; shell.shell_logger("%s")' % f.name], stdin=PIPE, stdout=PIPE, stderr=PIPE).communicate(b'`exit 1`')

# Generated at 2022-06-22 00:39:37.212108
# Unit test for function shell_logger
def test_shell_logger():
    import re
    import subprocess

    try:
        tty.setraw(sys.stdin.fileno())
        tty.setcbreak(sys.stdin.fileno())
    except tty.error:
        logs.warn("Test doesn't support your platform.")
        sys.exit(1)

    filename = '/tmp/pty_log_test'
    try:
        p = subprocess.Popen(['python3', '-m', 'deva._pty', '-o', filename])
        sys.stdout.write('\033[31m' + 'deva@localhost:~$ ' + '\033[0m')
        sys.stdout.flush()
    except OSError:
        logs.warn("Test doesn't support your platform.")
        sys.exit(1)


# Generated at 2022-06-22 00:39:43.317788
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    fd, output = tempfile.mkstemp()
    sys.argv = ['__main__', '-o', output]
    shell_logger(output)

# Generated at 2022-06-22 00:39:47.861893
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger function."""
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()
    try:
        shell_logger(tmpfile.name)
    except OSError:
        pass
    finally:
        os.remove(tmpfile.name)

# Generated at 2022-06-22 00:39:53.583197
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    # pwd change to test directory
    shell_logger('testoutput')
    # check exitcode
    assert subprocess.call(['./cli.py run unittest']) == 0
    # cleanup
    os.remove('testoutput')
    logs.info("Unit test for shell logger has passed.")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:03.896435
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: figure out if it is possible to write unit test.
    print('Shell logger test skipped.')
    sys.exit(0)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:09.708074
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import subprocess
    import filecmp
    import tempfile
    import random
    import string

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 00:40:10.256397
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:40:21.738371
# Unit test for function shell_logger
def test_shell_logger():
    """Test for shell_logger method.

    In this test we need a real shell.

    """
    fd, output = tempfile.mkstemp(suffix='.log')
    os.close(fd)

    def generator(input_lines):
        for line in input_lines:
            os.write(pty.STDOUT_FILENO, (line + '\n').encode())

    def checker(output, lines_to_check):
        with open(output) as f:
            for line in lines_to_check:
                assert line in f.read()

    input_lines = [
        '1 2 3 4',
        '3 4 5 6',
        '5 6 7 8',
        '7 8 9 0',
        '9 0 1 2',
    ]
    pid = os.fork()

# Generated at 2022-06-22 00:40:33.002169
# Unit test for function shell_logger
def test_shell_logger():
    import re
    import mock
    import io

    output = io.StringIO()

    with mock.patch.object(sys, 'exit') as mock_exit:
        with mock.patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
            with mock.patch('sys.stderr', new_callable=io.StringIO) as mock_stderr:
                shell_logger(output)

                mock_exit.assert_called_once_with(0)
                assert re.search(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \+0000\n$', output.getvalue())

# Generated at 2022-06-22 00:40:43.654004
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import pexpect
    import psi.process

    def _write(fd, data):
        os.write(fd, data.encode())

    def _write_all(fd, num=1, data='test\n'):
        for _ in range(num):
            _write(fd, data)

    def _read(fd, size):
        return os.read(fd, size).decode()

    fd = os.open(const.TMP_LOG, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-22 00:40:46.784774
# Unit test for function shell_logger
def test_shell_logger():
    with open('test.txt', 'w') as f:
        log_cpr = partial(shell_logger, f.name)
        log_cpr()

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:57.281066
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import unittest
    from multiprocessing import Process, Queue
    from shell_logger import shell_logger

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_command(self):
            log_file = os.path.join(self.temp_dir, 'output')
            p = Process(target=shell_logger, args=(log_file, ))
            p.start()
            p.join()
            with open(log_file) as f:
                output = f.read()
            self.assertTrue(output)

    unitt

# Generated at 2022-06-22 00:41:00.616410
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('./logs.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:04.053435
# Unit test for function shell_logger
def test_shell_logger():
    """Test function shell_logger."""
    logs.init()
    try:
        shell_logger('shell_logger.test')
    except NotImplementedError:
        pass
    finally:
        os.remove('shell_logger.test')
        logs.close()

# Generated at 2022-06-22 00:41:12.577814
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/dev/null') == 0


# Generated at 2022-06-22 00:41:18.790898
# Unit test for function shell_logger
def test_shell_logger():
    import docker
    import dockerpty
    client = docker.from_env()
    container = client.containers.run(
        'debian:jessie',
        tty=True,
        detach=True,
        stdin_open=True,
        volumes={'/opt/shell-logger': {'bind': '/host', 'mode': 'rw'}},
    )

    # Create new session and attach container to it
    dockerpty.exec_command(client, container.id, 'bash', stdin=True, stdout=True, stderr=True)

# Generated at 2022-06-22 00:41:26.352908
# Unit test for function shell_logger
def test_shell_logger():
    """ Shell logger should work in the most cases.
    """
    from . import runner
    output = os.path.abspath('shell_log_test.log')
    try:
        runner.run('shell_logger', {'output': output})
        with open(output, 'r') as f:
            assert f.readline().startswith('Welcome to')
    finally:
        os.remove(output)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:28.216648
# Unit test for function shell_logger
def test_shell_logger():
    # Create a test file
    assert shell_logger('test.txt') == 0

# Generated at 2022-06-22 00:41:35.104275
# Unit test for function shell_logger
def test_shell_logger():

    from ..helpers import process
    from os import remove
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    status = process.popen_stdout('../bin/shell_logger.py' + temp_dir + '/output')
    status(['ls', '-lh'])
    status(['ls', '-lh'])

    with open(temp_dir + '/output', 'r') as f:
        assert(f.read() != '')

    remove(temp_dir + '/output')
    shutil.rmtree(temp_dir)

# Generated at 2022-06-22 00:41:41.682982
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = 'bash'
    return_code = _spawn(os.environ['SHELL'], partial(_read, ''))
    sys.exit(return_code)
# Unit test end

if __name__ == '__main__':
    os.environ['SHELL'] = 'bash'
    return_code = _spawn(os.environ['SHELL'], partial(_read, ''))
    sys.exit(return_code)

# Generated at 2022-06-22 00:41:45.079693
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for the shell_logger function."""
    assert shell_logger("output") == "Success"
    #assert shell_logger("output") == "Failure"

# Generated at 2022-06-22 00:41:55.017966
# Unit test for function shell_logger
def test_shell_logger():
    import time
    # clear the log file
    fd = os.open("/tmp/log_file", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    os.close(fd)

    # start shell logger
    print("***** Start shell logger *****")
    return_code = _spawn("/bin/bash", partial(_read, "/tmp/log_file"))
    # time.sleep(1)
    print("***** End shell logger *****")
    # return_code = pty.spawn("/bin/bash", "/tmp/log_file")

    # test the output file
    f = open("/tmp/log_file", 'r')

# Generated at 2022-06-22 00:42:05.669871
# Unit test for function shell_logger
def test_shell_logger():
    import psutil
    import shutil
    import tempfile

    from .. import logs
    from .. import const

    logs.disable()
    tmp_dir = tempfile.mkdtemp()
    path = os.path.join(tmp_dir, 'test_log')

    pid = os.fork()
    if pid == 0:
        shell_logger(path)
    else:
        child = psutil.Process(pid)
        child.wait()
        with open(path) as f:
            assert f.read(const.LOG_SIZE_IN_BYTES) == '\x00' * const.LOG_SIZE_IN_BYTES
    assert os.path.exists(path)
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-22 00:42:07.030334
# Unit test for function shell_logger
def test_shell_logger():
    # uncomment to run test
    # shell_logger('/tmp/output.log')

    pass

# Generated at 2022-06-22 00:42:17.588359
# Unit test for function shell_logger
def test_shell_logger():
    """
    >>> shell_logger('shell_logger.test')
    """

if __name__ == '__main__': # pragma: no cover
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 00:42:22.102786
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    with tempfile.NamedTemporaryFile() as output:
        with tempfile.NamedTemporaryFile(mode='r') as f:
            shell_logger(output.name)
            f.write(output.read())
        logs.info(f.name)

# Generated at 2022-06-22 00:42:26.783923
# Unit test for function shell_logger
def test_shell_logger():
    output = 'log_test'

    if os.path.exists(output):
        os.remove(output)

    shell_logger(output)

    assert os.path.exists(output)

    with open(output, 'r') as f:
        lines = f.readlines()
        assert lines

    logs.info('Test OK')

# Generated at 2022-06-22 00:42:28.121038
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('output')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:42:37.895417
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile

    def cleanup(dir):
        if os.path.exists(dir):
            shutil.rmtree(dir)

    with tempfile.NamedTemporaryFile() as original:
        original.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
        original.flush()
        dir = tempfile.mkdtemp()

        def wrap():
            shell_logger(os.path.join(dir, 'output'))

        wrap.__name__ = 'wrap'

        shutil.copy(original.name, os.path.join(dir, 'original_output'))
        try:
            wrap()
        except SystemExit:
            pass
        finally:
            cleanup(dir)


# Generated at 2022-06-22 00:42:43.202793
# Unit test for function shell_logger
def test_shell_logger():
    f = open("/tmp/shell_logger.txt", "w")
    f.write("Test shell_logger")
    f.close()
    shell_logger("/tmp/shell_logger.txt")

if __name__ == "__main__":
    # test_shell_logger()
    shell_logger("/tmp/shell_logger.txt")

# Generated at 2022-06-22 00:42:49.702694
# Unit test for function shell_logger
def test_shell_logger():
    import os
    from .. import logs
    from .. import const
    from . import helpers

    logs.DEBUG = True

    # It works like unix script command with `-f` flag
    with helpers.tmp_dir() as tmp_dir:
        path = os.path.join(tmp_dir, 'test.log')
        shell_logger(path)
        assert os.path.getsize(path) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-22 00:42:55.672387
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = 'unix/test/shell-mock.sh'
    shell_logger('unix/test/output.txt')
    assert os.path.exists('unix/test/output.txt')
    assert os.path.getsize('unix/test/output.txt') == (3 + const.LOG_SIZE_TO_CLEAN)

# Generated at 2022-06-22 00:42:58.165459
# Unit test for function shell_logger
def test_shell_logger():
    # This is just a helper function, shell_logger can't really be tested
    pass

# Generated at 2022-06-22 00:43:01.793796
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    # TODO: create a better unit test for this function
    # (create a temporary file and run the script)
    shell_logger('/tmp/shell-log-output.txt')

# Generated at 2022-06-22 00:43:16.746204
# Unit test for function shell_logger
def test_shell_logger():
    with open(os.devnull, "w") as dev_null:
        sys.stdout = dev_null
        sys.stderr = dev_null
        shell_logger("test.log")
    #Test whether the first time stamp is recorded.
    with open("test.log", 'rb') as test_log:
        #The first line of the log file should have a time stamp.
        assert test_log.readline()[1] == ord('['), "First line has time stamp."


# Generated at 2022-06-22 00:43:23.004744
# Unit test for function shell_logger
def test_shell_logger():
    if not os.path.exists(const.LOG_PATH):
        os.mkdir(const.LOG_PATH)
    for i in range(const.LOG_SIZE_IN_BYTES):
        f = open(const.LOG_PATH + "test_log.txt", 'w')
        f.write("test_log: " + i * "c")
        f.close()


# Generated at 2022-06-22 00:43:23.540512
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:43:25.312900
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("~/shell_logger.out")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:43:30.503946
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/shell_logger_test'
    try:
        shell_logger(output)
    except SystemExit:
        pass
    assert os.path.exists(output) and os.path.getsize(output) == const.LOG_SIZE_IN_BYTES
    os.remove(output)

# Generated at 2022-06-22 00:43:31.925400
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: write a unit test
    pass

# Generated at 2022-06-22 00:43:42.572890
# Unit test for function shell_logger
def test_shell_logger():
    import os

    script_path = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(script_path, 'log.txt')

    def check_file_size(size):
        assert os.path.getsize(file_path) == size, \
            "File has wrong size: {} bytes, but should have {}".format(
                os.path.getsize(file_path), size)

    if os.path.exists(file_path):
        os.remove(file_path)

    shell_logger(file_path)
    check_file_size(const.LOG_SIZE_IN_BYTES)

    os.remove(file_path)

# Generated at 2022-06-22 00:43:45.300780
# Unit test for function shell_logger
def test_shell_logger():
    with TemporaryDirectory() as tdir:
        output = os.path.join(tdir, 'out.tmp')
        shell_logger(output)
        assert os.path.exists(output)



# Generated at 2022-06-22 00:43:56.044401
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import os
    tmp_path = os.path.join('/tmp', 'tmux_man_tests')
    tmp_file_path = os.path.join('/tmp', 'tmux_man_tests', 'tmp_file.txt')
    os.makedirs(tmp_path)
    try:
        shell_logger(tmp_file_path)
    except SystemExit as e:
        import re
        with open(tmp_file_path) as f:
            content = f.read()
        # $SHELL is exported to the subprocess with os.environ
        assert re.match(".*\$SHELL.*", content)
        assert int(e.code) == 0
    finally:
        shutil.rmtree(tmp_path)



# Generated at 2022-06-22 00:44:04.573352
# Unit test for function shell_logger
def test_shell_logger():
    """ Unit test for function shell_logger. """
    import pytest
    from .. import const
    from . import test_logs

    session = test_logs.open_session()
    shell_logger(session.get_file_name())

    assert os.path.getsize(session.get_file_name()) == const.LOG_SIZE_IN_BYTES
    assert session.read() == session.get_file_name()

    session.close()

# Generated at 2022-06-22 00:44:23.161102
# Unit test for function shell_logger
def test_shell_logger():
    from multiprocessing import Process
    from threading import Thread

    from . import test_logs
    from . import test_files

    def create_and_write_files(files):
        for filename, size in files.items():
            with open(filename, 'w') as file:
                file.write('*' * size)
        test_logs.write_logs()

    def test_shell_logger_process(cmd):
        os.system(cmd)

    def test_shell_logger_thread(cmd):
        from subprocess import Popen, call, PIPE

        Popen('while true; do {}; done'.format(cmd), stdin=PIPE, shell=True).communicate()


# Generated at 2022-06-22 00:44:27.224575
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    assert subprocess.call("test_shell_logger.py") == 0
    time.sleep(2)

if __name__ == "__main__":
    shell_logger("test.log")

# Generated at 2022-06-22 00:44:30.468188
# Unit test for function shell_logger
def test_shell_logger():

    file_name = '/tmp/test_shell_logger'
    shell_logger(file_name)

    if os.path.isfile(file_name):
        os.remove(file_name)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:44:31.887669
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell_logger')

# Generated at 2022-06-22 00:44:42.847922
# Unit test for function shell_logger
def test_shell_logger():
    def test_input(data):
        for ch in data.decode(encoding="utf-8"):
            os.write(pty.STDOUT_FILENO, (ch.encode()))
        os.close(pty.STDOUT_FILENO)

    # Must be run as a separate process to isolate the stdin and stdout
    # from the parent process.

# Generated at 2022-06-22 00:44:49.769291
# Unit test for function shell_logger
def test_shell_logger():
    from io import StringIO
    from . import logs
    stdin = sys.stdin

    def test(output=''):
        sys.stdin = StringIO('test')
        ret = shell_logger(output)
        with open(output, 'r') as f:
            output = f.read()
        return ret, output

    try:
        # Smoke test, too lazy to check if works on non-unix platforms
        assert test()
        # Test with actual output
        assert test('test_shell_logger')
    finally:
        sys.stdin = stdin

# Generated at 2022-06-22 00:45:00.083959
# Unit test for function shell_logger
def test_shell_logger():
    # The test should be run from the root of the project
    from .. import logs
    from .. import const

    import array
    import os
    import pty
    import signal
    import termios
    import tty

    import cStringIO

    def _read(f, fd):
        data = os.read(fd, 1024)
        f.write(data)
        return data

    def _set_pty_size(master_fd):
        buf = array.array('h', [0, 0, 0, 0])
        fcntl.ioctl(pty.STDOUT_FILENO, termios.TIOCGWINSZ, buf, True)
        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, buf)


# Generated at 2022-06-22 00:45:02.591203
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('./test_shell_logger_file') == 0


if __name__ == '__main__':
    shell_logger('/tmp/output')

# Generated at 2022-06-22 00:45:13.411594
# Unit test for function shell_logger
def test_shell_logger():
    import sys
    import os
    import subprocess
    import logging
    import tempfile
    import mmap
    import shutil
    import collections

    if sys.platform.startswith('win'):
        os.environ['SHELL'] = 'powershell'
    elif sys.platform.startswith('darwin'):
        os.environ['SHELL'] = '/bin/sh'
    else:
        os.environ['SHELL'] = '/usr/bin/sh'


    def read_file(path):
        with open(path) as f:
            return f.read()

    temp_dir = tempfile.TemporaryDirectory(prefix='fzf-history_test_')
    shell_log_file = os.path.join(temp_dir.name, 'shell_log')


# Generated at 2022-06-22 00:45:24.267317
# Unit test for function shell_logger
def test_shell_logger():
    """Unit tests for shell_logger

    Creates a temp file for output and a temp directory for the shell
    environment variable. Calls shell_logger with the temp file and checks
    that the file has been generated. When the test finishes, it removes the
    file and the directory

    """
    import tempfile
    fd, output_path = tempfile.mkstemp()
    temp_dir = tempfile.mkdtemp()
    os.environ['SHELL'] = os.path.join(temp_dir, 'shell_test')
    open(os.environ['SHELL'], 'a').close()
    try:
        shell_logger(output_path)
        assert os.path.isfile(output_path)
    except TypeError:
        assert False
    finally:
        os.remove(output_path)


# Generated at 2022-06-22 00:45:36.168258
# Unit test for function shell_logger
def test_shell_logger():
    """
    Unit test for function shell_logger.
    """
    logs.shell_logger = shell_logger
    logs.shell_logger('test.log')

# Generated at 2022-06-22 00:45:41.298590
# Unit test for function shell_logger
def test_shell_logger():
    filename = 'test_shell_logger.txt'
    if os.path.exists(filename): os.remove(filename)
    shell_logger(filename)
    with open(filename) as f:
        for line in f:
            assert(line)
    os.remove(filename)

# vim: set ts=4 sts=4 sw=4 et:

# Generated at 2022-06-22 00:45:42.503498
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/shell_logger')

# Generated at 2022-06-22 00:45:53.094408
# Unit test for function shell_logger
def test_shell_logger():

    def dummy_logs(param, str):
        return param+str

    def dummy_sys_exit(returncode):
        return returncode

    import sys
    import os
    import tempfile
    import io
    import unittest
    import unittest.mock as mock

    sys.modules['os.environ'] = {'SHELL': 'bin/bash'}
    sys.modules['os'] = lambda: os
    sys.modules['pty'] = lambda: pty
    sys.modules['pty.fork'] = lambda: os.fork()
    sys.modules['pty._copy'] = lambda *_, **__: True
    sys.modules['pty.CHILD'] = lambda: os.getpid()
    sys.modules['pty._read'] = lambda *_, **__: True

# Generated at 2022-06-22 00:46:02.578358
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    output = tempfile.NamedTemporaryFile().name
    buf = mmap.mmap(os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    buf.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
    buf.flush()
    # gives time to finish writing the file
    time.sleep(1)
    p = subprocess.Popen(["python", "./evsh/shell.py", "--log", output])
    time.sleep(1)
    p.kill()

    # Try to open a file, created by the command

# Generated at 2022-06-22 00:46:05.659452
# Unit test for function shell_logger
def test_shell_logger():
    tmp_file = 'tmp_file.log'
    os.environ['SHELL'] = '/bin/sh'
    try:
        shell_logger(tmp_file)
    finally:
        os.unlink(tmp_file)

# Generated at 2022-06-22 00:46:11.445963
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    try:
        shell_logger('/tmp/out.file')
    except SystemExit:
        pass
    with open('/tmp/out.file', 'rb') as f:
        buffer = mmap.mmap(f.fileno(), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_READ)
        assert buffer.find(b'\x00') < 0, 'Log file isn\'t filled.'
    shutil.rmtree('/tmp/out.file')

# Generated at 2022-06-22 00:46:14.360560
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger(const.LOG_FILE) == 0


if __name__ == "__main__":
    shell_logger(const.LOG_FILE)

# Generated at 2022-06-22 00:46:22.890497
# Unit test for function shell_logger
def test_shell_logger():
    def check_output(output):
        """Check output size."""
        if os.path.getsize(output) == 0:
            raise Exception("Output is empty.")

    if os.fork() == 0:
        shell_logger("/tmp/test_shell_logger.log")

    # Wait a little bit to make sure the child is running
    # The child process closes after the user exits the shell
    time.sleep(1)

    check_output("/tmp/test_shell_logger.log")

    os.remove("/tmp/test_shell_logger.log")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:46:31.503290
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open("/tmp/output.txt", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

    sys.exit(return_code)

# Generated at 2022-06-22 00:46:39.844209
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:46:45.397445
# Unit test for function shell_logger
def test_shell_logger():
    from . import test_utils
    from . import test_utils as tu
    assert tu.exists(test_utils.FILENAME)
    assert tu.contains(test_utils.FILENAME, 'Some text')
    assert tu.contains(test_utils.FILENAME, 'Some lines\n')
    shell_logger(test_utils.FILENAME)

# Generated at 2022-06-22 00:46:50.697186
# Unit test for function shell_logger
def test_shell_logger():
    with open(const.TEST_LOGS_FILE, 'w') as output:
        output.write('0' * 1024)

    shell_logger(const.TEST_LOGS_FILE)

    with open(const.TEST_LOGS_FILE, 'r') as output:
        result = output.read()
        assert result.startswith('\x00' * 1024)
        assert len(result) == const.LOG_SIZE_IN_BYTES
        assert result[-1] != '\x00'

# Generated at 2022-06-22 00:47:02.582981
# Unit test for function shell_logger
def test_shell_logger():
    from .. import logs
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    out = StringIO()
    fp = StringIO()
    logs.init(verbose=True, stdout=out)

    def mock_spawn(shell, master_read):
        return 0

    sys.argv.append('shell_logger')
    with patch('fly.pty',) as pty:
        pty.fork.return_value = 0
        with patch('fly.os',) as os_:
            os_.environ.get.return_value = 'shell'
            with patch('fly.logs.warn') as warn:
                with patch('fly.os.open',) as mock_open:
                    mock_open.return_value = fp.fileno()

# Generated at 2022-06-22 00:47:14.016703
# Unit test for function shell_logger
def test_shell_logger():
    # If SHELL is not specified or it's not supported, shell_logger exits with 1
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)

    # Test if function creates empty file with specified size
    master_fd, slave_fd = pty.openpty()
    fd = os.open('test_log.txt', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    assert buffer.read()

# Generated at 2022-06-22 00:47:20.172872
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for shell_logger function.

    Runs bash inside a pty.spawn() and check if it returns correct return code.

    """
    from ..utils import tmpfile
    from .env import override_env
    from .autodiscover import autodiscover

    autodiscover()

    output = tmpfile()
    with override_env(SHELL=which('bash')):
        rc = shell_logger(output)
        assert rc == 0, "rc = {}".format(rc)

# Generated at 2022-06-22 00:47:32.621257
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import signal
    import subprocess
    import time

    def read_log_output():
        with open('log.txt') as file:
            return file.read()

    def write_log_output(text):
        with open('log.txt', 'a') as file:
            file.write(text)

    child_pid = os.fork()
    if child_pid == 0:
        # child process
        #os.system('touch log.txt')
        write_log_output('init')
        os.environ['SHELL'] = 'sh'
        shell_logger('log.txt')
    else:
        # parent process
        time.sleep(1)
        #os.kill(child_pid, signal.SIGTERM)
        while True:
            write_log_output('parent')

# Generated at 2022-06-22 00:47:41.397907
# Unit test for function shell_logger
def test_shell_logger():
    # Prepare a mock environment
    import os as _os
    import sys as _sys
    import types as _types
    import warnings as _warnings
    import __main__ as _main
    _sys.argv[1] = 'test'
    _sys.stderr = _main.stderr = _sys.stdout = _main.stdout = _os.devnull
    _main.__name__ = '__main__'
    _main.__file__ = _os.path.join(_os.getcwd(), 'test.py')
    _warnings.warn = lambda msg, category, stacklevel: None
    module = _types.ModuleType(_main.__name__)
    module.__package__ = None
    module.__file__ = _os.devnull
    module.__name__ = _main.__

# Generated at 2022-06-22 00:47:53.261600
# Unit test for function shell_logger
def test_shell_logger():
    from testfixtures import LogCapture
    from io import BytesIO

    log_capture = LogCapture()

    output = BytesIO()
    shell_logger(output)
    output.seek(0)