

# Generated at 2022-06-22 00:38:08.201807
# Unit test for function shell_logger
def test_shell_logger():
    assert os.path.exists('test.log')
    assert os.path.getsize('test.log') == const.LOG_SIZE_IN_BYTES


# Generated at 2022-06-22 00:38:09.264360
# Unit test for function shell_logger
def test_shell_logger():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 00:38:16.297438
# Unit test for function shell_logger
def test_shell_logger():
    import os
    from . import utils

    def test_output(output):
        assert os.stat(output).st_size == const.LOG_SIZE_IN_BYTES
        assert b'\x00' * const.LOG_SIZE_IN_BYTES == open(output, 'rb').read()

    utils.run_as_main(__name__, shell_logger, test_output)

# Generated at 2022-06-22 00:38:20.709275
# Unit test for function shell_logger
def test_shell_logger():
    fn = "shell_logger.test"
    try:
        os.remove(fn)
    except:
        pass

    shell_logger(fn)

    assert os.path.isfile(fn)
    assert os.path.getsize(fn) == const.LOG_SIZE_IN_BYTES
    os.remove(fn)

# Generated at 2022-06-22 00:38:22.491271
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/pty_logger')

# Generated at 2022-06-22 00:38:26.601049
# Unit test for function shell_logger
def test_shell_logger():
    return_code = shell_logger('/tmp/test_shell_logger')
    assert return_code == 0
    with open('/tmp/test_shell_logger', 'r') as f:
        assert f.read()

# Generated at 2022-06-22 00:38:35.873270
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import unittest
    from ..shell import shell_logger

    class TestShellLogger(unittest.TestCase):
        def test_logger(self):
            with tempfile.NamedTemporaryFile(mode='w+b', delete=False) as f:
                shell_logger(f.name)

            with open(f.name, 'rb') as f:
                data = f.read(1024)

            self.assertEqual(data[:11], b'\x00' * 11)
            self.assertTrue(data[11:].replace(b'\x00', b''))

    unittest.main()

# Generated at 2022-06-22 00:39:06.402178
# Unit test for function shell_logger

# Generated at 2022-06-22 00:39:07.210472
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:39:07.759146
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:39:23.712075
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time
    import shutil
    import tempfile
    import unittest
    import os


# Generated at 2022-06-22 00:39:27.695227
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(const.TEST_OUTPUT)
    assert open(const.TEST_OUTPUT).read().startswith('shell-logger')
    os.remove(const.TEST_OUTPUT)

# Generated at 2022-06-22 00:39:36.486427
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import re
    import subprocess
    import time
    import unittest
    import platform

    class ShellLoggerTestCase(unittest.TestCase):
        def setUp(self):
            self.output = 'test.log'
            self.test_command = 'echo "$(date)"'
            self.test_output = 'test'

        def test_shell_logger(self):
            with open(self.output, 'w') as f:
                f.write('\x00'*const.LOG_SIZE_IN_BYTES)
            time.sleep(1)
            proc = subprocess.Popen(['python', '-m', 'logs.shell_logger', self.output], shell=False)
            time.sleep(1)

# Generated at 2022-06-22 00:39:50.129246
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import os
    import shutil
    import tempfile
    import unittest

    import ioctl_opt

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.file_name = tempfile.mktemp()
            self.directory = tempfile.mkdtemp()

        def tearDown(self):
            os.remove(self.file_name)
            shutil.rmtree(self.directory)

        def test_empty_file(self):
            shell_logger(self.file_name)
            self.assertEqual(os.path.getsize(self.file_name),
                             const.LOG_SIZE_IN_BYTES)


# Generated at 2022-06-22 00:39:53.158561
# Unit test for function shell_logger
def test_shell_logger():
    with open('./shell_output_test.txt', 'wb') as output:
        shell_logger(output)

# Generated at 2022-06-22 00:39:55.159772
# Unit test for function shell_logger
def test_shell_logger():
    logger = shell_logger('/tmp/shell_logger.out')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:03.647041
# Unit test for function shell_logger
def test_shell_logger():
    sys._argv = sys.argv
    sys.argv = [sys.argv[0], const.LOG_OUTPUT_FILE]
    try:
        return_code = shell_logger(sys.argv[1])
        file_size = os.path.getsize(const.LOG_OUTPUT_FILE)
        assert return_code == 0
        assert file_size == const.LOG_SIZE_IN_BYTES
    finally:
        sys.argv = sys._argv

# Generated at 2022-06-22 00:40:09.569185
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import random
    import shutil
    import socket
    import string
    import tempfile
    from contextlib import contextmanager

    # If you change this value, remember to change LOG_SIZE_IN_BYTES in const.py
    TEST_FILE_SIZE = 4096

    @contextmanager
    def tcp_server(address):
        s = socket.socket()
        s.bind(address)
        s.listen(1)
        yield s
        s.close()

    @contextmanager
    def temp_file(size=TEST_FILE_SIZE):
        fd, path = tempfile.mkstemp()
        os.write(fd, b'\x00' * size)
        os.close(fd)
        yield path
        os.remove(path)


# Generated at 2022-06-22 00:40:21.133778
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger func.
    """
    import os
    import tempfile
    import subprocess

    with tempfile.TemporaryDirectory() as tmpdirname:
        tmp_log_path = tmpdirname + '/log.txt'

        # Run shell logger and exit with code 0
        subprocess.run(['python3', '-c', 'import ptylogger; ptylogger.shell_logger("' + tmp_log_path + '")'])

        # Check if log is not empty
        assert os.path.getsize(tmp_log_path) != 0

        # Run shell logger and exit with some code

# Generated at 2022-06-22 00:40:32.268694
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import StringIO
    import tempfile
    import io

    # open a temp file, and write other file contents to it
    f, temp_path = tempfile.mkstemp()
    os.write(f, b"hello")
    os.close(f)

    # Add a bash command to write to the original temp file
    # The bash command is automatically executed whenever a shell is started
    shell_cmd = """
    echo hi >> {}
    """.format(temp_path)

    # start the shell logger
    # note the output is just a throwaway StringIO object
    s = StringIO.StringIO()
    shell_logger(s)

    # Read the temporary file and convert the read text into a string
    with io.open(temp_path, "r") as f:
        text = f.read()

# Generated at 2022-06-22 00:40:39.650968
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    temp = tempfile.NamedTemporaryFile()
    shell_logger(temp.name)

# Generated at 2022-06-22 00:40:47.301939
# Unit test for function shell_logger
def test_shell_logger():
    import time
    data = b'qwerty'  # prompt will not be logged
    path = 'a_tmp.log'
    pid = os.fork()
    if pid == 0:
        shell_logger(path)
    else:
        # time.sleep(0.5)
        os.write(sys.stdout.fileno(), data)
        os.system('exit')
        assert open(path).read() == data.decode()
        os.remove(path)
        os.kill(pid, signal.SIGTERM)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:51.343818
# Unit test for function shell_logger
def test_shell_logger():
    try:
        fd = open('tmp', 'w')
        fd.close()
        assert(shell_logger('tmp') == 0)
    finally:
        os.remove('tmp')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:02.890278
# Unit test for function shell_logger
def test_shell_logger():
    import time
    def test(output="/tmp/shell_logger.log", data="Hello", delay=5):
        buffer = mmap.mmap(os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR), const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        def _read(f):
            data = os.read(0, 1024)
            try:
                f.write(data)
            except ValueError as e:
                print(e)
            return data

        pid, master_fd = pty.fork()
        if pid == pty.CHILD:
            os.execlp('/bin/bash', '/bin/bash', '-c', data)
        os.waitpid

# Generated at 2022-06-22 00:41:03.956803
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test_shell_logger.txt')

# Generated at 2022-06-22 00:41:08.596280
# Unit test for function shell_logger
def test_shell_logger():
    sys.argv = ['yam']
    shell_logger('./tmp.log')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:14.956907
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger.

    Function doesn't have a meaningful return value, so unit-tests
    only check that an exception wasn't raised.

    """
    shell_logger('tests/data/output_shell_logger.txt')
    shell_logger(sys.stdout)
    shell_logger(sys.stderr)
    shell_logger(sys.stdin)


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:20.096901
# Unit test for function shell_logger
def test_shell_logger():
    filename = 'shell_logger_test_file'
    os.system('rm -f {}'.format(filename))
    os.system('touch {}'.format(filename))
    os.system('echo "hello_world" > {}'.format(filename))
    f = open(filename, 'rb')
    shell_logger(filename)
    f.seek(0)
    assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES
    os.system('rm -f {}'.format(filename))

# Generated at 2022-06-22 00:41:27.808884
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open('test_shell_logger', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * 1024)
    buffer = mmap.mmap(fd, 1024, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn('/bin/bash', partial(_read, buffer))



# Generated at 2022-06-22 00:41:36.614916
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    from .. import const
    from . import test_helpers
    from .test_helpers import TestCli

    def _test(lines, limit):
        output = test_helpers.TEST_FOLDER + 'shell-log.txt'
        with TestCli(['shell-logger', '--output', output]) as test:
            test.stdin.write(b'\n'.join(lines) + b'\n')
            test.stdin.close()

        with open(output) as f:
            assert f.readlines()[-limit:] == list(lines) + ['\n']
        os.remove(output)


# Generated at 2022-06-22 00:41:53.519935
# Unit test for function shell_logger
def test_shell_logger():
    # Write output of a shell to a file
    filename = "test-log.txt"
    shell_logger(filename)

    # Open the log file and read its content
    f = open(filename, 'rb')
    f.seek(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN)
    last_bytes = f.read(const.LOG_SIZE_TO_CLEAN)
    f.close()

    # Clean file and folder
    os.remove(filename)

    # Check if log file contains exactly what it should
    assert len(last_bytes) == const.LOG_SIZE_TO_CLEAN

# Generated at 2022-06-22 00:42:02.203362
# Unit test for function shell_logger
def test_shell_logger():
    # Use tempfile.mkstemp() instead of tempfile.NamedTemporaryFile()
    # because the latter creates a file with mode 0o600.
    with tempfile.TemporaryDirectory() as subdir:
        path = os.path.join(subdir, 'tempfile')
        shell_logger(path)
        assert os.path.exists(path)
        assert os.path.isfile(path)
        assert os.path.getsize(path) == const.LOG_SIZE_IN_BYTES # file size
        # print('\n')
        # print(path)
        # with open(path) as f:
        #     print(f.read())

# Generated at 2022-06-22 00:42:12.351974
# Unit test for function shell_logger
def test_shell_logger():
    """Test function `shell_logger`."""
    import random
    import string
    import os
    import sys

    # Test shell_logger with empty stdin:
    fd, tmp_file = tempfile.mkstemp()

# Generated at 2022-06-22 00:42:14.047001
# Unit test for function shell_logger
def test_shell_logger():
    import pytest
    with pytest.raises(SystemExit):
        shell_logger('shell_logger')

# Generated at 2022-06-22 00:42:22.228515
# Unit test for function shell_logger
def test_shell_logger():
    # clean up
    import os
    import shutil
    import tempfile
    def cleanup():
        shutil.rmtree(temp_dir)
    # temp_dir is created
    temp_dir = tempfile.mkdtemp()
    # create test dummy file
    temp_path = os.path.join(temp_dir, 'test.txt')
    with open(temp_path, 'w') as f:
        f.write('This is a test\n')
    # test
    shell_logger(temp_path)
    # clean up
    cleanup()

# Generated at 2022-06-22 00:42:23.933316
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("test_shell_logger.log")

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:42:25.738295
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('foo')

# Generated at 2022-06-22 00:42:27.333261
# Unit test for function shell_logger
def test_shell_logger():
    args = [ 'cmd', '-v', 'cmd' ]
    shell_logger('shell.log')

# Generated at 2022-06-22 00:42:36.923537
# Unit test for function shell_logger
def test_shell_logger():
    import pytest
    from mock import call
    from .. import logs
    from .. import exceptions
    import os

    def _write(out, lines=1):
        for _ in range(lines):
            out.write(b'\x00' * 1024)

    def _check(output, lines=1):
        with open(output) as f:
            for _ in range(lines):
                assert f.read(const.LOG_SIZE_IN_BYTES) == b'\x00' * const.LOG_SIZE_IN_BYTES

    @pytest.fixture(scope='function')
    def output(tmpdir):
        return str(tmpdir.join('shell.log'))


# Generated at 2022-06-22 00:42:48.309439
# Unit test for function shell_logger
def test_shell_logger():
    """Command line test for shell_logger function."""
    from .context import cwd

    cwd.set_cwd_to_tmp()


# Generated at 2022-06-22 00:42:59.119334
# Unit test for function shell_logger
def test_shell_logger():
    """
    Simple unit test for shell_logger function.
    """
    os.environ['SHELL'] = 'echo'
    f = tempfile.NamedTemporaryFile()
    shell_logger(f.name)

# Generated at 2022-06-22 00:43:10.369817
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test function shell_logger can correctly log the shell output
    """
    import os
    import pty
    import time
    import tempfile
    import subprocess
    import platform
    import shutil

    # Test only works on non windows system
    if platform.system() == 'Windows':
        return

    (tmp_file, tmp_file_path) = tempfile.mkstemp()
    os.close(tmp_file)

    pid, master_fd = pty.fork()
    if pid == pty.CHILD:
        try:
            os.remove(tmp_file_path)
            # subprocess of shell_logger
            shell_logger(tmp_file_path)
        finally:
            os.close(master_fd)

# Generated at 2022-06-22 00:43:12.387103
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)

# Generated at 2022-06-22 00:43:16.405997
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test.txt'
    assert shell_logger(output) == 0
    with open(output, 'r') as f:
        content = f.read()
        assert content == '\x00' * const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-22 00:43:27.801527
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    from . import logs

    logs.COLOR = False

    TEMP_DIR = tempfile.mkdtemp()
    OUTPUT = os.path.join(TEMP_DIR, 'test.log')

    shell_logger(OUTPUT)

    dir_list = os.listdir(TEMP_DIR)
    assert dir_list == ['test.log']

    try:
        os.unlink(OUTPUT)
    except FileNotFoundError:
        pass

    shutil.rmtree(TEMP_DIR)
    assert not os.path.exists(TEMP_DIR)

if __name__ == '__main__':
    import sys

    test_shell_logger()

    sys.exit(0)

# Generated at 2022-06-22 00:43:35.789996
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        proc = subprocess.run((sys.executable, '-m', __package__, 'shell_logger', tmp + '/output'), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.stdin.write(b"echo 'hello world!'\n")
        proc.stdin.close()
        proc.wait()

        assert os.path.isfile(tmp + '/output')
        with open(tmp + '/output') as f:
            assert f.read().strip() == 'hello world!'



# Generated at 2022-06-22 00:43:45.831288
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import os
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as log_dir:

        log_path = os.path.join(log_dir, 'log.txt')
        log_size = os.path.getsize(log_path)

        subprocess.Popen(['python', '-m', 'harold.scripts.shell_logger', log_path]).communicate()

        assert os.path.getsize(log_path) > log_size
        shutil.rmtree(log_dir)


if __name__ == "__main__":
    from ..scripts import utils
    utils.bootstrap()
    shell_logger(*sys.argv[1:])

# Generated at 2022-06-22 00:43:50.037793
# Unit test for function shell_logger
def test_shell_logger():
    sys.argv = ['shell_logger']
    shell_logger('/tmp/test.shell_logger')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:44:00.833995
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/shell_logger.test'
    fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)

    pid, master_fd = pty.fork()

    if pid == pty.CHILD:
        os.write(master_fd, b'test')


# Generated at 2022-06-22 00:44:02.049834
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/hulk.log')

# Generated at 2022-06-22 00:44:10.948046
# Unit test for function shell_logger
def test_shell_logger():
    sys.stdout.write(shell_logger.__doc__)

# Generated at 2022-06-22 00:44:17.242178
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess

    temp = tempfile.NamedTemporaryFile()
    shell_logger(output=temp.name)
    temp.seek(0)
    content = temp.read()
    assert content == b'\x00' * const.LOG_SIZE_IN_BYTES
    output = subprocess.check_output(['bash', '-c', 'echo foo;exit 1'])
    assert output in content

# Generated at 2022-06-22 00:44:17.742858
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:44:28.041614
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger"""
    # Test for SHELL environment variable
    assert os.environ.get('SHELL') is not None

    # Test for O_CREAT | O_TRUNC | O_RDWR
    with tempfile.NamedTemporaryFile() as test_file:
        shell_logger(test_file.name)
        assert os.path.isfile(test_file.name)
        assert os.path.getsize(test_file.name) == const.LOG_SIZE_IN_BYTES

    # Test for O_CREAT
    with tempfile.NamedTemporaryFile() as test_file:
        os.remove(test_file.name)
        shell_logger(test_file.name)
        assert os.path.isfile(test_file.name)
       

# Generated at 2022-06-22 00:44:32.525003
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as f:
        filename = f.name
        j = multiprocessing.Process(target=shell_logger, args=(filename,))
        j.daemon = True
        j.start()
        time.sleep(2)
        j.terminate()
        j.join()
        with open(filename, 'r') as f:
            assert f.read() == ''

# Generated at 2022-06-22 00:44:33.025549
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:44:39.419018
# Unit test for function shell_logger
def test_shell_logger():
    """
    test_shell_logger()
    """
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_shell_logger')

    try:
        shell_logger(tmp_file)
    finally:
        shutil.rmtree(tmp_dir)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:44:50.042362
# Unit test for function shell_logger
def test_shell_logger():
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)

    import tempfile, subprocess

    output = tempfile.NamedTemporaryFile().name
    p = subprocess.Popen(
        [sys.executable, __file__, "shell_logger", output],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.PIPE,
        universal_newlines=True,
        bufsize=0
    )
    subproc_stdin = p.stdin
    subproc_stdout = p.stdout
    subproc_stderr = p.stderr
    subproc_stdin.write("ls\n")
    subproc

# Generated at 2022-06-22 00:44:51.217905
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:44:54.874632
# Unit test for function shell_logger
def test_shell_logger():
    output = 'tmp'
    if os.path.isfile(output):
        os.remove(output)
    shell_logger(output)
    assert os.path.isfile(output)
    os.remove(output)

test_shell_logger()

# Generated at 2022-06-22 00:45:22.016753
# Unit test for function shell_logger
def test_shell_logger():
    """Tests shell_logger function."""
    import unittest
    import pkg_resources
    import re
    class TestShellLogger(unittest.TestCase):
        """Test class"""
        def test_shell_logger(self):
            """Test the shell logger."""
            location = pkg_resources.resource_filename(__name__, "test.txt")
            shell_logger(location)
            fd = open(location, "rb")
            result = fd.read().decode("utf8")
            fd.close()
            self.assertEqual(True, len(re.findall(r'(?i)pwd', result)) >= 1)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TestShellLogger)
    unittest.TextTestRunner

# Generated at 2022-06-22 00:45:22.587029
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:45:27.731923
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os

    output = tempfile.mktemp(prefix='shell_logger_test')
    try:
        shell = '/bin/sh'
        os.environ['SHELL'] = shell
        exit_code = shell_logger(output)
        assert exit_code == 0
        assert os.stat(output).st_size == const.LOG_SIZE_IN_BYTES
    finally:
        if os.path.exists(output):
            os.unlink(output)

# Generated at 2022-06-22 00:45:28.914890
# Unit test for function shell_logger
def test_shell_logger():
    # We can't test it because it's hard to stub os.write and os.read
    pass

# Generated at 2022-06-22 00:45:32.194336
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger(".mylog")
    return True
print(test_shell_logger())

shell_logger(".mylog")

# Generated at 2022-06-22 00:45:43.756646
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import mmap
    import pty
    import signal
    import fcntl
    import subprocess
    import array
    import termios
    import tty
    import tempfile
    import functools

    def _read_from_pty(f, fd):
        data = os.read(fd, 1024)
        try:
            f.write(data)
        except ValueError:
            position = const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN

            f.move(0, const.LOG_SIZE_TO_CLEAN, position)
            f.seek(position)
            f.write(b'\x00' * const.LOG_SIZE_TO_CLEAN)
            f.seek(position)

        return data


# Generated at 2022-06-22 00:45:49.908395
# Unit test for function shell_logger
def test_shell_logger():
    """Test that shell_logger works"""
    import tempfile
    with tempfile.NamedTemporaryFile() as tmp:
        if not os.environ.get('SHELL'):
            logs.warn("Shell logger test doesn't support your platform.")
            sys.exit(1)
        shell_logger(tmp.name)
        assert open(tmp.name, 'rb').read()

# Generated at 2022-06-22 00:45:58.575728
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import signal
    import sys
    import termios
    import time
    from . import logs
    import pty
    import tty
    import fcntl
    import array
    import mmap
    import os
    import signal
    import sys
    import termios
    import time
    import tty
    from functools import partial
    from ..core.logs import set_logger
    from ..core.logs import set_debug
    from .commands import spawn_shell, shell_logger

    set_debug(True)
    set_logger(None)

    def b2s(b):
        return b.decode('ascii')

    def _read(f, fd):
        data = os.read(fd, 1024)

# Generated at 2022-06-22 00:46:07.671365
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import tempfile
    import subprocess
    import random
    import re
    import string

    def _random_string(length=10, chars=string.ascii_letters):
        return ''.join(random.choices(chars, k=length))

    def _spawn_shell(logger, fd):
        pid, master_fd = pty.fork()

        if pid == pty.CHILD:
            os.dup2(fd, pty.STDOUT_FILENO)
            os.dup2(fd, pty.STDERR_FILENO)
            os.execlp(os.environ['SHELL'], os.environ['SHELL'])

        return master_fd, pid

    with tempfile.TemporaryDirectory() as tmp:
        random_string = _random

# Generated at 2022-06-22 00:46:17.676358
# Unit test for function shell_logger
def test_shell_logger():
    with open('/tmp/test', 'w') as f:
        def _read(fd):
            data = os.read(fd, 1024)
            try:
                f.write(data.decode())
            except ValueError:
                f.write(data.decode())
            return data

        pid, master_fd = pty.fork()

        if pid == pty.CHILD:
            os.execlp('/bin/bash', '/bin/bash')

        pty._copy(master_fd, partial(_read, master_fd), pty._read)
        os.close(master_fd)
        os.waitpid(pid, 0)[1]

    def print_file(f):
        while True:
            buf = f.read()
            if buf is None:
                break
            print(buf)



# Generated at 2022-06-22 00:46:34.471471
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:46:36.466684
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger("tmp.txt")
    except SystemExit:
        pass
    except:
        raise Exception("Expected 'SystemExit'")


# Generated at 2022-06-22 00:46:46.013965
# Unit test for function shell_logger
def test_shell_logger():
    from tempfile import mkstemp, mkdtemp
    import os
    import shutil
    import random
    import string

    # Get temp dir
    tmp_dir = mkdtemp()

    # Run function
    pid = os.fork()
    if pid == 0:
        os.chdir(tmp_dir)
        shell_logger('.shell-logger-test')
        exit(0)
    else:
        os.wait()

    # Check result
    with open(os.path.join(tmp_dir, '.shell-logger-test')) as f:
        actual = f.read()
    assert actual == ''

    # Clean up
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-22 00:46:46.555038
# Unit test for function shell_logger
def test_shell_logger():
    pass



# Generated at 2022-06-22 00:46:53.733550
# Unit test for function shell_logger
def test_shell_logger():
    """
    The script command: the shell will echo 20, then the script continue.
    """
    import time
    import subprocess
    import re
    import json

    output = "test_shell_logger.txt"
    command = "python " + __file__ + " shell_logger " + output
    process = subprocess.Popen(command, shell=True, universal_newlines=True, stdin=subprocess.PIPE)
    time.sleep(0.5)
    process.communicate("echo 20\nexit\n")
    time.sleep(0.5)
    with open(output, "rb") as f:
        f.seek(0)
        log = f.read()
        matchObj = re.search(b"echo 20", log)
        assert matchObj is not None

# Generated at 2022-06-22 00:47:04.474638
# Unit test for function shell_logger
def test_shell_logger():
    def read_output(output):
        import re
        with open(output, mode='rb') as f:
            output_data = f.read()

        non_short_sequence = re.compile(b'\x00{20,}')
        output_data = non_short_sequence.sub(b'\x00' * 20, output_data)

        # Need to support python2 and python3 (bytes and str types)
        if not isinstance(b'', str):
            output_data = output_data.decode()

        return output_data

    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        shell_logger(f.name)
        assert read_output(f.name).count('\x00') == 1



# Generated at 2022-06-22 00:47:07.549830
# Unit test for function shell_logger
def test_shell_logger():
    """
    Verify function shell_logger works as expected.
    """
    import os

    os.system('python -c "from tbot.tc import shell_logger; shell_logger(\'log\')"')
    assert os.path.exists('log') == True, 'log not created'
    os.remove('log')

# Generated at 2022-06-22 00:47:11.869264
# Unit test for function shell_logger
def test_shell_logger():
    buffer = io.BytesIO()
    shell_logger(output = buffer)
    assert b'\x00' * const.LOG_SIZE_IN_BYTES in buffer.getvalue()
    buffer.close()

# Generated at 2022-06-22 00:47:20.081460
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    import time

    sample_count = 5
    sleep_duration = 0.01
    with open('sample.log', 'wb') as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)

    shell_logger('sample.log')
    time.sleep(sleep_duration * sample_count)
    os.kill(os.getpid(), signal.SIGTERM)

    with open('sample.log', 'rb') as f:
        assert f.read(1) == b''
        assert f.read(const.LOG_SIZE_IN_BYTES - 1) != b''

# Generated at 2022-06-22 00:47:20.699759
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-22 00:47:49.954435
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    from datetime import datetime
    from . import logs
    from . import const
    # make tempdir
    tempdir = tempfile.mkdtemp()
    const.LOG_SIZE_IN_BYTES = 10000
    fp = open(os.path.join(tempdir, 'test.log'), 'w')
    oldstdout = sys.stdout
    sys.stdout = fp
    # run shell_logger
    shell_logger(os.path.join(tempdir, 'test.log'))
    # check file
    now = str(datetime.now())
    print('Check file contents: ' + now)
    logs.debug('Check file contents: ' + now)
    sys.stdout.flush()
    fp.close()
    # delete tempdir

# Generated at 2022-06-22 00:48:01.277139
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell_logger function with the following steps:
    1. Create new file, write some data to it, sleep.
    2. Create subprocess with shell_logger function and check file size.
    """
    import tempfile
    import time
    import os

    file_name = tempfile.mkstemp()[1]
    # write something to file to check file size later
    with open(file_name, 'w') as f:
        f.write(b'1'*const.LOG_SIZE_IN_BYTES)
    time.sleep(2)

    from multiprocessing import Process
    # launch shell logger
    p = Process(target=shell_logger, args=(file_name,))
    p.start()
    # wait for the subprocess to finish
    p.join()

    # file size