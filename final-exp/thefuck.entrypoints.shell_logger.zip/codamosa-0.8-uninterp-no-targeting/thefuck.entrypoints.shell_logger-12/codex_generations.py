

# Generated at 2022-06-22 00:37:58.129448
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: Implement unit test.
    pass


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-22 00:38:08.145946
# Unit test for function shell_logger
def test_shell_logger():
    import time
    import requests
    import json

    from .. import logs
    from ..logs import Logger
    from .. import app
    from .. import const
    from .. import utils
    from ..server.app import run_app

    def set_up():
        logs.setup_logging(output=const.LOGDIR + 'log')

    class TestShellLogger(object):
        def setup_class(self):
            self.token_url = 'https://auth.docker.io/token'
            self.compose_url = 'https://index.docker.io/v2/library/compose'
            self.log_url = 'http://localhost:5000/logs'
            self.timeout = 5
            self.request_num = 2

            self.app = run_app()
            self.app.start()



# Generated at 2022-06-22 00:38:15.612419
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test the shell logger output.
    """
    # Set output log file path
    output_log_file = './tests/data/shell_logger_test.out'
    shell_logger(output_log_file)
    logs.info("Shell logger test output file is: %s" % output_log_file)

if __name__ == "__main__":
    # Run directly
    shell_logger()

# Generated at 2022-06-22 00:38:21.688502
# Unit test for function shell_logger
def test_shell_logger():
    """
    Test shell_logger works with invalid file name
    """
    sys.argv.append('/bash-prompt-toolkit-logger/shell_log-test')
    return_code = shell_logger('shell_log.txt')
    assert return_code == 0
    try:
        os.remove('shell_log.txt')
    except OSError as err:
        logs.error('Error: %s - %s.' % (err.filename, err.strerror))

# Generated at 2022-06-22 00:38:33.924237
# Unit test for function shell_logger
def test_shell_logger():
    from . import helpers

    log = helpers.get_tmp_file(is_binary=True)

    # I suppose that `echo` is available everywhere with shell
    os.spawnlp(os.P_WAIT, 'echo', 'echo', 'Hello world!')

    # Run script command
    rv = os.spawnlp(os.P_WAIT, 'script', 'script', '-f', '-q', '-c', 'echo Hello world!', log)
    assert rv == 0

    # Run some pytest fixtures
    pytest_runner = os.environ['PYTEST_RUNNER']
    assert not os.spawnlp(os.P_WAIT, pytest_runner, pytest_runner, '--help', '--version')

    # Trash the buffer to emulate null bytes at the end of the output
   

# Generated at 2022-06-22 00:39:06.618654
# Unit test for function shell_logger

# Generated at 2022-06-22 00:39:17.758510
# Unit test for function shell_logger
def test_shell_logger():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class ShellLoggerTest(unittest.TestCase):
        def setUp(self):
            if os.path.isfile('testlog'):
                os.remove('testlog')

        def tearDown(self):
            if os.path.isfile('testlog'):
                os.remove('testlog')

        def test_shell_logger(self):
            sys.argv.append('shell_logger')
            shell_logger('testlog')
            assert os.path.isfile('testlog')
            assert os.stat('testlog').st_size == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-22 00:39:29.178864
# Unit test for function shell_logger
def test_shell_logger():
    import unit
    import logging
    import time
    from .. import shell

    old_logger = logging.getLogger('pwnlib.shell')
    logger = unit.MockLogger('pwnlib.shell')
    logger.expect(logging.WARN, 'Shell logger doesn\'t support your platform.', times=1)
    try:
        logging.setLoggerClass(unit.MockLogger)
        logging.getLogger('pwnlib.shell').setLevel(logging.DEBUG)
        shell.shell_logger("/tmp/shell_logger")
    finally:
        logging.setLoggerClass(old_logger.__class__)

    old_logger = logging.getLogger('pwnlib.shell')
    logger = unit.MockLogger('pwnlib.shell')
   

# Generated at 2022-06-22 00:39:37.062286
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import os
    import time
    import timeit

    def shell_logger_on_stdout(output):
        """Logs shell output to the `output`.

        Works like unix script command with `-f` flag.

        """
        if not os.environ.get('SHELL'):
            sys.exit(1)

        # Mocked file descriptor
        fd = io.StringIO()
        # Initializing buffer with zeroes
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES)
        return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

        sys.exit(return_code)

    def test_shell_logger_on_stdout():
        start_dir = os.getcwd()
        os

# Generated at 2022-06-22 00:39:43.706349
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    shell_logger('test_shell_logger.txt')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:39:52.354127
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('test.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:39:56.534145
# Unit test for function shell_logger
def test_shell_logger():
    with NamedTemporaryFile() as f:
        shell_logger(f.name)
        with open(f.name, 'rb') as r:
            assert r.read() == b'\x00' * const.LOG_SIZE_IN_BYTES


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:00.853356
# Unit test for function shell_logger
def test_shell_logger():
    def test(path):
        tmp = os.path.join(path, 'output')
        with logs.set_verbosity(0):
            shell_logger(tmp)
        assert os.path.getsize(tmp) == const.LOG_SIZE_IN_BYTES
    return test

# Generated at 2022-06-22 00:40:03.645498
# Unit test for function shell_logger
def test_shell_logger():
    from . import test_util
    test_util.run_test(shell_logger, [''])

# Generated at 2022-06-22 00:40:06.076470
# Unit test for function shell_logger
def test_shell_logger():
    import contextlib
    import tempfile

    with contextlib.closing(tempfile.TemporaryFile()) as temp:
        shell_logger(temp.name)
        with open(temp.name) as f:
            assert f.read() == ""

# Generated at 2022-06-22 00:40:17.741882
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    def _test(*args):
        if hasattr(args[0], "__call__"):
            args = args[1:]
        shell_logger(*args)

    if not os.environ.get('SHELL'):
        return

    _test("/dev/null")
    _test("/dev/urandom")
    _test("/dev/zero")

    with tempfile.NamedTemporaryFile() as f:
        _test(f.name)
        assert os.path.getsize(f.name) == const.LOG_SIZE_IN_BYTES
    assert os.path.getsize(f.name) == 0

    with tempfile.NamedTemporaryFile() as f:
        _test(f.name)

# Generated at 2022-06-22 00:40:29.014593
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile

    # Create temporary file for test
    output_file = tempfile.NamedTemporaryFile()
    
    # Function to test shell_logger
    def test_function():
        shell_logger(output_file.name)

    # Get the current PID
    pid = os.getpid()

    # Execute function to test in a new process
    pid_test = os.fork()
    if pid_test == 0:
        test_function()
    else:
        os.waitpid(pid_test, 0)
        # Open output file
        output_fd = os.open(output_file.name, os.O_RDONLY)

        # Get the PID number of process executed
        output_test = os.read(output_fd, 1024)

# Generated at 2022-06-22 00:40:31.032837
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
    return_code = shell_logger(f.name)
    os.unlink(f.name)

    assert not return_code

# Generated at 2022-06-22 00:40:32.546702
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("../../logs/shell_logger/shell_logger.log")



# Generated at 2022-06-22 00:40:34.225008
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('shell.log')
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-22 00:40:43.496689
# Unit test for function shell_logger
def test_shell_logger():
    with open('/tmp/test.log', 'w+') as f:
        with patch('sys.exit') as _sys_exit:
            shell_logger(f.name)
            assert _sys_exit.called

# Generated at 2022-06-22 00:40:52.548334
# Unit test for function shell_logger
def test_shell_logger():
    """
    Confirms that shell_logger is able to run a command and persist the text
    to a file
    """
    import tempfile
    f = tempfile.NamedTemporaryFile(prefix="test", suffix="output")
    filename = f.name
    f.close()
    shell_logger(filename)
    f = open(filename, "r")
    text = f.read()
    f.close()
    if "ls" in text:
        # command "ls" was successfully logged. Two ls lines: one for prompt,
        # one for command output
        assert True
    else:
        assert False
    os.remove(filename)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:03.892262
# Unit test for function shell_logger
def test_shell_logger():
    '''
    Shell logger unit test.

    Test coverage:
        ./shell.py:14
        ./shell.py:17
        ./shell.py:20
        ./shell.py:21
        ./shell.py:22
        ./shell.py:23
        ./shell.py:24
        ./shell.py:26
        ./shell.py:27
        ./shell.py:28
        ./shell.py:29
        ./shell.py:30
        ./shell.py:31
        ./shell.py:33
        ./shell.py:35
    '''
    import bitmath
    import os
    import shutil
    import tempfile

    from six import StringIO

    from lider.core import logs as logger

    logs.set_level(logger.DEBUG)

    tmpdir = tempfile.mkd

# Generated at 2022-06-22 00:41:06.857096
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:41:12.290106
# Unit test for function shell_logger
def test_shell_logger():
    out = './shell.log'
    shell_logger(out)
    try:
        with open(out) as output:
            output.seek(0, 2)
            size = output.tell()
            try:
                assert size >= const.LOG_SIZE_IN_BYTES
            finally:
                os.remove(out)
    except IOError:
        assert False

# Generated at 2022-06-22 00:41:13.776643
# Unit test for function shell_logger
def test_shell_logger():
    # since it depends on the environment, just ensuring no crashes
    shell_logger('/tmp/test_shell_logger')

# Generated at 2022-06-22 00:41:20.815689
# Unit test for function shell_logger
def test_shell_logger():
    def assert_log_content(log_content, line1, line2):
        assert log_content == line1 + line2
    from StringIO import StringIO

    output = StringIO()
    assert shell_logger(output) == 0

    logs.info("Unit test output size: %s" % os.stat(output).st_size)

    output.seek(0)
    assert_log_content(output.readline(),
                       "Script started on Sat Aug  2 11:48:55 2014\r\n",
                       "$ pwd\r\n")

    assert_log_content(output.readline(),
                       "/home/anatoly/projects/shell_logger\r\n",
                       "$ exit\r\n")


# Generated at 2022-06-22 00:41:22.309286
# Unit test for function shell_logger
def test_shell_logger():
    pass



# Generated at 2022-06-22 00:41:31.829595
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import unittest.mock

    def test_function():
        shell_logger('shell.log')
    path = os.path.dirname(__file__)


# Generated at 2022-06-22 00:41:38.709219
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    output = 'test.txt'
    command = './turtleshell.py shell_logger ' + output
    process = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    process.stdin.write('echo test\n')
    process.stdin.write('exit\n')
    process.wait()
    process = subprocess.Popen('cat ' + output, shell=True)
    process.wait()

# Generated at 2022-06-22 00:41:56.790572
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import shutil
    import subprocess
    tmpdir = tempfile.mkdtemp()
    fname = os.path.join(tmpdir, 'logger')
    argv = ['shell_logger', fname]
    process = subprocess.Popen([sys.executable, '-c', 'from simple.core import shell_logger; shell_logger.shell_logger("%s")' % fname])
    process.wait()
    with open(fname, "r") as f:
        lines = f.readlines()

    expected_lines = ['\n', 'user@hostname:~$ ls\n', 'user@hostname:~$ exit\n']

    assert lines == expected_lines
    shutil.rmtree(tmpdir)


# Generated at 2022-06-22 00:42:01.164316
# Unit test for function shell_logger
def test_shell_logger():
    logs.setup_testing()
    output_file = os.path.join(logs.ROOT, 'output.log')
    shell_logger(output_file)

    assert os.path.exists(output_file)
    os.remove(output_file)

# Generated at 2022-06-22 00:42:11.043569
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for shell_logger"""

    import tempfile
    import shutil
    import pipes
    import subprocess

    def remove_exclamation(text):
        return text.replace('!', '')

    def remove_hash(text):
        return text.replace('#', '')

    def replace_space(text):
        return text.replace(' ', '%20')

    def replace_backspace(text):
        return text.replace('\b', '')

    def replace_formfeed(text):
        return text.replace('\f', '')

    def replace_linefeed(text):
        return text.replace('\n', '')

    def replace_carriage_return(text):
        return text.replace('\r', '')

    def replace_horizontal_tab(text):
        return text.replace

# Generated at 2022-06-22 00:42:13.534599
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/output'
    try:
        shell_logger(output)
    finally:
        try:
            os.unlink(output)
        except OSError:
            pass

# Generated at 2022-06-22 00:42:20.906413
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/buffer.bin'
    pid = os.fork()
    if pid == 0:
        shell_logger(output)
    else:
        os.waitpid(pid, 0)
        afile = open(output)
        print(afile.read())
        afile.close()
        os.remove(output)

# Run test when executed standalone
if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-22 00:42:21.731335
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('tmp.out')

# Generated at 2022-06-22 00:42:28.457865
# Unit test for function shell_logger
def test_shell_logger():
    output = tempfile.mktemp()

    with open(output, 'wb') as fd:
        fd.write(bytes(b'\x00', 'UTF-8') * const.LOG_SIZE_IN_BYTES)

    shell_logger(output)

    with open(output, 'rb') as fd:
        out = fd.read()

    assert out == bytes(b'\x00', 'UTF-8') * const.LOG_SIZE_IN_BYTES, 'Empty log file'

    os.remove(output)

# Generated at 2022-06-22 00:42:34.231017
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import os.path

    filename = 'test_file'
    filename_log = filename + '.log'

    if os.path.isfile(filename):
        os.remove(filename)

    f = open(filename, 'w')
    f.close()
    shell_logger(filename + '.log')
    shutil.copyfile(filename_log, filename)
    assert(shutil.cmp(filename, filename_log) == True)

# Generated at 2022-06-22 00:42:35.474615
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-22 00:42:46.793588
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import tempfile
    import pty
    import fcntl
    import mmap
    import termios
    import signal
    import array
    import contextlib

    def _read_cmd(master_fd):
        data = 'ls\n'
        return os.write(master_fd, data)


    def _set_pty_size(master_fd):
        buf = array.array('h', [0, 0, 0, 0])
        fcntl.ioctl(pty.STDOUT_FILENO, termios.TIOCGWINSZ, buf, True)
        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, buf)



# Generated at 2022-06-22 00:43:00.001180
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger."""
    try:
        shell_logger('/tmp/test.log')
        logs.warn('Shell logger is not tested.')
    except SystemExit:
        pass
    else:
        assert False

# Generated at 2022-06-22 00:43:03.722340
# Unit test for function shell_logger
def test_shell_logger():
    test_output = '/tmp/shifter_test.shell_logger'
    sys.stdout.write('$SHELL log output should be in: ' + test_output + '\n')
    shell_logger(test_output)


# Generated at 2022-06-22 00:43:10.123836
# Unit test for function shell_logger
def test_shell_logger():
    import time
    log_file = 'test.log'
    shell_logger(log_file)
    time.sleep(5)
    buffer = mmap.mmap(os.open(log_file, os.O_RDONLY), const.LOG_SIZE_IN_BYTES)
    assert len(buffer) == const.LOG_SIZE_IN_BYTES
    os.remove(log_file)

# Generated at 2022-06-22 00:43:20.619012
# Unit test for function shell_logger
def test_shell_logger():
    if not os.environ.get('SHELL'):
        logs.warn("Shell logger doesn't support your platform.")
        sys.exit(1)
    try:
        with open('shell_log_test', 'w') as f:
            f.write(' ********* This is a test *********** ')
        with open('shell_log_test_log', 'w') as f:
            f.write(' ')
        shell_logger('shell_log_test_log')
        with open('shell_log_test_log', 'r') as f:
            first_line = f.readline().strip()
        assert first_line.find('This is a test') != -1
    finally:
        os.remove('shell_log_test')
        os.remove('shell_log_test_log')



# Generated at 2022-06-22 00:43:22.760794
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('./data/test_file.txt')

# Generated at 2022-06-22 00:43:23.293818
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-22 00:43:30.403681
# Unit test for function shell_logger
def test_shell_logger():
    from .. import const
    from . import shell_logger
    import os

    logs.log_dir = os.getcwd()
    logs.prefix = ''

    os.environ['SHELL'] = 'sh'

    pid = os.fork()
    if pid == 0:
        shell_logger('test.log')
    else:
        os.waitpid(pid, 0)
        logs.source = 'test.log'
        logs.read()

# vim: ts=8 sts=4 sw=4 et

# Generated at 2022-06-22 00:43:40.603356
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import os
    import random

    content = 'test'
    output = '.tmp'

    logs.info("Starting test_shell_logger unit-test")

    try:
        shutil.os.remove(output)
    except FileNotFoundError:
        pass

    old_argv = sys.argv
    sys.argv = ['', output]
    try:
        shell_logger(output)
    finally:
        sys.argv = old_argv
    assert os.path.isfile(output)
    assert len(content) <= os.path.getsize(output)
    for i in range(10):
        assert content in open(output, 'rb').read().decode()
    logs.info("test_shell_logger unit-test is finished")

# Generated at 2022-06-22 00:43:47.273682
# Unit test for function shell_logger
def test_shell_logger():
    def check_files_equal(filename1, filename2):
        with open(filename1, 'rb') as f1:
            with open(filename2, 'rb') as f2:
                return (f1.read() == f2.read())

    log_file = 'shell_logger_test'
    return_code = shell_logger(log_file)
    assert not return_code, 'shell_logger return code != 0'
    assert check_files_equal(log_file, log_file), 'script logfile is empty'


# Generated at 2022-06-22 00:43:53.904399
# Unit test for function shell_logger
def test_shell_logger():
    with open('/tmp/shell_logger_test', 'w'):
        pass
    shell_logger('/tmp/shell_logger_test')
    assert os.path.exists('/tmp/shell_logger_test')
    os.remove('/tmp/shell_logger_test')


if __name__ == '__main__':
    shell_logger(os.path.expanduser('~/.shell-logger'))

# Generated at 2022-06-22 00:44:04.651897
# Unit test for function shell_logger
def test_shell_logger():
    assert callable(shell_logger)

# Generated at 2022-06-22 00:44:12.929324
# Unit test for function shell_logger
def test_shell_logger():
    # Test with empty script
    try:
        output_name = 'empty'
        output = '/tmp/{}'.format(output_name)
        shell_logger(output)
        assert False
    except OSError:
        assert True

    # Test with simple script
    output_name = 'simple'
    output = '/tmp/{}'.format(output_name)
    print(output)
    script = 'echo "Test"'
    os.system('echo "{}" > {}'.format(script, output))
    shell_logger(output)
    lines = os.popen('tail -n +1 {}'.format(output)).readlines()
    assert len(lines) > 0
    last_line = lines[len(lines) - 1]

# Generated at 2022-06-22 00:44:15.189746
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: Check file is created
    assert True

# Generated at 2022-06-22 00:44:15.694956
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:44:18.132900
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as fp:
        shell_logger(fp.name)
        assert os.stat(fp.name).st_size >= const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-22 00:44:22.489241
# Unit test for function shell_logger
def test_shell_logger():
    print('testing shell_logger')
    output_file = 'shell_logger_test.log'
    shell_logger(output_file)
    print('shell_logger:', 'DONE')

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-22 00:44:23.017772
# Unit test for function shell_logger
def test_shell_logger():
    assert True

# Generated at 2022-06-22 00:44:28.859431
# Unit test for function shell_logger
def test_shell_logger():
    from . import test_runner
    from .. import const

    with test_runner.create_temp_dir() as tmp_dir:
        log_file = os.path.join(tmp_dir, 'log-file')
        shell_logger(log_file)

        with open(log_file) as f:
            data = f.read()
            assert len(data) == const.LOG_SIZE_IN_BYTES, data

# Generated at 2022-06-22 00:44:33.463768
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function shell_logger
    """
    output = 'shell_logger_test.txt'
    shell_logger(output)
    f = open(output, 'r')
    l = 0
    for _ in f:
        l += 1
    assert l == 1
    os.remove(output)


if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-22 00:44:36.201820
# Unit test for function shell_logger
def test_shell_logger():
    with tempfile.NamedTemporaryFile() as log_file:
        shell_logger(log_file.name)



# Generated at 2022-06-22 00:44:54.909111
# Unit test for function shell_logger
def test_shell_logger():
    try:
        os.remove('/tmp/foo.log')
    except OSError:
        pass

    subprocess.Popen(['bash', '-c', 'echo "foo" > /tmp/baz.log'])
    subprocess.Popen(['python', '-m', 'shell_logger', '/tmp/foo.log'])
    # Wait until file is created
    while not os.path.exists('/tmp/foo.log'):
        time.sleep(0.1)

    with open('/tmp/foo.log', 'rb') as f:
        output = f.read().decode('utf-8', 'ignore')
    with open('/tmp/baz.log', 'rb') as f:
        expected_output = f.read().decode('utf-8', 'ignore')



# Generated at 2022-06-22 00:44:58.393660
# Unit test for function shell_logger
def test_shell_logger():
    output = '/tmp/test.log'
    shell_logger(output)
    assert all(os.access(output, os.R_OK | os.W_OK | os.X_OK) for output in [output])

# Generated at 2022-06-22 00:45:03.785240
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger."""

    import os
    import subprocess
    import shutil
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        out = os.path.join(d, 'test.log')
        ret = subprocess.call(['sh', '-c', 'echo "ab" > /dev/tty && exit 1'],
                stdout=open(out, 'w'))
        assert ret == 1
        assert open(out).read() == '\0\0\0\0\0\0\0\0\0\0ab\n'

        os.write(1, b"c\n")
        ret = subprocess.call(['sh', '-c', 'echo "ab" > /dev/tty && exit 1'],
                stdout=open(out, 'w'))

# Generated at 2022-06-22 00:45:10.316382
# Unit test for function shell_logger
def test_shell_logger():
    """Unit tests for shell_logger"""
    test_str = "test_str"
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(prefix='shell_logger_test_')
    tmpfilename = tmpfile.name
    tmpfile.close()
    shell_logger(tmpfilename)
    with open(tmpfilename, 'rb') as f:
        assert f.read().endswith(test_str.encode())

# Generated at 2022-06-22 00:45:11.143290
# Unit test for function shell_logger
def test_shell_logger():
    # TODO: test for shell logger
    pass

# Generated at 2022-06-22 00:45:21.937892
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import pexpect
    import time
    import tempfile
    import shutil
    import mmap

    with tempfile.TemporaryDirectory() as td:
        LOGFILE = os.path.join(td, "test.log")
        GLOBAL_CMD = pexpect.spawn("python3 %s %s" % (__file__, LOGFILE))
        time.sleep(2)
        child = pexpect.spawn("bash")
        child.logfile = sys.stdout
        child.sendline("python3 -c \"print(42);print(42)\"")
        child.sendline("exit")
        child.wait()

# Generated at 2022-06-22 00:45:29.361807
# Unit test for function shell_logger
def test_shell_logger():
    import os, glob, subprocess, tempfile
    import unittest
    import const, utils

    # test shell_logger if the result is 0 bytes
    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self._output_file = tempfile.mktemp()
            self._process = subprocess.Popen(["python", sys.argv[0], self._output_file],
                                                stdin=subprocess.PIPE)
    
            # ugly hack, maybe fixed in the future
            self._process.communicate(b"echo 'hello, world'\n")
            self._process.communicate(b"exit\n")
            self._process.wait()
            
            self._process_output_size = os.path.getsize(self._output_file)


# Generated at 2022-06-22 00:45:32.633597
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    return_code = shell_logger('/tmp/test_shell_logger.txt')
    assert return_code == 0

# Generated at 2022-06-22 00:45:44.056246
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import os
    import stat
    import mmap
    import tempfile
    import time
    from . import logs

    old_stdout = sys.stdout

    logfile = os.path.join(tempfile.gettempdir(), 'test_shell_logger')
    sys.stdout = open(logfile, 'w')
    logs.set_verbosity(2)

    for n in range(10):
        os.system('ls -la')
        time.sleep(1)

    logs.set_verbosity(1)
    shell_logger(logfile)

    sys.stdout.close()
    sys.stdout = old_stdout


# Generated at 2022-06-22 00:45:54.885383
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import subprocess

    def wrapper(output):
        """Mock function shell_logger."""
        if not os.environ.get('SHELL'):
            return
        fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
        _spawn(os.environ['SHELL'], partial(_read, buffer))


# Generated at 2022-06-22 00:46:27.509698
# Unit test for function shell_logger
def test_shell_logger():
    output = 'test.log'
    fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    os.environ['SHELL'] = 'sh'
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
    assert return_code == 0
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))
    assert return_code == 0

# Generated at 2022-06-22 00:46:30.702118
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger("test_log")

if __name__ == "__main__":
    test_shell_logger()

# Generated at 2022-06-22 00:46:35.934259
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import tempfile
    from .. import main

    def main_action(output):
        main.shell_logger(output)

    # Local test
    buffer = io.BytesIO()
    main_action(buffer)
    assert buffer.getvalue() is not None

    # Remote test
    with tempfile.TemporaryFile() as buffer:
        main_action(buffer)
        assert buffer.getvalue() is not None

# Generated at 2022-06-22 00:46:46.353068
# Unit test for function shell_logger
def test_shell_logger():
    import shutil
    import time
    import tempfile
    from . import logs

    # Get temp file
    temp_fd, temp_file = tempfile.mkstemp(prefix='slap-')
    os.close(temp_fd)

# Generated at 2022-06-22 00:46:50.631203
# Unit test for function shell_logger
def test_shell_logger():
    import pytest

    logs.set_state(False)
    with pytest.raises(SystemExit) as e:
        shell_logger("/dev/null")
    assert e.value.code == 0

    logs.set_state(True)
    with pytest.raises(SystemExit) as e:
        shell_logger("/dev/null")
    assert e.value.code == 0



# Generated at 2022-06-22 00:47:02.534169
# Unit test for function shell_logger
def test_shell_logger():
    from .. import const
    import os
    import pty
    import os.path as path
    
    # Prepare file
    output = 'tmp_log'
    fd = os.open(output, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)

    # Create buffer
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    def _read(f, fd):
        data = os.read(fd, 1024)
        f.write(data)
        return data

    # Create a spawned process. Modified version of pty.spawn with terminal size support

# Generated at 2022-06-22 00:47:13.973571
# Unit test for function shell_logger
def test_shell_logger():
    try:
        if os.name == 'posix':
            import resource
            st_dev, st_ino, st_nlink, st_uid, st_gid = os.stat('/dev/pts/')
            resource.setrlimit(resource.RLIMIT_NOFILE, (st_nlink, st_nlink))
            shell_logger(os.environ['HOME'] + '/pytest.log')
            os.unlink(os.environ['HOME'] + '/pytest.log')
        else:
            error_code = os.system('pyspy -l pytest.log')
            if error_code != 0:
                raise Exception('unexpected error')
            os.unlink('pytest.log')
    except Exception:
        pass

# Generated at 2022-06-22 00:47:25.019400
# Unit test for function shell_logger
def test_shell_logger():
    tty.setraw(sys.stdin.fileno())
    output = 'output.txt'
    pid = os.fork()
    if pid == 0:
        sys.stdout.write('12345678901234567890\n')
        sys.stdout.flush()
        sys.stdout.write('12345678901234567890\n')
        sys.stdout.flush()
        sys.stdout.write('12345678901234567890\n')
        sys.stdout.flush()
        os.close(sys.stdout.fileno())
        os.close(sys.stdin.fileno())
        shell_logger(output)
    else:
        os.close(sys.stdout.fileno())
        os.close(sys.stdin.fileno())


# Generated at 2022-06-22 00:47:37.127666
# Unit test for function shell_logger
def test_shell_logger():
    """Tests the `shell_logger` function.
    """
    import os

    def _test(fn, in_, out):
        in_ = in_.encode()
        out = out.encode()
        pid, master_fd = pty.fork()

        if pid == pty.CHILD:
            os.execlp(os.environ['SHELL'], os.environ['SHELL'])

        def write(d):
            os.write(master_fd, d)

        def read():
            return os.read(master_fd, 1024)

        def close():
            os.close(master_fd)

        fn(partial(write), partial(read), close)


# Generated at 2022-06-22 00:47:49.722203
# Unit test for function shell_logger
def test_shell_logger():
    """Testing shell_logger function
    """
    import filecmp
    import shutil
    import shlex
    import subprocess
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    temp_file = temp_dir.name + 'test_shell_logger.log'
    output = 'test_shell_logger.log'