

# Generated at 2022-06-22 00:38:06.864149
# Unit test for function shell_logger
def test_shell_logger():
    try:
        # create test file
        fd = os.open('/tmp/test.log', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
        os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
        os.close(fd)

        # in known-to-be-a-tty environment
        os.environ['SHELL'] = '/bin/bash'
        os.environ['TERM'] = 'xterm'

        # run test
        os.environ['SHELL'] = '/bin/bash'
        shell_logger('/tmp/test.log')

    except Exception as e:
        print('test_shell_logger: error: ', e)

# Generated at 2022-06-22 00:38:11.681625
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as temp_dir:
        test_file = os.path.join(temp_dir, 'testfile')
        shell_logger(test_file)
        assert os.path.exists(test_file) == True

# Generated at 2022-06-22 00:38:19.885626
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(mode='wb+t') as f:
        shell_logger(f.name)

        f.seek(0)
        content = f.read(const.LOG_SIZE_IN_BYTES)
        assert content.startswith(b'\x00' * (const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN))
        assert content.endswith(b'sexit\n')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:38:26.325542
# Unit test for function shell_logger
def test_shell_logger():
    for x in range(1, 6):
        shell_logger('/tmp/test.log')

    f = open('/tmp/test.log')
    data = f.read()

    assert data.startswith('\x00' * 1000)
    assert data.endswith('\n'.join(['$ whoami', '$ log2exec']))

# Generated at 2022-06-22 00:38:31.522579
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    logs.log_filename = '/tmp/shell_logger.log'
    shell_logger(logs.log_filename)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:38:33.248830
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    shell_logger('/tmp/test.log')

# Generated at 2022-06-22 00:39:06.613668
# Unit test for function shell_logger

# Generated at 2022-06-22 00:39:14.717781
# Unit test for function shell_logger
def test_shell_logger():
    with open('shell_log.txt', 'w') as f:
        f.write('x' * const.LOG_SIZE_IN_BYTES)
    with open('shell_log.txt', 'r') as f:
        assert len(f.read()) == const.LOG_SIZE_IN_BYTES
    shell_logger('shell_log.txt')
    with open('shell_log.txt', 'r') as f:
        assert len(f.read()) == const.LOG_SIZE_IN_BYTES

# Generated at 2022-06-22 00:39:18.184924
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    return_code = shell_logger('/tmp/unit-test.txt')
    assert return_code == 0
    os.remove('/tmp/unit-test.txt')

# Generated at 2022-06-22 00:39:29.558579
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import os.path
    import mmap
    import tempfile
    import unittest

    class TestShellLogger(unittest.TestCase):
        def setUp(self):
            self.directory = tempfile.mkdtemp()
            logs.set_verbosity(5)
            self.output_file = os.path.join(self.directory, 'output.log')

            # Write to output file until it is full
            file_pointer = os.open(self.output_file, os.O_CREAT | os.O_TRUNC | os.O_RDWR)
            os.write(file_pointer, b'\x00' * const.LOG_SIZE_IN_BYTES)

# Generated at 2022-06-22 00:39:45.991865
# Unit test for function shell_logger
def test_shell_logger():
    logs.set_colors(False)
    logs.set_verbosity(0)
    at_exit = partial(logs.warn, "Don't forget to remove this file.")
    atexit.register(at_exit)
    shell_logger('test_script.log')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:39:54.873224
# Unit test for function shell_logger
def test_shell_logger():
    import unittest
    import subprocess
    import tempfile

    class TestFile(unittest.TestCase):
        def setUp(self):
            filepath = os.path.join(tempfile.gettempdir(), 'test_shell_logger')
            self.filepath = filepath
            self.open_file = open(filepath, 'w+b')

        def tearDown(self):
            os.remove(self.filepath)

        def test_shell_logger_returns_correctly(self, *args):
            # Subprocess call shell_logger.
            shell_logger(self.filepath)

try:
    import unittest
    unittest.main()
except ImportError:
    pass

# Generated at 2022-06-22 00:40:05.913525
# Unit test for function shell_logger
def test_shell_logger():
    """Tests the shell logger"""
    import unittest
    import shutil
    import os
    import tempfile

    class ShellLoggerTestCase(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            # create file for logs
            cls.test_dir = tempfile.mkdtemp()
            cls.test_dir = os.path.join(cls.test_dir, "test_file.txt")
            test_file = open(cls.test_dir, "w")
            test_file.close()
            # os.environ["SHELL"] = "/bin/bash"
            # os.environ["TERM"] = "xterm-256color"
            # os.environ["COLORTERM"] = "gnome-terminal"


# Generated at 2022-06-22 00:40:17.699095
# Unit test for function shell_logger
def test_shell_logger():
    cmd = "python -m poormanslogging.shell >/tmp/log.txt"
    lines = "this is a test\n" * 100
    output = "/tmp/test_shell_logger.log"
    return_code = os.system(cmd)
    assert return_code == 0
    sys.stderr.write("\n")
    return_code = os.system(cmd)
    assert return_code == 0
    sys.stderr.write("\n")
    return_code = os.system(cmd)
    assert return_code == 0
    sys.stderr.write("\n")
    return_code = os.system(cmd)
    assert return_code == 0
    sys.stderr.write("\n")
    return_code = os.system(cmd)

# Generated at 2022-06-22 00:40:28.939178
# Unit test for function shell_logger
def test_shell_logger():
    def mock_write(data):
        pass

    def mock_spawn(master_read):
        pass

    def mock_pty_size(master_fd):
        pass

    mmap.mmap = lambda fd, *args: mock_write


# Generated at 2022-06-22 00:40:33.469932
# Unit test for function shell_logger
def test_shell_logger():
    test_output = "shell_logger_test.txt"
    shell_logger(test_output)
    test = open(test_output, "r")
    returnCode = test.read()
    if returnCode == "0":
        print("Test passed")
    else:
        print("Test failed")

# Generated at 2022-06-22 00:40:41.926539
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import time
    import os

    output_file = tempfile.NamedTemporaryFile()
    pid = os.fork()
    if pid == 0:
        shell_logger(output_file.name)
    else:
        os.waitpid(pid)
        assert os.path.getsize(output_file.name) == const.LOG_SIZE_IN_BYTES
        output_file.close()

# Ignore shell_logger function if it is being run
if __name__ != '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:40:48.774139
# Unit test for function shell_logger
def test_shell_logger():

    fd = os.open('log.txt', os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn(os.environ['SHELL'], partial(_read, buffer))

    assert return_code == 0

# Generated at 2022-06-22 00:40:55.804664
# Unit test for function shell_logger
def test_shell_logger():
    fd = os.open("/tmp/foo.log", os.O_CREAT | os.O_TRUNC | os.O_RDWR)
    os.write(fd, b'\x00' * const.LOG_SIZE_IN_BYTES)
    buffer = mmap.mmap(fd, const.LOG_SIZE_IN_BYTES, mmap.MAP_SHARED, mmap.PROT_WRITE)
    return_code = _spawn("/bin/bash", partial(_read, buffer))

# Generated at 2022-06-22 00:41:05.287129
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    import sys
    from . import const

    logs.setup("test_logs")

    def setup_logs(log_dir):
        os.makedirs(log_dir)
        with open(os.path.join(log_dir, "shell.log"), "w") as f:
            f.write("\x00")
        return os.path.join(os.path.abspath(log_dir), "shell.log")

    def simulate_session(shell, log_file):
        """Simulates a shell session."""
        shell(log_file)
        with open(log_file, "r") as f:
            return f.read()

    def test_empty(shell):
        """Tests if logs are empty."""

# Generated at 2022-06-22 00:41:28.497609
# Unit test for function shell_logger
def test_shell_logger():

    # Open temporary file in order to test `shell_logger`
    with tempfile.NamedTemporaryFile() as file:
        logs.info("Testing shell logger. Tested command: echo 'test string 123'")

        shell_logger(file.name)
        logs.info("Testing is over. Tested file: {}".format(file.name))

        file.seek(0)
        test_string = file.read(const.LOG_SIZE_IN_BYTES)
        test_string_not_null = test_string.find(b'\x00')
        test_string = test_string[test_string_not_null:]
        test_string = test_string[:test_string.rfind(b'\x00')]


# Generated at 2022-06-22 00:41:35.404952
# Unit test for function shell_logger
def test_shell_logger():
    """Run unit test for function shell_logger.

    Note: under windows, this test is not executable.
    """
    import tempfile
    import subprocess
    import pty

    TEST_DATA = """test
test"""
    with tempfile.NamedTemporaryFile() as f:
        _, master_fd = pty.fork()
        if not master_fd:
            shell_logger(f.name)
        else:
            os.write(master_fd, TEST_DATA)
    with open(f.name, 'rb') as f:
        data = f.read()

    assert data == TEST_DATA

# Generated at 2022-06-22 00:41:36.847782
# Unit test for function shell_logger
def test_shell_logger():
    pass


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:41:42.248481
# Unit test for function shell_logger
def test_shell_logger():
    # Run shell (bash, ksh, zsh or any other)
    from unittest import mock
    import tempfile
    with mock.patch.dict(os.environ):
        os.environ['SHELL'] = '/bin/sh'
        with tempfile.TemporaryDirectory() as dirname:
            shell_logger(dirname + '/log')

# Generated at 2022-06-22 00:41:46.324226
# Unit test for function shell_logger
def test_shell_logger():
    master, slave = pty.openpty()
    os.write(slave, b'ddddd')
    os.write(slave, b'\x1a')
    assert slave == _read(master, master)

# Generated at 2022-06-22 00:41:50.297855
# Unit test for function shell_logger
def test_shell_logger():
    fd = open("test_output.txt", "w+")
    fd.write("")
    shell_logger("test_output.txt")
    assert os.path.getsize("test_output.txt")


if __name__ == '__main__':
    shell_logger('test_output.txt')

# Generated at 2022-06-22 00:42:00.765502
# Unit test for function shell_logger
def test_shell_logger():
    """Unit test for function `shell_logger`."""
    import tempfile
    import time

    test_file = tempfile.mktemp(suffix='.shell-logger')

    # Run shell logger to log shell commands.
    sys.argv = sys.argv[:1]
    shell_logger(test_file)
    # It is waiting for the shell command. Type something and press Enter.
    time.sleep(0.2)

    # Read logged file

# Generated at 2022-06-22 00:42:02.697845
# Unit test for function shell_logger
def test_shell_logger():
    from . import tmpdir
    with tmpdir.create_tmp_dir() as tmp:
        shell_logger(os.path.join(tmp, 'shell.log'))

# Generated at 2022-06-22 00:42:07.941080
# Unit test for function shell_logger
def test_shell_logger():
    output = format("%s/test_shell_logger_out" % logs.LOGS_DIR)
    shell_logger(output)
    with open(output, 'r') as f:
        buff = f.read()
    os.unlink(output)
    assert buff == '\0' * const.LOG_SIZE_IN_BYTES
    assert os.path.exists(output)

# Generated at 2022-06-22 00:42:11.389422
# Unit test for function shell_logger
def test_shell_logger():
    sp.call(["touch", "test_shell_logger"])
    shell_logger("test_shell_logger")
    assert(sp.call(["cat", "test_shell_logger"]) == 0)

# Generated at 2022-06-22 00:42:49.424210
# Unit test for function shell_logger
def test_shell_logger():
    from ..assertions import assert_that
    from ..daemon.constants import LOGS_PATH
    from tempfile import mkstemp
    
    logs_path = os.path.join('/tmp', 'testing-logs')
    if not os.path.exists(logs_path):
        os.makedirs(logs_path)
    fd, output = mkstemp(suffix='.log', prefix='shell', dir=logs_path)
    os.close(fd)
    
    shell_logger(output)
    
    assert_that(os.path.getsize(output)).is_greater_than(0)
    os.remove(output)

# Generated at 2022-06-22 00:43:00.985408
# Unit test for function shell_logger
def test_shell_logger():
    # Create temporary directory for `output` file
    tmp_dir = tempfile.mkdtemp(prefix="logl-")
    tmp_file = tempfile.mkstemp(suffix="-output", prefix="logl-", dir=tmp_dir)
    os.close(tmp_file[0])
    tmp_file = tmp_file[1]

    # Run function shell_logger
    pid = os.fork()
    if pid == 0:
        shell_logger(tmp_file)
    else:
        os.waitpid(pid, 0)
        with open(tmp_file, 'rb') as f:
            assert f.read() == b'\x00' * const.LOG_SIZE_IN_BYTES

    # Clean up temporary directory
    os.remove(tmp_file)
    os.rmdir

# Generated at 2022-06-22 00:43:01.962694
# Unit test for function shell_logger
def test_shell_logger():
    if sys.platform != 'darwin':
        return

    shell_logger('/tmp/test_shell_logger.txt')

# Generated at 2022-06-22 00:43:03.390450
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('/tmp/test_shell_logger.log') == 0
    os.unlink('/tmp/test_shell_logger.log')

# Generated at 2022-06-22 00:43:05.027022
# Unit test for function shell_logger
def test_shell_logger():
    os.environ['SHELL'] = '/bin/bash'
    shell_logger('/tmp/test.log')

# Generated at 2022-06-22 00:43:14.639739
# Unit test for function shell_logger
def test_shell_logger():
    import time

    # Creating temporary file
    import tempfile
    handle, path = tempfile.mkstemp()

    # Launching shel logger
    import multiprocessing
    process = multiprocessing.Process(target=shell_logger, args=[path])
    process.start()

    # Waiting when logger works
    time.sleep(5)

    # Stopping shell logger
    process.terminate()

    # Checking that file is not empty
    assert os.path.getsize(path) > 0

    # Cleaning up
    os.close(handle)
    os.remove(path)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:43:16.406287
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell_logger.log')

# Generated at 2022-06-22 00:43:28.124620
# Unit test for function shell_logger
def test_shell_logger():
    import os

    def _mock_spawn(shell, master_read):
        state = os.stat(shell)
        master_read(shell, state.st_ino)
        return 0

    def _mock_pty_fork():
        return 0, 0

    def _mock_spawn_called(shell, master_read):
        assert shell == 'shell'
        assert callable(master_read) is True
        return 0

    old_spawn = pty.spawn
    pty.fork = _mock_pty_fork
    pty.spawn = _mock_spawn_called

    old_env = os.environ.get('SHELL')
    os.environ['SHELL'] = 'shell'

    shell_logger('file')

    pty.spawn = old_spawn

# Generated at 2022-06-22 00:43:38.266357
# Unit test for function shell_logger
def test_shell_logger():
    import subprocess
    from . import cli
    from . import const
    from . import utils
    import os

    with utils.temporary_file(const.LOG_SIZE_IN_BYTES - const.LOG_SIZE_TO_CLEAN) as tmp_file:
        subprocess.call(['shell-logger', tmp_file.name], stdin=subprocess.PIPE)
        size = os.stat(tmp_file.name).st_size
        assert size == const.LOG_SIZE_IN_BYTES
        # FIXME: This assert fails because of the bug in fcntl.ioctl() function
        # assert tmp_file.read() == b'\x00' * const.LOG_SIZE_TO_CLEAN

# Generated at 2022-06-22 00:43:39.717388
# Unit test for function shell_logger
def test_shell_logger():
    logs.init_logger()
    shell_logger("test_shell_logger.log")

# Generated at 2022-06-22 00:44:16.637287
# Unit test for function shell_logger
def test_shell_logger():
    try:
        shell_logger('/tmp/__shell_logger')
        assert False
    except SystemExit as e:
        assert e.code == os.EX_IOERR

    shell_logger('/tmp/__shell_logger')
    os.remove('/tmp/__shell_logger')



# Generated at 2022-06-22 00:44:23.303881
# Unit test for function shell_logger
def test_shell_logger():
    """
    This is a unit test to check if shell logger works well with tty
    """
    # mockup test
    assert shell_logger.__doc__ is not None
    # This test needs to be run with a terminal which has a bash because
    # the logger spawns a shell and writes commands in that shell
    if os.environ.get('SHELL'):
        with open('test-file', 'w+') as f:
            shell_logger(f.name)
    else:
        logs.warn("No shell environment for this platform")
        assert False

# Generated at 2022-06-22 00:44:29.934407
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import pkgutil
    import shutil

    tmp_dir = 'tmp'
    tmp_file = 'shell.log'

    os.mkdir(tmp_dir)
    shell_logger(tmp_dir + '/' + tmp_file)

    data = pkgutil.get_data('shell_logger', tmp_dir + '/' + tmp_file)
    assert len(data) == const.LOG_SIZE_IN_BYTES

    shutil.rmtree(tmp_dir)


# Generated at 2022-06-22 00:44:31.946797
# Unit test for function shell_logger
def test_shell_logger():
    with open(const.TEST_FILE, 'w') as f:
        shell_logger(f)



# Generated at 2022-06-22 00:44:42.932544
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import sys
    import shutil
    import contextlib
    import tempfile
    import subprocess

    OUTPUT = 'output'
    with tempfile.TemporaryDirectory() as directory, contextlib.suppress(FileNotFoundError):
        os.chdir(directory)
        sys.argv = [sys.argv[0], OUTPUT]
        shell_logger(OUTPUT)

    output = os.path.join(os.path.dirname(__file__), OUTPUT)
    with open(output, 'w') as f:
        f.write('')
    sys.argv = [sys.argv[0], output]
    shell_logger(output)
    shutil.rmtree(directory)
    subprocess.call(['rm', output])

# Generated at 2022-06-22 00:44:52.617787
# Unit test for function shell_logger
def test_shell_logger():
    import tempfile
    import subprocess
    import time
    import ctypes
    import struct
    import unittest

    class TestShellLogger(unittest.TestCase):
        def test_shell_output(self):
            logs.debug('Testing shell logger')
            output = tempfile.mktemp()
            process = subprocess.Popen(
                ['python', '-m', 'houdini_console.backend.logger',
                 'shell_logger', output])
            time.sleep(0.1)  # Wait for shell to start
            subprocess.Popen(['osascript', '-e', 'tell application "Terminal" to do script "date" in first tab of first window'])
            time.sleep(0.1)  # Wait for date command finished
            process.kill()
            process.wait()

# Generated at 2022-06-22 00:44:55.295118
# Unit test for function shell_logger
def test_shell_logger():
    filename = 'test.txt'
    shell_logger(output=filename)
    assert os.path.isfile(filename)
    os.remove(filename)

# Generated at 2022-06-22 00:45:02.831611
# Unit test for function shell_logger
def test_shell_logger():
    import io
    import random
    import platform
    import subprocess
    import tempfile

    test_file = tempfile.NamedTemporaryFile()
    log_file = tempfile.NamedTemporaryFile()

    def test():
        cmd = [sys.executable, '-c', 'import sys;sys.exit(sys.stdin.read()[0])']
        return_code = subprocess.call(cmd, stdout=log_file, stdin=test_file, shell=True)
        return return_code

    test_output = lambda: ''.join([chr(c) for c in random.sample(range(ord('a'), ord('z')), 1024)])

    with io.open(test_file.name, 'wt') as f:
        f.write(test_output())

# Generated at 2022-06-22 00:45:06.544134
# Unit test for function shell_logger
def test_shell_logger():
    path = '/tmp/test_shell_logger'
    shell_logger(path)
    assert os.path.exists(path)

# Generated at 2022-06-22 00:45:11.028155
# Unit test for function shell_logger
def test_shell_logger():
    # Create temporary file
    import tempfile
    temp_file = tempfile.TemporaryFile()

    # Run shell_logger()
    shell_logger(temp_file)

    # Read the content of temporary file and see if it's not empty
    temp_file.seek(0)
    if tempfile.readline() == '':
        return False
    return True


# Generated at 2022-06-22 00:45:53.232424
# Unit test for function shell_logger
def test_shell_logger(): # pragma: no cover
    import pytest
    import os
    from ..logs import log as log_mod
    from ..logs.exceptions import LogDirNotExist

    class MockSys(object):
        def __init__(self):
            self.stdout = []
            self.stderr = []

        def exit(self, status):
            self.status = status

    class MockEnviron(object):
        def __init__(self, shell = None):
            self.shell = shell

        def get(self, shell):
            return self.shell

    class MockOs(object):
        def __init__(self, shell = None):
            self.shell = shell

        def path_exists(self, shell):
            if self.shell is None:
                return False
            else:
                return True


# Generated at 2022-06-22 00:45:55.137230
# Unit test for function shell_logger
def test_shell_logger():
    sys.argv = ['shell.py', 'shell.log']

# Generated at 2022-06-22 00:45:57.665861
# Unit test for function shell_logger
def test_shell_logger():
    # Highly impure function, should be refactored to use test.integration
    # This test is just for coverage
    shell_logger(os.path.join(const.TEST_DIR, 'foo'))

# Generated at 2022-06-22 00:46:05.110543
# Unit test for function shell_logger
def test_shell_logger():
    """Simple unit test for shell_logger()"""
    if os.path.exists('./test_log.txt'):
        os.remove('./test_log.txt')
    shell_logger("./test_log.txt")
    if not os.path.exists('./test_log.txt'):
        assert False

    if not len(open('./test_log.txt', 'rb').read()) > 0:
        assert False

    os.remove('./test_log.txt')


if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:46:10.839546
# Unit test for function shell_logger
def test_shell_logger():
    res = True
    if sys.platform == 'win32':
        res = False
    else:
        pid = os.fork()
        if pid == 0:
            shell_logger('./shell_logger.log')
            sys.exit(0)
        else:
            os.waitpid(pid, 0)
            res = os.path.isfile('./shell_logger.log')
    return res

if __name__ == '__main__':
    assert test_shell_logger() is True
    print('Everything is ok')

# Generated at 2022-06-22 00:46:11.769163
# Unit test for function shell_logger
def test_shell_logger():
    assert shell_logger('test.txt') == 0

# Generated at 2022-06-22 00:46:15.493358
# Unit test for function shell_logger
def test_shell_logger():
    # We can test only that function doesn't fail without creating and
    # cleaning up temporary files.
    from tempfile import NamedTemporaryFile
    out = NamedTemporaryFile(prefix='ttyrec_shell_logger_')
    shell_logger(out.name)

# Generated at 2022-06-22 00:46:22.786622
# Unit test for function shell_logger
def test_shell_logger():
    outputs = set([])
    for i in range(100):
        test_file = 'test%d.txt' % i
        shell_logger(test_file)
        outputs.add(test_file)

    for output in outputs:
        with open(output) as f:
            lines = f.readlines()
            assert lines , 'Shell logger failed to log to ' + output
            assert lines[0] == 'test\n', 'Shell logger fails to log user input to ' + output

    for output in outputs:
        os.remove(output)

# Generated at 2022-06-22 00:46:33.598835
# Unit test for function shell_logger
def test_shell_logger():
    """Test shell logger"""
    tmpfile = 'tmp.shell'

    try:
        with open(tmpfile, 'wb') as f:
            f.write(b'\x00' * const.LOG_SIZE_IN_BYTES)
            buffer = mmap.mmap(f.fileno(), const.LOG_SIZE_IN_BYTES,
                mmap.MAP_SHARED, mmap.PROT_WRITE)

        with open('/dev/null', 'wb') as f:
            pid = os.fork()
            if not pid:
                os.environ['SHELL'] = '/bin/sh'
                shell_logger(tmpfile)
            os.waitpid(pid, 0)
    finally:
        os.remove(tmpfile)

# Generated at 2022-06-22 00:46:38.137573
# Unit test for function shell_logger
def test_shell_logger():
    import os
    import shutil
    from .. import const
    from ..scripts import shell_logger
    import subprocess

    TEST_FILE = '__test_shell_logger_file'

    def create_empty_file(path):
        open(path, 'w').close()

    def init():
        create_empty_file(TEST_FILE)

    def cleanup():
        if os.path.exists(TEST_FILE):
            os.remove(TEST_FILE)

    def check_file_size(path, size):
        assert os.stat(path).st_size == size

    def test_log_bigger_than_memory(monkeypatch):
        init()
        monkeypatch.setattr(const, 'LOG_SIZE_IN_BYTES', 1024)

# Generated at 2022-06-22 00:47:43.466424
# Unit test for function shell_logger
def test_shell_logger():
    shell_logger('/tmp/test_shell.log')

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:47:47.246647
# Unit test for function shell_logger
def test_shell_logger():
    file = tempfile.NamedTemporaryFile(delete=False)
    shell_logger(file.name)

if __name__ == '__main__':
    test_shell_logger()

# Generated at 2022-06-22 00:47:47.852783
# Unit test for function shell_logger
def test_shell_logger():
    assert False

# Generated at 2022-06-22 00:47:48.435031
# Unit test for function shell_logger
def test_shell_logger():
    pass

# Generated at 2022-06-22 00:47:54.137831
# Unit test for function shell_logger
def test_shell_logger():
    """Testing shell_logger function"""
    test_path = "/tmp/test_log.txt"
    shell_logger(test_path)
    if os.path.exists(test_path):
        os.remove(test_path)
        logs.info(test_path + " is removed")
    else:
        logs.error(test_path + " is not created")
        sys.exit(1)