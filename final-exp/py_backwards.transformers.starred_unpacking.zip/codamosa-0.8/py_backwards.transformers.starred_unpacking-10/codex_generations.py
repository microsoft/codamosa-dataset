

# Generated at 2022-06-12 04:02:06.207128
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .py_to_py.test_transforms import to_source
    from .py_to_py.test_transforms import transform_test_template

    def test_transform(src: str) -> str:
        tree = transform_test_template(src, StarredUnpackingTransformer)
        return to_source(tree)

    assert test_transform('[2, 1, *range(10)]') == '[2, 1] + list(range(10))'
    assert test_transform('[2, *range(10), 1]') == '[2] + list(range(10)) + [1]'
    assert test_transform('[2]') == '[2]'

# Generated at 2022-06-12 04:02:07.936528
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print()
    print(StarredUnpackingTransformer)
    print()
test_StarredUnpackingTransformer()

# Generated at 2022-06-12 04:02:16.183988
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class X(StarredUnpackingTransformer):
        def _split_by_starred(self, xs):
            return xs

        def _prepare_lists(self, xs):
            return xs

        def _merge_lists(self, xs):
            return xs

        def _to_sum_of_lists(self, xs):
            return xs

    node = ast.parse('print(1, *[2,3], *[2,3])')
    expected = '\n'.join([
        'def __call__():',
        '    print(*[1, [2], [3], [2], [3]])',
    ])
    print(node)
    print()
    X().visit(node)
    print(node)
    print()

# Generated at 2022-06-12 04:02:24.058329
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    code = """
    f(1, *range(3), 4, *range(5, 7), 8)
    """
    expected = """
    f(*(list(range(3)) + list(range(5, 7))))
    """

    result = ast.fix_missing_locations(transformer.visit(ast.parse(code)))
    expected = ast.fix_missing_locations(ast.parse(expected))
    assert ast.dump(result) == ast.dump(expected), ast.dump(result)

# Generated at 2022-06-12 04:02:34.425694
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .util import dump_tree
    import astor

    class DummyTree(BaseNodeTransformer):
        target = (3, 0)

        def __init__(self, input_code: str):
            super().__init__()
            self._tree = astor.parse_file(input_code)

        def get_tree(self) -> ast.AST:
            return self._tree

        def set_tree(self, t: ast.AST) -> None:
            self._tree = t

    code = """
    [2, *range(10), 1]
    """
    dt = DummyTree(code)
    assert isinstance(dt, DummyTree)
    assert isinstance(dt.get_tree(), ast.Module)
    StarredUnpackingTransformer().visit

# Generated at 2022-06-12 04:02:41.008396
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Testing constructor for class StarredUnpackingTransformer"""
    tree = """
        print(*range(1), *range(3))
        """
    ast_tree = ast.parse(tree)
    StarredUnpackingTransformer().visit(ast_tree)
    assert_code_equal(tree, 'print(*(list(range(1)) + list(range(3))))')

    tree = """
        print(*range(1), 2, *range(3), 3)
        """
    ast_tree = ast.parse(tree)
    StarredUnpackingTransformer().visit(ast_tree)
    assert_code_equal(tree, 'print(*(list(range(1)) + [2] + list(range(3)) + [3]))')


# Generated at 2022-06-12 04:02:49.136431
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import assert_equal_ast, parse_ast
    st = StarredUnpackingTransformer()

    assert_equal_ast(
        st.visit(parse_ast('print(*range(3), 1, *range(2))')),
        parse_ast('print(*(list(range(3)) + [1] + list(range(2))))')
    )
    assert_equal_ast(
        st.visit(parse_ast('print(*range(5))')),
        parse_ast('print(*list(range(5)))')
    )
    assert_equal_ast(
        st.visit(parse_ast('print(2, 3, 4, *range(5))')),
        parse_ast('print(*(list([2, 3, 4]) + list(range(5))))')
    )


# Generated at 2022-06-12 04:03:00.890661
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_input = ast.parse("print(*range(10), *range(10))")

# Generated at 2022-06-12 04:03:07.375123
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .sample_ast import from_str, to_str
    from .transformer_test_case import TransformerTestCase

    test_cases = [
        ("print(*range(1), *range(3))",
         "print(*(list(range(1)) + list(range(3))))",
         ),
    ]

    transformed = TransformerTestCase.run_transform(StarredUnpackingTransformer, test_cases)
    assert transformed == [to_str(from_str(result)) for _, result in test_cases]


# Generated at 2022-06-12 04:03:12.723804
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
    [2, *range(10), 1]
    """

    expected = """
    [2] + list(range(10)) + [1]
    """

    module = ast.parse(source, filename='<unknown>')
    module = StarredUnpackingTransformer().visit(module)
    module = Compiler().ast_to_source(module)

    assert module == expected



# Generated at 2022-06-12 04:03:26.149822
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_helpers import ast_to_string
    from .ast_helpers import ast_normalized

    code = """
    print(*range(1), *range(3))
    print(*(2, 3, *range(4)))
    """

    expected = """
    print(*(list(range(1)) + list(range(3))))
    print(*(list(range(4)) + [2, 3]))
    """

    tr = StarredUnpackingTransformer()
    tr.visit_module(ast.parse(code))
    assert ast_normalized(ast_to_string(tr._module)) == ast_normalized(expected)



# Generated at 2022-06-12 04:03:33.400886
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = ast.parse('[*range(1), 2, *range(3)]').body[0]
    result = StarredUnpackingTransformer().visit(stmt)
    assert isinstance(result, ast.List)
    assert list(result.elts) == [ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                            args=[ast.Num(n=1)], keywords=[])),
                                 ast.Num(n=2),
                                 ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                            args=[ast.Num(n=3)], keywords=[]))]
    stmt = ast.parse('print(1, *range(3))').body[0]
    result = StarredUnpackingTransformer().vis

# Generated at 2022-06-12 04:03:40.856261
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    example_tree = ast.parse("x=[2, *range(10), 1]; print(*range(1), *range(3))")
    example_tree_after_transform = StarredUnpackingTransformer().visit(example_tree)
    expected_tree = ast.parse("x=[2] + list(range(10)) + [1]; print(*(list(range(1)) + list(range(3))))")
    assert astor.to_source(example_tree_after_transform) == astor.to_source(expected_tree)

# Generated at 2022-06-12 04:03:47.517147
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    expected=ast.parse("print(*(list(range(1)) + list(range(3))))")
    expected=StarredUnpackingTransformer(expected).visit(expected)
    node=ast.parse("print(*range(1), *range(3))")
    actual=StarredUnpackingTransformer(node).visit(node)
    assert expected == actual


# Generated at 2022-06-12 04:03:48.467164
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:55.388119
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as typed_ast
    from .ast_builder import ASTBuilder

    ast_builder = ASTBuilder()
    sut = StarredUnpackingTransformer()

    source_ast = typed_ast.parse("""[2, *range(10), 1]""")
    sut.visit(source_ast)

    expected_ast = ast_builder.build("""[2] + list(range(10)) + [1]""")

    assert typed_ast.dump(source_ast) == typed_ast.dump(expected_ast)

# Generated at 2022-06-12 04:04:02.054803
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .type_aliases import NodeTest
    from .type_aliases import StringTest
    assert NodeTest(
        node=ast.List(elts=[], ctx=ast.Load()),
        string='''
                List(
                    elts=[], ctx=Load())''',
        transformer=StarredUnpackingTransformer(),
        expected_node=ast.List(elts=[], ctx=ast.Load()),
        expected_string='''
                List(
                    elts=[], ctx=Load())''')


# Generated at 2022-06-12 04:04:11.686834
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer(3, 4)
    ret = t.visit(ast.parse("[2, *range(10), 1]"))
    ret = ast.fix_missing_locations(ret)
    assert isinstance(ret, ast.Module)
    assert len(ret.body) == 1
    assert isinstance(ret.body[0], ast.Expr)
    assert isinstance(ret.body[0].value, ast.BinOp)
    assert isinstance(ret.body[0].value.right, ast.List)
    assert len(ret.body[0].value.right.elts) == 1
    assert isinstance(ret.body[0].value.right.elts[0], ast.Num)
    assert ret.body[0].value.right.elts[0].n == 1

# Generated at 2022-06-12 04:04:18.845136
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from pybelt.decorators import post_visit
    from ...helpers import get_ast_from_source

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    @post_visit
    class StarredUnpackingTransformerTest(StarredUnpackingTransformer):
        """Tester."""

    transformed = get_ast_from_source(source)
    StarredUnpackingTransformerTest().visit(transformed)

    assert ast.dump(transformed) == expected


# Generated at 2022-06-12 04:04:23.719453
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')  # type: ast.List

    expected = ast.parse('[2] + list(range(10)) + [1]')
    actual = StarredUnpackingTransformer(mode=None).visit(node)

    assert ast.dump(expected, annotate_fields=False) == ast.dump(actual, annotate_fields=False)


# Generated at 2022-06-12 04:04:28.235286
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[1, *range(5), 2]')
    StarredUnpackingTransformer().visit(tree)
    assert str(tree) == '[1, 3 + list(range(5)), 2]'

# Generated at 2022-06-12 04:04:37.072130
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    t.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-12 04:04:45.450033
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..compile import UnitCompiler

    code = "[2, *range(10), 1]"
    mod = ast.parse(code)
    compiler = UnitCompiler(mod)
    compiler.compile(StarredUnpackingTransformer)
    assert compiler.to_source() == "[2] + list(range(10)) + [1]"

    code = "[1, *range(10), 2]"
    mod = ast.parse(code)
    compiler = UnitCompiler(mod)
    compiler.compile(StarredUnpackingTransformer)
    assert compiler.to_source() == "[1] + list(range(10)) + [2]"

    code = "[2, *range(10), 1, 3, 4]"
    mod = ast.parse(code)
    compiler = UnitCompiler(mod)

# Generated at 2022-06-12 04:04:55.501803
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert list(StarredUnpackingTransformer._split_by_starred([
        ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=1)], keywords=[]),
        ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=3)], keywords=[])),
    ])) == [
        [ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=1)], keywords=[])],
        ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=3)], keywords=[]))
    ]


# Generated at 2022-06-12 04:05:05.854813
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""
    # Case when not starred.
    code = "print(1, 2, 3, 4)"
    expected = code
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected

    # Case when starred.
    code = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected

    # Case when starred without whitespaces.

# Generated at 2022-06-12 04:05:12.332521
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source_code = """
        print(1, 2, *list(range(10)))"""
    expected = """
        print(*(args + list(range(10))))"""
    tree = ast.parse(source_code)
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(tree)
    print(ast.dump(transformed))
    assert ast.dump(transformed) == expected


# Generated at 2022-06-12 04:05:17.961606
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .transformer import UnitTestTransformer

    transformer = StarredUnpackingTransformer()
    transformed_ast = transformer.visit(
        ast.parse(
            'print(*range(1), *(0, ), *range(3))',
            mode='exec'
        )
    )
    tt = UnitTestTransformer()
    tt.visit(transformed_ast)

# Generated at 2022-06-12 04:05:22.902244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    stmt = ast.parse('[2, *range(10), 1]')
    assertion = ast.parse('[2] + list(range(10)) + [1]')
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(stmt)
    print(ast.unparse(result))
    print(ast.unparse(assertion))
    assert result == assertion


# Generated at 2022-06-12 04:05:30.064822
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test for method visit_Call() of class `StarredUnpackingTransformer`."""
    from ast_analyzer.rewriter import Rewriter
    code = "print(*range(1), *range(3))"
    tree = ast.parse(code)
    rewriter = Rewriter(tree, StarredUnpackingTransformer)
    result = rewriter.get_new_code()

    expected = "print(*(list(range(1)) + list(range(3))))"
    assert result == expected


# Generated at 2022-06-12 04:05:35.830357
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_code = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """
    expected_code = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    """
    expected_result = ast.parse(expected_code)
    actual_result = StarredUnpackingTransformer().visit(ast.parse(input_code))
    assert ast.dump(expected_result) == ast.dump(actual_result)

# Generated at 2022-06-12 04:05:39.178031
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:05:44.091028
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    result = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:05:45.733034
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)



# Generated at 2022-06-12 04:05:55.380170
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import copy
    from .util import to_source
    from .util import StatementTest
    from xotl.tools.xparser import parse

    def test(self):
        tree = parse(self.input, mode='eval', return_type='ast')
        trans = StarredUnpackingTransformer()
        transformed = trans.visit(copy.deepcopy(tree))

        source = to_source(transformed)
        self.assertEqual(source, self.expected)


# Generated at 2022-06-12 04:05:56.310566
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-12 04:06:05.325294
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.dump(ast.parse('1'), annotate_fields=False) == 'Module(body=[Expr(value=Num(n=1))])'  # noqa

    star = StarredUnpackingTransformer('')
    star.visit(ast.parse('[2, *range(10), 1]'))
    assert star._tree_changed
    assert ast.dump(star.tree, annotate_fields=False) == 'Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[])))])'  # noqa

# Generated at 2022-06-12 04:06:14.637116
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class DummyVisitor(ast.NodeVisitor):
        def visit(self, node: ast.AST) -> None:
            print(type(node))
            super().visit(node)

    tr = StarredUnpackingTransformer()
    tr.visit(ast.parse("[2, *range(10), 1]"))
    tr.visit(ast.parse("f(*[1, 2, 3])"))
    tr.visit(ast.parse("f(*[1, 2, 3], *d, 4)"))
    v = DummyVisitor()
    v.visit(tr.tree)
    assert v.visit.__code__ is not StarredUnpackingTransformer.visit.__code__
    assert v.visit.__code__ is tr.visit.__code__


# Generated at 2022-06-12 04:06:21.862473
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from lib_py_back.parsing.utils import ast_parse

    t = StarredUnpackingTransformer()
    sample = """print(1, *range(1), *range(2))"""
    expected = """print(*(list(range(1)) + list(range(2))))"""
    n = ast_parse(sample)
    n = t.visit(n)
    assert ast.dump(n) == expected
    return True


# Generated at 2022-06-12 04:06:29.633682
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import do_test

    def test_List(node: ast.List, expected: ast.AST) -> None:
        transformer = StarredUnpackingTransformer()
        actual = transformer.visit(node)
        assert expected == actual


# Generated at 2022-06-12 04:06:38.804992
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert str(ast.parse("[2, *range(10), 1]").body[0]) == str(s.visit(ast.parse("[2, *range(10), 1]").body[0]))
    assert str(ast.parse("print(*range(1), *range(3))").body[0]) == str(s.visit(ast.parse("print(*range(1), *range(3))").body[0]))
    assert str(ast.parse("print(1, 2, (3, 4), 5)").body[0]) == str(s.visit(ast.parse("print(1, 2, (3, 4), 5)").body[0]))


if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-12 04:06:51.209255
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = [2, *range(10), 1]
    result = StarredUnpackingTransformer().visit(ast.parse(str(x)))


# Generated at 2022-06-12 04:06:54.932420
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
    """.strip()
    expected = """
print(*(list(range(1)) + list(range(3))))
    """.strip()

    assert parse(source).body[0].value == parse(expected)



# Generated at 2022-06-12 04:06:59.476807
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse
    
    code = """
        print(*range(10))
    """
    expected = """
        print(*(list(range(10))))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    result = unparse(tree)
    assert_equals(expected, result)
    

# Generated at 2022-06-12 04:07:08.793597
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TreeNode:
        pass

    # Examples of call expression
    origin_call_expr_1 = ast.Call(func=ast.Name(id='print'), args=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range')), ast.Num(n=1)], keywords=[])
    origin_call_expr_2 = ast.Call(func=ast.Name(id='print'), args=[ast.Num(n=2), ast.Num(n=1), ast.Starred(value=ast.Name(id='range'))], keywords=[])
    origin_call_expr_3 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range'))], keywords=[])

# Generated at 2022-06-12 04:07:17.610493
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse
    from . import typed_ast_pprint_unparse

    tests = [
        ('print(1, *range(2), 3)', 'print(*(list([1]) + list(range(2)) + [3]))'),
        ('print(*range(2), 3)', 'print(*(list(range(2)) + [3]))'),
        ('print(*range(2), *range(3))', 'print(*(list(range(2)) + list(range(3))))'),
    ]

    for code, expected in tests:
        module = parse(code)
        result = typed_ast_pprint_unparse(module)
        assert result == expected



# Generated at 2022-06-12 04:07:27.849424
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class test_class:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
    test_case = test_class()
    assert (test_case.a  == 1), "test_StarredUnpackingTransformer - test_case class failed"
    assert (test_case.b  == 2), "test_StarredUnpackingTransformer - test_case class failed"
    assert (test_case.c  == 3), "test_StarredUnpackingTransformer - test_case class failed"
    assert (test_case.d  == 4), "test_StarredUnpackingTransformer - test_case class failed"

# Generated at 2022-06-12 04:07:37.214395
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer
    assert t('[2, *range(10), 1]').result == '[2] + list(range(10)) + [1]'
    assert t('list(*range(10))').result == 'list(range(10))'
    assert t('list(*range(10), *range(3))').result == 'list(range(10) + range(3))'
    assert t('list(range(10), *range(3))').result == 'list(range(10)) + list(range(3))'
    assert t('list(range(10), *range(3), *range(4))').result == 'list(range(10)) + list(range(3) + range(4))'

# Generated at 2022-06-12 04:07:39.061908
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]").body[0]).body == "[2, *(list(range(10))), 1]"



# Generated at 2022-06-12 04:07:47.200555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """unittest for method visit_List of class StarredUnpackingTransformer"""
    from .compile import compile_to_ast
    from .transformers import TransformerList

    source = """
        [2, *range(10), 1]
    """
    expected = """
    [2] + list(range(10)) + [1]
    """
    transformers = TransformerList(StarredUnpackingTransformer)
    node = compile_to_ast(source)
    node = transformers.visit(node)
    result = compile_to_ast(expected)
    assert node == result
"""Unit test for method visit_Call of class StarredUnpackingTransformer"""


# Generated at 2022-06-12 04:07:51.162079
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    expected = ast.parse("a + [2] + list(range(10)) + [1]")
    node = ast.parse("a + [2, *range(10), 1]")
    actual = transformer.visit(node)
    assert ast_equal(actual, expected)



# Generated at 2022-06-12 04:08:11.313464
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    Test that visit_Call function of class StarredUnpackingTransformer correctly convert list of arguments to sum of lists.
    """
    original = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    tested_instance = StarredUnpackingTransformer()
    transformed = tested_instance.visit(original)
    assert ast.dump(transformed) == ast.dump(expected)


# Generated at 2022-06-12 04:08:17.444185
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .tools import assert_code_equal, assert_tree_equal

    assert_code_equal(
        code1 = '[2, *range(10), 1]',
        code2 = '[2] + list(range(10)) + [1]',
        transformer = StarredUnpackingTransformer()
    )

    assert_code_equal(
        code1 = 'print(*range(1), *range(3))',
        code2 = 'print(*(list(range(1)) + list(range(3))))',
        transformer = StarredUnpackingTransformer()
    )

# Generated at 2022-06-12 04:08:26.180171
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(context=None)._split_by_starred([]) == []
    assert StarredUnpackingTransformer(context=None)._split_by_starred([ast.Starred(value=ast.Name(id='x'))]) == [
        [], ast.Starred(value=ast.Name(id='x')), []
    ]


# Generated at 2022-06-12 04:08:31.310352
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = 'print([2, *range(10), 1])'

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)

    assert code not in str(tree)
    assert 'list(range(10))' in str(tree)
    assert '+ [' not in str(tree)


# Generated at 2022-06-12 04:08:34.555208
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer

    s = StarredUnpackingTransformer(target=(3,4))
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert isinstance(s, StarredUnpackingTransformer)
    assert s


# Generated at 2022-06-12 04:08:43.198762
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    old_list = ast.List(elts=[ast.Num(n=2), ast.Starred(
        value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])
    new_list = ast.List(elts=[ast.Num(n=2), ast.Call(
        func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[]), ast.Num(n=1)])
    assert transformer.visit(old_list) == new_list


# Generated at 2022-06-12 04:08:48.067455
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    node = ast.parse('sum(range(5), range(5))')
    expected = 'sum(list(range(5)) + list(range(5)))'
    result: ast.Call = sut.visit(node.body[0].value)
    assert astor.to_source(result) == expected
    assert sut.has_changed() == True


# Generated at 2022-06-12 04:08:52.543924
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='x')), ast.Num(n=2)], ctx=ast.Load())
    print(ast.dump(x))
    StarredUnpackingTransformer().visit(x)
    print(ast.dump(x))

# Generated at 2022-06-12 04:08:53.984039
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None


# Generated at 2022-06-12 04:09:02.359753
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        ast.Name('print', ast.Load()),
        [ast.Starred(ast.Call(
            ast.Name('range', ast.Load()),
            [ast.Num(1)],
            []), ast.Load())],
        [])
    result = StarredUnpackingTransformer.run(node)
    expected = ast.Call(
        ast.Name('print', ast.Load()),
        [ast.Starred(ast.List(
            [ast.Call(
                ast.Name('range', ast.Load()),
                [ast.Num(1)],
                [])],
            []))],
        [])
    assert result == expected

# Generated at 2022-06-12 04:09:32.385327
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), *range(3))'
    expected = textwrap.dedent("""
    print(*(list(range(1)) + list(range(3))))
    """)
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True
    actual = to_source(tree)
    assert (actual == expected)


# Generated at 2022-06-12 04:09:37.202898
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""
    start_code = """foo(2, *range(10), 1)"""
    expected_code = """foo(*[2] + list(range(10)) + [1])"""
    # Second result is the same as the first
    actual_code = StarredUnpackingTransformer().visit(ast.parse(start_code)).ast_repr()
    assert expected_code == actual_code


# Generated at 2022-06-12 04:09:39.299311
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .remove_print import RemovePrintTransformer

    star_transformer = StarredUnpackingTransformer()
    remove_print_transformer = RemovePrintTransformer()


# Generated at 2022-06-12 04:09:40.705804
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Foo(object):
        pass
    assert not isinstance(Foo(), ast.Call)


# Generated at 2022-06-12 04:09:44.986517
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected_code = "a = [1, 2, 3] + list(range(10)) + [1]"
    node = ast.parse(expected_code)
    modified_node = StarredUnpackingTransformer().visit(node)
    modified_code = ast.unparse(modified_node)
    assert expected_code == modified_code


# Generated at 2022-06-12 04:09:46.367131
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert isinstance(t, StarredUnpackingTransformer)


# Generated at 2022-06-12 04:09:53.550841
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformer
    source = """
street = Street()
a = 10
print(*street.names, sep=', ', end='\\n', flush=False)
"""
    expected = """
street = Street()
a = 10
print(*(street.names + [sep=', ', end='\\n', flush=False]))
"""
    node = ast.parse(source)
    node = StarredUnpackingTransformer().visit(node)
    result = compile(node, '<stdin>', mode='exec')
    ns = {}
    exec(result, ns, ns)
    assert ns['a'] == 10
    assert ns['street'].names == [
        'Broadway', 'Lombard Street']
    ns['street'].logs.clear()  # clear logs

# Generated at 2022-06-12 04:10:02.479910
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[]'
    expected = '[]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

    source = '[1]'
    expected = '[1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

    source = '[1, *range(3)]'
    expected = 'list([1]) + list(range(3))'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

    source = 'list([])'
    expected = 'list([])'
    tree = ast.parse(source)

# Generated at 2022-06-12 04:10:05.070888
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(
        ast.parse('[2, *range(10), 1]')).body[0].value == \
        ast.parse('[2] + list(range(10)) + [1]').body[0].value



# Generated at 2022-06-12 04:10:10.614295
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_ = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()),
              ast.Starred(value=ast.Name(id='range'), ctx=ast.Load())],
        keywords=[])
    node = StarredUnpackingTransformer().visit(node_)
    assert astor.to_source(node).strip() == (
        "print(*(list(range) + list(range)))"
    )



# Generated at 2022-06-12 04:11:15.050257
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    actual = StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]"))
    expected = ast.parse("[2] + list(range(10)) + [1]")

    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-12 04:11:18.260808
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = dedent("""
    [2, *range(10), 1]
    """)
    exp = dedent("""
    [2] + list(range(10)) + [1]
    """)
    assert transform(src, StarredUnpackingTransformer) == exp



# Generated at 2022-06-12 04:11:22.986782
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import literal_eval
    from . import to_source

    for code in [
            "[1, 2, *range(3), 4, 5, 6]",
            "[*range(3), *range(3), 1]",
            "[None]",
    ]:
        node1 = literal_eval(code)
        node2 = StarredUnpackingTransformer().run(node1)
        assert to_source(node1) == to_source(node2)



# Generated at 2022-06-12 04:11:24.341741
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    assert repr(sut) == "<StarredUnpackingTransformer>"

# Generated at 2022-06-12 04:11:26.545102
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_transfom import create_ast

# Generated at 2022-06-12 04:11:33.829121
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert check_ast(ast.parse('[2, *range(10), 1]'), StarredUnpackingTransformer)
    assert check_ast(ast.parse('[*range(10), *range(10), 1]'), StarredUnpackingTransformer)
    assert check_ast(ast.parse('[*range(10), 1, 2, *range(10), 1]'), StarredUnpackingTransformer)
    assert check_ast(ast.parse('print(1, 2, *range(10), 1)'), StarredUnpackingTransformer)
    assert check_ast(ast.parse('print(*range(10), 1, 2, *range(10), 1)'), StarredUnpackingTransformer)

# Generated at 2022-06-12 04:11:35.593350
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)
    StarredUnpackingTransformer()


# Generated at 2022-06-12 04:11:45.120837
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    visitor = StarredUnpackingTransformer()
    test_in_str = "[1, 2, *[3], 4, *[5, 6]]"
    test_in_ast = ast.parse(test_in_str)
    test_out_ast = visitor.visit(test_in_ast)
    test_out_str = astor.to_source(test_out_ast)

# Generated at 2022-06-12 04:11:52.919166
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import unittest
    import sys

    class TestStarredUnpackingTransformer(unittest.TestCase):
        pass

    def generate_test_method(node_1, node_2):
        node_1 = ast.parse(node_1).body[0]
        node_2 = ast.parse(node_2).body[0].value
        def test(self):
            transformer = StarredUnpackingTransformer(verbose=3)
            result = transformer.visit(node_1)
            self.assertTrue(transformer._tree_changed)
            self.assertEqual(node_2, result)
        return test
