

# Generated at 2022-06-12 04:01:54.834865
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .unittest_tools import assert_nodes_equal
    from .unittest_tools import assert_code_equal
    from .unittest_tools import get_ast

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(get_ast(source))
    assert_nodes_equal(result, get_ast(expected))
    assert_code_equal(result, expected)
    assert transformer._tree_changed



# Generated at 2022-06-12 04:02:06.064897
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    star_transformer = StarredUnpackingTransformer()
    class_ast_node = ast.ClassDef(name='TestClassStarredUnpackingList',
                                  bases=[],
                                  keywords=[],
                                  body=[],
                                  decorator_list=[])
    

# Generated at 2022-06-12 04:02:11.216432
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    tree = ast.parse('func(a, b, c, *(d, e), f)')
    star = StarredUnpackingTransformer()
    star.visit(tree)
    s = astor.to_source(tree)
    assert s == 'func(*([a, b, c] + (list(d, e) + [f])))\n'


# Generated at 2022-06-12 04:02:17.552737
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    from typed_ast import parse
    from .ast_transformer_test_tools import assert_result

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = parse(code)
    result = StarredUnpackingTransformer().visit(tree)
    assert_result(result, expected)

    code = "[2, *range(10), 1] + [6, *range(5), 3, 1]"
    expected = "[2] + list(range(10)) + [1] + [6] + list(range(5)) + [3, 1]"
    tree = parse(code)
    result = StarredUnpackingTransformer().visit(tree)
    assert_result(result, expected)


# Generated at 2022-06-12 04:02:18.547903
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:02:27.204780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ministd.compat import NamedTemporaryFile
    from ministd.transformer.common import StdTransformer
    from ministd.transformer.print import PrintTransformer

    print('\ntest_print_PrintTransformer_visit_Call')
    test_code = '''
print(*[3, 4], *[5, 6])
print(*[3, 4], 5)
print(3, *[4, 5])
print(3, 4, *[5, 6])
    '''

# Generated at 2022-06-12 04:02:31.916059
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    nodes = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    actual = StarredUnpackingTransformer().visit(nodes)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-12 04:02:40.181514
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import unittest
    import astor

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_to_sum_of_lists(self):
            code = "[2, *range(10), 1]"
            expected = "[2] + list(range(10)) + [1]"
            node = ast.parse(code)
            StarredUnpackingTransformer().visit(node)
            self.assertEqual(expected, astor.to_source(node))

    unittest.main(module="lib2to3.fixes.test_starred_unpacking", exit=False)

# Code for testing (up to date)
# import unittest
# import astor
#
# class TestStarredUnpackingTransformer(unittest.TestCase):
#     def test_to_sum_

# Generated at 2022-06-12 04:02:44.355507
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print(ast.dump(ast.parse('''
        [2, *range(10), 1]
    ''')))
    print(ast.dump(StarredUnpackingTransformer().visit(ast.parse('''
        [2, *range(10), 1]
    '''))))



# Generated at 2022-06-12 04:02:50.659706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(code):
        node = ast.parse(dedent(code))
        StarredUnpackingTransformer().visit(node)
        return node

    node = test("""
        f(a, b, c)
    """)
    assert_code_equal("""
        f(*[a, b, c])
    """, node)

    node = test("""
        f(*x)
    """)
    assert_code_equal("""
        f(*x)
    """, node)

    node = test("""
        f(*x, *y)
    """)
    assert_code_equal("""
        f(*(list(x) + list(y)))
    """, node)

    node = test("""
        f(*x, *y, **z)
    """)
    assert_code

# Generated at 2022-06-12 04:03:04.623410
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # assert compile(mod, '<test>', 'exec')
    xs = ast.parse("""
[2, *range(10), 1]
""")
    sut = StarredUnpackingTransformer()
    res = sut.visit(xs)

    print(ast.dump(xs))
    print(ast.dump(res))

    assert res.body[0].value == ast.BinOp(ast.Num(2), ast.Add(), ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Num(10)], keywords=[])], keywords=[]))



# Generated at 2022-06-12 04:03:12.988104
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # try to unstar arguments via StarredUnpackingTransformer
    expected = ast.parse("print(a, 'test', *args, b)")
    example = ast.parse("print(a, 'test', *args, b)")
    result = StarredUnpackingTransformer().visit(example)
    assert ast.dump(result) == ast.dump(expected)
    
    # try to unstar arguments via StarredUnpackingTransformer
    expected = ast.parse("a = [b, *args, c]")
    example = ast.parse("a = [b, *args, c]")
    result = StarredUnpackingTransformer().visit(example)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 04:03:18.682817
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_program = """
foo(*range(10), *range(1), *range(2))
"""
    expected_program = """
foo(*(range(10) + range(1) + range(2)))
"""
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast.parse(input_program))
    source = ast.unparse(result)
    assert source == expected_program


# Generated at 2022-06-12 04:03:24.702732
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]", mode="eval")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "[2] + list(range(10)) + [1]"

    tree = ast.parse("range(10)", mode="eval")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "range(10)"


# Generated at 2022-06-12 04:03:32.849544
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class DummyTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'print':
                assert len(node.args) == 1
                assert len(node.keywords) == 0

                assert isinstance(node.args[0], ast.Starred)
                star = node.args[0]
                assert isinstance(star.value, ast.BinOp)
                assert isinstance(star.value.op, ast.Add)
                assert isinstance(star.value.left, ast.Call)

# Generated at 2022-06-12 04:03:42.159551
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseTreeTransformerTestCase


    class Test(BaseTreeTransformerTestCase):
        transform = StarredUnpackingTransformer
        cases = {
            '[]': '[  ]',
            '[1, *[2, 3]]': "(1 + [2, 3])",
            '[1, 2, 3, *[4, 5]]': "([1, 2, 3] + [4, 5])",
            '[1, 2, *[], 3, 4]': "(1 + [2] + [3, 4])",
            '[*[1], *[2], 3, 4]': "([] + list([1]) + list([2]) + [3, 4])",
        }



# Generated at 2022-06-12 04:03:43.847445
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:53.969416
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("x = (*range(3), 2, *range(4), 1)")
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 04:04:00.018550
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected_code = """\
list([1, 2, 3]) + list([4])
list([1, 2, 3]) + list([4, 5, 6]) + list([7])"""

    test_code = """\
[1, 2, 3, *[4]]
[1, 2, 3, *[4, 5, 6], *[7]]"""

    nodes = ast.parse(test_code)
    result = StarredUnpackingTransformer().visit(nodes)
    result_code = ast.unparse(result, '')
    assert result_code == expected_code


# Generated at 2022-06-12 04:04:03.669155
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    assert expected == compile_snippet(src, StarredUnpackingTransformer)


# Generated at 2022-06-12 04:04:20.878656
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:04:32.036780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if node.func.id == 'print':
                return super().visit_Call(node)

            return node

    node = ast.parse("print(*range(1), *range(2))", filename='<unknown>', mode='eval')
    tree = TestStarredUnpackingTransformer().visit(node)
    result = ast.dump(tree)

# Generated at 2022-06-12 04:04:36.557722
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code_to_transform = "[2, *range(5), 4]"
    tr = StarredUnpackingTransformer()
    res = tr.visit(ast.parse(code_to_transform))
    assert astunparse.unparse(res) == "[2] + list(range(5)) + [4]"


# Generated at 2022-06-12 04:04:39.973569
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[a, *b, c]"
    result = StarredUnpackingTransformer().transform_source(code)
    expected = "[a] + list(b) + [c]"
    assert result == expected



# Generated at 2022-06-12 04:04:46.876127
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    print(*range(1), *range(3))
    print("Hello", *range(2))
    print("Hello", *range(2), end='\n')
    print("Hello", *range(2), "World")
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    print("Hello", *(list(range(2))))
    print("Hello", *(list(range(2))), end='\\n')
    print("Hello", *(list(range(2))), "World")
    """
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    tree_str = ast.dump(tree)
    assert expected == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 04:04:56.772033
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class StarredUnpackingTransformer_mock_generic_visit:
        def __init__(self, args):
            self.args = args
        def method(self, x):
            return x

    class StarredUnpackingTransformer_mock_generic_visit2:
        def method(self, x):
            return x

    class StarredUnpackingTransformer_mock_Starred:
        def __init__(self, id, value):
            self.id = id
            self.value = value

    args = [StarredUnpackingTransformer_mock_Starred('x', 'y'), 'z']

    star = StarredUnpackingTransformer()
    star.generic_visit = StarredUnpackingTransformer_mock_generic_visit(args)
    star.generic_visit2 = StarredUn

# Generated at 2022-06-12 04:05:02.814888
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    source_program = 'print(*range(1), *range(3), end="")'
    expected_program = 'print(*(list(range(1)) + list(range(3))), end="")'
    expected_ast = ast.parse(expected_program)

    StarredUnpackingTransformer(source_program).visit(ast.parse(source_program)) == expected_ast


# Generated at 2022-06-12 04:05:06.512326
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    from . import ast_utils

    code = "[1, *a, 2, *b]"
    tree = ast_utils.parse(code)

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    expected_code = "[1] + list(a) + [2] + list(b)"
    result_code = typed_astunparse.unparse(tree)

    print(code)
    print(result_code)
    assert expected_code == result_code



# Generated at 2022-06-12 04:05:15.864724
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "lst = [2, 3, 4, 1]"
    expected = "[2, 3, 4, 1]"

    tr = StarredUnpackingTransformer()
    result = tr.visit(ast.parse(source))
    assert expected == tr.dump_tree(result)

    source = "lst = [2, *range(10), 1]"
    expected = "lst = [2] + list(range(10)) + [1]"

    tr = StarredUnpackingTransformer()
    result = tr.visit(ast.parse(source))
    assert expected == tr.dump_tree(result)

    source = "lst = [2, *range(10), *range(3), 1]"
    expected = "lst = [2] + list(range(10)) + list(range(3)) + [1]"

# Generated at 2022-06-12 04:05:21.783957
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    code = 'print(1, *range(3, 4), 1)'
    tree = ast.parse(code, mode='exec')
    expected_code = 'print(*(list([1]) + list([3, 4]) + list([1])))'
    result_tree = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(result_tree) == expected_code

test_StarredUnpackingTransformer()

# Generated at 2022-06-12 04:05:36.484103
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    tree1 = ast3.parse(text="foo(bar, *baz, spam)", mode="eval")
    tree2 = ast3.parse(text="[bar, *baz, spam]", mode="eval")
    tree3 = ast3.parse(text="[bar, *baz]", mode="eval")
    tree4 = ast3.parse(text="[*baz, *spam]", mode="eval")
    tree5 = ast3.parse(text="[bar, *baz, *spam]", mode="eval")
    tree6 = ast3.parse(text="[*baz + *spam]", mode="eval")
    tree7 = ast3.parse(text="[bar, *baz + *spam, spam]", mode="eval")

# Generated at 2022-06-12 04:05:43.412562
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    func_str = '[2, *range(10), 1]'
    func_ast = ast.parse(func_str).body[0].value

    transformer = StarredUnpackingTransformer()
    new_ast = transformer.visit(func_ast)
    new_code = compile(new_ast, file=None, mode='eval')

    assert eval(new_code) == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]



# Generated at 2022-06-12 04:05:50.090346
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer"""
    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='l')), ast.Num(n=1)])
    expected_ast = ast.List(elts=[ast.Num(n=2), ast.Num(n=1), ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='l')], keywords=[])])
    tr = StarredUnpackingTransformer()
    tr.visit(node)
    if tr.tree_changed():
        assert ast.dump(node) == ast.dump(expected_ast)



# Generated at 2022-06-12 04:05:59.147069
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10)]').body[0].value
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(node)
    assert isinstance(transformed, ast.BinOp)
    assert transformed.op == ast.Add()

    assert isinstance(transformed.left, ast.List)
    assert transformed.left.elts == [ast.Num(n=2)]
    assert isinstance(transformed.right, ast.Call)
    assert isinstance(transformed.right.func, ast.Name)  # type: ignore
    assert transformed.right.func.id == 'list'  # type: ignore
    assert isinstance(transformed.right.args[0], ast.Call)  # type: ignore

# Generated at 2022-06-12 04:06:03.386870
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    astree = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(astree)
    assert new_tree.body[0].value.op.left.func.id == 'list'


# Generated at 2022-06-12 04:06:10.561902
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .parser import Parser
    parser = Parser()
    transformer = StarredUnpackingTransformer()
    for code in [
            '[2, *range(10), 1]',
            '[1, 2]',
            'range(1, 2)'
    ]:
        assert transformer.is_target(code)
        node = parser.parse(code)
        node = transformer.visit(node)
        assert transformer.is_target(parser.unparse(node))


# Generated at 2022-06-12 04:06:21.062018
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    node = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Num(n=10)],
            keywords=[])),
        ast.Num(n=1)
    ], ctx=ast.Load())
    expected_node = ast.List(elts=[
        ast.Num(n=2),
        ast.List(elts=ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Num(n=10)],
            keywords=[])),
        ast.Num(n=1)
    ], ctx=ast.Load())

# Generated at 2022-06-12 04:06:27.217859
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    from cst2ast.transformer import CJSTransformer

    code = '[2, *range(10), 1]'

    cjs_transformed = CJSTransformer().visit(ast.parse(code))
    starred_unpacked = StarredUnpackingTransformer().visit(cjs_transformed)

    assert(starred_unpacked == ast.parse('[2] + list(range(10)) + [1]').body[0])



# Generated at 2022-06-12 04:06:32.007368
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .astunparse import unparse

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    node = ast.parse(source).body[0]
    node = StarredUnpackingTransformer().visit(node)
    result = unparse(node)
    assert result == expected, result



# Generated at 2022-06-12 04:06:37.642953
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .testing_utils import make_test_env, assert_equal_ast
    from .base import BaseNodeTransformer
    source = '[1, *range(5), 10]'
    expected = '[1, 2, 3, 4, 10]'
    env = make_test_env(source)
    env.update(locals())
    assert_equal_ast(env, expected, BaseNodeTransformer, StarredUnpackingTransformer)
    

# Generated at 2022-06-12 04:06:51.638728
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_list1 = """list(a + b, c, *range(10), d, e)"""
    expected_list1 = """list(a + b, c) + list(range(10)) + list(d, e)"""

    test_list2 = """list(a, *range(10), b)"""
    expected_list2 = """list(a) + list(range(10)) + list(b)"""

    test_list3 = """list(a, b, *range(10), c, *range(15), d)"""
    expected_list3 = """list(a, b) + list(range(10)) + list(c) + list(range(15)) + list(d)"""

    test_list4 = """list(*range(10))"""
    expected_list4 = """list(range(10))"""

# Generated at 2022-06-12 04:07:00.201394
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from textwrap import dedent
    node = ast.parse(dedent("""
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """))

    StarredUnpackingTransformer().visit(node)


# Generated at 2022-06-12 04:07:04.282590
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    new_tree = transformer.visit(tree)  # type: ignore
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert expected == new_tree


# Generated at 2022-06-12 04:07:12.362511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = 'l = [2, *range(10), 1]'
    tree = ast.parse(code)

    assert isinstance(tree.body[0], ast.Assign)
    node = tree.body[0]
    assert len(node.targets) == 1
    assert isinstance(node.targets[0], ast.Name)
    assert isinstance(node.value, ast.List)
    assert len(node.value.elts) == 3

    StarredUnpackingTransformer().visit(tree)

    assert isinstance(tree.body[0].value, ast.BinOp)



# Generated at 2022-06-12 04:07:17.650174
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    code_from = "[1, *range(3), *range(4, 6), 7]"
    code_to = "[1, *(list(range(3)) + list(range(4, 6))), 7]"
    assert transformer.visit(ast.parse(code_from)) == ast.parse(code_to)
    assert transformer.tree_changed == True


# Generated at 2022-06-12 04:07:22.838959
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert compile(tree, filename='', mode='exec') == compile('[2] + list(range(10)) + [1]', filename='', mode='exec')


# Generated at 2022-06-12 04:07:25.704294
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert run_transformer_on_string(StarredUnpackingTransformer, '[2, *range(10), 1]') == '[2] + list(range(10)) + [1]'


# Generated at 2022-06-12 04:07:30.098224
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    node = t.visit(ast.parse("[2, *range(10), 1]"))
    assert isinstance(node.body[0].value.elts[0], ast.Num)
    assert isinstance(node.body[0].value.elts[1], ast.Call)
    assert isinstance(node.body[0].value.elts[2], ast.Num)


# Generated at 2022-06-12 04:07:39.400955
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    NodeTransformer = StarredUnpackingTransformer

    # Test 1: empty list
    t1 = ast.List()
    nt1 = NodeTransformer()
    nt1.visit(t1)

# Generated at 2022-06-12 04:07:48.583207
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.left, ast.List)
    assert tree.body[0].value.left.elts[0].n == 2
    assert isinstance(tree.body[0].value.left.elts[1], ast.Call)
    assert isinstance(tree.body[0].value.right, ast.List)
    assert tree.body[0].value.right.elts[0].n == 1

    tree = ast.parse("[2, *range(10), *range(3)]")
    tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 04:07:58.934326
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("[1, 2, *range(2), 3, 4, 5]")) == \
        ast.parse("([1, 2] + list(range(2) + [3, 4, 5]))")



# Generated at 2022-06-12 04:08:03.889042
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"

    t = StarredUnpackingTransformer()
    tree = ast.parse(code)
    tree = t.visit(tree)

    ref_code = "[2] + list(range(10)) + [1]"
    ref_tree = ast.parse(ref_code)

    assert ast.dump(tree) == ast.dump(ref_tree)



# Generated at 2022-06-12 04:08:12.633922
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # type: () -> None
    """Tests that StarredUnpackingTransformer.visit_List works as expected."""
    node = ast.parse('[1, *[2, 3, 4], 5]').body[0]
    visitor = StarredUnpackingTransformer()
    result = visitor.visit(node)
    assert isinstance(result, ast.Expr) and isinstance(result.value, ast.List)
    assert len(result.value.elts) == 2
    assert isinstance(result.value.elts[0], ast.BinOp)
    assert isinstance(result.value.elts[1], ast.List)
    assert isinstance(result.value.elts[1].elts[0], ast.Num)
    assert visitor.tree_changed



# Generated at 2022-06-12 04:08:21.167203
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:08:30.089359
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ts = StarredUnpackingTransformer()
    l = ast.List(elts=[ast.Str('a'), ast.Starred(value=ast.Str('b')), ast.Str('c')])
    assert ast.dump(ts.visit(l)) == """Module(body=[Expr(value=BinOp(left=List(elts=[Str(s='a')], ctx=Load()), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[List(elts=[Str(s='b')], ctx=Load())], keywords=[]), op=Add(), right=List(elts=[Str(s='c')], ctx=Load()))))])"""


# Generated at 2022-06-12 04:08:37.008984
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Name(id='range')),
        ast.Num(n=1)
    ])
    expected = ast.List(elts=[
        ast.Num(n=2),
        ast.Call(
            ast.Name(id='list'),
            [ast.Name(id='range')],
            [],
            None,
            None
        ),
        ast.Num(n=1)
    ])

    obj = StarredUnpackingTransformer()
    result = obj.visit(node)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:08:43.564964
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
  transformer = StarredUnpackingTransformer()
  node = ast.parse("[2, *range(10), 1]").body[0].value
  transformer.visit(node)

  expected = ast.parse("[2] + list(range(10)) + [1]").body[0].value
  expected = ast.parse("(2) + list(range(10)) + (1)").body[0].value
  assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-12 04:08:50.538019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    @StarredUnpackingTransformer.test_on([
        ast.parse("[2, *range(10), 1]"),
        ast.parse("[2, *range(10), *range(3), 1]"),
        ast.parse("[*range(10), *range(3), 1]"),
        ast.parse("[*range(10)]"),
    ])
    def _(tree):
        # type: (ast.AST) -> ast.List
        assert isinstance(tree, ast.List)
        assert isinstance(tree.elts[0], ast.Name)
        assert isinstance(tree.elts[1], ast.Call)
        assert isinstance(tree.elts[2], ast.Call)

# Generated at 2022-06-12 04:09:00.711341
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:09:05.850019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "def foo(): return [2, *range(10), 1]"
    expected = "def foo(): return [2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)

    assert transformer._tree_changed is True
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-12 04:09:21.143453
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def check(code: str, result: str = None) -> None:
        if result is None:
            result = code

        node = ast.parse(code)
        new_node = StarredUnpackingTransformer(node).visit(node)
        assert ast.dump(node) == ast.dump(ast.parse(result))

    check('[*l[:10], 1]', '[1] + list(l[:10])')
    check('[*l[:10], 1, *[2]]', '[1, 2] + list(l[:10])')
    check('[1, *l[:10], 1, *[2]]', '[1] + list(l[:10]) + [1, 2]')

# Generated at 2022-06-12 04:09:30.286104
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_transformer import transform

    tree = ast.parse("[1, *range(2), 3]").body[0]
    assert isinstance(tree, ast.Expr)
    assert isinstance(tree.value, ast.List)
    tree = StarredUnpackingTransformer().visit(tree)  # type: ignore
    assert transform(tree) == "[1] + list(range(2))+ [3]"

    tree = ast.parse("[*range(2), 3, *range(10)]").body[0]
    assert isinstance(tree, ast.Expr)
    assert isinstance(tree.value, ast.List)
    tree = StarredUnpackingTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-12 04:09:34.484628
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def t(x: ast.List, y: ast.List):
        assert StarredUnpackingTransformer.run(x) == y

    t(ast.parse('[1, 2, *range(10), 10]').body[0].value,
      ast.parse('[1, 2] + list(range(10)) + [10]').body[0].value)



# Generated at 2022-06-12 04:09:41.499287
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert ast.dump(StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]").body[0])) == (
        "Expr(value=BinOp("
            "left=List(elts=[Num(n=2)]), "
            "op=Add(), "
            "right=BinOp("
                "left=Expr(value=Call("
                    "args=[Starred("
                        "value=Name(id='range', ctx=Load()))], "
                    "func=Name(id='list', ctx=Load()), "
                    "keywords=[])), "
                "op=Add(), "
                "right=List(elts=[Num(n=1)]))))"
    )


# Generated at 2022-06-12 04:09:47.157393
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    from .trees import tree1

    tree = ast.parse(tree1)
    StarredUnpackingTransformer().visit(tree)
    expected = """\
a = (1 + 2) + (3 + 4) + (5 + [7, 8, 9] + [6])
a = (1 + 2) + (3 + 4) + (5 + [7, 8, 9] + [6])
"""
    assert unparse(tree) == expected

# Generated at 2022-06-12 04:09:54.328717
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_transformer import trans

    tree, changed = trans(StarredUnpackingTransformer, '''
        [1, *range(10), 2]
    ''')
    assert changed
    assert str(tree) == '[[1] + list(range(10)) + [2]]'

    tree, changed = trans(StarredUnpackingTransformer, '''
        [x, 10, *range(1, 3), *range(3, 6)]
    ''')
    assert changed
    assert str(tree) == '[[x, 10] + list(range(1, 3)) + list(range(3, 6))]'

    tree, changed = trans(StarredUnpackingTransformer, '''
        [1, 2, 3, 4, 5]
    ''')
    assert not changed

# Generated at 2022-06-12 04:10:03.421738
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast_to_exe.ast_processor import ASTProcessor
    from ast_to_exe.utils import dumps

    transformer = StarredUnpackingTransformer()
    processor = ASTProcessor()

    source = '["1", *["2"], *["3", *["4", *["5", *["6"], *["7"]]]]'
    expected = dumps("['1' + list(['2']) + list(['3']) + list(['4']) + list(['5']) + list(['6']) + list(['7'])]")
    tree = ast.parse(source)
    actual = dumps(processor.process(tree, transformer))
    assert expected == actual, 'StarredUnpackingTransformer.visit_List does not work'

    source = '[*[x], 1, 2, 3]'

# Generated at 2022-06-12 04:10:07.659948
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = ast.parse('[2, *range(10), 1]', '<string>', 'eval')
    expected = ast.parse('[2, 1] + list(range(10))', '<string>', 'eval')
    a = StarredUnpackingTransformer().visit(a)
    assert ast.dump(a, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-12 04:10:15.868640
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    ls1 = ast.parse('[2, *range(10), 1]').body[0].value
    ls1_transformed = transformer.visit(ls1)
    assert transformer._tree_changed
    assert ls1_transformed.left.id == 'list'
    assert ls1_transformed.left.args[0].value.func.id == 'range'
    assert isinstance(ls1_transformed.left.args[0].value.args[0].n, int)
    assert ls1_transformed.right.id == 'list'
    assert ls1_transformed.right.args[0].elts[0].n == 2
    ls2 = ast.parse('[2, 1]').body[0].value

# Generated at 2022-06-12 04:10:25.713649
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_data = [
        (
            "[]",
            "[]",
            False
        ),
        (
            "[1]",
            "[1]",
            False
        ),
        (
            "[*[]]",
            "[]",
            True
        ),
        (
            "[*[], []]",
            "[] + []",
            True
        ),
        (
            "[1, *[2, 3]]",
            "[1] + list([2, 3])",
            True
        ),
        (
            "[*[], 1, *[2, 3]]",
            "[] + [] + list([2, 3])",
            True
        ),
    ]
    for before, after, changed in test_data:
        tree = ast.parse(before)

# Generated at 2022-06-12 04:10:46.478778
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
    [1, 2, *range(3), *range(4), 5]
    '''
    expected = '''
    [1, 2] + list(range(3)) + list(range(4)) + [5]
    '''
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)

    assert expected == astunparse.unparse(tree)


# Generated at 2022-06-12 04:10:52.942550
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from python_minifier.minification.call_visitor import CallVisitor
    from python_minifier.ast_compare import compare_ast
    import ast as stdlib_ast

    source = "[2,*range(10),1]"
    expected = stdlib_ast.parse(
        "[2] + list(range(10)) + [1]").body[0].value

    changes = compare_ast(stdlib_ast.parse(source), expected, True)
    CallVisitor().visit(changes)
    StarredUnpackingTransformer(minify=True).visit(changes)
    assert compare_ast(changes, expected, True) == []

# Generated at 2022-06-12 04:10:59.702022
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = textwrap.dedent("""
    l = [2, *range(10), 1]
    """)

    expected = textwrap.dedent("""
    l = ([2] + list(range(10)) + [1])
    """)

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)

    assert expected == astor.to_source(tree)

    # test if it returns a copy
    new_tree = ast.parse(code)
    StarredUnpackingTransformer().visit(new_tree)
    assert astor.to_source(tree) == astor.to_source(new_tree)



# Generated at 2022-06-12 04:11:03.351559
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from src.tests.utils import _transform
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    result = _transform(source, StarredUnpackingTransformer)
    assert result == expected


# Generated at 2022-06-12 04:11:09.606402
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    t = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    t.visit(tree)
    src = astor.to_source(tree)
    assert src == '[2] + list(range(10)) + [1]'

    t = StarredUnpackingTransformer()
    tree = ast.parse('[*[], *[], *[]]')
    t.visit(tree)
    src = astor.to_source(tree)
    assert src == '[] + [] + []'


# Generated at 2022-06-12 04:11:18.021695
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .common import Example
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, Call, Name, List, Add, Expr, AST, BinOp
    before = """
    [2, *range(10), 1]
    """
    after = """
    ([2] + list(range(10)) + [1])
    """
    assert StarredUnpackingTransformer(Example(before)).visit(ast.parse(before)) == ast.parse(after)

# Generated at 2022-06-12 04:11:26.215416
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test to convert list with starred elements to sum of lists."""
    t = StarredUnpackingTransformer()
    node = ast.List(elts=[
        ast.Name(id='a'),
        ast.Starred(value=ast.Name(id='b')),
        ast.Name(id='c'),
        ast.Starred(value=ast.Name(id='d')),
        ast.Name(id='e'),
    ])

# Generated at 2022-06-12 04:11:31.183754
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import L

    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)], ctx=ast.Load())
    assert L(StarredUnpackingTransformer().visit(node)) == L("[2] + list(range(10)) + [1]")


# Generated at 2022-06-12 04:11:38.327544
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compiler.ast import parse
    from .base import NodeTransformerTestCase

    class Test(NodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

    source = "[2, *range(10), 1]"
    tree = parse(source)
    expected_source = "[2] + list(range(10)) + [1]"
    Test.check(source, tree, expected_source)

    source = "[]"
    tree = parse(source)
    expected_source = "[]"
    Test.check(source, tree, expected_source)


# Generated at 2022-06-12 04:11:46.467853
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_List = ast.List(
        elts=[
            ast.Constant(value=2, kind=None),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()),
            ast.Constant(value=1, kind=None)
        ],
        ctx=ast.Load())

    trans = StarredUnpackingTransformer()
    res = trans.visit(node_List)

    expected = ast.List(
        elts=[
            ast.Constant(value=2, kind=None),
        ],
        ctx=ast.Load())

    assert ast.dump(res) == ast.dump(expected)

