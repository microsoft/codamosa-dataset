

# Generated at 2022-06-12 04:01:57.499111
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    lst = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)], ctx=ast.Load())
    res = StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer(), lst)
    assert str(res) == '[2] + list(range(10)) + [1]'

# Generated at 2022-06-12 04:02:08.841047
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def f1():
        f(3, *[2, 1], *[0])

    def f2():
        f(1, *[2, 3], *[4, 5], *[6])

    def f3():
        f(1, *[2, 3], 4, *[5], 6)

    node = ast.parse(textwrap.dedent(inspect.getsource(f1)).strip('\n')).body[0]
    assert type(node) == ast.FunctionDef
    node = node.body[0]
    assert type(node) == ast.Expr
    node = node.value
    assert type(node) == ast.Call
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:02:16.670275
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast3
    from .helpers import type_visit
    from .helpers import AssertNodeTransformed

    node = ast3.List([
        ast3.Num(1),
        ast3.Starred(ast3.Name(id='a')),
        ast3.Num(2)
    ])


# Generated at 2022-06-12 04:02:17.774699
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer({})

# Generated at 2022-06-12 04:02:23.637984
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Tests the method visit_List of StarredUnpackingTransformer."""
    t = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    node = t.visit(node)
    result = compile(node, filename="<ast>", mode="exec")
    assert eval(result) == [2] + list(range(10)) + [1]

# Generated at 2022-06-12 04:02:29.666716
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    node = ast.parse(source, mode='eval')
    StarredUnpackingTransformer.run_visitor(node)
    result = ast.dump(node)
    assert result == expected



# Generated at 2022-06-12 04:02:31.122977
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert tuple(StarredUnpackingTransformer().target) == (3, 4)

# Generated at 2022-06-12 04:02:39.270178
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    target_version = StarredUnpackingTransformer.target

    assert ast.parse('[1, 2]', '', 'eval') == ast.parse('[1, 2]', '', 'eval')
    assert ast.parse('[1, *range(2)]', '', 'eval') == ast.parse('[1, *range(2)]', '', 'eval')
    assert ast.parse('[1, *range(2), 3]', '', 'eval') == ast.parse('[1] + list(range(2)) + [3]', '', 'eval')
    assert ast.parse('[1, *range(2), *range(3)]', '', 'eval') == ast.parse('[1] + list(range(2)) + list(range(3))', '', 'eval')
    

# Generated at 2022-06-12 04:02:48.152717
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source_code = """\
x = [1, 2, 3, *range(4), 5]
"""

    expected_code = """\
x = [1, 2, 3] + list(range(4)) + [5]
"""

    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(ast.parse(source_code))
    new_code = compile(new_tree, '<string>', 'exec')

    code_obj = compile(source_code, '<string>', 'exec')
    ctx = {}
    exec(code_obj, ctx)

    ctx2 = {}
    exec(new_code, ctx2)

    assert ctx2['x'] == ctx['x']
    assert expected_code == transformer.dumps()


# Generated at 2022-06-12 04:03:00.069392
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:03:06.991510
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    trans.visit(tree)
    assert isinstance(tree.body[0].value, ast.BinOp)


# Generated at 2022-06-12 04:03:14.011230
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    transformer = StarredUnpackingTransformer()
    result_node = transformer.visit(node)
    print(ast.dump(result_node))
    assert transformer._tree_changed
    assert transformer._is_valid(result_node)
    assert result_node.body[0].value.args[0].value.left.func.id == 'list'
    assert result_node.body[0].value.args[0].value.right.func.id == 'list'


# Generated at 2022-06-12 04:03:21.564733
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import astunparse

    code = """
    print(*range(1), *range(3))
    [2, *range(10), 1]
    """

    expected = """
    print(*(list(range(1)) + list(range(3))))
    [2] + list(range(10)) + [1]
    """

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    result = astunparse.unparse(tree)

    print(result)
    assert result == expected


# -----------------------------------------------------------------------------


# Generated at 2022-06-12 04:03:23.853829
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse
    from .compile_to_str import compile_to_str

# Generated at 2022-06-12 04:03:24.843552
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    o = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:29.381302
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    t = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]").body[0]
    # Act
    result = t.visit(node)
    # Assert
    assert str(result) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-12 04:03:34.234053
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sut = StarredUnpackingTransformer()
    actual = ast.parse('[2, *range(10), 1]')
    actual = sut.visit(actual)

    expected = '_0 = list(range(10)); [2] + _0 + [1]'
    expected = ast.parse(expected).body[0]
    assert ast.dump(expected) == ast.dump(actual.body[0])



# Generated at 2022-06-12 04:03:39.041508
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    code = "print(1, *range(3), 2)"
    tree = ast.parse(code)
    transformer.visit(tree)
    assert str(tree) == "print(*(list([1]) + list(range(3)) + list([2])))"



# Generated at 2022-06-12 04:03:49.850826
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_cases = [
        (
            'print(*range(1), *range(3))',
            'print(*(list(range(1)) + list(range(3))))',
        ),
        (
            'print(1, *range(3), *range(4))',
            'print(1, *(list(range(3)) + list(range(4))))',
        ),
        (
            'print()',
            'print()',
        ),
        (
            'print(*range(1))',
            'print(*list(range(1)))',
        ),
        (
            'print(*[1, 2, 3], *range(1))',
            'print(*(list([1, 2, 3]) + list(range(1))))',
        ),
    ]


# Generated at 2022-06-12 04:03:59.032797
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astunparse
    class StarredUnpackingTransformerTest(StarredUnpackingTransformer):
        def __init__(self):
            super().__init__()

    t = StarredUnpackingTransformerTest()

    for t in (list, tuple, set, frozenset, dict):
        assert astunparse.unparse(t([1, 2, 3])) == astunparse.unparse(t([1, 2, 3]))

    assert astunparse.unparse([2, *range(10), 1]) == astunparse.unparse([2] + list(range(10)) + [1])

    assert astunparse.unparse(tuple([2, *range(10), 1])) == astunparse.unparse(tuple([2] + list(range(10)) + [1]))

    assert astun

# Generated at 2022-06-12 04:04:08.978926
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
    [2, *range(10), 1]
    """
    expected = """
    [2] + list(range(10)) + [1]
    """
    transformed = StarredUnpackingTransformer().visit_module(ast.parse(code))
    result = ast.fix_missing_locations(transformed)
    assert ast.dump(result) == expected



# Generated at 2022-06-12 04:04:13.535870
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compiler.transformer import CompilerTransformer
    from compiler.transformer.unpacking import StarredUnpackingTransformer

    code = '[2, *range(10), 1]'
    expected = '([2] + list(range(10)) + [1])'
    tree = ast.parse(code, mode='eval')
    c = CompilerTransformer()
    c.register(StarredUnpackingTransformer)
    c.visit(tree)
    compiled = c.get_code(tree)
    assert compiled == expected



# Generated at 2022-06-12 04:04:18.005941
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..unparse import Unparser
    from .. import compile

    code = compile('[2, *range(10), 1]', '<test>', 'exec', flags=0)
    assert Unparser(code).to_source() == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:04:28.129307
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    '''
    def _has_starred(self, xs: List[ast.expr]) -> bool:
        for x in xs:
            if isinstance(x, ast.Starred):
                return True

        return False
    '''
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .utils import run_transformer
    import sys


# Generated at 2022-06-12 04:04:31.260075
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    check(source, expected, StarredUnpackingTransformer)



# Generated at 2022-06-12 04:04:33.563849
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = ''''''
    node = parse(code)
    StarredUnpackingTransformer().visit(node)



# Generated at 2022-06-12 04:04:41.290703
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..compiler import compile_isolated
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        # Python code to be compiled
        CODE = '''\
            l = [2, *range(10), 1]
            '''
        # Python code expected after transformation
        AST = parse('''\
            l = [2] + list(range(3)) + [1]
            ''')

    assert compile_isolated(TestTransformer) == exec(TestTransformer.AST)


# Generated at 2022-06-12 04:04:44.654195
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    def t(code: str) -> str:
        return StarredUnpackingTransformer().visit(ast.parse(code))

    assert t('print(*range(1), *range(3))') == 'print(*(list(range(1)) + list(range(3))))'
    assert t('[2, *range(10), 1]') == '[2] + list(range(10)) + [1]'

# Generated at 2022-06-12 04:04:47.273059
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = 'print(2, *range(2), 3)'
    expected = 'print(*[2] + list(range(2)) + [3])'
    assert StarredUnpackingTransformer.run_test(src, expected) == 0

# Generated at 2022-06-12 04:04:55.462854
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    assert t.visit_Call(
        ast.Call(
            func=ast.Name(id="foo"),
            args=[
                ast.Starred(
                    value=ast.Name(id='bar'))],
            keywords=[])) == ast.Call(
                func=ast.Name(id="foo"),
                args=[ast.Starred(value=ast.Call(
                    func=ast.Name(id='list'),
                    args=[ast.Name(id='bar')],
                    keywords=[]))],
                keywords=[])


# Generated at 2022-06-12 04:05:13.909427
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star_unpack = StarredUnpackingTransformer('')
    xs = [ast.Num(n=7), ast.Starred(value=ast.Call(func=ast.Name(id='a'), args=[], keywords=[])), ast.Num(n=3)]
    ys: List[Splitted] = [
        [ast.Num(n=7)],
        ast.Starred(value=ast.Call(func=ast.Name(id='a'), args=[], keywords=[])),
        [ast.Num(n=3)]]
    assert star_unpack._split_by_starred(xs) == ys
    assert isinstance(star_unpack._prepare_lists(ys)[0], ast.Call)
    assert isinstance(star_unpack._prepare_lists(ys)[1], ast.List)

# Generated at 2022-06-12 04:05:22.943817
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of class StarredUnpackingTransformer."""
    from typed_ast.ast3 import parse
    from chymyst.compiler.compiler import compile_to_ast
    from chymyst.compiler.typings import typed_tuple, typed_list


# Generated at 2022-06-12 04:05:33.182215
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'def f(a, b, c): print(a, b, c)'
    t = ast.parse(code).body[0]
    a = t.args.args[0]
    b = t.args.args[1]
    c = t.args.args[2]
    l = ast.List(elts=[a, b, c], ctx=ast.Load())
    s = ast.Starred(value=l, ctx=ast.Load())
    ast.fix_missing_locations(s)
    c = t.body[0]
    c.args[0] = s
    ast.fix_missing_locations(c)
    t.body[0] = c
    ast.fix_missing_locations(t)

# Generated at 2022-06-12 04:05:38.456338
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer('')

    node = ast.Call()
    node.args = [ast.Starred(value=ast.Name(id='arg1'))]
    node.func = ast.Name(id='func')
    transformed_node = transformer.visit(node)
    expected_node = ast.Call()
    expected_node.func = ast.Name(id='func')
    expected_node.args = [ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='arg1')], keywords=[]))]

    assert ast.dump(transformed_node) == ast.dump(expected_node)
    assert transformer.tree_changed == True


# Generated at 2022-06-12 04:05:48.035551
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import compile, parse
    from .methods import MethodsTransformer

    tree = parse("""
print(1, *range(2), *range(3))
""")

    class MyStarredUnpackingTransformer(StarredUnpackingTransformer):
        pass

    class MyMethodsTransformer(MethodsTransformer):

        def call_print(self, args: List[ast.expr]) -> ast.Call:
            return ast.Call(
                func=ast.Name(id='print'),
                args=args,
                keywords=[])

    obj = MyStarredUnpackingTransformer().visit(tree)

    result = compile(
        MyMethodsTransformer().visit(obj),
        filename='<ast>',
        mode='exec',
    )


# Generated at 2022-06-12 04:05:49.777960
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert s


# Generated at 2022-06-12 04:05:55.115587
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from ast_unparse import unparse as ast_unparse

    module = pyast.parse("print(*range(1), *range(3))")
    tree = StarredUnpackingTransformer().visit(module)
    assert ast_unparse(tree) == "print(*(list(range(1)) + list(range(3))))"



# Generated at 2022-06-12 04:05:59.954439
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import compile_to_ast

    source = r'''
[2, *range(10), 1]
print(*range(1), *range(3))
    '''

    node = compile_to_ast(source)
    StarredUnpackingTransformer(node)

    expected = r'''
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    '''

    assert ast.dump(node) == compile_to_ast(expected)

# Generated at 2022-06-12 04:06:10.812973
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    def transform(src: str) -> str:
        return StarredUnpackingTransformer().transform_source(src)

    assert transform('[*range(10), 1, *range(2)]') == \
        '[*(list(range(10)) + [1] + list(range(2)))]'
    assert transform('[1, 2, *range(10), *range(20)]') == \
        '[1, 2, *(list(range(10)) + list(range(20)))]'
    assert transform('[1, 2, *range(10), 3]') == \
        '[1, 2, *(list(range(10)) + [3])]'
    assert transform('[1, 2, *range(10)]') == \
        '[1, 2, *(list(range(10)))]'

# Generated at 2022-06-12 04:06:19.284961
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    src = """
        [2, *range(10), 1]
        [2, *range(10), 1, *range(10), 1]
        print(*range(1), *range(3))
    """

    expected_result = """
        list([2]) + list(range(10)) + list([1])
        list([2]) + list(range(10)) + list([1]) + list(range(10)) + list([1])
        print(*(list(range(1)) + list(range(3))))
    """
    t = StarredUnpackingTransformer()
    tree = ast.parse(src)
    t.visit(tree)
    assert astor.to_source(tree) == expected_result

# Generated at 2022-06-12 04:06:39.404638
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(2, *range(10), 1)")
    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)
    assert str(node) == "print(2, *(list(range(10)) + [1]))"

# Generated at 2022-06-12 04:06:49.014244
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    exprs = [
        "['hello', 'world', *lst]",
        "['hello', 'world', *lst, '!']",
        "['hello', 'world', '!', *lst]",
        "[*lst, 'hello', 'world']",
        "[*lst, 'hello', 'world', *lst2]",
        "['hello', 'world', *lst, *lst2]",
        "[*lst, *lst2, 'hello', 'world']",
        "[*lst, *lst2, *lst3]",
    ]


# Generated at 2022-06-12 04:06:53.710611
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast, typed_ast.ast3 as typed_ast
    tree = ast.parse('print(*range(1), *range(3))')
    typed_tree = typed_ast.ast3.parse(
        """print(*range(3), *range(3))""")
    StarredUnpackingTransformer(tree).transform()
    assert ast.dump(tree) == ast.dump(typed_tree)

# Generated at 2022-06-12 04:07:01.685122
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import ast_helpers, compile_ex
    from ast import parse
    StarredUnpackingTransformer()
    for code, expected in [
        # Basic
        ('[2, *range(10), 1]', '[2] + list(range(10)) + [1]'),
        # Nested
        ('[[2, *range(10), 1], [2, *range(10), 1]]', '[[2] + list(range(10)) + [1], [2] + list(range(10)) + [1]]'),
    ]:
        res_test = compile_ex(code, '<test>', 'exec', mode='exec').strip()
        res_expected = compile_ex(expected, '<test>', 'exec', mode='exec').strip()
        assert res_expected == res_test


# Generated at 2022-06-12 04:07:11.626437
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.List)
    tree2 = transformer.visit(tree)
    assert transformer.tree_changed
    assert isinstance(tree2, ast.Module)
    assert len(tree2.body) == 1
    assert isinstance(tree2.body[0], ast.Expr)
    assert isinstance(tree2.body[0].value, ast.BinOp)
    assert isinstance(tree2.body[0].value.left, ast.List)

# Generated at 2022-06-12 04:07:20.323229
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .tools import dump_tree, run_transformers

    code = '''
    x = sorted(set(x for x in (1, 2, 3, 4)))
    y = sorted(((a, b, *c), (1, 2, 3, 4)))
    def f(a, b, *c):
        pass
    def g(a, b, *c, **d):
        pass
    z = sorted(1, 2, 3, 4)
    '''
    tree = ast.parse(code)

    new_tree = run_transformers(tree, [StarredUnpackingTransformer()])


# Generated at 2022-06-12 04:07:29.124521
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = ast.parse('''d = [1, *[2,3]]''')
    c = StarredUnpackingTransformer()
    result = c.visit(stmt)
    assert result.body[0].value.elts[1].args[0].elts[0].elts[0].n == 1
    assert result.body[0].value.elts[1].args[0].elts[0].elts[1].value.elts[0].value.n == 2
    assert result.body[0].value.elts[1].args[0].elts[0].elts[1].value.elts[1].value.n == 3


# Generated at 2022-06-12 04:07:38.476302
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:07:41.779233
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """\n
        print(*range(1), *range(1))
    """
    expected = """\n
        print(*(list(range(1)) + list(range(1))))
    """
    compiles_to(source, expected)



# Generated at 2022-06-12 04:07:50.878715
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse

    class V(ast.NodeVisitor):
        def __init__(self, z):
            self.z = z

        def visit_Call(self, node):
            if self.z == 1:
                zz = 0
            else:
                zz = 2

            if zz == 0:
                node.args.append(ast.Starred(value=ast.Name(id="none", ctx=ast.Load())))
            else:
                node.args.append(ast.Starred(value=ast.Name(id="one", ctx=ast.Load())))

            return self.generic_visit(node)

    class M(ast.NodeTransformer):
        def __init__(self, z):
            self.z = z


# Generated at 2022-06-12 04:08:38.284001
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def f():
        a = [2, *range(10), 1]
        print(*range(1), *range(3))
        print(a)

    sut = StarredUnpackingTransformer()
    node = ast.parse(inspect.getsource(f))

    sut.visit(node)
    code = compile(node, '<string>', mode='exec')
    ns = {}
    exec(code, ns)
    f = ns['f']

    # expected
    def expected():
        a = [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        print(a)

    with CaptureStdout() as capture_stdout:
        f()

    with CaptureStdout() as expected_stdout:
        expected

# Generated at 2022-06-12 04:08:39.937352
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert isinstance(a, StarredUnpackingTransformer)


# Generated at 2022-06-12 04:08:40.883287
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-12 04:08:49.373180
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_tools import should_fail, check_equal_code, run_all_nodes, run_all_files
    from ..main import transform

    assert check_equal_code(
        transform(
            'print(*[2, 3])',
            StarredUnpackingTransformer
        ),
        'print(*list([2, 3]))'
    )

    assert check_equal_code(
        transform(
            'print(*[2, *range(3)])',
            StarredUnpackingTransformer
        ),
        'print(*(list([2]) + list(range(3))))'
    )


# Generated at 2022-06-12 04:08:50.328192
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-12 04:08:52.824172
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    SUT = StarredUnpackingTransformer()
    assert str(SUT) == "<StarredUnpackingTransformer/>"


# Generated at 2022-06-12 04:08:56.886997
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("a*[2,3]")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='list', ctx=Load()), args=[a*[2, 3]], keywords=[])"


# Generated at 2022-06-12 04:09:03.022299
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class _T(StarredUnpackingTransformer):
        def visit_Name(self, node):
            return node

    node = ast.parse('print(1, 2, *range(10), 4)').body[0]
    result = _T().visit(node)
    compare = ast.parse('print(*(list([1, 2]) + list(range(10)) + [4]))').body[0]
    assert ast.dump(result) == ast.dump(compare)

# Generated at 2022-06-12 04:09:09.535515
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # if test1 pass, then test2 will pass
    def test1():
        node = ast.List(elts=[ast.Num(n=2), ast.Num(n=3), ast.Num(n=4)])
        trans = StarredUnpackingTransformer()
        new_node = trans.visit(node)
        assert new_node == node

    def test2():
        node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range')), ast.Num(n=4)])
        trans = StarredUnpackingTransformer()
        new_node = trans.visit(node)
        assert isinstance(new_node, ast.Call)
        assert new_node.func.id == 'list'

# Generated at 2022-06-12 04:09:15.435620
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    code = 'print([1, *range(5), 7])'
    tree = ast.parse(code)
    transformer.visit(tree)
    assert transformer._tree_changed is True

    code = 'print([1, range(5), 7])'
    tree = ast.parse(code)
    transformer.visit(tree)
    assert transformer._tree_changed is False



# Generated at 2022-06-12 04:10:54.337529
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest

    import typed_astunparse
    from typed_astunparse import ast3 as ast
    import astor

    class MockNodeTransformer(StarredUnpackingTransformer):
        # pylint: disable=unused-argument
        def visit_Name(self, node: ast.Name) -> ast.Name:
            node.id += "_bar"
            return node

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_StarredUnpackingTransformer_visit_Call(self):
            code = """if True:
                print("Hello", *range(10))
                """
            expected = """if True:
                print(*([str("Hello")] + list(range(10))))
                """

            tree = ast.parse(code)

# Generated at 2022-06-12 04:11:03.030067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse, dump
    from typed_astunparse import unparse

    tree = parse("[2, *range(4)]")
    tree = StarredUnpackingTransformer().visit(tree)

    assert [unparse(x).strip() for x in tree.body] == \
        ['x = [2] + list(range(4))']

# Generated at 2022-06-12 04:11:11.138908
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import typed_ast.ast3
    from typed_astunparse import unparse

    """
    input = ast.parse(
        "print(*range(1), *range(3))"
    )
    """

# Generated at 2022-06-12 04:11:16.565280
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .syntax import parse

    node = parse("print(*range(4), *range(7))")

    stu = StarredUnpackingTransformer()
    stu.visit(node)

    assert stu._tree_changed

    evaluated_result = eval(compile(node, '', 'exec'))
    expected_result = print(*(list(range(4)) + list(range(7))))

    assert evaluated_result == expected_result


# Generated at 2022-06-12 04:11:22.838781
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_compare import assert_equivalent_asts, find_transformer_class
    from .utils import get_ast

    ast_Call = get_ast("print(*range(1), *range(5), sep=' ')")
    
    ast_Call_prepared = get_ast("print(*(list(range(1)) + list(range(5))), sep=' ')")
    
    transformer_class = find_transformer_class("StarredUnpackingTransformer")
    transformer = transformer_class()
    new_ast = transformer.visit(ast_Call)

    assert_equivalent_asts(new_ast, ast_Call_prepared)


# Generated at 2022-06-12 04:11:29.029584
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert (
        StarredUnpackingTransformer().visit(
            ast.parse('[2, *range(10), 1]', mode='eval')
        ) ==
        ast.parse('[2] + list(range(10)) + [1]', mode='eval')
    )

    assert (
        StarredUnpackingTransformer().visit(
            ast.parse('print(*range(1), *range(3))')
        ) ==
        ast.parse('print(*(list(range(1)) + list(range(3))))')
    )

# Generated at 2022-06-12 04:11:35.246669
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    import ast

    test_code = """foo(*range(2), *range(3), *range(4))"""
    expected_code = """foo(*((list(range(2)) + list(range(3))) + list(range(4))))"""
    tree = astor.parse_tree(test_code)
    compiled_node = StarredUnpackingTransformer().visit(tree)
    compiled_code = astor.to_source(compiled_node)
    assert compiled_code == expected_code


# Generated at 2022-06-12 04:11:44.886317
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert ast.dump(StarredUnpackingTransformer().visit(ast.parse('print(*range(10))')), annotate_fields=False) == 'Module(body=(Expr(value=Call(func=Name(id=print, ctx=Load()), args=[List(elts=(Name(id=list, ctx=Load()), Starred(value=Name(id=range, ctx=Load()), ctx=Load()), List(elts=())), keywords=())), keywords=())), type_ignore=None)'