

# Generated at 2022-06-12 04:01:54.468442
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    src = """
from collections import Iterable
[2, *range(10), 1]
print(*range(1), *range(3))
    """
    expected = """
from collections import Iterable
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """
    actual = StarredUnpackingTransformer.run_it(src)
    assert actual == expected

# Generated at 2022-06-12 04:01:55.243804
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer


# Generated at 2022-06-12 04:02:00.493605
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from python_rewriter.tests.helpers import StatementTestCase

    class Test(StatementTestCase):
        transformer = StarredUnpackingTransformer

        def given_code(self):
            return ast.parse("print(*range(1), *range(3))")

        def expected_code(self):
            return "print(*(list(range(1)) + list(range(3))))"

# Generated at 2022-06-12 04:02:11.354527
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import textwrap
    from .test_transpile_ast import transpile_ast

    class_name = "StarredUnpackingTransformer"
    method_name = "visit_Call"
    test_str = textwrap.dedent(
        """
        print(1, *range(2), 3, *range(4))
        """
    )
    test_ast = ast.parse(test_str)
    expect_str = textwrap.dedent(
        """
        print(*(list(range(1)) + list(range(2)) + list(range(3)) + list(range(4))))
        """
    )
    expect_ast = ast.parse(expect_str)

    StarredUnpackingTransformer().generic_visit(test_ast)

# Generated at 2022-06-12 04:02:21.737669
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    sut = StarredUnpackingTransformer()
    sut._tree_changed = False

    ast_node = ast.parse(
        """
        def main():
            print(1, 2, *range(3), 4, 5, *range(6))
        """
    ).body[0].body[0].value

    expected_ast_node = ast.parse(
        """
        def main():
            print(*(([1, 2] + list(range(3))) + ([4, 5] + list(range(6)))))
        """
    ).body[0].body[0].value

    result = sut.visit(ast_node)

    assert result == expected_ast_node
    assert sut._tree_changed == True


# Generated at 2022-06-12 04:02:26.674466
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse as ast_parse
    from .test_utils import assert_code_equal

    code = """
print(*range(1), *range(3))
    """
    expected_code = """
print(*(list(range(1)) + list(range(3))))
    """

    tree = ast_parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert_code_equal(expected_code, tree)


# Generated at 2022-06-12 04:02:32.054405
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    required_output = ast.parse('[2] + list(range(10)) + [1]')
    first_input = '[2, *range(10), 1]'
    node = ast.parse(first_input)
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(required_output)



# Generated at 2022-06-12 04:02:40.303668
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    Test on:
    >>> print(*range(1), *range(3))
    """
    compiler = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:02:46.377762
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"

    root = ast.parse(code)
    StarredUnpackingTransformer().visit(root)

    assert ast.dump(root) == "Module([Expr(BinOp(BinOp(List([Num(2)]), Call(Name('list', Load()), [Call(Name('range', Load()), [Num(10)], [], None, None)], [], None, None), Add()), List([Num(1)]), Add()))])"


# Generated at 2022-06-12 04:02:56.621019
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse
    transformer = StarredUnpackingTransformer()
    # Transforming the following code:
    code = "print(*range(1), *range(3), 1)"
    root_node = ast.parse(code).body[0]
    # To the following code:
    expected_code = "print(*(list(range(1)) + list(range(3)) + [1]))"
    expected_root_node = ast.parse(expected_code).body[0]
    # Check the result.
    transformed_node = transformer.visit(root_node)
    assert unparse(expected_root_node).strip() == unparse(transformed_node).strip()



# Generated at 2022-06-12 04:03:08.444039
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class_ = StarredUnpackingTransformer()

    # test 1
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    branch = (tree.body[0].value)

    changed_branch = class_.visit(branch)

    assert isinstance(changed_branch, ast.BinOp)
    assert isinstance(changed_branch.left, ast.BinOp)
    assert isinstance(changed_branch.right, ast.BinOp)

    assert changed_branch.left.left.elts[0].n == 2
    assert isinstance(changed_branch.left.right, ast.Call)
    assert changed_branch.left.right.func.id == 'list'

# Generated at 2022-06-12 04:03:18.320958
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    assert ast.dump(t.visit(ast.parse('''
        [2, *range(10), 1]
    '''))) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-12 04:03:25.875294
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    
    class Visitor(ast.NodeVisitor):
        def visit_Call(self, node):
            print(node)

    def preprocess(source):
        visitor = Visitor()
        tree = ast.parse(source)
        StarredUnpackingTransformer().visit(tree)
        visitor.visit(tree)
        print('====')

    preprocess("print(1, 2)")
    preprocess("print(1, *range(10))")
    preprocess("print(1, *range(10), 3)")


# Generated at 2022-06-12 04:03:33.256221
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # [2, *range(10), 1]
    node = ast.List(
        elts=[
            ast.Constant(value=2),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[
                        ast.Constant(value=10)],
                    keywords=[]),
                ctx=None),
            ast.Constant(value=1)],
        ctx=None)


# Generated at 2022-06-12 04:03:44.602419
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[ast.Constant(value=2),
                          ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                     args=[ast.Constant(value=10)],
                                                     keywords=[])),
                          ast.Constant(value=1)])
    expected_node = ast.BinOp(left=ast.List(elts=[ast.Constant(value=2)]),
                              op=ast.Add(),
                              right=ast.Call(args=[ast.Constant(value=10)],
                                             func=ast.Name(id='list'),
                                             keywords=[]))

# Generated at 2022-06-12 04:03:48.697424
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    parse = ast.parse('print(*range(1), *range(3))')
    expected = '''
print(*([1] + list(range(3))))
'''
    assert StarredUnpackingTransformer().visit(parse).body[0] == ast.parse(expected).body[0]


# Generated at 2022-06-12 04:03:58.184821
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import compile_source
    from .ast_builder import create_ast
    from .visitors import dump_python_source
    source = 'print(2, *range(5), *range(10))'
    tree = compile_source(source, mode='exec')
    StarredUnpackingTransformer().visit(tree)
    print(dump_python_source(tree))
    source2 = 'print(*(list(range(2)) + list(range(5)) + list(range(10))))'
    tree2 = compile_source(source2, mode='exec')
    assert tree == tree2

    # source_code='sum([2, *range(10)])'
    # test_tree=create_ast(source_code)
    # StarredUnpackingTransformer().visit(test_tree)
    # print(dump

# Generated at 2022-06-12 04:04:02.463344
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    new_module = transformer.visit(module)
    assert len(ast.dump(new_module)) == 39


# Generated at 2022-06-12 04:04:11.953883
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='f'),
                    args=[ast.List(elts=[ast.Starred(value=ast.Name(id='a'))]),
                          ast.Starred(value=ast.List(elts=[ast.Name(id='b')]))],
                    keywords=[])
    expected = ast.Call(func=ast.Name(id='f'),
                        args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'),
                                                        args=[ast.Name(id='a')],
                                                        keywords=[]))],
                        keywords=[])
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(node)
    assert ast.dump(transformed) == ast.dump(expected)
# End of unit test for method visit_

# Generated at 2022-06-12 04:04:15.595724
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import dump
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert dump(tree) == expected



# Generated at 2022-06-12 04:04:27.201315
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    xs = [ast.parse("""print(*range(1), *range(3))""")]

# Generated at 2022-06-12 04:04:35.281249
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import transform

    def test_function(a, b):
        return a + b

    node = ast.Call(
        ast.Name(id='test_function'),
        [],
        [
            ast.Starred(
                ast.Call(
                    ast.Name(id='list'),
                    [ast.Name(id='args')],
                    []),
                []),
        ]
    )

    tree = ast.parse('test_function(*list(args))')
    new_tree = StarredUnpackingTransformer().visit(tree)
    assert transform(new_tree) == transform(node)

# Generated at 2022-06-12 04:04:40.255869
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from .test_util import round_trip

    snippet = "[2, *range(10), 1]"
    result = StarredUnpackingTransformer.run_single(snippet)
    assert result == ast3.parse(snippet[:-1] +
                                "+ list(range(10)) + [1]\n")


# Generated at 2022-06-12 04:04:46.337274
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utilities import assert_transform, assert_transform_unchanged

    assert_transform(
        'print(2, *range(4), 5, *[3, 2, 1])',
        'print(2, *(list(range(4)) + list([3, 2, 1])))',
        3)

    assert_transform(
        'list = [2, *range(4), 5, *[3, 2, 1]]',
        'list = [2] + list(range(4)) + [5] + list([3, 2, 1])',
        3)

    assert_transform(
        'list = [2, *[3, 2, 1]]',
        'list = [2] + list([3, 2, 1])',
        3)


# Generated at 2022-06-12 04:04:53.529455
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_cases = [
        (
            # test_case 1
            'a = [2, *range(10), 1]',
            'a = [2] + list(range(10)) + [1]',
        ),
    ]
    for test_case in test_cases:
        node = ast.parse(test_case[0])
        StarredUnpackingTransformer(test_case[0]).visit(node)
        assert test_case[1] == astunparse.unparse(node)


# Generated at 2022-06-12 04:04:59.679843
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    global node
    node = ast.parse('print(*range(1), *range(3))').body[0]
    visitor = StarredUnpackingTransformer()
    visitor.visit(node)
    assert ast.dump(node) == 'Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=1)], keywords=[])], ctx=Load()), right=List(elts=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=3)], keywords=[])], ctx=Load())), op=Add())], keywords=[]))'



# Generated at 2022-06-12 04:05:07.141858
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .base import transform_source
    input = astor.to_source(
        ast.parse("""
        print(*range(1), *range(3))
        """))
    output = astor.to_source(
        transform_source(input, [StarredUnpackingTransformer])
    ).strip()
    expected = astor.to_source(
        ast.parse("""
        print(*(list(range(1)) + list(range(3))))
        """)).strip()
    assert output == expected


# Generated at 2022-06-12 04:05:10.982944
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer."""
    # The only thing we can realistically test is that the class can be constructed
    StarredUnpackingTransformer()


# Generated at 2022-06-12 04:05:17.986879
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # 1. Test normal list
    l = ast.parse('[1, 2, 3]')
    node = l.body[0].value  # List node
    assert isinstance(node, ast.List)
    assert node.elts == [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]

    # 2. Test list with starred node
    l = ast.parse('[1, 2, *range(10), 3]')
    node = l.body[0].value  # List node
    assert isinstance(node, ast.List)

# Generated at 2022-06-12 04:05:27.677135
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test of method visit_List of class StarredUnpackingTransformer."""

    input_list = "[2, *range(10), 1]"
    expected_list = "[2] + list(range(10)) + [1]"
    test_list_before = ast.parse(input_list)
    test_list_before.body = test_list_before.body[0].value

    test_list_after = ast.parse(expected_list)
    test_list_after.body = test_list_after.body[0].value

    test_transformer = StarredUnpackingTransformer()
    test_list_returned = test_transformer.visit(test_list_before)

    assert test_list_returned == test_list_after


# Generated at 2022-06-12 04:05:39.276974
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..compile_ast import compile_ast, verify_v3

    verify_v3(StarredUnpackingTransformer)

    code = "[2, *range(10), 1]"
    tree = compile_ast(code, StarredUnpackingTransformer)  # type: ast.Expression
    assert isinstance(tree.body, ast.BinOp)

# Generated at 2022-06-12 04:05:48.635666
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .common import TreeAssert
    from .common import get_ast

# Generated at 2022-06-12 04:05:58.702741
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    class NodeTransformer(StarredUnpackingTransformer):
        def __init__(self):
            self._current_line = 0
            self._tree_changed = False

        def generic_visit(self, node):
            ast.NodeTransformer.generic_visit(self, node)
            return node

    nodeTransformer = NodeTransformer()

    # Test 1: Test that the tree is not changed
    test_program1 = ast.parse("""
    [2, 3, 4]
    """)
    new_program1 = nodeTransformer.visit(test_program1)
    assert new_program1 == test_program1

    # Test 2: Test that correct tree is returned

# Generated at 2022-06-12 04:06:04.400678
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as python_ast
    import typing
    import typed_ast.ast3 as typed_ast

    from .test.test_transformer import check_transformation

    code = "[0, *args, 1]"
    expected_code = "[0] + list(args) + [1]"
    python_tree = python_ast.parse(code)
    check_transformation(StarredUnpackingTransformer, python_tree, expected_code)

# Generated at 2022-06-12 04:06:05.899069
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:06:10.892698
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('[2, *range(10), 1]')  # type: ignore
    assert transformer.visit(node) == ast.parse('[2] + list(range(10)) + [1]')  # type: ignore

# Generated at 2022-06-12 04:06:18.726806
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.list = ast.List(elts=[
                ast.Num(n=1),
                ast.Starred(value=ast.Name(id='x')),
                ast.Num(n=2)
            ], ctx=ast.Load())

        def visit_List(self, node):
            if node == self.list:
                print('success')
                
    visitor = Visitor()
    
    StarredUnpackingTransformer.run_on(visitor.list)
    visitor.visit(visitor.list)


# Generated at 2022-06-12 04:06:23.365675
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(tree)
    assert str(tree.body[0].value) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:06:30.128197
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    def check(src):
        tree = ast.parse(src)
        StarredUnpackingTransformer().visit(tree)
        return astor.to_source(tree).strip()

    assert check('[2, 3]') == '[2, 3]'
    assert check('[2, 3, *range(10)]') == '[2, 3] + list(range(10))'
    assert check('[2, *range(10)]') == '[2] + list(range(10))'
    assert check('[*range(10), 2]') == 'list(range(10)) + [2]'
    assert check('[*range(10), *range(1)]') == 'list(range(10)) + list(range(1))'



# Generated at 2022-06-12 04:06:35.557345
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse("print(*range(1), *range(3), *range(5))")
    transpiler = StarredUnpackingTransformer()
    new_module = transpiler.visit(module)
    expected_module = ast.parse("print(*(list(range(1)) + list(range(3)) + list(range(5))))")
    check_equal_modules(expected_module, new_module)


# Generated at 2022-06-12 04:07:02.015435
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
print(*range(1), *range(2))
    """
    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    code_after = compile(new_tree, "test_StarredUnpackingTransformer_visit_Call", "exec")
    result, error = get_stdout(code_after)
    if error:
        print("Error: " + error)
    else:
        print("Result: " + result)
        assert result == "0\n1\n0\n1\n"


# Generated at 2022-06-12 04:07:11.957259
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    node1 = ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[])
    node2 = ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[])
    node3 = ast.Call(func=ast.Name(id='print'), args=[node1, node2], keywords=[])

# Generated at 2022-06-12 04:07:20.562704
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:07:29.261706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast.ast3 import Call, Name
    from typed_ast import ast3 as ast

    t = StarredUnpackingTransformer(print_log=True)
    expected = Call(func=Name(id='func'), args=[Starred(value=List(elts=[Num(n=1), Num(n=2), Num(n=3)]))], keywords=[])
    result = t.visit_Call(Call(func=Name(id='func'), args=[Num(n=1), Starred(value=List(elts=[Num(n=2), Num(n=3)])), Num(n=4)], keywords=[]))
    assert repr(expected) == repr(result)
    

# Generated at 2022-06-12 04:07:30.819569
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .transformer_test import run_transformer_test
    from . import INDENT_USER_SETTING


# Generated at 2022-06-12 04:07:39.877996
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Name(id='range'),
                ctx=ast.Load()),
            ast.Starred(
                value=ast.Name(id='range'),
                ctx=ast.Load()),
        ],
        keywords=[]
    )

# Generated at 2022-06-12 04:07:48.729362
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    from itertools import zip_longest
    from re import compile
    from textwrap import dedent

    # These are test cases, where `NodeTransformer` classes are expected to
    # make changes
    cases = [
        ('print(*range(1))', 'print(*(list(range(1))))'),
        ('print(*range(1), *range(2))', 'print(*(list(range(1)) + list(range(2))))'),
        ('print(*range(1), *range(2), *range(3))', 'print(*(list(range(1)) + list(range(2)) + list(range(3))))'),
    ]
    # `regexp_cases` are expected to be handled as well

# Generated at 2022-06-12 04:07:56.885438
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import DependencyInjectionTransformer, FunctionDefTransformer
    from . import fix_missing_locations, Py3AnnotationTransformer
    from .transpile import transpile

    def transform(node):
        tree = fix_missing_locations(node)
        tree = Py3AnnotationTransformer().visit(tree)
        tree = StarredUnpackingTransformer().visit(tree)
        tree = FunctionDefTransformer().visit(tree)
        tree = DependencyInjectionTransformer().visit(tree)
        return tree

    def test(snippet: str, expected: str) -> None:
        module = compile(snippet, '<test>', 'exec')
        tree = module.body[0]
        assert isinstance(tree, ast.Expr)

# Generated at 2022-06-12 04:08:00.733387
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    node = ast.parse('print(*range(1), *range(3))')
    fixed_node = sut.visit(node)

    expected_node = ast.parse('print(*(list(range(1))+list(range(3))))')
    assert ast.dump(expected_node) == ast.dump(fixed_node)


# Generated at 2022-06-12 04:08:09.982066
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='echo'),
        args=[
            ast.Constant(value=1),
            ast.Starred(value=ast.List(elts=[ast.Constant(value=2)], ctx=ast.Load())),
            ast.Constant(value=3)
        ],
        keywords=[]
    )

# Generated at 2022-06-12 04:08:45.792975
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse("print(*range(1), *range(3))")
    new_tree = transformer.visit(tree)

# Generated at 2022-06-12 04:08:52.081068
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''print(*[1, 2], 3, *[4], 5, 6)''')
    expected = ast.parse('''print(*(list([1, 2]) + [3, 4, 5, 6]))''')
    result = StarredUnpackingTransformer().visit(tree)
    print(ast.dump(tree))
    print(ast.dump(expected))
    print(ast.dump(result))
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:09:00.438496
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit Test for method visit_Call of class StarredUnpackingTransformer."""
    node = ast.parse(text="my_function_name(1, *range(5), *range(10))").body[0]
    node_reference = ast.parse(text="my_function_name(*(list(range(5))+list(range(10))))").body[0]
    transformer = StarredUnpackingTransformer()
    node_changed = transformer.visit(node)
    result = ast.dump(node_changed)
    reference = ast.dump(node_reference)
    assert (transformer.tree_changed() is True)
    assert (result == reference)


# Generated at 2022-06-12 04:09:05.993961
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code_snippet = 'print(*range(1), *range(3))'
    code_ast = ast.parse(code_snippet)
    print(astor.dump_tree(code_ast))
    transformed = StarredUnpackingTransformer().visit(code_ast)
    print(astor.dump_tree(transformed))
    code = compile(transformed, 'test', 'exec')
    exec(code)

# Generated at 2022-06-12 04:09:12.736979
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(1, *args, 2)    
    """
    expected = """
print(*(list([1]) + list(args) + list([2])))    
    """
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    result = compile(tree, '', 'exec')
    exec(result)
    expected_tree = ast.parse(expected)
    result_tree = ast.parse(str(tree))
    assert ast.dump(expected_tree) == ast.dump(result_tree)


# Generated at 2022-06-12 04:09:21.972598
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(
        ast.parse("print(*range(1), *range(3))", mode='eval').body)

# Generated at 2022-06-12 04:09:27.420708
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class MockVisitor(BaseNodeTransformer):
        def __init__(self, *args, **kwargs):
            raise Exception()

    for n in range(0, 3):
        for m in range(0, 3):
            node = ast.parse(
                'print(*range(%d), *range(%d))' % (n, m), mode='eval').body
            StarredUnpackingTransformer(MockVisitor).visit(node)

# Generated at 2022-06-12 04:09:30.329659
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    assert t.visit(ast.parse("print(*range(1), *range(3))")) == \
        ast.parse("print(*(list(range(1)) + list(range(3))))")

# Generated at 2022-06-12 04:09:36.260968
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
print(*range(1), *range(3))
""".lstrip()
    expected_code = """
print(*(list(range(1)) + list(range(3))))
""".lstrip()
    expected_ast = ast.parse(expected_code)
    expected_ast_code = astor.to_source(expected_ast)
    actual_ast = StarredUnpackingTransformer().visit(ast.parse(code))
    actual_code = astor.to_source(actual_ast)
    assert expected_ast_code == actual_code



# Generated at 2022-06-12 04:09:43.735900
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestStarredUnpackingTransformerCall(StarredUnpackingTransformer):
        def __init__(self):
            super().__init__()

# Generated at 2022-06-12 04:10:23.965447
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3

# Generated at 2022-06-12 04:10:29.477387
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('f(*range(10))').body[0].value
    result = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:10:34.159413
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .visitor import print_ast
    from .unparser import Unparser
    test_input = 'print(*range(1), *range(3))'
    test = StarredUnpackingTransformer()
    tree = ast.parse(test_input)
    tree = test.visit(tree)
    print_ast(tree)
    print(Unparser(tree).unparse())


# Generated at 2022-06-12 04:10:41.439411
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    target_tree = ast.parse('foo.bar(2, 3, *range(10), 1, **baz)')
    target_tree_expected = ast.parse('foo.bar(*(list(range(10)) + [1]), **baz)')
    test_instance = StarredUnpackingTransformer()
    test_instance.visit(target_tree)
    assert test_instance._has_starred(target_tree.body[0].value.args) == True
    compare_ast(target_tree, target_tree_expected)


# Generated at 2022-06-12 04:10:47.674531
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = ast.Name(id="a", ctx=ast.Load())
    b = ast.Name(id="b", ctx=ast.Load())
    c = ast.Name(id="c", ctx=ast.Load())
    arg = ast.Call(
        func=ast.Name(id="range", ctx=ast.Load()),
        args=[ast.Constant(value=10)],
        keywords=[])
    call = ast.Call(
        func=ast.Name(id="print", ctx=ast.Load()),
        args=[a, ast.Starred(value=arg, ctx=ast.Load())],
        keywords=[])

# Generated at 2022-06-12 04:10:53.481624
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected_output = '''\
print(*(list(range(1)) + list(range(3))), sep=" ", end="\\n")
'''
    input_code = '''\
print(*range(1), *range(3), sep=" ", end="\\n")
'''
    result = compile_restricted(input_code, '', 'exec', flags=ast.PyCF_ONLY_AST)
    node = StarredUnpackingTransformer().visit(result)
    output = astor.to_source(node).strip()
    assert output == expected_output


# Generated at 2022-06-12 04:11:02.089314
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.List(
                    elts=[
                        ast.Num(n=3),
                        ast.Num(n=1),
                        ast.Num(n=4)
                    ],
                    ctx=ast.Load()
                ),
                ctx=ast.Load()
            ),
            ast.Starred(
                value=ast.List(
                    elts=[
                        ast.Num(n=5),
                        ast.Num(n=9),
                        ast.Num(n=2)
                    ],
                    ctx=ast.Load()
                ),
                ctx=ast.Load()
            )
        ],
        keywords=[]
    )

# Generated at 2022-06-12 04:11:10.269610
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(1, 2, *range(1), *range(2))').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.keywords == []

    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.keywords == []
    assert isinstance(node.value.args[0], ast.Starred)
    assert isinstance(node.value.args[0].value, ast.BinOp)

# Generated at 2022-06-12 04:11:14.824519
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(5), *range(3))'
    expected_result = 'print(*(list(range(5)) + list(range(3))))'

    node = ast.parse(source)
    StarredUnpackingTransformer()(node)
    result = compile(node, filename='', mode='exec')
    assert result == expected_result



# Generated at 2022-06-12 04:11:19.545634
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
  import astor; import ast;
  dumptree = lambda tree: astor.to_source(tree).strip()
  module = ast.parse('f(*[1,2,*[3,4]], *[], **{})')
  t = StarredUnpackingTransformer().visit(module)
  actual = dumptree(t); expected = 'f(*(list([1, 2]) + list([3, 4]) + list([])))'
  assert actual == expected