

# Generated at 2022-06-12 04:01:57.745739
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    func = ast.Name(id='print')
    starred_1 = ast.Starred(value=ast.Name(id='range'))
    starred_2 = ast.Starred(value=ast.Name(id='range'))
    call = ast.Call(func=func, args=[starred_1, starred_2], keywords=[])

# Generated at 2022-06-12 04:02:09.068283
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = parse_ast("print(*range(1), *range(3), *range(5))").body[0]
    assert isinstance(stmt, ast.Expr)
    transformer = StarredUnpackingTransformer()
    transformer.visit(stmt)
    print(stmt)
    assert isinstance(stmt.value, ast.Call)
    assert isinstance(stmt.value.args[0], ast.Starred)
    assert isinstance(stmt.value.args[0].value, ast.BinOp)
    assert isinstance(stmt.value.args[0].value.left, ast.Call)
    assert isinstance(stmt.value.args[0].value.left.args[0], ast.Starred)

# Generated at 2022-06-12 04:02:16.792175
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.parse("print(*(1,2,3), *range(3), 5)")
    StarredUnpackingTransformer().visit(x)

# Generated at 2022-06-12 04:02:26.295735
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected_without_starred = ast.parse('l = list(range(2))')
    actual_without_starred = StarredUnpackingTransformer().visit(ast.parse('l = [*range(2)]'))
    assert ast.dump(expected_without_starred) == ast.dump(actual_without_starred)

    expected_with_starred = ast.parse('''
l = [] + list(range(2)) + [] + list(range(3)) + [4]
''')
    actual_with_starred = StarredUnpackingTransformer().visit(ast.parse('''
l = [*range(2), 4, *range(3)]
'''))
    assert ast.dump(expected_with_starred) == ast.dump(actual_with_starred)

    expected_another_with_

# Generated at 2022-06-12 04:02:35.536177
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list1 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id="value1")), ast.Num(n=1)])
    list2 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id="value1")), ast.Num(n=1)])
    expected = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)]), op=ast.Add(), right=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='value1')], keywords=[]))
    expected = ast.BinOp(left=expected, op=ast.Add(), right=ast.List(elts=[ast.Num(n=1)]))

# Generated at 2022-06-12 04:02:41.210957
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast.ast3 import parse

    code = """
print(*range(1), *range(3))
"""
    t = StarredUnpackingTransformer()
    tree = parse(code)
    t.visit(tree)
    t._tree_changed = False
    assert tree == parse("print(*(list(range(1)) + list(range(3))))")


# Generated at 2022-06-12 04:02:45.879317
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    frm = ast.parse("foo(*args)")
    t = StarredUnpackingTransformer()
    t.visit(frm)
    assert ast.dump(frm) == "Expr(value=Call(func=Name(id='foo', ctx=Load()), args=[Starred(value=args)], keywords=[]))"


# Generated at 2022-06-12 04:02:53.862329
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typechecker import TypeChecker
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    source = ast.parse("""
    [2, *range(10), 1]
        """)
    tree = StarredUnpackingTransformer().visit(source)
    assert TypeChecker().visit(tree) == ast.parse("""
    [2] + list(range(10)) + [1]
        """)



# Generated at 2022-06-12 04:03:00.388653
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helpers import get_ast, compare_asts
    from . import StarredUnpackingTransformer
    example = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    node = get_ast(example)
    StarredUnpackingTransformer().visit(node)
    actual = compile(node, '<string>', 'eval')

    compare_asts(expected, actual)


# Generated at 2022-06-12 04:03:08.589277
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t._has_starred([ast.Starred(value=ast.Name(id='a'))])
    assert not t._has_starred([ast.Name(id='a')])
    assert t._split_by_starred([ast.Name(id='a'), ast.Starred(value=ast.Name(id='a')), ast.Name(id='c')]) == [[ast.Name(id='a')], ast.Starred(value=ast.Name(id='a')), [ast.Name(id='c')]]

# Generated at 2022-06-12 04:03:17.190679
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('[2] + list(range(10)) + [1]')
    StarredUnpackingTransformer().visit(node)

    assert ast.dump(node, annotate_fields=False) == ast.dump(
        ast.parse('print(*[2] + list(range(10)) + [1])'), annotate_fields=False
    )

# Generated at 2022-06-12 04:03:18.130610
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:22.939606
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_ = ast.parse('print(1)')

    output = StarredUnpackingTransformer().visit(input_)
    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Num(n=1)
        ],
        keywords=[]
    )

    assert ast.dump(output) == ast.dump(expected)



# Generated at 2022-06-12 04:03:27.706134
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    source = "[2, *range(10), 1]"
    tree = ast.parse(source)
    result = astor.to_source(StarredUnpackingTransformer().visit(tree))
    assert result == "[2] + list(range(10)) + [1]\n"



# Generated at 2022-06-12 04:03:28.526299
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(1)


# Generated at 2022-06-12 04:03:34.533824
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[
        ast.Constant(value=2),
        ast.Starred(value=ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Constant(value=10)],
            keywords=[])),
        ast.Constant(value=1)])

# Generated at 2022-06-12 04:03:45.713585
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
     sample = """
        [2, *range(10), 1]
        [1, *range(10)]
        [1]
        [1,  *range(10), 2]
        [1, *range(10), 2, *range(5), 3]
        [1, *range(10), *range(5), 5]
        [1, *range(10), 2, *range(5)]
        [1, 2, 3, 4, 5]
        """

# Generated at 2022-06-12 04:03:48.903025
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = ast.parse("[2, *range(10), 1]")
    print(ast.dump(source))
    tree = StarredUnpackingTransformer().visit(source)
    print(ast.dump(tree))


# Generated at 2022-06-12 04:03:53.343363
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTest
    class Test(BaseNodeTransformerTest):
        transformer = StarredUnpackingTransformer
        file_path = __file__
        cases = [
            '[]',
            '[2, *range(10), 1]',
        ]

    Test().test()


# Generated at 2022-06-12 04:03:58.546575
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from script_compiler.transformer.starred_unpacking import StarredUnpackingTransformer
    myfile = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    actual = StarredUnpackingTransformer().visit(myfile)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-12 04:04:06.364797
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .asserts import assert_transform

    assert_transform(
        StarredUnpackingTransformer,
        'print(*[1, "foo"])',
        'print(*(list([1, "foo"])))',
    )

# Generated at 2022-06-12 04:04:13.656702
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast

    node = ast.parse("[2, *range(10), 1]").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)
    assert len(node.value.elts) == 3

    assert isinstance(node.value.elts[0], ast.Num)
    assert node.value.elts[0].n == 2

    assert isinstance(node.value.elts[1], ast.Starred)
    assert isinstance(node.value.elts[1].value, ast.Call)
    assert isinstance(node.value.elts[1].value.func, ast.Name)
    assert node.value.elts[1].value.func.id == "range"

# Generated at 2022-06-12 04:04:15.407517
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        StarredUnpackingTransformer()
    except Exception as e:
        print(repr(e))
        assert False


# Generated at 2022-06-12 04:04:22.652492
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    new_module = transformer.visit(module)
    assert len(new_module.body) == 1
    body = new_module.body.pop()

    assert isinstance(body, ast.Expr)
    assert isinstance(body.value, ast.BinOp)
    assert isinstance(body.value.left, ast.List)
    assert isinstance(body.value.left.elts.pop(), ast.Num)
    assert isinstance(body.value.left.elts.pop(), ast.Num)
    assert isinstance(body.value.right, ast.Call)
    assert isinstance(body.value.right.func, ast.Name)

# Generated at 2022-06-12 04:04:28.838390
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    data = """
    [1, *x, *y, 2]
    """
    should_be = """
    list([1]) + list(x) + list(y) + [2]
    """
    node = ast.parse(data)
    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)
    evaluated = ast.dump(new_node)
    assert evaluated == should_be

# Generated at 2022-06-12 04:04:29.939792
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:04:40.211984
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Num(n=1)], ctx=ast.Load())
    

# Generated at 2022-06-12 04:04:47.233856
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..asdl import asdl
    from .asdl import AsdlTransformer

    node1 = asdl('[2, *range(10), 1]')
    root1 = AsdlTransformer().visit(node1)
    result1 = StarredUnpackingTransformer().visit(root1)
    assert result1.left.args[0].elts[0].n == 2
    assert result1.left.args[0].elts[1].func.id == 'range'
    assert result1.left.args[0].elts[2].n == 10
    assert result1.right.n == 1

    node2 = asdl('[2, *range(10)]')
    root2 = AsdlTransformer().visit(node2)
    result2 = StarredUnpackingTransformer().visit(root2)


# Generated at 2022-06-12 04:04:49.922861
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = ast.List()
    y = StarredUnpackingTransformer()
    z = y.visit(x)
    assert z is x
    assert not y.tree_changed


# Generated at 2022-06-12 04:04:52.494485
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    algo = StarredUnpackingTransformer()
    assert algo is not None


# Generated at 2022-06-12 04:05:00.752865
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:05:05.615889
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('''[2, *range(10), 1]''').body[0].value
    assert isinstance(node, ast.List)
    result = StarredUnpackingTransformer().visit(node)
    assert isinstance(result, ast.BinOp)



# Generated at 2022-06-12 04:05:07.280548
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

    

# Generated at 2022-06-12 04:05:13.982979
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .unparse import Unparser
    from .parse import parse
    from .get_logger import get_logger
    log = get_logger(__name__)

    src = """
    [2, *range(10), 1]
    """
    tree = parse(src)
    t = StarredUnpackingTransformer()
    res = t.visit(tree)
    r = Unparser(res)
    log.info('Out: {}'.format(r))

# Generated at 2022-06-12 04:05:23.061650
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(module)
    assert isinstance(result, ast.Module)
    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.BinOp)
    assert isinstance(result.body[0].value.left, ast.BinOp)
    assert isinstance(result.body[0].value.right, ast.List)
    assert len(result.body[0].value.right.elts) == 1
    assert isinstance(result.body[0].value.op, ast.Add)

# Generated at 2022-06-12 04:05:33.292849
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = '''list(range(1, 2), *range(3), range(5, 6))'''
    p = ast.parse(src)
    node = p.body[0].value
    converter = StarredUnpackingTransformer()
    node = converter.visit(node)
    assert isinstance(node.args[0], ast.Starred), node.args
    assert isinstance(node.args[0].value, ast.BinOp), node.args[0]
    assert isinstance(node.args[0].value.left, ast.List), node.args[0]
    assert isinstance(node.args[0].value.right.right, ast.List), node.args[0]
    assert isinstance(node.args[0].value.right.left, ast.Call), node.args[0]



# Generated at 2022-06-12 04:05:35.984712
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(3), *range(2), 2)'
    expected = 'print(*(list(range(3)) + list(range(2)) + [2]))'
    
    result = StarredUnpackingTransformer().transform(source)
    assert expected == result

# Generated at 2022-06-12 04:05:39.582935
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    result = compile_ast(input, StarredUnpackingTransformer)
    assert result == expected

# Generated at 2022-06-12 04:05:45.153001
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import roundtrip_unparse, compare_ast

    source = 'a = my_func(*range(10), *range(5))'
    expected = 'a = my_func(*(list(range(10)) + list(range(5))))'
    compare_ast(roundtrip_unparse(expected), StarredUnpackingTransformer, source, mode='exec')



# Generated at 2022-06-12 04:05:51.266951
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:06:14.924361
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
            print(*range(1), *range(3))
        To:
            [2] + list(range(10)) + [1]
            print(*(list(range(1)) + list(range(3))))

        """
        target = (3, 4)

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True

            return False

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            """Split `xs` to separate list by Starred."""
            lists = [[]]  #

# Generated at 2022-06-12 04:06:17.118539
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('start test StarredUnpackingTransformer_visit_Call()')
    # case 1:

# Generated at 2022-06-12 04:06:27.724762
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import UnitTestTransformer
    from .printer import print_ast


# Generated at 2022-06-12 04:06:32.042603
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"

    expected_code = "[2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)

    print(result)
    assert result == expected_code


# Generated at 2022-06-12 04:06:36.304755
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    lines = ['print(*range(1), *range(3))']
    node = ast.parse(lines[0])
    StarredUnpackingTransformer().visit(node)
    # print(dump(node))
    exec(compile(node, filename="<ast>", mode="exec"))


# Generated at 2022-06-12 04:06:41.560260
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class DummyTransformer(BaseNodeTransformer):
        pass
    n = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer(n).visit(n)
    assert ast.dump(n) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list'), args=[Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))])"


# Generated at 2022-06-12 04:06:46.508347
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''print(*range(1), *range(3))''')
    expected = ast.parse('''print(*(list(range(1)) + list(range(3))))''')
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 04:06:50.270729
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    c = StarredUnpackingTransformer()
    node = ast.parse('print(*range(1), *range(3))').body[0]

    expected = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]
    actual = c.visit(node)
    assert actual == expected



# Generated at 2022-06-12 04:06:56.797670
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'

    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    generated_code = compile(node, '', 'exec').co_consts[1]

    expected_node = ast.parse(expected_code)
    expected_code = compile(expected_node, '', 'exec').co_consts[1]

    assert generated_code == expected_code, 'Code does not match'



# Generated at 2022-06-12 04:07:01.788149
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tr = StarredUnpackingTransformer()
    call = ast.Call(func=ast.Attribute(value=ast.Name(id='math'), attr='sin'), args=[ast.Name(id='x'), ast.Starred(value=ast.Name(id='args'))], keywords=[])
    call_new = tr.visit(call)
    assert call_new.args == [ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='args')], keywords=[]))]


# Generated at 2022-06-12 04:07:17.175200
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from . import TreeConverter
    from .transforms.starred_unpacking import StarredUnpackingTransformer

    src = """
        print(*range(1), *range(3))
    """

    expected = """
        print(*(list(range(1)) + list(range(3))))
    """

    b = ast.parse(src).body[0].value
    b = StarredUnpackingTransformer().visit(b)
    b = StarredUnpackingTransformer().visit(b)
    b = TreeConverter().visit(b)
    assert expected == b



# Generated at 2022-06-12 04:07:27.553251
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:07:30.521551
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:07:35.495179
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))')
    x = StarredUnpackingTransformer()
    result = x.visit(node)
    assert result.body[0].value.func.id == 'print'
    assert result.body[0].value.args[0].func.id == 'list'

# Generated at 2022-06-12 04:07:41.319954
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import enum
    import typing as tp
    import astor
    from astmonkey import transformers

    def to_source(node):
        return astor.to_source(node).rstrip()

    source_code = """
    print(*range(1), *range(3))
    """

    ast_tree = ast.parse(source_code)
    tree = transformers.ParentChildNodeTransformer().visit(ast_tree)
    unpacked = StarredUnpackingTransformer().visit(tree)
    expected_source_code = """
        print(*(list(range(1)) + list(range(3))))
    """
    assert to_source(unpacked) == expected_source_code.lstrip()



# Generated at 2022-06-12 04:07:47.317410
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = """
[
    *range(10), 
    *range(9), 
    *range(8),
]
"""
    transformer = StarredUnpackingTransformer()
    output = transformer.visit(ast.parse(input))  # type: ignore
    assert output
    assert ast.dump(output) == ast.dump(ast.parse(
        """
[
    list(range(10)) + list(range(9)) + list(range(8))
]
"""
    ))

# Generated at 2022-06-12 04:07:55.409512
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .transformer_test_helpers import run_transformer


# Generated at 2022-06-12 04:08:01.090077
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    node_before = ast.parse(textwrap.dedent("""\
        print(1, 2, *range(3))
        print(1, *range(3), 2, *range(4))"""))

    node_after = ast.parse(textwrap.dedent("""\
        print(*(list([1, 2]) + list(range(3))))
        print(*(list([1]) + list(range(3)) + list([2]) + list(range(4))))"""))

    assert transformer.visit(node_before) == node_after


# Generated at 2022-06-12 04:08:10.371127
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('Testing StarredUnpackingTransformer.visit_Call()...', end=' ')
    tree = ast.parse('print(range(1), *range(3), end="a")')
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    node = node.value

    assert len(node.args) == 3

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)

    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.Starred)
    starred = result.args[0]
    assert isinstance(starred.value, ast.BinOp)
    binop = starred.value

# Generated at 2022-06-12 04:08:12.955481
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse
    from .test_imports import ImportAndImportFromTransformer
    from .unpack_iterable_arg import UnpackIterableArgTransformer


# Generated at 2022-06-12 04:08:34.661711
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    xs = [2, *range(10), 1]
    xs1 = [2] + list(range(10)) + [1]

    assert(xs == xs1)

    xs2 = [0, 1, 2, 3]
    xs = [2, *xs2, 1]
    xs3 = [2] + xs2 + [1]
    assert(xs == xs3)


# Generated at 2022-06-12 04:08:35.451698
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:08:45.244840
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from nuitka.nodes.AssignNodes import ExpressionTargetVariableRef
    from nuitka.nodes.CallNodes import ExpressionCallNoKeywords
    from nuitka.nodes.ConstantRefNodes import ExpressionConstantRef
    from nuitka.nodes.FunctionNodes import ExpressionFunctionBody
    from nuitka.nodes.ParameterSpecs import ParameterSpec
    from nuitka.nodes.ReturnNodes import StatementReturn
    from nuitka.nodes.StatementNodes import StatementsSequence
    from nuitka.nodes.VariableRefNodes import ExpressionTargetTempVariableRef


# Generated at 2022-06-12 04:08:51.196876
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # Node
    x = ast.Call()

    # Node type
    assert isinstance(x, ast.Call)
    assert issubclass(type(x), ast.AST)

    # Fields
    assert isinstance(x.args, list) # args
    assert isinstance(x.keywords, list) # keywords
    assert isinstance(x.func, ast.expr) # func
    assert isinstance(x.starargs, ast.expr) # starargs
    assert isinstance(x.kwargs, ast.expr) # kwargs

    # repr
    assert repr(x) == '<Call at 0x10f7d7e10>'
    assert str(x) == '<Call at 0x10f7d7e10>'

# Generated at 2022-06-12 04:08:56.529943
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ts = StarredUnpackingTransformer(
        ast.parse(
            """x(range(1), *range(2), **{'b': 2})"""
        )
    )
    res = ts.visit(ts._tree)
    assert res == """\
x(*(list(range(1)) + list(range(2)))
  , **{'b': 2})"""


# Generated at 2022-06-12 04:09:01.462679
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import compile
    code = compile(
        """
        print(1, *range(3), 2, *range(4))
        """,
        StarredUnpackingTransformer
    )
    assert dedent(code) == dedent("""
    print(*(list([1, 2]) + list(range(3)) + list(range(4))))
    """)

# Generated at 2022-06-12 04:09:07.957718
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import sys
    import astunparse
    from .utils import roundtrip

    code = """\
    print(*[])
    print(*(1, 2), 3)
    print(*(1, 2))
    """
    expected = """\
    print()
    print(*(list([]) + list(1, 2)) + [3])
    print(*(list([]) + list(1, 2)))
    """

    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    got = astunparse.unparse(tree)
    assert roundtrip(got) == roundtrip(expected)


# Generated at 2022-06-12 04:09:17.367975
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:09:22.118632
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import generate, round_trip, compare_ast
    code = 'print(*range(1), *range(3))'

    tree = ast.parse(code)
    res_tree = round_trip(StarredUnpackingTransformer(), tree)
    compare_ast(generate(res_tree), 'print(*(list(range(1)) + list(range(3))))')



# Generated at 2022-06-12 04:09:31.334832
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import from_source, to_source
    from .transformer import Transformer, define_transformer
    from .node_visitor import GhostTransformer
    from .t_List import ListTransformer
    from .t_Starred import StarredTransformer

    @define_transformer
    class StarredTestTransformer(Transformer):
        def visit_List(self, node):
            return ListTransformer.visit_List(self, node)

        def visit_Starred(self, node):
            return StarredTransformer.visit_Starred(self, node)

        def visit_Call(self, node):
            return StarredUnpackingTransformer.visit_Call(self, node)

    # check not changed
    node = from_source('list(1, *range(2), 3)')
    assert to_source

# Generated at 2022-06-12 04:10:11.062173
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:10:19.249002
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    module = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    transformed_module = StarredUnpackingTransformer().visit(module)
    assert expected.body[0].value.args[0].value.left.func.name == \
        transformed_module.body[0].value.args[0].value.left.func.name
    assert expected.body[0].value.args[0].value.right.func.name == \
        transformed_module.body[0].value.args[0].value.right.func.name


# Generated at 2022-06-12 04:10:26.628375
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .example_code import LIST_UNPACK_EXAMPLE

    root = ast.parse(LIST_UNPACK_EXAMPLE)

    assert isinstance(root.body[0].value, ast.List)

    StarredUnpackingTransformer().visit(root)

    assert isinstance(root.body[0].value, ast.Call)
    assert isinstance(root.body[0].value.args[0].value, ast.BinOp)
    assert isinstance(root.body[0].value.args[0].value.left, ast.List)
    assert isinstance(root.body[0].value.args[0].value.right, ast.Call)


# Generated at 2022-06-12 04:10:34.460020
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import make_unop_call, assert_tree

    assert_tree(
        src=make_unop_call('StarredUnpackingTransformer', 'print(*range(1), *range(3))'),
        expected=make_unop_call('StarredUnpackingTransformer', 'print(*(list(range(1)) + list(range(3))))'))

    assert_tree(
        src=make_unop_call('StarredUnpackingTransformer', 'print(1, *range(1), *range(3))'),
        expected=make_unop_call('StarredUnpackingTransformer', 'print(1, *(list(range(1)) + list(range(3))))'))


# Generated at 2022-06-12 04:10:38.459107
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_node = _parse_ast('print(*range(1), *range(3))')
    ast_node = StarredUnpackingTransformer(None).visit(ast_node)
    assert _ast_to_code(ast_node) == 'print(*(list(range(1)) + list(range(3))))'



# Generated at 2022-06-12 04:10:46.874057
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseCodeGenerator
    from .base import BaseNodeTransformer
    from .base import NodeTransformer

    class TestCodeGenerator(BaseCodeGenerator):
        def __init__(self, node: ast.AST, file: TextIO, *, indentation: str = "", verbose: bool = False):
            self.visitor: NodeTransformer = StarredUnpackingTransformer(
                node=node,
                file=file,
                indentation=indentation,
                verbose=verbose,
            )

        def generic_visit(self, node: ast.AST):
            method = 'visit_' + node.__class__.__name__
            visitor = getattr(self.visitor, method, self.visitor.generic_visit)
            return visitor(node)


# Generated at 2022-06-12 04:10:54.945240
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Check that the transformer correctly transforms call with starred arguments."""
    node = ast.Call(func=ast.Name(id='f'), args=[ast.Num(1), ast.Starred(value=ast.Name(id='a'), ctx=ast.Store())], keywords=[])
    expected_node = ast.Call(func=ast.Name(id='f'), args=[ast.Starred(value=ast.BinOp(left=ast.List(elts=[ast.Num(1)]), right=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='a')], keywords=[]), op=ast.Add()))], keywords=[])
    transformed_node = StarredUnpackingTransformer().visit(node)
    assert transformed_node == expected_node


# Generated at 2022-06-12 04:10:59.106237
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node_before = ast.parse("print(*range(1), *range(3))").body[0]
    node_after = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]
    assert transformer.visit(node_before) == node_after

# Generated at 2022-06-12 04:11:07.486139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .unparse_compat import unparse

    exec(compile(
        'd = {"a": 1, "b": 2, **{"b": 3, "c": 4}}',
        '<test>', 'exec'))
    assert d == {'a': 1, 'b': 3, 'c': 4}

    exec(compile(
        'a = [1, 2, *range(10), 4, *range(100)]',
        '<test>', 'exec'))
    assert a == [1, 2] + list(range(10)) + [4] + list(range(100))

    exec(compile(
        'a = [*range(5), *range(1, 5), *range(5), *range(2, 5), "*"]',
        '<test>', 'exec'))
   

# Generated at 2022-06-12 04:11:16.274591
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def transform(code: str) -> bytes:
        tree = ast.parse(code)
        transformer = StarredUnpackingTransformer()
        tree = transformer.visit(tree)
        return compile(tree, '<test>', 'exec')
