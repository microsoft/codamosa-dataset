

# Generated at 2022-06-12 04:01:55.324452
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    # test
    input_source = """
    {'a': 1}
    dict(**{'a': 1})
    """
    expected_output = """
    {'a': 1}
    dict(**{'a': 1})
    """
    # create objects
    test_obj = StarredUnpackingTransformer()
    # test with single source code
    tree = ast.parse(input_source)
    test_obj.visit(tree)
    transformed_output = astor.to_source(tree)

    # check result
    assert expected_output == transformed_output


# Generated at 2022-06-12 04:02:01.560989
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """ Unit test for class StarredUnpackingTransformer
        This test should run with pytest.
    """
    source = "print(1,2, 3, *range(10), *range(1))"
    temp = StarredUnpackingTransformer()
    assert 'print(*(list([1, 2, 3])+list(range(10))+list(range(1))))' == str(temp.visit(ast.parse(source).body[0]))

# Generated at 2022-06-12 04:02:12.216423
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = [2, *range(10), 1]
    with pytest.raises(AssertionError):
        StarredUnpackingTransformer(tree)
    tree2 = ast.parse('''
        [2, *range(10), 1]
        ''')
    tree3 = ast.parse('''
        print(*range(1), *range(3))
        ''')
    tree4 = ast.parse('''
        print(*range(1), *range(3), 7)
        ''')
    tree5 = ast.parse('''
        print(7, *range(1), *range(3))
        ''')
    tree6 = ast.parse('''
        [7, *range(1), 1, *range(3)]
        ''')
    star_unpack_1

# Generated at 2022-06-12 04:02:18.697947
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    input_data = ast.parse(
        "[2, *range(10), 1, *[1,2]]")
    expected_result = ast.parse(
        "([2] + list(range(10)) + [1]) + ([1, 2])"
    )
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(input_data)
    assert ast.dump(result) == ast.dump(expected_result)



# Generated at 2022-06-12 04:02:27.276160
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(2))").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert node.value.func.id == "print"
    assert len(node.value.args) == 1
    assert isinstance(node.value.args[0], ast.Starred)
    assert isinstance(node.value.args[0].value, ast.Call)
    assert node.value.args[0].value.func.id == "range"
    assert len(node.value.args[0].value.args) == 1
    assert isinstance(node.value.args[0].value.args[0], ast.Num)
    assert node.value.args[0].value.args[0].n == 2

# Generated at 2022-06-12 04:02:32.939326
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = 'print(1, 2, *range(1), *range(2))'
    expected = 'print(1, 2, *(list(range(1)) + list(range(2))))'
    tree = ast.parse(source)
    print(tree)
    StarredUnpackingTransformer().visit_Module(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == expected


# Generated at 2022-06-12 04:02:38.053756
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    original = """print(1, *range(3), 4, *range(5))"""
    expected = """print(*(list([1]) + list(range(3)) + list([4]) + list(range(5))))"""

    tree = ast.parse(original)
    StarredUnpackingTransformer().visit(tree)

    assert expected == astor.to_source(tree)


# Generated at 2022-06-12 04:02:44.397025
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .util import parse

    sample_code = """[2, *range(10), 1]
    print(*range(1), *range(3))"""
    tree = parse(sample_code)
    expected_tree = """[2, list(range(10)), 1]
print(*(list(range(1)) + list(range(3))))"""

    assert StarredUnpackingTransformer(tree).result == parse(expected_tree)

# Generated at 2022-06-12 04:02:47.934775
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = '''\
[2, *range(10), 1]'''

    expected = '''\
[2] + list(range(10)) + [1]'''

    xformer = StarredUnpackingTransformer()
    actual = xformer.transform_source(input).strip()
    assert actual == expected


# Generated at 2022-06-12 04:02:55.451904
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Transformer(StarredUnpackingTransformer):
        def visit_Name(self, node):
            return node

    node = ast.parse("""
        f(2, *args(), *args())
    """).body[0]
    expected = ast.parse("""
        f(*([2] + list(args()) + list(args())))
    """).body[0]
    assert expected == Transformer().visit(node)

# Generated at 2022-06-12 04:03:08.955381
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(
        func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])
    sut = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:11.237124
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

# Unit tests for visit_List method of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:03:15.840082
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
a = 1
b = [2, *range(10), 1]
    """
    tree = compile_to_ast(code)

    StarredUnpackingTransformer().visit(tree)
    exec(compile(tree, '', 'exec'))

    assert locals()['b'] == [2] + list(range(10)) + [1]


# Generated at 2022-06-12 04:03:26.618621
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .utils import round_trip
    from .test_utils import TransformerTestCase
    from typed_ast.ast3 import parse

    code = '''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    '''

    class Test(TransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_code = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        """


# Generated at 2022-06-12 04:03:33.608507
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = ast.parse("[2, *range(10), 1]")
    b = StarredUnpackingTransformer().visit(a)
    assert len(b.body) == 1
    a = b.body[0].value
    assert isinstance(a, ast.BinOp)
    assert isinstance(a.left, ast.List)
    assert isinstance(a.op, ast.Add)
    assert isinstance(a.right, ast.BinOp)
    assert isinstance(a.right.left, ast.Call)
    assert isinstance(a.right.op, ast.Add)
    assert isinstance(a.right.right, ast.List)
    a = ast.parse("[2] + list(range(10)) + [1]")
    assert str(b) == str(a)



# Generated at 2022-06-12 04:03:40.995465
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("x = [2, *range(10), 1]")
    target = ast.parse("x = [2] + list(range(10)) + [1]")
    assert transformer.visit(node) == target

    transformer = StarredUnpackingTransformer()
    node = ast.parse("x = [*range(10)]")
    target = ast.parse("x = list(range(10))")
    assert transformer.visit(node) == target



# Generated at 2022-06-12 04:03:48.467399
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    test_code = "[2, *range(10), 1]"
    test_ast = ast.parse(test_code)

    expected_code = "[2] + list(range(10)) + [1]"
    expected_ast = ast.parse(expected_code)

    transformer = StarredUnpackingTransformer()
    transformed_ast = transformer.visit(test_ast)
    transformed_code = astor.to_source(transformed_ast)

    assert transformed_code == expected_code


# Generated at 2022-06-12 04:03:53.611412
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    n = ast.parse("print(1, *range(3), 2)").body[0]
    assert isinstance(n, ast.Expr)

    o = StarredUnpackingTransformer(n)
    assert astor.to_source(o) == "print(*(list(range(3)) + [1] + [2]))"



# Generated at 2022-06-12 04:04:01.111075
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import wrap_in_Module, wrap_in_FunctionDef, wrap_in_Expr

    class TestCase(BaseNodeTransformerTestCase):
        def create_NodeTransformer(self) -> BaseNodeTransformer:
            return StarredUnpackingTransformer()

# Generated at 2022-06-12 04:04:10.964297
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from _ast_transformer.compiler import Compiler

    source = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    module = ast.parse(source)
    new_module = Compiler.apply_transformer(module, StarredUnpackingTransformer)
    assert Compiler.compile_ast(new_module) == expected

    # Without *args - nothing should change
    source = """
    print(range(1), range(3))
    """
    module = ast.parse(source)
    new_module = Compiler.apply_transformer(module, StarredUnpackingTransformer)
    assert Compiler.compile_ast(new_module) == source

    # test without change
    source

# Generated at 2022-06-12 04:04:27.607759
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    t.transform(ast.parse('print(*range(10))'))
    assert t._tree_changed is True
    assert ast.dump(t.tree) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[[Starred(value=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load(10))], keywords=[]), right=Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load(10))], keywords=[]), op=Add()))]], keywords=[]))])"


# Generated at 2022-06-12 04:04:33.652012
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
        print(*range(10), *range(10))
    """
    tree = ast.parse(source)
    expected = """
        print(*(list(range(10)) + list(range(10))))
    """
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    assert astor.to_source(tree) == expected


# Generated at 2022-06-12 04:04:43.213486
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def input_for_code(code):
        return ast.parse(code, mode='eval').body

    def output_for_input(input_):
        transformer = StarredUnpackingTransformer()
        return transformer.visit(input_)

    def output_for_code(code):
        return output_for_input(input_for_code(code))

    def test_nodes(node_input, node_output):
        assert node_input is not node_output
        assert output_for_input(node_input) == node_output

    def test_codes(code_input, code_output):
        assert output_for_code(code_input) == input_for_code(code_output)

    def test_cases(input_, output):
        if isinstance(input_, ast.AST):
            test_n

# Generated at 2022-06-12 04:04:51.386870
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(1, *range(5), 2)")
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    assert str(tree) == 'print(*(list(range(5)) + [2]))\n'

    tree = ast.parse("print(1, *range(5), *range(1), 2)")
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    assert str(tree) == 'print(*(list(range(5)) + list(range(1)) + [2]))\n'

#Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:04:58.805224
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer([ast.Starred(value=ast.Name(id='ast', ctx=ast.Load()))]) == [ast.Call(
        func=ast.Name(id='list', ctx=ast.Load()),
        args=[ast.Name(id='ast', ctx=ast.Load())], 
        keywords=[])]

# Generated at 2022-06-12 04:05:09.021652
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    ast_node = ast.Call(func=ast.Name(id='x'), args=[ast.Starred(value=ast.Name(id='a'), ctx=ast.Load())], keywords=[])
    new_ast_node = t.visit(ast_node)
    assert isinstance(new_ast_node.args[0], ast.Starred)
    assert isinstance(new_ast_node.args[0].value, ast.Call)
    assert new_ast_node.args[0].value.func.id == 'list'
    assert new_ast_node.args[0].value.args[0].id == 'a'




# Generated at 2022-06-12 04:05:14.541316
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import ast_util

    tree = ast.parse("""
        print(*range(1), *range(3))
    """, mode='exec')

    expected_tree = ast.parse("""
        print(*(list(range(1)) + list(range(3))))
    """, mode='exec')

    StarredUnpackingTransformer().visit(tree)
    assert ast_util.is_equal_modulo_lineno(tree, expected_tree)



# Generated at 2022-06-12 04:05:23.839492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(s: str, expected: str) -> None:
        node = ast.parse(s)
        node = StarredUnpackingTransformer().visit(node)
        actual = astor.to_source(node).strip()
        assert actual == expected

    test('print(*range(1), 2, 3)', 'print(*(list(range(1)) + [2, 3]))')
    test('print(1, *range(1), 2, 3)', 'print(1, *(list(range(1)) + [2, 3]))')
    test('print(1, *range(1), *range(1), 2, 3)',
         'print(1, *(list(range(1)) + list(range(1)) + [2, 3]))')

# Generated at 2022-06-12 04:05:31.132119
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .utils import my_test_compile
    from .base import BaseNodeTransformer
    from .fix_print import FixPrintTransformer
    from .convert_from_future import ConvertFromFutureTransformer
    module = my_test_compile("""
        print(*range(1), *range(3))
        """,
        StarredUnpackingTransformer(BaseNodeTransformer()),
        FixPrintTransformer,
        ConvertFromFutureTransformer
    )

    assert module is not None



# Generated at 2022-06-12 04:05:37.366667
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('test_StarredUnpackingTransformer_visit_Call')
    from .utils import _to_code

    @StarredUnpackingTransformer.register_transformer
    class _ModuleTransformer(StarredUnpackingTransformer):
        pass

    src = """print(*[1], *[2, 3], sep=' ')"""
    print('src: ' + src)

    tree = ast.parse(src)
    module_transformer = _ModuleTransformer()
    module_transformer.visit(tree)
    dst = _to_code(tree)
    print('dst: ' + dst)

    assert dst == """print(*(list([1]) + list([2, 3])), sep=' ')"""


# Generated at 2022-06-12 04:05:54.822652
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2, ] + list(range(10)) + [1]"

    transformer = StarredUnpackingTransformer()
    assert transformer.transform_source(source) == expected


# Generated at 2022-06-12 04:06:00.158577
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import round_trip, parse
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            assert isinstance(node, ast.List)
            node.elts.append(ast.Num(1))
            return node

    b = parse("[1, *range(10), 1]")
    node = TestTransformer().visit(b)
    assert node == parse("[1, *range(10), 1, 1]")
    assert round_trip(b) == "[1, *range(10), 1]"



# Generated at 2022-06-12 04:06:11.009923
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest
    import typed_astunparse

    class TestCase(unittest.TestCase):
        def test_StarredUnpackingTransformer_visit_Call_1(self):
            transpiler = StarredUnpackingTransformer()
            parsed = ast.parse("""\
print(1, *range(1), *range(3))
            """)
            expected = ast.parse("""\
print(*((1,) + list(range(1)) + list(range(3))))
            """)
            typed_astunparse.fix_missing_locations(expected)
            self.assertEqual(expected, transpiler.visit(parsed))

        def test_StarredUnpackingTransformer_visit_Call_2(self):
            transpiler = StarredUnpackingTransformer(3, 5)

# Generated at 2022-06-12 04:06:21.806652
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .conftest import code, ast_equal

    trans = StarredUnpackingTransformer()

    assert ast_equal(code("foo", trans), code("foo"))
    assert ast_equal(code("foo+bar", trans), code("foo+bar"))
    assert ast_equal(code("(foo, bar)", trans), code("(foo, bar)"))
    assert ast_equal(code("foo, bar", trans), code("foo, bar"))

    assert ast_equal(code("[1, 2, 3]", trans), code("[1, 2, 3]"))
    assert ast_equal(code("[1, 2, *[3, 4]]", trans), code("[1, 2] + list([3, 4])"))

# Generated at 2022-06-12 04:06:27.731958
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    v = StarredUnpackingTransformer()
    v._visit(ast.parse("[2, *range(10), 1]"))  # type: ignore
    result = v.get_result()
    assert result == "[2] + list(range(10)) + [1]"

    v = StarredUnpackingTransformer()
    v._visit(ast.parse("[2, 3]"))  # type: ignore
    result = v.get_result()
    assert result == "[2, 3]"


# Generated at 2022-06-12 04:06:35.211873
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Set up arguments for constructor
    # Constructor should fail since args is not of type dict
    try:
        StarredUnpackingTransformer()
    except:
        pass

    # Constructor should fail since args is empty
    try:
        StarredUnpackingTransformer(args={})
    except:
        pass

    # Constructor should fail since args is not a dict
    try:
        StarredUnpackingTransformer(args="")
    except:
        pass

    # Constructor should fail since args is a dict but test is not of type bool
    try:
        StarredUnpackingTransformer(args={"test": None})
    except:
        pass

# Generated at 2022-06-12 04:06:40.057024
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    import parse_type as pt
    transformer = StarredUnpackingTransformer()
    code = pt.parse(
        '''
[2, *range(10), 1]
''')
    expected = pt.parse(
        '''
[2] + list(range(10)) + [1]
''')
    result = transformer.visit(code)
    assert pt.unparse(expected) == pt.unparse(result)



# Generated at 2022-06-12 04:06:45.121338
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_node_1 = ast.parse('[2, *range(10), 1]')
    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(ast_node_1)
    result = ast.parse('[2] + list(range(10)) + [1]')
    assert ast.dump(ast_node_1) == ast.dump(result)



# Generated at 2022-06-12 04:06:49.794135
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    # This test is to ensure that:
    # print(*(list(range(1)) + list(range(3))))
    # is the outcome when:
    # print(*range(1), *range(3))
    star_tested = ''
    print(*range(1), *range(3))
    star_test = StarredUnpackingTransformer()
    tree = ast.parse(star_tested)
    code = star_test.visit(tree)
    want = 'print(*(list(range(1)) + list(range(3))))'
    assert astor.to_source(code) == want

# Generated at 2022-06-12 04:06:55.194507
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # list with starred
    assert StarredUnpackingTransformer().visit_List(
        ast.parse('[2, *range(10), 1]')).as_string()\
        == 'list([2]) + list(range(10)) + list([1])'

    # other value
    assert StarredUnpackingTransformer().visit_List(
        ast.parse('[2, 1]')).as_string() == '[2, 1]'


# Generated at 2022-06-12 04:07:30.882394
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    #
    source = '[2, *range(10), 1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer.run_default(tree)
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert ast.dump(tree) == ast.dump(expected)

    source = '[a, b, *c, d, e]'
    tree = ast.parse(source)
    StarredUnpackingTransformer.run_default(tree)
    expected = ast.parse('[a, b] + list(c) + [d, e]')
    assert ast.dump(tree) == ast.dump(expected)

    source = '[*a, *b, *c, *d, *e]'
    tree = ast.parse(source)
    StarredUnpackingTrans

# Generated at 2022-06-12 04:07:39.903357
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class DummyNodeTransformer(BaseNodeTransformer):
        def visit_Num(self, node: ast.Num) -> ast.Num:
            return ast.Num(n=node.n * 100)

    node = ast.parse("[2, *range(10), 1]").body[0].value
    tree_changed, node = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:07:47.509306
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test for method visit_Call of class StarredUnpackingTransformer"""
    import ast as py_ast

    class UnitTestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def __init__(self, tree: py_ast.AST) -> None:
            self._tree_changed = False
            self.visit(tree)

        @property
        def tree_changed(self) -> bool:
            return self._tree_changed

    # test without starred
    tree = py_ast.parse(
        'print(range(3))',
        filename='<unknown>',
        mode='exec')
    actual = UnitTestStarredUnpackingTransformer(tree)
    assert not ac

# Generated at 2022-06-12 04:07:54.239340
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_helpers import module_to_str
    from .base import BaseNodeTransformer
    from typed_ast import ast3
    mod = ast3.parse('print(*range(10), 1, *range(2))')

    class TestTransformer(BaseNodeTransformer):
        @staticmethod
        def visit_Call(node):
            node.args.append(ast3.Num(3))
            return node

    new_mod = TestTransformer().visit(mod)
    assert module_to_str(new_mod) == 'print(*(list(range(10)) + [1] + list(range(2))), 3)'

# Generated at 2022-06-12 04:08:02.571170
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def test_code(code_to_test, expected_code):
        print("Testing:", code_to_test)
        print("Expected code:", expected_code)

        code_obj = compile(code_to_test, 'test.py', 'exec')
        tree = ast.parse(code_to_test)
        assert isinstance(tree, ast.Module)
        transformer = StarredUnpackingTransformer()
        new_tree = transformer.visit(tree)
        assert isinstance(new_tree, ast.Module)

        code_generated = compile(new_tree, 'test.py', 'exec')
        code_expected = compile(expected_code, 'test.py', 'exec')

        # Test that nodes are equivalent
        assert transformer.tree_changed()

        # Test that generated code is valid

# Generated at 2022-06-12 04:08:10.974070
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert not StarredUnpackingTransformer._has_starred([])
    assert not StarredUnpackingTransformer._has_starred([ast.Constant(value=2), ast.Constant(value=3)])

    assert StarredUnpackingTransformer._has_starred([ast.Constant(value=2), ast.Starred(value=ast.Name(id='asd'))])

    assert StarredUnpackingTransformer._to_sum_of_lists([]) is None
    assert StarredUnpackingTransformer._to_sum_of_lists([ast.Constant(value=2), ast.Constant(value=3)]) == \
            ast.List(elts=[ast.Constant(value=2), ast.Constant(value=3)])

# Generated at 2022-06-12 04:08:16.802972
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    b = StarredUnpackingTransformer()
    c = b.visit(ast.parse("[2, *range(10), 1]").body[0])
    assert "ast.List" in str(c)
    print(ast.dump(c))

    b = StarredUnpackingTransformer()
    c = b.visit(ast.parse("[2, range(10), 1]").body[0])
    assert "ast.List" in str(c)
    print(ast.dump(c))


# Generated at 2022-06-12 04:08:21.877949
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse("[2, 4, 1, *range(10), *range(5)]")
    tree = ast.fix_missing_locations(tree)
    tree = transformer.visit(tree)
    tree = ast.fix_missing_locations(tree)
    code = compile(tree, '<string>', 'exec')
    eval(code)



# Generated at 2022-06-12 04:08:31.733167
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node1 = ast.List(elts=[ast.Num(n=10), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Store()), ast.Num(n=2)], ctx=ast.Load())  # noqa
    node_eye = ast.List(elts=[ast.Num(n=1)], ctx=ast.Load())
    node_range = ast.Call(func=ast.Name(id='list', ctx=ast.Load()), args=[ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=10)], keywords=[])], keywords=[])  # noqa

# Generated at 2022-06-12 04:08:38.394733
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    calls = [
        'print("Hello", "world")',
        'print("Hello", *range(10), "world")',
        'print("Hello", *range(10), *range(10), "world")',
        'a("Hello", **dict(a=1, b=2))',
        'a("Hello", *range(10), **dict(a=1, b=2))',
        'a("Hello", *range(10), *range(10), **dict(a=1, b=2))',
        'a(*range(10))',
        'a(*range(10), *range(10))',
        'a(*range(10), b=1)',
        'a(*range(10), *range(10), b=1)',
    ]
    expected

# Generated at 2022-06-12 04:09:44.828838
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code = """
        f(1, *[3, 4], 2)
        """
    expected = """
        f(*(list([1]) + list([3, 4]) + list([2])))
        """
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    result = astor.to_source(node).strip()
    assert result == expected



# Generated at 2022-06-12 04:09:49.484726
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    source = 'f(2, 3, *range(2), 4, 5)'
    expected = \
    'f(*(list([2, 3]) + list(range(2)) + list([4, 5])))'
    # When
    result = compile(source, '', 'exec', ast.PyCF_ONLY_AST, optimize=2)
    StarredUnpackingTransformer().visit(result)
    # Then
    assert expected == ast.dump(result)



# Generated at 2022-06-12 04:09:56.597182
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test with List
    list_node = ast.parse('[2, *range(10), 1]').body[0].value
    standard_node = ast.parse('[2] + list(range(10)) + [1]').body[0].value
    transformed_node = StarredUnpackingTransformer().visit(list_node)
    assert ast.dump(standard_node) == ast.dump(transformed_node)

    # Test with Call
    call_node = ast.parse('print(*range(1), *range(3))').body[0]
    standard_node = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]
    transformed_node = StarredUnpackingTransformer().visit(call_node)

# Generated at 2022-06-12 04:10:04.247209
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from .test_utils import check_single_transformation

    check_single_transformation(
        StarredUnpackingTransformer,
        ast.parse('[2, *range(10), 1]'),
        ast.parse('[2] + list(range(10)) + [1]'),
        mode='eval',
    )

    check_single_transformation(
        StarredUnpackingTransformer,
        ast.parse('[2, *[1, 2, 3], 1]'),
        ast.parse('[2] + list([1, 2, 3]) + [1]'),
        mode='eval',
    )



# Generated at 2022-06-12 04:10:04.681541
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-12 04:10:05.393585
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

# Generated at 2022-06-12 04:10:08.927343
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helpers import compile_source, assert_equal_ast
    
    assert_equal_ast(
        StarredUnpackingTransformer().visit(compile_source('[2, *range(10), 1]', 3)),
        compile_source('[2] + list(range(10)) + [1]', 3),
    )


# Generated at 2022-06-12 04:10:14.444538
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    call_example = ast.parse("""
        print(1, *range(3), *range(4), 2, 3)
        """)  # type: ast.Module
    call_example.body[0] = StarredUnpackingTransformer().visit(call_example.body[0])
    assert ast.dump(call_example.body[0]) == "print(*(list([1]) + list(range(3)) + list(range(4)) + list([2]) + list([3])))"



# Generated at 2022-06-12 04:10:23.405311
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    #print(s.visit(ast.parse("[2,3,*range(10),1]").body[0]))
    print(s.visit(ast.parse("[2,1]").body[0]))
    print(s.visit(ast.parse("[2,1,*range(10)]").body[0]))
    print(s.visit(ast.parse("[2,3,*range(10),*range(5),1]").body[0]))
    #print(s.visit(ast.parse("print(*range(1),*range(3))").body[0]))

# Generated at 2022-06-12 04:10:28.662718
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import sys

    ast1 = ast.parse('print(1, *range(3), 2, *range(5)', mode='eval')
    ast2 = ast.parse('[1, *range(3), 2, *range(5), 3]', mode='eval')

    trans = StarredUnpackingTransformer(ast1)
    ast1 = trans.visit(ast1)
    sys.stdout.write(astor.to_source(ast1))

    print()
    trans = StarredUnpackingTransformer(ast2)
    ast2 = trans.visit(ast2)
    sys.stdout.write(astor.to_source(ast2))