

# Generated at 2022-06-12 04:02:01.610259
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .output_unification import dump_to_string
    orig = ast.parse("print(1, *range(3))")
    new = ast.parse("print(*(list([1]) + list(range(3))))")
    t = StarredUnpackingTransformer()
    result = t.visit(orig)
    assert len(t.errors) == 0, dump_to_string(t.errors)
    assert astor.code_gen.to_source(result) == astor.code_gen.to_source(new)

# Generated at 2022-06-12 04:02:06.709752
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = '''mylist = [1, *list(range(5)), 6]'''

    t = StarredUnpackingTransformer(s)
    t()
    assert t.get_code() == '''mylist = list(range(1, 6)) + [6]'''


# Generated at 2022-06-12 04:02:12.451351
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    star_unpacking = StarredUnpackingTransformer()
    call = ast.parse('print(*range(1), *range(3))').body[0]
    assert isinstance(call, ast.Expr)
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]

    call = star_unpacking.visit_Call(call.value)

    assert ast.dump(call) == ast.dump(expected)


# Generated at 2022-06-12 04:02:23.519387
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_field = starry_unpack._input_field
    output_field = starry_unpack._output_field
    transformer = starry_unpack.StarredUnpackingTransformer()

    input = """
[1, *(2, 3), 4]
"""
    expected = """
[1] + list((2, 3)) + [4]
"""
    assert transformer.visit(ast.parse(input, mode=input_field)) == ast.parse(expected, mode=output_field)

    input = """
list(*(2, 3), 4)
"""
    expected = """
list((2, 3), 4)
"""
    assert transformer.visit(ast.parse(input, mode=input_field)) == ast.parse(expected, mode=output_field)


# Generated at 2022-06-12 04:02:31.868851
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .transform import transform
    from .utils import get_ast, dump_ast

    code = '[2, *range(10), 1]'
    assert dump_ast(get_ast(code)) == dump_ast(
        get_ast('[2] + list(range(10)) + [1]'))

    code = 'print(*range(1), *range(3))'
    assert dump_ast(get_ast(code)) == dump_ast(
        get_ast('print(*(list(range(1)) + list(range(3))))'))

# Generated at 2022-06-12 04:02:34.854252
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compile_to_py.compiler import compile

    assert compile("print(*range(10))") == """range_=range
print(*list(range_(10)))
"""

# Generated at 2022-06-12 04:02:40.399098
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    unittest.TestCase().assertEqual(
        ast.parse(textwrap.dedent("""
            print(*(list(range(1)) + list(range(3))))
        """)),
        StarredUnpackingTransformer().visit(
            ast.parse(textwrap.dedent("""
                print(*range(1), *range(3))
            """))))



# Generated at 2022-06-12 04:02:46.186264
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    import textwrap
    t = StarredUnpackingTransformer()
    tree = ast.parse(textwrap.dedent("""
        [2, *range(10), 1]
      """))
    t.visit(tree)
    result = astor.to_source(tree)
    assert result == textwrap.dedent("""\
        ([2] + list(range(10)) + [1])
    """)


# Generated at 2022-06-12 04:02:56.023684
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse

    tree = ast.parse("[1, *range(2), 3, *range(4), 5]")

    # Test default
    assert unparse(StarredUnpackingTransformer().visit(tree)) == unparse(tree)
    assert unparse(StarredUnpackingTransformer().visit(tree)) == "[1, *range(2), 3, *range(4), 5]"

    # Test updated
    assert unparse(StarredUnpackingTransformer(update=True).visit(tree)) == \
           "[1] + list(range(2)) + [3] + list(range(4)) + [5]"


# Generated at 2022-06-12 04:03:04.923573
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0].value
    assert isinstance(node, ast.List)
    ast_transformer = StarredUnpackingTransformer()
    node = ast_transformer.visit(node)
    assert isinstance(node, ast.BinOp)
    assert isinstance(node.left, ast.List)
    assert isinstance(node.right, ast.List)
    assert isinstance(node.op, ast.Add)

    code = ast.unparse(ast.Expression(body=node))
    assert code == '[2] + list(range(10)) + [1]'

# Generated at 2022-06-12 04:03:18.728591
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert ast.dump(ast.parse("[2, *range(10), 1]").body[0]) == 'Expr(value=List(elts=[Constant(value=2, kind=None), Starred(value=Name(id=\'range\', ctx=Load()), ctx=Load()), Constant(value=1, kind=None)], ctx=Load()))'


# Generated at 2022-06-12 04:03:29.101217
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_astunparse
    from .test_base import CodeExecutor

    class Foo:
        pass

    foo = Foo()
    foo.a = 23
    foo.b = 42

    code = """
    l = [2, *range(2), 1]
    d = {'a': 1, **{'b': 2}}
    print(*l)
    """.strip()

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    new_code = typed_astunparse.unparse(tree)
    assert new_code == "l = [2] + list(range(2)) + [1]\nd = {'a': 1, **{'b': 2}}\nprint(*(list(range(0, 2)) + [1]))"
    assert CodeExec

# Generated at 2022-06-12 04:03:34.806002
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import compile_to_exec


# Generated at 2022-06-12 04:03:46.094134
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse

    src = """
    print('first', end=" ", *range(1), 'second', **{'end': '\n'})
    """
    expected = """
    def __CRAZY_UNPACKING_TMP_0():
        yield 1
    print(*(list(range(1)) + ['second']), end=' ', **{'end': '\\n'})\n\n
    """

    print('\n=== From: ===')
    print(src)
    print('=== To:  ===')
    tree = ast.parse(src)
    print(astunparse.unparse(StarredUnpackingTransformer().visit(tree)))
    print('=== Expect: ===')
    print(expected)

# Generated at 2022-06-12 04:03:48.990665
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    node = StarredUnpackingTransformer().visit(node)
    print(ast.dump(node))


# Generated at 2022-06-12 04:03:58.439364
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as ast

    # simple case
    input_code1 = """
print(1, *range(4))    
"""
    tree1 = ast.parse(input_code1)
    tree1 = StarredUnpackingTransformer().visit(tree1)
    output_code1 = compile(tree1, filename='<none>', mode='exec')
    result1 = {}
    exec (output_code1, result1)
    print(list(result1['__builtins__'].values()))

    # simple case, 1
    input_code1 = """
print(*range(4))
"""
    tree1 = ast.parse(input_code1)
    tree1 = StarredUnpackingTransformer().visit(tree1)

# Generated at 2022-06-12 04:04:04.585594
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse(
        "print(*range(2), 3, *range(3), *range(3))",
        mode="exec",
    )
    StarredUnpackingTransformer().visit(module)
    assert ast.dump(module) == "exec(print(*(list(range(2)) + [3] + list(range(3)) + list(range(3)))))"


# Generated at 2022-06-12 04:04:09.829077
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import pytest
    from typed_astunparse import unparse
    src = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = ast.parse(src)
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(tree)
    assert expected == unparse(tree)


# Generated at 2022-06-12 04:04:19.831282
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .common import setup_function_def_for_compare, \
        _transformer_from_source
    from typed_ast.ast3 import parse

    def transform(source: str) -> ast.AST:
        module_node = parse(source)
        node = setup_function_def_for_compare(module_node)

        transformer = _transformer_from_source(StarredUnpackingTransformer, source)
        return transformer.visit(node)

    __test__ = {
        # StarredUnpackingTransformer
        'test_StarredUnpackingTransformer_visit_Call': test_StarredUnpackingTransformer_visit_Call,
    }

# Generated at 2022-06-12 04:04:30.452281
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def transform(code: str) -> ast.Call:
        node = ast.parse(code)

        xformer = StarredUnpackingTransformer()
        xformer.visit(node)

        return node.body[0].value


# Generated at 2022-06-12 04:04:39.206617
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    result = StarredUnpackingTransformer().visit(node)
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]
    assert result.value == expected.value



# Generated at 2022-06-12 04:04:46.654945
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    code = """
x = [1, 2, 3]
y = [1, 2, 3, 4, 5]
z = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
a = ['a', 'b', 'c', 'd']
b = ['a', *z, 'b']
    """
    expected = """
x = [1, 2, 3]
y = [1, 2, 3, 4, 5]
z = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
a = ['a', 'b', 'c', 'd']
b = ['a'] + list(z) + ['b']
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
   

# Generated at 2022-06-12 04:04:56.613871
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Create AST node for expression [2, *range(10), 1]
    range_call = ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])
    starred_expr = ast.Starred(value=range_call)
    list_expr = ast.List(elts=[ast.Num(n=2), starred_expr, ast.Num(n=1)])

    # Create instance of StarredUnpackingTransformer
    obj = StarredUnpackingTransformer()

    # Call visit_List with expression [2, *range(10), 1]
    result = obj.visit_List(list_expr)

    # Check result
    assert result.elts[0].left.elts[0].args[0].n == 2
    assert result.elts[0].left

# Generated at 2022-06-12 04:04:57.606679
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-12 04:05:09.071080
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    file = ast.parse('print(*range(10), 1, *range(1))')

    StarredUnpackingTransformer().visit(file)


# Generated at 2022-06-12 04:05:13.421361
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import get_test_case_names, get_code, get_expected_code
    
    for name in get_test_case_names(__file__, 'StarredUnpackingTransformer_visit_Call_'):
        yield check_StarredUnpackingTransformer_visit_Call, name


# Generated at 2022-06-12 04:05:22.302598
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class _MockStarredUnpackingTransformer(StarredUnpackingTransformer):
        def __init__(self, value: List[ast.expr]):
            self.value = value
            super().__init__()

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            return True

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            return [self.value]

    trans = _MockStarredUnpackingTransformer([ast.List(elts=[ast.Literal(value=1)])])

    import astor

    class_ = ast.ClassDef(name='Foo', body=[])
    call = ast.Call(func=ast.Name(id='Foo'), args=[], keywords=[])
   

# Generated at 2022-06-12 04:05:23.180770
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()



# Generated at 2022-06-12 04:05:31.174588
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestList(unittest.TestCase):
        # [2, *range(10), 1]
        def test_1(self):
            tree = ast.parse('''[2, *range(10), 1]''')
            expected = ast.parse('''
            (List (List (Num (2)) (Call (Name (range)) (List (Num (10)))) (List (Num (1)))))
            ''')
            result = StarredUnpackingTransformer().visit(tree)
            self.assertEqual(result, expected)


# Generated at 2022-06-12 04:05:33.739902
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse(dedent("""
    [2, *range(10), 1]
    """))
    node = tree.body[0]
    assert isinstance(node, ast.Expr)

    StarredUnpackingTransformer().visit(tree)
    assert isinstance(node.value, ast.BinOp)



# Generated at 2022-06-12 04:05:42.805606
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)



# Generated at 2022-06-12 04:05:50.309407
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ast import parse as make_ast, dump
    from typed_ast.ast3 import parse as typed_parse
    import astunparse
    code = 'print(1)'
    tree = make_ast.parse(code)
    ut = StarredUnpackingTransformer()
    new_tree = ut.visit(tree)
    #assert False, dump(new_tree)
    assert astunparse.unparse(new_tree) == code
    code = 'print(*range(2))'
    tree = typed_parse(code)
    ut = StarredUnpackingTransformer()
    new_tree = ut.visit(tree)
    #assert False, dump(new_tree)
    assert astunparse.unparse(new_tree) == 'print(*list(range(2)))'

# Generated at 2022-06-12 04:05:56.879151
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(3), *range(3))')
    assert isinstance(tree.body[0].value, ast.Call)

    transformed = StarredUnpackingTransformer().visit(tree)
    print(ast.dump(transformed))
    assert isinstance(transformed.body[0].value.args[0], ast.Starred)
    assert isinstance(transformed.body[0].value.args[0].value, ast.BinOp)



# Generated at 2022-06-12 04:06:00.310800
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module = ast.parse("[2, *range(10), 1]")
    module = StarredUnpackingTransformer().visit(module)
    assert "Add" in str(module)

    module = ast.parse("print(*range(1), *range(3))")
  

# Generated at 2022-06-12 04:06:03.211257
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert StarredUnpackingTransformer.run_pipeline(
        """print(*range(1), *range(3))"""
    ) == """print(*(list(range(1)) + list(range(3))))"""

# Generated at 2022-06-12 04:06:13.353644
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import unittest
    from typed_ast import ast3 as ast
    from typed_ast import util as astutil
    class StarredUnpackingTransformer_test(unittest.TestCase):
        def test_visit_List(self):
            transformer = StarredUnpackingTransformer()
            input_ast = ast.parse('[2, *range(10), 1]')
            output_ast = transformer.visit(input_ast)
            expected_ast = ast.parse('[2] + list(range(10)) + [1]')
            diff, msg = astutil.ast2graphdiff(expected_ast, output_ast)
            self.assertEqual(msg, '')
        def test_visit_Call(self):
            transformer = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:06:24.769097
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import inspect

    from .base import BaseNodeTransformer, SourceCode

    source_code = SourceCode(inspect.getsource(test_StarredUnpackingTransformer_visit_List))
    source_code.tree = ast.parse(source_code.code)

    class ExampleTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    transformer = StarredUnpackingTransformer(ExampleTransformer())
    transformer.visit(source_code.tree)


# Generated at 2022-06-12 04:06:30.027524
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # BEFORE
    before_source = """
    print(a, *range(3), c)
    """

    # AFTER
    after_source = """
    print(*(list([a]) + list(range(3)) + [c]))
    """

    node = ast.parse(before_source)
    c = StarredUnpackingTransformer()
    c.visit(node)
    actual_source = compile(node, '<test>', mode='exec')

    assert after_source == actual_source


# Generated at 2022-06-12 04:06:36.457549
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    arg = [ast.Starred(ast.Name('a'), ast.Load()), ast.Name('b', ast.Load())]
    l = ast.List(arg)
    actual = StarredUnpackingTransformer().visit(l)
    expected = ast.Call(
        ast.Name('list', ast.Load()),
        [ast.Name('a', ast.Load())],
        []) + ast.List([ast.Name('b', ast.Load())])
    assert actual == expected


# Generated at 2022-06-12 04:06:40.406531
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert list(StarredUnpackingTransformer()._split_by_starred([ast.Num(1), ast.Starred(ast.Num(2)), ast.Num(3)])) == [[ast.Num(1)], ast.Starred(ast.Num(2)), [ast.Num(3)]]
    assert list(StarredUnpackingTransformer()._split_by_starred([ast.Num(1)])) == [[ast.Num(1)]]

# Generated at 2022-06-12 04:07:02.035179
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    program = """print(*range(5), *range(6))"""

    expected_program = """print(*(list(range(5)) + list(range(6))))"""

    module = ast.parse(program)
    # module = ast.Compare(left=ast.Name(id='a', ctx=ast.Load()), ops=[ast.Eq()], comparators=[ast.Name(id='b', ctx=ast.Load())])
    module = StarredUnpackingTransformer().visit(module)
    module = astor.to_source(module)

    print(module)
    assert module == expected_program



# Generated at 2022-06-12 04:07:06.240276
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    assert (sut.visit(ast.parse('''
print(*range(1), *range(3))
''').body[0]) == ast.parse('''
print(*(list(range(1)) + list(range(3))))
''').body[0])


# Generated at 2022-06-12 04:07:08.005857
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t is not None

# Generated at 2022-06-12 04:07:16.493391
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = textwrap.dedent("""\
        xs = [1, *[2,3], **{'a': 4}]
        ys = [1, 2, 3]
    """)
    expected = textwrap.dedent("""\
        xs = [1] + list([2,3]) + list({'a': 4})
        ys = [1, 2, 3]
    """)

    t = StarredUnpackingTransformer()
    tree = t.visit(ast.parse(src))
    t.generic_visit(tree)

    assert strip_lines(astor.to_source(tree)) == strip_lines(expected)


# Generated at 2022-06-12 04:07:24.985541
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))").body[0]
    assert isinstance(node, ast.Expr)
    assert_equal(
        node.value,
        StarredUnpackingTransformer().visit(ast.parse("print(*range(1), *range(3))").body[0]))


test_StarredUnpackingTransformer_visit_Call.description = 'Unit test for method visit_Call of class StarredUnpackingTransformer'
test_StarredUnpackingTransformer_visit_Call.timeout = 60
test_StarredUnpackingTransformer_visit_Call.hidden = False



# Generated at 2022-06-12 04:07:26.286670
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import astor

# Generated at 2022-06-12 04:07:31.485974
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import transform, assert_equal
    test_snippet = """
foo(2, *a, 3)
print(*a, **kwargs)
foo(1, *range(10), 2)
"""

    expected_snippet = """
foo(*(list(a) + [3]))
print(*(list(a) + [2]), **kwargs)
foo(*(list([1]) + list(range(10)) + list([2])))
"""

    assert_equal(StarredUnpackingTransformer,
                 test_snippet, expected_snippet,
                 returns=True)



# Generated at 2022-06-12 04:07:40.247121
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typing import Any

    from typed_ast.ast3 import parse

    source = [
        (
            'print(1, *j, *k, 1)',
            'print(*(list(j) + list(k) + [1]))'
        ),
        (
            'print(sum(1, *range(2), sum(1, *range(2), 1)))',
            'print(sum(*(list(range(2)) + [sum(*(list(range(2)) + [1]))])))',
        ),
        (
            'print(*list(range(10)))',  # No need to change
            'print(*list(range(10)))'
        )
    ]
    expected_ast = [parse(src) for src in [s[1] for s in source]]

# Generated at 2022-06-12 04:07:49.168545
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import check_equal, check_raises

    with check_equal(
        ast.parse("""
            def foo(x, *args):
                pass
            foo(1 + 2, *[i, *j] + [3, 4])
        """),
        ast.parse("""
            def foo(x, args):
                pass
            foo(1 + 2, list(range(i)) + list(range(j)) + [3, 4])
        """),
        transformers=[StarredUnpackingTransformer] * 2,
    ):
        pass


# Generated at 2022-06-12 04:07:50.385622
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-12 04:08:34.079984
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import _ast
    code = '''
        [2, *range(10), 1]
    '''
    expected = '''
        ([2] + list(range(10)) + [1])
    '''
    node = ast.parse(code)
    node = StarredUnpackingTransformer().visit(node)
    are_equal_nodes(node, expected)


# Generated at 2022-06-12 04:08:41.186702
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source='''
w=[[1, 2], [3, 4], [5, 6]]
print(*w)
print(*w[1], *w[2])
'''
    expected = '''
w = [[1, 2], [3, 4], [5, 6]]
print(*w)
print(*w[1], *w[2])
'''
    tree = ast.parse(textwrap.dedent(source))
    node = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(node).strip() == textwrap.dedent(expected).strip()

# Generated at 2022-06-12 04:08:45.423819
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''
print(*range(1), *range(3))''')
    expected_tree = ast.parse('''
print(*(list(range(1)) + list(range(3))))''')

    assert StarredUnpackingTransformer().visit(tree) == expected_tree


# Generated at 2022-06-12 04:08:48.733737
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "Expr(value=([2] + list(range(10)) + [1]))"



# Generated at 2022-06-12 04:08:58.596296
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert compile(
        'print(1, 2, 3, *range(10), 7, 8)',
        '<ast>', 'exec', optimization=-1).co_code == compile(
        '__import__("typed_ast").ast3.StarredUnpackingTransformer.run('
        'print(__import__("typed_ast").ast3.StarredUnpackingTransformer._to_sum_of_lists'
        '([ast.Call(func=ast.Name(id="list"), args=[ast.Name(id="range")], keywords=[ast.keyword(arg="start", value=ast.Num(n=3))])])),  # noqa: E501\n'
        ')',
        '<ast>', 'exec', optimization=-1).co_code


# Generated at 2022-06-12 04:09:03.600041
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_input = ast.parse(
        'print(*args, **kwargs)'
    )
    got = StarredUnpackingTransformer()(test_input)
    want = ast.parse(
        'print(*(list(args) + list(kwargs)))'
    )
    assert ast.dump(got) == ast.dump(want)



# Generated at 2022-06-12 04:09:07.026181
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expr = "print(2, *range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3)), 2))"
    actual = ast.dump(StarredUnpackingTransformer().visit(ast.parse(expr)))
    assert actual == expected


# Generated at 2022-06-12 04:09:08.079039
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t is not None


# Generated at 2022-06-12 04:09:16.291901
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code1 = "[2, *range(10), 1]\n"
    code2 = "[2, *range(10), 1]"
    expected1 = "[2] + list(range(10)) + [1]\n"
    expected2 = "[2] + list(range(10)) + [1]"

    transformer = StarredUnpackingTransformer()

    tree1 = ast.parse(code1)
    tree2 = ast.parse(code2)

    transformer.visit(tree1)
    transformer.visit(tree2)

    assert ast.dump(tree1) == expected1
    assert ast.dump(tree2) == expected2


# Generated at 2022-06-12 04:09:24.878905
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse

    class Analyzer(ast.NodeVisitor):
        def __init__(self):
            self.calls = 0
            self.names = []

        def visit_Call(self, node):
            self.calls += 1
            self.generic_visit(node)

        def visit_Name(self, node):
            if node.id == 'range':
                self.names.append(node)


    source = '[2, *range(10), 1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    Analyzer().visit(tree)

    assert Analyzer.calls == 2
    assert Analyzer.names[0].id == 'range'
    assert Analyzer.names[1].id == 'range'


# Generated at 2022-06-12 04:10:59.401112
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse
    from enum import Enum
    import textwrap

    class Nodes(Enum):
        SIMPLE_CALL = "call(value)"
        SIMPLE_CALL_LIST = "call(value) + list(value)"
        SIMPLE_CALL_LIST_LIST = "call(value) + list(value) + list(value)"

    tests = (
        ("[2, *range(10), 1]", Nodes.SIMPLE_CALL_LIST),
        ("print(*range(1), *range(3))", Nodes.SIMPLE_CALL_LIST_LIST),
    )
    for source, node in tests:
        source = textwrap.dedent(source)
        result = StarredUnpackingTransformer.run(source)
        print(result)

# Generated at 2022-06-12 04:11:04.134786
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    expected_output = '[2] + list(range(10)) + [1]'
    node = ast.parse(code).body[0].value
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert transformer.tree_changed
    assert astor.to_source(node).strip() == expected_output


# Generated at 2022-06-12 04:11:07.416329
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(1)]').body[0]
    result_node = StarredUnpackingTransformer().visit(node)
    expected_node = ast.parse('[2] + list(range(1))').body[0]
    assert result_node == expected_node


# Generated at 2022-06-12 04:11:16.194344
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def check(source: str, expected: str) -> None:
        new_tree = StarredUnpackingTransformer().visit(
            ast.parse(textwrap.dedent(source)))
        result = astor.to_source(new_tree).strip()
        assert result == expected, result
        #print(result)

    check(
        '''
        print(1, 2, 3)
        ''',
        '''
        print(1, 2, 3)
        ''')

    check(
        '''
        print(1, *range(2), 3)
        ''',
        '''
        print(*(([1] + list(range(2))) + [3]))
        ''')


# Generated at 2022-06-12 04:11:20.328367
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    st = ast.parse('''print(*range(1), *range(3))''')
    expected_st = ast.parse('''print(*(list(range(1)) + list(range(3))))''')
    actual_st = StarredUnpackingTransformer().visit(st)
    assert ast.dump(expected_st) == ast.dump(actual_st)


# Generated at 2022-06-12 04:11:24.447889
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformer
    mod = ast.parse('''
        print(*range(1), *range(3))
    ''')
    tree_changed, mod = StarredUnpackingTransformer().run(mod)
    assert tree_changed
    result = BaseNodeTransformer().visit(mod)
    assert result == "print(*((list(range(1)) + list(range(3)))))"



# Generated at 2022-06-12 04:11:33.639535
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range'))],
        keywords=[],
    )
    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='range')],
            keywords=[],
        ))],
        keywords=[],
    )
    result = StarredUnpackingTransformer().visit(node)
    assert expected == result


# Generated at 2022-06-12 04:11:39.533090
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    node = tree.body[0].value

    transformer = StarredUnpackingTransformer.visit(node)
    assert transformer.tree_changed is True
    assert transformer._tree_changed is True

    expected = ast.parse(
        """[2] + list(range(10)) + [1]""",
        mode='eval')

    assert ast.dump(expected) == ast.dump(node)

# Generated at 2022-06-12 04:11:40.302420
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-12 04:11:44.513719
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print(ast.dump(ast.parse("print(*range(1), *range(3))"), include_attributes=False))
    x = ast.parse("print(*range(1), *range(3))")
    print(ast.dump(StarredUnpackingTransformer().visit(x), include_attributes=False))
