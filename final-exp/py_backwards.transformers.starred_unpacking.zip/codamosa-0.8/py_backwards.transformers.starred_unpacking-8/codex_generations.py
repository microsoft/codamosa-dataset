

# Generated at 2022-06-12 04:01:54.132500
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-12 04:02:04.337067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def make_sample(inputStr, expectOutputStr):
        rootNode = ast.parse(inputStr)
        transformer = StarredUnpackingTransformer()
        outputNode = transformer.visit(rootNode)
        outputStr = ast.dump(transformer.visit(rootNode), include_attributes=True)
        assert outputStr == expectOutputStr


# Generated at 2022-06-12 04:02:10.036306
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._split_by_starred([ast.Name(id='a'), ast.Name(id='b'), ast.Starred(value=ast.Name(id='c'))]) == [[ast.Name(id='a'), ast.Name(id='b')], ast.Starred(value=ast.Name(id='c')), []]


# Generated at 2022-06-12 04:02:17.201216
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None)('[1, 2, *range(3), 5]').strip() == '[1, 2, list(range(3)), 5]'
    assert StarredUnpackingTransformer(None)('[1, 2, *range(3), 5, *range(4)]').strip() == '[1, 2, list(range(3)), 5, list(range(4))]'
    assert StarredUnpackingTransformer(None)('print(*range(2), *range(3))').strip() == 'print(*(list(range(2)) + list(range(3))))'
    assert StarredUnpackingTransformer(None)('print(*range(2), *range(3), *range(4))').strip() == 'print(*((list(range(2)) + list(range(3))) + list(range(4))))'

# Generated at 2022-06-12 04:02:26.573890
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(
        elts=[
            ast.Constant(value=2),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[
                        ast.Constant(value=10),
                    ],
                    keywords=[])
            ),
            ast.Constant(value=1),
        ]
    )


# Generated at 2022-06-12 04:02:32.939245
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of class StarredUnpackingTransformer."""
    src = """
        [2, *range(10), 1]
        """
    tree = ast.parse(src)
    StarredUnpackingTransformer().visit(tree)
    expected = """
        ([2] + list(range(10)) + [1])
        """
    expected = ast.parse(expected)
    assert ast.dump(expected) == ast.dump(tree)


# Generated at 2022-06-12 04:02:40.791786
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from pyaux.ast import convert_source
    import ast as stdlib_ast

    code = 'print(*range(1), *range(3))'
    source = convert_source(code)

    node = StarredUnpackingTransformer().visit(source)  # type: ignore
    result = stdlib_ast.dump(node, include_attributes=True)


# Generated at 2022-06-12 04:02:42.004524
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:02:49.532303
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import textwrap
    from .base import get_visitor
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        CODE = "print(1, *range(10))"
        RESULT = "print(*(list(range(0, 1)) + list(range(10))))"

    # Metaprogramming.
    def call_test(scope, new_scope):
        exec(scope, new_scope)
        TestCase().run_test(new_scope['test_visit_Call'])


# Generated at 2022-06-12 04:02:59.444489
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    Tests that the visit method of StarredUnpackingTransformer properly
    replaces calls that contain *args with the appropriate
    list(range(..)) calls
    """
    from typed_ast import ast3 as typed_ast
    from .base import BaseNodeTransformer

    tree = typed_ast.parse("print(*range(1), *range(3))")
    transformer = BaseNodeTransformer()
    transformer.visit(tree)
    
    exp = typed_ast.parse("print(*(list(range(1))+list(range(3))))")

    assert typed_ast.dump(tree) == typed_ast.dump(exp)


# Generated at 2022-06-12 04:03:06.400459
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    print(*[1, 2], *[3, 4], sep='-')
    """
    expected = """
    print(*(list([1, 2]) + list([3, 4])), sep='-')
    """
    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node) == expected


# Generated at 2022-06-12 04:03:15.659057
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    v = StarredUnpackingTransformer()
    l = ast.List(elts=[ast.Num(n=10), ast.Starred(value=ast.Num(n=20)), ast.Num(n=30)], ctx=ast.Load())
    assert ast.dump(l) == "List(elts=[Num(n=10), Starred(value=Num(n=20), ctx=Load()), Num(n=30)], ctx=Load())"
    v.visit(l)
    assert ast.dump(l) == "List(elts=[Num(n=10), Call(func=Name(id='list', ctx=Load()), args=[Num(n=20)], keywords=[]), Num(n=30)], ctx=Load())"

# Generated at 2022-06-12 04:03:26.429877
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # test *a
    node = ast.parse('[*a]').body[0]
    assert isinstance(node, ast.List)
    assert isinstance(node.elts[0], ast.Starred)
    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(node)
    assert isinstance(new_node, ast.List)
    assert isinstance(new_node.elts[0], ast.Call)

    # test a, *b
    node = ast.parse('[a, *b, 1]').body[0]
    assert isinstance(node, ast.List)
    assert isinstance(node.elts[0], ast.Name)
    assert isinstance(node.elts[1], ast.Starred)
    transformer = StarredUnpackingTransformer()
    new

# Generated at 2022-06-12 04:03:30.034764
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(1, *range(10), 2)')
    StarredUnpackingTransformer().visit(tree)
    res = ast.dump(tree)
    assert 'print(*(list([1]) + list(range(10)) + list([2])))' in res



# Generated at 2022-06-12 04:03:39.543621
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from diot import Diot
    from .base import BaseNodeTransformerTester

    class NoStarred(BaseNodeTransformerTester):
        __transformer__ = StarredUnpackingTransformer

    class WithStarred(BaseNodeTransformerTester):
        __transformer__ = StarredUnpackingTransformer

    class WithStarred2(BaseNodeTransformerTester):
        __transformer__ = StarredUnpackingTransformer

    class WithStarred3(BaseNodeTransformerTester):
        __transformer__ = StarredUnpackingTransformer

    class WithStarred4(BaseNodeTransformerTester):
        __transformer__ = StarredUnpackingTransformer

    call = Diot()
    call.args = [ast.Constant(1), ast.Starred(value=ast.Constant(2))]

# Generated at 2022-06-12 04:03:44.131695
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    c = StarredUnpackingTransformer()
    assert c.visit(ast.parse('[2, *range(10), 1]').body[0]) == ast.parse('[2] + list(range(10)) + [1]').body[0]


# Generated at 2022-06-12 04:03:46.318533
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 04:03:53.389514
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    res = compile(code, '<string>', 'single', optimize=2, flags=ast.PyCF_ONLY_AST)
    res = StarredUnpackingTransformer().visit(res)
    res = compile(res, '<string>', 'exec', optimize=2)
    ns = {}
    exec(res, ns)
    assert ns['_'] == eval(expected)


# Generated at 2022-06-12 04:04:00.985926
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert node.value.args == [ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[])),
                               ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[]))]

    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:04:10.855165
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    import textwrap
    from typed_ast import ast3 as ast
    from textx.scoping.providers import PlainName, FQN
    from textx import metamodel_from_str, get_metamodel
    from textx.export import metamodel_export, model_export


# Generated at 2022-06-12 04:04:28.467900
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def func(x, y):
        pass

# Generated at 2022-06-12 04:04:38.782571
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    result = transformer.visit(ast.parse("print(*range(1), *range(3))"))
    print(ast.dump(result))


# Generated at 2022-06-12 04:04:42.595172
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0].value
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0].value
    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-12 04:04:47.157592
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test StarredUnpackingTransformer.visit_List"""
    code = '''[2, *range(10), 1]'''
    expected = '''[2] + list(range(10)) + [1]'''
    tree = StarredUnpackingTransformer().visit(ast.parse(code))
    assert expected in astunparse.unparse(tree)
    assert not StarredUnpackingTransformer(debug=True).visit(ast.parse(code))


# Generated at 2022-06-12 04:04:51.437636
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test if we get same instance of StarredUnpackingTransformer when
    # we call constructor many times
    sut1 = StarredUnpackingTransformer()
    sut2 = StarredUnpackingTransformer()
    assert sut1 is sut2


# Generated at 2022-06-12 04:04:58.858165
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    transformer = StarredUnpackingTransformer()

    src_1 ='''
[2, *range(10), 1]
'''
    with patch('typed_astunparse.ast3unparse', return_value=src_1) as mock_parse:
        node_1 = ast.parse(src_1)
        transformer.visit(node_1)


# Generated at 2022-06-12 04:05:05.069547
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
    l = [2, *range(3), 4, *range(10), 1]
    """

    expected = """
    l = [2] + list(range(3)) + [4] + list(range(10)) + [1]
    """

    node = ast.parse(source)
    fixed = to_source(StarredUnpackingTransformer().visit(node))
    assert fixed == expected



# Generated at 2022-06-12 04:05:15.032115
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:05:17.600042
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    t.visit(ast.parse("print(*range(10), 1)", filename='<starred>', mode='exec'))

# Generated at 2022-06-12 04:05:26.539427
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    s = '[2, *range(10), 1]'
    astree = astor.code_to_ast.parse_string(s).body[0]
    context = {
        '__file__': None,
        '__name__': '__main__',
        '__package__': None,
        'range': range
    }
    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(astree)
    code = compile(astree, '<string>', 'eval')
    result = eval(code, context)
    assert result == list(range(3)) + list(range(10)) + [1]


# Generated at 2022-06-12 04:05:48.876183
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case = [
               ('[2, *range(10), 1]', '[2] + list(range(10)) + [1]'),
               ('[2, *range(10), *range(1), 1]', '[2] + list(range(10)) + list(range(1)) + [1]'),
               ('[2]', '[2]'),
               ('[2, 1]', '[2, 1]')
               ]
    for code, expected_code in test_case:
        module_node = ast.parse(code)
        StarredUnpackingTransformer.run_on_node(module_node)
        assert ast.dump(module_node) == expected_code



# Generated at 2022-06-12 04:05:57.802129
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import cst_to_ast
    from astmonkey.visitors import node_visit
    from astmonkey.visitors import InlineAndRecursiveVisitor

    source = 'print(*range(1), *range(3))'
    node = cst_to_ast(source)
    StarredUnpackingTransformer.run_on_node(node)

    assert_equal(source, InlineAndRecursiveVisitor().visit(node))

    node_visit(node, StarredUnpackingTransformer)

    assert_equal('print(*(list(range(1)) + list(range(3))))',
                 InlineAndRecursiveVisitor().visit(node))



# Generated at 2022-06-12 04:06:04.033831
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast.parse('[2, *range(10), 1]'))
    assert_source(result, '[2] + list(range(10)) + [1]')

    result = transformer.visit(ast.parse('print(*range(1), *range(3))'))
    assert_source(result, 'print(*(list(range(1)) + list(range(3))))')

# Generated at 2022-06-12 04:06:12.817306
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    program = ast.parse('''[2, *range(10), 1]''')
    program = StarredUnpackingTransformer().visit(program)  # type: ignore
    assert ast.dump(program) == "[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))]"



# Generated at 2022-06-12 04:06:19.047974
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse

    unparser = unparse.Unparser(ast.parse('''
a(b, c, *d, *e, f)
'''))
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(unparser.ast)
    assert unparse.unparse(tree) == 'a(*(b, c, *list(d), *list(e), f))\n'


# Generated at 2022-06-12 04:06:23.365170
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    call = ast.parse("print(*range(1), *range(3))")
    transformed = transformer.visit(call)
    print(ast.dump(transformed))
                                                    

# Generated at 2022-06-12 04:06:24.725981
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-12 04:06:28.537162
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    source = ast.parse('print(*range(1), *range(3))')
    expected_code = 'print(*(list(range(1)) + list(range(3))))'
    transformed_code = t.visit(source)
    assert expected_code == transformed_code.__repr__()



# Generated at 2022-06-12 04:06:37.725812
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class TestTransformer(StarredUnpackingTransformer):
        def visit_List(self, node):
            return ast.List(elts=node.elts)

        def visit_Call(self, node):
            return ast.Call(func=node.func, args=node.args)

        def visit_BinOp(self, node):
            return ast.BinOp(left=node.left, right=node.right, op=node.op)

    def check(before: str, after: str) -> None:
        transformer = TestTransformer()
        tree = ast.parse(before)
        transformed = transformer.visit(tree)
        transformed = ast.fix_missing_locations(transformed)
        transformed = astor.to_source(transformed)
        assert transformed == after


# Generated at 2022-06-12 04:06:40.241331
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expr = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    assert StarredUnpackingTransformer().visit(ast.parse(expr)) == ast.parse(expected)


# Generated at 2022-06-12 04:07:16.808953
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    source = [2, *range(10), 1]
    expected_ast = ast.parse(
        '_DUMMY = [2] + list(range(10)) + [1]').body[0]
    code = '_DUMMY = ' + str(source)
    result_ast = ast.parse(code).body[0]
    assert result_ast != expected_ast
    result_ast = transformer.visit(result_ast)
    assert result_ast == expected_ast


# Generated at 2022-06-12 04:07:27.173440
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast

    transformer = StarredUnpackingTransformer()

    tree = ast.parse('''
    [1, *range(3)]
    ''').body
    tree = transformer.visit(tree)
    assert "list(range(3))" in str(tree)

    transformer = StarredUnpackingTransformer()

    tree = ast.parse('''
    [1, *range(3), *range(4)]
    ''').body
    tree = transformer.visit(tree)
    assert "list(range(3))" in str(tree)
    assert "list(range(4))" in str(tree)

    tree = ast.parse('''
    [1, *range(2), 3, *range(4)]
    ''').body
    tree = transformer.vis

# Generated at 2022-06-12 04:07:30.785345
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import compare_source

    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    compare_source(StarredUnpackingTransformer, source, expected)


# Generated at 2022-06-12 04:07:35.495141
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    d = ast.parse('print(*range(1), *range(3))')
    r = StarredUnpackingTransformer().visit(d)
    assert 'print(*(list(range(1)) + list(range(3))))' in astor.to_source(r)


# Generated at 2022-06-12 04:07:40.200660
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Define a python 3.4 module
    code = """
    def test(a, b):
        print(a, b)
    
    test(1, *range(100))
    """

    # test transformation
    transformed_code = StarredUnpackingTransformer.run_on_string(code)
    assert transformed_code  # run_on_string return None if not modifed
    print(transformed_code)
    # should compile to the same
    compile(transformed_code, '', 'exec')

# Generated at 2022-06-12 04:07:44.861529
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code = 'print(*range(3), 4)'
    tree = ast.parse(code)
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    result = astor.to_source(tree)
    assert result == 'print(*(list(range(3)) + list([4])))'



# Generated at 2022-06-12 04:07:52.580156
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    v = StarredUnpackingTransformer()
    node = ast.parse("range(1, 2, 3)").body[0]
    node = v.visit(node)
    assert ast.dump(node) == 'Call(func=Name(id=\'range\', ctx=Load()), args=[List(elts=[], ctx=Load())], keywords=[])'

    node = ast.parse("range(1, *[2, 3], 4, *[3, 4])").body[0]
    node = v.visit(node)
    assert ast.dump(node) == 'Call(func=Name(id=\'range\', ctx=Load()), args=[List(elts=[], ctx=Load())], keywords=[])'

# Generated at 2022-06-12 04:08:00.187911
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    ast_node = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Call(
            func=ast.Name(id='range'),
            args=[
                ast.Num(n=10)],
            keywords=[]),
        ),
        ast.Num(n=1)],
    ctx=ast.Load()
    )


# Generated at 2022-06-12 04:08:04.452492
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from simpleast import parse_ast

    t = StarredUnpackingTransformer()

    l = parse_ast("[1, 2, *range(3)]")
    e = parse_ast("list([1, 2]) + list(range(3))")

    t.visit(l)

    assert t._tree_changed
    assert e == l

# Generated at 2022-06-12 04:08:13.230729
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .base import TransformerError
    from ..base import CodeReader
    from typed_ast import ast3
    import sys
    import ast

    # 1. create the object
    tsfr = StarredUnpackingTransformer()
    # 2. create the code to read
    code = \
    """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    # 3. create the CodeReader object
    cr = CodeReader(code)
    # 4. read the code
    tree = cr.read()
    # 5. check the tree
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.List)

# Generated at 2022-06-12 04:09:17.848858
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert isinstance(StarredUnpackingTransformer().visit(ast.parse('f(*a)')), ast.Call)


# Generated at 2022-06-12 04:09:22.590044
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astor import to_source
    from .fixtures import StarredUnpackingTransformer_visit_List_test_ast

    node = StarredUnpackingTransformer_visit_List_test_ast
    sut = StarredUnpackingTransformer()
    sut.visit(node)
    assert to_source(node) == "[2, *range(10), 1]"



# Generated at 2022-06-12 04:09:31.876005
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ..testing import assert_equal_ast, transform
    from ..testing import Case

    cases: List[Case] = []
    cases.append(Case(
        'foo(*args)',
        'foo(*(list(args)))',
        'foo(*(args))'))

    cases.append(Case(
        'foo(*args, **kwargs)',
        'foo(*(list(args)), **kwargs)',
        'foo(*(args), **kwargs)'))

    cases.append(Case(
        'foo(a, b, *args, **kwargs)',
        'foo(a, b, *(list(args)), **kwargs)',
        'foo(a, b, *(args), **kwargs)'))


# Generated at 2022-06-12 04:09:39.442580
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer(None)
    assert x._has_starred([ast.Name(id="a")]) == False
    assert x._has_starred([ast.Starred(value=ast.Name(id="a"))]) == True
    assert x._split_by_starred([ast.Name(id="a")]) == [ast.Name(id="a")]
    assert x._split_by_starred([
        ast.Name(id="a"),
        ast.Starred(value=ast.Name(id="b")),
        ast.Name(id="c")]) == [ast.Name(id="a"), ast.Starred(value=ast.Name(id="b")), ast.Name(id="c")]

# Generated at 2022-06-12 04:09:47.770698
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:09:54.991519
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    tree = ast.parse('[1, *range(3), 4]', mode='eval')
    for node in tree.body.elts:
        result = transformer.visit(node)
        if isinstance(result, ast.List):
            assert isinstance(result.elts, ast.List)
            assert isinstance(result.elts.elts[0], ast.Num)
            assert result.elts.elts[0].n == 1
            assert isinstance(result.elts.elts[1], ast.BinOp)
            assert isinstance(result.elts.elts[2], ast.Num)
            assert result.elts.elts[2].n == 4
            assert isinstance(result.elts.elts[1].left, ast.Call)

# Generated at 2022-06-12 04:10:04.065583
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    samples = [
        [
            'print(1)',
            'print(1)'
        ],
        [
            'print(1, *range(5))',
            'print(*([1] + list(range(5))))'
        ],
        [
            'print(1, *range(5), *range(3), 2)',
            'print(*([1] + list(range(5)) + list(range(3)) + [2]))'
        ],
        [
            'print(*range(5), *range(3))',
            'print(*(list(range(5)) + list(range(3))))'
        ],
    ]
    transformer = StarredUnpackingTransformer()
    for sample, expected in samples:
        actual = astor.to_source(ast.parse(sample))
        assert actual

# Generated at 2022-06-12 04:10:11.778669
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typing import List
    from typed_ast import ast3 as ast
    from .utilities import dump, round_trip, load

    source = """
        print(*[2, 3], *[4, 5])
    """
    tree = load(source)
    target = tree
    obj = StarredUnpackingTransformer()
    new_tree = round_trip(tree, target_ast=target, transformer=obj)

    assert dump(target) == dump(new_tree)

    source = """
        a = [2, *[3, 4], 5]
    """
    tree = load(source)
    target = tree
    obj = StarredUnpackingTransformer()
    new_tree = round_trip(tree, target_ast=target, transformer=obj)

    assert dump(target) == dump(new_tree)

    source

# Generated at 2022-06-12 04:10:21.732952
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
                """
                print(*range(1), *range(3))
                """)
    StarredUnpackingTransformer().visit(tree)


# Generated at 2022-06-12 04:10:26.991225
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as _ast
    from ast_transformer_utils.unparser import Unparser

    n = ("""def _():
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """)

    node = _ast.parse(n)
    t = StarredUnpackingTransformer(None)
    u = Unparser(node)

    res = t.visit(node)
    u.visit(res)
