

# Generated at 2022-06-12 04:01:54.388230
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer(None)

    # When
    node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.List(elts=[ast.Num(n=1)]))])
    actual = sut.visit_Call(node)

    # Then
    expected = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.List(elts=[ast.Num(n=1)]))])
    assert actual == expected



# Generated at 2022-06-12 04:02:03.365128
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    assert ast.dump(StarredUnpackingTransformer().visit(node)) == \
        "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), " \
        "right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', " \
        "ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), " \
        "right=List(elts=[Num(n=1)]), op=Add()))])"


# Generated at 2022-06-12 04:02:09.155617
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_astunparse
    transformer = StarredUnpackingTransformer()
    result = typed_astunparse.unparse(transformer.visit(ast.parse('print(*range(1), *range(3))').body[0].value))
    assert result == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-12 04:02:15.709929
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    AST = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(AST)
    assert ast.dump(AST).split('\n')[0:4] == [
        "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2), Num(n=1)]), op=Add(), right=Call(func=Name(id='list'), args=[Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])], keywords=[])))])",
        "",
        "",
        ""]

# Generated at 2022-06-12 04:02:25.247229
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .main import compile_for_ast_node

    class Tester(StarredUnpackingTransformer):
        def __init__(self):
            super().__init__()
            self.called = False

        def visit_Call(self, node: ast.Call) -> ast.Call:
            self.called = True
            return super().visit_Call(node)

    tester = Tester()
    locals_, globals_ = {}, {}
    compile_for_ast_node(tester, 'a = print(*(1, 2, 3))', globals_, locals_)
    fn_ = locals_['a']
    fn_()
    assert tester.called

# Generated at 2022-06-12 04:02:33.746224
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().run_on_node(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))])"


# Generated at 2022-06-12 04:02:37.616594
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_string = ast.parse("print(*range(1))")
    output_string = StarredUnpackingTransformer().visit(input_string)
    assert_string = ast.parse("print(*([list(range(1))]))")
    assert ast.dump(output_string) == ast.dump(assert_string)


# Generated at 2022-06-12 04:02:47.546519
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
    [2, *range(10), 1]
    """
    expect = """
    [2] + list(range(10)) + [1]
    """

    from uuid import uuid4
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse

    class CleanUp(ast.NodeTransformer):
        def __init__(self, target_name: str):
            super().__init__()
            self.target_name = target_name

        def visit_Name(self, node: ast.Name) -> ast.Name:
            if node.id == self.target_name:
                return ast.Name(id='range', ctx=ast.Load())
            return node


# Generated at 2022-06-12 04:02:59.489562
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(elts = [ast.Num(n=2), ast.Starred(
        value=ast.Call(func=ast.Name(id="range"), args=[ast.Num(n=10)], keywords=[], starargs=None, kwargs=None),
        ctx=ast.Load()), ast.Num(n=1)],
        ctx=ast.Load())


# Generated at 2022-06-12 04:03:00.793710
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)


# Generated at 2022-06-12 04:03:13.201044
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [1, *range(10), 1]
    tree = ast.parse('[1, *range(10), 1]')

    t = StarredUnpackingTransformer()
    t.visit(tree)
    assert t.result().body[0].value == ast.Call(
        func=ast.Name(id='list'),
        args=[
            ast.List(elts=[ast.Num(n=1)]),
            ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[]),
            ast.List(elts=[ast.Num(n=1)])
        ],
        keywords=[]
    )


# Generated at 2022-06-12 04:03:21.825244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code_string = "[2, *range(10), 1]"
    expected_ast=ast.parse(code_string)

    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(expected_ast)

    #-----------------------#
    #  Visit original code  #
    #-----------------------#
    code_string = "[2, *range(10), 1]"
    node_transformer = StarredUnpackingTransformer()
    actual_ast = ast.parse(code_string)
    node_transformer.visit(actual_ast)

    assert ast.dump(actual_ast) == ast.dump(expected_ast)


# Generated at 2022-06-12 04:03:27.603512
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    node = ast.parse('[2, *range(10)]', mode='eval')
    expected = ast.parse('[2] + list(range(10))', mode='eval')

    # Test
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(node)

    # Validate
    assert ast.dump(transformed) == ast.dump(expected)



# Generated at 2022-06-12 04:03:35.497832
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .util import assert_equal_ast
    from typed_ast import ast3 as ast
    t = StarredUnpackingTransformer()


# Generated at 2022-06-12 04:03:39.645990
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestTransformer(StarredUnpackingTransformer):
        pass

    assert TestTransformer().get_source(
        'print(*range(1), *range(3))') == 'print(*(list(range(1)) + list(range(3))))'



# Generated at 2022-06-12 04:03:49.536494
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expr_str = '[2, *range(10), 1]'
    test_tree = StarredUnpackingTransformer().visit(ast.parse(expr_str))
    assert_equals(ast.dump(test_tree), "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)], ctx=Load()), op=Add()))])\n")

# Generated at 2022-06-12 04:03:58.861771
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    transformer = StarredUnpackingTransformer()
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Name(id='a'),
            ast.Starred(value=ast.Name(id='x')),
            ast.Name(id='b'),
            ast.Starred(value=ast.Name(id='y')),
            ast.Name(id='c'),
            ast.Starred(value=ast.Name(id='z')),
            ast.Name(id='d'),
    ],
    keywords=[])

    # When
    result = transformer.generic_visit(transformer.visit_Call(node))

    # Then
    assert isinstance(result, ast.Call)
    assert transformer.tree_changed

# Generated at 2022-06-12 04:04:00.687538
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:04:06.460251
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import make_transformer  # pylint: disable=import-outside-toplevel
    from .base import BaseNodeTransformer

    StarredUnpackingTransformer.test(make_transformer(StarredUnpackingTransformer))
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    StarredUnpackingTransformer()
    BaseNodeTransformer.test(StarredUnpackingTransformer)

# Generated at 2022-06-12 04:04:08.899345
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astunparse import dump

    node = ast.parse('print(2, *range(10), 1)')
    assert dump(node) == 'print(2, *range(10), 1)\n'
    StarredUnpackingTransformer().visit(node)
    assert dump(node) == 'print(*(list(range(10)) + [1]))\n'

# Generated at 2022-06-12 04:04:21.430444
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    from .base import BaseNodeTransformer
    from random import randint

    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
        To:
            [2] + list(range(10)) + [1]
            
        """
        target = (3, 4)

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True

            return False

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            """Split `xs` to separate list by Starred."""
            lists = [[]]  # type: List[

# Generated at 2022-06-12 04:04:26.387949
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    expected = ast.parse("[2] + list(range(10)) + [1]")
    StarredUnpackingTransformer(tree).visit(tree)
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-12 04:04:32.514754
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    example_tree = ast.parse("[2, *range(10), 1]")

    class TransformtionTracker(StarredUnpackingTransformer):
        _tree_changed = False

    transformer = TransformtionTracker()
    transformed_tree = transformer.visit(example_tree)

    expected_tree = ast.parse("[2] + list(range(10)) + [1]")
    assert transformed_tree == expected_tree



# Generated at 2022-06-12 04:04:42.293070
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    print(*range(1), 2, *range(3), 4)
    print(*range(5), 6)
    print(7, *range(8), 9)
    """
    expected = """
    print(*(list(range(1)) + [2] + list(range(3)) + [4]))
    print(*(list(range(5)) + [6]))
    print(*([7] + list(range(8)) + [9]))
    """
    tree = ast.parse(source)
    visitor = StarredUnpackingTransformer()
    new_tree = visitor.visit(tree)
    compiled_code = compile(new_tree, '<string>', 'exec')
    new_code = ast.unparse(new_tree)
    old_code = ast.unparse(tree)

# Generated at 2022-06-12 04:04:46.119428
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = ast.parse("[2, *range(10), 1]")
    transform = StarredUnpackingTransformer()
    result = transform.visit(input)
    expected_output = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(result, include_attributes=True) == ast.dump(expected_output, include_attributes=True)



# Generated at 2022-06-12 04:04:56.182409
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    code1 = "[2, *range(10), 1]"
    code2 = "[2]"
    code3 = "[*range(10)]"
    code4 = "[2, *range(10), *range(10), 1]"
    code5 = "[2, 1, \"a\", *range(10), 1]"

    expected1 = "[2] + list(range(10)) + [1]"
    expected2 = "[2]"
    expected3 = "list(range(10))"
    expected4 = "[2] + list(range(10)) + list(range(10)) + [1]"
    expected5 = "[2, 1, \"a\"] + list(range(10)) + [1]"


# Generated at 2022-06-12 04:05:06.546091
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    assert str(transformer.visit(ast.parse('[2, *range(10), 1]'))) == \
           "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), \n" \
           "right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))])"


# Generated at 2022-06-12 04:05:15.865501
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # NOTE: this test also tests that class StarredUnpackingTransformer correctly
    #  initializes BaseNodeTransformer.
    class_instance = StarredUnpackingTransformer()
    test_input = ast.parse('[4, *[1, *[2, *[3]]], 5]')

# Generated at 2022-06-12 04:05:25.370181
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_template import expected, run
    from .test_template import _test_transform, unused_isinstance

    assert expected(
        """
        [x] + list(ys) + [z]
        """
    ) == run(StarredUnpackingTransformer, """
        [x, *ys, z]
        """)

    assert expected(
        """
        [x] + list(ys) + [z]
        """
    ) == run(StarredUnpackingTransformer, """
        [x, *ys, *[], z]
        """)

    assert expected(
        """
        [x] + list(ys) + [z] + list(ws)
        """
    ) == run(StarredUnpackingTransformer, """
        [x, *ys, z, *ws]
        """)

   

# Generated at 2022-06-12 04:05:32.166438
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = """
    p(1, 2, *a)
    p(1, *a, 2, *b)
    """
    expected = """
    p(*(list([1, 2]) + list(a)))
    p(*(list([1]) + list(a) + list([2]) + list(b)))
    """
    actual = ast_converter(src, StarredUnpackingTransformer)
    print(actual)
    assert actual == expected



# Generated at 2022-06-12 04:05:42.263105
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import parse_ast, dump_ast
    from .visitor import TmpNameRemover
    code = 'print(*range(1), *range(3))'
    # Expected result
    expected_code = 'print(*(list(range(1)) + list(range(3))))'
    # Parse code
    tree = parse_ast(code)
    StarredUnpackingTransformer().visit(tree)
    # Remove temp names
    TmpNameRemover().visit(tree)
    # Dump tree
    result_code = dump_ast(tree)
    # Check result
    assert result_code == expected_code


# Generated at 2022-06-12 04:05:46.774607
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .context import Context
    from .typed_visitor import TypedNodeVisitor

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Call(self, node):
            return node


# Generated at 2022-06-12 04:05:52.710336
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_code = "print(*range(1), *range(3))"
    expected_code = "print(*(list(range(1)) + list(range(3))))"
    tree = ast.parse(test_code)
    tree = StarredUnpackingTransformer.run_pipeline(tree)
    if expected_code != astor.to_source(tree).strip():
        raise Exception("ERROR: test_StarredUnpackingTransformer_visit_Call()")



# Generated at 2022-06-12 04:06:00.402969
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('foo(1, *range(2), 3)').body[0]

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)


# Generated at 2022-06-12 04:06:11.241580
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = ast.parse('print(*range(1), *range(3))').body[0]
    trans = StarredUnpackingTransformer()
    trans.visit(stmt)

# Generated at 2022-06-12 04:06:15.862270
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = ast.parse('''
print(*range(1), *range(3))
    ''').body[0]

    expected = ast.parse('''
print(*(list(range(1)) + list(range(3))))
    ''').body[0]

    assert StarredUnpackingTransformer().visit(source) == expected


# Generated at 2022-06-12 04:06:26.887370
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from samflow.command import PythonCommand
    from samflow.workflow import Workflow

    w = Workflow()

    w.transform(StarredUnpackingTransformer)

    w.subflow(PythonCommand(script="print(*range(10), *range(20))", func=lambda x: x, input=w.ref("test_data")))
    w.subflow(PythonCommand(script="print(*range(10))", func=lambda x: x, input=w.ref("test_data")))

    assert len(w.subflow(Workflow.CORE).subworkflow) == 1
    main_workflow = w.subflow(Workflow.CORE).subworkflow[0]
    assert len(main_workflow.subworkflow) == 1
    print_list_subworkflow = main_workflow.subworkflow

# Generated at 2022-06-12 04:06:35.474922
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from mixt.vendor.typed_ast import ast3 as ast
    from ..testing import normalize_ast

    source = """
        print(*range(1))
        print(*range(1), *range(2))
        print(*range(1), sep="-")
    """

    expected = """
        print(*(list(range(1))))
        print(*(list(range(1)) + list(range(2))))
        print(*(list(range(1))), sep="-")
    """

    transformer = StarredUnpackingTransformer()

    node = ast.parse(source)
    transformer.visit(node)
    result = normalize_ast(node)
    assert result == expected



# Generated at 2022-06-12 04:06:41.959285
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = "print(*range(1), *range(3))"
    os = StarredUnpackingTransformer()
    tree = ast.parse(code)
    new_tree = os.visit(tree)

# Generated at 2022-06-12 04:06:51.212291
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    for i in (1, 10):
        globals.debug = i
        test_code1 = """
        print(*range(1), *range(3))
        """
        test_ast1 = ast.parse(test_code1)
        expected_ast1 = ast.parse(
            """
        print(*(list(range(1)) + list(range(3))))
        """
        )
        actual_ast1 = StarredUnpackingTransformer().visit(test_ast1)
        assert ast.dump(expected_ast1) == ast.dump(actual_ast1)

        test_code2 = """
        print(*range(i), *range(j), i, j, sep=" ")
        """
        test_ast2 = ast.parse(test_code2)

# Generated at 2022-06-12 04:07:00.326964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_source = "\n".join([
        "print(*range(1), *range(3))"
        ])

    expected_ast = ast.parse(
        "\n".join([
            "print(*(list(range(1)) + list(range(3))))"
            ]))

    testee = StarredUnpackingTransformer()
    result_ast = testee.visit(ast.parse(input_source))

    assert ast.dump(result_ast) == ast.dump(expected_ast)


# Generated at 2022-06-12 04:07:04.415127
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    source = "print(1, *range(5))"
    expected = "print(*(list((1,)) + list(range(5))))"
    tree = ast.parse(source)
    compiled = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(compiled) == expected


# Generated at 2022-06-12 04:07:09.831270
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .util import parse_and_run

    statements = [
        "print(3)",
        "print(3, *range(3))",
        "print(3, *range(3), 4, *range(2))",
        "print(*range(3))",
    ]
    for source in statements:
        parse_and_run(source, [StarredUnpackingTransformer])


# Generated at 2022-06-12 04:07:16.763573
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    @add_lookup
    def f(v):
        return v
    tt = ast.parse("f(2, *range(10), 1)")
    t = StarredUnpackingTransformer()
    t.visit(tt)
    # print(ast.dump(tt))
    tt = ast.parse("f(2, *range(10), 1)")
    t = AddLookup(StarredUnpackingTransformer())
    t.visit(tt)
    # print(ast.dump(tt))



# Generated at 2022-06-12 04:07:23.498350
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .starred_unpacking import StarredUnpackingTransformer
    from .. import _ast_to_str
    _ast_to_str(ast.parse("[2, *range(10), 1]"))
    transformer = StarredUnpackingTransformer()
    assert _ast_to_str(transformer.visit(ast.parse("[2, *range(10), 1]"))) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:07:29.087143
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test visit_Call method of StarredUnpackingTransformer class."""
    code = """print(*range(1), *range(3))"""
    expected_code = """print(*(list(range(1)) + list(range(3))))"""
    module = ast.parse(code)
    expected_module = ast.parse(expected_code)
    result = StarredUnpackingTransformer().visit(module)
    assert ast.dump(result) == ast.dump(expected_module)


# Generated at 2022-06-12 04:07:37.026531
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # arrange
    def parse(src):
        tree = ast.parse(src)
        tree = StarredUnpackingTransformer().visit(tree)
        return str(tree)

    # act & assert
    assert parse("print(1, 2, 3)") == "print(1, 2, 3)"
    assert parse("print(1, 2, *range(3), 3)") == "print(*(list([1, 2]) + list(range(3)) + list([3])))"
    assert parse("print(*range(1), *range(3))") == "print(*(list(range(1)) + list(range(3))))"



# Generated at 2022-06-12 04:07:45.602109
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.code_gen import to_source
    from .base import compile_returning_tree
    from .base import GenericTransformerTestCase

    class TestCase(GenericTransformerTestCase):
        transformer = StarredUnpackingTransformer

    def test_single_starred():
        t = TestCase(
            before='print(*[2, 3])',
            after=(
                'print(*(list([2, 3])))'
            )
        )
        t.test(assert_source=False)

    def test_two_starred():
        t = TestCase(
            before='print(*[2, 3], *[5, 6])',
            after=(
                'print(*(list([2, 3]) + list([5, 6])))'
            )
        )

# Generated at 2022-06-12 04:07:53.464900
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = ast.parse("print(1, *lst, 2)").body[0]
    assert isinstance(stmt, ast.Expr)
    assert isinstance(stmt.value, ast.Call)

    transformer = StarredUnpackingTransformer()
    transformed_stmt = transformer.visit(stmt)

    assert isinstance(transformed_stmt, ast.Expr)
    assert isinstance(transformed_stmt.value, ast.Call)

    print("Compiled:")
    print(ast.dump(transformed_stmt))

    # assert transformed.value.args[0].left.args == [1]
    # assert transformed.value.args[0].right.args == [2]



# Generated at 2022-06-12 04:07:57.731139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse

    code = 'print(*range(10), *range(10))'
    ast_node = ast.parse(code)

    transformer = StarredUnpackingTransformer()
    new_ast = transformer.visit(ast_node)
    new_code = astunparse.unparse(new_ast).rstrip()
    assert new_code == 'print(*(list(range(10)) + list(range(10))))'



# Generated at 2022-06-12 04:08:15.109277
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .helper import assert_equivalent_nodes_ignoring_location
    from typed_ast import ast3 as ast
    
    # Input

# Generated at 2022-06-12 04:08:19.399179
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ..testing_utils import check_node_transformation

    check_node_transformation(
        StarredUnpackingTransformer,
        'assertTrue("abc" in "xyzabc", *range(2))',
        'assertTrue("abc" in "xyzabc", *(list(range(2)) + []))',
        target_version=(3, 4))

# Generated at 2022-06-12 04:08:20.329735
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass



# Generated at 2022-06-12 04:08:28.598618
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # pylint: disable=missing-docstring
    node = ast.parse("print(*range(1), *range(3))")
    node_expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node.body[0])
    # print(ast.dump(node_expected.body[0], annotate_fields=False))
    # print(ast.dump(result, annotate_fields=False))
    assert ast.dump(node_expected.body[0], annotate_fields=False) == \
        ast.dump(result, annotate_fields=False)


# Generated at 2022-06-12 04:08:31.310032
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest


# Generated at 2022-06-12 04:08:35.602187
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .syntax_trees import parses
    from .visitor import to_code

    tree = parses('print(*range(1), *range(3))')
    visitor = StarredUnpackingTransformer()
    visitor.visit(tree)
    assert visitor._tree_changed
    assert to_code(tree) == 'print(*(list(range(1)) + list(range(3))))'



# Generated at 2022-06-12 04:08:45.424471
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.code_gen import to_source
    from astor.codegen import to_source
    from test.utils import get_ast, ast_equal

    # Define the code to compile
    code = 'print(*range(1), *range(3))'

    expected_code = 'print(*(list(range(1)) + list(range(3))))'

    # Get the src code and the initial AST
    src_code = code
    ast_code = get_ast(src_code)

    # Get the expected AST
    expected_ast = get_ast(expected_code)

    # Call the transformer
    StarredUnpackingTransformer().visit(ast_code)

    # Get the transformer output
    code_out = to_source(ast_code)

    # Compare the expected AST with the code to be transformed
   

# Generated at 2022-06-12 04:08:47.428652
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pylib_ast
    import astunparse


# Generated at 2022-06-12 04:08:51.893064
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    xs = [ast.Call(func=ast.Name(id='func'),
                args=[ast.Starred(value=ast.Name(id='a'))],
                keywords=[])]
    for node in xs:
        result = StarredUnpackingTransformer().visit(node)
        assert result.args[0].value.value.id == 'a'


# Generated at 2022-06-12 04:08:55.671169
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiler import compile
    print("To:", compile(
        StarredUnpackingTransformer().visit(
            compile("print(1, *range(2), 3)", '<string>', 'single', optimize=0)),
        '<string>', 'exec'))


# Generated at 2022-06-12 04:09:08.825630
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    func = eval(compile(
        "lambda x, y: print(x, y)",
        "<test>",
        "eval",
        optimize=0,
    ))
    func_32 = transform(
        func,
        StarredUnpackingTransformer,
    )

    # 1
    eval(compile(
        str(ast.dump(ast.parse(  # noqa: F821
            "print(*[1, 2], *[3, 4])",
            "<test>",
            "exec",
        ))),
        "<test>",
        "exec",
        optimize=0,
    ))

    # 2

# Generated at 2022-06-12 04:09:14.714640
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_code = 'foo(1, *x, b, *y, c)'
    expected_code = 'foo(*(([1] + list(x)) + ([b] + list(y)) + ([c])))'
    tree = ast.parse(input_code)
    new_tree = StarredUnpackingTransformer().visit(tree)
    assert expected_code == astunparse.unparse(new_tree)



# Generated at 2022-06-12 04:09:15.508098
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:09:23.999141
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    import sys
    from pytu.ast import _get_ast_tree_from_str
    from pytu.nodes import _format_ast_tree
    from pytu.transformer import _apply_transformer_on_node

    node_str_dict = dict()
    node_str_dict["args"] = [
        "[2]",
        "[*range(10)]",
        "[1]"
    ]

# Generated at 2022-06-12 04:09:29.063174
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse
    from .visitor import make_visit
    code = 'print(*range(1), *range(3))'
    tree = parse(code)
    comparator = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    print(ast.dump(tree))
    assert make_visit(tree, comparator)


# Generated at 2022-06-12 04:09:36.917346
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .utils import _test_transform

    for version in [3,4]:
        _test_transform(StarredUnpackingTransformer(version), """
            print(*range(1),*range(2))
        """, """
            print(*(list(range(1))+list(range(2))))
        """)

        _test_transform(StarredUnpackingTransformer(version), """
            print(*range(1), *range(2))
        """, """
            print(*(list(range(1))+list(range(2))))
        """)

        _test_transform(StarredUnpackingTransformer(version), """
            print(*range(1), 2)
        """, """
            print(2,*list(range(1)))
        """)


# Generated at 2022-06-12 04:09:39.525790
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert StarredUnpackingTransformer().visit(
        ast.parse('print(*range(1), *range(3))').body[0]) == \
        ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]

# Generated at 2022-06-12 04:09:47.855283
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # print(*range(1), *range(3), 'd', 'e')

    body = ast.parse("print(*range(1), *range(3), 'd', 'e')").body[0]
    result = StarredUnpackingTransformer().visit(body)

    assert result.orelse == []
    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.Call)
    assert result.body[0].value.func.id == 'print'

    first_arg = result.body[0].value.args[0]
    assert isinstance(first_arg, ast.Starred)
    assert isinstance(first_arg.value, ast.BinOp)

# Generated at 2022-06-12 04:09:55.074300
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from transformer.typestransformer import TypeAnnotationsTransformer
    from transformer import const
    from transformer.models import TypedName, TypedCall
    from transformer.compiler import Compiler

    class DummyTarget:
        def __init__(self, x: int, y: int) -> None:
            pass

    func_def_input = '''
        x = 1
        y = 2
        z = 3
        a = 4
        b = 5
        c = 6
        d = 7
        def f(x: int, y: int, a: int, b: int = 50, *args, **kwargs):
            pass
    '''

# Generated at 2022-06-12 04:10:04.160133
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    from .utils import ast_equal
    from .base import run_transformer
    from .utils import dump_nodes

    def test_starred(input, expected):
        node = ast.parse(input)
        expected_node = ast.parse(expected)
        run_transformer(StarredUnpackingTransformer, node)
        assert ast_equal(node, expected_node)

    test_starred('1', '1')
    test_starred("foo(1, 2, 3, 4, 5)", 'foo(1, 2, 3, 4, 5)')
    test_starred("foo(1, *(2, 3), 4, 5)", 'foo(*[1, *list(2, 3), 4, 5])')

# Generated at 2022-06-12 04:10:24.790847
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*[2], 3, *[5,6], *[7,8], 9)'
    expected = 'print(*(([2] + [3] + [5, 6] + [7, 8] + [9])))'
    result = StarredUnpackingTransformer().transform_source(source)
    assert result == expected

# Generated at 2022-06-12 04:10:28.428304
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert StarredUnpackingTransformer.run_on_single_node(ast.parse('print(*range(1), *range(3))')) == ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]
assert StarredUnpackingTransformer.run_on_single_node(ast.parse('print(*range(1))')) == ast.parse('print(*list(range(1)))').body[0]

# Generated at 2022-06-12 04:10:36.652596
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    assert ast.dump(t.visit(ast.parse('print()')), no_unicode=True) == ast.dump(ast.parse('print()'), no_unicode=True)
    assert ast.dump(t.visit(ast.parse('print(1,2,3)')), no_unicode=True) == ast.dump(ast.parse('print(1,2,3)'), no_unicode=True)
    assert ast.dump(t.visit(ast.parse('print(1,2,*range(5))')), no_unicode=True) == ast.dump(ast.parse('print(1,2,*list(range(5)))'), no_unicode=True)

# Generated at 2022-06-12 04:10:46.290506
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    star_in_args = ast.parse('''
    import builtins
    builtins.print(*range(10), *range(20))
    ''')
    expected = ast.parse('''
    import builtins
    builtins.print(*(list(range(10)) + list(range(20))))
    ''')
    res = StarredUnpackingTransformer().visit(star_in_args)
    assert ast.dump(expected) == ast.dump(res)
    star_in_args = ast.parse('''
    import builtins
    builtins.print(*range(10), 1, *range(20))
    ''')
    expected = ast.parse('''
    import builtins
    builtins.print(*((1,) + list(range(20))))
    ''')

# Generated at 2022-06-12 04:10:54.217424
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    examples_src = """
    print(*range(1), *range(3))
    print(*range(1), 2, *range(3))
    print(1, *range(1), 2, *range(3), 4)
    print(1, *range(1), 2, *range(3), *range(4), 4)
    """

# Generated at 2022-06-12 04:10:58.668970
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
print(*range(1), *range(3), sep='3')
"""
    expected = """
print(*(list(range(1)) + list(range(3))))
print(*(list(range(1)) + list(range(3))), sep='3')
"""
    test_compile_ast(source, expected, StarredUnpackingTransformer)

# Generated at 2022-06-12 04:11:06.195758
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("*" * 20, "Testing visit_Call", "*" * 20)
    source = """
    print(a, *args, b)
    """
    print("Source:")
    print(source)

    scope = {}
    tree = ast.parse(source)
    expected = """
    print(*(list(a) + list(args) + list(b)))
    """
    print("Expected:")
    print(expected)

    transformer = StarredUnpackingTransformer(scope=scope)
    new_tree = transformer.visit(tree)
    output = ast.to_code(new_tree)
    assert output == expected

    print("Output:")
    print(output)


# Generated at 2022-06-12 04:11:14.939532
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # GIVEN
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='test', ctx=ast.Load)), ast.Num(n=2)],
        keywords=[])

# Generated at 2022-06-12 04:11:22.403830
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse as typed_parse
    from ast import parse
    import unittest

    unpacking_transform = StarredUnpackingTransformer()

    class TestCases(unittest.TestCase):
        def test_plain_call(self):
            node = typed_parse('print(1, 2, 3)')
            unpacking_transform.visit(node)
            unpacking_transform.generic_visit(node)
            assert ast.dump(node) == ast.dump(parse('print(1, 2, 3)'))

        def test_starred_call(self):
            node = typed_parse('print(*range(10), 1)')
            unpacking_transform.visit(node)
            unpacking_transform.generic_visit(node)

# Generated at 2022-06-12 04:11:22.915335
# Unit test for method visit_Call of class StarredUnpackingTransformer