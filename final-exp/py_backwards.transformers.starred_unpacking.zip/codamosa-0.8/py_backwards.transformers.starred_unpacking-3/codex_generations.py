

# Generated at 2022-06-12 04:02:09.426312
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with patch.object(StarredUnpackingTransformer, 'generic_visit') as mock_generic_visit:
        value = [2, ast.Starred(ast.Name(id="range"), lineno=0, col_offset=0), 1]
        result = StarredUnpackingTransformer().visit_List(ast.List(value, lineno=0, col_offset=0))
        assert result.elts == [2, ast.Call(ast.Name(id="list"), [ast.Name(id="range")], [], None, None), 1]

        mock_generic_visit.assert_called()


# Generated at 2022-06-12 04:02:16.969456
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from scrapy.utils.python import ast_from_code
    from .base import BaseNodeTransformerTestCase

    class Subclass(StarredUnpackingTransformer, BaseNodeTransformerTestCase):
        pass

    tree = ast_from_code("print(*range(1), *range(3))")
    transformer = Subclass()
    actual = transformer.visit_Call(tree.body[0].value)

# Generated at 2022-06-12 04:02:25.918050
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert compare_trees(
        StarredUnpackingTransformer().visit(ast.parse("print(*range(10))")),
        ast.parse("print(*list(range(10)))"))
    assert compare_trees(
        StarredUnpackingTransformer().visit(ast.parse("print(*range(1), *range(10))")),
        ast.parse("print(*(list(range(1)) + list(range(10))))"))
    assert compare_trees(
        StarredUnpackingTransformer().visit(ast.parse("print(*range(1), 1, *range(10))")),
        ast.parse("print(*(list(range(1)) + [1] + list(range(10))))"))


# Generated at 2022-06-12 04:02:31.309847
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test of method visit_Call of class StarredUnpackingTransformer"""
    tree = ast.parse("""y = f(1, *range(1), 2)""")
    tree = StarredUnpackingTransformer().visit(tree)
    assert str(tree) == "y = f(*([1] + list(range(1)) + [2]))"


# Generated at 2022-06-12 04:02:37.973790
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range'))], keywords=[])
    expected_node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'),
                                                                                       args=[ast.Name(id='range')],
                                                                                       keywords=[]))], keywords=[])
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    assert result == expected_node
    

# Generated at 2022-06-12 04:02:44.059000
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    import ast
    test_code = 'print(*range(1), *range(3))'
    tree = ast.parse(test_code)
    new_tree = StarredUnpackingTransformer().visit(tree)
    code = astunparse.unparse(new_tree)
    assert '(*(list(range(1)) + list(range(3))))' in code, code



# Generated at 2022-06-12 04:02:49.645898
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from .test_base import create_test_module

    t = StarredUnpackingTransformer()

    # TODO: Expression with Starred unpacking is always wrapped in List,
    #       not ListComp, SetComp or GeneratorExp.
    #       This is not an issue, but it's an exception and it can cause
    #       dummy test to fail.
    module = create_test_module(
        source="""
            [2, *range(10), 1]
        """)
    t.visit(module)
    assert isinstance(module.body[0].value, ast3.List)



# Generated at 2022-06-12 04:02:52.585271
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import assert_transform, ast_to_source
    assert_transform(
        StarredUnpackingTransformer,
        'print(*range(3), *range(4))',
        'print(*(list(range(3)) + list(range(4))))'
    )

    from . import assert_source
    assert_source(
        StarredUnpackingTransformer,
        'print(*range(3), *range(4), sep=1, end=2)',
        'print(*(list(range(3)) + list(range(4))), sep=1, end=2)'
    )


# Generated at 2022-06-12 04:03:04.158631
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3), sep=';')").body[0].value

# Generated at 2022-06-12 04:03:13.079095
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # checking the transformation of Call
    # the structure of the tree is:
    tree = ast.parse("print(*range(1), *range(3))").body[0]
    assert isinstance(tree, ast.Expr)
    assert isinstance(tree.value, ast.Call)
    # Check the structure of the tree Call
    node = tree.value
    # Check the structure of Call func
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'print'
    # Check the structure of Call args
    assert isinstance(node.args[0], ast.Starred)
    assert isinstance(node.args[0].value, ast.Call)
    assert isinstance(node.args[0].value.func, ast.Name)

# Generated at 2022-06-12 04:03:22.335970
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_node = ast.parse('[1, 2, *range(10), 3]')
    StarredUnpackingTransformer().visit(ast_node)

    expected_ast_node = ast.parse(
        '[1, 2] + list(range(10)) + [3]')

    assert ast.dump(ast_node) == ast.dump(expected_ast_node)


# Generated at 2022-06-12 04:03:31.588786
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('test_StarredUnpackingTransformer_visit_Call')
    cases = [  # type: List[Tuple[str, str]]
        ('print(1, *[2], *[3, 4])', 'print(*([] + list([2]) + [3] + [4]))'),
        ('list(1, *[2], *[3, 4])', 'list(*([] + list([2]) + [3] + [4]))'),
        ('dict(1, *[2], *[3, 4])', 'dict(*([] + list([2]) + [3] + [4]))'),
        ('set(1, *[2], *[3, 4])', 'set(*([] + list([2]) + [3] + [4]))'),
    ]

# Generated at 2022-06-12 04:03:41.761915
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:52.716706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from textx.scoping import Postponed
    import astor
    from .typehints import TypeHintsTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    def _test(file, expected_result):
        code = open(file).read()
        ast_orig = ast.parse(code)
        ast_first = TypeHintsTransformer().visit(ast_orig)
        ast_first = StarredUnpackingTransformer().visit(ast_first)
        result = astor.to_source(ast_first)
        assert result == expected_result, '\n{}\n{}\n{}\n{}'.format(result, "="*80, expected_result, "="*80)

# Generated at 2022-06-12 04:03:58.333828
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    print(ast.dump(ast.parse("print(*range(1), *range(3))")))
    print(ast.dump(t.visit(ast.parse("print(*range(1), *range(3))"))))
    assert str(t.visit(ast.parse("print(*range(1), *range(3))"))) == str(ast.parse("print(*(list(range(1)) + list(range(3))))"))


# Generated at 2022-06-12 04:04:08.504415
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse(
        """
        print(*range(1), *range(3))
        """
    )
    print(module)
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
              ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))],
        keywords=[]
    )
    changed_node = StarredUnpackingTransformer().visit_Call(node)
    print(changed_node)
    assert ast.dump(changed_node) == ast.dump(module.body[0].value)


# Generated at 2022-06-12 04:04:11.899263
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test method visit_Call of class StarredUnpackingTransformer."""
    from .tree_copy import copy_tree

    original = ast.parse('''
        print(*range(1), *range(3))
        ''')
    expected = ast.parse('''
        print(*(list(range(1)) + list(range(3))))
        ''')

    source = next(iter(original.body))
    expected = next(iter(expected.body))

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(copy_tree(source))

    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:04:14.950283
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    before = ast.parse("print(*range(1), *range(3))")
    after = ast.parse("print(*(list(range(1)) + list(range(3))))")
    assert StarredUnpackingTransformer().visit(before) == after


# Generated at 2022-06-12 04:04:22.429981
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import compile_source
    source = 'print(*range(10, 1), *range(4, 8))'
    expected = 'print(*([10, 11, 12] + [4, 5, 6, 7]))'
    claims = [
        'it compiles correct source',
        'it returns correct ast node'
    ]
    node = compile_source(source, mode='exec')
    node = StarredUnpackingTransformer().visit(node)
    actual = compile_source(ast.fix_missing_locations(node), mode='exec')
    actual = ast.dump(actual)
    assert expected == actual, f'{claims[0]}: {expected} != {actual}'

# Generated at 2022-06-12 04:04:27.468651
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    test_tree = ast.parse("[2, *range(10), 1]")
    transformer.visit(test_tree)
    expected_tree = ast.parse("[2] + list(range(10)) + [1]")
    compare_ast(expected_tree, test_tree)


# Generated at 2022-06-12 04:04:35.968688
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]").body[0].value
    expected = ast.parse("[2] + list(range(10)) + [1]").body[0].value
    assert StarredUnpackingTransformer().visit_List(node) == expected


# Generated at 2022-06-12 04:04:40.845773
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astutils
    tree = astutils.parse_string("print(*range(1), *range(3))")
    expected = astutils.parse_string(
        "print(*(list(range(1)) + list(range(3))))")
    transform = StarredUnpackingTransformer()
    result = transform.visit(tree)
    assert expected == result


# Generated at 2022-06-12 04:04:47.562003
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .builder import ast_from_code

    def test_case(code: str, expected: str):
        def get_args(node: ast.Call) -> List[ast.expr]:
            return node.args

        node = ast_from_code(code)
        visitor = StarredUnpackingTransformer()
        node = visitor.visit(node)

        assert node.body[0].value.args == [ast.Starred(value=ast.Call(
            ast.Name(id='list'),
            [],
            [
                ast.keyword(arg='start', value=ast.Constant(1)),
                ast.keyword(arg='stop', value=ast.Constant(4))
            ]
        ))]
        if expected:
            assert visitor.tree_changed
        else:
            assert not visitor.tree_

# Generated at 2022-06-12 04:04:53.430210
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code_to_test = 'x = call_function(1, 2, *range(5), 3)'
    expected_output = 'x = list([1, 2]) + list(range(5)) + list([3])'

    tester = StarredUnpackingTransformer()
    tester.transform_source(code_to_test)

    assert tester.code == expected_output


# Generated at 2022-06-12 04:04:59.638364
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    call = ast.Call(func=ast.Name(id='print'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[]), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[]))], keywords=[])
    call_after = transformer.visit(call)
    assert call_after.args[0].value.left.func.id == 'print'
    assert call_after.args[0].value.right.func.id == 'print'
    assert isinstance(call_after.args[0].value.left.args[0], ast.List)

# Generated at 2022-06-12 04:05:11.074495
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    from .util import parse, compare_source

    # I. List AST node
    SomeList = parse("[1,2,*range(3)]")
    assert isinstance(SomeList, ast.List)

    # I.1. Simple List
    SimpleList = parse("[1,2]")
    assert isinstance(SimpleList, ast.List)
    assert len(SimpleList.elts) == 2

    # I.1.1. List with Sum of Lists
    ListSumOfLists = parse("[1,2] + [3]")
    assert isinstance(ListSumOfLists, ast.BinOp)
    assert isinstance(ListSumOfLists.left, ast.List)
    assert len(ListSumOfLists.left.elts) == 2


    # I.2. List

# Generated at 2022-06-12 04:05:13.576670
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .fixtures import StarredUnpackingTestCase

    for i, o in StarredUnpackingTestCase.make_tests():
        transformer = StarredUnpackingTransformer()
        transformed = transformer.visit(i)
        assert transformed == o, 'case #{} failed'.format(transformer.case_id)



# Generated at 2022-06-12 04:05:18.253915
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseTestTransformer
    # Setup
    input_src = """
        [2, *range(10), 1]
        """
    expected_src = """
        [2] + list(range(10)) + [1]
        """
    test_obj = BaseTestTransformer(input_src, expected_src, StarredUnpackingTransformer)
    test_obj.test()


# Generated at 2022-06-12 04:05:23.802765
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestTransformer(StarredUnpackingTransformer):
        def __init__(self):
            self.counter = 0 

    test_ast = ast.parse('''print(*range(1), *range(3))''')
    tr = TestTransformer()
    tr.visit(test_ast)
    node = tr.visit(test_ast)
    transformed_code = compile(node, '<stdin>', 'eval')
    eval(transformed_code)

# Generated at 2022-06-12 04:05:29.881946
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..transpile import transpile

    x = [2, *range(10), 1]
    node = ast.parse(str(x)).body[0].value
    assert StarredUnpackingTransformer.visit(node) == '[2] + list(range(10)) + [1]'
    assert transpile(node) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:05:47.539377
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    StarredUnpackingTransformer._test_run('x', '1', 'x', 'x = [2, *range(10), 1]')
    StarredUnpackingTransformer._test_run('x', '*[2, 10]', 'x', 'x = [2, *range(10)]')
    StarredUnpackingTransformer._test_run('x', '*[2, 10, 1]', 'x', 'x = [2, *range(10), 1]')
    StarredUnpackingTransformer._test_run('x', '*[2, 10, 1, 4]', 'x', 'x = [2, *range(10), 1, *range(4)]')

# Generated at 2022-06-12 04:05:57.632510
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()

    # Check __init__
    assert sut.target == (3, 4)
    assert not sut.is_tree_changed()

    # Check that there is no need to change tree
    untouched_tree = ast.parse('[1, 2, 3]')
    sut.visit(untouched_tree)
    assert not sut.is_tree_changed()

    # Check that tree changes after visit
    changed_tree = ast.parse('[1, *range(10), 2]')
    sut.visit(changed_tree)
    assert sut.is_tree_changed()

    # Check correct transforming
    changed_tree = ast.parse('[1, *range(10), 2]')
    sut.visit(changed_tree)
    assert ast.dump

# Generated at 2022-06-12 04:06:03.387263
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    old_tree = ast.parse(source)
    new_tree = StarredUnpackingTransformer().visit(old_tree)
    new_tree_code = compile(new_tree, filename='<string>', mode='eval')
    assert eval(new_tree_code) == eval(expected)


# Generated at 2022-06-12 04:06:13.478677
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """\
a = [2, *range(10), 1]
print(*range(1), *range(3))"""
    expected = """\
a = [2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))"""
    tree = ast.parse(textwrap.dedent(source))
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    result = compile(tree, filename='<ast>', mode='exec')
    namespace = {}
    exec(result, namespace)
    assert namespace == {'a': [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]}
    captured = io.StringIO()

# Generated at 2022-06-12 04:06:21.854841
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import astunparse
    import inspect
    import textwrap

    source = textwrap.dedent(inspect.cleandoc('''
    func(2, *range(10), 3)
    '''))

    expected = textwrap.dedent(inspect.cleandoc('''
    func(*[2] + list(range(10)) + [3])
    '''))

    tree = ast.parse(source)
    result = StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(result) == expected



# Generated at 2022-06-12 04:06:29.607835
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as ast

    code = """print(*range(1), *range(3))"""
    example_tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(example_tree)
    result = ast.dump(tree)

# Generated at 2022-06-12 04:06:30.391755
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # TODO: insert test
    pass

# Generated at 2022-06-12 04:06:31.184415
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-12 04:06:31.700113
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:06:40.145438
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Create AST
    x = ast.parse("[2, *range(10), 1]")

    # Create a StarredUnpackingTransformer
    starTransformer = StarredUnpackingTransformer()

    # Transform the AST
    starTransformer.visit(x)
    xStr = ast.dump(x)
    expected = "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=Call(func=Name(id='list'), args=[Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])], keywords=[])), op=Add(), right=List(elts=[Num(n=1)])))])"
    assert expected == xStr


# Generated at 2022-06-12 04:07:03.379467
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = StarredUnpackingTransformer().visit(ast.parse("x = [1, 2, 3]"))
    assert ast.dump(a) == ast.dump(ast.parse("x = [1, 2, 3]"))
    b = StarredUnpackingTransformer().visit(ast.parse("x = [1, 2, *range(3), 4]"))
    assert ast.dump(b) == ast.dump(ast.parse("x = [1, 2] + list(range(3)) + [4]"))
    c = StarredUnpackingTransformer().visit(ast.parse("x = [1, *range(2), 3, *range(2), 4]"))

# Generated at 2022-06-12 04:07:13.208982
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        """Test case for method visit_Call of class StarredUnpackingTransformer"""

        transformer = StarredUnpackingTransformer

        def test_simple(self):
            source = """
                x = print(1, *range(5), 2)
            """
            expected = """
                x = print(*(list((1,)) + list(range(5)) + list((2,))))
            """
            tree = ast.parse(source)
            self.check(source, expected, tree=tree)

        def test_simple2(self):
            expected = """
                x = print(*(list((1,)) + list(range(5)) + list((2,))))
            """
            tree = ast.parse(expected)


# Generated at 2022-06-12 04:07:21.170810
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_source = """
    def test(a, b, c, d):
        foo(1, 2, 3, 4, *a, *b, c, d, *[1, 2, 3], *[], *[], *[1])

    def test2():
        bar(1, 2, 3, 4, 5, 6, 7, 8, 9)
    """

    expected_source = """
    def test(a, b, c, d):
        foo(*(list([1, 2, 3, 4]) + list(a) + list(b) + [c, d] + list([1, 2, 3]) + list([]) + list([]) + list([1])))

    def test2():
        bar(1, 2, 3, 4, 5, 6, 7, 8, 9)
    """


# Generated at 2022-06-12 04:07:25.561944
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    kwargs = dict()
    trans = StarredUnpackingTransformer()
    trans.visit(ast.parse(code))
    assert trans.code == expected


# Generated at 2022-06-12 04:07:31.939632
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("test_StarredUnpackingTransformer_visit_Call")

    # Checking convertion of starred unpacking argument to sum of lists
    # in the case of *args passed in one argument
    code = 'print(*range(1), *range(3))'
    nodes = ast.parse(code)

    transformer = StarredUnpackingTransformer()
    transformer.visit(nodes)

    fixed_code = astor.to_source(nodes)
    print(fixed_code)

    expected_code = "print(*([range(1)] + [range(3)]))"
    assert fixed_code == expected_code

    # Checking convertion of starred unpacking argument to sum of lists
    # in the case of *args passed in two argument
    code = 'print(*range(1), *range(3), 2)'

# Generated at 2022-06-12 04:07:38.718314
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_base import code_to_ast

    for code in [
        '[1] + [2, 3]',
        '[1] + [2, 3, *range(4)]',
        '[1] + [*range(2), 3, *range(4)]',
        '[*range(1), 2]',
        '[*range(1), 2, *range(4), 3]',
    ]:
        src = code_to_ast(code)
        assert StarredUnpackingTransformer().visit(src) == src



# Generated at 2022-06-12 04:07:42.905953
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = '''
    a = [2, *range(10), 1]
    print(*range(1), *range(3))
    '''
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    code = compile(tree, '<test>', 'exec')
    exec(code)

# Generated at 2022-06-12 04:07:50.296349
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tr = StarredUnpackingTransformer()
    tree = ast.parse(code)
    new_tree = tr.visit(tree)
    gen = ast.get_source_segment(new_tree)
    assert next(gen) == "[2, "
    assert next(gen) == "] + "
    assert next(gen) == "list(range(10))"
    assert next(gen) == " + "
    assert next(gen) == "[1]"
    assert next(gen) == ""
    assert next(gen, None) is None


# Generated at 2022-06-12 04:07:54.238600
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiled_pycon.transpiler import Transpiler
    from .testutils import AssertAST

    t = Transpiler()
    a = AssertAST(t)

    a.assert_ast("""
    print(*range(1), *range(3))
    """, """
    print(*(list(range(1)) + list(range(3))))
    """)

# Generated at 2022-06-12 04:07:57.111395
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    result = convert(source, StarredUnpackingTransformer)
    assert result == expected, '\n'.join([result, expected])



# Generated at 2022-06-12 04:08:42.034560
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import compile_to_ast
    from .base import node_to_src
    from .base import transform_ast

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = compile_to_ast(code, mode='eval')
    new_tree = transform_ast(tree, StarredUnpackingTransformer)
    assert node_to_src(new_tree) == expected


# Generated at 2022-06-12 04:08:46.704013
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = ast.parse("[1, *range(4), 1]").body[0]
    expected_ast = ast.parse("[1] + list(range(4)) + [1]").body[0]
    StarredUnpackingTransformer().visit(code)
    assert ast.dump(code) == ast.dump(expected_ast)


# Generated at 2022-06-12 04:08:56.332594
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse(
        textwrap.dedent(
            '''\
            print(*range(1), *range(3))
            '''
        )
    )
    if sys.version_info < (3, 5):
        expected = ast.parse(
            textwrap.dedent(
                '''\
                print(*(([1] + list(range(3))) + list(range(3))))
                '''
            )
        )
    else:
        expected = ast.parse(
            textwrap.dedent(
                '''\
                print(*(([1] + range(3)) + range(3)))
                '''
            )
        )
    result = StarredUnpackingTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(result)


# Unit

# Generated at 2022-06-12 04:09:06.062547
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    def s(x: str) -> ast.List:
        return ast.parse(x).body[0].value

    assert transformer.visit(s('[2, 3, 4]')) == s('[2, 3, 4]')
    assert transformer.visit(s('[*[1, 2, 3]]')) == s('[1, 2, 3]')
    assert transformer.visit(s('[1, *[2, 3], *[4, 5]]')) == s('[1] + [2, 3] + [4, 5]')
    assert transformer.visit(s('[*[], *[], *[]]')) == s('[] + [] + []')

# Generated at 2022-06-12 04:09:09.729491
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        """
import math
print(*range(1), *range(3))
""")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == """
<_ast.Module object at 0x0000000001D3F9E8>"""


# Generated at 2022-06-12 04:09:11.010933
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-12 04:09:17.256707
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import UnitCase

    # Example 1
    code = 'print(*range(3), *range(1))'
    expected = 'print(*(list(range(3)) + list(range(1))))'

# Generated at 2022-06-12 04:09:26.634577
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._to_sum_of_lists([ast.Starred(value=ast.Name(id='x'))]) == \
    ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='x')], keywords=[])
    assert StarredUnpackingTransformer()._to_sum_of_lists([ast.List(elts=[])]) == \
    ast.List(elts=[])

# Generated at 2022-06-12 04:09:35.118568
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase
    from . import base
    import textwrap

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        # Python code to parse
        CODE = textwrap.dedent('''
            a = [2, *range(10), 1]
            print(*range(1), *range(3))
        ''')

        # Check the result of transformation
        def test_transformed(self):
            ast.fix_missing_locations(self.transformed)


# Generated at 2022-06-12 04:09:37.846757
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]").body[0]) == \
        ast.parse("[2] + list(range(10)) + [1]").body[0]



# Generated at 2022-06-12 04:11:20.228936
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("""\
a = [*range(1), *range(3), [1, *range(3), 2]]
print(*range(1), *range(3))
""")
    t = StarredUnpackingTransformer()
    t.visit(tree)


# Generated at 2022-06-12 04:11:22.615194
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    res = StarredUnpackingTransformer().visit(ast.parse("""
a('b', *[1, 2], c=3)
    """).body[0])
    print(ast.dump(res))



# Generated at 2022-06-12 04:11:26.868041
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer."""
    try:
        # pylint: disable=pointless-statement,unused-variable
        StarredUnpackingTransformer()
    except TypeError:
        assert True # Exception should be raised by constructor
    else:
        assert False # No exception should be raised by constructor



# Generated at 2022-06-12 04:11:35.732923
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import get_node
    node1 = get_node("[2, *range(10), 1]")
    node1 = StarredUnpackingTransformer().visit(node1)
    print("Node1:", node1)

# Generated at 2022-06-12 04:11:45.266941
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast.ast3 import dump
    from .parsers import parse_to_ast

    to_compiled = '''
            print("a")
            print("b")
            print("c")
        '''
    expected = '''
            print("a", "b", "c")
        '''
    assert dump(StarredUnpackingTransformer().visit(parse_to_ast(to_compiled))).strip() == expected.strip()

    to_compiled = '''
            a(1)
            a(2)
            a(3)
        '''
    expected = '''
            a(*[1, 2, 3])
        '''
    assert dump(StarredUnpackingTransformer().visit(parse_to_ast(to_compiled))).strip() == expected.strip()

#

# Generated at 2022-06-12 04:11:53.021509
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert_result_of_visit = partial(assert_call, StarredUnpackingTransformer)

    assert_result_of_visit("print(*range(1), *range(3))",
                           "print(*(list(range(1)) + list(range(3))))")
    assert_result_of_visit("print(*range(1), 1)",
                           "print(*(list(range(1)) + [1]))")
    assert_result_of_visit("print(*range(1), 1, *[2, 3], 4)",
                           "print(*(list(range(1)) + [1] + [2, 3] + [4]))")
