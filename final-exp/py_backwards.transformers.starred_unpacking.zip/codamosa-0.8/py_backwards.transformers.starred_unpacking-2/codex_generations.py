

# Generated at 2022-06-12 04:01:53.546927
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-12 04:01:59.584414
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]')) == \
        ast.parse('[2] + list(range(10)) + [1]').body[0]
    assert StarredUnpackingTransformer().visit(ast.parse('print(*range(1), *range(3))')) == \
        ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]

# Generated at 2022-06-12 04:02:10.717828
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_ast = ast.parse('print(1, *[2, *range(5), 3], 4)').body[0]

# Generated at 2022-06-12 04:02:14.659171
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[*[1, 2], *range(3), 4]")

    result_node = StarredUnpackingTransformer().visit(node)
    expected_node = ast.parse("list([1, 2]) + list(range(3)) + [4]")

    assert ast.dump(result_node) == ast.dump(expected_node)

# Generated at 2022-06-12 04:02:22.325580
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'

    expected = 'print(*(list(range(1)) + list(range(3))))'

    ast_mod = ast.parse(code)
    StarredUnpackingTransformer().visit(ast_mod)  # type: ignore
    mod = compile(ast_mod, '<string>', 'exec')
    ns = {}
    exec(mod, ns)
    assert mod.co_code.hex() == dis.dis(expected).co_code.hex()


# Generated at 2022-06-12 04:02:28.214450
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as AST
    t = StarredUnpackingTransformer()
    node = AST.List(elts=[AST.Starred(value=AST.Name(id='a'), ctx=AST.Load()),
                          AST.Starred(value=AST.Name(id='b'), ctx=AST.Load())], ctx=AST.Load())
    t.visit(node)
    assert t._tree_changed
    assert isinstance(node.elts[0], AST.Call)
    assert node.elts[0].args[0].id == 'a'
    assert isinstance(node.elts[1], AST.Call)
    assert node.elts[1].args[0].id == 'b'


# Generated at 2022-06-12 04:02:36.685460
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    from typed_ast import ast3 as typed_ast
    source = ast.parse('print(1, *range(10))')
    node = source.body[0].value
    print(StarredUnpackingTransformer().visit(node))
    # Expected output:
    # Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Num(n=1, ctx=Load())]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10, ctx=Load()), keywords=[])], keywords=[])]))], keywords=[])


# Generated at 2022-06-12 04:02:46.830627
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse(
r"""
from typing import *
xs = [2, *range(10), 1]
""").body[1]

    class VisitorMockup:
        def __init__(self, node):
            self.node = node

        def generic_visit(self, node):
            return node

    visitor = StarredUnpackingTransformer(VisitorMockup(node))
    result = visitor.visit_List(node.value)

# Generated at 2022-06-12 04:02:58.715258
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Compiled to:
    # func(42, *list(range(4)), *[1])
    func = ast.Call(
        func=ast.Name(id='func'),
        args=[
            ast.Num(n=42),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='list'),
                    args=[ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Num(4)])],
                    keywords=[])),
            ast.Starred(
                value=ast.List(
                    elts=[ast.Num(1)]))],
        keywords=[]
    )

    tree = StarredUnpackingTransformer()(func)

# Generated at 2022-06-12 04:03:04.698813
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'
    tree = ast.parse(code)
    expected_code = """print(*(list(range(1)) + list(range(3))))"""
    expected_tree = ast.parse(expected_code)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-12 04:03:19.178364
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:03:22.901614
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from tests._test_utils import transform

    code = "foo(*range(10), *range(10))"
    expected = 'foo(*(list(range(10)) + list(range(10))))'
    transform(StarredUnpackingTransformer, code, expected)


# Generated at 2022-06-12 04:03:27.330077
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert compile(
        """
[2, *range(10), 1]
""", '<string>', mode='exec').co_code == b'|\x00\x00d\x01|\x01\x00d\x02d\x03'



# Generated at 2022-06-12 04:03:30.423872
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_example = """
        [2, *range(10)]
    """
    tree = ast.parse(test_example)
    StarredUnpackingTransformer().visit(tree)

    assert type(tree.body[0].value.right) is ast.Call


# Generated at 2022-06-12 04:03:33.827957
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_str = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    res = StarredUnpackingTransformer().visit_tree(ast.parse(test_str)).dump()
    assert res == expected


# Generated at 2022-06-12 04:03:44.959461
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typing import List
    from .. import visit_ast_tree
    from ..pattern_matching import match

    class Collector(BaseNodeTransformer):
        def __init__(self):
            self.els: List[str] = []

        def visit_Call(self, node: ast.Call) -> ast.Call:
            with match(node):
                if ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[]))], keywords=[]))]):
                    self.els.append('*range(1)')

# Generated at 2022-06-12 04:03:55.041718
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from tests.support import convert_and_compare_ast
    from tests.support import convert_and_compare_source

    convert_and_compare_source(
        """
        print(1, *range(3), *range(7), *range(5), 2)
        """,
        """
        print(*(list([1]) + list(range(3)) + list(range(7)) + list(range(5)) + list([2])))
        """
    )


# Generated at 2022-06-12 04:04:01.892527
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:04:11.562218
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTester

    source = 'print([1, *range(2), 3])'
    expected = 'print(([1] + list(range(2))) + [3])'
    BaseNodeTransformerTester(StarredUnpackingTransformer, source, expected).test()

    source = 'print([*range(2)])'
    expected = 'print(list(range(2)))'
    BaseNodeTransformerTester(StarredUnpackingTransformer, source, expected).test()

    source = 'print([[1], *range(2), [3]])'
    expected = 'print(([[1]] + list(range(2))) + [[3]])'
    BaseNodeTransformerTester(StarredUnpackingTransformer, source, expected).test()


# Generated at 2022-06-12 04:04:12.608441
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:04:23.042583
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import parse, ast3
    node = parse("[2, *range(10), 1]\nprint(*range(1), *range(3))\n")

    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)

    assert isinstance(node, ast3.Module)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast3.Expr)
    assert isinstance(node.body[0].value, ast3.BinOp)
    assert isinstance(node.body[1], ast3.Expr)
    assert isinstance(node.body[1].value, ast3.Call)
    assert len(node.body[1].value.args) == 1

# Generated at 2022-06-12 04:04:33.871005
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    import textwrap

    tree = ast.parse(textwrap.dedent('''\
        [2, *range(10), 1]
        [2, *range(10)]
        [2, *range(10)] + [1]
        [2, *range(10)] + [1] + [3]
        [2, *range(10), 1, *[2, 3, 4]]
        '''))
    tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 04:04:41.588972
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiler.ast import Call, Name
    transformator = StarredUnpackingTransformer()
    input_case = Call(
        Name("print"),
        [
            Name("a"),
            Name("b"),
            Name("c")
        ],
        []
    )
    expected_case = Call(
        Name("print"),
        [
            Name("*"),
            [
                Name("a"),
                Name("b"),
                Name("c")
            ]
        ],
        []
    )
    assert transformator.visit_Call(input_case) == expected_case



# Generated at 2022-06-12 04:04:48.993132
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class_ = StarredUnpackingTransformer

# Generated at 2022-06-12 04:04:56.320775
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(1, 2, *range(3), 4, *range(5), 6)")
    expected = ast.parse("print(*(list([1, 2]) + list(range(3)) + list([4]) + list(range(5)) + list([6])))")
    actual = list(StarredUnpackingTransformer.run(node))
    assert len(actual) == 1
    assert ast.dump(expected, annotate_fields=False) == ast.dump(actual[0], annotate_fields=False)


# Generated at 2022-06-12 04:05:00.960492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Visitor(ast.NodeVisitor):
        def visit_Call(self, node: ast.Call):
            return node

    node = ast.parse("print(*range(1), *range(3))").body[0]
    node = StarredUnpackingTransformer().visit(node)

    visitor = Visitor()

    visitor.visit(node)


# Generated at 2022-06-12 04:05:06.227898
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    f = """
[2, *range(10), 1]
    """
    x = ast.parse(f)
    StarredUnpackingTransformer.run_pipeline([StarredUnpackingTransformer])
    source = ast.dump(x)
    assert source == '[2] + list(range(10)) + [1]'


# Generated at 2022-06-12 04:05:11.610358
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = """
    [2, *range(10), 1]
    """

    t = """
    [2] + list(range(10)) + [1]
    """

    tree = ast.parse(s)
    StarredUnpackingTransformer().visit(tree)
    assert t == astor.to_source(tree)



# Generated at 2022-06-12 04:05:17.701576
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # "print(*range(1), *range(2))"
    tree = ast.parse('print(*range(1), *range(2))')
    trans = StarredUnpackingTransformer()
    tree = trans.visit(tree)

    # Check for tree change
    assert tree is not None

    # Check for correct result

# Generated at 2022-06-12 04:05:27.073563
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    tree = ast.parse(
        'print(*x, *y, z)',
        mode='eval')
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == (
        "Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Name(id='x', ctx=Load())]), right=BinOp(left=List(elts=[Name(id='y', ctx=Load())]), right=List(elts=[Name(id='z', ctx=Load())]), op=Add()), op=Add()))], keywords=[]))")

# Generated at 2022-06-12 04:05:34.740013
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Unit test for constructor of class StarredUnpackingTransformer")

    # create empty StarredUnpackingTransformer object test
    StarredUnpackingTransformer_obj = StarredUnpackingTransformer()

    assert isinstance(StarredUnpackingTransformer_obj, StarredUnpackingTransformer)

    print("End of unit test\n")



# Generated at 2022-06-12 04:05:44.493256
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    compiled = StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]").body[0].value)
    expected = ast.parse("[2] + list(range(10)) + [1]").body[0].value

    assert ast.dump(compiled) == ast.dump(expected)

    compiled = StarredUnpackingTransformer().visit(ast.parse("[1, *[]]").body[0].value)
    expected = ast.parse("[1]").body[0].value

    assert ast.dump(compiled) == ast.dump(expected)

    compiled = StarredUnpackingTransformer().visit(ast.parse("[*[1], 2]").body[0].value)
    expected = ast.parse("list([1]) + [2]").body[0].value



# Generated at 2022-06-12 04:05:48.781108
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # None can not be unpacked to placeholders
    with pytest.raises(ValueError):
        StarredUnpackingTransformer(None)
    # test3 is not a valid ast
    with pytest.raises(ValueError):
        StarredUnpackingTransformer('test3')
    # test2 is a valid ast
    a = StarredUnpackingTransformer('test2')
    assert a is not None

# Generated at 2022-06-12 04:05:56.920111
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(node)

    assert ast.dump(node) == "Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(func=Name(id='list'), args=[Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))"


# Generated at 2022-06-12 04:06:00.022672
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "[2] + list(range(10)) + [1]"



# Generated at 2022-06-12 04:06:10.561025
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import get_ast
    from .base import iter_node_classes
    code = get_ast("[2, *range(10), 1]", __file__)
    for node_class in iter_node_classes(code):
        transformer = StarredUnpackingTransformer()
        if isinstance(node_class, ast.List):
            old_code = ast.dump(node_class)
            new_code = ast.dump(transformer.visit(node_class))
            assert new_code == 'List(elts=[Num(n=2), Call(func=Name(id="list"), args=[Call(func=Name(id="range"), args=[Num(n=10)], keywords=[])], keywords=[]), Num(n=1)])'


# Generated at 2022-06-12 04:06:21.062642
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .tree_compiler import TreeCompiler
    import ast as python_ast

    source = """f(*[1, 2, *range(4), 4])"""

    expected_source = """f(*([] + [1, 2] + list(range(4)) + [4]))"""

    compiler = TreeCompiler('test', source)
    source_tree = compiler.parse()
    source_tree = StarredUnpackingTransformer().visit(source_tree)
    compiler.tree = source_tree
    result = compiler.compile()

    assert isinstance(result, python_ast.Module)
    assert len(result.body) == 1
    assert isinstance(result.body[0], python_ast.Expr)
    assert isinstance(result.body[0].value, python_ast.Call)

# Generated at 2022-06-12 04:06:25.907181
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code = 'print(*range(1), *range(3))'
    parsed = ast.parse(code)
    compiled = StarredUnpackingTransformer().visit(parsed)

    assert astor.to_source(compiled) == 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-12 04:06:30.673216
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import check_function_transformation

    check_function_transformation(StarredUnpackingTransformer,
                                  'print(*range(1), 2, *range(3), *range(2))',
                                  """
print(*(list(range(1)) + [2] + list(range(3)) + list(range(2))))
                                  """,
                                  """
# test_StarredUnpackingTransformer_visit_Call
print(*(list(range(1)) + [2] + list(range(3)) + list(range(2))))
                                  """,
                                  ast.parse)

# Generated at 2022-06-12 04:06:38.442605
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """
    Test that StarredUnpackingTransformer.visit_List method works.
    """
    source = inspect.cleandoc("""
        [2, *range(10), 1]
    """)
    expected_result = inspect.cleandoc("""
        ([2] + list(range(10)) + [1])
    """)
    module = ast.parse(source)
    expected_tree = ast.parse(expected_result)
    transformer = StarredUnpackingTransformer()
    module = transformer.visit(module) # type: ignore
    assert ast.dump(module) == ast.dump(expected_tree)



# Generated at 2022-06-12 04:06:53.799453
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer(tree).visit(tree)
    assert typed_astunparse.dump(tree) == "[2] + list(range(10)) + [1]"

    tree = ast.parse("[1, 2, *range(3), 4, 5, 6]")
    StarredUnpackingTransformer(tree).visit(tree)
    assert typed_astunparse.dump(tree) == "[1, 2] + list(range(3)) + [4, 5, 6]"

    tree = ast.parse("[2, 3, *[4, 5], 6]")
    StarredUnpackingTransformer(tree).visit(tree)

# Generated at 2022-06-12 04:07:01.738687
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseNodeTransformer):
        pass

    test_code = """
        print(*range(1), *range(3), 0)
    """

    test_node = ast.parse(test_code).body[0]
    expected_code = """
        print(*(list(range(1)) + list(range(3)) + [0]))
    """
    expected_node = ast.parse(expected_code).body[0]

    v = StarredUnpackingTransformer()
    v.visit(test_node)
    assert ast.dump(test_node) == ast.dump(expected_node)

    # check if transformer not breaks other transformers
    # and ensure that the tree was changed
    v = DummyTransformer()
    assert not v.vis

# Generated at 2022-06-12 04:07:11.709469
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    args = [ast.Name(id='range', ctx=ast.Load()), ast.Num(n=1)]
    star1 = ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[],
                                       starargs=None, kwargs=None))
    star2 = ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[],
                                       starargs=None, kwargs=None))
    # ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[star1, star2], keywords=[])

# Generated at 2022-06-12 04:07:20.378159
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    cases = [
        ('print', 'print'),
        ('print(1)', 'print(1)'),
        ('print(*range(3))', 'print(*(list(range(3))))'),
        ('print(*range(1), *range(3))', 'print(*(list(range(1)) + list(range(3))))'),
        ('print(*range(1), 2, *range(3))', 'print(*(list(range(1)) + [2] + list(range(3))))'),
        ('print(1, *range(3))', 'print(*([1] + list(range(3))))'),
    ]

    for before, after in cases:
        parsed = ast.parse(before)
        expected = ast.parse(after)

        assert isinstance(parsed.body[0], ast.Expr)
       

# Generated at 2022-06-12 04:07:26.024735
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """print(*range(1), *range(3))"""
    expected = """print(*(list(range(1)) + list(range(3))))"""

    result = parse_single_statement(code)
    expected = parse_single_statement(expected)

    StarredUnpackingTransformer().visit(result)
    assert compare_ast(result, expected)



# Generated at 2022-06-12 04:07:32.103858
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_01 = ast.Call(func=ast.Name(id='print'),
                       args=[ast.Starred(value=ast.Name(id='stuff'))],
                       keywords=[])
    node_02 = ast.Call(func=ast.Name(id='print'),
                       args=[ast.Starred(value=ast.Name(id='stuff'))],
                       keywords=[])
    node_03 = ast.Call(func=ast.Name(id='print'),
                       args=[ast.Starred(value=ast.Name(id='stuff'))],
                       keywords=[])
    node_04 = ast.Call(func=ast.Name(id='print'),
                       args=[ast.Starred(value=ast.Name(id='stuff'))],
                       keywords=[])

# Generated at 2022-06-12 04:07:37.101109
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(5), *range(10))'
    expected = 'print(*(list(range(5)) + list(range(10))))'
    node = ast.parse(source)
    expected_node = ast.parse(expected)
    assert StarredUnpackingTransformer().visit(node) == expected_node

# Generated at 2022-06-12 04:07:45.722121
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from test_pythran_to_python import to_python
    from test_python_to_pythran import parse_ast

    input_code_1 = """
    x = [3, 5, *range(10), 1]
    """
    expected_code_1 = """
    x = [3, 5] + list(range(10)) + [1]
    """
    tree_1 = parse_ast("" if input_code_1 is None else input_code_1)
    StarredUnpackingTransformer().visit(tree_1)
    assert to_python(tree_1) == expected_code_1

    input_code_2 = """
    x = [3, 5, *range(10), 1]
    y = [3, 5, *range(10), 1, 2]
    """
    expected

# Generated at 2022-06-12 04:07:46.969280
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    assert trans is not None


# Generated at 2022-06-12 04:07:50.920694
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    input_ = ast.parse('print(*[1, *range(10), 2])')
    expected_output = ast.parse('print(*(list([1]) + list(range(10)) + list([2])))')
    assert transformer.visit(input_) == expected_output


# Generated at 2022-06-12 04:08:00.630028
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    statement = """
        print(1, *range(3), 2)
    """
    expected = """
        print(*(list((1)) + list(range(3)) + list((2))))
    """
    with override_sys_modules('builtins'):
        result = compile_to_ast(statement)
        assert_equal(ast.dump(result), expected)



# Generated at 2022-06-12 04:08:03.330560
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert len(inspect.getfullargspec(StarredUnpackingTransformer.visit_Call).args) == 2


# Generated at 2022-06-12 04:08:07.062942
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    s = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"
    actual = compile(s, '<string>', mode="exec", optimize=2).co_code.decode()
    assert actual == expected

# Generated at 2022-06-12 04:08:12.741946
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import sys

    source = """\
print(*range(1), *range(3))
"""
    expected = """\
print(*(list(range(1)) + list(range(3))))
"""
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)  # type: ignore
    code = compile(tree, filename='<ast>', mode='exec')
    ns = {}
    exec(code, ns)
    assert expected == sys.stdout.getvalue()


# Generated at 2022-06-12 04:08:18.154390
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    transformer = StarredUnpackingTransformer()
    input_source_code = 'print(*range(10), *range(20))'
    expected_output_source_code = 'print(*(list(range(10)) + list(range(20))))'
    input_ast_tree = astor.code_to_ast(input_source_code)
    transformer.visit(input_ast_tree)

    assert astor.to_source(input_ast_tree) == expected_output_source_code

# Generated at 2022-06-12 04:08:26.916461
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class DummyNodeTransformer(ast.NodeTransformer):
        def visit(self, node):
            return node

    cls = DummyNodeTransformer
    cls.generic_visit = DummyNodeTransformer.visit

    def prepare(s: str) -> ast.Call:
        return ast.parse(s).body[0].value

    def test_1():
        node = prepare('print(1)')
        assert StarredUnpackingTransformer().visit(node) == node

    def test_2():
        node = prepare('print(*range(5))')
        assert str(StarredUnpackingTransformer().visit(node)) == 'print(*(list(range(5))))'


# Generated at 2022-06-12 04:08:29.797889
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import compile_pipeline
    tree = ast.parse('print(*range(1), *range(3))')
    tree = compile_pipeline(tree, StarredUnpackingTransformer())
    assert tree == ast.parse('print(*(list(range(1)) + list(range(3))))')


# Generated at 2022-06-12 04:08:34.905564
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test_transformer(code: str) -> str:
        module = ast.parse(code)
        StarredUnpackingTransformer().visit(module)
        assert module
        return ast.unparse(module)
        
    code = """print(*range(1), *range(3))"""
    assert test_transformer(code=code) == """print(*(list(range(1)) + list(range(3))))"""


# Generated at 2022-06-12 04:08:42.833963
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("""
    print(*range(1), *range(2), 3, sep=' ')
    """)

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    expected_result = ast.parse("""
    print(*(list(range(1)) + list(range(2)) + [3]), sep=' ')
    """)

    print("Expected result:")
    print(ast.dump(expected_result, include_attributes=False))
    print("Actual result:")
    print(ast.dump(tree, include_attributes=False))

    assert str(tree) == str(expected_result)


# Generated at 2022-06-12 04:08:48.131984
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
    print(*range(10), *range(3))
    """
    expected_code = """    
    print(*(list(range(10)) + list(range(3))))
    """
    node = get_ast(code)
    StarredUnpackingTransformer().visit(node)
    expected_node = get_ast(expected_code)
    assert astor.to_source(expected_node) == astor.to_source(node)


# Generated at 2022-06-12 04:09:05.138274
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    func_def = ast.parse("print(*range(1), *range(3))").body[0]

    expected = "print(*(list(range(1)) + list(range(3))))"
    result = StarredUnpackingTransformer().visit(func_def)

    assert expected == ast.dump(result)


# Generated at 2022-06-12 04:09:15.472827
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from _astpp import dump
    from _jit import jit # type: ignore
    from ast_toolbox import dump_pycode
    from ..examples.starred_unpacking import A

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            node = self.generic_visit(node)  # type: ignore
            if not self.tree_changed:
                print("Nothing to change.")
            return node

    tree_changed = False
    for name in ('test1', 'test2'):
        func = jit(getattr(A, name))
        func_node = ast.parse(dump_pycode(func)).body[0]


# Generated at 2022-06-12 04:09:23.962352
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Create an instance of StarredUnpackingTransformer
    star_trans = StarredUnpackingTransformer()

    # Create a call node with a list
    callNode = ast.parse('''
        f(1, *[1,2])
    ''', mode='eval').body
    # Compile the call node with the transformer
    callNode = star_trans.visit(callNode)
    # Get string representation of the call node
    str1 = str(ast.dump(callNode))

    # Assert that the node is a call with a single argument

# Generated at 2022-06-12 04:09:29.566094
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
            func=ast.Name(id='print'),
            args=[ast.Starred(value=ast.Name(id='range')), ast.Num(n=1), ast.Starred(value=ast.Name(id='range'))],
            keywords=[])
    visitor = StarredUnpackingTransformer()
    node_new = visitor.visit(node)
    print(ast.dump(node_new))


# Generated at 2022-06-12 04:09:37.564464
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    def do_test(source: str, expected: str) -> None:
        tree = ast.parse(source)
        StarredUnpackingTransformer().visit(tree)
        assert ast.dump(tree) == expected

    do_test('print(*range(1), *range(2))', 'Module(body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=1)], keywords=[])], keywords=[])], keywords=[]))])')

# Generated at 2022-06-12 04:09:45.870229
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def check(code1, code2):
        tree1 = ast.parse(code1)
        tree2 = ast.parse(code2)

        tr = StarredUnpackingTransformer()
        tree1 = tr.visit(tree1)
        assert ast.dump(tree1) == ast.dump(tree2)

    def check_fail(code):
        tree = ast.parse(code)

        tr = StarredUnpackingTransformer()
        with pytest.raises(AssertionError) as e:
            tr.visit(tree)
        return e


# Generated at 2022-06-12 04:09:49.320817
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import compare_ast
    from . import parse
    compare_ast(
        StarredUnpackingTransformer().visit(parse('''
            print(*range(1), *range(3))
        ''')),
        parse('''
            print(*(list(range(1)) + list(range(3))))
        '''),
    )


# Generated at 2022-06-12 04:09:56.510068
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            code = """\
            print(*range(1), *range(3))
            """
            expected = """\
            print(*(list(range(1)) + list(range(3))))
            """
            self.assert_transformation(code, expected)

        def test_simple_many_stars(self):
            code = """\
            print(*range(1, 3), *range(3, 6))
            """
            expected = """\
            print(*(list(range(1, 3)) + list(range(3, 6))))
            """
            self.assert_transformation(code, expected)

        def test_with_other_args(self):
            code

# Generated at 2022-06-12 04:10:04.650209
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import compile_to_ast
    
    tree = compile_to_ast(
        textwrap.dedent('''\
        from typing import List
        
        arr: List[str] = ['foo', 'bar']
        print(*arr)
        '''))
    
    StarredUnpackingTransformer().visit(tree)
    
    assert_code_equal(
        tree,
        textwrap.dedent('''\
        import typed_ast.ast3 as ast
        from collections import OrderedDict
        from typing import List
        
        arr: List[str] = ['foo', 'bar']
        print(*(arr))
        '''))



# Generated at 2022-06-12 04:10:12.410579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typing
    from typed_ast import ast3 as ast
    from typed_ast import util
    source = 'print(*range(1), *range(3))\n'
    node = util.parse(source)
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:10:39.882636
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given:
    tree = ast.parse("""
    sort(*range(10), *range(2))
    """)

    expected = ast.parse("""
    sort(*(list(range(10)) + list(range(2))))
    """)

    # When:
    StarredUnpackingTransformer().visit(tree)

    # Then:
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 04:10:44.397034
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    c = StarredUnpackingTransformer()
    tree = ast.parse('print(*range(1), *range(3))')
    tree = c.visit(tree)

    assert 'print' == tree.body[0].value.func.id
    assert 'range' == tree.body[0].value.args[0].value.func.id



# Generated at 2022-06-12 04:10:47.182523
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()
    node = ast.parse("print(*(range(1)))").body[0]
    visitor.visit(node)
    res = ast.parse("print(*list(range(1)))").body[0]
    assert node == res


# Generated at 2022-06-12 04:10:55.213778
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''
print(*[1, 2], *[1, 2], *[1, 2])
''').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'print'
    assert isinstance(node.value.args[0], ast.Starred)
    assert isinstance(node.value.args[0].value, ast.BinOp)
    assert isinstance(node.value.args[0].value.op, ast.Add)
    assert isinstance(node.value.args[0].value.left, ast.BinOp)

# Generated at 2022-06-12 04:11:03.954780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3), 4)").body[0].value
    assert isinstance(node, ast.Call)
    assert node.starargs is None
    assert node.kwargs is None
    assert isinstance(node.args, list)
    assert len(node.args) == 3
    assert node.args[0].s == '*range(1)'
    assert node.args[1].s == '*range(3)'
    assert node.args[2].s == '4'

    StarredUnpackingTransformer().visit(node)

    assert isinstance(node.args, list)
    assert len(node.args) == 1
    assert node.args[0].s == '*((list(range(1)) + list(range(3))) + [4])'

#

# Generated at 2022-06-12 04:11:04.968337
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:11:11.138377
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    call = ast.Call(func=ast.Name(id='print'), args=[ast.Name(id='a'),
                                                     ast.Starred(value=ast.Name(id='b'))])

    call_compiled = sut.visit(call)

    assert isinstance(call_compiled.args[0], ast.Starred)
    assert call_compiled.args[0].value.func.id == 'list'
    assert call_compiled.args[0].value.args[0].id == 'b'



# Generated at 2022-06-12 04:11:19.617935
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from .debug_transformer import DebugTransformer
    from .base import BaseNodeTransformer
    
    def get_root(func: ast3.FunctionDef) -> ast3.AST:
        dt = DebugTransformer()
        st = StarredUnpackingTransformer()
        dt.visit(func)
        BaseNodeTransformer.reset_tree_changed()
        return st.visit(func)
    
    def get_func(source: str) -> ast3.FunctionDef:
        """Returns root node of AST."""
        return ast3.parse(source).body[0]
    
    def assert_source_transformed(source: str, expected: str) -> None:
        """Assert that source was transformed to expected."""

# Generated at 2022-06-12 04:11:27.909868
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    import unittest
    import logging
    import inspect
    import astunparse
    class Test(unittest.TestCase):
        def test_1(self):
            code_source = """\
foo(*(range(5), range(5)))
"""
            code_expected = """\
foo(*(list(range(5)) + list(range(5))))
"""
            logging.info('code_source:\n%s', code_source)
            root_node = ast3.parse(code_source)
            logging.info('root_node:\n%s', astunparse.unparse(root_node))
            transformer = StarredUnpackingTransformer()
            transformer.visit(root_node)
            result_code = astunparse.unparse(root_node).rstrip()


# Generated at 2022-06-12 04:11:36.866189
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .context import Context
    from .typer import Typer
    from .compile_task import CompileTask

    code = """
        fn(1, *[1, 2])
    """

    ast_module = Context.parse(code)
    typer = Typer()
    task = CompileTask(ast_module, typer)
    typer.run(task)
    transformer = StarredUnpackingTransformer()
    transformer.run(task)

    module = task.module

    assert isinstance(module.body[0].value.args[0], ast.Starred)
    assert module.body[0].value.args[0].value.elts[0].n == 1
    assert module.body[0].value.args[0].value.elts[1].elts[0].n == 2

# Unit