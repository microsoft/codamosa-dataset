

# Generated at 2022-06-12 04:01:57.074458
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    import types
    node = ast.parse("[2, *range(10), 1]", mode="eval")
    StarredUnpackingTransformer().visit(node)
    node2 = compile(node, "<test>", "eval")
    assert type(node2) == types.CodeType
    assert eval(node2) == [2] + list(range(10)) + [1]


# Generated at 2022-06-12 04:02:08.493051
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1]
    node = ast.parse("[2, *range(10), 1]").body[0].value

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)

    assert transformer._tree_changed

    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.List)
    assert result.left.elts == [ast.Num(2)]
    assert isinstance(result.right, ast.BinOp)
    assert isinstance(result.right.left, ast.Call)
    assert isinstance(result.right.left.func, ast.Name)
    assert result.right.left.func.id == 'list'
    assert isinstance(result.right.left.args[0], ast.Call)
   

# Generated at 2022-06-12 04:02:16.460687
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as p
    import _ast as c
    parse = lambda s: p.parse(s, 'exec').body[0]
    expected = lambda s: c.fix_missing_locations(p.parse(s, 'exec'))


# Generated at 2022-06-12 04:02:26.295698
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    original = ast.List(elts=[ast.Num(1), ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()), ast.Num(3)])

    result = t.visit(original)

    expected = ast.BinOp(
        ast.BinOp(
            left=ast.List(elts=[ast.Num(1)]),
            op=ast.Add(),
            right=ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Name(id='a')],
                keywords=[]
            )
        ),
        op=ast.Add(),
        right=ast.List(elts=[ast.Num(3)])
    )


# Generated at 2022-06-12 04:02:32.100901
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    line = "print(*range(1), *range(3))"
    line = ast.parse(line)
    test = StarredUnpackingTransformer()
    line = test.visit(line)
    expected = "print(*(list(range(1)) + list(range(3))))"
    expected = ast.parse(expected)
    assert ast.dump(line) == ast.dump(expected)

# Generated at 2022-06-12 04:02:40.350571
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    node1 = ast.Call()
    node1.args = []
    node2 = ast.Call()
    node2.args = [ast.Starred()]
    node2.args[0].value = ast.Name()
    node2.args[0].value.id = 'a'

    node1_starred = ast.Call()
    node1_starred.args = [ast.Starred()]
    node1_starred.args[0].value = ast.List()
    node1_starred.args[0].value.elts = []
    node1_starred.keywords = []

    node2_starred = ast.Call()
    node2_starred.args = [ast.Starred()]
    node2_starred.args[0].value = ast.List()
    node2_

# Generated at 2022-06-12 04:02:47.577504
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .parser import parse_ast

    test_tree = parse_ast("[2, *range(10), 1]", mode="eval")
    expected_tree = parse_ast("[2] + list(range(10)) + [1]", mode="eval")

    test_tree_copy = copy.deepcopy(test_tree)
    expected_tree_copy = copy.deepcopy(expected_tree)

    assert test_tree_copy == expected_tree_copy

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(test_tree)

    assert result == expected_tree
    assert test_tree == expected_tree



# Generated at 2022-06-12 04:02:59.535133
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..compiler import to_source
    from .nodes import test_node

    for node in test_node(ast.List, size=(1, 3)):
        actual = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:03:04.158024
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
	su_t = StarredUnpackingTransformer()
	#assert su_t.visit_List([1, 2, 3]) == [1, 2, 3]
	assert su_t.visit_List([1, *[2, 3]]) == [1, 2, 3]

# Generated at 2022-06-12 04:03:13.078968
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1]
    class Starred(ast.Starred):
        def __init__(self):
            self.value = ast.Call(
                func=ast.Name(
                    id='range',
                    ctx=ast.Load()),
                args=[ast.Constant(10, kind=None)],
                keywords=[])
    a = ast.List()
    a.elts = [
        ast.Constant(2, kind=None),
        Starred(),
        ast.Constant(1, kind=None)
    ]
    transformer = StarredUnpackingTransformer()
    res = transformer.visit(a)

    # [2] + list(range(10)) + [1]

# Generated at 2022-06-12 04:03:28.283576
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import os
    from compilers.basenodetransformer import DefaultAstCompilerUnsafe
    from compilers.compiler import DefaultCompiler
    from compilers.syntax import Syntax
    from compilers.type import Type

    class TestCompiler(DefaultCompiler):
        syntax_version = Syntax.python_version

        def synthesize(self, source_code: str, target: Type) -> bytes:
            ast_tree = ast.parse(source_code)
            transpiler = StarredUnpackingTransformer()
            transpiled = transpiler.visit(ast_tree)
            code = self.compile_node(transpiled, target)

            return code

    test_path = os.path.dirname(os.path.abspath(__file__))
    source_path = os.path.join

# Generated at 2022-06-12 04:03:36.842880
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from roosterize.compiler import ast_to_source
    from typing import Iterable, List, Union
    from typed_ast import ast3 as ast

    class Unpacker(BaseNodeTransformer):

        target = (3, 5)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = self._to_sum_of_lists(node.args)
            return self.generic_visit(node) # type: ignore

        def _to_sum_of_lists(self, xs: List[ast.expr]) -> Iterable[List[ast.expr]]:
            """Translate all starred unpacking to just list."""
            result = []  # type: List[List[ast.expr]]

# Generated at 2022-06-12 04:03:48.103364
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:03:54.672109
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(1, *range(5), 2, *range(1), *range(3))")
    visitor = StarredUnpackingTransformer()
    tree = visitor.visit(tree)
    expected = ast.parse("print(*(list([1])+list(range(5))+"
                         "list([2])+list(range(1))+list(range(3))))")
    assert astor.to_source(tree) == astor.to_source(expected)


# Generated at 2022-06-12 04:03:58.184428
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Testing StarredUnpackingTransformer")

    transformer = StarredUnpackingTransformer()

    tree = 'print([2, *range(10), 1])'
    expected = 'print([2] + list(range(10)) + [1])'

    assert transformer.transform(tree) == expected

# Generated at 2022-06-12 04:04:09.432901
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astunparse import unparse

    tree = ast.parse("[2, *range(10), 1]")
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    result = unparse(tree)
    assert result == "(2 + list(range(10)) + 1)"

    tree = ast.parse("[2, *range(10)]")
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    result = unparse(tree)
    assert result == "(2 + list(range(10)))"

    tree = ast.parse("[*range(10), 1]")
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    result = unparse(tree)
    assert result == "(list(range(10)) + 1)"


# Generated at 2022-06-12 04:04:14.931326
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    from generator.ast_parse import ast_parse

    from .test_helpers import BaseNodeTransformerTestCase

    class TestStarredUnpackingTransformer(BaseNodeTransformerTestCase):

        transformer = StarredUnpackingTransformer()

        def test_simple_list(self):
            # Arrange
            before = ast_parse('''
                [2, *range(10), 1]
            ''')
            # Act
            after = self.transformer.visit(before)
            # Assert
            self.assertEqualAst(ast_parse('''
                [2] + list(range(10)) + [1]
            '''), after)

    test = TestStarredUnpackingTransformer()
    test.test_simple_list()


# Generated at 2022-06-12 04:04:19.144620
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tr = StarredUnpackingTransformer()
    code = [2, *range(10), 1]
    result = tr.transform([code])[0][1]
    assert result == [2] + list(range(10)) + [1]


# Generated at 2022-06-12 04:04:29.618698
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source0 = 'print(1, *range(2), 3)'
    source1 = 'print(1, 2, 3)'
    source2 = 'print(3, *[1, 2])'
    source3 = 'print(1, *[1, *range(2)], *[*range(2), 3])'
    source4 = 'print(1, *[1, *range(2)], *[*range(2), 3, *range(5), 6])'
    source5 = 'print(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18)'

    expected0 = 'print(*(list([1]) + list(range(2)) + list([3])))'
    expected1 = 'print(1, 2, 3)'

# Generated at 2022-06-12 04:04:30.530041
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-12 04:04:40.665925
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()



# Generated at 2022-06-12 04:04:43.938097
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("TEST1: testing StarredUnpackingTransformer constructor:")
    transformer = StarredUnpackingTransformer()
    assert isinstance(transformer, StarredUnpackingTransformer)
    assert isinstance(transformer._tree_changed, bool)
    assert transformer._tree_changed == False



# Generated at 2022-06-12 04:04:48.460427
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast1 = ast.parse("print(1, *range(4), *range(3), 2)")
    ast2 = ast.parse("print(*[1] + list(range(4)) + list(range(3)) + [2])")

    transformer = StarredUnpackingTransformer()
    compiled = transformer.visit(ast1)

    assert ast.dump(compiled) == ast.dump(ast2)
    assert transformer._tree_changed

# Generated at 2022-06-12 04:04:55.902627
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    script = ast.parse(
        textwrap.dedent('''\
            print(1, *range(10), 2)
        '''))

    expected = ast.parse(
        textwrap.dedent('''\
            print(*(list([1]) + list(range(10)) + list([2])))
        '''))

    actual = StarredUnpackingTransformer().visit(script)
    assert ast.dump(expected, annotate_fields=False) == ast.dump(actual, annotate_fields=False)


# Generated at 2022-06-12 04:05:06.367419
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("L = [1, *r, 2]")

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].value, ast.List)
    assert len(tree.body[0].value.elts) == 3
    assert isinstance(tree.body[0].value.elts[0], ast.Num)
    assert tree.body[0].value.elts[0].n == 1
    assert isinstance(tree.body[0].value.elts[1], ast.Name)
    assert tree.body[0].value.elts[1].id == 'r'

# Generated at 2022-06-12 04:05:10.937839
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseTestTransformer
    from .base import get_node
    from .live_ast import parse

    class StarredUnpackingTransformerTest(BaseTestTransformer):
        TRANSFORMER = StarredUnpackingTransformer


# Generated at 2022-06-12 04:05:14.574364
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)
    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 04:05:19.140933
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Tests visit_Call method of class StarredUnpackingTransformer
    when there is no Unstarred"""
    assert (ast.dump(ast.parse(
        'print(10, 20, 30)'
    )) == ast.dump(StarredUnpackingTransformer().visit(ast.parse(
        'print(10, 20, 30)'
    ))))


# Generated at 2022-06-12 04:05:24.991617
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .compile_ast import compile_ast
    from .unparse_ast import unparse_ast

    x = ast.parse('print(*range(1), *range(3))')

    StarredUnpackingTransformer().visit(x)

    assert unparse_ast(x) == "print(*(list(range(1)) + list(range(3))))\n"
    # Should pass all test cases:
    compile_ast(x)


# Generated at 2022-06-12 04:05:31.928375
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("['foo', *range(10), 'bar']")
    t = StarredUnpackingTransformer()
    t.visit(tree)
    assert ast.dump(tree) == "Expr(value=List(elts=[Str(s='foo'), Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[]), Str(s='bar')], ctx=Load()))"


# Generated at 2022-06-12 04:05:57.487926
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .runner import compile_code

    test_code = """
    def test_code():
        list_ = [2, *range(10), 1] + [4, *range(4)]
        call = print(*range(1), *range(3))
    """
    compiled_code = compile_code(test_code, StarredUnpackingTransformer)
    assert "list_ = [2] + list(range(10)) + [1] + [4] + list(range(4))" in compiled_code
    assert "call = print(*(list(range(1)) + list(range(3))))" in compiled_code

# Generated at 2022-06-12 04:06:08.234393
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # type: () -> None
    from .test_transformer import transform


# Generated at 2022-06-12 04:06:15.466271
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    from .base import get_node

    class MyTest(BaseNodeTransformerTest):
        transformer = StarredUnpackingTransformer
        code = 'print(*range(1), *range(3))'
        node = get_node(code, 3)

        def assert_node(self, node: ast.AST) -> None:
            assert isinstance(node, ast.Call)
            assert node.args[0].elts[0].func.id == 'range'
            assert node.args[0].elts[0].args[0].n == 1
            assert node.args[0].elts[1].func.id == 'range'
            assert node.args[0].elts[1].args[0].n == 3

    test = MyTest()
    test.test_auto()

# Generated at 2022-06-12 04:06:25.870710
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .codegen import Codegen
    from . import to_source
    from .remove_unused import RemoveUnused
    from .remove_pass import RemovePass
    from .remove_doc import RemoveDoc

    src = """
        def f(a, b):
            pass"""
    tree = ast.parse(src)
    c = Codegen()
    tree = c.visit(tree)
    tree = StarredUnpackingTransformer().visit(tree)
    tree = RemoveUnused().visit(tree)
    tree = RemovePass().visit(tree)
    tree = RemoveDoc().visit(tree)
    res = to_source(tree)
    assert res == """
        def f(a, b):
            pass"""

# Generated at 2022-06-12 04:06:29.718092
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .visitor import ASTPrintVisitor as APV
    from .visitor import ASTModifiedVisitor as AMV
    
    source = '[2, *range(10), 1]'
    visitor = AMV()
    node = ast.parse(source)
    visitor.visit(node)
    print('[2, *range(10), 1]')
    print('-->')
    visitor = APV()
    visitor.visit(node)
    
    
    

# Generated at 2022-06-12 04:06:37.766347
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [1,2,*[3],4]
    elts = [ast.Num(1), ast.Num(2), ast.Starred(value=ast.List(elts=[ast.Num(3)])), ast.Num(4)]
    node = ast.List(elts=elts)
    StarredUnpackingTransformer().visit(node)
    expected_result = ast.List(elts=[ast.Num(1), ast.Num(2), ast.Num(4)])
    assert node.elts[0].n == 1
    assert node.elts[1].n == 2
    assert node.elts[2].n == 4


# Generated at 2022-06-12 04:06:47.039291
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer(): # type: ignore
    assert StarredUnpackingTransformer([]) == StarredUnpackingTransformer.target
    assert StarredUnpackingTransformer([2]) == StarredUnpackingTransformer.target
    assert StarredUnpackingTransformer([2, 4]) == StarredUnpackingTransformer.target
    assert StarredUnpackingTransformer([2, 4, 6]) == StarredUnpackingTransformer.target
    assert StarredUnpackingTransformer([2, 4, 6, 8]) == StarredUnpackingTransformer.target
    assert StarredUnpackingTransformer([2, 4, 6, 8, 10]) == StarredUnpackingTransformer.target
    assert StarredUnpackingTransformer([2, 4, 6, 8, 10, 12]) == StarredUnpackingTransformer.target

# Generated at 2022-06-12 04:06:52.223029
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .compiler import compile_code
    assert compile_code("[2, *range(10), 1]") == compile_code("[2] + list(range(10)) + [1]")
    assert compile_code("print(*range(1), *range(3))") == compile_code("print(*(list(range(1)) + list(range(3))))")
    assert compile_code("print(*range(10, 20), *range(30, 40))") == compile_code("print(*(list(range(10, 20)) + list(range(30, 40))))")

# Generated at 2022-06-12 04:06:56.797175
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    before = ast.parse("[2, *range(10), 1, 3, *range(15)]")
    result = StarredUnpackingTransformer().visit(before)
    after = ast.parse("[2] + list(range(10)) + [1, 3] + list(range(15))")
    assert ast.dump(result) == ast.dump(after)


# Generated at 2022-06-12 04:07:01.969095
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # create AST
    module = ast.parse('print(*range(1), *range(3))\nprint(*range(1), *range(3), sep="-")')

    # compile AST
    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(module)
    compiled_ast = node_transformer.compile_ast(module)
    code = compiled_ast.to_code()
    print(code)

    # execute old and new code
    exec (compiled_ast.to_code(), globals())



# Generated at 2022-06-12 04:07:25.470804
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = """
    print(*range(10), *range(1))
    """

    expected = """
    print(*((list(range(10)) + list(range(1)))))
    """

    module = ast.parse(src)
    StarredUnpackingTransformer().visit(module)
    assert ast.dump(module) == expected


# Generated at 2022-06-12 04:07:30.398638
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():    
    code = 'list(range(10))'
    a = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(a)

    assert ast.dump(tree) == 'Module(body=[Expr(value=Call(func=Name(id="list", ctx=Load()), args=[Name(id="range", ctx=Load()), Num(n=10)], keywords=[], starargs=None, kwargs=None))])'

test_StarredUnpackingTransformer()

# Generated at 2022-06-12 04:07:35.941645
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')

    transformer = StarredUnpackingTransformer()
    actual = transformer.visit(tree)

    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-12 04:07:41.673245
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    new_starred_unpacking = StarredUnpackingTransformer()

    src = """\
print(*[5], *[5]+[1])
"""
    tree = ast.parse(src)

    changed_tree = new_starred_unpacking.visit(tree)

    print(ast.dump(changed_tree))

# Generated at 2022-06-12 04:07:47.993147
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_code = '''
        [1, *range(10), 1, *range(2), 3]
    '''
    expected_code = '''
        [1] + list(range(10)) + [1] + list(range(2)) + [3]
    '''
    node = ast.parse(test_code, mode='eval')
    node = StarredUnpackingTransformer().visit(node)
    code = compile(node, '', mode='eval')
    assert eval(expected_code) == eval(code)



# Generated at 2022-06-12 04:07:55.987245
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    trans = StarredUnpackingTransformer()

    tree = ast.parse('[2, *range(10), 1]')
    expected = ast.parse('[2] + list(range(10)) + [1]')
    tree = trans.visit(tree)
    assert ast.dump(tree, include_attributes=False) == ast.dump(expected, include_attributes=False)

    tree = ast.parse('[]')
    expected = ast.parse('[]')
    tree = trans.visit(tree)
    assert ast.dump(tree, include_attributes=False) == ast.dump(expected, include_attributes=False)

    tree = ast.parse('[*range(1), 2, 3]')
    expected = ast.parse('list(range(1)) + [2, 3]')
    tree = trans

# Generated at 2022-06-12 04:07:57.561054
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert isinstance(t, StarredUnpackingTransformer)


# Generated at 2022-06-12 04:08:00.536391
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse
    
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    result = str(parse(StarredUnpackingTransformer(code)))
    assert result == expected
    
    

# Generated at 2022-06-12 04:08:04.799788
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source_code = 'print(*range(5), *range(6))'

    tree = ast.parse(source_code)
    tree = StarredUnpackingTransformer().visit(tree)

    assert astor.to_source(tree) == 'print(*(list(range(5)) + list(range(6))))'



# Generated at 2022-06-12 04:08:09.276054
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
x = [2, *range(10), 1]
"""
    expected = """
x = [2] + list(range(10)) + [1]
"""
    result = compile_restricted(code, 'single', 'exec')
    assert result.errors == []
    assert result.warnings == []
    assert result.result == expected



# Generated at 2022-06-12 04:08:53.811973
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    case = ast.parse("print(1, 2, 3, 4)").body[0]
    expected = ast.parse("print(*[1, 2, 3, 4])").body[0]
    result = StarredUnpackingTransformer().visit(case)
    assert ast.dump(result, 'test') == ast.dump(expected, 'test')


# Generated at 2022-06-12 04:08:58.905080
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from primerlib.genast import gen_ast
    node = gen_ast('print(*range(10), end="\n")')
    expected = gen_ast('print(*(list(range(10)) + list(["\\n"])))')
    out = StarredUnpackingTransformer().visit(node)
    assert astor.to_source(expected) == astor.to_source(out)

# Generated at 2022-06-12 04:09:03.847215
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        code = 'print(*range(5), *range(7))'
        expected_code = 'print(*(list(range(5)) + list(range(7))))'

    TestCase().test()


# Generated at 2022-06-12 04:09:08.449652
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(
        expression=True).__class__.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer(
        expression=True)._expression == True
    assert StarredUnpackingTransformer(
        expression=False)._expression == False
    assert StarredUnpackingTransformer(
        expression=True)._tree_changed == False
    assert StarredUnpackingTransformer(
        expression=False)._tree_changed == False


# Generated at 2022-06-12 04:09:11.416105
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert_compile(
        src='print(*range(1), *range(3))',
        to_py='print(*(list(range(1)) + list(range(3))))',
        transformer=StarredUnpackingTransformer)


# Generated at 2022-06-12 04:09:20.892961
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .code_generator import generate_code
    from .transformer import Transformer
    from .test_python_ast_transformer import create_tree, ParseError

    def do_test(src: str, expected: str) -> None:
        tree = create_tree(src)
        transformer = Transformer()
        transformer.register(StarredUnpackingTransformer())
        tree = transformer.visit(tree)
        
        actual = generate_code(tree).rstrip()
        assert actual == expected


# Generated at 2022-06-12 04:09:30.054277
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_python.compiler.type_wrappers.compilable_builtins as compilable_builtins
    import typed_python.compiler.type_wrappers.runtime_functions as runtime_functions
    import typed_python.compiler.typed_expression as typed_expression

    typeWrapper = typed_expression.TypedExpression(typed_expression.TypedPythonReference("A"), lambda x: x)

# Generated at 2022-06-12 04:09:38.057521
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # 'x' will not be starredUnpacking
    code_to_compile = 'x = [2, *range(10), 1]'
    compiled_code = compile(code_to_compile, filename='<inline code>', mode='exec')
    expected_compiled_code = compile(
        'x = [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]',
        filename='<inline code>',
        mode='exec')
    assert StarredUnpackingTransformer().visit(compiled_code) == expected_compiled_code
    # 'x = [2, ...range(10), 1]'
    code_to_compile = 'x = [2, ...range(10), 1]'

# Generated at 2022-06-12 04:09:46.336129
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_src
    from . import run_module
    from . import remove_literals

    src = "[2, *range(10), 1]"
    expected_result = "2 + list(range(10)) + 1"

    tree = compile_src(src, mode="exec")
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(tree)
    assert transformer.tree_changed

    result = run_module(transformed)
    assert eval(expected_result) == result

    src = "[a, *b, c]"
    expected_result = "a + b + [c]"

    tree = compile_src(src, mode="exec")
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(tree)
    assert transformer.tree_changed

    result = run_module

# Generated at 2022-06-12 04:09:49.252178
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    tree = ast.parse("[2, 3, 4]")
    transformer = StarredUnpackingTransformer()
    transformed_tree = transformer.visit(tree)

    assert ast.dump(transformed_tree) == ast.dump(ast.parse("[2, 3, 4]"))


# Generated at 2022-06-12 04:11:35.212063
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    t = StarredUnpackingTransformer(src)
    result = t.result()
    assert result == expected



# Generated at 2022-06-12 04:11:41.865042
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    import sys

    src_code = """print(1, *range(2), *range(3), 4)"""

    node = ast.parse(src_code)
    new_node = StarredUnpackingTransformer().visit(node)
    assert new_node is not None
    expected = """print(*(list([1]) + list(range(2)) + list(range(3)) + list([4])))"""

    assert astunparse.unparse(new_node).strip() == expected.strip()


# Generated at 2022-06-12 04:11:46.046114
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")
    t = StarredUnpackingTransformer()
    t.visit(tree)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 04:11:51.242003
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected_code = "[2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    star_unp = StarredUnpackingTransformer()
    star_unp.visit(tree)
    star_unp.tree_changed = False

    result_code = compile(tree, '<test>', 'eval', optimize=0)
    assert eval(result_code) == eval(expected_code)

