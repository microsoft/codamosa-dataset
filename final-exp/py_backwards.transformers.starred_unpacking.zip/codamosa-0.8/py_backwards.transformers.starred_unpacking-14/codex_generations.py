

# Generated at 2022-06-12 04:02:03.866659
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call = ast.parse(dedent("""
        print('a', *range(10))
    """)).body[0].value

    result = StarredUnpackingTransformer().visit(call)

    isinstance(result, ast.Call)

# Generated at 2022-06-12 04:02:06.016866
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert a is not None

# Generated at 2022-06-12 04:02:11.891111
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(n=1)],
        keywords=[])

    t = StarredUnpackingTransformer()
    res = t.visit(node)

    assert isinstance(res, ast.Call)
    assert isinstance(res.args[0], ast.Starred)
    assert isinstance(res.args[0].value, ast.List)


# Generated at 2022-06-12 04:02:22.905343
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    p = StarredUnpackingTransformer()
    l = ast.parse("[2, *range(10), 1]")
    p.visit(l)
    assert isinstance(l, ast.Module)
    assert isinstance(l.body[0], ast.Expr)
    assert isinstance(l.body[0].value, ast.BinOp)
    assert isinstance(l.body[0].value.left, ast.List)
    assert isinstance(l.body[0].value.left.elts[0], ast.Num)
    assert l.body[0].value.left.elts[0].n == 2
    assert isinstance(l.body[0].value.op, ast.Add)
    assert isinstance(l.body[0].value.right, ast.Call)

# Generated at 2022-06-12 04:02:26.295039
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Initial tree
    tree = ast.parse("print(*range(1), *range(3))")

    # Tested method
    StarredUnpackingTransformer().visit(tree)

    expected = ast.parse("print(*list(range(1)) + list(range(3)))")
    compare_node(tree, expected, 'Call')


# Generated at 2022-06-12 04:02:32.054914
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected_code = "[2] + list(range(10)) + [1]"
    tree = ast.parse(code)
    result_tree = StarredUnpackingTransformer().visit(tree)
    result_code = astunparse.unparse(result_tree).strip()
    assert result_code == expected_code


# Generated at 2022-06-12 04:02:37.517946
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Testing function for StarredUnpackingTransformer.visit_List."""
    from . import parse

    transform = StarredUnpackingTransformer()
    parse_tree = parse('[1, 2, *' + 'range(3), *range(3, 5)]')
    assert transform.visit(parse_tree) == parse(
        '([1, 2] + list(range(3)) + list(range(3, 5)))')



# Generated at 2022-06-12 04:02:47.478821
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node1 = ast.parse("""
    def foo():
        print(*range(1), *range(3))
    """, mode="exec")

    node1_expected = ast.parse("""
    def foo():
        print(*((list(range(1)) + list(range(3)))))
    """, mode="exec")

    assert ast.dump(StarredUnpackingTransformer().visit(node1)) == ast.dump(node1_expected)

    node2 = ast.parse("""
    def foo():
        print(*range(1))
    """, mode="exec")

    node2_expected = ast.parse("""
    def foo():
        print(*((list(range(1)))))
    """, mode="exec")

    assert ast.dump(StarredUnpackingTransformer().visit(node2)) == ast

# Generated at 2022-06-12 04:02:59.444596
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name(id='test'),
                    args=[ast.Num(n=1), ast.Name(id='*args'), ast.Num(n=3)],
                    keywords=[])
    transformer.visit(node)

# Generated at 2022-06-12 04:03:07.757240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_ = ast.parse(
        textwrap.dedent("""
        [2, *range(10), 1]
        print(*range(1), *range(3))
        [2, 34, 3]
        """)
    )
    expected_ast_ = ast.parse(
        textwrap.dedent("""
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        [2, 34, 3]
        """)
    )
    node_transformer = StarredUnpackingTransformer()
    result = node_transformer.visit(ast_)
    assert ast.dump(expected_ast_) == ast.dump(result)



# Generated at 2022-06-12 04:03:21.298463
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from node_transformer import NodeTransformer
    code = """
    for i in [1, *range(10), 1]:
        print(*range(i, i + 3))
    """
    ast_tree = ast.parse(code, mode='exec')
    exp_code = """
    for i in [1] + list(range(10)) + [1]:
        print(*(list(range(i, i + 3))))
    """
    expected_ast = ast.parse(exp_code, mode='exec')

    NodeTransformer(StarredUnpackingTransformer).visit(ast_tree)
    assert ast_tree == expected_ast

if __name__ == "__main__":
    test_StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:26.667873
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    printed = compile(code, '<dummy>', 'exec')
    transformed = StarredUnpackingTransformer().visit(printed)
    assert code_gen.to_source(transformed) == expected


# Generated at 2022-06-12 04:03:33.629673
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from _devbuild.gen.syntax_asdl import Expr, expr_e, test_expr_e
    from _devbuild.gen.syntax_asdl import test_expr__List, test_expr__Starred
    from _devbuild.gen.runtime_asdl import value_t, value_e, lvalue_e
    from _devbuild.gen.runtime_asdl import lvalue__Indexed, lvalue__Keyed
    from _devbuild.gen.runtime_asdl import lvalue__ObjIndex, lvalue__ObjAttr
    from _devbuild.gen.runtime_asdl import value__Str, value__Int, value__Obj
    from _devbuild.gen.runtime_asdl import value__List, value__MaybeStrArray
    from frontend import consts
    
    from core.pyerror import log
   

# Generated at 2022-06-12 04:03:44.727781
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # visit_Call(self, node: ast.Call) -> ast.Call:
    s = '''
    print(1, 2, 3, 4)
    '''
    n = ast_parse(s)
    assert isinstance(n, ast.Module)
    n = n.body[0]
    assert isinstance(n, ast.Expr)
    n = n.value
    assert isinstance(n, ast.Call)

    n = n.args
    assert len(n) == 4
    assert isinstance(n[0], ast.Num)
    assert isinstance(n[1], ast.Num)
    assert isinstance(n[2], ast.Num)
    assert isinstance(n[3], ast.Num)

    assert n[0].n == 1
    assert n[1].n == 2
   

# Generated at 2022-06-12 04:03:54.805483
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    c = StarredUnpackingTransformer()
    call = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Name(id='+'), ast.Call(func=ast.Name(id='range'), args=[ast.Num(1)], keywords=[]), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(2)], keywords=[]))],
        keywords=[], )
    new_call = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(1)], keywords=[])], keywords=[]))],
        keywords=[], )
   

# Generated at 2022-06-12 04:04:01.781994
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # 1. Arrange
    node = ast.List(
        elts=[
            ast.Starred(
                value=ast.Name(id='replace', ctx=ast.Load()),
                ctx=ast.Load()),
            ast.Starred(
                value=ast.Name(id='extend', ctx=ast.Load()),
                ctx=ast.Load())
        ],
        ctx=ast.Load()
    )

# Generated at 2022-06-12 04:04:11.529682
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import transform, create_ast

    # Normal call with no starred in arguments
    assert transform(StarredUnpackingTransformer, 'print(1)') == 'print(1)\n'

    # Simple call with starred in args
    assert transform(StarredUnpackingTransformer, 'print(*range(10), *range(2))') == \
           'print(*(list(range(10)) + list(range(2))))\n'

    # Call with starred args and keywords
    assert transform(StarredUnpackingTransformer, 'print(*range(10), sep="|", *range(2), sep="&")') == \
           'print(*(list(range(10)) + list(range(2))), sep="&")\n'

    # Call with starred args, keywords and kwargs

# Generated at 2022-06-12 04:04:20.697147
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    from astunparse import unparse
    from .ast_utils import get_ast
    from .base import get_targets
    from .function_arguments import PositionalOnlyArgumentsTransformer
    from .star_args_to_star_kwargs import StarArgsToStarKwargsTransformer
    from .function_args_general import FunctionArgsGeneralTransformer
    from .function_args_typing import FunctionArgsTypingTransformer
    from .function_args_annotations import FunctionArgsAnnotationsTransformer
    from .function_args_defaults import FunctionArgsDefaultsTransformer
    from .function_args_general import FunctionArgsGeneralTransformer
    from .function_args_varargs import FunctionArgsVarArgsTransformer
    from .function_args_varkwargs import FunctionArgsVarKwArgsTransformer
   

# Generated at 2022-06-12 04:04:30.030742
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse(dedent("""\
        [1, *range(10), 2]
    """))
    expected = ast.parse(dedent("""\
        [1] + list(range(10)) + [2]
    """))
    transformer = StarredUnpackingTransformer()
    assert transformer.transform_single(tree) == expected
    assert transformer.transform_single(expected) == expected

    tree = ast.parse(dedent("""\
        print(*range(1), *range(3))
    """))
    expected = ast.parse(dedent("""\
        print(*(list(range(1)) + list(range(3))))
    """))
 

# Generated at 2022-06-12 04:04:36.739120
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """
[2, *range(10), 1]
print(*range(1), *range(3))
    """
    expected = """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """
    ast_tree = ast.parse(code)
    res = StarredUnpackingTransformer().visit(ast_tree)
    assert fix_code(astor.to_source(res)) == fix_code(expected)

# Generated at 2022-06-12 04:04:41.871412
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t is not None


# Generated at 2022-06-12 04:04:48.044566
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_cases_errors = [
        ('print(*range(1), *range(3), *range(4))',
         'print(*(list(range(1)) + list(range(3)) + list(range(4))))'),
        ('print(*(range(1)), *range(3), *range(4))',
         'print(*(list(range(1)) + list(range(3)) + list(range(4))))'),
    ]
    for test_case, expected_result in test_cases_errors:
        test_tree = ast.parse(test_case)
        transformer = StarredUnpackingTransformer()
        transformer.visit(test_tree)
        assert ast.dump(test_tree) == ast.dump(ast.parse(expected_result)), test_case


# Generated at 2022-06-12 04:04:54.499227
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import libcst as cst
    from libcst.metadata import PositionProvider
    transformer = StarredUnpackingTransformer()
    call = cst.parse_statement("print(1, *list_of_args)")
    res = transformer.visit(call)
    expected = cst.parse_statement("print(*(list(range(1)) + list(range(3))))")
    assert(res == expected)



# Generated at 2022-06-12 04:05:04.359376
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = ast.parse('print(*range(1))')
    b = ast.parse('print(list(range(1)))')
    StarredUnpackingTransformer().visit(a)
    assert a.body[0].value == b.body[0].value

if __name__ == '__main__':
    # Unit test for method visit_List of class StarredUnpackingTransformer
    def test_StarredUnpackingTransformer_visit_List():
        a = ast.parse('[1, *range(10), 3]')
        b = ast.parse('[1] + list(range(10)) + [3]')
        StarredUnpackingTransformer().visit(a)
        assert a.body[0].value == b.body[0].value

    test_StarredUnpackingTransformer_visit_List

# Generated at 2022-06-12 04:05:13.152796
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().process('[2, *range(10), 1]') == '[2] + list(range(10)) + [1]'
    assert StarredUnpackingTransformer().process('print(*range(1), *range(3))') == 'print(*(list(range(1)) + list(range(3))))'
    assert StarredUnpackingTransformer().process('print(*[1, 2, 3], *[4, 5, 6], *[7, 8, 9])') == 'print(*(list([1, 2, 3]) + list([4, 5, 6]) + list([7, 8, 9])))'


# Generated at 2022-06-12 04:05:17.008632
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    source = 'print(*range(1), *range(3))'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)
    expected = """print(*(list(range(1)) + list(range(3))))"""
    assert result == expected


# Generated at 2022-06-12 04:05:24.557205
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    assert str(StarredUnpackingTransformer().visit(node)) == '([2] + list(range(10)) + [1])'

    node = ast.parse('[2, *range(10)]')
    assert str(StarredUnpackingTransformer().visit(node)) == '([2] + list(range(10)))'

    node = ast.parse('[*range(10), 1]')
    assert str(StarredUnpackingTransformer().visit(node)) == '(list(range(10)) + [1])'


# Generated at 2022-06-12 04:05:34.631960
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import asttokens
    from io import StringIO
    from ...astcompat import ast_transformer, get_node
    code = "[2, *range(10), 1]"
    atok = asttokens.ASTTokens(code, parse=True, transform=ast_transformer)
    tree = ast.parse(code)
    assert isinstance(tree, ast.Module)
    assert 1 == len(tree.body)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.List)
    lst = tree.body[0].value
    assert [2, *range(10), 1] == lst.elts
    
    lst_unpacked = StarredUnpackingTransformer().visit(lst)

# Generated at 2022-06-12 04:05:42.949693
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast.ast3 import parse, dump
    from . import run_transformer_for_test_file

    source = '''
    print(1, *range(3), 4, 5, *range(7), 8)
    '''
    node = parse(source)
    transformer = StarredUnpackingTransformer()
    new_node = run_transformer_for_test_file(node, transformer)
    expected = '''
    print(*(list((1,)) + list(range(3)) + list((4, 5)) + list(range(7)) + list((8,))))
    '''
    assert dump(new_node) == expected


# Generated at 2022-06-12 04:05:43.908428
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-12 04:05:56.958530
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astor.source_repr import SourceRepr
    from .test_helpers import assert_source

    source = SourceRepr.of([2, *range(10), 1])
    expected = SourceRepr.of(2 + list(range(10)) + [1])

    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(source.node)

    assert_source(expected, transformed)


# Generated at 2022-06-12 04:05:58.060364
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x is not None

# Generated at 2022-06-12 04:06:08.778547
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compiler import compile
    from .base import BaseNodeTransformer
    from .base import NodeTransformerTestCase

    # Refer to compiler package for implementation of compile
    # https://github.com/python/cpython/blob/master/Lib/typed_ast/compiler
    code = '''[1, *range(10), 1]'''

    code2 = '''[*range(10), 1]'''

    code3 = '''[1, *range(10)]'''

    code4 = '''[*range(10)]'''

    code5 = '''[1, 2, *range(10), 3, 4]'''

    code6 = '''[*range(10)]'''

    expected = '''[1] + list(range(10)) + [1]'''


# Generated at 2022-06-12 04:06:10.515162
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

    assert transformer is not None

# Generated at 2022-06-12 04:06:12.802562
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .visit_Call import visit_Call
    visit_Call(StarredUnpackingTransformer, ast.parse("print(1, *[1])"))


# Generated at 2022-06-12 04:06:15.690639
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x =StarredUnpackingTransformer([ast.Num(n=1), ast.Num(n=2)])
    assert isinstance(x, StarredUnpackingTransformer)


# Generated at 2022-06-12 04:06:26.820676
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ..lib import as_code
    from ..vendor import parse

    class_ = StarredUnpackingTransformer

    def check(src: str, expected: str):
        tree = parse(src)
        class_().visit(tree)
        assert str(tree).strip() == expected

    check('[2, *range(10), 1]', '[2] + list(range(10)) + [1]')
    check('[2, *range(10)]', '[2] + list(range(10))')
    check('[*range(10), 1]', 'list(range(10)) + [1]')
    check('[*range(10)]', 'list(range(10))')

# Generated at 2022-06-12 04:06:32.623317
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*[1, 2], 3, *[4, 5], 6)
    """
    expected = """
print(*(list([1, 2]) + list([3]) + list([4, 5]) + list([6])))
    """
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    result = astor.to_source(tree)
    assert result == expected



# Generated at 2022-06-12 04:06:39.283770
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_variable = ast.parse("print(*range(1), *range(3))")
    tree_transformer = StarredUnpackingTransformer()
    tree_transformer.transform(test_variable)
    assert isinstance(test_variable.body[0].value, ast.BinOp)
    assert test_variable.body[0].value.op == ast.Add()
    assert isinstance(test_variable.body[0].value.left, ast.Call)
    assert isinstance(test_variable.body[0].value.right, ast.Call)


# Generated at 2022-06-12 04:06:44.915596
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_utils import check_visitor

    code = '''\
[2, *range(10), 1]
[*range(10)]
'''

    expected_code = '''\
[2] + list(range(10)) + [1]
list(range(10))
'''

    tr = StarredUnpackingTransformer()

    check_visitor(code, expected_code, tr)



# Generated at 2022-06-12 04:07:05.345159
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1] -> [2] + list(range(10)) + [1]
    node = ast.parse('[2, *range(10), 1]').body[0]
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0]
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:07:10.642491
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = ast.parse('print(1, *[1, 2], 3, *[4, 5])')
    expected = ast.parse('print(1, *list([1, 2]) + list([4, 5]) + [3])')
    output = StarredUnpackingTransformer().visit(input)
    assert ast.dump(output) == ast.dump(expected)



# Generated at 2022-06-12 04:07:16.295786
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('''\
[2, *range(10), 1]
print(*range(1), *range(3))''')
    StarredUnpackingTransformer().visit(tree)
    expected = '''\
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))'''
    assert expected == compile(tree, '', 'exec')

# Generated at 2022-06-12 04:07:25.131819
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer('[1, 2, 3, *[4, 5, 6]]')._tree == ast.parse('[1, 2, 3] + [4, 5, 6]')
    assert StarredUnpackingTransformer('[1, 2, *[3, 4, 5, *[6, 7, 8]]]')._tree == ast.parse('[1, 2] + [3, 4, 5] + [6, 7, 8]')
    assert StarredUnpackingTransformer('[1, 2, 3, 4, 5, 6]')._tree == ast.parse('[1, 2, 3, 4, 5, 6]')



# Generated at 2022-06-12 04:07:27.439623
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:07:32.396240
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transform = StarredUnpackingTransformer()
    tree = ast.parse("""
    [2, *range(10), 1]
    print(*range(1), *range(3))""")
    transform.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("""
    ([2] + list(range(10)) + [1])
    print(*(list(range(1)) + list(range(3))))"""))

# Generated at 2022-06-12 04:07:40.580503
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .common import UnitCase
    from .common import transform
    from .common import unit_test_ast

    class Case(UnitCase):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            if self.expected is not None:
                self.expected = unit_test_ast(self.expected)


# Generated at 2022-06-12 04:07:46.522633
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for visit_Call method of class StarredUnpackingTransformer."""
    source = """
tree = ast.parse(
    """
    'print(*range(1), *range(3))'
"""
)
"""


# Generated at 2022-06-12 04:07:54.770905
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    method = StarredUnpackingTransformer._to_sum_of_lists

    def test(args: List[ast.expr], expected: ast.AST) -> None:
        result = method(args)
        assert result, 'Result should not be empty.'

        # Check type of result.
        assert (isinstance(result, ast.AST)
                and not isinstance(result, list)), \
                'Result should be instance of AST, but not list.'

        # Check source of result
        assert ast.dump(result) == ast.dump(expected), \
                'Source of result: "{}" should be equal to expected: "{}".' \
                .format(ast.dump(result), ast.dump(expected))

    test([], ast.List(elts=[]))


# Generated at 2022-06-12 04:08:03.162363
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast import parse
    from . import _BaseNodeTestCase
    import copy
    class Test(
            _BaseNodeTestCase,
            unittest.TestCase,
    ):
        transformer = StarredUnpackingTransformer

        def test_00(self):
            node = parse('["a", *b, "c"]')
            expected = parse('["a"] + list(b) + ["c"]')
            self._test_one(node, expected)

        def test_01(self):
            node = parse('[*b]')
            expected = parse('list(b)')
            self._test_one(node, expected)

        def test_02(self):
            node = parse('[*b, *c]')
            expected = parse('list(b) + list(c)')
            self._test_one

# Generated at 2022-06-12 04:08:47.738520
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert not t._has_starred([])
    assert t._has_starred([ast.List()])

    splitted = t._split_by_starred([ast.Num(n=1), ast.Num(n=2)])
    assert splitted == [[ast.Num(n=1), ast.Num(n=2)]]

    splitted = t._split_by_starred([ast.Num(n=1), ast.Starred(value=ast.Num(n=2)), ast.Num(n=3)])
    assert splitted == [[ast.Num(n=1)], ast.Starred(value=ast.Num(n=2)), [ast.Num(n=3)]]


# Generated at 2022-06-12 04:08:57.342602
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('''[a, *b, c]''', mode='eval')
    expected = '''[a] + list(b) + [c]'''
    actual = to_source(SimpleFunctionCallSimplifier().visit(node))
    assert actual == expected

    node = ast.parse('''[a, *b, *c, d]''', mode='eval')
    expected = '''[a] + list(b) + list(c) + [d]'''
    actual = to_source(SimpleFunctionCallSimplifier().visit(node))
    assert actual == expected

    node = ast.parse('''[*a, *b, c]''', mode='eval')
    expected = '''[list(a) + list(b)] + [c]'''
    actual = to

# Generated at 2022-06-12 04:09:01.958940
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code_str = '[2, *range(10), 1]'
    node = ast.parse(code_str)

    t = StarredUnpackingTransformer()
    node_conv = t.visit(node)

    assert str(node_conv) == 'list([2]) + list(range(10)) + list([1])'


# Generated at 2022-06-12 04:09:08.401278
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tr = StarredUnpackingTransformer()
    node = ast.List(elts=[ast.Num(n=2),
                          ast.Starred(ast.Call(ast.Name(id='range'),
                                               [ast.Num(n=10)], [])),
                          ast.Num(n=1)])
    assert tr.visit(node) == ast.BinOp(ast.List(elts=[ast.Name(id='list')],
                                                ctx=ast.Load()),
                                       ast.Call(ast.Name(id='range'),
                                                [ast.Num(n=10)], []),
                                       ast.Add())


# Generated at 2022-06-12 04:09:17.587268
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .str_node import parse
    from .str_node import get_ast
    from .str_node import dump_ast
    from .str_node import dump_source
    from .str_node import compile_ast
    from .str_node import compile_source
    from .str_node import exec_compiled
    from .str_node import to_str
    from .str_node import bytecode_to_str
    from .str_node import bytecode_to_ast
    from .str_node import bytecode_to_source
    from .str_node import exec_bytecode

    foo = """
    def foo():
        print(*range(10), *range(10))
    """
    foo_bytecode_bytes = compile(foo, "<string>", "exec")
    foo_bytecode_bytes_str = to_

# Generated at 2022-06-12 04:09:26.628384
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def check(code_in, code_out):
        tree_in = ast.parse(code_in)
        tree_out = ast.parse(code_out)
        transformer = StarredUnpackingTransformer()
        transformer.visit(tree_in)
        assert transformer.tree_changed == True
        assert compare_ast(tree_in, tree_out) == True
    code_in1 = """
my_list = [*range(1), *range(3)]
print(*range(1), *range(3))
"""
    code_out1 = """
my_list = list(range(1)) + list(range(3))
print(*(list(range(1)) + list(range(3))))
"""
    check(code_in1, code_out1)


# Generated at 2022-06-12 04:09:28.460130
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  transformer = StarredUnpackingTransformer()
  assert isinstance(transformer, StarredUnpackingTransformer)


# Generated at 2022-06-12 04:09:34.050668
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Input
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)

    expected_code = "[2] + list(range(10)) + [1]"
    expected_tree = ast.parse(expected_code)

    # Run StarredUnpackingTransformer
    visitor = StarredUnpackingTransformer()
    visitor.visit(tree)

    # Check compilation result
    assert ast.dump(expected_tree) == ast.dump(tree)


# Generated at 2022-06-12 04:09:39.357833
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected_ast = ast.Call(func=ast.Name(id="print"), args=[ast.Starred(value=ast.List(elts=[ast.List(elts=[ast.Num(n=1)]), ast.List(elts=[ast.Num(n=2), ast.Num(n=3)])]))], keywords=[])
    compiled_ast = StarredUnpackingTransformer().visit(ast.parse("print(1, *(2, 3))").body[0])
    assert(ast.dump(expected_ast) == ast.dump(compiled_ast))



# Generated at 2022-06-12 04:09:46.913273
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast
    from .unparser import Unparser
    from .fix_missing_locations import fix_missing_locations
    
    input = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(input)
    assert Unparser(input) == "[2] + list(range(10)) + [1]"

    input = ast.parse("[*range(3), *range(3), *range(3)]")
    StarredUnpackingTransformer().visit(input)
    assert Unparser(input) == "list(range(3)) + list(range(3)) + list(range(3))"



# Generated at 2022-06-12 04:11:19.433570
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(10), *range(5), sep="|")'
    expected = 'print(*(list(range(10)) + list(range(5))), sep="|")'
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert expected == astor.to_source(node).strip()


# Generated at 2022-06-12 04:11:27.683047
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .util import source_to_node
    from .node_util import dump_node
    source = 'foo(2, *range(10), 1)'
    expected = 'foo(2) + list(range(10)) + (1,)'
    got = dump_node(StarredUnpackingTransformer().visit(source_to_node(source)), annotate_fields=False)
    assert expected == got

    source = 'bar(*range(1), 2, *range(3))'
    expected = 'bar(*(list(range(1)) + (2,) + list(range(3))))'
    got = dump_node(StarredUnpackingTransformer().visit(source_to_node(source)), annotate_fields=False)
    assert expected == got

    source = 'bar(*range(1), *range(3))'


# Generated at 2022-06-12 04:11:29.694550
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer(None)


if __name__ == '__main__':
    import doctest
    doctest.testmod(globs=globals())

# Generated at 2022-06-12 04:11:39.255547
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typepy import TypeConversionError
    from textwrap import dedent
    from minivm.compiler import Compiler
    from minivm.context import Context

    class TestCompiler(Compiler):
        def _create_transformer(self) -> StarredUnpackingTransformer:
            return StarredUnpackingTransformer(self)

    code = dedent('''\
        [1, 2, 3, 4, 5]
        [1, 2, *range(3), 4, 5]
        [1, 2, *range(3), 4, 5]
        [1, 2, *range(3), 4, 5]
        f(*range(10))
        f(*range(10))
        f(*range(10))
        f(*range(10))
        ''')

# Generated at 2022-06-12 04:11:48.289196
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    t = StarredUnpackingTransformer()

    # Test 1
    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)],
                                                                   keywords=[])), ast.Num(n=1)], ctx=ast.Load())