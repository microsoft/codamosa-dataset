

# Generated at 2022-06-12 04:02:01.351676
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('''[2, *range(10), 4]''')
    expr = ast.Expression(node)
    tr = StarredUnpackingTransformer()
    x = tr.visit(expr)
    assert ast.dump(x) == 'Expression(BinOp(List([Num(2)]), Add(), Call(Name(\'list\', Load()), [Attribute(Name(\'range\', Load()), \'range\', Load())], [keyword(arg=\'stop\', value=Num(10))]), Add(), List([Num(4)])))'



# Generated at 2022-06-12 04:02:12.055568
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_1= ast.parse('''[2, *range(10), 1]''').body[0]
    node_2= ast.parse('''[1]''').body[0]
    node_3= ast.parse('''[1, *range(10), 1]''').body[0]
    node_4= ast.parse('''[1, 1]''').body[0]
    node_5= ast.parse('''[1, 2] + [3, 4]''').body[0]
    node_6= ast.parse('''[1, 2] + [3, 4] + [5]''').body[0]

    result_1= StarredUnpackingTransformer().visit(node_1)

# Generated at 2022-06-12 04:02:16.940798
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''\
[2, *range(0, 10), 1]
'''
    expected = '''\
[2] + list(range(0, 10)) + [1]
'''
    transformed = StarredUnpackingTransformer().visit(ast.parse(source))
    assert expected == transformed



# Generated at 2022-06-12 04:02:26.409609
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected_result = ast.Call(
        func=ast.Name(id='show'),
        args=[ast.Starred(
            value=ast.BinOp(
                left=ast.List(elts=[]),
                right=ast.BinOp(
                    left=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='arg1')], keywords=[]),
                    right=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='arg2')], keywords=[]),
                    op=ast.Add()),
                op=ast.Add()))],
        keywords=[])


# Generated at 2022-06-12 04:02:31.075502
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = "[2, *range(10)]"
    mod = ast.parse(src)

    t = StarredUnpackingTransformer()
    t.visit(mod)
    result = ast.dump(mod)

    expected = "[2] + list(range(10))"

    assert result == expected



# Generated at 2022-06-12 04:02:31.722699
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-12 04:02:39.997203
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astor import to_source

    xs = [ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Num(1), ast.List(elts=[ast.Num(2), ast.Num(3)]), ast.Starred(value=ast.Name(id='map'), ctx=ast.Load())]
    source = """
    [2, *range(10), 1]
    """

    expected = """
    [2] + list(range(10)) + [1]
    """

    a = ast.parse(source)
    StarredUnpackingTransformer().visit(a)
    assert to_source(a) == expected.strip()

    a = ast.parse(source)
    a.body[0].value.elts = xs
    StarredUnpacking

# Generated at 2022-06-12 04:02:48.579772
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node2 = ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[]), ast.Num(n=1)])

    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Num(n=1)])

    t = StarredUnpackingTransformer()
    t.visit(node)

    assert t._tree_changed == True
    assert node2 == node


# Generated at 2022-06-12 04:03:00.437131
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:03:07.312129
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test the visit_Call method of the StarredUnpackingTransformer class """

    source = """print(*range(1), *range(3))"""
    expected = """print(*(list(range(1)) + list(range(3))))"""

    transformer = StarredUnpackingTransformer(skip_transpiled=False)
    transformed_tree = transformer.visit(ast.parse(source))
    actual = astor.to_source(transformed_tree).strip()

    assert actual == expected, f'Expected {expected!r}, but got {actual!r}'


# Generated at 2022-06-12 04:03:22.579079
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_ast = ast.parse('''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    ''').body
    assert len(test_ast) == 2
    assert isinstance(test_ast[0], ast.Expr)
    assert isinstance(test_ast[1], ast.Expr)
    assert isinstance(test_ast[0].value, ast.List)
    assert isinstance(test_ast[1].value, ast.Call)
    test_ast = StarredUnpackingTransformer().visit(test_ast)
    assert len(test_ast) == 2
    assert isinstance(test_ast[0], ast.Expr)
    assert isinstance(test_ast[1], ast.Expr)

# Generated at 2022-06-12 04:03:30.253524
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ..parser import Parser, ast_to_src
    from .base import NodeTransformerTestCase

    parser = Parser()
    compiled = StarredUnpackingTransformer()
    tree = parser.parse("""
    a = [2, *range(10), 1]
    print(*range(1), *range(3))
    """)
    tree = compiled.visit(tree)
    assert ast_to_src(tree) == """
    a = [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """.strip()

# Generated at 2022-06-12 04:03:40.027031
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    p = ast.parse('print(*range(2), 1, *range(5))')
    tree = StarredUnpackingTransformer().visit(p)
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'print'
    assert isinstance(node.args[0], ast.Starred)
    assert isinstance(node.args[0].value, ast.BinOp)
    assert isinstance(node.args[0].value.left, ast.Call)
    assert isinstance(node.args[0].value.right, ast.List)
    assert isinstance(node.args[0].value.op, ast.Add)

# Generated at 2022-06-12 04:03:50.498810
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    import ast as pyast, inspect
    StarredUnpackingTransformer.target = (3, 0)
    NodeTransformer = pyast.NodeTransformer
    
    # Test 0: node.args = [] # type: List[ast.expr]
    # Program to test
    program = 'print()'
    
    # Expected output (AST area)
    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[],
        keywords=[])
    
    # Unit test
    # Create an AST from source code
    root_node = pyast.parse(program, mode='exec')
    # Create a StarredUnpackingTransformer instance
    transformer = StarredUnpackingTransformer()
    # Collect information about self
    transformer

# Generated at 2022-06-12 04:03:54.105439
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    assert (
        str(StarredUnpackingTransformer(source).tree) == expected
    )



# Generated at 2022-06-12 04:04:01.394391
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from astor.code_gen import to_source  # type: ignore
    import ast

    def test(code: str, expected: str) -> None:
        tree = ast.parse(code)  # type: ignore
        StarredUnpackingTransformer().visit(tree)
        assert to_source(tree).rstrip() == expected.rstrip()

    test("print(2, *range(2))", "print(2, *([2] + list(range(2))))")
    test("[1, *range(2), 4]", "[1] + list(range(2)) + [4]")
    test("[1, 2, *range(2), 4]", "[1, 2] + list(range(2)) + [4]")

# Generated at 2022-06-12 04:04:09.991613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    actual = compile(
            'foo(x, *[1, 2, 3], *[4, 5, 6], y, *[7, 8, 9])',
            '<test>', 'single', flags=ast.PyCF_ONLY_AST)
    expect = compile(
            'foo(*(list(x) + list([1, 2, 3]) + \
            list([4, 5, 6]) + list(y) + \
            list([7, 8, 9])))',
            '<test>', 'single', flags=ast.PyCF_ONLY_AST)

    actual = StarredUnpackingTransformer().visit(actual)
    compare_ast(actual, expect)

# Generated at 2022-06-12 04:04:15.027948
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    from .syntax_fixture import SyntaxFixture
    cls = StarredUnpackingTransformer

    code = '''
        [2, *range(10), 1]
    '''
    assert SyntaxFixture.test(code, cls) == [
        "[2] + list(range(10)) + [1]",
    ]



# Generated at 2022-06-12 04:04:20.554927
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
        [2, *range(10), 1]
        """

    tree = ast.parse(code)
    transformed, info = StarredUnpackingTransformer().visit(tree)
    compiled = compile(transformed, '<transformed_code>', mode='exec')
    result = {}
    exec(compiled, result)
    assert result['_2'] == [2] + list(range(10)) + [1]



# Generated at 2022-06-12 04:04:31.442861
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer.run_visitor(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)], ctx=Load()))))])"
    # [2, *range(10), 1]
    # [2] + list(range(10)) + [1]



# Generated at 2022-06-12 04:04:38.185171
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 4)


# Generated at 2022-06-12 04:04:41.549009
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.run_visitor(
        ast.parse('[2, *range(10), 1]', mode='eval'), filename='') == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:04:48.550675
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import transform_module
    from . import dump_tree
    from .ast_utils import FormatVisitor
    from .typed_ast import ast3 as ast

    source_code = '''
    f(*x)
    f(*x, *y)
    f(1, *x, 2)
    '''
    tree = ast.parse(source_code)
    dump_tree(tree)
    result = FormatVisitor()(transform_module(source_code, StarredUnpackingTransformer))
    dump_tree(ast.parse(result))
    assert result == '''
    f(*list(x))
    f(*(list(x) + list(y)))
    f(*(list(x) + [2]))
    '''



# Generated at 2022-06-12 04:04:51.867627
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
  from .test_utils import assertType
  from typed_ast import ast3 as ast
  tr = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:04:59.021900
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # https://docs.python.org/3.6/reference/expressions.html#calls
    x = [2, *range(10), 1]
    assert repr(x) == '[2, *range(10), 1]'

    module = ast.parse('[2, *range(10), 1]')
    trans = StarredUnpackingTransformer()
    trans.visit(module)

# Generated at 2022-06-12 04:04:59.875592
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-12 04:05:11.400846
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import textwrap
    #from typed_ast import ast3 as ast

    code = textwrap.dedent('''
    m = [2, *range(10), 1]
    n = ["Hello", *[1, 2], "World"]
    print('m = %s' % m)
    print(*m)
    print(*m, *n, *n, 'asdf', 'world', *[10, *range(5)], *range(5))
    ''')


# Generated at 2022-06-12 04:05:17.611343
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._split_by_starred(
        [ast.Num(n=1), ast.Starred(value=ast.Name(id='x')), ast.Num(n=2)]
    ) == [[ast.Num(n=1)], ast.Starred(value=ast.Name(id='x')), [ast.Num(n=2)]]


# Generated at 2022-06-12 04:05:27.770544
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astmonkey import transformers
    code = dedent("""\
        [2, *range(10), 1]
        [2]
        [2, *range(10, 1), 1]
        [2, *range(10), 1, *range(10)]
        [2, *range(10), 1, *[3, 4], 5]
        [2, *[3, 4], 5]
        [2, [3, 4], 5]
        """)
    tree = ast.parse(code)
    t = StarredUnpackingTransformer()
    t.visit(tree)

# Generated at 2022-06-12 04:05:32.297767
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tr = StarredUnpackingTransformer()
    assert ast.dump(tr.visit(ast.parse('''
    [2, *range(10), 1]
    '''))) == ast.dump(ast.parse('''
    [2] + list(range(10)) + [1]
    '''))


# Generated at 2022-06-12 04:05:44.704554
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert str(tree) == "[2] + list(range(10)) + [1]"

    code = "[2, *range(10), 1, *range(3)]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert str(tree) == "[2] + list(range(10)) + [1] + list(range(3))"


# Generated at 2022-06-12 04:05:51.088483
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # test1
    tr = StarredUnpackingTransformer().visit(ast.parse("""print(*range(1), *range(3))""").body[0])
    assert isinstance(tr, ast.Call)
    assert isinstance(tr.args[0], ast.Starred)
    assert isinstance(tr.args[0].value, ast.BinOp)
    assert isinstance(tr.args[0].value.op, ast.Add)
    assert isinstance(tr.args[0].value.left, ast.Call)
    assert isinstance(tr.args[0].value.right, ast.Call)
    assert tr.func.id == 'print'

    # test2
    tr = StarredUnpackingTransformer().visit(ast.parse("""print(*range(1))""").body[0])
   

# Generated at 2022-06-12 04:05:59.661500
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer(inplace=True).visit(tree)
    assert str(tree) == "[2] + list(range(10)) + [1]"

    tree = ast.parse("[2, 3]")
    StarredUnpackingTransformer(inplace=True).visit(tree)
    assert str(tree) == "[2, 3]"

    tree = ast.parse("[2, *range(10), *range(10), *range(10), 1]")
    StarredUnpackingTransformer(inplace=True).visit(tree)
    assert str(tree) == "[2] + list(range(10)) + list(range(10)) + list(range(10)) + [1]"


# Generated at 2022-06-12 04:06:10.563240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import make_call, make_expression_factory
    from .test_utils import make_list, make_starred

    make_expression = make_expression_factory()

    # Empty list without change
    make_expression('[]')

    # List without starred
    make_expression('[a]', make_list([]))

    make_expression('[1, 2, 3]', make_list([1, 2, 3]))

    # List with starred
    make_expression('[1, 2, *range(3), 4]', make_list([
        1,
        2,
        make_starred(make_call('range', make_list([3]))),
        4,
    ]))

    # List with star

# Generated at 2022-06-12 04:06:16.836827
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Expect correct compilation of [2, *range(10), 1] -> [2] + list(range(10)) + [1]"""
    input_ast = ast.parse("[2, *range(10), 1]")
    expected_ast = ast.parse("[2] + list(range(10)) + [1]")
    actual_ast = StarredUnpackingTransformer().visit(input_ast)

    assert ast.dump(expected_ast) == ast.dump(actual_ast)


# Generated at 2022-06-12 04:06:20.879242
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))')
    result = StarredUnpackingTransformer().visit(node)
    assert_equal('print(*([1] + list(range(3))))', result)


# Generated at 2022-06-12 04:06:21.860504
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:06:28.821572
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as std_ast 
    from typed_ast import ast3 as ast

    code = """
    print(*range(1), *range(3))
    """

    expected = """
    print(*(list(range(1)) + list(range(3))))
    """

    _expected = std_ast.parse(expected)
    _expected = _expected.body[0]
    
    visitor = StarredUnpackingTransformer()
    _code = std_ast.parse(code)
    _code = visitor.visit(_code)
    print(ast.dump(_code))
    assert ast.dump(_code) == ast.dump(_expected)


# Generated at 2022-06-12 04:06:38.019594
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import logging
    import sys

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

    transformer = StarredUnpackingTransformer()

    # test 1

    transformer._tree_changed = False

    node1 = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()),
        ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())],
        keywords=[])

    node1 = transformer.visit_Call(node1)
    print(node1)

    assert transformer._tree_changed == True

# Generated at 2022-06-12 04:06:47.266268
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Unit test for method visit_Call of class StarredUnpackingTransformer
    def _exec_succ(before, expected):
        # This function tests a case of success
        from _ast import parse
        from typing import Dict

        node = parse(before)
        # print(ast.dump(node))
        # print()

        t = StarredUnpackingTransformer()
        t.visit(node)
        # print(ast.dump(node))
        # print()
        # print(expected)
        # print()
        # print()

        pre_node = parse(before)
        # print(ast.dump(pre_node))
        # print()

        pre_code = compile(pre_node, '<unknown>', 'exec', optimize=0)
        pre_ns = {}  # type: Dict[str,

# Generated at 2022-06-12 04:07:00.871692
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
            func=ast.Name(id="print", ctx=ast.Load()),
            args=[ast.Num(n=0), ast.Starred(value=ast.Name(id="some_list", ctx=ast.Load()), ctx=ast.Load())],
            keywords=[]
            )
    node = StarredUnpackingTransformer().visit(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.args[0], ast.Starred)
    assert isinstance(node.args[0].value, ast.BinOp)
    assert isinstance(node.args[0].value.left, ast.List)
    assert isinstance(node.args[0].value.right, ast.Call)


# Generated at 2022-06-12 04:07:10.827719
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    Test StarredUnpackingTransformer for AST Call nodes
    """

    import_node = ast.Import([ast.alias(name='typed_ast',asname='ast')])
    import_from_node = ast.ImportFrom(module='typed_ast', names=[ast.alias(name='ast3')], level=0)

# Generated at 2022-06-12 04:07:19.756616
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    make = lambda lines: ast.parse(
        textwrap.dedent(lines), '<test>', 'exec').body[0]


# Generated at 2022-06-12 04:07:24.277281
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]", mode='eval')
    expected = ast.parse("[2] + list(range(10)) + [1]", mode='eval')
    assert StarredUnpackingTransformer().visit(node) == expected

# Generated at 2022-06-12 04:07:31.425022
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = 'l = [1, *range(10), 1]'
    expected_code = 'l = [1] + list(range(10)) + [1]'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert expected_code == astor.to_source(tree)
    assert(ast.dump(ast.parse(code)) != ast.dump(tree))

    code = 'def foo(a, b):\n    return a + b'
    expected_code = 'def foo(a, b):\n    return a + b'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-12 04:07:40.223263
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from asttokens import ASTTokens

    src = """
a = [2, *range(10), 1]
a = [2, *range(10), 1, *(1, 2, 3)]
a = [*range(10), 1]
a = [2, *range(10)]
"""
    expected_src = """
a = [2] + list(range(10)) + [1]
a = [2] + list(range(10)) + [1] + list((1, 2, 3))
a = list(range(10)) + [1]
a = [2] + list(range(10))
"""
    atok = ASTTokens(src, parse=True, _encoding='utf-8')
    root = atok.tree
    assert isinstance(root, ast.Module)

    transformer = StarredUnpacking

# Generated at 2022-06-12 04:07:47.508335
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_1 = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Name(id='range')),
        ast.Num(n=3),
    ])

    StarredUnpackingTransformer().visit(node_1)

    node_2 = ast.List(elts=[
        ast.Num(n=2),
        ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='range')], keywords=[]),
        ast.Num(n=3),
    ])

    StarredUnpackingTransformer().visit(node_2)


# Generated at 2022-06-12 04:07:55.606097
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    node = ast.List(elts = [
        ast.Constant(value = 2),
        ast.Starred(value = ast.Call(
            func = ast.Name(id = 'range'),
            args = [ast.Constant(value = 10)],
            keywords = [],
        )),
        ast.Constant(value = 1),
    ])

    result = transformer.visit(node)

# Generated at 2022-06-12 04:08:04.019359
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_enaml import StarredUnpackingTransformer

    node = ast.parse("[2, *range(1, 5), 4, *range(5, 10)]").body[0].value


# Generated at 2022-06-12 04:08:11.656871
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import get_node, apply_transformer

    # Given an AST node for
    node = get_node("""
    print(*range(1), *range(3))
    """)

    # When applying `StarredUnpackingTransformer` to `node`
    transformer = StarredUnpackingTransformer()
    new_node = apply_transformer(transformer, node)

    # Then the original AST node is replaced with the new node
    assert new_node == get_node("""
    print(*(list(range(1)) + list(range(3))))
    """)

    # And the `tree_changed` flag is set to `True`
    assert transformer.tree_changed is True


# Generated at 2022-06-12 04:08:33.466060
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:08:42.787067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    from .utils import make_tree, compare_trees
    star = ast.Starred()
    star.value = ast.Call(func=ast.Name('a'), args=[])

# Generated at 2022-06-12 04:08:50.238063
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ..visitors import print_ast
    source = """
list(0, *range(10), *range(13))
print(*range(1), *range(3))
x = range(*range(1), *range(3))
[2, *range(10), 1]
test(2, *[1, 2, 3])
[2, *range(10), 1, (2, 3, 4)]
    """

# Generated at 2022-06-12 04:08:56.980543
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    inp = """
        f(*range(0), *range(1))
        """
    exp = """
        f(*(list(range(0)) + list(range(1))))
        """

    input_ast = ast.parse(inp)
    expected_ast = ast.parse(exp)

    transformer = StarredUnpackingTransformer()
    transformer.visit(input_ast)

    assert ast.dump(input_ast) == ast.dump(expected_ast)



# Generated at 2022-06-12 04:09:06.520427
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""
    from .base import BaseNodeTestMixin as NodeTestMixin
    from .base import BaseUnparserTestMixin as UnparserTestMixin
    from typed_astunparse import unparse as typed_unparse


# Generated at 2022-06-12 04:09:13.261333
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.code_gen import to_source
    from .tools import get_tree, tree_to_str

    node = get_tree(
        'def f():\n'
        '  print(*[1, *range(5), 9], *[1, 2])'
    )

    assert to_source(StarredUnpackingTransformer().visit(node)) == tree_to_str(
        'def f():\n'
        '  print(*(([1] + list(range(5)) + [9]) + list([1, 2])))'
    )



# Generated at 2022-06-12 04:09:22.410644
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from compiler.ast_tools.unparsing import Unparser

    unpacker = StarredUnpackingTransformer()

    tree1 = ast.Call(func=ast.Name(id="print"), args=[ast.Starred(value=ast.Name(id="range"), ctx=ast.Load()), ast.Num(n=1), ast.Starred(value=ast.Name(id="range"), ctx=ast.Load())], keywords=[])
    tree1 = unpacker.visit(tree1)
    print(Unparser(tree1)) # print(*(list(range(1)) + list(range(3))))


# Generated at 2022-06-12 04:09:27.879178
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Build AST
    tree = ast.parse("""[2, *range(10), 1]""")
    StarredUnpackingTransformer().visit(tree)

    # Execute it in an empty namespace and verify the result
    namespace = {}
    exec(compile(tree, '<string>', 'exec'), namespace)
    assert namespace['a'] == [2] + list(range(10)) + [1]

# Unit test

# Generated at 2022-06-12 04:09:35.159672
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import inspect
    method = inspect.getsource(StarredUnpackingTransformer.visit_Call)
    
    assert method.__contains__('''    def visit_Call(self, node: ast.Call) -> ast.Call:
        if not self._has_starred(node.args):
            return self.generic_visit(self.generic_visit(node))  # type: ignore

        self._tree_changed = True

        args = self._to_sum_of_lists(node.args)
        node.args = [ast.Starred(value=args)]
        return self.generic_visit(node)  # type: ignore
''')


# Generated at 2022-06-12 04:09:40.266966
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3, parse
    node = parse("print(*range(1), *range(3))").body[0]
    before_str = ast3.dump(node)
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    after_str = ast3.dump(node)
    expected_str = ast3.dump(parse("print(*(list(range(1)) + list(range(3))))").body[0])
    assert after_str == expected_str
    assert before_str != after_str


# Generated at 2022-06-12 04:10:18.133083
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    data_list = [
        ([], '[]'),
        (['1'], '[1]'),
        (['1', '*(2,)', '3'], '[1] + list((2,)) + [3]'),
        (['1', '*(2, 3)', '3'], '[1] + list((2, 3)) + [3]'),
        (['1', '*[2]', '3'], '[1] + list([2]) + [3]'),
        ('["a"+("b"*"c")]', '["a" + b * c]'),
        ('["a"+("b"*3)]', '["a" + "b" * 3]'),
    ]

# Generated at 2022-06-12 04:10:26.882622
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(t)
    print(ast.dump(t))

# Generated at 2022-06-12 04:10:28.420556
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test for the constructor of the class StarredUnpackingTransformer"""
    StarredUnpackingTransformer()


# Generated at 2022-06-12 04:10:36.652196
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tr = StarredUnpackingTransformer()
    assert tr.visit(
        ast.parse('''
        [1, *range(5)]
        ''').body[0]) == ast.parse('''
        [1] + list(range(5))
        ''').body[0]

    # Test empty list
    assert tr.visit(
        ast.parse('[]').body[0]) == ast.parse('[]').body[0]

    # Test already processed list
    assert tr.visit(
        ast.parse('[1] + list(range(5))').body[0]) == ast.parse(
        '''
        [1] + list(range(5))
        ''').body[0]

    # Test nested starred

# Generated at 2022-06-12 04:10:46.290466
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Test(StarredUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True
            return False

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            lists = [[]]  # type: List[Splitted]
            for x in xs:
                if isinstance(x, ast.Starred):
                    lists.append(x)
                    lists.append([])
                else:
                    assert isinstance(lists[-1], list)
                    lists[-1].append(x)
            return lists


# Generated at 2022-06-12 04:10:51.474450
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .visit_call_test_input import visit_call_test_input

    for call in visit_call_test_input.values():
        actual_ast = StarredUnpackingTransformer().visit(call)
        expected_ast = ast.parse(
            importlib.resources.read_text('pscript._compile', 'visit_call_test_output.py')
        )

        assert_ast_equal(expected_ast.body[0], actual_ast)


# Generated at 2022-06-12 04:10:59.239274
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    assert \
        ast.dump(t.visit(ast.parse('[2, *range(10), 1]'))) == \
        'Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id=\'list\', ctx=Load()), args=[Name(id=\'range\', ctx=Load())], keywords=[keyword(arg=None, value=Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=10)], keywords=[]))]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))'


# Generated at 2022-06-12 04:11:07.585111
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # type: () -> None
    from .test_helpers import assert_transform
    from .test_helpers import parse_to_node


# Generated at 2022-06-12 04:11:12.339949
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astpretty import pprint
    from .utils import assert_tree

    tree = ast.parse("[2, *range(10), 1, *range(3)]")
    expected = ast.parse("[2] + list(range(10)) + [1] + list(range(3))")

    StarredUnpackingTransformer().visit(tree)
    assert_tree(tree, expected)



# Generated at 2022-06-12 04:11:20.495033
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .tools import execute, compare_ast
    from .compat import exec_
    from .examples import ListExamples
    from .examples import StarredUnpackingExamples

    for example in StarredUnpackingExamples:
        source = example[0]
        expected = example[1]
        module = ast.parse(source)

        new_module = StarredUnpackingTransformer().visit(module)
        result = compare_ast(module, new_module)
        assert result, 'AST must be not changed'

        with open('/tmp/_test.py', 'w') as fp:
            fp.write(source)
            fp.write('\n')
        with open('/tmp/_expected.py', 'w') as fp:
            fp.write(expected)
            fp.write('\n')

       