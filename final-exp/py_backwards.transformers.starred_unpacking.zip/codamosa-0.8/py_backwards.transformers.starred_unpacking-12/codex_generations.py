

# Generated at 2022-06-12 04:02:04.246602
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class DummyNode:
        pass

    # Test for no starred unpacking
    node1 = DummyNode()
    node1.elts = [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]
    node2 = StarredUnpackingTransformer().visit_List(node=node1)
    assert isinstance(node2, DummyNode)
    assert [1, 2, 3] == [x.n for x in node2.elts]

    # Test without starred unpacking
    node1 = DummyNode()
    node1.elts = [ast.Num(n=1), ast.Starred(value=ast.List(elts=[])), ast.Num(n=3)]
    node2 = StarredUnpackingTransformer().visit_List(node=node1)

# Generated at 2022-06-12 04:02:14.183684
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with StarredUnpackingTransformer() as t:
        node = ast.parse('[1, 2, [*range(1), *range(2), 4]]').body[0]
        result = t.visit(node)
        assert isinstance(result, ast.List)
        assert result == ast.parse('[1, 2, [0, 1, 0, 1, 2, 4]]').body[0]

        node = ast.parse('[1, 2, *range(3)]').body[0]
        result = t.visit(node)
        assert isinstance(result, ast.List)
        assert result == ast.parse('[1, 2] + list(range(3))').body[0]


# Generated at 2022-06-12 04:02:17.521149
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    f = lambda: print(*range(1), *range(3))
    f()

    # Should transform to:
    # print(*(list(range(1)) + list(range(3))))



# Generated at 2022-06-12 04:02:23.111541
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
"""
    expected = """
print(*(list(range(1)) + list(range(3))))
"""

    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    generated = ast.unparse(node)
    assert generated == expected



# Generated at 2022-06-12 04:02:33.959794
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import asttokens
    from .test_compat_ast import parse
    from .test_compat_ast import test_compat_ast as _test_compat_ast  # noqa

    fname = 'tests/cases/starred_unpacking/source1.py'
    source = open(fname).read()
    atok = asttokens.ASTTokens(source, fname)
    node = atok.tree.body[1]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert node.value.keywords == []
    assert len(node.value.args) == 3
    assert isinstance(node.value.args[1], ast.Starred)


# Generated at 2022-06-12 04:02:37.482050
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    res = test_util.run_test(
        StarredUnpackingTransformer,
        '''[*range(1), 2, *range(3)]''',
        '''list(range(1)) + [2] + list(range(3))'''
    )

    assert res



# Generated at 2022-06-12 04:02:45.693175
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._split_by_starred(
        [ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()), ast.List(elts=[ast.Name(id='b'), ast.Name(id='c')]),
         ast.Name(id='d')]) == \
           [[], ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()), [],
            [ast.Name(id='b'), ast.Name(id='c')],
            [], [ast.Name(id='d')]]

# Generated at 2022-06-12 04:02:48.871064
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as _ast
    node = _ast.parse('[2, *range(10), 1]', mode='eval').body
    StarredUnpackingTransformer().visit(node)
    assert isinstance(node, _ast.BinOp)

# Generated at 2022-06-12 04:03:00.689557
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import TestTranspileExec

    class Test(TestTranspileExec):
        def test_list(self):
            self.assertCodeExecution("""
                print([2, *range(10), 1])
                """)

        def test_list_unpacking(self):
            self.assertCodeExecution("""
                a, *b = *range(5)
                print(a)
                print(b)
                """)

        def test_list_call_keyword(self):
            self.assertCodeExecution("""
                print(list(*range(5)))
                """)

        def test_list_call_plus(self):
            self.assertCodeExecution("""
                print(list(*range(5), *range(5)))
                """)


# Generated at 2022-06-12 04:03:03.473640
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    def test_constructor():
        i = StarredUnpackingTransformer()
        assert i

    test_constructor()

# Generated at 2022-06-12 04:03:17.694956
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import round_trips_unmodified
    from typed_ast.ast3 import Starred, List, Call, Load, Name
    round_trips_unmodified(
        'def foo(): [1, 2, *range(10), 3, 4]\nprint(*range(2), *range(3))\n'
    )
    a, b = Starred(value=Name(id='a', ctx=Load()), ctx=Load()), List(elts=[], ctx=Load())
    c = Call(func=Name(id='foo', ctx=Load()), args=[a, b], keywords=[])
    c = StarredUnpackingTransformer().visit(c)
    assert isinstance(c, Call)
    assert len(c.args) == 1

# Generated at 2022-06-12 04:03:18.635868
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:03:29.020405
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import round_trip_dump, round_trip_visit
    from .test_util import AssertEqualMixin
    from lib2to3.fixer_util import pprint

    class TestVisitor(AssertEqualMixin, StarredUnpackingTransformer):
        def visit_Call(self, node):
            node = super().visit_Call(node)
            print(pprint(node))
            return node
    print('TEST_STARRED_VISITOR:')
    example = """
>>> f( *args )
>>> f( *[1, 2, 3] )
>>> f( *(1, 2, 3) )
>>> f( *range(10) )
>>> f( *range(10), *range(10) )
"""
    for s in example.splitlines():
        s

# Generated at 2022-06-12 04:03:34.771834
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .compiler import TreeCompiler
    from .source_transformer import SourceTransformer
    import os

    class TestTransformer(SourceTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if not isinstance(node.func, ast.Name) or node.func.id != 'print':
                return self.generic_visit(node)
            node = StarredUnpackingTransformer().visit(node)
            return self.generic_visit(node)

    code = '''
    print(*range(1), *range(3))
    print('foo', *range(4))
    '''
    source = code.strip()

    transformer = TestTransformer()
    transformer.visit(ast.parse(source))

    compiler = TreeCompiler()
    code_obj = compiler

# Generated at 2022-06-12 04:03:40.313552
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_ast = ast.parse("[10,*range(10)]")
    assert type(input_ast) is ast.Module
    StarredUnpackingTransformer().visit(input_ast)
    output_ast = ast.parse('[10]+list(range(10))')
    assert type(output_ast) is ast.Module
    assert input_ast == output_ast

# Generated at 2022-06-12 04:03:45.862967
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''
print(*range(1), *range(3))
''')

    StarredUnpackingTransformer().visit(node)

    expected = ast.parse('''
print(*(list(range(1)) + list(range(3))))
''').body[0]

    assert node.body[0] == expected



# Generated at 2022-06-12 04:03:55.792636
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    cls = StarredUnpackingTransformer
    func = cls().visit_Call

    case1 = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Name(id='*'),
            ast.List(
                elts=[
                    ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Num(n=1)],
                        keywords=[]),
                    ast.Starred(
                        value=ast.Call(
                            func=ast.Name(id='range'),
                            args=[ast.Num(n=3)],
                            keywords=[]),
                        )
                ])
        ],
        keywords=[])
    result1 = func(case1)

# Generated at 2022-06-12 04:03:57.411890
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    node_1 = ast.parse('''[2, *range(10), 1]''', mode='eval').body
    StarredUnpackingTransformer.run_pipeline(node_1)
    assert astor.to_source(node_1) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:04:09.109613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as _ast
    source = 'print(*range(1), *range(2), *range(3), 4)'
    tree = _ast.parse(source, mode='exec')
    node = tree.body[0]
    node1 = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:04:14.653193
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    parent = ast.parse("print(10, *range(11), 20)")
    node = parent.body[0].value

    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert isinstance(node.args[0], ast.Num)
    assert isinstance(node.args[1], ast.Starred)
    assert isinstance(node.args[1].value, ast.Call)

    StarredUnpackingTransformer().visit(parent)

    assert isinstance(node.args[0], ast.Call)
    assert isinstance(node.args[0].func, ast.Name)
    assert isinstance(node.args[0].args[0], ast.Num)


# Generated at 2022-06-12 04:04:29.300855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestVisitor:
        def generic_visit(self, node):
            return node
    class TestVisitor2:
        def __init__(self):
            self.generic_visit_calls = 0
            self._tree_changed = False
        def generic_visit(self, node):
            self.generic_visit_calls += 1
            if self.generic_visit_calls == 1:
                return ast.Call(func=ast.Name(id='test'), args=[], keywords=[])
            else:
                return node
    class TestVisitor3:
        def __init__(self):
            self.generic_visit_calls = 0
            self._tree_changed = False
        def generic_visit(self, node):
            self.generic_visit_calls += 1

# Generated at 2022-06-12 04:04:39.563466
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestVisitor(ast.NodeVisitor):
        def __init__(self):
            self.result = []

        def visit_Call(self, node):
            self.result.append(node)

        def visit(self, node):
            self.result = []
            super().visit(node)
            return self.result

    def check(expr, expected):
        visitor = TestVisitor()
        visitor.visit(ast.parse(expr).body[0])
        assert len(expected) == len(visitor.result)
        for node, expected in zip(visitor.result, expected):
            assert isinstance(node, ast.Call)
            assert expected == ast.dump(node.args[0])


    check('f(1, 2, 3)', [])

# Generated at 2022-06-12 04:04:46.877262
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Target: [2, *range(10), 1]
    # Result: [2] + list(range(10)) + [1]
    binop1 = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)], ctx=ast.Load()), op=ast.Add(), right=ast.Call(func=ast.Name(id='list', ctx=ast.Load()), args=[ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=10)], keywords=[])], keywords=[]))
    binop2 = ast.BinOp(left=binop1, op=ast.Add(), right=ast.List(elts=[ast.Num(n=1)], ctx=ast.Load()))

# Generated at 2022-06-12 04:04:52.581282
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    expr = '''[2, *range(10), 1]'''
    expected_expr = '[2] + list(range(10)) + [1]'
    # When
    tree = ast.parse(expr)
    StarredUnpackingTransformer().visit(tree)
    # Then
    res = astor.to_source(tree)
    assert res == expected_expr


# Generated at 2022-06-12 04:04:57.145681
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .transforms import TransformerSequence

    t = TransformerSequence(StarredUnpackingTransformer)
    # t = StarredUnpackingTransformer()

    code = "print(*range(1), *range(3))"
    expected_code = "print(*(list(range(1)) + list(range(3))))"
    assert t.visit_and_transform(code) == expected_code

# Generated at 2022-06-12 04:05:01.630667
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0]
    result = StarredUnpackingTransformer().visit(node)
    assert ast.dump(result) == ast.dump(ast.parse('[2] + list(range(10)) + [1]').body[0])



# Generated at 2022-06-12 04:05:07.567841
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = """foo("blue", "green", *["red", "yellow"], "orange")"""
    expected_x = """foo(*(["blue", "green"] + list(["red", "yellow"]) + ["orange"]))"""
    node = ast.parse(x)
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected_x and node is not None

# Generated at 2022-06-12 04:05:16.016579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load())], keywords=[])

    expected_node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='range')], keywords=[]), ctx=ast.Load())], keywords=[])

    actual_node = StarredUnpackingTransformer().visit(node)

    assert ast.dump(expected_node) == ast.dump(actual_node)


# Generated at 2022-06-12 04:05:22.715717
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    code = "test([1, 2, 3], *range(5), *range(3))"
    node = ast.parse(code)
    # When
    transformed_node = StarredUnpackingTransformer().visit(node)
    # Then
    expected_node = ast.parse("test( *( [1, 2, 3] + list(range(5)) + list(range(3)) ) )")
    assert ast.dump(transformed_node) == ast.dump(expected_node)



# Generated at 2022-06-12 04:05:32.008469
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected_ast_a = ast.parse(
        "foo = [2] + list(range(10)) + [1]")
    expected_ast_b = ast.parse(
        "foo = list(range(10)) + [1]")
    source_a = ast.parse(
        "foo = [2, *range(10), 1]")
    source_b = ast.parse(
        "foo = [*range(10), 1]")
    assert expected_ast_a.body == StarredUnpackingTransformer().visit(source_a.body)
    assert expected_ast_b.body == StarredUnpackingTransformer().visit(source_b.body)


# Generated at 2022-06-12 04:05:45.943856
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .utils import round_trip
    src = "print(1, *range(2), 3)"
    expected = "print(*(1, *list(range(2)), 3))"
    result = round_trip(src, StarredUnpackingTransformer)
    assert str(result) == expected, f"{result!r} != {expected!r}"
    src = "print(1, *range(2), *range(3), 4)"
    expected = "print(*(1, *list(range(2)), *list(range(3)), 4))"
    result = round_trip(src, StarredUnpackingTransformer)
    assert str(result) == expected, f"{result!r} != {expected!r}"


# Generated at 2022-06-12 04:05:55.690594
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """\
[*"abc", *"def", 42]
    """
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert to_source(node) == "[*'abc' + *'def' + [42]]"

    code = """\
print(*range(1), *range(3))
    """
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert to_source(node) == "print(*(list(range(1)) + list(range(3))))\n"

    code = """\
[1, 2]
    """
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert to_source(node) == "[1, 2]"

# Generated at 2022-06-12 04:05:59.290456
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    code = """
a = [2, *range(10), 1]
"""
    expected = """
a = [2] + list(range(10)) + [1]
"""
    # Act
    result = compile_snippet(code, StarredUnpackingTransformer)

    # Assert
    assert_code_equal(result, expected)


# Generated at 2022-06-12 04:06:04.220914
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    print_ = ast.parse('print(*range(1), *range(3))').body[0]

    transformer = StarredUnpackingTransformer()
    new_print_ = transformer.visit(print_)

    assert transformer.changed
    assert round_trip(new_print_) == round_trip(print_)

# Generated at 2022-06-12 04:06:09.677831
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0].value
    
    assert str(node) == '[2, *range(10), 1]'
    
    StarredUnpackingTransformer().visit(node)
    assert str(node) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:06:14.032703
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source_code = """
        print(*range(1), *range(3))
    """
    expected_code = """
        print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(source_code)
    StarredUnpackingTransformer().visit(tree)
    assert expected_code == astor.to_source(tree).strip()
    return tree


# Generated at 2022-06-12 04:06:17.077811
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    assert StarredUnpackingTransformer.run_source(source) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-12 04:06:27.723989
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test visit_Call method of StarredUnpackingTransformer.

    """
    module = ast.parse("print(*range(1), *range(3), sep='-', end=' ')")
    node = module.body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Starred)
    assert type(node.args[0].value) == ast.Call
    assert type(node.args[1]) == ast.Starred
    assert type(node.args[1].value) == ast.Call
    assert len(node.keywords) == 2
    assert node.keywords[0].arg == 'sep'
    assert type(node.keywords[0].value) == ast.Str
    assert node.key

# Generated at 2022-06-12 04:06:33.801650
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    original_code = """
print(*range(10), *range(10), *[], *[], *range(5))
    """
    expected_code = """
print(*(list(range(10)) + list(range(10)) + list() + list() + list(range(5))))
    """
    node = ast.parse(original_code)
    expected = ast.parse(expected_code)
    result = StarredUnpackingTransformer().visit(node)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:06:41.328197
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from libcst.metadata import PositionProvider
    from libcst import parse_statement

    code = 'print(*range(1), *range(3))'
    tree = parse_statement(code)
    provider = tree.code[0].visit(PositionProvider())
    tree.visit(StarredUnpackingTransformer(provider))

    assert isinstance(tree.code[0].args[0], ast.Starred)
    assert tree.code[0].args[0].value.left.func.id == 'list'
    assert tree.code[0].args[0].value.left.args[0].func.id == 'range'
    assert tree.code[0].args[0].value.right.func.id == 'list'
    assert tree.code[0].args[0].value.right.args[0].func

# Generated at 2022-06-12 04:06:54.146396
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = 'x= [2, *range(10), 1]'
    tree = ast.parse(code, mode='eval')
    visitor = StarredUnpackingTransformer()
    visitor.visit(tree)

    assert code == visitor.get_source()


# Generated at 2022-06-12 04:07:01.904625
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import run_test_with_checker, run_test_with_checker_ast_only

    args = [ast.Num(n=1), ast.Starred(value=ast.Num(n=2)), ast.Num(n=3)]
    call_expr = ast.Call(func=ast.Name(id="f"), args=args)
    print(call_expr)

    # (1) check normal case
    run_test_with_checker(ast.parse, ast.Call, call_expr,
            StarredUnpackingTransformer, "(f, *([] + [2] + []), 3)")

    # (2) check nested starred

# Generated at 2022-06-12 04:07:07.962492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('test_StarredUnpackingTransformer_visit_Call')
    tt = StarredUnpackingTransformer(None)
    n = ast.parse("""
print(*range(1), *range(3))
        """)
    n = n.body[0]
    n = tt.visit(n)
    print(ast.dump(n))

if __name__ == '__main__':
    test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-12 04:07:11.372605
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer"""
    x = StarredUnpackingTransformer()
    assert isinstance(x, BaseNodeTransformer)
    assert x.target == (3, 4)


# Generated at 2022-06-12 04:07:17.950740
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast, typed_ast.ast3
    # orig_ast = ast.parse("[2, *range(10), 1]")
    orig_ast = typed_ast.ast3.parse("[2, *range(10), 1]")
    expected_ast = typed_ast.ast3.parse("[2] + list(range(10)) + [1]")
    transformed_ast = StarredUnpackingTransformer().visit(orig_ast)
    assert ast.dump(expected_ast) == ast.dump(transformed_ast)


# Generated at 2022-06-12 04:07:18.782085
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:07:25.423788
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from tests.helper import transform, assert_source

    STARRED_UNPACKING_CODE = '''print(*range(1), *range(3))'''
    STARRED_UNPACKING_SOURCE = '''print(*(list(range(1)) + list(range(3))))'''

    assert_source(STARRED_UNPACKING_SOURCE, transform(StarredUnpackingTransformer, STARRED_UNPACKING_CODE))



# Generated at 2022-06-12 04:07:30.576263
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .to_ast import to_ast
    from .to_source import to_source
    from .transformer import TransformerVisitor

    source = 'a = [1, *range(5), 2]'
    tree = to_ast(source)
    visitor = TransformerVisitor(StarredUnpackingTransformer)
    visitor.visit(tree)

    source = 'a = [1] + list(range(5)) + [2]'
    result = to_source(tree)
    assert source == result, result



# Generated at 2022-06-12 04:07:38.836025
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*[1, 2], 3)").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    xs = node.value.args
    assert len(xs) == 3
    assert isinstance(xs[0], ast.Starred)
    assert isinstance(xs[0].value, ast.List)
    assert xs[0].value.elts == [ast.Num(n=1), ast.Num(n=2)]
    assert isinstance(xs[1], ast.Num)
    assert xs[1].n == 3

    node = StarredUnpackingTran

# Generated at 2022-06-12 04:07:40.425059
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()


# Generated at 2022-06-12 04:07:52.449988
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import to_source
    from .mock import MockTranspiler
    from textwrap import dedent

    source = dedent("""\
    [2, *range(10), 1]""")
    expect = dedent("""\
    [2] + list(range(10)) + [1]""")
    tree = ast.parse(source)
    transpiler = MockTranspiler(tree=tree)
    node = transpiler.tree
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert to_source(node) == expect


# Generated at 2022-06-12 04:07:55.125568
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .testutils import test_ast
    source = '[2, *range(10)]'
    expected = '[2] + list(range(10))'
    test_ast(source, StarredUnpackingTransformer, expected)


# Generated at 2022-06-12 04:07:58.778906
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert repr(StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]"))) == repr(ast.parse("[2] + list(range(10)) + [1]"))
    assert repr(StarredUnpackingTransformer().visit(ast.parse("[2]"))) == repr(ast.parse("[2]"))

# Generated at 2022-06-12 04:08:07.900976
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_one_starred = ast.List(elts=[ast.Starred(value=ast.Name(id="range"), ctx=ast.Load())])
    node_no_starred = ast.List(elts=[ast.Num(n=2), ast.Name(id="range"), ast.Num(n=1)])
    node_with_starred_in_middle = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id="range"), ctx=ast.Load()), ast.Num(n=1)])
    node_with_starred_in_beginning = ast.List(elts=[ast.Starred(value=ast.Name(id="range"), ctx=ast.Load()), ast.Num(n=1)])
    node_with_star

# Generated at 2022-06-12 04:08:10.602608
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from utils import parse

    transformer = StarredUnpackingTransformer()

    assert transformer.visit(parse("[2, *range(10), 1]")) == parse("[2] + list(range(10)) + [1]")



# Generated at 2022-06-12 04:08:13.682980
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    transformed = StarredUnpackingTransformer().transform_source(code)
    print(transformed)
    assert transformed.strip() == expected



# Generated at 2022-06-12 04:08:20.753511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """
    Before:
        [2, *range(10), 1]
    After:
        [2] + list(range(10)) + [1]
    """
    node = ast.parse('[2, *range(10), 1]').body[0].value
    result = StarredUnpackingTransformer().visit_List(node)
    assert ast.dump(result, sort_keys=True) == 'List(elts=[Num(n=2), Add(left=List(elts=[]), right=List(elts=[]), op=Add()), Num(n=1)], ctx=Load())'


# Generated at 2022-06-12 04:08:24.500361
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")
    StarredUnpackingTransformer().visit(tree)
    
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-12 04:08:34.226980
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    UNPACKING_LIST = """
    [2, *range(10), "1"]
    """
    UNPACKING_LIST_EXPECTED = """
    [2] + list(range(10)) + ["1"]
    """
    UNPACKING_LIST_EXPECTED_2 = """
    [2] + list(range(10)) + list(list(list(list(list(list(list(list(list(list(list(["1"])))))))))))
    """
    UNPACKING_LIST_EXPECTED_3 = """
    [2] + list(range(10)) + ["1"] + list(range(10)) + list(range(10)) + ["1"]
    """

# Generated at 2022-06-12 04:08:38.098742
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .ast_transformer import ASTTransformer
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    module = ASTTransformer(StarredUnpackingTransformer).visit(ast.parse(source))
    assert ASTTransformer.compile(module) == expected


# Generated at 2022-06-12 04:08:49.262508
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = dedent('''
        [2, *range(10), 1]
    ''').strip()
    expected = dedent('''
        [2] + list(range(10)) + [1]
    ''').strip()

    node = ast.parse(source)
    actual = StarredUnpackingTransformer().visit(node)
    actual_str = astor.to_source(actual).strip()

    assert expected == actual_str



# Generated at 2022-06-12 04:08:52.403177
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-12 04:08:58.640780
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
[2, *range(10), 1]
    """
    expected = """
[2] + list(range(10)) + [1]
    """
    tree = ast.parse(source, feature_version=StarredUnpackingTransformer.target)
    StarredUnpackingTransformer().visit(tree)
    ast.fix_missing_locations(tree)
    print(astunparse.unparse(tree))
    assert astunparse.unparse(tree) == expected



# Generated at 2022-06-12 04:09:02.881978
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    tree = ast.parse("[2, *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == '[2] + list(range(10)) + [1]'


# Generated at 2022-06-12 04:09:08.847214
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from . import parse_ast

    src = '''[2, *range(10), 1]'''
    node = parse_ast(src)
    ctx = compile_source(src, '<test>', 'exec')
    comp = StarredUnpackingTransformer()
    comp.visit(node)
    new_code = compile(node, '<test>', 'exec')
    exec(new_code, ctx)
    result = eval('__main__', ctx)
    assert result == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]


# Generated at 2022-06-12 04:09:12.289398
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import unparse
    code = '[2, *range(10), 1]'
    result = unparse(code, StarredUnpackingTransformer)
    assert result == '[2] + list(range(10)) + [1]', result


# Generated at 2022-06-12 04:09:16.399036
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    test = StarredUnpackingTransformer(source).result

    # Should be: [2, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert test == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-12 04:09:21.687710
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse
    visitor = StarredUnpackingTransformer()
    tree = parse(
        "[1, 2, 3, *[4, 5]]"
    )
    new_tree = visitor.visit(tree)
    print(new_tree)

    tree = parse(
        "[*[1, 2, 3, 4, 5]]"
    )
    new_tree = visitor.visit(tree)
    print(new_tree)


# Generated at 2022-06-12 04:09:30.937144
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from copy import deepcopy
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    node = ast.List(
        elts=[
            ast.Name(id='foo', ctx=ast.Load()),
            ast.Name(id='bar', ctx=ast.Store()),
            ast.Starred(value=ast.Name(id='baz', ctx=ast.Load()))
        ],
        ctx=ast.Store())


# Generated at 2022-06-12 04:09:38.664148
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    unpacker = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    unpacker.visit(node)

# Generated at 2022-06-12 04:10:04.065996
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class MockNodeVisitor(ast.NodeVisitor):
        def visit(self, node):
            return node

    node = ast.parse('''
        [2, *range(10), 1]
    ''')
    StarredUnpackingTransformer().visit(node)

    expected = ast.parse('''
        [2] + list(range(10)) + [1]
    ''')

    assert MockNodeVisitor().visit(expected) == MockNodeVisitor().visit(node)


# Generated at 2022-06-12 04:10:10.614571
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    AST = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(AST)
    assert result.body[0].value == ast.BinOp(left=ast.List(elts=ast.Num(n=2)),
                                             right=ast.Call(func=ast.Name(id='list'),
                                                            args=[ast.Call(func=ast.Name(id='range'),
                                                                           args=[ast.Num(n=10)],
                                                                           keywords=[])],
                                                            keywords=[]),
                                             op=ast.Add())


# Generated at 2022-06-12 04:10:19.809806
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def _parse(expr_str: str) -> ast.List:
        return ast.parse(f'[{expr_str}]').body[0].value
    def _compile(expr_str: str) -> ast.List:
        return StarredUnpackingTransformer().visit(_parse(expr_str))

    assert _compile('1, 2, 3') == _parse('1, 2, 3')
    assert _compile('1, *range(3), 3') == _parse('1, *(list(range(3))), 3')
    assert _compile('1, *range(3), 3, *list(range(5))') == \
           _parse('1, *(list(range(3)) + list(range(5))), 3')


# Generated at 2022-06-12 04:10:26.102130
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .ast_converter import ASTConverter

    source_code = \
"""
[2, *range(10), 1]
"""
    expected_code = \
"""
[2] + list(range(10)) + [1]
"""
    # Make transformer and transform code
    transformer = StarredUnpackingTransformer()
    code = transformer.visit(ASTConverter().convert_to_ast(source_code))
    # Assert code
    assert ASTConverter.compare_source_code(code, expected_code)


# Generated at 2022-06-12 04:10:32.761331
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse('[1, *range(2), 3]')) == \
        ast.parse('[1] + list(range(2)) + [3]')

    assert StarredUnpackingTransformer().visit(ast.parse('[*range(3), 2, 1]')) == \
        ast.parse('list(range(3)) + [2] + [1]')

    assert StarredUnpackingTransformer().visit(ast.parse('[2, *range(1)]')) == \
        ast.parse('[2] + list(range(1))')



# Generated at 2022-06-12 04:10:35.941067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import assert_equal_ast
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    assert_equal_ast(StarredUnpackingTransformer(), source, expected)



# Generated at 2022-06-12 04:10:45.776915
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Dummy(ast.AST):
        pass
    dummy_0 = Dummy()
    dummy_1 = Dummy()
    dummy_2 = Dummy()
    dummy_3 = Dummy()

    result = StarredUnpackingTransformer.visit_List(None, ast.List(
        elts=[ast.Starred(value=dummy_0)], ctx=ast.Load()
    ))
    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert result.func.id == 'list'
    assert result.args == [dummy_0]
    assert result.keywords == []


# Generated at 2022-06-12 04:10:48.753466
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    tree = ast.parse("[2,*range(10),1]")

    t = StarredUnpackingTransformer()
    t.visit(tree)

    assert(str(t) == "[2] + list(range(10)) + [1]")

# Generated at 2022-06-12 04:10:57.131359
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(
        elts=[ast.Num(n=2)],
        ctx=ast.Load()
    )
    expected = node
    assert StarredUnpackingTransformer().visit(node) == expected

    node = ast.List(
        elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))],
        ctx=ast.Load()
    )
    expected = ast.List(
        elts=[ast.Num(n=2),
              ast.Call(
                  func=ast.Name(id='list'),
                  args=[ast.Name(id='range', ctx=ast.Load())],
                  keywords=[]
              )],
        ctx=ast.Load()
    )
    assert StarredUnpacking

# Generated at 2022-06-12 04:11:05.526156
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse
    t = StarredUnpackingTransformer()
    # [2, *range(10), 1]
    tree = parse("[2, *range(10), 1]")  # type: ast.Module
    t.visit(tree)
    result = ast.parse(t.tree_to_code(tree))  # type: ast.Module
    assert ast.dump(result) == ast.dump(parse('[2] + list(range(10)) + [1]'))
    # [2, 3, *range(10), 1]
    tree = parse("[2, 3, *range(10), 1]")  # type: ast.Module
    t.visit(tree)
    result = ast.parse(t.tree_to_code(tree))  # type: ast.Module
    assert ast

# Generated at 2022-06-12 04:11:48.024155
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    simple_list = ast.parse("[2, *range(10), 1]")
    simple_list_result = ast.parse("[2] + list(range(10)) + [1]")
    empty_list = ast.parse("[*[], 1, 2]")
    empty_list_result = ast.parse("list([]) + [1] + [2]")
    list_with_starred = ast.parse("[1, *[2], 3]")
    list_with_starred_result = ast.parse("[1] + list([2]) + [3]")
    list_with_several_starred = ast.parse("[1, *[2], 3, *[4, 5]]")

# Generated at 2022-06-12 04:11:55.257844
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def check(code: str, expected_code: str) -> None:
        tree = ast.parse(code)
        StarredUnpackingTransformer().visit(tree)
        assert expected_code == astor.to_source(tree)

    check('[2, *range(10), 1]', '[2] + list(range(10)) + [1]')
    check('[*range(10), 1]', 'list(range(10)) + [1]')
    check('[2, 1, *range(10)]', '[2, 1] + list(range(10))')
    check('[[*range(10)], 1]', '[[*range(10)], 1]')
    check('[2, [*range(10)], 1]', '[2, [*range(10)], 1]')