

# Generated at 2022-06-12 04:01:58.149922
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    create_arg_list = ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Num(n=1)],
        keywords=[]
    )
    create_run_list = ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Num(n=3)],
        keywords=[]
    )
    create_task_list = ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Num(n=2)],
        keywords=[]
    )
    create_sum_list = ast.BinOp(
        left=create_arg_list,
        right=create_run_list,
        op=ast.Add()
    )

# Generated at 2022-06-12 04:02:09.467630
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("""[2, *range(10), 1]""")
    transformer = StarredUnpackingTransformer()
    node = transformer.visit(tree)

# Generated at 2022-06-12 04:02:16.183791
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Name(id='range'))
        ],
        keywords=[])
    assert StarredUnpackingTransformer(print_source=True).visit(node) == \
        ast.Call(
            func=ast.Name(id='print'),
            args=[
                ast.Starred(
                    value=ast.Call(
                        func=ast.Name(id='list'),
                        args=[
                            ast.Name(id='range')
                        ],
                        keywords=[]))
            ],
            keywords=[])



# Generated at 2022-06-12 04:02:26.045985
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = """
print(1, *range(10), 2, *[3, 4])
"""
    expected = """
print(*(list(range(10)) + [2] + list([3, 4])))
"""
    with patch('builtins.print', create=True) as p:
        module = parse(input)
        StarredUnpackingTransformer().visit(module)
        tree_string = dump(module)
        # print(tree_string)
        assert tree_string == expected
        exec(compile(module, filename='<ast>', mode='exec'))
        # print(p.mock_calls)
        p.assert_called_once_with(*(list(range(10)) + [2] + list([3, 4])))



# Generated at 2022-06-12 04:02:33.422769
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3

    x = typed_ast.ast3.List(elts=[typed_ast.ast3.Name(id='t', ctx=typed_ast.ast3.Load())])

    y = StarredUnpackingTransformer().visit(x)

    assert isinstance(y, typed_ast.ast3.List)

    assert len(y.elts) == 1

    assert isinstance(y.elts[0], typed_ast.ast3.Name)

    assert y.elts[0].id == 't'


# Generated at 2022-06-12 04:02:40.846204
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from collections import namedtuple
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call

    StarredUnpackingTransformer = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:02:49.059182
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # test simple case
    tree = ast.parse("[2, *range(10), 1]")
    # without starred
    assert ast.dump(StarredUnpackingTransformer.run(tree)) == ast.dump(ast.parse("[2] + list(range(10)) + [1]"))
    # with starred
    assert ast.dump(StarredUnpackingTransformer.run(tree, use_starred=True)) == ast.dump(ast.parse("[2, *list(range(10)), 1]"))
    # test case with empty list
    tree = ast.parse("[1, *[], 2]")
    assert ast.dump(StarredUnpackingTransformer.run(tree)) == ast.dump(ast.parse("[1] + [] + [2]"))
    # test with nested list
    tree = ast.parse

# Generated at 2022-06-12 04:02:55.711570
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    source = '[2, *range(10), 1]'
    node = round_trip(source)
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0]
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(node) == expected



# Generated at 2022-06-12 04:03:05.249245
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call(): 
    node = ast.parse('print(1, *range(10), 2)').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert len(node.value.args) == 3

    t = StarredUnpackingTransformer()
    node = t.visit(node)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert len(node.value.args) == 1
    assert isinstance(node.value.args[0], ast.Starred)
    assert isinstance(node.value.args[0].value, ast.BinOp)


# Generated at 2022-06-12 04:03:11.711693
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def check(code: str, expected: str) -> None:
        node = ast.parse(code)
        StarredUnpackingTransformer().visit(node)
        assert ast.dump(node) == expected

    check('[2, *range(10), 1]', '[2] + list(range(10)) + [1]')
    check('print(*range(1), *[2], *range(3))', 'print(*(list(range(1)) + [2] + list(range(3))))')


# Generated at 2022-06-12 04:03:26.903480
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # case 1: simple case
    code = 'x = [2, *range(10), 1]'
    expected_result = 'x = [2] + list(range(10)) + [1]'
    trasformer = StarredUnpackingTransformer()
    transformed_code = trasformer.visit(ast.parse(code))
    assert trasformer._tree_changed == True
    assert astor.to_source(transformed_code.body[0]) == expected_result
    # case 2: nested star
    code = 'x = [2, *[1,*range(10)], 1]'
    expected_result = 'x = [2] + [1] + list(range(10)) + [1]'
    trasformer = StarredUnpackingTransformer()

# Generated at 2022-06-12 04:03:32.110421
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    input = [2, *range(10), 1]
    expected = [2] + list(range(10)) + [1]
    
    star_unpacking_transformer = StarredUnpackingTransformer()
    star_unpacking_transformer.visit(ast.parse(str(input)))
    result = star_unpacking_transformer.mod_tree.body[0].value
    assert_equals(reconstruct_source_code(result), str(expected))

    

# Generated at 2022-06-12 04:03:35.563078
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "list = [2, *range(10), 1]"
    result = "list = [2] + list(range(10)) + [1]"
    transformer = StarredUnpackingTransformer(code)
    assert transformer.result == result



# Generated at 2022-06-12 04:03:43.658509
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import ast_utl as utl
    tree = utl.parse_print(
        """
        [2, *range(10), 1]
        print(*range(1), *range(3))
        """)

    expected = utl.parse(
        """
        [2, *(list(range(10)) + [1])]
        print(*(list(range(1)) + list(range(3))))
        """)

    assert expected == StarredUnpackingTransformer(3).visit(tree)

# Generated at 2022-06-12 04:03:53.832659
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import copy, ast, unittest
    from nb2 import StarredUnpackingTransformer as SUT
    transformer = SUT()

    def f(a, b, c, d):
        pass

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = copy.deepcopy(transformer)

        def test_no_starred(self):
            node = ast.Call(func=ast.Name(id='f'), args=[ast.Num(n=1), ast.Num(n=2)], keywords=[])

            result = self.transformer.visit_Call(node)

            self.assertEqual(ast.dump(node), ast.dump(result))


# Generated at 2022-06-12 04:03:58.929404
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    result = StarredUnpackingTransformer(code).get_result()
    expected = "[2] + list(range(10)) + [1]"
    assert expected == result
    code = "[2, *range(10), 1]"
    result = StarredUnpackingTransformer(code).get_result()
    expected = "[2] + list(range(10)) + [1]"
    assert expected == result


# Generated at 2022-06-12 04:04:09.868408
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('*'*20, 'Unit test for method visit_Call of class StarredUnpackingTransformer')
    import astor  # type: ignore

    sample_input_0 = ast.parse('list([1, 2, *range(3), *range(5, 10)])')
    expected_output_0 = ast.parse('list([1, 2] + list(range(3)) + list(range(5, 10)))')
    sample = sample_input_0
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(sample)
    assert astor.to_source(transformed) == astor.to_source(expected_output_0)
    print(transformed)

    sample_input_1 = ast.parse('a(1, 2, *range(3), *range(5, 10))')


# Generated at 2022-06-12 04:04:19.257885
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    # src is a function that prints the input star-arguments
    src = """
    def f(a1, a2):
        print(a1, a2)
    """
    # expected is an ast of the expected-output for the given src
    expected = """
    def f(a1, a2):
        print(*(list(a1) + list(a2)))
    """
    
    # Comparing the expected-ast with the output-ast for the given input-ast
    expected_ast = ast.parse(expected)
    inp_ast = ast.parse(src)
    out_ast = StarredUnpackingTransformer().visit(inp_ast)
    assert ast.dump(expected_ast) == ast.dump(out_ast)

# Generated at 2022-06-12 04:04:29.712375
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from itertools import count
    from .parser import parse_source

    transformer = StarredUnpackingTransformer()

    for i, test in enumerate(count()):
        source = """
        def f(a, b):
            print(a, b)
        f(%s)
        """ % test

        new_source = transformer.transform_source(source)
        new_ast = parse_source(new_source)
        assert new_source != source, 'No changes were made'
        assert str(test), "Can't parse testcase"
        assert len(new_ast.body) == 1, 'One function should be added'
        function = new_ast.body[0]
        assert isinstance(function, ast.FunctionDef)
        assert len(function.body) == 1, 'One line should be in the function'


# Generated at 2022-06-12 04:04:39.973019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    delimiter = ast.Load()
    t = StarredUnpackingTransformer()
    before = ast.List(elts=[ast.Name(id='x', ctx=delimiter), ast.Starred(value=ast.Name(id='y', ctx=delimiter), ctx=delimiter), ast.Name(id='z', ctx=delimiter)], ctx=delimiter)

# Generated at 2022-06-12 04:04:58.070188
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # StarredUnpackingTransformer._split_by_starred
    class TestStarredUnpackingTransformer_split_by_starred:
        def test_wrap_splitted_element(self):
            node = ast.List(elts=[ast.Starred(value=ast.Name(id='a'), ctx=ast.Load)])
            splitted = StarredUnpackingTransformer._split_by_starred(node.elts)

            assert splitted == [ast.Starred(value=ast.Name(id='a'), ctx=ast.Load)]

        def test_wrap_each_splitted_element(self):
            node = ast.List(elts=[ast.Name(id='a'), ast.Starred(value=ast.Name(id='b'), ctx=ast.Load)])
            splitted = Starred

# Generated at 2022-06-12 04:05:09.541694
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    # Case 1: arguments: arg1, arg2, arg3, arg4
    node = ast.parse("f(arg1, arg2, arg3, arg4)")
    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)
    assert ast.dump(new_node) == ast.dump(node)

    # Case 2: arguments: arg1, arg2, *arg3, arg4
    node = ast.parse("f(arg1, arg2, *arg3, arg4)")
    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)
    assert ast.dump(new_node) == ast.dump(node)

    # Case 3: arguments: arg1,

# Generated at 2022-06-12 04:05:16.330559
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    import textwrap

    code = textwrap.dedent(r'''
    [2, *range(10), 1]
    ''')
    expected_code = textwrap.dedent(r'''
    [2] + list(range(10)) + [1]
    ''')

    node = ast.parse(code)
    node = StarredUnpackingTransformer().visit(node)
    generated_code = astunparse.unparse(node)

    print(code)
    print('===>')
    print(generated_code)
    print('<===')
    print(expected_code)

    assert generated_code == expected_code



# Generated at 2022-06-12 04:05:21.967743
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast
    from transform.unpacking import StarredUnpackingTransformer
    from utils.source import Source

    result = Source('[2, *range(10), 1]')
    expected_result = Source('[2] + list(range(10)) + [1]')
    StarredUnpackingTransformer().visit(result.tree)

    assert expected_result.pretty() == result.pretty()



# Generated at 2022-06-12 04:05:31.317152
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    node = ast.parse(code)
    t = StarredUnpackingTransformer()
    t.visit(node)
    assert ast.dump(node) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[])), op=Add(), right=List(elts=[Num(n=1)])))])"


# Generated at 2022-06-12 04:05:36.810457
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call(): 
    b = StarredUnpackingTransformer() 
    node = ast.Call(
            func=ast.Name(id='print'),
            args=[ast.Starred(value=ast.Name(id='range'))],
            keywords=[])
    
    result = b.visit_Call(node) 
    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.BinOp)
    

# Generated at 2022-06-12 04:05:43.725930
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(1, *range(3), 2, *range(3), 3, *range(3))'
    expected = 'print(*(list([1]) + list(range(3)) + list([2]) + list(range(3)) + list([3]) + list(range(3))))'
    result = StarredUnpackingTransformer().visit_Call(ast.parse(source).body[0].value)
    assert ast.dump(result) == expected, 'visit_Call does not work as expected'

# Generated at 2022-06-12 04:05:50.068644
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_util import load, dump, round_trip
    from . import UnnecessaryListCompTransformer  # NOQA: F401

    src = "[*[2, 3], 4, 5, *range(10), *range(5)]"
    expected = "[2, 3, 4, 5] + list(range(10)) + list(range(5))"
    tree = load(src, mode='eval')
    result = StarredUnpackingTransformer(UnnecessaryListCompTransformer(StarredUnpackingTransformer())).visit(tree)
    assert dump(result) == expected
    assert round_trip(src, mode='eval') == expected



# Generated at 2022-06-12 04:05:52.575224
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import test_utils
    test_utils.run_test_passthrough(StarredUnpackingTransformer, 'print(*range(5), 1, sep="-")')

# Generated at 2022-06-12 04:05:58.547237
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astunparse import unparse
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_starred_unpacking(self):
            src = '[2, *range(10), 1]'
            expected = '[2] + list(range(10)) + [1]'
            self.assertTransformedAst(src, expected)

    TestCase.run()


# Generated at 2022-06-12 04:06:08.648916
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()
    
# test example from class doc string

# Generated at 2022-06-12 04:06:14.060578
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import parse as ast_parse
    node = ast_parse('''\
a = [2, *range(10), 1]
print(*range(1), *range(3))''')
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == textwrap.dedent('''\
    a = [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))''')

# Generated at 2022-06-12 04:06:25.400539
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from nuitka.tree.building.createNodes import ExpressionTargetTempVariableRef, StatementExpressionOnly, StatementReturn
    from nuitka.tree.extraction.SymbolCodes import getNoneConstantCode
    from nuitka.plugins.languages.python.PythonPlugin import PythonPlugin
    #
    # def foo(arg1):
    #    print(arg1)
    #    return None
    #

# Generated at 2022-06-12 04:06:29.918186
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import tree_utils
    code = "print(*range(1), *range(3))"
    expected_result = "print(*(list(range(1))+list(range(3))))"

    tree = tree_utils.build_ast(code)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    result = tree_utils.ast2source(tree, code)
    assert expected_result == result

# Generated at 2022-06-12 04:06:30.723634
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import gencode


# Generated at 2022-06-12 04:06:35.268072
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]").body[0]

    new_node = transformer.visit(node)

    assert isinstance(new_node, ast.Expr)
    assert isinstance(new_node.value, ast.BinOp)

# Generated at 2022-06-12 04:06:40.502639
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    tree = ast.parse("print(*range(1), *range(3))")
    transformed_tree = transformer.visit(tree)

    assert len(transformed_tree.body) == 1
    value = transformed_tree.body[0].value
    assert value.func.id == 'list'
    assert [n.n for n in value.args[0].elts] == [1,3]
    assert [n.value.id for n in value.keywords] == []


# Generated at 2022-06-12 04:06:44.864733
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    expected_tree = ast.parse("[1, 2, 3] + [4, 5, 6]")
    result_tree = StarredUnpackingTransformer().visit(ast.parse("[1, 2, 3, *[4, 5, 6]]"))
    assert ast.dump(expected_tree) == ast.dump(result_tree)



# Generated at 2022-06-12 04:06:48.339066
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("a = [2, *range(10), 1]")
    print(ast.dump(node))
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    print(ast.dump(node))

# Generated at 2022-06-12 04:06:52.325292
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_setup import build_ast, compare_ast

    x = [3, *range(7), 2]
    expected = ast.parse('[3] + list(range(7)) + [2]')
    code_str = str(compile(build_ast(x), '<string>', 'single'))
    expected_str = str(compile(expected, '<string>', 'single'))
    assert code_str == expected_str


# Generated at 2022-06-12 04:07:11.331134
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test for method visit_Call of class StarredUnpackingTransformer."""
    tree = ast.parse("""
        a(*args, *args2, *args3)
        a(*[])
        a(*[], *[], *[])
        a()
        a([])
        """)
    expected = ast.parse("""
        a(*(args + list(range(10)) + [1]))
        a(*list([]))
        a(*(list([]) + list([]) + list([])))
        a()
        a([])
        """)
    # print(ast.dump(tree))
    StarredUnpackingTransformer().visit(tree)
    # print(ast.dump(tree))
    assert ast.dump(expected) == ast.dump(tree)


# Generated at 2022-06-12 04:07:12.241098
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass



# Generated at 2022-06-12 04:07:20.700417
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astunparse import unparse


# Generated at 2022-06-12 04:07:24.397721
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    check(
"""
[2, *range(10), 1]
""", """
([2] + list(range(10)) + [1])
""", StarredUnpackingTransformer)



# Generated at 2022-06-12 04:07:28.655966
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = source = compile('''
import sys
[2, *range(10), 1]
''', '<ast>', 'exec')

    expected = compile('''
import sys
([2] + list(range(10)) + [1])
''', '<ast>', 'exec')

    assert StarredUnpackingTransformer().visit(source) == expected



# Generated at 2022-06-12 04:07:31.354323
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = """
    print(*range(1), *range(3))
    """

    exp_output = """
    print(*(list(range(1)) + list(range(3))))
    """

    assert compile_snippet(input) == exp_output


# Generated at 2022-06-12 04:07:34.908584
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ensure_ast_changes(
        StarredUnpackingTransformer,
        '[2, *range(10), 1]',
        '[2] + list(range(10)) + [1]')


# Generated at 2022-06-12 04:07:38.805666
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as _ast
    module = _ast.parse('[2, *range(10), 1]')

    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(module)

    # This code was generated by StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-12 04:07:44.119723
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import astor
    code = 'print(*range(1), *range(3))'
    code_ast = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    new_ast = transformer.visit(code_ast)
    assert astor.to_source(new_ast).strip() == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-12 04:07:47.843921
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = """
    a = list(range(1))
    print(*a)
    """
    expected = """
    a = list(range(1))
    print(*(list(a)))
    """
    t = StarredUnpackingTransformer()
    assert t.test(input) == expected

# Generated at 2022-06-12 04:08:16.861201
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    star = ast.Starred(value=ast.Name(id='X'))
    node = ast.List(elts=[ast.Name(id='Y')])
    expected = '([Y])'

    # Without starred
    actual = StarredUnpackingTransformer().visit(node)
    assert unparse(actual) == expected

    # With starred
    node.elts.append(star)
    actual = StarredUnpackingTransformer().visit(node)
    expected = '([Y] + list(X))'
    assert unparse(actual) == expected


# Generated at 2022-06-12 04:08:24.041902
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as typed_ast
    from astor.code_gen import to_source
    from cwc_compiler import Compiler
    from cwc_compiler.compilers import StarredUnpackingCompiler

    compiler = Compiler(compilers=[StarredUnpackingCompiler()])

    @compiler.compile
    def foo():
        [1, *range(1)]

    string = """def foo():
    [1] + list(range(1))"""
    assert to_source(typed_ast.parse(string)) == to_source(compiler.typed_ast)


# Generated at 2022-06-12 04:08:33.857667
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from typed_astunparse import unparse

    def test(bad_code, good_code):
        # type: (str, str) -> None
        bad_tree = pyast.parse(bad_code)
        good_tree = pyast.parse(good_code)

        assert StarredUnpackingTransformer().visit(bad_tree) == good_tree

    test(
        'print(1, 2, 3, *range(4), 5)',
        'print(*(list(range(4)) + [1, 2, 3, 5]))')
    test(
        'print(*range(4), *range(4))',
        'print(*(list(range(4)) + list(range(4))))')

# Generated at 2022-06-12 04:08:38.260148
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_ast = ast.parse("print(*range(1), *range(3), 4)")
    result = StarredUnpackingTransformer.run_on_node(call_ast)
    expected = ast.parse("print(*[4] + list((list(range(1)) + list(range(3)))))")
    assert are_same(expected, result)



# Generated at 2022-06-12 04:08:47.668666
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[1, *range(10)]')

    class Result(ast.ast3.NodeTransformer):
        def visit_List(self, node):
            return node

    result = Result().visit(StarredUnpackingTransformer().visit(node))

    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.List)
    assert isinstance(result.left.elts[0], ast.Num)
    assert result.left.elts[0].n == 1
    assert isinstance(result.op, ast.Add)
    assert isinstance(result.right, ast.Call)
    assert isinstance(result.right.args[0], ast.Starred)
    assert isinstance(result.right.args[0].value, ast.Call)

# Generated at 2022-06-12 04:08:50.780812
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import from_source

    src = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    actual = from_source(StarredUnpackingTransformer, src)

    assert expected == actual


# Generated at 2022-06-12 04:08:56.015589
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse('list(range(1)) + [2] + list(range(3)) + [4]')
    result = ast.parse('[2, *range(10), 1]')
    result_transformed = StarredUnpackingTransformer().visit(result)
    assert ast.dump(expected) == ast.dump(result_transformed)


# Generated at 2022-06-12 04:08:59.988512
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(1, *range(2))")
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    result = ast_unparse(tree)
    expected = "print(*(1 + list(range(2))))"
    assert result == expected


# Generated at 2022-06-12 04:09:04.131432
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[1, *range(5), 1]"
    expect = "[1] + list(range(5)) + [1]"
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    assert expect == ast.dump(tree)


# Generated at 2022-06-12 04:09:07.825008
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected_tree = ast.parse("[2] + list(range(10)) + [1]")
    tree = ast.parse("[2, *range(10), 1]")
    test_transformer = StarredUnpackingTransformer()
    test_transformer.visit(tree)
    assert ast.dump(expected_tree) == ast.dump(tree)


# Generated at 2022-06-12 04:09:59.989226
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = "print(*range(1), *range(3))"
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 04:10:08.761618
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    c = StarredUnpackingTransformer()
    x = ast.parse("print(*range(1), *range(3))")
    print(ast.dump(c.visit(x)))

# Generated at 2022-06-12 04:10:10.029923
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 4)

# Generated at 2022-06-12 04:10:19.372555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import to_source
    from typed_ast import ast3


# Generated at 2022-06-12 04:10:27.363019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    ########################################################################
    # construct test node 1

    test1_elts = [
        ast.Num(n=2),
        ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
        ast.Num(n=1)
    ]

    test1_node = ast.List(elts=test1_elts)

    # construct visitor 1
    visitor1 = StarredUnpackingTransformer()

    # visit node 1
    visitor1.visit(test1_node)
    visitor1.generic_visit(test1_node)

    ########################################################################
    # construct expected result node 1


# Generated at 2022-06-12 04:10:34.594560
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astunparse import unparse

    class Source(object):
        def _source(self):
            return ast.parse(
                """
                [1, *range(5), 2]
                """
            ).body[0]

        def _expected(self):
            return ast.parse(
                """
                [1] + list(range(5)) + [2]
                """
            ).body[0]

    source = Source()._source()
    expected = Source()._expected()

    result = StarredUnpackingTransformer().visit(source)
    print(unparse(result))
    assert unparse(result) == unparse(expected)


# Generated at 2022-06-12 04:10:40.840470
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import python_ta
    import sys
    def test_init(mocker):
        mocker.patch.object(python_ta, 'logging', autospec=True)
        sys.modules['typed_ast'] = mocker.MagicMock()
        t = StarredUnpackingTransformer()
        assert t.target == (3, 4)
        assert t._tree_changed == False
    test_init()


# Generated at 2022-06-12 04:10:45.537292
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # Before
    code = "f(*args, **kwargs)"
    ast_code = ast.parse(code)
    before = astor.to_source(ast_code)

    # After
    transformer = StarredUnpackingTransformer()
    transformer.visit(ast_code)
    after = astor.to_source(ast_code)

    assert before == code
    assert after == "f(*list(args))"



# Generated at 2022-06-12 04:10:49.937723
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected_result = """
from builtins import list
from builtins import range
[2] + list(range(10)) + [1]
    """.strip()

    source = """
from builtins import range
[2, *range(10), 1]
    """.strip()

    actual_result = compile_to_ast(source, level=3, transformer=StarredUnpackingTransformer)
    assert_source(expected_result, actual_result)



# Generated at 2022-06-12 04:10:58.392364
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("""
l = [3, *range(10), 2, 1]
name = [1, 2, 3]
a = [*[1, 2, 3], *[4, 5], 6]
print(*range(1), *range(3))

name, *l, c = [1, 2, 3, 4, 5]
d, *e, f = [1, 2, 3, 4, 5]
a, *b, c, (d, *e, f) = [1, 2, 3, 4, 5, [6, 7, 8]]
a, *b, c, (d, *e, _, g) = [1, 2, 3, 4, 5, [6, 7, 8, 9]]
""")
    StarredUnpackingTransformer().visit(tree)