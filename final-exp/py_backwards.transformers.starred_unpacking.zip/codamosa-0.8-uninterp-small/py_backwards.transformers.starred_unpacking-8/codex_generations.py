

# Generated at 2022-06-25 22:31:23.226084
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Test case 0
    #   a_s_t_0 = None
    #   starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    #   node = None
    #   func_return_value_0 = None
    #   assert func_return_value_0 == starred_unpacking_transformer_0.visit_List(node)
    

# Generated at 2022-06-25 22:31:33.512056
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    
    # test 1
    node_0 = ast.Call(
        func=ast.Name(id='func'),
        args=[
            ast.Starred(
                value=ast.Name(id='args'),
                ctx=ast.Load()),
            ast.Name(id='arg1'),
            ast.Name(id='arg2')],
        keywords=[])
    
    try:
        node_0 = starred_unpacking_transformer_0.visit_Call(node_0)
    except:
        pass
    
    # test 2

# Generated at 2022-06-25 22:31:44.777066
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('a')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_c_0 = ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=10)], keywords=[])), ast.Str(s='test')], keywords=[])

# Generated at 2022-06-25 22:31:46.458334
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Constructor does not return a value


# Generated at 2022-06-25 22:31:54.168977
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def __test_case(test_arg):
        a_s_t_0 = ast.parse(test_arg)
        a_s_t_0.__class__ = ast.AST
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        __expected = ast.parse('[2] + list(range(10)) + [1]')
        __expected.__class__ = ast.AST
        __expected
        __expected_0 = ast.parse('[2] + list(range(10)) + [1]')
        __expected_0.__class__ = ast.AST
        __expected_0
        __actual = starred_unpacking_transformer_0.visit(ast.parse('[2, *range(10), 1]'))
        __actual.__class

# Generated at 2022-06-25 22:31:59.376684
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Can't use ast.parse since it's Python 2 and 3.
    source = """
    [2, *range(10), 1]
    """
    expected = """
    [2] + list(range(10)) + [1]
    """
    assert StarredUnpackingTransformer(source)._tree_changed == True
    assert str(StarredUnpackingTransformer(source).result) == expected


# Generated at 2022-06-25 22:32:13.175537
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Call()
    a_s_t_1.args = [ast.List()]
    a_s_t_1.args[0].elts = [ast.List()]
    a_s_t_1 = starred_unpacking_transformer_0.visit_Call(a_s_t_1)
    a_s_t_1 = ast.Call()
    a_s_t_1.args = [ast.List()]
    a_s_t_1.args[0].elts = [ast.List()]

# Generated at 2022-06-25 22:32:18.871959
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Call visit_Call of class StarredUnpackingTransformer
    try:
        starred_unpacking_transformer_0.visit_Call()
    except(NotImplementedError):
        pass


# Generated at 2022-06-25 22:32:27.921358
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s_u_t_ASTO = """
        [2, *range(10), 1]
    """
    s_u_t_expected = """
        [2] + list(range(10)) + [1]
    """
    s_u_t = StarredUnpackingTransformer(compile(s_u_t_ASTO, __file__, 'exec'))
    s_u_t_actual = s_u_t.visit_List([2, *range(10), 1])
    assert s_u_t_actual == compile(s_u_t_expected, __file__, 'exec')


# Generated at 2022-06-25 22:32:30.038482
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:32:37.472186
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(module_1)


# Generated at 2022-06-25 22:32:41.290375
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:32:47.271625
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_1 == call_0


# Generated at 2022-06-25 22:32:53.364476
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:56.781914
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:33:07.338427
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:33:17.548217
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    #
    # Some testing code ...
    #

    assert True
    if True:
        return
    else:
        some_lambda = lambda *args, **kwargs: None

    assert isinstance(some_lambda, types.FunctionType)
    assert isinstance(some_lambda, types.BuiltinFunctionType)

    assert isinstance(some_lambda, types.GeneratorType)
    assert isinstance(some_lambda, types.BuiltinGeneratorType)
    assert isinstance(some_lambda, types.CoroutineType)
    assert isinstance(some_lambda, types.AsyncGeneratorType)
    assert isinstance(some_lambda, types.AsyncIterableType)


# Generated at 2022-06-25 22:33:23.664776
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    c_a_l_l_0 = module_0.Call()
    return_value_0 = c_a_l_l_0
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    return_value_1 = starred_unpacking_transformer_0.visit_Call(return_value_0)

# Generated at 2022-06-25 22:33:26.260280
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:33:32.626351
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

    # Assert
    assert list_1 == list_0


# Generated at 2022-06-25 22:33:41.260195
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()

# Generated at 2022-06-25 22:33:46.669489
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    call_0.args = [list_0]
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:33:52.671181
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_1 = module_0.Call()
    call_1.args.append(module_0.Attribute())
    call_1.args.append(module_0.Attribute())
    call_1.args.append(module_0.Attribute())
    call_1.args.append(module_0.Attribute())
    
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_2 = starred_unpacking_transformer_0.visit_Call(call_1)


# Generated at 2022-06-25 22:34:04.123334
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    call_0.func = a_s_t_0
    call_0.args = [a_s_t_0]
    call_0.keywords = [a_s_t_0, a_s_t_0]
    call_1 = module_0.Call()
    call_1.func = call_0
    call_1.args = [a_s_t_0, call_0, a_s_t_0]
    call_1.keywords = [a_s_t_0, a_s_t_0]
    starred_0 = module_0.Starred()
    starred_0.value = call_0

# Generated at 2022-06-25 22:34:07.165841
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("testing constructor")
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:34:11.642326
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_1 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_2 = starred_unpacking_transformer_0.visit_List(list_1)


# Generated at 2022-06-25 22:34:18.811982
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse("""
some_function(*[1, 2, 3], 'some_string', *[4, 5, 6])
""")
    star_2 = module_0.body[0].value
    assert star_2.func.id == "some_function"
    star_1 = star_2.args[0]
    assert isinstance(star_1, ast.Starred)
    star_0 = star_2.args[3]
    assert isinstance(star_0, ast.Starred)
    assert len(star_0.value.elts) == 3
    assert len(star_1.value.elts) == 3
    assert len(star_2.args) == 4
    assert star_2.args[1].s == "some_string"

# Generated at 2022-06-25 22:34:23.397868
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:34:30.305060
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:34:35.586789
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:34:58.182172
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:04.580209
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast._ast3 as module_0
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

    # Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:35:08.392243
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_0 = StarredUnpackingTransformer(None)
    call_0 = module_0.Call()
    try:
        class_0.visit_Call(call_0)
    except Exception:
        pass


# Generated at 2022-06-25 22:35:14.168582
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

import typed_ast._ast3 as module_4


# Generated at 2022-06-25 22:35:18.798624
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:23.850641
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:27.660920
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = setup_test()
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:31.064382
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    module = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer(module).visit(module)
    exec(compile(module, filename='', mode='exec'))



# Generated at 2022-06-25 22:35:32.351441
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    assert StarredUnpackingTransformer(ast.AST()) is not None

# Generated at 2022-06-25 22:35:37.538606
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    # TODO: (templated_ast.py) StarredUnpackingTransformer, StarredUnpackingTransformer, line 10
    #assert_true(starred_unpacking_transformer_0.visit_List(list_0) == list)

# Generated at 2022-06-25 22:35:48.084691
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:35:52.457523
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:35:57.010288
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_1 = 'print(*range(1), *range(3))'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)

# Generated at 2022-06-25 22:36:01.864096
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:36:06.902952
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(2), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:36:11.540506
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:36:15.381126
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:36:19.317537
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    var_1 = StarredUnpackingTransformer(var_0).visit(var_0)


# Generated at 2022-06-25 22:36:23.337521
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_1 = 'print(*range(1), *range(3))'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:36:29.032572
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    assert starred_unpacking_transformer_0.visit_Call(module_0.parse('print(*range(1), *range(3))')).s == 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-25 22:36:45.121820
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    var_0.body[0]
    var_1 = StarredUnpackingTransformer(var_0)
    var_2 = var_1.visit(var_0.body[0])
    var_1._tree_changed

# Generated at 2022-06-25 22:36:49.281256
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)


# Generated at 2022-06-25 22:36:54.855740
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_4 = module_0.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_4)
    # Constructor calls method on object (line 16)
    return_value_1 = starred_unpacking_transformer_0.visit(var_4)
    assert return_value_1 is None, f'expected: None\nactual: {return_value_1}'


# Generated at 2022-06-25 22:37:00.949855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:08.024302
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = isinstance(var_1, module_0.List)
    assert var_2 == True
    assert str(var_1) == '([2] + list(range(10)) + [1])'


# Generated at 2022-06-25 22:37:11.613663
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    return None

# Generated at 2022-06-25 22:37:12.513597
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()


# Generated at 2022-06-25 22:37:16.559855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_1 = 'print(*range(1), *range(3))'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:37:18.371497
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    root = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer(root)



# Generated at 2022-06-25 22:37:27.064557
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '''[2, *range(10), 1]'''
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    # test: 'return _to_sum_of_lists(node.elts)'
    # test: '[2] + list(range(10)) + [1]'
    assert(isinstance(var_1, module_0.BinOp))


# Generated at 2022-06-25 22:37:37.673980
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:37:41.906333
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3), *range(5))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:46.228467
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:47.446247
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:37:49.576875
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[1, *range(10), 2]')
    assert StarredUnpackingTransformer(tree).tree is tree


# Generated at 2022-06-25 22:37:53.797688
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:56.509451
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = module_0.parse('[2, *range(10), 1]')
    assert StarredUnpackingTransformer(tree).tree is tree
    assert not StarredUnpackingTransformer(tree).tree_changed

# Generated at 2022-06-25 22:38:01.982694
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    astor.to_source(var_1)


# Generated at 2022-06-25 22:38:05.798242
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:06.514009
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:38:16.856554
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = "[2, *range(10), 1]"
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)


# Generated at 2022-06-25 22:38:20.783008
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:28.213115
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as ast
    NodeTransformer_0 = ast.NodeTransformer
    var_0 = NodeTransformer_0()
    str_0 = '[2, *range(10), 1]'
    var_1 = ast.parse(str_0)
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(var_1)
    assert len(StarredUnpackingTransformer_0.__dict__) == len(NodeTransformer_0.__dict__)
    assert StarredUnpackingTransformer_0.__dict__.keys() == NodeTransformer_0.__dict__.keys()


# Generated at 2022-06-25 22:38:32.231553
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    assert isinstance(StarredUnpackingTransformer(var_0), StarredUnpackingTransformer)



# Generated at 2022-06-25 22:38:41.044673
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Initialize node
    str_0 = ast.List(elts=[ast.Constant(value=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Constant(value=10)], keywords=[])), ast.Constant(value=1)])
    # Run initialization
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(str_0)
    assert starred_unpacking_transformer_0.target == (3, 4)


# Generated at 2022-06-25 22:38:44.082713
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:38:48.319255
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:52.001652
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:53.045091
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        test_case_0()
    except Exception:
        raise

# Generated at 2022-06-25 22:38:54.427481
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module_0 = StarredUnpackingTransformer(None)
    assert module_0 == None


# Generated at 2022-06-25 22:39:05.166601
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:09.350842
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:14.488009
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as module_0
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    assert 'StarredUnpackingTransformer' in str(type(starred_unpacking_transformer_0))


# Generated at 2022-06-25 22:39:18.661884
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = 'hello'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:29.342039
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Prepare parameters
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = module_0.Call(func=module_0.Name(id='print', ctx=module_0.Load()), args=[module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load())], keywords=[])

    # Execute function
    var_2 = starred_unpacking_transformer_0.visit_Call(var_1)

    # Check result
    assert isinstance(var_2, module_0.Call)

# Generated at 2022-06-25 22:39:33.251395
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:39:34.187463
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True == True


# Generated at 2022-06-25 22:39:39.013909
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:39:42.797913
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)


# Generated at 2022-06-25 22:39:46.814921
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_2 = module_0.parse("print(*range(1), *range(3))")
    var_3 = StarredUnpackingTransformer(var_2)
    var_4 = var_3.visit(var_2)


# Generated at 2022-06-25 22:39:59.239190
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:39:59.960926
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert False, "Test not written"


# Generated at 2022-06-25 22:40:02.564510
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:09.828530
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:19.058316
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as module_0
    import typed_ast.ast3 as module_1
    class_0 = StarredUnpackingTransformer
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_1.parse(str_0)
    var_1 = module_0.Call()
    var_2 = class_0(var_0)
    var_3 = var_2.visit(var_1)


# Generated at 2022-06-25 22:40:22.980457
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    tree_changed = False
    var_1 = StarredUnpackingTransformer(var_0, tree_changed)
    var_2 = var_1.visit(var_0)


# Generated at 2022-06-25 22:40:28.073610
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    module_0.parse(var_1)


# Generated at 2022-06-25 22:40:30.603535
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)


# Generated at 2022-06-25 22:40:34.329833
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:37.227408
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:53.471132
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = '[2, *range(10), 1]'
    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer(tree)
    assert transformer._tree_changed is False


# Generated at 2022-06-25 22:40:58.148288
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    with raises(Exception):
        str_0 = 'print(*range(1), *range(3))'
        var_0 = module_0.parse(str_0)
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
        var_1 = starred_unpacking_transformer_0.visit_Call(var_0)


# Generated at 2022-06-25 22:40:59.611239
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:41:05.740826
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # initialize class
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    print('Contents of the variable starred_unpacking_transformer_0:', starred_unpacking_transformer_0)
    print('Contents of the variable var_0:', var_0)

    # see if it compiles
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:41:12.931356
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_python.compiler.type_wrappers.wrapper import Wrapper
    from typed_python.compiler.type_wrappers.refcounted_wrapper import RefcountedWrapper
    from typed_python.compiler.type_wrappers.bound_method_wrapper import BoundMethodWrapper
    from typed_python.compiler.type_wrappers.none_type_wrapper import NoneTypeWrapper
    from typed_python.compiler.type_wrappers.module import Module
    from typed_python.compiler.type_wrappers.string_wrapper import StringWrapper
    from typed_python.compiler.type_wrappers.int_wrapper import IntWrapper
    from typed_python.compiler.type_wrappers.list_wrapper import ListOfWrapper
    from typed_python.compiler.type_wrappers.function_wrapper import Function