

# Generated at 2022-06-25 22:31:18.780588
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_0 = module_0.Call()
    starred_unpacking_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:31:21.440624
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:24.037515
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        test_case_0()
    except:
        import traceback
        traceback.print_exc()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:31:35.441911
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as ast3
    import ast
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:37.991737
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 22:31:47.749838
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_0, version=(3, 2))
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_0, version=(3, 5))
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_3 = StarredUnpackingTransformer(a_s_t_0, version=(3, 6))

# Generated at 2022-06-25 22:31:54.764487
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # test 0
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    module_0.parse('f(*args, **kwargs)')
    module_0.import_from('typed_ast', 'ast3')
    module_0.fix_missing_locations(stmt)


# Generated at 2022-06-25 22:32:07.501855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("Unit test for method visit_Call of class StarredUnpackingTransformer")
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    n_a_m_e_0 = module_0.Name()
    n_a_m_e_1 = module_0.Name()
    n_a_m_e_2 = module_0.Name()
    list_0 = module_0.List()
    call_0 = module_0.Call(args=[list_0], func=n_a_m_e_2, keywords=[])
    call_1 = module_0.Call(args=[call_0], func=n_a_m_e_1, keywords=[])
    starred_0

# Generated at 2022-06-25 22:32:14.025086
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    l_i_s_t_0 = module_0.List(elts=[], ctx=module_0.Load())
    starred_unpacking_transformer_0.visit_List(l_i_s_t_0)


# Generated at 2022-06-25 22:32:24.133588
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    test_0 = a_s_t_0.parse(
        """
list_0 = [2, *range(10), 1]
"""
    )
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    test_1 = starred_unpacking_transformer_0.visit(
        test_0,
        "test_0",
    )
    print(a_s_t_0.unparse(test_1))
    assert a_s_t_0.unparse(test_1) == """\
list_0 = [2] + list(range(10)) + [1]
"""


# Generated at 2022-06-25 22:32:31.640304
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = [module_0.Call()]
    call_0.keywords = []

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:38.147398
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0_copy = starred_unpacking_transformer_0.visit_Call(call_0)
    # assert call_0_copy.__class__.__name__ == "Call"


# Generated at 2022-06-25 22:32:44.869591
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call()
    call_0 = a_s_t_1
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:55.279873
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    func_0 = module_0.Name(id='print')
    starargs_0 = module_0.Starred(value=module_0.Call(func=module_0.Name(id='range'), args=[module_0.Num(n=1)], keywords=[]))
    starargs_1 = module_0.Starred(value=module_0.Call(func=module_0.Name(id='range'), args=[module_0.Num(n=3)], keywords=[]))
    args_0 = [starargs_0, starargs_1]
    call_0 = module_0.Call(func=func_0, args=args_0, keywords=[])
    assert(call_0.starargs is None)

# Generated at 2022-06-25 22:33:06.469344
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    call_3 = module_0.Call()
    starred_4 = module_0.Starred()
    starred_4.value = 'value_5'
    call_3.args = [starred_4]
    call_3.keywords = []
    call_3.keywords = []
    call_3.keywords = []
    call_3.starargs = 'starargs_6'
    call_3.kwargs = 'kwargs_7'
    call_3.func = 'func_8'

# Generated at 2022-06-25 22:33:16.092307
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    
    module_0 = ast.parse("""a = 1""")

    a_s_t_0 = module_0
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    call_0 = module_0.body[0].value
    
    assert call_0.args == []
    starred_unpacking_transformer_0.visit(call_0)
    
    call_0 = module_0.body[0].value
    assert call_0.args == []
    assert not isinstance(call_0, ast.Call)


# Generated at 2022-06-25 22:33:26.563709
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = module_0.Call(
        module_0.Name(
            id = 'list',
            ctx = module_0.Load()
        ),
        args = [
            module_0.Starred(
                value = module_0.Name(
                    id = 'seq',
                    ctx = module_0.Load()
                ),
                ctx = module_0.Load()
            )
        ],
        keywords = [],
        starargs = None,
        kwargs = None
    )
    starred_unpacking_transformer_1.visit_Call(call_1)

# Generated at 2022-06-25 22:33:37.711279
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Call(args=module_0.args(args=[module_0.Name(id='a', ctx=module_0.Load())], vararg=None, varargannotation=None, kwonlyargs=[], kw_defaults=[], kwarg=None, kwargannotation=None, defaults=[]), func=module_0.Name(id='print', ctx=module_0.Load()), keywords=[])
    
    # Exercise

# Generated at 2022-06-25 22:33:42.482267
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:45.678065
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    module_0.Call()


# Generated at 2022-06-25 22:34:02.958430
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = [module_0.Name()]
    call_0.keywords = [module_0.keyword()]
    call_0.starargs = module_0.Name()
    call_0.kwargs = module_0.Name()

    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    if (call_1 is not call_0):
        raise RuntimeError("Failed: Expected `call_1 is call_0`")


# Generated at 2022-06-25 22:34:13.305969
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    call_1 = module_0.Call(func=module_0.Name(id='list'), args=[module_0.Starred(value=module_0.Name(id='x'))], keywords=[])
    call_0 = module_0.Call(func=module_0.Name(id='print'), args=[module_0.Starred(value=call_1)], keywords=[])

    arg_1 = module_0.Starred(value=module_0.Name(id='x'))
    arg_0 = module_0.Starred(value=module_0.Name(id='x'))

# Generated at 2022-06-25 22:34:19.775410
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_2 = module_0.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)
    a_s_t_3 = module_0.Call()
    a_s_t_4 = module_0.Name(id='list')
    a_s_t_3.func = a_s_t_4
    a_s_t_3.args = []
    a_s_t_3.keywords = []
    a_s_t_5 = module_0.List(elts=[])
    a_s_t_6 = module_0.Call()
    a_s_t_7 = module_0.Name(id='list')
    a_s_t_6.func = a_s_t_7

# Generated at 2022-06-25 22:34:30.305370
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(elts=[module_0.Starred(value=module_0.Name(id=0, ctx=module_0.Load()), ctx=module_0.Load())])
    try:
        module_0.Call(func=module_0.Name(id='0', ctx=module_0.Load()), args=[list_0])
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 22:34:38.157937
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    arg_0 = ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Starred(value=ast.Name(id='range'))],
        keywords=[]
    )
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert starred_unpacking_transformer_0.visit_Call(arg_0) == arg_0


# Generated at 2022-06-25 22:34:46.013336
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_3 = module_0.AST()
    starred_unpacking_transformer_3 = StarredUnpackingTransformer(a_s_t_3)

    call_5 = module_0.Call(func=None, args=[], keywords=[], starargs=None, kwargs=None)
    expected_0 = call_5

    actual_0 = starred_unpacking_transformer_3.visit_Call(call_5)

    assert actual_0 == expected_0


# Generated at 2022-06-25 22:34:55.782875
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    name_0 = module_0.Name(id=str(), ctx=module_0.Load())
    call_1 = module_0.Call(func=name_0, args=[], keywords=[])
    call_0 = module_0.Call(func=name_0, args=[call_1], keywords=[])
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = starred_unpacking_transformer_0.visit_Call(node=call_0)
    assert isinstance(call_0, module_0.Call)

# Generated at 2022-06-25 22:35:05.561332
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    module_0_0 = module_0.Name()
    module_0_0.id = ()
    module_0_0.id = "range"
    call_0.func = module_0_0
    call_0.args = (()).append(module_0.Literal())
    call_0.args[0].value = 1
    call_0.keywords = ()
    assert starred_unpacking_transformer_0.visit_Call(call_0) is None


# Generated at 2022-06-25 22:35:12.716632
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert starred_unpacking_transformer_0._has_starred([]) == False

if __name__ == '__main__':
    try:
        test_case_0()
    except:
        pass
    try:
        test_StarredUnpackingTransformer_visit_Call()
    except:
        pass
# EOF

# Generated at 2022-06-25 22:35:23.581524
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST([])
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(func=module_0.Name(id='func'), args=[module_0.Name(id='arg')], keywords=[module_0.keyword(arg='kwarg', value=module_0.Name(id='value'))])
    call_0 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_0 == module_0.Call(func=module_0.Name(id='func'), args=[module_0.Name(id='arg')], keywords=[module_0.keyword(arg='kwarg', value=module_0.Name(id='value'))])

# Generated at 2022-06-25 22:35:40.547323
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
  a_s_t_0 = module_0.AST()
  starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
  s_t_0 = module_0.Call(func=module_0.Name(id='print', ctx=module_0.Load()), args=[module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load()), module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load())], keywords=[])
  try:
    starred_unpacking_transformer_0.visit_Call(s_t_0)
  except:
    pass

# Generated at 2022-06-25 22:35:50.556787
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0._has_starred = lambda x: x
    starred_unpacking_transformer_0._split_by_starred = lambda x: list(x)
    starred_unpacking_transformer_0._prepare_lists = lambda x: x
    starred_unpacking_transformer_0._merge_lists = lambda x: True
    starred_unpacking_transformer_0._to_sum_of_lists = lambda x: x
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:36:00.444148
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_0.major = 3
    a_s_t_0.minor = 4
    call_0 = module_0.Call()
    call_0.starargs = None
    call_0.kwargs = None
    name_0 = module_0.Name()
    name_0.id = "print"
    name_0.ctx = module_0.Load()
    call_0.func = name_0
    star_0 = module_0.Starred()
    call_1 = module_0.Call()
    call_1.starargs = None
    call_1.kwargs = None
    name_1 = module_0.Name()
    name_1.id = "range"
    name_1.ctx = module

# Generated at 2022-06-25 22:36:06.027764
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    node_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ret = starred_unpacking_transformer_0.visit_Call(node_0)


# Generated at 2022-06-25 22:36:12.580040
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call(func=module_0.Name(id='print'), args=[], keywords=[])
    a_s_t_2: module_0.AST = starred_unpacking_transformer_0.visit_Call(a_s_t_1)


# Generated at 2022-06-25 22:36:16.320996
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = module_0.Call()
    call_2 = starred_unpacking_transformer_1.visit_Call(call_1)
    assert call_2 is not None


# Generated at 2022-06-25 22:36:23.923425
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = typed_ast.ast3
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:33.311847
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    call_0 = module_0.Call(
        func=module_0.Name(
            id='print',
            ctx=module_0.Load()),
        args=[
            module_0.Starred(
                value=module_0.List(
                    elts=[
                        module_0.Num(
                            n=1)],
                    ctx=module_0.Load()),
                ctx=module_0.Load())],
        keywords=[])


# Generated at 2022-06-25 22:36:39.460841
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args = []
    try:
        starred_unpacking_transformer_0.visit_Call(call_0)
        pass
    except:
        assert False


# Generated at 2022-06-25 22:36:45.506010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    # assert call_1 == call_0



# Generated at 2022-06-25 22:37:09.674030
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    module_0.Call()
    module_0.List()
    module_0.BinOp()
    module_0.Add()
    module_0.Starred()
    module_0.Name()
    call_0 = module_0.Call()
    module_0.Call()
    module_0.Call()
    module_0.Call()
    call_0.args.append(module_0.List())
    call_0.args.append(module_0.Call())
    call_0.args.append(module_0.Call())
    print(call_0)

# Generated at 2022-06-25 22:37:15.416262
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    stmt_0 = module_0.parse('[2, *range(10), 1]')
    a_s_t_0.stmt = stmt_0
    starred_unpacking_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:37:21.142132
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    node_0 = module_0.Call(args = [module_0.Str(s = '1'), module_0.Starred(value = module_0.Name(id = 'b', ctx = module_0.Load()), ctx = module_0.Load())], func = module_0.Name(id = 'a', ctx = module_0.Load()), keywords = [], starargs = None, kwargs = None)
    result = starred_unpacking_transformer_1.visit_Call(node_0)

# Generated at 2022-06-25 22:37:32.070283
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args = []
    call_0.keywords = []
    call_0.func = module_0.Name()
    call_0.func.id = 'list'
    call_0.func.ctx = module_0.Load()
    call_0.args.append(module_0.Starred())
    call_0.args[0].value = call_0.func
    call_0.args[0].ctx = module_0.Load()
    call_0.keywords.append(module_0.arg())
    call_0.keywords[0].arg = None

# Generated at 2022-06-25 22:37:42.100276
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call()
    a_s_t_1.args = \
        []
    call_no_starred_expected_result_0 = \
        a_s_t_1
    call_no_starred_actual_result_0 = \
        starred_unpacking_transformer_0.visit_Call(
            a_s_t_1
        )
    assert call_no_starred_expected_result_0 == \
        call_no_starred_actual_result_0

    a_s_t_2 = module_0.Call()
    a_s_t_

# Generated at 2022-06-25 22:37:51.775682
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    _test_tree_0 = module_0.parse('print(*range(1), *range(3))\n')
    a_s_t_0 = module_0.AST()
    a_s_t_0.update(_test_tree_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:37:58.445714
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args.extend([module_0.Call(), module_0.Starred()])
    call_0.keywords.extend([module_0.keyword()])
    try:
        starred_unpacking_transformer_0.visit(call_0)
    except Exception as e:
        raise e


# Generated at 2022-06-25 22:38:07.772089
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_0 = StarredUnpackingTransformer(None)
    method_0 = StarredUnpackingTransformer.visit_Call
    method_1 = StarredUnpackingTransformer.visit_Call
    method_2 = StarredUnpackingTransformer.visit_Call
    method_3 = StarredUnpackingTransformer.visit_Call
    method_4 = StarredUnpackingTransformer.visit_Call
    method_5 = StarredUnpackingTransformer.visit_Call
    method_6 = StarredUnpackingTransformer.visit_Call
    method_7 = StarredUnpackingTransformer.visit_Call
    module_0 = module_0

# Generated at 2022-06-25 22:38:14.271008
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    call_0 = module_0.Call(args=[], keywords=[], starargs=None, kwargs=None)
    visit_Call_return_value_0 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert visit_Call_return_value_0 is None
    assert call_0 == visit_Call_return_value_0


# Generated at 2022-06-25 22:38:23.145967
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Create a class StarredUnpackingTransformer
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # class Call
    a_s_t_1 = module_0.parse('''func(a, *b, c)''')
    call_0 = a_s_t_1.body[0].value
    call_0 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert(str(call_0) == 'func(*([a] + list(b) + [c]))')
    # class Call
    a_s_t_2 = module_0.parse('''func(a, b, c)''')

# Generated at 2022-06-25 22:38:44.272703
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    star_0 = module_0.Starred(value=None, ctx=None)
    call_0 = module_0.Call(func=None, args=[star_0], keywords=[])
    a_s_t_0._nodes.append(call_0)
    a_s_t_0._nodes.append(star_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:38:52.842434
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    list_0 = module_

# Generated at 2022-06-25 22:39:00.967893
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

    test_0_arg_val_0 = module_0.List()
    test_0_arg_val_0.elts = []

    test_0_arg_val_1 = module_0.Name()
    test_0_arg_val_1.id = 'list'
    test_0_arg_val_1.ctx = module_0.Load()

    test_0_arg_val_2 = module_0.List()
    test_0_arg_val_2.elts = []

    test_0_arg_val_3 = module_0.Starred()
    test_0_arg_val_3.value = test

# Generated at 2022-06-25 22:39:01.738830
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:39:09.739067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_node_0 = module_0.List([module_0.Num(0), module_0.Starred(module_0.Name('range', module_0.Load()), module_0.Load()), module_0.Num(2)], module_0.Load())
    starred_unpacking_transformer_0.visit_List(a_s_t_node_0)


# Generated at 2022-06-25 22:39:14.165095
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    _StarredUnpackingTransformer = StarredUnpackingTransformer(a_s_t_0)
    _StarredUnpackingTransformer.visit(a_s_t_0)

if __name__ == "__main__":
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:39:16.788878
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:39:27.749130
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    n_a_m_e_0 = module_0.Name(id='foo')
    l_i_s_t_0 = module_0.List(elts=[n_a_m_e_0], ctx=module_0.Load())
    l_i_s_t_1 = module_0.List(elts=[], ctx=module_0.Del())
    c_a_l_l_0 = module_0.Call(func=n_a_m_e_0, args=[l_i_s_t_0, l_i_s_t_1], keywords=[])
    l_i_s_t

# Generated at 2022-06-25 22:39:32.652753
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)


# Generated at 2022-06-25 22:39:35.909994
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(StarredUnpackingTransformer(a_s_t_0), StarredUnpackingTransformer)

import typed_ast._ast27 as module_1


# Generated at 2022-06-25 22:40:10.377120
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    list_0 = module_0.List()
    module_0._fields(list_0)
    list_0.col_offset = -1
    list_0.ctx = module_0.Load()
    list_0.lineno = -1
    list_0.elts = (None, )

    starred_unpacking_transformer_0.visit(list_0)
    assert True


# Generated at 2022-06-25 22:40:16.379120
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:40:26.152337
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:40:33.961349
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.func.id = str()
    call_0.args = [module_0.Call()]
    call_0.keywords = [module_0.keyword()]
    call_0.starargs = module_0.Name()
    call_0.kwargs = module_0.Name()
    call_0.lineno = int()
    call_0.col_offset = int()
    call_0.end_lineno = int()
    call_0.end_col_offset = int()
    starred_un

# Generated at 2022-06-25 22:40:40.049656
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    bin_op_0 = module_0.BinOp(left=node0_0, right=node0_1, op=module_0.Add())
    add_0 = module_0.Add()
    list_0 = module_0.List(elts=[node0_0, node0_1])
    call_0 = module_0.Call(func=module_0.Name(id='list'), args=[node0_1], keywords=[])
    starred_0 = module_0.Starred(value=node0_1)
    list_1 = module_0.List(elts=[node0_0, node0_1])

# Generated at 2022-06-25 22:40:47.912268
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    expr_0 = module_0.Name(id=str(), ctx=module_0.Load())
    node_0 = module_0.List(elts=[expr_0])
    _0 = module_0.Call(func=module_0.Name(id='list'), args=[node_0.elts[0]], keywords=[])
    assert (starred_unpacking_transformer_0.visit_List(node_0) == _0)


# Generated at 2022-06-25 22:40:56.859055
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:41:05.227054
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    
    # Call to visit_Call of StarredUnpackingTransformer
    module_1 = module_0.Name(id='module')
    module_2 = module_0.Name(id='module')
    module_3 = module_0.Name(id='module')
    module_4 = module_0.Name(id='module')
    module_5 = module_0.Name(id='module')
    module_6 = module_0.Name(id='module')
    module_7 = module_0.Name(id='module')
    module_8 = module_0.Name(id='module')

# Generated at 2022-06-25 22:41:08.184160
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    assert (StarredUnpackingTransformer(a_s_t_0).tree == a_s_t_0)
