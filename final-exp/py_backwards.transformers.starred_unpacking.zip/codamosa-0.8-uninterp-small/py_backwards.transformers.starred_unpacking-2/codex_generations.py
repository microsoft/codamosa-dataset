

# Generated at 2022-06-25 22:31:15.129738
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    list_0.elts = []
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:31:21.797186
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    list_0 = module_0.List(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    try:
        list_0_0 = starred_unpacking_transformer_0.visit_List(list_0)
    except:
        raise Exception('todo')


# Generated at 2022-06-25 22:31:32.174464
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    dict_0 = {"value":[]}
    starred_0 = module_0.Starred(**dict_0)
    expr_0 = starred_0
    list_0 = [expr_0]
    expr_0 = list_0
    list_1 = [expr_0]
    expr_1 = list_1
    str_0 = "*a"
    expr_2 = str_0
    list_2 = [expr_2]
    expr_3 = list_2
    list_3 = [expr_3]
    expr_4 = list_3
    list_4 = [expr_4]
    expr_5 = list_4
    list_5 = [expr_5]
    expr_6 = list_5
    list_6 = [expr_6]
    expr_7 = list_6
    list_

# Generated at 2022-06-25 22:31:37.675708
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

if __name__ == '__main__':
    test_case_0()
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:31:44.406567
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(**dict_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    # test visit_Call
    assert(call_1 == call_0)


# Generated at 2022-06-25 22:31:47.346505
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    try:
        StarredUnpackingTransformer(a_s_t_0)
    except Exception as e:
        pass


# Generated at 2022-06-25 22:31:50.771077
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:32:00.224382
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    module_0.Assert(starred_unpacking_transformer_0._has_starred == (lambda: None))
    module_0.Assert(starred_unpacking_transformer_0._split_by_starred == (lambda: None))
    module_0.Assert(starred_unpacking_transformer_0._prepare_lists == (lambda: None))
    module_0.Assert(starred_unpacking_transformer_0._merge_lists == (lambda: None))

# Generated at 2022-06-25 22:32:13.774014
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    str_0 = "test"
    list_0 = []
    call_0 = module_0.Call(**dict_0)
    list_0.append(call_0)
    list_0.append(str_0)
    list_0.append(str_0)
    call_1 = module_0.Call(**dict_0)
    list_0.append(call_1)
    list_0.append(str_0)
    dict_0 = None
    kw_arg_2 = module_0.keyword(**dict_0)
    call_1.kw

# Generated at 2022-06-25 22:32:23.216709
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    module_0.Call.args = call_0
    module_0.Call.keywords = call_0
    module_0.Call.func = call_0
    module_0.Call.starargs = call_0
    module_0.Call.kwargs = call_0
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:34.727246
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    dict_0 = {'elts': [1,2,3]}
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(**dict_0)

    # Assertion 1
    try:
        assert not starred_unpacking_transformer_0.visit_Call(call_0) is None
        print('Assertion 1: OK')
    except AssertionError:
        print('Assertion 1: KO')
    # Assertion 2

# Generated at 2022-06-25 22:32:41.182375
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_1 = StarredUnpackingTransformer(module_0.AST(**None))
    call_0 = module_1._split_by_starred(list_0)
    call_1 = module_1._prepare_lists(call_0)
    list_1 = module_1._merge_lists(call_1)
    list_2 = module_1.visit_List(list_0)
    assert list_1 != list_2
    assert list_1 == list_0
    assert list_2 == list_0


# Generated at 2022-06-25 22:32:52.172674
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    l_0 = module_0.List(**dict_0)
    l_1 = l_0
    l_2 = l_1
    l_3 = l_2
    l_4 = l_3
    l_5 = l_4
    l_6 = l_5
    l_7 = l_6
    l_8 = l_7
    l_9 = l_8
    l_10 = l_9
    l_11 = l_10
    l_12 = l_11
    l_13 = l_12
    l_14 = l_13
   

# Generated at 2022-06-25 22:32:56.326623
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:58.133326
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert False


# Generated at 2022-06-25 22:33:07.710948
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    dict_1 = None
    list_0 = [0]
    arg_0 = 'list_0'
    dict_1[arg_0] = list_0
    list_1 = [0]
    arg_1 = 'list_1'
    dict_1[arg_1] = list_1
    dict_2 = None
    dict_1['kwargs'] = dict_2
    dict_3 = None
    dict_1['keywords'] = dict_3
    call_0 = module_0.Call(**dict_1)
    call_1 = starred_unpacking_transformer

# Generated at 2022-06-25 22:33:19.560700
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    a_s_t_1 = module_0.AST(**dict_0)
    a_s_t_1._fields = ['args']
    a_s_t_2 = module_0.AST(**dict_0)
    a_s_t_2._fields = ['elts']
    a_s_t_2._attributes = ['ctx']
    a_s_t_3 = module_0.AST(**dict_0)
    a_s_t_3._fields = ['value']
    a_s_t_4 = module_0.AST(**dict_0)
    a_s_t_4._fields = ['func', 'args', 'keywords']
    a_

# Generated at 2022-06-25 22:33:31.015155
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    dict_a_s_t_0 = None
    a_s_t_0 = module_0.AST(**dict_a_s_t_0)
    try:
        dict_starred_unpacking_transformer_0 = {'a_s_t': a_s_t_0}
    except TypeError:
        dict_starred_unpacking_transformer_0 = {'a_s_t': a_s_t_0}
    StarredUnpackingTransformer(a_s_t_0=a_s_t_0)
    try:
        StarredUnpackingTransformer(**dict_starred_unpacking_transformer_0)
    except TypeError:
        StarredUnpackingTransformer(a_s_t=a_s_t_0)

# Generated at 2022-06-25 22:33:40.013624
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    module_test_case_0 = module_0.Module(body=[])
    call_0 = module_0.Call(func=module_0.Name(id='list'), args=[module_0.List(elts=[module_0.Starred(value=module_0.Name(id='list'), ctx=module_0.Load())])], keywords=[])
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:45.446158
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = None
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(args=[])
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_0 == call_1


# Generated at 2022-06-25 22:33:52.038441
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    global module_0
    import typed_ast._ast3 as module_0

    test_case_0()

# Generated at 2022-06-25 22:33:52.941441
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert True == True

# Generated at 2022-06-25 22:33:56.593955
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:34:01.882068
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:09.660713
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(func=module_0.Name(id='a'), args=[module_0.Starred(value=module_0.Name(id='b'))])
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:13.342849
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    list_1 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = list_1.visit_Call(list_0)


# Generated at 2022-06-25 22:34:23.185070
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # Test 1, with valid parameters
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)

    # Test 2, with valid parameters
    call_1 = module_0.Call()
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    starred_unpacking_transformer_1.visit_Call(call_1)

    # Test 3, with valid parameters
    call_2 = module_0.Call()
    a_s_t_2

# Generated at 2022-06-25 22:34:31.295482
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List(elts=[])
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call(func=None, args=[], keywords=[])
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:41.044240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_cases = [
        # Test case 0
        # (input='[2, *range(10), 1]'),
        # (output='[2, *(list(range(10))), 1]'),
    ]
    for i in range(len(test_cases)):
        # Set up test case
        input = test_cases[i].input
        expected_output = test_cases[i].output
        
        # Run test case
        output = StarredUnpackingTransformer(input).visit_List()
        
        # Check results
        assert output == expected_output, 'Test case {} failed: got {}, expected {}'.format(i, output, expected_output)

# Generated at 2022-06-25 22:34:46.195743
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:35:01.450592
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(args=[module_0.Name(id='a')])
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:35:08.102790
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = module_0
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert type(call_1) == module_0.Call


# Generated at 2022-06-25 22:35:12.095158
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Check for None
    assert starred_unpacking_transformer_0 is not None


# Generated at 2022-06-25 22:35:20.721323
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse('a = (*range(1), 2)')
    a_s_t_0 = module_0.body[0].value
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    module_1 = ast.parse('list(*range(1)) + [2]')
    a_s_t_1 = module_1.body[0].value
    assert starred_unpacking_transformer_0.visit_Call(a_s_t_0) == a_s_t_1


# Generated at 2022-06-25 22:35:21.681579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass


# Generated at 2022-06-25 22:35:23.019288
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("test_StarredUnpackingTransformer")

    test_case_0()

# Generated at 2022-06-25 22:35:25.665872
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:35:28.896873
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:33.438989
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_1 = module_0.List()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:35:39.403138
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:03.722516
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    list_0_0 = module_0.List()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1_0 = starred_unpacking_transformer_0.visit_List(list_0_0)
    assert type(list_1_0) == module_0.List


# Generated at 2022-06-25 22:36:08.967938
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:11.120437
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # test constructor with AST parameter
    ast_0 = AST()
    StarredUnpackingTransformer(ast_0)


# Generated at 2022-06-25 22:36:20.050865
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    doc_0 = """Should not change the tree if there are no starred expressions."""

    class MyTest(unittest.TestCase):
        def test(self):
            list_0 = module_0.List()
            list_0.elts = []
            a_s_t_0 = module_0.AST()
            a_s_t_0.body = []
            starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
            list_1 = starred_unpacking_transformer_0.visit_List(list_0)
            self.assertEqual(list_1, list_0)
    test_case_0 = MyTest()
    test_case_0.test()


# Generated at 2022-06-25 22:36:29.501071
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = StarredUnpackingTransformer.__module__
    module_name_0 = module_0.split('.')[-1]

    def do_test(test_fn, input_0, expected, msg=None):
        if msg is None:
            msg = ''
        else:
            msg = ' (%s)' % msg

        # Call test function
        actual = test_fn(input_0)

        # Check results
        if actual != expected:
            raise AssertionError('%s.%s%s: %r != %r' % (module_name_0, test_fn.__name__, msg, actual, expected))

    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpacking

# Generated at 2022-06-25 22:36:39.676060
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = importlib.import_module("typed_ast._ast3")
    # Test with values 0, 1
    # int.__add__ is expected to raise a TypeError in case 1

# Generated at 2022-06-25 22:36:49.967035
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test method with default values
    list_0 = module_0.List()
    arg_1 = module_0.Name()
    arg_1.id = "thing"
    arg_0 = module_0.Tuple()
    arg_0.elts.append(arg_1)
    call_0 = module_0.Call()
    call_0.func = list_0
    call_0.args.append(arg_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


if __name__ == '__main__':
    test_case_0()
    test_

# Generated at 2022-06-25 22:36:55.512944
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast._ast3 as module_0
    num_0 = module_0.Num()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    call_0.args = [num_0]
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:37:01.233215
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert isinstance(starred_unpacking_transformer_0, module_0.NodeTransformer)


# Generated at 2022-06-25 22:37:04.007285
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    pass


# Generated at 2022-06-25 22:37:49.792566
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    assert a_s_t_0 is a_s_t_1
    assert a_s_t_0 == a_s_t_1
    assert not (a_s_t_0 != a_s_t_1)
    assert str(a_s_t_0) == str(a_s_t_1)
    assert repr(a_s_t_0) == repr(a_s_t_1)
    assert hash(a_s_t_0) == hash(a_s_t_1)
    list_0 = module_0.List()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:37:58.814202
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    try:
        list_0 = module_0.List()
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_0)
        list_1 = starred_unpacking_transformer_1.visit_List(list_0)
    except Exception as e:
        assert type(e) is module_0.UnsupportedOperationError


# Generated at 2022-06-25 22:38:04.372605
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:38:08.242780
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    result_0 = starred_unpacking_transformer_0.visit_List(list_0)
    assert result_0 is not None


# Generated at 2022-06-25 22:38:10.547350
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print('---> test_StarredUnpackingTransformer_visit_List')
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:38:18.777438
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test_case_0():
        list_0 = [1, 2, 3]
        call_0 = module_0.Call(list_0, [], [])
        a_s_t_0 = module_0.AST()
        call_1 = a_s_t_0.Call(list_0, [], [])
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        call_2 = starred_unpacking_transformer_0.visit_Call(call_1)

    def test_case_1():
        list_0 = [1, 2, 3]
        call_0 = module_0.Call(list_0, [], [])
        a_s_t_0 = module_0.AST()
        call_1 = a_

# Generated at 2022-06-25 22:38:20.082277
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True

print("<--")
print(__name__)
print("-->")

# Generated at 2022-06-25 22:38:24.586903
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    starred_unpacking_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:38:30.646209
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Passes a trivial case of two arguments, one of which is a Starred expression
    # object
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args = ["1", "2"]
    call_0.args[1] = module_0.Starred("3")
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:38:37.215425
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:39:58.546292
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    # Expected instance metadata:
    # :class: StarredUnpackingTransformer
    # :func: visit_List
    # :func: visit_Call
    # :func: _has_starred
    # :func: _prepare_lists
    # :func: _merge_lists
    # :func: _split_by_starred
    # :func: _to_sum_of_lists
    # :lineno: 19
    # :module: pyminifier.transformers.star

# Generated at 2022-06-25 22:39:59.572157
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # TODO: implement
    assert True


# Generated at 2022-06-25 22:40:09.829351
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    target_0 = (3, 4)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    assert starred_unpacking_transformer_0.tree == a_s_t_0
    assert starred_unpacking_transformer_0.target == target_0
    assert not starred_unpacking_transformer_0.tree_changed

    module_1 = module_0.Module()
    a_s_t_1 = module_0.AST(module_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

    assert starred_unpacking_transformer_1.tree == a_s_t_1
    assert starred_unpacking_

# Generated at 2022-06-25 22:40:17.764917
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert (isinstance(list_1, module_0.List))


# Generated at 2022-06-25 22:40:22.782226
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:40:25.261724
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = StarredUnpackingTransformer()
    list_0 = module_0.visit_List(list_0)


# Generated at 2022-06-25 22:40:32.984808
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast._ast3 as module_0
    module_1 = module_0
    int_0 = module_1.Int()
    list_0 = module_1.List()
    a_s_t_0 = module_1.AST()
    call_0 = module_1.Call()
    module_2 = module_1
    list_1 = module_2.List()
    module_3 = module_2
    module_4 = module_3
    name_0 = module_4.Name()
    module_5 = module_4
    module_6 = module_5
    arg_0 = module_6.arg()
    arg_0.s = "foo"
    arg_0.arg = "foo"
    arg_0.annotation = None
    arg_1 = module_6.arg()


# Generated at 2022-06-25 22:40:38.574248
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    dict_0 = dict()
    dict_0.clear()
    dict_0['a'] = module_0.Call()
    dict_0['b'] = module_0.Call()
    dict_0['c'] = module_0.Call()
    dict_0['d'] = module_0.Call()
    dict_0['e'] = module_0.Call()
    dict_0['f'] = module_0.Call()
    dict_0['g'] = module_0.Call()
    dict_0['h'] = module_0.Call()
    dict_0['i'] = module_0.Call()
    dict_0['j'] = module_0.Call()
    dict_0['k'] = module_0.Call()
    dict_0['l'] = module_0.Call()
    dict_

# Generated at 2022-06-25 22:40:43.294190
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:40:48.614472
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

if __name__ == '__main__':
    test_StarredUnpackingTransformer()
    test_case_0()