

# Generated at 2022-06-25 22:31:22.516305
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    a_s_t_1 = ast.Call(func=None, args=list_0, keywords=None)
    a_s_t_2 = starred_unpacking_transformer_0.visit_Call(a_s_t_1)
    assert a_s_t_2 is not None


# Generated at 2022-06-25 22:31:27.738132
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_0 = ast.Call()
    a_s_t_1 = starred_unpacking_transformer_0.visit(node_0)
    ast.fix_missing_locations(a_s_t_1)


# Generated at 2022-06-25 22:31:37.346631
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse('')
    a_s_t_1 = ast.parse('')
    a_s_t_2 = ast.parse('')
    a_s_t_3 = ast.parse('')
    a_s_t_4 = ast.parse('')
    a_s_t_5 = ast.parse('')

    assert (a_s_t_0 == a_s_t_1)
    assert (a_s_t_2 == a_s_t_3)
    assert (a_s_t_4 == a_s_t_5)


# Generated at 2022-06-25 22:31:40.353472
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    try:
        StarredUnpackingTransformer(a_s_t_0)
        assert False
    except ValueError:
        pass
    assert True


# Generated at 2022-06-25 22:31:49.574847
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    a_s_t_1 = None
    call_0 = ast.Call(args=a_s_t_1, keywords=[], func=ast.Name(id='a', ctx=ast.Load()), starargs=None, kwargs=None)
    result_0 = (starred_unpacking_transformer_0.visit_Call(call_0))
    assert result_0 == call_0
    assert isinstance(result_0, ast.Call)
    assert isinstance(result_0.args, list)
    assert result_0.args == []
    assert isinstance(result_0.keywords, list)
    assert result_0.keywords

# Generated at 2022-06-25 22:31:59.614880
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    token_0 = None
    module_0 = ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=1)], keywords=[]), ctx=ast.Load()), ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=3)], keywords=[]), ctx=ast.Load())], keywords=[]))])
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(module_0)

# Generated at 2022-06-25 22:32:12.096911
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Statement(s) to be executed
    print_1 = None
    args_2 = [None]
    keywords_3 = None
    func_4 = None
    call_5 = ast.Call(print_1, args_2, keywords_3, func_4)
    # Target call of method StarredUnpackingTransformer.visit_Call
    result_6 = starred_unpacking_transformer_0.visit_Call(call_5)
    # Assertion(s)
    assert result_6 is call_5


# Generated at 2022-06-25 22:32:15.752356
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List()
    starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:32:27.178286
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = (
        ast.Call(
            func=ast.Name(id='print'),
            args=[ast.Name(id='range'), ast.Starred(value=ast.Name(id='range'))],
            keywords=[]
        )
    )
    a_s_t_2 = (
        ast.Call(
            func=ast.Name(id='print'),
            args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='range')], keywords=[]))],
            keywords=[]
        )
    )
    a_s_t_3 = starred_

# Generated at 2022-06-25 22:32:39.841418
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = ast.parse("a = [2, *range(10), 1]")
    a_s_t_1.body[0].value.elts[1].value.func.id = 'list'
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = ast.parse("a = [2] + list(range(10)) + [1]")
    starred_unpacking_transformer_1.visit_List(a_s_t_1.body[0].value)
    assert [n for n in a_s_t_1.body] == [n for n in a_s_t_2.body], 'AssertionError'


# Generated at 2022-06-25 22:32:47.283383
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Call()
    assert isinstance(starred_unpacking_transformer_0.visit_Call(a_s_t_1), ast.Call)


# Generated at 2022-06-25 22:32:55.850924
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case = ast.parse('''list(*list(2, 3, 4))''').body[0]
    transformer = StarredUnpackingTransformer(None)
    assert transformer._has_starred(test_case.args[0].value.elts)

    expected = ast.parse('''list(*[list(2), list(3), list(4)])''').body[0]
    actual = transformer.visit(test_case)
    assert ast.dump(expected) == ast.dump(actual)


if __name__ == '__main__':
    test_case_0()
    test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-25 22:33:05.347986
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # some class to test
    class Test():
        pass

    # Call
    test_str = "test(*args)"
    test_ast = ast.parse(test_str)
    test_node = test_ast.body[0].value
    test_result = starred_unpacking_transformer_0.visit(test_node)
    test_expected = ast.parse("test(*([args]))").body[0].value

    assert test_result == test_expected


# Generated at 2022-06-25 22:33:12.565740
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    node_0 = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Name(id='args')],
        keywords=[])

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    result = starred_unpacking_transformer_0.visit_Call(node_0)
    assert isinstance(result, ast.Call)


# Generated at 2022-06-25 22:33:19.917492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_Call_0 = None
    try:
        ast_Call_return_val_0 = starred_unpacking_transformer_0.visit_Call(ast_Call_0)
    except Exception as e:
        print(e)
        print("Unhandled exception in StarredUnpackingTransformer.visit_Call()")


# Generated at 2022-06-25 22:33:23.285770
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Call
    test_case_0()

# Generated at 2022-06-25 22:33:30.109208
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    node_0 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range'))], keywords=[])
    node_1 = starred_unpacking_transformer_0.visit_Call(node_0)


# Generated at 2022-06-25 22:33:39.727869
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None                                         # type: ast.AST
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert starred_unpacking_transformer_0._tree_changed == False
    call_0 = ast.Call()
    starred_unpacking_transformer_0.visit_Call(call_0)
    assert starred_unpacking_transformer_0._tree_changed == False
    call_0.args = [ast.Starred()]
    starred_unpacking_transformer_0.visit_Call(call_0)
    # Check for expected values
    assert starred_unpacking_transformer_0._tree_changed == True
    

# Generated at 2022-06-25 22:33:49.130677
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = ast.parse('range(2, 4)')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = ast.parse('range(2, 4)')
    assert_equals(starred_unpacking_transformer_1.visit(a_s_t_2), a_s_t_2)
    a_s_t_3 = ast.parse('print(*range(2, 4))')
    a_s_t_4 = ast.parse('print(*(list(range(2, 4))))')
    assert_equals(starred_unpacking_transformer_1.visit(a_s_t_3), a_s_t_4)
    a_s_t_

# Generated at 2022-06-25 22:33:52.582235
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

# Generated at 2022-06-25 22:34:05.075438
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = ast.parse('[2, *range(10)]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.parse('print(*range(1), *range(3))')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Unit tests for StarredUnpackingTransformer')
    parser.add_argument('-t', '--test-case', type=int, default=0)
    args = parser.parse_args()
    if args.test_case == 0:
        test_case_0()
    el

# Generated at 2022-06-25 22:34:06.109308
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:34:12.009628
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List()
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    try:
        assert list_0 == list_1
    except AssertionError as e:
        print('Unexpected Exception Raised!')


# Generated at 2022-06-25 22:34:13.935763
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    assert(isinstance(StarredUnpackingTransformer(a_s_t_0), StarredUnpackingTransformer))


# Generated at 2022-06-25 22:34:24.380129
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Call()
    a_s_t_2 = None
    a_s_t_3 = ast.Starred(value=a_s_t_2)
    a_s_t_4 = None
    a_s_t_5 = ast.Starred(value=a_s_t_4)
    a_s_t_6 = ast.Call()
    a_s_t_1.args.append(a_s_t_3)
    a_s_t_1.args.append(a_s_t_5)

# Generated at 2022-06-25 22:34:32.096554
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse("")
    StarredUnpackingTransformer_a = StarredUnpackingTransformer(a_s_t_0)
    list_node_StarredUnpackingTransformer_a = ast.List(elts=[], ctx=ast.Load())
    StarredUnpackingTransformer_a.visit_List(list_node_StarredUnpackingTransformer_a)


# Generated at 2022-06-25 22:34:40.866758
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse('''[2, *range(10), 1]''')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = starred_unpacking_transformer_0.visit(a_s_t_0)
    assert a_s_t_0 == ast.parse('''[2] + list(range(10)) + [1]'''), \
        "method visit_List of class StarredUnpackingTransformer didn't work"


# Generated at 2022-06-25 22:34:41.951638
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()



# Generated at 2022-06-25 22:34:54.281987
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    elts_0 = []
    list_0 = ast.List(elts = elts_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert(list_1 == list_0)

    elts_1 = [ast.Call(func=ast.Name(id='range'), args=[ast.Constant(value='a')], keywords=[])]
    list_2 = ast.List(elts = elts_1)
    list_3 = starred_unpacking_transformer_0.visit_List(list_2)
    assert(list_3 == list_2)

    elts_2

# Generated at 2022-06-25 22:34:59.912133
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    t_y_p_e___v_a_r_0 = StarredUnpackingTransformer(a_s_t_0)
    assert t_y_p_e___v_a_r_0._tree is None
    assert not t_y_p_e___v_a_r_0._tree_changed


# Generated at 2022-06-25 22:35:07.251419
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None
    result = starred_unpacking_transformer_0.visit_List(a_s_t_1)
    import typed_ast.ast3 as ast
    result_0 = None
    assert isinstance(result, ast.List) == result_0


# Generated at 2022-06-25 22:35:11.422025
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(
        a_s_t_0)
    test_case_0()

# Unit Test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:35:13.452553
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()
    print("Constructor of StarredUnpackingTransformer is ok")


# Generated at 2022-06-25 22:35:14.447413
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:35:15.610790
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()



# Generated at 2022-06-25 22:35:16.211539
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-25 22:35:19.485639
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("testing method StarredUnpackingTransformer.visit_Call")
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:35:23.805852
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:24.473976
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()



# Generated at 2022-06-25 22:35:29.097529
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    func_0 = ast.Name(id='foo')
    call_0 = ast.Call(func=func_0, args=[], keywords=[])
    actual = starred_unpacking_transformer_0.visit_Call(call_0)
    assert actual == call_0


# Generated at 2022-06-25 22:35:41.213591
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Input Parameters

    a_s_t_0 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])

    # Instantiate a StarredUnpackingTransformer
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Method under test
    result = starred_unpacking_transformer_0.visit_Call(a_s_t_0)

    # Check Result
    assert result == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-25 22:35:50.999160
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    function_name = 'purr'

    def run_test(description, input_node, expected_output_node, expected_tree_changed, expected_return_value):
        assert description != ''
        print(description)

        try:
            output_node = starred_unpacking_transformer_1.visit_Call(input_node)
            assert output_node == expected_output_node
            assert starred_unpacking_transformer_1._tree_changed == expected_tree_changed
            assert output_node == expected_return_value

            print('Success')
        except Exception as e:
            print('Error: ' + str(e))
            raise e


# Generated at 2022-06-25 22:35:53.416327
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)



# Generated at 2022-06-25 22:35:57.995180
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    try:
        from typed_ast import ast3 as ast
    except:
        pass
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert starred_unpacking_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:36:09.160776
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    for lst in [ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='a')), ast.Num(n=1)], ctx=ast.Load()), ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='a')), ast.Starred(value=ast.Name(id='b')), ast.Num(n=1)], ctx=ast.Load())]:
        assert isinstance(lst, ast.List)
        assert isinstance(lst.ctx, ast.Load)
        elts = lst.elts
        assert elts

        if hasattr(lst, 'targets'):
            targets = lst.targets
            assert targets


# Generated at 2022-06-25 22:36:14.684773
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = ast.parse('[2, *range(10), 1]')
    print(ast.dump(a_s_t_2))
    print(ast.dump(starred_unpacking_transformer_1.visit(a_s_t_2)))


# Generated at 2022-06-25 22:36:21.494316
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    assert_equals(True,
                  StarredUnpackingTransformer.is_target(a_s_t_0))
    assert_equals(False,
                  StarredUnpackingTransformer.is_target(3))
    assert_equals(False,
                  StarredUnpackingTransformer.is_target(3.0))
    assert_equals(True,
                  StarredUnpackingTransformer.is_target(3.4))
    assert_equals(False,
                  StarredUnpackingTransformer.is_target(a_s_t_0))
    assert_equals(False,
                  StarredUnpackingTransformer.is_target((3,4)))
    assert_equals(False,
                  StarredUnpackingTransformer.is_target(None))

#

# Generated at 2022-06-25 22:36:28.239271
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    a_s_t_1 = ast.Call()
    a_s_t_1.args = []
    
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    try:
        starred_unpacking_transformer_0.visit(a_s_t_1)
    except Exception as e:
        msg = e.args[0]
    """ensure return type"""
    assert isinstance(msg, ast.Call)


# Generated at 2022-06-25 22:36:31.411309
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(None)
    # test arguments
    # test outputs
    # test return
    assert starred_unpacking_transformer_0.visit_Call(None) == None


# Generated at 2022-06-25 22:36:37.996773
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # parameters
    print("Test if visit_Call works...")
    
    a_s_t_0 = ast.parse("print(*range(1), *range(3))")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call()
    
    assert(starred_unpacking_transformer_0.tree_changed == True)
    

# Generated at 2022-06-25 22:36:52.386191
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    t_a_s_t_0 = None
    list_0 = ast.List(elts=t_a_s_t_0)
    assert starred_unpacking_transformer_0.visit_List(list_0) is list_0

    list_1 = ast.List(elts=[ast.Name(id='a')])
    assert starred_unpacking_transformer_0.visit_List(list_1).elts == list_1.elts

    value_0 = ast.Num(n=1)
    starred_0 = ast.Starred(value=value_0)

# Generated at 2022-06-25 22:37:03.432231
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.parse('''[2, *range(10), 1]''').body[0].value

    # Invoke method
    result = starred_unpacking_transformer_0.visit_List(list_0)

    # Check attributes
    assert isinstance(result, ast.List)
    assert isinstance(result.elts[0], ast.Num)
    assert isinstance(result.elts[1], ast.Call)
    assert isinstance(result.elts[2], ast.Num)

    # Check values
    assert result.elts[0].n == 2

# Generated at 2022-06-25 22:37:10.640876
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Input parameters
    a_s_t_0 = None
    a_s_t_0 = None
    # Output parameters
    # Call function(s)
    try:
        _ = StarredUnpackingTransformer(a_s_t_0).visit_Call(a_s_t_0)
    except Exception as e:
        print("Exception for 'StarredUnpackingTransformer(a_s_t_0).visit_Call(a_s_t_0)'")
        raise e


# Generated at 2022-06-25 22:37:18.786373
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Attribute()
    a_s_t_1.attr = str()
    a_s_t_1.value = ast.Starred()
    a_s_t_2 = ast.Call()
    a_s_t_2.args = [a_s_t_1]
    a_s_t_2.func = ast.Attribute()
    a_s_t_2.func.attr = str()
    a_s_t_2.func.value = str()
    a_s_t_2.keywords = [ast.keyword()]

# Generated at 2022-06-25 22:37:22.105004
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    try:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:37:31.932521
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking_transformer import StarredUnpackingTransformer
    a_s_t_tree_0 = None
    a_s_t_0 = ast.parse(
'''
"""Example"""
print(1, *[2] + [3, 4] + list(range(5)))
'''
    )
    with BaseNodeTransformer(a_s_t_0) as star_0:
        if star_0 is None:
            star_0 = StarredUnpackingTransformer(a_s_t_0)
        star_0.visit(a_s_t_tree_0)

# Generated at 2022-06-25 22:37:36.418846
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    try:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    except Exception as e:
        print(e)
    else:
        pass


# Generated at 2022-06-25 22:37:38.911730
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:45.515461
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():


    # SUT
    try:
        from . import usercode
        from . import testcode_starred_unpacking_transformer_visit_list as testcode
    except ImportError:
        import usercode
        import testcode_starred_unpacking_transformer_visit_list as testcode


    # set up context
    import ast
    import sys
    import random
    import textwrap
    import pycodestyle
    _ast = ast.parse(textwrap.dedent(usercode.__doc__))
    _codeobj = compile(_ast, 'usercode', 'exec')
    _mod = sys.modules['usercode'] = types.ModuleType('usercode')
    exec(_codeobj, _mod.__dict__)
    _mod.random.seed(0)


    # SUT Call
   

# Generated at 2022-06-25 22:37:48.490588
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:38:03.007211
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Test the case where list is None
    a_s_t_1 = None
    assert starred_unpacking_transformer_0.visit_List(a_s_t_1) is None



# Generated at 2022-06-25 22:38:04.489098
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


test_StarredUnpackingTransformer()
test_case_0()

# Generated at 2022-06-25 22:38:08.353250
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None  # type: ast.AST
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    node_1 = None  # type: ast.Call
    StarredUnpackingTransformer.visit_Call(starred_unpacking_transformer_1, node_1)


# Generated at 2022-06-25 22:38:10.848328
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # No error


# Generated at 2022-06-25 22:38:12.881874
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test case 0
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:38:19.497074
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = []
    ast.List(elts=list_0)
    list_1 = list_0
    star_arg_0 = ast.Starred(value=list_1)
    list_2 = [star_arg_0]
    list_3 = list_2
    ast.List(elts=list_3)
    starred_unpacking_transformer_0.visit_List(list_3)


# Generated at 2022-06-25 22:38:23.423824
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    transform_source_code_0 = None
    change_tree_0 = StarredUnpackingTransformer(a_s_t_0).visit(transform_source_code_0)
    # AssertionError: Expected <class 'ast.List'>, got <class 'NoneType'>


# Generated at 2022-06-25 22:38:26.409997
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    print(starred_unpacking_transformer_0)

# Generated at 2022-06-25 22:38:29.609288
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    s_c_0 = None
    a_s_t_0 = None
    s_u_t_0 = StarredUnpackingTransformer(a_s_t_0)
    s_u_t_0.visit_Call(s_c_0)


# Generated at 2022-06-25 22:38:41.748218
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Test case where List.elts is none
    a_s_t_1 = ast.List()
    try:
        starred_unpacking_transformer_0.visit_List(a_s_t_1)
    except AssertionError:
        pass
    # Test case where List.elts is empty
    a_s_t_2 = ast.List(elts=[])
    try:
        starred_unpacking_transformer_0.visit_List(a_s_t_2)
    except AssertionError:
        pass
    # Test case where List.elts is empty

# Generated at 2022-06-25 22:39:11.724844
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Code snippet:
    #     [2, *range(10), 1]
    # Expected result:
    #     [2] + list(range(10)) + [1]
    def e_ast_0(v):
        return [5, v, 2]
    a_list_0 = ast.List(
        elts=[ast.Num(n=2), ast.Starred(value=ast.Call(
            func=ast.Name(id='range'), args=[ast.Num(n=10)])), ast.Num(n=1)])
    [a_list_0_0, a_list_0_1] = a_list_0.el

# Generated at 2022-06-25 22:39:16.554882
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.List(elts=[])
    assert starred_unpacking_transformer_0.visit_List(a_s_t_1) is a_s_t_1


# Generated at 2022-06-25 22:39:27.529043
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    list_0 = ast.List()
    list_0_0 = ast.Attribute()
    list_1 = ast.List()
    list_2 = ast.List()
    list_2_0 = ast.Attribute()
    list_3 = ast.List()
    list_4 = ast.List()
    list_4_0 = ast.Attribute()
    list_5 = ast.List()
    list_6 = ast.List()
    list_6_0 = ast.Attribute()
    list_7 = ast.List()
    list_8 = ast.List()
    list_8_0 = ast.Attribute()
    list_9 = ast.List()
   

# Generated at 2022-06-25 22:39:28.721356
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:39:32.033463
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # There is no code to check
    assert True
    return


# Generated at 2022-06-25 22:39:34.894204
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # a_s_t_0 = None
    # starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:39:38.607539
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast.parse('[2, *range(10), 1]')


# Generated at 2022-06-25 22:39:41.692464
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:39:51.374559
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = ast.parse('''
        print(*range(1), *range(42))
    ''')

    StarredUnpackingTransformer(t).visit(t)


# Generated at 2022-06-25 22:39:52.110716
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert_raises(
        StarredUnpackingTransformer,
        test_case_0
    )


# Generated at 2022-06-25 22:40:58.101352
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None
    a_s_t_15 = None
    a_s_t_16 = None
    a_s_t_17 = None
    a_s_t_18 = None
   

# Generated at 2022-06-25 22:41:00.250440
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:41:01.055861
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()



# Generated at 2022-06-25 22:41:08.089483
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_expr_0 = None
    ast_expr_1 = None
    ast_expr_list_0 = [ast_expr_0, ast_expr_1]
    ast_list_0 = ast.List(elts=ast_expr_list_0)
    starred_unpacking_transformer_0.visit(ast_list_0)
    assert(starred_unpacking_transformer_0._tree_changed == False)


# Generated at 2022-06-25 22:41:10.960813
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = ast.Call()
    call_2 = starred_unpacking_transformer_1.visit_Call(call_1)
