

# Generated at 2022-06-25 22:31:19.063711
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        test_case_0()
    except Exception:
        __tracebackhide__ = True
        raise

# Generated at 2022-06-25 22:31:23.928599
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(None, [], [])
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_1 is not None


# Generated at 2022-06-25 22:31:34.586459
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:31:40.815502
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    list_0.elts = [module_0.Name(), module_0.Str()]
    starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:31:49.903541
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:31:51.004512
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:32:00.349093
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    StarredUnpackingTransformer_0_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0_0 = [module_0.parse(src='print(*range(1), *range(3))', mode='eval').body]
    func_0_0 = lambda node: StarredUnpackingTransformer_0_0.visit_Call(node)
    ast_0_0 = StarredUnpackingTransformer_0_0.modify(list_0_0, func_0_0)
    expected_0_0 = module_0.parse(src='print(*(list(range(1)) + list(range(3))))', mode='eval').body
    assert ast_0_0 == expected_0_0


# Generated at 2022-06-25 22:32:11.993109
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(args=[], keywords=[])
    # Test attribute args
    try:
        call_0.args = 'str'
        assert False
    except AttributeError:
        pass
    # Test attribute keywords
    try:
        call_0.keywords = 'str'
        assert False
    except AttributeError:
        pass
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:20.253130
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = [module_0.Starred()]
    call_0.keywords = [module_0.keyword()]
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert type(starred_unpacking_transformer_0.visit_Call(call_0)) is module_0.Call

# Generated at 2022-06-25 22:32:26.652716
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call()
    module_0.Call(starred_unpacking_transformer_0.visit_Call(a_s_t_1))


# Generated at 2022-06-25 22:32:34.112205
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    method_result = transformer.visit_List(a_s_t_0)
    assert True


# Generated at 2022-06-25 22:32:40.950964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # setup
    a_s_t_0 = module_0.StarredUnpackingTransformer(a_s_t_0, [], [])
    a_s_t_1 = module_0.Call(a_s_t_0, [], [], [])

    # test
    a_s_t_2 = a_s_t_0.visit_Call(a_s_t_1)

    # verify
    assert isinstance(a_s_t_2, module_0.Call)


# Generated at 2022-06-25 22:32:51.950159
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = ast.Module()
    a_s_t_1.body = [ast.Expr(value=ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)], ctx=ast.Load()))]
    classes_0 = (StarredUnpackingTransformer,)
    a_s_t_0_result = a_s_t_0.parse(a_s_t_0.dump(a_s_t_1), classes=classes_0)

# Generated at 2022-06-25 22:32:58.825800
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    node = module_0.List(module_0.Expr(module_0.Starred(module_0.Name(module_0.Load(), module_0.Name(module_0.Store(), 'range', module_0.Param(), module_0.Load()), module_0.Store()), 0))[0])
    expected = a_s_t_0.expr(value=a_s_t_0.call(func=a_s_t_0.name(id='range'), args=[], keywords=[]))
    obj = StarredUnpackingTransformer()
    actual = obj.visit_List(node)
    assert actual == expected


# Generated at 2022-06-25 22:33:03.638758
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    node_0 = a_s_t_0.List(elts=[a_s_t_0.Constant(value=1)])
    transformer_0 = StarredUnpackingTransformer()
    result_0 = transformer_0.visit(node_0)


# Generated at 2022-06-25 22:33:15.947831
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    c_l_a_s_s_0 = a_s_t_0.ClassDef(name="Class0")
    c_l_a_s_s_0.body.append(module_0.FunctionDef(name="test_StarredUnpackingTransformer_visit_Call",
        args=module_0.arguments(args=[], vararg=None, kwarg=None, defaults=[], kw_defaults=[]),
        body=[], decorator_list=[], returns=None))
    c_l_a_s_s_1 = a_s_t_0.ClassDef(name="Class1")

# Generated at 2022-06-25 22:33:18.488821
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected_result = StarredUnpackingTransformer
    actual_result = StarredUnpackingTransformer()
    assert type(actual_result) == expected_result


# Generated at 2022-06-25 22:33:19.562298
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()

# Generated at 2022-06-25 22:33:31.014432
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Input parameters
    node_0 = module_0.Call()
    
    obj_0 = StarredUnpackingTransformer()
    _a_s_t_0_0 = module_0.Call()
    obj_0.visit(_a_s_t_0_0)
    
    _a_s_t_0_0 = module_0.Call()
    obj_0.visit(_a_s_t_0_0)
    
    _a_s_t_0_0 = module_0.Call()
    obj_0.visit(_a_s_t_0_0)
    
    _a_s_t_0_0 = module_0.Call()
    obj_0.visit(_a_s_t_0_0)
    
    _a_s_t

# Generated at 2022-06-25 22:33:40.013288
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_10 = test_case_0()
    a_s_t_11 = a_s_t_10.Call()
    a_s_t_12 = a_s_t_10.Name()
    a_s_t_11.func = a_s_t_12

    t_r_n_0 = StarredUnpackingTransformer.visit_Call(a_s_t_10, a_s_t_11)

    assert t_r_n_0.func == a_s_t_12
    assert t_r_n_0.args == ()
    assert t_r_n_0.keywords == ()


# Generated at 2022-06-25 22:33:46.216671
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    new_StarredUnpackingTransformer = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:33:53.747479
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.List(module_0.Starred(module_0.Starred(module_0.Name('a', module_0.Load()), module_0.Load()), module_0.Load()), module_0.Load())
    a_s_t_2 = module_0.BinOp(module_0.List(module_0.expr(), module_0.Load()), module_0.BinOp(module_0.Call(module_0.Name('list', module_0.Load()), [module_0.Name('a', module_0.Load())], []), module_0.List(module_0.expr(), module_0.Load()), module_0.Add()), module_0.Add())

# Generated at 2022-06-25 22:34:00.676937
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    s = StarredUnpackingTransformer()
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Call(func=module_0.Name(id='a', ctx=module_0.Load()), args=[module_0.Name(id='b', ctx=module_0.Load())], keywords=[])
    assert s.visit_Call(a_s_t_1) == a_s_t_0


# Generated at 2022-06-25 22:34:01.684768
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert True


# Generated at 2022-06-25 22:34:11.717746
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_0.type_ignores.append('A')
    a_s_t_0.type_ignores.append('B')
    a_s_t_0.type_ignores.append('C')
    a_s_t_0.type_ignores.append('D')
    a_s_t_0.type_ignores.append('E')
    a_s_t_0.type_ignores.append('F')
    s_t_0 = StarredUnpackingTransformer()
    a_s_t_1 = s_t_0.visit_List(a_s_t_0)
    

# Generated at 2022-06-25 22:34:18.862952
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.List(elts=[])
    a_s_t_1 = module_0.List(elts=[])
    a_s_t_2 = module_0.List(elts=[])
    a_s_t_3 = module_0.List(elts=[])
    a_s_t_4 = module_0.List(elts=[])
    a_s_t_5 = module_0.List(elts=[])
    a_s_t_6 = module_0.List(elts=[])
    a_s_t_7 = module_0.List(elts=[])
    a_s_t_8 = module_0.List(elts=[])
    a_s_t_9 = module_0.List(elts=[])

# Generated at 2022-06-25 22:34:31.343636
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    try:
        import ast
    except:
        import typed_ast.ast3 as ast

    source_0 = [
        ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[
                ast.Starred(
                    value=ast.Name(id='range', ctx=ast.Load()),
                    ctx=ast.Load()
                ),
                ast.Starred(
                    value=ast.Name(id='range', ctx=ast.Load()),
                    ctx=ast.Load()
                )
            ],
            keywords=[]
        )
    ]

# Generated at 2022-06-25 22:34:43.453880
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.Call()
    a_s_t_1 = ast.Call()
    a_s_t_2 = ast.expr()
    a_s_t_3 = ast.Starred()
    a_s_t_4 = ast.expr()
    a_s_t_5 = ast.expr()
    a_s_t_6 = ast.expr()
    a_s_t_7 = ast.expr()
    a_s_t_3.value = a_s_t_7
    a_s_t_6.args = [a_s_t_3]
    a_s_t_6.keywords = []
    a_s_t_1.func = a_s_t_6

# Generated at 2022-06-25 22:34:46.620642
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    assert ((StarredUnpackingTransformer()).visit_List(a_s_t_0.List()) == a_s_t_0.List())


# Generated at 2022-06-25 22:34:55.674870
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Call()
    a_s_t_2 = module_0.Name()
    a_s_t_1.args = [a_s_t_2]
    a_s_t_3 = module_0.Starred()
    a_s_t_1.args = [a_s_t_3]
    a_s_t_4 = StarredUnpackingTransformer()
    a_s_t_4.visit(a_s_t_1)


# Generated at 2022-06-25 22:35:03.772707
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:35:08.657483
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:14.028078
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert list_0 is list_1


# Generated at 2022-06-25 22:35:23.488998
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arguments
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    list_1 = [list_0]
    call_0 = module_0.Call(func=None, args=list_1, keywords=[], starargs=None, kwargs=None)
    a_s_t_1 = module_0.AST()
    p_0 = module_0.parse('', mode='exec')
    a_s_t_2 = module_0.AST()
    # Function call
    call_1 = visit_Call(a_s_t_1, call_0)
    # Return call
    return call_1


# Generated at 2022-06-25 22:35:31.865729
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert list_0 == list_1
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_2 = starred_unpacking_transformer_1.visit_List(list_1)



if __name__ == '__main__':
    test_case_0()
    # test_StarredUnpackingTransformer_visit_List()

# Generated at 2022-06-25 22:35:36.533502
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:44.656143
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    module_0.Starred.value(call_1)
    call_2 = module_0.Call()
    call_3 = starred_unpacking_transformer_0.visit_Call(call_2)


# Generated at 2022-06-25 22:35:49.141999
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:52.038559
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module_0 = ast.AST()
    try:
        a_s_t_0 = StarredUnpackingTransformer(module_0)
    except TypeError:
        raise AssertionError()


# Generated at 2022-06-25 22:35:57.348707
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:12.153669
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse("list(range(10))")
    call_0 = module_0.body[0].value
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)



# Generated at 2022-06-25 22:36:14.591470
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Inits py_ast by AST()
    py_ast = AST()

    # Tests constructor
    StarredUnpackingTransformer(py_ast)

# Generated at 2022-06-25 22:36:16.839582
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[*range(1), 2, *range(3), *range(4)]")
    StarredUnpackingTransformer(tree).visit(tree)

# Generated at 2022-06-25 22:36:24.818956
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    l_0 = lambda: None
    l_1 = lambda: None
    l_2 = lambda: None
    l_3 = lambda: None
    call_0.args = []
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_1.args == []
    call_0.args.append(list_0)
    call_2 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_2.args == [list_0]

# Generated at 2022-06-25 22:36:25.745539
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:36:30.044239
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:36:40.216420
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # if not self._has_starred(node.elts):
    #     return self.generic_visit(node)  # type: ignore
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    # else:
    #     self._tree_changed = True
    #     return self.generic_visit(self._to_sum_of_lists(node.elts))  # type: ignore
    list_2 = module_0.List()
    starred_0 = module_0.Starred()

# Generated at 2022-06-25 22:36:47.705531
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert_equals(list_0, starred_unpacking_transformer_0.visit_List(list_0))
    # When
    call_0 = module_0.Call()
    list_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:57.749958
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_0)
    eval('''starred_unpacking_transformer_1.visit_List(list_0)''')
    assert(str(type(starred_unpacking_transformer_0)) == "<class 'typed_astunparse.unparser._Unparser'>")
    assert(str(starred_unpacking_transformer_0.target_tree) == '<typed_ast.ast3.Module object at 0x7f8d3f9c2240>')

# Generated at 2022-06-25 22:37:04.381987
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = module_0
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    call_0.args.append(list_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:17.528808
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_0 = module_0.Call(
        func=module_0.Name(
            id='print'
            ),
        args=[
            module_0.Starred(
                value=module_0.List(
                    elts=[
                        module_0.Str(
                            s='test'
                            )
                        ],
                    ctx=module_0.Load()
                    ),
                ctx=module_0.Load()
                )
            ],
        keywords=[]
        )
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:37:22.236982
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(1, 2, 3, *range(10))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:28.246650
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3), sep="-")'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:32.695480
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:37.913097
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'foo(1, *range(10), 2)'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:42.959277
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '(*range(1), 2, *range(3), *range(4))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

    # pylint: disable=comparison-with-itself
    assert var_1 == var_1


# Generated at 2022-06-25 22:37:47.714826
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    module_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(module_0)
    starred_unpacking_transformer_0.visit(module_0)


# Generated at 2022-06-25 22:37:52.058964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(1, 2, 3, *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:56.467449
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:01.273464
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:38:12.209988
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True # TODO: implement your test here

if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-25 22:38:19.456170
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(2), 3)'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = var_0.name
    var_2 = var_0.args
    var_3 = var_2[0]
    var_4 = var_3.value
    var_5 = var_4.id
    var_6 = var_0.args
    var_7 = var_6[0]
    var_8 = var_7.elts
    var_9 = var_8[0]

# Generated at 2022-06-25 22:38:21.658192
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("")
    transformer = StarredUnpackingTransformer(node)
    assert not getattr(transformer, "_tree_changed", False)



# Generated at 2022-06-25 22:38:30.441488
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13)'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:38:42.327856
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ###
    # [1, 2, 3, *range(10)] --> [1, 2, 3] + list(range(10))
    ###
    code = '[1, 2, 3, *range(10)]'
    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer(tree)
    assert transformer.visit(tree).body[0].value.elts[0].value.elts[0].values[0].value.n == 1
    assert transformer.visit(tree).body[0].value.elts[1].elts[0].n == 2
    assert transformer.visit(tree).body[0].value.elts[2].elts[0].n == 3
    assert transformer.visit(tree).body[0].value.elts[3].func.id == 'list'


# Generated at 2022-06-25 22:38:46.430091
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'open(1, *[1])'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:49.805623
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        test_case_0()
    except:
        print('unittest failed')
        raise
    else:
        print('unittest passed')

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:38:53.295334
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(1, *range(2), 3)'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:01.120798
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, 3, *range(10)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert isinstance(var_1, module_0.List)
    assert len(var_1.elts) == 1
    assert isinstance(var_1.elts[0], module_0.BinOp)
    assert isinstance(var_1.elts[0].left, module_0.List)
    assert len(var_1.elts[0].left.elts) == 3

# Generated at 2022-06-25 22:39:02.087271
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:39:10.305371
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_1 = 'import ast'
    var_2 = module_0.parse(str_1)
    starre_unpacking_transformer_0 = StarredUnpackingTransformer(var_2)


# Generated at 2022-06-25 22:39:11.295737
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:39:15.874578
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print([1, *range(2), 3])'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:39:21.735403
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '1 + 2 + 3'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    assert isinstance(starred_unpacking_transformer_0, StarredUnpackingTransformer)


# Generated at 2022-06-25 22:39:28.830750
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[*range(1), 2, *range(3), *range(4)]'
    var_0 = module_0.parse(str_0)
    str_1 = 'list(range(1)) + [2] + list(range(3)) + list(range(4))'
    var_1 = module_0.parse(str_1)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    assert str(starred_unpacking_transformer_0.visit(var_0)) == str(var_1)


# Generated at 2022-06-25 22:39:30.251931
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:39:33.108339
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:41.523572
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(2))'
    module_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(module_0)
    module_0.body[0] = starred_unpacking_transformer_0.visit(module_0.body[0])

    str_1 = 'print(*(list(range(1)) + list(range(2))))'
    module_1 = module_1.parse(str_1)
    assert module_0 == module_1


# Generated at 2022-06-25 22:39:42.449845
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()
    return

# Generated at 2022-06-25 22:39:48.471439
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = typed_ast.ast3
    str_0 = '[*range(1), 2, *range(3), *range(4)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:00.248007
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[*range(1), 2, *range(3), *range(4)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.unparse(var_1)
    try:
        assert var_2 == 'list(range(1)) + [2] + list(range(3)) + list(range(4))'
    except AssertionError as var_3:
        print(var_3)




# Generated at 2022-06-25 22:40:08.408803
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[*range(1), 2, *range(3), *range(4)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    str_1 = '[1] + list(range(2)) + [3] + list(range(4))'
    var_1 = module_0.parse(str_1)
    assert_0 = module_0.dump(starred_unpacking_transformer_0.visit(var_0)) == module_0.dump(var_1)
    assert assert_0


# Generated at 2022-06-25 22:40:13.040035
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Testing constructor of class StarredUnpackingTransformer")
    var_0 = ast.parse('[*range(1), 2, *range(3), *range(4)]')
    var_1 = StarredUnpackingTransformer(var_0)



# Generated at 2022-06-25 22:40:21.055117
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = 'print([1, 2, 3])'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

    str_1 = 'print([1, 2, 3, *range(3), 4, 5, 6, *range(3)])'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:40:29.588597
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3), end="\\n")'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_Call(module_0.parse(str_0).body[0].value)
    str_1 = str(var_1)
    class_0 = StarredUnpackingTransformer
    module_0.dump(module_0.parse(str_1).body[0].value)
    str_2 = '_StarredUnpackingTransformer_visit_Call_var_0 = list(range(1)) + list(range(3))'

# Generated at 2022-06-25 22:40:34.160666
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # call_0 is a Call(func=Name(id='print'), args=[*range(1), *range(3)], keywords=[])
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    var_1 = StarredUnpackingTransformer(var_0)
    call_0 = var_1.visit(var_0)


# Generated at 2022-06-25 22:40:42.115787
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[1, 2, *range(5)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert isinstance(var_1, module_0.List)
    var_2 = var_1.elts
    assert len(var_2) == 3
    assert isinstance(var_2[0], module_0.Num)
    assert var_2[0].n == 1
    assert isinstance(var_2[1], module_0.Num)
    assert var_2[1].n == 2
    assert isinstance(var_2[2], module_0.BinOp)
   

# Generated at 2022-06-25 22:40:50.820342
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'hello(*range(3))'
    var_0 = module_0.parse(str_0)
    var_1 = StarredUnpackingTransformer(var_0)
    var_2 = var_1.visit(var_0)
    var_3 = module_0.dump(var_2)
    print(str_0, var_2)

# Generated at 2022-06-25 22:40:55.109371
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), 2, *range(3), 4, *range(5))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:59.206062
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = 'lst = []'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0.body[0].value)


# Generated at 2022-06-25 22:41:10.528733
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("2 * 3")
    StarredUnpackingTransformer(tree)
    try:
        StarredUnpackingTransformer("")
    except TypeError:
        pass