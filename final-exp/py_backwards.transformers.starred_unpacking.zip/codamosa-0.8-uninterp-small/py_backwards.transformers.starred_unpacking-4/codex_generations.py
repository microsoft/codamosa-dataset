

# Generated at 2022-06-25 22:31:20.657649
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = module_0.List(
        elts=[module_0.Num(n=1)],
        ctx=module_0.Load()
    )
    list_2 = module_0.List(
        elts=[list_1, module_0.Num(n=3)],
        ctx=module_0.Load()
    )
    starred_unpacking_transformer_0.visit_List(list_2)


# Generated at 2022-06-25 22:31:27.374577
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0.Name(id='T', lineno=2, col_offset=0,)
    a_s_t_0.arguments(args=[module_0.Name(id='r', ctx=module_0.Load(), lineno=2, col_offset=0,)], vararg=None, varargannotation=None, kwonlyargs=[], kw_defaults=[], kwarg=None, kwargannotation=None, defaults=[], lineno=2, col_offset=0,)

# Generated at 2022-06-25 22:31:30.227089
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:31:31.190705
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()


# Generated at 2022-06-25 22:31:41.094962
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(module_0.PyCF_ONLY_AST)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST(module_0.PyCF_ONLY_AST, module_0.PyCF_IGNORE_COOKIE)
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)


# Generated at 2022-06-25 22:31:50.092930
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List
    call_1 = module_0.Call
    name_0 = module_0.Name
    call_0 = module_0.Call
    bin_op_0 = module_0.BinOp
    list_1 = module_0.List
    starred_1 = module_0.Starred
    bin_op_1 = module_0.BinOp
    bin_op_2 = module_0.BinOp
    list_3 = module_0.List
    list_2 = module_0.List


# Generated at 2022-06-25 22:31:57.393626
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Call()
    
    # Assertion/Command
    with pytest.raises(AssertionError):
        assert_equal(starred_unpacking_transformer_0.visit_Call(node_0), __)
    

# Generated at 2022-06-25 22:32:10.124528
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    kw0 = module_0.keyword()
    kw0.arg = None
    kw0.value = None
    stararg_1 = module_0.Starred()
    stararg_1.value = None
    call_0 = module_0.Call()
    call_0.func = None
    call_0.args = [None]
    call_0.keywords = [None]
    call_0.starargs = None
    call_0.kwargs = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:11.152238
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        test_case_0()
    except NameError:
        assert()
    else:
        assert(StarredUnpackingTransformer)

# Generated at 2022-06-25 22:32:18.423671
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    l_i_s_t_0 = module_0.List()
    module_0._visit(starred_unpacking_transformer_0, l_i_s_t_0)


# Generated at 2022-06-25 22:32:32.659208
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:37.635563
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    try:
        assert isinstance(StarredUnpackingTransformer(a_s_t_0), StarredUnpackingTransformer)
    except:
        raise AssertionError("Expected an instance of class StarredUnpackingTransformer")

# Generated at 2022-06-25 22:32:45.212105
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args = [1]
    call_0.func = 2
    call_0.keywords = [3]
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:32:55.532209
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(
        elts=[module_0.Num(n=2), module_0.Starred(value=module_0.Call(
            func=module_0.Name(id='range'), args=[module_0.Num(n=10)], keywords=[]), ctx=module_0.Load()), module_0.Num(n=1)], ctx=module_0.Load())

# Generated at 2022-06-25 22:33:06.615694
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Call(module_0.Name(id='print', ctx=module_0.Load()), [module_0.Starred(module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load())], keywords=[])]
    a_s_t_0.type_ignores = []
    t_y_p_e_0 = module_0.FunctionDef(name='a', body=[], decorator_list=[], returns=None, type_comment=None)
    func_type_0 = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])

# Generated at 2022-06-25 22:33:11.736846
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:17.058892
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert isinstance(starred_unpacking_transformer_0, StarredUnpackingTransformer) == True


# Generated at 2022-06-25 22:33:20.795562
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # a_s_t_0 = module_0.AST()
    # assert(a_s_t_0 == 3)
    # starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert True

# Generated at 2022-06-25 22:33:26.610455
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    module_0.fix_missing_locations(call_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:37.756766
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args = []
    call_0.func = module_0.Name()
    call_0.keywords = []
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = module_0.Call()
    call_1.args = []
    call_1.func = module_0.Call()
    call_1.keywords = []
    call_2 = module_0.Call()
    call_2.args = []
    call_2.func = module_0.Name()
    call_2

# Generated at 2022-06-25 22:33:48.781997
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:33:52.088293
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert hasattr(StarredUnpackingTransformer, '__init__')
    assert callable(StarredUnpackingTransformer.__init__)


# Generated at 2022-06-25 22:34:02.614806
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Testing when arguments is empty
    dict_0 = {}
    str_0 = '=G0?VqW'
    dict_1 = {str_0: str_0}
    list_0 = [dict_1, str_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_1 == call_0
    dict_2 = {str_0: str_0}
    list_1 = [dict_2, str_0]
    call_1 = module_0.Call(*list_1)

# Generated at 2022-06-25 22:34:10.033470
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from _ast3 import mod as module
    from typed_ast.ast3 import AST
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    instance0 = module.Call()
    list0 = [instance0]
    instance1 = ast.List(list0)
    instance2 = AST()
    instance3 = StarredUnpackingTransformer(instance2)
    instance3.visit_List(instance1)


# Generated at 2022-06-25 22:34:11.077391
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True == True


# Generated at 2022-06-25 22:34:18.474483
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'vPyVp\n'
    str_1 = '8tG\n'
    str_2 = '?&Z\x7f\x0e'
    str_3 = '\x0e'
    str_4 = '$'
    str_5 = '.'
    str_6 = '\x1f'
    str_7 = '\n'
    str_8 = 'r\x3b'
    str_9 = '\x1e'
    str_10 = 'g\x2e'
    str_11 = '\x01'
    str_12 = '\x18;'
    str_13 = '\x19\x1f'
    str_14 = '/\x1f'
    str_15 = '\x10\x13'


# Generated at 2022-06-25 22:34:26.127029
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '~N&t`"+|lRF\t'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, str_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:34.682278
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, str_0]
    list_1 = module_0.List(*list_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_2 = starred_unpacking_transformer_0.visit_List(list_1)

# Generated at 2022-06-25 22:34:46.520193
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # Test case 0
    str_0 = 'jW'
    str_1 = 'E3qm'
    str_2 = '&dtX'
    str_3 = '&E3=?.nOl\n=G0?VqW'
    str_4 = 'f'
    list_0 = [str_0, str_1, str_2, str_3, str_4]
    list_1 = [list_0]
    dict_0 = {str_2: list_0}
    list_2 = [dict_0, str_2]
    call_0 = module_0.Call(*list_2)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:34:57.041885
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '*b?f\x0b@x\\t'
    str_1 = '\nZdG[B'
    str_2 = '-\x17\x16#]?\tBX&'
    str_3 = '+'
    str_4 = '\x18J'
    str_5 = '+Xr'
    str_6 = '&'
    str_7 = '\x08f'
    str_8 = '+'
    star_arg_0 = module_0.Starred(str_0)
    call_0 = module_0.Call(*[str_1, star_arg_0, str_2])
    binop_0 = module_0.BinOp(*[star_arg_0, call_0, str_3])
    star_

# Generated at 2022-06-25 22:35:14.029640
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '.Ia>\nQ'
    module_0 = module_0.Call(None, *str_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = starred_unpacking_transformer_0.visit_Call(module_0)


# Generated at 2022-06-25 22:35:24.555196
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = __import__('typed_ast._ast3')
    str_0 = '*'
    str_1 = '-'
    str_2 = '-'
    str_3 = '+'
    str_4 = '+'
    str_5 = '-'
    str_6 = '+'
    str_7 = '*'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7]
    list_1 = [*{list_0}, '6\x17']
    list_2 = ['6\x17']
    func_0 = module_0.Call(*list_2)
    func_1 = module_0.Call(*list_2)

# Generated at 2022-06-25 22:35:33.263086
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    kwargs_0 = module_0.Keyword(arg=str_0)
    arg_0 = module_0.Starred(value=str_0)
    call_0 = module_0.Call(args=[arg_0], keywords=[kwargs_0])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)
    str_2 = '+o38^/i/g-X9/e+\x0c%\x19'
    a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 22:35:44.122522
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '1f=y:4<)./'
    str_1 = 'l!D#rZBn\x0c'
    str_2 = {str_0: str_0}
    str_3 = {str_1: str_1}
    str_4 = 'D:lH'
    str_5 = '*-i[&'
    str_6 = '9u!a'
    str_7 = {str_6: str_6}
    str_8 = '|\x0c-/'
    str_9 = {str_8: str_8}
    str_10 = '\x0c\x0bD;=^'
    str_11 = {str_10: str_10}
    str_12 = '-!c'
    str_13

# Generated at 2022-06-25 22:35:45.761304
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:35:55.807998
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '<'
    str_1 = '\x12'
    str_2 = 'q[\xe8\x1f\x9a'
    str_3 = '\x02L'
    tuple_0 = (str_1, str_2, str_3)
    str_4 = str_0.join(tuple_0)
    list_0 = module_0.List(str_4)
    str_5 = '\x08K\x1a'
    str_6 = str_5.lower()
    list_1 = module_0.List(str_6)
    str_7 = '\x1c\x0c\x9c\xcc'
    str_8 = str_7.lower()

# Generated at 2022-06-25 22:36:06.658877
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '5, 9, 8, ', 'jXO', 'f, u, ', 'oU6$0*iB', '6'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    named_expr_0 = module_0.NamedExpr(target=list_0, value=list_0)
    call_0 = module_0.Call(func=list_0, keywords=[named_expr_0])
    a_s_t_0 = module_0.AST()
    str_2 = "&E3=?.nOl\n=G0?VqW"
    str_3 = {str_2: str_2}
    list_1 = module_0.List(*str_3)
    module_

# Generated at 2022-06-25 22:36:13.118926
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:36:13.968165
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()

# Generated at 2022-06-25 22:36:22.474000
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'PtJ?(y:N&iY'
    str_1 = '}x$)_?{o]c%'
    str_2 = 'IZ:.g\'/R$nH'
    str_3 = '12U6b-?2!XH'
    str_4 = 'Y(h#d@rC&FxM'
    str_5 = '-{X9Oc\']2:f'
    str_6 = '*5&5Z+/D$J'
    str_7 = '[\']y:Qa+F/'
    str_8 = '#nG_U);b6U'
    str_9 = '@j:&M-Yp'
    str_10 = 'x{s[A+;^c'
   

# Generated at 2022-06-25 22:36:52.874624
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = 'rCX?K0t>W:gaI'
    str_1 = ['n$E1w<g1=m2', 'SX9Hv\x7f%P']
    list_0 = [str_0, str_1]
    a_s_t_0 = module_0.AST()
    list_1 = module_0.List(*str_1)
    call_0 = module_0.Call(list_1, args=[], keywords=[], starargs=[], kwargs=[])
    list_2 = module_0.List(call_0)
    list_3 = module_0.List(list_2)
    bin_op_0 = module_0.BinOp(call_0, list_2, op=ast.Add())

# Generated at 2022-06-25 22:37:01.232410
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:37:10.501003
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '?<P@'
    str_1 = '-TJ}`kk^'
    tuple_0 = (str_1, str_0)
    function_0 = module_0.keyword(*tuple_0)
    list_0 = module_0.List(function_0)
    tuple_1 = (str_0, list_0)
    call_0 = module_0.Call(**tuple_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:16.413909
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:37:23.982593
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    instance_0 = StarredUnpackingTransformer(ast.AST())
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = ast.List(*str_1)
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:37:31.840289
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:37:32.441886
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:37:42.064492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '~[#*:mGvZ7m'
    str_1 = 'i15|TWo9/Dz*5'
    tuple_0 = (str_1, str_0)
    list_0 = module_0.List(str_0)
    dict_0 = module_0.Dict(str_0, str_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(list_0, list(tuple_0))
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:49.405112
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '*_sZQ,\\+aM0q9X'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    call_0 = module_0.Call(list_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:58.407035
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_1 = '#m([38p\n8M&:('
    str_2 = '2ef\nO%O[??'
    str_3 = 'W,aY'
    str_4 = 't"f%W[1'
    str_5 = 'T(\n\nM;P8'
    str_6 = '{'
    str_7 = '9.n'
    str_8 = '\n;, '
    call_0 = module_0.Call()
    try:
        module_0.Call(args=[call_0])
        raise TypeError('wrong exception')
    except TypeError as e:
        if not e.args[0] == 'i_am_kwargs':
            raise
    
    # Testing condition 0

# Generated at 2022-06-25 22:38:51.304656
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    # Constructor of class StarredUnpackingTransformer
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Method `visit_List` of class StarredUnpackingTransformer
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    list_1 = module_0.List()
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    # Method `get_changed` of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:38:58.903892
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '^,7x\x16\x11!\x1d\x1a(\x1b\x00O-\x03\x13\x05=\x0f\\\x1a\x12\x1b'
    str_1 = str_0.replace('x', '*')
    str_2 = str_1.replace('=', '(')
    str_3 = str_2.replace('\x00', 'range')
    str_4 = str_3.replace('\x1b', ')')

# Generated at 2022-06-25 22:39:02.406791
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer()
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

#Unit test for method visit of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:39:11.150898
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '&E3=?.nOl\n=G0?VqW'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    call_0 = module_0.Call(func='h*&Y$pyw+2(<c%{', args=[list_0])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:39:18.814689
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'Ohr[%Jn?~IzCWZa'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    call_0 = module_0.Call(module_0.Name(), list_0, [])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)

# Generated at 2022-06-25 22:39:24.177367
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Default case
    try:
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    except:
        print('Exception caught in test: test_StarredUnpackingTransformer')


# Generated at 2022-06-25 22:39:28.014263
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Set up parameters
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    # Construct object
    try:
        StarredUnpackingTransformer(a_s_t_0)
    except Exception as err:
        raise err


# Generated at 2022-06-25 22:39:30.437703
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        a_s_t_0 = module_0.AST()
        StarredUnpackingTransformer(a_s_t_0)
    except Exception as e:
        raise e


# Generated at 2022-06-25 22:39:37.439878
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'O[\x1eW^'
    str_1 = {str_0: str_0}
    list_0 = module_0.List(*str_1)
    call_0 = module_0.Call(index=list_0)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:39:48.350836
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = ']k*`'
    int_0 = -2347
    str_1 = '5%p[B3k'
    str_2 = {str_1: str_1}
    list_0 = module_0.List(*str_2)
    call_0 = module_0.Call(func=module_0.Name(id=str_0), args=[module_0.Constant(int_0), list_0])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


if __name__ == '__main__':
    test_case_0()
   