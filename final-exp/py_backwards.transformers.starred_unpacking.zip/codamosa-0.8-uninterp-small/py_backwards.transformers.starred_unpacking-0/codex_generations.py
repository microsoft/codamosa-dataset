

# Generated at 2022-06-25 22:31:17.678922
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 22:31:24.345314
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_0 = "\n# <codeobj> replace\n(1)\n# </codeobj>\n"
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(ast_0)
    ast_1 = "\n# <codeobj> replace\n(1)\n# </codeobj>\n"
    result_0 = starred_unpacking_transformer_0.visit_Call(ast_1)
    assert result_0 == ast.Call(func = ast.Num(n = 1), args = [], keywords = [])


# Generated at 2022-06-25 22:31:25.570542
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None



# Generated at 2022-06-25 22:31:36.976009
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = ast.parse("[2, *range(10), 1]")
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_1 = starred_unpacking_transformer_1.visit(a_s_t_1)

# Generated at 2022-06-25 22:31:38.084058
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:31:47.828143
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typing import Union, Iterable, List
    from .no_starred_unpacking import ast as no_starred_unpacking_ast
    from ._test_utils import get_default_dynamic_context
    from ._test_utils import evaluate_node
    test_dynamic_context_0 = get_default_dynamic_context()
    test_starred_unpacking_transformer_0 = StarredUnpackingTransformer(no_starred_unpacking_ast.parse("[2, *range(10), 1]", mode='eval'))
    test_starred_unpacking_transformer_0.context = test_dynamic_context_0
    test_starred_unpacking_transformer_0.transform()

# Generated at 2022-06-25 22:31:55.848305
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_2 = ast.Call()
    call_2.args = [ast.Num()]
    call_2.func = ast.Name()
    call_2.keywords = []
    return_value_3 = starred_unpacking_transformer_1.visit_Call(call_2)
    print(return_value_3)


# Generated at 2022-06-25 22:32:03.753337
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List(elts=[])
    list_1 = None
    try:
        list_1 = starred_unpacking_transformer_0.visit_List(list_0)

        assert 2 == 2
    except:
        assert 2 == 3


# Generated at 2022-06-25 22:32:14.407581
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse(
        """
print(*range(1), *range(3))
"""
    )
    a_s_t_1 = ast.parse(
        """
print(*(list(range(1)) + list(range(3))))
"""
    )
    try:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        res = starred_unpacking_transformer_0.visit(a_s_t_0)
        assert(res == a_s_t_1)
    except:
        print("starred_unpacking_transformer_0.visit(a_s_t_0) error")
        assert False


# Generated at 2022-06-25 22:32:23.307783
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None
    call_0 = ast.Call(func=a_s_t_1, args=[], keywords=[], starargs=None, kwargs=None)
    try:
        result = starred_unpacking_transformer_0.visit_Call(call_0)
        assert result == call_0
    except:
        raise Exception('Unit test for method visit_Call of class StarredUnpackingTransformer failed!')


# Generated at 2022-06-25 22:32:33.354951
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = 'range'
    module_0 = module_0
    star_0 = module_0.Starred(value=module_0.Name(id='range'))
    bool_0 = bool(star_0)
    bool_1 = bool(star_0.value)
    list_0 = [1, 2, star_0, 3]
    int_0 = len(list_0)
    list_1 = [1, 2, star_0.value, 3]
    int_1 = len(list_1)
    list_2 = [star_0, 1, 2, 3]
    int_2 = len(list_2)
    list_3 = [star_0.value, 1, 2, 3]
    int_3 = len(list_3)

# Generated at 2022-06-25 22:32:38.698706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:32:44.292200
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'test_0(2, *range(10), 1)'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:32:49.415506
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:32:55.490527
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer()
    assert isinstance(var_0, BaseNodeTransformer)


# Generated at 2022-06-25 22:33:00.547435
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    assert starred_unpacking_transformer_0 is not None


# Generated at 2022-06-25 22:33:05.508674
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:33:11.515971
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    str_1 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    var_1 = module_0.parse(str_1)
    var_2 = StarredUnpackingTransformer(var_0)
    var_3 = StarredUnpackingTransformer(var_1)

# Generated at 2022-06-25 22:33:18.397179
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

if __name__ == '__main__':
    test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-25 22:33:25.302194
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.parse('print(*(list(range(1)) + list(range(3))))')
    assert var_1 == var_2


# Generated at 2022-06-25 22:33:33.341097
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)

# Generated at 2022-06-25 22:33:41.492825
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_1 = '[2, *range(10), 1]'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)
    assert var_3 == module_0.parse(
        '_PY2: list([2, ] + list(range(10)) + [1])\n'
        'not _PY2: [2, ] + list(range(10)) + [1]')


# Generated at 2022-06-25 22:33:50.513144
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import os
    import sys
    import pytest

    # Path to the directory containing the sample script
    str_0 = os.path.dirname(os.path.abspath(__file__))

    # Append the sample script directory to the module search path
    sys.path.append(str_0)

    # Import the sample script
    import test_star_unpacking_transformer

    # Test the constructor of class StarredUnpackingTransformer
    obj_0 = StarredUnpackingTransformer(test_star_unpacking_transformer.test_case_0())
    obj_0.visit(test_star_unpacking_transformer.test_case_0())

    # Test the constructor of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:33:51.501952
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:33:55.253850
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Maybe consider improving coverage of this unit test,
    # and then removing this "pass" statement.
    pass

if __name__ == '__main__':
    test_case_0()
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:33:56.307714
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Code
    test_case_0()

# Generated at 2022-06-25 22:34:02.426703
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    str_1 = '[2, *range(10), 1]'
    var_1 = module_0.parse(str_1)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_2 = starred_unpacking_transformer_0.visit_List(var_1)

# Generated at 2022-06-25 22:34:07.969211
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:34:12.256372
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:34:15.519784
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:34:21.595852
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:34:32.434598
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    str_1 = 'list([2, 10, 1])'
    var_1 = module_0.parse(str_1)
    var_2 = starred_unpacking_transformer_0.visit_List(var_0.body[0].value)
    assert var_1.body[0].value.elts[0].value == var_2.elts[0].value

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:34:37.246012
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:34:47.931288
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = typed_ast.ast3
    str_0 = 'print(*range(1), *range(3))'
    str_1 = 'print(*(list(range(1)) + list(range(3))))'
    var_0 = module_0.parse(str_0)
    var_1 = None
    try:
        var_1 = module_0.parse(str_1)
    except module_0.ParseError:
        pass
    except ImportError:
        pass

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_2 = starred_unpacking_transformer_0.visit(var_0)
    assert var_2 == var_1


# Generated at 2022-06-25 22:34:54.409225
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer.target == (3, 4)

# Generated at 2022-06-25 22:34:58.231261
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert not StarredUnpackingTransformer()
    from typed_ast import ast3 as ast
    var_0 = ast.parse("a = 2")
    assert not StarredUnpackingTransformer(var_0)
    assert True


# Generated at 2022-06-25 22:35:08.971736
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:35:13.927227
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:35:18.515417
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:35:23.581585
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:35:29.218001
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:35:33.438747
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:35:44.290830
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print("")
    print("test_StarredUnpackingTransformer_visit_List")
    var_0 = "[2, *range(10), 1]"
    var_1 = module_0.parse(var_0)
    var_2 = StarredUnpackingTransformer(var_1)
    var_3 = var_2.visit(var_1)
    print("var_3.elts")
    print(var_3.elts)
    print(var_3.elts[0].elts)
    print(var_3.elts[0].elts[0].n)
    print(type(var_3.elts[0].elts[0].n))
    var_4 = var_3.elts[1].func.id
    print("var_4")

# Generated at 2022-06-25 22:35:49.147004
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Initialize input parameters for the test
    node = ast.parse('''print(*range(1), *range(3))''').body[0]
    # Call the method with its arguments
    StarredUnpackingTransformer.visit_Call(StarredUnpackingTransformer(ast.parse('''print(*range(1), *range(3))''').body[0]), node)

# Generated at 2022-06-25 22:35:52.824460
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Arrange
    tree = module_0.parse('[*range(10), 2, *range(20), 3]')
    expected = module_0.parse('list(range(10)) + [2] + list(range(20)) + [3]')
    expected = module_0.fix_missing_locations(expected)
    # Act
    transformer = StarredUnpackingTransformer(tree)
    actual = transformer.visit(tree)
    actual = module_0.fix_missing_locations(actual)
    # Assert
    if expected != actual:
        raise AssertionError('expected = ' + str(expected) + ' != actual = ' + str(actual))

# Generated at 2022-06-25 22:35:57.395171
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    print(ast.dump(starred_unpacking_transformer_0.visit(var_0)))


# Generated at 2022-06-25 22:36:08.538487
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Test StarredUnpackingTransformer")
    var_0 = StarredUnpackingTransformer(module_0.parse("x = 3"))
    print(var_0)
    print(type(var_0))
    print(var_0._tree_changed)
    assert str(var_0) == '<StarredUnpackingTransformer(3.4)>'

# Generated at 2022-06-25 22:36:18.251637
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.parse('[2] + list(range(10)) + [1]')
    var_3 = var_1.body[0]
    var_4 = var_0.body[0]
    var_5 = var_0
    var_6 = module_0.unparse(var_1)
    module_0.fix_missing_locations(var_5)
    module_0.copy_location(var_1, var_5)

# Generated at 2022-06-25 22:36:21.674856
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:36:30.945627
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # ...
    str_0 = 'foo(2, 3, *[4, 5, 6], 7)'
    var_0 = module_0.parse(str_0)
    var_1 = StarredUnpackingTransformer(var_0)
    var_2 = var_1.visit(var_0)
    var_3 = module_0.parse('foo(2, 3, *(list([4, 5, 6]) + list([7])))')
    var_4 = assertEqual(var_2, var_3)

    # ...
    str_1 = 'foo(1, *[2], *[3])'
    var_5 = module_0.parse(str_1)
    var_6 = StarredUnpackingTransformer(var_5)

# Generated at 2022-06-25 22:36:35.030171
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert type(StarredUnpackingTransformer()) == StarredUnpackingTransformer, \
        'Test failed, wrong type'


# Generated at 2022-06-25 22:36:43.088873
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0.body[0].value)
    str_1 = module_0.unparse(var_1)
    str_2 = '[2, *list(range(10)), 1]'
    assert(str_1 == str_2)


# Generated at 2022-06-25 22:36:47.614994
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = StarredUnpackingTransformer_0.visit(var_0)

# Generated at 2022-06-25 22:36:49.923693
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Success
    print("Testing Success:")
    print("Expected output: None")
    test_case_0()

test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:36:54.813518
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:36:56.306127
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:37:07.616067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    print('\ntest_StarredUnpackingTransformer_visit_List')

    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    starred_unpacking_transformer_0.visit(var_0)
    str_1 = 'list(range(10))'
    var_1 = module_0.parse(str_1)
    var_2 = starred_unpacking_transformer_0.visit(var_1)
    str_2 = 'print(*range(1), *range(3))'
    var_3 = module_0.parse(str_2)
    var_4 = starred_unpacking_transformer_0.visit

# Generated at 2022-06-25 22:37:17.045927
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert isinstance(var_1, module_0.List)
    assert isinstance(var_1.ctx, module_0.Load)
    assert isinstance(var_1.elts[0], module_0.Num)
    assert isinstance(var_1.elts[1], module_0.BinOp)
    assert isinstance(var_1.elts[1].op, module_0.Add)

# Generated at 2022-06-25 22:37:21.275254
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:26.611504
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:31.795119
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Unit test for constructor of class StarredUnpackingTransformer
    test_case_0()


# Generated at 2022-06-25 22:37:33.845802
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:37:38.375814
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_12 = '[2, *range(10), 1]'
    var_8 = module_0.parse(str_12)
    class_0 = StarredUnpackingTransformer(var_8)
    arg_0 = module_0.parse(str_12)
    var_9 = class_0.visit_List(arg_0)


# Generated at 2022-06-25 22:37:43.262112
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    str_1 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert module_0.dump(var_1) == str_1


# Generated at 2022-06-25 22:37:48.122004
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:52.102021
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:53.307503
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:37:57.314448
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_3 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_3)
    var_4 = starred_unpacking_transformer_0.visit(var_3)


# Generated at 2022-06-25 22:38:01.822499
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_0 = ''
    var_1 = module_0.parse(var_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_1)
    var_2 = starred_unpacking_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:38:02.803164
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert True


# Generated at 2022-06-25 22:38:13.907197
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)


# Generated at 2022-06-25 22:38:17.537002
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    var_2 = StarredUnpackingTransformer(var_0)
    var_1 = var_2.visit(var_0)


# Generated at 2022-06-25 22:38:22.856112
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(1, *range(1), 2)'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert 'print(*[1] + list(range(1)) + [2])' == module_0.unparse(var_1)


# Generated at 2022-06-25 22:38:26.789240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    var_1 = StarredUnpackingTransformer(var_0)
    var_2 = var_1.visit_List(var_0.body[0].value)


# Generated at 2022-06-25 22:38:30.471775
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:37.033943
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    # Check constructor
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(module_0.parse("[2, *range(10), 1]"))
    module_0.parse("[2, *range(10), 1]")
    assert isinstance(starred_unpacking_transformer_0, StarredUnpackingTransformer)

# Generated at 2022-06-25 22:38:41.385494
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    var_2 = module_0.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)
    print(var_3)


# Generated at 2022-06-25 22:38:46.587800
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.parse(str_0)
    assert var_1 == var_2

# Generated at 2022-06-25 22:38:51.211501
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    # assert var_1 == '2 + list(range(10)) + 1'

# Generated at 2022-06-25 22:38:54.258122
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:18.346556
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(module_0.List(elts=[module_0.Constant(value=2, kind=None), module_0.Starred(value=module_0.Call(func=module_0.Name(id='range'), args=[module_0.Constant(value=10, kind=None)], keywords=[])), module_1.Constant(value=1, kind=None)]))

# Generated at 2022-06-25 22:39:23.788598
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '[[2, 3, 4], [1, 2, 3]]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)

test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:39:28.309691
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("test_StarredUnpackingTransformer")
    tree = ast.parse('2')
    transformer = StarredUnpackingTransformer(tree)
    assert type(transformer) == StarredUnpackingTransformer
    tree_changed = False
    tree = transformer.visit(tree, tree_changed=tree_changed)
    assert tree_changed == False


# Generated at 2022-06-25 22:39:31.734651
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:36.092160
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:39:37.309731
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:39:40.265188
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:39:42.144110
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Arguments should not be used.
    this_0 = StarredUnpackingTransformer(None)


# Generated at 2022-06-25 22:39:47.848913
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as module_0
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:51.684294
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:54.720852
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # test1
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_2 = starred_unpacking_transformer_0.visit(var_0)
    # at this point the test has finished running, and the output should
    # have fixed a bug, because at the start of this test, the var_2 was NoneType.
    var_1 = var_2 is not None
    assert var_1


# Generated at 2022-06-25 22:41:03.249243
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)
    module_0.fix_missing_locations(var_1)

    v_list_0 = var_1.elts

# Generated at 2022-06-25 22:41:07.864498
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:41:10.988944
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
