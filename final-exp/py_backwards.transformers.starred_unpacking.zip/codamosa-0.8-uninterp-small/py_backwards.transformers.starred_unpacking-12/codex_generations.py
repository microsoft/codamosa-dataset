

# Generated at 2022-06-25 22:31:12.977338
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t = None
    starred_unpacking_transformer = StarredUnpackingTransformer(a_s_t)
    assert (type(starred_unpacking_transformer) == StarredUnpackingTransformer)
    assert (type(starred_unpacking_transformer._a_s_t) == None)
    assert (type(starred_unpacking_transformer._tree_changed) == bool)


# Generated at 2022-06-25 22:31:19.773186
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_2 = None
    call_0 = ast.Call(a_s_t_0, args=[a_s_t_2], keywords=[])
    a_s_t_3 = None
    starred_unpacking_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:31:27.061185
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Create AST
    ast_0 = ast.parse("print(*range(1), *range(3))")
    # Get target function
    function_0 = getattr(ast_0, 'body')[0]
    # Get target node
    call_0 = getattr(function_0, 'value')
    # Assign to target
    # Method call
    result_0 = getattr(starred_unpacking_transformer_0, 'visit_Call')(call_0)

# Generated at 2022-06-25 22:31:33.975412
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    starred_unpacking_transformer_0.visit_Call(call_0)
    exception_0 = None
    try:
        call_0 = None
        starred_unpacking_transformer_0.visit_Call(call_0)
    except NameError as exception_0:
        pass


# Generated at 2022-06-25 22:31:45.225367
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list1 = ast.List(elts=[ast.Num(n=2)])
    starred1 = ast.Starred(value=ast.Call(
        func=ast.Name(id='range'),
        args=[ast.Num(n=10)],
        keywords=[]))
    list2 = ast.List(elts=[ast.Num(n=1)])
    node1 = ast.List(elts=[list1, starred1, list2])

    range1 = ast.Call(func=ast.Name(id='range'),
                      args=[ast.Num(n=1)],
                      keywords=[])
    range2 = ast.Call(func=ast.Name(id='range'),
                      args=[ast.Num(n=3)],
                      keywords=[])

# Generated at 2022-06-25 22:31:51.357664
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree_0 = ast.parse('x[5, [*it], 7]')
    tree_0.__setattr__('starred_unpacking', True)
    tree_0.__setattr__('async_compat', False)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(tree_0)
    tree_1 = starred_unpacking_transformer_0.get_tree()
    x = tree_1.body[0].value.args[0]
    x = x.elts[0]
    assert isinstance(x, ast.Num) is True


# Generated at 2022-06-25 22:31:55.014538
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:32:07.680108
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('print(*range(1), *range(3))')
    assert str(a_s_t_0) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=List(elts=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=1)], keywords=[]), Call(func=Name(id='range', ctx=Load()), args=[Num(n=3)], keywords=[])], ctx=Load())], keywords=[]))])"
    compare(StarredUnpackingTransformer(a_s_t_0).visit(a_s_t_0), ast.parse('print(*(list(range(1)) + list(range(3))))'))

# Generated at 2022-06-25 22:32:17.555138
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arrange
    locally_declared_node = ast.Call(func=ast.Name(id='print'),
                                     args=[ast.Starred(value=ast.Name(id='ys'))],
                                     keywords=[])
    node = ast.Call(func=ast.Name(id='print'), args=[ast.Name(id='x')], keywords=[])
    locally_declared_starred_unpacking_transformer_0 = StarredUnpackingTransformer(node)
    locally_declared_call_0 = locally_declared_node.func
    locally_declared_call_1 = locally_declared_node.args
    locally_declared_bin_op_0 = None
    locally_declared_list_0 = None
    locally_declared_list_1 = None
    locally_declared_list_

# Generated at 2022-06-25 22:32:27.007523
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    list_0 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Num(n=1)], ctx=ast.Load())
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    actual = starred_unpacking_transformer_0.visit_List(list_0)
    expected = [2] + list(range(10)) + [1]
    assert actual == expected


# Generated at 2022-06-25 22:32:38.731527
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List(elts=[])
    ast.copy_location(list_0, None)
    # The statement below is expected to fail at compile time
    # starred_unpacking_transformer_0.visit_List(list_0)
    raise AssertionError(
        "The statement below is expected to fail at compile time: starred_unpacking_transformer_0.visit_List(list_0)")


# Generated at 2022-06-25 22:32:43.922119
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Assert
    starred_unpacking_transformer_0.visit_List(a_s_t_0)


# Generated at 2022-06-25 22:32:48.697116
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ctx = StarredUnpackingTransformer(None)
    ast_node_0 = ast.List(elts=[], ctx=ast.Load())
    ast_node_1 = ctx.visit_List(ast_node_0)
    assert ast_node_1 != ast_node_0


# Generated at 2022-06-25 22:32:54.982229
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # TODO: add test for method visit_List of class StarredUnpackingTransformer
    pass


# Generated at 2022-06-25 22:33:00.927355
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_List(a_s_t_0.body[0].value)


# Generated at 2022-06-25 22:33:06.150696
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List(elts=())
    list_1 = starred_unpacking_transformer_0.visit(list_0)
    assert (list_1 == list_0)


# Generated at 2022-06-25 22:33:13.009467
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_list_0 = None
    ast_list_0 = ast.List()
    ast_list_0.elts = []
    ast_list_0.ctx = None
    starred_unpacking_transformer_0.visit(ast_list_0)


# Generated at 2022-06-25 22:33:16.375914
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:33:24.821044
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])
    ast.copy_location(list_0, 'a_s_t_0')
    starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:33:35.911308
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None
    a_s_t_15 = None
    a_s_t_16 = None
    a_s_t_17 = None
   

# Generated at 2022-06-25 22:33:47.162043
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    a_s_t_1 = None
    try:
        a_s_t_0 = ast.parse('[2, *range(10), 1]')
    except Exception:
        print("Failed to parse:\n[2, *range(10), 1]")


    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    try:
        a_s_t_1 = ast.parse('[2] + list(range(10)) + [1]')
    except Exception:
        print("Failed to parse:\n[2] + list(range(10)) + [1]")

    try:
        ast.fix_missing_locations(a_s_t_1)
    except Exception:
        pass


# Generated at 2022-06-25 22:33:56.738755
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    a_s_t_2 = ast.Expr(ast.List(elts=[], ctx=ast.Load()))
    a_s_t_3 = ast.Expr(ast.List(elts=[], ctx=ast.Load()))
    a_s_t_4 = ast.Expr(ast.List(elts=[], ctx=ast.Load()))
    a_s_t_5 = ast.Expr(ast.List(elts=[], ctx=ast.Load()))
    a_s_t_6 = ast.Expr(ast.List(elts=[], ctx=ast.Load()))
    a_s_t_7 = ast.Expr(ast.List(elts=[], ctx=ast.Load()))
    a

# Generated at 2022-06-25 22:34:07.688352
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Starred *expr
    expr_1 = ast.Starred(value=ast.Num(n=10), ctx=ast.Load())
    # Expr *expr
    expr_2 = ast.Call(func=ast.Name(id='fun', ctx=ast.Load()), args=ast.Num(n=10, ctx=ast.Load()))
    # Call fun *expr
    expr_1 = ast.Call(func=ast.Name(id='fun', ctx=ast.Load()), args=[expr_1])
    # Call fun expr *expr

# Generated at 2022-06-25 22:34:10.204398
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    return


# Generated at 2022-06-25 22:34:14.688173
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    assert_equal(StarredUnpackingTransformer(a_s_t_0)._tree, None)
    a_s_t_1 = None
    a_s_t_2 = None
    assert_equal(StarredUnpackingTransformer(a_s_t_1, a_s_t_2).generic_visit(None), None)


# Generated at 2022-06-25 22:34:18.005492
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    assert_equal(StarredUnpackingTransformer(a_s_t_0).__class__, StarredUnpackingTransformer)


# Generated at 2022-06-25 22:34:21.771304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    assert_equal(starred_unpacking_transformer_0.tree, a_s_t_0)
    assert_equal(starred_unpacking_transformer_0.tree_changed, False)



# Generated at 2022-06-25 22:34:33.802680
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    a_s_t_1 = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])),
        ast.Num(n=1)
    ], ctx=ast.Load())
    a_s_t_2 = ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[]), ast.Num(n=1)], ctx=ast.Load())
    expected_0 = a_s_t_2


# Generated at 2022-06-25 22:34:38.924851
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.List(elts=[])
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = starred_unpacking_transformer_0.visit_List(a_s_t_0)


# Generated at 2022-06-25 22:34:44.998534
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("test_StarredUnpackingTransformer_visit_Call")
    a_s_t_0 = None
    node_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(node_0)


# Generated at 2022-06-25 22:34:53.669722
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Expr(value=None)
    starred_unpacking_transformer_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:34:58.489172
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = [2,*range(10),1]
    source = ast.parse(source)
    source = StarredUnpackingTransformer(source).visit(source)
    #print(astunparse.unparse(source))
    s = compile(source, '', 'exec')
    exec(s)

# Generated at 2022-06-25 22:35:02.667532
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_0 = None
    starred_unpacking_transformer_0.visit_Call(node_0)


# Generated at 2022-06-25 22:35:09.079110
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('[1, 2, 3]')
    a_s_t_1 = ast.parse('print(*[1, 2, 3], *[1, 2, 3])')
    assert a_s_t_0 == StarredUnpackingTransformer(a_s_t_0).result
    assert a_s_t_1 == StarredUnpackingTransformer(a_s_t_1).result


# Generated at 2022-06-25 22:35:14.028407
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_2 = None
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)
    a_s_t_3 = ast.List(elts=[])
    starred_unpacking_transformer_2.visit_List(a_s_t_3)


# Generated at 2022-06-25 22:35:22.002925
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    '''
    Unit test for method visit_List of class StarredUnpackingTransformer
    '''
    a_s_t_0 = """
    [2, *range(10), 1]
    """
    a_s_t_0_nodes = ast.parse(a_s_t_0)

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0_nodes)
    starred_unpacking_transformer_0.visit(a_s_t_0_nodes)


# Generated at 2022-06-25 22:35:28.111460
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List(elts=[], ctx=ast.Load())
    test_list_0 = starred_unpacking_transformer_0.visit_List(list_0)
    assert(isinstance(test_list_0, ast.List))
    assert(test_list_0.ctx == ast.Load())
    assert(test_list_0.elts == [])


# Generated at 2022-06-25 22:35:30.282225
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:34.971040
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """ Test for constructor of class StarredUnpackingTransformer"""
    a_s_t_0 = ast.parse("d = {**{'a': 1}, 'b': 2}")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert starred_unpacking_transformer_0 is not None

# Generated at 2022-06-25 22:35:44.336715
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
  try:
    a_s_t_0 = ast.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = starred_unpacking_transformer_0.visit(a_s_t_0)
  except:
    assert False, 'Error during StarredUnpackingTransformer visit_Call'
  try:
    assert a_s_t_1._fields == ('left', 'op', 'right'), 'Wrong fields'
  except:
    assert False, 'Error during StarredUnpackingTransformer visit_Call'
    pass
  return True


# Generated at 2022-06-25 22:35:58.721379
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

    a_s_t_2 = None
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)

    a_s_t_3 = None
    starred_unpacking_transformer_3 = StarredUnpackingTransformer(a_s_t_3)

    a_s_t_4 = None
    starred_unpacking_transformer_4 = StarredUnpackingTransformer(a_s_t_4)


# Generated at 2022-06-25 22:36:00.085515
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:36:11.260009
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Testing unknown type of var of type NoneType
    # Testing unknown type of var of type NoneType
    py40 = True
    if py40:
        a_s_t_1 = ast.Call(func=ast.Name(id='list'), args=ast.Starred(value=ast.Name(id='xs'), ctx=ast.Load()), keywords=[])
        assert (starred_unpacking_transformer_0.visit(a_s_t_1) == ast.Call(func=ast.Name(id='list'), args=[ast.Starred(value=ast.Name(id='xs'), ctx=ast.Load())], keywords=[]))

# Generated at 2022-06-25 22:36:12.241938
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:36:16.505810
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse("[2, *range(10), 1]")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    assert starred_unpacking_transformer_0.visit_List(a_s_t_0) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-25 22:36:21.683995
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # The following line should not raise a type error
    starred_unpacking_transformer_0.visit_List(None)

    # The following line should not raise a type error
    starred_unpacking_transformer_0.generic_visit(None)


# Generated at 2022-06-25 22:36:30.944838
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    elts_0 = [
        ast.Num(n=2),
        ast.Starred( value=ast.Call( func=ast.Name( id='range' ), args=[ast.Num( n=10 )], keywords=[] ), ctx=ast.Load() ),
        ast.Num(n=1)
    ]
    list_0 = ast.List( elts=elts_0 )
    assert not starred_unpacking_transformer_0._tree_changed
    assert starred_unpacking_transformer_0.visit(list_0) is not None
    assert starred_unpacking_transformer_0._tree_changed


# Generated at 2022-06-25 22:36:35.616661
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = ast.Call(
        func=ast.Name(id='y'),
        args=[],
        keywords=[]
    )
    actual = StarredUnpackingTransformer(None).visit_Call(ast.Call(
        func=ast.Name(id='x'),
        args=[],
        keywords=[]
    ))

    assert actual == expected


# Generated at 2022-06-25 22:36:43.329765
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ctx_0 = ast.Load()
    value_0 = ast.List()
    if hasattr(value_0, 'ctx'): value_0.ctx = ctx_0
    node_0 = value_0
    ast_0 = starred_unpacking_transformer_0.visit_List(node_0)
    assert ast_0 is node_0


# Generated at 2022-06-25 22:36:46.338513
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:56.569861
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-25 22:37:04.828686
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    a_s_t_0 = ast.parse("[2, *range(10), 1]", "some_file.py", "exec")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.parse("print(*range(1), *range(3))", "some_file.py", "exec")
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:37:13.716540
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Arrange
    non_target_asts = [ast.parse('import datetime')]
    target_asts = [ast.parse('[2, *range(10), 1]')]

    # Act
    for a_s_t in non_target_asts:
        starred_unpacking_transformer = StarredUnpackingTransformer(a_s_t)

    # Assert
    for a_s_t in non_target_asts:
        assert starred_unpacking_transformer.is_target(a_s_t) == False

    for a_s_t in target_asts:
        assert starred_unpacking_transformer.is_target(a_s_t) == True



# Generated at 2022-06-25 22:37:16.210424
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Num(n=1))], keywords=[])
    StarredUnpackingTransformer(a_s_t)


# Generated at 2022-06-25 22:37:17.019406
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert True


# Generated at 2022-06-25 22:37:21.230381
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None
    assert starred_unpacking_transformer_0.visit_Call(a_s_t_1) is None
    return


# Generated at 2022-06-25 22:37:26.565608
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    try:
        starred_unpacking_transformer_0.visit_List(list_0)
    except Exception as caught:
        assert False


# Generated at 2022-06-25 22:37:37.367407
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:37:38.596352
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = 'test'
    assert StarredUnpackingTransformer(a_s_t_0).tree == 'test'



# Generated at 2022-06-25 22:37:41.598767
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.parse('''
g(1, *a, *b)
    ''')
    x = StarredUnpackingTransformer(x).get_ast()

    assert str(x) == str(ast.parse('''
g(*(list(a) + list([*b])))
    '''))



# Generated at 2022-06-25 22:38:09.050173
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.List()
    a_s_t_0.elts = [ast.Name()]
    a_s_t_0.ctx = ast.Load()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = starred_unpacking_transformer_0.visit_List(a_s_t_0)


# Generated at 2022-06-25 22:38:10.146610
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # TODO: create test
    assert False



# Generated at 2022-06-25 22:38:11.261757
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    for _ in range(10):
        test_case_0()


# Generated at 2022-06-25 22:38:12.057607
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None) != None

# Generated at 2022-06-25 22:38:20.572121
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t = ast.parse("[2, *range(10), 1]")
    assert ast.dump(a_s_t) == "Module(body=[Expr(value=List(elts=[Num(n=2), Starred(value=Name(id='range', ctx=Load()), ctx=Load()), Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[]), Num(n=1)], ctx=Load()))])"

# Generated at 2022-06-25 22:38:26.902926
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .utils import build_and_run

    source = """[2, *range(10), 1]"""
    expect = str(ast.parse(source).body)
    actual = str(build_and_run(source, StarredUnpackingTransformer))
    assert expect == actual

    source = """print(*range(1), *range(3))"""
    expect = str(ast.parse(source).body)
    actual = str(build_and_run(source, StarredUnpackingTransformer))
    assert expect == actual


# Generated at 2022-06-25 22:38:32.136170
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = None
    __tracebackhide__ = True
    try:
        assert False
    except:
        __exc_info = sys.exc_info()
        __last_traceback = __exc_info[2]
        while (__tracebackhide__ and
               tb_hide.tb_hide(__last_traceback, __exc_info)):
            __last_traceback = __last_traceback.tb_next
        if __last_traceback is not None:
            raise __exc_info[0].with_traceback(__last_traceback)


# Generated at 2022-06-25 22:38:43.771078
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import generate_equivalent_test

    a_s_t_1 = ast.parse("[2, *range(10), 1]")
    a_s_t_1.body[0].value.args[0].elts[0] = ast.Num(2)
    a_s_t_1.body[0].value.args[0].elts[1] = ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(10)], keywords=[]))
    a_s_t_1.body[0].value.args[0].elts[2] = ast.Num(1)
    a_s_t_2 = ast.parse("[2] + list(range(10)) + [1]")
    a_s_t_

# Generated at 2022-06-25 22:38:49.038384
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    StarredUnpackingTransformer_visit_List_0 = StarredUnpackingTransformer(a_s_t_0)
    test_StarredUnpackingTransformer_visit_List_0 = ast.List()
    StarredUnpackingTransformer_visit_List_0.visit_List(test_StarredUnpackingTransformer_visit_List_0)


# Generated at 2022-06-25 22:38:54.966002
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Create an instance of the StarredUnpackingTransformer class
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(None)

    # Create an instance of the List class
    list_0 = ast.List()

    # Set the attribute `elts` to a list of instance(s) of the expr class.
    setattr(list_0, 'elts', [])

    # Call method visit_List of StarredUnpackingTransformer on the ast and list_0
    starred_unpacking_transformer_0.visit_List(list_0)



# Generated at 2022-06-25 22:39:43.847316
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert_equal(starred_unpacking_transformer_0.visit_List(), None)


# Generated at 2022-06-25 22:39:53.253716
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ast_extractor.instrumentation import get_name


# Generated at 2022-06-25 22:39:55.068447
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    with pytest.raises(TypeError):
        StarredUnpackingTransformer()


# Generated at 2022-06-25 22:40:01.112711
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = '[2, *range(10), 1]'
    node = ast.parse(code)
    transformed = StarredUnpackingTransformer(node).visit(node)
    print(code)
    print(transformed)
    print("\n"*3)
    code = 'print(*range(1), *range(3))'
    node = ast.parse(code)
    transformed = StarredUnpackingTransformer(node).visit(node)
    print(code)
    print(transformed)

test_case_0()
test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:40:10.378059
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse("list1 + *list2 + *list3")
    a_s_t_1 = ast.parse("list1 + list(list2) + list(list3)")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_2 = starred_unpacking_transformer_0.visit(a_s_t_0)
    assert (a_s_t_1 == a_s_t_2)


# Generated at 2022-06-25 22:40:17.576066
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    try:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    except Exception as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
        print('Exception from test:')
        raise



# Generated at 2022-06-25 22:40:27.820771
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test 1
    a_s_t_1 = ast.parse('''
        print(*range(1), *range(3))
    ''')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    result_1 = starred_unpacking_transformer_1.visit_Call(a_s_t_1.body[0].value)
    assert result_1 == ast.parse('''
        print(*(list(range(1)) + list(range(3))))
    ''').body[0].value
    assert starred_unpacking_transformer_1._tree_changed

    # Test 2

# Generated at 2022-06-25 22:40:34.698303
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    _a_s_t_1 = ast.parse('[2, *range(10), 1]')
    _a_s_t_1 = _a_s_t_1.body[0].value
    _a_s_t_2 = ast.parse('[2] + list(range(10)) + [1]')
    _a_s_t_2 = _a_s_t_2.body[0].value
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit(_a_s_t_1)


# Generated at 2022-06-25 22:40:36.563978
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:40:44.984463
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=1)], keywords=[], starargs=None, kwargs=None))], keywords=[ast.keyword(arg='end', value=ast.Str(s='\n'))], starargs=None, kwargs=None)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert not call_0 is call_1