

# Generated at 2022-06-25 22:31:26.049184
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    name_0 = module_0.Name(id='range', ctx=module_0.Load())
    call_0 = module_0.Call(func=name_0, args=[], keywords=[module_0.keyword(arg='start', value=module_0.Num(n=10)), module_0.keyword(arg='stop', value=module_0.Num(n=100))])
    name_1 = module_0.Name(id='range', ctx=module_0.Load())

# Generated at 2022-06-25 22:31:32.975266
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.List(elts=[])
    value_9 = starred_unpacking_transformer_0.visit_List(a_s_t_1)
    assert isinstance(value_9, module_0.List)
    assert value_9.elts == []


# Generated at 2022-06-25 22:31:33.928043
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:31:45.180809
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call(module_0.Name(id='None', ctx=module_0.Load()), [], [])
    call_0.args.append(module_0.Name(id='print', ctx=module_0.Load()))
    s_t_a_r_r_e_d_0 = module_0.Starred(module_0.Name(id='x', ctx=module_0.Load()), module_0.Load())
    call_0.args.append(s_t_a_r_r_e_d_0)
    list_0 = module_0.List([], module_0.Load())
    s_t_a_r_r_e_d_0_2 = module_

# Generated at 2022-06-25 22:31:52.171194
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    o_a_s_t_0 = module_0.Call()
    i_a_s_t_0 = module_0.Call()
    i_a_s_t_1 = module_0.Call()
    i_a_s_t_2 = module_0.AST()
    i_a_s_t_1.body = [i_a_s_t_0]
    i_a_s_t_2.body = [i_a_s_t_1]
    i_a_s_t_3 = module_0.Expr()
    i_a_s_t_3.value = i_a_s_t_0
    i_a_s_t_2.body.append(i_a_s_t_3)
    i_a_s_t_

# Generated at 2022-06-25 22:31:58.005825
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(elts=[])
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:32:11.521556
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
  module_0_0 = typed_ast._ast3
  a_s_t___0 = module_0_0.AST()
  module_0_1 = typed_ast._ast3
  a_s_t___1 = module_0_1.AST()
  module_0_2 = typed_ast._ast3
  a_s_t___2 = module_0_2.AST()
  module_0_3 = typed_ast._ast3
  a_s_t___3 = module_0_3.AST()
  module_0_4 = typed_ast._ast3
  a_s_t___4 = module_0_4.AST()
  module_0_5 = typed_ast._ast3
  a_s_t___5 = module_0_5.AST()

# Generated at 2022-06-25 22:32:19.150370
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_node_0 = module_0.Call(func=module_0.Name(id='a'),
                                 args=[module_0.Starred(value=module_0.List(elts=[],
                                                                            ctx=module_0.Load()),
                                                        ctx=module_0.Load())],
                                 keywords=[],
                                 starargs=None,
                                 kwargs=None)
    a_s_t_node_0_ast_0 = a_s_t_node_0
    a_s_t_node_0 = a_s_t_node_0_ast_0

# Generated at 2022-06-25 22:32:25.517973
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    expr_0 = a_s_t_0.List([])
    expr_1 = starred_unpacking_transformer_0.visit_List(expr_0)
    assert type(expr_1) == ast.List


# Generated at 2022-06-25 22:32:40.046215
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = a_s_t_0.List(elts=[a_s_t_0.Num(n=2), a_s_t_0.Starred(value=a_s_t_0.Call(func=a_s_t_0.Name(id='range'), args=[a_s_t_0.Num(n=10)], keywords=[])), a_s_t_0.Num(n=1)], ctx=a_s_t_0.Load())
    list_0.elts[0].lineno = 1
    list_0.elts[0].col_offset = 0
    list_0

# Generated at 2022-06-25 22:32:44.342629
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert True == True

# Generated at 2022-06-25 22:32:54.880960
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = module_0._convert("print(*range(5))")
    original_call_0 = a_s_t_0.body[0].value
    a_s_t_0 = module_0._convert("print(*range(5))")
    call_0 = a_s_t_0.body[0].value
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    result_0 = starred_unpacking_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:33:02.564156
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_0 = module_0.parse('''
[2, *range(10), 1]
''')
    list_0 = ast_0.body[0].value
    result_0 = starred_unpacking_transformer_0.visit_List(list_0)
    print(result_0)


# Generated at 2022-06-25 22:33:10.695387
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Setup argument
    node_0 = None
    
    # Assert pre-condition

    # Exercise
    method_result_0 = starred_unpacking_transformer_0.visit_List(node_0)

    # Assert post-condition
    assert method_result_0 is None


# Generated at 2022-06-25 22:33:17.342649
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    function_call_0 = module_0.Call()
    function_call_0.args = []
    module_0.Call_visit(starred_unpacking_transformer_0, function_call_0)


# Generated at 2022-06-25 22:33:28.616715
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_values_0 = [[3, 4, 6]]
    test_values_1 = [[2, 3, 1]]
    test_values_2 = [[6, 2, 1, 7]]
    test_values_3 = [[9, 1, 3, 6]]
    test_values_4 = [[]]
    test_values_5 = [[3, 7, 5]]
    test_values_6 = [[0, 6, 9]]
    test_values_7 = [[9, 4, 6, 8]]
    test_values_8 = [[1, 7, 2]]
    test_values_9 = [[]]
    test_values_10 = [[1, 9, 5, 0]]
    test_values_11 = [[6, 0, 1, 3]]
    test_values_12 = [[]]

# Generated at 2022-06-25 22:33:37.440566
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    source_0 = module_0.List(elts=[module_0.Num(n=1), module_0.Num(n=2)], ctx=module_0.Load())
    list_0 = starred_unpacking_transformer_0.visit_List(source_0)
    assert list_0 == module_0.List(elts=[module_0.Num(n=1), module_0.Num(n=2)], ctx=module_0.Load())


# Generated at 2022-06-25 22:33:44.151015
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test with no Starred
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(elts=[module_0.Num(n=1), module_0.Num(n=2)])
    result = starred_unpacking_transformer_0.visit_List(list_0)
    assert list_0 is result


# Generated at 2022-06-25 22:33:47.293106
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    assert starred_unpacking_transformer_1 is not None


# Generated at 2022-06-25 22:33:54.369664
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    module_0.Call.args = [call_0]
    print_0 = module_0.Call()
    module_0.Call.func = print_0
    function_def_0 = module_0.FunctionDef()
    module_0.FunctionDef.body = [function_def_0]
    module_0.FunctionDef.name = 'func'
    function_def_1 = module_0.FunctionDef()
    module_0.FunctionDef.body = [function_def_1]
    module_0.FunctionDef.name = 'func'
    module_0.FunctionDef.decor

# Generated at 2022-06-25 22:34:02.436252
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = StarredUnpackingTransformer
    name_0 = module_0.Name(id_0)
    call_0 = module_0.Call(func=name_0, args=[], keywords=[])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:34:06.356541
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_0 = StarredUnpackingTransformer()
    call_0 = module_0.Call()
    class_0._tree_changed = False
    call_1 = class_0.visit_Call(call_0)

# Generated at 2022-06-25 22:34:06.981913
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert True

# Generated at 2022-06-25 22:34:12.134045
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:19.103359
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    str_0 = str()
    str_1 = str()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_

# Generated at 2022-06-25 22:34:31.575975
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    c_a_l_l_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    c_a_l_l_0 = starred_unpacking_transformer_0.visit_Call(c_a_l_l_0)
    a_s_t_0 = module_0.AST()
    c_a_l_l_0 = module_0.Call()
    c_a_l_l_0.args = list_0
    c_a_l_l_0.keywords = list_0
    c_a_l_l_0.starargs = None
    c_a

# Generated at 2022-06-25 22:34:43.646017
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = module_0
    typed_ast__ast3_9 = module_0
    class Call(typed_ast__ast3_9.Call):
        def __init__(self, args):
            self.args = args
    module_1 = module_1
    typed_ast__ast3_10 = module_1
    class AST(typed_ast__ast3_10.AST):
        pass
    class Add(typed_ast__ast3_9.Add):
        pass
    class Name(typed_ast__ast3_9.Name):
        def __init__(self, id):
            self.id = id
    class Starred(typed_ast__ast3_9.Starred):
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-25 22:34:50.460774
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert isinstance(call_1, module_0.Call)

# Generated at 2022-06-25 22:35:04.050215
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import typed_ast.ast3 as ast3
    from tests.visitor.test_base import NodeTestBase
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Assign, Attribute, BinOp, Call, Dict, Expr, \
        FunctionDef, GeneratorExp, IfExp, Index, List, Module, Name, NameConstant, \
        Num, Print, Str, Subscript, UnaryOp, arguments, alias, arg, Assert, Delete, \
        Exec, For, Global, If, ImportFrom, Import, In, Pass, Raise, Return, With, \
        While, Yield, BoolOp, Compare, keyword, Load, Not, Store, AugLoad, AugStore, \
        Del, Param, Eq, Gt, GtE, Is, IsNot, Lt, LtE

# Generated at 2022-06-25 22:35:08.972409
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:35:17.128386
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:35:22.972908
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:35:29.910139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # Create AST
    from typed_ast import ast3 as ast
    node = ast.Call(func=ast.Name(id='foo'),
                    args=[ast.Starred(value=ast.Name(id='bar'))],
                    keywords=[])
    expected = ast.Call(func=ast.Name(id='foo'),
                        args=[ast.Starred(value=ast.List(elts=[ast.Name(id='bar')]))],
                        keywords=[])

    # Unpack arguments
    transformer = StarredUnpackingTransformer(node)
    result = transformer.visit_Call(node)

    # Check result
    assert transformer._tree_changed, "Tree was not changed"
    assert result == expected, "Ast mismatch"



# Generated at 2022-06-25 22:35:35.703269
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:35:43.638190
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_1 = module_0
    list_2 = module_1.List(
        elts=[
            module_1.Num(n=1),
            module_1.Starred(
                value=module_1.Name(id='a'),
                ctx=module_1.Load()),
            module_1.Num(n=2)],
        ctx=module_1.Load())
    module_1.Call(
        func=module_1.Name(id='a'),
        args=[list_2],
        keywords=[])


# Generated at 2022-06-25 22:35:48.093763
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:35:57.905925
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    func_0 = module_0.FunctionDef()
    module_0.arguments(func_0, (), None, (), ())
    module_0.annotation('2', func_0, None)
    f_s_t_0 = module_0.AST()
    module_0.Module(module_0.body(f_s_t_0, (func_0,)))
    func_2 = module_0.FunctionDef()
    module_0.arguments(func_2, (), None, (), ())
    module_0.annotation('2', func_2, None)
    f_s_t_1 = module_0.AST()
    module_0.Module(module_0.body(f_s_t_1, (func_2,)))
    func_4 = module_0.FunctionDef()
    arguments

# Generated at 2022-06-25 22:36:06.123638
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Init StarredUnpackingTransformer
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Init call
    call_0 = module_0.Call()
    # Call method
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    # Assert
    assert call_1 == module_0.Call(args=[module_0.Starred(value=module_0.List())])


# Generated at 2022-06-25 22:36:15.541706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    s = "import builtins; builtins.print(1, 'a', *[1, 2, 3], 4, 'b', 'c', *[5], 6, 'd', 'e')"
    s = ast.parse(s, mode='eval')
    s = StarredUnpackingTransformer().visit(s)
    compile_and_run(s)

    s = ast.parse('print(1, *range(2), 2)', mode='eval')
    print(ast.dump(s))
    s = parse(s, filename='<input>')
    print(ast.dump(s))
    s = StarredUnpackingTransformer().visit(s)
    print(ast.dump(s))
    s = parse(s, filename='<input>')
    print(ast.dump(s))

# Generated at 2022-06-25 22:36:20.390946
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = importlib.import_module('typed_ast._ast3')
    star_0 = StarredUnpackingTransformer()
    list_0 = module_0.List()
    star_0.visit_List(list_0)
    call_0 = module_0.Call()
    star_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:35.479097
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = __import__('2to3_version_1.typed_ast._ast3', globals(), locals(), ['*'], level=0)
    module_1 = __import__('2to3_version_1.typed_ast._ast3', globals(), locals(), ['*'], level=0)
    # Test case where all argument types are AST and are not modified by the method
    # Return type is Call
    list_0 = module_1.List()
    arg_0 = module_1.AST()
    call_0 = module_0.Call(list_0, [arg_0])
    arg_1 = module_1.AST()
    call_1 = module_0.Call(call_0, [arg_1])
    a_s_t_0 = module_1.AST()
    starred

# Generated at 2022-06-25 22:36:40.518039
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:46.955622
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = list_0
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:51.164501
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:54.855724
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(ast_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:37:01.274923
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:11.274838
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0=None
    try:
        #
        # Try to get an object of type module_0.AST from imported module "typed_ast._ast3"
        #
        module_0 = module_0.AST()
    except Exception as e:
        raise Exception("An unexpected exception occurred in test_StarredUnpackingTransformer_visit_Call", e)
    try:
        #
        # Try to call method visit_Call of object module_0.AST
        #
        method_return_value_0 = module_0.visit_Call()
    except Exception as e:
        raise Exception("An unexpected exception occurred while calling method visit_Call", e)
    if not ( method_return_value_0 is None):
        raise Exception("Unexpected output from method visit_Call")


# Generated at 2022-06-25 22:37:17.603605
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test for method visit_Call of class StarredUnpackingTransformer
    module_0 = module_0.Module([])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(module_0.Name(id='print'), [module_0.Starred(module_0.Name(id='range'), module_0.Load())])
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:21.969276
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as module_0
    ast_instance_0 = module_0.parse("a(*range(100))")
    StarredUnpackingTransformer_instance_0 = StarredUnpackingTransformer(ast_instance_0)
    StarredUnpackingTransformer_instance_0.visit(ast_instance_0)


# Generated at 2022-06-25 22:37:28.339977
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:37.960582
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '*{a: 1, b: 2}'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    with pytest.raises(TypeError):
        starred_unpacking_transformer_0.visit_List(var_0)


# Generated at 2022-06-25 22:37:38.570704
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:37:44.035696
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print('Executing test test_StarredUnpackingTransformer_visit_List...')
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert var_0 != var_1
    assert var_1 == module_0.parse('[2] + list(range(10)) + [1]')



# Generated at 2022-06-25 22:37:48.535995
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'a(*range(100))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:37:52.466892
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[*range(10)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:56.592409
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[a, *b]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:04.450740
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    arg_0 = module_0.Call()
    arg_0.func = module_0.Name(id='print')
    arg_0.args = [module_0.Starred(value=module_0.Name(id='range'), ctx=module_0.Load())]
    arg_0.keywords = []
    arg_1 = module_0.parse(str(arg_0))
    striped_unpacking_transformer_0 = StarredUnpackingTransformer(arg_1)
    assert str(striped_unpacking_transformer_0.visit(arg_1)) == 'print(*range)'


# Generated at 2022-06-25 22:38:05.875046
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:38:10.625791
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    arg0 = None
    arg1 = None
    arg2 = True
    arg3 = False
    arg4 = False
    arg5 = True
    arg6 = True
    arg7 = None
    arg8 = True
    arg9 = True
    
    StarredUnpackingTransformer(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
    

# Generated at 2022-06-25 22:38:12.957345
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    n = 1
    while n <= 20:
        try:
            test_case_0()
        except:
            print("Test failed")
            raise
        n += 1
    else:
        print("Test passed")

# Generated at 2022-06-25 22:38:26.789409
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[*range(100), *range(10)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert str(var_1) == '[*(list(range(100)) + list(range(10)))]'
    str_1 = '[*range(10), *range(20)]'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)

# Generated at 2022-06-25 22:38:30.441918
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = 'a(*range(100))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:31.603841
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass


# Generated at 2022-06-25 22:38:40.166594
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert (str(var_1) == '([2] + list(range(10)) + [1])'), 'AssertionError: {}'.format(str(var_1))


# Generated at 2022-06-25 22:38:43.826760
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # AstTree
    var_0 = ast.parse('[*range(100)]')
    var_1 = StarredUnpackingTransformer(var_0)
    RuntimeError_0 = RuntimeError()
    RuntimeError_0.code = "TypeError: TODO"
    with raises(RuntimeError_0):
        var_1._to_sum_of_lists([])


# Generated at 2022-06-25 22:38:48.755523
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[2, *range(10), 1]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    module_0.fix_missing_locations(var_1)


# Generated at 2022-06-25 22:38:51.780402
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[*range(100)]'
    module_0 = module_0.parse(str_0)
    var_0 = StarredUnpackingTransformer(module_0)
    var_0.visit_List(module_0)


# Generated at 2022-06-25 22:38:59.709253
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    _0 = ast.List()
    _0.elts = []
    _1 = ast.List()
    _1.elts = [_0]

    _2 = ast.List()
    _2.elts = [_1]

    _3 = ast.List()
    _3.elts = [_2]

    _4 = ast.List()
    _4.elts = [_3]

    assert _4.elts[0].elts[0].elts[0].elts == []

    _0 = ast.List()
    _0.elts = [ast.Starred(value=_1)]

    _1 = ast.List()
    _1.elts = [ast.Starred(value=_2)]

    _2 = ast.List()

# Generated at 2022-06-25 22:39:07.530677
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = ("a = [1, *range(100), 99]")
    var_0 = module_0.parse(str_0)
    str_1 = ("s = [1, *range(100), 99]")
    var_1 = module_0.parse(str_1)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_2 = starred_unpacking_transformer_0.visit(var_0)
    assert str(module_0.dump(var_2)) == str(module_0.dump(var_1))


# Generated at 2022-06-25 22:39:17.301876
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    var_0 = module_0.parse('a.b(*range(10), [4, 5, *range(6)])')
    var_1 = StarredUnpackingTransformer(var_0)
    var_2 = var_1.visit(var_0)
    var_3 = str(var_2)
    str_0 = '''a.b(*(list(range(10)) + [[4, 5] + list(range(6))]))'''
    assert var_3 == str_0
    var_4 = module_0.parse('a.b([4, 5, *range(6)], *range(10))')
    var_5 = StarredUnpackingTransformer(var_4)
    var_6 = var_5.visit(var_4)

# Generated at 2022-06-25 22:39:28.266764
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    case___1_0 = module_0.parse('[2, *range(10), 1]')
    var_1 = StarredUnpackingTransformer(case___1_0)
    var_2 = var_1.visit(case___1_0)


# Generated at 2022-06-25 22:39:31.658524
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = 'a(*range(100))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert True


# Generated at 2022-06-25 22:39:37.710277
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = 'a(*range(100))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert starred_unpacking_transformer_0._tree_changed == True
    assert starred_unpacking_transformer_0._target == (3, 4)


# Generated at 2022-06-25 22:39:48.513137
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test: Only args
    str_0 = 'a(*range(1))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_Call(var_0.body[0].value)  # type: ignore
    str_1 = module_0.unparse(var_1)
    assert str_1 == 'a(*(list(range(1))))'

    # Test: Args before kwargs
    str_2 = 'a(*range(1), b=1)'
    var_2 = module_0.parse(str_2)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
   

# Generated at 2022-06-25 22:39:52.275736
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'a(*range(100))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:39:55.347008
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = 'a([2, *range(100), 3])'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:59.737037
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[1, *range(100), *range(100)]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    print(repr(var_1))


# Generated at 2022-06-25 22:40:10.326910
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test method StarredUnpackingTransformer.visit_List."""
    str_0 = '[1, *range(100), 100]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List(var_0.body[0].value)
    assert var_1.elts[0].n == 1
    assert var_1.elts[1].func.id == 'list'
    assert var_1.elts[1].args[0].func.id == 'range'
    assert var_1.elts[1].args[0].args[0].n == 100
    assert var_1.elts[2].n == 100


# Generated at 2022-06-25 22:40:17.576138
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = 'a(*range(100))'
    var_0 = module_0.parse(str_0)
    try:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    except TypeError:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)


# Generated at 2022-06-25 22:40:21.634346
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer(None)
    var_1 = StarredUnpackingTransformer((None,))
    var_2 = StarredUnpackingTransformer(None)


# Generated at 2022-06-25 22:40:33.999048
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer(None)
    assert var_0.generic_visit is not None


# Generated at 2022-06-25 22:40:37.792199
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = 'a([1, *range(10), 2])'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.unparse(var_1)
    assert(str_0 == var_2)


# Generated at 2022-06-25 22:40:46.585833
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test 1: Expecting an error that the source code is not typed-AST, but Python source code.
    str_1 = 'def fun(x): return x'
    with raises(NotImplementedError):
        StarredUnpackingTransformer(str_1)
    # Test 2: Expecting an error because the source code has already been compiled
    str_2 = compile(str_1, '', 'exec')
    with raises(NotImplementedError):
        StarredUnpackingTransformer(str_2)
    # Test 3: Expecting an error because the argument is not ast.AST or ast.Module, but a string
    with raises(AssertionError):
        StarredUnpackingTransformer(str_1)


# Generated at 2022-06-25 22:40:55.110482
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = 'a([2, *range(10), 1])'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = '__main__'
    var_3 = module_0.parse(var_2)
    str_1 = 'a([2] + list(range(10)) + [1])'
    var_4 = module_0.parse(str_1)
    var_5 = var_1.body
    var_6 = var_4.body
    var_7 = var_5[0]
    var_8 = var_7.value
    var_9 = var_

# Generated at 2022-06-25 22:40:57.057028
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

if __name__ == "__main__":
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:41:05.374220
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Passing mocked arguments
    str_0 = 'a(*range(100))'
    module_0 = mock.Mock()
    module_1 = mock.Mock()
    module_0.parse.return_value = module_1
    module_2 = mock.Mock()

    module_1.args = module_2
    module_1.args = mock.Mock()
    module_3 = mock.Mock()

    module_1.args = [module_3]
    module_3.value = 1

    module_1.args = mock.Mock()
    module_4 = mock.Mock()

    module_1.args = [module_4]
    module_4.value = 2

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(module_1)

# Generated at 2022-06-25 22:41:08.805589
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    var_0 = module_0.parse('a(*range(100))')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:41:11.487866
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '[]'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_List()
