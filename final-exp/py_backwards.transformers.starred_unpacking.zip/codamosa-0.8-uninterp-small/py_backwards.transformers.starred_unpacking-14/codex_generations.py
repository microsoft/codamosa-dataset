

# Generated at 2022-06-25 22:31:23.417312
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_12 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 22:31:29.134811
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    try:
        starred_unpacking_transformer_1.visit_List("")
    except NotImplementedError as instance_0:
        assert type(instance_0) is NotImplementedError
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:31:40.401718
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_0 = module_0.List(elts=[module_0.Num(n=2), module_0.Starred(value=module_0.Call(func=module_0.Name(id='range'), args=[module_0.Num(n=10)], keywords=[]), ctx=module_0.Load()), module_0.Num(n=1)])
    with pytest.raises((NotImplementedError, RuntimeError)):
        # Action
        returned_value_0 = StarredUnpackingTransformer.visit_List(starred_unpacking_transformer_0, node_0)

# Unit test

# Generated at 2022-06-25 22:31:49.609695
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()

    s_u_t_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:31:59.641561
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    module_1 = ast.parse('print()')
    call_0 = module_1.body[0].value
    result_0 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert result_0 == call_0

    module_2 = ast.parse('print(1, 2, 3)')
    call_1 = module_2.body[0].value
    result_1 = starred_unpacking_transformer_0.visit_Call(call_1)
    assert result_1 == call_1

    module_3 = ast.parse('print(*[1])')
    call_2 = module_3.body

# Generated at 2022-06-25 22:32:03.890233
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:32:14.806932
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    module_0.copy_location(a_s_t_1, ellipsis)
    module_0.fix_missing_locations(a_s_t_1)
    list_0 = module_0.List(elts=[], ctx=a_s_t_1)
    module_0.copy_location(list_0, ellipsis)
    module_0.fix_missing_locations(list_0)
    result = starred_unpacking_transformer_0.visit_List(list_0)
    assert result is not list_0
    assert result

# Generated at 2022-06-25 22:32:22.745463
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_1 = module_0.Call()
    call_1.args = [module_0.Name()]
    call_1.func = None
    call_1.keywords = []
    call_1.starargs = None
    call_1.kwargs = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert(starred_unpacking_transformer_0.visit_Call(call_1) == None)


# Generated at 2022-06-25 22:32:32.332106
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(
        elts=[
            module_0.Name(id='a'), 
            module_0.Starred(
                value=module_0.Name(id='b'), 
                ctx=module_0.Load())], 
        ctx=module_0.Load())
    assert starred_unpacking_transformer_0.visit_List(list_0).elts[1] == module_0.Call(
        func=module_0.Name(id='list'), 
        args=[module_0.Name(id='b')], 
        keywords=[])


# Generated at 2022-06-25 22:32:33.312299
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:32:49.649460
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    node = ast.List(elts=[ast.Starred(value=ast.Call(func=ast.Name(id='foo'), args=[], keywords=[])), ast.Starred(value=ast.Call(func=ast.Name(id='bar'), args=[], keywords=[]))])
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    star_unpack_tree_0 = module_0.parse('", ".join([str(x) for x in [foo, bar]])')
    result_value_0 = module_0.dump(starred_unpacking_transformer_0.visit_Call(node))

# Generated at 2022-06-25 22:32:57.834863
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    c_a_l_l_0 = module_0.Call()
    list_0 = module_0.List()
    n_a_m_e_0 = module_0.Name()
    n_a_m_e_1 = module_0.Name()
    list_0.elts = [n_a_m_e_0, n_a_m_e_1]
    p_r_i_n_t_0 = module_0.Print()
    p_r_i_n_t_0.dest = n_a_m_e_0
    p_r_i_n_t_1 = module_

# Generated at 2022-06-25 22:33:05.883541
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    list_0 = module_0.List(elts=[module_0.Name(id='range'), module_0.Name(id='range')], ctx=module_0.Load())
    try:
        starred_unpacking_transformer_0.visit_List(list_0)
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-25 22:33:07.392625
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    c = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:33:19.244102
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    call_0.args.append(call_0)
    call_0.args.append(call_0)

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0._has_starred(["1", "2"])
    starred_unpacking_transformer_0._split_by_starred(["1", "2"])
    starred_unpacking_transformer_0._prepare_lists([[call_0], call_0])
    starred_unpacking_transformer_0._to_sum_of_lists(["1", "2"])
    starred_unpacking_transformer_0.visit

# Generated at 2022-06-25 22:33:25.680830
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    # Test for default argument
    with pytest.raises(TypeError):
        StarredUnpackingTransformer(a_s_t_0)
    # Get method object
    call_1 = StarredUnpackingTransformer.visit_Call
    # Assert method return type
    assert isinstance(call_1(starred_unpacking_transformer_0, node_0), module_0.Call)


# Generated at 2022-06-25 22:33:32.528712
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = None
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(elts=[], ctx=module_0.Load())
    list_0 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:33:37.147659
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:47.162711
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_List_0 = module_0.List(elts=[], ctx=module_0.Load())
    ast_BinOp_0 = module_0.BinOp(left=ast_List_0, op=module_0.Add(), right=ast_List_0)
    ast_Expr_0 = module_0.Expr(value=ast_BinOp_0)
    ast_Assign_0 = module_0.Assign(targets=[ast_List_0], value=ast_BinOp_0)

# Generated at 2022-06-25 22:33:56.739764
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # prepare
    a_s_t_0 = module_0.AST()
    a_s_t_0.arguments = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])

# Generated at 2022-06-25 22:34:11.243940
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(
        value=ast.BinOp(left=ast.List(elts=[ast.call(func=ast.Name(id='list'), args=[ast.Name(id='range')], keywords=[], starargs=None, kwargs=None)]
            ), right=ast.List(elts=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[])]), op=ast.Add()))], keywords=[])

# Generated at 2022-06-25 22:34:20.477688
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Create the AST
    module_node = ast.Module(body=[ast.Expr(value=ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)]))])

    # Construct StarredUnpackingTransformer
    transformer_StarredUnpackingTransformer = StarredUnpackingTransformer()
    transformed_module_node = transformer_StarredUnpackingTransformer.visit(node=module_node)

    # Check if the transformed tree is equal to the expected output tree

# Generated at 2022-06-25 22:34:21.881078
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3,4)

# Generated at 2022-06-25 22:34:33.879172
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    

    assert starred_unpacking_transformer_0.visit_Call(['*', ['range', ['1']]]) == ['print', ['*', [['list', ['range', ['1']]]]]]
    assert starred_unpacking_transformer_1.visit_Call([[['range', ['1']]], ['+', [['range', ['3']]]], ['+', ['list', ['range', ['1']]]]]) == ['print', ['*', [['list', ['range', ['1']]]]]]

# Generated at 2022-06-25 22:34:45.650554
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node1 = ast.Starred(value=1, ctx=ast.Store())
    args = [ast.Name(id='a', ctx=ast.Load()), ast.Name(id='b', ctx=ast.Load()), node1]
    node2 = ast.Call(func=ast.Name(id='c', ctx=ast.Load()), args=args, keywords=[])
    node3 = ast.Name(id='d', ctx=ast.Load())
    code1 = """c(a, b, *d)"""
    code2 = """*d"""
    tree = ast.parse(code1)
    node4 = tree.body[0]
    assert isinstance(node4, ast.Expr)
    assert isinstance(node4.value, ast.Call)

# Generated at 2022-06-25 22:34:56.520800
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visited_node = ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()), 
            args=[
                ast.Name(id='*args', ctx=ast.Load()),
                ast.Starred(
                    value=ast.Name(id='args', ctx=ast.Load())
                )
            ], 
            keywords=[]
        )

# Generated at 2022-06-25 22:35:07.207370
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # first test case
    transformer1 = StarredUnpackingTransformer()
    test_input1 = ast.parse('print(*range(1), *range(3))')
    test_expected_output1 = ast.parse('''
                                print(*(list(range(1)) + list(range(3))))
                                ''')

    test_output1 = transformer1.visit(test_input1)
    assert ast.dump(test_output1) == ast.dump(test_expected_output1)

    # second test case
    transformer2 = StarredUnpackingTransformer()
    test_input2 = ast.parse('print(*range(1), 2)')
    test_expected_output2 = ast.parse('''
                                print(*(list(range(1)) + [2]))
                                ''')



# Generated at 2022-06-25 22:35:08.816305
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-25 22:35:17.088047
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]", "<test>", "exec")
    expected_tree = ast.parse("[2] + list(range(10)) + [1]", "<test>", "exec")
    starred_unpacking_transformer_visit_List = StarredUnpackingTransformer()
    transformed_tree_visit_List = starred_unpacking_transformer_visit_List.visit(tree)
    assert astor.to_source(transformed_tree_visit_List) == astor.to_source(expected_tree)


# Generated at 2022-06-25 22:35:25.767128
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(
        ast.parse('''
[2, *range(10), 1]
        ''').body[0]).body[0].elts == \
           [ast.BinOp(left=ast.List(elts=[ast.Num(n=2)]),
                      op=ast.Add(),
                      right=ast.Call(args=[ast.Call(args=[ast.Num(n=10)],
                                                    keywords=[],
                                                    func=ast.Name(id='range'))],
                                     func=ast.Name(id='list'),
                                     keywords=[])),
            ast.Num(n=1)]



# Generated at 2022-06-25 22:35:44.123129
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # test 0: test that you can visit_List with no starred
    assert (
        ast.dump(StarredUnpackingTransformer().visit(ast.parse('[1, 2]'))) ==
        'List(elts=[Num(n=1), Num(n=2)], ctx=Load())')

    # test 1: test that you can visit_List with starred
    assert (
        ast.dump(StarredUnpackingTransformer().visit(ast.parse('[1, *range(1)]'))) ==
        'List(elts=[Num(n=1), Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(\'range\', Load()), args=[Num(n=1)], keywords=[])], keywords=[])], ctx=Load())')

    # test 2:

# Generated at 2022-06-25 22:35:48.952914
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    starred_unpacking_transformer_1 = StarredUnpackingTransformer()
    assert starred_unpacking_transformer_1 is not None
    ast_1 = ast.parse("print(1, *[1,2], 3)")
    assert ast_1 is not None
    assert starred_unpacking_transformer_1.visit(ast_1) is not None


# Generated at 2022-06-25 22:35:52.223760
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_ = ast.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer()
    starred_unpacking_transformer_0.visit(ast_)



# Generated at 2022-06-25 22:35:54.915228
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    StarredUnpackingTransformer().visit_Call(
        ast.Call(func=ast.Name(id='print'),
                 args=[],
                 keywords=[]))


# Generated at 2022-06-25 22:36:05.729173
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .starred_unpacking import Splitted
    from .starred_unpacking import ListEntry
    starred_unpacking_transformer_0 = StarredUnpackingTransformer()
    # BEGIN
    node_0 = ast.Call(
        func=ast.Attribute(
            value=ast.Name(
                id='print',
                ctx=ast.Load()),
            attr='__init__',
            ctx=ast.Load()),
        args=[
            ast.Starred(
                value=ast.Name(
                    id='range',
                    ctx=ast.Load()),
                ctx=ast.Load())],
        keywords=[])
    # END

# Generated at 2022-06-25 22:36:07.146031
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-25 22:36:08.350534
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert True


# Generated at 2022-06-25 22:36:13.686773
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
[2, 3, 4, 5, 1]
    """

    expected = """
[2, 3, 4, 5, 1]
    """

    node = ast.parse(code)

    starred_unpacking_transformer_0 = StarredUnpackingTransformer()
    result = starred_unpacking_transformer_0.visit(node)

    assert astor.to_source(result) == expected



# Generated at 2022-06-25 22:36:21.547780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node_0 = ast.Call(
        func=ast.Name(id='foo'),
        args=[ast.Starred(value=ast.Name(id='a'), ctx=ast.Load())],
        keywords=[])
    result_0 = transformer.visit_Call(node_0)
    node_1 = ast.Call(
        func=ast.Name(id='foo'),
        args=[ast.Starred(value=ast.List(elts=[ast.Num(n=1), ast.Name(id='a')], ctx=ast.Load()))],
        keywords=[])

    assert result_0 == node_1


# Generated at 2022-06-25 22:36:30.819205
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:36:47.527321
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    method_0 = type(starred_unpacking_transformer_0).visit_List
    method_0(starred_unpacking_transformer_0, list_0)
    call_0 = module_0.Call()
    method_1 = type(starred_unpacking_transformer_0).visit_Call
    method_1(starred_unpacking_transformer_0, call_0)
    assert starred_unpacking_transformer_0._tree_changed == False

# Generated at 2022-06-25 22:36:52.345591
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test 1
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:52.927978
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:37:04.096706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from unittest import TestCase
    from unittest import mock

    from typed_ast import ast3 as ast

    class MockStarredUnpackingTransformer(StarredUnpackingTransformer):
        def _has_starred(self, xs: List[ast.expr]) -> bool:
            pass

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            pass

        def _prepare_lists(self, xs: List[Splitted]) -> Iterable[ListEntry]:
            pass

        def _merge_lists(self, xs: List[ListEntry]) -> Union[ast.BinOp, ListEntry]:
            pass


# Generated at 2022-06-25 22:37:09.765403
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = module_0.Call()
    call_1.args = list_0
    call_2 = starred_unpacking_transformer_0.visit_Call(call_1)

# Generated at 2022-06-25 22:37:14.863273
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:15.833018
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert False


# Generated at 2022-06-25 22:37:18.182581
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:37:23.419560
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # set up test data
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # invoke the method
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:37:30.160563
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert (list_0 is list_1)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:37:42.570758
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    call_0 = module_0.Call()
    call_0.args = [list_0]
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:37:48.490569
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Set up context
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    # Force exception
    try:
        # Call the method
        return_value_0 = StarredUnpackingTransformer(a_s_t_0).visit_List(list_0)
    except:
        pass

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:37:53.464407
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse('')
    list_0 = module_0.body[0].value
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_Call(list_0)


# Generated at 2022-06-25 22:37:57.795342
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = StarredUnpackingTransformer
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:37:58.649250
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert test_case_0() == None

# Generated at 2022-06-25 22:38:03.569115
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:38:07.520677
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Assert #0
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert isinstance(starred_unpacking_transformer_0, StarredUnpackingTransformer)



# Generated at 2022-06-25 22:38:15.490802
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    constructor_args = []
    try:
        StarredUnpackingTransformer(constructor_args) # Try to instantiate with an invalid type of arguments
    except TypeError:
        pass
    
    a_s_t_0 = module_0.AST()
    constructor_args = [a_s_t_0]
    instance = StarredUnpackingTransformer(constructor_args) # Type hint: StarredUnpackingTransformer
    assert isinstance(instance, StarredUnpackingTransformer)
    assert hasattr(instance, '_tree_changed')
    assert hasattr(instance, '_starred_unpacking_transformer')
    assert hasattr(instance, '_visit_children')
    assert hasattr(instance, 'visit')
    assert hasattr(instance, 'generic_visit')

# Generated at 2022-06-25 22:38:19.497692
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    #
    test_case_0()
    test_case_0()
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #

# Generated at 2022-06-25 22:38:22.368155
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ast_0 = module_0.AST()
    StarredUnpackingTransformer(ast_0)


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 22:38:43.183447
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert(list_0 == list_1)


# Generated at 2022-06-25 22:38:48.115946
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_1 = module_0.List()
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:38:53.844573
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Declare variables to use in test
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    # The above assert statement will fail when method visit_List of class StarredUnpackingTransformer is implemented
    pytest.fail('Test #0 failed: visit_List not implemented')

# Generated at 2022-06-25 22:38:57.571843
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:39:03.042593
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert isinstance(starred_unpacking_transformer_0, StarredUnpackingTransformer)

    # Test try-except
    try:
        StarredUnpackingTransformer()
    except Exception:
        pass
    else:
        raise AssertionError("No exception was thrown")


# Generated at 2022-06-25 22:39:08.057962
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:39:12.765052
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:39:17.257437
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:39:23.089431
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:39:27.350596
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:40:02.726480
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse("print(*range(1), *range(3))")
    source_0 = module_0
    a_s_t_0 = ast.AST(source_0)
    call_0 = module_0.body[0].value
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:40:11.385369
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    import typed_ast
    import typed_ast._ast3
    a_s_t_2 = typed_ast._ast3.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)
    call_0 = typed_ast._ast3.Call()
    call_1 = starred_unpacking_transformer_2.visit_Call(call_0)


# Generated at 2022-06-25 22:40:17.387984
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = List()
    a_s_t_0 = AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = Call()
    call_0 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:40:22.650253
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:40:25.971025
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:40:26.768457
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass # TODO: implement your test here

# Generated at 2022-06-25 22:40:30.155304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = '''
[2, 3]
    '''
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer(tree)
    result_tree = transformer.get_ast()

    assert isinstance(result_tree, ast.AST)
    assert transformer.is_changed() is False


# Generated at 2022-06-25 22:40:34.697985
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module0 = module_0
    test0 = module0.parse(
    """\
    print(*[1, 2])
    """
    )
    test1 = StarredUnpackingTransformer().visit(test0)
    assert repr(test1) == "Module([Expr(Call(Name('print', Load()), [Starred(List([Num(1), Num(2)], Load()), Load())], []))], [])"


# Generated at 2022-06-25 22:40:36.077521
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = module_0.AST()
    StarredUnpackingTransformer(a)


# Generated at 2022-06-25 22:40:39.062549
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)