

# Generated at 2022-06-25 22:31:24.217233
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('''print(*range(1), *range(3))''')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = ast.parse('''print(*(list(range(1)) + list(range(3))))''')
    assert ast.dump(starred_unpacking_transformer_0.visit(a_s_t_0), include_attributes=True) == ast.dump(a_s_t_0, include_attributes=True)
    return


# Generated at 2022-06-25 22:31:35.635233
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:31:46.736511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Prepare
    a_s_t_1 = None
    node_2 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)], ctx=ast.Load())

    # Execute
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    result_3 = starred_unpacking_transformer_1.visit_List(node_2)

    # Evaluate
    assert isinstance(result_3, ast.List)
    assert len(result_3.elts) == 3
    assert isinstance(result_3.elts[0], ast.Num)

# Generated at 2022-06-25 22:31:57.497087
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.Call(
        args=[],
        func=ast.Name(id='func'),
        keywords=[],
    )
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast.fix_missing_locations(starred_unpacking_transformer_0)
    a_s_t_1 = ast.Call(
        args=[],
        func=ast.Name(id='func'),
        keywords=[],
    )
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    ast.fix_missing_locations(starred_unpacking_transformer_1)

# Generated at 2022-06-25 22:32:03.276565
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(None)
    actual_0 = starred_unpacking_transformer_0.visit_List(None)
    excepted_0 = None
    assert actual_0 == excepted_0


# Generated at 2022-06-25 22:32:09.648909
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('Running test case (0)')
    a_s_t_0 = ast.parse('', mode='single')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = ast.Call()
    starred_unpacking_transformer_0.visit(call_0)
    print('Successful')

# Generated at 2022-06-25 22:32:18.326903
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

# Generated at 2022-06-25 22:32:26.423195
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse("print(*range(10), *range(1))")
    a_s_t_1 = ast.parse("print(*(list(range(10)) + list(range(1))))")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0 = starred_unpacking_transformer_0.run()
    assert (a_s_t_0 == a_s_t_1)


# Generated at 2022-06-25 22:32:32.270345
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:32:39.353923
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    py_src = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
    
    """
    expected_result = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    
    """
    # Test
    result = get_ast(py_src, StarredUnpackingTransformer)

    assert(expected_result == astunparse.unparse(result))

# Generated at 2022-06-25 22:32:46.582234
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with pytest.raises(RuntimeError):
        x = None
        y = 5
        z = 7
        x = y + z
        assert x == 12
        x = x + y
        assert x == 17
        assert False


# Generated at 2022-06-25 22:32:54.423254
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    list_0 = ast.List(elts=[ast.Starred(value=ast.List(elts=[], ctx=ast.Load()), ctx=ast.Load())])
    ast.List(elts=[ast.Starred(value=list_0, ctx=ast.Load())], ctx=ast.Load())

    assert starred_unpacking_transformer_0._tree_changed


# Generated at 2022-06-25 22:33:05.912388
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    e_ast_0 = ast.BinOp(left=ast.Call(func=ast.Name(id='list'),
                              args=[ast.Name(id='range')],
                              keywords=[]),
                        right=ast.List(elts=[]),
                        op=ast.Add())
    e_ast_1 = ast.BinOp(left=e_ast_0,
                        right=ast.List(elts=[ast.Num(n=1)]),
                        op=ast.Add())
    e_ast_2 = ast.Expr(value=e_ast_1)
    ast_0 = ast.Module(body=[e_ast_2])

    expected = ast.Module(body=[e_ast_2])

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(ast_0)

# Generated at 2022-06-25 22:33:15.566116
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    import typed_ast.ast3 as typed_ast
    #  print([1, *range(5), 2, *range(3)])
    a_s_t_0 = ast.Call(args=[ast.Starred(value=ast.Name(id='range', ctx=typed_ast.Load()), ctx=typed_ast.Load())],
                       func=ast.Name(id='print', ctx=typed_ast.Load()),
                       keywords=[])
    starred_unpacking_transformer_0 = StaredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:33:22.210622
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    a_s_t_0 = ast.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # self.assertEqual(starred_unpacking_transformer_0.visit_List(), [2] + list(range(10)) + [1])
    # TODO: Test throws NotImplementedError; fix test


# Generated at 2022-06-25 22:33:33.525820
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = ast.parse('')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    starred_unpacking_transformer_1._tree_changed = False
    list_1 = ast.parse('[2, *range(10), 1]')
    a_s_t_2 = list_1
    starred_unpacking_transformer_1.generic_visit(a_s_t_2)
    res_1 = starred_unpacking_transformer_1.visit(a_s_t_2)
    expected_1 = ast.parse('[2, *(list(range(10)) + [1])]')
    assert ast.dump(res_1) == ast.dump(expected_1)
    assert starred_unpacking

# Generated at 2022-06-25 22:33:40.568393
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.parse('print(*range(1))')
    a_s_t_1 = a_s_t_1.body[0].value
    assert type(starred_unpacking_transformer_0.visit_List(a_s_t_1)) == ast.Call


# Generated at 2022-06-25 22:33:46.713248
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.List(elts=[], ctx=None)
    result = starred_unpacking_transformer_0.visit_List(a_s_t_1)
    assert type(result) == ast.List
    assert len(result.elts) == 0
    assert result.ctx == None


# Generated at 2022-06-25 22:33:54.039376
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.List(elts=[], ctx=ast.Load())
    assert starred_unpacking_transformer_0._has_starred(a_s_t_1.elts) == False
    a_s_t_1 = ast.List(elts=[], ctx=ast.Store())
    assert starred_unpacking_transformer_0._has_starred(a_s_t_1.elts) == False
    a_s_t_1 = ast.List(elts=[], ctx=ast.Del())

# Generated at 2022-06-25 22:34:05.176840
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Local variable(s) declaration
    a_s_t_0 = None
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None
    a_s_t_15 = None
    a_s_t_16 = None
    a_

# Generated at 2022-06-25 22:34:15.895009
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = ast.parse('*[2, 3]')
    ast.fix_missing_locations(a_s_t_0)
    assert isinstance(a_s_t_0, ast.Module)
    assert isinstance(a_s_t_0.body[0], ast.Expr)
    assert isinstance(a_s_t_0.body[0].value, ast.Starred)
    assert isinstance(a_s_t_0.body[0].value.value, ast.List)
    assert len(a_s_t_0.body[0].value.value.elts) == 2
    assert isinstance(a_s_t_0.body[0].value.value.elts[0], ast.Num)

# Generated at 2022-06-25 22:34:24.850577
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('''print(*range(1), *range(3))''')
    a_s_t_1 = ast.parse('''print(*(list(range(1)) + list(range(3))))''')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_2 = starred_unpacking_transformer_0.visit(a_s_t_1)
    assert a_s_t_2 == a_s_t_1


# Generated at 2022-06-25 22:34:35.608792
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Input
    a_s_t_0 = None

    # Testing input
    try:
        is_instance_0 = isinstance(a_s_t_0, ast.AST)
    except Exception as e_0:
        print(str(e_0))
    else:
        if not is_instance_0:
            raise RuntimeError('Variable a_s_t_0 might not have been initialized.')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Testing output
    try:
        visit_Call_0 = starred_unpacking_transformer_0.visit_Call(a_s_t_0)
    except Exception as e_0:
        print(str(e_0))

# Generated at 2022-06-25 22:34:40.219019
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = "null"
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert starred_unpacking_transformer_0 is not None


# Generated at 2022-06-25 22:34:41.542695
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    assert StarredUnpackingTransformer(a_s_t_0).node is a_s_t_0


# Generated at 2022-06-25 22:34:50.629492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    func_0 = None

    args_0 = [None, None]

    keywords_0 = []

    node_0 = ast.Call(func_0, args_0, keywords_0)

    try:
        starred_unpacking_transformer_0.visit_Call(node_0)
    except:
        assert False, 'Expected no exception'


# Generated at 2022-06-25 22:34:57.661714
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    _ = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:35:00.859205
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:35:05.653095
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('print(*[1, 2], *[3])', mode='eval')
    a_s_t_1 = ast.parse('print(*list([1, 2]) + list([3]))', mode='eval')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    starred_unpacking_transformer_0.visit(a_s_t_0)
    assert(str(starred_unpacking_transformer_0) == str(starred_unpacking_transformer_1))


# Generated at 2022-06-25 22:35:11.663218
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    try:
        print(">>>>>>>>> 1")
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_StarredUnpackingTransformer()
    print("Success!!!")

# Generated at 2022-06-25 22:35:25.483614
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('test StarredUnpackingTransformer()')
    ast1 = ast.parse('[2, *range(10), 1]')
    ast2 = ast.parse('print(*range(1), *range(3))')
    ast3 = ast.parse('[2, 3, 4]')
    ast4 = ast.parse('print(2, 3)')

    str0 = '[2, *range(10), 1]'
    str1 = 'print(*range(1), *range(3))'
    str2 = '[2, 3, 4]'
    str3 = 'print(2, 3)'

    star_unpack_0 = StarredUnpackingTransformer(ast1)
    star_unpack_1 = StarredUnpackingTransformer(ast2)

# Generated at 2022-06-25 22:35:29.668506
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse('print(1, *[1, *[1, *[1]]])')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:35:30.755222
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass


# Generated at 2022-06-25 22:35:41.353035
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Implementation of test case 1
    call_0 = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Name(id='x'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='y'), ctx=ast.Load())],
        keywords=[]
    )
    star_0 = ast.Starred(value=ast.Name(id='x'), ctx=ast.Load())
    star_1 = ast.Starred(value=ast.Name(id='y'), ctx=ast.Load())

# Generated at 2022-06-25 22:35:51.219959
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    name_0 = ast.Name(id='a')
    call_0 = ast.Call(func=name_0, args=[], keywords=[])
    try:
        starred_unpacking_transformer_0.visit_Call(call_0)
    except Exception:
        pass
    else:
        raise AssertionError('expected Exception to be raised')
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    str_0 = ast.Str(s='a')
    starred_0 = ast.Starred(value=str_0)

# Generated at 2022-06-25 22:36:01.372174
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    #
    # Call method visit_List of class StarredUnpackingTransformer
    #
    # [2, *range(10), 1]
    #
    a_s_t_1 = ast.Constant(value=2)
    a_s_t_2 = ast.Constant(value=10)
    a_s_t_3 = ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[a_s_t_2], keywords=[]))
    a_s_t_4 = ast.Constant(value=1)

# Generated at 2022-06-25 22:36:04.071433
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert callable(StarredUnpackingTransformer)


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:36:07.194997
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:36:13.201811
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List(elts=[])
    ast.copy_location(list_0, list_0)
    ast.fix_missing_locations(list_0)
    assert starred_unpacking_transformer_0.visit_List(list_0) == list_0


# Generated at 2022-06-25 22:36:16.717178
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_1 = ast.List()
    if True:
        assert True
    else:
        raise AssertionError


# Generated at 2022-06-25 22:36:29.164422
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_2 = None
    call_2 = ast.Call(func=ast.Name(id='list'), args=[a_s_t_2], keywords=[])
    bin_op_3 = ast.BinOp(left=a_s_t_2, right=a_s_t_2, op=ast.Add)
    call_4 = ast.Call(func=ast.Name(id='list'), args=[a_s_t_2], keywords=[])
    bin_op_5 = ast.BinOp(left=bin_op_3, right=call_4, op=ast.Add)
    bin_op_6 = ast.B

# Generated at 2022-06-25 22:36:39.373519
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    node_0 = None
    module_0 = ast.parse("[2, *range(10), 1]")
    tree_0 = module_0.body[0]
    assert isinstance(tree_0, ast.Expr)
    assert isinstance(tree_0.value, ast.List)

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_1 = starred_unpacking_transformer_0.visit(node_0)
    assert isinstance(node_1, ast.List)

    node_2 = starred_unpacking_transformer_0.visit(node_1)
    assert isinstance(node_2, ast.BinOp)

# Generated at 2022-06-25 22:36:47.916097
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    test_case_0_ast_0 = ast.List(elts=[ast.Num(n=0), ast.Num(n=1), ast.Num(n=2)])
    try:
        r_0 = starred_unpacking_transformer_0.visit_List(test_case_0_ast_0)
    except Exception as e_0:
        print((('Caught unexpected exception while visiting List: ' + str(e_0)) + '\n'))
        raise


# Generated at 2022-06-25 22:36:57.999292
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:37:00.520551
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(None), StarredUnpackingTransformer)



# Generated at 2022-06-25 22:37:01.477751
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()



# Generated at 2022-06-25 22:37:08.157657
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    star_1 = ast.Starred()
    list_2 = ast.List(star_1)
    call_3 = ast.Call(list_2)

    assert(starred_unpacking_transformer_0.visit_Call(call_3) == 'list(list(list(list(*range(10), 1)) + list(range(10))))')


# Generated at 2022-06-25 22:37:12.469988
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('In StarredUnpackingTransformer.py:')
    print('test_StarredUnpackingTransformer()')
    if False == False:
        print('Successful in StarredUnpackingTransformer.py')
    else:
        print('Failed in StarredUnpackingTransformer.py')

# Generated at 2022-06-25 22:37:19.817505
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

    a_s_t_2 = ast.Call()
    a_s_t_2.args = []
    a_s_t_2.keywords = []
    a_s_t_2.kwargs = None
    a_s_t_2.kwonlyargs = []
    a_s_t_2.vararg = None
    a_s_t_2.func = ast.Name()
    a_s_t_2.func.id = 'print'
    a_s_t_2.func.ctx = ast.Load()

    # Call method visit_Call
    a_s_t_3 = starred_unpacking_transformer_1

# Generated at 2022-06-25 22:37:23.745820
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert_equals(starred_unpacking_transformer_0._tree_changed, False)


# Generated at 2022-06-25 22:37:39.997754
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    r_e_s_t_0 = None
    a_s_t_0 = ast.Call(r_e_s_t_0)
    m_t_0 = None
    r_e_s_t_1 = None
    a_s_t_1 = ast.Starred(r_e_s_t_1)
    m_t_1 = a_s_t_1
    m_t_2 = None
    r_e_s_t_2 = None
    a_s_t_2 = ast.List(r_e_s_t_2)
    l_s_t_0 = [m_t_0, m_t_1, m_t_2]
    a_s_t_3 = ast.BinOp(l_s_t_0)
   

# Generated at 2022-06-25 22:37:48.868150
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import sys
    from typed_ast import ast3 as ast
    
    a_s_t_0 = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load()),
        ctx=ast.Load())])
    a_s_t_0 = ast.Module(body=[a_s_t_0])
    print(a_s_t_0)
    assert str(a_s_t_0) == 'Module(body=[Call(func=Name(id=\'print\', ctx=Load()), args=[Starred(value=Name(id=\'range\', ctx=Load()), ctx=Load())], keywords=[])])'

    a_s_t_1

# Generated at 2022-06-25 22:37:57.916324
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ast_explore import generate_ast
    import ast
    import typed_astunparse
    source = ""
    expected = ""
    actual = typed_astunparse.unparse(StarredUnpackingTransformer().visit(generate_ast(source)))
    assert expected == actual
    
    source = "A = [2, *range(10), 1]"
    expected = "A = [2] + list(range(10)) + [1]"
    actual = typed_astunparse.unparse(StarredUnpackingTransformer().visit(generate_ast(source)))
    assert expected == actual
        
    source = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"

# Generated at 2022-06-25 22:37:58.811965
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:38:08.059446
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # This is just to make a compile time check, if ast is correct
    ast.parse('[2, *range(10), 1]')
    ast.parse('print(*range(1), *range(3))')

    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer(tree).visit(tree)
    assert compile(tree, '', 'exec') == compile('[2] + list(range(10)) + [1]', '', 'exec')

    tree = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer(tree).visit(tree)
    assert compile(tree, '', 'exec') == compile('print(*(list(range(1)) + list(range(3))))', '', 'exec')


# Unit test

# Generated at 2022-06-25 22:38:14.268747
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:38:23.104096
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('''
print(*range(1), *range(3), *range(4))
''')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    a_s_t_1 = None
    a_s_t_1 = (a_s_t_0).body[0]
    a_s_t_2 = a_s_t_1.value
    assert starred_unpacking_transformer_0._has_starred(a_s_t_2.args) == True
    assert a_s_t_1.__class__.__name__ == 'Expr'


# Generated at 2022-06-25 22:38:28.115564
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_Expr_0 = ast.Expr()
    ast_List_0 = ast.List(elts=[ast_Expr_0])
    starred_unpacking_transformer_0.visit_List(ast_List_0)


# Generated at 2022-06-25 22:38:30.581069
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:38:41.005010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse("print(1, *range(3), 2)")
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = ast.Call(func=ast.Name(id='print'), args=[ast.Num(n=1), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[])), ast.Num(n=2)], keywords=[])
    call_0 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:39:01.634425
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    a_s_t_8 = None
    a_s_t_9 = None
    a_s_t_10 = None
    a_s_t_11 = None
    a_s_t_12 = None
    a_s_t_13 = None
    a_s_t_14 = None
    a_s_t_15 = None
    a_s_t_16 = None
    starred_unpacking_transformer_0 = Star

# Generated at 2022-06-25 22:39:04.994582
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:39:08.800512
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.parse('[2, *range(10), 1]')
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ret_val_0 = starred_unpacking_transformer_0.visit_List(None)

# Generated at 2022-06-25 22:39:09.737500
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # TODO
    return


# Generated at 2022-06-25 22:39:18.389348
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    ast_1 = ast.parse("""\
f("Hello World")
""")
    ast_1.body[0] = ast.Expr(value=ast.Call(func=ast.Name(id='f'), args=[ast.Str(s="Hello World")], keywords=[]))

    StarredUnpackingTransformer(ast_1)

    assert repr(ast_1).replace("\n", "") == repr("""\
Module(body=[Expr(value=Call(func=Name(id='f', ctx=Load()), args=[Str(s='Hello World')], keywords=[], starargs=None, kwargs=None))])
""").replace("\n", "")


# Generated at 2022-06-25 22:39:23.788519
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = ast.Call()
    call_0 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:39:28.669264
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(1), *range(3))')
    new_tree = StarredUnpackingTransformer.run_on_tree(tree)
    expected = ast.fix_missing_locations(ast.parse('print(*(list(range(1)) + list(range(3))))'))

    assert ast.dump(new_tree) == ast.dump(expected)


# Generated at 2022-06-25 22:39:37.929682
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    # Verify that only the RHS of the assignment is mutated.
    a_s_t_1 = ast.parse('a = [1, 2, 3]')
    a_s_t_2 = ast.parse('a = [1, 2, 3]')
    assert a_s_t_1.body[0].value.elts ==  a_s_t_2.body[0].value.elts
    a_s_t_2.body[0].value.elts = [1]
    a_s_t_2.body[0].value.elts[0] = 1
    assert a_s_t_1.body[0].value.elts != a_s_t_2.body[0].value.elts
    # Verify that the LHS

# Generated at 2022-06-25 22:39:48.716653
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    x_0 = ast.Call(func=ast.Name(id='print'), args=[ast.Name(id='range'), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[]))], keywords=[ast.keyword(arg='sep', value=ast.Str(s=' '))])

# Generated at 2022-06-25 22:39:55.915059
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = ast.parse('x, y')
    assert ast.dump(a_s_t_0) == "Module(body=[Expr(value=Tuple(elts=[Name(id='x', ctx=Load()), Name(id='y', ctx=Load())], ctx=Load()))])"
    a_s_t_1 = ast.parse(
        """a = [2, *range(2)]
print(a)
""")

# Generated at 2022-06-25 22:40:30.736834
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:40:37.873452
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    a_s_t_1 = ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Constant(value=3)],
            keywords=[]))],
        keywords=[])
    assert starred_unpacking_transformer_0.visit(a_s_t_1) == ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Starred(value=ast.Constant(value=range(3)))],
        keywords=[])


# Generated at 2022-06-25 22:40:38.820326
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:40:40.059540
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # arranges
    # acts
    test_case_0()

# Generated at 2022-06-25 22:40:44.517832
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_2 = ast.List(elts=[])
    assert starred_unpacking_transformer_1.visit_List(list_2) == list_2


# Generated at 2022-06-25 22:40:53.519340
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Expected call: visit_List(node=List(elts=[Num(n=10), Starred(value=Name(id='range', ctx=Load()), ctx=Load()), Num(n=20)], ctx=Load()))
    a_s_t_1 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = ast.Num(n=10)
    a_s_t_7 = ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())

# Generated at 2022-06-25 22:40:58.481758
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.parse('print(a, *b, c)')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    return


# Generated at 2022-06-25 22:41:02.774426
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None
    try:
        starred_unpacking_transformer_0.visit_List(a_s_t_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:41:09.402874
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    
    a_s_t_1 = ast.parse('x').body[0]
    ast.fix_missing_locations(a_s_t_1)
    
    assert starred_unpacking_transformer_0._tree_changed == None
    
    starred_unpacking_transformer_0.visit(a_s_t_1)
    assert starred_unpacking_transformer_0._tree_changed == None
    
    

# Generated at 2022-06-25 22:41:15.033763
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.expr()
    a_s_t_1.args = []
    a_s_t_1.keywords = []
    a_s_t_1.starargs = None
    a_s_t_1.kwargs = None
    a_s_t_1.func = ast.Attribute()
    a_s_t_1.func.value = ast.Name()
    a_s_t_1.func.value.id = 'reduce'
    a_s_t_1.func.value.ctx = ast.Load()
    a_s_t_1.func.attr = 'reduce'
