

# Generated at 2022-06-25 22:31:11.094743
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()
# __pycache__/typed_ast/test_StarredUnpackingTransformer.cpython-35.pyc not found

# Generated at 2022-06-25 22:31:13.152734
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    assert hasattr(a_s_t_0, 'visit_Call')

# Generated at 2022-06-25 22:31:22.989647
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    visit_Call_result_0 = StarredUnpackingTransformer(a_s_t_0)
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    import typed_ast._ast3 as module_0_0
    call_0 = module_0_0.Call(args=[], keywords=[])
    import typed_ast._ast3 as module_0_1
    call_1 = module_0_1.Call(args=[], keywords=[])
    import typed_ast._ast3 as module_0_2
    call_2 = module_0_2.Call(args=[], keywords=[])
    import typed_ast._ast3 as module_0_3

# Generated at 2022-06-25 22:31:26.536969
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_0.Call(starred_unpacking_transformer_0, ())

# Generated at 2022-06-25 22:31:37.992542
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    list_0 = [module_0.Name(id='range', ctx=module_0.Load()), module_0.Num(n=1), module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load())], module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load()), module_0.Num(n=3)
    call_0 = module_0.Call(func=module_0.Name(id='print', ctx=module_0.Load()), args=list_0, keywords=[])
    starred_unpacking_transformer_0 = StarredUnpacking

# Generated at 2022-06-25 22:31:43.126945
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List(elts= [])
    list_0 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:31:50.387869
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # Arrange
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_list_0 = module_0.List(elts=[], ctx=module_0.Load())

    # Act
    star_unpack_list_0 = starred_unpacking_transformer_0.visit_List(ast_list_0)

    # Assert
    assert isinstance(star_unpack_list_0, module_0.List)
    assert star_unpack_list_0 == ast.List(elts=[], ctx=ast.Load())


# Generated at 2022-06-25 22:31:53.944669
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:57.967854
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    assert_equal(StarredUnpackingTransformer(a_s_t_0), None)

import typed_ast._ast3 as module_1

import typed_ast._ast3 as module_2


# Generated at 2022-06-25 22:32:11.470711
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    list_1 = module_0.List()
    list_2 = module_0.List()
    list_3 = module_0.List()
    list_4 = module_0.List()
    list_5 = module_0.List()
    list_6 = module_0.List()
    list_7 = module_0.List()
    list_8 = module_0.List()
    list_9 = module_0.List()
    list_10 = module_0.List()
    list_11 = module_0.List()
    list_12 = module_0.List()


# Generated at 2022-06-25 22:32:32.537704
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:32:41.791867
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    assert a_s_t_1 == a_s_t_2
    assert a_s_t_1 is not a_s_t_2
    assert id(a_s_t_1) != id(a_s_t_2)
    assert type(a_s_t_1) == type(a_s_t_2)

# Generated at 2022-06-25 22:32:52.986716
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:32:59.758030
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    assert type(starred_unpacking_transformer_0.visit_List(a_s_t_0)) == module_0.List

    try:
        assert type(starred_unpacking_transformer_0.visit_List(stars_unpacking_transformer_0)) == module_0.List
    except (Exception, AttributeError) as e:
        print(e)
    
    assert type(starred_unpacking_transformer_0.visit_List(StarredUnpackingTransformer)) == type


# Generated at 2022-06-25 22:33:07.773895
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)

    module_0.List(elts=[
        module_0.Constant(value=1, kind=None),
        module_0.Starred(value=module_0.Name(id='a'), ctx=module_0.Load())])

    module_0.List(elts=[
        module_0.Constant(value=1, kind=None),
        module_0.Starred(value=module_0.Name(id='a'), ctx=module_0.Load())])


# Generated at 2022-06-25 22:33:12.897338
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    if (starred_unpacking_transformer_0._tree is not a_s_t_0):
        raise RuntimeError


# Generated at 2022-06-25 22:33:16.647969
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:33:27.247292
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 22:33:31.160538
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    if get_python_version() < ("3", "8"):
        with pytest.raises(RuntimeError):
            test_case_0()
    else:
        test_case_0()

# Generated at 2022-06-25 22:33:41.630222
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t = module_0.AST()

# Generated at 2022-06-25 22:33:55.452998
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()
    return None


# Generated at 2022-06-25 22:33:59.206368
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = module_0.call(1, 2, 3, 4, 5, 6)

    a_s_t_0 = StarredUnpackingTransformer()
    a_s_t_0.visit_Call(a_s_t_1)

# Generated at 2022-06-25 22:34:10.068398
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Expr(module_0.Constant('VALUE'))]
    a_s_t_0.body.append(module_0.AnnAssign(module_0.Constant('VALUE'), module_0.Constant('VALUE'), module_0.Constant('VALUE'), module_0.Constant('VALUE')))
    a_s_t_0.body.append(module_0.Assert(module_0.Constant('VALUE'), module_0.Constant('VALUE')))
    a_s_t_0.body.append(module_0.Assign(module_0.Constant('VALUE'), module_0.Constant('VALUE')))

# Generated at 2022-06-25 22:34:17.909256
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    node = a_s_t_0.parse("print(2, *range(5), 3)").body[0]
    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)

# Generated at 2022-06-25 22:34:18.982112
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()



# Generated at 2022-06-25 22:34:31.496381
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:34:33.953430
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_under_test = StarredUnpackingTransformer(
        node=None,
        tree=None,
        filename=None
    )
    assert class_under_test is not None


# Generated at 2022-06-25 22:34:45.735004
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('test_StarredUnpackingTransformer_visit_Call')
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:34:47.144467
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module_0.AST()
    StarredUnpackingTransformer()


# Generated at 2022-06-25 22:34:53.853908
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.Call(
        func=ast.Name(
            id='',
            ctx=ast.Load()),
        args=[],
        keywords=[])
    ts_0 = StarredUnpackingTransformer()
    ts_0.generic_visit(a_s_t_0)


# Generated at 2022-06-25 22:35:16.885698
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = StarredUnpackingTransformer()
    _a_s_t_2 = ast.FunctionDef(name='a', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Return(value=ast.Call(func=ast.Name(id='b'), args=[ast.Starred(value=ast.List(elts=[], ctx=ast.Load()))], keywords=[]))], decorator_list=[], returns=None)


# Generated at 2022-06-25 22:35:19.392359
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    a_s_t_0 = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:35:28.615529
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 22:35:38.770602
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_1.name = None
    a_s_t_1.args = module_0.arguments()
    a_s_t_1.args.args = []
    a_s_t_1.args.vararg = None
    a_s_t_1.args.kwonlyargs = []
    a_s_t_1.args.kwarg = None
    a_s_t_1.args.defaults = []
    a_s_t_1.args.kw_defaults = []
    a_s_t_1.returns = None
    a_s_t_1.body = []

# Generated at 2022-06-25 22:35:45.008492
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    node = module_0.List(elts=[module_0.Num(n=2), module_0.Num(n=3)])
    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(node)

    assert isinstance(transformer, StarredUnpackingTransformer)
    assert transformer.target == (3, 4)
    assert new_node is node


# Generated at 2022-06-25 22:35:55.012403
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    _op_0 = module_0.FunctionDef()
    _op_0.name = "a"
    _op_0.args = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    _op_0.body = [module_0.Expr(value=module_0.Call(func=module_0.Name(id="f", ctx=module_0.Load()), args=[], keywords=[]))]
    _op_0.decorator_list = []
    _op_0.returns = None
    _op_0.type_comment = None
    a_s_t_0.body = [_op_0]
   

# Generated at 2022-06-25 22:36:02.113613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typing as t
    import ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as typed_ast
    a_s_t_1 = StarredUnpackingTransformer()
    a_s_t_0 = typed_ast.Call(args=typed_ast.Starred(value=typed_ast.Name(id='x'), ctx=typed_ast.Load()), func=typed_ast.Name(id='f', ctx=typed_ast.Load()), keywords=[])
    pass


# Generated at 2022-06-25 22:36:08.154031
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()

    f_name_0 = module_0.Name()
    a_s_t_0.body = [f_name_0]

    a_e_0 = StarredUnpackingTransformer()
    result = a_e_0.visit(a_s_t_0)

    assert result == a_s_t_0

# Generated at 2022-06-25 22:36:10.258346
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # TODO: implement test for method visit_Call of class StarredUnpackingTransformer
    pass # Raises NotImplementedError


# Generated at 2022-06-25 22:36:11.971349
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_ = StarredUnpackingTransformer
    instance = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:36:28.635149
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    ast_0 = module_0.Call()
    call_0 = starred_unpacking_transformer_0.visit_Call(ast_0)


# Generated at 2022-06-25 22:36:33.972980
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Exercise
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    # Verify
    assert UNDEFINED != list_1


# Generated at 2022-06-25 22:36:39.065589
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:42.369426
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    assert isinstance(StarredUnpackingTransformer(a_s_t_0), BaseNodeTransformer)

test_case_0()

# Generated at 2022-06-25 22:36:49.107225
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test to confirm correctness of visitor pattern has been correctly implemented
    module_0 = __import__('', globals(), locals(), [''])
    class_0 = getattr(module_0, '')
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    method_0 = getattr(class_0, '')(a_s_t_0)
    call_1 = method_0.visit_Call(call_0)



# Generated at 2022-06-25 22:36:59.380011
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import sys
    import ast
    import astor
    import typed_ast.ast3 as typed_ast
    code = """
a, *b = range(3)
*c, d = range(3)
e, *f, g = range(3)
h, i, *j = range(3)
k, *l, m, n = range(4)
o, *p, q, r, s = range(5)
"""
    typed_code = astor.code_to_ast(code, include_attributes=False).body
    converted_code = StarredUnpackingTransformer(typed_code).visit(typed_code)
    expected_code = code
    assert astor.to_source(converted_code) == expected_code


# Generated at 2022-06-25 22:37:04.270421
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:37:07.185163
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Assert 1. self._has_starred(node.elts) == False
    assert True

    # Assert 2. self._has_starred(node.elts) == True
    assert True


# Generated at 2022-06-25 22:37:11.982532
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:37:16.112336
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test case 1, in order to test method visit_List of class StarredUnpackingTransformer
    # Statement list_1 = starred_unpacking_transformer_0.visit_List(list_0) throws an AttributeError
    # since the method visit_List of class StarredUnpackingTransformer is not implemented
    test_case_0()

# Generated at 2022-06-25 22:37:37.048971
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t = module_0.AST()
    a_s_t.body = [module_0.Expr(module_0.List([]))]
    starred_unpacking_transformer = StarredUnpackingTransformer(a_s_t)
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [module_0.Expr(module_0.List([]))]
    assert_equals(starred_unpacking_transformer.result, a_s_t_1)

if __name__ == '__main__':
    test_StarredUnpackingTransformer_visit_List()

# Generated at 2022-06-25 22:37:39.130091
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node_0 = module_0.AST()
    instance_0 = StarredUnpackingTransformer(node_0)


# Generated at 2022-06-25 22:37:42.801613
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Static type checker
    assert isinstance(StarredUnpackingTransformer.visit_List(list_1), module_0.List)

if __name__ == "__main__":
    import sys
    test_case_0()

    test_StarredUnpackingTransformer_visit_List()
    print("Success")

# Generated at 2022-06-25 22:37:43.356467
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    return


# Generated at 2022-06-25 22:37:52.301753
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = StarredUnpackingTransformer(StarredUnpackingTransformer)
    list_0 = None
    assert module_0._has_starred(list_0) == None
    assert module_0._merge_lists(list_0) == None
    assert module_0._prepare_lists(list_0) == None
    assert module_0._split_by_starred(list_0) == None
    assert module_0._to_sum_of_lists(list_0) == None
    assert module_0.visit_List(list_0) == None
    assert module_0.visit_Call(list_0) == None
    assert module_0.visit_Starred(list_0) == None

# Generated at 2022-06-25 22:37:54.202304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    if __name__ == '__main__':
        test_case_0()
        test_case_1()

# Generated at 2022-06-25 22:37:59.532160
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

if __name__ == '__main__':
    test_StarredUnpackingTransformer_visit_List()
    print("Done")

# Generated at 2022-06-25 22:38:05.065926
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:38:13.105930
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    list_1 = module_0.List()
    int_0 = module_0.Num()
    call_0 = module_0.Call()
    bool_0 = bool()
    bool_1 = bool()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    if (not bool_0):
        if (not bool_1):
            list_2 = starred_unpacking_transformer_0.visit_List(list_0)
        call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

if (__name__ == '__main__'):
    test_case_0()
    test

# Generated at 2022-06-25 22:38:13.650370
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True

# Generated at 2022-06-25 22:38:41.210872
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    with pytest.raises(Exception):
        StarredUnpackingTransformer()


# Generated at 2022-06-25 22:38:45.352218
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:38:50.164983
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = typed_ast.typed_ast3
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:38:57.571555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List(elts = [module_0.Num(n = 2), module_0.Starred(value = module_0.Call(func = module_0.Name(id = 'range', ctx = module_0.Load()), args = [module_0.Num(n = 10)], keywords = [])), module_0.Num(n = 1)])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert type(list_1) == module_0.List
    

# Generated at 2022-06-25 22:39:01.633680
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = module_0.List()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_1 is None

# Generated at 2022-06-25 22:39:07.449407
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


test_case_0()
test_StarredUnpackingTransformer_visit_List()

# Generated at 2022-06-25 22:39:17.268931
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    lst = ast.List(elts=[ast.Str(s='a'), ast.Starred(value=ast.Name(id='b', ctx=ast.Load())), ast.Str(s='c')])

    transformer = StarredUnpackingTransformer(lst)
    result = transformer.visit_List(lst)

    assert isinstance(result, ast.BinOp)
    assert result.op is ast.Add
    assert isinstance(result.left, ast.BinOp)
    assert result.left.op is ast.Add
    assert isinstance(result.right, ast.List)
    assert len(result.right.elts) == 1
    assert isinstance(result.left.left, ast.List)
    assert len(result.left.left.elts) == 1

# Generated at 2022-06-25 22:39:26.407017
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse(
        """
        [2, *range(10), 1]
        """)

    module_1 = ast.parse(
        """
        [2] + list(range(10)) + [1]
        """)

    StarredUnpackingTransformer().visit(module_0)
    #print()
    #print(astor.to_source(module_0))

    print()
    print(astor.to_source(module_1))
    print(astor.to_source(module_0))

    assert ast.dump(module_0) == ast.dump(module_1)


# Generated at 2022-06-25 22:39:31.907629
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    module_0.Starred()
    module_0.BinOp()
    module_0.Add()
    module_0.BinOp()
    module_0.BinOp()
    module_0.BinOp()
    module_0.BinOp()
    call_1 = StarredUnpackingTransformer(a_s_t_0).visit_Call(call_0)


# Generated at 2022-06-25 22:39:36.313069
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = __import__('typed_ast._ast3')
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(module_0.AST())
    List_0 = module_0.List()
    List_1 = StarredUnpackingTransformer_0.visit_List(List_0)


# Generated at 2022-06-25 22:40:42.882651
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    list_0 = [ ast.Name(id='a', ctx=ast.Load()), ast.Starred(value=ast.Name(id='b', ctx=ast.Load()), ctx=ast.Load()) ]
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = ast.Call(func=ast.Name(id='c', ctx=ast.Load()), args=list_0, keywords=[], starargs=None, kwargs=None)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert isinstance(call_1.args, ast.Starred)



# Generated at 2022-06-25 22:40:47.600561
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = ast.List()
    a_s_t_0 = ast.AST()
    try:
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        assert False
    except Exception as e:
        assert isinstance(e, TypeError)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:40:51.466817
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:40:55.406247
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:41:04.127812
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Default constructor
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    call_0 = module_0.Call()
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    arg_0 = module_0.arg()
    arg_1 = starred_unpacking_transformer_0.visit_arg(arg_0)
    arguments_0 = module_0.arguments()
    arguments_1 = starred_unpacking_transformer_0.visit_arguments(arguments_0)
