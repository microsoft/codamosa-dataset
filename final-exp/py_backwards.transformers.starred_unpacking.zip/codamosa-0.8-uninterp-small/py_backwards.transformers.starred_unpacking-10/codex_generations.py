

# Generated at 2022-06-25 22:31:17.047348
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    starred_unpacking_transformer_0.visit_List(list_0)

    try:
        import ast
        import sys
        import io
        import traceback

        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        traceback.print_exc()
        sys.stdout.seek(0)
        traceback_output = sys.stdout.read()
        sys.stdout.close()
        sys.stdout = old_stdout

        assert False, traceback_output
    except AssertionError:
        raise

# Generated at 2022-06-25 22:31:22.434057
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert  starred_unpacking_transformer_0

a_s_t_0 = module_0.AST()
starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:31:32.651341
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    eval_0 = ast.Assign(targets=[module_0.Name(id='a_s_t_0', ctx=module_0.Load())], value=module_0.AST())
    list_0 = ast.List(elts=[module_0.Name(id='a_s_t_0', ctx=module_0.Load())])
    assign_0 = ast.Assign(targets=[module_0.Name(id='starred_unpacking_transformer_0', ctx=module_0.Load())], value=module_0.StarredUnpackingTransformer(a_s_t_0))
    if_

# Generated at 2022-06-25 22:31:43.927670
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    test_case_0_0=module_0.Call()
    test_case_0_0._fields=['func', 'args', 'keywords', 'starargs', 'kwargs']
    test_case_0_0.func=None
    test_case_0_0.args=[None]
    test_case_0_0.keywords=[]
    test_case_0_0.starargs=None
    test_case_0_0.kwargs=None
    test_case_0_1=module_0.Name()
    test_case_0_1._fields=['id', 'ctx']
    test_case_0_

# Generated at 2022-06-25 22:31:51.508980
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    lineno_0 = 0
    col_offset_0 = 0
    elts_0 = [module_0.Num(n=2), module_0.Starred(value=module_0.Call(func=module_0.Name(id='range', ctx=module_0.Load()), args=[module_0.Num(n=10)], keywords=[])), module_0.Num(n=1)]
    list_0 = module_0.List(elts=elts_0, ctx=module_0.Load())
    list_0.lineno = lineno_0
    list_0.col_offset = col_offset_0


# Generated at 2022-06-25 22:31:54.194355
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = module_0.AST()
    StarredUnpackingTransformer(a)

# Generated at 2022-06-25 22:32:05.017012
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    l_i_s_t_0 = module_0.List()
    l_i_s_t_0.elts = [module_0.List(), module_0.List()]
    l_i_s_t_0.ctx = module_0.Load()
    l_i_s_t_1 = starred_unpacking_transformer_0.visit_List(l_i_s_t_0)


# Generated at 2022-06-25 22:32:06.057877
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

import unittest


# Generated at 2022-06-25 22:32:16.286981
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:32:27.600884
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = _ast3()
    func_0 = module_0.FunctionDef('f', module_0.arguments([], None, [], []), [], [], [module_0.Expr(module_0.Call(module_0.Name('print', module_0.Load()), [module_0.Call(module_0.Name('range', module_0.Load()), [module_0.Num(1)], []), module_0.Starred(module_0.Call(module_0.Name('range', module_0.Load()), [module_0.Num(3)], []), module_0.Load())], [], None, None), module_0.Store())], [])
    a_s_t_0 = module_0.AST(module_0.Module([func_0], []))
    starred_

# Generated at 2022-06-25 22:32:41.211992
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'a_s_t_0.Call(a_s_t_0.Name(id=\'input\'), [a_s_t_0.Starred(value=a_s_t_0.Name(id=\'range\'), ctx=a_s_t_0.Load())], [])'

# Generated at 2022-06-25 22:32:50.774677
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert hasattr(StarredUnpackingTransformer, '_split_by_starred')
    assert hasattr(StarredUnpackingTransformer, '_prepare_lists')
    assert hasattr(StarredUnpackingTransformer, '_merge_lists')
    assert hasattr(StarredUnpackingTransformer, '_to_sum_of_lists')
    assert hasattr(StarredUnpackingTransformer, 'generic_visit')
    assert hasattr(StarredUnpackingTransformer, 'visit_Call')
    assert hasattr(StarredUnpackingTransformer, 'visit_List')
    assert hasattr(StarredUnpackingTransformer, 'visit')


# Generated at 2022-06-25 22:32:58.570301
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input0 = module_0.List(elts=[module_0.BinOp(left=module_0.Name(id='a'), right=module_0.Num(n=0), op=module_0.Mult()), module_0.BinOp(left=module_0.Name(id='b'), right=module_0.Num(n=0), op=module_0.Add()), module_0.BinOp(left=module_0.Name(id='c'), right=module_0.Num(n=0), op=module_0.Div())])

# Generated at 2022-06-25 22:33:06.723916
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.List(elts=[module_0.Num(n=0), module_0.Starred(value=module_0.List(elts=[module_0.Num(n=1), module_0.Num(n=2)], ctx=module_0.Load())), module_0.Num(n=3)], ctx=module_0.Load())
    a_s_t_2 = StarredUnpackingTransformer()
    a_s_t_2.visit(a_s_t_1)


# Generated at 2022-06-25 22:33:18.499762
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.ast3.List(elts=[a_s_t_0, a_s_t_1, a_s_t_2], type_comment=None)
    StarredUnpackingTransformer().visit_List(node=a_s_t_7)

    a_s_t_8 = module_

# Generated at 2022-06-25 22:33:23.864324
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_1 = module_0.AST()

    assert a_s_t_0.__class__ == module_0.AST
    assert a_s_t_1.__class__ == module_0.AST
    assert a_s_t_0 == a_s_t_1

# Unit tests for methods of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:33:34.932301
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0.AST()
    a_s_t_0 = module_0.AST()
    
    # Call to Call(...) (line 6)
    # Processing the call keyword arguments (line 6)
    kwargs_0 = {}
    # Getting the type of 'kwargs_0' (line 6)
    kwargs_0_type = type(kwargs_0)
    
    # Call to Name(...): (line 6)
    # Processing the call keyword arguments (line 6)
    kwargs_1 = {}
    # Getting the type of 'kwargs_1' (line 6)
    kwargs_1_type = type(kwargs_1)
    
    # Call to range(...): (line 6)
    # Processing the call arguments (line 6)
    int_3 = get_builtin_

# Generated at 2022-06-25 22:33:45.261005
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_12 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 22:33:47.292869
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test for method visit_List of class StarredUnpackingTransformer."""
    t = StarredUnpackingTransformer()

# Generated at 2022-06-25 22:33:57.013989
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    assert a_s_t_0.node_classes == set()
    assert a_s_t_0.generic_visit == a_s_t_0._visit_untyped_node_list
    a_s_t_0.node_classes.add(module_0.List)
    a_s_t_0.node_classes.add(module_0.Starred)
    a_s_t_0.node_classes.add(module_0.Expr)
    a_s_t_0.node_classes.add(module_0.BinOp)
    a_s_t_0.node_classes.add(module_0.Add)

# Generated at 2022-06-25 22:34:04.499434
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t_0 = StarredUnpackingTransformer()
    c_0 = module_0.Call()
    c_1 = t_0.visit_Call(c_0)


# Generated at 2022-06-25 22:34:13.905785
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = ast.List(
        elts=[],
        ctx=ast.Load(),
    )
    b = ast.BinOp(
        left=ast.List(
            elts=[],
            ctx=ast.Load(),
        ),
        op=ast.Add(),
        right=ast.List(
            elts=[],
            ctx=ast.Load(),
        ),
    )
    c = ast.List(
        elts=[],
        ctx=ast.Load(),
    )
    d = ast.Call(
        func=ast.Name(id='list'),
        args=[ast.List(
            elts=[],
            ctx=ast.Load(),
        ),],
        keywords=[],
    )

# Generated at 2022-06-25 22:34:24.328273
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.AST
    a_t_t_1 = type(a_s_t_1()) # TODO: in need of remove
    a_t_t_2 = type(a_s_t_1())
    a_t_t_3 = type(a_s_t_1())
    a_t_t_4 = type(a_s_t_1())
    a_t_t_5 = type(a_s_t_1())
    a_t_t_6 = type(a_s_t_1())
    a_t_t_7 = type(a_s_t_1())
    a_t_t_8 = type(a_s_t_1())

# Generated at 2022-06-25 22:34:34.241882
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    u_t_a_s_t_0 = ast.parse('a = []\nb = [1, 2, 3]\nc = [6, 5, 4]\na = b + c\n')
    u_t_s_t_a_s_t_0 = StarredUnpackingTransformer()
    u_t_s_t_a_s_t_0.visit(u_t_a_s_t_0)
    assert u_t_a_s_t_0 == ast.parse('a = []\nb = [1, 2, 3]\nc = [6, 5, 4]\na = b + c\n')


# Generated at 2022-06-25 22:34:46.013504
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    _transformer_0 = StarredUnpackingTransformer()
    _ast_0 = module_0.Call(
        func=module_0.Name(id='foo'),
        args=[
            module_0.Starred(value=module_0.List(
                elts=[
                    module_0.Name(id='bar'),
                    module_0.List(elts=[], ctx=module_0.Load()),
                ],
                ctx=module_0.Load()
            )),
            module_0.Name(id='baz')
        ],
        keywords=[]
    )

# Generated at 2022-06-25 22:34:56.748799
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x0_0 = module_0.Call()
    x0_0.args = []
    x1_0 = module_0.Call()
    x1_0.args = []
    x2_0 = module_0.Call()
    x2_0.args = []
    x3_0 = module_0.Call()
    x3_0.args = [x0_0]
    x4_0 = module_0.Call()
    x4_0.args = []
    x5_0 = module_0.Call()
    x5_0.args = []
    x6_0 = module_0.Call()
    x6_0.args = []
    x7_0 = module_0.Call()
    x7_0.args = [x6_0]
    x8_0

# Generated at 2022-06-25 22:35:07.437135
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    test_input = ast.parse("""
    class A:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return "A({self.x}, {self.y})".format(self=self)

        def __add__(self, other):
            return A(self.x + other.x, self.y + other.y)

        def __mul__(self, other):
            return A(self.x * other.x, self.y * other.y)
    """)

    assert isinstance(test_input, ast.Module)

    test_input = ast.parse("""
    a = A(10, 20)
    """, mode='eval')


# Generated at 2022-06-25 22:35:17.452965
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test for method visit_Call of class StarredUnpackingTransformer."""
    star_unpack = StarredUnpackingTransformer()
    call_node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range')), ast.Name(id='5')],
        keywords=[])
    call_node_2 = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range')), ast.Name(id='5')],
        keywords=[])
    star_unpack.visit(call_node)
    star_unpack.visit(call_node_2)


# Generated at 2022-06-25 22:35:27.283253
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.List(
        elts=[
            module_0.Num(n=2),
            module_0.Starred(
                value=module_0.Call(
                    func=module_0.Name(id='range'),
                    args=[module_0.Num(n=10)],
                    keywords=[])),
            module_0.Num(n=1)],
        ctx=None)
    actual = StarredUnpackingTransformer().visit_List(a_s_t_0)

# Generated at 2022-06-25 22:35:36.842248
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST(
        body=[
            module_0.Call(
                func=module_0.Name(id='print'),
                args=[
                    module_0.Call(
                        func=module_0.Name(id='range'),
                        args=[
                            module_0.Constant(value=5),
                        ],
                        keywords=[],
                    ),
                ],
                keywords=[],
            ),
        ],
    )
    a_s_t_0.validate()

    c_0 = StarredUnpackingTransformer()
    a_s_t_1 = c_0.visit(a_s_t_0)
    a_s_t_1.validate()

# Generated at 2022-06-25 22:35:53.871428
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [module_0.Expr(value=module_0.List(ctx=module_0.Load(), elts=[module_0.Num(n=2),module_0.Starred(value=module_0.Call(func=module_0.Name(id='range'), args=[module_0.Num(n=10)], keywords=[]), ctx=module_0.Load()), module_0.Num(n=1)]))]
    a_s_t_1.type_ignores = []
    a_s_t_2 = module_0.AST()

# Generated at 2022-06-25 22:35:56.598766
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    asdf = a_s_t_0.parse('[2, *range(10), 1]')



# Generated at 2022-06-25 22:35:57.951044
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()


# Generated at 2022-06-25 22:36:03.277062
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Input params
    node = None

    # Output params
    output_0 = None

    # Returned result
    result = None

    # Create an instance
    instance = StarredUnpackingTransformer()

    # Invoke method
    result = instance.visit_List(node)

    # Check if result is as expected
    assert result == output_0


# Generated at 2022-06-25 22:36:04.622826
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()


# Generated at 2022-06-25 22:36:06.609727
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s_u_t_0 = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:36:16.012849
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    l_i_s_t_0 = module_0.List(elt=None, ctx=None, col_offset=None, lineno=None)
    c_a_l_l_0 = module_0.Call(func=None, args=[], keywords=[], starargs=None, kwargs=None, lineno=None, col_offset=None, ctx=None)
    s_t_a_r_r_e_d_0 = module_0.Starred(value=None, ctx=None, col_offset=None, lineno=None)

# Generated at 2022-06-25 22:36:23.735533
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.Module([])
    a_s_t_2 = module_0.Name(id='list')
    a_s_t_3 = module_0.Name(id='list')
    a_s_t_4 = module_0.Call(func=a_s_t_3, args=[], keywords=[])
    a_s_t_5 = module_0.Num(n=2)
    a_s_t_6 = module_0.Name(id='range')
    a_s_t_7 = module_0.Num(n=10)
    a_s_t_8 = module_0.Call(func=a_s_t_6, args=[a_s_t_7], keywords=[])
    a_s_t_9 = module_

# Generated at 2022-06-25 22:36:33.014210
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = module_0.AST()

# Generated at 2022-06-25 22:36:34.383006
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_StarredUnpackingTransformer = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:36:43.434309
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()


# Generated at 2022-06-25 22:36:47.482431
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = test_case_0()
    asd = StarredUnpackingTransformer(a_s_t_0)
    assert asd

from .base import BaseNodeTransformer

from .base import BaseNodeTransformer


# Generated at 2022-06-25 22:36:49.448485
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()


# Generated at 2022-06-25 22:36:53.203564
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = typed_ast.ast3.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(tree)
    assert result.body[0].value.left.value.left.elts[0].n == 2


# Generated at 2022-06-25 22:37:04.430228
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body.append(a_s_t_0.parse('foo(a, b, c, d, e)'))
    a_s_t_0.body.append(a_s_t_0.parse('foo(a, b, c, d, e).foo(a, b, c, d, e)'))
    a_s_t_0.body.append(a_s_t_0.parse('foo(a, b, c, d, e).foo(a, b, c, d, e).foo(a, b, c, d, e)'))

# Generated at 2022-06-25 22:37:10.081718
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    l_i_s_t_0 = module_0.List(elts=[module_0.Num(n=5)])
    a_s_t_1 = module_0.AST()

    a_s_t_0.body = l_i_s_t_0
    assert a_s_t_0 == a_s_t_1

# Generated at 2022-06-25 22:37:11.003267
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-25 22:37:18.997457
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Create an instance of the AST class
    a_s_t_1 = module_0.AST()
    # Create an instance of a Call node named n_0
    n_0 = a_s_t_1.Call(args=[])
    # Create an instance of a Name node named n_1
    n_1 = a_s_t_1.Name(id='a')
    # Store a node named n_0 whose value is an instance of a Starred node named n_2
    n_2 = a_s_t_1.Starred(value=n_1, ctx=n_0.args, ast3=a_s_t_1)
    # Store a node named n_3 whose value is an instance of a Name node named n_4

# Generated at 2022-06-25 22:37:30.070464
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_1.body = [a_s_t_2]
    a_s_t_2.value = a_s_t_3
    a_s_t_3.func = a_s_t_4
    a_s_t_4.id = 'DoSomething'

# Generated at 2022-06-25 22:37:39.710513
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    method = getattr(StarredUnpackingTransformer, "visit_List")

    # Check that the method exists
    assert hasattr(StarredUnpackingTransformer, "visit_List")

    # Check that it is callable
    assert callable(method)

    # Check that the required arguments are present
    assert "self" in method.__code__.co_varnames
    assert "node" in method.__code__.co_varnames

    # If we can provide optional arguments, check that they are present
    try:
        method()
    except TypeError as exc:
        assert "missing" in str(exc)

    # Verify the docstring exists
    assert method.__doc__ is not None



# Generated at 2022-06-25 22:37:50.257191
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x: ast.List
    pass
    instance_0 = StarredUnpackingTransformer('_tree_changed')
    instance_0.visit(x)
    assert instance_0._tree_changed is None


# Generated at 2022-06-25 22:37:51.124468
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:38:01.103068
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    with pytest.raises(Exception):
        StarredUnpackingTransformer()
    with pytest.raises(TypeError):
        StarredUnpackingTransformer(None)
    with pytest.raises(TypeError):
        StarredUnpackingTransformer([])
    with pytest.raises(TypeError):
        StarredUnpackingTransformer(())
    with pytest.raises(TypeError):
        StarredUnpackingTransformer({})
    with pytest.raises(TypeError):
        StarredUnpackingTransformer(1)
    with pytest.raises(TypeError):
        StarredUnpackingTransformer(1.1)
    with pytest.raises(TypeError):
        StarredUnpackingTransformer(True)
    with pytest.raises(TypeError):
        StarredUnpackingTransformer

# Generated at 2022-06-25 22:38:09.501369
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:38:12.733882
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    StarredUnpackingTransformer().visit(a_s_t_0)
    StarredUnpackingTransformer().visit(a_s_t_1)

# Generated at 2022-06-25 22:38:13.870065
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    StarredUnpackingTransformer.visit_Call()



# Generated at 2022-06-25 22:38:22.615100
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    o_p_t_i_o_n_s_0 = module_0.CompilerOptions()
    o_p_t_i_o_n_s_0.lineno_names = True
    o_p_t_i_o_n_s_0.strict_types = True
    t_r_a_n_s_f_o_r_m_e_r_0 = StarredUnpackingTransformer(
            o_p_t_i_o_n_s_0, None, None)
    t_r_a_n_s_f_o_r_m_e_r_1 = StarredUnpackingTransformer(
            o_p_t_i_o_n_s_0, None, None)

# Generated at 2022-06-25 22:38:31.084614
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    w_0 = module_0.Name(id="print", ctx=module_0.Load())
    w_1 = module_0.Starred(value=module_0.Name(id="range", ctx=module_0.Load()), ctx=module_0.Load())
    w_2 = module_0.Call(func=w_1, args=[module_0.Num(n=1)], keywords=[])
    w_3 = module_0.Starred(value=module_0.Name(id="range", ctx=module_0.Load()), ctx=module_0.Load())
    w_4 = module_0.Starred(value=module_0.List(elts=[w_2, w_3], ctx=module_0.Load()), ctx=module_0.Load())
   

# Generated at 2022-06-25 22:38:42.715010
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.Module(body=[module_0.Expr(value=module_0.List(elts=[module_0.Num(n=1), module_0.Starred(value=module_0.Name(id="s", ctx=module_0.Load()), ctx=module_0.Load()), module_0.Num(n=2)], ctx=module_0.Load()))])
    a_s_t_1 = StarredUnpackingTransformer().visit(a_s_t_0)

# Generated at 2022-06-25 22:38:45.486252
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    f_0 = module_0.parse("f(*args, a=0)")
    t_0 = StarredUnpackingTransformer()
    t_0.visit(f_0)


# Generated at 2022-06-25 22:39:01.943219
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_S_T_0 = StarredUnpackingTransformer()


# Generated at 2022-06-25 22:39:12.310125
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
  # Create an instance of an AST and use it to build a tree
    a_s_t_0 = module_0.AST()
    _List_0 = a_s_t_0.List([], [])
    _Num_0 = a_s_t_0.Num(1)
    _List_0.elts.append(_Num_0)
    _List_0.ctx = a_s_t_0.Load()
    _List_1 = a_s_t_0.List([], [])
    _Num_0 = a_s_t_0.Num(2)
    _List_1.elts.append(_Num_0)
    _Num_0 = a_s_t_0.Num(3)
    _List_1.elts.append(_Num_0)
    _Star

# Generated at 2022-06-25 22:39:14.749978
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        my_ast = StarredUnpackingTransformer()
    except Exception:
        print("Constructor of class StarredUnpackingTransformer is not empty")


# Generated at 2022-06-25 22:39:16.253735
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    StarredUnpackingTransformer.visit_List()


# Generated at 2022-06-25 22:39:27.263210
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    
    ast_0 = module_0.Module(body=[module_0.Expr(value=module_0.List(elts=[module_0.Num(n=2), module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()), ctx=module_0.Load()), module_0.Num(n=1)], ctx=module_0.Load()), ctx=module_0.Load())])
    ast_0 = transformer.visit(ast_0)

# Generated at 2022-06-25 22:39:32.897901
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # AST 1
    _ = """
        [2, *range(10), 1]
    """
    # AST 1 expected
    expected_1 = """
    [2, list(range(10)), 1]
    """
    a_s_t_1 = ast.parse(_.strip(), mode='eval')
    t_r_1 = StarredUnpackingTransformer()
    a_s_t_2 = t_r_1.visit(a_s_t_1)
    assert astor.to_source(a_s_t_2).strip() == expected_1


# Generated at 2022-06-25 22:39:33.875625
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-25 22:39:45.052140
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_2 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_3 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_4 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_5 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_6 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_7 = ast.Name(id='x', ctx=ast.Load())
    a_s_t_8 = ast.Name(id='x', ctx=ast.Load())

# Generated at 2022-06-25 22:39:47.189868
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        a_StarredUnpackingTransformer_0 = StarredUnpackingTransformer()
    except Exception:
        assert False


# Generated at 2022-06-25 22:39:54.943423
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Call(
        func=1,
        args=[
            module_0.List(
                elts=[
                    module_0.Starred(
                        value=4,
                        ctx=module_0.Load()),
                    6],
                ctx=module_0.Load())],
        keywords=[
            module_0.keyword(
                arg='value',
                value=module_0.Num(n=8))])

# Generated at 2022-06-25 22:40:38.356667
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # TEMPLATE STARTS HERE
    # TEMPLATE ENDS HERE
    assert obj # obj is a StarredUnpackingTransformer object


# Generated at 2022-06-25 22:40:47.842499
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from _ast import Call

    StarredUnpackingTransformer._tree_changed = False
    StarredUnpackingTransformer().visit_Call(Call(args = [], keywords = [], starargs = None, kwargs = None))
    assert StarredUnpackingTransformer._tree_changed == False

    StarredUnpackingTransformer._tree_changed = False
    StarredUnpackingTransformer().visit_Call(Call(args = [Starred(value = 'a', ctx = Load())], keywords = [], starargs = None, kwargs = None))
    assert StarredUnpackingTransformer._tree_changed == True

    StarredUnpackingTransformer._tree_changed = False
    StarredUnpackingTransformer().visit_Call(Call(args = [], keywords = [], starargs = 'a', kwargs = None))
   

# Generated at 2022-06-25 22:40:55.535550
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_0.body.append(module_0.Name(id='x', ctx=module_0.Load()))
    a_s_t_0.body.append(module_0.FunctionDef(name='f', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], defaults=[]), body=[module_0.Return(value=module_0.Num(n=0))]))
    t_r_0 = StarredUnpackingTransformer()
    t_r_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:41:04.236780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.Call( func = ast.Name( id = 'print' ) , args = [ ast.Call( func = ast.Name( id = 'range' ) , args = [ ast.Num( n = 1 ) ] , keywords = [] ) , ast.Call( func = ast.Name( id = 'range' ) , args = [ ast.Num( n = 3 ) ] , keywords = [] ) , ast.Call( func = ast.Name( id = 'range' ) , args = [ ast.Num( n = 4 ) ] , keywords = [] ) ] , keywords = [] )