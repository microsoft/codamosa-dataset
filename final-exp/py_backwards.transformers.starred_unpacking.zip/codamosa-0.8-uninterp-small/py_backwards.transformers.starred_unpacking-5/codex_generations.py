

# Generated at 2022-06-25 22:31:17.820810
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    a_s_t_0 = ast.AST()
    list_0 = ast.List()
    assert_equals(list_0.elts, [])
    attr_0 = ast.Attribute()
    attr_0.ctx = ast.Load()
    attr_0.value = list_0
    attr_0.attr = 'elts'

    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    result = starred_unpacking_transformer_0.visit_List(list_0)
    assert result.elts == []

#  Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:31:25.435817
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Init
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Try to compute
    a_s_t_0.body = [module_0.Expr(value=module_0.Call(func=module_0.Name(id='print', ctx=module_0.Load()), args=[module_0.Starred(value=module_0.Name(id='range', ctx=module_0.Load()))], keywords=[]))]
    starred_unpacking_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:31:36.228665
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Raises an exception if the and_expr is a BinOp
    a_s_t_0 = module_0.AST()
    x_0 = a_s_t_0.mod(body=[], type_ignores=[])
    y_0 = a_s_t_0.Call(args=[], keywords=[], starargs=None, kwargs=None, func=a_s_t_0.BinOp(op=a_s_t_0.BitAnd(), left=a_s_t_0.Num(n=0), right=a_s_t_0.Num(n=0)))
    assert_raises(TypeError, x_0.body.append, y_0)


# Generated at 2022-06-25 22:31:44.683262
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    try:
        list_0 = module_0.List(elts=[], ctx=module_0.Load())
        starred_unpacking_transformer_0.visit_List(list_0)
    except AssertionError as a_s_s_e_r_t__e_r_r_0:
        print(a_s_s_e_r_t__e_r_r_0)


# Generated at 2022-06-25 22:31:47.588603
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    # Test if constructor of class StarredUnpackingTransformer returns the right object
    assert isinstance(StarredUnpackingTransformer(a_s_t_0), StarredUnpackingTransformer)

# Generated at 2022-06-25 22:31:50.092377
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # TODO: Add more tests



# Generated at 2022-06-25 22:31:59.498511
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = module_0.Call(
        func=1,
        args=2,
        keywords=[],
        starargs=(),
        kwargs=()
    )

    @add_source_attributes(call_1)
    def call_1_src():
        foo_0 = 1
        foo_0(
            2,
            *[],
        )

    call_2 = starred_unpacking_transformer_0.visit_Call(call_1)

    assert repr(call_2) == repr(call_1)


# Generated at 2022-06-25 22:32:00.161705
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:32:13.670148
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # Verify that method visit_List returns correct response
    list_0 = module_0.List(elts=[], ctx=None)
    assert starred_unpacking_transformer_0.visit_List(list_0) == list_0
    list_1 = module_0.List(elts=[module_0.Constant(value='2', kind=None)], ctx=None)
    assert starred_unpacking_transformer_0.visit_List(list_1) == list_1

# Generated at 2022-06-25 22:32:25.026715
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_0 = module_0.AST()
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(ast_0)
    call_0 = module_0.Call()
    call_0.args = [module_0.Starred(module_0.Name(id='a'), module_0.Load())]
    call_0.func = module_0.Name(id='b')
    call_0.keywords = [module_0.keyword()]
    call_0.starargs = module_0.Starred(module_0.Name(id='c'), module_0.Load())
    call_0.kwargs = module_0.Starred(module_0.Name(id='d'), module_0.Load())

# Generated at 2022-06-25 22:32:30.414542
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Number of errors = 0
    test_case_0()


# Generated at 2022-06-25 22:32:40.701264
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List(None, None)
    call_0 = module_0.Call(None, None, None, None, None, None)
    starred_0 = module_0.Starred(call_0, None)
    str_0 = None
    list_1 = module_0.List(starred_0, str_0)
    call_1 = module_0.Call(None, None, None, None, None, None)
    call_2 = module_0.Call(None, list_1, None, None, None, None)
    call_3 = module_0.Call(None, call_2, None, None, None, None)
    list_2 = module_0.List(call_3, None)
    list_3 = module_0.List(list_2, None)


# Generated at 2022-06-25 22:32:49.967619
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_1 = starred_unpacking_transformer_1.visit_List(list_0)



# Generated at 2022-06-25 22:33:03.377503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)

    assert call_0 is None
    assert call_1 is None


# Generated at 2022-06-25 22:33:15.763482
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_3 = module_0.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_3)
    list_1 = None
    str_1 = 'a'
    list_2 = None
    str_2 = 'b'
    list_3 = None
    list_4 = [str_1, str_2]
    list_5 = [list_1, list_2, list_3, list_4]
    list_6 = starred_unpacking_transformer_2.visit_List(list_5)

a_s_t_3 = module_0.AST()
starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_3)
list_1 = None

# Generated at 2022-06-25 22:33:23.815820
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_1 = starred_unpacking_transformer_1.visit_List(list_0)

# Generated at 2022-06-25 22:33:28.854153
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:33:39.073648
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)
    
    assert call_1 is call_0
    assert call_1 is None


# Generated at 2022-06-25 22:33:43.963455
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # test setup
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert list_1 is None


# Generated at 2022-06-25 22:33:48.443225
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_2 = module_0.AST(**dict_0)
    StarredUnpackingTransformer(a_s_t_2)


# Generated at 2022-06-25 22:33:58.882256
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('Test: visit_Call')
    test_case_0()

import argparse
import sys
import unittest


# Generated at 2022-06-25 22:34:01.791063
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:34:12.495177
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)
    str_1 = 'simpleDialog'
    str_2 = 'prompt'
    str_3 = 'title'
    starred_0 = module_0.Starred(None, module_0.Load())


# Generated at 2022-06-25 22:34:18.316435
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_1 = starred_unpacking_transformer_1.visit_List(list_0)


# Generated at 2022-06-25 22:34:20.844539
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_2 = module_0.AST()
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(a_s_t_2)


# Generated at 2022-06-25 22:34:21.880679
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:34:33.878486
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

if __name__ == "__main__":
    a_s_t_2 = module_0.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)
    call_2 = None
    str_1 = 'tkSimpleDialog'
    dict_1 = {str_1: str_1}
    a_s_t_3 = module_0.AST(**dict_1)
    starred_unpacking_transformer_3 = StarredUnpackingTransformer(a_s_t_3)
    call_3 = starred_unpacking_transformer_3.visit_Call(call_2)
    test_StarredUnpackingTransformer()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 22:34:41.901253
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # TODO type check for call_0
    call_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:34:54.241897
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)
    a_s_t_2 = module_0.AST()
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)
    call_2 = starred_

# Generated at 2022-06-25 22:34:56.316365
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:35:13.747679
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:35:22.464649
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    list_1 = starred_unpacking_transformer_1.visit_List(list_0)


# Generated at 2022-06-25 22:35:28.918449
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:35:29.791077
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass



# Generated at 2022-06-25 22:35:31.598768
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:35:42.403908
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    list_0 = []
    str_0 = '__name__'
    str_1 = '__package__'
    str_2 = '__loader__'
    str_3 = '__spec__'
    str_4 = '__path__'
    str_5 = '__file__'
    str_6 = '__cached__'
    str_7 = '__builtins__'
    str_8 = '__doc__'
    str_9 = '__annotations__'
    str_10 = '__all__'
    str_11 = '__version__'
    str_12 = '__author__'
    str_13 = '__docformat__'
    str

# Generated at 2022-06-25 22:35:44.079041
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:35:51.580994
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_0 = None
    str_1 = 'tkSimpleDialog'
    dict_1 = {str_1: str_1}
    a_s_t_2 = module_0.AST(**dict_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_2)
    call_1 = starred_unpacking_transformer_1.visit_Call(call_0)

# Generated at 2022-06-25 22:35:59.516062
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_3 = module_0.AST()
    starred_unpacking_transformer_3 = StarredUnpackingTransformer(a_s_t_3)
    list_0 = None
    str_3 = 'C_CONTIGUOUS'
    dict_1 = {str_3: str_3}
    a_s_t_4 = module_0.AST(**dict_1)
    starred_unpacking_transformer_4 = StarredUnpackingTransformer(a_s_t_4)
    list_1 = starred_unpacking_transformer_4.visit_List(list_0)


# Generated at 2022-06-25 22:36:06.999297
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    str_0 = 'tkSimpleDialog'
    dict_0 = {str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:36:40.955107
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        StarredUnpackingTransformer()
    except Exception as ex:
        assert type(ex) is TypeError


# Generated at 2022-06-25 22:36:45.883525
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Assert #1
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert isinstance(starred_unpacking_transformer_0, StarredUnpackingTransformer)


# Generated at 2022-06-25 22:36:48.575058
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    _ast_0 = ast.AST()
    _starred_unpacking_transformer_0 = StarredUnpackingTransformer(_ast_0)
    _starred_unpacking_transformer_0.tree_changed

# Generated at 2022-06-25 22:36:55.181045
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = [None, None, None]
    list_1 = [list_0, None, None]
    call_0 = module_0.Call(*list_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    call_2 = starred_unpacking_transformer_0.visit_Call(call_1)

# Generated at 2022-06-25 22:37:06.546959
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def test_case_0():
        bytes_0 = b'module_1.call_1'
        bytes_1 = b'function'
        bytes_2 = b'module_0'
        list_0 = [bytes_0, bytes_1, bytes_2]
        list_1 = [list_0, bytes_1, bytes_2]
        list_2 = [list_1, bytes_1, bytes_2]
        list_3 = [list_2, list_0]
        call_0 = module_0.Call(*list_3)
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        call_1 = starred_unpacking_transformer_0.visit_Call

# Generated at 2022-06-25 22:37:15.689258
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    bytes_0 = b''
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = [list_0, bytes_0, bytes_0]
    module_0 = module_0.Call(*list_1)
    module_1 = module_0.AST()
    StarredUnpackingTransformer_0 = StarredUnpackingTransformer(module_1)
    list_2 = [bytes_0, bytes_0, bytes_0]
    list_3 = [list_2, bytes_0, bytes_0]
    module_0 = module_0.List(*list_3)
    assert StarredUnpackingTransformer_0.visit_List(module_0)


# Generated at 2022-06-25 22:37:20.487974
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    bytes_0 = b''
    bytes_1 = b''
    list_0 = [bytes_0, bytes_1, bytes_0]
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:37:31.513945
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = ast
    a_s_t_0 = module_0.AST()
    list_0 = [module_0.Starred(value=module_0.Name(id='None', ctx=module_0.Load())),
              module_0.Starred(value=module_0.Name(id='None', ctx=module_0.Load()))]
    list_1 = [module_0.List(elts=list_0),
              module_0.List(elts=list_0)]

# Generated at 2022-06-25 22:37:38.648540
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer(ast.AST())
    list_1 = []
    call_0 = ast.Call(func=ast.Name(id='foo'), args=list_1)
    call_1 = sut.visit_Call(call_0)
    assert isinstance(call_1, ast.Call), "Expected instance of <class 'typed_ast.ast3.Call'>, got <class '%s'>" % type(call_1).__name__


# Generated at 2022-06-25 22:37:39.346131
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert test_case_0() is None


# Generated at 2022-06-25 22:38:50.287010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    

# Generated at 2022-06-25 22:38:52.820410
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  import typed_ast._ast3 as module_0
  StarredUnpackingTransformer(module_0.AST())
  StarredUnpackingTransformer.__init__(StarredUnpackingTransformer, module_0.AST())

  

# Generated at 2022-06-25 22:39:00.704505
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    bytes_0 = b''
    list_1 = [bytes_0, bytes_0]
    list_0 = [bytes_0, bytes_0, list_1, bytes_0]
    list_2 = [list_0, bytes_0, bytes_0]
    call_0 = module_0.Call(*list_2)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    bytes_1 = b''
    list_3 = [bytes_1, bytes_1, bytes_1]
    list_4 = [list_3, bytes_1, bytes_1]
    call_2

# Generated at 2022-06-25 22:39:01.596340
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:39:11.988056
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    bytes_0 = b'foo'
    bytes_1 = b'bar'
    bytes_2 = b'baz'
    list_0 = [bytes_1, bytes_1, bytes_1]
    list_1 = [bytes_2, bytes_2, bytes_2]
    list_2 = [list_0, list_1]
    list_3 = [bytes_0, bytes_0, bytes_0]
    list_4 = [list_2, list_3]
    call_0 = module_0.Call(*list_4)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:39:23.183029
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    bytes_0 = b''
    list_0 = [bytes_0, bytes_0, bytes_0]
    list_1 = [list_0, bytes_0, bytes_0]
    list_2 = module_0.List(*list_1)
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_3 = starred_unpacking_transformer_0.visit_List(list_2)

try:
    from _ast import *
except ImportError:
    # Python 3.4+ doesn't have _ast
    import sys
    import struct
    from .py34_compat import *

    # TYPE_CHECKING

# Generated at 2022-06-25 22:39:24.543377
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:39:26.206917
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:39:26.770878
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert False

# Generated at 2022-06-25 22:39:29.873449
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    bytes_0 = b''
    list_0 = [bytes_0, bytes_0, bytes_0]
    a_s_t_0 = module_0.AST()
    list_1 = module_0.List(list_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_2 = starred_unpacking_transformer_0.visit_List(list_1)
