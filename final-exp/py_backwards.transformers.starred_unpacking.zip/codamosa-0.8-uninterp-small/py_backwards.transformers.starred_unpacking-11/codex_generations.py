

# Generated at 2022-06-25 22:31:20.098394
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    a_s_t_1 = ast.Call(func=ast.Name(id='func'), args=[], keywords=[])
    a_s_t_1 = ast.Call(func=ast.Name(id='func'), args=[], keywords=[])

    try:
        assert a_s_t_1 == starred_unpacking_transformer_0.visit_Call(a_s_t_1)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 22:31:21.073644
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-25 22:31:25.011820
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    call_1 = None
    starred_unpacking_transformer_1.visit_Call(call_1)


# Generated at 2022-06-25 22:31:33.560473
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import astunparse
    a_s_t_0 = ast.parse(
'''
[2, *range(10), 1]
''')
    a_s_t_1 = ast.parse(
'''
[2] + list(range(10)) + [1]
''')
    actual_output = astunparse.unparse(StarredUnpackingTransformer(a_s_t_0).visit(a_s_t_0))
    expected_output = astunparse.unparse(a_s_t_1)
    assert actual_output == expected_output


# Generated at 2022-06-25 22:31:39.883355
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    elts_1 = None
    list_2 = ast.List(elts=elts_1)
    list_3 = starred_unpacking_transformer_1.visit_List(list_2)
    assert list_3 is not None


# Generated at 2022-06-25 22:31:44.263721
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    #
    # Testing method __init__(self, tree)
    #
    # Testing method visit(self, node)
    #


# Generated at 2022-06-25 22:31:51.658505
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = ast.List()
    list_0_0 = list_0.elts
    int_0 = ast.Num()
    int_0_0 = int_0.n
    int_0_0 = 2
    list_0_0.append(int_0)
    list_1 = ast.List()
    list_1_0 = list_1.elts
    list_0_0.append(list_1)
    list_1_1 = list_1.elts
    star_0 = ast.Starred()
    list_1_1.append(star_0)
    starred_0 = star_0.value
    call_

# Generated at 2022-06-25 22:32:00.628003
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(a_s_t_1)
    a_s_t_2 = None
    starred_unpacking_transformer_2 = StarredUnpackingTransformer(a_s_t_2)
    a_s_t_3 = None
    starred_unpacking_transformer_3 = StarredUnpackingTransformer(a_s_t_3)
    a_s_t_4 = None
    starred_unpacking_transformer_4 = StarredUnpackingTransformer(a_s_t_4)

# Generated at 2022-06-25 22:32:07.233481
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    node_0 = ast.Call()
    node_0.args = ()
    node_0 = starred_unpacking_transformer_0.visit_Call(node_0) # type: ast.Call
    assert not node_0


# Generated at 2022-06-25 22:32:12.283436
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = None
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    try:
        list_0 = None
        raise TypeError
    except TypeError:
        print('exception test')



# Generated at 2022-06-25 22:32:19.437545
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_module = ast.parse("print(*range(2, 5), 0)")
    test_output = ast.parse("print(*list(range(2, 5)) + [0])")

    result = StarredUnpackingTransformer().visit(test_module)
    assert result == test_output


# Generated at 2022-06-25 22:32:29.940121
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Testing no call and no starred
    starred_unpacking_transformer_0_0 = StarredUnpackingTransformer()
    assert starred_unpacking_transformer_0_0.visit(ast.parse("print(1, 2, 3)").body[0]) == ast.parse("print(1, 2, 3)").body[0]

    # Testing single call
    starred_unpacking_transformer_0_1 = StarredUnpackingTransformer()
    assert starred_unpacking_transformer_0_1.visit(ast.parse("print(*range(1), *range(3))").body[0]) == ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]

    # Testing double call
    starred_unpacking_transformer_0_2 = StarredUnpackingTransformer

# Generated at 2022-06-25 22:32:36.562953
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list', ctx=ast.Load()), args=[ast.List(elts=[ast.Name(id='range', ctx=ast.Load())], ctx=ast.Load())], keywords=[], starargs=None, kwargs=None), ctx=ast.Load()), ast.Starred(value=ast.Call(func=ast.Name(id='list', ctx=ast.Load()), args=[ast.List(elts=[ast.Name(id='range', ctx=ast.Load())], ctx=ast.Load())], keywords=[], starargs=None, kwargs=None), ctx=ast.Load())], keywords=[])


# Generated at 2022-06-25 22:32:48.697494
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('f(1, *g(3))')
    assert str(ast.dump(node)) == "Expr(value=Call(func=Name(id='f', ctx=Load()), args=[Num(n=1), Starred(value=Call(func=Name(id='g', ctx=Load()), args=[Num(n=3)], keywords=[]))], keywords=[]))"
    StarredUnpackingTransformer().visit(node)
    assert str(ast.dump(node)) == "Expr(value=Call(func=Name(id='f', ctx=Load()), args=[Starred(value=List(elts=[Num(n=1), List(elts=[Num(n=3)])]))], keywords=[]))"


# Generated at 2022-06-25 22:32:53.323916
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    arguments = [[1, 2], [3, 4], [5, ], [7, 8]]
    node = ast.Call(
        func=ast.Name(id='func'),
        args=[],
        keywords=[])

    for args in arguments:
        node.args = args
        StarredUnpackingTransformer().visit(node)



# Generated at 2022-06-25 22:32:59.971598
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # ----------------------------------------------------------------------
    # Test 1
    # ----------------------------------------------------------------------
    node = ast.parse("print(1, 2, 3)").body[0]

    expected = ast.Call(
        func=ast.Name(id="print"),
        args=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)],
        keywords=[])

    assert StarredUnpackingTransformer().visit(node) == expected

    # ----------------------------------------------------------------------
    # Test 2
    # ----------------------------------------------------------------------
    node = ast.parse("print(*range(10), *range(3))").body[0]


# Generated at 2022-06-25 22:33:08.766452
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    # Case #0

    input_node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()),
            ast.Starred(value=ast.Name(id='range'), ctx=ast.Load(lineno=1, col_offset=22))],
        keywords=[])
    expected_output_node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Call(
                func=ast.Name(id='list'),
                args=[
                    ast.Name(id='range')],
                keywords=[]))],
        keywords=[])


# Generated at 2022-06-25 22:33:20.419547
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("Running StarredUnpackingTransformer.visit_Call test")
    # Creating node Call
    star = ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())
    arg = ast.Name(id='range', ctx=ast.Load())
    call = ast.Call(func=arg, args=[star], keywords=[])
    # Creating node Call
    star_0 = ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())
    arg_0 = ast.Name(id='range', ctx=ast.Load())
    call_0 = ast.Call(func=arg_0, args=[star_0], keywords=[])
    # Creating node Call
    star_1 = ast.Starred

# Generated at 2022-06-25 22:33:21.014959
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert False

# Generated at 2022-06-25 22:33:32.531723
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    # [2, *range(10), 1]
    stmt = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=10)],
                    keywords=[])),
            ast.Num(n=1)],
        ctx=ast.Load())

# Generated at 2022-06-25 22:33:39.649624
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:33:44.161496
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'print(*range(1), *range(3))'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:33:48.318393
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_0 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))], keywords=[])
    var_1 = StarredUnpackingTransformer(var_0)
    var_1.visit(var_0)


# Generated at 2022-06-25 22:33:52.117471
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:34:00.723398
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Create an instance of class StarredUnpackingTransformer
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(None)

    # Prepare input for method visit_Call of class StarredUnpackingTransformer
    var_2 = '\nprint(*range(1), *range(3))\n'
    var_3 = module_0.parse(var_2)

    # Call method visit_Call of class StarredUnpackingTransformer
    starred_unpacking_transformer_1.visit_Call(var_3)

    # Assert output of method visit_Call of class StarredUnpackingTransformer
    pass


# Generated at 2022-06-25 22:34:08.214348
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import typed_ast.ast3 as module_0
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_Call(var_0.body[0].value)


# Generated at 2022-06-25 22:34:16.665805
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert type(var_1) is module_0.FunctionDef
    assert var_1.name == 'test_StarredUnpackingTransformer_visit_Call'
    assert len(var_1.body) == 2
    assert type(var_1.body[0]) is module_0.Expr
    assert type(var_1.body[0].value) is module_0.Call
    assert type(var_1.body[0].value.func) is module_0

# Generated at 2022-06-25 22:34:21.880760
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:34:29.949353
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_1 = '\nprint(*range(1), *range(3))\n'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)

test_case_0()
test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-25 22:34:40.810859
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert \
        '''\nprint(*(list(range(1)) + list(range(3))))\n''' == \
        module_0.unparse(var_1)


if __name__ == '__main__':
    test_case_0()
    test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-25 22:34:44.711808
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer()
    test_case_0()


# Generated at 2022-06-25 22:34:53.714991
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    var_2 = module_0.parse('print(*range(1), *range(3))')
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)
    assert var_3 == module_0.parse('print(*(list(range(1)) + list(range(3))))')

if __name__ == "__main__":
    test_case_0()
    test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-25 22:34:58.987542
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = "\na = b(c, d, *e)\n"
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:35:04.938034
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # arrange
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)

    # act
    var_1 = starred_unpacking_transformer_0.visit(var_0)

    # assert
    assert var_1 is not None

# Generated at 2022-06-25 22:35:06.735385
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer(module_0.parse('x = 1\n'))


# Generated at 2022-06-25 22:35:12.241164
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3), sep=" ")\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:35:23.161861
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '\n[2, *range(10), 1]\n'
    module_0 = module_0.parse(str_0)
    module_1 = StarredUnpackingTransformer(module_0)
    module_2 = module_1._split_by_starred([module_0.body[0].value.elts[0], module_0.body[0].value.elts[1], module_0.body[0].value.elts[2]])
    module_3 = module_2[0][0]
    module_4 = module_2[1]
    module_5 = module_2[2][0]
    module_6 = str(module_3)
    module_7 = str(module_4)
    module_8 = str(module_5)


# Generated at 2022-06-25 22:35:30.414579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # module_0.py
    var_0 = 2
    var_1 = 3
    var_2 = module_0.Module()
    var_3 = module_0.Expr(var_1)
    var_2.body.append(var_3)
    var_4 = []
    var_5 = __import__('typed_ast.ast3')
    var_6 = module_0.Call(func=module_0.Name(id='print', ctx=var_5.Load()),
                          args=[var_0],
                          keywords=[])
    var_4.append(var_6)
    var_7 = __import__('typed_ast.ast3')

# Generated at 2022-06-25 22:35:39.661709
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    str_1 = '\n[2] + list(range(10)) + [1]\n'
    var_1 = module_0.parse(str_1)
    var_1 = var_1.body[0].value
    var_2 = starred_unpacking_transformer_0.visit_List(var_0.body[0].value)
    assert repr(var_2) == repr(var_1)


# Generated at 2022-06-25 22:35:49.691582
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = 3
    b = 4.2
    c = 'string'
    d = True
    e = False
    f = None
    module_0 = StarredUnpackingTransformer(root=None, file_name='file_name_0', init_kwargs={'optimize': True, 'target': (3, 4)})
    module_1 = StarredUnpackingTransformer(root=module_0, file_name=f, init_kwargs=None)
    module_2 = StarredUnpackingTransformer(root=module_1, file_name=d, init_kwargs=None)
    module_3 = StarredUnpackingTransformer(root=module_2, file_name=c, init_kwargs=None)

# Generated at 2022-06-25 22:36:00.719298
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)

    # For testing private method _has_starred
    assert starred_unpacking_transformer_0._has_starred([module_0.Tuple(elts=[module_0.Num(n=2)])]) == False
    assert starred_unpacking_transformer_0._has_starred([module_0.Starred(value=module_0.Name(id='range'))]) == True

    # For testing private method _split_by_starred

# Generated at 2022-06-25 22:36:06.562149
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:36:12.372055
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_1 = '\n[2, *range(10), 1]\n'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = var_2.body[0].value.elts
    var_4 = starred_unpacking_transformer_1.visit_List(var_3)


# Generated at 2022-06-25 22:36:14.871628
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 22:36:21.722750
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    # Assign parameters for test case.
    node = ast.List(elts=[ast.Name(id='x', ctx=ast.Load()), ast.Starred(value=ast.Name(id='x', ctx=ast.Load()), ctx=ast.Load()), ast.Name(id='y', ctx=ast.Load())])

    # Call the tested method
    ret_val = StarredUnpackingTransformer.visit_List(node=node)

    # Check returned value

# Generated at 2022-06-25 22:36:25.876264
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_1 = '\n[2, *range(10), 1]\n'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit_List(var_2)

# Generated at 2022-06-25 22:36:28.720150
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()


if __name__ == '__main__':
    test_StarredUnpackingTransformer()
    import unittest
    unittest.main()

# Generated at 2022-06-25 22:36:32.888767
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:36:38.466189
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_2 = '\nprint(*range(1), *range(3))\n'
    var_4 = module_0.parse(str_2)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_4)
    var_5 = starred_unpacking_transformer_1.visit(var_4)


# Generated at 2022-06-25 22:36:45.602257
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # setup
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)

    # test
    var_1 = starred_unpacking_transformer_0.visit_List(var_0)

    # post-test
    module_1 = module_0.dump(var_1)


# Generated at 2022-06-25 22:37:13.031208
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    assert(isinstance(var_1, module_0.Module))


# Generated at 2022-06-25 22:37:13.876634
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:37:17.380835
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:21.815907
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:37:27.902454
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:37:28.975528
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:37:39.488581
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.List(elts=(module_0.Num(n=2), (module_0.Call(func=module_0.Name(id='list'), args=(module_0.Call(func=module_0.Name(id='range'), args=(module_0.Num(n=10),), keywords=(), starargs=None, kwargs=None),), keywords=(), starargs=None, kwargs=None)), module_0.Num(n=1)))

# Generated at 2022-06-25 22:37:42.392667
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    list_0 = module_0.parse('print(*range(1), *range(3))')
    test_StarredUnpackingTransformer_0 = StarredUnpackingTransformer(list_0)

test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:37:48.443994
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    var_0 = var_0.body[0]
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit_Call(var_0)


# Generated at 2022-06-25 22:37:49.524213
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case_0()


# Generated at 2022-06-25 22:38:20.120374
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source_0 = '\n[2, *range(10), 1]\n'
    module_0 = module_0.parse(source_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(module_0)


# Generated at 2022-06-25 22:38:21.322792
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 22:38:25.757527
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:38:32.450813
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # PyCharm may be confused and mark this as an error.
    # However, this is really an import from another unit-test module,
    # and it is ok to ignore the error.
    # noinspection PyUnresolvedReferences
    import test_StarredUnpackingTransformer as module_0
    var_1 = '\n[2, *range(10), 1]\n'
    var_2 = module_0.module_0.parse(var_1)
    var_3 = StarredUnpackingTransformer(var_2)
    var_3.visit(var_2)
    with pytest.raises(StarredUnpackingError):
        '\nprint(*range(1), *range(3))\n'
        '\nprint(*range(1), *range(3))\n'
        var_

# Generated at 2022-06-25 22:38:42.936045
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = 'foo(*args)'
    var_0 = module_0.parse(str_0)
    module_0.fix_missing_locations(var_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.dump(var_1)
    assert var_2 == 'Call(func=Name(id=\'foo\', ctx=Load()), args=[Starred(value=Name(id=\'args\', ctx=Load()), ctx=Load())], keywords=[])'


# Generated at 2022-06-25 22:38:50.285949
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_1 = '\n[2, *range(10), 1]\n'
    var_3 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_3)
    var_4 = starred_unpacking_transformer_1.visit_List(var_3)
    import astor
    var_5 = astor.to_source(var_4)
    str_2 = '[2] + list(range(10)) + [1]\n'
    assert (var_5 == str_2)

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:38:58.276612
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    var_1 = module_0.parse(str_0)
    var_2 = module_0.parse(str_0)
    var_3 = module_0.parse(str_0)
    var_4 = module_0.parse(str_0)
    var_5 = module_0.parse(str_0)
    var_6 = module_0.parse(str_0)
    var_7 = module_0.parse(str_0)
    var_9 = module_0.parse(str_0)
    var_10 = module_0.parse(str_0)
    var_11 = module_0.parse(str_0)
   

# Generated at 2022-06-25 22:39:03.649273
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_0 = ast.parse('input')
    module_0.body[0].value = ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())],
        keywords=[])
    module_1 = StarredUnpackingTransformer(module_0)
    module_1.visit(module_0)


# Generated at 2022-06-25 22:39:13.492527
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)
    var_2 = type(var_1) is module_0.Expr
    assert var_2 == True
    var_3 = type(var_1.value) is module_0.BinOp
    assert var_3 == True
    var_4 = type(var_1.value.left) is module_0.BinOp
    assert var_4 == True
    var_5 = type(var_1.value.left.left) is module_0.List

# Generated at 2022-06-25 22:39:14.482174
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-25 22:39:28.830309
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:39:32.651292
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:39:43.233997
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # import typed_ast.ast3 as ast
    from typing import Iterable, List
    from typed_ast import ast3 as ast
    # from .base import BaseNodeTransformer
    class MetaNodeTransformer(ast.NodeTransformer):
        _tree_changed: bool
        def __init__(self, tree: ast.Module) -> None:
            self._tree_changed = False
            self._tree = tree
            self.generic_visit = ast.NodeVisitor.generic_visit
            self.visit = ast.NodeVisitor.visit
        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True
            return False

# Generated at 2022-06-25 22:39:46.899544
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    try:
        test_case_0()
    except Exception:
        var_0 = 'Test StarredUnpackingTransformer.visit_List failed'
        print(var_0)
        raise


# Generated at 2022-06-25 22:39:52.013552
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    arg0 = ''
    arg1 = '\nprint(*range(1), *range(3))\n'
    arg2 = module_0.parse(arg1)
    arg3 = StarredUnpackingTransformer(arg2)
    arg3.visit(arg2)

if __name__ == '__main__':
    import subprocess
    import sys

    subprocess.run([sys.executable, '-m', 'unittest', __file__])

# Generated at 2022-06-25 22:39:55.346309
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_1 = '\nprint(*range(1), *range(3))\n'
    var_2 = module_0.parse(str_1)
    starred_unpacking_transformer_1 = StarredUnpackingTransformer(var_2)
    var_3 = starred_unpacking_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:39:56.607814
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    var_0 = StarredUnpackingTransformer(None)


# Generated at 2022-06-25 22:40:00.406715
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:03.538682
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    str_0 = '\nprint(*range(1), *range(3))\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:14.918257
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    str_0_0 = 'print(&1, *range(1), *range(3))'
    expected_0_0 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.BinOp(left=ast.List(elts=[ast.Num(n=1)]), right=ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[])], keywords=[]), op=ast.Add()))], keywords=[])
    node_0_0 = ast.parse(str_0_0).body[0].value
    var_0_0 = StarredUnpackingTransformer(node_0_0)
    var_1_0 = var_0_0.vis

# Generated at 2022-06-25 22:40:46.453521
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from pprint import pprint as func_0
    pass


# Generated at 2022-06-25 22:40:50.607218
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    str_0 = '\n[2, *range(10), 1]\n'
    var_0 = module_0.parse(str_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(var_0)
    var_1 = starred_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:40:53.432278
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_0 = StarredUnpackingTransformer(None)
    var_1 = module_0.Call(func=None, args=[], keywords=[])
    var_2 = var_0.visit_Call(var_1)


# Generated at 2022-06-25 22:41:02.216202
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_1 = StarredUnpackingTransformer(None, 1)
    var_2 = module_0.Call(
        func=(var_1),
        args=[(var_1)],
        keywords=[],
        starargs=(var_1),
        kwargs=(var_1)
    )
    var_3 = module_0.Call(
        func=(var_1),
        args=[(var_1)],
        keywords=[],
        starargs=(var_1),
        kwargs=(var_1)
    )
    var_4 = StarredUnpackingTransformer.visit_Call(
        (var_1),
        (var_2)
    )
    assert var_4 != var_3
    assert var_4 is not var_3


# Generated at 2022-06-25 22:41:08.955547
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    var_0 = module_0.parse('print(*range(1), *range(3))')
    
    # Call StarredUnpackingTransformer.visit_Call (line 65)
    var_1 = StarredUnpackingTransformer(var_0).visit_Call(var_0.body[0].value)
    var_2 = bool()
    var_3 = bool()
    
    
    
    
    
    
    
    
    
    
    
    
    assert var_1 == None
    assert var_2 == False
    assert var_3 == False
