

# Generated at 2022-06-25 22:31:19.726812
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_0.arg_acount = 5
    a_s_t_0.arg_bcount = 5
    node_0 = module_0.Call(a_s_t_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    starred_unpacking_transformer_0.visit_Call(node_0)


# Generated at 2022-06-25 22:31:27.041914
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.If()
    a_s_t_3 = module_0.Bytes()
    a_s_t_4 = module_0.BinOp()
    a_s_t_5 = module_0.Yield()
    a_s_t_6 = module_0.Module()
    a_s_t_7 = module_0.For()
    a_s_t_8 = module_0.DictComp()
    a_s_t_9 = module_0.Delete()
    a_s_t_10 = module_0.TryExcept()
    a_s_t_11 = module_0.Add()
    a_s_t_12 = module_0.Num()
   

# Generated at 2022-06-25 22:31:38.449333
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree_0 = parse_ast("print(1, 2, 3)")
    tree_1 = parse_ast("print(1, 2, 3)")
    assert tree_0 == tree_1
    st = StarredUnpackingTransformer()
    st.visit(tree_0)
    assert tree_0 == tree_1
    tree_2 = parse_ast("print(1, 2, 3)")
    tree_3 = parse_ast("print(1, 2, 3)")
    assert tree_2 == tree_3
    st = StarredUnpackingTransformer()
    st.visit(tree_2)
    assert tree_2 == tree_3
    tree_4 = parse_ast("print(1, 2, 3)")
    tree_5 = parse_ast("print(1, 2, 3)")
   

# Generated at 2022-06-25 22:31:48.138244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.List()
    a_s_t_1.elts = [module_0.Num(1)]
    a_s_t_1.ctx = module_0.Load()
    a_s_t_1 = starred_unpacking_transformer_0.visit_List(a_s_t_1)
    assert(a_s_t_1.elts == [module_0.Num(1)])


if __name__ == '__main__':
    test_case_0()
    test_StarredUnpackingTransformer_visit_List()
    print('Test finished')

# Generated at 2022-06-25 22:31:58.728421
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    call_0 = module_0.Call(func=module_0.Name(id='print'), args=[module_0.Starred(value=module_0.Name(id='range'), starargs=None, kwargs=None)], keywords=[])
    try:
        starred_unpacking_transformer_0.visit_Call(call_0)
    except:
        pass

    try:
        starred_unpacking_transformer_0.visit_Call(call_0)
    except:
        pass

    try:
        starred_unpacking_transformer_0.visit_Call(call_0)
    except:
        pass



# Generated at 2022-06-25 22:32:04.349604
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:32:09.419619
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    m_0_0_23 = module_0.Name(id="f")
    m_0_0_24 = module_0.Name(id="args")
    m_0_0_25 = module_0.keyword(arg="kwargs", value=None)
    m_0_0_26 = module_0.Call(func=m_0_0_23,
                             args=m_0_0_24,
                             keywords=[m_0_0_25])
    m_0_0_26 = starred_unpacking_transformer_0.visit_Call(m_0_0_26)
    m_0_

# Generated at 2022-06-25 22:32:10.643332
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert True



# Generated at 2022-06-25 22:32:13.865697
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert callable(StarredUnpackingTransformer)


# Generated at 2022-06-25 22:32:19.018399
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        assert starred_unpacking_transformer_0 is not None
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 22:32:29.154670
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


pytest.main()

# Generated at 2022-06-25 22:32:35.063893
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    print(str(call_0))

# Generated at 2022-06-25 22:32:39.695198
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:32:41.741447
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call = ast.Call()
    StarredUnpackingTransformer(ast.AST()).visit_Call(call)

# Generated at 2022-06-25 22:32:46.582487
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_List(call_0)

# Generated at 2022-06-25 22:32:54.103376
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = None
    try:
        import ast
        module_0 = ast
    except:
        import _ast as module_0
        module_0 = module_0
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:33:00.458730
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Name(id='range'),
                ctx=ast.Load()),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=3)],
                    keywords=[]),
                ctx=ast.Load())],
        keywords=[])
    

# Generated at 2022-06-25 22:33:05.430155
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:08.324424
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_0 = StarredUnpackingTransformer()
    list_0 = ast.List()
    a_s_t_0 = ast.AST()
    module_0.a_s_t = a_s_t_0
    module_0.visit_List(list_0)


# Generated at 2022-06-25 22:33:14.686117
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:33:31.209594
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Setup test fixture
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Exercise SUT
    call_1 = starred_unpacking_transformer_0.visit_List(call_0)

    # Verify outcome
    assert False

# Generated at 2022-06-25 22:33:35.674484
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:33:41.537605
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Input parameters
    call_0 = module_0.Call()

    # Additional parameters
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Call the method under test
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)



# Generated at 2022-06-25 22:33:49.332537
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    str_0 = a_s_t_0.to_source(call_0)
    assert str_0 == 'Call()'
    a_s_t_1 = module_0.AST()
    str_1 = a_s_t_1.to_source(call_0)
    assert str_1 == 'Call()'
    a_s_t_2 = module_0.AST()
    str_2 = a_s_t_2.to_source(call_0)
    assert str_2 == 'Call()'


# Generated at 2022-06-25 22:33:55.197055
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:34:06.160266
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def test_List_0():
        list_0 = module_0.List()
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    def test_List_1():
        list_0 = module_0.List()
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
        list_1 = starred_unpacking_transformer_0.visit_List(list_0)
        
    test_List_0()
    test_List_1()
    

# Generated at 2022-06-25 22:34:11.024511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List(elts=[])
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:34:15.553842
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module_0 = StarredUnpackingTransformer()
    # assert (module_0._tree_changed == False)
    # module_0._tree_changed = True
    # assert (module_0._tree_changed == True)
    # module_0._tree_changed = False
    # assert (module_0._tree_changed == False)
    # module_0._tree_changed = True
    # assert (module_0._tree_changed == True)


# Generated at 2022-06-25 22:34:21.220089
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # test
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:34:26.210176
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = ast.Call()
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:53.159862
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:34:59.034896
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    call_2 = module_0.Call()
    a_s_t_1 = module_0.AST()
    none_0 = None
    a_s_t_2 = module_0.AST()
    none_1 = None
    a_s_t_3 = module_0.AST()
    str_0 = str()

# Generated at 2022-06-25 22:35:04.983399
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List(): # unit test for method visit_List of class StarredUnpackingTransformer
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)
    assert (list_0 == list_1)


# Generated at 2022-06-25 22:35:10.078223
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    assert isinstance(starred_unpacking_transformer_0,
        StarredUnpackingTransformer)


# Generated at 2022-06-25 22:35:20.831045
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module_0 = StarredUnpackingTransformer()
    print(module_0)
    print(type(module_0))
    print(module_0._target)
    print(type(module_0._target))
    print(module_0._tree_changed)
    print(type(module_0._tree_changed))
    module_0._check_dunder_all()
    module_0._check_dunder_doc()
    module_0._check_dunder_file()
    module_0._check_dunder_name()
    module_0._check_dunder_packages()
    module_0._check_dunder_path()
    module_0._check_dunder_path_hooks()
    test_case_0()


# Generated at 2022-06-25 22:35:26.100008
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    call_0 = ast.Call()
    a_s_t_0 = ast.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)

    # Invoke method
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)

    # Check
    assert isinstance(call_1, ast.Call)


# Generated at 2022-06-25 22:35:32.394681
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        modules = [module_0]
        for module in modules:
            for name, data in module.__dict__.items():
                if hasattr(data, '__base__') and issubclass(data, module.AST):
                    if hasattr(data, 'visit') and hasattr(data, 'generic_visit'):
                        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-25 22:35:33.305787
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:35:36.585806
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Create an instance of class 'StarredUnpackingTransformer'
    test_instance_StarredUnpackingTransformer = StarredUnpackingTransformer()
    assert test_instance_StarredUnpackingTransformer


# Generated at 2022-06-25 22:35:39.035309
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    arg0_0 = module_0.AST()
    StarredUnpackingTransformer(arg0_0)


# Generated at 2022-06-25 22:36:24.772798
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_0 = module_0.List()
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:36:29.032034
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:30.000151
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:36:31.707599
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test for constructor for class StarredUnpackingTransformer."""
    pass


# Generated at 2022-06-25 22:36:34.847519
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        a_s_t_0 = module_0.AST()
        starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    except:
        assert False


# Generated at 2022-06-25 22:36:39.906057
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # call_0 = module_0.Call()
    # a_s_t_0 = module_0.AST()
    # starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    # call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    pass

# Generated at 2022-06-25 22:36:47.040587
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    starargs_0 = module_0.Starred()
    call_0.starargs = starargs_0
    a_s_t_0 = module_0.AST()
    starargs_0.value = list
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:36:51.249407
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:37:00.377730
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    a_s_t_0.body[0] = module_0.Expr(value=call_0)
    module_0.fix_missing_locations(a_s_t_0)
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert isinstance(call_1, module_0.Call)

test_case_0()

# Generated at 2022-06-25 22:37:05.711653
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    # with raises(ValueError):
    #     call_1.visit_Call(call_0)


# Generated at 2022-06-25 22:38:43.827161
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    assert call_0 is call_1
    assert call_0 == call_1
    assert call_1 == call_0


# Generated at 2022-06-25 22:38:49.079513
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    try:
        call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    except:
        fail()
    else:
        pass


# Generated at 2022-06-25 22:38:52.733983
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:38:57.866974
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = module_0.List()
    starred_unpacking_transformer_0.visit_Call(call_0)
    list_2 = starred_unpacking_transformer_0.visit_List(list_1)


# Generated at 2022-06-25 22:39:01.163056
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)

# Generated at 2022-06-25 22:39:06.288805
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_List(call_0)


# Generated at 2022-06-25 22:39:15.874316
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    all_good = True
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_Call(call_0)
    call_0.args = module_0.arguments(args=[module_0.Starred(value=module_0.Call(func=module_0.Name(id='list'), args=[module_0.Starred(value=module_0.Name(id='x'))], keywords=[]))])
    call_2 = starred_unpacking_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:39:21.735014
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_0 = module_0.List()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    list_1 = starred_unpacking_transformer_0.visit_List(list_0)


# Generated at 2022-06-25 22:39:26.722613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    i = ast.parse("""[2, *range(10), 1]""", mode='eval').body
    actual = StarredUnpackingTransformer().visit(i)
    expected = ast.parse("""[2] + list(range(10)) + [1]""", mode='eval').body
    match = ast.dump(actual) == ast.dump(expected)
    assert match


# Generated at 2022-06-25 22:39:30.547101
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    starred_unpacking_transformer_0 = StarredUnpackingTransformer(a_s_t_0)
    call_1 = starred_unpacking_transformer_0.visit_List(call_0)
