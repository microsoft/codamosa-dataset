

# Generated at 2022-06-21 17:57:14.425697
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import check_visitor
    example = check_visitor.parse("print(*range(10, 13), *range(3))")

    visitor = StarredUnpackingTransformer()
    visitor.visit(example)

    assert visito

# Generated at 2022-06-21 17:57:21.147043
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    tree = astor.parse_file('test/testcases/unpacking.py')

    new_tree = StarredUnpackingTransformer().visit(tree)
    new_code = astor.to_source(new_tree)
    with open('test/test_results/unpacking.py') as f:
        target_code = f.read()

    assert new_code == target_code

# Generated at 2022-06-21 17:57:33.124452
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .restructure import RestructureTransformer
    from .identity import IdentityTransformer
    from .unpacking import UnpackingTransformer

    with open('samples/starred_unpack.py', 'r') as f:
        tree = ast.parse(f.read())
        assert tree

        # TODO: Move to BaseNodeTransformer
        steps = [
            ('StarredUnpackingTransformer', StarredUnpackingTransformer),
            ('RestructureTransformer', RestructureTransformer),
            ('UnpackingTransformer', UnpackingTransformer),
            ('IdentityTransformer', IdentityTransformer),
        ]
        BaseNodeTransformer.apply_steps(tree, steps)

    print(ast.dump(tree, annotate_fields=False))
    print()

# Generated at 2022-06-21 17:57:38.429056
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = 'print([2, *range(10), 1])'
    source_tree = ast.parse(source, '<test>')
    expected_tree = ast.parse('print([2] + list(range(10)) + [1])', '<test>')

    transformer = StarredUnpackingTransformer()
    assert transformer.visit(source_tree) == expected_tree


# Generated at 2022-06-21 17:57:40.120144
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 17:57:50.988453
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = """
a = 1, 2, 3
print(1, 2, 3)
print(*[1, 2, 3])
b = [1, 2, 3]
print(*b)
print(*b, 4)
print(4, *b, 5)
print(*b, *b)
print(1, *b, 2, *b, 3)
print(*[], *[1, 2])
c = [1, 2, 3], 4
print(c)
print(*c)
"""

# Generated at 2022-06-21 17:57:55.522357
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 4).target == (3, 4)
    assert StarredUnpackingTransformer(3, 4)._has_starred([]) == False
    assert StarredUnpackingTransformer(3, 4)._has_starred([ast.Starred(value=ast.Name(id="Num", ctx=None))]) == True
    assert StarredUnpackingTransformer(3, 4)._has_starred([ast.Starred(value=ast.Name(id="Num", ctx=None)), ast.Num(n=1)]) == True
    assert StarredUnpackingTransformer(3, 4)._has_starred([ast.Num(n=1), ast.Num(n=2)]) == False

# Generated at 2022-06-21 17:58:04.862879
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import pytest
    from typed_astunparse import unparse
    import typed_ast.ast3 as typed_ast

    source = ['foo(1, 2, 3, 4, 5)', 'foo(1, 2, 3, *[4, 5], 6)', 'foo(1, 2, 3, *[4, 5])', 'foo(1, 2, 3, *[4, 5], *[6, 7])']
    expected = ['foo(1, 2, 3, 4, 5)', 'foo(*list([1, 2, 3]) + list([4, 5]) + list([6]))', 'foo(*list([1, 2, 3]) + list([4, 5]))',
                'foo(*list([1, 2, 3]) + list([4, 5]) + list([6, 7]))']


# Generated at 2022-06-21 17:58:12.013647
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_tree = ast.parse("x = [2, *range(10), 1]")
    transformed_tree = StarredUnpackingTransformer().visit(test_tree)
    assert compare_ast(
        ast.parse("x = [2] + list(range(10)) + [1]"),
        transformed_tree)


# Generated at 2022-06-21 17:58:22.257447
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    from typed_ast import ast3
    from . import UncompyleNodeVisitor
    sut = StarredUnpackingTransformer(UncompyleNodeVisitor())
    node = ast3.List(elts=[ast3.Name(id='x', ctx=ast3.Load()), ast3.Starred(value=ast3.Name(id='y', ctx=ast3.Load()), ctx=ast3.Load()), ast3.Name(id='z', ctx=ast3.Load())], ctx=ast3.Load())

# Generated at 2022-06-21 17:58:29.773890
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-21 17:58:32.611077
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    '''Unit test for class StarredUnpackingTransformer'''
    StarredUnpackingTransformer()


# Generated at 2022-06-21 17:58:41.280351
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
    print(*range(1), *range(3))
    sum([*range(1), *range(2)], *(range(1)))
    foo(*[], *[])
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    sum(list(range(1)) + list(range(2)) + list(range(1)))
    foo(*[], *[])
    """
    transformed = StarredUnpackingTransformer().visit(ast.parse(code))

    assert expected == astor.to_source(transformed).strip()


# Generated at 2022-06-21 17:58:49.616129
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformer import Python3To2Transformer
    import ast as pyast
    import python_to_python.typed_ast_transformer as T
    import python_to_python.typed_ast_transformer.transformer_util as U

    def assert_node_transformation(initial_node: pyast.AST,
                                   expected_node: pyast.AST) -> None:
        tree = pyast.parse(U.ast2str(initial_node), '<test>', 'eval')
        tree = T.StarredUnpackingTransformer().transform(tree)
        actual_node = U.ast2str(tree)
        expected_node = U.ast2str(expected_node)

        assert actual_node == expected_node


# Generated at 2022-06-21 17:58:55.118855
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    from nuitka.ast.tree import parseSourceCodeToAst

    node = parseSourceCodeToAst('[2, *range(10), 1]')

    transformer = StarredUnpackingTransformer()
    transformer.visit(node)

    node = parseSourceCodeToAst('[2, *range(10), 1]')
    result = transformer.visit(node)

    assert astunparse.unparse(result) == '([2] + list(range(10)) + [1])'

    node = parseSourceCodeToAst('[2, 3, 4, 5]')
    result = transformer.visit(node)

    assert astunparse.unparse(result) == '[2, 3, 4, 5]'



# Generated at 2022-06-21 17:59:02.515615
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]", mode="eval")
    node = transformer.visit(node)
    assert ast.dump(node, annotations=False) == "Call(func=Name(id='list'), args=[Num(n=2), Call(func=Name(id='range'), args=[Num(n=10)], keywords=[]), Num(n=1)], keywords=[])"



# Generated at 2022-06-21 17:59:11.709674
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('# Unit test for method visit_Call of class StarredUnpackingTransformer')
    class _Call:
        name = 'print'
        args = [ast.Starred(value=ast.Name(id='x', ctx=ast.Load()))]
    tree = {
        'body': [
            ast.Expr(_Call()),
        ],
    }
    tree = StarredUnpackingTransformer.run_on_tree(ast.parse(dedent(inspect.getsource(tree))))

# Generated at 2022-06-21 17:59:21.172353
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse(
        "def foo():\n"
        "    b = []\n"
        "    c = 1\n"
        "    d = 2\n"
        "    x = [a, *b, c, *d, 1]\n"
        "    y = (*b, c, *d, 1)\n"
    )

    result = StarredUnpackingTransformer().visit(node)
    actual = ast.dump(result)


# Generated at 2022-06-21 17:59:33.203919
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    l = ast.List(elts=[
            ast.Constant(value=2),
            ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Constant(value=10)], keywords=[])),
            ast.Constant(value=1)])
    c = ast.Call(func=ast.Name(id='print'), args=[
            ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Constant(value=1)], keywords=[])),
            ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Constant(value=3)], keywords=[]))], keywords=[])
    test_StarredUnpackingTransformer = StarredUnpackingTransformer()
    assert test_Starred

# Generated at 2022-06-21 17:59:41.285057
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    tree = ast.parse("[2, *range(10), 1]")
    result = trans.visit(tree)
    assert compile("[2, *range(10), 1]", filename="<test>", mode="exec")
    """
        [(2,)]
        [(2,) + list(range(10)) + (1,)]
        [2]
        [2]
    """

# Generated at 2022-06-21 17:59:57.708124
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    xs = [ast.Num(n=2),
          ast.Starred(value=ast.Call(
              func=ast.Name(id='range'),
              args=[ast.Num(n=10)],
              keywords=[])),
          ast.Num(n=1)]

    tree = ast.parse('''[2, *range(10), 1]''')
    expected = ast.parse('''([2] + list(range(10)) + [1])''')

    transformed = StarredUnpackingTransformer().visit(tree)

    assert hasattr(transformed, 'body')
    assertion_method = getattr(assert_equal, '__code__')
    assertion_method.co_argcount(expected.body[0].value, transformed.body[0].value)



# Generated at 2022-06-21 18:00:04.522264
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
    [2, *range(10), 1]
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer(tree).visit(tree)
    assert astor.to_source(ast.fix_missing_locations(tree)) == """
    ([2] + list(range(10)) + [1])
    """


# Generated at 2022-06-21 18:00:15.310176
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*(range(10)), *range(2))'
    expected_code = 'print(*(list(range(10)) + list(range(2))))'

    node = compile(code, filename='<string>', mode='exec', flags=ast.PyCF_ONLY_AST)
    StarredUnpackingTransformer().visit(node)

    result_code = compile(node, filename='<string>', mode='exec').co_code
    expected_code = compile(expected_code, filename='<string>', mode='exec').co_code

    assert result_code == expected_code



# Generated at 2022-06-21 18:00:21.485488
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('f(*list, 5)', mode='eval')
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert transformer.changed is True
    assert transformer.result == ast.parse('f(*(list + [5]))', mode='eval')


# Generated at 2022-06-21 18:00:23.567306
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-21 18:00:29.415484
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import compile_function

    def foo(*args):
        return args

    compiled = compile_function(foo, target_versions={'3.3', '3.4', '3.5'})
    assert compiled(1, 2, 3) == (1, 2, 3)
    assert compiled(*[1, 2, 3]) == (1, 2, 3)
    assert compiled(*range(2, 5)) == (2, 3, 4)


# Generated at 2022-06-21 18:00:41.560932
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert repr(ast.parse(
            "print(*range(1), *range(3))",
            mode='eval')) \
        == "Call(func=Name(id='print', ctx=Load()), " \
           "args=[Starred(value=Call(func=Name(id='range', ctx=Load()), " \
           "args=[Num(n=1)], keywords=[])), " \
           "Starred(value=Call(func=Name(id='range', ctx=Load()), " \
           "args=[Num(n=3)], keywords=[]))], keywords=[])"

# Generated at 2022-06-21 18:00:42.441611
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:00:46.188560
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .utils import assert_ast

    source = 'print(*range(1), *range(3))'
    node = ast.parse(source)
    expected = "print(*(list(range(1)) + list(range(3))))"
    assert_ast(StarredUnpackingTransformer, source, expected, node)


# Generated at 2022-06-21 18:00:50.252020
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = "[2, *range(10), 1]"
    tr = StarredUnpackingTransformer()
    res = tr.visit(ast.parse(tree))
    expected = "[2] + list(range(10)) + [1]"
    assert astor.to_source(res) == expected


# Generated at 2022-06-21 18:01:08.895312
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    # Note: not tested in test_StarredUnpackingTransformer_run(). See there for explanation.

    from typed_ast import ast3 as ast
    from type_inference_programs.support import make_test_case_for_given_input_output

    StarredUnpackingTransformer.run_test = staticmethod(
        make_test_case_for_given_input_output(StarredUnpackingTransformer))

    StarredUnpackingTransformer.run_test(
        input_ast="print(*range(1), *range(3))",
        expected_output_ast="print(*(list(range(1)) + list(range(3))))")


# Generated at 2022-06-21 18:01:11.520176
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:13.984092
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[1, *[2, 3], 4]').body[0]
    result = StarredUnpackingTransformer().visit(node)
    assert isinstance(result.elts[0], ast.Call)
    assert len(result.elts) == 2
    assert isinstance(result.elts[1], ast.List)


# Generated at 2022-06-21 18:01:17.171113
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = [2, *range(10), 1]
    expected = [2] + list(range(10)) + [1]
    result = StarredUnpackingTransformer().visit(source)
    assert result == expected



# Generated at 2022-06-21 18:01:29.409772
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # this code is meant to test:
    #   if not self._has_starred(node.elts):
    #   splitted = self._split_by_starred(xs)
    #   prepared = list(self._prepare_lists(splitted))
    #   return self._merge_lists(prepared)
    #   return self.generic_visit(node)  # type: ignore
    StarredUnpackingTransformer(inplace=False).visit(
        ast.parse('list(range(10))'))
    StarredUnpackingTransformer(inplace=False).visit(
        ast.parse('[2, list(range(10)), 1]'))
    StarredUnpackingTransformer(inplace=False).visit(
        ast.parse('[2, *range(10), 1]'))




# Generated at 2022-06-21 18:01:40.949872
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = ast.parse("a = [2, *range(10), 1]\n"
                       "b = print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(source)
    assert ast.dump(source) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], " \
        "value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add())), " \
       

# Generated at 2022-06-21 18:01:53.833218
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    def transform_list(list_):
        transformer = StarredUnpackingTransformer()
        trans_list = transformer.visit(ast.parse(list_).body[0].value)
        return ast.unparse(trans_list).strip()

    assert transform_list("[2, *range(10), 1]") == "[2] + list(range(10)) + [1]"
    assert transform_list("[2, *range(10)]") == "[2] + list(range(10))"
    assert transform_list("[*range(10), 1]") == "list(range(10)) + [1]"
    assert transform_list("[*range(10)]") == "list(range(10))"
    assert transform_list("[2, 1]") == "[2, 1]"

# Generated at 2022-06-21 18:02:06.475086
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .cst_to_ast import cst_to_ast
    from .TestTransformer import TestTransformer

# Generated at 2022-06-21 18:02:12.721388
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'a(1, *b, *c, 2)'
    expected_source = 'a(*(([1] + list(b)) + list(c)) + [2])'
    node = ast.parse(source, '<unknown>', mode='eval')
    actual_node = StarredUnpackingTransformer().visit(node)
    assert astor.to_source(actual_node) == expected_source


# Generated at 2022-06-21 18:02:24.414272
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import parse

    def transform(code: str) -> ast.Call:
        node = parse(code)
        return StarredUnpackingTransformer().visit(node)

    assert ast.dump(transform('print(*range(1), *range(3))')) == \
        "Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=1)], keywords=[])], ctx=Load()), right=List(elts=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=3)], keywords=[])], ctx=Load()), op=Add()))], keywords=[]))"


#

# Generated at 2022-06-21 18:02:52.356909
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    assert ast.dump(
        transformer.visit(
            ast.parse("[2, *range(10), 1]")
        )
    ) == "[2] + list(range(10)) + [1]"



# Generated at 2022-06-21 18:03:01.536537
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

  # Tested function
  transformer = StarredUnpackingTransformer()

  # Expected values
  expected_tree_changed = True
  expected_node = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)]), right=ast.Call(ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[]), op=ast.Add())

  # Values to test
  node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])

  # Perform the test
  actual_node = transformer

# Generated at 2022-06-21 18:03:03.070036
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:13.291706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # class Starred:
    #     """Compiles:
    #         print(*range(1), *range(3))
    #     To:
    #         print(*(list(range(1)) + list(range(3))))
    #
    #     """

    tree = ast.parse('''
print(*range(1), *range(3))
''')

    trans = StarredUnpackingTransformer()
    trans.visit(tree)

    assert isinstance(tree.body[0].value.args[0], ast.Starred)
    assert isinstance(tree.body[0].value.args[0].value, ast.BinOp)

    # class Starred:
    #     """Compiles:
    #         print(*range(1), 2)
    #     To:
    #         print(*(list(

# Generated at 2022-06-21 18:03:25.560999
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pt = StarredUnpackingTransformer()
    x = ast.parse('[2, 1, 3]')
    ok_x = ast.parse('[2, 1, 3]')
    x_repl1 = ast.parse('[2, 1, 3] + list(range(3))')
    x_repl2 = ast.parse('list(range(3)) + [2, 1, 3]')
    x_repl3 = ast.parse('list(range(3)) + [2, *range(3), 3] + list(range(3))')
    x_repl4 = ast.parse('[2, 1, 3] + list(range(3))')

    x1 = ast.parse('[2, *range(3)]')
    ok_x1 = ast.parse('[2, 1, *range(3)]')


# Generated at 2022-06-21 18:03:36.596581
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_file = open("../ast_transformer/transformer.py", "r").read()
    class_ast = ast.parse(class_file)

    transformer = StarredUnpackingTransformer()
    for node in ast.walk(class_ast):
        if isinstance(node, ast.Starred):
            transformer.visit(node)
            
    executor = Executor()
    code = executor.visit(class_ast)
    exec(code, globals())
    assert transformer == StarredUnpackingTransformer()
    assert transformer.__str__() == "StarredUnpackingTransformer"
    assert transformer.__repr__() == "<StarredUnpackingTransformer>"

# Generated at 2022-06-21 18:03:44.732636
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast
    from .sample_asts import StarredUnpackingTransformer_visit_Call_ast as sample_ast

    class TestCase(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer
        def test_StarredUnpackingTransformer_visit_Call(self):
            self.assertTransformedAST(sample_ast)
    TestCase().test_StarredUnpackingTransformer_visit_Call()


# Generated at 2022-06-21 18:03:52.547846
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    PREFIX = '{}/demos/ast/'.format(ROOT_DIR)
    tree = ast.parse(pathlib.Path(PREFIX + 'StarredUnpacking.py').read_text())
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    with open(PREFIX + 'StarredUnpacking2.py', 'w') as o:
        o.write(astor.to_source(tree, indent_with='    '))
    assert bool(trans.tree_changed) == True


# Generated at 2022-06-21 18:04:02.989550
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .unittest_helpers import assert_py_and_cpp_ast_equivalent, compile_cpp
    tr = StarredUnpackingTransformer()

    @assert_py_and_cpp_ast_equivalent(tr, compile_cpp=compile_cpp)
    def test():
        f([2, *range(10), 1])

    @assert_py_and_cpp_ast_equivalent(tr, compile_cpp=compile_cpp)
    def test():
        f([2, *range(10), 3], *range(10))

    @assert_py_and_cpp_ast_equivalent(tr, compile_cpp=compile_cpp)
    def test():
        f(2, *range(10), *range(10), 3)


# Generated at 2022-06-21 18:04:07.834321
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    actual = StarredUnpackingTransformer()(expected)
    assert ast.dump(src) == ast.dump(actual)

# Generated at 2022-06-21 18:05:08.302920
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astunparse
    import astunparseplus
    code = '[1, 2, *range(10)]'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert code != astunparseplus.unparse(tree)
    assert '1, 2, *range(10)' not in astunparse.unparse(tree)
    #print(astunparseplus.unparse(tree))

    code = 'print(*range(10))'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert code != astunparseplus.unparse(tree)
    assert '*range(10)' not in astunparse.unparse(tree)
    #print(astunparseplus.unparse(tree))



# Generated at 2022-06-21 18:05:15.899568
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .unit_tools import get_ast
    from .unit_tools import compare_ast
    from .unit_tools import rewrite

    src = '[2, *range(10), 1]'
    expected = '2 + list(range(10)) + [1]'

    trand = StarredUnpackingTransformer()
    trand.visit(get_ast(src))
    assert trand._tree_changed
    assert compare_ast(expected, rewrite(trand.root))


# Generated at 2022-06-21 18:05:26.835016
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code1 = "print(*range(1), *range(3))"
    expected1 = "print(*(list(range(1)) + list(range(3))))"
    actual1 = StarredUnpackingTransformer().visit(ast.parse(code1)).body[0]
    assert expected1 == astor.to_source(actual1).strip()

    code2 = "print(*[1, 2, 3])"
    expected2 = "print(*[1, 2, 3])"
    actual2 = StarredUnpackingTransformer().visit(ast.parse(code2)).body[0]
    assert expected2 == astor.to_source(actual2).strip()

    code3 = "print(1, *range(3), 4, 5, *{6})"

# Generated at 2022-06-21 18:05:34.146493
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    for code in [
        "print(*range(10), *range(20))",
        "print(*range(10), *range(20), sep='/')",
        "print(*range(10), *range(20), file=sys.stderr)",
        "print(*range(10), *range(20), **{'sep': '/'})",
    ]:
        node = ast.parse(code)
        result = StarredUnpackingTransformer(node).result

        code = compile(result, '', 'exec')
        exec(code)

# Generated at 2022-06-21 18:05:35.478033
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:05:37.064210
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    if __debug__:
        NodeTransformer = StarredUnpackingTransformer

# Generated at 2022-06-21 18:05:47.891840
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:05:58.145257
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import compile_entry
    from .helpers import assert_item_same, assert_node_equal

    tests = [
        ("print(1)", "print(1)"),
        ("print(1, 2)", "print(1, 2)"),
        ('print(1, *range(3), 2, 3)', 'print(*(list([1]) + list(range(3)) + list([2, 3])))'),
    ]

    for code, expected in tests:
        tree = compile_entry(code, '<test>', 'exec')
        assert_item_same(tree.body[0], ast.parse(expected))



# Generated at 2022-06-21 18:05:59.226025
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:06:09.374436
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("test_StarredUnpackingTransformer_visit_Call")
    import astor
    # Test case: print(1, *range(4), 4)
    example_input = \
"""
print(1, *range(4), 4)
"""
    example_output = \
"""
print(*(list([1]) + list(range(4)) + list([4])))
"""
    in_node = astor.parse_expr(example_input)
    trans = StarredUnpackingTransformer()
    out_node = trans.visit(in_node)
    assert astor.to_source(out_node) == example_output
