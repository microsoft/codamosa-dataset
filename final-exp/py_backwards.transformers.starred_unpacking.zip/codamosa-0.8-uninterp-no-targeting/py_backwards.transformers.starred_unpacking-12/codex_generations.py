

# Generated at 2022-06-21 17:57:18.449598
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from transpyle.ast_processing import AstProcessor
    processor = AstProcessor(transformer=StarredUnpackingTransformer)
    code = 'print(*range(1), 1, *range(3))'
    tree = ast.parse(code)
    tree = processor.visit(tree)
    assert tree is not None
    assert ast.dump(tree) == ast.dump(ast.parse('print(*(list(range(1)) + list(range(3))), 1)'))


# Generated at 2022-06-21 17:57:23.194957
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of class StarredUnpackingTransformer
    """
    print('Constructor test for class StarredUnpackingTransformer')

    sut = StarredUnpackingTransformer()
    assert repr(sut) == "<StarredUnpackingTransformer for Python 3.4>"


test_StarredUnpackingTransformer.__test__ = False  # type: ignore

# Generated at 2022-06-21 17:57:26.082970
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
"""
    expected = """
print(*(list(range(1)) + list(range(3))))
"""
    tree = ast.parse(source)
    StarredUnpackingTransformer(tree).visit(tree)
    assert astor.to_source(tree) == expected


# Generated at 2022-06-21 17:57:27.878536
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:57:38.635962
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_astunparse as unparser
    st = ast.parse("[2, *range(10), 1]")
    unparser.unparse(StarredUnpackingTransformer().visit(st))
    st = ast.parse("print(*range(1), *range(3))")
    unparser.unparse(StarredUnpackingTransformer().visit(st))
    st = ast.parse("print(*range(1), *range(3), *range(5))")
    unparser.unparse(StarredUnpackingTransformer().visit(st))
    st = ast.parse("print(1, *range(5))")
    unparser.unparse(StarredUnpackingTransformer().visit(st))
    st = ast.parse("print(*range(5), 1)")

# Generated at 2022-06-21 17:57:49.319988
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node1 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='args'), ctx=ast.Load()), ast.Str(s='\n')], keywords=[])
    node2 = StarredUnpackingTransformer().visit(node1)
    assert isinstance(node2, ast.Call)
    assert isinstance(node2.args[0], ast.Starred)
    assert isinstance(node2.args[0].value, ast.BinOp)
    assert isinstance(node2.args[0].value.left, ast.Call)
    assert isinstance(node2.args[0].value.left.func, ast.Name)
    assert node2.args[0].value.left.func.id == 'list'

# Generated at 2022-06-21 17:57:54.748672
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = "print(*range(1), *range(3))"
    py3_ast = ast.parse(code)
    py2_ast = StarredUnpackingTransformer().visit(py3_ast)
    code2 = compile(py2_ast, filename="<ast>", mode="exec")
    exec(code2)

# Generated at 2022-06-21 17:58:00.716353
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import parse
    from .function import FunctionTransformer
    from .import_ import ImportTransformer
    from .class_ import ClassTransformer
    from .loop import LoopTransformer
    from .pass_ import RemovePassTransformer
    from .condition import ConditionTransformer

    source = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """.strip()

    result = """
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """.strip()

    # Init class StarredUnpackingTransformer
    class_name = 'StarredUnpackingTransformer'
    class_bases = (StarredUnpackingTransformer,)

# Generated at 2022-06-21 17:58:05.244795
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    ''' This test checks the constructor of class StarredUnpackingTransformer
        to make sure it works as intended
    '''
    assert (isinstance(StarredUnpackingTransformer(), BaseNodeTransformer))


# Generated at 2022-06-21 17:58:13.536874
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    lines = "import os; print(os.linesep)"
    tree = ast.parse(lines, "test")
    tree = ast.fix_missing_locations(tree)
    assert ast.dump(tree) == ast.dump(transformer.visit(tree))
    return


if __name__ == "__main__":
    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:23.518788
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as ast_stdlib

    source = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """

    tree = ast_stdlib.parse(source)
    StarredUnpackingTransformer().visit(tree)
    compile(tree, filename='<ast>', mode='exec')

    assert expected == ast_stdlib.dump(tree)

# Generated at 2022-06-21 17:58:27.541612
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class test_transformer_constuctor(unittest.TestCase):
        def test_init(self):
            node = ast.List()
            result = StarredUnpackingTransformer(node)
            self.assertEqual(True, result._tree_changed)


# Generated at 2022-06-21 17:58:39.671987
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1]
    # print(*range(1), *range(3))
    root = ast.parse("""\
a = [2, *range(10), 1]
b = [2, 3, 4]
c = print()
d = print(*range(1), *range(3))
""")
    StarredUnpackingTransformer().visit(root)
    expected = ast.parse("""\
a = [2] + list(range(10)) + [1]
b = [2, 3, 4]
c = print()
d = print(*(list(range(1)) + list(range(3))))
""")
    assert ast.dump(root) == ast.dump(expected)



# Generated at 2022-06-21 17:58:41.190253
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(allow_recursive=True).target == (3, 4)


# Generated at 2022-06-21 17:58:43.130607
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print(StarredUnpackingTransformer())

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:51.631286
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3

    # Test for visit_List
    list_test = ast3.parse('[2, *range(10), 1]')
    expected = ast3.parse('[2] + list(range(10)) + [1]')
    assert (StarredUnpackingTransformer().visit(list_test)) == expected

    # Test for visit_Call
    call_test = ast3.parse('print(*range(1), *range(3))')
    expected = ast3.parse('print(*(list(range(1)) + list(range(3))))')
    assert (StarredUnpackingTransformer().visit(call_test)) == expected

# Generated at 2022-06-21 17:58:55.686495
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)

# Testing values of attributes of object StarredUnpackingTransformer.__dict__

# Generated at 2022-06-21 17:59:00.402511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[1, 2, *range(5), -1]')
    StarredUnpackingTransformer().visit(node)
    assert str(node) == '[1, 2] + list(range(5)) + [-1]'


# Generated at 2022-06-21 17:59:05.647467
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._split_by_starred([ast.Name(id='int'),
                                                          ast.Starred(value=ast.Name(id='range'))]) == [[ast.Name(id='int')],
                                                                                                       ast.Starred(value=ast.Name(id='range')),
                                                                                                       []]

# Generated at 2022-06-21 17:59:15.580163
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        return

    code = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
        """
    expected_source = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        """

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_source.strip()

# Generated at 2022-06-21 17:59:31.975130
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Unit test for constructor of class StarredUnpackingTransformer")
    # Create an instance of StarredUnpackingTransformer
    obj = StarredUnpackingTransformer()
    # Create an expression [1, 2, *range(4), 5, 6]
    list_args = [ast.Num(n=1), ast.Num(n=2), ast.Starred(ast.Call(ast.Name('range', ast.Load()), [ast.Num(4)], [])), ast.Num(5), ast.Num(6)]
    expr = ast.List(list_args, ast.Load())
    print("Before list transformation: ", ast.dump(expr))
    expected = '[1, 2] + list(range(4)) + [5, 6]'
    print("Expected: ", expected)

# Generated at 2022-06-21 17:59:38.860539
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(3, *range(3), 4)")
    expected = ast.parse("print(*([3] + list(range(3)) + [4]))")
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:59:47.436565
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 17:59:53.331064
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(
        code='''
        [2, *range(10), 1]
        print(*range(1), *range(3))
        ''').to_source() == '''
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        '''

# Generated at 2022-06-21 18:00:06.362661
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[1, *range(2), 3, *range(4)]")
    code = ast.fix_missing_locations(tree)
    trans = StarredUnpackingTransformer()
    fixed = trans.visit(code)
    assert ast.dump(fixed) == "Expr(value=BinOp(left=List(elts=[Num(n=1)]), op=Add(), right=BinOp(left=Call(args=[Num(n=2)], func=Name(id='range', ctx=Load()), keywords=[]), op=Add(), right=BinOp(left=List(elts=[Num(n=3)]), op=Add(), right=Call(args=[Num(n=4)], func=Name(id='range', ctx=Load()), keywords=[]))))))"  # no

# Generated at 2022-06-21 18:00:18.039003
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:00:25.076579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    src = 'print(*range(1), *range(3))'
    expected = ast.parse(
        'print(*(list(range(1)) + list(range(3))))'
    ).body[0]

    node = ast.parse(src)

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    transformer.assert_tree_changed()
    assert result == expected



# Generated at 2022-06-21 18:00:32.939167
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from pytype_extensions.type_utils import my_eval
    
    tree = ast3.parse('[2, *range(10), 1]')
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    assert trans._tree_changed == True
    assert my_eval(tree) == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]
    
    tree = ast3.parse('[2, 3, 4]')
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    assert trans._tree_changed == False
    assert my_eval(tree) == [2, 3, 4]
    
    tree = ast3.parse('[*list(range(1))]')


# Generated at 2022-06-21 18:00:45.216336
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert make_ast("[2, *range(10), 1]").body[0] == StarredUnpackingTransformer().visit(
        make_ast("[2, *range(10), 1]").body[0])
    assert (make_ast("[2, 1, *range(10), 1]").body[0] ==
            StarredUnpackingTransformer().visit(
                make_ast("[2, 1, *range(10), 1]").body[0]))
    assert (make_ast("[2, 1, *range(10), 1, *range(10), 1]").body[0] ==
            StarredUnpackingTransformer().visit(
                make_ast("[2, 1, *range(10), 1, *range(10), 1]").body[0]))

# Generated at 2022-06-21 18:00:49.403122
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = textwrap.dedent('''
    [2, *range(10), 1]
    ''')
    node = ast.parse(code)
    node = StarredUnpackingTransformer.visit(node)
    assert code_gen(node) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-21 18:01:05.166430
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')

    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)

    exec(compile(expected, '<ast>', mode='exec'))
    exec(compile(new_tree, '<ast>', mode='exec'))



# Generated at 2022-06-21 18:01:12.733029
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse("total = sum([1, 2, 3, 4] + [5, 6, 7] + [8, 9])")
    code = ast.parse("total = sum([1, 2, 3, *range(4), 5, 6, 7 * 2, *range(10, 11)])")
    assert expected.body == StarredUnpackingTransformer().visit(code).body



# Generated at 2022-06-21 18:01:17.767866
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    assert len(transformer.visit(ast.parse("print(1, *[1, 2], *{})"))) == 1
    assert len(transformer.visit(ast.parse("print()"))) == 1
    assert len(transformer.visit(ast.parse("print(1, *[1, 2], *{},)"))) == 1

# Generated at 2022-06-21 18:01:29.252719
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    _module = ast.parse("[*range(3), 1, 2]")
    assert not StarredUnpackingTransformer().visit(_module)
    assert ast.dump(_module) == textwrap.dedent('''\
        Module(body=[Expr(value=BinOp(left=Call(func=Name(id='list', ctx=Load()),
                                                args=[Starred(value=Call(func=Name(id='range', ctx=Load()),
                                                                           args=[Num(n=3)], keywords=[]))],
                                                keywords=[]),
                                      op=Add(),
                                      right=List(elts=[Num(n=1), Num(n=2)])))])''')



# Generated at 2022-06-21 18:01:36.761448
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    buf = io.StringIO()
    src = 'print(*range(1), *range(3))'

    module = ast.parse(src)
    StarredUnpackingTransformer().visit(module)  # type: ignore
    tree = ast.fix_missing_locations(module)
    compiled = compile(tree, '<range>', 'exec')
    eval(compiled, {'print': print, 'range': lambda x: [i for i in range(x)]}, {})
    output = buf.getvalue().strip()

    assert output == '0 1 2'

# Generated at 2022-06-21 18:01:43.519848
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import test_compiler
    comp = test_compiler.Compiler()
    trans = StarredUnpackingTransformer()

    source = '''[2, *range(10), 1]
print(*range(1), *range(3))'''
    comp.set_source(source, '<test>')
    comp.visit(trans)
    assert comp.source == comp.source_orig == source
    assert comp.tree_changed == trans._tree_changed
    assert not comp.tree_changed

    comp.reset()
    comp.set_source('[2, *[], *range(10), 3, *[1]]', '<test>')
    comp.visit(trans)
    assert comp.source != comp.source_orig
    assert comp.tree_changed == trans._tree_changed

# Generated at 2022-06-21 18:01:47.350652
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class TestStarredUnpackingTransformer():
        def __init__(self):
            self.tree_changed = True
    x = StarredUnpackingTransformer()
    assert isinstance(x, StarredUnpackingTransformer)



# Generated at 2022-06-21 18:01:48.489020
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:59.952085
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..testing_utils import assert_equal_with_printing
    import astor

    a = ast.parse('[1, *[2], 3]')
    a.body = StarredUnpackingTransformer().visit(a.body)
    assert_equal_with_printing(astor.to_source(a), '([1] + list([2]) + [3])')

    a = ast.parse('[1, *[2], 3, *[4], 5]')
    a.body = StarredUnpackingTransformer().visit(a.body)
    assert_equal_with_printing(astor.to_source(a), '([1] + list([2]) + [3] + list([4]) + [5])')


# Generated at 2022-06-21 18:02:06.937885
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = 'list = [2, *range(10), 1]'
    tree = ast.parse(code)
    tr = StarredUnpackingTransformer()
    tr.visit(tree)
    res = compile(tree, '', 'exec')
    d = {}
    exec(res, d)
    assert d['list'] == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]


# Generated at 2022-06-21 18:02:30.405398
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    nodes = [ast.List([ast.Num(n=2), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()),ast.Num(n=1)], ctx=ast.Load()), ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()),ast.Num(n=1)], keywords=[])]
    for n in nodes:
        StarredUnpackingTransformer().visit(n)


if __name__ == '__main__':
    from .conftest import assume_ast_types_are_present
    assume_ast_types_are_present()

    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:35.211139
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    lst = [2, *range(10), 1]
    prnt = print(*range(1), *range(3))

    assert lst == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]
    assert prnt == None

# Generated at 2022-06-21 18:02:46.258935
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    obj = StarredUnpackingTransformer(source_code='',
                                      filename='',
                                      add_line_information=False)
    expr_0_0 = ast.Name(id='print', ctx=ast.Load())
    arg_0_1 = ast.Call(func=expr_0_0, args=[], keywords=[])
    expr_0_2 = ast.Num(n=2)
    stararg_0_3 = ast.Starred(value=expr_0_2, ctx=ast.Load())
    expr_0_4 = ast.Name(id='range', ctx=ast.Load())
    call_0_5 = ast.Call(func=expr_0_4, args=[], keywords=[])

# Generated at 2022-06-21 18:02:57.850015
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_util import check_visitor_result_is

    src = """[2, *range(10), 1]"""
    tree = compile(src, "<?>", "exec", ast.PyCF_ONLY_AST)
    tree = StarredUnpackingTransformer().visit(tree)

    res = compile(ast.dump(tree), "<?>", "exec")
    result = list(res.co_consts)
    assert result == [2, range(10), 1]

    src = """[2, *range(10), 1]"""
    check_visitor_result_is(StarredUnpackingTransformer, src, """
        list([2]) + list(range(10)) + list([1])
    """)

    src = """[2, *range(10)]"""
    check_visitor_result

# Generated at 2022-06-21 18:03:09.130724
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class MyNodeVisitor(StarredUnpackingTransformer):
        def generic_visit(self, node):
            return node

    lst = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range'),
                args=[
                    ast.Num(n=10),
                ],
                keywords=[])),
            ast.Num(n=1),
        ],
        ctx=ast.Load())
    assert ast.dump(lst) == 'List(elts=[Num(n=2), Starred(value=Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=10)], keywords=[])), Num(n=1)], ctx=Load())'

    l

# Generated at 2022-06-21 18:03:18.461316
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = ast.parse("""
    x = [1, 2, 3, 4, 5]
    x = list(x) + list([1, 2])    
    y = x + x
    """)
    actual = ast.parse("""
    x = [1, 2, 3, 4, 5]
    x = [1, 2, 3, 4, 5] + [1, 2]
    y = [1, 2, 3, 4, 5] + [1, 2, 3, 4, 5]
    """)
    StarredUnpackingTransformer().visit(actual)
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-21 18:03:20.053050
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:03:31.419128
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tr = StarredUnpackingTransformer()
    elts = [ast.Num(1, lineno=1, col_offset=0),
            ast.Starred(ast.Name('a', ast.Load(), lineno=1, col_offset=0), lineno=1, col_offset=0),
            ast.Num(3, lineno=1, col_offset=0),
            ast.Starred(ast.Name('b', ast.Load(), lineno=1, col_offset=0), lineno=1, col_offset=0),
            ast.Num(5, lineno=1, col_offset=0)]
    list_node = ast.List(elts, lineno=1, col_offset=0)
    node = tr.visit(list_node)
    #print(ast.dump(node))
   

# Generated at 2022-06-21 18:03:44.252721
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = '[2, *range(10), 1]\n'
    test = 'assert [2] + list(range(10)) + [1] == '

    expected = 'assert [2] + list(range(10)) + [1] == [2] + list(range(10)) + [1]\n'

    node = ast.parse(src)  # type: ignore
    node = StarredUnpackingTransformer().visit(node)
    code = compile(node, '<%s>' % 'test', mode='exec')

    globals().update({'range': range})
    exec(code)

    assert test in src
    assert node.body[0].targets[0].elts[0].elts == \
        node.body[0].value.left.elts + node.body[0].value

# Generated at 2022-06-21 18:03:55.670255
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_inputs.starred_unpacking import input_code as input
    from .test_inputs.starred_unpacking import output_code as expected_output

    from .test_inputs.starred_unpacking import expected_output_args as expected_output2

    # First test
    transformer = StarredUnpackingTransformer()
    tree = ast.parse(input)
    transformer.visit(tree)
    output = compile(tree, '', mode='exec')
    exec(output)

    # Second test
    transformer = StarredUnpackingTransformer()
    tree2 = ast.parse(input)
    transformer.visit(tree2)
    output2 = compile(tree2, '', mode='exec')
    exec(output2)

    # Compare
    assert output == expected_output

# Generated at 2022-06-21 18:04:30.532915
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arrange
    ast_tree = ast.parse(
        textwrap.dedent('''
        print(1, *range(3), *range(4), 7)
    '''))
    expected_ast_tree = ast.parse(textwrap.dedent('''
    print(*((1,) + list(range(3)) + list(range(4)) + (7,)))
    '''))
    
    # Act
    StarredUnpackingTransformer(ast_tree).visit(ast_tree)

    # Assert
    assert ast.dump(ast_tree, annotate_fields=False) == ast.dump(expected_ast_tree, annotate_fields=False)


# Generated at 2022-06-21 18:04:40.156172
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .base import BaseNodeTransformer, Options
    StarredUnpackingTransformer(tree_changed=False, options=Options()).visit_Call(
    ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
             args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())], keywords=[]))

# Generated at 2022-06-21 18:04:42.099976
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:04:51.323539
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast_transforms import StarredUnpackingTransformer
    from typed_ast.ast3 import List, Starred, Expr, Name, Load, Add, Call, \
        Subscript, Index, Num, BinOp, parse
    assert parse("[2, *range(10), 1]").body[0] == Expr(value=List(elts=[Num(n=2),
        Starred(value=Name(id='range', ctx=Load()), ctx=Load()), Num(n=1)], ctx=Load()))
    assert parse("print(*range(1), *range(3))").body[0].value.args == [
        Starred(value=Name(id='range', ctx=Load()), ctx=Load())]



# Generated at 2022-06-21 18:04:52.664022
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    assert trans is not None


# Generated at 2022-06-21 18:04:54.446193
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast, unittest
    from typed_ast import ast3

# Generated at 2022-06-21 18:05:06.811131
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    from typed_astunparse import unparse
    from typed_ast import ast3 as _ast
    import astor
    from .method_signature import MethodSignature
    from .insert_explicit_return import InsertExplicitReturn

    test_input_code_1 = "[1, 2, 3]"
    test_input_1 = astor.parse_file(MethodSignature.input_to_string(
        test_input_code_1)).body[0]
    test_input_1.body = [test_input_1.body[0]]
    test_output_1 = astor.parse_file(MethodSignature.input_to_string(
        test_input_code_1)).body[0]
    test_output_1.body = [test_output_1.body[0]]

    test_input_code_

# Generated at 2022-06-21 18:05:12.796718
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), 2, *range(3))'
    expected_tree = ast.parse('print(*(list(range(1)) + [2] + list(range(3))))')
    tree = ast.parse(source)

    StarredUnpackingTransformer().visit(tree)
    assert tree.body[0].value == expected_tree.body[0].value


# Generated at 2022-06-21 18:05:24.691008
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from typed_ast.ast3 import parse
    # Create a call node tree
    call_node = pyast.Call(
        func=pyast.Name(id="print"),
        args=[
            pyast.Starred(
                value = pyast.Call(
                    func=pyast.Name(id="range"),
                    args=[pyast.Num(n=1)],
                    keywords=[]),
                ctx=pyast.Load()),
            pyast.Starred(
                value = pyast.Call(
                    func=pyast.Name(id="range"),
                    args=[pyast.Num(n=3)],
                    keywords=[]),
                ctx=pyast.Load())],
        keywords=[])
    print("Original AST: ")

# Generated at 2022-06-21 18:05:31.650585
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[
        ast.Num(n=3),
        ast.Starred(value=ast.Name(id='a')),
        ast.Num(n=5)
    ])
    expected = ast.BinOp(
        left=ast.List(elts=[ast.Num(n=3)]),
        right=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='a')],
            keywords=[]),
        op=ast.Add())
    expected = ast.BinOp(
        left=expected,
        right=ast.List(elts=[ast.Num(n=5)]),
        op=ast.Add())
    visitor = StarredUnpackingTransformer()
    result = visitor.visit(node)

# Generated at 2022-06-21 18:06:00.884347
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert isinstance(t, StarredUnpackingTransformer)

# Generated at 2022-06-21 18:06:13.112790
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
  """unit test for method visit_List of class StarredUnpackingTransformer """
  node1 = ast.List(elts=[ast.Starred(ast.Name(id='a'), ast.Load())])
  node2 = ast.List(elts=[ast.Starred(ast.Name(id='b'), ast.Load())])
  node3 = ast.Starred(ast.List(elts=[ast.Name(id='a'), ast.Name(id='a')], ctx=ast.Load()), ast.Load())
  node4 = ast.Starred(ast.List(elts=[ast.Name(id='a'), ast.Name(id='a')], ctx=ast.Load()), ast.Load())
  node5 = ast.Name(id='a', ctx=ast.Load())
  node6 = ast.Starred

# Generated at 2022-06-21 18:06:19.235467
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(code):
        return StarredUnpackingTransformer(
            stop_on_first_error=True,
            inline_callback=lambda node: None,
        ).visit(ast.parse(code))

    assert test("print(*range(1), *range(3))") == """\
print(*(list(range(1)) + list(range(3))))"""

# Generated at 2022-06-21 18:06:21.074352
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Module test

# Generated at 2022-06-21 18:06:28.812168
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
	compiler = StarredUnpackingTransformer()
	node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])
	compiler.visit(node)
	target = ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[]), ast.Num(n=1)])
	assert compiler._tree_changed == True
	assert node == target

# Generated at 2022-06-21 18:06:31.031215
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as py_ast
    import typed_ast.ast3 as t_ast


# Generated at 2022-06-21 18:06:37.141817
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = ast.parse('''
[1, 2, *range(3), 2]
''')
    expected = ast.parse('''
[1, 2] + list(range(3)) + [2]
''')
    result = StarredUnpackingTransformer().visit(input)
    assert result.body[0].value == expected.body[0].value


# Generated at 2022-06-21 18:06:39.997166
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    instance = StarredUnpackingTransformer()
    assert isinstance(instance, BaseNodeTransformer)

# All tests are in test_fixers.py

# Generated at 2022-06-21 18:06:48.871284
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = ast.parse('[2, *range(10), 1]')
    src.body[0].value.elts[1].value.func.id = 'list'
    src.body[0].value.elts[2].value.func.id = 'list'

    assert StarredUnpackingTransformer().visit(src) == src

    src = ast.parse('[2, *range(10), 1]')
    result = ast.parse('[2] + list(range(10)) + [1]')
    assert StarredUnpackingTransformer().visit(src) == result


# Generated at 2022-06-21 18:06:53.183056
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = 'print(*range(1), *range(3))'
    node = ast.parse(code)
    StarredUnpackingTransformer()(node)

    result = ast.parse('print(*(list(range(1)) + list(range(3))))')
    assert node == result, "Fail"