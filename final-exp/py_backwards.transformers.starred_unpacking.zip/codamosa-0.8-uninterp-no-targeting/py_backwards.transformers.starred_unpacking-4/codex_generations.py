

# Generated at 2022-06-21 17:57:20.761388
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 17:57:28.526186
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .util import parse_to_ast
    from .util import apply_transformer

    tree = parse_to_ast("""
    print(*range(1), *range(3))
    """, mode='exec')
    transformer = StarredUnpackingTransformer()
    res = apply_transformer(transformer, tree)
    assert res == ast.parse("""
    print(*(list(range(1)) + list(range(3))))
    """, mode='exec').body[0]

# Generated at 2022-06-21 17:57:35.947563
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_code = """
        print(*range(1), *range(3))
    """
    output_code = """
        print(*(list(range(1)) + list(range(3))))
    """
    transformer = StarredUnpackingTransformer()
    tree = ast.parse(input_code)
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert ast.dump(new_tree) == output_code



# Generated at 2022-06-21 17:57:38.470600
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    with pytest.raises(ValueError):
        sut.__init__("foo")
    assert sut

# Generated at 2022-06-21 17:57:50.169015
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class _NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.result = False
        def generic_visit(self, node):
            self.result = True
    _node_visitor = _NodeVisitor()
    _ast_Call = ast.parse("print(*range(1), *range(3))")
    _transformer = StarredUnpackingTransformer()
    _transformer.visit(_ast_Call)
    _transformer.generic_visit(_ast_Call)
    _ast_Call.body[0].value.args[0].value.args[0].func.id
    _node_visitor.visit(_ast_Call)
    assert _ast_Call.body[0].value.args[0].value.args[0].func.id == 'add'
   

# Generated at 2022-06-21 17:58:00.734971
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformer_test import dummy_visit
    from .. import dump

    # Example 1
    source = """\
        [2, *range(10), 1]
        """
    expected = """\
        [2] + list(range(10)) + [1]
        """
    transformer = StarredUnpackingTransformer(
        lambda node: isinstance(node, ast.FunctionDef),
        dummy_visit)
    # it should transform starred unpacking by adding elements of lists
    tree = ast.parse(source)
    tree = transformer.visit(tree)

    actual = dump(tree)
    assert expected == actual

    # Example 2
    source = """\
        [2, *range(10), *range(10), 1]
        """

# Generated at 2022-06-21 17:58:09.719430
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_util import expect_equal
    from .test_fixtures import in_out

    for method in (
            test_StarredUnpackingTransformer_visit_List,
            test_StarredUnpackingTransformer_visit_Call,
    ):
        method.__name__ = 'StarredUnpackingTransformer.{}'.format(method.__name__)

    test = StarredUnpackingTransformer.visit_List

# Generated at 2022-06-21 17:58:15.937924
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_transformer import _test_transform
    tpl = """
        func(1, *args, 5)
    """
    res = """
        func(*(([1] + list(args)) + [5]))
    """
    _test_transform(tpl, res, StarredUnpackingTransformer)
    _test_transform(res, res, StarredUnpackingTransformer)



# Generated at 2022-06-21 17:58:21.349853
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    node = ast.parse("[2, *range(10), 1]")
    node = StarredUnpackingTransformer().visit(node)
    assert typed_astunparse.unparse(node) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-21 17:58:22.838148
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()


# Generated at 2022-06-21 17:58:39.629324
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import get_ast
    from . import apply_transformer



# Generated at 2022-06-21 17:58:45.304629
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from pyt.utils import copy_tree

    ast1 = ast.parse('f(1, *range(2), 2)')
    expected_ast1 = ast.parse('f(*(range(1) + range(1)))')

    ast2 = ast.parse('f(1, 2, 3)')
    expected_ast2 = ast.parse('f(1, 2, 3)')

    ast3 = ast.parse('f(1, *range(2), *range(3), 2)')
    expected_ast3 = ast.parse('f(*(range(1) + range(1) + range(2)))')

    ast4 = ast.parse('f(*range(1), *range(2), *range(3))')

# Generated at 2022-06-21 17:58:50.452863
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from util import parse_single_stmt

    code = "print(*range(1), *range(3))"
    tree = parse_single_stmt(code)

    expected = "print(*(list(range(1)) + list(range(3))))"
    tree = StarredUnpackingTransformer.run_on(tree)
    assert tree == expected



# Generated at 2022-06-21 17:58:51.360054
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 17:58:58.473644
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # The following code is directly from previous test
    import ast
    from testing.types import MyDict, MySet
    from typed_ast import ast3 as typed_ast, convert

    # from typed_ast import ast3 as typed_ast
    # from typed_ast import convert
    # from testing.types import MyDict, MySet


# Generated at 2022-06-21 17:59:01.729875
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sut = StarredUnpackingTransformer()
    sut.visit(ast.parse("list(range(1), *range(2))"))
    sut.visit(ast.parse("list(*range(1), *range(2))"))
    sut.visit(ast.parse("list(*range(1), *range(2), *range(3))"))
    sut.visit(ast.parse("list(*range(1))"))
    sut.visit(ast.parse("[*range(1), *range(2), 2]"))


# Generated at 2022-06-21 17:59:08.647534
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse

    source = '[2, *range(10), 1]'
    source_ast = parse(source)
    StarredUnpackingTransformer().visit(source_ast)

    expected_source = """
[2] + list(range(10)) + [1]
    """

    assert expected_source.strip() == astor.to_source(source_ast).strip()


# Generated at 2022-06-21 17:59:19.337095
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from python_ta.transforms import StarredUnpackingTransformer

    tree = ast.parse('[2, *range(10), 1]', '', 'single')
    expected_tree = ast.parse('[2] + list(range(10)) + [1]', '', 'single')
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

    tree = ast.parse('[2, *range(10), [3, *range(10)], 1]', '', 'single')
    expected_tree = ast.parse('[2] + list(range(10)) + list([3] + list(range(10))) + [1]', '', 'single')
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree)

# Generated at 2022-06-21 17:59:25.758664
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from python_modernizer.compat import source_to_ast, ast_to_source
    tree = source_to_ast("print(*range(1), *range(3))")
    StarredUnpackingTransformer().generic_visit(tree)
    assert ast_to_source(tree) == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-21 17:59:26.979899
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  transformer = StarredUnpackingTransformer()
  assert transformer

# Generated at 2022-06-21 17:59:38.442033
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

    assert transformer.target == (3, 4)

    node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='e'), ctx=ast.Load()), ast.Num(n=3)], keywords=[])
    result = transformer.visit(node)
    expected = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Name(id='e')], 
        keywords=[],
        ), ctx=ast.Load())], keywords=[])
    assert result.__eq__(expected) == NotImplemented


# Generated at 2022-06-21 17:59:44.207239
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    inputStr = """
    *range(10)
    [2, *range(10), 1]
    [2, *range(10), 1][0]
    (*range(10), 1)
    (1, *range(10))
    """
    outStr = """
    list(range(10))
    [2] + list(range(10)) + [1]
    ([2] + list(range(10)) + [1])[0]
    (list(range(10)), 1)
    (1, list(range(10)))
    """
    out = compile(outStr, '', 'exec', ast.PyCF_ONLY_AST)
    print(astor.to_source(out).strip())


# Generated at 2022-06-21 17:59:56.051672
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .base import TreeBasedTransformerTestCase

    class Test(TreeBasedTransformerTestCase):
        transformers = StarredUnpackingTransformer

        def test_simple(self):
            code = 'print(2, *range(10), 1)'
            result = 'print(*(list(range(0, 10)) + [1]))'
            self.assertTransform(code, result)

        def test_nested(self):
            code = 'print(2, *range(10), 1, *range(5, 10), *[1])'
            result = 'print(*(list(range(0, 10)) + [1] + list(range(5, 10)) + list(range(1))))'
            self.assertTransform(code, result)

        def test_list(self):
            code

# Generated at 2022-06-21 17:59:57.627271
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()


# Generated at 2022-06-21 18:00:03.611897
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    exec(compile(new_tree, filename="<ast>", mode="exec"))



# Generated at 2022-06-21 18:00:11.434802
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert tree.body[0].value.left.func.id == 'range' \
        and tree.body[0].value.right.n == 1 \
        and tree.body[0].value.left.args[0].n == 10


# Generated at 2022-06-21 18:00:16.766138
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    f_in = "f = [2, *range(10), 1]\n"

    f_out = "f = [2] + list(range(10)) + [1]\n"

    assert remove_extra_indentation(StarredUnpackingTransformer(f_in).result) == remove_extra_indentation(f_out)


# Generated at 2022-06-21 18:00:20.508649
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]")) == ast.parse(
        "[2] + list(range(10)) + [1]")



# Generated at 2022-06-21 18:00:28.425777
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import os, sys
    sys.path.append(os.getcwd())
    from scripts.local_ast_transformer import LocalAstTransformer
    from scripts.utils import ast_dump, transform_and_dump, check_transformation

    list_str = '[2, *range(10), 1]'
    expected = ast_dump(ast.parse('[2] + list(range(10)) + [1]'))

    source_ast = ast.parse(list_str)
    actual_ast = LocalAstTransformer(StarredUnpackingTransformer()).visit(source_ast)

    assert ast_dump(actual_ast) == expected


# Generated at 2022-06-21 18:00:40.453744
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    _step = StarredUnpackingTransformer()
    node = ast.parse("print(*range(1), *range(3))")
    _step.visit(node)

# Generated at 2022-06-21 18:00:50.206497
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # before
    node = ast.parse("print(*range(1), *range(3))").body[0].value
    # after
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0].value.args[0].value
    assert StarredUnpackingTransformer().visit(node) == expected

# Generated at 2022-06-21 18:00:58.066779
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    # test a function call with no starred argument
    input_code = '''
    f()
    '''
    expected_code = '''
    f()
    '''
    tree = ast.parse(input_code)
    transformer.visit(tree)
    assert ast.dump(tree) == expected_code

    # test a function call with a single argument that is a starred expression
    input_code = '''
    f(*args)
    '''
    expected_code = '''
    f(*(list(args)))
    '''
    tree = ast.parse(input_code)
    transformer.visit(tree)
    assert ast.dump(tree) == expected_code

    # test a function call with multiple arguments and no starred argument

# Generated at 2022-06-21 18:01:07.927137
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    actual = ast.parse('f(1, *l1, 2, *l2, 3)').body[0]

# Generated at 2022-06-21 18:01:16.838714
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test should run if the ast version is >= 3.4.0.
    # Otherwise the code will not compile
    if tuple(map(int, ast.__version__.split("."))) >= (3, 4):
        src = "[2, *range(10), 1]"
        expected = "[2] + list(range(10)) + [1]"
        t = StarredUnpackingTransformer()
        res = t.visit(ast.parse(src))
        assert astor.to_source(res).splitlines() == expected.splitlines()


# Generated at 2022-06-21 18:01:23.163527
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    list_object = ast.parse('[2, *range(10), 1]').body[0].value
    expected_result = ast.parse('[2] + list(range(10)) + [1]').body[0].value
    assert transformer.visit(list_object) == expected_result


# Generated at 2022-06-21 18:01:33.963143
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast_compat import parse
    from astpp import dump
    from pytest import raises


# Generated at 2022-06-21 18:01:42.239665
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.parse("print(*range(1), *range(3))")
    met = StarredUnpackingTransformer(x).visit_Call
    call = x.body[0].value  # type: ast.Call
    assert call.args[0].value.func.id == 'range'
    assert call.args[1].value.func.id == 'range'
    new_call = met(call)
    assert new_call.starargs is None
    assert new_call.kwargs is None
    assert new_call.func.id == 'print'
    args = new_call.args[0].value
    assert isinstance(args, ast.BinOp)
    assert isinstance(args.left, ast.BinOp)
    assert isinstance(args.right, ast.Call)
    assert args.left

# Generated at 2022-06-21 18:01:54.492616
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    # Test case 1
    list1 = ast.List()
    list1.elts = [ast.Num()]
    list1.elts[0].n = 10
    list1_1 = ast.List()
    list1_1.elts = [ast.Starred()]
    list1_1.elts[0].value = ast.Name()
    list1_1.elts[0].value.id = "range"
    list1_1.elts[0].value.ctx = ast.Load()
    list1_2 = ast.List()
    list1_2.elts = [ast.Num()]
    list1_2.elts[0].n = 1
    list1.elts.append(list1_1)

# Generated at 2022-06-21 18:01:58.247834
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import inspect
    import astor
    # Should return source code of class
    assert inspect.getsource(StarredUnpackingTransformer) == astor.to_source(
        StarredUnpackingTransformer)


# Generated at 2022-06-21 18:02:07.470145
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """
    [2, *range(10), 1] - > [2] + list(range(10)) + [1]
    """
    start_node = ast.parse('[2, *range(10), 1]', mode='eval').body
    expected_node = ast.parse(
        '[2] + list(range(10)) + [1]', mode='eval').body

    trans = StarredUnpackingTransformer()
    assert ast.dump(expected_node).strip() == ast.dump(trans.visit(start_node)).strip()


# Generated at 2022-06-21 18:02:27.917444
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

    # Target version:
    # [2] + list(range(10)) + [1]
    list_node = ast.List(
        elts=[ast.Num(n=2),
              ast.Starred(value=ast.Call(
                  func=ast.Name(id='range'),
                  args=[ast.Num(n=10)],
                  keywords=[])),
              ast.Num(n=1)])

# Generated at 2022-06-21 18:02:37.072105
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
	assert StarredUnpackingTransformer()


######################################################################

# Unit test with Black
# Run in command line:
#    black --check --diff star_unpack.py

# To reformat code, use:
#    black star_unpack.py

# To enable automatic reformatting on save, add to VSCode User Settings:
#    "editor.formatOnSave": true,
#    "[python]": {
#       "editor.formatOnSave": true
#    }

# Generated at 2022-06-21 18:02:45.559695
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree).strip() == '[2] + list(range(10)) + [1]'

    tree = ast.parse('print(*range(1), *range(3))')
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree).strip() == 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-21 18:02:54.635519
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_compare import AstEqualityChecker
    equalityChecker = AstEqualityChecker()
    visitor = StarredUnpackingTransformer()

    old_call = ast.parse('print(1, *range(5), 3)')
    new_call = ast.parse('print(*(list(range(1)) + list(range(5)) + list(range(3))))')

    equalityChecker.check_ast(visitor.visit(old_call), new_call)


# Generated at 2022-06-21 18:03:05.372322
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of class StarredUnpackingTransformer"""
    print('')
    print('StarredUnpackingTransformer.__class__.__name__:', StarredUnpackingTransformer.__class__.__name__)
    print('StarredUnpackingTransformer.__mro__:', StarredUnpackingTransformer.__mro__)
    print('')
    print('StarredUnpackingTransformer._tree_changed:', StarredUnpackingTransformer._tree_changed)
    print('')
    print('StarredUnpackingTransformer.target:', StarredUnpackingTransformer.target)
    print('StarredUnpackingTransformer.target.__class__.__name__:', StarredUnpackingTransformer.target.__class__.__name__)

# Generated at 2022-06-21 18:03:14.720898
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse(
            "for x in [1, 2, *range(10), 1]:\n"
            "    pass"
        ).body[0]

    StarredUnpackingTransformer().visit(node)


# Generated at 2022-06-21 18:03:24.680013
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    code = '[a, *b, c]'
    tree = ast.parse(code)
    expected_tree = ast.parse('[a] + list(b) + [c]')

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(tree)
    result = ast.fix_missing_locations(result)
    expected_result = ast.fix_missing_locations(expected_tree)
    assert astor.to_source(result) == astor.to_source(expected_result)
    assert transformer._tree_changed == True



# Generated at 2022-06-21 18:03:30.144856
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print(StarredUnpackingTransformer.__name__)

    class TestVisitor(ast.NodeVisitor):
        def visit_Call(self, node):
            print('Call', ast.dump(node))

        def visit_BinOp(self, node):
            print('BinOp', ast.dump(node))

        def visit_List(self, node):
            print('List', ast.dump(node))

        def visit_Starred(self, node):
            print('Starred', ast.dump(node))

    transformer = StarredUnpackingTransformer()
    src = 'x = [1, *range(10), 2]'
    src = 'x = [1, *range(10), *[1, 2, 3], 2]'
    node = ast.parse(src)
    node = transformer.visit(node)

# Generated at 2022-06-21 18:03:39.079244
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_ = "print(*range(2), 3, *range(2))"
    expected_output = "print(*(list(range(2)) + [3] + list(range(2))))"

    input_ast_tree = ast.parse(input_)
    expected_output_ast_tree = ast.parse(expected_output)

    transformer = StarredUnpackingTransformer(input_)
    transformer.visit(input_ast_tree)

    assert ast.dump(input_ast_tree) == ast.dump(expected_output_ast_tree)

# Generated at 2022-06-21 18:03:48.539726
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Name(id='a')
            )
        ],
        keywords=[])


    class SuperNodeTransformer(StarredUnpackingTransformer):
        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True

            return False

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            lists = [[]]  # type: List[Splitted]
            for x in xs:
                if isinstance(x, ast.Starred):
                    lists.append(x)
                    lists.append

# Generated at 2022-06-21 18:04:04.468624
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """
    tree = ast.parse(code)

    expected_code = """
        ([2] + list(range(10)) + [1])
        print(*(list(range(1)) + list(range(3))))
    """
    expected_tree = ast.parse(expected_code)

    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(tree)

    assert_equal_ignore_lineno(transformed, expected_tree)

# Generated at 2022-06-21 18:04:08.434089
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t.__class__.__name__ == 'StarredUnpackingTransformer'
    assert isinstance(t, BaseNodeTransformer)


# Generated at 2022-06-21 18:04:13.999738
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import get_source_of_transformed
    from .test_fixtures import StarredUnpackingCallFixture
    transformer = StarredUnpackingTransformer()
    source = get_source_of_transformed(transformer, StarredUnpackingCallFixture)
    assert source == expected_StarredUnpackingCallFixture



# Generated at 2022-06-21 18:04:15.754799
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:04:25.640886
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    from typed_astunparse import unparse
    from astor.codegen import to_source

    from .testutils import assert_source_code
    from astunparse import unparse

    class CodeTransformer(BaseNodeTransformer):
        def __init__(self, code):
            self.code = code

        def transform(self):
            root = ast.parse(self.code)
            StarredUnpackingTransformer().visit(root)
            return to_source(root)


# Generated at 2022-06-21 18:04:32.666990
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_code = """
print(1, *[2, 3])
    """
    expected_code = """
print(*(list([1]) + list([2, 3])))
    """
    assert expected_code == StarredUnpackingTransformer().visit(ast.parse(input_code))


# Generated at 2022-06-21 18:04:37.908545
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from typed_ast.ast3 import parse
    
    t= parse("""a(*b, *c, d, x)""").body[0]
    t= StarredUnpackingTransformer().visit(t)
    assert round_trip(t) == "a(*(b + list(c) + [d] + [x]))"



# Generated at 2022-06-21 18:04:46.536519
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    lst = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range')), ast.Num(n=1)])
    expected = ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='range')], keywords=[]), ast.Num(n=1)])
    assert StarredUnpackingTransformer().visit(lst) == expected


# Generated at 2022-06-21 18:04:50.096095
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    src = 'list([1, 2, 3, *range(4), 5])'

    module = ast.parse(src)
    StarredUnpackingTransformer().visit(module)
    code = compile(module, '<string>', mode='exec')
    print(code)
    exec(code)

# Generated at 2022-06-21 18:04:55.856954
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    transformer = StarredUnpackingTransformer()

    module = ast.parse("[1, 2, *range(1), 10, *range(10), 1, 2 ,*range(2)]")
    module = transformer.visit(module)
    expected = "[1, 2] + list(range(1)) + [10] + list(range(10)) + [1, 2] + list(range(2))"
    assert unparse(module.body[0]).strip() == expected



# Generated at 2022-06-21 18:05:26.836088
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    with set_config(StarredUnpackingTransformer):
        tree = ast.parse("f(*a, b, c, d, *j, l)")
        StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 18:05:35.420491
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_converter import convert_from_str, convert_from_ast
    from .ast_walker import ASTWalker

    src = 'print(*range(1), *range(3))'
    converter = convert_from_str
    walker = ASTWalker(StarredUnpackingTransformer)
    exp_src = 'print(*(list(range(1)) + list(range(3))))'
    exp_ast = convert_from_str(exp_src)

    res_ast = walker.walk(converter(src))
    res_src = convert_from_ast(res_ast)

    assert res_src == exp_src
    assert res_ast == exp_ast


# Generated at 2022-06-21 18:05:37.016537
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x is not None


# Generated at 2022-06-21 18:05:47.860494
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node0 = ast.Call(func=ast.Name(id='print'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)])], keywords=[])
    node1 = ast.Call(func=ast.Name(id='print'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)])], keywords=[])
    node2 = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)])], keywords=[]))], keywords=[])
    assert node0 == node1
    node0 = StarredUnpackingTransformer().visit

# Generated at 2022-06-21 18:06:00.267246
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
        return [2, *range(10), 1]
    '''
    expected = '''
        return [2] + list(range(10)) + [1]
    '''
    print(expected)
    actual, _ = compile_text(source, '<test>', 'exec')
    assert actual == expected

    source = '''
        return [2, *range(10), 3, *range(20)]
    '''
    expected = '''
        return [2] + list(range(10)) + [3] + list(range(20))
    '''
    print(expected)
    actual, _ = compile_text(source, '<test>', 'exec')
    assert actual == expected


# Generated at 2022-06-21 18:06:12.544349
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)
    assert StarredUnpackingTransformer(None)._has_starred([ast.List(elts=[])]) == False
    assert StarredUnpackingTransformer(None)._has_starred([ast.Starred(value=ast.List(elts=[]))]) == True
    assert StarredUnpackingTransformer(None)._split_by_starred(
        [ast.List(elts=[]), ast.Starred(value=ast.List(elts=[]))]) == [[ast.List(elts=[])], ast.Starred(value=ast.List(elts=[])), []]

# Generated at 2022-06-21 18:06:23.889491
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from .compat import BackportVisitor
    from .base import BaseBackportTransformer

    code = dedent('''
    [2, *range(10)]
    ''')

    tree = ast.parse(code)
    node_transformer = StarredUnpackingTransformer()
    BackportVisitor().visit(tree)
    # Tree already changed in test, but it will not affect behaviour of
    # node_transformer.visit(tree)
    node_transformer.visit(tree)

    output = BackportVisitor().visit(tree)
    assert dedent('''
    [2] + list(range(10))
    ''').strip() == output.strip()




# Generated at 2022-06-21 18:06:26.786958
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    _transformer = StarredUnpackingTransformer(3, 4)
    _node = ast.parse("print(*range(1), *range(3))").body[0]
    print(ast.dump(_transformer.visit(_node)))


# Generated at 2022-06-21 18:06:39.155072
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .demo import StarredUnpackingTransformer
    from typed_ast import ast3 as ast
    from .testutils import assert_equal_asts

    code1 = "print(1, *range(10), 100)"
    code2 = "print(*range(1), *range(5), *range(10))"
    tree1 = ast.parse(code1)
    tree2 = ast.parse(code2)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree1)
    transformer.visit(tree2)
    expected1 = "print(*(list([1]) + list(range(10)) + list([100])))"
    expected2 = "print(*(list(range(1)) + list(range(5)) + list(range(10))))"

# Generated at 2022-06-21 18:06:48.613917
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    expected = ast.List(elts=[ast.Num(1), ast.Num(2), ast.Num(3)], ctx=ast.Load())
    x = ast.Call(func=ast.Name(id="list", ctx=ast.Load()), 
                 args=[ast.Starred(value=ast.Num(2), ctx=ast.Load())], 
                 keywords=[])
    actual = ast.List(elts=[ast.Num(1), x, ast.Num(3)], ctx=ast.Load())
    assert StarredUnpackingTransformer().visit(actual) == expected
