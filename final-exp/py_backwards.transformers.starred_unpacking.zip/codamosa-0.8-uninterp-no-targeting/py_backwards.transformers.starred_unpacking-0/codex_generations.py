

# Generated at 2022-06-21 17:57:15.075664
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import to_source
    node = ast.parse("[1, *range(10), 3]")
    StarredUnpackingTransformer(node).visit(node)
    assert to_source(node) == "[1] + [3, 1, 2, 3, 4, 5, 6, 7, 8, 9] + [3]"


# Generated at 2022-06-21 17:57:26.722693
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed

    # As repr(tree) is too large, check it as ast
    assert ast.dump(tree) == 'Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))])'


# Generated at 2022-06-21 17:57:35.901546
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''
fn(1, 2, 3, 4, 5,
   6, 7, 8, 9, 10,
   *range(11), 11, 12, 13,
   *range(14), 14, 15,
   16, 17, 18)
''').body[0].value

    updated = StarredUnpackingTransformer().visit(node)

    expected = ast.parse('''
fn(*((1, 2, 3, 4, 5,
      6, 7, 8, 9, 10)
      + list(range(11))
      + (11, 12, 13)
      + list(range(14))
      + (14, 15)
      + (16, 17, 18)))
''').body[0].value

    print(ast.dump(expected))
    assert ast.dump(updated)

# Generated at 2022-06-21 17:57:41.439531
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '''
    [2, *range(10), 1]
    '''
    expected_code = '''
    [2] + list(range(10)) + [1]
    '''
    from .common import compare_ast
    from _ast import parse
    StarredUnpackingTransformer(parse(code)).visit(parse(code))
    compare_ast(parse(expected_code), parse(code))


# Generated at 2022-06-21 17:57:51.814329
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 17:57:57.991348
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    code = "factorial(n, *inputs)"

    old_tree = ast.parse(code)
    new_tree = StarredUnpackingTransformer(debug=False).visit(old_tree)
    new_code = astunparse.unparse(new_tree)
    assert new_code == 'factorial(*(n + list(inputs)))'


# Generated at 2022-06-21 17:58:09.486766
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .testutils import round_trip, round_trip_on_single_expr
    

# Generated at 2022-06-21 17:58:14.670315
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.dump(StarredUnpackingTransformer().visit(ast.parse("print(*range(1), *range(3))").body[0])) == \
           ast.dump(ast.parse("print(*(list(range(1)) + list(range(3))))").body[0])



# Generated at 2022-06-21 17:58:18.939600
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    from .sample_asts import TARGET_CALL_WITH_STARRED

    sut = StarredUnpackingTransformer()
    assert astunparse.unparse(sut.visit(TARGET_CALL_WITH_STARRED)) == 'print(*(list(range(1)) + list(range(2)) + list(range(3))))'


# Generated at 2022-06-21 17:58:29.486725
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='print'), args=[
        ast.Starred(value=ast.Name(id='r1'), ctx=ast.Load()),
        ast.Starred(value=ast.Name(id='r2'), ctx=ast.Load())
    ], keywords=[])

# Generated at 2022-06-21 17:58:34.064810
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:41.991633
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from .transformer import TransformerSuite

    suite = TransformerSuite()
    suite.register_transformer(StarredUnpackingTransformer)
    source = '[2, *range(10), 1]'
    root = compile_source(source, mode='exec', transformer=suite)
    assert isinstance(root, ast.Module)
    assert len(root.body) == 1
    assert isinstance(root.body[0], ast.Expr)
    assert isinstance(root.body[0].value, ast.BinOp)
    assert isinstance(root.body[0].value.left, ast.List)
    assert len(root.body[0].value.left.elts) == 1
    assert root.body[0].value.left.elts[0].n == 2
   

# Generated at 2022-06-21 17:58:48.197422
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_code = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    expected_code = """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """
    assert_result_code(StarredUnpackingTransformer, input_code, expected_code)

# Generated at 2022-06-21 17:58:54.957001
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Normal call
    assert ast.dump(
        ast.parse(
            "f()"
        ).body[0]
    ) == ast.dump(
        StarredUnpackingTransformer().visit(ast.parse(
            "f()"
        ).body[0])
    )

    # Call with args
    assert ast.dump(
        ast.parse(
            "f(1, 2)"
        ).body[0]
    ) == ast.dump(
        StarredUnpackingTransformer().visit(ast.parse(
            "f(1, 2)"
        ).body[0])
    )

    # Call with args and kwargs

# Generated at 2022-06-21 17:58:57.364372
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from mypy_extensions import TypedDict

    # TODO: implement.
    pass


# Generated at 2022-06-21 17:59:09.225052
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('Start test for method visit_Call of class StarredUnpackingTransformer')
    print('Testing with "print(*range(1), *range(3))"...')
    call_node = ast.parse('print(*range(1), *range(3))').body[0].value

    StarredUnpackingTransformer().visit(call_node)

# Generated at 2022-06-21 17:59:17.104626
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = "myList = [2, *range(10), 1]\n" \
           "print(*range(1), *range(3))\n"
    expected = "myList = [2] + list(range(10)) + [1]\n" \
               "print(*(list(range(1)) + list(range(3))))\n"
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    actual = ast.unparse(node)
    assert actual == expected

# Generated at 2022-06-21 17:59:29.976430
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # simple calls
    assert ast.dump(StarredUnpackingTransformer().visit(ast.parse('print(1)'))) == 'Module(body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[List(elts=[Num(n=1)])], keywords=[]))])'
    assert ast.dump(StarredUnpackingTransformer().visit(ast.parse('print()'))) == 'Module(body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[], keywords=[]))])'

    # call with kwargs

# Generated at 2022-06-21 17:59:37.818404
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import compile_to_ast, dump_ast
    from .base import TEST_CASE as T

    code = """
        print(*range(10), *range(3))
        print(*range(10))
        print(*range(3))
    """

    expected_ast = compile_to_ast(
        textwrap.dedent("""
        print(*(list(range(10)) + list(range(3))))
        print(*(list(range(10))))
        print(*(list(range(3))))
        """))

    T.assertEqual(dump_ast(expected_ast), dump_ast(StarredUnpackingTransformer().visit(compile_to_ast(code))))

# Generated at 2022-06-21 17:59:47.178549
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert hasattr(
        StarredUnpackingTransformer,
        'visit_Call')
    assert hasattr(
        StarredUnpackingTransformer,
        'visit_List')
    assert hasattr(
        StarredUnpackingTransformer,
        '_split_by_starred')
    assert hasattr(
        StarredUnpackingTransformer,
        '_prepare_lists')
    assert hasattr(
        StarredUnpackingTransformer,
        '_merge_lists')
    assert hasattr(
        StarredUnpackingTransformer,
        '_to_sum_of_lists')
    obj_1 = StarredUnpackingTransformer()
    obj_2 = StarredUnpackingTransformer()

    assert obj_1._split_by_starred([]) == []
    assert obj_2._split_by

# Generated at 2022-06-21 17:59:55.723657
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert tree.body[0].value.right.right.func.id == 'list'


# Generated at 2022-06-21 18:00:02.778186
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor

    tree = ast.parse('print(1, *range(2), 3)')
    expected = ast.parse('print(*[1] + list(range(2)) + [3])')

    StarredUnpackingTransformer().transform(tree)
    assert astor.to_source(tree) == astor.to_source(expected)



# Generated at 2022-06-21 18:00:10.731863
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .fixtures import StarredUnpackingTransformer
    from .test_transformer import _test_transform_node

    _test_transform_node(
        StarredUnpackingTransformer,
        "[*range(10)]",
        "[] + list(range(10))"
    )

    _test_transform_node(
        StarredUnpackingTransformer,
        "[*range(10), *range(100)]",
        "[] + list(range(10)) + list(range(100))"
    )

    _test_transform_node(
        StarredUnpackingTransformer,
        "[1, *range(10), 2]",
        "[1] + list(range(10)) + [2]"
    )


# Generated at 2022-06-21 18:00:17.049288
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .literals import LiteralsTransformer
    from astunparse import unparse
    s = 'print(*range(1), *range(3))'
    conv = LiteralsTransformer()
    conv.visit(ast.parse(s))
    print(conv._tree_changed)

    conv = StarredUnpackingTransformer()
    conv.visit(conv.visit(ast.parse(s)))
    print(conv._tree_changed)

# Generated at 2022-06-21 18:00:24.415170
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    input = 'print(1, *range(3), 2, *range(5), 3)'
    expected = 'print(*(list(range(1)) + list(range(3)) + list([2]) + list(range(5)) + list([3])))'

    # When
    actual = StarredUnpackingTransformer().visit(ast.parse(input))

    # Then
    assert astor.to_source(actual) == expected


# Generated at 2022-06-21 18:00:27.740165
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]").body[0].value
    expected = "[2] + list(range(10)) + [1]"
    assert expected == ast.dump(StarredUnpackingTransformer().visit(node))



# Generated at 2022-06-21 18:00:37.092237
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Tests for method visit_List of class StarredUnpackingTransformer."""

    # Create a tree before the transformation.
    tree = ast.parse("[2, *range(10), 1]")

    # Create a tree after the transformation.
    tree_transformed = ast.parse("[2] + list(range(10)) + [1]")

    # Create an instance of class StarredUnpackingTransformer.
    xformer = StarredUnpackingTransformer()
    xformer.visit(tree)
    assert ast.dump(tree) == ast.dump(tree_transformed), 'Programming error.'



# Generated at 2022-06-21 18:00:43.579883
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """\
        [2, *range(10), 1]
        print(*range(1), *range(3))
        """
    assert StarredUnpackingTransformer().transform(code) == """\
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        """

# Generated at 2022-06-21 18:00:45.865724
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    assert trans is not None

# Generated at 2022-06-21 18:00:49.495381
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("testing StarredUnpackingTransformer()")
    t = StarredUnpackingTransformer()
    t.transform(ast.parse("a = [1, *range(3), 5], print(*range(3), *range(3))"))
    print("t.output", t.output)

# Generated at 2022-06-21 18:01:05.709697
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer"""
    target_ast_str = '''
        [2, *range(10), 1]
        '''
    actual_ast_str = StarredUnpackingTransformer().visit(ast.parse(target_ast_str))
    expected_ast_str = '''
        [2] + list(range(10)) + [1]
        '''

    assert ast.dump(actual_ast_str) == ast.dump(ast.parse(expected_ast_str))


# Generated at 2022-06-21 18:01:08.092274
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    c = "print(*range(1), *range(3))"
    StarredUnpackingTransformer().transform_source(c)

# Generated at 2022-06-21 18:01:18.959159
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    lst = ast.parse("[1, 2, *range(3), *range(4), 5]").body[0]
    res = t.visit(lst)
    assert isinstance(res, ast.Call)
    assert isinstance(res.func, ast.Name)
    assert res.func.id == 'list'
    assert isinstance(res.args[0], ast.BinOp)
    assert isinstance(res.args[0].left, ast.BinOp)
    assert isinstance(res.args[0].left.left, ast.BinOp)
    assert isinstance(res.args[0].left.left.left, ast.List)
    assert isinstance(res.args[0].left.left.left.elts, list)

# Generated at 2022-06-21 18:01:27.122896
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:01:33.597667
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
  #print(arg)
  prog = ast.parse("print(arg)")
  tree_before = prog.body[0]

  transformer = StarredUnpackingTransformer()
  tree_after = transformer.visit(tree_before)

  assert transformer.tree_changed()
  assert ast.dump(tree_after) == "Print(dest=None, values=[Starred(value=Name(id='arg', ctx=Load()), ctx=Load())], nl=True)"

# Generated at 2022-06-21 18:01:42.070391
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = """
    print("a" + "b")
    """

    expected = """
    print("a" + "b")
    """

    t = StarredUnpackingTransformer()
    new_tree = ast.parse(src)
    t.visit(new_tree)
    assert safe_dump(ast.fix_missing_locations(new_tree)) == expected

    src = """
    print("a", "b")
    """

    expected = """
    print(*("a", "b"))
    """

    t = StarredUnpackingTransformer()
    new_tree = ast.parse(src)
    t.visit(new_tree)
    assert safe_dump(ast.fix_missing_locations(new_tree)) == expected


# Generated at 2022-06-21 18:01:49.746602
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('''
    [2, *range(5), 10]
    ''').body[0]

    assert isinstance(node, ast.Expr)

    # Check transformation
    assert isinstance(node.value, ast.List)
    assert len(node.value.elts) == 3

    # Check result
    assert isinstance(StarredUnpackingTransformer().visit(node.value), ast.BinOp)

# Generated at 2022-06-21 18:02:01.841359
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import TransformerTestCase, Source
    assert_source = TransformerTestCase(StarredUnpackingTransformer)
    test1 = Source('''
        [1]
    ''')
    assert_source.test(test1, test1)
    test2 = Source('''
        [1, 2]
    ''')
    assert_source.test(test2, test2)
    test3 = Source('''
        [*range(10)]
    ''')
    result3 = Source('''
        list(range(10))
    ''')
    assert_source.test(test3, result3)
    test4 = Source('''
        [1, *range(10)]
    ''')

# Generated at 2022-06-21 18:02:10.938464
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from textwrap import dedent
    from .tools import normalize
    from typed_astunparse import unparse
    from .ct import CT  # noqa

    source = dedent('''
        print(*range(1), *range(3))
    ''')
    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    expected = dedent('''
        print(*(list(range(1)) + list(range(3))))
    ''')
    actual = unparse(node)

    assert normalize(expected) == normalize(actual)



# Generated at 2022-06-21 18:02:22.115586
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import roundtrip_unparse
    from ..unparser import Unparser

    def test_case(code: str, expected: str) -> str:
        tree = ast.parse(code)
        StarredUnpackingTransformer().visit(tree)
        assert roundtrip_unparse(tree) == expected
        return Unparser(tree).print_tree()

    test_case(
        '[2, *range(10), 1]',
        '[2, *list(range(10)), 1]')

    test_case(
        '[2, *range(10), *range(10), 1]',
        '[2, *(list(range(10)) + list(range(10))), 1]')


# Generated at 2022-06-21 18:02:44.581949
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast.ast3 import parse
    ast_tree = parse('print(*range(1), *range(3))')
    transformer = StarredUnpackingTransformer()
    new_ast = transformer.visit(ast_tree)
    assert format(new_ast) == format(ast_tree)

# Generated at 2022-06-21 18:02:50.808275
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    assert transformer.visit(node) == ast.parse(
        "[2] + list(range(10)) + [1]")

# Generated at 2022-06-21 18:03:00.173392
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    import astunparse

    class Example(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.expr:
            self.generic_visit(node)
            if len(node.elts):
                node.elts = [ast.Starred(value=node.elts[0], ctx=ast.Load())]
            return node

        def visit_Call(self, node: ast.Call) -> ast.expr:
            self.generic_visit(node)
            if len(node.args):
                node.args = [ast.Starred(value=node.args[0], ctx=ast.Load())]
            return node


# Generated at 2022-06-21 18:03:01.252280
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:03:03.012243
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert repr(StarredUnpackingTransformer())

# Generated at 2022-06-21 18:03:13.250574
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:14.555261
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test StarredUnpackingTransformer constructor."""
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:03:27.087210
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor

    class Dummy:
        """For type hinting"""
        pass

    dummy = Dummy()

    dummy.StarredUnpackingTransformer = StarredUnpackingTransformer
    dummy.test_code = ["[2, *range(10), 1]", "print(*range(1), *range(3))"]
    dummy.expected_result = "[2] + list(range(10)) + [1]\nprint(*(list(range(1)) + list(range(3))))"

    dummy.transformer = dummy.StarredUnpackingTransformer()
    dummy.transformed_code = []

    for code in dummy.test_code:
        dummy.node = ast.parse(code)
        dummy.transformed_code.append(dummy.transformer.visit(dummy.node))

    dummy.transformed

# Generated at 2022-06-21 18:03:34.843378
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse

    # 1. [2, *range(10), 1]
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    expected = ast.parse("[2] + list(range(10)) + [1]")
    result = StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(result) == astunparse.unparse(expected)



# Generated at 2022-06-21 18:03:42.102807
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # given
    code = "[2, 5, *range(10)]"

    # when
    node = ast.parse(code)
    node = StarredUnpackingTransformer().visit(node)
    code_after = compile(node, '<test>', 'exec')

    # then
    globals = {}
    exec(code_after, globals)
    result = globals['_']
    assert result == [2, 5] + list(range(10))



# Generated at 2022-06-21 18:04:30.664864
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .tr import parse
    from .repr import dump_ast
    from .to_source import compile_ast

    node = parse("[1, *a, 2]")
    new_node = StarredUnpackingTransformer().visit(node)
    assert dump_ast(new_node) == \
        "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=1)]), right=Call(func=Name(id='list', ctx=Load()), args=[Name(id='a', ctx=Load())], keywords=[], starargs=None, kwargs=None), op=Add()), right=List(elts=[Num(n=2)]), op=Add()))])"

# Generated at 2022-06-21 18:04:34.610179
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    trans = StarredUnpackingTransformer()
    print(trans.visit(ast.parse("[2, *range(3), 1]")))


# Generated at 2022-06-21 18:04:41.944658
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    trans = StarredUnpackingTransformer()
    node = ast.List(
        elts=[
            ast.Constant(value=2),
            ast.Starred(value=ast.Call(
                func=ast.Name(id="range"), args=[ast.Constant(value=10), ],
                keywords=[])),
            ast.Constant(value=1),
        ])
    result = ast.BinOp(
        left=node,
        right=ast.Call(
            func=ast.Name(id="list"),
            args=[ast.Call(
                func=ast.Name(id="range"),
                args=[ast.Constant(value=10), ], keywords=[])]),
        op=ast.Add())
    assert trans.visit(node) == result


# Generated at 2022-06-21 18:04:43.167362
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    c = StarredUnpackingTransformer()
    assert c

# Generated at 2022-06-21 18:04:52.161640
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # Given
    module = ast.parse('print(*range(1), *range(3))')
    node = module.body[0]
    assert isinstance(node, ast.Expr) and isinstance(node.value, ast.Call), \
        "print(*range(1), *range(3))"

    # When
    xformer = StarredUnpackingTransformer()
    result = xformer.visit(node.value)

    # Then
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    assert isinstance(expected.body[0], ast.Expr) and isinstance(expected.body[0].value, ast.Call), \
        "print(*(list(range(1)) + list(range(3))))"
    assert result == expected.body[0].value

# Generated at 2022-06-21 18:04:54.599777
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.transform(
        'lista = [2, *range(10), 1]') == 'lista = [2] + list(range(10)) + [1]'



# Generated at 2022-06-21 18:04:59.389485
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    actual = StarredUnpackingTransformer().visit(ast.parse('print(*range(1), *range(3))'))
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-21 18:05:01.666337
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:05:13.124535
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(code):
        expected_code = code.replace('*', '').replace('(', '').replace(')', '').replace(' ', '')
        print('Expected code:', expected_code)
        ft = compile(code, filename="<string>", mode="eval")
        ft_code = dis.dis(ft).replace('\n', '')
        print('Python code:', ft_code)
        ft_mod = ast.parse(code)
        print('AST code:', ft_mod)
        succ = StarredUnpackingTransformer().visit(ft_mod)
        if succ:
            tco = compile(ft_mod, filename="<string>", mode="eval")
            tco_code = dis.dis(tco).replace('\n', '')

# Generated at 2022-06-21 18:05:19.133010
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_ = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast_)
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 18:07:07.038679
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    x = ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())])
    print(x)