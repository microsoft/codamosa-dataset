

# Generated at 2022-06-21 17:57:16.438009
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = ast.parse("[2, *range(10), 1]").body[0]
    transformer = StarredUnpackingTransformer()
    transformer.visit_List(a)
    expected = ast.parse("[2] + list(range(10)) + [1]").body[0]
    assert ast.dump(a) == ast.dump(expected)


# Generated at 2022-06-21 17:57:24.100800
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    # Input
    original_tree = ast.parse('''
        [2, *range(10), 1]
    ''')
    # Expected output
    expected_tree = ast.parse('''
        ([2] + list(range(10)) + [1])
    ''')

    transformer.visit(original_tree)
    assert ast.dump(original_tree) == ast.dump(expected_tree)



# Generated at 2022-06-21 17:57:30.988745
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformerTest
    from qcore import script
    import astor

    source = BaseNodeTransformerTest.apply_transformers(
        script,
        StarredUnpackingTransformer,
    )

    print(astor.to_source(source))

    # Can't run test on all Python versions, because of problems with astor
    # and typing.
    #assert source == script

# Generated at 2022-06-21 17:57:41.171912
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    node = ast.parse(code)
    ast.fix_missing_locations(node)
    new_node = StarredUnpackingTransformer().visit(node)
    compiled = compile(new_node, '<test>', 'exec')
    globals_dict, locals_dict = {}, {}
    exec(compiled, globals_dict, locals_dict)
    assert len(locals_dict) == 0
    assert len(globals_dict) == 1
    assert 'output' in globals_dict
    assert globals_dict['output'] == expected
test_Starred

# Generated at 2022-06-21 17:57:47.722096
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    expected_source = '[2] + list(range(10)) + [1]'

    source_ast = ast.parse(source)
    expected_ast = ast.parse(expected_source)
    result_ast = StarredUnpackingTransformer().visit(source_ast)
    assert ast.dump(expected_ast) == ast.dump(result_ast)


# Generated at 2022-06-21 17:57:54.941442
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    raw = """
[2, *range(10), 1]
"""
    compiled = """
[2] + list(range(10)) + [1]
"""
    t = StarredUnpackingTransformer()
    t.visit(ast.parse(raw))
    assert compile(t.root, '<ast>', 'exec') == compile(compiled, '<ast>', 'exec')


# Generated at 2022-06-21 17:58:04.383461
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=0)],
                    keywords=[])),
            ast.Num(n=1)
        ],
        ctx=ast.Load())

    n = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-21 17:58:17.211142
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from . import FakeTree
    arg1 = ast3.Name(id='a', ctx=ast3.Load())
    arg2 = ast3.Name(id='b', ctx=ast3.Load())
    arg3 = ast3.Name(id='c', ctx=ast3.Load())
    arg4 = ast3.Name(id='d', ctx=ast3.Load())
    arg5 = ast3.Name(id='e', ctx=ast3.Load())
    arg6 = ast3.Name(id='f', ctx=ast3.Load())
    arg7 = ast3.Starred(value=ast3.Name(id='a', ctx=ast3.Load()), ctx=ast3.Load())

# Generated at 2022-06-21 17:58:28.944956
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('foo(*list(range(3)), 2, a, *list(range(3)), *list(range(2)))')
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:58:38.724305
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse as stringify
    from .visitor import TypedAstVisitor
    from .uncompyle_module import UncompyleModule

    module = UncompyleModule()
    src = '[2, *range(10), 1]'

    with module.builtins('range'):
        code = compile(src, '<>', 'eval')
        tree = ast.parse(code)
        TypedAstVisitor(print).visit(tree)
        StarredUnpackingTransformer().visit(tree)
        print(stringify(tree))



# Generated at 2022-06-21 17:58:50.212743
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:55.684205
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = StarredUnpackingTransformer()
    assert s.visit(ast.parse("[1, *range(10), *[1, 2]]", mode='eval')) == \
        ast.parse("1 + list(range(10)) + [1, 2]", mode='eval')



# Generated at 2022-06-21 17:59:07.295848
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import astor
    from typed_ast import ast3 as ast

    test_1 = ast.parse("[2, *range(10), 1]")

    expected1 = '[2] + list(range(10)) + [1]'
    expected2 = '[2] + list(range(10)) + [1]'

    test_1 = StarredUnpackingTransformer().visit(test_1)
    actual = astor.to_source(test_1)
    assert actual == expected1

    test_2 = ast.parse("print(*range(1), *range(3))")

    test_2 = StarredUnpackingTransformer().visit(test_2)
    actual = astor.to_source(test_2)
    assert actual == expected2

# Generated at 2022-06-21 17:59:14.543555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == 'List(elts=[Num(n=2), List(elts=[Call(func=Name(id="range", ctx=Load()), args=[Num(n=10)], keywords=[])]), Num(n=1)], ctx=Load())'


# Generated at 2022-06-21 17:59:19.633650
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("print(1, *range(3), 4, *range(4))")
    actual = transformer.visit(node)
    expected = ast.parse("print(*(list([1]) + list(range(3)) + list([4]) + list(range(4))))")
    assert ast.dump(expected) == ast.dump(actual)
    assert transformer.tree_changed


# Generated at 2022-06-21 17:59:30.280453
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .common import as_lines
    from .to_function_call import FunctionCallTransformer

    code = as_lines('''
        [2, *range(10), 1]
    ''')

    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    tree = FunctionCallTransformer().visit(tree)
    expected_code = as_lines([
        'def list(range_10,):',
        '    return (2, ) + range_10 + (1, )'
    ])
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))



# Generated at 2022-06-21 17:59:38.705666
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import parse
    from .variable_unpacking import VariableUnpackingTransformer

    unpacking = VariableUnpackingTransformer()
    unpacked_tree = unpacking.visit(parse('a, *b = range(10)'))

    result_init = unpacking.generic_visit(
        StarredUnpackingTransformer().visit(parse('[2, *range(10), 1]')))

    assert unpacking.generic_visit(
        StarredUnpackingTransformer().visit(parse('print(*range(1), *range(3))'))) == \
        parse('print(*(list(range(1)) + list(range(3))))')


# Generated at 2022-06-21 17:59:41.149554
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    string = "[2, *range(10), 1]"
    tree = astor.parse_file(string)
    StarredUnpackingTransformer.run_on_node(tree)
    print(astor.to_source(tree))



# Generated at 2022-06-21 17:59:42.202042
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:52.926814
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_dict = ast.parse("print(*range(2, 3), *range(1))").body[0].__dict__
    node_dict["args"] = ast.parse("(*range(2, 3), *range(1))", mode = "eval").body.__dict__
    node = ast.Call(**node_dict)
    trans = StarredUnpackingTransformer()
    actual = trans.visit(node)
    expected = ast.parse("print(*([2] + list(range(3)) + list(range(1))))").body[0]
    assert str(actual) == str(expected)

# Generated at 2022-06-21 18:00:04.468574
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # given
    code = "print(*range(1), *range(3))\n"

    # when
    refactored_code = StarredUnpackingTransformer().refactor(code)

    # then
    assert refactored_code == "print(*((range(1)) + (range(3))))\n"

# Generated at 2022-06-21 18:00:11.635981
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    from .base import BaseNodeTransformer

    def make_test_ast(code: str) -> Union[ast.AST, None]:
        a = ast.parse(code)
        t = StarredUnpackingTransformer()
        t.visit(a)
        assert t._tree_changed
        return a

    assert astor.to_source(make_test_ast('[2, *range(10), 1]')) == '[2] + list(range(10)) + [1]'
    assert astor.to_source(make_test_ast('print(*range(1))')) == 'print(*(list(range(1))))'

# Generated at 2022-06-21 18:00:13.710684
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """\
if True:
    print(*range(10))
"""
    expected = """\
if True:
    print(*(list(range(10))))
"""
    assert StarredUnpackingTransformer().visit(ast.parse(code)) == ast.parse(expected)

# Generated at 2022-06-21 18:00:23.811603
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]")
    assert isinstance(node, ast.Module)
    node = node.body[0]  # type: ast.Expr
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.List)
    assert len(node.elts) == 3
    assert any([isinstance(x, ast.Starred) for x in node.elts])

    transformer = StarredUnpackingTransformer()
    assert transformer.visit(node) is None  # caused no side effects.
    assert transformer.tree_has_changed
    assert isinstance(node, ast.BinOp)
    assert isinstance(node.left, ast.List)
    assert isinstance(node.right, ast.List)




# Generated at 2022-06-21 18:00:28.106945
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test `StarredUnpackingTransformer.visit_List` method.

    :return: None
    """
    transformer = StarredUnpackingTransformer()
    root = ast.parse("[2, *range(10), 1]")

    assert transformer.visit(root) == ast.parse("[2] + list(range(10)) + [1]")


# Generated at 2022-06-21 18:00:39.993793
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse
    from . import test_utils

    code = """
        print(1, *range(1), *range(2), 3)
        print(1, *range(1))
        print(*range(1), 2, 3)
        print(*range(1))
    """

    xform = StarredUnpackingTransformer()
    tree = test_utils.parse(code)

    xform.visit(tree)

    expected = """
        print(*(1 + list(range(1)) + list(range(2)) + 3))
        print(1, *(list(range(1))))
        print(*(list(range(1)) + 2 + 3))
        print(*(list(range(1))))
    """

    assert unparse(tree) == test_utils.dedent(expected)

# Generated at 2022-06-21 18:00:48.374407
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    xs = [
        ast.List(elts=[
            ast.Num(n=1),
            ast.Starred(value=ast.Name(id='a')),
            ast.Num(n=2)
        ], ctx=ast.Load()),
        ast.List(elts=[
            ast.Num(n=1),
            ast.Str(s='abc'),
            ast.Num(n=2)
        ], ctx=ast.Load())
    ]

# Generated at 2022-06-21 18:00:57.210521
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    suc = StarredUnpackingTransformer()

    test_args = [ast.Starred(value=ast.Name(id='a')),
                 ast.Num(n=1),
                 ast.Starred(value=ast.Name(id='c'))]
    test_res = suc._to_sum_of_lists(test_args)

    assert isinstance(test_res, ast.BinOp)
    assert isinstance(test_res.left, ast.Call)
    assert isinstance(test_args[0].value, ast.Name)
    assert isinstance(test_res.right, ast.List)
    assert isinstance(test_res.right.elts[0], ast.Num)
    assert isinstance(test_res.right.elts[1], ast.Starred)

# Generated at 2022-06-21 18:01:07.086734
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    SUT = StarredUnpackingTransformer()
    call_node = ast.Call(
        func=ast.Name(id="print"),
        args=[
            ast.Starred(value=ast.Name(id="range", ctx=ast.Load())),
            ast.Starred(value=ast.Name(id="range", ctx=ast.Load()))
        ],
        keywords=[
            ast.keyword(arg='end', value=ast.Str(s=''))
        ])

# Generated at 2022-06-21 18:01:18.125731
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    obj = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name(id='a'), args=[ast.Starred(value=ast.List(elts=[ast.Name(id='b'), ast.Num(n=1)]))], keywords=[])
    new_node = obj.visit(node)
    assert new_node == ast.Call(func=ast.Name(id='a'), args=[ast.Starred(value=ast.BinOp(left=ast.Call(func=ast.Name(id='list'), args=[ast.List(elts=[ast.Name(id='b'), ast.Num(n=1)])], keywords=[]), right=ast.List(elts=[]), op=ast.Add()))], keywords=[])

# Generated at 2022-06-21 18:01:37.303834
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse(
        "def f(x: int, y: str = 'hello') -> str: print(x, y)").body[0]
    expected = ast.parse(
        "def f(x: int, y: str = 'hello') -> str: print(*(x, y))").body[0]

    assert expected == StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-21 18:01:43.783398
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test method visit_Call of class StarredUnpackingTransformer."""
    class_to_test = StarredUnpackingTransformer

    code = 'print(*range(1), *range(2))'
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)


# Generated at 2022-06-21 18:01:51.060595
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Create input
    t = ast.parse('[2, *range(10), 1]')
    t = t.body[0]
    # Create StarredUnpackingTransformer object
    tree_transformer = StarredUnpackingTransformer()
    # Test method visit_List
    transformed = tree_transformer.visit(t)
    # Confirm transformed result
    assert str(transformed) == ast.dump(ast.parse('[2] + list(range(10)) + [1]'))



# Generated at 2022-06-21 18:02:03.148220
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    print("Before:", ast.dump(tree))
    transformer = StarredUnpackingTransformer()
    node = transformer.visit(tree)

    print("After:", ast.dump(node))
    # Output:
    # Before: Module(
    #   body=[
    #     Expr(
    #       value=Call(
    #         func=Name(id='print', ctx=Load()),
    #         args=[Starred(value=Name(id='range', ctx=Load()), ctx=Load()), Starred(value=Name(id='range', ctx=Load()), ctx=Load())],
    #         keywords=[]))])
    # After: Module(
    #   body=[
    #     Expr(

# Generated at 2022-06-21 18:02:05.990953
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test case for constructor of class StarredUnpackingTransformer"""
    transformer = StarredUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-21 18:02:11.249263
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)
    assert isinstance(StarredUnpackingTransformer(), ast.NodeTransformer)
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)
    # StarredUnpackingTransformer() is an object of class StarredUnpackingTransformer


# Generated at 2022-06-21 18:02:22.449288
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def _transform(s: str) -> ast.AST:
        return StarredUnpackingTransformer().visit(ast.parse(s))

    assert _transform('print(1, *range(3))').body[0].value.args[0].value.elts[0].n == 1
    assert _transform('print(1, *range(3))').body[0].value.args[0].value.elts[1].func.id == 'list'

    assert _transform('[1, *range(3), *range(5)]').body[0].value.left.elts[0].n == 1
    assert _transform('[1, *range(3), *range(5)]').body[0].value.left.elts[1].func.id == 'list'

# Generated at 2022-06-21 18:02:31.186077
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer([
        ast.List(elts=[ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()),
                      ast.Starred(value=ast.Name(id='b'), ctx=ast.Load())],
                 ctx=ast.Load()),
    ]) == [
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='a')],
            keywords=[]
        ),
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='b')],
            keywords=[]
        )
    ]


# Generated at 2022-06-21 18:02:43.714326
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call1 = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=1)],
                    keywords=[],
                ),
                ctx=ast.Load(),
            ),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=3)],
                    keywords=[],
                ),
                ctx=ast.Load(),
            ),
        ],
        keywords=[])


# Generated at 2022-06-21 18:02:51.944146
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10)]"
    expected = "[2] + list(range(10))"

    tree = ast.parse(textwrap.dedent(source))
    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(tree)
    assert expected == astor.to_source(tree)


# Generated at 2022-06-21 18:03:31.124211
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import compile_source
    from .cmp import compare_source


# Generated at 2022-06-21 18:03:43.746513
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer.target == (3, 4)
    t = StarredUnpackingTransformer()
    assert t._has_starred == t.__class__._has_starred
    assert t._split_by_starred == t.__class__._split_by_starred
    assert t._prepare_lists == t.__class__._prepare_lists
    assert t._merge_lists == t.__class__._merge_lists
    assert t._to_sum_of_lists == t.__class__._to_sum_of_lists
    assert t.visit == t.__class__.visit
    assert t.visit_List == t.__class__.visit_List
    assert t.visit_Call == t.__class__.visit_Call

# Unit tests for

# Generated at 2022-06-21 18:03:50.529818
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    result = transform(StarredUnpackingTransformer, code)
    assert result == '[2] + list(range(10)) + [1]'

    code = '[*range(10)]'
    result = transform(StarredUnpackingTransformer, code)
    assert result == 'list(range(10))'

    code = '[1, 2]'
    result = transform(StarredUnpackingTransformer, code)
    assert result == '[1, 2]'

    code = '[1, 2, 3, *range(10)]'
    result = transform(StarredUnpackingTransformer, code)
    assert result == '[1, 2, 3] + list(range(10))'

    code = '[*range(10), *range(2), 1, 2, 3]'

# Generated at 2022-06-21 18:03:55.936010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from vyper.parser.parser_utils import LLLnode
    from vyper.utils import MemoryPositions
    from ethereum.utils import encode_hex

    from vyper.exceptions import InvalidLiteral
    from vyper.parser.parser import parse_to_lll


# Generated at 2022-06-21 18:04:02.334313
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    trans = StarredUnpackingTransformer()
    tree = ast.parse(
        '['
        '2,'
        '*range(10),'
        '1,'
        '*range(4)]'
    )
    expected = ast.parse(
        '[2] + list(range(10)) + [1] + list(range(4))'
    )
    trans.visit(tree)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-21 18:04:03.627755
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:04:07.768544
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
    [2, *range(10), 1]
    """
    correct_code = """
    [2] + list(range(10)) + [1]
    """
    node = ast.parse(code)  # type: ast.Module
    tr = StarredUnpackingTransformer()
    tr.visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(correct_code))



# Generated at 2022-06-21 18:04:19.299248
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    # print(dump(tree))
    assert dump(tree) == '[2 + list(range(10)) + [1]]'

    tree = ast.parse("[[2], *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    # print(dump(tree))
    assert dump(tree) == '[[2] + list(range(10)) + [1]]'

    tree = ast.parse("[2, *[3, 4, [5, 6]], 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    # print(dump(tree))

# Generated at 2022-06-21 18:04:28.279961
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
[2, *range(10), 1]
    '''
    tree = ast.parse(source)
    expected_tree = '''
Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[
    Num(n=2), 
    Name(id='list', ctx=Load()), 
    Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[]),
    Name(id='list', ctx=Load()),
    List(elts=[Num(n=1)])
], ctx=Load()), op=Add(), right=Name(id='list', ctx=Load())), op=Add(), right=Name(id='list', ctx=Load())))])
    '''
   

# Generated at 2022-06-21 18:04:34.031286
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    test_str = "[2, *range(10), 1]\nprint(*range(1), *range(3))"

    assert transformer.transform(test_str) == '''[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))'''

# Generated at 2022-06-21 18:05:16.831916
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    uo = StarredUnpackingTransformer()
    assert str(uo._to_sum_of_lists([ast.Starred(value=ast.Name(id='a'), ctx=ast.Load())])) == "list(a)"
    assert str(uo._to_sum_of_lists([ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='b'), ctx=ast.Load())])) == "list(a) + list(b)"

# Generated at 2022-06-21 18:05:27.114916
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                   args=[ast.Num(n=10)],
                                   keywords=[])),
        ast.Num(n=1)
    ])
    start = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                       args=[ast.Num(n=1)],
                                       keywords=[])),
            ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                       args=[ast.Num(n=3)],
                                       keywords=[]))
        ],
        keywords=[])

   

# Generated at 2022-06-21 18:05:36.191730
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Set up test-data
    test1_call_node = ast.Call(func=ast.Name(id='print'), args=[ast.Num(n=1), ast.Num(n=2), ast.Name(id='*'), ast.Name(id='args')])
    test1_list_node = ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='args'))])
    test1_expected_call_node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.List(elts=[ast.Num(n=1), ast.List(elts=[ast.Name(id='args')])]))])

# Generated at 2022-06-21 18:05:40.807579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(2, *range(10), 1)'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    assert compile_restricted(source, StarredUnpackingTransformer) == expected


# Generated at 2022-06-21 18:05:49.417757
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse('[] + list(range(3)) + [] + list(range(3)) + []').body[0]
    source = ast.parse('[*range(3), *range(3)]').body[0]

    actual = StarredUnpackingTransformer().visit(source)

    assert ast.dump(expected) == ast.dump(actual)
    assert ast.dump(expected) == ast.dump(StarredUnpackingTransformer().visit(actual))

    # Test empty list
    expected = ast.List(elts=[])
    source = ast.List(elts=[])

    actual = StarredUnpackingTransformer().visit(source)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-21 18:05:51.245749
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test that constructor raises no exception

    StarredUnpackingTransformer()


# Generated at 2022-06-21 18:06:03.584550
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Create instance of class StarredUnpackingTransformer
    star_tran = StarredUnpackingTransformer()
    # Initalize _tree_changed to False
    star_tran._tree_changed = False
    # Declare a test ast
    test1 = """
[2, *range(10), 1]
print(*range(1), *range(3))
    """
    # Expected output
    expected1 = """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """
    # Parse the test ast
    parsed = ast.parse(test1)
    # Modify it
    modified = star_tran.visit(parsed)
    # Compare the output
    assert astor.to_source(modified) == expected1

# Generated at 2022-06-21 18:06:14.046269
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target is (3, 4)
    StarredUnpackingTransformer().visit_List(ast.List(elts=[ast.Num(n=0), ast.Starred(value=ast.Num(n=0))]))
    StarredUnpackingTransformer().visit_Call(ast.Call(func=ast.Name(id='list'), args=[ast.Num(n=0), ast.Starred(value=ast.Num(n=0))], keywords=[]))
    StarredUnpackingTransformer().visit_Call(ast.Call(func=ast.Name(id='set'), args=[ast.Name(id='a'), ast.Starred(value=ast.Num(n=0))], keywords=[]))

# Generated at 2022-06-21 18:06:19.287181
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), *range(3))'
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(ast.parse(source)) == ast.parse(
        'print(*(list(range(1)) + list(range(3))))'
    )

# Generated at 2022-06-21 18:06:24.997373
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Check that class is defined
    transformer = StarredUnpackingTransformer()
    # Check methods of class are defined
    transformer._prepare_lists([])
    transformer._split_by_starred([])
    transformer._merge_lists([])
    transformer._to_sum_of_lists([])
    # Check visit methods of class are defined
    transformer.visit_List(ast.List())
    transformer.visit_Call(ast.Call())