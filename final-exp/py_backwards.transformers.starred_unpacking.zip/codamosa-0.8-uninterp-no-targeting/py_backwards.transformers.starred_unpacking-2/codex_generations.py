

# Generated at 2022-06-21 17:57:13.112660
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor

    t = StarredUnpackingTransformer()
    node = ast.parse('[2, *range(10), 1]')
    node = t.visit(node)
    print(astor.to_source(node))

# Generated at 2022-06-21 17:57:20.258761
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    call = ast.parse('print(*range(1), *range(4))').body[0].value
    expected = 'print(*(list(range(1)) + list(range(4))))'
    result = sut.visit(call).body[0].value

    (result,) = ast.fix_missing_locations(ast.Module(body=[result]))
    assert_equal(expected, astor.to_source(result))


# Generated at 2022-06-21 17:57:21.718012
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-21 17:57:34.108503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    from .test_utils import GenericTestBase

    from . import base

    class Test(GenericTestBase, base.BaseNodeTransformerTest):
        target_class = StarredUnpackingTransformer
        transform_two_asts = False

        def _run_one(self, source: str, target: str) -> None:
            self._test(target, source)

    test = Test()
    test.test_generic_replacement(
        'print(1, 2, *list(range(3)))',
        'print(*list(list([1, 2]) + list(range(3))))',
    )

# Generated at 2022-06-21 17:57:41.453614
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import parse_ast
    from . import to_source

    test_code = """
    a = [2, *range(10), 1]
    """
    expected_code = """
    a = [2] + list(range(10)) + [1]
    """
    transformer = StarredUnpackingTransformer()
    tree = parse_ast(test_code)
    transformer.visit(tree)
    result_code = to_source(tree)
    assert expected_code == result_code, result_code


# Generated at 2022-06-21 17:57:51.814440
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    args = ast.parse('[2, *range(10), 1]').body[0].value.elts
    assert len(args) == 3
    assert isinstance(args[1], ast.Starred)

    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(ast.List(elts=args))

    assert transformer._has_starred(args)
    assert isinstance(new_node, ast.List)

    assert new_node.elts[0] == args[0]

    assert isinstance(new_node.elts[1], ast.Call)
    assert new_node.elts[1].func.id == 'list'
    assert new_node.elts[1].args[0] == args[1].value


# Generated at 2022-06-21 17:58:02.257721
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import sys
    import os
    import ast
    sys.path.append(os.getcwd())
    from ..node_visitor import basic_visitor as visitor
    from ..node_visitor import show_ast
    from ..node_visitor import ast_transformer as transformer
    from ..typed_ast_pprint import pprint
    from ..translate_to_typed import translate as type_translate
    from ..translate_to_typed import ast_typed_remove_type
    from .. import typed_ast_to_python as typed_to_py
    from ..typed_ast_to_python import PythonCodeConverter
    from ..typed_ast_to_python import PythonCodeGenerator
    from ..typed_ast_to_python import PythonCodeFormatter

# Generated at 2022-06-21 17:58:08.682560
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class EmptyStarredUnpackingTransformer(BaseNodeTransformer):
        target = (3, 4)

    class StarredUnpackingTransformer_ctor_test(BaseNodeTransformer):
        target = (3, 4)
        code = "def test_method():"
        sut = StarredUnpackingTransformer()

    assert EmptyStarredUnpackingTransformer.target == (3,4)
    assert StarredUnpackingTransformer_ctor_test.target == (3,4)
    assert StarredUnpackingTransformer_ctor_test.code == "def test_method():"


# Generated at 2022-06-21 17:58:09.838523
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:17.285601
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    if sys.version_info < (3, 5):
        pytest.skip('Requires Python 3.5+')

    node = ast.parse('''
        print(*range(1), *range(3))
    ''').body[0]

    new_node = StarredUnpackingTransformer().visit(node)
    assert_source_equal(ast.fix_missing_locations(new_node),
                        '''
                        print(*(list(range(1)) + list(range(3))))
                        ''')


# Generated at 2022-06-21 17:58:28.210132
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_astunparse
    from typed_ast.ast3 import parse
    node = parse('print(*range(1), *range(3))')
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(node)
    target = parse('print(*(list(range(1)) + list(range(3))))')
    assert typed_astunparse.unparse(transformed) == typed_astunparse.unparse(target)

# Generated at 2022-06-21 17:58:40.786959
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .code_gen import to_source
    from .unpacking_generalizations import UnpackingGeneralizationsTransformer
    
    code = """
    from typing import List, Iterable
    from builtins import map, filter
    
    def foo(x: List[int], y: Iterable[int]):
        return [0, *x, *y, 1]
    """
    tree = ast.parse(code)
    UnpackingGeneralizationsTransformer().visit(tree)
    StarredUnpackingTransformer().visit(tree)
    fixed_code = to_source(tree)

# Generated at 2022-06-21 17:58:43.037010
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # test_StarredUnpackingTransformer::test_StarredUnpackingTransformer
    assert StarredUnpackingTransformer().target == (3, 4)



# Generated at 2022-06-21 17:58:52.599054
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    xs = [ast.Starred(value=ast.Name(id='foo'))]
    node = ast.Call(
        func=ast.Name(id='open'),
        args=xs,
        keywords=[])
    sum_of_lists = ast.BinOp(left=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='foo')], keywords=[]),
                             right=ast.List(elts=[]),
                             op=ast.Add())
    expected = ast.Call(
        func=ast.Name(id='open'),
        args=[ast.Starred(value=sum_of_lists)],
        keywords=[])
    result = StarredUnpackingTransformer().visit(node)
    assert expected == result


# Generated at 2022-06-21 17:58:59.529499
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    node = ast.parse("print(2, *range(10), 1)").body[0]
    StarredUnpackingTransformer.run(node)

    expected = "print(*(list([2]) + list(range(10)) + list([1])))"
    assert astor.to_source(node) == expected



# Generated at 2022-06-21 17:59:06.445475
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class M:
        _tree_changed = False
    from typed_ast import ast3
    node = ast3.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    transformer._tree_changed = M._tree_changed
    transformer.visit(node)
    assert str(node) == "[2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]"
    assert transformer._tree_changed == True


# Generated at 2022-06-21 17:59:14.697377
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # given
    code = "[2, *range(10), 1]"
    # when
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast.parse(code))
    # then
    expected = (
        ast.fix_missing_locations(ast.parse(
            "[2] + list(range(10)) + [1]").body[0])
    )
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 17:59:18.828832
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = "foo(1, *[2, *[3]])"
    expect = "foo(*(list([1]) + list([2, *list([3])])))"
    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    assert source != expect
    assert ast.dump(node) == expect

# Generated at 2022-06-21 17:59:31.070072
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast.ast3 import Module, parse
    from typeguard import typechecked
    from unittest.mock import patch
    import sys

    @typechecked
    def transform(data: str,
                  filename: str = '',
                  mode: str = 'exec',
                  ast_module: ast = ast) -> ast.Module:
        return StarredUnpackingTransformer().visit(parse(data, filename, mode, ast_module))


# Generated at 2022-06-21 17:59:39.524732
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""f(*args)""")
    transformer = StarredUnpackingTransformer(node)
    new_node = transformer.visit(node)
    result = ast.dump(new_node)

    assert result == "Module(body=[Expr(value=Call(func=Name(id='f', ctx=Load()), args=[Starred(value=List(elts=[Name(id='args', ctx=Load())], ctx=Load())]), keywords=[]))])"



# Generated at 2022-06-21 17:59:48.870379
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import m_transform_to

    assert m_transform_to('print(1, 2, 3)',
        StarredUnpackingTransformer) == 'print(1, 2, 3)'

    assert m_transform_to('print(1, *range(2), 3)',
        StarredUnpackingTransformer) == 'print(*(list(range(1)) + [2] + [3]))'

    assert m_transform_to('print(1, *range(1), *range(2))',
        StarredUnpackingTransformer) == 'print(*(list(range(1)) + list(range(1)) + list(range(2))))'


# Generated at 2022-06-21 17:59:55.674765
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[2, *range(10), 1]")
    assert not isinstance(tree.body[0].value.elts[2], ast.Starred)
    StarredUnpackingTransformer.run_transform(tree)
    assert isinstance(tree.body[0].value.elts[2], ast.BinOp)
    assert isinstance(tree.body[0].value.elts[2].left, ast.List)
    assert isinstan

# Generated at 2022-06-21 18:00:06.366368
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .context import Context
    from .python_source_to_ast import parse_src_to_ast
    from .ast_to_source import ast_to_src
    from ..samples import call_with_starred
    body = parse_src_to_ast(call_with_starred).body
    context = Context()
    transformer = StarredUnpackingTransformer(context=context)
    new_body = transformer.visit(body[0])
    new_src = ast_to_src(new_body)

    expected_src = 'print(*(list(range(1)) + list(range(3))))'

    assert expected_src == new_src


# Generated at 2022-06-21 18:00:18.038319
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call = ast.parse('print(*range(1), *range(2))').body
    assert len(call) == 1
    call = call[0]
    assert isinstance(call, ast.Expr)
    call = call.value
    assert isinstance(call, ast.Call)
    assert isinstance(call.func, ast.Name)
    assert call.func.id == 'print'

    result = StarredUnpackingTransformer().visit(call)  # type: ignore

    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert result.func.id == 'print'
    assert isinstance(result.args[0], ast.Starred)
    starred = result.args[0]
    assert isinstance(starred.value, ast.BinOp)


# Generated at 2022-06-21 18:00:19.748401
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import to_source


# Generated at 2022-06-21 18:00:29.341104
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None)._split_by_starred(  # type: ignore
        [ast.Name(id='a'), ast.Starred(value=ast.Name(id='b')),
         ast.Name(id='c'), ast.Starred(value=ast.Name(id='d')),
         ast.Name(id='e'), ast.Name(id='f')]  # type: ignore
    ) == [[ast.Name(id='a')], ast.Starred(value=ast.Name(id='b')),
          [ast.Name(id='c')], ast.Starred(value=ast.Name(id='d')),
          [ast.Name(id='e'), ast.Name(id='f')]]


# Generated at 2022-06-21 18:00:35.953438
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ..transformer import Tokens
    from ..codewriter import CodeWriter

    code = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"
    tokens = Tokens(code)
    call = StarredUnpackingTransformer().run(tokens.extract_tree())
    assert expected == CodeWriter().visit(call)

# Generated at 2022-06-21 18:00:41.641720
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    xs = [ast.Starred(value=ast.Name(id='range', ctx=ast.Load())), ast.Num(n=10)]
    s = StarredUnpackingTransformer()
    result = s.visit(xs)
    assert astor.to_source(result) == "[*(list(range()) + list([10]))]"

# Generated at 2022-06-21 18:00:48.792806
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='print'),
                    args=[ast.Starred(value=ast.Name(id='range'),
                                      ctx=ast.Load()),
                          ast.Num(n=0),
                          ast.Starred(value=ast.Name(id='range'),
                                      ctx=ast.Load()),
                          ast.Num(n=0)],
                    keywords=[])
    t = StarredUnpackingTransformer()
    node = t.visit(node)
    assert node.args[0].value.func.id == 'list'
    assert node.args[0].value.args[0].value.func.id == 'range'


# Generated at 2022-06-21 18:00:54.557159
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:01:00.211579
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()



# Generated at 2022-06-21 18:01:08.514232
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    data = [
        ('[2, *range(10), 1]', '[2, *(list(range(10)) + [1])]'),
        ('[2, *[range(2)], 1]', '[2, *(list([range(2)]) + [1])]'),
        ('[2, *[1, 2, 3], *range(10), 1]', '[2, *(list([1, 2, 3]) + list(range(10)) + [1])]'),
        ('[2, *[1, 2, 3], *range(10), *(1, 2, 3), 1]', '[2, *(list([1, 2, 3]) + list(range(10)) + list((1, 2, 3)) + [1])]'),  # noqa
    ]


# Generated at 2022-06-21 18:01:19.204415
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Tests that the visit_List method correctly transforms
    the input.
    """

# Generated at 2022-06-21 18:01:23.215463
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import inspect
    class_name = lambda x: x.__name__
    assert class_name(StarredUnpackingTransformer) == 'StarredUnpackingTransformer'


# Generated at 2022-06-21 18:01:24.890668
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None
    tra = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:30.253022
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class MockContext:
        node = None

    class MockNode:
        @property
        def args(self):
            return ["a", "b", "c"]

    node = MockNode()
    context = MockContext()

    context.node = node
    assert StarredUnpackingTransformer().visit_Call(context) == ["a", "b", "c"]


# Generated at 2022-06-21 18:01:38.828120
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    result = unparsed(compile_to_ast3(code))
    assert result == expected
    code = '[2, *range(10), *range(2)]'
    expected = '[2] + list(range(10)) + list(range(2))'
    result = unparsed(compile_to_ast3(code))
    assert result == expected



# Generated at 2022-06-21 18:01:39.878334
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    exec(str(transformer), {})

# Generated at 2022-06-21 18:01:45.210904
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    '''
    Example:
        [2, *range(10), 1]
        
    Is transformed to:
        [2] + list(range(10)) + [1]
    '''

# Generated at 2022-06-21 18:01:56.080014
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # *range(1), 2, *range(10), 1
    array = ast.List(elts=[
        ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                   args=[ast.Num(n=1)],
                                   keywords=[])),
        ast.Num(n=2),
        ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                   args=[ast.Num(n=10)],
                                   keywords=[])),
        ast.Num(n=1)])

    # [2] + list(range(1)) + [10] + list(range(10)) + [1]

# Generated at 2022-06-21 18:02:05.729647
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:15.270457
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = '[2, *range(10), 1]'
    module = ast.parse(code, "<code>", 'exec')
    StarredUnpackingTransformer().visit(module)
    assert module.body[0].value.left.elts[0].n == 2
    assert module.body[0].value.left.elts[1].elts[0].func.id == 'range'
    assert module.body[0].value.left.elts[1].elts[0].args[0].n == 10
    assert module.body[0].value.left.elts[2].n == 1



# Generated at 2022-06-21 18:02:17.849131
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ast_StarredUnpackingTransformer = StarredUnpackingTransformer()
    assert isinstance(ast_StarredUnpackingTransformer, StarredUnpackingTransformer)


# Generated at 2022-06-21 18:02:28.420694
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .transformer_visitor import TransformerVisitor
    from .base import BaseNodeTransformer
    from .base import BaseTransformer
    from .node_transformer import NodeTransformer
    from .base_context import BaseContext
    from .transformer_visitor import TransformerVisitor
    from .replacement import Replacement
    transformer = StarredUnpackingTransformer(BaseContext())

    # test if class variables are set correctly
    assert transformer.context == BaseContext()
    assert transformer._tree_changed == False

    # test if class returns correct type
    assert type(transformer._has_starred([])) == bool
    assert type(transformer._split_by_starred([])) == list
    assert type(transformer._prepare_lists([])) == list

# Generated at 2022-06-21 18:02:41.790176
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from tests.test_transformer import to_source, run_all_nodes, get_all_nodes, assert_source
    from .base import BaseTransformer, BaseNodeTransformer
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert issubclass(StarredUnpackingTransformer, BaseTransformer)
    assert StarredUnpackingTransformer.target == (3, 4)
    source = '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    '''
    expected = '''
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    '''
    t = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:43.872719
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().__class__.__name__ == 'StarredUnpackingTransformer'

# Generated at 2022-06-21 18:02:57.182109
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Name(ast.expr):
        def __init__(self, id, ctx=None):
            self.id = id
            self.ctx = ctx

    class Add(ast.expr):
        def __init__(self, left, right):
            self.left = left
            self.right = right
            self.op = ast.Add()

    class List(ast.expr):
        def __init__(self, elts):
            self.elts = elts

    class Call(ast.Call):
        def __init__(self, func, args, keywords=None):
            self.func = func
            self.args = args
            self.keywords = keywords
            self.starargs = None
            self.kwargs = None


# Generated at 2022-06-21 18:03:03.261724
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    # basic
    assert isinstance(s, BaseNodeTransformer)
    assert s.target == (3, 4)
    # target should be a tuple
    with pytest.raises(AssertionError):
        s.target = 1
    # tree_changed should raise error
    with pytest.raises(RuntimeError):
        assert s.tree_changed


# Generated at 2022-06-21 18:03:08.038900
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .helpers import run_transformer_on_string 

    source = "[2, *range(10), 1]"
    node = ast.parse(source)
    expected = ast.parse("[2] + list(range(10)) + [1]")
    actual = run_transformer_on_string(StarredUnpackingTransformer(), source)

    assert ast.dump(node) == ast.dump(expected)
    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-21 18:03:14.168989
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = """
x = [1, *range(10), 2]
"""
    expected = """
x = [1] + list(range(10)) + [2]
"""
    code = compile(src, '<test>', 'exec', optimize=0)
    expected_code = compile(expected, '<test>', 'exec', optimize=0)
    actual_code = StarredUnpackingTransformer().visit(code)
    assert ast.dump(actual_code) == ast.dump(expected_code)


# Generated at 2022-06-21 18:03:41.910379
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from _ast import list
    from ast_utils.transformer import transform_to_ast
    from ast_utils.source import get_ast
    from ast_utils.compare import compare_asts

    source_code = '[2, *range(10), 1]'
    expected_source_code = '[2] + list(range(10)) + [1]'

    source_ast = get_ast(source_code)
    expected_ast = get_ast(expected_source_code)

    transform_to_ast(source_ast, [StarredUnpackingTransformer()])
    assert compare_asts(source_ast, expected_ast)



# Generated at 2022-06-21 18:03:47.826658
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''\
print(*range(1), *range(3), *[], *range(5), *range(6), *[])
''')
    StarredUnpackingTransformer().visit(tree)
    StarredUnpackingTransformer(debug=True).visit(tree)
    assert str(tree).strip() == 'print(*(list(range(1)) + list(range(3)) + [] + list(range(5)) + list(range(6)) + []))'


# Generated at 2022-06-21 18:03:55.486366
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    source = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"

    def read_source_as_tree(source):
        return ast.parse(source)

    tree = read_source_as_tree(source)
    StarredUnpackingTransformer.run_on(tree)
    result = astor.to_source(tree)
    assert expected == result


# Generated at 2022-06-21 18:04:05.394240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    try:
        from typed_ast import ast3 as ast
        from typed_ast.ast3 import Starred
    except:
        from typed_ast import ast3 as ast
        from typed_ast.ast3 import Starred

    from .test_transformer_base import BaseTestTransformer

    class TestCases(BaseTestTransformer):
        def test_empty(self):
            source = "[]"
            expect = source
            tree = ast.parse(source)
            new_tree = StarredUnpackingTransformer().visit(tree)
            self.assertEqual(expect, ast.dump(new_tree))

        def test_single(self):
            source = "[1]"
            expect = source
            tree = ast.parse(source)
            new_tree = StarredUnpackingTransformer().visit(tree)
            self

# Generated at 2022-06-21 18:04:18.135102
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Type instantiation
    # `span` is used for positional source info, it's not important for our test
    span = ast.parse("").body[0]
    node = ast.List(elts=[2,
                          ast.Starred(value=ast.Call(
                              func=ast.Name(id='range'),
                              args=[10],
                              keywords=[])),
                          1],
                    ctx=ast.Load(),
                    )
    x = StarredUnpackingTransformer()
    assert isinstance(x, ast.NodeTransformer)

    # Method `visit_List`
    x.generic_visit = lambda x: x
    node = x.visit_List(node)
    assert isinstance(node, ast.List)
    assert isinstance(node.elts[0], ast.Num)

# Generated at 2022-06-21 18:04:21.449590
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Instance StarredUnpackingTransformer
    obj = StarredUnpackingTransformer(verbosity=0)
    # Init by constructor
    obj.visit_List(ast.List())



# Generated at 2022-06-21 18:04:22.437771
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-21 18:04:29.644531
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
        '''

    expected = '''
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        '''

    result = compile(source, '<test>', 'exec', flags=ast.PyCF_ONLY_AST, optimize=2)
    StarredUnpackingTransformer(verbose=True).visit(result)
    code = compile(result, '<string>', 'exec')  # compile fixes formatting
    result = ast.unparse(result)
    print(result)
    assert result.strip() == expected.strip()

# Generated at 2022-06-21 18:04:35.682982
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import round_trip, compare_source
    code = 'print(1, *range(10))'
    tree = round_trip(code)
    assert isinstance(tree.body[0].value, ast.Call)
    StarredUnpackingTransformer().visit(tree)
    compare_source(tree, 'print(*(list(range(10)) + [1]))')



# Generated at 2022-06-21 18:04:42.261177
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import astunparse
    sut = StarredUnpackingTransformer()
    result = sut.visit_Call(ast.parse("print(*range(1), *range(3))").body[0])
    assert astunparse.unparse(result) == 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-21 18:05:24.995033
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Unit test for constructor of class StarredUnpackingTransformer")
    assert StarredUnpackingTransformer().tree_changed == False
    

# Generated at 2022-06-21 18:05:35.808397
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    '''
    Unit test for constructor of class StarredUnpackingTransformer
    '''
    input_ast = ast.parse("[2, *range(10), 1]")
    test_transformer = StarredUnpackingTransformer(input_ast)

    assert test_transformer._has_starred([]) == False
    assert test_transformer._has_starred(['abc']) == False
    assert test_transformer._has_starred([ast.Starred()]) == True
    assert test_transformer._has_starred([ast.Starred(), ast.Starred()]) == True
    assert test_transformer._has_starred([ast.Name()]) == False
    assert test_transformer._has_starred([ast.Name(), ast.Starred()]) == True
    assert test_transformer._has_starred

# Generated at 2022-06-21 18:05:47.082219
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    l = ast.List(elts=[ast.Num(n=2),
                       ast.Starred(value=ast.Name(id='range')),
                       ast.Num(n=1)])
    assert StarredUnpackingTransformer.check_tree(l, 'py3')
    assert not StarredUnpackingTransformer.check_tree(l, 'py2')

    l = ast.Call(func=ast.Name(id='print'),
                 args=[ast.Starred(value=ast.Name(id='range')),
                       ast.Starred(value=ast.Name(id='range'))],
                 keywords=[])
    assert StarredUnpackingTransformer.check_tree(l, 'py3')
    assert not StarredUnpackingTransformer.check_tree(l, 'py2')


# Generated at 2022-06-21 18:05:53.868410
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .testutils import roundtrip_unparse

    tests = [
        "[2, *range(10), 1]",
        "print(*range(1), *range(3))",
    ]

    for code in tests:
        tree = ast.parse(code)
        tree2 = roundtrip_unparse(tree)
        assert ast.dump(tree) == ast.dump(tree2)


test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:05:59.149758
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sn = StarredUnpackingTransformer()
    result = sn.visit(ast.parse("[2, *range(10), 1]"))
    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert str(expected) == str(expected)


# Generated at 2022-06-21 18:06:11.607544
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer(None)
    args = [ast.Starred(value=ast.Name(id='a')), 
            ast.List(elts=[ast.Name(id='b'), ast.Name(id='c')]),
            ast.Starred(value=ast.Name(id='d'))
           ]
    node = ast.Call(func=ast.Name(id='print'), args=args, keywords=[])

# Generated at 2022-06-21 18:06:12.316828
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-21 18:06:17.290905
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import TreeCompiler

    code = '[x, *ys, 5]'
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    result = TreeCompiler().visit(node)
    assert result == '([x, 5] + list(ys))'



# Generated at 2022-06-21 18:06:27.140425
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmnt = ast.Module([ast.Expr(
        value=ast.Call(
            func=ast.Name(id='print'),
            args=[
                ast.Starred(
                    value=ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Num(n=1)],
                        keywords=[]),
                    ctx=ast.Load()),
                ast.Starred(
                    value=ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Num(n=3)],
                        keywords=[]),
                    ctx=ast.Load())],
            keywords=[]))])


# Generated at 2022-06-21 18:06:34.233130
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)
    star_expr_removed = "print([2] + list(range(10)) + [1])"
    assert compile(tree, file=None, mode="exec") == compile(star_expr_removed, file=None, mode="exec")
