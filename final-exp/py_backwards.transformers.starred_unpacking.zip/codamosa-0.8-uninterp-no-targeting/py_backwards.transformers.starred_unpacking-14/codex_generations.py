

# Generated at 2022-06-21 17:57:08.128914
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    sut = StarredUnpackingTransformer()
    tree = ast.parse(source)
    tree = sut.visit(tree)

    assert astor.to_source(tree) == expected

# Generated at 2022-06-21 17:57:09.834660
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3).target == (3,)

# Generated at 2022-06-21 17:57:12.516975
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None

# Generated at 2022-06-21 17:57:18.894494
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    expected_ast = ast.parse(
        'print(*(list(range(1)) + list(range(3))))')
    tree_to_compile = ast.parse('print(*range(1), *range(3))')
    result_tree = StarredUnpackingTransformer().visit(tree_to_compile)
    assert ast.dump(result_tree) == ast.dump(expected_ast)
    assert StarredUnpackingTransformer()._tree_changed == True




# Generated at 2022-06-21 17:57:20.595318
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star_transformer = StarredUnpackingTransformer()
    assert star_transformer
    # print(star_transformer)

# Generated at 2022-06-21 17:57:24.570099
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .transform import CstLintRuleSet
    rs = CstLintRuleSet()
    sut = StarredUnpackingTransformer(rs)
    assert sut is not None
    assert isinstance(sut, StarredUnpackingTransformer)

# Generated at 2022-06-21 17:57:36.386068
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import collections.abc
    from typed_ast import ast3 as ast
    import typed_astunparse
    import unittest

    class TestStarredUnpackingTransformer_visit_Call(unittest.TestCase):

        def test_empty_arguments(self):
            test_node = ast.parse('print()').body[0]
            self.assertIsInstance(test_node, ast.Expr)
            self.assertIsInstance(test_node.value, ast.Call)
            self.assertIsInstance(test_node.value.func, ast.Name)
            self.assertEqual(test_node.value.func.id, 'print')
            self.assertEqual(len(test_node.value.args), 0)

            expected_node = ast.parse('print()').body[0]

# Generated at 2022-06-21 17:57:46.343529
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = 'print(*range(1), *range(3))'
    expected_ast = ast.parse(
        'print(*(list(range(1)) + list(range(3))))')
    expected_source = 'print(*(list(range(1)) + list(range(3))))'

    # Test AST
    actual_ast = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    actual_ast = transformer.visit(actual_ast)
    assert ast.dump(expected_ast) == ast.dump(actual_ast)

    # Test source
    actual_source = compile(actual_ast, filename='<test>', mode='exec').co_consts[1]
    assert expected_source == actual_source

# Generated at 2022-06-21 17:57:47.676005
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert s is not None

# Generated at 2022-06-21 17:57:55.961072
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(
            value=ast.Name(id='range'),
            ctx=ast.Load()),
            ast.Num(1),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(2)],
                    keywords=[]),
                ctx=ast.Load())],
        keywords=[])

# Generated at 2022-06-21 17:58:09.660308
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..ast_utils import get_ast
    from .dict_comp_transformer import DictCompTransformer
    tree = get_ast('[2, *range(10), 1]')
    expected = get_ast('[2] + list(range(10)) + [1]')
    transformer = StarredUnpackingTransformer()
    new = transformer.visit(tree)
    assert ast.dump(expected) == ast.dump(new)
    assert transformer.was_changed

    tree = get_ast('[*[], 1]')
    transformer = StarredUnpackingTransformer()
    new = transformer.visit(tree)
    assert ast.dump(expected) == ast.dump(new)
    assert transformer.was_changed

    tree = get_ast('[1, *[], 2]')
    expected = get_ast

# Generated at 2022-06-21 17:58:19.385939
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast.ast3 import parse
    from typed_astunparse import dump
    from .TransformerTest import TransformerTest, cases
    from .test_ListComprehensionTransformer import list_comp_cases

    transformer = StarredUnpackingTransformer()

    def _eval(s: str) -> str:
        node = parse(s, mode='eval')
        transformed = transformer.visit(node)
        return dump(transformed)


# Generated at 2022-06-21 17:58:20.929444
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-21 17:58:30.565735
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tested_class = StarredUnpackingTransformer

# Generated at 2022-06-21 17:58:41.686033
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helper import _dump, assertAstEqual

    code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'
    tree = ast.parse(code)
    result = StarredUnpackingTransformer().visit(tree)  # type: ignore
    assertAstEqual(_dump(result), expected_code)

    expected_code = '[2, 1]'
    tree = ast.parse(expected_code)
    result = StarredUnpackingTransformer().visit(tree)  # type: ignore
    assertAstEqual(_dump(result), expected_code)

    expected_code = '[*range(10)]'
    tree = ast.parse(expected_code)
    result = StarredUnpackingTransformer().visit(tree)  # type: ignore


# Generated at 2022-06-21 17:58:43.640637
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest
    import doctest
    doctest.testmod(StarredUnpackingTransformer)
    unittest.main(verbosity=2)

# Generated at 2022-06-21 17:58:52.829162
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[ast.Constant(value=2), ast.Starred(value=ast.Call(
        func=ast.Name(id='range'), args=[ast.Constant(value=10)], keywords=[])), ast.Constant(value=1)])
    assert ast.dump(node) == "List(elts=[Constant(value=2), Starred(value=Call(func=Name(id='range', ctx=Load()), args=[Constant(value=10)], keywords=[])), Constant(value=1)])"
    tur = StarredUnpackingTransformer()
    node = tur.visit(node)

# Generated at 2022-06-21 17:59:05.751492
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer(verbose=True)

    # No Starred
    out = t.visit(ast.parse('[1, 2, 3]'))
    assert ast.dump(out) == "[1, 2, 3]\n"

    # One Starred
    out = t.visit(ast.parse('[1, *range(2), 3]'))
    assert ast.dump(out) == "BinOp(left=List(elts=[1]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=2)], keywords=[])], keywords=[]))\n"

    # Two Starred

# Generated at 2022-06-21 17:59:17.837494
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse("""
        print(*range(10))
    """)

    transformer = StarredUnpackingTransformer()
    module = transformer.visit(module)
    assert isinstance(module, ast.Module)
    assert isinstance(module.body[0], ast.Expr)
    assert isinstance(module.body[0].value, ast.Call)
    call = module.body[0].value
    assert isinstance(call.func, ast.Name)
    assert call.func.id == 'print'

# Generated at 2022-06-21 17:59:27.248283
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = """[0, 1, 2, 3, 4, 5, 6]
        [0, *range(10), 6]
        [0, *range(10), 1, *range(10), 6]"""
    expected = """[0, 1, 2, 3, 4, 5, 6]
        [0] + list(range(10)) + [6]
        [0] + list(range(10)) + [1] + list(range(10)) + [6]"""
    result = transform(s, StarredUnpackingTransformer)
    assert expected == result


# Generated at 2022-06-21 17:59:41.805380
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    result = transpile_func("def f(): return [2, *range(10), 1]")
    assert "def f(): return [2] + list(range(10)) + [1]" in result

    result = transpile_func("def f(): return [2, *range(10), 1, *range(10)]")
    assert "def f(): return [2] + list(range(10)) + [1]" in result



# Generated at 2022-06-21 17:59:45.166450
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = ast.parse("[2, *range(10), 1]")
    target = ast.parse("[2] + list(range(10)) + [1]")

    assert StarredUnpackingTransformer().visit(source) == target


# Generated at 2022-06-21 17:59:51.019577
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .common import _test_transformed
    tree = """
        print(*range(1), *range(3))
    """
    want = """
        print(*(list(range(1)) + list(range(3))))
    """
    _test_transformed(StarredUnpackingTransformer, tree, want)


# Generated at 2022-06-21 17:59:54.381376
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)
    print(ast.dump(tree))


# Generated at 2022-06-21 18:00:06.406217
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    call1 = ast.Call(func=ast.Name(id='list'),
                     args=[ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                     args=[ast.Num(1)],
                                                     keywords=[]))],
                     keywords=[])

# Generated at 2022-06-21 18:00:17.731349
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    old = ast.parse("""
    print('a', 2, *range(4), *range(5))
    print('b', 2, *range(4))
    print('c', 2, *range(5))
    print('d', 2)
    print('e')
    """)
    new = ast.parse("""
    print(*(['a', 2] + list(range(4)) + list(range(5))))
    print(*(['b', 2] + list(range(4))))
    print(*(['c', 2] + list(range(5))))
    print(*(['d', 2]))
    print(*(['e']))
    """)
    assert list(StarredUnpackingTransformer().visit(old.body)) == list(new.body)

# Generated at 2022-06-21 18:00:27.320640
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer"""
    def do_test(code: str) -> None:
        """Helper function for unit test"""
        expected = ast.parse(code)
        tr = StarredUnpackingTransformer()
        tree = ast.parse(code)
        tr.visit(tree)
        assert tr.tree_changed == True, "tree has been not changed"
        assert ast.dump(tree) == ast.dump(expected), "visit_List is broken"

    do_test("[2, *range(10), 1]")
    do_test("[2, *range(10), 1, *[3, 4, 5]]")


# Generated at 2022-06-21 18:00:28.204583
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x

# Generated at 2022-06-21 18:00:34.147692
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]")
    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)
    assert ast.dump(new_node) == "Expr(value=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)], ctx=Load()))))"
    node = ast.parse("print(*range(1), *range(3))")
    trans = StarredUn

# Generated at 2022-06-21 18:00:41.274363
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from ..compat import parse

    code = 'list_example = [1, *[2, *[3, 4]]]'
    module = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    transformer.visit(module)

    expected = parse('list_example = [1] + list([2] + list([3, 4]))')
    assert identical(transformer.module, expected)


# Generated at 2022-06-21 18:01:02.442911
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
  code = '''[2, *range(10), 1]'''
  
  tree = ast.parse(code)
  StarredUnpackingTransformer().visit(tree)
  t = ast.parse('[2] + list(range(10)) + [1]')
  assert ast.dump(tree) == ast.dump(t)


# Generated at 2022-06-21 18:01:05.884796
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer
    transformer.target = (3, 4)
    assert transformer.target == (3, 4)


# Tests for method _has_starred of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:01:07.318395
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    print(t)



# Generated at 2022-06-21 18:01:16.684282
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """
    Source:
        [2, *range(10), 1]
    Compiled:
        [2] + list(range(10)) + [1]
    """
    import astor

    source = ast.parse('[2, *range(10), 1]').body[0]
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0]
    compiler = StarredUnpackingTransformer()
    compiler.visit(source)
    assert astor.to_source(source) == astor.to_source(expected)



# Generated at 2022-06-21 18:01:24.943086
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import numpy as np
    code = 'np.mean(np.vstack([*map(lambda x: np.array(x), x)]))'
    unstarred = 'np.mean(np.vstack(list(map(lambda x: np.array(x), x))))'

    result = StarredUnpackingTransformer().visit(ast.parse(code))
    expected = ast.parse(unstarred)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 18:01:35.656712
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """
    Tests for the visit_List method of class StarredUnpackingTransformer
    """

    # The transformer should be triggered for List with a Starred
    snippet = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tr = StarredUnpackingTransformer()
    node = ast.parse(snippet)
    result = tr.visit(node)
    assert(str(result) == expected)

    # The transformer should be triggered for a multi-line List
    snippet = """[
        2,
        *range(10),
        1
    ]"""
    expected = """[
        2] + list(range(10)) + [
        1
    ]"""
    tr = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:40.200033
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = """
    [1, *[2, 3], 4]
    """
    expected = """
    (([1] + list([2, 3]))) + list([4])
    """
    node = ast.parse(input)
    node2 = StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node2).strip() == expected


# Generated at 2022-06-21 18:01:40.979150
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:01:44.104326
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:55.155683
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = if_(name('is_ok'),
               List([Num(2), Starred(value=Call(func=Name(id='range'),
                                                args=[Num(10)],
                                                keywords=[])), Num(1)]),
               Num(0))
    expected = if_(name('is_ok'),
                   BinOp(left=List(elts=[Num(2)]),
                         right=BinOp(left=Call(func=Name(id='list'),
                                               args=[Call(func=Name(id='range'),
                                                          args=[Num(10)],
                                                          keywords=[])],
                                               keywords=[]),
                                     right=List(elts=[Num(1)]),
                                     op=Add()),
                         op=Add()),
                   Num(0))
    tree = ast

# Generated at 2022-06-21 18:02:27.233305
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:02:28.891458
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert_equal(StarredUnpackingTransformer().target, (3, 4))

# Generated at 2022-06-21 18:02:31.609044
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-21 18:02:44.130253
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    visitor = StarredUnpackingTransformer()

    parsed_code = ast.parse(
        '''[2, *range(10), 1, *range(0, 3), 3]''')
    visitor.visit(parsed_code)
    code = astor.to_source(parsed_code)
    assert code == '([2] + list(range(10)) + [1] + list(range(0, 3)) + [3])'

    parsed_code = ast.parse(
        '''[2, *range(10), 1]''')
    visitor.visit(parsed_code)
    code = astor.to_source(parsed_code)
    assert code == '([2] + list(range(10)) + [1])'


# Generated at 2022-06-21 18:02:57.263875
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseUnaryNodeTransformerTestCase
    class TestCase(BaseUnaryNodeTransformerTestCase):
        transformer_class = StarredUnpackingTransformer
        expr_data = [
            [15, [2, 3, '*', [4, 5], [6, 7]]],
            [None, [[[1, 2], '*', [3, 4], [5, 6]], '*', [[7, 8], '*', [9, 0], [1, 2]]]],
            [None, [[[], '*', [1, 2]], '*', [[], '*', [3]], '*', [[], '*', [4, 5]]]],
        ]
        def pre_test(self, test_case: dict):
            """Before test add `list` to `__builtins__`."""

# Generated at 2022-06-21 18:03:04.471200
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print("\n# Unit test for method visit_List of class StarredUnpackingTransformer")
    transformer = StarredUnpackingTransformer()
    node = ast.parse('[2, *range(10), 1]').body[0]
    print(ast.dump(node, include_attributes=True))
    transformer.visit(node)
    print(ast.dump(node, include_attributes=True))
    print(ast.dump(ast.fix_missing_locations(node), include_attributes=True))
    exec(compile(ast.fix_missing_locations(node), filename="<ast>", mode='exec'))

if __name__ == "__main__":
    test_StarredUnpackingTransformer_visit_List()

# Generated at 2022-06-21 18:03:10.159982
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected = ['[2, *range(10), 1]\n',
                'print(*range(1), *range(3))']
    result = str(StarredUnpackingTransformer(3, 4).visit(expected))
    assert result == "[2] + list(range(10)) + [1]\nprint(*(list(range(1)) + list(range(3))))"

# Generated at 2022-06-21 18:03:14.594914
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)

    expected_code = "[2] + list(range(10)) + [1]"
    expected = ast.parse(expected_code)
    assert ast.dump(new_tree) == ast.dump(expected)



# Generated at 2022-06-21 18:03:22.421856
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = 'print([2, *range(10), 1])'
    expected_tree = ast.parse('''
print(
    [2]
    + list(range(10))
    + [1]
)
'''.strip())
    actual_tree = ast.parse(code)
    StarredUnpackingTransformer().visit(actual_tree)
    assert ast_equals_source(actual_tree, expected_tree)



# Generated at 2022-06-21 18:03:34.789322
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    c1 = StarredUnpackingTransformer(3, 4)
    c2 = StarredUnpackingTransformer(3, 4)
    c3 = StarredUnpackingTransformer(3, 5)

    assert not c1._tree_changed
    assert not c2._tree_changed
    assert not c3._tree_changed

    assert c1.target == (3, 4)
    assert c2.target == (3, 4)
    assert c3.target == (3, 5)

    assert c1 == c2
    assert not c1 == c3

    assert hash(c1) == hash(c2)
    assert hash(c1) != hash(c3)

    assert str(c1) == 'StarredUnpackingTransformer(3, 4)'

# Generated at 2022-06-21 18:04:46.584805
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[1, *(2, 3), 4, *[5, 6], 7]")
    tree_visited = StarredUnpackingTransformer().visit(tree)
    tree_expected = ast.parse("[1] + list((2, 3)) + [4] + list([5, 6]) + [7]")
    assert ast.dump(tree_visited) == ast.dump(tree_expected)


# Generated at 2022-06-21 18:04:53.901785
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    filename = 'print(*[3, 4, 5], *[6, 7, 8])'
    tree = ast.parse(filename)
    node = StarredUnpackingTransformer().visit(tree)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Call)
    assert isinstance(node.body[0].value.args[0], ast.Starred)
    assert isinstance(node.body[0].value.args[0].value, ast.BinOp)
    assert isinstance(node.body[0].value.args[0].value.left, ast.BinOp)

# Generated at 2022-06-21 18:05:02.094480
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    file = open("test.py", "r")
    tree = ast.parse(file.read())  # type: ignore
    tree = StarredUnpackingTransformer().visit(tree)  # type: ignore
    ast.fix_missing_locations(tree)  # type: ignore
    print(ast.dump(tree))
    exec(compile(tree, filename="<ast>", mode="exec"))

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:05:13.476858
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from compiler.transformer.starred_unpacking import StarredUnpackingTransformer
    node = ast3.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-21 18:05:23.309320
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import compile_to_ast
    from .visitor import BaseNodeTransformer

    code = '[2, *range(10), 1]'
    target_code = '[2] + list(range(10)) + [1]'
    assert compile_to_ast(code) == compile_to_ast(target_code)

    code = '[2, *range(10), 1]'
    node = compile_to_ast(code)
    transformer = StarredUnpackingTransformer(BaseNodeTransformer)
    transformer.visit(node)
    assert compile_to_ast(code) == compile_to_ast(target_code)


# Generated at 2022-06-21 18:05:30.911663
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # test_issue_7_with_2_stars
    node = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(node)

    # test_issue_10_multiline_call
    node = ast.parse("""
        foo(
            *arg,
            key=val,
            **kw
        )
        """)
    expected = ast.parse("""
        foo(*(list(arg) + [
            ast.keyword(key='key', value=val)
        ] + list(kw)))
        """)
    StarredUnpackingTransformer().visit(node)


# Generated at 2022-06-21 18:05:37.501638
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(elts=[
        ast.NameConstant(value=2),    # 2
        ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()),
        ast.Num(n=10),                # range
        ast.NameConstant(value=1),    # 1
    ])

# Generated at 2022-06-21 18:05:48.015858
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def test(code, expected_code):
        tree = ast.parse(code)
        tree = StarredUnpackingTransformer().visit(tree)
        assert ast.dump(tree) == expected_code

    test('a', 'a')
    test('[2, 3, 4]', '[2, 3, 4]')
    test('[2, *range(10), 1]', '[2] + list(range(10)) + [1]')
    test('[2, *range(10), *[], 1]', '[2] + list(range(10)) + [1]')
    test('[2, *range(10), *range(1)]', '[2] + list(range(10)) + list(range(1))')

# Generated at 2022-06-21 18:05:49.213070
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:06:01.394450
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestCase(unittest.TestCase):
        def test(self):
            tests = [
                (
                    "[2, *range(10), 1]",
                    "[2] + list(range(10)) + [1]"
                ),
                (
                    "print([1, 2, *range(10)])",
                    "print(*(list([1, 2]) + list(range(10))))"
                ),
                (
                    "print(*range(10))",
                    "print(*list(range(10)))"
                ),
                (
                    "print(*[1, 2], *range(10))",
                    "print(*(list([1, 2]) + list(range(10))))"
                ),
            ]
