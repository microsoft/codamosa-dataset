

# Generated at 2022-06-21 17:57:06.618364
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:57:11.477399
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typedast.ast3 import String, dump
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    str1 = String(s = 'hello world')
    StarredUnpackingTransformer.visit(str1)
    print(dump(str1))

    # References:
    # 1. https://greentreesnakes.readthedocs.io/en/latest/nodes.html
    # 2. https://typed-ast.readthedocs.io/en/latest/api.html#typed_ast.ast3.Starred
    # 3. https://stackoverflow.com/questions/53791097/how-to-get-value-from-a-starred-node-in-the-ast


# Generated at 2022-06-21 17:57:21.352270
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .operators import OperatorsTransformer
    from .gens import GenexpTransformer
    from .comprehensions import ComprehensionsTransformer
    from .tuples_unpacking import TuplesUnpackingTransformer


# Generated at 2022-06-21 17:57:26.244302
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node=ast.Call(func=ast.Name(id='foo'), args=[2, 3,5], keywords=[], starargs=None, kwargs=None)
    tree=StarredUnpackingTransformer().visit(node)

    assert len(tree.args) == 3


# Generated at 2022-06-21 17:57:37.915968
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='call_some_function'),
        args=[ast.List(elts=[], ctx=ast.Load()),
              ast.Starred(value=ast.List(elts=[ast.Name(id='a'),
                                               ast.Name(id='b'),
                                               ast.Name(id='c')],
                                         ctx=ast.Load()), ctx=ast.Load()),
              ast.Starred(value=ast.List(elts=[ast.Name(id='d'),
                                               ast.Name(id='e'),
                                               ast.Name(id='f')],
                                         ctx=ast.Load()), ctx=ast.Load())],
        keywords=[])

# Generated at 2022-06-21 17:57:50.044101
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from tests.helper import ast_data, StageTestCase

    # test with example from docstring
    class TestDocstring(StageTestCase):

        stagename = 'StarredUnpackingTransformer'
        stageclass = StarredUnpackingTransformer

        def test_docstring(self):
            input_data = ast_data(
                """
                [2, *range(10), 1]
          
                print(*range(1), *range(3))
            """
            )

            expected_data = ast_data(
                """
                ([2] + list(range(10)) + [1])
          
                print(*(list(range(1)) + list(range(3))))
            """
            )

            self.assertStageOutput(input_data, expected_data)

    # further test with multiple starred

# Generated at 2022-06-21 17:57:56.501721
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    code = '[2, *range(10), 1]'
    expected = '([2] + list(range(10)) + [1])'
    node = ast.parse(code)

    # Act
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)

    # Assert
    assert transformer._tree_changed is True
    assert ast.dump(result) == expected


# Generated at 2022-06-21 17:58:03.528341
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(1, *[2,3])").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)

    expected = ast.parse("print(*(list(1)+list([2,3])))").body[0]
    assert isinstance(expected, ast.Expr)
    assert isinstance(expected.value, ast.Call)

    new_node = StarredUnpackingTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(expected)


# Generated at 2022-06-21 17:58:10.288276
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(2), *range(5))').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'print'
    assert node.value.args == [ast.Starred(ast.Call(ast.Name(id='range'), [ast.Num(2)], []), ast.Load()),
                               ast.Starred(ast.Call(ast.Name(id='range'), [ast.Num(5)], []), ast.Load())]
    assert node.value.keywords == []
    assert node.value.starargs is None
    assert node.value.kwargs is None
    out = StarredUnpackingTrans

# Generated at 2022-06-21 17:58:11.906137
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert a.target == (3, 4)

# Generated at 2022-06-21 17:58:19.620952
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .utils import transform_source

# Generated at 2022-06-21 17:58:26.713220
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]")
    node = StarredUnpackingTransformer().visit(node)
    # Check name of BinOp (which is '+')
    assert node.body[0].value.value.left.op.__class__.__name__ == 'Add'
    # Check name of Call (which is 'range')
    assert node.body[0].value.value.right.value.func.id == 'range'


# Generated at 2022-06-21 17:58:29.984805
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Name(id="*"))])
    assert not StarredUnpackingTransformer._has_starred([ast.Name(id="*")])
    assert not StarredUnpackingTransformer._has_starred([])


# Generated at 2022-06-21 17:58:38.392646
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseTestTransformer
    from .base import untransform
    from .base import compare_nodes

    class Test(BaseTestTransformer):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """\
        [2, *range(10), 1]
        """

        EXPECTED = """\
        [2] + list(range(10)) + [1]
        """

    untransform()
    compare_nodes(Test.TEST())



# Generated at 2022-06-21 17:58:44.588483
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.Call(func=ast.Name(id='print'), args=[ ast.Starred(value=ast.Name(id='x'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='y'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='z'), ctx=ast.Load())], keywords=[])
    transformed = StarredUnpackingTransformer().visit(x)
    assert type(transformed) == ast.Call
    assert type(transformed.args[0]) == ast.Starred
    assert type(transformed.args[0].value) == ast.BinOp
    assert transformed.args[0].value.left.func.id == 'list'
    assert transformed.args[0].value.left.args[0].id == 'x'


# Generated at 2022-06-21 17:58:52.420805
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse(
            "func(1)"
            ).body[0]
    assert node == StarredUnpackingTransformer().visit(node)
    node = ast.parse(
            "func(*[])"
            ).body[0]
    assert node == StarredUnpackingTransformer().visit(node)
    node = ast.parse(
            "func(1, *[], 2)"
            ).body[0]
    expected = ast.parse(
        "func(*(list([1]) + list([]) + list([2])))"
        ).body[0]
    assert expected == StarredUnpackingTransformer().visit(node)
    

# Generated at 2022-06-21 17:58:59.308201
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    xformed = StarredUnpackingTransformer().visit(node)
    expected = ast.parse('[2] + list(range(10)) + [1]')  # type: ignore
    assert ast.dump(xformed) == ast.dump(expected)



# Generated at 2022-06-21 17:59:05.833650
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test:
    code = "[2, *range(10), 1]"
    node = ast.parse(code)
    expr = StarredUnpackingTransformer().visit(node)
    # Expected:
    expected_code = "[2] + list(range(10)) + [1]"
    expected_node = ast.parse(expected_code).body[0]

    assert ast.dump(expected_node) == ast.dump(expr)


# Generated at 2022-06-21 17:59:09.675170
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    source = inspect.getsource(transformer.__init__)
    assert 'def __init__' in source


# Generated at 2022-06-21 17:59:19.023581
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = StarredUnpackingTransformer()
    elts = [ast.Name(id="1", ctx=ast.Load()), ast.Starred(value=ast.Name(id="range", ctx=ast.Load()))]
    node = ast.List(elts=elts, ctx=ast.Load())
    result = a.visit(node)
    assert isinstance(result, ast.List)
    assert isinstance(result.elts[0], ast.List)
    assert isinstance(result.elts[1], ast.Call)
    assert result.elts[1].func.id == "list"
    assert result.elts[1].args == elts[1].value


# Generated at 2022-06-21 17:59:30.813110
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:34.963302
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert not transformer._has_starred([])
    assert transformer._has_starred([ast.Starred()])
    assert transformer._has_starred([ast.Num()])
    assert not transformer._has_starred([ast.Num(), ast.Num()])
    assert transformer._has_starred([ast.Num(), ast.Starred()])
    assert transformer._has_starred([ast.Starred(), ast.Num()])

    assert transformer._split_by_starred([]) == [[]]
    assert transformer._split_by_starred([ast.Num()]) == [[ast.Num()]]
    assert transformer._split_by_starred([ast.Num()]) == [[ast.Num()]]

# Generated at 2022-06-21 17:59:40.790257
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("""
        import random
        def run(n):
            print(random.randrange(n), *range(10))
    """)

    transformed = StarredUnpackingTransformer().visit(tree)

    # transformed = ast.dump(transformed)
    # print(transformed)



# Generated at 2022-06-21 17:59:45.886578
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(
        id='range', ctx=ast.Load())), ast.Num(n=10)])
    assert str(node) == "[2, *range, 10]"

    node = StarredUnpackingTransformer().visit(node)
    assert str(node) == "[2] + list(range) + [10]"

# Generated at 2022-06-21 17:59:55.577812
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = ast.parse("[2, *range(10), 1]")
    y = ast.fix_missing_locations(x)
    transformer = StarredUnpackingTransformer()
    transformer.visit(y)
    assert type(y) == ast.Module
    body = y.body[0]
    assert type(body) == ast.Expr
    value = body.value
    assert type(value) == ast.BinOp
    assert type(value.left) == ast.BinOp
    assert type(value.right) == ast.List
    assert len(value.right.elts) == 1


# Generated at 2022-06-21 18:00:06.232566
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = ['[2, *range(10), 1]',
            '[2, *range(10), 1, *range(100)]']
    expected = ['[2] + list(range(10)) + [1]',
                '[2] + list(range(10)) + [1] + list(range(100))']
    
    actual = [StarredUnpackingTransformer().visit(ast.parse(code)) for code in code]
    actual = [ast.fix_missing_locations(node).body[0].value for node in actual]
    actual = [ast.unparse(node) for node in actual]
    
    assert actual == expected


# Generated at 2022-06-21 18:00:15.265317
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import opensource
    from .base import BaseASTNodeTransformerTester

    unittest_data = [(
        'l = [2, *range(10), 1]',
        'l = [2] + list(range(10)) + [1]',
    )]

    for code_before, code_after in unittest_data:
        tester = BaseASTNodeTransformerTester(
            code_before,
            code_after,
            StarredUnpackingTransformer,
            opensource=opensource)
        tester.run_tests()


# Generated at 2022-06-21 18:00:27.636491
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .vectorize_all_returns import VectorizeAllReturnsTransformer
    from .empty_parentheses import EmptyParenthesesTransformer
    from .list_comprehensions import ListComprehensionsTransformer
    from .surround_with_list import SurroundWithListTransformer
    from .multiple_unpacking_assignment import MultipleUnpackingAssignmentTransformer
    from .unpacking_assignment import UnpackingAssignmentTransformer
    from .for_loops import ForLoopsTransformer
    from .while_loops import WhileLoopsTransformer
    from .if_expressions import IfExpressionsTransformer
    from .starred_expression import StarredExpressionTransformer
    from .gather_all_returns import GatherAllReturnsTransformer
    from .gather_all_yields import GatherAllYieldsTransformer

    code

# Generated at 2022-06-21 18:00:30.341069
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Testing StarredUnpackingTransformer constructor")
    x = StarredUnpackingTransformer()
    print("Testing StarredUnpackingTransformer constructor")
    print(x)
    print("\n")
    

# Generated at 2022-06-21 18:00:35.401596
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    tree = transformer.visit(tree)
    assert tree.body[0].value.func.id == 'list'



# Generated at 2022-06-21 18:01:01.233530
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(ast.parse('[2, *range(10), 1]')) == ast.parse('[2] + list(range(10)) + [1]')


# Generated at 2022-06-21 18:01:09.053861
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('print(1, *range(4), 5, *range(4, 6), 7)') # type: ignore
    tree = transformer.visit(tree) # type: ignore
    assert tree.body[0].value.args[0].value.op.left.elts[0].n == 1
    assert tree.body[0].value.args[0].value.op.left.elts[1].value.func.id == 'range'
    assert tree.body[0].value.args[0].value.op.left.elts[2].n == 5
    assert tree.body[0].value.args[0].value.op.right.left.value.func.id == 'range'
    assert tree.body[0].value.args[0].value

# Generated at 2022-06-21 18:01:14.979743
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected_code = "[2] + list(range(10)) + [1]"
    ast_tree = ast.parse(code)
    StarredUnpackingTransformer().visit(ast_tree)
    assert astor.to_source(ast_tree) == expected_code


# Generated at 2022-06-21 18:01:22.237731
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    t._tree_changed = False
    t._has_starred([1,4,5,6,*range(4)])
    assert t._tree_changed == True
    t._split_by_starred([1,2,3,*range(3),*range(3)])


test_constructor = test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:30.187965
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test StarredUnpackingTransformer.visit_Call().
    # 1. Test with an Call without starred.
    node = ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Constant(value=1, kind=None)],
        keywords=[])
    unpacking_transformer = StarredUnpackingTransformer()
    new_node = unpacking_transformer.visit(node)

    assert not unpacking_transformer._tree_changed
    assert isinstance(new_node, ast.Call)

    # 2. Test with an Call with starred.

# Generated at 2022-06-21 18:01:39.804505
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    from .test_transformer_utils import parse, compare_source

    source = 'print(*range(1), *range(10))'
    node = parse(source)
    StarredUnpackingTransformer().visit(node)
    compare_source(node, 'print(*(list(range(1)) + list(range(10))))')

    source = 'print(*range(1), *range(10), sep=";")'
    node = parse(source)
    StarredUnpackingTransformer().visit(node)
    compare_source(node, 'print(*(list(range(1)) + list(range(10))), sep=";")')

    source = 'print(*range(1), *range(10), 1, sep=";")'
    node = parse(source)
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-21 18:01:44.825876
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = compile(code, '', 'eval')
    transformed = StarredUnpackingTransformer().visit(tree)
    assert type(transformed.body) == ast.BinOp
    assert type(transformed.body.left) == ast.List and type(transformed.body.right) == ast.List
    assert type(transformed.body.op) == ast.Add
    assert type(transformed.body.left.elts[1]) == ast.Call
    assert type(transformed.body.left.elts[1].func) == ast.Name


# Generated at 2022-06-21 18:01:55.657555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tests = [
        (
            """
            [2, *range(10), 1]
            """,
            """
            [2] + list(range(10)) + [1]
            """
        ),
        (
            """
            [
                2,
                *range(10),
                *range(5),
                1
            ]
            """,
            """
            [2] + list(range(10)) + list(range(5)) + [1]
            """
        ),
        (
            """
            [a, *b, c]
            """,
            """
            [a] + list(b) + [c]
            """
        ),
    ]

    for test_input, expected_output in tests:
        transformer = StarredUnpackingTransformer()
        input_ast = ast.parse

# Generated at 2022-06-21 18:02:02.672934
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import NodeTestCase
    from .constant_folding import ConstantFoldingTransformer

    code = """
    [2, *range(10), 1]
    """

    expected = """
    list([2]) + list(range(10)) + list([1])
    """

    NodeTestCase(
        StarredUnpackingTransformer(ConstantFoldingTransformer),
        code,
        expected).test()

# Generated at 2022-06-21 18:02:14.249241
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test for the method visit_Call of the class StarredUnpackingTransformer.
        Test for the conversion of a call to a print with a star unpacking.
    """
    from typed_ast import ast3
    from .visitor import ASTVisitor
    from .visitor import NodeTransformer
    from .visitor import TreeChanger
    from .starred_unpacking import StarredUnpackingTransformer
    from .visitor import NodeTransformer
    import ast

    # Code with the star unpacking
    code = ast.parse("print(*range(1, 4), *range(5, 7))")

    # Execute the transformation to the code
    StarredUnpackingTransformer().visit(code)

    # Compare the results
    assert(isinstance(code, ast.Module))
    assert(len(code.body) == 1)


# Generated at 2022-06-21 18:03:01.763285
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import assert_code_equal
    node = ast.parse('[1, 2, *range(10), 1]').body[0].value
    assert_code_equal(node, StarredUnpackingTransformer().visit(node))



# Generated at 2022-06-21 18:03:03.468028
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()
    assert StarredUnpackingTransformer().visit(ast.parse("[1, *[1, 2, 3]]"))

# Generated at 2022-06-21 18:03:13.553707
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    tree = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 18:03:26.042713
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import sys
    from .base import create_module
    module = create_module('import ast', '__main__')
    module.body.extend([ast.Expr(value=ast.List(elts=[ast.Num(n=4), ast.Starred(value=ast.Name(id='ast'))]))])
    module.body.extend([ast.Expr(value=ast.List(elts=[ast.Num(n=4)]))])
    StarredUnpackingTransformer.run_module(module)
    print(ast.dump(module))
    assert "ast" in str(module)
    assert "Starred" in str(module)
    with open("test.py", "w") as f:
        f.write(ast.dump(module))
    # import test.py
    import subprocess


# Generated at 2022-06-21 18:03:38.633100
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:44.605859
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('''[2, *range(10), 1]''')

    StarredUnpackingTransformer().visit(node)

    expected = ast.parse('''
list([2]) + list(range(10)) + list([1])
    ''')

    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-21 18:03:46.098805
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    o = StarredUnpackingTransformer()
    assert o is not None


# Generated at 2022-06-21 18:03:55.154038
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import astunparse

    source = '''
[2, *range(10), 1]
print(*range(1), *range(3))
    '''

    tree = ast.parse(source)
    expected_tree = ast.parse('''
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    ''')  # noqa

    tree = StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(expected_tree) == astunparse.unparse(tree)

# Generated at 2022-06-21 18:04:05.129427
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Simple test to see if the method visit_Call works."""
    node = ast.Call(
        func=ast.Name(id='test'),
        args=[ast.Num(n=1), ast.Starred(value=ast.Num(n=2)), ast.Num(n=3)],
        keywords=[])
    node2 = ast.Call(
        func=ast.Name(id='test'),
        args=[ast.List(elts=[])],
        keywords=[])
    node3 = ast.Call(
        func=ast.Name(id='test'),
        args=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)],
        keywords=[])

# Generated at 2022-06-21 18:04:06.402606
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer."""
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:05:48.992017
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .conftest import make_ast, assert_source

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    assert_source(expected, make_ast(code, StarredUnpackingTransformer))

    code = '[2, *range(10)]'
    expected = '[2] + list(range(10))'
    assert_source(expected, make_ast(code, StarredUnpackingTransformer))


# Generated at 2022-06-21 18:05:59.149891
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = dedent('''
        print(1, 2, 3)
        print(1, *[2, 3], 4)
        print(1, *range(3), 4)
    ''')
    expected = dedent('''
        print(1, 2, 3)
        print(*(list([2, 3]) + list([4])))
        print(*(list([1]) + list(range(3)) + list([4])))
    ''')

    tr = StarredUnpackingTransformer()
    tr.visit(ast.parse(source))
    assert expected == tr.output()


# Generated at 2022-06-21 18:06:00.265659
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:06:12.585608
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest.mock
    from contextlib import contextmanager

    @contextmanager
    def mock_imports(name: str, *args: str) -> None:
        from importlib import import_module
        with unittest.mock.patch('{}.__name__'.format(name)) as name_mock:
            name_mock.start()
            with unittest.mock.patch('{}.__getattr__'.format(name)) as _mock:
                def _import_mock(import_name: str) -> unittest.mock.Mock:
                    submodule = import_module(import_name)
                    return unittest.mock.Mock()

                _mock.side_effect = _import_mock
                yield


# Generated at 2022-06-21 18:06:19.958692
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astor.code_gen import to_source

    expected = 'list([1, 2, 3])'
    code = '[1, *(2, 3)]'
    tree = compile(code, '', 'exec', ast.PyCF_ONLY_AST)
    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(tree)
    actual = to_source(tree.body[0].value)
    assert actual == expected


# Generated at 2022-06-21 18:06:28.656465
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ast_tools.passes.unparser import Unparser
    from ast_tools.passes.transform import source_to_ast

    # Test 1
    source = "print(*range(1), *range(3))"
    expected_source = "print(*(list(range(1)) + list(range(3))))"

    ast_node = source_to_ast(source)
    StarredUnpackingTransformer().visit(ast_node)

    assert expected_source == Unparser(ast_node)

    # Test 2
    source = 'print(*range(1), 1)'
    expected_source = 'print(*(list(range(1)) + [1]))'

    ast_node = source_to_ast(source)
    StarredUnpackingTransformer().visit(ast_node)

    assert expected_source == Un

# Generated at 2022-06-21 18:06:36.784476
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor 
    from textwrap import dedent

    source = dedent('''
        print(*range(1), *range(5))
    ''')

    tree = astor.parse_file(source)
    tree = StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree).strip()

    expected = dedent('''
        print(*(list(range(1)) + list(range(5))))
    ''')

    assert result == expected



# Generated at 2022-06-21 18:06:39.075246
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == "StarredUnpackingTransformer"

# Generated at 2022-06-21 18:06:51.035909
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_tree = ast.parse(textwrap.dedent('''\
        def foo(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z):
            pass
        
        foo(1, *range(10), 2, *range(5), *range(8), 3, *range(3), *range(3))
    '''))

# Generated at 2022-06-21 18:06:58.005139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(1)],
                keywords=[])),
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(3)],
                keywords=[]))
        ],
        keywords=[]
    )

    node = StarredUnpackingTransformer().visit(tree)