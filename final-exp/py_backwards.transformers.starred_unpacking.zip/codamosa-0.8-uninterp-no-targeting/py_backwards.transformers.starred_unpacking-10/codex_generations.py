

# Generated at 2022-06-21 17:57:06.540443
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    c = ast.Call()
    c.func = ast.Name()
    c.func.id = "print"
    c.args = [ast.Num(n=1), ast.Num(n=2), ast.Starred(value=ast.List(elts=[ast.Num(n=3), ast.Num(n=4)]))]
    t.visit(c)
    assert t._tree_changed == True
    assert len(c.args) == 1
    assert isinstance(c.args[0], ast.Starred)
    assert isinstance(c.args[0].value, ast.BinOp)
    assert isinstance(c.args[0].value.left, ast.List)

# Generated at 2022-06-21 17:57:12.619837
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class NotStarredArg(ast.AST):
        pass

    class StarredArg(ast.AST):
        pass

    node = ast.Call()
    node.args = [NotStarredArg(), NotStarredArg(), NotStarredArg()]
    res = StarredUnpackingTransformer().visit_Call(node)
    assert res is node
    assert [type(arg) for arg in res.args] == [
        NotStarredArg, NotStarredArg, NotStarredArg
    ]

    node = ast.Call()
    node.args = [NotStarredArg(), NotStarredArg(), StarredArg()]
  

# Generated at 2022-06-21 17:57:14.104698
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import tests
    from . import StarredUnpackingTransformer

    tests.test_NodeTransformer(lambda: StarredUnpackingTransformer())

# Generated at 2022-06-21 17:57:15.541927
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star = StarredUnpackingTransformer()

# Generated at 2022-06-21 17:57:24.022884
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(2), 3)').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert node.value.args == [
        ast.Starred(
            value=ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(n=1)],
                keywords=[]
            )
        ),
        ast.Starred(
            value=ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(n=2)],
                keywords=[]
            )
        ),
        ast.Num(n=3)
    ]


# Generated at 2022-06-21 17:57:36.042778
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformer_utils import run_visitor_recursively
    source = "[2, *range(10), 1]"
    source_ast = ast.parse(source)

    assert StarredUnpackingTransformer().visit(source_ast) == ast.parse("[2] + list(range(10)) + [1]")
    assert StarredUnpackingTransformer().visit([1, *[2, *[3, *[4, *[5]]]]]) == \
        ast.List(elts=[1, 2, 3, 4, 5], ctx=ast.Load())

# Generated at 2022-06-21 17:57:40.854906
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import compile

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = compile(source, "<string>", "eval")
    StarredUnpackingTransformer().visit(tree)
    assert compile(expected, "<string>", "eval") == tree


# Generated at 2022-06-21 17:57:51.287850
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest
    import textwrap
    from typed_ast.ast3 import parse
    from typed_ast.exceptions import ASTError

    class StarredUnpackingTransformerTestCase(unittest.TestCase):
        def _run_test(self, original: str, expected: str):
            node = parse(textwrap.dedent(original))
            expected_node = parse(textwrap.dedent(expected))
            transformer = StarredUnpackingTransformer()
            transformer.visit(node)
            self.assertEqual(expected_node, node)
            # Print ast
            # print(node_repr(node))
            # The resulting AST node must be valid
            compiler.parse(node_repr(node))


# Generated at 2022-06-21 17:58:01.823260
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from textwrap import dedent
    from .test_base import BaseNodeTestCase
    from .test_utils import assert_source_equal


# Generated at 2022-06-21 17:58:06.340180
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    unpacker = StarredUnpackingTransformer()
    result = unpacker.visit(ast.parse('[1, *range(2), 3]').body[0])
    expected = ast.parse('[1] + list(range(2)) + [3]').body[0]
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 17:58:20.126504
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert ast.dump(StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]").body[0])) == \
           "Expr(value=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), " \
           "op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), " \
           "args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), " \
           "op=Add(), right=List(elts=[Num(n=1)], ctx=Load()))))"


# Generated at 2022-06-21 17:58:26.365017
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    py_source = '''
a = [1, 2, *range(3), 4, 5, *range(6)]
'''
    py_expected = '''
a = [1, 2] + list(range(3)) + [4, 5] + list(range(6))
'''
    assert StarredUnpackingTransformer().transform_source(py_source) == py_expected


# Generated at 2022-06-21 17:58:31.915281
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert str(StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer(), ast.parse('[2, 3]'))) == '[2, 3]'
    assert str(StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer(), ast.parse('[*range(10)]'))) == 'list(range(10))'
    assert str(StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer(), ast.parse('[2, *range(10), 1]'))) == '[2] + list(range(10)) + [1]'


# Generated at 2022-06-21 17:58:41.772014
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source_text = """
[2, *range(10), 1]
    """
    with open('temp.py', 'w') as f:
        f.write(source_text)
    with open('temp.py', 'r') as f:
        tree = ast.parse(f.read())
        t = StarredUnpackingTransformer()
        t.visit(tree)
        source_text_modified = compile(tree, '<ast>', 'exec')
        source_text_modified = source_text_modified.replace('\n', '')
        assert source_text_modified == '[2] + list(range(10)) + [1]'
        # removing temporary file
        os.remove('temp.py')


# Generated at 2022-06-21 17:58:42.677189
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:48.022504
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # !p = PythonTransformer(StarredUnpackingTransformer())
    p = StarredUnpackingTransformer()
    assert p.run(
        tree=ast.parse('[2, *range(10), 1]'),
        filename='<unknown>',
    ) == ast.parse('[2] + list(range(10)) + [1]')



# Generated at 2022-06-21 17:58:54.903323
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .tools import print_ast, parse_ast
    from .dummy_visitor import DummyVisitor
    import ast as py_ast
    import typing
    code = "print(*range(1), *range(3))"
    node = parse_ast(code)
    print_ast(node)
    visitor = StarredUnpackingTransformer()
    result = visitor.visit(node)
    visitor = DummyVisitor()
    visitor.visit(result)
    assert isinstance(result, py_ast.Call)
    if isinstance(result.args, typing.List):
        assert len(result.args) == 1

# Generated at 2022-06-21 17:59:06.393572
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import fix_missing_locations
    from . import parse

    tree = parse('print(*range(1), *range(2))')
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(tree)
    fix_missing_locations(transformed)

    assert isinstance(transformed.body[0].value, ast.Call)

    call = transformed.body[0].value
    assert len(call.args) == 1

    assert isinstance(call.args[0], ast.Starred)

    assert isinstance(call.args[0].value, ast.BinOp)
    assert isinstance(call.args[0].value.left, ast.Call)
    assert isinstance(call.args[0].value.right, ast.Call)

    left = call.args[0].value.left

# Generated at 2022-06-21 17:59:08.803217
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)

# Generated at 2022-06-21 17:59:11.420963
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

# Unit tests for the visit_List method of the StarredUnpackingTransformer class

# Generated at 2022-06-21 17:59:21.413203
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:31.527035
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .parser import parse_expr

    for src, expected in [
        ('[2, *range(10), 1]', '[2] + list(range(10)) + [1]'),
        ('[*[1, 2]]', 'list([1, 2])'),
        ('[1, *range(2), *range(3)]', '[1] + list(range(2)) + list(range(3))'),
        ('[1, *range(2), 3]', '[1] + list(range(2)) + [3]'),
    ]:
        assert StarredUnpackingTransformer().visit(parse_expr(src)) == parse_expr(expected)

# Generated at 2022-06-21 17:59:39.231392
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """ Unit test for StarredUnpackingTransformer class. """
    expr = ast.parse("[2, *range(10), 1]")
    assert isinstance(expr, ast.Module)
    assert len(expr.body) == 1
    assert isinstance(expr.body[0], ast.Expr)
    assert isinstance(expr.body[0].value, ast.List)
    expr = expr.body[0].value
    StarredUnpackingTransformer().visit(expr)
    assert isinstance(expr, ast.BinOp)
    assert isinstance(expr.left, ast.List)
    assert isinstance(expr.right, ast.BinOp)
    assert isinstance(expr.right.left, ast.Call)
    assert isinstance(expr.right.right, ast.List)

    expr = ast.parse

# Generated at 2022-06-21 17:59:44.932094
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
a = [2, *range(10), a]
    """.strip()
    source_compiled = StarredUnpackingTransformer().visit(
        ast.parse(source))
    expected_source = """
a = [2] + list(range(10)) + [a]
    """.strip()
    assert astor.to_source(source_compiled).strip() == expected_source



# Generated at 2022-06-21 17:59:56.531968
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer.__new__(StarredUnpackingTransformer) # type: ignore
    x = StarredUnpackingTransformer() # type: ignore

    assert obj
    assert x
    assert hasattr(obj, 'visit')
    assert hasattr(x, 'visit')
    assert hasattr(obj, 'generic_visit')
    assert hasattr(x, 'generic_visit')
    assert hasattr(obj, 'visit_List')
    assert hasattr(x, 'visit_List')
    assert hasattr(obj, 'visit_Call')
    assert hasattr(x, 'visit_Call')
    assert hasattr(obj, 'target')
    assert hasattr(x, 'target')
    assert obj.target == (3, 4)

# Generated at 2022-06-21 18:00:04.726855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*((list(range(1)) + list(range(3)))))")
    transformed_node = StarredUnpackingTransformer().visit(node)
    assert ast.dump(expected, annotate_fields=False, include_attributes=True) == ast.dump(transformed_node, annotate_fields=False, include_attributes=True)


# Generated at 2022-06-21 18:00:07.491054
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    d = {}
    assert d[id(StarredUnpackingTransformer)] == [
        'target',
        'visit_List',
        'visit_Call',
    ]

# Generated at 2022-06-21 18:00:12.522534
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class T(BaseNodeTransformer):
        def visit_arguments(self, node: ast.arguments) -> ast.arguments:
            pass

    obj = StarredUnpackingTransformer(T())
    assert isinstance(obj, StarredUnpackingTransformer)


# Generated at 2022-06-21 18:00:22.361551
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer"""
    from typed_ast import ast3
    from typed_ast import ast3 as ast
    node = ast3.parse('a = [2, *range(10), 1]')
    # typed_ast.ast3.parse() returns an AST object
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Assign)
    assert len(node.body[0].targets) == 1
    assert len(node.body[0].value.elts) == 3
    assert isinstance(node.body[0].value.elts[0], ast.Constant)
    assert isinstance(node.body[0].value.elts[1], ast.Starred)

# Generated at 2022-06-21 18:00:30.746808
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer(target=(3, 5))

    assert sut._split_by_starred([]) == []
    assert sut._split_by_starred([1]) == [[1]]
    assert sut._split_by_starred([1, *range(3)]) == [[1], ast.Starred(value=ast.Name(id='range')), [], [3]]
    assert sut._split_by_starred([1, *range(3), 1]) == [[1], ast.Starred(value=ast.Name(id='range')), [], [3], [1]]


# Generated at 2022-06-21 18:00:53.733546
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    t = StarredUnpackingTransformer()
    src = """
[2, *range(10), 1]
print(*range(1), *range(3), sep="\n")
"""
    tree = ast.parse(src)
    tree = t.visit(tree)
    print(astor.to_source(tree))
    assert t._tree_changed

# Generated at 2022-06-21 18:01:04.865616
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *iterable, 1]")
    result = transformer.visit(node)
    assert isinstance(result, ast.Module) and len(result.body) == 1
    assert isinstance(result.body[0].value, ast.BinOp)
    assert result.body[0].value.left.elts == [ast.Num(n=2)]
    assert isinstance(result.body[0].value.right, ast.BinOp)
    assert isinstance(result.body[0].value.right.left, ast.Call)
    assert isinstance(result.body[0].value.right.right, ast.List)
    assert result.body[0].value.right.left.func.id == 'list'



# Generated at 2022-06-21 18:01:16.951489
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    node = ast.List(
        elts=[
            ast.Constant(value=2),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
            ast.Constant(value=10),
            ast.Constant(value=1)
        ],
        ctx=ast.Load())
    expected = ast.List(
        elts=[
            ast.Constant(value=2),
            ast.Call(
                func=ast.Name(id='list'),
                args=[
                    ast.Name(id='range', ctx=ast.Load())
                ],
                keywords=[]),
            ast.Constant(value=10),
            ast.Constant(value=1)
        ],
        ctx=ast.Load())

# Generated at 2022-06-21 18:01:29.114572
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile3ast
    from . import optimize_ast

    def assert_transform(code:str, expected:str) -> None:
        module = compile3ast(code)
        assert optimize_ast(module, StarredUnpackingTransformer)

        new_module = compile3ast(expected)
        assert module == new_module

    assert_transform('[1, *range(10)]', '[1] + list(range(10))')
    assert_transform('[1, *range(10), 2]', '[1] + list(range(10)) + [2]')
    assert_transform('[1, *range(10), *range(5), 2]',
                     '[1] + list(range(10)) + list(range(5)) + [2]')

# Generated at 2022-06-21 18:01:39.049331
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer(None)
    assert isinstance(x, BaseNodeTransformer)
    assert x._has_starred([]) == False
    assert x._split_by_starred([]) == [[]]
    assert x._has_starred([ast.Starred(ast.Name('a'), ast.Load())]) == True
    assert x._split_by_starred([ast.Starred(ast.Name('a'), ast.Load())]) == [[], [ast.Starred(ast.Name('a'), ast.Load()), []],[]]
    assert isinstance(x._prepare_lists([]), list)
    assert isinstance(x._merge_lists([]), list)
    assert isinstance(x._to_sum_of_lists([]), list)

# Generated at 2022-06-21 18:01:51.331745
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from src.python_transpilers.transpilers.starred_unpacking_transformer import StarredUnpackingTransformer
    from src.python_transpilers.python_to_python_utils import compile_ast
    import python_transpilers.clean_ast as ast


# Generated at 2022-06-21 18:01:52.186801
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    o = StarredUnpackingTransformer()
    assert o is not None

# Generated at 2022-06-21 18:01:58.993123
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()

    new_tree = transformer.visit(tree)  # type: ignore
    assert transformer.is_changed()

    expected_tree = ast.parse('[2] + list(range(10)) + [1]')
    assert ast.dump(new_tree) == ast.dump(expected_tree)



# Generated at 2022-06-21 18:02:11.299921
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("print(*range(1), *range(3))")
    node_transformer = StarredUnpackingTransformer()
    tree_new = node_transformer.visit(tree)
    assert isinstance(tree_new, ast.Module)
    body = tree_new.body
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[0].value, ast.Call)
    args = body[0].value.args
    assert isinstance(args, list)
    assert isinstance(args[0], ast.Starred)
    assert isinstance(args[0].value, ast.BinOp)
    assert isinstance(args[0].value.left, ast.Call)
    assert isinstance(args[0].value.right, ast.Call)

# Generated at 2022-06-21 18:02:22.510610
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]", "<test>", "eval")
    tree_changed, tree = StarredUnpackingTransformer().visit(node, [])
    assert tree_changed
    assert ast.dump(tree) == "Expression(body=BinOp(left=BinOp(left=List(elts=[Num(n=2), Num(n=1)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=Call(func=Name(id='list', ctx=Load()), args=[], keywords=[]), op=Add()))"


# Generated at 2022-06-21 18:03:07.408014
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit tests for constructor of class StarredUnpackingTransformer"""
    class_object = StarredUnpackingTransformer()
    assert class_object._has_starred([ast.Starred(value=ast.Num(n=1)),
                                      ast.Num(n=2)])
    assert not class_object._has_starred([ast.Name(id="x"),
                                          ast.Name(id="y")])


# Generated at 2022-06-21 18:03:08.339280
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)



# Generated at 2022-06-21 18:03:13.212494
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor  # type: ignore
    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == expected


# Generated at 2022-06-21 18:03:15.255910
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as ast
    class A:
        def __call__(self, *args):
            return args
    def f(a):
        return A()(*a)


# Generated at 2022-06-21 18:03:27.324774
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    test_code = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    [1, 2, 3]
    print(1, 2, 3)
    """
    res_code = """
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    [1, 2, 3]
    print(1, 2, 3)
    """
    tr = StarredUnpackingTransformer()
    tree_test = ast.parse(test_code)
    tree_res = ast.parse(res_code)
    tree_test = tr.visit(tree_test)
    assert tree_test == tree_res

# Generated at 2022-06-21 18:03:34.673976
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
[2, *range(10), 1]
'''
    expected = '''
[2] + list(range(10)) + [1]
'''
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)
    print(ast.unparse(tree))
    assert ast.unparse(tree) == expected


# Generated at 2022-06-21 18:03:41.578561
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    node = ast.parse('''
foo(**bar, *baz)
''')
    expected = ast.parse('''
foo(*(bar + list(baz)))
''')
    assert ast.dump(sut.visit(node.body[0]), annotate_fields=False) == ast.dump(expected.body[0], annotate_fields=False)


# Generated at 2022-06-21 18:03:47.609147
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_code = 'print(*range(1), *range(3))'
    expected_code = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(test_code)
    StarredUnpackingTransformer().visit(tree)
    tree_code = compile(tree, '<test>', 'exec')
    exec(tree_code)
    assert tree_code == compile(ast.parse(expected_code), '<test>', 'exec')

# Generated at 2022-06-21 18:03:49.929468
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-21 18:03:58.141472
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
x = [2, *range(10), 1]
"""

    # The source code above should be translated into the following AST.
    expected = ast.parse("""
x = [2] + list(range(10)) + [1]
""")

    # Assert that the transformation produces the expected AST.
    actual = StarredUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(actual, include_attributes=False) == ast.dump(expected, include_attributes=False)


# Generated at 2022-06-21 18:05:31.573547
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(textwrap.dedent("""\
        print(*range(1), *range(3), sep=' ', end='\n', file=sys.stdout, flush=False)
    """), filename='<ast>', mode='exec')
    assert isinstance(tree.body[0].value, ast.Call)
    x = StarredUnpackingTransformer()
    x.visit(tree)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.args[0], ast.Starred)
    assert isinstance(tree.body[0].value.args[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.args[0].value.right, ast.Call)

# Generated at 2022-06-21 18:05:43.973850
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import astunparse

    c = StarredUnpackingTransformer()
    source = ast.parse('[1, 2]')
    expected = ast.parse('[1, 2]')
    actual = c.visit(source)
    assert astunparse(expected) == astunparse(actual)

    c = StarredUnpackingTransformer()
    source = ast.parse('[1, 2, *range(5), 0]')
    expected = ast.parse('[1, 2] + list(range(5)) + [0]')
    actual = c.visit(source)
    assert astunparse(expected) == astunparse(actual)

    c = StarredUnpackingTransformer()
    source = ast.parse('[1, 2, *range(5), *range(3), 0]')


# Generated at 2022-06-21 18:05:55.610499
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .transformer import Transformer
    from .utils import dump_code

    dump_code(code="[2, *range(10), 1]", mode='exec')
    dump_code(code="print(*range(1), *range(3))", mode='exec')

    assert Transformer(StarredUnpackingTransformer).visit_module(
        ast.parse(mode='exec', body="[2, *range(10), 1]")
    ).body[0].value.value.left.func.id == 'list'

    assert Transformer(StarredUnpackingTransformer).visit_module(
        ast.parse(mode='exec', body="print(*range(1), *range(3))")
    ).body[0].value.func.value.left.value.value.id == 'range'

# Generated at 2022-06-21 18:06:07.487399
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as ast3
    tree = ast3.parse('''
print(*range(10), *range(1))
    ''')
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

# Generated at 2022-06-21 18:06:16.707040
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import compile_func
    from .to_binops import ToBinopsTransformer

    for code in [
        'print([2, *range(5)])',
        'print(-((5 * 4) / (3 + 2) - 1))',
        "print(*range(1), *range(2))",
        "print(*range(1), 3, *range(2))",
        "print(3, *range(1), -1, *range(2))",
    ]:
        expected_code = f'({code[6:]})'
        func = compile_func(code)
        StarredUnpackingTransformer().visit(func)
        ToBinopsTransformer().visit(func)
        assert expected_code == func.body[0].value.func.code.strip()

# Unit test

# Generated at 2022-06-21 18:06:19.286898
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .transformer_test_util import parse, round_trip_check, expect_equal_ast


# Generated at 2022-06-21 18:06:24.650382
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ex = '[1, 2, *[3, 4, 5], 6]'
    expected = "[1, 2, 3, 4, 5, 6]"

    t = StarredUnpackingTransformer()
    tree = ast.parse(ex)  # type: ast.AST
    assert str(tree) == ex
    t.visit(tree)
    assert str(tree) == expected



# Generated at 2022-06-21 18:06:29.847054
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_tree = ast.parse("""
    print(*range(1), *range(3))
    """)
    assert "*range(1)" in ast_to_src(ast_tree)
    transformer = StarredUnpackingTransformer().visit(ast_tree)
    assert "*range(1)" not in ast_to_src(transformer)
    assert "range(1), *range(3)" not in ast_to_src(transformer)
    assert "list(range(1)) + list(range(3))" in ast_to_src(transformer)


# Generated at 2022-06-21 18:06:41.774499
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse("print(*range(1), *range(3))")
    transform = StarredUnpackingTransformer()
    module_transform = transform.visit(module)
    assert isinstance(module_transform, ast.Module)
    assert isinstance(module_transform.body[0], ast.Expr)
    assert isinstance(module_transform.body[0].value, ast.Call)
    assert module_transform.body[0].value.func.id == 'print'
    assert isinstance(module_transform.body[0].value.args[0], ast.Starred)
    assert isinstance(module_transform.body[0].value.args[0].value, ast.BinOp)
    assert isinstance(module_transform.body[0].value.args[0].value.right, ast.List)
   

# Generated at 2022-06-21 18:06:52.531050
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert hasattr(StarredUnpackingTransformer, 'target')
    assert StarredUnpackingTransformer.target == (3, 4)
    assert hasattr(StarredUnpackingTransformer, '_has_starred')
    assert hasattr(StarredUnpackingTransformer, '_split_by_starred')
    assert hasattr(StarredUnpackingTransformer, '_prepare_lists')
    assert hasattr(StarredUnpackingTransformer, '_merge_lists')
    assert hasattr(StarredUnpackingTransformer, '_to_sum_of_lists')
    assert hasattr(StarredUnpackingTransformer, 'visit_List')
    assert hasattr(StarredUnpackingTransformer, 'visit_Call')