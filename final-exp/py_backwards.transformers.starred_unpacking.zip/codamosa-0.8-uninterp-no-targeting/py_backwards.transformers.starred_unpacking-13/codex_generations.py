

# Generated at 2022-06-21 17:57:11.219149
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import parse_ast
    from . import unparse

    node = parse_ast('''
        [2, *range(10), 1]
    ''')

    x = StarredUnpackingTransformer()
    result = x.visit(node)
    assert isinstance(result, ast.List)
    assert isinstance(result.elts[0], ast.Num)
    assert isinstance(result.elts[1], ast.Call)
    assert isinstance(result.elts[2], ast.Num)



# Generated at 2022-06-21 17:57:13.166427
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    n_t = StarredUnpackingTransformer()
    assert n_t.__class__.__name__ == "StarredUnpackingTransformer"


# Generated at 2022-06-21 17:57:19.242377
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("f(1, *range(5), 2, 3, *range(2), *[2, 3])")
    exp_tree = ast.parse("f(*(([1] + list(range(5)) + [2, 3]) + list(range(2)) + list([2, 3])))")
    assert StarredUnpackingTransformer.run(tree) == exp_tree


# Generated at 2022-06-21 17:57:31.352030
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star_dict_1 = {
        'target': (3, 4),
        '_has_starred': False,
        '_split_by_starred': [[]]
    }

    star_dict_2 = {
        'target': (3, 4),
        '_has_starred': False,
        '_split_by_starred': [[]]
    }

    try:
        assert isinstance(StarredUnpackingTransformer(**star_dict_1), BaseNodeTransformer), "star not instance of BaseNodeTransformer"
        print('StarredUnpackingTransformer is an instance of BaseNodeTransformer')
    except AssertionError as error:
        print(error)


# Generated at 2022-06-21 17:57:41.450412
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)

    assert isinstance(tree.body[0].value, ast.Call)
    call = tree.body[0].value

    assert call.func.id == 'print'
    assert len(call.args) == 1

    assert isinstance(call.args[0], ast.Starred)
    assert isinstance(call.args[0].value, ast.BinOp)
    assert isinstance(call.args[0].value.left, ast.List)
    assert len(call.args[0].value.left.elts) == 0
    assert isinstance(call.args[0].value.right, ast.Call)

# Generated at 2022-06-21 17:57:42.531329
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:57:53.412289
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from pprint import pprint
    from .ast_compare import compare_ast, TreeChanged

    s = "print(*range(1), *range(3))"  # Function call with two starred unpacking
    ast_original = compile(s, filename="<ast>", mode="exec", flags=ast.PyCF_ONLY_AST)
    ast_to_check = compile("print(*(list(range(1)) + list(range(3))))", filename="<ast>", mode="exec", flags=ast.PyCF_ONLY_AST)

    s = "print(*range(1), *range(3), **dict(x=1, y=2))"  # Function call with two starred unpacking and kwargs

# Generated at 2022-06-21 17:58:00.908956
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
    print(1, 2, *range(3), 4, *range(5, 8), 9)
    """

    expected = """
    print(*(list([1, 2]) + list(range(3)) + list([4]) + list(range(5, 8)) + list([9])))
    """

    node = ast.parse(code)
    transformed = StarredUnpackingTransformer().visit(node)
    assert_equal(dump_python_source(transformed), expected.strip())


# Generated at 2022-06-21 17:58:05.557303
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = '''
        print(*range(1), *range(3))
    '''
    another_code = ast.parse(code)
    StarredUnpackingTransformer().visit(another_code)
    exec(compile(another_code, filename="<ast>", mode="exec"))


# Generated at 2022-06-21 17:58:11.340393
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree1 = ast.parse('[2, *range(10), 1]')
    tree2 = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree1)
    StarredUnpackingTransformer().visit(tree2)

# Generated at 2022-06-21 17:58:28.090440
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer(None, None)
    # Test _has_starred
    assert not transformer._has_starred([])
    assert not transformer._has_starred([ast.Num(n=2)])
    assert transformer._has_starred([ast.Num(n=2),
                                     ast.Starred(value=ast.Name(id='a'))])

    # Test _split_by_starred
    assert transformer._split_by_starred([]) == []
    assert transformer._split_by_starred([ast.Num(n=2)]) == [[ast.Num(n=2)]]

# Generated at 2022-06-21 17:58:40.705537
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    mod = ast.parse(
        '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
        ''',
        '<test>')
    mod = StarredUnpackingTransformer().visit(mod)


# Generated at 2022-06-21 17:58:45.649298
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    StarredUnpackingTransformer.run_test(code, expected)

    code = 'print(*range(1))'
    expected = 'print(*list(range(1)))'
    StarredUnpackingTransformer.run_test(code, expected)



# Generated at 2022-06-21 17:58:53.800318
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    node = ast.parse('[1,2,3,*range(4),4]', mode='eval').body

    # When
    StarredUnpackingTransformer().visit(node)

    # Then
    assert ast.dump(node) == '[1, 2, 3, list(range(4)), 4]'

    # Given
    node = ast.parse('[1,2,3,*range(4),4,*range(5)]', mode='eval').body

    # When
    StarredUnpackingTransformer().visit(node)

    # Then
    assert ast.dump(node) == '[1, 2, 3, list(range(4)), 4, list(range(5))]'

    # Given
    node = ast.parse('[1,2,**{1:2}]', mode='eval').body

# Generated at 2022-06-21 17:59:02.975480
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input_code = """
        [2, *range(10), 1]
    """
    expected_code = """
        [2] + list(range(10)) + [1]
    """
    tree = ast.parse(input_code)
    tree = StarredUnpackingTransformer().visit(tree)
    code = compile(tree, '<test>', 'exec')
    ns = {}
    exec(code, ns)

    assert code == compile(expected_code, '<test>', 'exec')



# Generated at 2022-06-21 17:59:09.067790
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    caller = ast.parse("print(*range(1), *range(3))").body[0].value
    caller_expect = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0].value
    actual = StarredUnpackingTransformer().visit(caller)
    assert actual == caller_expect


# Generated at 2022-06-21 17:59:11.320818
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Do not remove this
StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:19.528139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = ast.Name(id='a')
    args = [ast.Call(func=a, args=[], keywords=[])]

    star = ast.Starred(value=a, ctx=ast.Load())
    args.append(star)

    call = ast.Call(func=a, args=args, keywords=[])
    trans = StarredUnpackingTransformer()
    node = trans.visit(call)
    assert isinstance(node.args[0], ast.Call)
    assert node.args[0].func.id == 'list'
    assert node.args[0].args[0] is a


# Generated at 2022-06-21 17:59:31.826431
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip, round_trip_unwrap_starred
    from .test_utils import round_trip_wrap_starred
    from .test_utils import compare_node

    # [1, 2, 3] or [1]
    node = ast.List(elts=[ast.Num(1), ast.Num(2), ast.Num(3)], ctx=ast.Load())
    node2 = ast.List(elts=[ast.Num(1)], ctx=ast.Load())
    round_trip(node, StarredUnpackingTransformer)
    round_trip(node2, StarredUnpackingTransformer)
    assert compare_node(round_trip(node, StarredUnpackingTransformer), node)

# Generated at 2022-06-21 17:59:38.162932
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    src = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    node = ast.parse(src)
    StarredUnpackingTransformer.run_fragment(node)
    result = format(node, 'eval')

    assert result == expected

# Generated at 2022-06-21 17:59:49.351405
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer("print(*range(1), *range(3))") == "print(*(list(range(1)) + list(range(3))))"
    assert StarredUnpackingTransformer("[2, *range(10), 1]") == "[2] + list(range(10)) + [1]"

# Generated at 2022-06-21 17:59:58.720794
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[1, 2, *range(10), *range(10), 2, 1]')
    StarredUnpackingTransformer().visit(tree)


# Generated at 2022-06-21 18:00:01.823038
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    input = 'print(*range(1), *range(3))'
    input_ast = astor.code_to_ast.parse_string(input)
    output_ast = StarredUnpackingTransformer().visit(input_ast)
    output = astor.to_source(output_ast)
    assert output == 'print(*(list(range(1)) + list(range(3))))\n'

# Generated at 2022-06-21 18:00:10.252514
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._has_starred([]) == False
    assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Num(n=1))]) == True
    assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Num(n=1)), ast.Num(n=1)]) == True
    assert StarredUnpackingTransformer._has_starred([ast.Num(n=1), ast.Num(n=1)]) == False
    assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Num(n=1)), ast.Num(n=1), ast.Num(n=1)]) == True

# Generated at 2022-06-21 18:00:14.774831
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_import_transformer import skip_unless_python3_and_typed_ast

    skip_unless_python3_and_typed_ast()

    import sys
    import typed_ast.ast3 as ast

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    root = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformed_node = transformer.visit(root)
    sys.stdout.write(ast.fix_missing_locations(transformed_node).body[0].value.left.right.func.id)


# Generated at 2022-06-21 18:00:23.679604
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = "[2, *range(10), 1]"
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)], ctx=Load()), op=Add()))])"

# Generated at 2022-06-21 18:00:24.278274
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-21 18:00:30.588567
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_code = 'print(1, 2, *range(3), 4)'
    t = StarredUnpackingTransformer()
    tree = ast.parse(input_code)
    t.visit(tree)
    result = ast.fix_missing_locations(tree)
    output_code = compile(result, 'test.py', 'exec')
    ns = dict()
    exec(output_code, ns)
    assert ns['__builtins__'].print(1, 2, 0, 1, 2, 4) is None


# Generated at 2022-06-21 18:00:38.481695
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    root = ast.parse("[2, *range(10), 1]", mode="exec")
    StarredUnpackingTransformer().visit(root)

    expected_root = ast.parse(
        "[2] + list(range(10)) + [1]", mode="exec")
    ast.fix_missing_locations(expected_root)
    assert ast.dump(root) == ast.dump(expected_root)



# Generated at 2022-06-21 18:00:48.380636
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import CompileError

    class MockNodeTransformer(StarredUnpackingTransformer):
        tree_changed = False

    node = ast.parse('print(*range(1), *range(3))')
    assert ast.dump(node) == "Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=Call(func=Name(id='range', ctx=Load()), args=[Num(n=1)], keywords=[])), Starred(value=Call(func=Name(id='range', ctx=Load()), args=[Num(n=3)], keywords=[]))], keywords=[]))"
    node_transformer = MockNodeTransformer()
    node_transformer.visit(node)

# Generated at 2022-06-21 18:00:57.860729
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'
    expected_code = 'print(*(list(range(1)) + list(range(3))))'
    transform_test_utils.check_on_transform(StarredUnpackingTransformer, code, expected_code)


# Generated at 2022-06-21 18:01:01.788296
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'f(*range(3))'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    expected = """
    f(*(list(range(3))))
    """
    compare_source(expected, tree)


# Generated at 2022-06-21 18:01:05.351917
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None)._has_starred([])
    assert StarredUnpackingTransformer(None)._has_starred([None])



# Unit tests for the _split_by_starred method

# Generated at 2022-06-21 18:01:17.381446
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
   # Initial input
   lst = ast.parse("[2, *range(10), 1]")
   assert isinstance(lst, ast.Module)
   star_unpacking_transformer = StarredUnpackingTransformer()
   assert isinstance(star_unpacking_transformer, BaseNodeTransformer)

   # Returned from parent class
   if not star_unpacking_transformer._has_starred(lst.body[0].value.elts):
       assert isinstance(star_unpacking_transformer.generic_visit(lst), ast.Module)

   # Returned from method visit_List

# Generated at 2022-06-21 18:01:24.891356
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import parse_to_ast
    from .utils import dump_ast

    transform = StarredUnpackingTransformer()
    node = parse_to_ast("[2, *range(10), 1]")

    assert dump_ast(node) == "[2, *range(10), 1]"
    transform.visit(node)
    assert dump_ast(node) == "[2] + list(range(10)) + [1]"



# Generated at 2022-06-21 18:01:27.013586
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-21 18:01:33.091980
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))')
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    call_node = node.body[0]
    assert isinstance(call_node, ast.Expr)
    assert isinstance(call_node.value, ast.Call)
    assert isinstance(call_node.value.args[0], ast.Starred)


# Generated at 2022-06-21 18:01:41.778963
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = (
        'A = [2, *range(10), 1]\n'
        'B = [2, *range(10), 1]\n'
        'C = [2, *range(10), 1]\n'
        'D = [2, *range(10), 1]\n'
    )
    expected = (
        'A = [2] + list(range(10)) + [1]\n'
        'B = [2] + list(range(10)) + [1]\n'
        'C = [2] + list(range(10)) + [1]\n'
        'D = [2] + list(range(10)) + [1]\n'
    )
    assert StarredUnpackingTransformer(src).result == expected



# Generated at 2022-06-21 18:01:48.920386
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = "[1, 2, 3, *range(4), 5, 6]"
    result = StarredUnpackingTransformer().visit(ast.parse(x))
    expected = "[1, 2, 3] + list(range(4)) + [5, 6]"
    assert ast.dump(result) == ast.dump(ast.parse(expected))


# Generated at 2022-06-21 18:01:54.682692
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    code = """
print(1, *range(2), 3)
"""
    expected = """
print(*(list([1]) + list(range(2)) + list([3])))
"""

    # Action & Assertion
    t = StarredUnpackingTransformer()
    assert expected == t.visit(ast.parse(code)).body[0].print()


# Generated at 2022-06-21 18:02:06.044537
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:02:07.468800
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:18.580794
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_1_1 = ast.Num(n=2)
    node_1_2 = ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))
    node_1_3 = ast.Num(n=1)
    node_1 = ast.List(elts=[node_1_1, node_1_2, node_1_3])
    expected_1_1 = ast.BinOp(left=ast.Name(id='range', ctx=ast.Load()),
                             right=ast.List(elts=[], ctx=ast.Load()),
                             op=ast.Add())

# Generated at 2022-06-21 18:02:23.125388
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    b = StarredUnpackingTransformer()
    assert b.run_visit_test(ast.parse("[2, *range(10), 1]"), ast.parse("[2] + list(range(10)) + [1]")) == True
    

# Generated at 2022-06-21 18:02:28.159259
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arrange
    node = ast.parse('print(*range(1), *range(3))')
    expected_result = 'print(*(list(range(1)) + list(range(3))))'
    # Act
    result = StarredUnpackingTransformer().visit(node)
    # Assert
    assert compile(result, '', mode='exec').co_consts[0] == expected_result


# Generated at 2022-06-21 18:02:41.742829
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    input1 = ast3.parse("f(1, 2, *g(), 3, *h(), 4)")
    input2 = ast3.parse("f(*g(), *h(), 1, 2, 3, 4)")
    input3 = ast3.parse("f(1, 2, *g(), 3, *h(), 4, *i())")
    input4 = ast3.parse("f(*g(), *h(), *i(), 1, 2, 3, 4)")
    expected1 = ast3.parse("f(*(list(g()) + list(h()) + [1, 2, 3, 4]))")
    expected2 = ast3.parse("f(*(list(g()) + list(h()) + [1, 2, 3, 4]))")

# Generated at 2022-06-21 18:02:44.991096
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3

    StarredUnpackingTransformer().visit(ast3.parse('''
[2, *range(10), 1]
print(*range(1), *range(3))
'''))

# Generated at 2022-06-21 18:02:48.018487
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-21 18:02:50.501753
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructure of class StarredUnpackingTransformer
    """
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:56.424787
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    code = "[2, *range(3), 1]"
    expected_code = "([2] + list(range(3)) + [1])"
    # Act
    t = StarredUnpackingTransformer()
    t.visit(ast.parse(code))
    actual_code = astor.to_source(t.transformed_tree)
    # Assert
    assert actual_code == expected_code



# Generated at 2022-06-21 18:03:16.542057
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:28.048334
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    _source = '''
[2, *range(10), *range(10), 1]
    '''
    expr = ast.parse(_source).body[0].value
    result = StarredUnpackingTransformer.run_on(expr)

# Generated at 2022-06-21 18:03:36.432166
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse('print(*range(1), *range(4), 6, 7)')
    StarredUnpackingTransformer().visit(tree)

    assert ast.dump(tree, annotate_fields=False, include_attributes=False) == dedent('''\
        print(*(list(range(1)) + list(range(4)) + [6] + [7]))
        ''')



# Generated at 2022-06-21 18:03:47.086735
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_ast = ast.List(elts=[ast.Num(n=2),
                         ast.Starred(value=ast.Call(
                             func=ast.Name(id='range'),
                             args=[ast.Num(n=10)],
                             keywords=[],
                             starargs=None,
                             kwargs=None)),
                         ast.Num(n=1)])

    test_ast.lineno = 1
    test_ast.col_offset = 1


# Generated at 2022-06-21 18:03:57.443137
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformerTest
    from .base import UnitTestAutoConfigure

    class Test(BaseNodeTransformerTest, UnitTestAutoConfigure):

        transformer = StarredUnpackingTransformer
        targets = (3, 4)

        @property
        def source_data(self):
            source = '''
# target code
[2, *range(10), 1]
print(*range(1), *range(3))
'''
            expected = '''
# expected code
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
'''
            return (source, expected)

# Generated at 2022-06-21 18:04:06.182816
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNoChangeNodeTransformerTests
    from . import testutils
    from .base import generate_tests
    from .base import BaseNodeTransformerTests
    from .base import BaseBuiltinFunctionTransformerTests


    class StarredUnpackingTransformerTests(
        BaseNoChangeNodeTransformerTests,
        BaseNodeTransformerTests
    ):
        transformer = StarredUnpackingTransformer
        transform_function = staticmethod(
            StarredUnpackingTransformer.run)

        files_to_test = (
            'list_starred.py',
            'list_starred_example.py'
        )

    generate_tests(StarredUnpackingTransformerTests)

if __name__ == '__main__':
    testutils.run_tests()

# Generated at 2022-06-21 18:04:12.734081
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    compile_tree = ast.parse('a([*range(10), 2, 3])')
    expected_tree = ast.parse('a(list(range(10)) + [2, 3])')
    actual_tree = StarredUnpackingTransformer().visit(compile_tree)
    assert ast.dump(actual_tree) == ast.dump(expected_tree)


# Generated at 2022-06-21 18:04:21.619851
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    source = """
[2, *range(10), 1]
"""
    expected = """
[2] + list(range(10)) + [1]
"""
    tr = StarredUnpackingTransformer()
    tr.visit(ast.parse(source, '<test>', 'exec'))
    self = BaseNodeTransformerTestCase()
    self.assertNoDiff(expected, compile(tr.root, '<test>', 'exec'))
test_StarredUnpackingTransformer_visit_List.unittest = ['starred_unpacking']


# Generated at 2022-06-21 18:04:29.612402
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_list = [2, 3, "a"]
    test_node = ast.List(elts=test_list, ctx=ast.Load())
    expected_node = test_node.deep_copy()
    assert StarredUnpackingTransformer().visit(test_node) == expected_node

    test_list = [2, 3, ast.Starred(value=ast.Name(id="b", ctx=ast.Load()))]
    test_node = ast.List(elts=test_list, ctx=ast.Load())

# Generated at 2022-06-21 18:04:30.266049
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)

# Generated at 2022-06-21 18:05:18.478049
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = ast.parse("[2, *range(10), 1]")
    print("--------------------")
    for node in a.body:
        node1 = StarredUnpackingTransformer().visit(node)
        print(node1)
        print("--------------------")

    b = ast.parse("print(*range(1), *range(3))")
    for node in b.body:
        node1 = StarredUnpackingTransformer().visit(node)
        print(node1)
        print("--------------------")

# Generated at 2022-06-21 18:05:22.918533
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("f(1, 2, *range(3))")
    visitor = StarredUnpackingTransformer()
    node = visitor.visit(node)

    assert str(node) == "f(*(list([1]) + list([2, 3])))"


# Generated at 2022-06-21 18:05:30.722419
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_astunparse
    t = StarredUnpackingTransformer()
    expected = typed_astunparse.unparse(ast.parse(r"""
range(1, *[2, 3])
    """)).strip()
    actual = typed_astunparse.unparse(t.visit(ast.parse(r"""
range(1, *[2, 3])
    """).body[0])).strip()
    assert expected == actual
    print('passed 1')

    expected = typed_astunparse.unparse(ast.parse(r"""
a = 1
b = 2
range(1, *f(a, *g(), c=b, *[2, 3], **{'a': 1}))
    """)).strip()

# Generated at 2022-06-21 18:05:31.973285
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()



# Generated at 2022-06-21 18:05:35.924119
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """\
[2, *range(10), 1]
print(*range(1), *range(3))
"""
    expected = """\
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
"""
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert astunparse.unparse(node) == expected

# Generated at 2022-06-21 18:05:47.184684
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    node = ast.Call()
    node.args = [ast.Starred(value=ast.Name(id='x')),
                  ast.List(elts=[ast.Num(n=1),
                                 ast.Num(n=2),
                                 ast.Starred(value=ast.Name(id='y')),
                                 ast.Num(n=4),
                                 ast.Num(n=5)
                                 ])]

    # When
    c = StarredUnpackingTransformer()
    result = c.visit_Call(node)

# Generated at 2022-06-21 18:05:55.211920
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class Test(object):
        def __init__(self):
            self.tree_changed = False
            self.result = None
        def visit_List(self, node):
            return node
        def visit_Call(self, node):
            return node
    t = Test()
    node = ast.parse('[2, *range(10), 1]')
    s = StarredUnpackingTransformer(t)
    s.visit(node)
    t.tree_changed = True
    assert isinstance(t.result, ast.List)

# Generated at 2022-06-21 18:06:07.243194
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .visitor.ast_node_visitor import ASTNodeVisitor

    _base_node_transformer = BaseNodeTransformer(target=(2, 3))
    _ast_node_visitor = ASTNodeVisitor()

    _StarredUnpackingTransformer = StarredUnpackingTransformer(_ast_node_visitor, _base_node_transformer)
    _StarredUnpackingTransformer.target = (2, 4)
    _StarredUnpackingTransformer._tree_changed = False


    # __init__ test
    assert _StarredUnpackingTransformer.target == (2, 4), 'StarredUnpackingTransformer.target != (2,4)'

# Generated at 2022-06-21 18:06:09.370012
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:06:17.097059
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3
    node = typed_ast.ast3.Call(func=typed_ast.ast3.Name(id='print', ctx=typed_ast.ast3.Load()),
                               args=[typed_ast.ast3.Starred(value=typed_ast.ast3.Name(id='range', ctx=typed_ast.ast3.Load()),
                                                            ctx=typed_ast.ast3.Load())],
                               keywords=[typed_ast.ast3.keyword(arg='end', value=typed_ast.ast3.Str(s='\n'))])
    StarredUnpackingTransformer(tree=node).visit(node)