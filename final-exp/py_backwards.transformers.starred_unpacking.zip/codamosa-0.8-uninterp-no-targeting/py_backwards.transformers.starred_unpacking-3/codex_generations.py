

# Generated at 2022-06-21 17:57:16.685568
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 4)._split_by_starred([]) == []

    assert StarredUnpackingTransformer(3, 4)._split_by_starred([ast.Name(id='a')]) == [[ast.Name(id='a')]]

    assert StarredUnpackingTransformer(3, 4)._split_by_starred([ast.Name(id='a'), ast.Starred(ast.Name(id='b'), ast.Load())]) == [[ast.Name(id='a')], ast.Starred(ast.Name(id='b'), ast.Load())]


# Generated at 2022-06-21 17:57:20.120472
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(),
                      StarredUnpackingTransformer)

# Testing if the tree_changed flag is updated properly

# Generated at 2022-06-21 17:57:27.824921
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse

    code = '[2, *range(10), 1]'
    tree = parse(code)
    StarredUnpackingTransformer.run_transform(tree)

    assert code in tree.body[0].value
    assert '+' in tree.body[0].value
    assert 'list' in tree.body[0].value
    assert 'range' in tree.body[0].value
    assert '10' in tree.body[0].value


# Generated at 2022-06-21 17:57:38.597740
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test = StarredUnpackingTransformer()
    try:
        import astor
    except ImportError:
        astor = None


# Generated at 2022-06-21 17:57:50.258181
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def run(code):
        code_ast = ast.parse(dedent(code))
        StarredUnpackingTransformer().visit(code_ast)
        return code_ast

    assert run('''
        foo(1, 2, 3)
    ''') == ast.parse('''
        foo(1, 2, 3)
    ''')

    assert run('''
        foo(1, 2, 3, *[9, 8, 7])
    ''') == ast.parse('''
        foo(*(list([1, 2, 3]) + list([9, 8, 7])))
    ''')


# Generated at 2022-06-21 17:57:54.644366
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(node)

    assert node.body[0].value.args[0].value.args[0].func.id == 'list'


# Generated at 2022-06-21 17:58:04.112662
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer"""
    from .utils import get_ast_of_source

    source = "[*range(10), *range(5), 1]"
    expected_source = "[] + list(range(10)) + list(range(5)) + [1]"

    with StarredUnpackingTransformer(compat=True) as pass1:
        ast_tree = get_ast_of_source(source)
        ast_tree = pass1.visit(ast_tree)

    with StarredUnpackingTransformer(compat=True) as pass2:
        expected_ast_tree = get_ast_of_source(expected_source)
        expected_ast_tree = pass2.visit(expected_ast_tree)


# Generated at 2022-06-21 17:58:13.692987
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    p = StarredUnpackingTransformer()
    d = ast.Call(func=ast.Name(id='f'),
                 args=[ast.Starred(
                     value=ast.List(elts=[ast.Name(id='x')])),
                       ast.Starred(
                           value=ast.List(elts=[ast.Name(id='y')]))],
                 keywords=[])
    p.visit(d)
    assert str(p.result) == 'f(*(x + y),)'



# Generated at 2022-06-21 17:58:20.609230
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sut = StarredUnpackingTransformer()
    assert sut.visit(ast.parse('[2, *range(10), 1]')) == ast.parse('[2] + list(range(10)) + [1]')
    assert sut.visit(ast.parse('[*range(10)]')) == ast.parse('list(range(10))')
    assert sut.visit(ast.parse('[*range(10), 1]')) == ast.parse('list(range(10)) + [1]')
    assert sut.visit(ast.parse('[2, *range(10)]')) == ast.parse('[2] + list(range(10))')


# Generated at 2022-06-21 17:58:28.644698
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_node = ast.parse('print(*range(1), *range(3))')
    x = StarredUnpackingTransformer()
    x.visit_Call(ast_node.body[0].value)
    assert ast_node.body[0].value.args == [ast.Starred(value=ast.Call(func=ast.Name(id='list'),
                                                  args=[ast.Call(func=ast.Name(id='range'),
                                                                 args=[ast.Num(n=1)], keywords=[])],
                                                  keywords=[]))]


# Generated at 2022-06-21 17:58:36.528922
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    StarredUnpackingTransformer().visit(
        ast.parse('[2, *range(10), 1]')) == ast.parse(
        '[2] + list(range(10)) + [1]')


# Generated at 2022-06-21 17:58:37.422596
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x

# Generated at 2022-06-21 17:58:46.615059
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = ast.parse('[2, *range(10), 1]')
    y = StarredUnpackingTransformer().visit(x)
    assert isinstance(y, ast.Call)
    assert isinstance(y.func, ast.Name) and y.func.id == 'list'
    assert isinstance(y.args[0], ast.BinOp)
    assert isinstance(y.args[0].left, ast.List) and y.args[0].left.elts == [ast.Num(n=2)]
    assert isinstance(y.args[0].right, ast.List) and y.args[0].right.elts == [ast.Num(n=1)]
    assert isinstance(y.args[0].op, ast.Add)

# Generated at 2022-06-21 17:58:51.719055
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star_unpack = StarredUnpackingTransformer()
    def f(x):
        l = [1, *x, 2]
        l = [(1, *x, 2), (x, *l)]
        return [*[None], *l, *x]
    
    star_unpack.visit(ast.parse(f.__code__).body[0])
    assert star_unpack._tree_changed

# Generated at 2022-06-21 17:58:56.916372
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    
    try:
        StarredUnpackingTransformer()
    except (TypeError, SyntaxError):
        pass
    else:
        assert False, "Expected error not raised"



# Generated at 2022-06-21 17:59:02.617611
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    init = ast.parse(dedent((
        'f(*l, 0)'
    )))
    expected = ast.parse(dedent((
        'f(*(list(l) + [0]))'
    )))
    result = StarredUnpackingTransformer().visit(init)
    assert ast.dump(expected) == ast.dump(result)



# Generated at 2022-06-21 17:59:11.706404
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class StarredUnpackingTransformer_visit_Call(StarredUnpackingTransformer):
        def generic_visit(self, node):
            return node
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer_visit_Call().visit(tree).body[0].value.args[0].value.value.value.value.elts[0].value.value.value.value.func.value[0].value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.value.func.id
    StarredUnpackingTransformer_visit

# Generated at 2022-06-21 17:59:12.428484
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass


# Generated at 2022-06-21 17:59:14.291331
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:20.622951
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('b.foo(1, 2, *[3, 4], 5, *[6, 7], 8, 9, **{3: 4}, 10, 11)')
    expected = ast.parse('b.foo(*(list([1, 2]) + list([3, 4]) + [5] + list([6, 7]) + [8, 9]), **{3: 4}, 10, 11)')

    node = StarredUnpackingTransformer().visit(node)

    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-21 17:59:35.291411
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .unit_test_helpers import make_call, get_ast_from_expr
    from .test_dict_to_kwargs_transformer import test_DictToKwargsTransformer_visit_Call as make_call2
    code = 'max([1, *range(2), 3, *range(4)], *range(5))'
    tree = get_ast_from_expr(code)
    StarredUnpackingTransformer().visit(tree)
    assert make_call(tree) == make_call2('max(*(([1] + list(range(2)) + [3] + list(range(4))) + list(range(5))))')
    code = 'max([1, *range(2), 3, *range(4)] + list(range(5)))'
    tree = get_ast_from_

# Generated at 2022-06-21 17:59:40.646285
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10)]", mode="eval")
    new_node = transformer.visit(node)
    assert ast.dump(new_node) == "Num(n=2) + list(range(10))"


# Generated at 2022-06-21 17:59:43.921051
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tests = [
        ('[2, *range(10), 1]', '[2] + list(range(10)) + [1]'),
    ]
    test_factory(StarredUnpackingTransformer, tests)


# Generated at 2022-06-21 17:59:55.971996
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Visitor(ast.NodeVisitor):
        def visit_BinOp(self, node):
            return node

    code = '[2, *range(10), 1]'
    tree = ast.parse(code)
    StarredUnpackingTransformer.run_with_visitor(code, 'exec')
    transformer = StarredUnpackingTransformer(code, 'exec')
    transformer.visit(tree)
    transformed = Visitor().visit(transformer.tree)
    assert transformed.left.elts == [node_factory('2')]
    assert transformed.left.elts == [node_factory('2')]
    assert transformed.right.func.id == 'list'
    assert transformed.right.args == [node_factory('1')]

# Generated at 2022-06-21 18:00:05.365770
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_tree = ast.parse("[2, *range(10), 1]")
    ast_tree_copy = copy.deepcopy(ast_tree)
    trans = StarredUnpackingTransformer()
    trans.visit(ast_tree)
    exec(compile(ast_tree_copy, "filename", mode="exec"), globals())
    exec(compile(ast_tree, "filename", mode="exec"), globals())
    assert eval(astor.to_source(ast_tree)) == eval(astor.to_source(ast_tree_copy))


# Generated at 2022-06-21 18:00:11.156347
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('''
[2, *range(10), 1]
print(*range(1), *range(3))
''')
    transformer.visit(node)
    print(ast.dump(node))



# Generated at 2022-06-21 18:00:21.417163
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    call = ast.Call(
        args=[
            ast.Name(id="a"),
            ast.Starred(
                value=ast.Name(id='b')
            )
        ],
        keywords=[]
    )
    visited = transformer.visit(call)
    expected = ast.Call(
        args=[
            ast.Starred(
                value=ast.Call(
                    args=[
                        ast.Name(id='b')
                    ],
                    keywords=[],
                    func=ast.Name(id='list')
                )
            )
        ],
        keywords=[]
    )
    assert visited == expected, f"Expected:\n{ast.dump(expected)}\nbut got:\n{ast.dump(visited)}"


# Generated at 2022-06-21 18:00:30.895564
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_transformer import transform, test_tree_changed
    from .test_transformer import should_raise, should_skip

    code_to_ast = lambda code: transform(code, StarredUnpackingTransformer)

    code_to_ast("print(1, 2, 3)")
    test_tree_changed(False)

    code_to_ast("print(1, *range(3), 2)")
    test_tree_changed(True)
    
    code_to_ast("print(*range(2), *range(1))")
    test_tree_changed(True)

    code_to_ast("print(*range(2), *[1])")
    test_tree_changed(True)

    should_raise(SyntaxError, code_to_ast, "print('test')")


# Generated at 2022-06-21 18:00:42.991831
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_1: ast.List = ast.parse('[2, *range(10), 1]', mode='eval').body
    node_2: ast.List = ast.parse('[2, 1]').body
    node_3: ast.List = ast.parse('[2, *range(10)]').body
    node_4: ast.List = ast.parse('[*range(10), 1]').body
    node_5: ast.List = ast.parse('[*range(10)]').body

    expected = ast.parse(
        '[2] + list(range(10)) + [1]', mode='eval').body

    r = StarredUnpackingTransformer()
    r.visit(node_1)
    assert r._tree_changed
    assert ast.dump(node_1) == ast.dump(expected)


# Generated at 2022-06-21 18:00:53.256727
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    node = ast.List(
        elts=[
            ast.Name(id='a', ctx=ast.Load()),
            ast.Starred(value=ast.Name(id='b', ctx=ast.Load()), ctx=ast.Load()),
            ast.Name(id='c', ctx=ast.Load())
        ],
        ctx=ast.Load())

    result = StarredUnpackingTransformer().visit(node)
    print (result)
    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.List)
    assert isinstance(result.right, ast.Call)
    assert isinstance(result.right.func, ast.Name)
    assert result.right.func.id == 'list'

# Generated at 2022-06-21 18:01:00.500880
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert str(transformer) == 'from version 3.4 transforms range arguments: print(*range(1), *range(3)) to print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-21 18:01:05.929043
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""
print(*range(1), *range(3))
""")  # type: ignore
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    expected = ast.parse("""
print(*(list(range(1)) + list(range(3))))
""")  # type: ignore
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 18:01:17.580004
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTest
    from .function import FunctionTransformer

    class WrapperTransformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__()
            self._function = FunctionTransformer()

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            node = self._function.visit(node)
            node = StarredUnpackingTransformer().visit(node)
            return node

    class Test(BaseNodeTransformerTest):
        transformer = WrapperTransformer()

        def test_simple(self):
            tree = self.parse("a = [1, *b, 2, *range(10), 1]")
            tree = self.transform(tree)

# Generated at 2022-06-21 18:01:18.509552
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t

# Generated at 2022-06-21 18:01:30.859594
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected_value = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)]),
                               op=ast.Add(),
                               right=ast.Call(func=ast.Name(id='list'),
                                              args=[ast.Call(func=ast.Name(id='range'),
                                                             args=[ast.Num(n=10)],
                                                             keywords=[])],
                                              keywords=[]))
    expected = ast.List(elts=[ast.Num(n=2),
                              ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                         args=[ast.Num(n=10)],
                                                         keywords=[])),
                              ast.Num(n=1)],
                        ctx=ast.Load())
   

# Generated at 2022-06-21 18:01:34.203400
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().name == 'StarredUnpackingTransformer'

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:41.503567
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    actual = StarredUnpackingTransformer().transform_source(source)
    assert expected == actual

    source = "[2, *range(10), 3, *range(10), 1]"
    expected = "[2] + list(range(10)) + [3] + list(range(10)) + [1]"
    actual = StarredUnpackingTransformer().transform_source(source)
    assert expected == actual


# Generated at 2022-06-21 18:01:45.316575
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        x = StarredUnpackingTransformer()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-21 18:01:56.170638
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .unit_test import run_transformer_test

    transformer = StarredUnpackingTransformer()

    run_transformer_test(transformer, """
        [2, *range(10), 1]
    """, """
        [2] + list(range(10)) + [1]
    """)

    run_transformer_test(transformer, """
        [2, *range(10), 1, 3, *range(3)]
    """, """
        [2] + list(range(10)) + [1, 3] + list(range(3))
    """)


# Generated at 2022-06-21 18:01:58.354507
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t.target == (3, 4)

# Generated at 2022-06-21 18:02:13.156088
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='print'),
                    args=[ast.List(elts=[ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                                    args=[ast.Num(n=1)],
                                                                    keywords=[])),
                                             ast.Starred(value=ast.Call(func=ast.Name(id='range'),
                                                                    args=[ast.Num(n=3)],
                                                                    keywords=[]))])],
                    keywords=[])

# Generated at 2022-06-21 18:02:15.148968
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

# Unit tests for this class

# Generated at 2022-06-21 18:02:17.372591
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """
    Test StarredUnpackingTransformer init.
    """
    transformer = StarredUnpackingTransformer()


# Generated at 2022-06-21 18:02:21.455087
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = ast.parse('''[2, *range(10), 1]''')
    y = ast.parse('''[2] + list(range(10)) + [1]''')
    assert StarredUnpackingTransformer().visit(x) == y



# Generated at 2022-06-21 18:02:26.845354
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = """someFunc(2 * 3, *range(10), 13)"""
    expected_output = """someFunc(*((2 * 3) + list(range(10)) + [13]))"""

    x = StarredUnpackingTransformer().visit(ast.parse(input))
    assert str(ast.dump(x)) == expected_output


# Generated at 2022-06-21 18:02:39.485208
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import get_node, get_node_source
    from .tree import PrintTransformer
    from .unpacking import UnpackingTransformer

    source = """
        [2, *range(10), 1]
        [2 * range(10)]
        []
        [2 * range(10), 1]
        [2, *range(10)]
    """
    expected = """
        [2] + list(range(10)) + [1]
        [2 * range(10)]
        []
        [2 * range(10)] + [1]
        [2] + list(range(10))
    """
    tree = get_node(source)
    tree = UnpackingTransformer().visit(tree)
    tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 18:02:44.256048
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestTransformer(StarredUnpackingTransformer):
        _tree_changed = False
    expected_result = ast.List(elts=[
        ast.Name(id='a'),
        ast.BinOp(left=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='b')], keywords=[]),
                  right=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='c')], keywords=[]),
                  op=ast.Add()),
        ast.Name(id='d')])
    result = TestTransformer().visit(ast.parse(
        '''
a = [1, *b, *c, 2]
''').body[0].value)
    TestTransformer._tree_changed == True
    ast.dump(result) == ast

# Generated at 2022-06-21 18:02:52.256909
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
print(*range(1), *range(2))
"""
    node = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)
    assert code_gen.to_source(node) == """
print(*(([*range(1)]) + ([*range(2)])))
"""


# Generated at 2022-06-21 18:03:01.469880
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    transformed_tree = transformer.visit(tree)

# Generated at 2022-06-21 18:03:03.938174
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    obj.__class__ == StarredUnpackingTransformer


# Generated at 2022-06-21 18:03:24.385019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astunparse import unparse

    s = "[2, *range(10), 1]"
    result = unparse(StarredUnpackingTransformer().visit(ast.parse(s)))
    assert result == "[2] + list(range(10)) + [1]"

    s = "[*range(10), *range(4)]"
    result = unparse(StarredUnpackingTransformer().visit(ast.parse(s)))
    assert result == "list(range(10)) + list(range(4))"

    s = "[2, *range(10), 1, *range(3)]"
    result = unparse(StarredUnpackingTransformer().visit(ast.parse(s)))
    assert result == "[2] + list(range(10)) + [1] + list(range(3))"


# Generated at 2022-06-21 18:03:29.107977
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .util import parse
    from .tree_utils import ast_to_obj

    code = '''
    [2, *range(10), 1]
    '''
    tree = parse(code)
    obj = ast_to_obj(tree)
    assert obj == [[2, 'range(10)', 1]]

# Generated at 2022-06-21 18:03:36.854086
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    >>> transformer = StarredUnpackingTransformer()
    >>> node = ast.parse('print(1, *range(10))')
    >>> changed = transformer.visit(node)
    >>> print(astunparse.unparse(changed))
        print(1, *(list(range(10))))
    >>> print(astunparse.unparse(node))
        print(1, *range(10))
    """
    pass

# Generated at 2022-06-21 18:03:40.295030
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    cases = [
        # [2, *range(10), 1]
        ast.parse('[2, *range(10), 1]', mode='eval'),
        # [2] + list(range(10)) + [1]
        ast.parse('[2] + list(range(10)) + [1]', mode='eval'),
    ]

    # When
    for case in cases:
        t = StarredUnpackingTransformer()
        t.visit(case)

    # Then
    for case in cases:
        assert ast.dump(cases[0]) == ast.dump(cases[1])



# Generated at 2022-06-21 18:03:46.093113
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(1), *range(3))', mode='eval')
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))', mode='eval')
    assert ast.dump(tree, include_attributes=False) == ast.dump(expected, include_attributes=False)


# Generated at 2022-06-21 18:03:52.089899
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    print()
    print(*range(5), *range(10))
    """
    expected = """
    print()
    print(*(list(range(5)) + list(range(10))))
    """
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-21 18:04:02.990080
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_tree_1 = ast.parse(textwrap.dedent('''
    print(1)
    [1, 2, 3]
    '''))
    StarredUnpackingTransformer(target=None).visit(test_tree_1)
    assert ast.dump(test_tree_1) == ast.dump(ast.parse(textwrap.dedent('''
    print(1)
    [1, 2, 3]
    ''')))

    test_tree_2 = ast.parse(textwrap.dedent('''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    '''))
    StarredUnpackingTransformer(target=None).visit(test_tree_2)

# Generated at 2022-06-21 18:04:07.008118
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(
        ast.parse('[2, *range(10), 1]')
    ).body[0].value.right.value.elts[0].id == 'range'


# Generated at 2022-06-21 18:04:18.576683
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
a = [1, 2, 3]
b = print(1, 2, 3)
c = print(*a)
d = print(*a, 1, 2, 3)
e = print(*a, 1, 2, 3, *a)
    """

    expected = """
a = [1, 2, 3]
b = print(1, 2, 3)
c = print(*list(a))
d = print(*(list(a) + [1, 2, 3]))
e = print(*(list(a) + [1, 2, 3] + list(a)))
    """

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    generated_code = astor.to_source(tree)
    assert expected == generated_code



# Generated at 2022-06-21 18:04:27.729573
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(elts=[
        ast.Num(n=2),
        ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[]),
        ast.Name(id='a'),
        ast.Num(n=1),
    ], ctx=ast.Load())

    result = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-21 18:04:45.869027
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import gast as ast

    tree = ast.parse("print(42, *range(1), *range(3))")
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(tree)

    expected_result = ast.parse("print(*[42]+list(range(1))+list(range(3)))")

    assert ast.dump(result) == ast.dump(expected_result)


# Generated at 2022-06-21 18:04:55.791855
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""
    transformer = StarredUnpackingTransformer()
    # Check that call with no starred nodes 
    # returns the same node
    node = ast.parse('[1, 2, 3]')
    assert transformer.visit(node) == node
    # Check that call with one starred node
    # returns sum of two lists
    node = ast.parse('[1, 2, *range(10)]')
    expected = ast.parse('[1, 2] + list(range(10))')
    assert transformer.visit(node) == expected
    # Check that call with two starred nodes
    # returns sum of three lists
    node = ast.parse('[1, *range(10), *range(5), 2]')

# Generated at 2022-06-21 18:05:02.094421
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.run_visitor_on_single_node(
        """
        [2, *range(10), 1]
        """,
        transform_non_top_level_nodes = True,
    ) == """
        [2] + list(range(10)) + [1]
        """.strip()


# Generated at 2022-06-21 18:05:13.476976
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import inspect
    import textwrap
    from typing import Any, Callable, List, Type
    from ast_tools.base import BaseNodeTransformer

    f_code = """
        def g():
            return [*range(3), *range(4), 5]
    """
    f_tree = ast.parse(textwrap.dedent(f_code))
    f_g = f_tree.body[0]
    f_return = f_g.body[0]
    g_return_test = isinstance(f_return.value, ast.Call)
    f_return_test = f_tree.body[0].body[0].value.func.id
    assert g_return_test and f_return_test == 'list'


# Generated at 2022-06-21 18:05:25.395218
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = "[2, *range(10), 1]"
    b = ast.parse(a, mode = 'eval')
    b_ = StarredUnpackingTransformer().visit(b)
    b_str = ast.dump(b_)

# Generated at 2022-06-21 18:05:35.866093
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test case 1
    input_string1 = """
[2, *range(10), 1]
print(*range(1), *range(3))
    """

    # Output of the test case 1
    output_string1 = """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """

    tree1 = ast.parse(input_string1)
    new_tree1 = StarredUnpackingTransformer().visit(tree1)
    assert ast.dump(new_tree1) == output_string1

    # Test case 2
    input_string2 = """
[2, *range(10), 1]
print(*range(1), *[4, *range(2), 3])
    """

    # Output of the test case 2
   

# Generated at 2022-06-21 18:05:47.118112
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    node = ast.parse(
        """
        print(*range(1), *range(3))
    """
    ).body[0]

    # When
    result = StarredUnpackingTransformer().visit(node)

    # Then
    assert isinstance(result, ast.Expr)
    assert isinstance(result.value, ast.Call)
    assert isinstance(result.value.func, ast.Name)
    assert result.value.func.id == 'print'
    assert len(result.value.args) == 1
    assert isinstance(result.value.args[0], ast.Starred)
    assert isinstance(result.value.args[0].value, ast.BinOp)
    assert isinstance(result.value.args[0].value.left, ast.Call)
    assert isinstance

# Generated at 2022-06-21 18:05:48.918353
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .test_helpers import get_ast, get_compiled_ast

    # [2, *range(10), 1]

# Generated at 2022-06-21 18:05:53.593215
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.__call__(  # type: ignore
        ast.parse('[2, *range(10), 1]')
    ) == ast.parse('[2] + list(range(10)) + [1]')



# Generated at 2022-06-21 18:06:05.565885
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node0 = ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Starred(value=ast.List(elts=[], ctx=ast.Load()), ctx=ast.Load())],
            keywords=[])
    tr0 = StarredUnpackingTransformer()
    assert tr0.visit(node0) == node0

    node1 = ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Name(id='*', ctx=ast.Load()), ast.Starred(value=ast.Name(id='range(2)', ctx=ast.Load()), ctx=ast.Load())],
            keywords=[])

# Generated at 2022-06-21 18:06:42.262842
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Regular case:
    stmt = ast.parse('[2, *range(10), 1]')
    expected = ast.parse('[2] + list(range(10)) + [1]')
    actual = StarredUnpackingTransformer().visit(stmt)
    assert expected.body[0].value.elts[1].left.func.id == actual.body[0].value.elts[1].left.func.id

    # Case with no starred expressions:
    stmt = ast.parse('[2, 10, 1]')
    expected = stmt
    actual = StarredUnpackingTransformer().visit(stmt)
    assert expected.body[0].value.elts[0].n == actual.body[0].value.elts[0].n

    # Case with no expressions:

# Generated at 2022-06-21 18:06:53.597026
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Test(ut.TestCase):
        def setUp(self) -> None:
            self.src = '''def f():
                x = [2, 3, 4]
                y = [1, *range(10), 2, 3, 4]
                z = list(range(10))
            '''

        def test_base(self):
            expected = '''def f():
                x = [2, 3, 4]
                y = [1] + list(range(10)) + [2, 3, 4]
                z = list(range(10))
            '''
            node = ast.parse(textwrap.dedent(self.src))
            StarredUnpackingTransformer().visit(node)
            actual = astor.to_source(node)
            self.assertEqual(expected, actual)

    ut

# Generated at 2022-06-21 18:07:03.286353
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import logging
    import unittest.mock as mock
    import astor
    x = StarredUnpackingTransformer(mock.MagicMock(), logging.DEBUG)
    code = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    expected = """
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    x.visit(tree)
    assert astor.to_source(tree) == expected