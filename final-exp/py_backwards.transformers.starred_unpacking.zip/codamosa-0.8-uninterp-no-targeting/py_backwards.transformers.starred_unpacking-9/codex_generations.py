

# Generated at 2022-06-21 17:57:08.846766
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class X:
        pass

    x = X()
    # Let's call constructor of the class
    StarredUnpackingTransformer(x)

# Generated at 2022-06-21 17:57:15.812981
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('Testing StarredUnpackingTransformer')
    builder = StarredUnpackingTransformer()
    builder.visit(ast.parse('[2, *range(10), 1]'))
    builder.visit(ast.parse('print(*range(1), *range(3))'))
    assert builder._tree_changed
    print('StarredUnpackingTransformer: OK')

# Generated at 2022-06-21 17:57:24.184625
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import sys
    import io
    import unittest

    class TestCase(unittest.TestCase):
        def test_scenario(self):
            # Given
            node_to_test = ast.parse(
                "my_list = [2, *range(10), 1]")

            expected = ast.parse(
                "my_list = [2] + list(range(10)) + [1]")

            # When
            tree_transformer = StarredUnpackingTransformer()
            tree_transformer.visit(node_to_test)
            actual = compile(
                node_to_test,
                filename='<ast>',
                mode='exec',
                dont_inherit=True)

            # Then

# Generated at 2022-06-21 17:57:29.000165
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = ast.parse('print(*range(1), *range(2))')
    expected = ast.parse('print(*(list(range(1)) + list(range(2))))')
    StarredUnpackingTransformer.run_test(input, expected)


# Generated at 2022-06-21 17:57:35.183992
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_source = """print(*range(1), *range(3))"""
    expected_result_source = """print(*(list(range(1)) + list(range(3))))"""
    tree = ast.parse(ast_source)
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(tree)
    assert str(result) == expected_result_source



# Generated at 2022-06-21 17:57:41.139054
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code = 'print(*range(1), *range(3))' # code to be compiled
    tree = ast.parse(code); # turn code into a tree
    tree = StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree) # tree back to code
    expected_result = 'print(*(list(range(1)) + list(range(3))))'
    print(result)
    assert result == expected_result

# Generated at 2022-06-21 17:57:46.948664
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[x, *y, z]"
    expected_code = "[x] + list(y) + [z]"

    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))



# Generated at 2022-06-21 17:57:48.272194
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from pprint import pprint


# Generated at 2022-06-21 17:57:52.895421
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    s = StarredUnpackingTransformer()
    tree = ast.parse(source, 'lala')
    tree2 = s.visit(tree)
    assert ast.dump(tree2) == expected



# Generated at 2022-06-21 17:57:58.981753
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('''
    [2, *range(10), 1]
    ''')
    expected = ast.parse('''
    [2] + list(range(10)) + [1]
    ''')

    transformer = StarredUnpackingTransformer()
    actual = transformer.visit(tree)
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-21 17:58:20.033866
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # First test
    node = ast.parse('[2, *range(10), 1]')
    expected_node = ast.parse('[2] + list(range(10)) + [1]')
    sut = StarredUnpackingTransformer()
    res = sut.visit(node)
    assert ast.dump(res) == ast.dump(expected_node)
    # Second test
    node = ast.parse('print(1, *range(10), 2)')
    expected_node = ast.parse('print(*(list(range(1)) + list(range(10)) + list(range(2))))')
    sut = StarredUnpackingTransformer()
    res = sut.visit(node)
    assert ast.dump(res) == ast.dump(expected_node)

# Generated at 2022-06-21 17:58:21.083998
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 17:58:27.703191
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer
    from .StarredUnpackingTransformer import StarredUnpackingTransformer
    input_source = "[2, *range(10), 1]"
    expected_output_source = "[2] + list(range(10)) + [1]"
    result = BaseNodeTransformer.compile_snippet(StarredUnpackingTransformer, input_source)
    assert result == expected_output_source


# Generated at 2022-06-21 17:58:40.421240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    xs = [2, *range(10), 1]  # type: List[int]
    [2, *range(10), 1]  # type: List[int]
    [2, *range(10), 1]  # type: List[int]

    source = ast.parse(inspect.getsource(xs)).body[0].value
    expected = ast.parse(inspect.getsource([2] + list(range(10)) + [1])).body[0].value

    transformer = StarredUnpackingTransformer()
    actual = transformer.visit(source)

    assert expected.left.elts == actual.left.elts
    assert expected.left.ctx == actual.left.ctx
    assert expected.right.func.id == actual.right.func.id

# Generated at 2022-06-21 17:58:48.749653
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .. import StarredUnpackingTransformer
    f = '''\
    [1, *range(5), *range(3, 7), 4]
    print(*range(10), 1, 'a', *'cde')
    test(*[1, 2, 3])
    test(*range(4), *range(5), *range(6))
    '''
    expected = '''\
    [1] + list(range(5)) + list(range(3, 7)) + [4]
    print(*(list(range(10)) + [1] + ['a'] + list('cde')))
    test(*[1, 2, 3])
    test(*(list(range(4)) + list(range(5)) + list(range(6))))
    '''
    t = StarredUnpackingTransformer()
    t

# Generated at 2022-06-21 17:58:55.415854
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast import parse, dump
    ast_node = parse('[1, 2, 3, 4, *range(0, 5, 1)]')
    expected_node = parse('[1, 2, 3, 4] + list(range(0, 5, 1))')

    trans = StarredUnpackingTransformer()
    trans.visit(ast_node)
    assert dump(ast_node) == dump(expected_node)



# Generated at 2022-06-21 17:59:06.444979
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .helpers import node_from_source
    from .formatting import ReformatCodeTransformer

    source = '''
        print(*range(1), *range(3))
        f(*range(1), *range(3))
    '''

    node = StarredUnpackingTransformer().visit(node_from_source(source))
    node = ReformatCodeTransformer().visit(node)
    node = ast.fix_missing_locations(node)
    expected = '''
        print(*(list(range(1)) + list(range(3))))
        f(*(list(range(1)) + list(range(3))))
    '''
    assert ast.dump(node) == ast.dump(node_from_source(expected))



# Generated at 2022-06-21 17:59:12.896757
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformations_util import expect_equal_asts
    ast_before = ast.parse("[2, *range(10), 1]")
    ast_after = ast.parse("[2] + list(range(10)) + [1]")
    expect_equal_asts(ast_after, StarredUnpackingTransformer().visit(ast_before))
    

# Generated at 2022-06-21 17:59:21.820243
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from ..helper import get_ast

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            code = 'print(*[1, *range(3), 2])'
            expected = 'print(*list([1] + list(range(3)) + [2]))'
            self.assertTransform(code, expected)

        def test_no_unpacking(self):
            code = 'print(1, *range(3), 2)'
            expected = 'print(1, *list(range(3)), 2)'
            self.assertTransform(code, expected)

        def test_nested(self):
            code = 'print(*[1, *[*range(3), 2]], 3)'

# Generated at 2022-06-21 17:59:33.678342
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""
    import astor

    class Visitor(ast.NodeVisitor):
        def __init__(self, transformer: StarredUnpackingTransformer, node: ast.AST):
            self.transformer = transformer
            self.node = node

        def visit(self):
            self.visit_list(self.node)

        def visit_list(self, node):
            self.generic_visit(self.transformer.visit(node))  # type: ignore

    class CallNode:
        def __call__(self, node):
            return ast.Call(func=ast.Name(id=self.__class__.__name__, ctx=ast.Load()), args=[node], keywords=[])


# Generated at 2022-06-21 17:59:55.715680
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    trans = StarredUnpackingTransformer()
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='range'))],
        keywords=[]
    )
    result = trans.visit_Call(node)
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.Call)
    assert isinstance(result.args[0].value.func, ast.Name)
    assert isinstance(result.args[0].value.func.id, str)
    assert result.args[0].value.func.id == 'list'

# Generated at 2022-06-21 18:00:07.990364
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Set up testing Node
    testNode = ast.List(elts = [ast.Num(n = 2),
                                ast.Starred(value = ast.Call(func = ast.Name(id = 'range'),
                                                             args = [ast.Num(n = 10)],
                                                             keywords = [])),
                                ast.Num(n = 1)])
    # Set up expected node

# Generated at 2022-06-21 18:00:17.483743
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import ast_converter
    from .assert_nodes import assert_nodes

    tree = ast_converter.parse_text('''
        [2, *range(10), 1]
        [2, *range(10), 1]
    ''')
    expected = ast_converter.parse_text('''
        [2] + list(range(10)) + [1]
        [2] + list(range(10)) + [1]
    ''')

    trans = StarredUnpackingTransformer()
    tree = trans.visit(tree)

    assert_nodes(tree, expected)



# Generated at 2022-06-21 18:00:28.010314
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = ast.parse("print(1, *range(2), 3, *range(4), 5)")
    print(ast.dump(StarredUnpackingTransformer().visit(a)))

# Generated at 2022-06-21 18:00:39.941677
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from node_test_helpers import (
        transform,
        node_is,
        node_of_class,
        node_is_of_type,
        node_is_type_instance,
    )
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, List, Name, Starred, Call, Num, Tuple
    transform(ast.parse("[2, *range(10), 1]"), StarredUnpackingTransformer)
    transform(ast.parse("print(*range(1), *range(3))"), StarredUnpackingTransformer)
    transform(ast.parse("[2, *(1,), 1]"), StarredUnpackingTransformer)
    transform(ast.parse("[*(1,), *(2,), 1]"), StarredUnpackingTransformer)

# Generated at 2022-06-21 18:00:48.050011
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_string = 'print(*range(1), *range(3))'
    correct_string = 'print(*(list(range(1)) + list(range(3))))'
    incorrect_string = 'print(*list(range(1)) + list(range(3)))'

    # If tree is not changed, NodeTransformer should just return the node
    node = ast.parse(input_string, mode='eval').body
    node = StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == incorrect_string

    # If tree is changed, NodeTransformer should return the changed node
    node = ast.parse(input_string, mode='eval').body
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == correct_string

# Generated at 2022-06-21 18:00:56.731727
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from string import ascii_lowercase as alphabet
    from .util import parse
    from .canonicalize import CanonicalizingTransformer

    code = """print(*range(2), 2, *range(10), 1, sep='.')"""
    expected_code = """print(*(([2] + list(range(10))) + [1]), sep='.')"""

    tree = parse(code)
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    tree = CanonicalizingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(parse(expected_code))



# Generated at 2022-06-21 18:01:04.485083
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor

    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    expected = dedent(expected).strip()

    source = """
print(*range(1), *range(3))
    """
    source = dedent(source).strip()
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    transformed = astor.to_source(tree)
    assert expected == transformed


# Generated at 2022-06-21 18:01:12.068007
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    unpack = StarredUnpackingTransformer()

    node = ast.parse("print(*range(1), *range(3))").body[0]
    node = unpack.visit(node)
    output = astor.to_source(node)
    expect = """print(*(list(range(1)) + list(range(3))))"""
    assert output == expect


# Generated at 2022-06-21 18:01:20.217662
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 18:01:38.266949
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(2, 3)

# Generated at 2022-06-21 18:01:41.864176
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    printer = StarredUnpackingTransformer()
    result = printer.visit(tree)
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 18:01:54.093149
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("""[2, *range(10), 1]""")
    comp = StarredUnpackingTransformer()
    new_tree = comp.visit(tree)
    res = ast.dump(new_tree)
    # print(res)
    assert res == 'Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(func=Call(func=Name(id=\'call\', ctx=Load()), args=[Name(id=\'range\', ctx=Load()), Num(n=10)], keywords=[]), args=[], keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))])'



# Generated at 2022-06-21 18:01:57.040161
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert 'print(*(list(range(1)) + list(range(3))))' == StarredUnpackingTransformer.compile('print(*range(1), *range(3))')



# Generated at 2022-06-21 18:01:58.895236
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:11.169551
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 18:02:18.481977
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """\
x = [2, *range(10)]
"""
    # This transforms:
    # x = [2, *range(10)]
    # To:
    # x = [2] + list(range(10))
    result = StarredUnpackingTransformer().run_pipeline(code)

    # This is the expected output from the transformation:
    expected = """\
x = [2] + list(range(10))
"""

    assert result == expected



# Generated at 2022-06-21 18:02:25.169999
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    src = ast.parse(source)
    tgt = ast.parse(expected)
    result = StarredUnpackingTransformer().visit(src)
    assert result.body[0].value.__repr__() == tgt.body[0].value.__repr__()


# Generated at 2022-06-21 18:02:27.191688
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    t = StarredUnpackingTransformer()
    assert isinstance(t, StarredUnpackingTransformer)


# Generated at 2022-06-21 18:02:29.473957
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:06.662961
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    if not test: pass
    else:
        # a placeholder for test code
        print(StarredUnpackingTransformer.__name__)

# Generated at 2022-06-21 18:03:11.822535
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BlackHoleVisitor
    from typed_ast import ast3 as ast

    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer(BlackHoleVisitor()).visit(tree)
    result = tree.body[0].value
    assert isinstance(result, ast.BinOp)



# Generated at 2022-06-21 18:03:14.497250
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    from typed_ast import ast3
    from .constant_folding import ConstantFoldingTransformer
    from .unused import UnusedAssignmentTransformer


# Generated at 2022-06-21 18:03:16.439700
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:26.004962
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    @pytest.mark.parametrize("list,expected", [
        ([], "[]"),
        (["1"], "[1]"),
        (["1", "*range(3)", "4"], "list({0}) + list({1})".format(
            "[1]",
            "[*range(3)] + [4]",
        )),
    ])
    def test(list, expected):
        tree = ast.parse("[" + ", ".join(map(str, list)) + "]")
        assert transformer.visit(tree) == ast.parse(expected).body[0]

    test()

# Generated at 2022-06-21 18:03:38.534982
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    decl = "[2, *range(10), 1]"
    decl_ast = ast.parse(decl)
    actual_ast = StarredUnpackingTransformer().visit(decl_ast)
    actual = astor.to_source(actual_ast)
    expected = "[2] + list(range(10)) + [1]"
    assert actual == expected

    decl = "[*range(10), 1]"
    decl_ast = ast.parse(decl)
    actual_ast = StarredUnpackingTransformer().visit(decl_ast)
    actual = astor.to_source(actual_ast)
    expected = "list(range(10)) + [1]"
    assert actual == expected

    decl = "[2, *range(10)]"
    decl_ast = ast.parse(decl)
    actual_ast

# Generated at 2022-06-21 18:03:48.294859
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .optimizer import optimize_ast
    from .recursive import RecursiveFunctionCallTransformer
    from .functions import FunctionCallTransformer
    from .transform import transform_tree
    import astor
    import ast


# Generated at 2022-06-21 18:04:00.251460
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astor.code_gen import to_source
    from .base import BaseNodeTransformer
    unpacking = StarredUnpackingTransformer()
    class MyTransformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__()
            self.unpacking = StarredUnpackingTransformer()
        def visit_List(self, node):
            node = self.unpacking.visit_List(node)
            node = self.generic_visit(node)
            return node
    my_transformer = MyTransformer()
    def test_case(input, expected):
        tree = ast.parse(input)
        transformed = my_transformer.visit(tree)
        source_transformed = to_source(transformed)
        assert source_transformed == expected

# Generated at 2022-06-21 18:04:07.705846
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast as pyast
    
    strings = [
        "foo()",
        "print(*range(3),*range(2))", # List of starred
        "foo(1, *range(3))", # Starred with args
        "[2, 3, *range(3), 4, 5]", # Multiple starred
        "foo(*range(3), 2)", # Starred with keywords
        "foo(1, *range(5), 4, *(5, 6, 7, 8), 9)"] # Unpacking
    
    for string in strings:
        node = pyast.parse(string).body[0]
        new_node = StarredUnpackingTransformer().visit(node)
        assert isinstance(new_node, pyast.AST)

# Generated at 2022-06-21 18:04:19.248627
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(n=0), ast.Starred(value=ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)], ctx=ast.Load()))],
        keywords=[]
    )
    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)], ctx=ast.Load())], keywords=[]))],
        keywords=[]
    )
    result = StarredUnpackingTransformer().vis

# Generated at 2022-06-21 18:05:36.757632
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert isinstance(x, StarredUnpackingTransformer)


# Generated at 2022-06-21 18:05:45.372568
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Tests that StarredUnpackingTransformer can convert:
        print(*list(range(1)), *range(3))
    To:
        print(*(list(range(1)) + list(range(3))))
    """
    import astor

    call = ast.parse('print(*list(range(1)), *range(3))').body[0]
    transformed = StarredUnpackingTransformer().visit(call)
    assert astor.to_source(transformed) == "print(*(list(range(1)) + list(range(3))))"


test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-21 18:05:50.672728
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from tartiflette import Resolver
    from tartiflette.language.ast import ListValue
    from tartiflette.language.parsers.document import parse as parse_sdl
    from tartiflette.language.parsers.expression import parse as parse_expr

    @Resolver('Query.sumOfLists', schema_name='test')
    async def resolver_query_sum_of_lists(*_args, **_kwargs):
        return [2, 3, 5]

    sdl = """
    type Query {
        sumOfLists: [Int!]
    }
    """.strip()

    schema = await schema_from_sdl(sdl)
    query = '{ a: [[1, 2], *sumOfLists] }'
    ast = parse_sdl(sdl)
    parsed = parse_expr

# Generated at 2022-06-21 18:05:54.169721
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    lines = inspect.getsource(StarredUnpackingTransformer)
    node = ast.parse(lines)
    node = StarredUnpackingTransformer().visit(node)
    assert len(node.body) == 1

# Generated at 2022-06-21 18:05:56.497393
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # assert isinstance(StarredUnpackingTransformer.__init__(), StarredUnpackingTransformer)
    return

# Generated at 2022-06-21 18:06:04.307005
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_output = """
        a = 3
        """
        tree = ast.parse("""
        a = 1
        b = 2
        c = 3
        foo([a, *b, c])
        a = 3
        """)

    test = TestCase()
    test.test_output()

# Generated at 2022-06-21 18:06:05.795417
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  assert(StarredUnpackingTransformer())


# Generated at 2022-06-21 18:06:11.907766
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    result = transformer.visit(node)

    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 18:06:20.341253
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    node = astor.parse_expr("range(1, 2, *range(3))").body

    transformer = StarredUnpackingTransformer()
    transformer.visit(node)

    assert astor.to_source(node).strip() == 'list(range(1, 2)) + list(range(3))'

    node = astor.parse_expr("range(1, 2)").body
    transformer.visit(node)
    assert astor.to_source(node).strip() == 'range(1, 2)'


# Generated at 2022-06-21 18:06:26.529871
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    code = "a = [1, *xs, 2]"
    result_code = "a = [1] + list(xs) + [2]\n"

    tree = ast.parse(code)
    transformed_tree = transformer.visit(tree)

    assert transformer.get_result() == result_code
    assert astor.to_source(transformed_tree) == result_code
    assert transformer.get_tree_changed()

