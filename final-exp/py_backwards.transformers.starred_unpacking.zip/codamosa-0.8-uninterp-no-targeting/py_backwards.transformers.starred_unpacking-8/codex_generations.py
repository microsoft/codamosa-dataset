

# Generated at 2022-06-21 17:57:19.954369
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('*' * 50, '\nTest constructor of class StarredUnpackingTransformer')
    tree = ast.parse('list(*range(10), 1)', '<test>', 'exec')
    StarredUnpackingTransformer().visit(tree)

    print(ast.dump(tree))
    assert tree.body[0].value.func.id == 'list'
    assert len(tree.body[0].value.args) == 1
    assert isinstance(tree.body[0].value.args[0], ast.BinOp)
    assert isinstance(tree.body[0].value.args[0].left, ast.Call)
    assert tree.body[0].value.args[0].left.func.id == 'range'

# Generated at 2022-06-21 17:57:32.265547
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='range'))],
        keywords=[])

    # check for 'print(*(list(range(1)) + list(range())))'
    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Num(n=1)],
                keywords=[])],
            keywords=[]))],
        keywords=[])

    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-21 17:57:34.093849
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-21 17:57:44.940151
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from compilertools.python import ast_unparse, parse

    ex_1 = [2, *range(10), 1]
    ex_2 = print(*range(1), *range(3))

    parser = parse(__file__)
    l_1 = parser('[2, *range(10), 1]')
    l_2 = parser('print(*range(1), *range(3))')
    l_3 = parser('[2, *range(10), 1, *range(3), *range(10), 1]')

    assert l_1 == l_1

    transformer = StarredUnpackingTransformer()
    l_1 = transformer.visit(l_1)
    l_2 = transformer.visit(l_2)
    l_3 = transformer.visit(l_3)


# Generated at 2022-06-21 17:57:50.900597
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    node1 = ast.parse("print(3)").body[0]
    node2 = ast.parse("print(3, *range(3))").body[0]
    t.visit(node1)
    t.visit(node2)
    assert node1 == ast.parse("print(3)").body[0]
    assert node2 == ast.parse("print(*(list(range(3))))").body[0]


# Generated at 2022-06-21 17:57:54.631961
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
    a(1, 2, 3, 4)
    """
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    expected = """
    a(*(list([1, 2, 3, 4])))
    """
    assert astor.to_source(node) == expected



# Generated at 2022-06-21 17:57:59.927114
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    args = [2, 3, 4]
    result = StarredUnpackingTransformer().visit_Call(ast.Call(func=ast.Name(id='print'), args=args, keywords=[]))
    expected = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.List(elts=args))], keywords=[])
    assert result == expected


# Generated at 2022-06-21 17:58:09.680915
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import textwrap

    src = textwrap.dedent('''
    [0, *range(10), *range(0, 20)]
    print(*range(1), *range(3), *range(7))
    ''')

    expected = textwrap.dedent('''
    ([0] + list(range(10)) + list(range(0, 20)))
    print(*(list(range(1)) + list(range(3)) + list(range(7))))
    ''')

    node = ast.parse(src)
    StarredUnpackingTransformer().visit(node)
    actual = compile(node, '<string>', 'exec')
    ns = {}
    exec(actual, ns)
    assert ns['range'](5) == list(ns['range'](5))

# Generated at 2022-06-21 17:58:19.166414
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTest
    from .base import get_example_ast_tree
    from typed_ast.ast3 import parse

    class Test(BaseNodeTest):
        target_node = ast.List
        transformer = StarredUnpackingTransformer

    tree = parse(get_example_ast_tree(Test))
    name, = tree.body
    assert isinstance(name, ast.Expr)
    assert isinstance(name.value, ast.List)
    assert len(name.value.elts) == 3
    assert isinstance(name.value.elts[0], ast.Num)
    assert isinstance(name.value.elts[1], ast.BinOp)
    assert isinstance(name.value.elts[2], ast.Num)

# Generated at 2022-06-21 17:58:26.313629
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ...general import clean_code

    transformer = StarredUnpackingTransformer()
    code = 'x = [1, *range(0, 5), [1, *range(6, 10)]]'
    tree = ast.parse(code)
    with transformer.visit(tree):
        assert clean_code(transformer, code) == 'x = ([1] + list(range(0, 5)) + ([1] + list(range(6, 10))))'



# Generated at 2022-06-21 17:58:32.409295
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    _ = StarredUnpackingTransformer()


# Generated at 2022-06-21 17:58:37.662313
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
        a = [1, 2, *range(4), 5]
        b = [0, 1, 2, 3]
    """
    compiled = compile(source, '', 'exec')
    tree = StarredUnpackingTransformer().visit(ast.parse(source))
    result = compile(tree, '', 'exec')
    assert eval(compiled) == eval(result)



# Generated at 2022-06-21 17:58:43.080713
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
      code = """
      print(*[1,2,3], *[4,5,6])
      """
      expected_code = """
      print(*(list([1, 2, 3]) + list([4, 5, 6])))
      """
      tree = ast.parse(code)
      tree = StarredUnpackingTransformer().visit(tree)
      assert astor.to_source(tree) == expected_code



# Generated at 2022-06-21 17:58:50.492880
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from ..ast_helpers import dump_ast
    print('\n' + astor.to_source(ast.parse('''
        print(*(range(1), range(2)))
        #print(*[range(1), range(2)])
    ''')))
    print('=>')
    dump_ast(StarredUnpackingTransformer().visit(ast.parse('''
        print(*(range(1), range(2)))
        #print(*[range(1), range(2)])
    ''')))

# Generated at 2022-06-21 17:58:59.195855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''
    foo(*frob)
    ''')
    node.body[0].value.func.id == "foo"
    node.body[0].value.args[0].value.id == "frob"
    transformed = StarredUnpackingTransformer().visit(node.body[0].value)
    transformed.args[0].value.value.id == "frob"
    transformed.args[0].value.func.id == "list"


# Generated at 2022-06-21 17:59:00.725634
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(tree=None).tree is None

# Generated at 2022-06-21 17:59:11.366870
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("Testing visit_Call of class StarredUnpackingTransformer")
    StarredUnpackingTransformer.testing=True
    StarredUnpackingTransformer.testing_level=1
    node = ast.Call(func=ast.Name(id='myfunc'), args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='v1'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='v2'), ctx=ast.Load())], keywords=[], starargs=None, kwargs=None)
    StarredUnpackingTransformer().visit(node)
    print("Finished testing visit_Call of class StarredUnpackingTransformer")


# Generated at 2022-06-21 17:59:20.949630
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    node = tree.body[0].value

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    print(ast.dump(result))


# Generated at 2022-06-21 17:59:29.312768
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    filename = 'StarredUnpackingTransformer.py'
    with open(filename) as f:
        src = f.read()
    module = ast.parse(src)
    StarredUnpackingTransformer().visit(module)
    fixed_src = unparse(module)
    with open(filename.replace('.py', '_fixed.py'), 'w') as f:
        f.write(fixed_src)

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:35.527880
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Arrange
    text = """
[2, *range(10), 1]
print(*range(1), *range(3))
"""
    node = ast.parse(text)
    expected = """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
"""
    # Act
    StarredUnpackingTransformer().visit(node)
    # Assert
    assert astor.to_source(node).strip() == expected.strip()

# Generated at 2022-06-21 17:59:55.930155
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    n1 = ast.Name(id='foo')
    n2 = ast.Name(id='bar')
    n3 = ast.Name(id='baz')
    n4 = ast.Name(id='qux')
    n5 = ast.Name(id='quux')
    n6 = ast.Name(id='quuz')
    li1 = ast.List(elts=[n1, n2, n3, n4])
    li2 = ast.List(elts=[n5, n6, n3])
    ld = ast.List(elts=[li1, ast.Starred(value=li2), n2, n3])
    ld = StarredUnpackingTransformer().visit(ld)
    assert isinstance(ld, ast.BinOp)

# Generated at 2022-06-21 18:00:03.252120
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse

    input = """\
print(*range(1), *range(3))
"""
    expected = """\
print(*(list(range(1)) + list(range(3))))
"""
    tree = ast.parse(input)
    StarredUnpackingTransformer().visit(tree)
    actual = unparse(tree)
    assert expected == actual


# Generated at 2022-06-21 18:00:08.259276
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """print(1, *range(1))"""
    expected = """print(*(list(range(1)) + [1]))"""
    tr = StarredUnpackingTransformer()
    tr._visit_tree(ast.parse(source))
    assert tr._tree_changed
    tree = tr.get_tree()
    assert astor.to_source(tree).strip() == expected


# Generated at 2022-06-21 18:00:15.778310
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = textwrap.dedent("""\
    [2, *range(10), 1]
    """)

    module = ast.parse(code)
    result = StarredUnpackingTransformer().visit(module)

    expected = textwrap.dedent("""\
    classlist([2] + list(range(10)) + [1])
    """)

    print(ast.dump(result))
    assert ast.dump(result) == expected



# Generated at 2022-06-21 18:00:27.707315
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    import astor
    nodes = [
        ast.List(elts=[
            ast.Num(n=2),
            ast.Starred(value=ast.Name(id='range')),
            ast.Num(n=1)],
            ctx=ast.Load()),
        ast.Num(n=1),
        ast.List(elts=[
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
            ast.Num(n=1),
            ast.Name(id='a', ctx=ast.Load()),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
        ],
            ctx=ast.Load()),
    ]

# Generated at 2022-06-21 18:00:33.914872
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    method = transformer.visit_List
    tree = ast.parse('[1, *[3, 4], 6]')

    result = method(tree.body[0].value)
    assert isinstance(result, ast.BinOp)
    assert result.op.__class__.__name__ == 'Add'  # type: ignore
    assert result.left.__class__.__name__ == 'List'  # type: ignore
    assert result.left.elts[0].n == 1
    assert result.right.__class__.__name__ == 'List'  # type: ignore
    assert result.right.elts[0].n == 6
    assert result.right.elts[1].value.__class__.__name__ == 'List'  # type: ignore
   

# Generated at 2022-06-21 18:00:45.609782
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sut = StarredUnpackingTransformer()
    # Case 1: list of args
    l = ast.List(elts=[ast.Starred(value=ast.Name(id='l'), ctx=ast.Load()), ast.Num(n=1), ast.Name(id='l')])
    sut.visit(l)
    assert sut.generic_visit(ast.Compare(left=l, ops=[ast.Eq()], comparators=[ast.List(elts=[ast.Call(func=ast.Name(id='list'),
      args=[ast.Name(id='l')], keywords=[]), ast.Num(n=1), ast.List(elts=[ast.Name(id='l')])])]))
    # Case 2: list of lists

# Generated at 2022-06-21 18:00:46.706908
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x is not None

# Generated at 2022-06-21 18:00:55.747376
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print_3_1 = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Num(3),
            ast.Num(1),
        ],
        keywords=[])
    print_range_1_2_3 = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range'),
                args=[
                    ast.Num(1),
                ],
                keywords=[])),
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range'),
                args=[
                    ast.Num(2),
                    ast.Num(3),
                ],
                keywords=[])),
        ],
        keywords=[])
    assert StarredUnpackingTrans

# Generated at 2022-06-21 18:01:06.208335
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tr_obj=StarredUnpackingTransformer()
    code1="[2, *range(10), 1]"
    code2="print(*range(1), *range(3))"
    expected1="[2] + list(range(10)) + [1]"
    expected2="print(*(list(range(1)) + list(range(3))))"

    tree1=ast.parse(code1)
    tree2=ast.parse(code2)
    
    tr_obj.visit(tree1)
    tr_obj.visit(tree2)

    print(ast.dump(tree1))
    print(ast.dump(tree2))

    assert ast.dump(tree1)==expected1
    assert ast.dump(tree2)==expected2

    # print(ast.dump(tree))
    # print(

# Generated at 2022-06-21 18:01:27.640956
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Asserting if the object has been constructed properly
    class_object = StarredUnpackingTransformer()
    assert class_object.visit_Call([1, 2]) == []
    assert class_object.visit_List([1, 2, 3]) == [1, 2, 3]
    assert class_object._has_starred([1, 2, 3]) == False

# Generated at 2022-06-21 18:01:36.987930
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    f = ast.parse('[2, *range(10), 1]').body[0].value

    result = StarredUnpackingTransformer().visit(f)
    assert result == ast.BinOp(
        ast.Num(2),
        ast.Add(),
        ast.BinOp(
            ast.Call(
                func=ast.Name(id="list"),
                args=[ast.Call(
                    func=ast.Name(id="range"),
                    args=[ast.Num(10)],
                    keywords=[])],
                keywords=[]
            ),
            ast.Add(),
            ast.List(elts=[ast.Num(1)])
        )
    )


# Generated at 2022-06-21 18:01:40.438416
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # fixture
    from astor import codegen
    ct_1 = StarredUnpackingTransformer()
    ast_1 = ast.parse('[2, *range(10), 1]')
    ast_2 = ast.parse('print(*range(1), *range(3))')
    # actual result
    actual_result_1 = ct_1.visit(ast_1)
    actual_result_2 = ct_1.visit(ast_2)
    # expected result
    expected_result_1 = ast.parse('[2] + list(range(10)) + [1]')
    expected_result_2 = ast.parse('print(*(list(range(1)) + list(range(3))))')
    # check result

# Generated at 2022-06-21 18:01:49.794694
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    def f():
        print(1, *range(2), 3, *range(4))
        print(1, *range(2))
    """

    expected = """
    def f():
        print(*(list([1]) + list(range(2)) + list([3]) + list(range(4))))
        print(1, *range(2))
    """
    result = astor.to_source(StarredUnpackingTransformer().visit(astor.parse_file(source)))
    assert result == expected



# Generated at 2022-06-21 18:02:01.893022
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformer
    import ast
    from typed_ast import ast3 as typed_ast
    class StarredUnpackingTransformer(BaseNodeTransformer):
        target = (3, 4)
        """Compiles:
            [2, *range(10), 1]
            print(*range(1), *range(3))
        To:
            [2] + list(range(10)) + [1]
            print(*(list(range(1)) + list(range(3))))
        """
        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True
            return False

# Generated at 2022-06-21 18:02:07.515027
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    node = ast.parse(source)
    compiler = StarredUnpackingTransformer()
    transformed = compiler.visit(node)
    assert ast.dump(transformed) == expected



# Generated at 2022-06-21 18:02:11.516780
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import compile_source
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    assert compile_source(source, StarredUnpackingTransformer).strip() == expected


# Generated at 2022-06-21 18:02:23.276472
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    node = ast.parse(
        'print(*range(1), *range(3), *range(5))')
    res = StarredUnpackingTransformer().visit(node)
    res = astor.dump_tree(res)

# Generated at 2022-06-21 18:02:28.566208
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import BaseNodeTransformerTestCase
    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        code = """\
[
    *range(10),
    a,
    *[1, 2, 3],
    b,
]
"""
        expected = """\
([] + list(range(10)) + [a] + list([1, 2, 3]) + [b])
"""
    return Test

# Generated at 2022-06-21 18:02:29.234956
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert 3 == 3

# Generated at 2022-06-21 18:02:57.776330
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    stmt = ast.parse("[1, *range(3), 4]").body[0]
    assert isinstance(stmt, ast.Expr)
    assert isinstance(stmt.value, ast.List)

    # When
    StarredUnpackingTransformer().visit(stmt)

    # Then

# Generated at 2022-06-21 18:03:05.149593
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.parse(
        'a(*[f(x), *g(y), h(z)])',
        mode='eval'
    )
    transformer = StarredUnpackingTransformer()
    transformer.visit(x)
    y = ast.parse(
        'a(*(list(f(x)) + list(g(y)) + list(h(z))))',
        mode='eval'
    )

    assert ast.dump(x) == ast.dump(y)


# Generated at 2022-06-21 18:03:13.738026
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    e =ast.List(
            elts=[
                ast.Starred(
                    value=ast.Call(func=ast.Name(id="list"), args=[ast.Name(id="range")], keywords=[])
                ),
                ast.Starred(
                    value=ast.Call(func=ast.Name(id="list"), args=[ast.Name(id="range")], keywords=[])
                )
            ],
        ctx=ast.Load())

    t = StarredUnpackingTransformer(e)

    assert isinstance(e,ast.List), True

    assert t._has_starred(e.elts) == True

    assert len(t._split_by_starred(e.elts)) == 3

# Generated at 2022-06-21 18:03:26.195322
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast as pyast
    x = StarredUnpackingTransformer()

    e = pyast.List()
    node = pyast.Str()
    assert isinstance(e, ast.expr)
    assert (x._split_by_starred([e, node]) == [[e], node])

    e = pyast.Call()
    node = pyast.Str()
    assert isinstance(e, ast.expr)
    assert (x._split_by_starred([e, node]) == [[e], node])

    e = pyast.Call()
    node = pyast.Str()
    assert isinstance(e, ast.expr)
    assert (x._split_by_starred([e, node]) == [[e], node])

    e = pyast.Starred()
    node = pyast.Str()

# Generated at 2022-06-21 18:03:31.136457
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
[2, *range(10), 1]
    """

    expected = """
[2] + list(range(10)) + [1]
    """

    module = ast.parse(source)
    module = StarredUnpackingTransformer().transform(module)
    assert expected == astunparse.unparse(module)

    source = """
x = [1, 2, 3, 4]
y = [5, 6, 7, 8]
print(sum([*x, *y, 9, 10]))
    """

    expected = """
x = [1, 2, 3, 4]
y = [5, 6, 7, 8]
print(sum(([1, 2, 3, 4] + [5, 6, 7, 8]) + [9, 10]))
    """


# Generated at 2022-06-21 18:03:39.540732
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    root = ast.parse(source)
    t = StarredUnpackingTransformer()
    t.visit(root)
    result = compile(root, '<test>', 'exec')
    exec(result)
    assert result.co_code.decode('utf-8') == expected



# Generated at 2022-06-21 18:03:44.981473
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = 'l = [2, *range(10), 1]'
    expected = 'l = [2] + list(range(10)) + [1]'

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast.parse(source))

    assert transformer.has_changed
    assert astor.to_source(result) == expected



# Generated at 2022-06-21 18:03:56.744723
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import typed_ast.ast3
    tree1 = typed_ast.ast3.parse('(2, *range(10), 1)')
    tree2 = typed_ast.ast3.parse('print(*range(1), *range(3))')
    tree3 = typed_ast.ast3.parse('print(2, *range(2), 3, *range(3))')
    tree4 = typed_ast.ast3.parse('print(2, *range(2))')
    tree5 = typed_ast.ast3.parse('print(*range(2))')
    tree6 = typed_ast.ast3.parse('print(2, *range(2), 3)')
    tree7 = typed_ast.ast3.parse('print(2, *range(2), 3, 7)')
    tree8 = typed

# Generated at 2022-06-21 18:04:02.111781
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == expected


# Generated at 2022-06-21 18:04:13.446053
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1]
    x = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[
                        ast.Num(n=10)],
                    keywords=[])),
            ast.Num(n=1)],
        ctx=ast.Load())

    actual = ast.dump(StarredUnpackingTransformer().visit(x))
    expected = ast.dump(ast.List(
        elts=[ast.Num(n=2)],
        ctx=ast.Load())) + '''\
 + list(range(10)) + [1]'''
    print('actual  ', actual)
    print('expected', expected)

# Generated at 2022-06-21 18:04:54.017348
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("--- begin test_StarredUnpackingTransformer() ---")
    import astor
    source = astor.parse_file('test/StarredUnpackingTransformer.py')
    trans = StarredUnpackingTransformer(source)
    trans.visit(source)
    astor.to_source(source)
    print("--- end test_StarredUnpackingTransformer() ---")

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-21 18:05:05.057693
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    func = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(func)
    assert func.body[0].value.elts[0] == ast.Num(n=2)
    assert func.body[0].value.elts[1].func.id == 'list'
    assert func.body[0].value.elts[1].args[0].func.id == 'range'
    assert func.body[0].value.elts[1].args[0].args[0].n == 10
    assert func.body[0].value.elts[2] == ast.Num(n=1)

# Generated at 2022-06-21 18:05:15.200613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.codegen import to_source
    from .common import print_fn
    from .quantifier import QuantifierTransformer
    from .call_chain import CallChainTransformingVisitor

    code = """\
print(*range(1), *range(3))
"""
    code = to_source(QuantifierTransformer().visit(print_fn(code)))
    code = to_source(StarredUnpackingTransformer().visit(ast.parse(
        code, mode='exec')))
    code = to_source(CallChainTransformingVisitor().visit(ast.parse(
        code, mode='exec')))
    assert code == """\
print(*(list(range(1)) + list(range(3))))
"""



# Generated at 2022-06-21 18:05:26.623239
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_ast.ast3 as ast

    class FakeNode(object):
        node = None  # type: ast.AST


# Generated at 2022-06-21 18:05:35.837342
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import unittest
    import ast as pyast

    token = unittest.mock.MagicMock()
    node = ast.List(
        elts= [ast.Starred(value=ast.Name(id='x', ctx=pyast.Load()), ctx=pyast.Store())],
        ctx=pyast.Load())
    expected = ast.List(
        elts= [ast.Call(func=ast.Name(id='list', ctx=pyast.Load()), args=[ast.Name(id='x', ctx=pyast.Load())], keywords=[])],
        ctx=pyast.Load())

    actual = StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer, node)

    assert actual == expected


# Generated at 2022-06-21 18:05:42.908342
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .transformer_case import TransformerCase
    case = TransformerCase(
        node='''print(*range(1), *range(3))''',
        expected='''print(*(list(range(1)) + list(range(3))))''')
    case.test(StarredUnpackingTransformer)

# Unit tests for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:05:54.069537
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    testcase_1 = """def foo():
    g = [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    expected_1 = """def foo():
    g = [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """

    testcase_2 = """def foo():
    g = [*range(10)]
    print(*range(1))
    """
    expected_2 = """def foo():
    g = list(range(10))
    print(*(list(range(1))))
    """
    testcase_3 = """def foo():
    g = [1, 2, 3]
    print(1)
    """

# Generated at 2022-06-21 18:06:00.636488
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""

    # given
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    # when
    actual = to_source(StarredUnpackingTransformer().visit(parse(source)))

    # then
    assert expected == actual



# Generated at 2022-06-21 18:06:12.917456
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    example_input_1 = ast.parse("""
    print(*range(1), *range(3))
    """)

    expected_output_1 = ast.parse("""
    print(*(list(range(1)) + list(range(3))))
    """)

    example_input_2 = ast.parse("""
    print(1, *[2, 3], 4, 5)
    """)

    expected_output_2 = ast.parse("""
    print(*(list([1]) + list([2, 3]) + list([4]) + list([5])))
    """)

    example_input_3 = ast.parse("""
    print(1, *[2, *[3, 4]], 5)
    """)


# Generated at 2022-06-21 18:06:19.386722
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(ast.parse("[2, *range(10), 1]")) == ast.parse("[2] + list(range(10)) + [1]")
    assert transformer.visit(ast.parse("print(*range(1), *range(3))")) == ast.parse("print(*(list(range(1)) + list(range(3))))")