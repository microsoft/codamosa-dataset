

# Generated at 2022-06-21 17:57:21.098750
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = (
        'print(*range(10), *range(20))\n'
        'print([1, *range(10), 2])\n'
    )
    expected = (
        'print(*(list(range(10)) + list(range(20))))\n'
        'print(list([1]) + list(range(10)) + list([2]))\n'
    )
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    actual = compile(tree, '<asdf>', 'exec')
    glob = {}
    exec(actual, glob)
    assert expected == str(glob['__builtins__']['print']) + str(glob['__builtins__']['list'])  # noqa: E501


# Generated at 2022-06-21 17:57:33.492249
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # list, sum of lists, 1:
    node = ast.Call(
        func=ast.Name(id='func'),
        args=[
            ast.List(elts=[
                ast.Num(n=2),
                ast.Starred(value=ast.Name(id='range')),
                ast.Num(n=1),
            ]),
            ast.Starred(value=ast.Name(id='range')),
            ast.Starred(value=ast.Name(id='range')),
        ],
        keywords=[])

# Generated at 2022-06-21 17:57:44.336442
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    
    node = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-21 17:57:50.725950
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    n = ast.parse('''
print(*range(1), *range(3), 4)
print(*range(3), *range(3))
print(1, *range(3), *range(3))
print(1, *range(3), 3)
''').body[0]

    r = StarredUnpackingTransformer().visit(n)
    assert astor.to_source(r).strip() == 'print(*(list(range(1)) + list(range(3)) + [4]))'



# Generated at 2022-06-21 17:57:58.418889
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_construction(self):
            StarredUnpackingTransformer()

        def test_visit_list(self):
            StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]'))

        def test_visit_call(self):
            StarredUnpackingTransformer().visit(ast.parse('print(*range(1), *range(3))'))

    unittest.main()

# Generated at 2022-06-21 17:58:09.182987
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from jedi._compatibility import u
    from typed_ast import ast3 as ast
    from .utility import source_to_node

    node = source_to_node(u('''
    def f(a, b, c):
        return a + b + c

    f(1, *range(2), 3 + x, *y)
    '''))
    expected = source_to_node(u('''
    def f(a, b, c):
        return a + b + c

    f(*(1 + list(range(2)) + [3 + x] + list(y)))
    '''))
    result = StarredUnpackingTransformer().visit(node)

    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-21 17:58:19.134621
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .visitor import dump

    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert dump(tree) == \
        "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), " + \
        "op=Add(), right=Call(func=Name(id='list', ctx=Load()), " + \
        "args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], " + \
        "keywords=[])], keywords=[])))])"

    code = "print(*range(1), *range(3))"
    tree = ast.parse(code)
    StarredUnpackingTransformer().vis

# Generated at 2022-06-21 17:58:24.997171
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input_expr = "[2, *range(10), 1]"
    expected_expr = "[2] + list(range(10)) + [1]"
    actual = StarredUnpackingTransformer().visit(ast.parse(input_expr).body[0])
    expected = ast.parse(expected_expr).body[0]
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-21 17:58:37.503292
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_base import run_test_node, print_node
    from typed_ast import ast3
    node = ast3.Call(
        func=ast3.Name(id='print', ctx=ast3.Load()),
        args=[
            ast3.Starred(
                value=ast3.Name(id='range', ctx=ast3.Load()),
                ctx=ast3.Load()),
            ast3.Name(id='range', ctx=ast3.Load())],
        keywords=[])

# Generated at 2022-06-21 17:58:40.387624
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(target=(3, 7)).target == (3, 7)
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-21 17:58:53.143207
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_tree = ast.parse('''
r = [2, *range(1, 6, 2), 2]
''')
    StarredUnpackingTransformer().visit(ast_tree)

# Generated at 2022-06-21 17:59:00.027719
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
a=[1, *range(10), 4]
"""
    expected = """
a = [1] + list(range(10)) + [4]
"""
    result = StarredUnpackingTransformer().visit(ast.parse(source))
    assert expected == ast.unparse(result)



# Generated at 2022-06-21 17:59:10.148406
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""
    from .test_transformer import run_test, check_ast_transform

    def check_transform(node):
        """Check `node` is transformed to sum of lists."""
        assert isinstance(node, ast.BinOp)
        assert isinstance(node.left, ast.List)
        assert isinstance(node.right, ast.BinOp)

    check_ast_transform(
        StarredUnpackingTransformer,
        run_test,
        check_transform,
        "mylist = [2, *range(10), 1]",
    )



# Generated at 2022-06-21 17:59:20.235875
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return self.generic_visit(super().visit_Call(node))

    tree = ast.parse('''
print(*range(1), *range(3))
''')

    tree = TestTransformer().visit(tree)

# Generated at 2022-06-21 17:59:32.494304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    assert ast.dump(StarredUnpackingTransformer().visit(tree)) == "Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2), Num(n=1)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=Call(func=Name(id='list', ctx=Load()), args=[], keywords=[]), op=Add()))"

    tree = ast.parse('print(2, *range(3))')

# Generated at 2022-06-21 17:59:35.705284
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(lambda:None, lambda:None)

# Generated at 2022-06-21 17:59:41.238339
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assertStarredUnpackingTransformer("[]", "[]")
    assertStarredUnpackingTransformer("[1]", "[1]")
    assertStarredUnpackingTransformer("[1, *range(10)]", "[1] + list(range(10))")
    assertStarredUnpackingTransformer("[1, *range(10), 1]", "[1] + list(range(10)) + [1]")
    assertStarredUnpackingTransformer("[*range(10), 1]", "list(range(10)) + [1]")
    assertStarredUnpackingTransformer("[*range(10), 1, *range(10), 1]", "list(range(10)) + [1] + list(range(10)) + [1]")

# Generated at 2022-06-21 17:59:43.240410
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    text = 'print(1, 2, 3, 4)'
    module = parse(text)

    StarredUnpackingTransformer().visit(module)

    assert(unparse(module) == 'print(*([1, 2, 3, 4]))')
    

# Generated at 2022-06-21 17:59:45.171588
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None

# Generated at 2022-06-21 17:59:55.347996
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .testlibraries.base import BaseTestTransformer

    class TestStarredUnpackingTransformer(BaseTestTransformer):   # type: ignore
        target = StarredUnpackingTransformer

        def _to_string(self, node: ast.AST) -> str:
            return self.target.to_source(node)

        def _assert_transform_equal(self, node_before: ast.AST, node_after: ast.AST) -> None:
            super()._assert_transform_equal(node_before, node_after)

    return TestStarredUnpackingTransformer

TestStarredUnpackingTransformer = test_StarredUnpackingTransformer()
del test_StarredUnpackingTransformer

# Generated at 2022-06-21 18:00:13.962081
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = ast.parse('[2, *range(10)]')
    transformer = StarredUnpackingTransformer()
    new_x = transformer.visit(x)

    assert isinstance(new_x, ast.Module)
    assert len(new_x.body) == 1
    assert isinstance(new_x.body[0], ast.Expr)
    assert isinstance(new_x.body[0].value, ast.BinOp)
    assert isinstance(new_x.body[0].value.left, ast.List)
    assert new_x.body[0].value.left.elts[0].n == 2
    assert isinstance(new_x.body[0].value.right, ast.Call)
    assert isinstance(new_x.body[0].value.right.func, ast.Name)

# Generated at 2022-06-21 18:00:24.025581
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'

    module_node = ast.parse(code)

    transformer = StarredUnpackingTransformer()
    transformer.visit(module_node)

    print(ast.dump(module_node))

# Generated at 2022-06-21 18:00:32.369863
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast import parse
    from typing import List
    from typed_ast import ast3 as ast

    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
            print(*range(1), *range(3))
        To:
            [2] + list(range(10)) + [1]
            print(*(list(range(1)) + list(range(3))))
            
        """
        target = (3, 4)

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True

            return False


# Generated at 2022-06-21 18:00:43.572851
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("Test for method StarredUnpackingTransformer.visit_Call")
    node = ast.parse("""
print(*range(1), *range(3))
    """)

    node_after = ast.parse("""
print(*(list(range(1)) + list(range(3))))
        """)
    expected = ast.parse("""
print(*(list(range(1)) + list(range(3))))
        """)

    tree_after = StarredUnpackingTransformer(
    ).visit(node)  # type: ignore

    print("Node after transformation: ", ast.dump(tree_after))
    print("Expected:                 ", ast.dump(expected))

    assert ast.dump(tree_after) == ast.dump(expected)


# Generated at 2022-06-21 18:00:45.080786
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:00:48.656439
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    #Test 1
    before = "[2, *range(10), 1]"
    after = "[2] + list(range(10)) + [1]"
    assert t.visit(ast.parse(before).body[0]) == ast.parse(after).body[0]


# Generated at 2022-06-21 18:00:52.225569
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    before = ast.parse('''
print(1, 2, 3, 4)
print(*range(10), 1)
print()
''').body
    expected = ast.parse('''
print(1, 2, 3, 4)
print(*(list(range(10)) + [1]))
print()
''').body
    actual = StarredUnpackingTransformer().visit(before)
    assert actual == expected


# Generated at 2022-06-21 18:01:03.382903
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sut = StarredUnpackingTransformer()
    node = ast.List(elts=[])
    sut.visit(node)
    assert node.elts == []

    node = ast.List(elts=[ast.Name("x")])
    sut.visit(node)
    assert node.elts == [ast.Name("x")]

    node = ast.List(elts=[ast.Name("x"), ast.Starred(ast.Name("xs"))])
    sut.visit(node)
    assert node.elts == [ast.Name("x")]
    assert isinstance(node.elts[0], ast.Name)

    node = ast.List(elts=[ast.Starred(ast.Name("xs"))])
    sut.visit(node)

# Generated at 2022-06-21 18:01:10.103130
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""
    class Node:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __repr__(self):
            return 'Node(a={!r}, b={!r})'.format(self.a, self.b)

    node_list = lambda n, *args: Node(n, args)
    node_call = lambda n, *args: Node(n, [node_list(None, *args)])
    node_starred = lambda n, *args: Node(n, args)
    node_num = lambda n: Node(n, [])


# Generated at 2022-06-21 18:01:16.793684
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input_text = """
    [1, 2, 3]
    [1, *[2, 3]]
    [1, 2, *[3, 4], 5, 6] 
    [1, *[2, 3], 4, 5, *[6, 7], 8, 9]
    """
    expected_text = """
    [1, 2, 3]
    (list([1]) + list(list([2, 3])))
    (list([1, 2]) + list(list([3, 4])) + list([5, 6]))
    (list([1, 2, 3, 4, 5]) + list(list([6, 7])) + list([8, 9]))
    """
    transformer_tester = TransformerTester(StarredUnpackingTransformer, input_text, expected_text)
    transformer_

# Generated at 2022-06-21 18:01:30.394769
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_code = """\
input_code = [2, *range(10), 1]\
"""

    expected_code = """\
input_code = [2] + list(range(10)) + [1]\
"""

    actual_code = StarredUnpackingTransformer(input_code).output
    assert actual_code == expected_code

# Generated at 2022-06-21 18:01:39.985988
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""print(*range(1), *range(3))""").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    node = StarredUnpackingTransformer().visit(node.value)
    assert isinstance(node, ast.Call)
    assert node.args
    assert isinstance(node.args[0], ast.Starred)
    assert isinstance(node.args[0].value, ast.BinOp)
    assert isinstance(node.args[0].value.left, ast.Call)
    assert isinstance(node.args[0].value.right, ast.Call)

    node = ast.parse("""print(1, *range(1), *range(3), 5)""").body[0]

# Generated at 2022-06-21 18:01:46.124696
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('[2, *range(10), 1]')
    transformed = transformer.visit(node)
    assert ast.dump(ast.parse('[2] + list(range(10)) + [1]')) == ast.dump(transformed)


# Generated at 2022-06-21 18:01:49.385515
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit testing for constructor of class StarredUnpackingTransformer"""
    star_unpack = StarredUnpackingTransformer()
    assert isinstance(star_unpack, StarredUnpackingTransformer)

# Generated at 2022-06-21 18:01:50.847720
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    #constructor test
    StarredUnpackingTransformer()

# Unit test

# Generated at 2022-06-21 18:01:52.378200
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    print(x.__class__)
    assert issubclass(x.__class__, ast.NodeTransformer)

# Generated at 2022-06-21 18:01:59.139919
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert StarredUnpackingTransformer().visit_Call(
        ast.parse('f(1, *x)').body[0].value) == ast.Call(
        func=ast.Name(id='f'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='x')],
            keywords=[]))],
        keywords=[])


# Generated at 2022-06-21 18:02:11.430294
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()
    ast_node = ast.parse("print(*range(1), *range(3))").body[0]
    assert isinstance(ast_node, ast.Expr)
    assert isinstance(ast_node.value, ast.Call)
    new_ast_node = visitor.visit(ast_node)
    assert isinstance(new_ast_node, ast.Expr)
    assert isinstance(new_ast_node.value, ast.Call)

# Generated at 2022-06-21 18:02:12.590300
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:02:24.287553
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # test _has_starred
    test_su_has_starred = StarredUnpackingTransformer()
    test_list1 = [ast.Num(n=1), ast.Num(n=2)]
    test_list2 = [ast.Num(n=1), ast.Starred(value=ast.Name(id='a'))]
    assert test_su_has_starred._has_starred(test_list1) == False
    assert test_su_has_starred._has_starred(test_list2) == True
    # test _split_by_starred
    test_su_split_by_starred = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:46.224979
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]")
    expected_node = ast.parse("[2] + list(range(10)) + [1]")

    node = StarredUnpackingTransformer().visit(node)

    assert ast.dump(node) == ast.dump(expected_node)


# Generated at 2022-06-21 18:02:50.668998
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from unittest.mock import Mock
    ast1 = Mock(name="ast1")
    ast1.elts = [ast.Starred(value=ast.Name(id="a"))]
    ast1.args = [ast.Starred(value=ast.Name(id="a"))]
    ast1.value = [ast.Starred(value=ast.Name(id="a"))]
    ast2 = Mock(name="ast2")
    ast2.elts = []
    ast2.args = []
    ast2.value = []

    assert StarredUnpackingTransformer._has_starred(ast1.elts)
    assert StarredUnpackingTransformer._has_starred(ast1.args)
    assert StarredUnpackingTransformer._has_starred(ast1.value)
    assert not Starred

# Generated at 2022-06-21 18:03:00.093370
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_obj = StarredUnpackingTransformer()
    # 'None' was None, so we had to change it to 'None'
    # 'None' was None, so we had to change it to 'None'
    # 'None' was None, so we had to change it to 'None'
    # 'None' was None, so we had to change it to 'None'
    # 'None' was None, so we had to change it to 'None'
    # 'None' was None, so we had to change it to 'None'
    assert class_obj.visit(ast.parse("print(1, 2, *[3, 4], 5)").body[0]) == ast.parse("print(*(list([1, 2]) + list([3, 4]) + list([5])))").body[0]
    # 'None' was None

# Generated at 2022-06-21 18:03:11.574702
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Example 1
    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    actual = astor.to_source(tree)
    assert actual == expected

    # Example 2
    code = """
    print(*range(3), *range(1))
    """
    expected = """
    print(*(list(range(3)) + list(range(1))))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    actual = astor.to_source(tree)
    assert actual == expected



# Generated at 2022-06-21 18:03:17.350166
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .compile import compile_to_ast, CodeGenerator

    def check(code: str, result: str):
        node = compile_to_ast(code)
        StarredUnpackingTransformer(CodeGenerator()).visit(node)

        node = ast.fix_missing_locations(node)
        result = compile(node, '<test>', 'exec')
        exec(result)

    check('[2, *range(10), 1]', '[2, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]')
    check('print(*range(1), *range(3))', '[0, 0, 1, 2]')

# Generated at 2022-06-21 18:03:29.062588
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_astunparse
    import astunparse

    # test for simple case
    source = 'print(1, *range(8), 2)'
    source1 = 'print(1, *range(8), 2, *range(3))'
    t = StarredUnpackingTransformer()
    tree = t.transform(ast.parse(source))
    tree1 = t.transform(ast.parse(source1))
    source_code = typed_astunparse.unparse(tree).strip()
    source_code1 = typed_astunparse.unparse(tree1).strip()
    expected_code = astunparse.unparse(ast.parse(
        'print(*(list(range(8)) + [2]))')).strip()

# Generated at 2022-06-21 18:03:41.952853
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print(ast.parse('''[2,*range(10),1] == [2] + list(range(10)) + [1]'''))
    print(ast.parse('''[*range(1),*range(3)] == list(range(1)) + list(range(3))'''))
    print(ast.parse('''[*range(1),*range(3),*range(3)] == list(range(1)) + list(range(3)) + list(range(3))'''))
    print(ast.parse('''[*range(1),*range(3),*range(3),2] == list(range(1)) + list(range(3)) + list(range(3)) + [2]'''))

# Generated at 2022-06-21 18:03:49.752389
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from polytropos.ontology.composite import Composite
    from polytropos.ontology.schema import Schema
    from polytropos.util.tree import Tree
    from polytropos.ontology.track import Track
    from polytropos.ontology.variable import VariableId

    tree: Tree = {
        'composite_key': 'name',
        'key': 'name',
        'primitive': 'name',
        'list_primitive': 'name',
        'list_composite': 'name',
        'list_key': 'name',
        'list_list_primitive': 'name',
        'list_list_composite': 'name',
        'list_list_key': 'name'
    }
    schema: Schema = Schema(tree)

# Generated at 2022-06-21 18:03:56.697359
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(1, *range(10), 'hello')")
    node = ast.fix_missing_locations(node)
    node = StarredUnpackingTransformer().visit(node)
    node = ast.fix_missing_locations(node)
    assert "print(*(list([1]) + list(range(10)) + list(['hello'])))" == ast.dump(node)


# Generated at 2022-06-21 18:04:06.086365
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from collections import OrderedDict
    from .base import BaseNodeTransformer
    tr_cls = StarredUnpackingTransformer
    if not issubclass(tr_cls, BaseNodeTransformer):
        return
    tr = tr_cls()
    tr_method = tr.visit_List
    assert tr_method
    if not callable(tr_method):
        return
    node = ast.List(elts=[])
    result = tr_method(node)
    assert isinstance(result, ast.List)
    assert result.elts == []
    node = ast.List(elts=[])
    result = tr_method(node)
    assert isinstance(result, ast.List)
    assert result.elts == []

# Generated at 2022-06-21 18:04:50.669100
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    from . import generate_test

    transformer = StarredUnpackingTransformer()
    for original, expected in generate_test(transformer, """
    [2, *range(10), 1]
    [2, *range(10)]
    [2, 1]
    [2, 1, *range(10)]
    [2, 1, *range(10), *range(5)]
    [2, 1, *range(10), *range(5), *range(7), 0]
    """):
        print(unparse(transformer.visit(original)).rstrip())
        print(unparse(expected).rstrip())
        assert transformer.visit(original) == expected



# Generated at 2022-06-21 18:04:58.232779
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test for method visit_List of class StarredUnpackingTransformer."""
    # Unit test for method visit_List of class StarredUnpackingTransformer
    # Test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:05:03.987358
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    prog = """some.func(1, *args_0, 2, *args_1, 3)"""
    expected = """some.func(*(list(args_0) + list(args_1)), 1, 2, 3)"""
    StarredUnpackingTransformer(prog).assert_changed(expected)

# Generated at 2022-06-21 18:05:04.612122
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None)


# Generated at 2022-06-21 18:05:05.532306
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    return x

# Generated at 2022-06-21 18:05:17.739859
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-21 18:05:27.787798
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    from lib3to6.compiler.transforms.starred_unpacking import StarredUnpackingTransformer
    from lib3to6.compiler.transforms.base import BaseNodeTransformer

    node = ast.parse("print(*range(10), *range(20))")
    t = StarredUnpackingTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert hasattr(t, "visit_Call")
    assert isinstance(t.visit_Call(node.body[0].value), ast.Call)

# Generated at 2022-06-21 18:05:36.455304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ast_transformer import AstTransformer
    from .test_utils import assert_asdl, assert_exec

    tr = AstTransformer()
    tr.register_transformer(StarredUnpackingTransformer())


# Generated at 2022-06-21 18:05:39.205753
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert isinstance(t, StarredUnpackingTransformer)

# Generated at 2022-06-21 18:05:48.724602
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    xs = [ast.Constant(value=42, kind=None), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())]
    c = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=xs, keywords=[])
    node = c.visit(node)

    assert node.args == [ast.Starred(value=ast.Call(
        func=ast.Name(id='list'),
        args=[ast.Constant(value=42, kind=None)],
        keywords=[]), ctx=ast.Load())]