

# Generated at 2022-06-21 17:57:08.843819
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("""[2, *range(10), 1]""")
    transformer = StarredUnpackingTransformer() 
    transformed = transformer.visit(node)
    assert transformer._tree_changed == True
    assert ast.dump(transformed) == "[2] + list(range(10)) + [1]"



# Generated at 2022-06-21 17:57:20.303278
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import make_test_function

    sut = StarredUnpackingTransformer()
    node = make_test_function(
        "f([1, *[2, 3], 4], *[1, 2])"
    ).body[0].body[0]
    
    result = sut.visit_Call(node)
    expected = make_test_function(
        "f(*(list([1, 2, 3]) + list([4])))"
    ).body[0].body[0]
    assert result == expected

    # Test with more than one starred
    node = make_test_function(
        "f(*[1, 2, *[3, 4, 5], 6], 8, *[2, 3])"
    ).body[0].body[0]

    result = sut.visit

# Generated at 2022-06-21 17:57:32.680506
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import sys
    import os
    sys.path.append(os.getcwd() + "/test")
    from test_StarredUnpackingTransformer import *
    
    test = StarredUnpackingTransformer()

    # Test visit_List
    result = test.visit(node1)
    assert result == node1_transformed

    # Test visit_Call
    result = test.visit(node2)
    assert result == node2_transformed

    # Test _split_by_starred
    result = test._split_by_starred([])
    assert result == [[]]
    result = test._split_by_starred([ast.Name(id="a")])
    assert result == [[ast.Name(id="a")]]

# Generated at 2022-06-21 17:57:38.428515
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 0]').body[0].value
    assert isinstance(node, ast.List)
    transformed = StarredUnpackingTransformer().visit(node)

    expected = ast.parse('[2] + list(range(10)) + [0]').body[0].value
    assert isinstance(expected, ast.BinOp)
    assert transformed == expected


# Generated at 2022-06-21 17:57:45.007475
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ministrel import compile_source
    from ministrel.fixtures.typed_asts.target_py36.unpack_in_list_and_call import \
        source, expected, utils

    nodes = compile_source(source=source, version='3.6')
    transformer = StarredUnpackingTransformer(nodes=nodes)
    output = utils.ast2source(transformer, expected)
    assert output == expected

# Generated at 2022-06-21 17:57:51.724803
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
	test_arguments = [ast.List(elts=[], ctx=ast.Load())]
	test_func = ast.Name(id='test_func', ctx=ast.Load())
	test_node = ast.Call(func=test_func, args=test_arguments, keywords=[])
	start = StarredUnpackingTransformer()
	start.visit_Call(test_node)
	assert isinstance(test_node, ast.Call)
	assert test_node.func == test_func
	assert isinstance(test_node.args[0], ast.Starred)

# Generated at 2022-06-21 17:58:02.181293
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()

    # [2, *range(10), 1]
    assert isinstance(t.run(
        [ast.List(elts=[ast.Constant(2), ast.Starred(value=ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Constant(10)],
            keywords=[])),
                    ast.Constant(1)]
         )]
    )[0], ast.List)

    # [2, 1]
    assert isinstance(t.run(
        [ast.List(elts=[ast.Constant(2), ast.Constant(1)]
         )]
    )[0], ast.List)

    # [*range(10)]

# Generated at 2022-06-21 17:58:08.655596
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('TEST:  test_StarredUnpackingTransformer_visit_Call()')

    transformer = StarredUnpackingTransformer()

    original = ast.parse('print(1, *range(1), 2, *range(2))')
    expected = ast.parse(
        'print(*(list([1]) + list(range(1)) + list([2]) + list(range(2))))')

    transformed = transformer.visit(original)
    assert transformer._tree_changed is True
    assert transformed == expected

    print('SUCCESS')


# Generated at 2022-06-21 17:58:14.710935
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse
    from .base import BaseNodeTransformer

    code = '[2, *range(10), 1]'
    tree = StarredUnpackingTransformer(BaseNodeTransformer()).visit(parse(code))
    expected = parse('[2] + list(range(10)) + [1]')
    assert tree == expected


# Generated at 2022-06-21 17:58:22.602871
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast
    from typed_astunparse import unparse
    from .base import UnitTestTransformer

    node = ast.parse("[2, *range(10), 1]")
    r = StarredUnpackingTransformer().visit(node)
    expected = unparse(r)
    r = UnitTestTransformer().visit(r)
    assert unparse(r) == expected

    node = ast.parse("[*range(1), 2, *range(3), 1]")
    r = StarredUnpackingTransformer().visit(node)
    expected = unparse(r)
    r = UnitTestTransformer().visit(r)
    assert unparse(r) == expected

    node = ast.parse("[1, *range(2), 3, *range(4), 5]")


# Generated at 2022-06-21 17:58:41.279466
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer
    """
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    from typed_ast import ast3
    from tests.transpilers.base import BaseRes

    debug = True
    if debug:
        print('-----------------')
        print('test_StarredUnpackingTransformer_visit_List()')
        print('-----------------')
    node = ast.parse(r"""
[1, 2, 3, *[4, 5], 6]
    """).body[0]
    if debug:
        print('input', node)
        # print('\tnode.elts', node.elts)
        # _has_starred(node.elts)
        # split_by_starred(node.elts

# Generated at 2022-06-21 17:58:42.164588
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-21 17:58:51.154783
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from static_typing.typing.parser_util import parse

    code1 = '[2, *range(10), 1]'
    result1 = StarredUnpackingTransformer().visit(parse(code1))

    code2 = '[2] + list(range(10)) + [1]'
    result2 = parse(code2)

    assert result1 == result2

    code3 = '[*range(10)]'
    result3 = StarredUnpackingTransformer().visit(parse(code3))

    code4 = 'list(range(10))'
    result4 = parse(code4)

    assert result3 == result4


# Generated at 2022-06-21 17:58:58.187581
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    code_expected = '[2] + list(range(10)) + [1]'
    tree_expected = ast.parse(code_expected)
    assert ast.dump(tree_expected) == ast.dump(tree)



# Generated at 2022-06-21 17:59:10.149313
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("[1, *[2, 3], 4]")) == \
        ast.parse("[1] + list([2, 3]) + [4]")
    assert StarredUnpackingTransformer().visit(ast.parse("[*[2, 3]]")) == \
        ast.parse("list([2, 3])")
    assert StarredUnpackingTransformer().visit(ast.parse("[1, *[2, [1, 2]], 4]")) == \
        ast.parse("[1] + list([2, [1, 2]]) + [4]")

# Generated at 2022-06-21 17:59:11.316235
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 17:59:19.537350
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import textwrap
    s = textwrap.dedent("""
        a = 'abc'
        b = 'abc'
        print(*a, *b)""").lstrip()

    tree = ast.parse(s)
    StarredUnpackingTransformer().visit(tree)

    expected = textwrap.dedent("""
        a = 'abc'
        b = 'abc'
        print(*(list(a) + list(b)))""").lstrip()

    assert ast.dump(tree) == ast.dump(ast.parse(expected))
test_StarredUnpackingTransformer_visit_Call()


# Generated at 2022-06-21 17:59:31.826066
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    tree = StarredUnpackingTransformer().visit(node)
    result = ast.dump(tree)

# Generated at 2022-06-21 17:59:44.695785
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import parse, dump_ast

    def assert_compiles(src: str, expected: str, **kwargs):
        tree = parse(src, **kwargs)
        StarredUnpackingTransformer().visit(tree)
        code = dump_ast(tree)
        assert code == expected
        return tree

    assert_compiles(
        "[1, 2, 3]",
        "[1, 2, 3]")
        
    assert_compiles(
        "[*range(10), 1]",
        "list(range(10)) + [1]")

    assert_compiles(
        "[2, *range(10), 1]",
        "[2] + list(range(10)) + [1]")


# Generated at 2022-06-21 17:59:56.372255
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input =  ast.parse("[2, *range(10), 1]")
    expected = ast.List(elts= [ast.Num(n=2), ast.Call(func=ast.Name(id='list', ctx=ast.Load()),
                                                    args=[ast.Call(func=ast.Name(id='range', ctx=ast.Load()),
                                                                   args=[ast.Num(n=-2147483648), ast.Num(n=10)], keywords=[])],
                                                    keywords=[]), ast.Num(n=1)],
                        ctx=ast.Load())
    tr = StarredUnpackingTransformer()
    transformed = tr.visit(input)
    assert ast.dump(transformed) == ast.dump(expected)
    assert tr._tree_changed == True



# Generated at 2022-06-21 18:00:09.380907
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    fn = 'output = print("Hello",*("World!"))'
    root = ast.parse(fn)
    node = root.body[0].value
    assert node.__class__.__name__ == 'Call'

    transformer = StarredUnpackingTransformer()
    transformer.visit(root)

    assert transformer.tree_changed
    result = ast.dump(root)

# Generated at 2022-06-21 18:00:12.623105
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
        [2, *range(10), 1]
        [2, *range(10), 1]
    """

    expected_result = """
        [2] + list(range(10)) + [1]
        [2] + list(range(10)) + [1]
    """

    result = compile_and_transform(code, StarredUnpackingTransformer)
    assert compare(expected_result, result)


# Generated at 2022-06-21 18:00:19.202046
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
    [2, *range(10), 1]
    [1, 2]
    """
    expected = """
    [2] + list(range(10)) + [1]
    [1, 2]
    """
    module_node = ast.parse(code)
    StarredUnpackingTransformer().visit(module_node)
    assert ast.dump(module_node) == ast.dump(ast.parse(expected))



# Generated at 2022-06-21 18:00:29.016593
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            tree = ast.parse(dedent('''\
                [2, *range(10), 1]
                '''))
            expected = ast.parse(dedent('''\
                [2] + list(range(10)) + [1]
                '''))
            self.assertEqual(self.transform(tree), expected)

        def test_without_starred(self):
            tree = ast.parse(dedent('''\
                [2, 3, 4, 10, 1]
                '''))

# Generated at 2022-06-21 18:00:34.636753
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    line = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    node = ast.parse(line)
    StarredUnpackingTransformer().visit(node)

    actual = ast.dump(node, annotate_fields=False)
    assert expected == actual


# Generated at 2022-06-21 18:00:41.653382
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiler import compile
    from . import to_source

    code = "print(*range(1), *range(3))"
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert_equal(to_source(tree),
                 'print(*[list(range(1)) + list(range(3))])')

    # Test for correct behavior
    exec(compile(tree, "<test>", "single"))


# Generated at 2022-06-21 18:00:42.522207
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:00:50.267866
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import unittest
    import astor

    class StarredUnpackingTransformerTest(unittest.TestCase):
        def test_empty(self):
            raw = """
            [1, 2, 3]
            """
            expected = """
            [1, 2, 3]
            """
            program = ast.parse(raw)
            program = StarredUnpackingTransformer().visit(program)
            self.assertEqual(astor.to_source(program), expected)

        def test_list(self):
            raw = """
            [1, *[2, 3], 4]
            """
            expected = """
            [1] + list([2, 3]) + [4]
            """
            program = ast.parse(raw)
            program = StarredUnpackingTransformer().visit(program)
            self

# Generated at 2022-06-21 18:01:01.437731
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('> test_StarredUnpackingTransformer start')
    import astor
    from ..compat import parse
    from .unpacking import StarredCollector
    collector = StarredCollector()

    code = astor.to_source(parse('''
[2, *range(10), 1, *range(5, 10)]
print(1, *range(3), 1, *range(3))
    '''))
    collector.visit(parse(code))
    print('Original code:')
    print(code)

    ## Apply transformation
    transformed = StarredUnpackingTransformer.run_visitor(collector.tree)
    print('After transformation:')
    print(astor.to_source(transformed))
    print('> test_StarredUnpackingTransformer end')

# Generated at 2022-06-21 18:01:02.263751
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:01:10.046928
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-21 18:01:12.882437
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    node = ast.parse("[2, *range(5), 7]").body[0]
    expected_node = ast.parse("[2] + list(range(5)) + [7]").body[0]

    # When
    actual_node = StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer(), node)

    # Then
    assert ast_equal(actual_node, expected_node)


# Generated at 2022-06-21 18:01:20.637228
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with open('tests/samples/starred_unpacking/list.py') as f:
        source = f.read()

    tree = compiler.parse(source)
    t = StarredUnpackingTransformer()
    new_tree = t.visit(tree)
    assert new_tree is not tree
    assert 'print' in source
    assert 'print' not in compiler.unparse(new_tree)
    assert '+' in compiler.unparse(new_tree)
    assert 'list(range(5)) + [5]' in compiler.unparse(new_tree)
    assert 'list(range(3)) + [2]' in compiler.unparse(new_tree)
    assert 'list(range(4)) + list(range(1))' in compiler.unparse(new_tree)



# Generated at 2022-06-21 18:01:32.033142
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3

    class TestNodeTransformer(StarredUnpackingTransformer):
        def visit_Name(self, node: ast3.Name):
            return ast3.Name(id='foo', ctx=node.ctx)

        def visit_Num(self, node: ast3.Num):
            return ast3.Num(n=1)

    node = ast3.parse('''
        print(*range(1, 3), 'a')
    ''')
    node = node.body[0].value

    assert isinstance(node, ast3.Call)
    assert node.func.id == 'print'

# Generated at 2022-06-21 18:01:39.127960
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast.ast3 import parse
    from .transformer_util import dump
    from ministd import starprune

    # ------------------------------ test a list ---------------------------------
    node = parse('[2, *range(10), 1]')
    assert starprune(node) == parse('[2] + list(range(10)) + [1]')

    # ------------------------------ test a function ---------------------------------
    node = parse('print(*range(1), *range(3))')
    assert starprune(node) == parse('print(*(list(range(1)) + list(range(3))))')

# Generated at 2022-06-21 18:01:46.606971
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # tests if the StarredUnpackingTransformer Class constructor works
    assert StarredUnpackingTransformer()
    assert StarredUnpackingTransformer(future_features=1)
    assert StarredUnpackingTransformer(future_features=2)
    assert StarredUnpackingTransformer(future_features=3)
    assert StarredUnpackingTransformer(future_features=4)
    assert StarredUnpackingTransformer(future_features=5)


# Generated at 2022-06-21 18:01:50.667099
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree, include_attributes=False) == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-21 18:02:02.776208
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from .util import extract_tree
    from .assign_target import AssignTargetTransformer
    from .unpack_target import UnpackTargetTransformer
    from .format_string import FormatStringTransformer
    source = '[*[2], **{}, *(3,), **{"a": 1, "b": 2, "c": 3}, **{}, *range(5), **{"d": 4, "e": 5}]'

# Generated at 2022-06-21 18:02:11.390218
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_transformer import run_test_transformers
    def sample_func(a, b):
        return a, *b
    source = 'range(1)'
    called = 'sample_func(1, range(1))'
    expected = '(1, *list(range(1)))'
    got = run_test_transformers([(StarredUnpackingTransformer, called, expected),])
    source += '\n' + got + '\n'
    assert source == 'range(1)\n' + expected + '\n'


# Generated at 2022-06-21 18:02:22.605018
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._has_starred([]) == False
    assert StarredUnpackingTransformer()._has_starred([ast.Num(n=0), ast.Num(n=1)]) == False
    assert StarredUnpackingTransformer()._has_starred([ast.Starred(value=ast.Name(id='one')), ast.Num(n=1)]) == True

    assert StarredUnpackingTransformer()._split_by_starred([]) == [[]]
    assert StarredUnpackingTransformer()._split_by_starred([ast.Starred(value=ast.Name(id='one')), ast.Num(n=1)]) == [
        [ast.Starred(value=ast.Name(id='one'))], [], [ast.Num(n=1)]]

    assert Star

# Generated at 2022-06-21 18:02:31.658451
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Check that the class can be constructed
    StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:32.748429
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:38.777839
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    xs = list(range(10))
    node = ast.parse('[2, *range(10)]')
    StarredUnpackingTransformer().visit(node)
    res = compile(node, '<string>', 'eval').__code__.co_consts[1]
    assert res == [2] + xs



# Generated at 2022-06-21 18:02:44.235027
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from test_tree_transformer import T

    tree = ast.parse('print(*range(1, 10))')
    StarredUnpackingTransformer(tree).run()
    T(tree, """
    def __lambda__():
        print(*(([1] + list(range(2, 10))) + []))
    """)


# Generated at 2022-06-21 18:02:47.133688
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass


# Generated at 2022-06-21 18:02:49.390440
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:02:53.342988
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of class StarredUnpackingTransformer"""
    try:
        StarredUnpackingTransformer(tree=None)
    except TypeError as e:
        assert "__init__() missing 1 required positional argument: 'tree'" == str(e)
    else:
        raise AssertionError("Expected TypeError")

# Generated at 2022-06-21 18:02:57.060913
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    transformer.visit(ast.parse("[2, *range(10), 1]"))
    transformer.visit(ast.parse("print(*range(1), *range(3))"))
    assert transformer._tree_changed

# Generated at 2022-06-21 18:03:00.326641
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert (t is not None)
    assert (t._tree_changed is False)
    # it will throw error if not implemented properly
    assert (t.visit is not None)


# Generated at 2022-06-21 18:03:08.847155
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Test(StarredUnpackingTransformer):
        tree_changed = False

    expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]

    tree = ast.parse("print(range(1), *range(3))")
    transformer = Test()
    result = transformer.visit(tree)
    assert transformer.tree_changed == True
    assert ast.dump(expected, include_attributes=True) == ast.dump(result, include_attributes=True)


# Generated at 2022-06-21 18:03:36.162714
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import UnitTestTransformer
    from compile_test_case import CompileTestCase


# Generated at 2022-06-21 18:03:46.942071
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_env import test_env

    # No starred -> nothing to do
    node = ast.parse("print(1, 2)").body[0].value
    assert test_env.run(StarredUnpackingTransformer, node) == node

    # Single starred
    node = ast.parse("print(*range(10))").body[0].value
    result = test_env.run(StarredUnpackingTransformer, node)
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.Starred)
    with pytest.raises(IndexError):
        result.args[1]

    # Multiple starred
    node = ast.parse("print(*range(10), *range(3))").body[0].value

# Generated at 2022-06-21 18:03:58.870996
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test case 1

    # Test case 1.1
    node = ast.parse("print(*range(1), *range(3))").body[0]
    transformer = StarredUnpackingTransformer()
    tree, changed = transformer.visit_Call(node)
    assert changed == True

# Generated at 2022-06-21 18:04:00.593855
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    assert isinstance(trans, StarredUnpackingTransformer)


# Generated at 2022-06-21 18:04:08.363287
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast3 import parse


# Generated at 2022-06-21 18:04:20.344378
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import CompilerTestCase

    class TestCase(CompilerTestCase):
        TRANSFORMER = StarredUnpackingTransformer

        def test_two(self):
            node = ast.parse('print(*range(1), 2)')
            expected = ast.Call(
                func=ast.Name(id='print'),
                args=[ast.Starred(value=ast.Call(
                    func=ast.Name(id='list'),
                    args=[ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Constant(value=1), ast.Constant(value=2)])],
                    keywords=[]))],
                keywords=[])

            self.check(node, expected)

        def test_two_starred(self):
            node = ast

# Generated at 2022-06-21 18:04:27.882527
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = 'x = [1, *y, 2]'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=BinOp(left=List(elts=[Num(n=1)], ctx=Load()), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Name(id='y', ctx=Load())], keywords=[]), op=Add(), right=List(elts=[Num(n=2)], ctx=Load()))))])"

# Generated at 2022-06-21 18:04:38.678566
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    var_test_Call = ast.parse(
        """\
print(*range(3))
"""
    )

    obj = StarredUnpackingTransformer()
    result = obj.visit(var_test_Call)


# Generated at 2022-06-21 18:04:39.554226
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True

# Generated at 2022-06-21 18:04:47.432504
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .utils import compile_and_decompile
    assert compile_and_decompile(ast.parse('foo(a, b, *c, *d, e)')) == 'foo(a, b, *(list(c) + list(d)), e)'
    assert compile_and_decompile(ast.parse('[a, b, *c, *d, e]')) == '[a, b, *(list(c) + list(d)), e]'

# Generated at 2022-06-21 18:05:28.972903
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    transformer = StarredUnpackingTransformer()
    source = '\n'.join([
        '[2, *range(10), 1, 1, 2]',
    ])
    tree = typed_ast.ast3.parse(source)
    expected = "\n".join([
        "([2] + (list(range(10)) + ([1] + [1] + [2])))",
    ])
    node = tree.body[0]
    new_node = transformer.visit(node)
    assert typed_astunparse.dump(new_node) == expected, "Error in method visit_List of class StarredUnpackingTransformer"


# Generated at 2022-06-21 18:05:36.888668
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test for method visit_List of class StarredUnpackingTransformer"""
    
    func = ast.parse("[2, *range(10), 1]")
    func_new = StarredUnpackingTransformer().visit(func)
    
    if ast.dump(func_new) == \
        "Expr(value=BinOp(left=List(elts=[Num(n=2), List(elts=[])], ctx=Load()), right=BinOp(left=List(elts=[List(elts=[])]), right=List(elts=[Num(n=1)]), op=Add()), op=Add()))":
        return True

# Generated at 2022-06-21 18:05:39.515992
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import compile_and_reload

# Generated at 2022-06-21 18:05:40.622430
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None, None)

# Generated at 2022-06-21 18:05:49.345768
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from .util import clean_ast
    from .test_ast_transformer import test_equal
    xs = [ast3.List(elts=[ast3.Num(n=1), ast3.Starred(value=ast3.Num(n=2)),
                          ast3.Num(n=3)],
                   ctx=ast3.Load()),
          ast3.List(elts=[ast3.Num(n=10), ast3.Starred(value=ast3.Num(n=20)),
                          ast3.Starred(value=ast3.Num(n=30)),
                          ast3.Num(n=40)],
                    ctx=ast3.Load())]

# Generated at 2022-06-21 18:06:01.526812
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .unparse import Unparser
    x = ast.parse('[2, *range(10), 1]')
    # should split list by starred
    list1 = [ast.Num(n=2), ast.Starred(value=ast.Name(id='range(10)'), ctx=ast.Load()), ast.Num(n=1)]
    assert StarredUnpackingTransformer()._split_by_starred(list1) == [[ast.Num(n=2)], ast.Starred(value=ast.Name(id='range(10)'), ctx=ast.Load()), [ast.Num(n=1)]]
    # should add list() to starred

# Generated at 2022-06-21 18:06:03.964222
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    assert isinstance(sut, StarredUnpackingTransformer)

# Generated at 2022-06-21 18:06:14.935404
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert s._has_starred([]) == False
    assert s._has_starred([ast.Starred(value=ast.Num(n=1))]) == True
    assert s._has_starred([ast.Starred(value=ast.Num(n=1)), ast.Starred(value=ast.Num(n=2))]) == True
    assert s._has_starred([ast.Num(n=1), ast.Starred(value=ast.Num(n=2)), ast.Num(n=3)]) == True
    assert s._has_starred([ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]) == False

    assert s._split_by_starred([]) == []
    assert s._split_by_

# Generated at 2022-06-21 18:06:25.630819
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer(None)

    assert sut._has_starred([]) == False
    assert sut._has_starred([ast.Name(id='a')]) == False
    assert sut._has_starred([ast.Name(id='a'), ast.Starred(value=ast.Name(id='a')), ast.Name(id='a')]) == True

    assert sut._split_by_starred([]) == []
    assert sut._split_by_starred([ast.Name(id='a')]) == [[ast.Name(id='a')]]

# Generated at 2022-06-21 18:06:31.840934
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)], ctx=Load()), op=Add()))])"
    node = ast.parse("print(*range(1), *range(3))")