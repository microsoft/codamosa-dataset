

# Generated at 2022-06-21 17:57:21.159697
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as pyast
    from astor import to_source
    from asttokens import ASTTokens
    from .common_utils import compare_ast

    source_1 = '[2, *range(10), 1]'
    source_2 = '[2, *range(10), 1, 1]'
    source_3 = '[2, *range(10), 1, 1, 1]'
    source_4 = '[2, *range(10), 1, 1, 1, 1]'
    source_5 = '[2, *range(10), 1, 1, 1, 1, 1]'
    source_6 = '[2, *range(10), 1, 1, 1, 1, 1, 1]'
    source_7 = '[2, *range(10), 1, 1, 1, 1, 1, 1, 1]'

# Generated at 2022-06-21 17:57:25.603058
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[x, *range(10), y]').body[0].value
    expect = '[x] + list(range(10)) + [y]'
    assert str(StarredUnpackingTransformer().visit(node)) == expect



# Generated at 2022-06-21 17:57:37.347775
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    star = ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load())
    call = ast.Call(func=ast.Name(id='list', ctx=ast.Load()),
                    args=[star],
                    keywords=[])
    lists = ast.List(elts=[call, call], ctx=ast.Load())
    node = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                    args=[star, star],
                    keywords=[])
    result = astor.to_source(ast.fix_missing_locations(node))
    assert result == 'print(*(list(range) + list(range)))'
    result = astor.to_source(ast.fix_missing_locations(lists))

# Generated at 2022-06-21 17:57:47.997345
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)
    assert len(node.value.elts) == 3
    assert isinstance(node.value.elts[0], ast.Num)
    assert node.value.elts[0].n == 2
    assert isinstance(node.value.elts[1], ast.Starred)
    assert isinstance(node.value.elts[1].value, ast.Call)
    assert isinstance(node.value.elts[2], ast.Num)
    assert node.value.elts[2].n == 1

    StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]"))

# Generated at 2022-06-21 17:57:52.373613
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # case1
    StarredUnpackingTransformer()

    # case2
    # Wrong AssertionError
    try:
        StarredUnpackingTransformer()
    except AssertionError:
        assert True

    # case3
    # Wrong AttributeError
    try:
        StarredUnpackingTransformer()
    except AttributeError:
        assert True


# Generated at 2022-06-21 17:58:00.595317
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = ast.parse('print(*range(1), *range(3))')
    tree = StarredUnpackingTransformer().visit(stmt)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Expr)
    # All tests for StarredUnpackingTransformer_visit_Call are here, as
    # StarredUnpackingTransformer_visit_List is empty
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    assert ast.dump(expected) == ast.dump(tree)


# Generated at 2022-06-21 17:58:09.700434
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    ast_v3 = astor.parse_file(open("tests/starred_unpacking_test_cases/visit_List_test.py", "r", encoding="utf-8"))
    from cpython_ast import cpython_ast
    ast_v4 = cpython_ast.convert(ast_v3)
    StarredUnpackingTransformer().visit(ast_v4)
    with open("tests/starred_unpacking_test_results/visit_List_result.py", "r", encoding="utf-8") as file:
        expected_source = file.read()
    actual_source = astor.to_source(ast_v4)
    #print(astor.dump_tree(ast_v4))
    assert expected_source == actual_source


# Generated at 2022-06-21 17:58:15.231493
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")
    actual = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(expected, False) == ast.dump(actual, False)



# Generated at 2022-06-21 17:58:27.959603
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='map', ctx=ast.Load()), args=[ast.Name(id='None', ctx=ast.Load())], keywords=[])
    StarredUnpackingTransformer().visit_Call(node)
    assert node.args == [ast.Name(id='None', ctx=ast.Load())]
    node = ast.Call(func=ast.Name(id='map', ctx=ast.Load()), args=[ast.Starred(value=ast.Name(id='None', ctx=ast.Load()), ctx=ast.Load())], keywords=[])
    StarredUnpackingTransformer().visit_Call(node)

# Generated at 2022-06-21 17:58:36.733754
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse("""
a = 1
y = 2
print(a, *range(5), y)
    """)
    transformer = StarredUnpackingTransformer(module)
    transformed = transformer.visit(module)
    expected_module = ast.parse("""
a = 1
y = 2
print(*(list(range(0, 5)) + [1, 2]), end='')
    """)
    assert ast.dump(transformed) == ast.dump(expected_module)



# Generated at 2022-06-21 17:58:53.638959
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
        x = -1
        print(*range(1), *range(3))
    """

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)

    expected_code = """
        x = -1
        print(*(list(range(1)) + list(range(3))))
    """
    assert ast.unparse(tree) == expected_code


# Generated at 2022-06-21 17:58:59.360891
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compile import compile_code

    assert compile_code("a = [2, *range(10), 1]").co_code == compile_code(
        "a = [2] + list(range(10)) + [1]").co_code


# Generated at 2022-06-21 17:59:07.347000
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'
    expected_code = 'print(*(list(range(1)) + list(range(3))))'

    source_tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    StarredUnpackingTransformer().visit(source_tree)

    for source_node, expected_node in zip(source_tree.body, expected_tree.body):
        assert ast.dump(source_node) == ast.dump(expected_node)



# Generated at 2022-06-21 17:59:18.587466
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestCase:
        def __init__(self, source, expected):
            self.source = source
            self.expected = expected


# Generated at 2022-06-21 17:59:24.800482
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # given
    transformer = StarredUnpackingTransformer()
    # when
    result = transformer.visit_List(ast.parse('[2, *range(10), 1]').body[0])
    # then
    assert ast.dump(result) == ast.dump(ast.parse('[2] + list(range(10)) + [1]').body[0])



# Generated at 2022-06-21 17:59:35.250502
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    my_code = """
        [2, *range(10), 1]
        [2, 3]
        [2, *range(1), 3, *range(2)]
        [2, range(1), *range(2)]
        [2, range(1)]
    """
    expected_code = """
        [2] + list(range(10)) + [1]
        [2, 3]
        [2] + list(range(1)) + [3] + list(range(2))
        [2] + list(range(1)) + list(range(2))
        [2, range(1)]
    """

    from py_mini_racer.transpiler import Transpiler
    t = Transpiler()
    t.register_transformer(StarredUnpackingTransformer)
    t.register_

# Generated at 2022-06-21 17:59:43.656700
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tests = [
        ('print(1)', 'print(1)'),
        ('print(1, *range(1), 2)', 'print(*(list(range(1)) + [2]))')]

    for source, expected in tests:
        node = ast.parse(source, mode='eval')
        trans = StarredUnpackingTransformer()
        new_tree = trans.visit(node)

        assert ast.dump(new_tree) == ast.dump(ast.parse(expected, mode='eval'))
        assert trans.tree_changed is True


# Generated at 2022-06-21 17:59:48.038242
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    assert(isinstance(sut, BaseNodeTransformer))

# Unit tests for _split_by_starred method of StarredUnpackingTransformer

# Generated at 2022-06-21 17:59:52.922965
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse

    code = '[1, *range(5), 2]'
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    unparse(node) == '(1+list(range(5))+2)'



# Generated at 2022-06-21 17:59:56.869300
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_ = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    transformer.visit(ast_)
    ast.fix_missing_locations(ast_)
    exec(compile(ast_, "<ast>", "exec"))
    

# Generated at 2022-06-21 18:00:00.984939
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import base

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    transpiler = StarredUnpackingTransformer()
    base.test_node_transformer(transpiler, code, expected)



# Generated at 2022-06-21 18:00:06.184541
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Arrange
    tree = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("([2] + list(range(10)) + [1])")
    transformer = StarredUnpackingTransformer()

    # Act
    transformed = transformer.visit(tree)

    # Assert
    assert_equals(expected, transformed)


# Generated at 2022-06-21 18:00:13.539341
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .. import visitor
    import astunparse
    node = ast.parse("print(*range(10), *range(1), end='\\n')")
    visitor.visit(node, StarredUnpackingTransformer())
    res = astunparse.unparse(node)
    assert res == "print(*([list(range(10)) + list(range(1))]), end='\\n')", res



# Generated at 2022-06-21 18:00:23.679000
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    original = """\
print(*range(2))
print(*range(2), *range(4))
print(*range(2), 5)
print(*range(2), 5, *range(4))
print(*range(2), 5, 6)
print(*range(2), 5, *range(4), 6)
"""
    tree = astor.parse_tree(original)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)

# Generated at 2022-06-21 18:00:32.157831
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class public:
        _tree_changed = False
    public = public()
    private = StarredUnpackingTransformer(public)
    assert private._has_starred([]) == False
    
    assert private._has_starred([ast.Num(n=1)]) == False
    
    assert private._has_starred([ast.Num(n=1), ast.Starred(value=ast.List(elts=[]))]) == True
    
    assert private._split_by_starred([]) == []
    
    assert private._split_by_starred([ast.Num(n=1)]) == [[ast.Num(n=1)]]
    

# Generated at 2022-06-21 18:00:39.159407
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    example = """print(*range(1), *range(3))"""
    expected = """print(*(list(range(1)) + list(range(3))))"""
    ast_node = ast.parse(example, mode='exec')
    StarredUnpackingTransformer().visit(ast_node)
    assert ast_to_str(ast_node) == expected


# Generated at 2022-06-21 18:00:42.522978
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[0, *range(3)]"
    new_code = StarredUnpackingTransformer().transform_source(code)
    assert new_code == 'list([0]) + list(range(3))'


# Generated at 2022-06-21 18:00:44.588961
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    
    node = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().generic_visit(node)  # type: ignore
    print(node)
    node = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().generic_visit(node)  # type: ignore
    print(node)

# Generated at 2022-06-21 18:00:47.579996
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = '''[2, *range(10), 1]'''
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    code_compiled = compile(tree, '', 'exec')
    assert eval(code_compiled) == [2] + list(range(10)) + [1]
    code = '''print(*range(1), *range(3))'''
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    code_compiled = compile(tree, '', 'exec')
    result = []
    exec(code_compiled, locals(), locals())
    assert result == list(range(4))

# Generated at 2022-06-21 18:00:56.065684
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import roundtrip
    from .unpacking_in_iterable_transformer import UnpackingInIterableTransformer
    from .unpacking_in_except_transformer import UnpackingInExceptTransformer

    tree_str = '[2, *range(10), 1]'
    expected_str = '[2] + list(range(10)) + [1]'

    tree = ast.parse(tree_str)
    tree = StarredUnpackingTransformer().visit(tree)
    tree = UnpackingInIterableTransformer().visit(tree)
    tree = UnpackingInExceptTransformer().visit(tree)
    tree = roundtrip(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected_str))


# Generated at 2022-06-21 18:01:03.336474
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_input = [2, ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), 1]
    expected_output = [2] + list(range(10)) + [1]
    assert StarredUnpackingTransformer().visit(test_input) == expected_output


# Generated at 2022-06-21 18:01:10.102506
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .examples.starred_unpacking import *

# Generated at 2022-06-21 18:01:12.492942
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    node = ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Num(n=2), ctx=ast.Load())])
    t = StarredUnpackingTransformer()
    node = t.visit(node)
    assert isinstance(node, ast.Call)

# Generated at 2022-06-21 18:01:17.256723
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .testing_utils import assert_source_equal
    tree = ast.parse("print(*[1, 2], *range(7), 3)")
    StarredUnpackingTransformer().visit(tree)
    assert_source_equal(tree, "print(*(list([1, 2]) + list(range(7)) + list([3])))")


# Generated at 2022-06-21 18:01:29.504895
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = """\
    package main
    
    import (
        "fmt"
        "reflect"
    )
    
    func main() {
        fmt.Print(reflect.TypeOf((([]int{1} + list(range(10))) + list(range(3)))))
    }
    """

# Generated at 2022-06-21 18:01:39.332408
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .list import ListComprehensionTransformer
    from .tuple import TupleUnpackingTransformer
    from .str import StrTransformer
    from .number import NumberTransformer
    from .call import CallTransformer
    from .name import NameTransformer
    from .binop import BinOpTransformer
    from .boolop import BoolOpTransformer
    from .unaryop import UnaryOpTransformer
    from .compare import CompareTransformer
    from .operator import OperatorTransformer
    from .ifexp import IfExpTransformer
    from .ifexp import IfExprTransformer
    from .comprehension import ComprehensionTransformer
    from .compare import CompareTransformer
    from .docstring import DocstringTransformer
    from .returns import ReturnsTransformer
    from .arguments import ArgumentsTransformer

# Generated at 2022-06-21 18:01:40.430783
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    print(obj)

# Generated at 2022-06-21 18:01:41.461553
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-21 18:01:44.174922
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Todo
    pass


# Generated at 2022-06-21 18:01:54.388892
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    for target_version in (3, 4):
        for unpacking in ((1, 2, 3), (4, 5, 6)):
            for args in ((2, 3, 4), (5, 6, 7)):
                source = "list(%s)(*%s)" % (args[0], unpacking[0])
                expected = "list(%s + %s + ([%s]))" % (
                    args[1],
                    unpacking[1],
                    args[2]
                    )
                assert expected == StarredUnpackingTransformer(target_version).visit(
                    ast.parse("list(%s)(*%s)" % (args[0], unpacking[0])).body[0]).value.s



# Generated at 2022-06-21 18:02:05.105943
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert ast.parse('[2, *range(10), 1]') == StarredUnpackingTransformer().visit(
        ast.parse('[2, *range(10), 1]'))

# Unit tests for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:02:06.810859
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None



# Generated at 2022-06-21 18:02:17.993097
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-21 18:02:27.916276
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    simple_call = ast.Call(func=ast.Name(id='func', ctx=ast.Load()),
                           args=[],
                           keywords=[])
    call_with_starred = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                                 args=[ast.Starred(value=ast.Name(id='elts',
                                                                  ctx=ast.Load()),
                                                   ctx=ast.Load())],
                                 keywords=[])

    assert StarredUnpackingTransformer().visit(simple_call) == simple_call
    assert StarredUnpackingTransformer().visit(call_with_starred) == call_with_starred



# Generated at 2022-06-21 18:02:31.610815
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    transformer = StarredUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-21 18:02:32.747356
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    instance = StarredUnpackingTransformer()

# Generated at 2022-06-21 18:02:41.743079
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import NodeTransformerTestCase
    from .base import apply_transformer

    class Test(NodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_1(self):
            node = ast.parse('x = [2, *range(10), 1]')
            expected = ast.parse('x = [2] + list(range(10)) + [1]')
            self.transformer_test(node, expected)

    apply_transformer(Test)


# Generated at 2022-06-21 18:02:47.049584
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    nodes = ast.parse('[2, *range(10), 1]')
    expected_result = ast.parse('[2] + list(range(10)) + [1]')
    translated_nodes = StarredUnpackingTransformer().visit(nodes)
    assert ast.dump(translated_nodes, include_attributes=False) == ast.dump(expected_result, include_attributes=False)


# Generated at 2022-06-21 18:02:51.944517
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert compile(
        StarredUnpackingTransformer().visit(
            ast.parse("print(*range(1), *range(3))")),
        '<ast>',
        'exec').co_consts[0].elts == [1, 2, 3]



# Generated at 2022-06-21 18:03:01.046602
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from typed_ast.ast3 import parse

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer

# Generated at 2022-06-21 18:03:16.284425
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    te = StarredUnpackingTransformer()
    assert te is not None

# Generated at 2022-06-21 18:03:20.623998
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_data = [
        ("print(1, *range(2))", "print(*([1] + list(range(2))))"),
    ]
    utils.assert_code_equal(StarredUnpackingTransformer, test_data)

# Generated at 2022-06-21 18:03:25.081114
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert tree_equal(tree, '[2] + list(range(10)) + [1]')


# Generated at 2022-06-21 18:03:37.729096
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name(id='print'),
                    args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='args1'))],
                    keywords=[ast.keyword(arg='end', value=ast.Str(s=" ", kind=None)),
                              ast.keyword(arg='file', value=ast.Name(id='file'))])
    
    node = transformer.visit(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == "print"
    assert isinstance(node.args, list) and len(node.args) == 1

# Generated at 2022-06-21 18:03:47.919299
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import typed_astunparse

    class ExpectedNode(ast.AST):
        _fields = ['func', 'args', 'keywords', 'starargs', 'kwargs']
        _attributes = ['lineno', 'col_offset']

        def __init__(self, func, args, keywords, starargs, kwargs, lineno=None, col_offset=None):
            self.func = func
            self.args = args
            self.keywords = keywords
            self.starargs = starargs
            self.kwargs = kwargs
            self.lineno = lineno
            self.col_offset = col_offset

    class ExpectedNode_args(ast.AST):
        _fields = ['body']
        _attributes = []


# Generated at 2022-06-21 18:03:59.851602
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''
        foo(bar, *baz, qux, *quux)
    ''')
    assert type(tree) is ast.Module
    assert len(tree.body) == 1
    assert type(tree.body[0]) is ast.Expr
    assert type(tree.body[0].value) is ast.Call
    assert type(tree.body[0].value.func) is ast.Name
    assert tree.body[0].value.func.id == 'foo'
    assert len(tree.body[0].value.args) == 4
    assert type(tree.body[0].value.args[0]) is ast.Name
    assert tree.body[0].value.args[0].id == 'bar'

# Generated at 2022-06-21 18:04:05.167985
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))')  # type: ast.AST
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')  # type: ast.AST
    uut = StarredUnpackingTransformer()
    result = uut.visit(node)  # type: ast.AST
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-21 18:04:13.817864
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import astor
    from ast_pp.walkers import NodeTransformer

    input_ = 'print(*range(1), *range(3))'
    tree = ast.parse(input_)
    tree = NodeTransformer(StarredUnpackingTransformer()).visit(tree)
    result = astor.to_source(tree).strip()
    expected = 'print(*(list(range(1)) + list(range(3))))'
    assert result == expected



# Generated at 2022-06-21 18:04:23.389154
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    T = StarredUnpackingTransformer(None)
    code = 'foo([2, *range(10), 1])'
    ex = ast.parse(code, mode='exec')
    assert T.visit(ex) == ast.parse('foo(list([2]) + list(range(10)) + [1])', mode='exec')
    assert T.visit(ex).body[0].value.args[0].func.id == 'list'
    assert T.visit(ex).body[0].value.args[1].func.id == 'list'
    assert T.visit(ex).body[0].value.args[2].elts[0].n == 1


# Generated at 2022-06-21 18:04:30.092475
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    source = 'print(2, *range(10), 3, *range(100))'
    transformed = transformer.visit(ast.parse(source))

    expected = 'print(*(list([2, 3]) + list(range(10)) + list(range(100))))'
    assert ast.dump(transformed) == expected

# Generated at 2022-06-21 18:04:49.805686
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    @given(lists(jst.jsn))
    def test(xs):
        source = "[" + ",".join(xs) + "]"
        expected = ast.parse(source).body[0]

        node = StarredUnpackingTransformer().visit(ast.parse("[*" + ",".join(xs) + "]"))
        assert_ast_have_same_structure(node, expected)
    
    test()


# Generated at 2022-06-21 18:04:50.782204
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-21 18:04:58.316474
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    x.visit(ast.parse("[2, *range(10), 1]"))

# Generated at 2022-06-21 18:05:08.885877
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    from ...utils import UnparsePatch, source_to_ast

    args = [ast.Starred(value=ast.Name(id='b'), ctx=ast3.Load())]

    c = source_to_ast("c(1, *b)")
    assert isinstance(c, ast3.Call)
    unpatch = UnparsePatch(astunparse, 'Unparser')
    unpatch()
    wrapper = UnparsePatch(astunparse, 'Unparser')
    wrapper.patch()

    b = StarredUnpackingTransformer().visit(c)
    assert isinstance(b, ast3.Call)
    assert b.args == args

    unpatch.revert()


# Generated at 2022-06-21 18:05:20.287194
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='range'))],
        keywords=[],
    )
    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(n=1)],
                keywords=[])],
            keywords=[]))],
        keywords=[])
    actual = StarredUnpackingTransformer().visit(node)
    assert expected == actual



# Generated at 2022-06-21 18:05:29.347266
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    xs = [2, *range(10), 1]
    n1 = ast.List(elts=[ast.Num(n=2),
                        ast.Starred(value=ast.Call(
                            func=ast.Name(id='range'),
                            args=[ast.Num(n=10)],
                            keywords=[])),
                        ast.Num(n=1)])
    n2 = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)]),
                   right=ast.Call(
                       func=ast.Name(id='list'),
                       args=[ast.Call(
                           func=ast.Name(id='range'),
                           args=[ast.Num(n=10)],
                           keywords=[])],
                       keywords=[]),
                   op=ast.Add())
   

# Generated at 2022-06-21 18:05:35.032432
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""print(*range(1), *range(3))""").body[0]
    # print(ast.dump(node))
    st = StarredUnpackingTransformer()
    st.visit(node)
    # print(ast.dump(node))
    expected = ast.parse("""print(*(list(range(1)) + list(range(3))))""").body[0]
    assert ast.dump(expected) == ast.dump(node)


# Generated at 2022-06-21 18:05:41.125981
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    tree_expected = ast.parse("[2] + list(range(10)) + [1]")
    t = StarredUnpackingTransformer()
    tree_processed = t.visit(tree)
    assert ast.dump(tree_processed) == ast.dump(tree_expected)


# Generated at 2022-06-21 18:05:49.021621
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    FOR_TEST = """
        x = int(10)
        y = [x, x]
        z = [1, *y, 2]
    """
    # above code will be:
    AFTER_TRANSFORM = """
        x = int(10)
        y = [x, x]
        z = [1] + y + [2]
    """

    after_transform_ast = ast.parse(AFTER_TRANSFORM)
    for_test_ast = ast.parse(FOR_TEST)

    StarredUnpackingTransformer().visit(for_test_ast)
    assert ast.dump(after_transform_ast) == ast.dump(for_test_ast)


# Generated at 2022-06-21 18:05:57.189270
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    source = "print(*range(1), *range(3))"
    before = astor.code_to_ast.parse(source)
    before = StarredUnpackingTransformer().transform_tree(before)
    after = astor.code_to_ast.parse("print(*(list(range(1)) + list(range(3))))")
    assert astor.codegen.to_source(before) == astor.codegen.to_source(after)


# Generated at 2022-06-21 18:06:34.655905
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    cls = StarredUnpackingTransformer
    cls.nodes = []
    lines = ['[2, *range(10), 1]', 'print(*range(1), *range(3))']
    for line in lines:
        node = ast.parse(line)
        cls.visit(node)
        assert cls.nodes == [node]
        cls.nodes = []


# Generated at 2022-06-21 18:06:38.622396
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("test_StarredUnpackingTransformer")
    source = "[2, *range(10), 1]\n"
    expected = "[2] + list(range(10)) + [1]\n"
    code = StarredUnpackingTransformer().transform_source(source)
    assert code == expected

    source = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"
    code = StarredUnpackingTransformer().transform_source(source)
    assert code == expected

# Generated at 2022-06-21 18:06:44.232974
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.target == (3, 4)
    x = StarredUnpackingTransformer()
    assert isinstance(x, BaseNodeTransformer)
    assert x.target == (3, 4)



# Generated at 2022-06-21 18:06:52.249932
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .helpers import parse, dump

    node = parse("print(*range(1), *range(3))")
    dump(node)
    obj = StarredUnpackingTransformer()
    node = obj.visit(node)
    dump(node)
    assert node.body[0].value.args[0].value.elts[0].elts[0].value.value.id == 'range'
    assert node.body[0].value.args[0].value.elts[1].elts[0].value.value.id == 'range'


# Generated at 2022-06-21 18:06:58.730940
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Method visit_Call of class StarredUnpackingTransformer must properly handle """
    """calls with starred arguments."""
    node = ast.parse("print(*range(1), *range(3))").body[0]

# Generated at 2022-06-21 18:07:06.989968
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_program_1 = '''
[2, *range(10), 1]
    '''
    expected_program_1 = '''
[2] + list(range(10)) + [1]
    '''
    actual_program_1 = StarredUnpackingTransformer(verbose=False).visit(ast.parse(test_program_1))
    assert astor.to_source(actual_program_1) == expected_program_1

    test_program_2 = '''
[*range(10), 1, 2, *range(3), *range(1)]
    '''
    expected_program_2 = '''
list(range(10)) + [1] + [2] + list(range(3)) + list(range(1))
    '''
    actual_program_2 = StarredUnpackingTrans