

# Generated at 2022-06-23 22:59:10.386755
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-23 22:59:14.015866
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert "print(*(list(range(1)) + list(range(3))))" == (
        astor.to_source(StarredUnpackingTransformer().visit(
            ast.parse("print(*range(1), *range(3))").body[0]))
        )



# Generated at 2022-06-23 22:59:24.142906
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class StarredUnpackingTransformer_visit_List_TestCase(unittest.TestCase):
        def test_simple(self):
            tree = compile(
                textwrap.dedent("""
                [2, *range(10), 1]
                """),
                filename='<test>',
                mode='exec')
            StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 22:59:33.650213
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTest
    from .base import check_transformer

    class StarredUnpackingTransformerTest(BaseNodeTest):
        transform = StarredUnpackingTransformer

        def test_no_starring(self):
            tree = self.parse("""
            [1, 2, 3]
            """)
            transformed = self.transform(tree)
            self.assertAST(transformed, """
            [1, 2, 3]
            """)

        def test_starring_at_the_end(self):
            tree = self.parse("""
            [1, 2, 3, *range(10)]
            """)
            transformed = self.transform(tree)
            self.assertAST(transformed, """
            [1, 2, 3] + list(range(10))
            """)


# Generated at 2022-06-23 22:59:44.776894
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print("\nStarredUnpackingTransformer.visit_Call")
    source = """\
    func()
    func(1, 2, 3)
    func(*range(5))
    func(*range(5), *range(4), *range(7))
    func(*range(5), *range(4), 1, *range(7), *range(3))
    """
    expected = """\
    func()
    func(1, 2, 3)
    func(*list(range(5)))
    func(*(list(range(5)) + list(range(4)) + list(range(7))))
    func(*(list(range(5)) + list(range(4)) + [1] + list(range(7)) + list(range(3))))
    """
    tree = ast.parse(source)
    Starred

# Generated at 2022-06-23 22:59:50.435230
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4) and \
           isinstance(StarredUnpackingTransformer(None)._split_by_starred([ast.Starred(value=ast.Name(id='a'))]), list) and \
           isinstance(StarredUnpackingTransformer(None)._split_by_starred([ast.Name(id='a')]), list)

# Generated at 2022-06-23 23:00:00.586412
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[ast.Constant(2), ast.Starred(ast.Call(ast.Name(id="range"), [ast.Constant(10)], []), ast.Load()), ast.Constant(1)])
    node = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:00:09.713318
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest
    import textwrap
    import ast as pyast
    from compile.compile import compile as py_compile
    from compile.transformer.starred_unpacking import StarredUnpackingTransformer

    class TestStarredUnpackingTransformer_visit_Call(unittest.TestCase):
        """Test method visit_Call of class StarredUnpackingTransformer"""

        def __init__(self, *args):
            super().__init__(*args)

            self.transformer = StarredUnpackingTransformer()

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_simple(self):
            """Simple example"""


# Generated at 2022-06-23 23:00:11.497462
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
	transformer = StarredUnpackingTransformer()
	print("Unit test for constructor of class StarredUnpackingTransformer")

# Generated at 2022-06-23 23:00:14.777807
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    #check if the class is initialized correctly
    assert(isinstance(a, StarredUnpackingTransformer))



# Generated at 2022-06-23 23:00:25.025855
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer()(node)

# Generated at 2022-06-23 23:00:29.513126
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert(ast.dump(StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]').body[0]),
                    annotate_fields=False, include_attributes=False) == \
            ast.dump(ast.parse('[2] + list(range(10)) + [1]').body[0],
                    annotate_fields=False, include_attributes=False))


# Generated at 2022-06-23 23:00:37.816913
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    value = ast.parse("[2, *range(10), 1]")

    assert isinstance(value, ast.Module)
    assert isinstance(value.body[0], ast.Expr)
    assert isinstance(value.body[0].value, ast.List)
    assert isinstance(value.body[0].value.elts[1], ast.Starred)

    result = sut.visit(value)
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.BinOp)

# Generated at 2022-06-23 23:00:41.055903
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('print(*range(1), *range(3))')
    node = transformer.visit(node)
    assert_equal(
        "print(*(list(range(1)) + list(range(3))))",
        astor.to_source(node)
    )



# Generated at 2022-06-23 23:00:48.675325
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    given_ast_source = "[2, *range(10), 1]"
    expected_ast_source = "[2] + list(range(10)) + [1]"
    given_node = ast.parse(given_ast_source)
    expected_node = ast.parse(expected_ast_source)

    actual_node = StarredUnpackingTransformer().visit(given_node)

    assert ast.dump(expected_node) == ast.dump(actual_node)


# Generated at 2022-06-23 23:01:00.037502
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from transformator.AST_walker import TreeWalker
    from typed_ast import ast3

    s = ast.parse("[2, *range(10), 1]")
    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
        To:
            [2] + list(range(10)) + [1]
        """
        target = (3, 4)

        def _has_starred(self, xs: List[ast3.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast3.Starred):
                    return True

            return False


# Generated at 2022-06-23 23:01:03.768991
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert StarredUnpackingTransformer().visit(ast.parse("print(1, *range(1), *range(2))")) == \
           ast.parse("print(*([1] + list(range(1)) + list(range(2))))")

# Generated at 2022-06-23 23:01:07.748899
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'
    expected_result = \
        "print(*(list(range(1)) + list(range(3))))"

    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    tranformed_tree = transformer.visit(tree)

    assert transformer._tree_changed is True
    assert ast.dump(tranformed_tree) == expected_result


# Generated at 2022-06-23 23:01:13.114381
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:01:17.390404
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    inp = ast.parse(
        'def foo():\n'
        '    [2, *range(10), 1]\n'
        '    print(*range(1), *range(3))')
    out = ast.parse(
        'def foo():\n'
        '    [2] + list(range(10)) + [1]\n'
        '    print(*(list(range(1)) + list(range(3))))')
    assert ast.dump(StarredUnpackingTransformer().visit(inp)) == ast.dump(out)



# Generated at 2022-06-23 23:01:27.068606
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import inspect
    from ast_unparse import unparse
    from transformer import StarredUnpackingTransformer
    from ast_helper import dump_ast, get_parent

    # print(*range(1), *range(3))
    source = inspect.getsource(test_StarredUnpackingTransformer_visit_Call)
    tree = ast.parse(source)
    call_node = tree.body[1].body[0].value
    assert isinstance(call_node, ast.Expr)
    assert isinstance(call_node.value, ast.Call)
    call_node = call_node.value
    parent = get_parent(tree, call_node)

    print("Original Call:")
    print(unparse(call_node))

# Generated at 2022-06-23 23:01:28.984414
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_tree = ast.parse('''foo(*args, **kwargs)''')
    StarredUnpackingTransformer().visit(ast_tree)

# Generated at 2022-06-23 23:01:33.678744
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("func1(1, 2, *range(3), 4, *range(5))")
    result = transformer.visit(node)

    expect = ast.parse("func1(*(list([1, 2]) + list(range(3)) + list([4]) + list(range(5))))")
    assert ast.dump(result) == ast.dump(expect)


# Generated at 2022-06-23 23:01:44.699467
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.tests.test_unparse import unparse
    from textwrap import dedent
    from tatsu.util import asjson
    import doctest

    # AST with list arguments / list
    module = ast.parse(dedent("""
        [2, *range(10), 1]
        [2, *range(10)]
        [2, *range(10), *range(2), 3]
        [2] + list(range(10)) + [1]
        [2] + list(range(10))
        [2] + list(range(10)) + list(range(2)) + [3]
        """))

    # Test 1:
    # Test AST
    transformer = StarredUnpackingTransformer()
    module = transformer.visit(module)
   

# Generated at 2022-06-23 23:01:51.481362
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    Unpack args, kwargs but not starargs
    """
    code = "test = Call(args=['a', 'b', 'c'], kwargs={'a': 'b', 'c': 'd'}, starargs=['a', 'b', 'c', 'd'])"
    expected = "test = Call(args=['a', 'b', 'c'], kwargs={'a': 'b', 'c': 'd'}, starargs=['a', 'b', 'c', 'd'])"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert code_gen.to_source(tree) == expected


# Generated at 2022-06-23 23:01:58.686338
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    l = ast.parse('print(*range(1), *range(3))')
    t.visit(l)
    assert t.changed
    assert ast.dump(l) == 'Module(body=[Print(dest=None, values=[Call(func=Name(id="print", ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Call(func=Name(id="range", ctx=Load()), args=[Num(n=1)], keywords=[])], ctx=Load()), op=Add(), right=List(elts=[Call(func=Name(id="range", ctx=Load()), args=[Num(n=3)], keywords=[])], ctx=Load())])), keywords=[])], nl=True)])'

# Unit

# Generated at 2022-06-23 23:02:07.862024
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), 3)")
    node = tree.body[0].value
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.Call)
    node.args
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Starred)

    t = StarredUnpackingTransformer()
    result = t.visit(node)
    assert isinstance(result, ast.Call)
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.Call)
    result = result.args[0].value
    assert isinstance(result.func, ast.Name)
   

# Generated at 2022-06-23 23:02:18.194571
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:27.812347
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .sample_asts import (
        m1_1_2, m1_1_3, m1_4, m1_4_1, m1_4_2, m1_4_3, m1_4_4
    )
    from .. import compile

    assert compile(m1_1_2) == compile(StarredUnpackingTransformer(ast.parse(m1_1_2)).visit(ast.parse(m1_1_2)))
    assert compile(m1_1_3) == compile(StarredUnpackingTransformer(ast.parse(m1_1_3)).visit(ast.parse(m1_1_3)))

# Generated at 2022-06-23 23:02:36.333847
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ast_toolbox import ast_to_source
    from typed_ast import ast3 as ast

    expected = """\
[2] + list(range(10)) + [1]
""".strip()

    node = ast.parse("[2, *range(10), 1]").body[0]
    t = StarredUnpackingTransformer()
    node = t.visit(node)

    source = ast_to_source(node)
    assert source == expected


if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:02:42.185603
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(stmt)
    StarredUnpackingTransformer().visit(tree)
    result = compile(tree, '', 'exec')
    assert result == expected, '%r != %r' % (result, expected)


# Generated at 2022-06-23 23:02:52.680320
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typing
    import astunparse
    import astor
    # Test 1
    input_ast = ast.parse("ans = [2, *range(10), 1]")
    test_StarredUnpackingTransformer = StarredUnpackingTransformer()
    actual = ast.dump(test_StarredUnpackingTransformer.visit(input_ast))

# Generated at 2022-06-23 23:02:59.585797
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    source = 'print(*range(1), *range(3))'
    expected = \
"""print(*(list(range(1)) + list(range(3))))"""

    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-23 23:03:08.942894
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
a = [1, *range(1), *range(0)]
"""
    expected = """
a = [1] + list(range(1)) + list(range(0))
"""
    node = ast.parse(source)
    result = StarredUnpackingTransformer().visit(node)
    result_code = compile(result, '<test>', 'exec')
    globals_ = {}
    locals_ = {}
    exec(result_code, globals_, locals_)
    assert expected == ast.unparse(result)
    assert [1] + list(range(1)) + list(range(0)) == locals_['a']


# Generated at 2022-06-23 23:03:17.026059
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import textwrap
    from .base import BaseNodeTransformerTestCase
    from .unpacking_transformer import StarredUnpackingTransformer
    
    class Test(BaseNodeTransformerTestCase):
        @property
        def input_code(self):
            return textwrap.dedent('''\
                print(*range(1), *range(3))
            ''')
        
        @property
        def expected_code(self):
            return textwrap.dedent('''\
                print(*(list(range(1)) + list(range(3))))
            ''')
        
        def get_transformer(self):
            return StarredUnpackingTransformer()
    
    Test().assert_expected()


# Generated at 2022-06-23 23:03:28.023734
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .utils import compile_to_code
    single_list = StarredUnpackingTransformer([ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])])
    assert(compile_to_code(single_list) == '[1, 2, 3]')
    repeate_list = StarredUnpackingTransformer([ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Starred(value=ast.List(elts=[ast.Num(n=3), ast.Num(n=4), ast.Num(n=5)])), ast.Num(n=6)])])

# Generated at 2022-06-23 23:03:33.792164
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = ast.parse("print(range(1), range(3), *[1.1, 1.2, *range(9)])")
    actual = StarredUnpackingTransformer().visit(ast.parse(
        "print(*range(1), *range(3), 1.1, 1.2, *range(9))"))
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-23 23:03:35.899360
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    obj.target = (3, 4) 
    assert repr(obj) == ("StarredUnpackingTransformer(target=(3, 4))")

# Generated at 2022-06-23 23:03:44.007859
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
        print(*range(1), *range(3))
        print(*range(1), *range(3), sep=' ', end='\\n')
    """

    expected = """
        print(*(list(range(1)) + list(range(3))))
        print(*(list(range(1)) + list(range(3))), sep=' ', end='\\n')
    """

    transpiled, _ = StarredUnpackingTransformer().transpile(code)
    assert transpiled == expected


# Generated at 2022-06-23 23:03:53.589655
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:03:56.729326
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    program = [ast.List(elts=[]), ast.Call(func=ast.Name(id='print'), args=[], keywords=[])]
    StarredUnpackingTransformer(program).get_tree()

# Generated at 2022-06-23 23:03:57.741247
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:04.814216
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_input = 'print(5, *range(10), 3)'
    expected_output = 'print(*(list([5]) + list(range(10)) + list([3])))'
    test_output = StarredUnpackingTransformer().transform(test_input)
    assert test_output == expected_output

    assert not StarredUnpackingTransformer().transform("print('lol')")
    assert StarredUnpackingTransformer().transform("print('lol', *range(10), 'end')") == "print(*(list(['lol']) + list(range(10)) + list(['end'])))"

# Generated at 2022-06-23 23:04:17.240877
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(node)
    StarredUnpackingTransformer().visit(node)
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:04:27.238957
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(None)
    expected_output = ast.List(elts=[])

    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(ast.List(elts=[ast.Starred(value=ast.Num(n=1), ctx=ast.Load())]))
    expected_output = ast.Call(func=ast.Name(id='list'), args=[ast.Num(n=1)], keywords=[])

    node_transformer = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:28.828371
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:04:35.509261
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformers_test import _transform
    node = ast.parse('[1, *range(4), 2, *range(5)]')
    assert node == ast.parse('[1, 2] + list(range(4)) + [2] + list(range(5))')
    assert _transform(StarredUnpackingTransformer, '[1, *range(4), 2, *range(5)]') == '[1, 2] + list(range(4)) + [2] + list(range(5))'


# Generated at 2022-06-23 23:04:36.127503
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert True

# Generated at 2022-06-23 23:04:41.178726
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]').body[0]) == ast.parse('[2] + list(range(10)) + [1]').body[0]
    assert StarredUnpackingTransformer().visit(ast.parse('print(*range(1), *range(3))').body[0]) == ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]


# Generated at 2022-06-23 23:04:51.552216
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('''
        print(*range(1), *range(2))
        ''').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    new_node = transformer.visit_Call(node.value)
    assert isinstance(new_node, ast.Call)
    assert new_node.args
    assert isinstance(new_node.args[0], ast.Starred)
    assert isinstance(new_node.args[0].value, ast.BinOp)
    assert isinstance(new_node.args[0].value.left, ast.Call)
    assert isinstance(new_node.args[0].value.right, ast.Call)

# Generated at 2022-06-23 23:05:01.114634
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    code = '[2, *range(10), 1]'
    t = StarredUnpackingTransformer()
    tree = ast.parse(code)
    t.visit(tree)
    expected = '([2] + list(range(10)) + [1])'
    assert astor.to_source(tree) == expected

    code = '[*range(10), 2, 3, *range(4)]'
    t = StarredUnpackingTransformer()
    tree = ast.parse(code)
    t.visit(tree)
    expected = '(list(range(10)) + [2, 3] + list(range(4)))'
    assert astor.to_source(tree) == expected


# Generated at 2022-06-23 23:05:08.521579
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    ast_node = ast.parse("sort_f(*range(1), *range(3))")
    assert str(ast_node) == "sort_f(*range(1), *range(3))"
    transformed_ast_node = transformer.visit(ast_node)
    assert str(transformed_ast_node) == "sort_f(*(list(range(1)) + list(range(3))))"


# Generated at 2022-06-23 23:05:09.937326
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert str(s) == '<StarredUnpackingTransformer>'

# Generated at 2022-06-23 23:05:13.741611
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    _code = '''
[2, *range(10), 1]
'''
    _expected_code = '''
[2] + list(range(10)) + [1]
'''
    _tree = ast.parse(_code)
    StarredUnpackingTransformer().visit(_tree)
    assert ast.dump(_tree) == _expected_code


# Generated at 2022-06-23 23:05:16.899890
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


if __name__ == '__main__':
    import pytest, sys
    pytest.main(sys.argv)

# Generated at 2022-06-23 23:05:23.102198
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer.run_on_tree(tree)
    expected = ast.parse(
        '[2] + list(range(10)) + [1]'
    )
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-23 23:05:26.196731
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert isinstance(transformer, StarredUnpackingTransformer)


# Generated at 2022-06-23 23:05:31.308350
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_input = """
    print(1, 2, 3, *[4, 5], 6, 7, 8, *[9, 10], 11, 12)
    """
    test_output = """
    print(*(list([1, 2, 3]) + list([4, 5]) + list([6, 7, 8]) + list([9, 10]) + list([11, 12])))
    """

    from . import generate_code
    assert generate_code(test_input, StarredUnpackingTransformer) == test_output


# Generated at 2022-06-23 23:05:37.922095
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    assert 'VAR' == ast.parse('VAR').body[0].name  # sanity check
    assert isinstance(ast.parse('VAR').body[0], ast.AnnAssign)  # sanity check
    assert StarredUnpackingTransformer().visit(
        ast.parse('a = VAR')).body[0].name == 'a'  # sanity check

# Generated at 2022-06-23 23:05:43.952215
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_util import parse

    source = "[2, *range(10), 1]"
    transform = StarredUnpackingTransformer(parse(source))
    expected = "[2] + list(range(10)) + [1]"
    actual = transform.get_output()

    assert actual == expected

    source = "[2, *range(10), 1, 4]"
    transform = StarredUnpackingTransformer(parse(source))
    expected = "[2] + list(range(10)) + [1, 4]"
    actual = transform.get_output()

    assert actual == expected

    source = "[2, *range(10), 1, 3, *range(4)]"
    transform = StarredUnpackingTransformer(parse(source))

# Generated at 2022-06-23 23:05:50.865659
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    s = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    node = ast.parse(s)
    tr = StarredUnpackingTransformer()
    tr.visit(node)
    assert astor.to_source(node) == expected

    s = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"
    node = ast.parse(s)
    tr = StarredUnpackingTransformer()
    tr.visit(node)
    assert astor.to_source(node) == expected

    s = "tuple([2, 3, 4])"
    expected = "tuple([2, 3, 4])"

# Generated at 2022-06-23 23:05:57.176803
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import source_to_code

    trans = StarredUnpackingTransformer()
    node = source_to_code("""
    print(*range(1), *range(3))
    """)

    transformed_node = trans.visit(node)

    assert(source_to_code(transformed_node) == """
    print(*(list(range(1)) + list(range(3))))
    """)


# Generated at 2022-06-23 23:06:06.743596
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class_instance = StarredUnpackingTransformer()
    List1 = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)], ctx=None)
    List2 = ast.List(elts=[ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[])), ast.Num(n=1)], ctx=None)
    List3 = ast.List(elts=[ast.Starred(value=ast.Name(id='a')), ast.Num(n=1)], ctx=None)

    List1_transformed = class_instance.vis

# Generated at 2022-06-23 23:06:13.610503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    print('Unit test for method visit_Call of class StarredUnpackingTransformer')
    code = 'print(*range(1), *range(2))'
    print('INPUT CODE:')
    print(code)
    print()
    tree = compile(code, '', 'exec', ast.PyCF_ONLY_AST)
    print('INPUT TREE:')
    print(astunparse.unparse(tree))
    print()
    result = StarredUnpackingTransformer().visit(tree)
    print('OUTPUT TREE:')
    print(astunparse.unparse(result))


# Generated at 2022-06-23 23:06:23.401821
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import dump, parse
    obj = StarredUnpackingTransformer()
    node = parse('''[2, *range(10), 1]''')
    result = obj.visit(node)
    assert dump(result) == "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(func=Name(id='list'), args=[Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))])"


# Generated at 2022-06-23 23:06:28.282250
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import parse
    t = StarredUnpackingTransformer()
    n = parse('[1, 2, *range(3), 4]')
    result = t.visit(n)
    expected = parse('[1, 2] + list(range(3)) + [4]')

    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 23:06:35.124545
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    actual = '''
print(*range(1), *range(3))
    '''
    expected = '''
print(*(list(range(1)) + list(range(3))))
    '''

    parser = ast.parse(actual)
    expected_parser = ast.parse(expected)

    StarredUnpackingTransformer().visit(parser)

    assert ast.dump(parser) == ast.dump(expected_parser), "Failed test"



# Generated at 2022-06-23 23:06:37.304465
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tr = StarredUnpackingTransformer()
    _ = tr  # for pyflakes


# Generated at 2022-06-23 23:06:47.188424
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test method StarredUnpackingTransformer.visit_List"""
    node = ast.parse('[2, *range(10), 1]')
    trans = StarredUnpackingTransformer()
    result = trans.visit(node).body[0].value

# Generated at 2022-06-23 23:06:57.496655
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 1).target == (3, 4)
    assert StarredUnpackingTransformer(3, 5).target == (3, 7)
    assert StarredUnpackingTransformer(3, 6).target == (3, 7)
    assert StarredUnpackingTransformer(3, 7).target == (3, 8)
    assert StarredUnpackingTransformer(3, 8).target == (3, 9)
    assert StarredUnpackingTransformer(3, 9).target == (3, 10)
    assert StarredUnpackingTransformer(3, 10).target == (3, 10)
    assert StarredUnpackingTransformer(3, 11).target == (3, 11)
    assert StarredUnpackingTransformer(3, 12).target == (3, 11)



# Generated at 2022-06-23 23:07:09.465823
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import check_transform

    tree = """a = [1, 2, *b, 3, *c]"""
    expected = """a = [1, 2] + list(b) + [3] + list(c)"""
    check_transform(StarredUnpackingTransformer, tree, expected)

    tree = """a = [1, 2, *b, 3, *c, *d]"""
    expected = """a = [1, 2] + list(b) + [3] + list(c) + list(d)"""
    check_transform(StarredUnpackingTransformer, tree, expected)

    tree = """a = [1, 2, 3, *b]"""
    expected = """a = [1, 2, 3] + list(b)"""

# Generated at 2022-06-23 23:07:19.726833
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer()


# Generated at 2022-06-23 23:07:30.621853
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:07:40.367874
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    t = StarredUnpackingTransformer()
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Name(id='range'),
                ctx=ast.Load()
            ),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[
                        ast.Num(n=3)
                    ],
                    keywords=[]
                ),
                ctx=ast.Load()
            )
        ],
        keywords=[])
    processed = t.visit(node)

# Generated at 2022-06-23 23:07:51.727211
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:08:02.042096
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(ast.parse("[2, *range(10), 1]")) == ast.parse("[2] + list(range(10)) + [1]")
    assert transformer.visit(ast.parse("[2, *range(10), 1]")) == ast.parse("[2] + list(range(10)) + [1]")
    assert transformer.visit(ast.parse("[1, 2, 3]")) == ast.parse("[1, 2, 3]")
    assert transformer.visit(ast.parse("[1, *range(4)]")) == ast.parse("[1] + list(range(4))")

# Generated at 2022-06-23 23:08:11.798810
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.parse("fn(1, *[2, 3], 4)").body[0]
    assert ast.dump(StarredUnpackingTransformer().visit(node)) == \
        "Call(func=Name(id='fn', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Num(n=1), Num(n=4)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[List(elts=[Num(n=2), Num(n=3)], ctx=Load())], keywords=[]), op=Add()))], keywords=[])"



# Generated at 2022-06-23 23:08:18.480239
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    # Test StarredUnpackingTransformer._has_starred()
    test_body = '''
        s = Str(args=[Str(s='f')])
        x = Str(args=[Str(s='f')])
        print(x)
    '''
    test_body_ast = ast.parse(test_body)
    output_body_ast = ast.parse(test_body)
    StarredUnpackingTransformer().visit_Call(test_body_ast.body[1].value)
    assert ast.dump(output_body_ast) == ast.dump(test_body_ast)

    # Test StarredUnpackingTransformer._split_by_starred()
    test_body = '''
        print(x, *range(10), 1)
    '''
    test_body_

# Generated at 2022-06-23 23:08:20.092173
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None) is not None


# Generated at 2022-06-23 23:08:30.941528
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ._transform_unittest import TransformTestCase

    class Test(TransformTestCase):
        target_cls = StarredUnpackingTransformer

        def test_starred_unpacking(self):
            self.assertEqual(
                """
                [2, *range(10), 1]
                """,
                """
                [2] + list(range(10)) + [1]
                """,
            )

        def test_empty(self):
            self.assertEqual(
                """
                []
                """,
                """
                []
                """,
            )


# Generated at 2022-06-23 23:08:31.983362
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    raise NotImplementedError()


# Generated at 2022-06-23 23:08:40.442745
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._split_by_starred([]) == [[]]
    assert StarredUnpackingTransformer()._split_by_starred([ast.Starred(value=ast.Num(10))]) == [[], ast.Starred(value=ast.Num(10)), []]
    assert StarredUnpackingTransformer()._split_by_starred([ast.Num(1), ast.Starred(value=ast.Num(10)), ast.Num(15), ast.Starred(value=ast.Num(20)), ast.Num(25)]) == [[ast.Num(1)], ast.Starred(value=ast.Num(10)), [ast.Num(15)], ast.Starred(value=ast.Num(20)), [ast.Num(25)]]
    assert StarredUnpackingTransformer()._split_by

# Generated at 2022-06-23 23:08:46.024703
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from grako.contexts import ParseContext
    from grako.codegen import codegen, StarredUnpackingTransformer, ModuleTransformer
    from grako.test.test_util import TestCase

    rule_expr = 'x * y * z'
    grammar = r'''
        rule<int> = rule_expr

        rule_expr
            = x:INT '*' y:INT '*' z:INT '*' rest:(. rule_expr)?
            {
                print(x, y, z, rest)
            }
            ;
    '''

    class StarredTransformer(StarredUnpackingTransformer):
        def __init__(self):
            super(StarredTransformer, self).__init__()
            self._code = None


# Generated at 2022-06-23 23:08:50.130743
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    m = ast.parse('[2, *range(10), 11]')
    StarredUnpackingTransformer().visit(m)
    assert ast.dump(m) == ast.dump(ast.parse('[2] + list(range(10)) + [11]'))


# Generated at 2022-06-23 23:08:52.219108
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:09:03.385410
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('test_StarredUnpackingTransformer_visit_Call')
    from typed_ast import ast3 as ast

    stmt = ast.parse('print(1, *range(3), 7, *range(10))')
    assert isinstance(stmt, ast.Module)

    assert len(stmt.body) == 1
    assert isinstance(stmt.body[0], ast.Expr)
    assert isinstance(stmt.body[0].value, ast.Call)

    t = StarredUnpackingTransformer()
    stmt = t.visit(stmt)

    assert len(stmt.body) == 1
    stmts_body0_value = stmt.body[0].value
    assert isinstance(stmts_body0_value, ast.Call)


# Generated at 2022-06-23 23:09:06.016727
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typing import cast
    from typed_ast import ast3 as ast
    from typed_ast import annotatedast as aast


# Generated at 2022-06-23 23:09:17.361014
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert list(StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]'))) == [
        ast.Expr(
            value=ast.BinOp(
                left=ast.BinOp(
                    left=ast.List(
                        elts=[ast.Num(n=2)]),
                    right=ast.Call(
                        func=ast.Name(id='list'),
                        args=[ast.Call(
                            func=ast.Name(id='range'),
                            args=[ast.Num(n=10)],
                            keywords=[])],
                        keywords=[]),
                    op=ast.Add()),
                right=ast.List(elts=[ast.Num(n=1)]),
                op=ast.Add()))]

