

# Generated at 2022-06-23 22:59:19.390226
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse(
        "print([2, *range(10), 1])")
    print(ast.dump(tree, include_attributes=False))
    StarredUnpackingTransformer().visit(tree)
    print(ast.dump(tree, include_attributes=False))



# Generated at 2022-06-23 22:59:24.807015
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import to_source
    node = ast.parse('[2, *range(10), 1]')
    expected_node = ast.parse('[2] + list(range(10)) + [1]')
    t = StarredUnpackingTransformer()
    result = t.visit(node)
    print(to_source(result))
    assert result == expected_node


# Generated at 2022-06-23 22:59:29.900219
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_function

    def f():
        return [2, *range(10), 1]

    assert f() == [2, *range(10), 1]

    f_compiled = compile_function(StarredUnpackingTransformer().visit, f)

    assert f_compiled() == [2, *range(10), 1]


# Generated at 2022-06-23 22:59:35.279727
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
	input_tree = parser.parse('[2, *range(10), 1]')

	expected_tree = parser.parse('[2] + list(range(10)) + [1]')
	actual_tree = StarredUnpackingTransformer().visit(input_tree)

	assert astor.to_source(expected_tree) == astor.to_source(actual_tree)


# Generated at 2022-06-23 22:59:46.651963
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("print(*range(1), *range(3))").body[0]

    result = transformer.visit_Call(node)


# Generated at 2022-06-23 22:59:54.120493
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from .transformer_testing import assert_code_equal

    tree = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree)
    assert_code_equal(tree,'print(*(list(range(1)) + list(range(3))))')

    tree = ast.parse('print(*range(1))')
    StarredUnpackingTransformer().visit(tree)
    assert_code_equal(tree,'print(*(list(range(1))))')


# Generated at 2022-06-23 22:59:55.569339
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()

    assert a is not None


# Generated at 2022-06-23 23:00:00.491788
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .helper import get_ast, compare_asts, run_local_tests
    from .python_org_examples import EXAMPLES

    for key, value in EXAMPLES.items():
        tree = get_ast(value)
        StarredUnpackingTransformer().visit(tree)
        compare_asts(tree, get_ast(value))

    run_local_tests()

# Generated at 2022-06-23 23:00:06.132635
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast as pyast
    src = """
[2, *range(10), 1]
print(*range(1), *range(3))
"""
    tree = pyast.parse(src)
    tree = StarredUnpackingTransformer().visit(tree)
    assert pyast.unparse(tree) == """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
"""

# Generated at 2022-06-23 23:00:17.115814
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:18.032431
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:21.814348
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import apply_transformer
    code = '''
    [2, *range(10), 1]
    '''
    new_code = '''
    [2] + list(range(10)) + [1]
    '''
    assert apply_transformer(StarredUnpackingTransformer, code) == new_code


# Generated at 2022-06-23 23:00:27.511761
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from codetransformer.ast_compiler import CodeTransformer
    pycode = (
        "print(1, *range(3), *range(4), sep=';')"
    )
    code = pyast.parse(pycode, mode='exec')
    expected_code = (
        "print(*(list(range(1)) + list(range(3)) + list(range(4))), sep=';')"
    )
    expected = pyast.parse(expected_code, mode='exec')
    transformer = CodeTransformer(StarredUnpackingTransformer)
    transformed = transformer.visit(code)
    assert pyast.dump(expected) == pyast.dump(transformed)


# Generated at 2022-06-23 23:00:35.336351
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    from typed_ast import ast3 as pyscript_ast
    from .standart_transformer import StandartTransformer
    pyast_node = pyast.Call(func=pyast.Name(id='print'),
                            args=[pyast.Starred(value=pyast.List(elts=[pyast.Name(id='a'),
                                                                       pyast.Starred(value=pyast.Name(id='b'))],
                                                                 ctx=pyast.Load()),
                                                  ctx=pyast.Load())],
                            keywords=[])

# Generated at 2022-06-23 23:00:42.980333
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import typing
    from nodetranspiler.compiler import NodeTranspiler

    ast_before = ast.parse(
        'print(*range(5), *range(3), "hello", *range(1))')
    ast_after = ast.parse(
        'print(*(list(range(5)) + list(range(3)) + ["hello"] + list(range(1))))')

    t = NodeTranspiler()
    compiled_ast = t.compile_ast(ast_before, processors=[
                                 StarredUnpackingTransformer])
    assert ast.dump(ast_after) == ast.dump(compiled_ast)
    assert typing.get_type_hints(t.compile_func(ast_before, [
                                 StarredUnpackingTransformer])) == typing.get_type_h

# Generated at 2022-06-23 23:00:54.511348
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:59.139089
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_ = StarredUnpackingTransformer()
    assert class_.__class__ == StarredUnpackingTransformer
    assert isinstance(class_, StarredUnpackingTransformer)
    assert isinstance(class_, BaseNodeTransformer)
    assert class_.target == (3, 4)

# Generated at 2022-06-23 23:01:09.315044
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast_typed_transformer.transformer import BaseNodeTransformer
    from ast_typed_transformer.library.base import BaseNodeTransformer
    from ast_typed_transformer.transformer.__main__ import PyTypedTransformer
    from ast_typed_transformer.library.base import BaseNodeTransformer

    code = "[2, *range(10), 1]"
    ast_tree = ast.parse(code)  # type: ignore
    transformer = BaseNodeTransformer(ast_tree)  # type: ignore
    transformer.visit_List(ast_tree.body[0].value)
    type(transformer._tree) == ast.AST
    assert transformer._tree_changed == True

# Generated at 2022-06-23 23:01:20.114829
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def test(code_before: str, code_after: str) -> None:
        node = ast.parse(code_before)
        transformer = StarredUnpackingTransformer()
        transformer.visit(node)
        code = str(node)
        assert code == code_after

    test(code_before="[2, *range(10), 1]",
         code_after="[2] + list(range(10)) + [1]")

    test(code_before="[*range(10), g()]",
         code_after="list(range(10)) + [g()]")

    test(code_before="[*range(10), *range(3)]",
         code_after="list(range(10)) + list(range(3))")


# Generated at 2022-06-23 23:01:23.430286
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as ast
    test_ast = ast.List([ast.Num(1),ast.Starred(value=ast.Name(id='test', ctx=ast.Load())),ast.Name(id='test2', ctx=ast.Load())], ast.Load())
    trans = StarredUnpackingTransformer()
    new_ast = trans.visit(test_ast)
    assert(isinstance(new_ast, ast.BinOp))


# Generated at 2022-06-23 23:01:28.818514
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    list_with_starred = ast.parse(
        'l = [1, *iter, 2]',
        mode='eval'
    ).body # type: ast.expr

    # When
    converted_node = StarredUnpackingTransformer().visit(list_with_starred)

    # Then
    assert codegen.to_source(converted_node) == \
        'l = [1] + list(iter) + [2]'



# Generated at 2022-06-23 23:01:36.483294
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    expected = ast.Expression(value=ast.BinOp(
        left=ast.List(elts=[ast.Num(n=2)]),
        right=ast.BinOp(
            left=ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=10)],
                    keywords=[])],
                keywords=[]),
            right=ast.List(elts=[ast.Num(n=1)]),
            op=ast.Add()),
        op=ast.Add()))

    tf = StarredUnpackingTransformer()
    assert tf.visit(tree) == expected

#

# Generated at 2022-06-23 23:01:37.487086
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-23 23:01:44.033029
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer), \
        "should be subclass of BaseNodeTransformer"
    assert hasattr(StarredUnpackingTransformer, 'target'), \
        "StarredUnpackingTransformer should have target attribute"
    assert StarredUnpackingTransformer.__name__ == "StarredUnpackingTransformer", \
        "StarredUnpackingTransformer class name should be 'StarredUnpackingTransformer'"


# Generated at 2022-06-23 23:01:51.607219
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3
    node = typed_ast.ast3.List(
        elts=[typed_ast.ast3.Name(id='a'), typed_ast.ast3.Starred(value=typed_ast.ast3.Name(id='b')),
              typed_ast.ast3.Name(id='c')], ctx=typed_ast.ast3.Load())

# Generated at 2022-06-23 23:01:58.788720
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from .utils import NodeTestCaseMixin
    from .utils import assert_nodes_equal


    class StarredUnpackingTransformer_visit_Call_TestCase(NodeTestCaseMixin):
        target_class = StarredUnpackingTransformer

        def test_star_twice(self):
            node = ast3.parse('assert(True, *range(10), *range(1))', mode='eval')
            expected = (
                'Assert(test=True, msg=(list(range(10)) + '
                'list(range(1))))'
            )
            assert_nodes_equal(self.transform(node), expected)


# Generated at 2022-06-23 23:02:09.286649
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor, sys
    #ast_print = ast.NodeVisitor()
    #t = ast_print.visit(StarredUnpackingTransformer())
    #out = astor.to_source(t)
    #print(out)
    #sys.exit(0)
    ast1 = ast.parse("""
[2, *range(10), 1]
""")
    ast2 = ast.parse("""
[2] + list(range(10)) + [1]
""")
    astor.dump(ast1)
    result = StarredUnpackingTransformer().visit(ast1)
    print(ast.dump(result))
    assert astor.to_source(result) == astor.to_source(ast2)


# Generated at 2022-06-23 23:02:13.194187
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print("test_StarredUnpackingTransformer_visit_List()")
    x = ast.parse(
        """
        [2, *range(10, 20), 1]
        """
    ).body[0]

    expected = ast.parse(
        """
        ([2] + list(range(10, 20)) + [1])
        """
    ).body[0]

    actual = StarredUnpackingTransformer().visit(x)
    assert astor.to_source(actual) == astor.to_source(expected)


# Generated at 2022-06-23 23:02:17.139638
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .fixtures import StarredUnpackingSource
    src = StarredUnpackingSource()
    StarredUnpackingTransformer.verify(src, star_unpacking=True)
    StarredUnpackingTransformer.verify(src, star_unpacking=False)

# Generated at 2022-06-23 23:02:22.073646
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import assert_transform

    assert_transform(
        StarredUnpackingTransformer,
        """
        [2, *range(10), 1]
        print(*range(1), *range(3))
        """,
        """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        """)

# Generated at 2022-06-23 23:02:27.906274
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    '''
    Test func visit_List
    '''
    # Using loads to create ast
    code = '[2, *range(10), 1]'
    tree = ast.parse(code)
    # Calling StarredUnpackingTransformer.visit_List
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    # Re-using code as expected code
    expected_code = '__pyccel_inline_sequence_add([2], list(__pyccel_inline_sequence_range(10)), [1])'
    expected_tree = ast.parse(expected_code)
    # Comparing expected tree to transformed tree
    assert_ast_equal(expected_tree, tree)


# Generated at 2022-06-23 23:02:35.962537
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with open('test/test_files/test_StarredUnpackingTransformer_visit_List.py') as f:
        input_code = f.read()
        tree = ast.parse(input_code)
    node_transformer = StarredUnpackingTransformer()
    new_tree = node_transformer.visit(tree)
    generated_code = astunparse.unparse(new_tree)
    assert generated_code == """\
list([2] + list(range(10)) + [1])
"""



# Generated at 2022-06-23 23:02:41.530045
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helpers import assert_equal_ast, get_ast
    from .base import NodeTransformer

    code = '[1, *range(5), "a", *list(range(2)), 3]'
    expected_code = '[1] + list(range(5)) + ["a"] + list(range(2)) + [3]'

    expected_tree = get_ast(expected_code)
    tree = get_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected_tree)


# Generated at 2022-06-23 23:02:52.258127
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    mycode = """\
    [1, 2, 3, 4, 5, 6, 7, 8]
    [1, *range(2), 3, 4, 5, 6, 7, 8]
    [1, *range(2), 3, *range(4), 5, 6, 7, 8]
    [1, *range(2), 3, *range(4), 5, 6, 7, 8, *range(2)]
    """

# Generated at 2022-06-23 23:02:54.953737
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)


# Generated at 2022-06-23 23:03:07.243040
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from . import dump
    from . import StarredUnpackingTransformer

    v = StarredUnpackingTransformer()
    node = ast3.Call(
        func=ast3.Name(id='print'),
        args=[
            ast3.Starred(value=ast3.Name(id='range')),
            ast3.Starred(value=ast3.Call(
                func=ast3.Name(id='range'),
                args=[ast3.Num(n=3)]
            ))
        ],
        keywords=[]
    )
    print(dump(v.visit(node)))


# Generated at 2022-06-23 23:03:10.695436
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    transformer.visit(ast.parse("[0, *range(10), 1]"))
    transformer.visit(ast.parse("print(*range(1), *range(3))"))

# Generated at 2022-06-23 23:03:18.729530
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .transformers import TransformerSequence, remove_star_tuple_expressions
    seq = TransformerSequence([
        StarredUnpackingTransformer(),
        remove_star_tuple_expressions.StarTupleExpressionRemover()
    ])


# Generated at 2022-06-23 23:03:29.306388
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test for method visit_Call of StarredUnpackingTransformer
    print('\nTest for method visit_Call of StarredUnpackingTransformer')
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Num(n=1),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))
        ],
        keywords=[])
    star_unpack_transformer = StarredUnpackingTransformer()
    star_unpack_transformer.visit(node)
    assert star_unpack_transformer.changed()
    assert star_unpack_transformer.tree_changed
    
    

# Generated at 2022-06-23 23:03:34.323934
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTestCase, transform_from_str

    class TestVisitor(BaseNodeTestCase):
        transformer = StarredUnpackingTransformer()
        expected_tree = transform_from_str('[2] + list(range(10)) + [1]')

    node = transform_from_str('[2, *range(10), 1]')
    TestVisitor.check(node)


# Generated at 2022-06-23 23:03:40.746694
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ..unroller import Unroller
    from ..codegen import to_source
    from astor import parse_file
    from astunparse import unparse

    class_file = 'brizy/pipeline/transformers/starred_unpacking.py'
    tree = parse_file(class_file)
    StarredUnpackingTransformer(tree).visit(tree)
    star_unpack = to_source(tree)

    unroller = Unroller(star_unpack)
    unroller.visit(unroller.tree)
    test_code = unroller.transformed_code
    test_tree = parse_file(test_code)
    assert unparse(StarredUnpackingTransformer(test_tree).visit(test_tree)) == test_code
    assert test_code is not None

# Generated at 2022-06-23 23:03:50.709648
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    c = StarredUnpackingTransformer()
    call = ast.Call(func=ast.Name(id='print'), args=[ast.Num(1), ast.Starred(value=ast.List(elts=[ast.Num(2)]))], keywords=[])

    result = c.visit(call)

    assert isinstance(result, ast.Call)
    assert result.func.id == 'print'
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.BinOp)
    assert isinstance(result.args[0].value.left, ast.List)
    assert isinstance(result.args[0].value.right, ast.List)
    assert result.args[0].value.op.__class

# Generated at 2022-06-23 23:04:00.816020
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import contextlib
    import io
    import ast as std_ast
    import sys
    import textwrap
    import unittest

    class Test(unittest.TestCase):
        maxDiff = None
        longMessage = True

        @staticmethod
        def compile_and_run(src: str) -> str:
            sys.modules['__main__'].__dict__.clear()
            tree = std_ast.parse(textwrap.dedent(src))
            tree = StarredUnpackingTransformer().visit(tree)
            code = compile(tree, '<string>', 'exec')
            assert StarredUnpackingTransformer.tree_changed()


# Generated at 2022-06-23 23:04:01.624343
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:05.859998
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    '''
    >>> import typed_ast.ast3 as ast
    >>> from typed_astunparse import unparse
    >>> source = 'print(*range(1), *range(3))'
    >>> tree = ast.parse(source)
    >>> transformer = StarredUnpackingTransformer()
    >>> new_tree = transformer.visit(tree)
    >>> unparse(new_tree)
    "print(*(list(range(1)) + list(range(3))))"
    '''


# Generated at 2022-06-23 23:04:17.668054
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    node = tree.body[0].value
    assert isinstance(node, ast.List)
    assert len(node.elts) == 3
    assert isinstance(node.elts[0], ast.Num)
    assert isinstance(node.elts[1], ast.Starred)
    assert isinstance(node.elts[2], ast.Num)

    transformed = StarredUnpackingTransformer().visit(node)
    assert isinstance(transformed, ast.Call)
    assert isinstance(transformed.args[0], ast.List)
    assert isinstance(transformed.args[0].elts[0], ast.Num)
    assert isinstance(transformed.args[1], ast.Call)



# Generated at 2022-06-23 23:04:26.618203
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    for ver in [3, 4]:
        tfm = StarredUnpackingTransformer(
            target_version=ver
        )
        node = ast.parse(
            """
            [2, *range(1), *range(2), 3]
            """,
            mode='eval',
            version=ver
        )
        tfm.visit(node)
        expected = ast.parse(
            """
            [2] + list(range(1)) + list(range(2)) + [3]
            """,
            mode='eval',
            version=ver
        )
        assert ast.dump(node, annotate_fields=False) == ast.dump(expected, annotate_fields=False)


# Generated at 2022-06-23 23:04:31.589992
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = ast.parse("['a', *range(10), 'z']")
    expected = ast.parse("['a'] + list(range(10)) + ['z']")

    StarredUnpackingTransformer().generic_visit(source)
    assert ast.dump(source) == ast.dump(expected)



# Generated at 2022-06-23 23:04:40.417151
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    from . import parse

    node = ast.parse("[2, *range(10), 1]")

    result = parse(StarredUnpackingTransformer, node=node)
    assert type(result).__name__ == 'Module'
    assert len(result.body) == 1
    assert type(result.body[0]).__name__ == 'Expr'
    assert type(result.body[0].value).__name__ == 'BinOp'
    assert type(result.body[0].value.left).__name__ == 'BinOp'
    assert type(result.body[0].value.left.left).__name__ == 'List'
    assert type(result.body[0].value.left.right).__name__ == 'Call'

# Generated at 2022-06-23 23:04:48.483571
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == "Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(args=[], func=Name(id='list'), keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))"


# Generated at 2022-06-23 23:04:58.812753
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    source = "print(*range(1), *range(3))"
    astree = ast.parse(source)
    res = transformer.visit(astree)
    assert isinstance(res, ast.Module)
    assert len(res.body) == 1
    assert isinstance(res.body[0], ast.Expr)
    assert isinstance(res.body[0].value, ast.Call)
    assert isinstance(res.body[0].value.func, ast.Name)
    assert res.body[0].value.func.id == 'print'
    assert len(res.body[0].value.args) == 1
    assert isinstance(res.body[0].value.args[0], ast.Starred)

# Generated at 2022-06-23 23:05:05.404014
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sample_node = ast.parse('''
    def function():
        print(1, *range(3), *range(2), 4)
    ''').body[0]
    fixed_node = ast.parse('''
    def function():
        print(*(list([1]) + list(range(3)) + list(range(2)) + list([4])))
    ''').body[0]

    assert StarredUnpackingTransformer().visit(sample_node) == fixed_node



# Generated at 2022-06-23 23:05:14.327297
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from tests.test_transformer import transform_from_func

    def f():
        print(*range(1), *range(3))

    transformed = transform_from_func(f, 3.4, StarredUnpackingTransformer)
    assert len(transformed.body) == 1
    call = transformed.body[0].value
    assert isinstance(call, ast.Call)
    assert isinstance(call.args[0], ast.Starred)
    assert isinstance(call.args[0].value, ast.BinOp)
    assert len(call.args[0].value.left.elts) == 3  # type: ignore
    assert len(call.args[0].value.right.elts) == 2  # type: ignore

# Generated at 2022-06-23 23:05:17.682437
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    transform = StarredUnpackingTransformer()
    result = transform.visit(ast.parse(code))

    # For some reason ast.dump() appends newline to string
    assert ast.dump(result).rstrip('\n') == expected


# Generated at 2022-06-23 23:05:21.028999
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().unpack_function('*range(1)', 3) == 'range(1)'

# Generated at 2022-06-23 23:05:31.472502
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''print(*range(1), *range(3))''')
    visitors = [StarredUnpackingTransformer]
    node_new = transform('test.py', node, visitors)

# Generated at 2022-06-23 23:05:36.811949
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert 'print(*(list(range(1)) + list(range(3))))' == StarredUnpackingTransformer().visit(
        ast.parse('print(*range(1), *range(3))').body[0]
    ).to_python()



# Generated at 2022-06-23 23:05:37.894486
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:05:38.970821
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:05:43.031210
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''print(*range(1), *range(3))''')
    obj = StarredUnpackingTransformer()
    obj.visit(node)
    assert str(node).strip() == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-23 23:05:48.253117
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer.run_visitor(tree.body[0])

    assert tree.body[0].value.left.func.id == 'list'
    assert tree.body[0].value.op.__class__.__name__ == 'Add'
    assert tree.body[0].value.left.args[0].func.id == 'range'
    assert tree.body[0].value.right.__class__.__name__ == 'List'


# Generated at 2022-06-23 23:05:50.763070
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(1), *range(2))')
    transformed = StarredUnpackingTransformer().visit(tree)
    assert transformed.body[0].value.args[0].value.right.right.value.value.value.value == 2


# Generated at 2022-06-23 23:06:00.364438
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = StarredUnpackingTransformer()
    elts = [ast.Num(n=2), ast.Starred(value=ast.Name(id='range')), ast.Num(n=1)]
    node = ast.List(elts=elts)
    result = s.visit(node)
    expected = ast.Call(func=ast.Name(id='list'),
                        args=[ast.Num(n=2)],
                        keywords=[]) + ast.Call(func=ast.Name(id='list'),
                                                args=[ast.Name(id='range')],
                                                keywords=[]) + ast.List(elts=[ast.Num(n=1)])
    assert result == expected


# Generated at 2022-06-23 23:06:09.048597
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2,*range(3)]")
    # print(ast.dump(tree))
    expected_result = ast.parse("[2] + list(range(3))")
    # print(ast.dump(expected_result))
    transform = StarredUnpackingTransformer()
    new_tree = transform.visit(tree)
    assert ast.dump(expected_result) == ast.dump(new_tree)
    dump_result = ast.dump(new_tree)
    tests_tree = ast.parse(dump_result)
    assert ast.dump(expected_result) == ast.dump(tests_tree)
    # print(ast.dump(tests_tree))


# Generated at 2022-06-23 23:06:13.977141
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()

    s = """call('smth', *(list(range(1)) + list(range(2))))"""

    tree = ast.parse(s)
    t.visit(tree)

    s_expected = """call('smth', *(list(range(1)) + list(range(2))))"""
    tree_expected = ast.parse(s_expected)
    assert_equals(tree, tree_expected)



# Generated at 2022-06-23 23:06:17.283095
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformer_tests import ASTNodeTest

    tree = ASTNodeTest.compile_source(
        'x = [1, *range(3)]')
    node = tree.body[0]

    tr = StarredUnpackingTransformer()
    tr.visit(node)

    assert ASTNodeTest.compare_source(tree, 'x = [1] + list(range(3))')


# Generated at 2022-06-23 23:06:23.982737
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node_tree = ast.parse("print(*range(1), *range(3))")
    expected_tree = ast.parse("""
print(*(list(range(1)) + list(range(3))))
""")
    StarredUnpackingTransformer().visit(node_tree)
    print(node_tree)
    assert ast.dump(node_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:06:27.446154
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import _MSG, _ast_dumps

    tree = ast.parse("""
    s.split(';', 2)
    s.split(';', *range(1))
    """)
    expected_tree = ast.parse("""
    s.split(';', 2)
    s.split(';', *(list(range(1))))
    """)

    assert StarredUnpackingTransformer().visit(tree) == expected_tree, _MSG


# Generated at 2022-06-23 23:06:34.706391
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astparser import parse
    from .codegen import to_source
    node = parse('print(*range(1), *range(3))').body[0].value
    expected_node = parse('print(*(_ + list(range(3))))').body[0].value
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(node)
    assert expected_node == transformed

    source = to_source(transformed)
    assert source == 'print(*(_ + list(range(3))))'

# Generated at 2022-06-23 23:06:45.572915
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert list(StarredUnpackingTransformer()._split_by_starred([ast.Starred(value=ast.Num(1)), ast.Num(2), ast.Starred(value=ast.Num(3))])) == [
        [ast.Starred(value=ast.Num(1))],
        ast.Starred(value=ast.Num(1)),
        [],
        [ast.Num(2)],
        ast.Starred(value=ast.Num(3)),
        []
        ]

# Generated at 2022-06-23 23:06:56.081400
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(target=(3, 4))._split_by_starred([ast.Num(n=10), ast.Starred(value=ast.Num(n=1)), ast.Num(n=2)]) == [[ast.Num(n=10)],
                                                                                                                                            ast.Starred(value=ast.Num(n=1)),
                                                                                                                                            [ast.Num(n=2)]]


# Generated at 2022-06-23 23:07:05.226553
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visit_Call_test_data = [
        (
                "print(*range(10), 1, *range(5))",
                "print(*(list(range(10)) + list([1]) + list(range(5))))"
        )
    ]

    for (input_string, expected_string) in visit_Call_test_data:
        tree = ast.parse(input_string, mode='exec')
        tree_changed, new_tree = StarredUnpackingTransformer().run(tree)
        print(new_tree)
        assert new_tree == ast.parse(expected_string, mode='exec')



# Generated at 2022-06-23 23:07:12.595060
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .tests.utils import assert_transformation

    assert_transformation(StarredUnpackingTransformer, [
        '[]',
        '[2, *range(10), 1]',
        'print(*range(1), *range(3))',
    ], [
        '[]',
        '[2] + list(range(10)) + [1]',
        'print(*(list(range(1)) + list(range(3))))',
    ])

# Generated at 2022-06-23 23:07:20.745653
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    test_cases = [
        (
            ast.parse('print(2, 3, 4, 5)').body[0],
            ast.parse('print(2, 3, 4, 5)').body[0],
        ),
        (
            ast.parse('print(2, 3, 4, 5, *[2])').body[0],
            ast.parse('print(*(list(range(5)) + [2]))').body[0],
        ),
    ]

    for case in test_cases:
        in_code, expected_code = case
        assert StarredUnpackingTransformer().visit(in_code) == expected_code



# Generated at 2022-06-23 23:07:23.767813
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    expected = '[2] + list(range(10)) + [1]'
    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-23 23:07:29.388478
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    old = ast.parse('[2, *range(10), 1]')
    transformed = StarredUnpackingTransformer().visit(old)
    new = ast.parse('[2] + list(range(10)) + [1]')
    assert ast.dump(transformed) == ast.dump(new)


# Generated at 2022-06-23 23:07:37.059111
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert ast.dump(ast.parse(
        '[1 + 2, *range(10), 2 + 3, *range(2, 5), 3 + 4]'
    )) == ast.dump(StarredUnpackingTransformer().visit(ast.parse(
        '[1 + 2, *range(10), 2 + 3, *range(2, 5), 3 + 4]'
    ))) == ast.dump(ast.parse(
        '[1 + 2] + list(range(10)) + [2 + 3] + list(range(2, 5)) + [3 + 4]'
    ))



# Generated at 2022-06-23 23:07:38.685079
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class1 = StarredUnpackingTransformer()
    assert class1 is not None


# Generated at 2022-06-23 23:07:47.174042
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Test(object):
        def test(self, x, *args):
            pass

    node = ast.Call(
        func=ast.Name(id='self'),
        args=[ast.Name(id='x'), ast.Starred(value=ast.Name(id='args'))],
        keywords=[])

    new_node = StarredUnpackingTransformer().visit(node)

    expected = "self(*(x + list(args)))"

    assert ast.dump(new_node) == expected

# Generated at 2022-06-23 23:07:55.520381
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .compile_to_ast import compile_to_ast

    source = "[2, *range(10), 1]"

    tree = compile_to_ast(source)

    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)

    assert transformer._tree_changed is True
    assert tree.body[0].value.elts[0].value == 2
    assert tree.body[0].value.elts[1].value.func.id == 'list'
    assert tree.body[0].value.elts[1].value.args[0].value.func.id == 'range'
    assert tree.body[0].value.elts[1].value.args[0].value.args[0].value == 10
    assert tree.body[0].value.elts[2].value.elts

# Generated at 2022-06-23 23:08:00.835544
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = """
    foo = [2, *range(10), 1]
    """
    expected = """
    foo = [2] + list(range(10)) + [1]
    """
    node = ast.parse(src)
    StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node) == expected



# Generated at 2022-06-23 23:08:11.885865
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._split_by_starred(
        [ast.Starred(value=ast.Name(id="a")),
         ast.Name(id="b"),
         ast.Starred(value=ast.Name(id="c")),
         ]) == [[], ast.Starred(value=ast.Name(id="a")), [], ast.Name(id="b"), [],
                ast.Starred(value=ast.Name(id="c")), []]
    assert StarredUnpackingTransformer()._split_by_starred(
        [ast.Name(id="b"),
         ast.Starred(value=ast.Name(id="c")),
         ]) == [[ast.Name(id="b")], [], ast.Starred(value=ast.Name(id="c")), []]

# Generated at 2022-06-23 23:08:17.146819
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    lst = ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])
    result = StarredUnpackingTransformer().visit(lst)
    assert result == lst
    assert ast.dump(result) == ast.dump(lst)

    lst = ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Starred(value=ast.Num(n=3))])
    result = StarredUnpackingTransformer().visit(lst)
    assert result != lst


# Generated at 2022-06-23 23:08:19.523463
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None, None) is not None

# Generated at 2022-06-23 23:08:30.258011
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Tester(StarredUnpackingTransformer):
        @property
        def tree_changed(self) -> bool:
            return self._tree_changed

    sut = Tester()

    node1 = ast.List(elts=[])
    node2 = ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])
    node3 = ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='arg1')), ast.Num(n=2)])

    assert sut.visit(node1) == node1
    assert sut.tree_changed is False

    assert sut.visit(node2) == node2
    assert sut.tree_changed is False


# Generated at 2022-06-23 23:08:39.412217
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_inputs = [
        "a = [2, *range(10), 1] + [1]\n",
        "a = [*range(10), 2, 1] + [1]\n",
        "a = [2, *range(10), 1] + [*range(10), 2, 1]\n"
        "a = [2, *range(10), 1] + [2, *range(10), 1]\n"
        "a = [2, *range(10), 1]\n"
    ]

# Generated at 2022-06-23 23:08:45.852351
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    # Constructor for class StarredUnpackingTransformer
    def __init__(self, tree: ast.AST, *, filename: str = None) -> None:
        super().__init__(tree, filename=filename)
        self._tree_changed: bool = False


    StarredUnpackingTransformer.__init__ = __init__

# Generated at 2022-06-23 23:08:51.780854
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_unpacked = ast.parse(
        'l = [2, *range(10), 1]')
    ast_packed = ast.parse(
        'l = [2] + list(range(10)) + [1]')
    transformer = StarredUnpackingTransformer()
    transformer.visit(ast_unpacked)
    assert ast_unpacked == ast_packed



# Generated at 2022-06-23 23:08:58.706462
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    example = ast.parse("[2, *range(10), 1]\nprint(*range(1), *range(3))")
    expected = ast.parse("[2] + list(range(10)) + [1]\nprint(*(list(range(1)) + list(range(3))))")
    actual = transformer.visit(example)
    assert ast.dump(actual) == ast.dump(expected)
    assert transformer.tree_changed

# Generated at 2022-06-23 23:09:04.544941
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arrange
    program = ast.parse("print(*range(1), *range(3))")
    visitor = StarredUnpackingTransformer()

    # Act
    visitor.visit(program)

    # Assert

# Generated at 2022-06-23 23:09:08.523375
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .common import UnitTest, compare_with_expected

    class Test(UnitTest):
        transformer = StarredUnpackingTransformer

        @compare_with_expected(__name__, "test_StarredUnpackingTransformer")
        def test_constructor(self):
            for code in ("*range(10)", "1", "[2, *range(10), 1]", "print(*range(1), *range(3))"):
                self.transformer.visit_source(code)

    test = Test()
    test.test_constructor()

# Generated at 2022-06-23 23:09:19.436454
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast

    class TestNode(ast.Call):
        def __init__(self, args):
            self.args = args

    class TestStarred(ast.Starred):
        def __init__(self, value):
            self.value = value

    class TestName(ast.Name):
        def __init__(self, id: str):
            self.id = id

    class TestBinOp(ast.BinOp):
        def __init__(self, left, right, op):
            self.left = left
            self.right = right
            self.op = op

    class TestAdd(ast.Add):
        pass
        
    class TestList(ast.List):
        def __init__(self, elts):
            self.elts = elts
