

# Generated at 2022-06-23 22:59:24.143404
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import round_trip
    from .test_utils import compare_source

    # Test 1
    source = "[2, *range(10), 1]"
    tree0 = round_trip(source)
    tree1 = StarredUnpackingTransformer().visit(tree0)
    source1 = compare_source(tree1, source)
    print(source1)
    assert source1 == "[2] + list(range(10)) + [1]"

    # Test 2
    source = "print(*range(1), *range(3))"
    tree0 = round_trip(source)
    tree1 = StarredUnpackingTransformer().visit(tree0)
    source1 = compare_source(tree1, source)
    print(source1)

# Generated at 2022-06-23 22:59:31.355002
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree, include_attributes=False) == "Expr(value=List(elts=[Num(n=2), Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), Num(n=1)], ctx=Load()))"


# Generated at 2022-06-23 22:59:41.675035
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .visitors import TestVisitor
    from .ast_factory import ast_call
    from .ast_factory import ast_list
    from .ast_factory import ast_name
    from .ast_factory import ast_num

    source = ast_call(
        func=ast_name(id='print'),
        args=[
            ast_num(n=1),
            ast_name(id='*args')
        ]
    )
    expected = ast_call(
        func=ast_name(id='print'),
        args=[
            ast_list(elts=[ast_num(n=1)])
        ],
        keywords=[]
    )

    v = TestVisitor(StarredUnpackingTransformer)
    actual = v.visit(source)

# Generated at 2022-06-23 22:59:47.554965
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    import typed_ast.ast3 as typed_ast
    from .utils import dump
    from .checker import TypeChecker

    class Mock(object):
        def __init__(self, name):
            self.name = name

    mock_arg1 = Mock('arg1')
    mock_arg2 = Mock('arg2')
    mock_arg3 = Mock('arg3')
    mock_arg4 = Mock('arg4')
    mock_arg5 = Mock('arg5')
    mock_arg6 = Mock('arg6')
    mock_arg7 = Mock('arg7')
    mock_arg8 = Mock('arg8')
    mock_arg9 = Mock('arg9')
    mock_arg10 = Mock('arg10')


# Generated at 2022-06-23 22:59:57.518190
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        return

    source = """a = [2, *range(10), 1]"""
    expected = """a = [2] + list(range(10)) + [1]"""

    tree = ast.parse(source)
    tree_ = StarredUnpackingTransformer().visit(tree)
    actual = compile(tree_, '<string>', 'exec')
    try:
        exec(actual)
    except NameError:
        pass
    actual = [_ for _ in actual.co_consts if isinstance(_, ast.AST)][0]
    actual = ast.fix_missing_locations(actual)
    actual = astor.to_source(actual).strip()
    assert actual == expected

# Generated at 2022-06-23 23:00:07.224824
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Case is_has_starred=False
    tr = StarredUnpackingTransformer()
    node = ast.parse("[a, b, c]").body[0].value
    result = tr.visit_List(node)
    assert result is node

    # Case is_has_starred=True
    tr = StarredUnpackingTransformer()
    node = ast.parse("[a, 2, *b, c]").body[0].value
    result = tr.visit_List(node)
    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert result.func.id == 'list'
    assert isinstance(result.args, list)
    assert len(result.args) == 2
    assert isinstance(result.args[0], ast.List)

# Generated at 2022-06-23 23:00:18.711841
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # List(elts=[])
    node = ast.parse("[]").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)
    unpacker = StarredUnpackingTransformer()
    unpacker.visit_List(node.value)
    assert unpacker.is_changed is False
    assert astor.to_source(node.value) == "[]"

    # List(elts=[])
    node = ast.parse("[1, 2, 3]").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)
    unpacker = StarredUnpackingTransformer()
    unpacker.visit_List(node.value)
    assert unpacker.is_

# Generated at 2022-06-23 23:00:25.185100
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]\n"
    Node = ast.parse(code)
    Transformer = StarredUnpackingTransformer()
    result = ast.dump(Transformer.visit(Node))
    assert result == r"Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))"


# Generated at 2022-06-23 23:00:34.089541
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ast_analyzer.transformer.starred_unpacking import StarredUnpackingTransformer
    from ast_analyzer.transformer.base import BaseNodeTransformer

    class DummyNodeTransformer(BaseNodeTransformer):
        def visit(self, node: ast.AST) -> ast.AST:
            from ast_analyzer.transformer.base import BaseNodeTransformer
            return node
        def generic_visit(self, node: ast.AST) -> ast.AST:
            from ast_analyzer.transformer.base import BaseNodeTransformer
            return node

    dummy = DummyNodeTransformer()
    test = StarredUnpackingTransformer(dummy)
    

# Generated at 2022-06-23 23:00:40.785782
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import os
    os.environ["TT_DEBUG"] = "true"

    s = '''
print(*range(1), *range(3))
'''
    ast_tree = ast.parse(s)
    expected = '''
print(*(list(range(1)) + list(range(3))))
'''
    node_transformer = StarredUnpackingTransformer()
    new_ast = node_transformer.visit(ast_tree)

    assert ast_tree != new_ast
    assert expected == astor.to_source(new_ast).strip()
    assert node_transformer.changed()



# Generated at 2022-06-23 23:00:49.930775
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Given
    source = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """

    # When
    transformer = StarredUnpackingTransformer()
    tree = ast.parse(source)
    new_tree = transformer.visit(tree)

    # Then
    expected = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    """
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:00:52.264384
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test constructor without parameters
    obj1 = StarredUnpackingTransformer()
    assert obj1._tree_changed == False


# Generated at 2022-06-23 23:00:59.240151
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='print'),
                    args=[ast.Starred(value=ast.Name(id='x'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='y'), ctx=ast.Load())],
                    keywords=[])
    t = StarredUnpackingTransformer(node)
    t.run()
    assert "print(*(x + y))\n" == ast.dump(node)


# Generated at 2022-06-23 23:01:00.643395
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert a.target == (3, 4)

# Generated at 2022-06-23 23:01:07.107527
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from utils import dump_tree
    from .base import Parser, Compiler
    parser = Parser()
    compiler = Compiler(parser)
    tree = parser.parse("[2, *range(10), 1]")
    tree1 = compiler.run(tree, StarredUnpackingTransformer)
    assert dump_tree(tree1) == dump_tree(parser.parse("[2] + list(range(10)) + [1]"))


# Generated at 2022-06-23 23:01:08.410612
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # For example
    m = StarredUnpackingTransformer()


# Generated at 2022-06-23 23:01:18.373204
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse(
        """
        [2] + list(range(10)) + [1]
        [1, 2, 3]
        """
    )

    src = ast.parse(
        """
        [2, *range(10), 1]
        [1, 2, 3]
        """
    )

    transformer = StarredUnpackingTransformer()
    actual = transformer.visit(src)
    assert are_asts_equal(expected, actual)
    assert transformer._tree_changed

    actual = transformer.visit(expected)
    assert are_asts_equal(expected, actual)
    assert not transformer._tree_changed



# Generated at 2022-06-23 23:01:24.750589
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""
    def test(a, b, c):
        return print(*range(c, a), c, b, c, *range(a, b))
    """)
    expected = ast.parse("""
    def test(a, b, c):
        return print(*((list(range(c, a)) + [c]) + (list(range(a, b)) + [b]) + [c]))
    """)
    assert node == expected


# Generated at 2022-06-23 23:01:33.004593
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast

    class TestVisitor(ast.NodeVisitor):
        def visit_List(self, node):
            # type: (ast.List) -> None
            assert isinstance(node, ast.List)
            assert len(node.elts) == 3
            assert isinstance(node.elts[0], ast.Num)
            assert isinstance(node.elts[1], ast.Call)
            assert isinstance(node.elts[2], ast.Num)
            return node

    transformer = StarredUnpackingTransformer()
    code = "[2, *range(10), 1]"
    node = ast.parse(code)
    node = transformer.visit(node)

    TestVisitor().visit(node)



# Generated at 2022-06-23 23:01:40.468951
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import transform
    from . import python_to_python_ast

    code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'
    tree = python_to_python_ast.parse(code)
    new_tree = transform.transform(tree, StarredUnpackingTransformer)
    assert python_to_python_ast.to_code(new_tree) == expected_code



# Generated at 2022-06-23 23:01:48.458803
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    fake_tree = ast.parse('[2, *range(10), 1]')
    fake_tree2 = ast.parse('print(*range(1), *range(3))')

    StarredUnpackingTransformer().visit(fake_tree)
    StarredUnpackingTransformer().visit(fake_tree2)

    assert ast.dump(fake_tree) == "Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))"

# Generated at 2022-06-23 23:01:54.259503
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = "[2, *range(10), 1]\nprint(*range(1), *range(3))"
    expected = "[2] + list(range(10)) + [1]\nprint(*(list(range(1)) + list(range(3))))"
    tree = ast.parse(source)

    class Visitor(ast.NodeVisitor):
        def visit_Call(self, node):
            node.func.id = 'List'
        def visit_Name(self, node):
            if node.id == 'range':
                node.id = 'list'
    Visitor().visit(tree)

    StarredUnpackingTransformer().visit(tree)
    result = compile(tree, '', 'exec')

    assert expected == result.co_consts[0]

# Generated at 2022-06-23 23:02:05.456686
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:07.452446
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer.target == (3, 4)

# Generated at 2022-06-23 23:02:13.046965
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    codes = [
        'List(2, range(10), 1)',
        'print(range(1), range(3))'
    ]
    for code in codes:
        src = ast.parse(code)
        src.body[0].value = StarredUnpackingTransformer()(src.body[0].value)
        assert compile(src, '<test>', 'exec') is not None

# Generated at 2022-06-23 23:02:22.695691
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(10), *range(5))")
    transformer = StarredUnpackingTransformer()
    a = transformer.visit(tree)

# Generated at 2022-06-23 23:02:34.608533
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse as unparser, typed_astunparse as typed_unparser

    code = 'x = [2, *range(10), 1]'
    tree = compile(code, filename='', mode='exec',
                   flags=ast.PyCF_ONLY_AST,
                   dont_inherit=True,
                   optimize=0)  # type: ignore
    expected_tree = compile(code, filename='', mode='exec',
                            flags=ast.PyCF_ONLY_AST,
                            dont_inherit=True,
                            optimize=0)  # type: ignore

    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert new_tree == expected_tree
    assert not transformer._tree_changed


# Generated at 2022-06-23 23:02:45.790435
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # 0. Check on `[2, *range(10), 1]`
    node0 = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(node0)

# Generated at 2022-06-23 23:02:53.553502
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected

    code = "[2, 1]"
    expected = "[2, 1]"
    tree = ast.parse(code)
    assert astor.to_source(StarredUnpackingTransformer().visit(tree)).strip() == expected

if __name__ == '__main__':
    test_StarredUnpackingTransformer_visit_List()

# Generated at 2022-06-23 23:03:05.639046
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:03:15.222237
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    node = """
        a, *b, c = 1, 2, 3, 4, 5
    """
    node = ast.parse(node).body[0]
    print(node)
    t.visit(node)
    print(ast.dump(node))

# Generated at 2022-06-23 23:03:23.209098
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    source = '[2, *range(10), 1]'
    source_tree: ast.List = ast.parse(source).body[0].value

    exp_source = '[2] + list(range(10)) + [1]'
    exp_tree: ast.List = ast.parse(exp_source).body[0].value

    tree = StarredUnpackingTransformer().visit(source_tree)

    assert astor.to_source(tree) == astor.to_source(exp_tree)



# Generated at 2022-06-23 23:03:31.195274
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = "print(*range(1), *range(3))"
    expected_code = "print(*(list(range(1)) + list(range(3))))"

    linter = StarredUnpackingTransformer()
    new_tree = linter.run(code)
    # print("StarredUnpackingTransformer_visit_Call: ", astor.to_source(new_tree))
    actual_code = astor.to_source(new_tree)
    assert actual_code == expected_code

    code_tree = astor.parse_file(code)
    actual_code = astor.to_source(code_tree)
    assert actual_code == code

# Generated at 2022-06-23 23:03:36.960995
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from komodo.py_to_js.compilers.ast_base import JSCompiler
    from komodo.py_to_js.compilers.function_convertion import FunctionConvertionCompiler
    comp = JSCompiler()
    fc = FunctionConvertionCompiler(comp, "test.py")
    node = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(node)
    res = fc.visit(node)
    assert res == "([2] + list(range(10)) + [1])"


# Generated at 2022-06-23 23:03:42.933629
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    test_cases = [
        (
            'print(1, *range(3), 4, *range(5))',
            'print(*(list([1]) + list(range(3)) + list([4]) + list(range(5))))'
        ),
        (
            '[1, *range(2)]',
            '[1] + list(range(2))'
        ),
        (
            '[1, *range(2), *range(3)]',
            '[1] + list(range(2)) + list(range(3))'
        ),
        (
            'a = [1, *range(2), *range(3)]',
            'a = [1] + list(range(2)) + list(range(3))'
        )
    ]

# Generated at 2022-06-23 23:03:52.651200
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import parse
    from .test_utils import dump
    from .test_utils import assert_equal_trees

    t = StarredUnpackingTransformer()

    # Test cases for list with starred
    s = "[2, *range(10), 1]"
    tree = parse(s)
    tree = t.visit(tree)
    assert_equal_trees(parse(dump(tree)), parse("[2] + list(range(10)) + [1]"))
    assert t._has_starred(tree.elts) is False

    s = "[2, *range(10), *range(10)]"
    tree = parse(s)
    tree = t.visit(tree)

# Generated at 2022-06-23 23:04:01.656991
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tests = [
        'print(1, *[2], 3)',
        'print(1, *[2, 3], 4, 5)',
        'print(1, *[2, 3], 4, 5, *[6])',
        'print(1, *[2, 3], 4, 5, *[6, 7, 8])',
        'print(1, *[2, 3], 4, 5, *[6, 7], 8, 9, 10)',
    ]

    for test in tests:
        s = test
        print(s)
        node = ast.parse(s)
        StarredUnpackingTransformer().visit(node)
        print(node)


# Generated at 2022-06-23 23:04:07.755383
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*[1, 2], *range(3))").body[0]
    src = ast.dump(tree)
    tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 23:04:18.892976
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("foo(1, *range(2), 2, *range(3), 3, *range(4))").body[0]
    assert isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)

    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert transformer._tree_changed

    assert isinstance(node.value.args[0], ast.Starred)
    assert isinstance(node.value.args[0].value, ast.BinOp)

    sum_of_lists = node.value.args[0].value
    assert sum_of_lists.op is ast.Add
    assert isinstance(sum_of_lists.left, ast.BinOp)

# Generated at 2022-06-23 23:04:20.346903
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """
    >>> sut = StarredUnpackingTransformer()
    """


# Generated at 2022-06-23 23:04:31.438033
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class StarredUnpackingTransformer_Test(StarredUnpackingTransformer):
        _tree_changed = False
        _node = ast.Call(func=ast.Name(id='print'),
                        args=[ast.Starred(value=ast.Name(id='range'))],
                        keywords=[])

        def _to_sum_of_lists(self, xs: List[ast.expr]) -> List[ast.expr]:
            return [ast.Str(s=str(len(xs)))]

    assert StarredUnpackingTransformer_Test().visit(StarredUnpackingTransformer_Test._node) ==\
           ast.Call(func=ast.Name(id='print'),
                    args=[ast.Starred(value=ast.Str(s='1'))],
                    keywords=[])

# Generated at 2022-06-23 23:04:40.296390
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import Sass
    from . import StarredUnpackingTransformer

    script = """
    call_function(1, *args1, *args2, arg3)
    call_function(1, *args1, *args3, *args2, arg3)

    """
    # Test1
    tree = ast.parse(script)
    Sass(StarredUnpackingTransformer).visit(tree)
    code = compile(tree, filename="<ast>", mode="exec")
    ns = {}
    exec(code, ns, ns)
    assert ns['call_function'].__defaults__ == (list(range(1)), list(range(1)) + list(range(2)) + [3],)
    # Test2
    tree = ast.parse(script)

# Generated at 2022-06-23 23:04:41.421886
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:43.060664
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import check_convert

# Generated at 2022-06-23 23:04:46.099998
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:04:51.977860
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer_fixture_1
    node = BaseNodeTransformer_fixture_1
    expected = ast.parse(textwrap.dedent('''
    def f():
        x = 1
        print(1, *[2, 3], 4, *[])
        [foo(*bar), *quux] = arr
    '''))

    assert ast.dump(node, annotate_fields=False) == ast.dump(expected, annotate_fields=False)


# Generated at 2022-06-23 23:05:00.552659
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # case: List
    x1 = ast.parse('[2, *range(10), 1]')
    y1 = ast.parse('[2] + list(range(10)) + [1]')

    # case: Call
    x2 = ast.parse('print(*range(1), *range(3))')
    y2 = ast.parse('print(*(list(range(1)) + list(range(3))))')

    for src, dest in [(x1, y1), (x2, y2)]:
        assert StarredUnpackingTransformer.match(src)
        assert StarredUnpackingTransformer(src).result == dest

# Generated at 2022-06-23 23:05:04.659908
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer  # use your breakpoint


if __name__ == "__main__":
    # run this module as __main__ and not as a library
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:05:09.134198
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
    [2, *range(10), 1]
    """

    module = ast.parse(source)
    transformed = StarredUnpackingTransformer().visit(module)

    expected = """
    [2] + list(range(10)) + [1]
    """

    assert ast.dump(transformed) == expected



# Generated at 2022-06-23 23:05:18.130160
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("f(2, *range(10), 1)")
    xformer = StarredUnpackingTransformer()
    xformer.visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='f', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[])))), Num(n=1)], keywords=[]))])"



# Generated at 2022-06-23 23:05:30.095823
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._has_starred([
        ast.Starred(),
        ast.Str(s='Something'),
        ast.Starred(),
        ast.Bytes(s=b'Something else'),
    ])
    assert not StarredUnpackingTransformer()._has_starred([
        ast.Str(s='Something'),
        ast.Bytes(s=b'Something else'),
    ])
    assert not StarredUnpackingTransformer()._has_starred([
        ast.Starred(),
        ast.Starred(),
    ])

# Generated at 2022-06-23 23:05:39.745146
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Simple unit test for method visit_List of class StarredUnpackingTransformer."""
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    node = transformer.visit(node)
    assert "ast.BinOp" in str(node)
    assert "list(range(10))" in str(node)
    assert "ast.List(elts=[ast.Num(n=2)]" in str(node)
    assert "ast.List(elts=[ast.Num(n=1)]" in str(node)


# Generated at 2022-06-23 23:05:51.145441
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transpiler = StarredUnpackingTransformer()
    # Test call without starred expressions
    inp = 'print(1, 2, 3)'
    result = transpiler.visit(ast.parse(inp, mode='eval'))
    assert result.body.args[0].elts == [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]
    # Test call with starred expressions
    inp = 'print(*range(1), *range(3), 1, 2)'
    result = transpiler.visit(ast.parse(inp, mode='eval'))

# Generated at 2022-06-23 23:05:58.167900
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    star_unpacked = ast.List(elts=[
        ast.Name(id="first"),
        ast.Starred(value=ast.Name(id="second")),
        ast.Name(id="third")
    ])
    assert transformer.visit(star_unpacked) == ast.List(elts=[
        ast.Name(id="first"),
        ast.Call(func=ast.Name(id="list"),
                 args=[ast.Name(id="second")],
                 keywords=[]),
        ast.Name(id="third")
    ])


# Generated at 2022-06-23 23:06:02.265244
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_ = StarredUnpackingTransformer()
    # run test for empty list
    assert class_.visit(ast.Call(
        func=ast.Name(id='list'),
        args=[],
        keywords=[]
    )) == ast.Call(
        func=ast.Name(id='list'),
        args=[],
        keywords=[]
    )
    # run test for simple list (without Starred element)

# Generated at 2022-06-23 23:06:11.760750
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def get_result(x: ast.List) -> ast.List:
        t = StarredUnpackingTransformer()
        return t.visit(x)

    x = ast.List(elts=[ast.Num(1), ast.Starred(value=ast.Name(id='y'), ctx=ast.Load()), ast.Num(2)])
    result = get_result(x)
    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.List)
    assert isinstance(result.right, ast.List)

    result = get_result(ast.List(elts=[ast.Num(1), ast.Name(id='y'), ast.Num(2)]))
    assert isinstance(result, ast.List)

# Generated at 2022-06-23 23:06:23.598723
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast, typed_ast.ast3 as typed_ast
    from typed_ast import ast3 as ast3
    from .base import node_to_str
    from .reduce_expr import ReduceExprTransformer
    from .reduce_range import ReduceRangeTransformer

    print('*** Unit test for StarredUnpackingTransformer.visit_list().')

    # Assert function arguments are tuple, and that they have no starred element.
    node_str = '[2, 3, *[1, 2], 1]'
    node = ast3.parse(node_str, '<unknown>', 'eval')

    print('Test input: {}'.format(node_str))
    result = StarredUnpackingTransformer().visit(node)
    assert isinstance(result, typed_ast.Expression), 'assert result is Expression'

# Generated at 2022-06-23 23:06:28.475889
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .commons import get_ast
    from .commons import compare_ast

    # Modules to compare
    src = 'print(*range(1), *range(3))'  # type: str
    expected = 'print(*(list(range(1)) + list([2, 3])))'  # type: str

    # The AST nodes of expected
    expected_ast = get_ast(expected)

    # Get the AST of module
    ast_tree = get_ast(src)

    # Rewrite
    fixer = StarredUnpackingTransformer()
    fixed_ast = fixer.visit(ast_tree)

    # Compare
    compare_ast(expected_ast, fixed_ast)


# Generated at 2022-06-23 23:06:35.893178
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    res = """
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """
    node = ast.parse(src)
    expected = ast.parse(res)
    st = StarredUnpackingTransformer()
    node = st.visit(node)
    assert node == expected


# Generated at 2022-06-23 23:06:37.146079
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:06:40.478080
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    st = ast.parse("[2, *range(10), 1]")
    st = StarredUnpackingTransformer().visit(st)
    print(ast.dump(st))
    assert False

# Generated at 2022-06-23 23:06:44.267618
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .snake_to_camel_transformer import SnakeToCamelTransformer

    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert not issubclass(SnakeToCamelTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 23:06:54.956497
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from pprint import pprint
    from .base import BaseNodeTransformer
    from .list_comprehensions import ListComprehensionsTransformer
    
    test_data = (
        ast.parse("[2, *range(10), 1]"),
        ast.parse("[*range(10), 1]"),
        ast.parse("[2, *range(10)]"),
        ast.parse("[*range(10)]"),
        ast.parse("[*range(10), *range(15)]"),
    )

# Generated at 2022-06-23 23:07:05.969776
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import compile_to_ast
    from .fill_call_arguments import FillCallArgumentsTransformer
    from .fill_list_arguments import FillListArgumentsTransformer
    from .global_usage import GlobalUsageTransformer
    from .optimizer import MergeNodesTransformer
    from .remove_docstrings import RemoveDocsTransformer
    from .remove_passes import RemovePassesTransformer
    from .remove_set_literals import RemoveSetLiteralsTransformer
    from .remove_tuple_arguments import RemoveTupleArgumentsTransformer

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = compile_to_ast(code)


# Generated at 2022-06-23 23:07:12.872197
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
        [2, *range(10), 1]
    """
    expected_code = """
        [2] + list(range(10)) + [1]
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(tree).strip() == expected_code.strip()



# Generated at 2022-06-23 23:07:14.209950
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(True) is not None



# Generated at 2022-06-23 23:07:23.345280
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from astor.codegen import to_source

    pieces = [
        ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load())), ast.Num(n=1)], ctx=ast.Load()),
        ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load())), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))], keywords=[])
    ]


# Generated at 2022-06-23 23:07:33.239383
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from typed_ast.py36_ast import Starred
    from .ast_compare import compare_asts

    code = "[2, *range(10), 1]"

# Generated at 2022-06-23 23:07:36.498963
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_ = StarredUnpackingTransformer()

    assert class_.visit(ast.parse('print(*range(10), *range(10))')) == ast.parse('print(*(list(range(10)) + list(range(10))))')
    

# Generated at 2022-06-23 23:07:48.274137
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import unit_test_ast, assert_ast

    code = "".join((
        "print(*range(1), *range(4))",
        "print(1, *range(4))",
        "print(*range(2), 3, *range(4))",
        "print(*range(2), 3, *range(4), **{'args': 'for'})",
        "print(*range(2), 3, *range(4), 5)",
        "print(1, *range(2), 3, *range(4), 5, *range(6))",
    ))

# Generated at 2022-06-23 23:07:49.275690
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:07:54.609457
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    '''
    expected = '''
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    '''
    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    assert expected == compile(node, '', mode='eval').strip()

# Generated at 2022-06-23 23:07:55.974417
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    print(x)


# Generated at 2022-06-23 23:08:00.941181
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10)]")
    result = transformer.visit(node)
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(ast.parse("[2] + list(range(10))"))



# Generated at 2022-06-23 23:08:06.467605
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    tree = ast.parse(code)

    StarredUnpackingTransformer().visit(tree)

    expected = '[2] + list(range(10)) + [1]'
    assert ast.dump(tree) == expected



# Generated at 2022-06-23 23:08:14.930918
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(elts=[ast.Num(n=0), ast.Starred(value=ast.Name(id='num')),
                          ast.Num(n=4), ast.Num(n=5)])
    expected = ast.BinOp(left=ast.List(elts=[ast.Num(n=0)]),
                         right=ast.Call(func=ast.Name(id='list'),
                                        args=[ast.Name(id='num')], keywords=[]),
                         op=ast.Add())
    expected = ast.BinOp(left=expected,
                         right=ast.List(elts=[ast.Num(n=4), ast.Num(n=5)]),
                         op=ast.Add())

    assert expected == StarredUnpackingTransformer(node)

# Generated at 2022-06-23 23:08:20.655948
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    from .parser import parse_src

    source = """
print(*range(1), *range(3))
print(*range(1), *range(3), sep=";")
print(*range(1), *range(3), end="\\n")
print(*range(1), *range(3), sep=";", end="\\n")
"""
    expected = """
print(*(list(range(1)) + list(range(3))))
print(*(list(range(1)) + list(range(3))), sep=";")
print(*(list(range(1)) + list(range(3))), end="\\n")
print(*(list(range(1)) + list(range(3))), sep=";", end="\\n")
"""

    tree = parse_src(source)
    transformer = StarredUnpacking

# Generated at 2022-06-23 23:08:28.606074
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    node = ast.parse('some_func(*some_args)')

    # When
    transformed = StarredUnpackingTransformer().visit(node)

    # Then
    assert ''.join(ast.dump(transformed)) == "Expr(value=Call(func=Name(id='some_func', ctx=Load()), args=[Starred(value=Call(func=Name(id='list', ctx=Load()), args=[Name(id='some_args', ctx=Load())], keywords=[]))], keywords=[]))"


# Generated at 2022-06-23 23:08:34.418719
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class_obj = ast.parse('print(*range(1), *range(3))', '<string>', 'exec')
    created_obj = StarredUnpackingTransformer().visit(class_obj)
    expected_obj = ast.parse('print(*(list(range(1)) + list(range(3))))', '<string>', 'exec')
    assert ast.dump(created_obj) == ast.dump(expected_obj)


# Generated at 2022-06-23 23:08:38.551420
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source_code = """
        [1, *[], 2]
        """
    expected_ast = ast.parse(
        """
        [1, 2]
        """
    )
    actual_ast = compile_backend(source_code, StarredUnpackingTransformer)
    assert ast_equals(expected_ast, actual_ast)



# Generated at 2022-06-23 23:08:44.680362
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transpiler = StarredUnpackingTransformer()
    # [2, *range(10), 1]
    # -> [2] + list(range(10)) + [1]
    test_list = ast.parse(
        '[2, *range(10), 1]',
        mode='eval')
    transpiler.visit(test_list)
    print(test_list)
    assert test_list.body.elts[0].value + test_list.body.elts[1].elts[0].func.value.id + test_list.body.elts[2].value == '2list1021'

    # print(*range(1), *range(3))
    # -> print(*(list(range(1)) + list(range(3))))

# Generated at 2022-06-23 23:08:49.444893
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    assert ast.dump(ast.parse('[1, *range(3)]')) == ast.dump(sut.visit(ast.parse('[1, *range(3)]')))
    assert ast.dump(ast.parse('[1, *range(3), 2]')) == ast.dump(sut.visit(ast.parse('[1, *range(3), 2]')))
    assert ast.dump(ast.parse('list([1, *range(3)])')) == ast.dump(sut.visit(ast.parse('list([1, *range(3)])')))

# Generated at 2022-06-23 23:08:54.431519
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    ast.fix_missing_locations(transformer.visit(ast.parse("""
        print(1, *range(3), 4)
        print(1, *[1, 2, 3], 4)
    """)))
    assert transformer._tree_changed == True

# Generated at 2022-06-23 23:09:05.092917
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .compiler import Compiler
    from .helpers import ast_dump
    code = "print(1, *range(3), 2, *range(2))"
    ast_node = Compiler(StarredUnpackingTransformer).ast_dump(code)

# Generated at 2022-06-23 23:09:11.078169
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[1, *range(3), 2]"
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    compiled = compile(tree, '<input>', 'exec')
    exec(compiled)
    assert list(compiled.co_consts[1]) == [1, 0, 1, 2]



# Generated at 2022-06-23 23:09:21.094869
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    code = '[1, *range(3), 5]'
    result = typed_astunparse.unparse(StarredUnpackingTransformer().visit(ast.parse(code)))
    expected = '[1] + list(range(3)) + [5]'
    assert result == expected

    code2 = '[1, *[], 5]'
    result2 = typed_astunparse.unparse(StarredUnpackingTransformer().visit(ast.parse(code2)))
    expected2 = '[1] + [] + [5]'
    assert result2 == expected2

    code3 = '[1, *[], *[], *[], 5]'
    result3 = typed_astunparse.unparse(StarredUnpackingTransformer().visit(ast.parse(code3)))