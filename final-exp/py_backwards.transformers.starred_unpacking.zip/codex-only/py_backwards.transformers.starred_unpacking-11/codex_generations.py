

# Generated at 2022-06-23 22:59:22.028737
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    def visit_Call(node: ast3.Call) -> ast3.Call:
        try:
            return StarredUnpackingTransformer().visit_Call(node)
        except Exception:
            raise NotImplementedError
    node = ast3.Call(func=ast3.Name(id='print', ctx=ast3.Load()), args=[], keywords=[])
    assert visit_Call(node) == node


# Generated at 2022-06-23 22:59:24.227268
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert s is not None

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 22:59:33.720860
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    transformer = StarredUnpackingTransformer()

    node_a1 = ast.parse("print(*range(1), *range(3))")

    node_a2 = transformer.visit(node_a1)

    # Test AST
    assert isinstance(node_a2, ast.Module)
    assert len(node_a2.body) == 1
    assert isinstance(node_a2.body[0], ast.Expr)
    assert isinstance(node_a2.body[0].value, ast.Call)
    assert isinstance(node_a2.body[0].value.args[0], ast.Starred)
    assert isinstance(node_a2.body[0].value.args[0].value, ast.BinOp)

# Generated at 2022-06-23 22:59:36.593831
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test for constructor of class StarredUnpackingTransformer
    """
    transformer = StarredUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:59:44.630019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[1, *range(10), 2]"
    expected = "[1] + list(range(10)) + [2]"
    module = ast.parse(code)
    result = StarredUnpackingTransformer().visit(module)
    transformed_code = compile(result, "<test>", "exec")
    context = {}
    exec(transformed_code, context)
    assert context["__builtins__"] == {}
    assert code in transformed_code.co_code, code
    assert expected in transformed_code.co_code, expected


# Generated at 2022-06-23 22:59:47.413468
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[1, 2, 3]")
    t = StarredUnpackingTransformer()
    t.visit(tree)


# Generated at 2022-06-23 22:59:48.476103
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass



# Generated at 2022-06-23 22:59:54.021718
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .syntax import ast_equals

    node = ast.parse('[2, *range(10), 1]').body[0].value

    result = StarredUnpackingTransformer().visit(node)

    expected = ast.parse('[2] + list(range(10)) + [1]').body[0].value
    assert ast_equals(expected, result)



# Generated at 2022-06-23 23:00:01.849979
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("""
[2, *range(10), 1]
""")
    expected_result = ast.parse("""
[2] + list(range(10)) + [1]
""")
    assert expected_result == StarredUnpackingTransformer().visit(tree)

    tree = ast.parse("""
print(*range(1), *range(3))
""")
    expected_result = ast.parse("""
print(*(list(range(1)) + list(range(3))))
""")
    assert expected_result == StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 23:00:03.073751
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert str(x) == '<StarredUnpackingTransformer>'



# Generated at 2022-06-23 23:00:12.411623
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Tests visit_Call method of class StarredUnpackingTransformer."""

    # Build AST
    module = ast.parse(
        """
        l = [1, 2, 3]
        print(*l)
        print(*[1, 2, 3])
        """
    )

    # Create transformer
    transformer = StarredUnpackingTransformer()

    # Apply transformer
    new_tree = transformer.visit(module)

    # Assert the result
    assert transformer._tree_changed is True
    assert transformer._error_message is None
    assert ast.dump(new_tree) == ast.dump(
        ast.parse(
            """
            l = [1, 2, 3]
            print(*list(l))
            print(*list([1, 2, 3]))
            """
        )
    )

# Unit

# Generated at 2022-06-23 23:00:22.130015
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .code_to_ast import code_to_ast
    import astor

    def transpile(code: str) -> str:
        node = code_to_ast(code)
        StarredUnpackingTransformer().visit(node)
        return astor.to_source(node).strip()

    m = transpile('[2, *range(10), 1]')
    assert m == '[2] + list(range(10)) + [1]'

    m = transpile('foo[0, *range(10), 1]')
    assert m == 'foo[2] + list(range(10)) + [1]'

    m = transpile('d = {1: 2, **{3: 4}}')
    assert m == 'd = {1: 2, **{3: 4}}'

    m = trans

# Generated at 2022-06-23 23:00:26.500862
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import translate
    from astunparse import unparse
    from ast import parse

    code = parse(
        '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
        '''
    )
    tree = StarredUnpackingTransformer().visit(code)
    assert unparse(tree) == '\n[2] + list(range(10)) + [1]\nprint(*(list(range(1)) + list(range(3))))\n'



# Generated at 2022-06-23 23:00:33.617798
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    from typed_ast import ast3 as ast

    expected = """\
[2] + list(range(10)) + [1]"""

    node = ast.List(
        elts=[
            ast.Num(2),
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(10)],
                keywords=[])),
            ast.Num(1),
        ],
    )

    result = StarredUnpackingTransformer().visit(node)
    assert unparse(result).strip() == expected



# Generated at 2022-06-23 23:00:34.594261
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-23 23:00:38.614151
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module = ast.parse(dedent("""\
        [2, *range(10), 1]
        """))

    expected = ast.parse(dedent("""\
        [2] + list(range(10)) + [1]
        """))

    StarredUnpackingTransformer().visit(module)

    assert module == expected


# Generated at 2022-06-23 23:00:42.802395
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
a = [1, 2, *range(3), *range(3)]
    """
    tree = ast.parse(code)
    expected_tree = ast.parse("""
a = [1, 2] + list(range(3)) + list(range(3))
    """)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert ast.dump(expected_tree) == ast.dump(tree)



# Generated at 2022-06-23 23:00:49.191149
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    obj = StarredUnpackingTransformer()
    src = "# some comment\n[2, *range(10), 1]\n"
    expected = "# some comment\n[2] + list(range(10)) + [1]\n"
    tree = ast.parse(src)
    res = obj.visit(tree)
    assert expected == astor.to_source(res)


# Generated at 2022-06-23 23:00:50.470589
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:52.367678
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    StarredUnpackingTransformer().visit_List(ast.List(elts=[], ctx=None))

# Generated at 2022-06-23 23:01:02.793263
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_call = ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Starred(value=ast.NameConstant(value=True), ctx=ast.Load())],
        keywords=[],
        )
    node_expr = ast.Expr(
        value=ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Starred(value=ast.NameConstant(value=True), ctx=ast.Load())],
            keywords=[],
            ),
        )
    StarredUnpackingTransformer()(node_call)
    StarredUnpackingTransformer()(node_expr)


# Generated at 2022-06-23 23:01:11.793733
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import unittest
    import typed_astunparse  # type: ignore
    
    class TestCase(unittest.TestCase):
        def test_simple_case(self):
            transformer = StarredUnpackingTransformer()
            
            source = 'func(1, *range(10))'
            tree = ast.parse(source)
            new_tree = transformer.visit(tree)
            
            self.assertNotEqual(tree, new_tree)
            
            expected = 'func(*(1 + list(range(10))))'
            self.assertEqual(expected, typed_astunparse.unparse(new_tree))
            
            new_tree = transformer.visit(new_tree)
            self.assertEqual(expected, typed_astunparse.unparse(new_tree))
    
    un

# Generated at 2022-06-23 23:01:22.598506
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = "a = [1, 2, 3]\nb = [1, 2, 3]"
    expected = "a = list([1, 2, 3])\nb = list([1, 2, 3])"
    StarredUnpackingTransformer(source).test(expected)

    source = "a = *range(1)"
    expected = "a = *list(range(1))"
    StarredUnpackingTransformer(source).test(expected)

    source = "a = [*range(1)]"
    expected = "a = list(range(1))"
    StarredUnpackingTransformer(source).test(expected)

    source = "a = [1, *range(1)]"
    expected = "a = list([1] + list(range(1)))"
    StarredUnpackingTransformer(source).test(expected)

# Generated at 2022-06-23 23:01:31.600937
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseTreeTransformer
    from .base import BaseFileTransformer
    from .base import BaseTreeHelper
    from .base import BaseFileHelper
    from .base import BaseNodeHelper
    from ..visitors import visitor_mixins

    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert issubclass(StarredUnpackingTransformer, BaseTreeTransformer)
    assert issubclass(StarredUnpackingTransformer, BaseFileTransformer)
    assert issubclass(StarredUnpackingTransformer, BaseTreeHelper)
    assert issubclass(StarredUnpackingTransformer, BaseFileHelper)
    assert issubclass(StarredUnpackingTransformer, BaseNodeHelper)

# Generated at 2022-06-23 23:01:42.891894
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from python_minifier.ast_compare import compare_ast
    from typed_ast import ast3 as ast
    input_object = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
        ast.Num(n=1)
    ], ctx=ast.Load())

    expected_output = ast.BinOp(left=ast.List(elts=[
        ast.Num(n=2)
    ], ctx=ast.Load()), op=ast.Add(), right=ast.Call(
        func=ast.Name(id='list', ctx=ast.Load()),
        args=[ast.Name(id='range', ctx=ast.Load())],
        keywords=[])
    )
    expected

# Generated at 2022-06-23 23:01:49.537143
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Implicit test for method visit_List of class StarredUnpackingTransformer
    from typed_ast import ast3 as ast
    from . import __implicit_test__
    from .__implicit_test__ import visit_method_test_helper
    from ._unittest import unittest

    @unittest.skipUnless(__implicit_test__.enabled, '__implicit_test__ disabled')
    class TestStarredUnpackingTransformer(__implicit_test__.ImplicitTest, unittest.TestCase):
        TARGET_CLASS = StarredUnpackingTransformer
        TARGET_METHOD = 'visit_List'

    visit_method_test_helper(starred_unpacking, unittest)


# Generated at 2022-06-23 23:01:55.686587
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import unparse
    from .base import TreeTransformerTestCase

    class Test(TreeTransformerTestCase):
        transform = StarredUnpackingTransformer

        def test_1(self):
            before = """
                print(1, 2, *range(3), end='', sep='\\n')
            """
            after = """
                print(*(list([1, 2]) + list(range(3))), end='', sep='\\n')
            """
            self.assertTransformedAST(before, after)

        def test_2(self):
            before = """
                [2, *range(10), 1]
            """
            after = """
                list([2]) + list(range(10)) + list([1])
            """
            self.assertTransformedAST(before, after)


# Generated at 2022-06-23 23:02:01.738126
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input_ast = ast.parse("[2, *range(5)]")
    expected_ast = ast.parse("[2] + list(range(5))")

    transformer = StarredUnpackingTransformer()
    result_ast = transformer.visit(input_ast)

    assert ast.dump(expected_ast) == ast.dump(result_ast)


# Generated at 2022-06-23 23:02:10.028374
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    call = ast.parse("print(1, 2, 3, *range(4), 5, *range(6))").body[0].value
    call_expected = ast.parse(
        """
print(*(
    [1, 2, 3] + list(range(4)) + [5] + list(range(6))
))
""").body[0].value

    assert transformer.visit(call) == call_expected

    call = ast.parse("print(*range(1), *range(3))").body[0].value
    call_expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0].value

    assert transformer.visit(call) == call_expected


# Generated at 2022-06-23 23:02:17.907211
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    ast1=ast.parse("""
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """)
    ast2=transformer.visit(ast1)
    assert "ast.Module" in str(ast2)
    assert "ast.Expr" in str(ast2)
    assert "ast.Call" in str(ast2)
    assert "2" in str(ast2)
    assert "range" in str(ast2)
    assert "Starred" not in str(ast2)

# Generated at 2022-06-23 23:02:27.430283
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:38.672122
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import compile_source

    source = '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    '''
    tree = compile_source(source, '<test>', 'exec')
    assert isinstance(tree, ast.Module)

    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert isinstance(new_tree, ast.Module)
    assert transformer.tree_changed

    expected = '''
        __tmp__0 = list(range(10))
        __tmp__1 = list(range(1))
        __tmp__2 = list(range(3))
        [2] + __tmp__0 + [1]
        print(*(__tmp__1 + __tmp__2))
    '''
   

# Generated at 2022-06-23 23:02:50.183161
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:03:01.078628
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import unittest

    from typed_ast import ast3

    class StarredUnpackingTransformer_visit_List(unittest.TestCase):

        def test_StarredUnpackingTransformer_visit_List(self):
            import _ast
            import typed_ast.ast3 as ast
            node = ast.parse('[2, *range(10), 1]')
            node = StarredUnpackingTransformer().visit(node)
            compare = ast.parse('[2] + list(range(10)) + [1]')
            self.assertEqual(ast.dump(node, include_attributes=True), ast.dump(compare, include_attributes=True))
            self.assertTrue(isinstance(node, ast.Module))
            node = node.body[0]

# Generated at 2022-06-23 23:03:11.880785
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test method StarredUnpackingTransformer.visit_Call
    
    Test args of ast.Call being handled properly.
    """
    from .transformer import Transformer
    import typed_astunparse as unparser

    source = 'print(*range(1), *range(3))'
    node = ast.parse(source)
    expected = 'print(*(list(range(1)) + list(range(3))))'

    StarredUnpackingTransformer(node)
    assert unparser.unparse(node) == expected
    assert node.body[0].args[0].starargs.left.left.value.id == 'range'
    assert node.body[0].args[0].starargs.left.right.value.id == 'range'

    # Compare StarredUnpackingTransformer with Transformer in order to check
    #

# Generated at 2022-06-23 23:03:19.411957
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]")
    node = StarredUnpackingTransformer().visit(node)
    assert(ast.dump(node) == "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[])))])")

    node = ast.parse("print(*range(1), *range(3))")
    node = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:03:29.854593
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t._has_starred([ast.Name(id='a'), ast.Starred(value=ast.Name(id='b'))])
    assert not t._has_starred([ast.Name(id='a')])
    assert t._split_by_starred([
        ast.Name(id='a'),
        ast.Starred(value=ast.Name(id='b')),
        ast.Name(id='c')
    ]) == [[ast.Name(id='a')], ast.Starred(value=ast.Name(id='b')), [ast.Name(id='c')]]

# Generated at 2022-06-23 23:03:37.224702
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import generate_testcase
    tmpl = """
        def f():
            print(%s)
    """
    testcases = [
        (',', 'print(list(range(1)) + list(range(2)))'),  # does nothing
        ('*range(1),', 'print(*(list(range(1)) + []))'),
        ('*range(1), 2', 'print(*(list(range(1)) + list([2])))'),
        ('2, *range(1), *range(2)', 'print(*(list([2]) + list(range(1)) + list(range(2))))'),
    ]
    generate_testcase(testcases, StarredUnpackingTransformer, tmpl)


# Generated at 2022-06-23 23:03:48.285528
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # given
    transformer = StarredUnpackingTransformer()
    node_1 = ast.parse('''
    [2, *range(10), 1]
    ''').body[0].value
    node_2 = ast.parse('''
    [1]
    ''').body[0].value
    node_3 = ast.parse('''
    [1, *[2], 3]
    ''').body[0].value

    # when
    result_1 = transformer.visit(node_1)
    result_2 = transformer.visit(node_2)
    result_3 = transformer.visit(node_3)

    # then
    assert isinstance(result_1, ast.BinOp)
    assert result_1.left.args[0].value.func.id == 'range'

# Generated at 2022-06-23 23:03:51.593465
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import dump
    from . import parse

    dump.parse_dump(
        parse.parse(
            '''
            a = [2, *range(10), 1]
            print(*range(1), *range(3))
            '''),
        StarredUnpackingTransformer)

# Generated at 2022-06-23 23:03:52.922730
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None, None, None)



# Generated at 2022-06-23 23:04:02.300097
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    from .unparse import Unparser

    class TestUnparser(Unparser):

        def __init__(self, node: ast.Call, **kwargs: object) -> None:
            self.node = node
            super().__init__(**kwargs)

        def visit_Call(self, node: ast.Call) -> None:
            self.write(astunparse.unparse(self.node))

    tree = ast.parse('''print(*range(1), *range(3))''').body[0]
    unparser = TestUnparser(StarredUnpackingTransformer().visit(tree))
    assert unparser.result == 'print(*(list(range(1)) + list(range(3))))\n'

# Generated at 2022-06-23 23:04:10.642666
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[1, *[2, *[3, *[4]]], 5]'
    expected = '__result__ = [1] + [2] + [3] + [4] + [5]'

    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    code = compile(ast.Module([ast.Expr(node.body[0])]),
                   filename='?', mode='exec')
    ns = {}
    exec(code, ns)
    assert str(ns['__result__']) == '[1, 2, 3, 4, 5]'



# Generated at 2022-06-23 23:04:15.379934
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '''
[2, *range(10), 1]
'''
    expected = '''
[2] + list(range(10)) + [1]
'''

    _, result = StarredUnpackingTransformer(code).result_and_changed()

    assert expected == result



# Generated at 2022-06-23 23:04:17.533325
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    src = 'import builtins\nprint([1, 2, 3])'
    transformer = StarredUnpackingTransformer()
    pprint.pprint(transformer.visit(ast.parse(src).body[1]))

# Generated at 2022-06-23 23:04:27.713245
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = compile("f(*[(2, 3)], *range(3), *[(1,)], *range(5))", "<test>", mode="eval",
                optimize=0, flags=0)
    eval(a)

    a = compile("f(2, 3, *[(4, 5)], *range(4), *[(6,)], *range(4))", "<test>", mode="eval",
                optimize=0, flags=0)
    eval(a)

    a = compile("f(2, 3, *[(4, 5)], *range(4), *[(6,)], *range(4),  x=2)", "<test>", mode="eval",
                optimize=0, flags=0)
    eval(a)


# Generated at 2022-06-23 23:04:28.918716
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer((3, 4))

# Generated at 2022-06-23 23:04:38.340660
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class_ = StarredUnpackingTransformer()
    node = ast.parse(
        '[2, *range(10), 1]',
        mode='eval').body  # type: ignore
    class_.visit(node)

    assert ast.dump(node) == \
        "BinOp(left=List(elts=[Num(n=2)], ctx=Load()), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)], ctx=Load())))"


# Generated at 2022-06-23 23:04:47.206494
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  code = """[2, *range(10), 1]
  print(*range(1), *range(3))
  """

  expected_code = """\
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
"""
  import madam.parse as parse
  t = StarredUnpackingTransformer()
  tree = parse.parse(code)
  tree = t.visit(tree)
  tree = parse.unparse(tree)

  assert(tree == expected_code)

test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:54.842251
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer."""
    tree = ast.parse("""
[2, *range(10), 1]
print(*range(1), *range(3))
""")
    StarredUnpackingTransformer().transform(tree)

# Generated at 2022-06-23 23:05:01.598006
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(
        ast.parse('[1, *range(2), 3]').body[0].value) == ast.parse(
            '([1] + list(range(2)) + [3])').body[0].value

    assert StarredUnpackingTransformer().visit(
        ast.parse('[1]').body[0].value) == ast.parse('[1]').body[0].value



# Generated at 2022-06-23 23:05:09.088179
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    src = \
'''[2, *range(10), 1]
[*range(10)]
[]
[1, *(), 2]
'''
    expected = \
'''[2] + list(range(10)) + [1]
list(range(10))
[]
[1, 2]
'''
    assert transformer.visit(ast.parse(src)) == ast.parse(expected)



# Generated at 2022-06-23 23:05:16.348670
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    unpacking = StarredUnpackingTransformer()

    call = ast.parse("f(*l, *range(10))").body[0]  # type: ast.Call
    unpacking.visit(call)

# Generated at 2022-06-23 23:05:21.256175
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Call with no args
    call_0 = ast.Call(func=ast.Name(id='w'), args=[], keywords=[])
    assert StarredUnpackingTransformer().visit(call_0) == call_0

    # Call with one arg not starred
    call_1 = ast.Call(func=ast.Name(id='w'), args=[ast.Str(s='hello')], keywords=[])
    assert StarredUnpackingTransformer().visit(call_1) == call_1

    # Call with one arg starred
    call_2 = ast.Call(
        func=ast.Name(id='w'),
        args=[ast.Starred(value=ast.List(elts=[ast.Name(id='a')]))],
        keywords=[])

# Generated at 2022-06-23 23:05:30.177680
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    arg = ast.parse("*range(1)").body[0].value
    node = ast.Call(func=ast.Name(id='foo'), args=[arg])
    actual = StarredUnpackingTransformer().visit(node)
    expected = ast.Call(func=ast.Name(id='foo'), 
        args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), 
            args=[ast.Name(id='range')], keywords=[ast.keyword(arg='start', value=ast.Num(n=1))]))])
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 23:05:42.265653
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transpiler = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    tree = transpiler.visit(tree)

    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.left, ast.BinOp)
    assert tree.body[0].value.right.elts[0].id == '1'

    tree = ast.parse('[2, *range(10), *range(10), 1]')
    tree = transpiler.visit(tree)

    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.left, ast.BinOp)

# Generated at 2022-06-23 23:05:43.382734
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:05:50.982755
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[1, *a, 2]'
    expected = """\
_0 = a
_1 = list(_0)
_2 = [1]
_3 = _1 + _2
_4 = [2]
_5 = _3 + _4
"""
    expected_ast = ast.parse(expected)
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert ast_equal(ForgivingNodeTransformer().visit(node), expected_ast)


# Generated at 2022-06-23 23:06:01.683320
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Name(id='a'),
            ast.Starred(value=ast.Name(id='b')),
            ast.Name(id='c')
        ],
        keywords=[])

# Generated at 2022-06-23 23:06:06.365973
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    # Unit test for StarredUnpackingTransformer.visit_List
    ast.parse('[2, *range(10), 1]')
    # Unit test for StarredUnpackingTransformer.visit_Call
    ast.parse('print(*range(1), *range(3))')

# Generated at 2022-06-23 23:06:14.732577
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:06:21.335139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    actual = ast.fix_missing_locations(tree).body[0]
    assert ast.dump(actual) == expected



# Generated at 2022-06-23 23:06:28.378240
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Constructor test for class StarredUnpackingTransformer.")
    source = """
[2, *range(10), 1]
print(*range(1), *range(3))
"""
    expected = """
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
"""
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    transformed = ast.unparse(tree)
    assert transformed == expected

# Generated at 2022-06-23 23:06:30.132376
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)
    

# Generated at 2022-06-23 23:06:34.706262
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Entry point for unit tests."""
    from .base import NodeTestCase  # type: ignore

    code = NodeTestCase.load_example_snippet('StarredUnpackingTransformer_visit_List.py')

    NodeTestCase.verify_node(code, StarredUnpackingTransformer)


# Generated at 2022-06-23 23:06:36.591864
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-23 23:06:44.362123
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_compiler import AstCompiler
    from .source_to_ast import source_to_ast

    # [2, *range(10), 1]
    ast_node = source_to_ast(
        '''[2, *range(10), 1]'''
    )
    result = AstCompiler.run_transformer(ast_node, StarredUnpackingTransformer)
    expected = source_to_ast(
        '''[2] + list(range(10)) + [1]'''
    )
    assert result == expected



# Generated at 2022-06-23 23:06:54.047519
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import to_source
    from typed_ast import ast3
    from .fixtures import StarredUnpackingTransformer as Sut
    sut = Sut()
    (code, tree) = to_source(
        '''\
        [2, *range(10), 1]
        print(*range(1), *range(3))
        ''')
    assert code == '''\
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        '''
    expected = ast3.parse(code)
    sut.visit(tree)
    assert str(sut._tree) == str(expected)

# Generated at 2022-06-23 23:07:00.126128
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''
        print(1, 2, 3, *range(4, 10), 9)
        print(*range(1), *range(3))
    ''')

    # Remove [fut.patches.python_ast] from imports
    if 'fut' in tree.body[0].body[0].value.func.attr:
        tree.body[0].body[0].value.func.attr.remove("patches")

    # Compile
    t = StarredUnpackingTransformer()
    t.visit(tree)
    exec(compile(tree, '<string>', 'exec'))

# Generated at 2022-06-23 23:07:09.902351
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import node_to_source
    from .utils import from_source
    from .utils import find_all_method_calls_in_node

    source = '[2, *range(10), 1]'

    expected_source = '[2] + list(range(10)) + [1]'

    node = from_source(source)

    StarredUnpackingTransformer().visit(node)

    result_source = node_to_source(node)

    assert result_source == expected_source

    assert find_all_method_calls_in_node(ast.parse(result_source)) == []



# Generated at 2022-06-23 23:07:13.591037
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
foo(*range(3), *range(3))
"""
    expected = """
foo(*(list(range(3)) + list(range(3))))
"""
    assert StarredUnpackingTransformer(code).result == expected



# Generated at 2022-06-23 23:07:18.517214
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTest

    source = """\
    [2, *range(10), 1]
    """
    expected = """\
    [2] + list(range(10)) + [1]    
    """
    BaseNodeTransformerTest.source_to_source(
        StarredUnpackingTransformer, source, expected)



# Generated at 2022-06-23 23:07:29.076636
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestVisitor(BaseNodeTransformer):
        def visit_BinOp(self, node):
            return node

    tree = ast.parse("mylist = [2, *range(5), 1]")
    tree_after = ast.parse("mylist = [2] + list(range(5)) + [1]")

    transformer = StarredUnpackingTransformer()
    transformed_tree = transformer.visit(tree)

    assert deep_equal(transformed_tree, tree_after)

    # Test with NoneStarred
    tree = ast.parse("mylist = [2, *range(5)]")
    tree_after = ast.parse("mylist = [2] + list(range(5))")
    transformed_tree = transformer.visit(tree)

    assert deep_equal(transformed_tree, tree_after)

# Generated at 2022-06-23 23:07:39.228226
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer"""
    example_list1 = ast.parse("['a', 'b', *('c', 'd'), 'e']")
    example_list2 = ast.parse("[*range(10), 'b', 'c']")
    list1_before = example_list1.body[0].value
    list2_before = example_list2.body[0].value

    transformer = StarredUnpackingTransformer()
    list1_after = transformer.visit(list1_before)
    list2_after = transformer.visit(list2_before)

    assert isinstance(list1_after, ast.BinOp)
    assert list1_after.left.elts == ['a', 'b']
    assert list1_after.left.ctx == list1

# Generated at 2022-06-23 23:07:47.694426
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

    node = ast.parse(
        "print(1, *range(10), start='s', end='e', sep='s', file=file, flush=flush)")
    expected = ast.parse(
        "print(*(list([1]) + list(range(10))), start='s', end='e', sep='s', file=file, flush=flush)")

    actual = transformer.visit(node)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-23 23:07:52.270054
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_input = ast.parse("[2, *range(10), 1]")
    expected_output = ast.parse("[2] + list(range(10)) + [1]")

    # Act
    actual_output = StarredUnpackingTransformer().visit(test_input)

    # Assert
    assert ast.dump(expected_output) == ast.dump(actual_output)



# Generated at 2022-06-23 23:08:03.540607
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_visitor import dump
    from .test_visitor import assert_code_equal

    c = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name(id='print'), args=[
        ast.Starred(value=ast.Name(id='range')),
        ast.Starred(value=ast.Name(id='range')),
    ], keywords=[])
    node = c.visit(node)

# Generated at 2022-06-23 23:08:13.073754
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    l = ast.parse('''print(1, *range(4), 2)''').body[0]
    print(ast.dump(l))
    expected = '''Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Num(n=1), Starred(value=BinOp(left=BinOp(left=List(elts=[], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=4)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=2)], ctx=Load()), op=Add()))], keywords=[]))])'''
    assert ast

# Generated at 2022-06-23 23:08:13.815390
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()



# Generated at 2022-06-23 23:08:20.348118
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""
        import numpy as np

        a = [1]
        b = [1, *np.arange(2, 5), *np.arange(4, 6)]

        print(a, b)
    """).body[3]  # type: ast.Expr
    result = ast.parse("""
        import numpy as np

        a = [1]
        b = [1, *list(np.arange(2, 5)) + list(np.arange(4, 6))]

        print(a, b)
    """).body[3]  # type: ast.Expr
    assert StarredUnpackingTransformer().visit(node) == result

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:08:21.906786
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .registry import Registry


# Generated at 2022-06-23 23:08:25.962605
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import unpacking
    from . import compilation
    root = compilation('print(*range(3), *range(1))')  # type: ignore
    assert unpacking(root) == 'print(*(list(range(3)) + list(range(1))))'



# Generated at 2022-06-23 23:08:32.319352
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name('f', ctx=ast.Load()), 
                    args=[ast.Starred(value=ast.List(elts=[ast.Num(n=3), ast.Starred(value=ast.Tuple(elts=[ast.Num(n=4), ast.Num(n=5)], ctx=ast.Load())), ast.Num(n=6)], ctx=ast.Load()))],
                    keywords=[])

# Generated at 2022-06-23 23:08:42.997687
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.is_applicable(
        sys.version_info.major, sys.version_info.minor)

    # noinspection SpellCheckingInspection
    node = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(node)
    # noinspection SpellCheckingInspection
    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(node) == ast.dump(expected)

    # noinspection SpellCheckingInspection
    node = ast.parse("[2, 1]")
    StarredUnpackingTransformer().visit(node)
    # noinspection SpellCheckingInspection
    expected = ast.parse("[2, 1]")

# Generated at 2022-06-23 23:08:54.433028
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class Dummy:
        pass
    obj = Dummy()
    obj.target = 3
    def _has_starred(self, xs):
        return True

    def _split_by_starred(self, xs):
        return xs

    def _prepare_lists(self, xs):
        return xs

    def _merge_lists(self, xs):
        return xs

    def _to_sum_of_lists(self, xs):
        return self._merge_lists(self._prepare_lists(self._split_by_starred(xs)))

    def visit_List(self, node):
        if not self._has_starred(node.elts):
            return node
        else:
            return self._to_sum_of_lists(node.elts)

   

# Generated at 2022-06-23 23:09:05.093584
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    from .group import GroupTransformer
    from .base import TransformerConfig
    from .base import TransformerConfig
    from .base import TransformerConfig
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast

    class TestTransformer(GroupTransformer, BaseNodeTransformer):
        """Testing class for test_StarredUnpackingTransformer_visit_Call method
        """
        def __init__(self, *args, **kwargs):
            self._tree_changed = True  # type: bool
            super().__init__(*args, **kwargs)

        target = (3, 4)

    ast3 = ast.parse("print(*range(1), *range(3))")

# Generated at 2022-06-23 23:09:13.394886
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # source to be transformed
    source = """
[2, *range(10), 1]   
"""  # noqa

    # expected source
    expected = """
[2] + list(range(10)) + [1]   
"""  # noqa

    # transform source
    result = StarredUnpackingTransformer().visit_module(ast.parse(source))

    # make expected and result consistent
    expected = ast.fix_missing_locations(ast.parse(expected))

    # compare
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 23:09:19.267445
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[1, 2, 3, *[4], 5, *[6], 7, 8]"
    expected = "[1, 2, 3] + list([4]) + [5] + list([6]) + [7, 8]"
    actual = StarredUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(normalize_code(expected)) == ast.dump(normalize_code(actual))

