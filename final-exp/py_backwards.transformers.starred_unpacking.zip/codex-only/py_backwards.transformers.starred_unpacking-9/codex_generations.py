

# Generated at 2022-06-23 22:59:12.791080
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[1, *range(3), 4]"
    expected = "[1, *list(range(3)), 4]"

    assert StarredUnpackingTransformer(source).result == expected


# Generated at 2022-06-23 22:59:13.878987
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer


# Generated at 2022-06-23 22:59:23.958590
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast

    a = ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='range'),
               args=[ast.Num(n=10)], keywords=[]), ast.Num(n=1)], ctx=ast.Load())
    b = ast.Call(func=ast.Name(id='print'),
                 args=[ast.Call(func=ast.Name(id='range'),
                                args=[ast.Num(n=1)], keywords=[])],
                 keywords=[ast.keyword(arg='sep', value=ast.Str(s=' '))])
    tree = ast.Module(body=[b, a])


# Generated at 2022-06-23 22:59:33.536125
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Compiles:
        [2, *range(10), 1]
        print(*range(1), *range(3))
    To:
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        
    """

    import astor, typed_ast.ast3

    StarredUnpackingTransformer().visit(ast.List(elts=[ast.Num(2), ast.Starred(value=ast.Name(id="range", ctx=ast.Load()), ctx=ast.Load()), ast.Num(1)]))

# Generated at 2022-06-23 22:59:44.629925
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Test class StarredUnpackingTransformer")

    tree = ast.parse("[2, *range(10), 1]")
    expected_tree = ast.parse("[2] + list(range(10)) + [1]")

    StarredUnpackingTransformer().visit(tree)

    assert ast.dump(tree, include_attributes=True) == ast.dump(expected_tree, include_attributes=True)  # type: ignore

    tree = ast.parse("print(*range(1), *range(3))")
    expected_tree = ast.parse("print(*(list(range(1)) + list(range(3))))")

    StarredUnpackingTransformer().visit(tree)


# Generated at 2022-06-23 22:59:47.088943
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('test StarredUnpackingTransformer.visit_Call')
    print('FIXME: write me')


# Generated at 2022-06-23 22:59:57.420396
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestStarredUnpackingTransformer_visit_List_Transformer(StarredUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False

        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node
    node = ast.parse("[2, *range(10), 1]")
    value = TestStarredUnpackingTransformer_visit_List_Transformer().visit(node)
    assert('BinOp' == repr(value).split()[0])
    assert('Call' == repr(value).split()[1])
    assert('Name' == repr(value).split()[3])
    assert('Load' == repr(value).split()[4])
    assert('range' == repr(value).split()[5])

# Generated at 2022-06-23 22:59:58.410058
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pass



# Generated at 2022-06-23 23:00:01.852024
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from astor.codegen import to_source
    from _error import ThothError
    try:
        StarredUnpackingTransformer()
    except ThothError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 23:00:10.470765
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test case: print(*range(1), *range(3))
    node = ast.parse('print(*range(1), *range(3))').body[0]
    # we have here node of type Call
    assert isinstance(node, ast.Call)
    # we have here node.args with length 3
    assert len(node.args) == 3
    # we have here TypeError with message
    # 'expected Call, got Starred'

# Generated at 2022-06-23 23:00:15.905586
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ...py_to_py import compile_py_to_py
    from ast import parse

    src = 'assert 1, *range(3)'
    tree = parse(src)
    tree = compile_py_to_py(tree, StarredUnpackingTransformer)

    assert tree.body[0].test.args[1].value.left.func.id == 'list'

# Generated at 2022-06-23 23:00:20.521703
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast
    import os
    from typed_astunparse import unparse
    from ..print_visitor import PrintVisitor
    import typing
    import tempfile
    import re

    # input_text = 's = "TEST"; print(s,end="")\n'

# Generated at 2022-06-23 23:00:31.038512
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    trans = StarredUnpackingTransformer()
    expr1 = ast.List(elts=[ast.UnaryOp(
        op=ast.USub(),
        operand=ast.Num(n=5),
        lineno=1,
        col_offset=16
    )])

    expr2 = ast.List(elts=[ast.UnaryOp(
        op=ast.USub(),
        operand=ast.Num(n=5),
        lineno=1,
        col_offset=16
    ), ast.Starred(
        value=ast.Name(id='list', ctx=ast.Load(), lineno=1, col_offset=16),
        lineno=1,
        col_offset=16
    )])


# Generated at 2022-06-23 23:00:35.915535
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    from .base import CompiledAstTesterMixin
    from .unpacking_base import UnpackingBaseTransformerTester

    class StarredUnpackingTransformerTester(
            CompiledAstTesterMixin,
            UnpackingBaseTransformerTester):

        source = """
        def foo(a, *b):
            pass
        """
        expected_source = """
        def foo(a, *b):
            pass
        """
        transformer = StarredUnpackingTransformer

    StarredUnpackingTransformerTester.test_default_transformer()

# Generated at 2022-06-23 23:00:37.189749
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)

# Generated at 2022-06-23 23:00:40.431371
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as ast

    assert isinstance(StarredUnpackingTransformer.__init__(StarredUnpackingTransformer), StarredUnpackingTransformer)

# Unit tests for method _has_starred of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:43.411239
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    src = """[2, *range(10), 1]"""
    _nodes = ast.parse(src).body
    expected = """[2] + list(range(10)) + [1]"""
    actual = StarredUnpackingTransformer().visit(nodes=_nodes)
    assert str(actual[0]) == expected

# Generated at 2022-06-23 23:00:45.687265
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star = ast.Starred()
    assert star.value is None
    star = ast.Starred(value=1)
    assert star.value == 1

# Generated at 2022-06-23 23:00:53.552506
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input = ast.parse(
        "print(*range(1), *range(3))\n"
    )
    expected = ast.parse(
        "print(*(list(range(1)) + list(range(3))))\n"
    )
    actual = StarredUnpackingTransformer().visit(input)
    assert ast.dump(expected, sort_keys=True, include_attributes=False) == ast.dump(actual, sort_keys=True, include_attributes=False)


# Generated at 2022-06-23 23:01:04.863933
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer(): # type: ignore
    """Unit test for the class StarredUnpackingTransformer."""
    from typed_ast import ast3 as ast
    source_code='[2, *range(10), 1]\n'
    module = ast.parse(source_code)
    code = compile(module, '<string>', 'exec')
    StarredUnpackingTransformer().visit(module)
    assert(code == compile(module, '<string>', 'exec'))

if __name__ == "__main__":
    import sys
    import os
    if len(sys.argv) > 1:
        file_name = sys.argv[1]
        if not os.path.exists(file_name):
            print('File not found')
            sys.exit(1)

# Generated at 2022-06-23 23:01:08.165222
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    assert isinstance(tree, ast.AST)
    assert isinstance(tree.body[0].value, ast.List)
    StarredUnpackingTransformer().visit(tree)
    assert isinstance(tree.body[0].value, ast.BinOp)

# Generated at 2022-06-23 23:01:19.733204
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    miniglobals = {}
    minilocals = {}
    exec('''
if 1:
    print(*range(1), *range(3))
    print(1, *range(3), *range(2))
''', miniglobals, minilocals)
    original_func = minilocals['print']
    unpacked_func = StarredUnpackingTransformer().visit(
        ast.parse('print(*range(1), *range(3))').body[0].value)
    unpacked_func = StarredUnpackingTransformer().visit(unpacked_func)
    unpacked_func = unpacked_func.body[0].value
    exec(compile(unpacked_func, '<string>', 'exec'), miniglobals, minilocals)
    unpacked_func = minil

# Generated at 2022-06-23 23:01:29.082385
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    transformer = StarredUnpackingTransformer()

    # [x]
    node = ast.List(elts=[ast.Name(id='x', ctx=ast.Load())])
    expected = ast.List(elts=[ast.Name(id='x', ctx=ast.Load())])
    actual = transformer.visit(node)
    assert expected == actual

    # [x,y,z]
    node = ast.List(elts=[ast.Name(id='x', ctx=ast.Load()),
                          ast.Name(id='y', ctx=ast.Load()),
                          ast.Name(id='z', ctx=ast.Load())])

# Generated at 2022-06-23 23:01:35.997022
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .visitor import dump
    from .utils import unparse

    tree = ast.parse("[2, *(1,2,3)]")
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    expected = ast.parse("[2] + list((1,2,3))")
    assert dump(new_tree) == dump(expected)
    assert unparse(new_tree) == "[2] + list((1, 2, 3))"


# Generated at 2022-06-23 23:01:41.190139
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)

    expected = "[2] + list(range(10)) + [1]"
    actual = astor.to_source(tree)

    assert actual == expected


# Generated at 2022-06-23 23:01:45.337144
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse(
        '''[2, *range(10), 1]''').body[0]  # type: ast.Expr
    expected = ast.parse(
        '''([2] + list(range(10)) + [1])''').body[0]  # type: ast.Expr

    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-23 23:01:50.110134
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('testing StarredUnpackingTransformer')

    code = 'print(*[2], 3)'
    expected = 'print(*(list([2]) + [3]))'

    tree = ast.parse(code)
    assert tree.body[0].value.args[0].value.func.id == 'list'

    tree = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 23:01:51.428151
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer."""

# Generated at 2022-06-23 23:01:52.312158
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-23 23:01:59.113874
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    def t(code):
        node = ast.parse(code)
        StarredUnpackingTransformer().visit(node)
        return str(node.body[0].value)

    assert t("[2, *range(10), 1]") == "2 + list(range(10)) + 1"
    assert t("[*range(10), 2, 1]") == "list(range(10)) + [2, 1]"
    assert t("[2, *range(10), *range(10)]") == "2 + list(range(10)) + list(range(10))"
    assert t("[*range(10), 2, *range(10)]") == "list(range(10)) + [2] + list(range(10))"

# Generated at 2022-06-23 23:02:09.494632
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Part 1
    source1 = 'print(*range(1), *range(3))'
    expected1 = "print(*(list(range(1)) + list(range(3))))"

    # Part 2
    source2 = 'print(*range(2), *range(3), *range(4))'
    expected2 = "print(*(list(range(2)) + list(range(3)) + list(range(4))))"

    # Part 3
    source3 = 'print(*range(2), *range(3), *range(4), *range(5))'
    expected3 = "print(*(list(range(2)) + list(range(3)) + list(range(4)) + list(range(5))))"

    # Part 4

# Generated at 2022-06-23 23:02:19.638250
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # type: () -> None

    tree = ast.parse("[2, *range(10), 1]")
    tree = ast.fix_missing_locations(tree)
    result = StarredUnpackingTransformer()(tree)
    assert ast.dump(result) == ast.dump(tree)

    tree = ast.parse("[2, range(10), 1]")
    tree = ast.fix_missing_locations(tree)
    result = StarredUnpackingTransformer()(tree)

# Generated at 2022-06-23 23:02:23.383606
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("print(*range(1), *range(3))")
    new_node = StarredUnpackingTransformer().visit(node)
    assert str(new_node).replace(' ', '').replace('\n', '') == \
        "print(*(list(range(1))+list(range(3))))"

# Generated at 2022-06-23 23:02:35.502811
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_case1 = """assert_equals = adskalman.assert_equals
    [2, *range(10), 1]"""
    expected_code1 = '[2] + list(range(10)) + [1]'
    actual_code1 = StarredUnpackingTransformer().visit(ast.parse(test_case1))
    assert ast.dump(actual_code1) == expected_code1
    # Test for function such as print
    test_case2 = """assert_equals = adskalman.assert_equals
    print(*range(1), *range(3))"""
    expected_code2 = 'print(*(list(range(1)) + list(range(3))))'
    actual_code2 = StarredUnpackingTransformer().visit(ast.parse(test_case2))

# Generated at 2022-06-23 23:02:36.952032
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 23:02:42.686647
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    code_str = "[2, *range(10)] * 3"
    tree = ast.parse(code_str)
    trans = StarredUnpackingTransformer()
    new_tree = trans.visit(tree)
    code_str2 = astor.to_source(new_tree)
    # print(code_str)
    # print(code_str2)

    new_tree = ast.parse(code_str2)
    assert ast.dump(tree) != ast.dump(new_tree)


if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:02:52.865743
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()

    assert t._split_by_starred([ast.Starred(value=ast.Name(id='x')), ast.Name(id='y'), ast.Starred(value=ast.Name(id='z'))]) == \
        [[], ast.Starred(value=ast.Name(id='x')), [], ast.Starred(value=ast.Name(id='z')), []]

    assert t._prepare_lists(t._split_by_starred([])) == []

# Generated at 2022-06-23 23:03:05.489861
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    result = StarredUnpackingTransformer().visit(
        ast.parse('print(*range(1), *range(3))').body[0])

# Generated at 2022-06-23 23:03:15.105087
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from compile3 import Compile3
    from transform import TransformError
    code = \
'''
[1, 2, *range(10), 3]
'''
    expected = \
'''
[1, 2] + list(range(10)) + [3]
'''
    c3 = Compile3()
    c3.append_transformer(StarredUnpackingTransformer)
    c3.assert_ok(code, expected)

if __name__ == '__main__':
    import argparse
    import json
    import sys

    parser = argparse.ArgumentParser()
    parser.add_argument('json', metavar='json',
                         help="ast in json format")
    args = parser.parse_args()

    # Load ast from stdin

# Generated at 2022-06-23 23:03:25.420375
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import TypedAST

    tree = TypedAST.parse('print(*range(1), *range(3))')
    node = tree.body[0].value

    result = StarredUnpackingTransformer().visit(node)

    assert isinstance(result, ast.Call)
    assert result.func.id == 'print'

    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.Starred)

    assert isinstance(result.args[0].value, ast.BinOp)
    assert result.args[0].value.left.func.id == 'list'
    assert result.args[0].value.right.func.id == 'list'

# Generated at 2022-06-23 23:03:34.730181
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    k1 = ast.List(elts=[ast.Name(id='mn',ctx=ast.Load()),ast.Name(id='j',ctx=ast.Load()),ast.Starred(value=ast.Name(id='l',ctx=ast.Load()),ctx=ast.Load())])
    trans.visit_List(k1)
    
    k2 = ast.Call(func=ast.Name(id='print',ctx=ast.Load()), args=[ast.Name(id='np',ctx=ast.Load()),ast.Starred(value=ast.Name(id='p',ctx=ast.Load()),ctx=ast.Load()),ast.Name(id='a',ctx=ast.Load())], keywords=[])
    trans.visit_Call(k2)

# Generated at 2022-06-23 23:03:38.454287
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj_StarredUnpackingTransformer = StarredUnpackingTransformer()
    obj_StarredUnpackingTransformer._tree_changed = True
    print(obj_StarredUnpackingTransformer)
    

# Generated at 2022-06-23 23:03:49.140473
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    def check_ast(ast_str, expected_ast_str):
        expected_ast = ast.parse(expected_ast_str)
        compiler = StarredUnpackingTransformer()
        compiler.visit(ast.parse(ast_str))
        assert codegen.to_source(compiler.root) == codegen.to_source(expected_ast)
    #
    # Tests
    check_ast(
        "a = [2, *range(10), 1]",
        "a = [2] + list(range(10)) + [1]")
    check_ast(
        "a = [*range(10), 1, *range(5)]",
        "a = list(range(10)) + [1] + list(range(5))")

# Generated at 2022-06-23 23:03:53.666662
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(2))', mode='eval').body
    assert isinstance(node, ast.Call)
    assert isinstance(node.args[0], ast.Starred)

    trans = StarredUnpackingTransformer()
    result = trans.visit(node)
    assert result.args == [ast.Starred(ast.Call(ast.Name('list', ast.Load()),
                                               [ast.Call(ast.Name('range', ast.Load()),
                                                         [ast.Num(2)], [])], []))]


# Generated at 2022-06-23 23:04:02.819742
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected = """\
[2, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1]
[2, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1]
print(1, 2, 3, 1, 2, 3)
print(*(list(range(1)) + list(range(3))))
"""

    for line in expected.splitlines():
        node = ast.parse(line)
        StarredUnpackingTransformer().visit(node)
        result = compile(node, '<string>', 'eval')
        expected_result = eval(line)
        assert result == expected_result, \
            f"result: {result}, expected: {expected_result}"

# Generated at 2022-06-23 23:04:09.136967
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    nodes = ast.parse('list(range(10))')
    StarredUnpackingTransformer().visit(nodes)
    assert python_to_str(nodes) == 'list(range(10))'
    nodes = ast.parse('sqrt(sum(*range(10)))')
    StarredUnpackingTransformer().visit(nodes)
    assert python_to_str(nodes) == 'sqrt(sum(*list(range(10))))'
    nodes = ast.parse('sqrt(sum(*range(10), *range(3)))')
    StarredUnpackingTransformer().visit(nodes)
    assert python_to_str(nodes) == 'sqrt(sum(*(list(range(10)) + list(range(3)))))'


# Generated at 2022-06-23 23:04:15.631305
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .ast_unparse import unparse
    from . import common

    source = 'print(*range(1), *range(3))'
    target = 'print(*(list(range(1)) + list(range(3))))'

    t = StarredUnpackingTransformer(common.python_version)
    tree = ast.parse(source)  # type: ignore
    t.visit(tree)
    assert unparse(tree) == target

# Generated at 2022-06-23 23:04:16.464086
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-23 23:04:25.394541
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .cases import (as_transformed, STARRED_UNPACKING_CASES,
                        STARRED_UNPACKING_CASES_CODE)

    for code, result in zip(STARRED_UNPACKING_CASES_CODE, STARRED_UNPACKING_CASES):
        node = ast.parse(code)
        assert isinstance(node, ast.Module)
        star_unpacking_transformer = StarredUnpackingTransformer()
        transformed = star_unpacking_transformer.visit(node)

        assert isinstance(transformed, ast.Module)
        assert astor.to_source(transformed) == result
        assert as_transformed(code, star_unpacking_transformer) == result


# Generated at 2022-06-23 23:04:30.611827
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    node = tree.body[0]
    StarredUnpackingTransformer().visit(node)
    code = compile(tree, '', "exec")
    eval(code) == [2] + list(range(10)) + [1]



# Generated at 2022-06-23 23:04:36.967991
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    program = 'print(*range(1), *range(3))'
    t = StarredUnpackingTransformer()
    tree = ast.parse(program).body[0]
    tree = t.visit(tree)
    t = ast.fix_missing_locations(tree)
    node = ast.dump(t)
    print(program)
    print(node)
    g = globals()
    exec(compile(tree, filename='<ast>', mode='exec'),g)


# Generated at 2022-06-23 23:04:48.261072
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    global log
    log = []
    sut = StarredUnpackingTransformer(logger=log)
    node = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    assert_nodes_equivalent(expected, sut.visit(node))

# Generated at 2022-06-23 23:04:58.761749
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)

    assert ast.dump(tree) == 'Module(body=[Print(dest=None, values=[Starred(value=BinOp(left=Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=1)], keywords=[])], keywords=[])), right=Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=3)], keywords=[])], keywords=[])), op=Add())), nl=True)])'



# Generated at 2022-06-23 23:05:08.855092
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transform = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:05:16.816304
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    o = StarredUnpackingTransformer()
    o.visit(ast.parse("print(*range(1), *range(3))"))
    o.visit(ast.parse("print(1, *range(1), *range(2))"))
    o.visit(ast.parse("print(1, *range(1), *range(1), *range(2), *range(3))"))
    o.visit(ast.parse("print(1, 2, 3, *range(3))"))
    o.visit(ast.parse("print(1, 2, 3, *range(3), *range(4))"))


# Generated at 2022-06-23 23:05:21.853211
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = ast.parse(
        "ast.Call(func=ast.Name(id='print', ctx=ast.Load()), "
        "args=[ast.Starred(value=ast.BinOp(left=ast.List(elts=[]), "
        "right=ast.BinOp(left=ast.List(elts=[]), right=ast.Call(func=ast.Name(id='list', ctx=ast.Load()), "
        "args=[ast.Name(id='range', ctx=ast.Load())(1)], keywords=[]), op=ast.Add()), "
        "op=ast.Add()), ctx=ast.Load())], keywords=[])").body[0].value

# Generated at 2022-06-23 23:05:31.989534
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # case 1
    root = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(root)

    assert str(root) == '_result_ = [2] + list(range(10)) + [1]'

    # case 2
    root = ast.parse('[*range(10)]')
    StarredUnpackingTransformer().visit(root)

    assert str(root) == '_result_ = list(range(10))'

    # case 3
    root = ast.parse('[1, *[1], *range(10)]')
    StarredUnpackingTransformer().visit(root)

    assert str(root) == '_result_ = [1] + [1] + list(range(10))'



# Generated at 2022-06-23 23:05:33.874565
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor, typed_ast.ast3

# Generated at 2022-06-23 23:05:44.697525
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class _CallMethodTester(StarredUnpackingTransformer):
        def _test_visit_Call(self, node):
            self._tree_changed = False
            new_node = self.visit_Call(node)
            return self._tree_changed, new_node

    tester = _CallMethodTester()

    call = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Num(1)],
        keywords=[])

    tree_changed, new_node = tester._test_visit_Call(call)
    assert not tree_changed
    assert new_node.args == [ast.Num(1)]


# Generated at 2022-06-23 23:05:48.080852
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from pprint import pprint

    unit = ast3.parse("[1, 2, *range(5), *range(10), 3]", mode="exec")
    StarredUnpackingTransformer().visit(unit)
    pprint(ast3.dump(unit))



# Generated at 2022-06-23 23:05:53.500131
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Compiles:
        print(*range(1), *range(3))
    To:
        print(*(list(range(1)) + list(range(3))))
    """
    import astor
    source = "print(*range(1), *range(3))"
    tree = ast.parse(source)
    trans = StarredUnpackingTransformer()
    new_tree = trans.visit(tree)
    result = astor.to_source(new_tree)
    expected_result = "print(*(list(range(1)) + list(range(3))))\n"
    assert result == expected_result



# Generated at 2022-06-23 23:05:58.119538
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import sys
    from typed_astunparse import dump, unparse

    code = """
print(*range(1), *range(3))
    """
    node = ast.parse(code)

    StarredUnpackingTransformer().visit(node)

    assert dump(node) == unparse(node)



# Generated at 2022-06-23 23:06:01.955803
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("""
[2, *range(10), 1]
""")).body[0].value == ast.parse("""
[2] + list(range(10)) + [1]
""").body[0].value


# Generated at 2022-06-23 23:06:07.388466
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    source = '[2, *range(10), 1]'
    expected_result = '[2] + list(range(10)) + [1]'
    StarredUnpackingTransformer.test_transformer(source, expected_result)

    source = '[2, 3]'
    expected_result = source
    StarredUnpackingTransformer.test_transformer(source, expected_result)



# Generated at 2022-06-23 23:06:15.438056
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast as pyast
    from astor import dump
    from textwrap import dedent

    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    
    code = dedent("""
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """)

    expected = dedent("""
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """)
    
    expected = expected.strip()
    code = code.strip()

    tree = pyast.parse(code)
    expected = pyast.parse(expected)

    tree = StarredUnpackingTransformer().visit(tree)
    result = dump(tree)

    expected = dump(expected)



# Generated at 2022-06-23 23:06:27.027444
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor

    input_text = "foo(*range(10))"
    expected_text = "foo(*[list(range(10))])"
    tree = ast.parse(input_text)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_text
    # Test for two unpackings:
    input_text = "foo(*range(10), *range(3))"
    expected_text = "foo(*[list(range(10))+list(range(3))])"
    tree = ast.parse(input_text)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_text
    # Test for preservation of order:

# Generated at 2022-06-23 23:06:28.424613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip


# Generated at 2022-06-23 23:06:38.040291
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    from py_mini_racer import py_mini_racer

    def test(code: str, expected: str) -> None:
        node = ast.parse(code)
        transformer = StarredUnpackingTransformer()
        transformer.visit(node)
        modified = astunparse.unparse(node)
        print(code, '==>', modified)
        assert modified == expected
        ctx = py_mini_racer.MiniRacer()

        def prepare():
            ctx.eval(code)

        def run():
            ctx.eval(modified)

        assert timeit.timeit(prepare, number=100) > timeit.timeit(run, number=100)


# Generated at 2022-06-23 23:06:44.242023
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                    args=[ast.Starred(value=ast.Name(id='range_arg', ctx=ast.Load()), ctx=ast.Load())], keywords=[])

    expected = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                        args=[ast.Starred(value=ast.Call(func=ast.Name(id='list', ctx=ast.Load()),
                                                        args=[ast.Name(id='range_arg', ctx=ast.Load())], keywords=[]))], keywords=[])

    # The order is not important so we need to sort the nodes

# Generated at 2022-06-23 23:06:51.672503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('self.foo(1, *self.bar(), 2, *self.baz())')
    # self.foo(1, *((self.bar() + self.baz())))
    ans = ast.parse('(self.foo)(1, *((self.bar)() + (self.baz)()))')

    trans = StarredUnpackingTransformer()
    tree = trans.visit(tree)
    assert ast.dump(tree) == ast.dump(ans)



# Generated at 2022-06-23 23:06:57.412900
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import textwrap
    from typing import Dict
    from .base import BaseNodeTransformerTestCase
    from .obfuscation import Obfuscator
    from .unpacking import UnpackingTransformer, StarredUnpackingTransformer
    from .six_idioms import SixIdiomsTransformer
    from .print_function import PrintFunctionTransformer
    from .init_exec_grammar import InitExecGrammarTransformer

    class TestCase(BaseNodeTransformerTestCase):
        target_version = (3, 6)

# Generated at 2022-06-23 23:07:09.355955
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:07:16.475521
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor import codegen, parse
    from copy import deepcopy

    code = """a([1, 2, 3], [1, 2, 3], b=[2, 3])"""
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    result_code = codegen.to_source(tree)
    expected_result_code = """a(list([1, 2, 3] + list([1, 2, 3])), b=[2, 3])"""

    assert result_code == expected_result_code
    

# Generated at 2022-06-23 23:07:19.501266
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    source = ast.parse("[2, *range(10), 1]")
    result = transformer.visit(source)
    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 23:07:28.668244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    from grako.codegen import python, python3
    from grako.semantics import ModelBuilderSemantics
    from grako.util import trim
    parser = python3
    tree = parser.parse(trim("""
    [2, *range(10), 1]
    """))

    result = python3.parse(trim("""
    [2] + list(range(10)) + [1]
    """))

    t = StarredUnpackingTransformer()
    t.visit(tree)
    assert typed_astunparse.dump(result) == typed_astunparse.dump(tree)

# Generated at 2022-06-23 23:07:33.631064
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astunparse

    source = '''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    '''
    expected_result = '''
    ([2] + list(range(10)) + [1])
    print(*(list(range(1)) + list(range(3))))
    '''

    tree = StarredUnpackingTransformer().visit(ast.parse(source))
    assert astunparse.unparse(tree) == expected_result

# Generated at 2022-06-23 23:07:39.848370
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:07:47.746052
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ls = ast.parse("[2, *range(10), 1]", mode='eval')
    ls = ls.body
    assert isinstance(ls, ast.List)
    lst = StarredUnpackingTransformer().visit(ls)
    code = compile(ast.Module(body=[lst]), filename="<ast>", mode="exec")
    assert eval(code) == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]


# Generated at 2022-06-23 23:07:55.802987
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test class StarredUnpackingTransformer.
    This class tests the following methods:
        - visit_List()
        - visit_Call()
    """
    # This tests the visit_List method
    _ast_tree = ast.parse("[2, *range(10), 1]", mode='eval')
    transformer = StarredUnpackingTransformer()

    # Transform the code
    transformer.visit(_ast_tree)
    code_out = compile(transformer.result, '<stdin>', 'eval')
    result = eval(code_out)
    assert result == [2] + list(range(10)) + [1]

    # This testes the visit_Call method
    _ast_tree = ast.parse("print(*range(1), *range(3))", mode='exec')
    transformer = StarredUnpackingTrans

# Generated at 2022-06-23 23:07:57.191289
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None


# Generated at 2022-06-23 23:07:59.723768
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert get_transformer_classes('StarredUnpackingTransformer')[0] == StarredUnpackingTransformer


# Generated at 2022-06-23 23:08:10.889969
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  from .test_utils import round_trip
  from .test_utils import round_trip_unparse
  from .test_utils import assert_syntax_error
  from .test_utils import tree_equal

  # Compiles:
  #   [2, *range(10), 1]
  #   print(*range(1), *range(3))
  # To:
  #   [2] + list(range(10)) + [1]
  #   print(*(list(range(1)) + list(range(3))))

  expected = """
  [2] + list(range(10)) + [1]
  print(*(list(range(1)) + list(range(3))))
  """


# Generated at 2022-06-23 23:08:17.307773
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from collections import namedtuple
    from typed_ast import ast3 as ast

    Tree = namedtuple("Tree", ['obj', 'expected'])

    tests = [
        Tree(
            obj=ast.parse("print(*range(1), *range(3))"),
            expected=ast.parse("print(*(list(range(1)) + list(range(3))))")
        ),
        Tree(
            obj=ast.parse("print(**dict(foo=1, bar=2), *range(3))"),
            expected=ast.parse("print(*(list(dict(foo=1, bar=2)) + list(range(3))))")
        )
    ]

    trans = StarredUnpackingTransformer()
    for index, test in enumerate(tests):
        assert trans.visit(test.obj) == test.expected

# Generated at 2022-06-23 23:08:29.045887
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == (
        "Expr(value=Call(func=Name(id='print', ctx=Load()), "
        "args=[Starred(value=BinOp(left=List(elts=[Call(func=Name(id='range', ctx=Load()), "
        "args=[Num(n=1)], keywords=[])], ctx=Load()), "
        "right=List(elts=[Call(func=Name(id='range', ctx=Load()), "
        "args=[Num(n=3)], keywords=[])], ctx=Load()), op=Add()))], keywords=[]))"
    )



# Generated at 2022-06-23 23:08:34.505497
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")
    compiled_tree = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(compiled_tree, include_attributes=False) == ast.dump(expected, include_attributes=False)


# Generated at 2022-06-23 23:08:39.220959
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = StarredUnpackingTransformer()
    assert node.target == (3,4)
    assert node._tree_changed == False
    assert node._has_starred == False
    assert node._split_by_starred == False
    assert node._prepare_lists == False
    assert node._to_sum_of_lists == False
    assert node.visit_List == False
    assert node.visit_Call == False

# Generated at 2022-06-23 23:08:49.971800
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from vyper.parser.parser import VyperParser
    from vyper.exceptions import SyntaxException


    parser = VyperParser()
    test = '''
a: int128 = 2
b: int128 = 3
c: list[int128] = [2, *range(a, b)]
'''
    test_func = parser.parse(test)
    tree = StarredUnpackingTransformer().visit(test_func)
    assert type(tree.body[0].value) == ast3.BinOp
    assert type(tree.body[1].value) == ast3.Num
    assert type(tree.body[2].value) == ast3.BinOp
    assert type(tree.body[2].value.left) == ast3.List

# Generated at 2022-06-23 23:08:51.073293
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:08:58.117844
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class Dummy(StarredUnpackingTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            return node
    tree = ast.parse('print(*range(1), *range(3))')
    expected_tree = ast.parse('print(*(list(range(1)) + list(range(3))))')
    Dummy().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:09:07.652440
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():

    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10),], keywords=[],),), ast.Num(n=1),], ctx=ast.Load(),)
    expect = ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10),], keywords=[],),], keywords=[],), ast.Num(n=1),], ctx=ast.Load(),)
    node = StarredUnpackingTransformer().visit(node)
    assert node == expect


# Generated at 2022-06-23 23:09:18.797095
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Dummy(StarredUnpackingTransformer):
        """Dummy transformer for testing."""
        def visit_Call(self, node):
            return node

    # Basic
    inp = """
[1, 2, 3]
[1, 2, *[3]]
    """
    expected = """
[1, 2, 3]
[1, 2, 3]
    """
    res = Dummy().visit(parse(inp).body)
    exp = parse(expected).body
    assert res == exp

    # Has starred
    inp = """
[1, 2, *range(10), 1]
    """
    expected = """
[1, 2] + list(range(10)) + [1]
    """
    res = Dummy().visit(parse(inp).body)