

# Generated at 2022-06-23 22:59:19.731371
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = StarredUnpackingTransformer()
    # test using repr to compare ast
    assert repr(node) == '<StarredUnpackingTransformer(target=(3, 4))>'

# Generated at 2022-06-23 22:59:26.598942
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .ast_transformer_util import ASTNode, ast2str
    import typed_ast.ast3 as ast
    from .base import BaseNodeTransformer

    tree = ASTNode(ast.List([ast.Constant(1), ast.Starred(value=ast.Constant(2)),
                             ast.Constant(3)], lineno=0, col_offset=0))
    trans = StarredUnpackingTransformer()
    trans.visit(tree)
    assert ast2str(tree) == '[1] + list(2) + [3]'

# Generated at 2022-06-23 22:59:35.400838
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer(None, None)
    # test_split_by_starred
    # 1. General case
    xs_1 = [ast.Starred(value=ast.Num(n=1), ctx=ast.Load()), ast.Name(id='a', ctx=ast.Load()), ast.Starred(value=ast.Num(n=6), ctx=ast.Load())]
    xs_1_res = [[], ast.Starred(value=ast.Num(n=1), ctx=ast.Load()), [], ast.Starred(value=ast.Num(n=6), ctx=ast.Load()), []]
    splitted_1 = transformer._split_by_starred(xs_1)
    assert xs_1_res == splitted_1
   

# Generated at 2022-06-23 22:59:40.035736
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compiler import parse

    tree = parse("[1, 2, *range(5), 6, 7]")
    StarredUnpackingTransformer().visit(tree)
    assert str(tree) == "[1, 2] + list(range(5)) + [6, 7]"


# Generated at 2022-06-23 22:59:51.096096
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from textx.lang_python.python3 import ast_utils as p3_ast_utils
    from textx.lang_python.test_python3 import test_transformers
    from textx.lang_python.python3.test_python3 import SimplePython3ModelBuilder

    builder = SimplePython3ModelBuilder(
        star_unpacking_transformer=StarredUnpackingTransformer)
    model = builder.build_model('''
    print(*range(1), *range(3))
    ''')
    assert len(model.program.stmts) == 1

    print_stmt = model.program.stmts[0]
    assert isinstance(print_stmt, ast.Expr)
    assert isinstance(print_stmt.value, ast.Call)
    print_call = print_stmt.value



# Generated at 2022-06-23 22:59:57.270009
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    print = ast.parse('"print(*(list(range(1)) + list(range(3))))"')
    node = print.body[0].value
    assert isinstance(node, ast.Call)
    result = StarredUnpackingTransformer().visit(node)
    print = astor.to_source(result)
    assert print == 'print(*(list(range(1)) + list(range(3))))', print



# Generated at 2022-06-23 23:00:04.607676
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code_str = """l = [1, *[2, 3], 4]"""
    expected_code_str = """l = [1] + list([2, 3]) + [4]"""
    tree = ast.parse(code_str)
    compiled = compile(tree, "<test>", "exec")
    exec(compiled)

    transformed = StarredUnpackingTransformer().visit(tree)
    transformed_code = compile(transformed, "<test>", "exec")
    exec(transformed_code)

    assert expected_code_str == code_to_string(transformed)

# Generated at 2022-06-23 23:00:12.205115
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseTestTransformer
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import List, Num, Call, Name, Expr, Tuple
    from typed_ast.ast3 import BinOp, Add

    class Test(BaseTestTransformer):
        transformer = StarredUnpackingTransformer()
        target = (3, 4)
        node = parse("b = [1, *range(10)]").body[0].value
        expected = parse("b = [1] + list(range(10))")

    # noinspection PyTypeChecker
    assert Test().test()

    class Test(BaseTestTransformer):
        transformer = StarredUnpackingTransformer()
        target = (3, 4)

# Generated at 2022-06-23 23:00:13.964170
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t

# Generated at 2022-06-23 23:00:22.634267
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.dump(
        ast.parse("(1, 2, *range(3))"),
        annotate_fields=False, include_attributes=False) == 'Call(args=[Num(n=1), Num(n=2), Starred(value=Name(id=\'range\', ctx=Load()), ctx=Load())], keywords=[], func=Name(id=\'range\', ctx=Load()), starargs=None, kwargs=None)'

    sut = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:32.885036
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    import astor
    # preparation
    expr = """print([1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 * 10 * 11 * 12 * 13 * 14 * 15 * 16 * 17 * 18 * 19 * 20] + 1)"""
    # call method
    nodes = astor.parse_file(expr)
    StarredUnpackingTransformer().visit(nodes)
    # check result
    expected_result = astor.dump_tree(nodes)


# Generated at 2022-06-23 23:00:41.190418
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # noinspection PyPep8Naming
    import typed_ast.ast3 as ast

# Generated at 2022-06-23 23:00:43.302880
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().__class__ == StarredUnpackingTransformer



# Generated at 2022-06-23 23:00:54.858009
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = ast.parse('''
    [2, *range(10), 1]
    ''').body[0].value
    assert isinstance(x, ast.List)

    expected = ast.parse('''
    [2] + list(range(10)) + [1]
    ''').body[0].value

    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(x)
    assert isinstance(transformed, ast.BinOp)
    assert ast.dump(transformed) == ast.dump(expected)

    x = ast.parse('''
    [2, [3, *range(10)], 1, f(*range(10))]
    ''').body[0].value
    assert isinstance(x, ast.List)


# Generated at 2022-06-23 23:00:57.864268
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:01:07.517642
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_helpers import assert_transform

    source = "[2, *range(10), 1]"
    target = "[2] + list(range(10)) + [1]"
    assert_transform(StarredUnpackingTransformer, source, target)

    source = "[*[2, 3], 4, 5, *[6, 7]]"
    target = "[2, 3] + [4, 5] + [6, 7]"
    assert_transform(StarredUnpackingTransformer, source, target)

    source = "[b, c, *d, *e, f]"
    target = "[b, c] + list(d) + list(e) + [f]"
    assert_transform(StarredUnpackingTransformer, source, target)



# Generated at 2022-06-23 23:01:18.915148
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # input AST:
    # Module(body=[Expr(value=List(elts=[Num(n=2), Starred(value=Name(id='range', ctx=Load()), ctx=Load()), Num(n=1)], ctx=Load()))])
    module = ast.parse(
        'print(2, *range(10), 1)')

    # expected AST:
    # Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load())], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))])

# Generated at 2022-06-23 23:01:19.499522
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    pass

# Generated at 2022-06-23 23:01:22.130964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()
    actual = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    visitor.visit(actual)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-23 23:01:23.510295
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-23 23:01:32.271209
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_astunparse
    import astunparse

    code = """
    xs = [1, *y, 2]
    """
    node = ast.parse(code)
    node = StarredUnpackingTransformer().visit(node)
    code_after = typed_astunparse.unparse(node)
    code_expected = """
    xs = [1] + list(y) + [2]
    """
    assert code_after == code_expected

    code = """
    xs = [1, *range(20), 2]
    """
    node = ast.parse(code)
    node = StarredUnpackingTransformer().visit(node)
    code_after = typed_astunparse.unparse(node)

# Generated at 2022-06-23 23:01:42.148715
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange

    # Act
    root = ast.parse('[1, *foo]')
    transformer = StarredUnpackingTransformer()
    new_root = transformer.visit(root)

    # Assert
    assert isinstance(new_root, ast.Module)
    node = new_root.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.BinOp)
    assert isinstance(node.value.right, ast.Call)
    assert isinstance(node.value.right.func, ast.Name)
    assert isinstance(node.value.right.args[0], ast.Name)


# Generated at 2022-06-23 23:01:45.583139
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 0]')
    assert isinstance(tree.body[0].value, ast.List)

    result = transformer.visit(tree)
    assert str(result) == "[2] + list(range(10)) + [0]"


# Generated at 2022-06-23 23:01:49.733561
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(4), *range(4))')

    # print(*(list(range(4)) + list(range(4))))
    expected = ast.parse('print(*(list(range(4)) + list(range(4))))')

    result = StarredUnpackingTransformer().visit(node)

    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 23:01:53.406365
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast.parse("print(*range(1), *range(3))"))
    assert result.body[0].value.args[0].value.left.left.func.id == 'list'
    assert result.body[0].value.args[0].value.left.right.func.id == 'list'
    assert result.body[0].value.args[0].value.right.func.id == 'list'

# Generated at 2022-06-23 23:02:04.365249
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.codegen import to_source
    from .helper import code_to_ast, code_equal

    # Special case:
    #         print(1, *range(3), 0, 3, *range(2))
    # must be:
    #         print(*(tuple((1,)) + tuple(range(3)) + tuple((0, 3)) + tuple(range(2))))
    code = "print(1, *range(3), 0, 3, *range(2))"
    result = code_to_ast("print(*(tuple((1,)) + tuple(range(3)) + tuple((0, 3)) + tuple(range(2))))")
    node = code_to_ast(code).body[0]
    assert isinstance(node, ast.Expr)

# Generated at 2022-06-23 23:02:10.572835
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # arranges
    visitor = StarredUnpackingTransformer()
    
    actual = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
    
    # acts
    visitor.visit(actual)
    actual_node = ast.fix_missing_locations(actual)
    expected_node = ast.fix_missing_locations(expected)
    
    # asserts
    assert ast.dump(actual_node) == ast.dump(expected_node)

# Generated at 2022-06-23 23:02:18.813800
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        "func(*[1, 2], 3, *[4, 5], args=*[6, 7], kwargs=8)")
    visitor = StarredUnpackingTransformer()
    visitor.visit(tree)
    func = tree.body[0].value
    assert isinstance(func, ast.Call)
    assert [arg.value for arg in func.args] == [
        1,
        2,
        3,
        4,
        5,
    ]
    assert func.keywords[0].value.value == 6
    assert func.keywords[1].value.value == 7


# Generated at 2022-06-23 23:02:25.863929
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        textwrap.dedent(r'''
        print(1, 2, *range(4), 5)
        ''').strip())
    expected_tree = ast.parse(
        textwrap.dedent(r'''
        print(*(list([1, 2]) + list(range(4)) + list([5])))
        ''').strip())
    result_tree = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(expected_tree) == ast.dump(result_tree)


# Generated at 2022-06-23 23:02:37.143112
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import parse
    from jittor import init

    init()
    
    t = StarredUnpackingTransformer()

    assert str(parse("[x, *xs]")) == str(parse("[x] + list(xs)"))
    assert str(parse("[*xs]")) == str(parse("list(xs)"))
    assert str(parse("[1, *xs]")) == str(parse("[1] + list(xs)"))
    assert str(parse("[1, *xs, 2]")) == str(parse("[1] + list(xs) + [2]"))
    assert str(parse("[*xs, 2]")) == str(parse("list(xs) + [2]"))

# Generated at 2022-06-23 23:02:45.025586
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3

    expected = """module.__init__(foo=[], args=[], kwargs=[])"""
    code = """module.__init__(foo=[1, 2, 3], *[4, 5, 6], **{})"""
    tree = ast3.parse(code)
    expected_tree = ast3.parse(expected)

    mutator = StarredUnpackingTransformer()
    mutator.visit(tree)
    assert ast3.dump(tree) == ast3.dump(expected_tree)


# Generated at 2022-06-23 23:02:49.190778
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_util import parse, round_trip

    expect = 'print(*(list(range(1)) + list(range(3))))'
    actual = round_trip(parse(expect), StarredUnpackingTransformer)

    # Test
    assert expect == actual

# Generated at 2022-06-23 23:02:56.551351
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import ast
    from ..base import CodeTransformer
    left_value = ast.Name(id='a', ctx=ast.Load())
    right_value = ast.Name(id='b', ctx=ast.Load())

# Generated at 2022-06-23 23:02:58.146912
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None


# Generated at 2022-06-23 23:03:09.577125
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import parse
    node = parse("""
print(1, *range(1), *range(3))
""")
    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)

    assert transformer.tree_changed is True


# Generated at 2022-06-23 23:03:18.021781
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:03:22.472200
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typing
    import astunparse
    from typed_ast import ast3
    code = "[1, 2, 3, *[2, 3]]"
    AST = ast3.parse(code)
    StarredUnpackingTransformer().visit(AST)
    expected_result = "[(1, 2, 3) + list([2, 3])]"
    result = astunparse.unparse(AST)
    assert result == expected_result


# Generated at 2022-06-23 23:03:24.881628
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    # assert x.target == (3, 4), "Wrong target version"


# Generated at 2022-06-23 23:03:32.066143
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmt = ast.parse('f(a, [b, c], *range(5), d)')
    trans = StarredUnpackingTransformer()
    new_stmt = trans.visit(stmt)
    assert str(new_stmt) == 'f(*(a, list([b, c]) + list(range(5)), d))'
    assert new_stmt.body[0].value.args[0].elts[1].value.elts[1].value.elts[0].value.args[0].n == 5


# Generated at 2022-06-23 23:03:36.319339
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .compat import unicode

    source = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """

    t = StarredUnpackingTransformer()
    new_tree = t.visit(ast.parse(source))

    assert unicode(expected) == unicode(astunparse.unparse(new_tree))


# Generated at 2022-06-23 23:03:46.565928
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helpers import parse_to_ast, my_ast_dump, ast_dump
    from .helpers import diff_ast

    code = '[2, *range(10), 1]'

    root = parse_to_ast(code)
    my_ast_dump(root)

    StarredUnpackingTransformer().visit(root)
    my_ast_dump(root)

    expected = """Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=List(elts=[Num(n=1)])))])"""
    result = ast_dump(root)
    assert result == expected, diff_ast(expected, result)



# Generated at 2022-06-23 23:03:51.250890
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    check_py_code = '''
import logging

logging.debug(*(1, 2, 3))
    '''
    check_ast = ast.parse(check_py_code)
    expected_ast = ast.parse(
        'logging.debug(*([1, 2, 3]))')

    result_ast = StarredUnpackingTransformer().visit(check_ast)
    assert ast.dump(expected_ast) == ast.dump(result_ast)



# Generated at 2022-06-23 23:03:52.269284
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:02.392404
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    p = ast.parse('[2, *range(10), 1]')
    t = ast.dump(p)
    assert t == "Expr(value=List(elts=[Num(n=2), Starred(value=Name(id='range', ctx=Load()), ctx=Load()), Num(n=1)], ctx=Load()))"
    x = StarredUnpackingTransformer()
    r = x.visit(p)
    t = ast.dump(r)

# Generated at 2022-06-23 23:04:05.106221
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        """print(*range(3), *range(5))"""
    )

    StarredUnpackingTransformer().visit(tree)

    assert ast.dump(tree) == "print(*(list(range(3)) + list(range(5))))"


# Generated at 2022-06-23 23:04:11.259010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import UnitTestsBase
    root = ast.parse('print(*range(1), *range(3))')
    result = ast.parse('print(*(list(range(1)) + list(range(3))))')
    UnitTestsBase.assert_equal_source(result, StarredUnpackingTransformer().visit(root))


# Generated at 2022-06-23 23:04:18.960313
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.visit_List(StarredUnpackingTransformer(), ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])) == ast.List(elts=[ast.Num(n=2), ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[]), ast.Num(n=1)])


# Generated at 2022-06-23 23:04:24.726244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    original_tree = ast.parse("[2, *range(10), 1]")
    tree = StarredUnpackingTransformer().visit(original_tree)
    expected_tree = ast.parse("[2] + list(range(10)) + [1]")
    assert equal_trees(ast.fix_missing_locations(tree), ast.fix_missing_locations(expected_tree))



# Generated at 2022-06-23 23:04:33.858885
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class BaseNodeTransformer(ast.NodeTransformer):
        def generic_visit(self, node: ast.Node) -> ast.Node:
            return super().generic_visit(node)

    node = ast.parse("print(1, *[2, 3])")
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=List(elts=[Num(n=1), Num(n=2), Num(n=3)], ctx=Load()))], keywords=[]))])"



# Generated at 2022-06-23 23:04:38.407319
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .common import compile_transform, assert_equal
    from ast import parse

    src = parse('[2, *range(10), 1]')
    tree = src.body[0].value
    assert_equal(StarredUnpackingTransformer().visit(tree), parse(
        '[2] + list(range(10)) + [1]').body[0].value)



# Generated at 2022-06-23 23:04:49.420884
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astunparse import (
        unparse as unparser
    )

    target = (3, 4)
    tests = [
        ("print(*[1])", "print(*([1]))"),
        ("print(*[1, 2])", "print(*([1, 2]))"),
        ("print(*[1, 2, 3])", "print(*([1, 2, 3]))"),
        ("print(*[1, *[2, 3]])", "print(*([1] + list([2, 3])))"),
        ("print(*[1, *[2, 3], 4, *[5]])", "print(*([1] + list([2, 3]) + [4] + list([5])))"),
    ]

    for test, expected in tests:
        tree = ast.parse(test, mode="exec")

# Generated at 2022-06-23 23:04:59.731050
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert str(StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]"))) == "[2] + list(range(10)) + [1]"
    assert str(StarredUnpackingTransformer().visit(ast.parse("[*range(10), 1]"))) == "list(range(10)) + [1]"
    assert str(StarredUnpackingTransformer().visit(ast.parse("[2, *range(10)]"))) == "[2] + list(range(10))"
    assert str(StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1, *range(2)]"))) == "[2] + list(range(10)) + [1] + list(range(2))"

# Generated at 2022-06-23 23:05:03.751329
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helpers import assert_equal_source
    source = "[2, *range(10), 1]"
    ast_tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(ast_tree)
    assert_equal_source(result, "[2] + list(range(10)) + [1]")


# Generated at 2022-06-23 23:05:11.931893
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""
    a()
    a(1)
    a(1, *b)
    a(*b, 1)
    a(1, *b, 2, *c)
    """).body
    expected = """
    a()
    a(1)
    a(*(list(b)+[1]))
    a(*(list([1])+list(b)))
    a(*(list([1])+list(b)+list([2])+list(c)))
    """
    node = StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node).strip() == expected.strip()


# Generated at 2022-06-23 23:05:17.352837
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .ast_transformer_registry import ASTTransformerRegistry
    from subprocess import PIPE, Popen
    import json
    import os
    import py_compile
    import random
    import subprocess
    import sys
    import tempfile

    transformer = StarredUnpackingTransformer()
    #assert ASTTransformerRegistry.is_transformer_available(transformer_cls=StarredUnpackingTransformer)
    script = ast3.parse("[2, *range(10), 1]")
    script = transformer.visit(script)
    #print("script _is_:")
    #print(script)
    #print("script _is_:")
    #print(script)
    #print("script _is_:")
    #print(script)


# Generated at 2022-06-23 23:05:22.608667
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[2, *range(10), 1]")
    print(StarredUnpackingTransformer().visit(tree))
    print(tree)
    #assert tree == ast.parse("[2] + list(range(10)) + [1]")

# Generated at 2022-06-23 23:05:28.495493
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer().check_ast(
        """
        [2, *range(10), 1]
        print(*range(1), *range(3))
        """,
        """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        """,
    )

# Generated at 2022-06-23 23:05:36.017153
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse

    from . import Py36Parser

    parser = Py36Parser()
    expected_source = '[2] + list(range(10)) + [-1]'
    source = '[2, *range(10), -1]'

    ast_node = parser.parse(source)
    StarredUnpackingTransformer().visit(ast_node)
    processed_source = unparse(ast_node)

    assert expected_source == processed_source



# Generated at 2022-06-23 23:05:41.648693
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from textwrap import dedent
    from astunparse import unparse
    from ast_tools.passes import StarredUnpackingTransformer as Sut
    py_src = dedent('''
    def a(x, y, *z):
        print(x, y, z)
    ''')
    expected_py_src = dedent('''
    def a(*(x + y + list(z))):
        print(*(x + y + list(z)))
    ''')
    ast_node = ast.parse(py_src)
    res = Sut().visit(ast_node)
    expected_res = ast.parse(expected_py_src)
    actual = unparse(res)
    expected = unparse(expected_res)
    assert actual == expected, actual


# Generated at 2022-06-23 23:05:52.983697
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_astunparse import unparse

    x = ast.List(elts=[
        ast.Num(n=1),
        ast.Starred(value=ast.Name(id='a')),
        ast.Num(n=4),
        ast.Starred(value=ast.Name(id='b')),
        ast.Starred(value=ast.Name(id='c')),
        ast.Num(n=9)
    ])

    sut = StarredUnpackingTransformer()
    actual = sut.visit(x)

# Generated at 2022-06-23 23:05:59.980282
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code_in = ast.parse('''
        def foo(arg):
            print(*arg, *range(5), "str", sep="*")
        ''')

    expected_code = ast.parse('''
        def foo(arg):
            print(*((arg + (list(range(5)) + (["str"]))))))
        ''')

    assert StarredUnpackingTransformer.run_on_single_node(code_in).body[0] == expected_code.body[0]


# Generated at 2022-06-23 23:06:08.316002
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    root = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(root)
    assert new_node.body[0].value == ast.BinOp(
        left=ast.List(elts=[
            ast.Constant(value=2, kind=None),
        ]),
        right=ast.Call(
            func=ast.Name(id='list'),
            args=[
                ast.Name(id='range'),
                ast.Constant(value=10, kind=None),
            ],
            keywords=[]),
        op=ast.Add())


# Generated at 2022-06-23 23:06:13.176401
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    ast_node = ast.parse('''print(*[1, *range(3), 4], *range(5))''').body[0]
    ast_node = transformer.visit(ast_node)
    expected_ast_code = 'print(*([1] + list(range(3)) + [4] + list(range(5))))'
    assert astor.to_source(ast_node) == expected_ast_code

# Generated at 2022-06-23 23:06:15.075780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor 
    from .misc import from_string
    from .misc import to_string

# Generated at 2022-06-23 23:06:23.551770
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "list_to_list = [2, *range(10), 1]"
    expected_output = "list_to_list = [2] + list(range(10)) + [1]"
    expected_tree = ast.parse(expected_output)
    tree = ast.parse(source)

    transformer = StarredUnpackingTransformer(tree)

    assert transformer.tree != expected_tree
    assert transformer.tree == tree

    transformer.visit(tree)

    assert transformer.tree != tree
    assert transformer.tree == expected_tree


# Generated at 2022-06-23 23:06:26.799089
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    src = 'print(*range(1), *range(3))'
    expected = 'print(*(range(1) + range(3)))\n'
    tree = pyast.parse(src)
    result = StarredUnpackingTransformer().visit(tree)
    code = compile(result, '<test>', 'exec')  # type: ignore
    code = str(code)
    assert code == expected



# Generated at 2022-06-23 23:06:37.119292
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:06:41.290230
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[x for x in range(5) if x > 2]")
    StarredUnpackingTransformer().visit(tree)
    assert tree_to_code(tree) == "[x for x in list(range(5)) if x > 2]"



# Generated at 2022-06-23 23:06:45.735474
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(2))")
    result = StarredUnpackingTransformer().visit(node)
    expected = ast.parse("print(*(list(range(1)) + list(range(2))))")
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 23:06:55.918395
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse

    src1 = """
    x(b, [10, *range(5), 2], 3)
    """
    src2 = """
    x(*list(range(10)), *[1, *range(6), 2], **{'k': 1})
    """
    src3 = """
    x(y=2, **{1: 3, 'a': *range(10), 'b': 4})
    """
    srcs = [src1, src2, src3]

    for src in srcs:
        tree = parse(src)
        StarredUnpackingTransformer().visit(tree)

        assert '*' not in ast.dump(tree)
        exec(compile(tree, __file__, mode='exec'))



# Generated at 2022-06-23 23:07:05.216456
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .tools import assert_equal_ast
    from .yield_from import YieldFromTransformer

    source = '[10, 20, *range(1, 10), 11, *range(30)]'
    expected = '[10, 20]+list(range(1, 10))+[11]+list(range(30))'

    tree = parse(source)
    with YieldFromTransformer() as transformed_tree:
        transformed_tree.visit(tree)
    with StarredUnpackingTransformer() as transformed_tree:
        transformed_tree.visit(tree)

    assert_equal_ast(expected, tree)


# Generated at 2022-06-23 23:07:16.922512
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    import unittest
    import astor
    from ast_converter3to4.helpers import get_func_body

    class StarredUnpackingTransformerTesting(unittest.TestCase):
        def setUp(self) -> None:
            self.maxDiff = None

        def test_StarredUnpackingTransformer_visit_List(self):
            code_orig = ' [2, *range(10), 1] '
            tree_orig = ast3.parse(code_orig)
            func_body = get_func_body(tree_orig)
            expected_code = ' [2] + list(range(10)) + [1] '
            expected_tree = ast3.parse(expected_code)
            expected_func_body = get_func_body(expected_tree)

# Generated at 2022-06-23 23:07:22.304469
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    original_code = 'print(*range(1, 3), *range(3, 5))'
    expected_code = 'print(*(list(range(1, 3)) + list(range(3, 5))))'
    ast_orig = ast.parse(original_code)
    ast_act = transformer.visit(ast_orig)
    ast_exp = ast.parse(expected_code)
    assert ast_exp == ast_act

# Generated at 2022-06-23 23:07:32.439265
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    node = ast.parse('def f(x): return x + 1', mode='eval').body
    t.visit(node)

    node = ast.parse('1, *range(10), 1', mode='eval').body
    transformed = t.visit(node)

    assert isinstance(transformed, ast.Call)
    assert isinstance(transformed.args[0], ast.Starred)
    assert isinstance(transformed.args[0].value, ast.BinOp)
    assert isinstance(transformed.args[0].value.left, ast.BinOp)
    assert isinstance(transformed.args[0].value.left.left, ast.List)

# Generated at 2022-06-23 23:07:41.446863
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class StarredUnpackingTransformerVisitor(unittest.TestCase):
        def test_one_empty(self):
            node = ast.List(elts=[])
            transformer = StarredUnpackingTransformer()
            self.assertEqual(transformer.visit(node), node)

        def test_one_expr(self):
            expr = ast.Call(
                func=ast.Name(id='foo'),
                args=[],
                keywords=[])
            node1 = ast.List(elts=[expr])
            node2 = ast.List(elts=[expr])
            transformer = StarredUnpackingTransformer()
            self.assertEqual(transformer.visit(node1), node2)


# Generated at 2022-06-23 23:07:49.571145
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test create
    transformer = StarredUnpackingTransformer()
    assert isinstance(transformer, StarredUnpackingTransformer)

    # Test return type
    tree = ast.parse("[2, 3, *range(10), 10]", "<string>", "eval")
    transformer.visit(tree)
    print(ast.dump(transformer.visit(tree)))
    assert isinstance(transformer.visit(tree), ast.List)

if __name__ == "__main__":
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:07:59.259266
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module_node = ast.parse("print(*range(1), *range(3))")
    result = StarredUnpackingTransformer().visit(module_node)

# Generated at 2022-06-23 23:08:04.418194
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert transform_assert_equal(
        StarredUnpackingTransformer(),
        """
        print(*range(1), *range(3))
        """,
        """
        print(*(list(range(1)) + list(range(3))))
        """)



# Generated at 2022-06-23 23:08:13.765858
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''
print('1', 2, sep='.', end='-')
print(*range(10), *range(3))
    ''')

# Generated at 2022-06-23 23:08:16.422118
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    t = StarredUnpackingTransformer()

    tree = ast.parse("x = [2, *range(10), 1] + 'a'")
    t.visit(tree)

    assert 'astunparse.unparse' in str(t)

# Generated at 2022-06-23 23:08:28.287868
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    expected_tree=ast.parse("""
        print(*(list(range(1)) + list(range(3))))
    """)
    tree = ast.parse("""
        print(*range(1), *range(3))
    """)
    t = StarredUnpackingTransformer()
    t.visit(tree)
    diff = ast_differ.compare(expected_tree,tree)
    assert not diff
    
    expected_tree=ast.parse("""
        [2] + list(range(10)) + [1]
    """)
    tree = ast.parse("""
        [2, *range(10), 1]
    """)
    t = StarredUnpackingTransformer()
    t.visit(tree)
    diff = ast_differ.compare(expected_tree,tree)
   

# Generated at 2022-06-23 23:08:37.867667
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # print(*range(1), *range(3))
    root = ast.Module(body=[ast.Expr(value=ast.Call(
        # print
        func=ast.Name(id='print'),
        # *range(1), *range(3)
        args=[
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=1)],
                    keywords=[])),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=3)],
                    keywords=[]))
        ],
        keywords=[])
    )])

# Generated at 2022-06-23 23:08:41.467999
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert [3, 4, 5, 6, 7] == ast.literal_eval(
        ast.dump(
            StarredUnpackingTransformer().visit(ast.parse(
                "print(*[3, *range(4, 8)])").body[0].value)))

# Generated at 2022-06-23 23:08:52.764313
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_astunparse.unparser import Unparser
    from typed_astunparse.unparser import UnparserVisitor
    from typed_ast import ast3 as ast
    test_ast_1 = ast.parse('[2, *range(10), 1]')
    test_ast_2 = ast.parse('print(*range(1), *range(3))')
    test = StarredUnpackingTransformer()
    result_1 = test.visit(test_ast_1)
    t = UnparserVisitor()
    Unparser(result_1, t)
    result_str_1 = t.result
    assert result_str_1 == '[2] + list(range(10)) + [1]'
    result_2 = test.visit(test_ast_2)
    t = UnparserVisitor()
    Unparser

# Generated at 2022-06-23 23:09:03.847011
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .. import ast_compare
    from .. import ast_parse
    from .. import ast_unparse
    from .. import ast_transformer
    tree = ast_parse.parse_string("""
[2, *range(10), 1]
print(*range(1), *range(3))
    """)
    expected = ast_parse.parse_string("""
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """)
    transformer = ast_transformer.ASTTransformer(
        [StarredUnpackingTransformer],
        "3.6")
    tree = transformer.visit(tree)
    ast_compare.expect_ast_eq(tree, expected)
    assert ast_unparse.unparse_obj(tree) == ast

# Generated at 2022-06-23 23:09:11.013353
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:09:15.200745
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == ast.dump(tree_visit_List())


# Generated at 2022-06-23 23:09:21.460297
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1] -> [2] + list(range(10)) + [1]
    source = """
    [2, *range(10), 1]
    """
    expected = """
    ([2] + list(range(10)) + [1])
    """
    tree = ast.parse(source)
    new_tree = StarredUnpackingTransformer().visit(tree)
    new_code = astor.to_source(new_tree)
    assert new_code == expected
