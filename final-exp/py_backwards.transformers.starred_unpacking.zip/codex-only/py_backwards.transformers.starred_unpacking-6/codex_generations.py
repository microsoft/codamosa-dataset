

# Generated at 2022-06-23 22:59:24.342558
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    query = "ast.List(elts=PATTERN)"
    result = ast_parse(code)
    result = list(result.find(query))[0]

    match = StarredUnpackingTransformer().visit(result)
    assert astor.to_source(match) == expected



# Generated at 2022-06-23 22:59:33.826054
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(*range(1), *range(3))'

    source = ast.parse(code)
    source_transformer = StarredUnpackingTransformer()
    source_transformer.visit(source)


# Generated at 2022-06-23 22:59:36.034968
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
     # tests that it creates an instance of StarredUnpackingTransformer
    assert StarredUnpackingTransformer()

# Unit tests for visit_List

# Generated at 2022-06-23 22:59:43.233482
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from .compile_to_ast import compile_body

    code = """
a.b(*c, *d)
"""
    node = ast3.parse(code)
    expected_code = """
a.b(*(c + d))
"""
    expected = compile_body(expected_code)
    assert StarredUnpackingTransformer.transform_code(code) == expected_code
    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-23 22:59:54.073181
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Test(unittest.TestCase):
        def test(self):
            # Given
            node = ast.List(elts=[
                ast.Num(n=2),
                ast.Starred(value=ast.Name(id='range')),
                ast.Name(id='A'),
            ], ctx=ast.Load())
            transformer = StarredUnpackingTransformer(is_test=True)

            # When
            new_node = transformer.visit(node)

            # Then
            self.assertEqual(len(new_node.elts), 2)
            result = ast.parse(compile(new_node, '<>', mode='eval')).body
            self.assertIsInstance(result, ast.Expression)
            self.assertIsInstance(result.value, ast.List)

# Generated at 2022-06-23 23:00:04.293837
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .context import Context
    from .helpers import dump_ast
    from .base import get_ast
    from mb.util.types import Function, ListOf
    """Unit test for constructor of class StarredUnpackingTransformer"""
    code = """
    class F:
        def __init__(self, x):
            self._x = x

    print(*range(1), *range(3))
    a = [2, *range(10), 1]
    b = F(*(2, *range(10), 1))
    c = F(*[2, *range(10), 1])
    """
    tree = get_ast(code, version=(3, 7))
    transformer = StarredUnpackingTransformer(Context())
    new_tree = transformer.visit(tree)

# Generated at 2022-06-23 23:00:12.004141
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    split_by_starred = StarredUnpackingTransformer._split_by_starred
    assert split_by_starred([ast.Num(n=2), ast.Num(n=3)]) == [[ast.Num(n=2), ast.Num(n=3)]]
    assert split_by_starred([ast.Num(n=2), ast.Starred(value=ast.Name(id='x')), ast.Num(n=3)]) == [[ast.Num(n=2)], ast.Starred(value=ast.Name(id='x')), [ast.Num(n=3)]]
    assert split_by_starred([ast.Starred(value=ast.Name(id='x'))]) == [ast.Starred(value=ast.Name(id='x'))]
    assert split_by

# Generated at 2022-06-23 23:00:15.274330
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass
#     print("Unit test for constructor of class StarredUnpackingTransformer")
#     StarredUnpackingTransformer()
# test_StarredUnpackingTransformer()


# Generated at 2022-06-23 23:00:18.753159
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse('[2, 3, 4]')
    actual = StarredUnpackingTransformer().visit(ast.parse('[2, *[3, 4]]'))
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-23 23:00:20.853338
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    print(isinstance(transformer, BaseNodeTransformer))
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-23 23:00:31.356142
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ..pygram import python_symbols as syms

    #
    # INPUT
    #

# Generated at 2022-06-23 23:00:39.322345
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    if not isinstance(transformer, StarredUnpackingTransformer):
        raise RuntimeError(f'Failed to create an instance of StarredUnpackingTransformer')
    if not isinstance(transformer, BaseNodeTransformer):
        raise RuntimeError(f'StarredUnpackingTransformer is not derived from BaseNodeTransformer')
    if not callable(transformer.visit_Call):
        raise RuntimeError(f'SUT does not implement visit_Call()')
    if not callable(transformer.visit_List):
        raise RuntimeError(f'SUT does not implement visit_List()')


# Generated at 2022-06-23 23:00:45.509299
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for visit_Call method."""
    code = 'print(*range(1), *range(3), 42)'
    tree = ast.parse(code)
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)

    assert transformer._tree_changed

# Generated at 2022-06-23 23:00:57.813874
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .fixtures import cst, ast_Module
    cst_list = cst('[2, *range(10), 1]')
    node_list = ast_Module(body=[
        ast.Expr(
            value=ast.List(elts=[
                ast.Num(n=2),
                ast.Call(
                    func=ast.Name(id='list'),
                    args=[ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Num(n=10)],
                        keywords=[])],
                    keywords=[]),
                ast.Num(n=1)])),
    ])

    class Transformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            self._tree_changed = True
            return node


# Generated at 2022-06-23 23:01:02.687436
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")

    expected = ast.parse("print(*((list(range(1)) + list(range(3)))))")
    result = StarredUnpackingTransformer().visit(node)

    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 23:01:03.711571
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:01:12.281458
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # dict
    module = ast.parse("{a:b, *{c:d, e:f, *{g:h}}}")
    expected = ast.parse("{**{'a':b}, **{'c':d, 'e':f}, **{'g':h}}")
    StarredUnpackingTransformer().visit(module)
    assert module == expected

    # list in list
    module = ast.parse("[[a,b], *[c,d]]")
    expected = ast.parse("[a,b]+[c,d]")
    StarredUnpackingTransformer().visit(module)
    assert module == expected

    # args
    module = ast.parse("print(1, *[2,3], 4)")
    expected = ast.parse("print(*(1,2,3,4))")

# Generated at 2022-06-23 23:01:18.318601
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ast_toolbox.transformer import NodeTransformer

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    tree = ast.parse(source)
    new_tree = NodeTransformer(StarredUnpackingTransformer).visit(tree)
    result = ast.unparse(new_tree)
    assert result == expected


# Generated at 2022-06-23 23:01:25.061766
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    module = ast.parse("""
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """)

    # When
    refactored = StarredUnpackingTransformer().visit(module)

    # Then
    expected = ast.parse("""
        list([2]) + list(range(10)) + list([1])
        print(*(list(range(1)) + list(range(3))))
    """)
    assert ast.dump(refactored) == ast.dump(expected)

# Generated at 2022-06-23 23:01:34.120131
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = 'list = [1, *range(10)]'
    expected = 'list = [1] + list(range(10))'

    tree = ast.parse(source)

    trans = StarredUnpackingTransformer()
    trans.visit(tree)

    generated = compile(tree, '<test>', 'exec')
    with io.StringIO() as io_out, io.StringIO() as io_err:
        with contextlib.redirect_stdout(io_out), contextlib.redirect_stderr(io_err):
            exec(generated)

        exec_out = io_out.getvalue()
        exec_err = io_err.getvalue()

    assert exec_out == ''
    assert exec_err == ''
    assert exec_out == ''
    assert exec_err == ''

    generated

# Generated at 2022-06-23 23:01:39.384432
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree.body[0].value) == \
        "[2,] + list(range(10)) + [1]"


# Generated at 2022-06-23 23:01:43.541536
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert StarredUnpackingTransformer().visit(
        ast.parse('print(1, *range(1), *range(10))')) == \
    ast.parse('print(*(list(range(1)) + list(range(10))))')



# Generated at 2022-06-23 23:01:44.140096
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-23 23:01:48.586061
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .fixtures import ast3_src

    src = ast3_src('''[2, *range(10), 1]''')
    expected = ast3_src('''[2] + list(range(10)) + [1]''')
    tr = StarredUnpackingTransformer()
    tr.visit(src)
    assert tr.tree_changed
    assert ast.dump(src) == ast.dump(expected)


# Generated at 2022-06-23 23:01:51.666767
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arrange
    source = "list(1, *range(3), *range(2))"
    expected = "list(*(list(1) + list(range(3)) + list(range(2))))"

    # Act
    actual = StarredUnpackingTransformer().visit(ast.parse(source))

    # Assert
    assert_source_equal(expected, actual)



# Generated at 2022-06-23 23:01:58.120931
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer
    from .docstrings import DocstringTransformer
    from .numeric_literals import NumericLiteralsTransformer

    code = '[2, *range(10), 1]'
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    NodeTransformer = BaseNodeTransformer.combined(
        (DocstringTransformer, True),
        (NumericLiteralsTransformer, True))
    tree = NodeTransformer().visit(tree)

    code = 'list([2] + list(range(10)) + [1])'
    assert eval(compile(tree, '', 'exec')) == eval(code)


# Generated at 2022-06-23 23:02:04.624270
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]")) == ast.parse("[2] + list(range(10)) + [1]")
    assert StarredUnpackingTransformer().visit(ast.parse("print(*range(1), *range(3))")) == ast.parse("print(*(list(range(1)) + list(range(3))))")

# Generated at 2022-06-23 23:02:09.101637
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code = 'print(*range(1), *range(3))'
    trans = StarredUnpackingTransformer()
    node = ast.parse(code)
    trans.visit(node.body[0])
    assert astor.to_source(node) == 'print(*(list(range(1)) + list(range(3))))\n'



# Generated at 2022-06-23 23:02:11.641381
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Testing StarredUnpackingTransformer")
    assert StarredUnpackingTransformer()


if __name__ == "__main__":
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:02:21.597389
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    from astmonkey import transformers
    # We don't care to compare errors
    transform = transformers.ParentChildNodeTransformer()
    visitor = StarredUnpackingTransformer()

    assert transform(ast.parse("print(2, 3, *[4, 5, 6])")) == \
           transform(ast.parse("print(*[2, 3, 4, 5, 6])"))

    assert transform(ast.parse("print(2, 3, *[4, 5, 6])")) == \
           transform(visitor.visit(ast.parse("print(2, 3, *[4, 5, 6])")))


# Generated at 2022-06-23 23:02:22.757736
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)

# Generated at 2022-06-23 23:02:31.308911
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    # Transformer
    result = transform(source, StarredUnpackingTransformer)
    # Compare
    assert iter_fields(result) == iter_fields(expected)
    # Unit test end
    global test_StarredUnpackingTransformer_visit_Call
    del test_StarredUnpackingTransformer_visit_Call
    

# Generated at 2022-06-23 23:02:38.625610
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import os
    import sys
    import astor
    from .example_code import example_code

    code_str = example_code.EXAMPLE_FUNC_PY3_4
    tree = ast.parse(code_str)
    tree1 = StarredUnpackingTransformer().visit(tree)
    tree2 = StarredUnpackingTransformer().visit(tree1)
    tree3 = StarredUnpackingTransformer().visit(tree2)


# Generated at 2022-06-23 23:02:50.135461
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source_code = """
    [2, *range(10), 1]
    """
    root = ast.parse(source_code)
    node = root.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)
    assert len(node.value.elts) == 3
    assert isinstance(node.value.elts[0], ast.Num)
    assert isinstance(node.value.elts[1], ast.Starred)
    assert isinstance(node.value.elts[2], ast.Num)
    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(node)
    assert isinstance(new_node, ast.Expr)
    assert isinstance(new_node.value, ast.BinOp)

# Generated at 2022-06-23 23:02:50.767089
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:02:54.385763
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.dump(ast.parse('''foo(1, *range(10), 2)''')) == \
        ast.dump(StarredUnpackingTransformer().visit(ast.parse('''foo(1, *range(10), 2)''')))


# Generated at 2022-06-23 23:03:02.565830
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """a = [2, *[3, 4]]"""
    node = ast.parse(code)
    t = StarredUnpackingTransformer()
    t.visit(node)
    expected = """a = [2] + list([3, 4])"""
    compiled = compile(node, '<test>', 'exec')
    assert expected == ''.join(l for l in pprinter.pprint(compiled.co_code).splitlines() if not l.startswith('  '))



# Generated at 2022-06-23 23:03:10.454842
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    module_node = parser.parse(
        textwrap.dedent('''
        list([3, *range(3), 2])
        '''))
    expected_node = parser.parse(
        textwrap.dedent('''
        list(3 + list(range(3)) + 2)
        '''))
    transformer = StarredUnpackingTransformer()

    # Act
    module_node = transformer.visit(module_node)

    # Assert
    assert ast.dump(module_node) == ast.dump(expected_node)


# Generated at 2022-06-23 23:03:18.551249
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class T(StarredUnpackingTransformer):
        def visit_Expr(self, node: ast.Expr) -> ast.Expr:
            return self.generic_visit(node)  # type: ignore

    t = T()
    tree = ast.parse('import sys; [1, *sys.argv, 2]')
    t.visit(tree)

# Generated at 2022-06-23 23:03:21.560671
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None
    assert transformer.changed == False

# Unit tests for function visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:03:29.387705
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)])
    result = transformer.visit(node)
    # print(result)

    assert transformer._tree_changed is True
    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.List)
    assert isinstance(result.right, ast.Call)

# Generated at 2022-06-23 23:03:33.438245
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'a, *b = [1, 2, 3]'
    check_equal_with_printing(code,
                              StarredUnpackingTransformer,
                              """
a, *b = [1, 2] + list(range(3))
""",
                              verbose=False)


# Generated at 2022-06-23 23:03:40.413764
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import inspect
    import astor
    from itertools import chain

    source = inspect.getsource(StarredUnpackingTransformer)
    tree = ast.parse(source)

    result = StarredUnpackingTransformer().visit(tree)
    source = astor.to_source(result)

    assert source == inspect.getsource(StarredUnpackingTransformer), 'Source code changed'

# Generated at 2022-06-23 23:03:45.984644
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

    assert transformer._has_starred([]) is False
    assert transformer._has_starred([ast.Starred(value=ast.Name(id='a'))]) is True
    assert transformer._has_starred([ast.Name(id='a')]) is False

    xs = [ast.List(elts=[ast.Starred(value=ast.Name(id='a')), ast.Name(id='b')])]
    assert transformer._split_by_starred(xs) == [
        ast.List(elts=[ast.Name(id='b')]),
        ast.Starred(value=ast.Name(id='a')),
        [],
    ]

# Generated at 2022-06-23 23:03:55.623726
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import asttyped
    import random
    import warnings

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            self.test_cases = list()  # type: List[Tuple[int, int]]

        def test_tree_changed(self):
            assert len(self.test_cases) == 0

        def test_invariants(self, test_case: Union[List[ast.expr], ast.List]):
            assert isinstance(test_case, (list, ast.List))

            if isinstance(test_case, list):
                for x in test_case:
                    assert isinstance(x, ast.expr)

# Generated at 2022-06-23 23:04:00.081824
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    tr = StarredUnpackingTransformer()
    result = tr.visit(node)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 23:04:07.815195
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    t = StarredUnpackingTransformer()
    new_node = t.visit(node)
    assert ast.dump(new_node) == "Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=1)], keywords=[])], keywords=[]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=3)], keywords=[])], keywords=[]))), keywords=[])"



# Generated at 2022-06-23 23:04:09.709231
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print(StarredUnpackingTransformer)


# Generated at 2022-06-23 23:04:20.037150
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    from typed_ast import ast3
    from io import StringIO
    from ast_pprint import pformat
    from py_src.cpy_ast_pprint import PPrintAST

    def assert_ast_equal(ast1, ast2):
        assert isinstance(ast1, type(ast2))

        if isinstance(ast1, ast.AST):
            for field in ast1._fields:
                if field == 'ctx':
                    # Both ctx and col_offset fields are not printed
                    # by ast_pprint (and are not tested here)
                    pass
                elif field == 'col_offset':
                    pass
                else:
                    value1 = getattr(ast1, field)
                    value2 = getattr(ast2, field)
                    assert_ast_equal(value1, value2)

       

# Generated at 2022-06-23 23:04:21.268595
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3,4)

# Generated at 2022-06-23 23:04:27.763786
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
    """

    expected_ast = ast.parse(
        """
print(*(list(range(1)) + list(range(3))))
        """
    )

    got_ast = ast.parse(source)
    got_ast = StarredUnpackingTransformer().visit(got_ast)
    assert got_ast == expected_ast


# Generated at 2022-06-23 23:04:32.676369
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse('a(*range(1),*range(3))')
    StarredUnpackingTransformer().visit(module)
    expected = ast.parse('a(*(list(range(1))+list(range(3))))')
    assert ast.dump(module) == ast.dump(expected)


# Generated at 2022-06-23 23:04:38.905042
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import from_source
    source = 'print(*range(1), *range(3))'
    node = from_source(source)
    res = StarredUnpackingTransformer().visit_Call(node)

# Generated at 2022-06-23 23:04:44.048721
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    tree = ast.parse(source)
    expected = "[2] + list(range(10)) + [1]"
    StarredUnpackingTransformer().visit(tree)
    assert expected == format_source(tree)


# Generated at 2022-06-23 23:04:49.817112
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # type: () -> None
    input_str = 'print(*range(1), *range(3))'
    ast_tree = ast.parse(input_str)
    expected_result = 'print(*(list(range(1)) + list(range(3))))'
    expected_tree = ast.parse(expected_result)

    result_transformer = StarredUnpackingTransformer()
    result_tree = result_transformer.visit(ast_tree)
    assert ast.dump(expected_tree) == ast.dump(result_tree)


# Generated at 2022-06-23 23:04:51.799317
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # N.B. This is an internal function, so it is not tested.
    pass # pragma: no cover


# Generated at 2022-06-23 23:05:01.987516
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    original = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Num(n=1)], ctx=ast.Load())
    expected = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)], ctx=ast.Load()), right=ast.Call(func=ast.Name(id='list', ctx=ast.Load()), args=[ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[], keywords=[])], keywords=[]), op=ast.Add())

# Generated at 2022-06-23 23:05:13.039354
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    class_instance = StarredUnpackingTransformer()
    node_with_starred = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Num(n=1)], ctx=ast.Load())

    # When
    result = class_instance.visit(node_with_starred)

    # Then
    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.List)
    assert isinstance(result.left.elts[0], ast.Num)
    assert result.left.elts[0].n == 2

    assert isinstance(result.right, ast.List)

# Generated at 2022-06-23 23:05:15.773012
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = 'print(*range(2), *range(3), sep="!")'
    expected = ast.parse('print(*(list(range(2)) + list(range(3))), sep="!")').body[0]
    actual = StarredUnpackingTransformer().visit(ast.parse(src).body[0])
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-23 23:05:23.702382
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """
    Visit Call and change this node from `Call(args=[Expr(Starred(...))])`
    to `Call(args=[Expr(BinOp(left=Expr(BinOp(...)), right=Expr(BinOp(...))))])`
    """
    target_tree = ast.parse(
        """
        [2, *range(10)]
        print(*range(1), *range(3))
        """
    )
    expected_tree = ast.parse(
        """
        [2] + list(range(10))
        print(*(list(range(1)) + list(range(3))))
        """
    )
    tree = StarredUnpackingTransformer().visit(target_tree)
    assert ast.dump(expected_tree) == ast.dump(tree)

# Generated at 2022-06-23 23:05:32.850432
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class DummyNodeTransformer(StarredUnpackingTransformer):
        def __init__(self):
            super().__init__()
            self._tree_changed = False

    node = ast.parse("[1, *range(10)]")

    transformer = DummyNodeTransformer()
    transformer.visit(node)

    assert transformer._tree_changed
    assert ast.dump(node) == "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=1)]), op=Add(), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[])))])"


# Generated at 2022-06-23 23:05:44.132511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer('x=[2, *range(10), 1]').visit_code() == 'x = [2] + list(range(10)) + [1]'
    assert StarredUnpackingTransformer('x=[2, 3, 4, 5]').visit_code() == 'x = [2, 3, 4, 5]'
    assert StarredUnpackingTransformer('x=[*range(10)]').visit_code() == 'x = list(range(10))'
    assert StarredUnpackingTransformer('x=[2, 3, *range(10)]').visit_code() == 'x = [2, 3] + list(range(10))'

# Generated at 2022-06-23 23:05:46.574421
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(b'None').tree is None
    assert StarredUnpackingTransformer(b'x').tree is None

# Generated at 2022-06-23 23:05:55.936359
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import astunparse
    import textwrap
    code = ast.parse(textwrap.dedent('''\
    print(*range(1), *range(3))
    '''))
    code = StarredUnpackingTransformer().visit(code)
    print(astunparse.unparse(code))
    print(ast.dump(code))

    code = ast.parse(textwrap.dedent('''\
    [2, *range(10), 1]
    '''))
    code = StarredUnpackingTransformer().visit(code)
    print(astunparse.unparse(code))
    print(ast.dump(code))

# Generated at 2022-06-23 23:06:05.985368
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ast_node = ast.parse(
        "range(1, *range(10), 1)"
    )
    tu = StarredUnpackingTransformer()
    tu.visit(ast_node)

    assert ast.dump(ast_node) == 'Module(body=[Expr(value=Call(func=Name(id="range", ctx=Load()), args=[BinOp(left=Num(n=1), op=Add(), right=Call(func=Name(id="range", ctx=Load()), args=[List(elts=[Num(n=10)]), Num(n=1)], keywords=[], starargs=None, kwargs=None))], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-23 23:06:14.468551
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    from textwrap import dedent
    from .utils import roundtrip

    source = dedent('''
    [2, *range(10), 1]
    ''')
    expected = dedent('''
    [2] + list(range(10)) + [1]
    ''')
    source_tree = ast.parse(source)
    expected_tree = ast.parse(expected)

    # Check that unmodified "source_tree" is equal to "expected_tree"
    assert roundtrip(source_tree) == roundtrip(expected_tree)

    # Check that "source_tree" compiled to "expected_tree" by
    # StarredUnpackingTransformer
    tree = StarredUnpackingTransformer.run(source_tree)
    assert roundtrip(tree) == roundtrip

# Generated at 2022-06-23 23:06:25.989634
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .unparse import Unparser
    result = Unparser(StarredUnpackingTransformer('').visit(ast.parse(
        ('print(1, 2, 3, *[4, 5], 6)'
         'print(1, 2, 3, *[4, 5], 6, *[1, 2, 3], 1)'
         'print(1, 2, 3, *[4, 5], 6, *[1, 2, 3], 1, *[1])'
         'print(1, 2, 3, *[4, 5], 6, *[1, 2, 3], 1, *[1], *[2])')).body[0]))


# Generated at 2022-06-23 23:06:35.125733
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    from typed_ast.ast3 import parse
    import astor
    node = parse("print(*range(1), *range(3))").body[0]
    xformer = StarredUnpackingTransformer()
    new_node = xformer.visit(node)
    expected_new_node = parse("""
from __future__ import print_function
print(*(list(range(1)) + list(range(3))))
""").body[1]
    assert astor.to_source(new_node) == astor.to_source(expected_new_node)



# Generated at 2022-06-23 23:06:45.816734
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer._split_by_starred([ast.Name(id='a'), ast.Starred(ast.Name(id='b'),ast.Load()), ast.Name(id='c')]) == [[ast.Name(id='a')], ast.Starred(ast.Name(id='b'),ast.Load()), [ast.Name(id='c')]]

# Generated at 2022-06-23 23:06:53.590549
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)

    StarredUnpackingTransformer().visit(node)

    assert isinstance(node.value, ast.BinOp)
    assert isinstance(node.value.left, ast.List)
    assert isinstance(node.value.op, ast.Add)
    assert isinstance(node.value.right, ast.List)


# Generated at 2022-06-23 23:06:57.123257
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    src = """
print(*range(1), *range(3))
    """
    expected_result = """
print(*(list(range(1)) + list(range(3))))
    """
    _test_transformer(StarredUnpackingTransformer, src, expected_result)


# Generated at 2022-06-23 23:07:09.088324
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    erp = StarredUnpackingTransformer()
    code = 'print(*range(10), *range(20))'
    test1 = erp.visit(ast.parse(code))
    print(test1)
    assert isinstance(test1, ast.Module)
    assert isinstance(test1.body[0], ast.Expr)
    assert isinstance(test1.body[0].value, ast.Call)
    assert isinstance(test1.body[0].value.func, ast.Name)
    assert isinstance(test1.body[0].value.args[0], ast.Starred)
    assert isinstance(test1.body[0].value.args[0].value, ast.BinOp)

# Generated at 2022-06-23 23:07:16.469759
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(
        ast.parse("[*range(1), *range(2)]").body[0]
    ) == ast.parse("[*(list(range(1)) + list(range(2)))]").body[0]
    assert StarredUnpackingTransformer().visit(
        ast.parse("[*range(1)]").body[0]
    ) == ast.parse("[*(list(range(1)))]").body[0]
    assert StarredUnpackingTransformer().visit(
        ast.parse("[*range(1), 1, *range(2)]").body[0]
    ) == ast.parse("[*(list(range(1)) + [1] + list(range(2)))]").body[0]
    assert StarredUnpackingTransformer().vis

# Generated at 2022-06-23 23:07:19.756363
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Arguments:
    inp_string = """\
        def function(a,*b): 
            a + b """
    out_string = """\
        def function(a, *b): 
            a + b """
    # Unit test
    StarredUnpackingTransformer().assert_equal(inp_string, out_string)
        

# Generated at 2022-06-23 23:07:24.168649
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast_py = """
foo = [2, *range(10), 1]
     """
    assert StarredUnpackingTransformer().visit(ast.parse(ast_py)) == ast.parse("""
foo = [2] + list(range(10)) + [1]
     """)


# Generated at 2022-06-23 23:07:30.505503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    source = """
x = "test"
print(x, x, x)
"""
    expected = """
x = "test"
print(*(["test", "test", "test"]))
"""
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)
    tree = round_trip(tree)
    assert ast.dump(tree) == expected



# Generated at 2022-06-23 23:07:40.371157
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    import astor
    t = StarredUnpackingTransformer()


# Generated at 2022-06-23 23:07:51.727318
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    
    def create_list_with_unpacking():
        return ast.List(elts=[
            ast.Starred(value=ast.Name(id='x')),
            ast.Const(value=2),
            ast.Starred(value=ast.Name(id='y')),
            ast.Const(value=3)])
    
    def create_call_with_unpacking():
        return ast.Call(
            func=ast.Name(id='print'),
            args=[
                ast.Starred(value=ast.Name(id='x')),
                ast.Starred(value=ast.Name(id='y'))],
            keywords=[])

    l = create_list_with_unpacking()
    c = create_call_with_unpacking()

    assert StarredUnpackingTransformer.is_applic

# Generated at 2022-06-23 23:07:52.539446
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:08:03.919058
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Initialize a list of nodes
    # Create an example of a list of nodes
    node1 = ast.List(
        elts=[
            ast.Call(
                func=ast.Name(id='list'),
                args=[
                    ast.Starred(
                        value=ast.Name(id='range'))],
                keywords=[])],
        ctx=ast.Load())

# Generated at 2022-06-23 23:08:13.378535
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse("""print([1, *range(10), 2])""")
    transformer.visit(tree)


# Generated at 2022-06-23 23:08:18.527850
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Unit test for constructor of class StarredUnpackingTransformer"""
    assert StarredUnpackingTransformer()._split_by_starred([ast.Name(id='a'),
                                                            ast.Starred(value=ast.Num(n=4)),
                                                            ast.Name(id='b'),
                                                            ast.Starred(value=ast.Name(id='c'))]) == \
        [ast.Name(id='a'),
         ast.Starred(value=ast.Num(n=4)),
        [],
         ast.Name(id='b'),
         ast.Starred(value=ast.Name(id='c')),
        []]

# Generated at 2022-06-23 23:08:28.236617
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .helpers import assert_equal_ast

    tree = ast.parse('[2, *range(10), 1]')
    res = StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(res, '([2] + list(range(10)) + [1])')
    assert StarredUnpackingTransformer().was_changed

    tree = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(res, ('print(*(([2] + list(range(10)) + [1]) + list(range(3))))'))
    assert StarredUnpackingTransformer().was_changed

# Generated at 2022-06-23 23:08:37.824398
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import UncompyleTestCase

    class Test(UncompyleTestCase):
        @property
        def _transformer(self):
            return StarredUnpackingTransformer

        def test_call_without_starred(self):
            node = ast.parse(
                'print(1, 2, 3)',
                mode='eval')
            new_node = self._transform(node)
            self.assertEqual(
                ast.dump(new_node),
                'Call(func=Name(id=\'print\', ctx=Load()), args=[Num(n=1), Num(n=2), Num(n=3)], keywords=[])')


# Generated at 2022-06-23 23:08:48.328375
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with pytest.raises(AssertionError):
        StarredUnpackingTransformer._has_starred([ast.Starred])

    assert StarredUnpackingTransformer._has_starred([
        ast.Starred(value=ast.Name(id='a'))])

    assert not StarredUnpackingTransformer._has_starred([
        ast.Num(10)
    ])

    assert StarredUnpackingTransformer._split_by_starred([
        ast.Name(id='a'), ast.Starred(value=ast.Num(10)), ast.Name(id='b')
    ]) == [
        [ast.Name(id='a')],
        ast.Starred(value=ast.Num(10)),
        [ast.Name(id='b')],
    ]

    assert StarredUnpackingTransformer._split

# Generated at 2022-06-23 23:08:59.869278
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()
    node = ast.parse("print(1, *range(10), 2, *range(10))").body[0]

    result = visitor.visit(node)

    assert isinstance(result, ast.Call)
    assert result.func.id == 'print'
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.BinOp)
    assert isinstance(result.args[0].value.left, ast.List)
    assert len(result.args[0].value.left.elts) == 3
    assert result.args[0].value.op.__class__ == ast.Add

# Generated at 2022-06-23 23:09:01.003222
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:09:06.443831
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test StarredUnpackingTransformer._to_sum_of_lists method."""

    node = ast.parse('''
    x = test(1, *range(1), *range(3), 2)
    ''').body[0].value  # type: ast.Call

    expected = ast.parse('''
    x = test(*(list(range(1)) + list(range(3)) + [1, 2]))
    ''').body[0].value

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)

    assert transformer._tree_changed
    assert ast.dump(result, annotate_fields=False) == ast.dump(expected, annotate_fields=False)


# Generated at 2022-06-23 23:09:12.732487
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import typed_ast.ast3
    class _(ast.AST):
        _fields = ('left','right','op')
    x = typed_ast.ast3.BinOp(ast.Num(n=1),ast.Num(n=1),op=_(ast.Num(n=1),ast.Num(n=1),ast.Add()))
    assert x is not None


# Generated at 2022-06-23 23:09:21.999037
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import CompileError, compile_ast

    def assert_compile(node, expected):
        x = StarredUnpackingTransformer().visit(node)
        yield assertEqual, compile_ast(x, '<test>', 'exec', mode='eval'), expected

    yield assert_compile(ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range'), ctx=ast.Load())]), 'print(*range(10))\n')