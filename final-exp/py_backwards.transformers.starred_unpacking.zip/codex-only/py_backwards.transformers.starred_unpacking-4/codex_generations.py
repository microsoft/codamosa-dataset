

# Generated at 2022-06-23 22:59:22.838192
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[1, 2, 3, *[4, 5], 6, *range(7, 9)]')
    ast.fix_missing_locations(tree)

    with transformer.enable():
        transformed_tree = transformer.visit(tree)

    assert isinstance(transformed_tree, ast.Module)
    assert len(transformed_tree.body) == 1
    node = transformed_tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.BinOp)
    assert isinstance(node.value.left, ast.BinOp)
    assert isinstance(node.value.left.left, ast.BinOp)

# Generated at 2022-06-23 22:59:23.654734
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 4)

# Generated at 2022-06-23 22:59:33.266853
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Define initial test-cases
    # Test-case 1
    test_case_1 = '[2, *range(10), 1]'
    # Test-case 2
    test_case_2 = 'print(*range(1), *range(3))'
    # Test-case 3 -- recognize error
    test_case_3 = '[2, range(10), 1]'

    # Test test-case 1
    result_1 = StarredUnpackingTransformer().visit(ast.parse(test_case_1))

# Generated at 2022-06-23 22:59:38.211688
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = ast.parse('print(*range(3))')
    expected = ast.parse('print(*list(range(3)))')
    transformer = StarredUnpackingTransformer()
    transformer.visit(source)
    assert transformer._tree_changed
    assert ast.dump(source) == ast.dump(expected)


# Generated at 2022-06-23 22:59:49.124259
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .test_helpers import node_equal
    from .test_helpers import ast_parse
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    supt = StarredUnpackingTransformer()
    assert isinstance(supt, BaseNodeTransformer)
    source = "[2, *range(10), 1]"
    expected_target = "ast_parse('[2] + list(range(10)) + [1]', mode='eval').body"
    result = ast_parse(source=source, mode='eval').body
    expected = eval(expected_target)
    assert isinstance(result, ast3.List)
    assert node_equal(left=expected, right=result)
    source = "print(*range(1), *range(3))"
    expected

# Generated at 2022-06-23 22:59:51.446022
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    assert isinstance(sut, StarredUnpackingTransformer)



# Generated at 2022-06-23 23:00:01.634416
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from py_mini_racer import py_mini_racer

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    ctx = py_mini_racer.MiniRacer()
    ctx.eval(code)
    tr = StarredUnpackingTransformer()
    tr.visit(ast.parse(code))
    assert tr.get_code() == expected

    # noop
    code = "[1, 2, 3]"
    ctx.eval(code)
    tr = StarredUnpackingTransformer()
    tr.visit(ast.parse(code))
    assert tr.get_code() == code

    # more tests
    code = "[3,*a,*b,*c,4]"

# Generated at 2022-06-23 23:00:10.331430
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = 1
    b = 2
    c = 3
    test = StarredUnpackingTransformer()
    node = ast.List(elts=[a, b, c])
    assert test._has_starred(node.elts) == False
    assert isinstance(test._split_by_starred(node.elts), list) == True
    assert isinstance(test._prepare_lists(node.elts), Iterable) == True
    assert isinstance(test._merge_lists(node.elts), ast.BinOp) == True
    assert isinstance(test._to_sum_of_lists(node.elts), Union[ast.BinOp, ListEntry]) == True
    assert isinstance(test.generic_visit(node), ast.List) == True

# Generated at 2022-06-23 23:00:16.501036
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = '''
print(*range(1), *range(3), 3, *range(5))
'''
    expected = '''
print(*(list(range(1)) + list(range(3)) + [3] + list(range(5))))
'''
    node = ast.parse(source)
    StarredUnpackingTransformer().visit(node)
    result = ast.unparse(node)
    assert result == expected



# Generated at 2022-06-23 23:00:22.667426
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
   code = """
print('hello', *args, 'world')
"""
   # Compile code
   module = compile(code, 'test.py', 'exec')
   # Transform tree
   StarredUnpackingTransformer().visit(module)
   # Get new code
   code2 = ast.unparse(module)
   # Compare source codes
   print(code)
   print(code2)
   assert code.strip() != code2.strip()
   assert 'print(*(list([\'hello\']) + list(args) + list([\'world\'])))' in code2

# Generated at 2022-06-23 23:00:28.958751
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''
        f(1, 2, 3, *range(10), 1)
    ''')
    StarredUnpackingTransformer().visit(tree)
    assert astunparse(tree)[1:-1] == 'f(*(list([1]) + list([2]) + list([3]) + list(range(10)) + list([1])))'



# Generated at 2022-06-23 23:00:36.108897
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]")) == \
        ast.parse("[2] + list(range(10)) + [1]").body[0]

    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), *range(1), 1]")) == \
        ast.parse("[2] + list(range(10)) + list(range(1)) + [1]").body[0]

    assert StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), [], 1]")) == \
        ast.parse("[2] + list(range(10)) + [1]").body[0]


# Generated at 2022-06-23 23:00:40.683180
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import typed_ast.ast3
    tree = ast.parse('[2, *range(10), 1]')
    tree2 = typed_ast.ast3.ast_parse('[3] + list(range(10)) + [1]')
    StarredUnpackingTransformer(tree).visit(tree)
    assert typed_ast.ast3.dump(tree) == typed_ast.ast3.dump(tree2)



# Generated at 2022-06-23 23:00:44.930300
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import sys
    import parser
    import astunparse
    print(sys.version)
    print("Constructor Test Start")
    # Test should be updated with minimum python version
    # to test with.
    code = """
    [2, *range(10), 1]
    """
    tree = parser.suite(code)
    # print(tree)
    compiled_node = StarredUnpackingTransformer()
    print(astunparse.unparse(compiled_node.visit(tree)))
    print("Constructor Test End\n")

# Generated at 2022-06-23 23:00:52.511592
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    code_transformed = "[2].__add__(list(range(10))).__add__([1])"

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    generated_code = compile(tree, '<string>', mode='eval')
    result = eval(generated_code)
    assert eval(code_transformed) == result


# Generated at 2022-06-23 23:01:01.975921
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .__test__.transformers.test_data.StarredUnpackingTransformer import test_data_StarredUnpackingTransformer
    from .__test__.transformers.test_data.StarredUnpackingTransformer import test_data_StarredUnpackingTransformer_expected_from_visit_List

    assert_transformer_result(
        StarredUnpackingTransformer(),
        test_data_StarredUnpackingTransformer,
        test_data_StarredUnpackingTransformer_expected_from_visit_List
    )

    # TODO: assert error if List(elts=[Starred(value=1), Starred(value=2)])


# Generated at 2022-06-23 23:01:07.880424
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # given
    target_version = (3, 6)
    transformer = StarredUnpackingTransformer(target_version)
    node = ast.parse('[2, *range(10), 1]')
    expected = ast.parse('[2] + list(range(10)) + [1]')

    # when
    result = transformer.visit(node)

    # then
    assert_equal_ast(result, expected)



# Generated at 2022-06-23 23:01:19.449047
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typed_python_transpiler.untyped_python_ast_to_typed_python_ast import _fix_ast
    import typed_python_transpiler
    import typing
    import ast as typed_ast
    from typed_python_transpiler.untyped_python_ast_to_typed_python_ast import UntypedPythonAstToTypedPythonAst, _get_ast_node_location

    class StarredUnpackingTransformerTest(StarredUnpackingTransformer):
        target = typed_ast.ast3.parse('print(*(list(range(1)) + list(range(3))))')

    class DummyBase(typing.NamedTuple):
        a: int
        b: str

    # Create typed_ast

# Generated at 2022-06-23 23:01:25.411886
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1]
    tree = ast.parse("[2, *range(10), 1]", "...test_file.py")
    # Should be [2] + list(range(10)) + [1]
    should_be = ast.parse("[2] + list(range(10)) + [1]", "...test_file.py")

    assert StarredUnpackingTransformer.apply(tree) == should_be


# Generated at 2022-06-23 23:01:33.565440
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer

    class CustomTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    tree = ast.parse("[2, *range(10), 1]")
    CustomTransformer().visit(tree)
    node = tree.body[0].value
    assert isinstance(node, ast.BinOp)
    assert isinstance(node.left, ast.BinOp)
    assert isinstance(node.left.left, ast.List)
    assert isinstance(node.left.op, ast.Add)
    assert isinstance(node.left.right, ast.Call)
    assert isinstance(node.op, ast.Add)
    assert isinstance(node.right, ast.List)


# Generated at 2022-06-23 23:01:38.384680
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def check(code: str, expected: str) -> None:
        tree = ast.parse(code)
        node = tree.body[0]
        actual = StarredUnpackingTransformer().visit(node)
        assert actual == ast.parse(expected).body[0]


# Generated at 2022-06-23 23:01:47.486397
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_tools import assert_node_equal

    x = StarredUnpackingTransformer()
    assert_node_equal(x.visit(ast.parse('[2, *range(10), 1]')), '[2] + list(range(10)) + [1]')
    assert_node_equal(x.visit(ast.parse('[2, 3, *range(10), 1]')), '[2, 3] + list(range(10)) + [1]')
    assert_node_equal(x.visit(ast.parse('[2, 3, *range(10), *range(1), 1]')),
                       '[2, 3] + list(range(10)) + list(range(1)) + [1]')

# Generated at 2022-06-23 23:01:48.201366
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:01:53.317225
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astunparse
    from .base import BaseNodeTransformer
    from .parens import RemoveParensAroundLists
    from .literals import LiteralToBuiltin

    program = ast.parse("print(*[1, 5, 9], *[2, 5, 9, 0], sep=' ')")
    print(astunparse.unparse(program))
    print("--")

    program = StarredUnpackingTransformer().visit(program)
    program = RemoveParensAroundLists().visit(program)
    program = LiteralToBuiltin().visit(program)
    print(astunparse.unparse(program))
    assert program
    print("--")

# Generated at 2022-06-23 23:02:00.394944
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    expected = """
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """
    node = parse(source)
    result = StarredUnpackingTransformer(node).visit(node)
    assert_source_equal(expected, result)

# Generated at 2022-06-23 23:02:02.169106
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10)]'
    expected = 'list([2]) + list(range(10))'
    result = compile_restricted(source, StarredUnpackingTransformer)
    assert result == expected


# Generated at 2022-06-23 23:02:11.241811
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .._test_utils import make_fake_node
    from .. import ast3 as ast3_module
    from . import _core_transformer

    @ast3_module.parse
    def make_starred():
        print(*range(1), *range(2), *[1])

    source = make_starred
    node = source.body[0]
    node = make_fake_node(node)

    core_transformer = _core_transformer.CoreTransformer()
    core_transformer.visit(node)
    assert core_transformer.tree_changed is True

    assert isinstance(node.body[0].value.args[0].elts[0], ast.Call)
    assert node.body[0].value.args[0].elts[0].func.id == 'list'


# Generated at 2022-06-23 23:02:21.257429
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    import io
    import sys

    code = """
some_list = [1, 2, 3]
some_other_list = [4, 5, 6, 7, 8]

combined = [1, 2, *some_list, *some_other_list, 3]

print(*range(1), *range(2))
    """

    # Get ast from code
    node = ast3.parse(code)

    # Write ast in code
    output = io.StringIO()
    ast3.unparse(node, output)
    written_code = output.getvalue()
    assert written_code == code

    # Modify ast
    transformer = StarredUnpackingTransformer()
    new_node = transformer.visit(node)
    assert transformer.has_changed() == True

   

# Generated at 2022-06-23 23:02:23.341984
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    assert repr(obj) == '<StarredUnpackingTransformer>'
    assert str(obj) == '<StarredUnpackingTransformer>'

# Generated at 2022-06-23 23:02:28.442337
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    assert ast.dump(result) == ast.dump(ast.parse('[2] + list(range(10)) + [1]'))


# Generated at 2022-06-23 23:02:39.993449
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    sut = StarredUnpackingTransformer()
    assert isinstance(sut, BaseNodeTransformer)
    assert sut._has_starred([]) == False
    assert sut._has_starred([ast.Call(func=ast.Name(id='list'), args=[], keywords=[])]) == False
    assert sut._has_starred(
        [ast.Call(func=ast.Name(id='list'), args=[], keywords=[]), ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[], keywords=[]))]) == True
    assert sut._split_by_starred([]) == [[]]

# Generated at 2022-06-23 23:02:49.598171
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]", "<test>", 'eval')
    expected = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=10)],
                    keywords=[])],
                keywords=[]
            ),
            ast.Num(n=1)
        ],
        ctx=ast.Load())
    res = StarredUnpackingTransformer().visit(node)
    assert res.body == expected


# Generated at 2022-06-23 23:02:59.808052
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .visitor import FakeVisitor
    from .visitor import FakeTransformer
    from .visitor import print_helper
    from .visitor import print_ast

    code = """
    [2, *range(10), 1]
    """

    tree = ast.parse(code)
    print_ast(tree)

    t = StarredUnpackingTransformer()

    tree = t.visit(tree)
    print_ast(tree)

    compiler = t.get_compiler()

    fake_transformer = FakeTransformer(compiler)
    print_helper(fake_transformer.visit(tree))
    assert fake_transformer.code == """
    [2] + list(range(10)) + [1]
    """

    fake_visitor = FakeVisitor(compiler)
    fake_vis

# Generated at 2022-06-23 23:03:01.293033
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import inspect
    assert inspect.isclass(StarredUnpackingTransformer)

# Generated at 2022-06-23 23:03:12.066290
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from byterun.packed_ast import pack_ast
    from typed_astunparse import unparse

    def test_transformer_works(code, expected):
        compiled = compile(code, 'test', 'exec')
        packed_tree = pack_ast(compiled)
        x = StarredUnpackingTransformer()
        x.visit(packed_tree)
        compiled_tree = x.visit(packed_tree)
        unparsed = unparse(compiled_tree)
        assert unparsed.strip() == expected.strip()
    
    def test_transformer_raises(code):
        compiled = compile(code, 'test', 'exec')
        packed_tree = pack_ast(compiled)
        x = StarredUnpackingTransformer()
        x.vis

# Generated at 2022-06-23 23:03:22.462953
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast
    inp = [
        'a = [2, *range(10), 1]',
        'print(*range(1), *range(3))'
    ]

# Generated at 2022-06-23 23:03:23.514021
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-23 23:03:32.591322
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1]")) == ast.parse("[2] + list(range(10)) + [1]")
    StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), 1, *range(5), 1]")) == ast.parse("[2] + list(range(10)) + [1] + list(range(5)) + [1]")
    StarredUnpackingTransformer().visit(ast.parse("[2, *range(10), *range(5), 1]")) == ast.parse("[2] + list(range(10)) + list(range(5)) + [1]")

# Generated at 2022-06-23 23:03:34.764425
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_obj = StarredUnpackingTransformer()
    if isinstance(test_obj, BaseNodeTransformer):
        assert True
    else:
        assert False

# Generated at 2022-06-23 23:03:38.930795
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import do_test
    code = "[2, *range(10), 1]"
    result = "[2] + list(range(10)) + [1]"
    do_test(code, result, StarredUnpackingTransformer)


# Generated at 2022-06-23 23:03:40.308926
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer

# Generated at 2022-06-23 23:03:46.876878
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    '''Tests that StarredUnpackingTransformer works as intended.'''
    expected_output = ast.parse('[1, 2, 3, 4, 5]')  # Test that it passes unchanged
    test_output_1 = ast.parse('[1, *[2, 3, 4], 5]')
    input_ = StarredUnpackingTransformer().visit(test_output_1)
    assert ast.dump(expected_output) == ast.dump(input_)

# Generated at 2022-06-23 23:03:48.006280
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x is not None


# Generated at 2022-06-23 23:03:54.921846
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .utils import setup_fixtures, assert_transform_equal
    from typed_ast import ast3 as ast

    source = '''
        [1, *range(10), 2]
        print(*range(3))
    '''

    expected = '''
        [1] + list(range(10)) + [2]
        print(*list(range(3)))
    '''

    fixtures = setup_fixtures(source, expected)
    BaseNodeTransformer.verbose = True
    result = StarredUnpackingTransformer().visit(fixtures['node'])
    assert isinstance(result, ast.Module)
    assert_transform_equal(result, fixtures['expected'])

# Generated at 2022-06-23 23:04:04.436957
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from py_transpiler.test_utils import transpile_test_case
    from py_transpiler.test_utils import source_to_ast as sta


# Generated at 2022-06-23 23:04:11.875986
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """print(*range(1), *range(3))"""
    expected_code = """print(*(list(range(1)) + list(range(3))))"""
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node).strip() == expected_code

test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-23 23:04:16.339208
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x, y, z = 4, 1, 2
    call = "print(*range(x), *range(y), z)"
    expected = "print(*((list(range(x)) + list(range(y)) + [z])))"
    assert StarredUnpackingTransformer().run(call) == expected

# Generated at 2022-06-23 23:04:20.199137
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse(
        '[2, *range(10), 1]', mode='eval')  # type: ast.Expression
    expected = ast.parse(
        '[2] + list(range(10)) + [1]', mode='eval')  # type: ast.Expression

    result = StarredUnpackingTransformer().visit(node)

    assert result == expected


# Generated at 2022-06-23 23:04:31.627411
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer((3,4)).visit(ast.parse('[2, *range(10), 1]')) == \
        """_ast.List(
    elts=[_ast.Constant(
        value=2,
        kind=None),
        _ast.Call(
            func=_ast.Name(
                id='list',
                ctx=_ast.Load()),
            args=[_ast.Call(
                func=_ast.Name(
                    id='range',
                    ctx=_ast.Load()),
                args=[_ast.Constant(
                    value=10,
                    kind=None)],
                keywords=[])],
            keywords=[]),
        _ast.Constant(
            value=1,
            kind=None)],
    ctx=_ast.Load())"""

# Generated at 2022-06-23 23:04:40.462764
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:04:45.801962
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
[2, *range(10), 1]
"""
    expected = """
([2] + list(range(10)) + [1])
"""
    assert(expected.strip() ==
           StarredUnpackingTransformer().visit(ast.parse(source)).body[0].value.strip())


# Generated at 2022-06-23 23:04:53.871566
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)
    assert repr(tree) == (
        "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), "
        "args=[Starred(value=BinOp(left=BinOp(left=List(elts=[Call(func=Name(id='range', ctx=Load()), "
        "args=[Constant(value=1)])]), right=List(elts=[Call(func=Name(id='range', ctx=Load()), "
        "args=[Constant(value=3)])]), op=Add()))], keywords=[]))])])"
    )



# Generated at 2022-06-23 23:05:00.017018
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
        [2, *range(10), 1]
    """
    expected = """
        (2) + list(range(10)) + (1)
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    compiled = compile(tree, '<test>', 'exec')
    assert expected == str(compiled.code)



# Generated at 2022-06-23 23:05:01.646359
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert isinstance(a, StarredUnpackingTransformer)

# Generated at 2022-06-23 23:05:08.820599
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            code = "[2, *range(10), 1]"
            expected = "[2] + list(range(10)) + [1]"
            self.assertTransformEqual(code, expected)

    return Test('test_simple').test_simple()


# Generated at 2022-06-23 23:05:18.479150
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from .base import NodeTransformerTestCase
    from .base import run_transformer_test_cases

    class TestTransformer(NodeTransformerTestCase):
        transformer_class = StarredUnpackingTransformer

        def test_star_inside(self):
            input_source = """
            [2, *range(10), 1]
            """
            self.assertTransformedAst(input_source, """
            [2] + list(range(10)) + [1]
            """)

        def test_star_only(self):
            input_source = """
            [*range(10)]
            """
            self.assertTransformedAst(input_source, """
            list(range(10))
            """)


# Generated at 2022-06-23 23:05:25.365542
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(2), 4, *range(3), 5, *range(1)]"
    expected = "[2] + list(range(2)) + [4] + list(range(3)) + [5] + list(range(1))"
    test = StarredUnpackingTransformer()
    result = test.visit(ast.parse(code))
    assert result.body[0].value.elts[0].elts[0].n == 2
    assert result.body[0].value.elts[1].args[0].elts[0].n == 2
    assert result.body[0].value.elts[1].args[0].elts[1].n == 4
    assert result.body[0].value.elts[2].args[0].elts[0].n == 3
   

# Generated at 2022-06-23 23:05:26.995063
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert s is not None


# Generated at 2022-06-23 23:05:32.462964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
	source = 'print(*range(1), *range(3), *range(5))'
	# expected = 'print(*(list(range(1)) + list(range(3)) + list(range(5))))'
	print(ast.parse(source).body[0])
	print('\n')
	print(StarredUnpackingTransformer().visit(ast.parse(source).body[0]))



if __name__ == "__main__":
    print("This is a module for import, not for direct use.")

# Generated at 2022-06-23 23:05:39.603247
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Arrange
    cls = StarredUnpackingTransformer

    node = ast.parse('f(*range(1), *range(3))')
    expected = ast.parse('f(*(list(range(1)) + list(range(3))))')

    # Act
    result = cls().visit(node)

    # Assert
    assert ast.dump(expected) == ast.dump(result)



# Generated at 2022-06-23 23:05:50.223127
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .asdl import asdl_to_ast
    
    c = StarredUnpackingTransformer()
    node = asdl_to_ast(ast3, "(<expr>body=(<expr>value=<name>'a' <expr>value=<name>'b' <starred>value=<name>'c' <expr>value=<name>'d'))")
    c.visit(node)
    assert isinstance(node.body, ast3.BinOp)
    assert node.body.left.value.id == "a"
    assert node.body.right.value.id == "b"
    assert node.body.right.left.value.id == "d"


# Generated at 2022-06-23 23:05:59.127010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(code):
        tree = ast.parse(code)
        StarredUnpackingTransformer().visit(tree)
        compiled = compile(tree, '<test>', 'exec')
        res = []
        exec(compiled, {'print': res.append})
        return res

    assert test('print(*range(3), *range(2))') == ['0', '1', '2', '0', '1']
    assert test('print(1, *range(2), 3, *range(4))') == ['1', '0', '1', '3', '0', '1', '2', '3']

# Generated at 2022-06-23 23:06:09.141277
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class FakeLoader():
        @staticmethod
        def load_module(*args):
            pass
    fake_loader = FakeLoader()

    source_1 = """
foo(bar, *[1,2])
"""
    source_2 = """
foo(bar, *[1,2], *[1,2])
"""
    source_3 = """
foo(bar, *[1,2], *[1,2], *[1,2])
"""
    source_4 = """
foo(*[1,2], bar, *[1,2], baz, *[1,2], *[1,2])
"""
    source_5 = """
foo(*[1,2], bar, *[1,2], baz, *[1,2], *[1,2], *[1,2])
"""
    source_

# Generated at 2022-06-23 23:06:15.310612
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.source_repr import to_source
    from .utils import round_trip

    input_source = """
    a = f(0, 1, *x, *y)
    
    """
    expected_source = """
    a = f(*(list([0, 1]) + list(x) + list(y)))
    
    """

    tree = round_trip(input_source)
    node = StarredUnpackingTransformer().visit(tree)
    assert expected_source == to_source(node)



# Generated at 2022-06-23 23:06:16.324435
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-23 23:06:24.310568
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.dump(
        StarredUnpackingTransformer().visit(
            ast.parse(
                """
            a = 1
            b = 2
            print(*range(b), *range(a))
            """
            )
        )
    ) == ast.dump(
        ast.parse(
            """
        >>> a = 1
        >>> b = 2
        >>> print(*(list(range(b)) + list(range(a))))
        """
        )
    )



# Generated at 2022-06-23 23:06:26.924384
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    line = 3
    column = 4
    t = StarredUnpackingTransformer(line, column)
    assert t.target == (3, 4)

# Generated at 2022-06-23 23:06:34.170952
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source_code = """\
[2, *range(10), 1]
print(*range(1), *range(3))
    """
    tree = ast.parse(source_code)
    new_tree = StarredUnpackingTransformer().visit(tree)

    print(ast.dump(new_tree, include_attributes=True))
    source_code2 = """\
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
    """
    tree2 = ast.parse(source_code2)
    print(ast.dump(tree2, include_attributes=True))

    assert ast.dump(new_tree, include_attributes=True) == ast.dump(tree2, include_attributes=True)


# Generated at 2022-06-23 23:06:36.881053
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class TestTransformer(StarredUnpackingTransformer):
        pass

    assert TestTransformer().name == '<TestTransformer>'


# Generated at 2022-06-23 23:06:42.419334
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    star = ast.Name(id='list', ctx=ast.Load())
    star1 = ast.Call(func=star, args=[ast.Num(n=1)], keywords=[])
    star2 = ast.Call(func=star, args=[ast.Num(n=2)], keywords=[])
    result = ast.Call(func=ast.Name(id='print', ctx=ast.Load()),
                      args=[ast.Starred(value=ast.BinOp(left=star1, right=star2, op=ast.Add()))],
                      keywords=[])
    ex_result = astor.to_source(result)

# Generated at 2022-06-23 23:06:42.976604
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

# Generated at 2022-06-23 23:06:52.985809
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import generate_code

    node = ast.List(elts=[
        ast.Num(n=1),
        ast.Starred(value=ast.Name(id='a')),
    ])
    # Deduced type: ast.List(elts=[
    #     ast.Num(n=1),
    #     ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='a')], keywords=[])])

    code_before = generate_code(node)

    node_transformed = StarredUnpackingTransformer().visit(node)
    code_after = generate_code(node_transformed)

    assert code_before != code_after



# Generated at 2022-06-23 23:06:57.317692
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("""
    [2, *range(10), 1]
    """)
    expected = """
    [2] + list(range(10)) + [1]
    """
    # visit_List
    node = StarredUnpackingTransformer().visit_List(node.body[0].value)
    result = ast.unparse(node)
    assert result == expected


# Generated at 2022-06-23 23:07:02.955413
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # test_generate_starred_transformer_visit_List
    node = ast.List(elts=[
        ast.List(elts=[
            ast.List(elts=[ast.Num(n=2)]),
            ast.Starred(value=ast.Name(id='list'))
        ])
    ])

    StarredUnpackingTransformer().visit(node)


# Generated at 2022-06-23 23:07:09.526155
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    st = StarredUnpackingTransformer()
    assert(st.unparse(st.transform(st.parse("[2, *range(10), 1]\nprint(*range(1), *range(3))"))) ==
           "[2] + list(range(10)) + [1]\nprint(*(list(range(1)) + list(range(3))))")


# Generated at 2022-06-23 23:07:15.863344
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Example of code to parse
    source = """
print(*range(1), *range(3))
"""

    # Parsed code
    tree = ast.parse(source)

    # Expected result
    expected_source = """
print(*(list(range(1)) + list(range(3))))
"""
    expected_tree = ast.parse(expected_source)

    # Compare two ASTs
    assert StarredUnpackingTransformer().visit(tree) == expected_tree

# Generated at 2022-06-23 23:07:21.322510
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    parser = ast.PyCF_ONLY_AST
    code_string = "[2, 3, *range(3)]"
    code = compile(code_string, "<string>", mode="eval", flags=parser)
    tree = StarredUnpackingTransformer()(code)
    expected = "([2, 3] + list(range(3)))"
    assert ast.dump(tree) == expected, f"{ast.dump(tree)}"

# Generated at 2022-06-23 23:07:31.555201
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class MockNode(ast.AST):
        _attributes = ()

    code = ast.parse(textwrap.dedent('''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    '''))

    # Check if an object of class StarredUnpackingTransformer is created or not
    assert isinstance(StarredUnpackingTransformer(), StarredUnpackingTransformer)

    # Check if the contents of node are properly extracted
    assert StarredUnpackingTransformer().visit(MockNode()) == MockNode()

    # Check if a call with no starred arguments is not processed

# Generated at 2022-06-23 23:07:38.077526
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('Unit test: StarredUnpackingTransformer.visit_Call')
    ast_ = ast.parse('print(*range(1), *range(3))')
    transformer = StarredUnpackingTransformer()
    ast_.body[0].value = transformer.visit(ast_.body[0].value)
    assert transformer.tree_changed is True
    assert astor.to_source(ast_.body[0].value) == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-23 23:07:50.456007
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # test1
    xs = [ast.Call(func=ast.Name(id='print'),
               args=[ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()),
                     ast.Num(n=1),
                     ast.Starred(value=ast.Name(id='range'), ctx=ast.Load())],
               keywords=[])]


# Generated at 2022-06-23 23:08:00.079244
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    d = {'a': 3}
    n = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Num(n=3),
            ast.Starred(
                value=ast.Dict(keys=[ast.Name(id='a', ctx=ast.Load())],
                               values=[ast.Num(n=3)]))
        ], keywords=[])

    tree = ast.parse(
        inspect.getsource(test_StarredUnpackingTransformer_visit_Call))
    tree = tree.body[0].value  # get the test function call
    orig = ast.dump(tree)
    compile(tree, '<test>', 'exec')

    tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 23:08:07.156490
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helper import compile_source
    from astunparse import unparse

    source = '[2, *range(10), 1]'
    code = compile_source(source, '<test>', 'exec')
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert unparse(tree) == '([2] + list(range(10)) + [1])'



# Generated at 2022-06-23 23:08:13.456749
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = "print(2, *range(5), *range(7))"
    expect_result = "print(*(list(range(5)) + list(range(7))))"
    print(expect_result)
    expect_result = ast.parse(expect_result, '<unknown>', 'exec')

    tree = ast.parse(source, '<unknown>', 'exec')
    assert ast.dump(StarredUnpackingTransformer(False).visit(tree)) == ast.dump(expect_result)


# Generated at 2022-06-23 23:08:24.208129
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Name(id='x'))])
    assert StarredUnpackingTransformer._split_by_starred([ast.Starred(value=ast.Name(id='x'))]) == [[], ast.Starred(value=ast.Name(id='x')), []]
    assert StarredUnpackingTransformer._split_by_starred([ast.Name(id='x')]) == [[ast.Name(id='x')]]

# Generated at 2022-06-23 23:08:34.656737
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]", mode='eval')
    transformer = StarredUnpackingTransformer({})
    transformed_node = transformer.visit(node)
    assert isinstance(transformed_node, ast.BinOp)
    assert isinstance(transformed_node.left, ast.List)
    assert isinstance(transformed_node.right, ast.BinOp)
    assert isinstance(transformed_node.right.left, ast.Call)
    assert isinstance(transformed_node.right.right, ast.List)
    assert len(transformed_node.right.right.elts) == 1
    assert isinstance(transformed_node.right.right.elts[0], ast.Num)

# Generated at 2022-06-23 23:08:40.696908
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from autoclass import StarredUnpackingTransformer
    a = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    node_1 = ast.parse("[2] + list(range(10)) + [1]")
    node_2 = a.visit(node)
    node_3 = a.generic_visit(node_2)
    node_4 = a.visit(node_3)
    assert ast.dump(node_1) == ast.dump(node_4)

# Generated at 2022-06-23 23:08:45.196729
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expr = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
            ast.Num(n=1)
        ],
        ctx=ast.Load()
    )
    StarredUnpackingTransformer().visit(expr)
    assert ast.dump(expr, annotate_fields=False) == \
        "Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[], keywords=[])], keywords=[])"

# Generated at 2022-06-23 23:08:50.632803
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """\
[1, 2, *range(3)]
[*range(3), 2, 1]
[*range(3), *[2], *[], 1]
[1, *(), *range(3), *[2], *[], 1]
[1, 2, *range(3), *[2], *[]]
[1, 2, *range(3), *[2], *[], *range(4)]
"""

# Generated at 2022-06-23 23:09:01.957981
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]").body[0]
    StarredUnpackingTransformer().visit(node)

    assert node.elts[0].s == '2'
    assert isinstance(node.elts[1], ast.BinOp)
    assert isinstance(node.elts[1].left, ast.Call)
    assert isinstance(node.elts[1].left.func, ast.Name)
    assert node.elts[1].left.func.id == 'list'
    assert isinstance(node.elts[1].left.args[0], ast.Name)
    assert node.elts[1].left.args[0].id == 'range'
    assert node.elts[1].left.args[0].ctx == ast.Load()

# Generated at 2022-06-23 23:09:09.999732
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse(dedent(
        """
        print(1, 2, *range(10), 3)
        print(*range(10))
        print(1, *range(10))
        print(*range(10), 1)
        print(1, 2, *range(10), *range(3), 4)
        """
    ))

# Generated at 2022-06-23 23:09:11.372653
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:09:15.151058
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    StarredUnpackingTransformer().visit(ast.parse(code)) == ast.parse(expected)