

# Generated at 2022-06-23 22:59:25.583830
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from gitdrop.converters.utils.convert import convert_source
    from gitdrop.converters.utils.unparser import Unparser
    from gitdrop.converters.utils.unparser import FixedUnparser

    star_remover = StarredUnpackingTransformer()
    test_input_1 = FixedUnparser(
        convert_source(
            """
            [2, *range(10), 1]
            """
        )
    )
    expected_output_1 = '[2] + list(range(10)) + [1]'
    test_input_2 = FixedUnparser(
        convert_source(
            """
            print(*range(1), *range(3))
            """
        )
    )
    expected_output_2 = 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-23 22:59:26.101858
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-23 22:59:30.354166
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_ = StarredUnpackingTransformer()
    assert isinstance(class_, StarredUnpackingTransformer)
    assert class_.target == (3,4)
    assert class_._has_starred([ast.Name(id="a"),ast.Name(id="b")]) == False



# Generated at 2022-06-23 22:59:35.899780
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""
    import astor
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node).strip() == expected



# Generated at 2022-06-23 22:59:41.286592
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse(dedent('''
        [2, *range(10), 1]
        ''')).body[0].value

    StarredUnpackingTransformer().visit(node)
    assert_code(node, dedent('''
        ([2] + list(range(10)) + [1])
        '''))



# Generated at 2022-06-23 22:59:52.283116
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .helpers import assert_equal_ast

    tree = ast.parse('[1, *range(3), 4, *range(5), 6]')
    expected = ast.parse('[1] + list(range(3)) + [4] + list(range(5)) + [6]')
    assert_equal_ast(StarredUnpackingTransformer().visit(tree), expected)

    tree = ast.parse('[*range(100)]')
    expected = ast.parse('list(range(100))')
    assert_equal_ast(StarredUnpackingTransformer().visit(tree), expected)

    tree = ast.parse('[1, *range(4)]')
    expected = ast.parse('[1] + list(range(4))')

# Generated at 2022-06-23 22:59:53.274201
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-23 22:59:59.425497
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """\
        [2, *range(10), 1]
        """
    expected = """\
    [2] + list(range(10)) + [1]
    """
    tree = ast.parse(source, "unknown")
    transformed = StarredUnpackingTransformer().visit(tree)
    assert transformed is not None
    assert source != ast.dump(transformed)
    assert expected == ast.dump(transformed, annotate_fields=False)


# Generated at 2022-06-23 23:00:08.845208
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import typed_ast.ast3 as ast3
    assert str(ast3.parse("[2, *range(10), 1]").body[0].value) == "[2, *range(10), 1]"
    assert str(StarredUnpackingTransformer().visit(ast3.parse("[2, *range(10), 1]")).body[0].value) == "[2] + list(range(10)) + [1]"
    print("[*range(10), 1]")
    print(StarredUnpackingTransformer().visit(ast3.parse("[*range(10), 1]")).body[0].value)

# Generated at 2022-06-23 23:00:18.873144
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_list = [
        ast.Name(id='max', ctx=ast.Load()),
        ast.List(elts=[ast.Name(id='first', ctx=ast.Load()), ast.Starred(value=ast.Name(id='second', ctx=ast.Load())), ast.Name(id='third', ctx=ast.Load())]),
        ast.Name(id='a', ctx=ast.Load()),
        ast.Name(id='b', ctx=ast.Load()),
        ast.Name(id='c', ctx=ast.Load())]
    node = ast.Call(func=node_list[0], args=node_list[1:])

# Generated at 2022-06-23 23:00:24.261221
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # case_1
    input_expr = ast.parse('[2, *range(10), 1]')
    expected_expr = ast.parse('[2] + list(range(10)) + [1]')
    result_expr = StarredUnpackingTransformer()\
        .visit(input_expr)
    assert ast.dump(expected_expr) == ast.dump(result_expr)



# Generated at 2022-06-23 23:00:28.726253
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = "[2, *range(10), 1]"
    expected_ast = "[2] + list(range(10)) + [1]"
    t = StarredUnpackingTransformer()
    t.visit(x)
    assert t.get_transformed_tree() == expected_ast


# Generated at 2022-06-23 23:00:36.412458
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    root = ast.parse('[2, *range(10), 1]')
    assert isinstance(root.body[0], ast.Expr)
    assert isinstance(root.body[0].value, ast.List)
    root = StarredUnpackingTransformer().visit(root)

    assert isinstance(root.body[0].value, ast.BinOp)
    assert isinstance(root.body[0].value.right, ast.Call)
    assert isinstance(root.body[0].value.right.args[0], ast.Starred)
    assert root.body[0].value.op.__class__.__name__ == 'Add'


# Generated at 2022-06-23 23:00:37.890693
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t.target == (3, 4)

# Generated at 2022-06-23 23:00:42.437150
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = ast.parse('[2, 1, *range(3), *range(3, 4)]')
    expected = ast.parse(
        '[_j1 + ([2, 1] + list(range(3))) + ([3] + list(range(3, 4)))]')
    assert StarredUnpackingTransformer().visit(source).body[0].value.right.right.right.right.func.id == expected.body[0].value.right.right.right.right.func.id


# Generated at 2022-06-23 23:00:43.097303
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:43.977735
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer



# Generated at 2022-06-23 23:00:56.304415
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star_tree = ast.parse(textwrap.dedent("""
    [2, *range(10), 1]"""))
#    print(ast.dump(star_tree, annotate_fields=True, include_attributes=True))
    star_tree_transformed = StarredUnpackingTransformer().visit(star_tree)
#    print(ast.dump(star_tree_transformed, annotate_fields=True, include_attributes=True))

    print_tree = ast.parse(textwrap.dedent("""
    print(*range(1), *range(3))"""))
#    print(ast.dump(print_tree, annotate_fields=True, include_attributes=True))
    print_tree_transformed = StarredUnpackingTransformer().visit(print_tree)
#    print(ast.

# Generated at 2022-06-23 23:01:04.915793
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse
    from . import transform
    from .misc import FunctionDefWalker
    from .base import BaseNodeTransformer

    code = """
    print(*range(1), *range(3))

    """
    tree = ast.parse(code)
    # print(ast.dump(tree))

    tree = transform(tree, StarredUnpackingTransformer)  # type: ignore
    # print(ast.dump(tree))

    ref = """
    print(*(list(range(1)) + list(range(3))))

    """
    out = unparse(tree)
    print(out)
    assert ref == out

# Generated at 2022-06-23 23:01:13.926622
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
a = [1, 2, 3]
b = [1, 2, *[3, 4]]
c = [*[1, 2], 3, 4]
d = [1, *[2, 3], 4, *[5, 6], 7]
    '''
    expected = '''
a = [1, 2, 3]
b = list([1, 2]) + list([3, 4])
c = list([1, 2]) + [3, 4]
d = list([1]) + list([2, 3]) + [4] + list([5, 6]) + [7]
    '''
    transformed = StarredUnpackingTransformer().visit(parse_snippet(source))
    assert_source_equal(transformed, expected)


# Generated at 2022-06-23 23:01:18.762482
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test1 = ast.parse('[2, *range(10), 1]')
    p = StarredUnpackingTransformer()
    p.visit(test1)
    assert ast.dump(test1) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list'), args=[Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))])"


# Generated at 2022-06-23 23:01:25.845496
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    s = StarredUnpackingTransformer()
    test_tree = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='x'))])
    test_tree_result = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Name(id='x')], keywords=[]))])
    result = s.visit(test_tree)
    assert result == test_tree_result


# Generated at 2022-06-23 23:01:33.997651
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer.visit_List.__name__ == 'visit_List'
    expected_result = ast.List(
        elts=[
            ast.Num(n=2), 
            ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=10)],
                    keywords=[])]), 
            ast.Num(n=1)])
    tree = ast.parse('[2, *range(10), 1]')
    result = StarredUnpackingTransformer().visit(tree)
    assert result.body[0].value == expected_result


# Generated at 2022-06-23 23:01:44.961300
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .utils import to_source


# Generated at 2022-06-23 23:01:47.370303
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_fixtures import basic_tree
    from .test_fixtures import advanced_tree
    assert StarredUnpackingTransformer(basic_tree).visit(basic_tree) == advanced_tree

# Generated at 2022-06-23 23:01:49.922434
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import assert_transformed

    assert_transformed(
        StarredUnpackingTransformer,
        [3, *range(4), 5],
        [3] + list(range(4)) + [5]
    )



# Generated at 2022-06-23 23:01:52.192919
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import parse_function, compare_nodes
    compare_nodes(
        parse_function('[2, *range(10), 1]'),
        parse_function('[2] + list(range(10)) + [1]'))



# Generated at 2022-06-23 23:02:02.526074
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .testing_utils import make_locals, make_module
    locals = make_locals(
        'list',
        'range',
    )

    node = ast.parse('''\
    [2, *range(10), 1]
    ''').body[0]
    new_node = StarredUnpackingTransformer().visit(node)
    result = str(new_node)
    expected = '[2] + list(range(10)) + [1]'
    assert result == expected, f"generated: {result}\nexpected: {expected}"

    # test that we can eval after transpiling
    transpiled = make_module([new_node], locals=locals)
    assert eval(compile(transpiled, '', 'exec'), locals) == [2] + list(range(10)) + [1]

# Generated at 2022-06-23 23:02:11.443440
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:20.450227
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('f(*[1, 2, *[3, 4], 5])')
    visitor = StarredUnpackingTransformer()
    result = visitor.visit(node)
    assert isinstance(result, ast.Call)
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.BinOp)
    assert isinstance(result.args[0].value.left, ast.List)
    assert isinstance(result.args[0].value.left.elts[0], ast.Num)
    assert result.args[0].value.left.elts[0].n == 1
    assert isinstance(result.args[0].value.left.elts[1], ast.Num)
    assert result.args[0].value.left.el

# Generated at 2022-06-23 23:02:21.364205
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:02:32.860023
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformed = StarredUnpackingTransformer().visit(
        ast.parse('[2, *range(10), 1]')
    ).body[0].value

    assert isinstance(transformed, ast.BinOp)
    assert isinstance(transformed.left, ast.List)
    assert isinstance(transformed.right, ast.BinOp)

    assert transformed.left.elts == [ast.Num(n=2)]
    assert transformed.right.op == ast.Add
    assert isinstance(transformed.right.left, ast.Call)
    assert isinstance(transformed.right.right, ast.List)

    assert transformed.right.left.func.id == 'list'
    assert isinstance(transformed.right.left.args[0], ast.Call)

# Generated at 2022-06-23 23:02:40.380554
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import assert_code_equal

    code = """
        print(*range(1), *range(3))
    """

    expected = """
        print(*(list(range(1)) + list(range(3))))
    """

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    code1 = compile(tree, '', 'exec')
    code2 = compile(expected, '', 'exec')
    assert_code_equal('code', code1, code2)



# Generated at 2022-06-23 23:02:41.934306
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x is not None


# Generated at 2022-06-23 23:02:44.630207
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .compile import compile_source, apply_transformer
    from .base import BaseNodeTransformer


# Generated at 2022-06-23 23:02:46.401013
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .transformer_util import run_transformer_on_single_file


# Generated at 2022-06-23 23:02:50.135272
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    result = StarredUnpackingTransformer.run('''
[2, *range(10), 1]
''')

    assert result == '''
[2] + list(range(10)) + [1]
'''


# Generated at 2022-06-23 23:02:50.767009
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:51.472040
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert x

# Generated at 2022-06-23 23:03:03.484153
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert AST(source="[1, 2, 3]").to(StarredUnpackingTransformer) == \
        AST(source="[1, 2, 3]")
    assert AST(source="[1, 2, *range(3), 4]").to(StarredUnpackingTransformer) == \
        AST(source="[1, 2] + list(range(3)) + [4]")
    assert AST(source="[1, *range(3)]").to(StarredUnpackingTransformer) == \
        AST(source="[1] + list(range(3))")
    assert AST(source="[*range(3), 1]").to(StarredUnpackingTransformer) == \
        AST(source="list(range(3)) + [1]")

# Generated at 2022-06-23 23:03:08.756323
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # Define a dictionary of tests
    tests = {
        '[2, *range(10), 1]': '__list__(2, *__list__(__call__(range, __tuple__(10))), 1)',
        '[2, *range(10), 1, *range(5)]': '__list__(2, *__list__(__call__(range, __tuple__(10))), 1, *__list__(__call__(range, __tuple__(5))))',
        '[2, 1]': '__list__(2, 1)',
        '[2, 1, *range(5)]': '__list__(2, 1, *__list__(__call__(range, __tuple__(5))))'
    }

    # Run the tests

# Generated at 2022-06-23 23:03:17.484027
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test simple call
    tree = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")
    transpiled = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(expected) == ast.dump(transpiled)

    # Test list
    tree = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")
    transpiled = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(expected) == ast.dump(transpiled)

    # Test function arguments
    tree = ast.parse("def x(*args, **kwargs): pass")
    transpiled

# Generated at 2022-06-23 23:03:19.657192
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""

# Generated at 2022-06-23 23:03:27.193534
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from py3roast.transformers._helpers import ASTHelper
    imports = ("from typing import List",)
    name = "StarredUnpackingTransformer"

    code = """foo(a, *b, c, *d, e)"""
    cases = ("foo([a] + list(b) + [c] + list(d) + [e])",)

    helper = ASTHelper(code, imports, name)
    helper.run_transformer(StarredUnpackingTransformer)
    helper.assert_results(cases)


# Generated at 2022-06-23 23:03:31.336263
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    expected_tree = ast.parse('[2] + list(range(10)) + [1]')
    StarredUnpackingTransformer().visit(tree)
    assert tree == expected_tree


# Generated at 2022-06-23 23:03:35.573463
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ast1 = ast.parse("print(*range(2), 3, *range(4), *range(6))")
    print("Original:", ast.dump(ast1))

    star_unpacker = StarredUnpackingTransformer()
    ast2 = star_unpacker.visit(ast1)
    print("Transformed:", ast.dump(ast2))

    assert ast2 != ast1



# Generated at 2022-06-23 23:03:39.998789
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse
    from .util import Unparser
    import sys
    import os

    test_code = """
    l = [1, *range(10), 2]
    """

    old_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')

    tree = parse(test_code)
    tree = StarredUnpackingTransformer().visit(tree)

    sys.stdout.close()
    sys.stdout = old_stdout

    Unparser(tree)


# Generated at 2022-06-23 23:03:46.985625
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from pprint import pformat

    from typed_ast import ast3 as ast

    node = ast.parse("""
print(*range(1), *range(3))
""").body[0]
    expected = ast.parse("""
print(*(list(range(1)) + list(range(3))))
""").body[0]
    StarredUnpackingTransformer().visit(node)
   # print(pformat(node))
    assert node == expected, pformat(node)


# Generated at 2022-06-23 23:03:50.295155
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = """
        [2, *range(10), 1]
    """
    expected = """
        [2] + list(range(10)) + [1]
    """
    StarredUnpackingTransformer().assert_matches(input, expected)


# Generated at 2022-06-23 23:04:00.331160
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    call_ast = ast.parse('print(*(list(range(1)) + list(range(3))))')
    call = call_ast.body[0].value
    assert isinstance(call, ast.Call)
    assert isinstance(call.args[0], ast.Starred)
    assert isinstance(call.args[0].value, ast.BinOp)
    call_transformed = sut.visit(call_ast)
    call = call_transformed.body[0].value
    assert sut._tree_changed
    assert isinstance(call, ast.Call)
    assert isinstance(call.args[0], ast.Starred)
    assert isinstance(call.args[0].value, ast.List)

# Generated at 2022-06-23 23:04:00.792113
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-23 23:04:08.213498
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import do_test_node
    from .base import TestParams
    from .base import TestTree
    from .. import py2typed

# Generated at 2022-06-23 23:04:12.359465
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ast_ = parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(ast_)

    assert ast_ == parse("[2] + list(range(10)) + [1]")



# Generated at 2022-06-23 23:04:21.567625
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert type(ast.parse('[2, 3, 4, 5]').body[0].value) == ast.List
    assert ast.dump(ast.parse('[2, 3, 4, 5]')) == 'Expr(value=List(elts=[Num(n=2), Num(n=3), Num(n=4), Num(n=5)], ctx=Load()))'

    transformer = StarredUnpackingTransformer()
    list_ = ast.parse('[2, 3, 4, 5]')
    t = transformer.visit(ast.parse('[2, 3, 4, 5]'))
    assert type(t) == ast.List

# Generated at 2022-06-23 23:04:27.766883
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:29.349998
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert not (StarredUnpackingTransformer)()


# Generated at 2022-06-23 23:04:38.954169
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as ast
    ast_ = StarredUnpackingTransformer().visit(ast.parse("""\
[2, *range(10), 1]
""").body[0])
    assert ast_ == ast.parse("""\
([2] + list(range(10)) + [1])
""").body[0]

    ast_ = StarredUnpackingTransformer().visit(ast.parse("""\
[2, 3, 4, 5]
""").body[0])
    assert ast_ == ast.parse("""\
([2, 3, 4, 5])
""").body[0]

    ast_ = StarredUnpackingTransformer().visit(ast.parse("""\
[]
""").body[0])
    assert ast_ == ast.parse("""\
([])
""").body

# Generated at 2022-06-23 23:04:49.888456
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test visit_Call method of class StarredUnpackingTransformer
    """
    from textwrap import dedent
    from .buffered_generic_visit import BufferedGeneric_Visit
    from .unpacking_transformer import UnpackingTransformer
    from .unary_starred_transformer import UnaryStarredTransformer
    from .parentheses_transformer import ParenthesesTransformer
    from .print_function_transformer import PrintFunctionTransformer
    from .print_function_transformer import PrintFunctionCompatibilityTransformer
    from .check_str_transformer import CheckStrTransformer
    from .check_str_transformer import CheckStrCompatibilityTransformer
    from .compat_transformer import CompatTransformer

# Generated at 2022-06-23 23:04:51.626200
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(ast.parse('print(*range(1), *range(3))')) is not None

# Generated at 2022-06-23 23:04:59.403022
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .minifier import Minifier

    minifier = Minifier()
    minifier.add_transformer(StarredUnpackingTransformer)

    source = "[2, *range(10), 'string']"
    expected = "[2] + list(range(10)) + ['string']"
    actual = minifier.minify(source)
    assert expected == actual

    expected = "[2] + list(range(10)) + ['x']"
    actual = minifier.minify(source, {"string": "x"})
    assert expected == actual


# Generated at 2022-06-23 23:05:06.764013
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast

    list_obj = ast.List(elts=[ast.Num(n=2),ast.Starred(value=ast.Call(func=ast.Name(id='range'),args=[ast.Num(n=10)], keywords=[])),ast.Num(n=1)])
    call_obj = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='range'),args=[ast.Num(n=1)], keywords=[])),ast.Starred(value=ast.Call(func=ast.Name(id='range'),args=[ast.Num(n=3)], keywords=[]))],keywords=[])

    obj = StarredUnpackingTransformer(list_obj)


# Generated at 2022-06-23 23:05:13.992272
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import sys
    import io
    import unittest
    from typed_ast import ast3 as ast

    class TestCase(unittest.TestCase):
        def test(self):
            code = """
print(*range(1), *range(3))
            """

            module = ast.parse(code)
            compiled = StarredUnpackingTransformer().visit(module)
            compiled = compile(module, '', 'exec')
            output = io.StringIO()
            sys.stdout = output
            exec(compiled)
            sys.stdout = sys.__stdout__
            self.assertEqual(output.getvalue(), '0\n1\n2\n')

    unittest.main()

# Generated at 2022-06-23 23:05:19.090828
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_code = '''
        a(*range(10), *range(10))
    '''
    expected_code = '''
        a(*(list(range(10)) + list(range(10))))
    '''
    result = StarredUnpackingTransformer().visit(ast.parse(input_code))
    assert astor.to_source(result) == expected_code



# Generated at 2022-06-23 23:05:23.222998
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    input = ast.parse("print(*range(1), 1, *range(3))")
    expected = ast.parse("print(*(list(range(1)) + [1] + list(range(3))))")
    tr = StarredUnpackingTransformer()
    tr.visit(input)
    assert astor.to_source(expected).strip() == astor.to_source(input).strip()


# Generated at 2022-06-23 23:05:29.840483
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_transformer import make_visitor

    code = "[2, *range(5), 1]"
    expected_code = "[2] + list(range(5)) + [1]"

    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    visitor = make_visitor(StarredUnpackingTransformer)
    assert visitor.visit(tree) == expected_tree


# Generated at 2022-06-23 23:05:31.164711
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:05:32.080365
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # TODO
    pass


# Generated at 2022-06-23 23:05:38.395787
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import RoundTripChecker, run_test_eq

    class Checker(RoundTripChecker):
        transformer = StarredUnpackingTransformer

    run_test_eq(Checker, '''
        print(1, 2, *range(10), 3, 4)
    ''')



# Generated at 2022-06-23 23:05:42.913526
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('f(*[1, 2], *[3, 4], *[2])')
    StarredUnpackingTransformer().generic_visit(tree)
    assert astor.to_source(tree) == 'f(*(([1, 2] + [3, 4]) + [2]))'


# Generated at 2022-06-23 23:05:50.014995
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    def f():
        x = [3, *range(2), 5, *range(4)]
        print(x)
        x = [3, *range(2), 5, *range(4)]
        print(*range(2), 5, *range(4))
    print("Testing StarredUnpackingTransformer")
    print("Original AST tree:")
    print(ast.dump(ast.parse(f.__code__), include_attributes=True))
    print("Transformed AST:")
    tree = StarredUnpackingTransformer().visit(ast.parse(f.__code__))
    print(ast.dump(tree, include_attributes=True))
    print("Code:")
    print(compile(tree, '<stdin>', mode='exec'))


# Generated at 2022-06-23 23:05:55.930814
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast as pyast
    import typed_astunparse
    from ast_tools.passes import StarredUnpackingTransformer
    trans = StarredUnpackingTransformer()
    tree = ast.parse('print(*range(1), *range(3))')
    trans.visit(tree)
    expected = pyast.parse('list(*range(1)) + list(*range(3))')  # type: ignore
    print(typed_astunparse.unparse(tree))
    print(typed_astunparse.unparse(expected))
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-23 23:06:07.105969
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    consumer_func = ast.parse('print(1)')
    stmt = consumer_func.body[0]
    assert isinstance(stmt, ast.Expr)
    consumer_call = stmt.value
    assert isinstance(consumer_call, ast.Call)
    args = consumer_call.args

    arg = ast.parse('*range(10)', mode='single')
    arg = arg.body
    assert len(arg) == 1
    arg = arg[0]
    assert isinstance(arg, ast.Expr)
    arg = arg.value
    assert isinstance(arg, ast.Starred)
    arg = arg.value
    assert isinstance(arg, ast.Call)
    arg = arg.func
    arg = arg.id


# Generated at 2022-06-23 23:06:13.016605
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = ast.parse(
        "args = [1, '1', *range(3), True, None, 1.0]",
        mode='eval').body
    expected = ast.parse(
        "args = [1, '1'] + list(range(3)) + [True, None, 1.0]",
        mode='eval').body

    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(input)

    assert ast.dump(transformed) == ast.dump(expected)


# Generated at 2022-06-23 23:06:16.402479
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    st = "a = [1, 2, 3, *range(5)]"
    expected = \
"""a = [1, 2, 3] + list(range(5))"""
    node = ast.parse(st)
    StarredUnpackingTransformer(node).visit(node)
    result = fix_code(node)
    assert result == expected


# Generated at 2022-06-23 23:06:17.792871
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-23 23:06:24.219127
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert compile(r'''
a = [1, *[1, 2, 3], 4]
''', '', 'exec', flags=compile.PyCF_ONLY_AST) == compile(r'''
a = [1] + list([1, 2, 3]) + [4]
''', '', 'exec', flags=compile.PyCF_ONLY_AST)


# Generated at 2022-06-23 23:06:35.006658
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0].value
    def check(node: ast.List):
        assert node.elts[0].n == 2
        assert node.elts[1].elts[0].func.id == 'list'
        assert node.elts[1].elts[0].args[0].func.id == 'range'
        assert node.elts[1].elts[0].args[0].args[0].n == 10
        assert node.elts[1].elts[0].args[0].args[1].n == 3
        assert node.elts[1].elts[0].args[0].keywords == []
        assert node.elts[1].elts[1].elts[0].n == 1
        assert node.el

# Generated at 2022-06-23 23:06:40.006991
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    tree = ast.parse('print(*range(3), *range(4))')
    t.visit(tree)
    assert ast_to_source(tree) == 'print(*(list(range(3)) + list(range(4))))'


# Generated at 2022-06-23 23:06:48.539096
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import to_source
    from .ast_unparser import ASTUnparser
    from .common import dump_tokens


# Generated at 2022-06-23 23:06:50.315167
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer(): 
    node_transformer = StarredUnpackingTransformer(None)
    pass


# Generated at 2022-06-23 23:06:58.092326
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test that method visit_Call of class StarredUnpackingTransformer works correctly"""
    class NodeVisitor(ast.NodeVisitor):
        def visit_Call(self, node):
            return node

    expected_ast = ast.parse('print(*(list(range(1)) + list(range(3))), end="")')
    actual_ast = StarredUnpackingTransformer().visit(
        ast.parse('print(*range(1), *range(3), end="")')
    )

    assert ast.dump(expected_ast.body[0].value) == ast.dump(
        NodeVisitor().visit(actual_ast).body[0].value)


# Generated at 2022-06-23 23:07:03.009625
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")

    res = StarredUnpackingTransformer().visit(input)
    assert ast.parse(compile(res, filename="<ast>", mode="exec")) == expected



# Generated at 2022-06-23 23:07:14.216174
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[1, 2, 'a', *range(10)]").body[0].value
    assert isinstance(node, ast.List)
    assert repr(StarredUnpackingTransformer().visit(node)) == repr(ast.BinOp(
        left=ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Str(s='a')]),
        right=ast.Call(func=ast.Name(id='list'), args=[ast.Call(
            func=ast.Name(id='range'),
            args=[ast.Num(n=10)],
            keywords=[])], keywords=[]),
        op=ast.Add()))
    print('ok')


# Generated at 2022-06-23 23:07:17.857094
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test of method visit_List of class StarredUnpackingTransformer
    """
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(
        tree)  # type: ignore  # pylint: disable=no-value-for-parameter
    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert expected



# Generated at 2022-06-23 23:07:25.677993
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    n = ast.parse('[2, *range(10), 1]').body[0]
    assert isinstance(n, ast.Expr)
    assert isinstance(n.value, ast.List)
    assert n.value.elts == [ast.Num(2),
                            ast.Starred(ast.Call(ast.Name(id='range',
                                                          ctx=ast.Load()),
                                                 [ast.Num(10)], [])),
                            ast.Num(1)]
    orig_n = deepcopy(n)

    StarredUnpackingTransformer().visit(n)
    assert isinstance(n, ast.Expr)
    assert isinstance(n.value, ast.BinOp)

# Generated at 2022-06-23 23:07:29.256434
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from . import Py2C_test_support
    p = Py2C_test_support.program_from_source("""
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """)
    transformed = StarredUnpackingTransformer().visit(p)
    assert str(transformed) == """
    ([2] + list(range(10)) + [1])
    print(*(list(range(1)) + list(range(3))))
    """

# Generated at 2022-06-23 23:07:37.671735
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse("[2, *range(10), 1]")
    tree1 = ast.parse("[2, *range(10), 1]")
    transformer.visit(tree1)
    assert transformer._tree_changed == True
    code_expected = "__res = list([2]) + list(range(10)) + list([1])"
    code_expected1 = "list([2]) + list(range(10)) + list([1])"
    assert get_compiled_code(tree, code_expected) == get_compiled_code(tree1, code_expected1)


# Generated at 2022-06-23 23:07:44.112615
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_astunparse import unparse

    transformer = StarredUnpackingTransformer()
    node = ast.parse('print(*range(3))')
    node = transformer.visit(node)
    assert unparse(node) == "print(*(list(range(3))))"
    
    assert not transformer.has_changed()

    transformer = StarredUnpackingTransformer()
    node = ast.parse('str(1, *[2, 3], 4)')
    node = transformer.visit(node)
    assert unparse(node) == "str(*(list([1]) + list([2, 3]) + list([4])))"
    
    assert transformer.has_changed()


# Generated at 2022-06-23 23:07:54.005977
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .translators import Python3to2Translator
    source = """
        a = [1, *[2]]
        b = list([1, *[2, 3]])
        c = dict([1, *[2, 3], 6, 7])
        d = dict([(1, 2), *[(2, 3), (3, 4)]])
        e = *[a, b]
    """

# Generated at 2022-06-23 23:07:55.698517
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer_instance = StarredUnpackingTransformer()
    assert transformer_instance



# Generated at 2022-06-23 23:08:03.918060
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import get_node, get_nodes, get_compiled_node

    from .test_helpers import assert_equal_ast

    code = "numbers = [2, 3, 5, 7, 11, 13]; print(*numbers)"
    node = get_node(code)
    compiled_node = get_compiled_node(code)
    StarredUnpackingTransformer().visit(node)
    assert_equal_ast(node, compiled_node)

# Generated at 2022-06-23 23:08:09.563570
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    code_in = "[2, *range(10), 1]"
    tree_in = astor.parse_file(astor.code_to_ast(code_in))
    tree_out = StarredUnpackingTransformer().visit(tree_in)
    code_out = astor.to_source(tree_out)

    assert code_out == "[2] + list(range(10)) + [1]"


# Generated at 2022-06-23 23:08:16.005555
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """
    print(2, *range(10), 1)
    [2, *range(10), 1]
    """
    tree = compile(code, '<module>', 'exec', flags=ast.PyCF_ONLY_AST)
    transformed_tree = StarredUnpackingTransformer.run_on_tree(
        tree, StarredUnpackingTransformer.target)

    code_after_transformation = compile(
        transformed_tree, '<module>', 'exec',
        flags=ast.PyCF_ONLY_AST
    )
    # Compile again to compare with original
    code_after_transformation = compile(
        code_after_transformation, '<module>', 'exec', flags=ast.PyCF_ONLY_AST
    )

    # remove lineno and col_offset to allow comparison


# Generated at 2022-06-23 23:08:19.989247
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import sys

    # 1. Check that the __init__ does not have any issues
    StarredUnpackingTransformer(ast)
    StarredUnpackingTransformer(sys)

# Generated at 2022-06-23 23:08:27.915906
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # class StarredUnpackingTransformer
    class A(StarredUnpackingTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # Instantiation
    x0 = A()

    # call to visit_Call
    x1 = ast.Call(
        func=ast.Name(id='print'),
        args=[],
        keywords=[]
    )
    x2 = x0.visit_Call(x1)
    assert type(x2) == ast.Call


# Generated at 2022-06-23 23:08:31.259401
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))')
    trans = StarredUnpackingTransformer()
    trans.visit(node)
    target = ast.parse('print(*(list(range(1)) + list(range(3))))')
    assert ast.dump(node) == ast.dump(target)

# Generated at 2022-06-23 23:08:34.611517
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of StarredUnpackingTransformer"""
    sut = StarredUnpackingTransformer()
    assert isinstance(sut, StarredUnpackingTransformer)
    assert sut.target == (3, 4)


# Generated at 2022-06-23 23:08:39.328752
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = ast.parse('[2, *range(10), 1]')
    expected = ast.parse('[2] + list(range(10)) + [1]')
    actual = StarredUnpackingTransformer().visit(src)

    assert ast.dump(expected, annotate_fields=False, include_attributes=True) == \
           ast.dump(actual, annotate_fields=False, include_attributes=True)



# Generated at 2022-06-23 23:08:50.079883
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    args = [ast.Num(n=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Num(n=1)]
    node = ast.List(elts=args)
    node_transformed = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:08:59.701149
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    pairs = [
        ([ast.Call(func=ast.Name(id='a'), args=[], keywords=[])],
         ast.Call(func=ast.Name(id='a'), args=[], keywords=[])),
        ([ast.Call(func=ast.Name(id='a'), args=[], keywords=[])],
         ast.Call(func=ast.Name(id='a'), args=[], keywords=[])),
    ]

    for pair in pairs:
        x, y = pair
        t = StarredUnpackingTransformer()
        assert ast.dump(t.visit(x), annotate_fields=False) == ast.dump(y, annotate_fields=False)


# Generated at 2022-06-23 23:09:05.640263
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from pprint import pprint
    import json
    import os.path
    from . import ast_compare
    file_dir = os.path.dirname(__file__)
    test_file = os.path.join(file_dir, 'test_starred_unpacking_transformer.visit_Call.py')
    test_file_ast = ast.parse(open(test_file).read())
    expected_file = os.path.join(file_dir, 'test_starred_unpacking_transformer.visit_Call.expected.py')
    expected_file_ast = ast.parse(open(expected_file).read())
    expected_ast = json.loads(ast.dump(expected_file_ast))
    test_ast = json.loads(ast.dump(test_file_ast))
    Starred

# Generated at 2022-06-23 23:09:09.855696
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """[summary]
    Unit test for constructor of class StarredUnpackingTransformer
    
    :raises AssertionError: [description]
    """
    st = StarredUnpackingTransformer()

    assert st is not None

# Generated at 2022-06-23 23:09:10.876689
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-23 23:09:17.908047
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    result = StarredUnpackingTransformer.run_visitor_on_snippet(
        snippet='''
        print(*range(1), *range(3))
        print(*[1, 2, *range(3), 4])
        ''',
        visitor=StarredUnpackingTransformer)

    assert result == """
        print(*(list(range(1)) + list(range(3))))
        print(*(list([1, 2]) + list(range(3)) + list([4])))
        """.lstrip()