

# Generated at 2022-06-23 22:59:13.751189
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree_builder = StarredUnpackingTransformer()
    tree = tree_builder.visit(ast.parse("[2, *range(10), 1]"))
    assert astor.to_source(tree) == "([2] + list(range(10)) + [1])"



# Generated at 2022-06-23 22:59:20.321479
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_transformer import to_source
    from .test_transformer import assert_equal

    # [2, *range(10), 1] -> [2] + list(range(10)) + [1]
    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)

    assert_equal(to_source(tree), expected)



# Generated at 2022-06-23 22:59:30.441975
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiled.statement_unpacking import StarredUnpackingTransformer
    from typed_ast import ast3 as ast
    from .utils import dump

    node = ast.parse('''
    print(*range(1), *range(3))
    ''')
    node = StarredUnpackingTransformer().visit(node)
    result = dump(node)

# Generated at 2022-06-23 22:59:40.036195
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import os
    os.environ['STARRED_UNPACKING_TRANSFORMER_DEBUG'] = '1'
    target = ast.parse(r'''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    ''')
    result = StarredUnpackingTransformer().visit(target)

    expected = ast.parse(r'''
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    ''')

    assert ast.dump(result, anno=False) == ast.dump(expected, anno=False)
    
test_StarredUnpackingTransformer()

# Generated at 2022-06-23 22:59:51.096799
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typing import List

    from typed_ast import ast3 as ast

    from .loader import load_module

    code = """
    def func(a,b,*c,d):
        pass

    func(1,2,3,4,5,6,d=1)
    """
    module = load_module(code=code)
    module = StarredUnpackingTransformer().visit(module)
    assert isinstance(module.body[1], ast.Expr)
    assert isinstance(module.body[1].value, ast.Call)
    assert isinstance(module.body[1].value.args, list)
    assert len(module.body[1].value.args) == 1
    assert isinstance(module.body[1].value.args[0], ast.Starred)

# Generated at 2022-06-23 22:59:52.092976
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  StarredUnpackingTransformer()

# Generated at 2022-06-23 22:59:58.310667
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_code = """
[1, *range(3), *range(7), 8]
[2, 3, 4, 5, 6]
    """

    expected_code = """
list([1]) + list(range(3)) + list(range(7)) + [8]
[2, 3, 4, 5, 6]
    """

    assert_source_equal(StarredUnpackingTransformer().visit(get_ast(test_code)), expected_code)



# Generated at 2022-06-23 22:59:59.665597
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    st = StarredUnpackingTransformer()
    assert st is not None

# Generated at 2022-06-23 23:00:08.985534
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import typed_astunparse, ast
    node = ast.parse("print(*range(1), *range(3))")
    node = node.body[0].value
    transformer = StarredUnpackingTransformer()
    transformer.visit(node)

# Generated at 2022-06-23 23:00:18.874045
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test star unpack method."""
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformer):
        def _visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    tree = ast.parse("print(*range(1), *range(3))")

    tree2 = StarredUnpackingTransformer().visit(tree)
    t = Test().visit(tree2)

    assert isinstance(t, ast.Call)  # type: ignore
    assert len(t.args) == 1
    assert isinstance(t.args[0], ast.Starred)

    tree2 = StarredUnpackingTransformer().visit(tree)
    t = Test().visit(tree2)


# Generated at 2022-06-23 23:00:23.882791
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .fixtures.functions import function_with_starred_args
    from .fixtures.functions import function_with_starred_args_transformed
    result = StarredUnpackingTransformer().visit(function_with_starred_args)
    assert ast.dump(result) == ast.dump(function_with_starred_args_transformed)



# Generated at 2022-06-23 23:00:33.247284
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    @compile_to_ast3
    def sample_list():
        return [2, *range(10), 1]

    @compile_to_ast3
    def sample_list_with_call():
        return [a(*b) for a, b in [(lambda a, b: a+b, [1, 2]), (lambda a, b: a*b, [*range(3)])]]

    @compile_to_ast3
    def sample_list_with_starred():
        return [a, *b]

    @compile_to_ast3
    def sample_list_with_starred_double():
        return [a, *b, *c]


# Generated at 2022-06-23 23:00:41.462149
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_args = [
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Num(n=1)],
            keywords=[]),
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Num(n=2)],
            keywords=[])]
    node = ast.Call(
        func=ast.Name(id='print'),
        args=node_args,
        keywords=[])

    node2 = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:00:42.287092
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:46.809492
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(i, *range(1), *range(10))", mode='eval')
    assert ("print(*(list(range(1)) + list(range(10))))" ==
            StarredUnpackingTransformer().visit(node))


# Generated at 2022-06-23 23:00:58.328636
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astpretty import pprint
    from .test_base import BaseTestTransformer
    from .test_base import get_test_case_ast
    from .test_base import my_namedtuple

    Test = my_namedtuple('Test', ['code', 'expected', 'transformer'])
    tests = [
        Test(
            code='t = (1, *range(3), 1)',
            expected='t = [1] + list(range(3)) + [1]',
            transformer=StarredUnpackingTransformer('(file)', 'f'))
    ]

    for test in tests:
        expected_ast = get_test_case_ast(test.expected)
        test_transformer = test.transformer
        test_transformer.visit(get_test_case_ast(test.code))
       

# Generated at 2022-06-23 23:01:08.620949
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_inputs = [
        "b = [1, *a, 2]",
        "b = [1, *a, 2, *range(10)]",
        "b = [*a, 2, *range(10)]",
        "b = [*range(10), 2, *a]",
        "b = [*a, *range(10), 2]",
        "b = [*a, *range(10), 2, *l]",
    ]

# Generated at 2022-06-23 23:01:19.928313
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # _has_starred
    assert StarredUnpackingTransformer()._has_starred([ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[])]) \
        == True
    assert StarredUnpackingTransformer()._has_starred([ast.Num(n=10)]) == False

    # _split_by_starred

# Generated at 2022-06-23 23:01:23.323791
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]')
    result = StarredUnpackingTransformer().visit(node.body[0].value)
    assert isinstance(result, ast.BinOp)



# Generated at 2022-06-23 23:01:29.130040
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .compile_tree import compile_tree

    before = "[2, *range(10), 1]"
    after = """[2] + list(range(10)) + [1]"""
    ast_before = compile_tree(before, mode='eval')
    ast_after = compile_tree(after, mode='eval')

    transformer = StarredUnpackingTransformer()
    ast_after_transformed = transformer.visit(ast_before)
    assert ast_after == ast_after_transformed

# Generated at 2022-06-23 23:01:39.800032
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from ast_tools.transformers import StarredUnpackingTransformer
    star_test = StarredUnpackingTransformer()
    list_test = ast3.List(
        elts=[
            ast3.Call(
                func=ast3.Attribute(
                    value=ast3.Name(id='x'), attr='a', ctx=ast3.Load()),
                args=[ast3.Num(n=1)],
                keywords=[ast3.keyword(
                    arg='y', value=ast3.Num(n=2))]),
            ast3.Name(id='z')])
    print(ast3.dump(list_test))

# Generated at 2022-06-23 23:01:48.149159
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse("[2, *range(10), 1]").body
    StarredUnpackingTransformer().visit(node)
    assert node == [ast.Expr(ast.BinOp(ast.List(elts=[ast.Num(n=2)]),
                                       ast.Add(),
                                       ast.Call(func=ast.Name(id='list'),
                                                args=[ast.Call(func=ast.Name(id='range'),
                                                               args=[ast.Num(n=10)],
                                                               keywords=[])],
                                                keywords=[])),
                            ast.Add(),
                            ast.List(elts=[ast.Num(n=1)]))]
    node = ast.parse("print(1, *range(3), 4)").body
    StarredUnpackingTransformer

# Generated at 2022-06-23 23:01:49.791384
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer.run_visit_test(code)



# Generated at 2022-06-23 23:01:58.390685
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = """
    a = [2, *range(10), 1]
    print([*range(1), *range(3)])
    """
    expected = """
    a = list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """
    node = ast.parse(x)
    StarredUnpackingTransformer().visit(node)
    codeobj = compile(node, '<test>', 'exec')
    ns = {}
    exec(codeobj, ns)
    assert ns['a'] == [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]
    assert ns['_'] == '[2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1]'
   

# Generated at 2022-06-23 23:02:03.297140
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    module = ast.parse(
        'print(2, *range(10), 1, sep=1)'
    )
    StarredUnpackingTransformer().visit(module)
    expected = ast.parse(
        'print(*(range(1) + list(range(3))))'
    )
    assert ast.dump(module) == ast.dump(expected)




# Generated at 2022-06-23 23:02:09.460553
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import ast_from_str, unparse
    from .main import transform
    input_str = "[1, 2, *range(10), 3]"
    expected_str = "[1, 2] + list(range(10)) + [3]"
    tree = ast_from_str(input_str)
    new_tree = transform(tree, StarredUnpackingTransformer)
    new_str = unparse(new_tree)
    assert expected_str == new_str



# Generated at 2022-06-23 23:02:11.592256
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer
    return transformer

transformer = test_StarredUnpackingTransformer()



# Generated at 2022-06-23 23:02:20.598213
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node1 = ast.List(elts=[ast.Num(n=2),
                  ast.Starred(value=ast.Call(func=ast.Name(id="range"), args=[ast.Num(n=10)], keywords=[])),
                  ast.Num(n=1)])
    node2 = ast.Call(func=ast.Name(id="print"), args=[ast.Starred(value=ast.Call(func=ast.Name(id="range"), args=[ast.Num(n=1)], keywords=[])), ast.Starred(value=ast.Call(func=ast.Name(id="range"), args=[ast.Num(n=3)], keywords=[]))], keywords=[])

    obj = StarredUnpackingTransformer()
    obj.visit(node1)
    obj.visit(node2)


#

# Generated at 2022-06-23 23:02:32.014574
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # _________________________________________________________________________
    # Setup
    # _________________________________________________________________________
    module_node = ast.parse("""
print(*range(1), *range(3))
""")
    node = module_node.body[0]

    # _________________________________________________________________________
    # Exercise
    # _________________________________________________________________________
    StarredUnpackingTransformer().visit(module_node)

    # _________________________________________________________________________
    # Verify
    # _________________________________________________________________________
    assert isinstance(node.args[0], ast.Starred)
    assert isinstance(node.args[0].value, ast.Call)
    assert isinstance(node.args[0].value.func, ast.Name)
    assert node.args[0].value.func.id == 'list'

# Generated at 2022-06-23 23:02:39.230964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'foo(1, 2, *range(100), 5, *range(100))'
    expected_source = 'foo(*(list(range(100)) + list(range(100)) + [1, 2, 5]))'
    transformed = StarredUnpackingTransformer().visit(ast.parse(source))
    assert compile(transformed, '<test>', 'exec').co_code.hex() == \
           compile(expected_source, '<test>', 'exec').co_code.hex()


# Generated at 2022-06-23 23:02:50.687906
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from mypy_extensions import Check

    node = ast.parse(
            """print(*range(1), *range(3))""",
            mode='eval')
    t = StarredUnpackingTransformer()
    transformed = t.visit(node)
    transformed = ast.fix_missing_locations(transformed)


# Generated at 2022-06-23 23:02:54.610571
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from common import Source, assert_equal_code

    src = Source("[2, *range(10), 1]")
    src = StarredUnpackingTransformer().visit(src.node)
    assert_equal_code(src, "[2] + list(range(10)) + [1]")



# Generated at 2022-06-23 23:03:06.906173
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tests = [
        """
a = [1, 2]
        """,
        """
a = [1, 2, 3, 4, 5, 6]
        """,
        """
a = [1, *range(10), 2, 3, 4]
        """,
        """
a = [1, *range(10), 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        """,
        """
a = [1, *range(10), 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        """
    ]

# Generated at 2022-06-23 23:03:07.940109
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert not StarredUnpackingTransformer()

# Generated at 2022-06-23 23:03:13.820993
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        """
print(*range(1), *range(3))
        """
    )
    expected = ast.parse(
        """
print(*(list(range(1)) + list(range(3))))
        """
    )
    result = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(expected, annotate_fields=False) == ast.dump(result, annotate_fields=False)


# Generated at 2022-06-23 23:03:25.209827
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer"""
    import unittest

    class Test(unittest.TestCase):
        def assertAstEqual(self, ast1: ast.AST, ast2: ast.AST) -> None:
            """Recursively asserts that two ASTs are equal."""
            self.assertEqual(type(ast1), type(ast2))
            for k, v in ast1._fields:  # type: ignore
                self.assertAstEqual(getattr(ast1, k), getattr(ast2, k))

        def assertCall(self, args: Iterable[ast.expr], starargs: Union[List[ast.expr], ast.expr]) -> None:
            print(args, starargs)

# Generated at 2022-06-23 23:03:34.565067
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(elts=[
        ast.Name(id='a', ctx=ast.Store()),
        ast.Starred(value=ast.Name(id='b', ctx=ast.Load()), ctx=ast.Load()),
        ast.Name(id='c', ctx=ast.Store())
    ])

# Generated at 2022-06-23 23:03:42.028046
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    utils.assert_source_equals_tree(StarredUnpackingTransformer,
                                    "[2, *range(10), 1]",
                                    "[2] + list(range(10)) + [1]")

    utils.assert_source_equals_tree(StarredUnpackingTransformer,
                                    "print(*range(1), *range(3))",
                                    "print(*(list(range(1)) + list(range(3))))")


# Generated at 2022-06-23 23:03:51.815366
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .type_inference import TypeInferer
    from .base import BaseNodeTransformer
    from .param_refs import ParameterReferencesTransformer
    from .call_arg_refs import CallArgumentReferencesTransformer
    from .merge_assignments import MergeAssignmentsTransformer
    from .dead_code_elimination import DeadCodeEliminationTransformer
    from .flatten_ifs import FlattenIfsTransformer
    from .remove_nop import RemoveNOPsTransformer
    from .local_names import LocalNamesTransformer
    from .constant_propagation import ConstantFoldingTransformer
    from .merge_assignments import MergeAssignmentsTransformer
    from .param_refs import ParameterReferencesTransformer
    from .known_attrs import Known

# Generated at 2022-06-23 23:04:01.934988
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # Test function
    def test(before_code: str, after_code: str) -> None:
        # Test StarredUnpackingTransformer.visit_List
        py_code = ast.parse(before_code)
        if sys.version_info < (3, 8):
            StarredUnpackingTransformer().visit(py_code)
        else:
            with pytest.warns(None):
                StarredUnpackingTransformer().visit(py_code)
        after_ast = ast.parse(after_code)
        assertEqualAst(py_code, after_ast)

    # Test StarredUnpackingTransformer.visit_List

# Generated at 2022-06-23 23:04:03.231451
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    "Constructor should not raise exception"
    t = StarredUnpackingTransformer()
    assert t


# Generated at 2022-06-23 23:04:03.861801
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:04:10.039337
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    result = "[2] + list(range(10)) + [1]"
    node = ast.parse(code)
    xformer = StarredUnpackingTransformer()
    node = xformer.visit(node)
    assert str(node) == result


# Generated at 2022-06-23 23:04:20.271462
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = StarredUnpackingTransformer()
    assert node.visit(ast.parse('''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    ''', mode='eval'))
    
    
    
    

# Generated at 2022-06-23 23:04:30.153433
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .utils import get_ast

    print(ast.dump(StarredUnpackingTransformer().visit(
        get_ast('func(*range(10))')
    )))

    print(ast.dump(StarredUnpackingTransformer().visit(
        get_ast('func(1, *range(10))')
    )))

    print(ast.dump(StarredUnpackingTransformer().visit(
        get_ast('func(1, *range(10), 1)')
    )))

    print(ast.dump(StarredUnpackingTransformer().visit(
        get_ast('func(1, *range(10), 1, *range(3))')
    )))

# Generated at 2022-06-23 23:04:34.994753
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class Dummy:
        pass

    astroid = Dummy()
    astroid.body = [ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='x'))]),
                    ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='x')), ast.Num(n=1)])]
    astroid.name = 'astroid'

    astroid_expected = Dummy()

# Generated at 2022-06-23 23:04:35.980439
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer

# Generated at 2022-06-23 23:04:40.502108
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[1, *[2, 3], 4]"
    print(code)
    code = StarredUnpackingTransformer().visit(ast.parse(code))
    print(ast.dump(code))

    code = "[1, *[2, 3], 'a']"
    print(code)
    code = StarredUnpackingTransformer().visit(ast.parse(code))
    print(ast.dump(code))



# Generated at 2022-06-23 23:04:42.697571
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None, None, None)
    
    

# Generated at 2022-06-23 23:04:52.389521
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    sut = StarredUnpackingTransformer()
    assert sut.visit(ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])) == \
        ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])

# Generated at 2022-06-23 23:05:02.558938
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import pprint
    import typing

    with open('test_starred.py', 'r') as f:
        source = f.read()

    import astunparse
    if typing.TYPE_CHECKING:
        expected = astunparse.unparse(ast.parse(source))

    import asttools.visitors.transformer
    transformer = asttools.visitors.transformer.Transformer()
    transformer.add_transformer(StarredUnpackingTransformer())

    root = ast.parse(source)
    for i in range(5):
        root = transformer.transform(root)
        #ast.fix_missing_locations(root)
        code = compile(root, filename='<ast>', mode='exec')
        #pprint.pprint(code.co_names)
        #pprint.pprint(code.co_

# Generated at 2022-06-23 23:05:10.040994
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from python_minifier.node_util import node_to_str

    test_input = [ast.List([ast.Num(2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()), ctx=ast.Load()), ast.Num(1)])]
    expected_result = [ast.List([ast.BinOp(left=ast.BinOp(left=ast.List(elts=[ast.Num(2)]), right=ast.Call(func=ast.Name(id='list', ctx=ast.Load()), args=[ast.Name(id='range', ctx=ast.Load())], keywords=[]), op=ast.Add()), right=ast.List(elts=[ast.Num(1)]), op=ast.Add())])]

    actual_result = StarredUn

# Generated at 2022-06-23 23:05:12.509043
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer

    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.target == (3, 4)


# Generated at 2022-06-23 23:05:19.972192
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformer, Compiled
    from .unpacking import UnpackingTransformer
    from .starred import StarredTransformer
    from .expr_parse import ExprParseTransformer
    node = StarredUnpackingTransformer.run(
        'print(*range(10), *range(2), 1)')
    ref_node = Compiled(
        'print(*(list(range(10)) + list(range(2)) + [1]))')
    res = ExprParseTransformer.run(
        UnpackingTransformer.run(
            StarredTransformer.run(node)))
    assert res.code == ref_node.code

# Generated at 2022-06-23 23:05:31.262047
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    o = StarredUnpackingTransformer()
    a = ast.Call(func=ast.Name(id='foo'),
                 args=[ast.Num(n=2),
                       ast.Starred(value=ast.List(elts=[ast.Name(id='range'), ast.Num(n=10)], ctx=ast.Load()), ctx=ast3.Load()),
                       ast.Num(n=2)],
                 keywords=[],
                 starargs=None, kwargs=None, kwarg=None)

# Generated at 2022-06-23 23:05:32.573875
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    assert obj is not None


# Generated at 2022-06-23 23:05:34.198785
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:05:39.178450
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"
    compiled = StarredUnpackingTransformer().visit_and_compile(code)
    assert compiled == expected



# Generated at 2022-06-23 23:05:50.931527
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class Parser(ast.NodeVisitor):
        def __init__(self):
            self.code = ""

        def visit_List(self, node):
            children = [self.visit(child) for child in ast.iter_child_nodes(node)]
            res = list()
            for child in children:
                if type(child) is tuple:
                    for item in child:
                        res.append(item)
                else:
                    res.append(child)

            return res

        def visit_BinOp(self, node):
            left = self.visit(node.left)
            op = type(node.op)
            right = self.visit(node.right)
            return (left, op, right)


# Generated at 2022-06-23 23:06:01.647077
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast.ast3 import parse
    x = parse("[2, *range(10), 1]")
    x = StarredUnpackingTransformer().visit(x)
    assert isinstance(x, ast.Expr)
    assert isinstance(x.value, ast.BinOp)
    assert isinstance(x.value.left, ast.BinOp)
    assert isinstance(x.value.right, ast.List)
    assert isinstance(x.value.left.op, ast.Add)
    assert isinstance(x.value.left.left, ast.List)
    assert isinstance(x.value.left.right, ast.Call)
    assert isinstance(x.value.left.right.func, ast.Name)

# Generated at 2022-06-23 23:06:04.830665
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """Test constructor of class StarredUnpackingTransformer."""
    assert StarredUnpackingTransformer().target == (3, 4)

# Unit tests for _has_starred method of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:06:05.797366
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor


# Generated at 2022-06-23 23:06:11.646349
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as pyast
    from typed_ast import ast3 as typed_ast
    from _ast_transforms.unpacking import StarredUnpackingTransformer
    
    # Create pyast expression
    expr = pyast.parse('[1, 2, 3]')
    visited = StarredUnpackingTransformer().visit(expr)

    # Create typed_ast expression
    expected_expr = typed_ast.parse('[1, 2, 3]')

    assert visited == expected_expr
    

# Generated at 2022-06-23 23:06:15.772930
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1] + [2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1] + [2] + list(range(10)) + [1]'
    tree = ast.parse(source)
    transformed = StarredUnpackingTransformer().visit(tree)
    assert expected == ast.dump(transformed, annotate_fields=False)


# Generated at 2022-06-23 23:06:20.730226
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert ast.dump(
        StarredUnpackingTransformer().visit(
            ast.parse('[2, *range(10), 1]')),
        include_attributes=True) == ast.dump(ast.parse('[2] + list(range(10)) + [1]'))


# Generated at 2022-06-23 23:06:25.548893
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]")
    expected = ast.parse("[2] + list(range(10)) + [1]")

    transformer = StarredUnpackingTransformer()
    node = transformer.visit(node)
    assert node == expected


# Generated at 2022-06-23 23:06:36.044029
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def _test(before, after):
        module = compile_to_ast("""
a = %s
        """ % before)
        StarredUnpackingTransformer().visit(module)
        result = ast.dump(module)
        expected = """
Module(body=[
    Assign(targets=[Name(id='a', ctx=Store())], value=%s)
    ])
        """ % after
        assert result == expected

    _test("[2, *range(10), 1]", "[2] + list(range(10)) + [1]")
    _test("[2, *[1, 2], 3 * 4, *range(10), 1]", "[2] + [1, 2] + 3 * 4 + list(range(10)) + [1]")

# Generated at 2022-06-23 23:06:42.714793
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input_expr = "[2, *range(10), 1]"
    expected_expr = "[2] + list(range(10)) + [1]"

    # Given
    tree = ast.parse(input_expr)
    transformer = StarredUnpackingTransformer()

    # When
    transformed = transformer.visit(tree)

    # Then
    assert transformer.changed  # test case for issue #4
    assert ast.dump(transformed) == expected_expr



# Generated at 2022-06-23 23:06:45.226358
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    xs = [2, *range(10), 1]
    xs_ = StarredUnpackingTransformer()(xs)
    print(xs_)


# Generated at 2022-06-23 23:06:55.798048
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
  code = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """
  module = ast.parse(code)
  tree = StarredUnpackingTransformer().visit(module)

# Generated at 2022-06-23 23:07:02.205559
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"

    node = ast.parse(code)
    expected_node = ast.parse(expected)
    tr = StarredUnpackingTransformer()
    tr.visit(node)
    assert ast.dump(node) == ast.dump(expected_node)


# Generated at 2022-06-23 23:07:14.298071
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    tests = [
        ("print(1, *[2, 3, *range(5)])", "print(*([1] + [2, 3] + list(range(5))))"),
        ("print(1, *[1, *range(5)], 2)", "print(*([1] + [1] + list(range(5)) + [2]))"),
    ]

    for before, after in tests:
        tree = ast.parse(before)
        tree = transformer.visit(tree)
        assert ast.dump(tree, include_attributes=False) == after.strip()
        assert transformer.tree_changed == True

    # Nothing changed
    tree = ast.parse("print(1, 2, 3)")
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:07:19.595677
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
    [2, *range(10), 1]
    '''
    expected = '''
    ([2] + list(range(10)) + [1])
    '''
    tr = StarredUnpackingTransformer()
    tree = ast.parse(source)
    tree = tr.visit(tree)
    assert expected == astor.to_source(tree)



# Generated at 2022-06-23 23:07:26.761620
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class FakeNode(ast.AST):
        pass

    class FakeNodeTransformer(BaseNodeTransformer):
        def __init__(self):
            self.nodes = []


# Generated at 2022-06-23 23:07:33.585124
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    def check(code: str) -> None:
        node = ast.parse(code)
        StarredUnpackingTransformer().visit(node)
        assert code == compile(node, filename='<ast>', mode='exec').co_consts[0]

    check('[2, *range(10), 1]')
    check('print(*range(1), *range(3))')
    check('f(*range(1), *range(3))')
    check('f(*f(*range(1), *range(3)))')

# Generated at 2022-06-23 23:07:41.138095
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typed_ast.ast3 import parse as ast_parse
    from ..tests.utils import unparse_ast
    from .test_base import NodeTransformerTestCaseMixin

    sample_node = ast_parse('''f(*[2, *range(10), 1])''').body[0].value
    expected_node = ast_parse('''f(*([2] + list(range(10)) + [1]))''').body[0].value

    class TestCase(NodeTransformerTestCaseMixin):
        transformer = StarredUnpackingTransformer
        node = sample_node
        expected_node = expected_node

    TestCase.check()



# Generated at 2022-06-23 23:07:47.642261
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformerTest
    from .test_nodes import (
        SomeClass, 
        test_nodes,
        expected_nodes
    )
    class_under_test = StarredUnpackingTransformer

    BaseNodeTransformerTest().test_node_transformer(
        class_under_test,
        test_nodes,
        expected_nodes
    )

# Generated at 2022-06-23 23:07:54.106595
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    with open('../examples/list.py') as fd:
        tree = ast.parse(fd.read())

    cf_transformer = StarredUnpackingTransformer()
    cf_transformer.visit(tree)

    expected_result = """
# Compiled from list.py (version 3.4)
a = [2, *range(10), 1]
    """
    # Now we can compare the string form of AST of our code with the expected result
    assert ast.dump(tree, include_attributes=False) == expected_result
    


# Generated at 2022-06-23 23:08:05.909555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sample_args_list = ast.parse('[1, 2, 3]')
    result = StarredUnpackingTransformer().visit(sample_args_list)
    assert isinstance(result, ast.List)
    assert not StarredUnpackingTransformer().tree_changed()

    sample_args_list = ast.parse('[1, *range(2), 3]')
    result = StarredUnpackingTransformer().visit(sample_args_list)
    assert isinstance(result, ast.BinOp)
    assert isinstance(result.left, ast.BinOp)
    assert isinstance(result.left.right, ast.Call)
    assert isinstance(result.right, ast.List)
    assert StarredUnpackingTransformer().tree_changed()


# Generated at 2022-06-23 23:08:11.667350
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        "print(None, 1, *range(10), 2, *range(3), 3)")
    visitor = StarredUnpackingTransformer()
    visitor.visit(tree)
    assert visitor._tree_changed
    assert repr(tree) == repr(ast.parse(
        "print(*(list(range(1)) + list(range(10)) + [2] + list(range(3)) + [3]))"))



# Generated at 2022-06-23 23:08:14.576414
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """\
[2, *range(10), 1]
    """
    expected = """\
[2] + list(range(10)) + [1]
    """
    utils.assert_converted_tree(source, expected, StarredUnpackingTransformer)


# Generated at 2022-06-23 23:08:26.302914
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # given
    import typed_astunparse  # type: ignore
    from astunparse import unparse  # type: ignore
    from .exceptions import FailedToTransformToAst
    source = """
        print(1, *range(3), *range(3), 2)
    """
    expected = """
        print(*(list([1]) + list(range(3)) + list(range(3)) + list([2])))
    """
    # and
    module = ast.parse(source)
    # when
    new_module = StarredUnpackingTransformer().visit(module)
    # then
    try:
        new_source = typed_astunparse.unparse(new_module)
    except:
        raise FailedToTransformToAst()

# Generated at 2022-06-23 23:08:35.990605
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    node = ast.parse("print(*range(1), *range(3))")
    assert node.body[0].value == ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.BinOp(
                    left=ast.List(elts=[]),
                    right=ast.Call(
                        func=ast.Name(id='list'),
                        args=[
                            ast.Call(
                                func=ast.Name(id='range'),
                                args=[ast.Constant(value=3)],
                                keywords=[])],
                        keywords=[]),
                    op=ast.Add()))],
        keywords=[])



# Generated at 2022-06-23 23:08:41.370571
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = 'foo = [1, 2, *xs, 3, 4, *ys]'
    expected_code = 'foo = [1, 2] + list(xs) + [3, 4] + list(ys)'

    tree = ast.parse(code)
    StarredUnpackingTransformer()(tree)
    assert expected_code == astor.to_source(tree)


# Generated at 2022-06-23 23:08:52.711279
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_input = "[2, *range(10), 1]"
    test_input2 = "print(*range(1), *range(3))"

    tree = ast.parse(test_input)
    tree2 = ast.parse(test_input2)

    expected_output = "[2] + list(range(10)) + [1]"
    expected_output2 = "print(*(list(range(1)) + list(range(3))))"

    StarredUnpackingTransformer().visit(tree)
    StarredUnpackingTransformer().visit(tree2)

    output = compile(tree, filename='<string>', mode='exec')
    output2 = compile(tree2, filename='<string>', mode='exec')


# Generated at 2022-06-23 23:09:03.800190
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer._split_by_starred([]) == [[]]
    assert StarredUnpackingTransformer._split_by_starred([
        ast.Call(func=ast.Name(id='A'), args=[], keywords=[]),
        ast.Starred(value=ast.Name(id='B')),
        ast.Name(id='C'),
        ast.Starred(value=ast.Name(id='D')),
    ]) == [[ast.Call(func=ast.Name(id='A'), args=[], keywords=[])],
              ast.Starred(value=ast.Name(id='B')), [],
              ast.Name(id='C'),
              ast.Starred(value=ast.Name(id='D')),
             ]
    assert StarredUnpackingTransformer._split_by_starred

# Generated at 2022-06-23 23:09:14.101590
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .utils import get_ast
    from .to_inline_ifs import InlineIfsTransformer

    source = 'print(*range(1), 2)'

    tree = get_ast(source)
    tree = InlineIfsTransformer().visit(tree)

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value.func.id == 'print'
    assert len(tree.body[0].value.args) == 1