

# Generated at 2022-06-23 22:59:25.584858
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    tree = ast.parse("print(*range(1), *range(3))")
    print(ast.dump(tree))
    t.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 22:59:34.322735
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    list_with_starred = ast.parse('[a, *b, c]').body[0]
    list_without_starred = ast.parse('[a, b, c]').body[0]

    assert isinstance(list_with_starred, ast.Expr)
    assert isinstance(list_with_starred.value, ast.List)

    assert isinstance(list_without_starred, ast.Expr)
    assert isinstance(list_without_starred.value, ast.List)

    list_with_starred_after_visit = StarredUnpackingTransformer()\
        .visit(list_with_starred.value)

    list_without_starred_after_visit = StarredUnpackingTransformer()\
        .visit(list_without_starred.value)



# Generated at 2022-06-23 22:59:40.628044
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[2, *range(10), 1]")
    self = StarredUnpackingTransformer()
    self.visit(tree)
    assert "ast.BinOp(ast.List(elts=[ast.Num(n=2)]), ast.Add(), ast.List(elts=[ast.Call(ast.Name(id='range'), [ast.Num(n=10)], [])])" in str(tree)

# Generated at 2022-06-23 22:59:51.741491
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import string
    import random
    import json
    import astunparse
    st = StarredUnpackingTransformer()
    star_num = 100
    list_num = 20
    total_num = star_num + list_num
    for i in range(100):
        src = '['
        for j in range(star_num):
            star = '*'
            ran = random.Random()
            star_target_num = ran.randint(0, 10)
            for i in range(star_target_num):
                star = star + 'range(' + str(ran.randint(0, 10)) + ')'
            src = src + star + ','
        for j in range(list_num):
            src = src + 'range(' + str(random.randint(0, 10)) + ')' + ','


# Generated at 2022-06-23 22:59:56.774086
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)

    expected_code = "[2] + list(range(10)) + [1]"
    expected_node = ast.parse(expected_code)
    assert ast.dump(node) == ast.dump(expected_node)



# Generated at 2022-06-23 23:00:06.638002
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class DummyNode(object): pass
    node = DummyNode()
    node.args = [3, 4, 5]

    v = StarredUnpackingTransformer()
    v.visit_Call(node)

    assert v._tree_changed == False
    assert node.args == [3, 4, 5]

    class DummyNode2(object): pass
    node = DummyNode2()
    node.args = [3, 4, 5]
    v = StarredUnpackingTransformer()
    v.visit_Call(node)

    assert v._tree_changed == False
    assert node.args == [3, 4, 5]

    class DummyNode3(object): pass
    node = DummyNode3()
    node.args = [3, 4, 5]
    v = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:15.051056
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    test_ast = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    new_ast = transformer.visit(test_ast)
    print(astor.to_source(new_ast))

    test_ast = ast.parse("print(*range(1), *range(3))")
    transformer = StarredUnpackingTransformer()
    new_ast = transformer.visit(test_ast)
    print(astor.to_source(new_ast))

# Generated at 2022-06-23 23:00:19.983339
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Test that the output code is identical to the input code."""
    input_string = 'def foo(a, b, *c): print(a, 4, *c)'
    output_string = 'def foo(a, b, *c): print(a, 4, *c)'
    assert transform_code(input_string, StarredUnpackingTransformer) == output_string


# Generated at 2022-06-23 23:00:29.049480
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("test(*args)")
    node = tree.body[0].value
    assert isinstance(node.args[0], ast.Starred)

    class StarredUnpackingTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return ast.Call(node.func, [node.args[0].value], node.keywords, [])

    node_transformer = StarredUnpackingTransformer()
    node_transformer.visit(node)
    res = node_transformer.result()
    assert isinstance(res, ast.Call)
    assert not isinstance(res.args[0], ast.Starred)

# Generated at 2022-06-23 23:00:38.400830
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import assert_in, assert_same_source, FrozenTree

    tree = FrozenTree("""
    a()
    a(x, y)
    a(x, y, z)
    a(x, *y)
    a(*y)
    a(*y, z)
    a(x, *y, z)
    a(x, y, z, *o)
    a(x, y, z, *o, w)
    """)


# Generated at 2022-06-23 23:00:44.881553
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # do nothing if not in Python 3.4 or higher
    if sys.version_info[:2] < (3, 4):
        return

    sut = StarredUnpackingTransformer()
    ast1 = ast.parse('[2, *range(10), 1]')
    ast2 = ast.parse('print(*range(1), *range(3))')
    ast3 = ast.parse('print([*range(1)], [*range(3)])')
    sut.visit(ast1)
    sut.visit(ast2)
    sut.visit(ast3)
    compiled1 = compile(ast1, filename='', mode='exec')
    compiled2 = compile(ast2, filename='', mode='exec')
    compiled3 = compile(ast3, filename='', mode='exec')

# Generated at 2022-06-23 23:00:48.881034
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    StarredUnpackingTransformer(
        BaseNodeTransformer("StarredUnpackingTransformer")
    )


# Generated at 2022-06-23 23:00:59.036524
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=BinOp(left=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)], ctx=Load()), op=Add()))])"



# Generated at 2022-06-23 23:01:09.175006
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class _Transformer(StarredUnpackingTransformer):
        def __init__(self, source: str, **kargs) -> None:
            super(_Transformer, self).__init__(**kargs)
            self.source = source

        @property
        def tree(self) -> ast.AST:
            return ast.parse(self.source)

    source = 'print(*range(1), *range(3))'
    assert source == _Transformer(source).to_source()

    source = 'print(*range(1), *range(3))'
    source = 'print(*(list(range(1)) + list(range(3))))'
    assert source == _Transformer(source).to_source()

    source = '[2, *range(10), 1]'
    assert source == _Transformer(source).to_source()

# Generated at 2022-06-23 23:01:11.943696
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))").body[0]
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]

    assert StarredUnpackingTransformer().visit(node) == expected

# Generated at 2022-06-23 23:01:18.427404
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node_old = ast.parse('print(1, *range(1, 2), *range(2, 3))').body[0]
    node_new = ast.parse('print(*(list(range(1, 2)) + list(range(2, 3))))')

    assert node_old == node_new
    assert node_old != ast.parse('print(1, *range(1, 2), *range(2, 3))').body[0]


# Generated at 2022-06-23 23:01:23.748006
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert (StarredUnpackingTransformer()._has_starred([]) == False)
    assert (StarredUnpackingTransformer()._has_starred([ast.expr()]) == False)
    assert (StarredUnpackingTransformer()._has_starred([ast.Starred()]) == True)
    assert (StarredUnpackingTransformer()._has_starred([ast.expr(), ast.Starred()]) == True)

# Generated at 2022-06-23 23:01:32.903957
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(value=ast.Call(
                func=ast.Name(id='range', ctx=ast.Load()),
                args=[ast.Num(n=10)],
                keywords=[])),
            ast.Num(n=1)],
    )

    res = StarredUnpackingTransformer().visit(node)


# Generated at 2022-06-23 23:01:33.812015
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:01:40.564278
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import get_ast
    source = "[1, 2, 3, 4, 5, *range(10, 15), 6]"
    expected = '[1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 6]'
    result = StarredUnpackingTransformer().visit(get_ast(source))
    assert expected == compile(result, '<string>', 'exec')


# Generated at 2022-06-23 23:01:42.812150
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_util import MockFile

    tree = ast.parse('[2, *range(10), 1]')
    tree = StarredUnpackingTransformer().visit(tree)

    with MockFile() as out:
        ast.fix_missing_locations(tree)
        exec(compile(tree, out.name, 'exec'))
        assert [2, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1] == out.getvalue()



# Generated at 2022-06-23 23:01:43.661537
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:01:51.416410
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import from_source

    assert from_source(StarredUnpackingTransformer, '[2, *range(10), 1]') == '[2] + list(range(10)) + [1]'
    assert from_source(StarredUnpackingTransformer, '[*range(10)]') == '[list(range(10))]'
    assert from_source(StarredUnpackingTransformer, '[2, *range(10)]') == '[2] + list(range(10))'
    assert from_source(StarredUnpackingTransformer, '[*range(10), 1]') == 'list(range(10)) + [1]'
    assert from_source(StarredUnpackingTransformer, '[2, *range(10, 20), 1]') == '[2] + list(range(10, 20)) + [1]'

# Generated at 2022-06-23 23:01:55.853006
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import round_trip
    from .util import re_assert_equal_source

    with_star = '''
    [1, *range(10)]
    '''

    tree = round_trip(with_star)

    StarredUnpackingTransformer().visit(tree)

    re_assert_equal_source(tree, '''
    (list([1]) + list(range(10)))
    ''')


# Generated at 2022-06-23 23:02:03.041972
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse
    import pickle

    source_code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'
    tree = parse(source_code)
    expected_tree = parse(expected_code)

    StarredUnpackingTransformer().visit(tree)

    assert pickle.dumps(tree) == pickle.dumps(expected_tree)


# Generated at 2022-06-23 23:02:11.415153
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ex_1 = ast.parse('[2, *range(10), 1]')
    ex_2 = ast.parse('[2, *range(10), 1]', mode='eval')
    ex_3 = ast.parse('print(*range(1), *range(3))')
    ex_4 = ast.parse('print(*range(3), *range(1))')

    for ex in [ex_1, ex_2, ex_3, ex_4]:
        node = StarredUnpackingTransformer().visit(ex)
        assert type(node) is ast.List
        assert type(node.elts[0]) is ast.List
        assert type(node.elts[1]) is ast.Call
        assert type(node.elts[2]) is ast.List

# Generated at 2022-06-23 23:02:16.988131
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # List of arguments with Starred
    node = ast.parse('[2, *range(10), 1]').body[0].value
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0].value

    new_node = StarredUnpackingTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(expected)



# Generated at 2022-06-23 23:02:19.626150
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    res = StarredUnpackingTransformer.run_case(src)
    assert res == expected



# Generated at 2022-06-23 23:02:30.561010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from tests.helper_test import test
    from ast_unparse import Unparser
    from ast_normalization_checker import AstNormalizationChecker

    test_cases = (
        ('print()', 'print()'),
        ('print(*range(10))', 'print(*(list(range(10))))'),
        ('print(*range(10), *range(9))', 'print(*(list(range(10)) + list(range(9))))'),
        ('print(*range(10), *range(9), *range(8))', 'print(*(list(range(10)) + list(range(9)) + list(range(8))))'),
    )

    for code, answer in test_cases:
        tree = test(code, StarredUnpackingTransformer)
        result = Unparser(tree)
        assert result == answer
        Ast

# Generated at 2022-06-23 23:02:32.574514
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert ast.dump(StarredUnpackingTransformer().visit(parse('''
[2, *range(10), 1]
'''))) == ast.dump(parse('''
[2] + list(range(10)) + [1]
'''))



# Generated at 2022-06-23 23:02:35.445592
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)

# Unit tests for method _has_starred of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:46.548187
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """\
[2, *range(10), 1]
[range(10), *range(10)]
[*range(3), *range(3)]
[*range(3), *range(3), *range(3)]
[*range(3), *range(3), *range(10), *range(10)]
[*range(3), *range(3), *range(10)]
    """

# Generated at 2022-06-23 23:02:51.348033
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """print([2, *range(10), 1])"""
    expected_code = """print(([2] + list(range(10)) + [1]))"""

    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node) == expected_code


# Generated at 2022-06-23 23:02:57.681316
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ._tests import get_ast

    tree = get_ast('''
        [2, *range(10), 1]
        print(*range(1), *range(3))''')

    StarredUnpackingTransformer().walk(tree)

    assert len(tree.body) == 2

    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.left, ast.BinOp)
    assert isinstance(tree.body[0].value.left.left, ast.List)
    assert isinstance(tree.body[0].value.left.right, ast.Call)
    assert isinstance(tree.body[0].value.right, ast.List)


# Generated at 2022-06-23 23:03:04.374851
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    node = compile(source, "<test>", "eval", ast.PyCF_ONLY_AST)
    result = StarredUnpackingTransformer().visit(node)
    assert expected == compile(ast.Expression(body=result),
                               "<test>", "eval").strip()



# Generated at 2022-06-23 23:03:14.474571
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('print(*range(1), *range(2))').body[0]

    transformed = transformer.visit(node)

    assert isinstance(transformed.value, ast.Call)
    assert isinstance(transformed.value.args, list)
    assert len(transformed.value.args) == 1, 'We should have only one argument to `print`'
    assert isinstance(transformed.value.args[0], ast.Starred)
    assert isinstance(transformed.value.args[0].value, ast.BinOp)
    assert isinstance(transformed.value.args[0].value.left, ast.Call)
    assert transformed.value.args[0].value.left.func.id == 'list'

# Generated at 2022-06-23 23:03:26.108010
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from pytypes import type_inference
    from pytypes.parsers.python import string_to_ast
    from pytypes.transformers import TransformerError
    from pytypes import Scope
    from pytypes import modules
    import os
    import ast
    import types
    import tempfile
    import glob
    import shutil
    
    print("(1) Testing StarredUnpackingTransformer:")
    print("\t (1.1) Constructor")
    star = StarredUnpackingTransformer()
    print("\t (1.2) visit_Call")
    str = """print(*(list(range(1)) + list(range(3))))"""
    tree = ast.parse(str)
    tree = star.visit(tree)
    print("\t (1.3) visit_List")
    str = ""

# Generated at 2022-06-23 23:03:35.188634
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import parse

    cases = [
        ("[2, *range(10), 1]", "[2] + list(range(10)) + [1]"),
        ("[1, *[1, 2], *range(5), 4]", "[1] + [1, 2] + list(range(5)) + [4]"),
        ("[]", "[]"),
    ]

    for case_ori, case_exp in cases:
        t_ori = parse(case_ori)
        t_exp = parse(case_exp)
        trans = StarredUnpackingTransformer()
        t_res = trans.visit(t_ori)
        assert t_res == t_exp, f'\n{case_ori!r}\n{case_exp!r}\n{t_res!r}'

#

# Generated at 2022-06-23 23:03:46.724041
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class T:
        def __init__(self, s):
            self.s = s

    class M:
        def __call__(self, *args):
            return T(args[0])

    m = M()
    node = ast.parse("m(2*2, *[2, 3, 4], 2)")
    print("IN =====")
    print(ast.dump(node))
    print("OUT ====", end="")
    obj = StarredUnpackingTransformer()
    res = obj.visit(node)
    print(res)
    res = obj.transformer.visit(res)
    print("COMPILED", end="")
    print(compile(res, "<string>", "exec"))

    #compiled = compile(res, "<string>", "exec")
    #eval(

# Generated at 2022-06-23 23:03:50.384826
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import evaluate_ast, parse_code

    result = evaluate_ast(
        parse_code(
            'print(*range(1), *range(3))',
        ).body[0],
        transformers=StarredUnpackingTransformer,
    )
    print(result)



# Generated at 2022-06-23 23:03:54.122741
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    sample = ast.parse('[2, *range(10), 1]')
    result = StarredUnpackingTransformer().visit(sample)
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert result == expected



# Generated at 2022-06-23 23:04:03.815989
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    import sys
    import io

    class StdoutIO(io.TextIOBase):
        def write(self, s):
            pass

    ast2 = parse("__tree_changed = True\n" +
                 "x = [2, *range(10), 1]\n" +
                 "print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(ast2)
    sys.stdout = StdoutIO()
    exec(compile(ast2, filename="<ast>", mode="exec"))
    sys.stdout = sys.__stdout__
    assert __tree_changed
    assert x == [2] + list(range(10)) + [1]
    assert ast2
   

# Generated at 2022-06-23 23:04:05.795059
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-23 23:04:08.251663
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    SUT = StarredUnpackingTransformer()
    assert SUT is not None


# Generated at 2022-06-23 23:04:19.190038
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
     assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Name(id="x"))]) == True
     assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Name(id="x")), ast.Num(n=5)]) == True
     assert StarredUnpackingTransformer._has_starred([ast.Num(n=5), ast.Num(n=5)]) == False
     assert StarredUnpackingTransformer._has_starred([ast.Starred(value=ast.Name(id="x")), ast.Num(n=5), ast.Num(n=5)]) == True

# Generated at 2022-06-23 23:04:25.910353
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
[2, *range(10), 1]
'''
    expected = '''
([2] + list(range(10)) + [1])
'''
    x = StarredUnpackingTransformer()
    tree = x.parse(source)
    tree = x.visit(tree)
    tree = x.fix_missing_locations(tree)
    code = x.compile(tree)
    assert expected == code



# Generated at 2022-06-23 23:04:36.441828
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    node = tools.parse(source)
    tools.assert_equivalent_to_source(StarredUnpackingTransformer().visit(node), expected)
    source = "[2, *a]"
    expected = "[2] + a"
    node = tools.parse(source)
    tools.assert_equivalent_to_source(StarredUnpackingTransformer().visit(node), expected)
    source = "[2, *a, 3, *b]"
    expected = "[2] + a + [3] + b"
    node = tools.parse(source)
    tools.assert_equivalent_to_source(StarredUnpackingTransformer().visit(node), expected)


# Generated at 2022-06-23 23:04:43.474357
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "lst = [2, *range(10), 1]"
    correct_result = "lst = [2] + list(range(10)) + [1]"
    assert str(ast.parse(source)) == str(ast.parse(correct_result))
    assert str(ast.parse(source).body[0]) == str(StarredUnpackingTransformer().visit(ast.parse(source).body[0]))


# Generated at 2022-06-23 23:04:52.899173
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import type_collector
    source = """
    def func(a, b, c, d, e):
        pass
    func(*range(1, 6))
    """
    tree = type_collector.parse(source)
    node = tree.body[1].value
    assert isinstance(node, ast.Call)
    assert node.keywords == []
    assert node.starargs is None
    assert node.kwargs is None
    assert len(node.args) == 5
    assert isinstance(node.args[0], ast.Call)
    assert isinstance(node.args[0].func, ast.Name)
    assert node.args[0].func.id == 'range'
    assert node.args[0].args == [ast.Num(1), ast.Num(6)]

# Generated at 2022-06-23 23:05:00.415565
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse("[2, *range(10), 1]")
    out_tree = transformer.visit(tree)
    out_code = compile(out_tree, '<string>', 'eval')
    result = eval(out_code)
    assert all([i in result for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]])
    assert all([i in result for i in [1, 2]])


# Generated at 2022-06-23 23:05:01.754036
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__ is StarredUnpackingTransformer


# Generated at 2022-06-23 23:05:13.038975
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:05:14.655768
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range'))],
        keywords=[]
    )
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(node) == node

# Generated at 2022-06-23 23:05:16.146201
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:05:22.136193
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    assert StarredUnpackingTransformer().visit(ast.parse(source)).body[0] == ast.parse(expected).body[0]

# Generated at 2022-06-23 23:05:30.573929
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .samplers import StarredUnpackingSampler

    for tree in StarredUnpackingSampler.get_samples():
        t = StarredUnpackingTransformer()
        out = t.visit(tree)
        t.assert_tree_unchanged()

        assert out is None

    tree = ast.parse('[2, *range(10), 1]')
    t = StarredUnpackingTransformer()
    out = t.visit(tree)
    t.assert_tree_changed()

    assert isinstance(out.body[0].value, ast.BinOp)


# Generated at 2022-06-23 23:05:40.450607
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    # https://docs.python.org/3/library/typing.html#typing.List
    list_ = transformer.visit(node)
    assert repr(list_) == \
        "[2, +, list, (, Call, (, Name, (, id='range', ), 'range', [2, 3], ), [, " \
        "Call, (, Name, (, id='range', ), 'range', [2, 3], ), [10], ), ), ], " \
        "1, ]"



# Generated at 2022-06-23 23:05:48.285715
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class M:
        def visit_List(self, node):
            return node
    a = M()
    b = M()
    c = M()

    star1 = ast.Starred(value=a, ctx=ast.Load())
    star2 = ast.Starred(value=b, ctx=ast.Load())
    star3 = ast.Starred(value=c, ctx=ast.Load())
    method = ast.Name(id="__new__", ctx=ast.Load())
    call1 = ast.Call(func=method, args=[a], keywords=[])
    call2 = ast.Call(func=method, args=[b], keywords=[])
    call3 = ast.Call(func=method, args=[c], keywords=[])

# Generated at 2022-06-23 23:05:49.111166
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:05:51.802128
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert isinstance(new_tree, ast.AST)
    assert isinstance(ast.dump(new_tree), str)



# Generated at 2022-06-23 23:05:59.975365
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = [2, *range(10), 1]
    tree = ast.fix_missing_locations(ast.parse(compile(x, __file__, 'eval')))  # type: ignore
    
    transformer = StarredUnpackingTransformer()
    transformed = transformer.visit(tree)
    
    assert isinstance(transformed, ast.List)
    assert transformed.elts[1].value.func.id == 'range'
    assert transformed.elts[1].value.args[0].n == 10
    assert transformed.elts[-1].n == 1
    assert len(transformed.elts) == 3


# Generated at 2022-06-23 23:06:04.968883
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(1), *range(3))\n'
    module = ast.parse(source)
    expected = 'print(*(list(range(1)) + list(range(3))))\n'
    StarredUnpackingTransformer().visit(module)
    actual = ast.unparse(module)
    assert expected == actual


# Generated at 2022-06-23 23:06:07.437883
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .fix_code import FixCode
    fc = FixCode(StarredUnpackingTransformer())
    result = fc.test()
    assert result.success

# Generated at 2022-06-23 23:06:08.776441
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer.target == (3, 4)

# Generated at 2022-06-23 23:06:16.373000
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[a, *b, c, d]"
    expected = "[a] + list(b) + [c, d]"

    tree = ast.parse(code)
    assert ast.dump(tree) == "Module(body=[Expr(value=List(elts=[Name(id='a', ctx=Load()), Starred(value=Name(id='b', ctx=Load()), ctx=Load()), Name(id='c', ctx=Load()), Name(id='d', ctx=Load())], ctx=Load()))])"  # noqa: E501
    new_tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 23:06:16.957592
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-23 23:06:18.381497
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:06:24.726089
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = '''[2, *range(10), 1]'''
    expected = '''[2] + list(range(10)) + [1]'''
    with rewrite_assert(input, expected) as test:
        x = ast.parse(test.input)
        StarredUnpackingTransformer().visit(x)
        assert astunparse.unparse(x) == test.expected


# Generated at 2022-06-23 23:06:35.439004
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiler import compile
    from .base import BaseNodeTransformer
    from .unpacking import UnpackingTransformer

    code = """
print(*range(1), *range(3))

with open('test.txt') as f:
    for x in f:
        print(x)
    """

    tree = compile(code, "<string>", "exec", ast.PyCF_ONLY_AST)

    actual_tree = StarredUnpackingTransformer().visit(
        UnpackingTransformer().visit(tree))
    expected_tree = compile(code.replace(
        "print(*range(1), *range(3))",
        "print(*(list(range(1)) + list(range(3))))"),
        "<string>", "exec", ast.PyCF_ONLY_AST)

    BaseNodeTransformer.compare

# Generated at 2022-06-23 23:06:45.892411
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module = ast.parse("""
    x = [1, *(2,), 3, *range(4, 7)]
    f(1, *range(2), 3)
    """)
    StarredUnpackingTransformer().visit(module)

# Generated at 2022-06-23 23:06:51.817376
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
        [2, *range(10), 1]
    """
    expected = """
        [2] + list(range(10)) + [1]
    """

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)

    assert astor.to_source(tree).strip() == expected



# Generated at 2022-06-23 23:06:54.627155
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    input_ast = ast.parse('[x, y, z]')
    assert StarredUnpackingTransformer().visit(input_ast) == input_ast


# Generated at 2022-06-23 23:07:05.623030
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class _Mock(object):
        _tree_changed = False
    mock = _Mock()

    class _MockNodeTransformer(StarredUnpackingTransformer):
        def generic_visit(self, node):
            return node

    node_transformer = _MockNodeTransformer(mock)

    call = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Name(id='range')),
            ast.Starred(value=ast.Name(id='range2'))
        ],
        keywords=[])


# Generated at 2022-06-23 23:07:11.261192
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    node = ast.parse("print(*range(1), *range(3))")
    transformer = StarredUnpackingTransformer()
    res = transformer.visit(node)

    assert str(res) == "print(*(list(range(1)) + list(range(3))))"


# Generated at 2022-06-23 23:07:18.454988
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as pyast


# Generated at 2022-06-23 23:07:25.371606
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = [2, *range(10), 1]
    print(*range(1), *range(3))
    assert source == [2, *range(10), 1]
    assert print(*range(1), *range(3)) == None
    p1 = StarredUnpackingTransformer()
    p2 = StarredUnpackingTransformer()
    source2 = p1.visit(ast.parse(str(source)))
    print2 = p2.visit(ast.parse(str(print(*range(1), *range(3)))))
    assert eval(compile(source2, '<string>', mode='eval')) == eval(compile(print2, '<string>', mode='eval'))

# Generated at 2022-06-23 23:07:34.024813
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .StarredUnpackingTransformer import StarredUnpackingTransformer
    import unittest
    import astunparse
    import textwrap
    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_StarredUnpackingTransformer(self):
            source = textwrap.dedent(r"""
                list1 = [1, 2, 3]
                list2 = [9, 8, 7]
                list3 = [4, 5, 6]
                print(*list1, *list2, *list3)
            """)

# Generated at 2022-06-23 23:07:39.740820
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    input_source = """
    def foo(a, b, c, d):
        pass

    foo(1, *[2], 3, *[4, 5], *[6, *[7]])
    """
    input_tree = ast.parse(input_source)
    expected_output = """
    def foo(a, b, c, d):
        pass

    foo(*(1, *list([2]), 3, *list([4, 5]), *list([6, *list([7])])))
    """

    # Exercise
    actual_output = StarredUnpackingTransformer().visit(input_tree)

    # Verify
    assert expected_output == astor.to_source(actual_output)

# Generated at 2022-06-23 23:07:47.173568
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    st = ast.parse("print(*range(10))")
    StarredUnpackingTransformer().visit(st)
    assert ast.dump(st) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=List(elts=[Name(id='range', ctx=Load()), Constant(value=10, kind=None)]), ctx=Load())], keywords=[]))])"

# Generated at 2022-06-23 23:07:52.572906
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .__tests__.test_transform import transform
    src = '''
list_ = [2, *range(10), 1]
print(*range(1), *range(3))
'''
    expected = '''
list_ = [2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
'''
    assert transform(StarredUnpackingTransformer, src) == expected

# Generated at 2022-06-23 23:07:55.976640
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input_ = ast.parse("[2, *range(10), 1]")
    expected_output = ast.parse("[2] + list(range(10)) + [1]")
    assert StarredUnpackingTransformer().visit(input_) == expected_output


# Generated at 2022-06-23 23:07:57.390044
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    _ = StarredUnpackingTransformer()
    return True


# Generated at 2022-06-23 23:08:09.091412
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    visited = StarredUnpackingTransformer().visit(
        ast.parse(dedent('''\
        [2, *range(10), 1]
        [2, 1]
        ''')))

# Generated at 2022-06-23 23:08:16.921965
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from ast import List
    from visitor import Visitor
    from visitor.transformer.starred_unpacking import StarredUnpackingTransformer
    from_visitor = Visitor([StarredUnpackingTransformer()])
    node = List(
        elts=[2, 3, 4, 5, 6],
        ctx=ast.Load())
    expected = List(
        elts=[2, 3, 4, 5, 6],
        ctx=ast.Load())
    actual = from_visitor.visit(node)
    assert expected == actual

    node = List(
        elts=[2, 3, ast.Starred(value=ast.Name(id='x', ctx=ast.Load()), ctx=ast.Load()), 5, 6],
        ctx=ast.Load())
    expected = ast

# Generated at 2022-06-23 23:08:28.659180
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = [1, *[2, 3], 4]

    # test _has_starred
    assert StarredUnpackingTransformer._has_starred(a)
    a = [1, 2, 3, 4]
    assert not StarredUnpackingTransformer._has_starred(a)

    # test _split_by_starred
    assert StarredUnpackingTransformer._split_by_starred(a) == [[1, 2, 3, 4]]

    a = [1, *[2, 3], *[4, 5], 6]
    assert StarredUnpackingTransformer._split_by_starred(a) == [[1, 2, 3], ast.Starred(value=ast.List(elts=[4,5], ctx=ast.Load())), [6]]

    # test _merge_lists
   

# Generated at 2022-06-23 23:08:38.136786
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import typed_ast.ast3 as typed_ast
    #     test = [2, *range(10), 1]
    test = typed_ast.List(
        elts=[
            typed_ast.Constant(value=2),
            typed_ast.Starred(value=typed_ast.Call(
                func=typed_ast.Attribute(
                    value=typed_ast.Name(id='range', ctx=typed_ast.Load()),
                    attr='range',
                    ctx=typed_ast.Load()),
                args=[typed_ast.Constant(value=10)],
                keywords=[])),
            typed_ast.Constant(value=1)],
        ctx=typed_ast.Load())

# Generated at 2022-06-23 23:08:46.967376
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .util import source_to_node
    from .util import node_to_source

    source = 'print(*range(1), *range(3))'
    node = source_to_node(source)
    transformer = StarredUnpackingTransformer()
    node_transformed = transformer.visit(node)

    expected_source = 'print(*(list(range(1)) + list(range(3))))'
    node_expected = source_to_node(expected_source)
    assert node_transformed == node_expected

    source_transformed = node_to_source(node_transformed)
    assert source_transformed == expected_source


# Generated at 2022-06-23 23:08:51.727875
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    visitor = StarredUnpackingTransformer()
    code = '''print(*range(1), *range(3))'''
    tree = ast.parse(code)
    tree = visitor.visit(tree)

# Generated at 2022-06-23 23:08:57.799723
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .util import parse

    # Compile
    t = StarredUnpackingTransformer()
    node = parse("[2, *range(10), 1]")
    results = t.visit(node)

    assert [x.__class__.__name__ for x in results.body] == ['Expr']
    assert str(results) == "([2] + list(range(10)) + [1])"

# Generated at 2022-06-23 23:09:05.305106
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    _source = """
lst = [1, *range(10), 2, *range(5, 8)]
print(lst)
"""
    _expected = """
lst = list(range(1, 11)) + list(range(5, 8)) + [2]
print(lst)
"""
    _expected_ast = ast.parse(_expected)

    transformer = StarredUnpackingTransformer()
    actual_ast = transformer.visit(ast.parse(_source))
    assert ast.dump(actual_ast) == ast.dump(_expected_ast)



# Generated at 2022-06-23 23:09:16.602914
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    # [2, *range(10), 1] -> [2] + list(range(10)) + [1]
    assert transformer.visit(ast.parse("[2, *range(10), 1]").body[0]) == \
        ast.parse('[2] + list(range(10)) + [1]').body[0]
    # [2, *range(10), 1] -> [2] + list(range(10)) + [1]
    assert transformer.visit(ast.parse("[2, *range(10), 1]").body[0]) == \
        ast.parse('[2] + list(range(10)) + [1]').body[0]
    # [2, *range(10), 1, *range(8), 9, *range(10)]

# Generated at 2022-06-23 23:09:21.621277
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    trans = StarredUnpackingTransformer()
    trans.visit(tree)

    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.op, ast.Add)
    assert isinstance(tree.body[0].value.right, ast.List)

