

# Generated at 2022-06-23 22:59:29.250124
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer()
    node = ast.parse('print(*range(1), *range(3))')
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]
    assert isinstance(expected, ast.Expr)
    expected = expected.value

    actual = t.visit(node.body[0].value)
    assert isinstance(actual, ast.Call)
    actual = actual.args[0].value
    assert isinstance(actual, ast.BinOp) and isinstance(expected, ast.BinOp)
    actual = [actual.left, actual.right]
    expected = [expected.left, expected.right]
    assert actual[0] == expected[0]
    assert actual[1] == expected[1]

# Unit

# Generated at 2022-06-23 22:59:39.099783
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    arg_list = [ast.Str(s='a'), ast.Starred(value=ast.Num(n=1)), ast.Str(s='b')]
    node = ast.List(elts=arg_list, ctx=ast.Load())
    trans = StarredUnpackingTransformer(node=node)
    trans.visit()
    assert repr(trans.result) == repr(ast.BinOp(
        left=ast.List(elts=[ast.Str(s='a')], ctx=ast.Load()),
        right=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Num(n=1)],
            keywords=[],
        ),
        op=ast.Add(),
    ))


# Generated at 2022-06-23 22:59:50.027139
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    st = ast.parse(
        """
print(1, *range(10), 2, *[1, 2, 3], *range(10), 4, *[1, 2, 3], *range(10))
print(1, *range(10), 2, *[1, 2, 3], *range(10), 4, *[1, 2, 3], *range(10))
list([1, 2, 3, *range(1, 10)])
"""
    )


# Generated at 2022-06-23 22:59:55.465414
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ..autotransformer import AutoTransformer

    code = """
    def f(x):
        return [2, *range(10), 1]
    print(*range(1), *range(3))    
    """

    tree = ast.parse(code)
    StarredUnpackingTransformer()(tree)
    assert 'list' in AutoTransformer()._collect_symbols(tree)

# Generated at 2022-06-23 22:59:56.068307
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ...

# Generated at 2022-06-23 23:00:06.006301
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:14.776853
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(1, *[2, *[4, *[4, *[4, *[4, *[4, *[4, *[4, *[4, *[4, *[4]]]]]]]]]], 3)')
    result = StarredUnpackingTransformer().visit(node)
    fixed_result = str(result.body[0].value).replace(' ', '').replace('\n', '')
    expected_result = 'print(*(list(range(1))+list(range(3))))'
    assert fixed_result == expected_result

# Generated at 2022-06-23 23:00:21.221230
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
print(1, *range(1))
print(2, *range(2))
    """
    expected = """
print(*(list([1]) + list(range(1))))
print(*(list([2]) + list(range(2))))
    """
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    result = compile(node, '<string>', 'exec')
    expected = compile(ast.parse(expected), '<string>', 'exec')
    assert result.co_code == expected.co_code

# Generated at 2022-06-23 23:00:30.417058
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test case 1
    node1 = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(node1)
    assert ast.dump(node1) == \
           "Module(body=[Expr(value=[2, __Pyx_call(range, ((10,), None)) + [1]])])"

    # Test case 2
    node2 = ast.parse("2, 3")
    StarredUnpackingTransformer().visit(node2)
    assert ast.dump(node2) == \
           "Module(body=[Expr(value=2), Expr(value=3)])"


# Generated at 2022-06-23 23:00:31.291752
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:37.078319
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]")
    assert isinstance(node, ast.Module)
    node = node.body[0]
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.List)
    assert isinstance(node.ctx, ast.Load)
    assert node.elts[0] == ast.Num(n=2)
    assert isinstance(node.elts[1], ast.Starred)
    assert isinstance(node.elts[1].value, ast.Call)
    assert node.elts[-1] == ast.Num(n=1)

    visitor = StarredUnpackingTransformer()
    result = visitor.visit(node)
    print(ast.dump(result))
    assert isinstance

# Generated at 2022-06-23 23:00:42.530683
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test for correct unpacking of variables
    code_in = """
print(1, *[2, 3, 4, 5], 10)
    """
    code_out = """
print(*(list([1]) + list(range(2, 6)) + list([10])))
    """
    node_in = ast.parse(code_in)
    node_out = ast.parse(code_out)
    transformer = StarredUnpackingTransformer()
    node_transformed = transformer.visit(node_in)
    assert node_transformed == node_out


# Generated at 2022-06-23 23:00:48.886046
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as _ast
    import astunparse
    node = _ast.parse(
        '[2, *range(10), 1]'
    )
    expected = (
        '[2] + list(range(10)) + [1]'
    )
    actual = StarredUnpackingTransformer().visit(node)
    assert astunparse.unparse(actual) == expected


# Generated at 2022-06-23 23:00:52.660340
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:01:03.920172
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    
    import astor
    from tools.transformer import transform

    class Node(ast.AST):

        _fields = ('kwargs_elts',)

        def __init__(self, **kwargs) -> None:
            values = kwargs.pop('kwargs_elts', None) or ()
            self.kwargs_elts = values
            super().__init__(**kwargs)

    def create_kwargs_node(values: List[ast.expr]) -> Node:
        return Node(kwargs_elts=values)

    def create_star_node(name: str) -> Node:
        return Node(kwargs_elts=[ast.Starred(value=ast.Name(id=name))])


# Generated at 2022-06-23 23:01:08.367102
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer._tree_changed == False
    assert transformer.target == (3, 4)


if __name__ == "__main__":
    # Run the unit tests
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:01:15.290957
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .helpers import get_node, strip

    code = """\
        print(1, *range(5), 1)
        """
    expected_result = """\
        print(*(list(range(5)) + [1]))
        """
    node = get_node(code, 'expr')
    result = StarredUnpackingTransformer().visit(node)
    assert strip(expected_result) == strip(result)

# Generated at 2022-06-23 23:01:17.770436
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("Testing constructor of class StarredUnpackingTransformer...")
    text = """x = [1, 2, 3]"""
    result = StarredUnpackingTransformer().transformer(text)
    assert result == "x = [1, 2, 3]\n"
    print("Pass")


# Generated at 2022-06-23 23:01:27.352131
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()
    code = 'print(2, *range(10), 1, *range(5))'
    root = ast.parse(code)
    result = visitor.visit(root)
    assert type(root) != type(result)
    assert result.body[0].value.func.id == 'print'
    assert result.body[0].value.args[0].op.left.op.left.values[1].n == 2
    assert result.body[0].value.args[0].op.left.op.right.func.id == 'list'
    assert result.body[0].value.args[0].op.right.op.left.func.id == 'list'

# Generated at 2022-06-23 23:01:37.487364
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # Stuff that does not need to be checked
    node = ast.List()
    node.lineno = 1
    node.col_offset = 1

    # Test 1 :
    node.elts = [2, ast.Starred(ast.Name('range', ast.Load()), ast.Load()), 1]
    exp = ast.Call( ast.Name('list', ast.Load()), [ast.Name('range', ast.Load())], [])
    expected_call = 'BinOp(left=List(elts=[Num(n=2)], ctx=Load()), op=Add(), right=BinOp(left=exp, op=Add(), right=List(elts=[Num(n=1)], ctx=Load())))'
    actual_call = repr(StarredUnpackingTransformer().visit_List(node))

# Generated at 2022-06-23 23:01:38.478504
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:01:45.685915
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code_with_unpacking = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    expected_code = """
    ([2] + list(range(10)) + [1])
    print(*(list(range(1)) + list(range(3))))
    """

    t = StarredUnpackingTransformer()
    t.visit(ast.parse(code_with_unpacking))

    assert t._tree_changed
    assert ast.dump(ast.parse(expected_code)) == ast.dump(t.root)

# Generated at 2022-06-23 23:01:52.902827
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    class MockNodeTransformer(BaseNodeTransformer):
        # pylint: disable=abstract-method
        def visit_List(self, node):
            pass

    # just to make sure it is not visited in case of no * in list
    tree = ast.parse("[1, 2]")
    StarredUnpackingTransformer(MockNodeTransformer).visit(tree)

    # pylint: disable=line-too-long

# Generated at 2022-06-23 23:01:57.759626
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('print(*range(100))')
    output = transformer.visit(node)
    expected = ast.parse('print(*(list(range(100))))')
    assert ast.dump(output) == ast.dump(expected)



# Generated at 2022-06-23 23:02:08.706326
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    # Object
    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Num(n=1)], ctx=ast.Load())

    # Expected result
    expected_result = ast.BinOp(left=ast.List(elts=[ast.Num(n=2)]), op=ast.Add(), right=ast.Call(func=ast.Name(id='list'), args=[ast.Call(args=[ast.Num(n=10)], keywords=[], func=ast.Name(id='range'))], keywords=[]))

    # Result
    obj = StarredUnpackingTransformer()
    result = obj.visit(node)

    # Assertion
    assert result == expected_result


# Unit

# Generated at 2022-06-23 23:02:14.505771
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
    print(*range(1), *range(3))
    """
    expected_code = """
    print(*(list(range(1)) + list(range(3))))  # noqa
    """
    src = ast.parse(code)
    StarredUnpackingTransformer().visit(src)
    # print(ast.dump(src))
    assert ast.dump(src) == expected_code


# Generated at 2022-06-23 23:02:20.583610
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test = """
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """
    expected = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    """
    node = ast.parse(test)
    StarredUnpackingTransformer().visit(node)
    actual = ast.dump(node)
    assert expected == actual

# Generated at 2022-06-23 23:02:31.517491
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast as pyast  # type: ignore
    import astor  # type: ignore
    code = '''[2, *range(10), 1]'''
    tree = pyast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    new_code = astor.to_source(tree)
    assert new_code == '([2] + list(range(10)) + [1])'

    code = '''print(*range(1), *range(3))'''
    tree = pyast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    new_code = astor.to_source(tree)
    assert new_code == 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-23 23:02:42.838499
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected_source = 'args = [2, *range(10), 1]'

    tree = ast.parse(expected_source, mode='eval')  # type: ast.Module

    refactored_tree = StarredUnpackingTransformer().visit(tree)


# Generated at 2022-06-23 23:02:49.993818
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_node = ast.parse(
        "print(*range(1), *range(3))",
        mode='eval',
    ).body
    expected_call_node = ast.parse(
        "print(*(list(range(1)) + list(range(3))))",
        mode='eval',
    ).body
    call_node = StarredUnpackingTransformer().visit(call_node)
    assert ast.dump(call_node) == ast.dump(expected_call_node)


# Generated at 2022-06-23 23:03:00.725414
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def check(code_before):
        node = ast.parse(code_before)  # type: ignore
        StarredUnpackingTransformer().visit(node)  # type: ignore
        code_after = compile(node, filename="<ast>", mode="exec")
        eval(code_after)

    check("print(2, *range(4), 3)")
    check("print(2, *[1, 2])")
    check("print(2, *[], 3)")
    check("print(2, *range(4), *range(3))")
    check("print(2, *range(4), *range(3), *range(5))")
    check("print(*range(3), 2, *range(1), *range(3))")
    check("print(2)")

# Generated at 2022-06-23 23:03:06.800947
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """\
print(*range(10), *range(3))
"""
    target = """\
print(*(list(range(10)) + list(range(3))))
"""

    tr = StarredUnpackingTransformer()
    result = tr.visit(ast.parse(source))
    assert ast.dump(result) == ast.dump(ast.parse(target))


# Generated at 2022-06-23 23:03:16.054189
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def _test_transform(code: str, expected: str) -> None:
        tree = ast.parse(code)
        transf = StarredUnpackingTransformer()
        tree_transformed = transf.visit(tree)
        code_transformed = compile(tree_transformed, '<string>', 'exec')
        ns = {}
        exec(code_transformed, ns)
        assert ns['result'] == eval(expected)
    code = """
        result = [2, *range(10), 1]
    """
    expected = "[2] + list(range(10)) + [1]"
    _test_transform(code, expected)
    code = """
        result = [2, *range(10), *range(10), 1]
    """

# Generated at 2022-06-23 23:03:21.614380
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    import ast

    expected = "print(*(list(range(1)) + list(range(3))))"

    source = "print(*range(1), *range(3))"
    tree = ast.parse(source)
    new_tree = StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(new_tree) == expected

# Generated at 2022-06-23 23:03:24.011157
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-23 23:03:33.638808
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ast_node = ast.parse('[2, *range(10), 1]')
    assert isinstance(ast_node, ast.Module)
    assert isinstance(ast_node.body[0], ast.Expr)
    assert isinstance(ast_node.body[0].value, ast.List)
    assert isinstance(ast_node.body[0].value.elts[1], ast.Starred)

    assert isinstance(StarredUnpackingTransformer([ast_node]), ast.Module)
    assert isinstance(ast_node.body[0], ast.Expr)
    assert isinstance(ast_node.body[0].value, ast.BinOp)
    assert isinstance(ast_node.body[0].value.left, ast.BinOp)

# Generated at 2022-06-23 23:03:46.046131
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Normal case
    node = ast.List(elts=[ast.Starred(value=ast.Name(id='a')), ast.Name(id='b')])
    new_node = StarredUnpackingTransformer().visit(node)
    assert new_node == ast.BinOp(
        left=ast.List(elts=[]),
        right=ast.List(elts=[ast.Name(id='b')]),
        op=ast.Add()
    )
    # Only `*`
    node = ast.List(elts=[ast.Starred(value=ast.Name(id='a'))])
    new_node = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:03:55.675595
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .testing_utils import make_dummy_code
    from .node_testing_mixin import NodeTestingMixin
    from .starred_unpacking_compile_utils import StarredUnpackingCompileUtils
    from .compiler_class_mixin import CompilerClassMixin
    from .compiler_utils import CompilerUtils
    from .function_compiler import FunctionCompiler
    from .transformer_utils import TransformerUtils
    from .constants_mixin import ConstantsMixin
    from .context_utils import ContextUtils


# Generated at 2022-06-23 23:04:00.134569
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    code = "list(1, *[4, 5])"
    ast_tree = ast.parse(code)
    ast.fix_missing_locations(ast_tree)
    try:
        obj(ast_tree)
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 23:04:07.842550
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import unittest.mock as mock

    tree = {
        'elts': [
            {'value': {'id': 'a'}},
            {'value': {'id': 'b'}},
            {'value': {'id': 'c'}}]}

    expected_tree = ast.List(
        elts=[
            ast.Call(func=ast.Name(id='list'),
                     args=[{'id': 'a'}],
                     keywords=[]),
            ast.List(elts=[{'value': {'id': 'b'}}, {'value': {'id': 'c'}}])])

    transformer = StarredUnpackingTransformer()
    node = ast.parse(str(ast.dump(tree))).body[0]


# Generated at 2022-06-23 23:04:13.200548
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # test: [2, *range(10), 1]
    sut = StarredUnpackingTransformer(None)
    value = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])),
        ast.Num(n=1)
    ])
    actual = sut.visit(value)

# Generated at 2022-06-23 23:04:14.731410
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    s = StarredUnpackingTransformer()
    assert(s)

# Generated at 2022-06-23 23:04:22.856609
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().transform(tree)

# Generated at 2022-06-23 23:04:30.153127
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    a = ast.parse('[2, *range(10), 1]')
    t = StarredUnpackingTransformer()

    # Act
    b = t.visit(a)
    print(ast.dump(b))

    # Assert
    assert eval(compile(b, filename='<ast>', mode='eval')) == eval(compile(a, filename='<ast>', mode='eval'))


# Generated at 2022-06-23 23:04:33.547003
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .codegen import Codegen
    t = StarredUnpackingTransformer()
    t._tree_changed = False
    node = ast.parse('print(*range(1), *range(3))')
    node = t.visit(node)
    assert t._tree_changed == True
    assert str(node) == 'print(*[0, 1, 2])'


# Generated at 2022-06-23 23:04:37.180276
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from typed_ast import ast3
    
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)
    assert isinstance(StarredUnpackingTransformer().visit(ast3.Name()), ast3.Name)

# Generated at 2022-06-23 23:04:48.261223
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    sut = StarredUnpackingTransformer()
    node = ast.parse("print(*range(1), *range(3))")
    assert ast.dump(sut.visit(node)) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load())], keywords=[keyword(arg='start', value=Num(n=1))]), right=Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load())], keywords=[keyword(arg='start', value=Num(n=3))]), op=Add()))], keywords=[]))])"

#

# Generated at 2022-06-23 23:04:51.953568
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]').body[0]) == \
        ast.parse('[2] + list(range(10)) + [1]').body[0]


# Generated at 2022-06-23 23:04:57.774679
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3).target == (3, 3)
    assert StarredUnpackingTransformer(3, 4, 5).target == (3, 5)

    assert not StarredUnpackingTransformer(0).target == (0, 4)
    assert not StarredUnpackingTransformer(0).target == (3, 4)


# Unit Test for method _has_starred

# Generated at 2022-06-23 23:05:04.798684
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    from .ast_utils import parse_to_ast, module_from_ast_list

    source = """
    def test(a, b):
        print(a, b)
    test(*range(1, 5), 7)
    """
    expected_source = """
    def test(a, b):
        print(a, b)
    test(*(list(range(1, 5)) + [7]))
    """

    tree = parse_to_ast(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected_source.strip()

# Generated at 2022-06-23 23:05:12.615801
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
        print(*range(1), *range(3))
        print(range(9), *range(3), range(4), *range(5))
    """

    expected = """
        print(*(list(range(1)) + list(range(3))))
        print(range(9), *((list(range(3)) + list(range(4))) + list(range(5))))
    """

    tree = ast.parse(code)  # type: ignore
    fixer = StarredUnpackingTransformer()
    fixer.visit(tree)
    fixed = astor.to_source(tree)
    assert fixed.replace(' ', '').replace('\r', '').replace('\n', '') == expected.replace(' ', '').replace('\r', '').replace('\n', '')


# Unit test

# Generated at 2022-06-23 23:05:17.850599
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def assertTransformed(node: ast.AST, expected: ast.AST):
        result = StarredUnpackingTransformer().visit(node)
        assert result == expected
        assert ast.dump(result) == ast.dump(expected)

    # test_StarredUnpackingTransformer_visit_Call#1
    print(
        ast.dump(
            StarredUnpackingTransformer().visit(
                ast.parse('print(1, *range(3), 2)')
            ),
            annotate_fields=False,
            include_attributes=False
        )
    )

# Generated at 2022-06-23 23:05:24.941144
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*range(1), *range(3))
print(*range(1))
"""
    expected = """
print(*(list(range(1)) + list(range(3))))
print(*list(range(1)))
"""
    tree = ast.parse(source)
    assert ast.dump(tree) == expected
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected



# Generated at 2022-06-23 23:05:27.893890
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('''print(*range(1), *range(3))''').body[0]
    expected = ast.parse('''print(*(list(range(1)) + list(range(3))))''').body[0]
    StarredUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-23 23:05:39.128147
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(tree)
    expected = ("List([Num(2), Add(Call(Name(id='list', ctx=Load()), [Call(Name(id='range', ctx=Load()), [Num(10)], [])], [], None, None), Num(1))], ctx=Load())")
    assert (str(tree.body[0].value) == expected)
    tree = ast.parse('[2, 3, *range(10), 1, 3, 4]')
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 23:05:47.176887
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    value = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()), ast.Name(id='b'), ast.Name(id='c')],
        keywords=[])
    actual = StarredUnpackingTransformer().visit(value)

    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='a')],
            keywords=[]),
            ctx=ast.Load())],  # +++
        keywords=[])

    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 23:05:50.708843
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    src = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    actual = compile(src, '', 'exec', ast.PyCF_ONLY_AST).body[0]
    StarredUnpackingTransformer().visit(actual)
    actual = ast.Unparse().visit(actual)
    assert actual == expected, actual



# Generated at 2022-06-23 23:05:51.813833
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass


# Generated at 2022-06-23 23:06:00.885581
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import make_nodes
    from .compile import Compile
    from .remove_const_expr import RemoveConstExpr

    for code in [
        """
        print(*range(2), 3, *range(3))
    """
    ]:
        nodes = make_nodes(code)
        nodes = StarredUnpackingTransformer.run(nodes)
        assert isinstance(nodes[0].value.args[0].elts[0], ast.Call)
        nodes = RemoveConstExpr.run(nodes)
        import inspect
        signature = inspect.signature(print)
        signature.bind(Compile.run(nodes))

# Generated at 2022-06-23 23:06:10.571735
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class Source(ast.AST):
        _fields = ("body",)
        _attributes = ("body",)

    class Assignment(ast.AST):
        _fields = ("targets", "value")

    class Unpack(ast.AST):
        _fields = ("elts",)

    sample_expr = ast.List(
        [ast.Num(1), ast.Starred(
            ast.Num(2), ctx=ast.Load())], ctx=ast.Load())

# Generated at 2022-06-23 23:06:21.262726
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
	parser = ast.parse
	transformer = StarredUnpackingTransformer()
	transformed = parser('''
		[2, *range(10), 1]
		print(*range(1), *range(3))''')
	transformer.visit(transformed)

# Generated at 2022-06-23 23:06:23.296286
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert isinstance(StarredUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 23:06:28.565848
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '''
        [2, *range(10), 1]
    '''

    res = '''
        [2] + list(range(10)) + [1]
    '''

    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    assert astor.to_source(node).strip() == res.strip()



# Generated at 2022-06-23 23:06:37.970918
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for 'StarredUnpackingTransformer.visit_Call' method."""
    # Before
    before_source = """
        print(*range(1), *range(3))
        print(1, *range(3))
        print(*range(3), 1)
        print(*range(1, 3), 1)
    """
    before_tree = ast.parse(before_source)

    # After
    after_source = """
        print(*(list(range(1)) + list(range(3))))
        print(1, *(list(range(3))))
        print(*(list(range(3)) + [1]))
        print(*(list(range(1, 3)) + [1]))
    """
    after_tree = ast.parse(after_source)

    # Compare
    transformer = Starred

# Generated at 2022-06-23 23:06:45.484497
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source_code = 'foo(1, *args, 2, *kwargs)'
    expected_code = 'foo(*(list([1]) + list(args) + list([2]) + list(kwargs)))'
    tr = StarredUnpackingTransformer()
    node = ast.parse(source_code)
    tr.visit(node)
    generated_code = compile(node, '<string>', 'exec')
    actual_code = str(generated_code).replace("', '", "',\n'")
    assert actual_code == expected_code


# Generated at 2022-06-23 23:06:47.067597
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer.__name__ == 'StarredUnpackingTransformer'



# Generated at 2022-06-23 23:06:57.420618
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base_transformers_test import BaseNodeTransformerTest
    from .base_transformers import check_ast_nodes_attributes

    tree = ast.parse('[2, *range(10), 1]')

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    check_ast_nodes_attributes(transformer.result)

    BaseNodeTransformerTest.assert_code_equal(transformer.result, '[2] + list(range(10)) + [1]')

    # Test visiting: [1, x, 2]
    tree = ast.parse('[1, x, 2]')

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    check_ast_nodes_attributes(transformer.result)

    BaseNodeTransformerTest.assert_

# Generated at 2022-06-23 23:07:07.950461
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ...visitor import UnitTestVisitor
    from .utils import to_source

    source = """\
        [2, *range(10), 1]
        print(*range(1), *range(3))
    """
    expected = """\
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    """
    src_ast = ast.parse(source)
    expected_ast = ast.parse(expected)
    visitor = UnitTestVisitor(StarredUnpackingTransformer)
    result = visitor.visit(src_ast)

    assert to_source(result) == to_source(expected_ast)

# Generated at 2022-06-23 23:07:18.471263
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseTestTransformer
    from .base import transform_snippet
    from .base import expected

    @expected(
        "test_class_StarredUnpackingTransformer_1",
        "test_class_StarredUnpackingTransformer_2",
    )
    class Test1(BaseTestTransformer):

        T = StarredUnpackingTransformer

        def test_class_StarredUnpackingTransformer_1(self):
            self.assert_transformed_ast(
                transform_snippet(self.T, "print(1, *[2])"),
                "print(*(list([1]) + list([2])))",
            )


# Generated at 2022-06-23 23:07:26.066562
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import ast, typed_ast.ast3

    # input: 1
    # output: 1
    def h(n):
        return n

    # input: 1
    # output: 1
    def i():
        return 1

    # input: 1
    # output: 1
    def j(a, b, c):
        return a, b, c

    tree = ast.parse('h(i())')
    tre = typed_ast.ast3.parse(str(tree))
    tr = StarredUnpackingTransformer().visit(tre)
    s = ast.dump(typed_ast.ast3.parse(str(tr)))

# Generated at 2022-06-23 23:07:30.144470
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(textwrap.dedent('''
    def fn(x):
        print(*range(10), 1, *range(10))
    '''))

    expected_tree = ast.parse(textwrap.dedent('''
        def fn(x):
            print(*(list(range(10)) + [1] + list(range(10))))
    '''))
    node_transformer = StarredUnpackingTransformer()
    extra_args = [sys.argv[0]]
    tree = node_transformer.visit(tree, extra_args)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:07:39.146237
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import assert_code_equal
    from .. import KeywordRemovalTransformer, ParentNodeRemovalTransformer
    source_code = 'print(*range(1), *range(3))'
    expected_code = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(source_code)
    tree = ParentNodeRemovalTransformer().visit(tree)
    tree = StarredUnpackingTransformer().visit(tree)
    tree = ParentNodeRemovalTransformer().visit(tree)
    tree = KeywordRemovalTransformer().visit(tree)
    assert_code_equal(ast.dump(tree), expected_code)


# Generated at 2022-06-23 23:07:50.865582
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print(ast.dump(ast.parse("[2, *range(10), 1]", mode='eval')))
    node1 = ast.parse("[2, *range(10), 1]", mode='eval')
    transformed1 = StarredUnpackingTransformer().visit(node1)
    print(ast.dump(transformed1))
    assert str(transformed1) == "[2] + list(range(10)) + [1]"

    print(ast.dump(ast.parse("[2, 1, *range(10), 1]", mode='eval')))
    node2 = ast.parse("[2, 1, *range(10), 1]", mode='eval')
    transformed2 = StarredUnpackingTransformer().visit(node2)
    print(ast.dump(transformed2))

# Generated at 2022-06-23 23:08:00.586875
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    '''
    Check that StarredUnpackingTransformer works
    '''
    from typed_ast import ast3 as ast
    import astunparse

    def check(source, expected):
        node = ast.parse(source)
        node = StarredUnpackingTransformer().visit(node)
        got = astunparse.unparse(node)
        if got != expected:
            raise AssertionError('TEST FAILED:\n  source:\n{}\n  expected:\n{}\n  got:\n{}'.format(
                source, expected, got
            ))

    check(
        'a = [2, *range(10), 1]',
        'a = [2] + list(range(10)) + [1]',
    )

# Generated at 2022-06-23 23:08:07.247703
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = "l = [2, *range(10), 1]"
    tree = ast.parse(s)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True
    target = "l = [2] + list(range(10)) + [1]"
    assert ast.dump(tree) == ast.dump(ast.parse(target))


# Generated at 2022-06-23 23:08:15.229602
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))").body[0]
    StarredUnpackingTransformer().visit(node)
    assert node.args == [ast.Starred(value=ast.Call(
    func=ast.Name(id='list'),
    args=[ast.Call(
        func=ast.Name(id='range'),
        args=[ast.Num(n=1)],
        keywords=[])],
    keywords=[]) + ast.Call(
    func=ast.Name(id='list'),
    args=[ast.Call(
        func=ast.Name(id='range'),
        args=[ast.Num(n=3)],
        keywords=[])],
    keywords=[]))]

# Generated at 2022-06-23 23:08:15.968308
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:08:21.244868
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_source = "[1, 2, *range(3), 0]"
    node = ast.parse(node_source)
    StarredUnpackingTransformer(node_source).visit(node)
    assert isinstance(node.body[0].value, ast.Add)


# Generated at 2022-06-23 23:08:32.079397
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .StrToBytesTransformer import StrToBytesTransformer
    from .ConvertLiteralsTransformer import ConvertLiteralsTransformer
    from .NewStyleClassesTransformer import NewStyleClassesTransformer
    from .RestorePrintFunctionTransformer import RestorePrintFunctionTransformer
    from .Base64Transformer import Base64Transformer
    from .RemoveStaticmethodTransformer import RemoveStaticmethodTransformer
    from .FixObjectNewMethodTransformer import FixObjectNewMethodTransformer
    from .ImportSelectorTransformer import ImportSelectorTransformer
    from .XRangeToRangeTransformer import XRangeToRangeTransformer
    from .ConvertMethodCallsTransformer import ConvertMethodCallsTransformer
    from .UnicodeToStrTransformer import UnicodeToStrTransformer
    from .ConvertImportsTransformer import ConvertImportsTransformer

# Generated at 2022-06-23 23:08:37.308052
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    module_node = ast.parse('b = [1, 2, *range(3), 7]')
    expected_node = ast.parse('b = [1, 2] + list(range(3)) + [7]')
    synthesizer = StarredUnpackingTransformer()
    synthesizer.visit(module_node)
    assert node_equals_ignore_pos(module_node, expected_node), module_node


# Generated at 2022-06-23 23:08:43.849058
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import compile_visit, assert_ast_equal
    assert_ast_equal(
        StarredUnpackingTransformer,
        '[2, *range(10), 1]',
        'list([2]) + list(range(10)) + list([1])')
    assert_ast_equal(
        StarredUnpackingTransformer,
        '[2, *range(10), 3 * [1]]',
        'list([2]) + list(range(10)) + list([3, *[1]])')

# Generated at 2022-06-23 23:08:55.387684
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Set up
    node = ast.parse("print(*range(1), *range(3))")
    transformer = StarredUnpackingTransformer()

    # Exercise
    result = transformer.visit(node)

    # Verify

# Generated at 2022-06-23 23:09:05.137183
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(code: str, expected: str) -> None:
        module = ast.parse(code)
        StarredUnpackingTransformer().visit(module)
        actual = astor.to_source(module)
        assert actual == expected

    test('foo(2, *range(5), 10)', 'foo(*(([2] + list(range(5))) + [10]))')
    test('foo(2, *range(5), last=10)', 'foo(2, *range(5), last=10)')
    test('foo(2, *range(5), *range(20), last=10)', 'foo(*(([2] + list(range(5))) + list(range(20))), last=10)')



# Generated at 2022-06-23 23:09:06.502027
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()
    assert t is not None


# Generated at 2022-06-23 23:09:08.580535
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    assert isinstance(obj, StarredUnpackingTransformer)


# Generated at 2022-06-23 23:09:10.335685
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-23 23:09:20.614220
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import os
    import ast

    from pyless.transformers.starred_unpacking import StarredUnpackingTransformer

    node = ast.parse(
        '''
target_list = [1, *range(3)]
target_tuple = (1, *range(3))
target_set = {1, *range(3)}
target_dict = {1: 1, *{2: 2, 3: 3}}
target_for_index = [1, *range(3)][2]
target_as_dict_value = {**{1: 1}, *{2: 2, 3: 3}}
''').body[0]
