

# Generated at 2022-06-23 22:59:22.745480
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print()
    print('------------------------------------------------------------')
    print('Running: test_StarredUnpackingTransformer_visit_Call()')
    print('------------------------------------------------------------')
    star = StarredUnpackingTransformer()

    def run(source: str, expected: str):
        print(source)
        node = ast.parse(source)
        star.visit(node)
        # print(ast.dump(node, include_attributes=True))
        assert expected in ast.dump(node, include_attributes=True)


# Generated at 2022-06-23 22:59:26.792076
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    node = ast.parse("print(*range(1), *range(3))")
    transformation = StarredUnpackingTransformer()
    transformation.visit(node)
    assert astor.to_source(node) == "print(*(list(range(1)) + list(range(3))))"

# Generated at 2022-06-23 22:59:31.310921
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """
    [2, *range(10), 1]
    """
    node = astor.parse_file(StringIO(code))
    node = StarredUnpackingTransformer().visit(node)

    assert astor.to_source(node).strip() == "print([2] + list(range(10)) + [1])"

# Generated at 2022-06-23 22:59:41.673920
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Check StarredUnpackingTransformer.visit_List method."""
    from unpythonic.syntax import macros, test, macrotest
    from . import macros as mc

    from .typed_ast_nodes import TList

    from typed_ast.ast3 import Module, parse, dump
    from .base import BaseNodeTransformer
    from .base import compile_nc
    from .base import clone_tree
    from .base import set_context
    from .base import BaseTreeTransformer
    from .context import Context
    import sys

    class M(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return List(elts=[Num(n=1), Num(n=2)])

    source = '[*(1, 2, 3)]'

# Generated at 2022-06-23 22:59:51.054132
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import do_test_node, do_test_tree, iter_tree
    from .base import ast_equal, dump_tree
    from typed_ast import ast3 as ast
    from .visitor import Code

    transformer = StarredUnpackingTransformer()
    for tree in iter_tree("/tests/data/starred_unpacking"):
        if tree['success'] is False:
            with pytest.raises(SyntaxError, match=tree['error']):
                transformer.visit(tree['node'])
        else:
            expected = ast.parse(tree['expected']).body[0]
            assert ast_equal(expected, transformer.visit(tree['node']))

# Generated at 2022-06-23 23:00:00.775238
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Foo:
        def __iter__(self):
            yield 1
            yield 2
            yield 3
            yield 4
            yield 5

    class Bar:
        def __iter__(self):
            yield 6
            yield 7
            yield 8

    SUT = StarredUnpackingTransformer()

    # noinspection PyTypeChecker
    assert isinstance(SUT.visit(ast.parse('[1, *Foo(), *Bar()]').body[0]), ast.List)
    assert ast.dump(ast.parse('[1, *Foo(), *Bar()]', mode='eval')) \
        == ast.dump(
            SUT.visit(ast.parse('[1, *Foo(), *Bar()]').body[0]),
            mode='eval')

# Generated at 2022-06-23 23:00:05.002818
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    statements = [ast.parse("l = [2, *range(10), 1]")]
    expected = [ast.parse("l = [2] + list(range(10)) + [1]")]

    StarredUnpackingTransformer.transform_statements(statements)
    assert statements == expected



# Generated at 2022-06-23 23:00:12.453549
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    trans = StarredUnpackingTransformer()
    
    assert trans.visit(
        ast.Call(func=ast.Name(id='print'),
                 args=[ast.Name(id='a')],
                 keywords=[])
    ) == ast.Call(func=ast.Name(id='print'),
                  args=[ast.Name(id='a')],
                  keywords=[])


# Generated at 2022-06-23 23:00:19.673571
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    visitor = StarredUnpackingTransformer()
    expr = ast.parse("[2, *range(10), 1]")
    visitor.visit(expr)

# Generated at 2022-06-23 23:00:27.900398
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()

    sample = ast.parse('[2, *range(10), 1]', mode='eval').body

    eq_(
        transformer.visit(sample),
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.List(elts=[ast.Num(n=2), ast.Num(n=1)])],
            keywords=[ast.keyword(arg='*', value=ast.Name(id='range')), ast.keyword(arg='', value=ast.Num(n=10))]
        )
    )


# Generated at 2022-06-23 23:00:30.040882
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .impl import StarredUnpackingTransformer
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    actual = StarredUnpackingTransformer.compile(source)
    assert expected == actual

# Generated at 2022-06-23 23:00:38.541090
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = 'print(1, *[], 2, *range(0, 1))'
    tree = ast.parse(code)
    compiler = StarredUnpackingTransformer()
    compiler.visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Name(id='range', ctx=Load()), Num(n=0), Num(n=1)]), op=Add(), right=List(elts=[Num(n=1), Num(n=2)])))], keywords=[]))])"


# Generated at 2022-06-23 23:00:43.893574
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ast_helpers import AssertNodeEqual
    import ast

    transformer = StarredUnpackingTransformer()

    node = ast.parse("some_func(*some_args, *other_args)").body[0]
    expected = ast.parse("some_func(*(list(some_args) + list(other_args)))").body[0]

    new_node = transformer.visit(node)
    assert isinstance(new_node, ast.Call)

    assert_node_equal = AssertNodeEqual()
    assert_node_equal.visit(new_node)
    assert_node_equal.visit(expected)

# Generated at 2022-06-23 23:00:50.256801
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse("""[1, 2, 3, 4, 5]""").body[0].value
    tested = StarredUnpackingTransformer().visit(ast.parse("""[1, *range(2), 3, *range(2), 5]""").body[0].value)
    assert ast.dump(expected) == ast.dump(tested)



# Generated at 2022-06-23 23:01:01.406010
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse("""
print(*range(1), *range(3), sep=' ')
""")

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    assert ast.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=BinOp(left=BinOp(left=List(elts=[Name(id='range', ctx=Load()), Num(n=1)]), right=List(elts=[Name(id='range', ctx=Load()), Num(n=3)]), op=Add()), right=Constant(value=' '), op=Add()))], keywords=[]))])"


# Generated at 2022-06-23 23:01:02.994861
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:01:11.884573
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer(
        source='print(*range(1), *range(3))',
        target=StarredUnpackingTransformer.target)
    t.visit(t.tree)
    result = ast.dump(t.tree, include_attributes=True)

# Generated at 2022-06-23 23:01:22.647999
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    @to_tuple
    def do(code: str) -> ast.AST:
        module = to_ast(code)
        transformer = StarredUnpackingTransformer()
        transformer.visit(module)
        return module


# Generated at 2022-06-23 23:01:31.676590
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('a = [1, *[2], 3]').body[0].value
    assert isinstance(node, ast.List)

    new_node = StarredUnpackingTransformer().visit(node)
    assert isinstance(new_node, ast.BinOp)
    assert new_node.op.__class__.__name__ == 'Add'
    assert new_node.left.elts == [ast.Num(1)]
    assert new_node.right.elts == [ast.Num(3)]
    assert isinstance(new_node.left.elts[0], ast.Num)
    assert isinstance(new_node.right.elts[0], ast.Num)
    assert isinstance(new_node.right.elts[1], ast.Num)


# Generated at 2022-06-23 23:01:42.933422
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    call = ast.parse('print(*[2, 3, *[1, 2], 4])').body[0]
    assert not transformer._has_starred(call.args)

    res = transformer.visit(call)
    assert isinstance(res, ast.Call)
    assert transformer._has_starred(res.args)

    assert len(res.args) == 1
    assert isinstance(res.args[0], ast.Starred)
    assert isinstance(res.args[0].value, ast.BinOp)

    assert isinstance(res.args[0].value.left, ast.List)
    assert len(res.args[0].value.left.elts) == 2


# Generated at 2022-06-23 23:01:48.323119
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Case 1:
    assert str(StarredUnpackingTransformer().visit(ast.parse('[2, *range(10), 1]').body[0])) == str(ast.parse('[2] + list(range(10)) + [1]').body[0])

    # Case 2:
    assert str(StarredUnpackingTransformer().visit(ast.parse('print(*range(1), *range(3))').body[0])) == str(ast.parse('print(*(list(range(1)) + list(range(3))))').body[0])

# Generated at 2022-06-23 23:01:54.405850
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    mod = ast.parse(textwrap.dedent('''\
        [2, *range(10), 1]
        print(*range(1), *range(3))'''))
    expected = ast.parse(textwrap.dedent('''\
        (([2] + list(range(10))) + [1])
        print(*((list(range(1)) + list(range(3)))))'''))

    tr = StarredUnpackingTransformer()
    tr.visit(mod)
    assert(ast.dump(mod) == ast.dump(expected))


if __name__ == "__main__":
    mod = ast.parse(textwrap.dedent('''\
        [2, *range(10), 1]
        print(*range(1), *range(3))'''))
    expected = ast

# Generated at 2022-06-23 23:02:05.584643
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:10.826943
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
        print(1, *range(5))
    """
    expected = """
        print(*(list(range(5)) + [1]))
    """
    transformer = StarredUnpackingTransformer()
    assert transformer.visit(ast.parse(source)) == ast.parse(expected)



# Generated at 2022-06-23 23:02:20.181050
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    call_node = StarredUnpackingTransformer(
        ast.parse('print(*range(1), *range(3))', mode='eval')).visit(ast.parse('print(*range(1), *range(3))', mode='eval'))
    assert isinstance(call_node, ast.Call)
    assert len(call_node.args) == 1
    arg_node = call_node.args[0]
    assert isinstance(arg_node, ast.Starred)
    value_node = arg_node.value
    assert isinstance(value_node, ast.BinOp)
    assert isinstance(value_node.left, ast.List)
    assert isinstance(value_node.right, ast.List)


# Generated at 2022-06-23 23:02:31.363063
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from ast import ast
    from metatools.asttools.visitor import resolve_names
    from metatools.asttools.transformer.wrappers import MethodTransformer, Transformer
    from metatools.asttools.transformer.unpack import StarredUnpackingTransformer

    def n(name):
        return ast.Name(id=name, ctx=ast.Load())

    def call(name, *args):
        return ast.Call(func=n(name), args=args)

    def star(value):
        return ast.Starred(value=value, ctx=ast.Store())

    def binop(left, right, op):
        return ast.BinOp(left=left, right=right, op=op)


# Generated at 2022-06-23 23:02:42.397769
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test StarredUnpackingTransformer._has_starred
    sut = StarredUnpackingTransformer()
    sut_has_starred = sut._has_starred

    # Test StarredUnpackingTransformer._has_starred with List
    assert sut_has_starred([ast.Num(n=1)]) == False
    assert sut_has_starred([ast.Starred(value=ast.Num(n=1), ctx=ast.Load())]) == True

    # Test StarredUnpackingTransformer
    sut = StarredUnpackingTransformer()

    assert sut.visit(ast.parse("[1]", '<string>', "eval")) == ast.parse("[1]", '<string>', "eval")


# Generated at 2022-06-23 23:02:47.870564
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    precode1 = "[2, *range(10), 1]"
    precode2 = "[*range(10), 1, *range(10), 1]"
    precode3 = "[2, *range(10), 1, *range(10), 1]"
    precode4 = "[2, *range(10), 1, *range(10), 1, *range(10), 1]"
    precode5 = "[2, 3, 4, 5]"

    exp_code1 = "[2] + list(range(10)) + [1]"
    exp_code2 = "[] + list(range(10)) + [1] + list(range(10)) + [1]"
    exp_code3 = "[2] + list(range(10)) + [1] + list(range(10)) + [1]"

# Generated at 2022-06-23 23:02:55.890455
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Declare ast tree that we are going to test
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.List(
                    elts=[
                        ast.Num(n=1),
                        ast.Starred(
                            value=ast.List(
                                elts=[
                                    ast.Num(n=2),
                                    ast.Num(n=3)
                                ]
                            )
                        )
                    ]
                )
            ),
            ast.Starred(value=ast.List(elts=[ast.Num(n=4)]))
        ],
        keywords=[]
    )

    # Expected result

# Generated at 2022-06-23 23:03:00.222581
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .ast_utils import dump_ast
    
    code = '''
[2, *range(10), 1]
print(*range(1), *range(3))
'''
    
    expected = '''
[2] + list(range(10)) + [1]
print(*(list(range(1)) + list(range(3))))
'''
    
    
    tree = ast.parse(code)
    expected_tree = ast.parse(expected)
    
    transformed_tree = StarredUnpackingTransformer(tree).visit(tree)
    assert dump_ast(transformed_tree) == dump_ast(expected_tree)

# Generated at 2022-06-23 23:03:11.126099
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = ast.parse('[2, *range(10), 1]')
    t = StarredUnpackingTransformer()
    n_x = t.visit(x)
    print(n_x)
    exec(compile(n_x, '', 'exec'))
# Output:
# Module(body=[Assign(targets=[Name(id='result', ctx=Store())], value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))])


# Generated at 2022-06-23 23:03:18.995712
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse(
'''
print(1, *range(5), 0)
'''
    ).body[0]

    result = StarredUnpackingTransformer().visit(node)
    assert ast.dump(result) == \
        'Call(func=Name(id=\'print\', ctx=Load()), args=[Starred(value=BinOp(left=List(elts=[Num(n=1)]), op=Add(), right=BinOp(left=Call(func=Name(id=\'list\', ctx=Load()), args=[Call(func=Name(id=\'range\', ctx=Load()), args=[Num(n=5)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=0)]))))], keywords=[])'

# Unit

# Generated at 2022-06-23 23:03:29.518625
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    program = ast.parse("[2 * 3]")
    new_program = transformer.visit(program)
    assert transformer.tree_changed
    assert ast.dump(program) != ast.dump(new_program)
    assert ast.dump(new_program) == ast.dump(ast.parse("[2 * 3]"))

    program = ast.parse("[2, *range(10), 1]")
    new_program = transformer.visit(program)
    assert transformer.tree_changed
    assert ast.dump(program) != ast.dump(new_program)
    assert ast.dump(new_program) == ast.dump(ast.parse("[2] + list(range(10)) + [1]"))

    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:03:30.913276
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 23:03:37.406469
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import generate_code
    from .base import generate_ast
    from .base import evaluate_ast
    from .base import compare_source

    code = """
    print(1, *range(10), 1)
    """
    source, tree = generate_code(code)
    assert type(tree) is ast.Module
    evaluate_ast(tree)

    new_tree = StarredUnpackingTransformer().visit(tree)
    assert new_tree is not tree

    new_code = generate_code(new_tree)[0]
    compare_source(new_code, """
    print(*(list((1,)) + list(range(10)) + list((1,))))
    """)



# Generated at 2022-06-23 23:03:45.720831
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse
    from .exprs import parse_expr_and_check
    tree = parse("""
try:
    [2, *range(10), 1]
except Exception:
    (1, *range(10), 2)
    """)
    StarredUnpackingTransformer().visit(tree)
    parse_expr_and_check("""
try:
    [2] + list(range(10)) + [1]
except Exception:
    (1,) + list(range(10)) + (2,)
""")



# Generated at 2022-06-23 23:03:49.437413
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse('[2, *range(10), 1]').body[0].value
    transformed = StarredUnpackingTransformer.run(node)
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0].value
    assert ast.dump(transformed) == ast.dump(expected)


# Generated at 2022-06-23 23:03:55.001749
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    module = ast.parse(
        "lst = [2, *rng, 1]\n"
        "print(*rng1, *rng2)\n")

    StarredUnpackingTransformer().visit(module)

    assert str(module) == '''\
lst = list(range(2)) + list(rng) + list(range(1))
print(*(list(rng1) + list(rng2)))
'''

# Generated at 2022-06-23 23:03:59.152312
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = ast.parse("[2, 3, 4]")
    node = ast.parse("[2, *[3, 4]]")
    new_node = StarredUnpackingTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(new_node)


# Generated at 2022-06-23 23:04:07.273631
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:04:18.501524
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    trans = StarredUnpackingTransformer()
    call_node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(1.0)], keywords=[]),
              ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(3.0)], keywords=[])),
              ast.Num(42)],
        keywords=[])

# Generated at 2022-06-23 23:04:27.132704
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor

    def test(source: str, expected: str):
        tree = ast.parse(source)
        StarredUnpackingTransformer().visit(tree)

        astor.dump_tree(tree)
        print(expected)

        assert astor.to_source(tree) == expected

    test('[1, 2]', '[1, 2]')
    test('[1, *range(10), 2]', '[1] + list(range(10)) + [2]')
    test('baz(**bar(*args), **k)', ('baz(**(dict(*args) + dict(k)))'))

# Generated at 2022-06-23 23:04:28.646920
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None



# Generated at 2022-06-23 23:04:31.457522
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source, assert_node_equal
    source = '[2, *range(10), 1]'
    expected = ast.parse('[2] + list(range(10)) + [1]')
    result = compile_source(source, [StarredUnpackingTransformer])
    assert_node_equal(result, expected)


# Generated at 2022-06-23 23:04:35.980273
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    node = ast.parse('print(*range(1), *range(3))').body[0]
    visitor = StarredUnpackingTransformer()
    visitor.visit(node)
    assert astor.to_source(node).strip() == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-23 23:04:39.097069
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    expected = '''[2] + list(range(10)) + [1]'''
    tree = ast.parse('[2, *range(10), 1]')
    assert str(StarredUnpackingTransformer().visit(tree)) == expected


# Generated at 2022-06-23 23:04:45.347748
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_call = ast.parse("print(*range(1), *range(3))".strip()).body[0]
    input_list = ast.parse("[2, *range(10), 1]".strip()).body[0]
    expected_call = ast.parse("print(*(list(range(1)) + list(range(3))))".strip()).body[0]
    expected_list = ast.parse("[2] + list(range(10)) + [1]".strip()).body[0]

    transformer = StarredUnpackingTransformer()

    assert ast.dump(expected_call, include_attributes=False) == ast.dump(transformer.visit(input_call), include_attributes=False)

# Generated at 2022-06-23 23:04:53.871102
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()
    assert obj.__class__.__name__ == 'StarredUnpackingTransformer'

    assert obj._has_starred([]) == False
    assert obj._has_starred([ast.Num(n=0)]) == False
    assert obj._has_starred([ast.Starred(value=ast.Name(id='a'))]) == True
    assert obj._has_starred([ast.Num(n=0), ast.Starred(value=ast.Name(id='a')), ast.Num(n=1)]) == True

    list_of_ast_expr = [ast.Num(n=0), ast.Starred(value=ast.Name(id='a')), ast.Num(n=1), ast.Starred(value=ast.Name(id='b'))]

# Generated at 2022-06-23 23:05:03.209238
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    source = '''
        def f(a, *b, c):
            return c

        f(1, *[2], *range(3), c=4)
        f(1, *[2], *range(3), c=4, *range(4))
    '''

    expected = '''
        def f(a, *b, c):
            return c

        f(*(list([2]) + list(range(3)) + [4]))
        f(*(list([2]) + list(range(3)) + [4] + list(range(4))))
    '''

    actual = StarredUnpackingTransformer().visit(ast.parse(source))
    compare_ast(actual, expected)



# Generated at 2022-06-23 23:05:08.109902
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()

    # Example from doc of this class
    call_node = ast.parse('print(*range(1), *range(3))').body[0]
    result = visitor.visit(call_node)
    target = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]
    assert ast.dump(result) == ast.dump(target)

    # Check if [2, *range(10), 1] is translated to
    # [2] + list(range(10)) + [1]
    list_node = ast.parse('[2, *range(10), 1]').body[0]
    result = visitor.visit(list_node)

# Generated at 2022-06-23 23:05:12.824500
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = """
        print(*range(1), *range(3))
    """
    
    y = """
        print(*(list(range(1)) + list(range(3))))
    """
    assert StarredUnpackingTransformer().visit(ast.parse(x)) == StarredUnpackingTransformer().visit(ast.parse(y))


# Generated at 2022-06-23 23:05:15.673040
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = 'print(*range(3), 2, *range(3), 2)'
    expected = 'print(*(([2] + list(range(3))) + [2]))'
    tree = ast.parse(source)
    transformed_tree = StarredUnpackingTransformer().visit(tree)

    assert expected == astor.to_source(transformed_tree).strip()

# Generated at 2022-06-23 23:05:23.650385
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()

    # This is the code that was introduced in Python 3.5,
    # which allows using starred expressions in list and set
    # comprehensions as in "a = [*range(10), 0, *[1], *range(5)]".
    #
    # This is the code that was introduced in Python 3.5,
    # which allows using starred expressions in list and set
    # comprehensions as in "a = [*range(10), 0, *[1], *range(5)]".
    input_code = """
a = [2, *range(10), 1]
b = [*range(1), *range(3)]
c = [1, *range(2), 3]
d = [*range(5), 1, 2, *range(3)]
"""

# Generated at 2022-06-23 23:05:30.136563
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as ast

    source = """x = [0, *a, 1]"""
    expected = """
x = [0] + list(a) + [1]
"""

    module = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    new_module = transformer.visit(module)
    assert transformer.tree_changed
    assert ast.dump(new_module) == expected.strip()

# Generated at 2022-06-23 23:05:32.485009
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ast.parse("""
[2, *range(10), 1]
print(*range(1), *range(3))
""")

# Generated at 2022-06-23 23:05:38.448506
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    l = StarredUnpackingTransformer(
        'foo.py',
        """
        a = [2, *range(10), 1]
        print(*range(1), *range(3))
        """
    )
    assert l is not None
    assert isinstance(l, StarredUnpackingTransformer)

# Generated at 2022-06-23 23:05:44.281006
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    __tracebackhide__ = True
    class UnitTestStarredUnpackingTransformer_visit_Call(unittest.TestCase):
        def setUp(self):
            self.transformer = StarredUnpackingTransformer()
        def test_call_with_args(self):
            node = ast.parse("print(*range(1), *range(3))").body[0]
            self.assertEqual(
                self.transformer.visit(node),
                ast.parse("print(*(list(range(1)) + list(range(3))))").body[0])

        def test_call_without_args(self):
            node = ast.parse("print()").body[0]
            self.assertEqual(
                self.transformer.visit(node),
                ast.parse("print()").body[0])

# Generated at 2022-06-23 23:05:48.902204
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    x = ast.parse("[2, *range(10), 1]")
    res = StarredUnpackingTransformer().visit(x)
    res_str = ast.dump(res)
    assert 'BinOp' in res_str
    assert 'Call' in res_str


# Generated at 2022-06-23 23:05:52.092388
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]").body[0].value
    result = StarredUnpackingTransformer().visit(node)
    expected = ast.parse("[2] + list(range(10)) + [1]").body[0].value
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 23:05:59.955765
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as pyast
    from cpylighter.compilers.ast_compiler import ASTCompiler

    source = "[1, 2, 3, *[4, 5, 6], 7, 8]"

    compiler = ASTCompiler()
    tree = pyast.parse(source)
    compiler.visit(tree)

    source_after = "([1, 2, 3] + [4, 5, 6] + [7, 8])"
    tree_after = pyast.parse(source_after)
    assert pyast.dump(tree_after) == pyast.dump(tree)

# Generated at 2022-06-23 23:06:09.704513
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class TestTransformer(StarredUnpackingTransformer):
        def _has_starred(self, xs: List[ast.expr]):
            return False

        def _split_by_starred(self, xs: Iterable[ast.expr]):
            return xs

        def _prepare_lists(self, xs: List[Splitted]):
            return xs

        def _merge_lists(self, xs: List[ListEntry]):
            return xs

    t = TestTransformer()
    n = compile("[2, *range(10), 1]", filename="<test>", mode="eval")
    node = ast.parse(n)
    node_new = t.visit(node)

# Generated at 2022-06-23 23:06:14.648073
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse("[2, *range(10), 1]")
    tree2 = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)
    StarredUnpackingTransformer().visit(tree2)
    print(ast.dump(tree))
    print(ast.dump(tree2))

#test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:06:15.618473
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer((3,7))

# Generated at 2022-06-23 23:06:27.219985
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # [2, *range(10), 1]
    # print(*range(1), *range(3))
    # to
    # [2] + list(range(10)) + [1]
    # print(*(list(range(1)) + list(range(3))))
    # new_tree, tree_changed = StarredUnpackingTransformer(t1).visit(t1)
    # new_tree, tree_changed = StarredUnpackingTransformer(t2).visit(t2)
    t1 = ast.parse('[2, *range(10), 1]')
    t2 = ast.parse('print(*range(1), *range(3))')
    # new_tree, tree_changed = StarredUnpackingTransformer(t1).visit(t1)
    # new_tree, tree_changed =

# Generated at 2022-06-23 23:06:28.235156
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-23 23:06:36.448166
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    input_code = """
    def func(arg_0):
        print(arg_0)
    func(*[1, 2, 3, 4])
    """
    node = ast.parse(input_code)
    StarredUnpackingTransformer().generic_visit(node)
    expected_output_code = """
    def func(arg_0):
        print(arg_0)
    func(*list([1, 2, 3, 4]))
    """
    expected_node = ast.parse(expected_output_code)
    assert ast.dump(node) == ast.dump(expected_node)


# Generated at 2022-06-23 23:06:42.093359
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from ... import testing
    from . import ast_converter

    code = '''
        print(*args)
    '''
    tree = testing.load_module(code)
    expected = '''
        print(*(list(args)))
    '''
    result = StarredUnpackingTransformer().visit(tree)
    assert expected == ast_converter.dump_python_source(result)

    code = '''
        a(*args, *args2, *args3, *args4)
    '''
    tree = testing.load_module(code)
    expected = '''
        a(*(list(args) + list(args2) + list(args3) + list(args4)))
    '''
    result = StarredUnpackingTransformer().visit(tree)
    assert expected == ast_conver

# Generated at 2022-06-23 23:06:43.994565
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("test_StarredUnpackingTransformer")

    # Test constructor function.

    star_transformer = StarredUnpackingTransformer()

    # Test instance attributes.

    assert star_transformer.tree_changed == False
    assert star_transformer.target == (3, 4)

# Unit tests for _has_starred private method of class StarredUnpackingTransformer.

# Generated at 2022-06-23 23:06:54.710773
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
    [1, *range(10), 2]
    """
    tree = ast.parse(source)
    compiled = StarredUnpackingTransformer().visit(tree)
    print(ast.dump(compiled))

# Generated at 2022-06-23 23:07:05.716935
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node1 = ast.parse('[2, *range(10), 1]').body[0].value
    result1 = StarredUnpackingTransformer().visit(node1)
    assert ast.dump(result1) == "BinOp(left=List(elts=[Num(n=2)], ctx=Load()), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[], starargs=None, kwargs=None)], keywords=[], starargs=None, kwargs=None), op=Add(), right=List(elts=[Num(n=1)], ctx=Load())))"

# Generated at 2022-06-23 23:07:17.378233
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    input = """\
foo = [1, 2, 3, 4, 5]
bar = [6, 7, 8, 9, 10]
baz = [11, 12, 13, 14, 15]

x = [foo, bar, baz]
y = [*foo, *bar, *baz]
z = [*x]
u = [*x, *y]
"""

# Generated at 2022-06-23 23:07:25.401727
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test 1. Test with empty list
    test_List_1 = ast.List(elts=[], ctx=ast.Load())
    expected_List_1 = ast.List(elts=[], ctx=ast.Load())
    actual_List_1 = StarredUnpackingTransformer().visit(test_List_1)
    assert ast.dump(expected_List_1) == ast.dump(actual_List_1)

    # Test 2. Test with list without starred
    test_List_2 = ast.List(elts=[ast.Num(n=2), ast.Num(n=3)], ctx=ast.Load())
    expected_List_2 = ast.List(elts=[ast.Num(n=2), ast.Num(n=3)], ctx=ast.Load())
    actual_List_2

# Generated at 2022-06-23 23:07:26.041186
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:07:33.090688
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    with open(__file__, 'r') as f_in:
        source = f_in.read()
    source = source.split('# Unit test for method visit_Call of class StarredUnpackingTransformer')[0]
    tree = ast.parse(source)

    mod = StarredUnpackingTransformer(tree)
    mod.visit(tree)
    new_source = ast.fix_missing_locations(tree)
    exec(compile(new_source, __file__, mode='exec'))



# Generated at 2022-06-23 23:07:36.107230
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '''
        [2, *range(10), 1]
    '''
    expected = '''
        [2] + list(range(10)) + [1]
    '''
    result = get_converted(StarredUnpackingTransformer, source)
    assert_equal(result, expected)


# Generated at 2022-06-23 23:07:43.760555
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from .transformers import get_source
    from .base import get_transformer_source

    tree = ast.parse('[2, *range(10), 1]')
    actual = get_source(tree)
    assert actual == 'x = [2, *range(10), 1]'  # type: ignore
    transformer = get_transformer_source(StarredUnpackingTransformer, tree)
    assert transformer == 'x = [2] + list(range(10)) + [1]'



# Generated at 2022-06-23 23:07:49.451584
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_case = [
        (
            '[None]',
            '[None]',
        ),
        (
            '[*range(10)]',
            '[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]',
        ),
        (
            '[1, *range(10), 1]',
            '[1] + list(range(10)) + [1]',
        ),
        (
            '[1, *range(10), 1, 2]',
            '[1] + list(range(10)) + [1, 2]',
        ),
        (
            '[1, *range(10), 1, 2, *range(3)]',
            '[1] + list(range(10)) + [1, 2] + list(range(3))',
        ),
    ]


# Generated at 2022-06-23 23:07:53.660043
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse("[2, *range(10), 1]")
    result = transformer.visit(node.body[0])
    expected = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(result) == ast.dump(expected.body[0])


# Generated at 2022-06-23 23:08:05.357916
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("""
        print(*[2, 3], 4, *[5, 6])
    """)
    StarredUnpackingTransformer().visit(tree)
    body = tree.body
    assert len(body) == 1
    assert isinstance(body[0], ast.Expr)
    expr = body[0].value
    assert isinstance(expr, ast.Call)
    assert len(expr.args) == 1
    assert isinstance(expr.args[0], ast.Starred)
    starred = expr.args[0].value
    assert isinstance(starred, ast.BinOp)
    assert starred.op.__class__ == ast.Add
    assert isinstance(starred.left, ast.List)
    assert isinstance(starred.right, ast.Call)

# Generated at 2022-06-23 23:08:14.389012
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .nodes import PythonNode
    from .tree import Tree

    test_str = """def foo(a, b, c, d, e):
    a, *b, c = d, *e
    f, *g, h = i, *j
    k, *l = m, *n
    o, *p, q = 1, 2, 3, 4
    r, *s, t = *u
    v, *w, x = [1, 2, 3, 4], *y
    z, *aa, bb, *cc, dd, ee = *[1, 2, 3, 4], *[5, 6]"""

# Generated at 2022-06-23 23:08:25.962295
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test case 1:
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('a = [2, *range(10), 1]')
    transformer.visit(tree)
    expected = 'a = [2] + list(range(10)) + [1]'
    expected_tree = ast.parse(expected)
    assert ast.dump(tree) == ast.dump(expected_tree)
    # Test case 2:
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('print(*range(1), *range(3))')
    transformer.visit(tree)
    expected = 'print(*(list(range(1)) + list(range(3))))'
    expected_tree = ast.parse(expected)
    assert ast.dump(tree) == ast.dump(expected_tree)




# Generated at 2022-06-23 23:08:35.348899
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Set up testing variables
    tree = ast.parse("[2, *range(10), 1]")
    transformer = StarredUnpackingTransformer()
    # Run the program
    result = transformer.visit(tree)
    # Verify the results
    assert ast.dump(result) == "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))])"

# Generated at 2022-06-23 23:08:36.858065
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(3, 4).target == (3, 4)

# Generated at 2022-06-23 23:08:47.444876
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test_func(a, b, c, d, e, f=1, g=2, h=3, i=4):
        ...


# Generated at 2022-06-23 23:08:59.024859
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    tree = StarredUnpackingTransformer().visit(tree)
    assert type(tree.body[0].value) is ast.BinOp
    assert type(tree.body[0].value.left) is ast.List
    assert type(tree.body[0].value.right) is ast.Call
    assert type(tree.body[0].value.right.args[0].value) is ast.List
    assert type(tree.body[0].value.right.args[0].value.elts[0]) is ast.Name
    assert tree.body[0].value.right.args[0].value.elts[0].id == 'range'

# Generated at 2022-06-23 23:09:04.913171
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .parser import parse
    from .transformer_test_case import TransformerTestCase


# Generated at 2022-06-23 23:09:10.430909
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree_orig = ast.parse("[2, *range(10), 1]")
    tree_expected = ast.parse("[2] + list(range(10)) + [1]")
    tree_actual = StarredUnpackingTransformer().visit(tree_orig)
    assert ast.dump(tree_expected) == ast.dump(tree_actual)



# Generated at 2022-06-23 23:09:16.647448
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import dump
    node = ast.parse('[2, *range(10), 1]').body[0]
    transformer = StarredUnpackingTransformer()
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0]
    # assert dump(transformer.visit(node)) == dump(expected)
    assert dump(transformer.visit(node)) == dump(expected)

