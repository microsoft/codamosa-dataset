

# Generated at 2022-06-23 22:59:17.821785
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor, ast

    node1 = ast.List(
        elts=[
            ast.Num(n=2),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range', ctx=ast.Load()),
                    args=[ast.Num(n=10)],
                    keywords=[])),
            ast.Num(n=1)],
        ctx=ast.Load())

    node2 = StarredUnpackingTransformer().visit(node1)
    assert isinstance(node2, ast.BinOp)
    assert astor.to_source(node2).strip() == '[2] + list(range(10)) + [1]'


# Generated at 2022-06-23 22:59:23.631330
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    input_str = "[1, *range(10)]"
    input_ast = ast.parse(input_str)

    expected_str = "[1] + list(range(10))"
    expected_ast = ast.parse(expected_str)

    actual_ast = StarredUnpackingTransformer().visit(input_ast)
    assert ast_equal(expected_ast, actual_ast)


# Generated at 2022-06-23 22:59:27.955072
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))').body[0]
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]

    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-23 22:59:32.859500
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected_code = """[2] + list(range(10)) + [1]"""
    actual_code = StarredUnpackingTransformer.run_test(
        code, 'test_StarredUnpackingTransformer_visit_List')
    assert actual_code == expected_code, "expected %s, got %s" % (expected_code, actual_code)


# Generated at 2022-06-23 22:59:43.547156
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import typed_ast.ast3 as ast
    from ..utils import dump
    transform = StarredUnpackingTransformer()
    args = [ast.Num(1), ast.Starred(ast.Name('a'), ast.Load())]
    #print(dump(StarredUnpackingTransformer().visit_List(ast.List(args, ast.Load()))))
    res = transform.visit_List(ast.List(args, ast.Load()))
    print("***"*50)
    print(dump(res))
    print("***"*50)
    res = transform.visit_List(ast.List(args, ast.Load()))
    print("***"*50)
    print(dump(res))
    print("***"*50)



test_StarredUnpackingTransformer()

# Generated at 2022-06-23 22:59:54.215663
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 22:59:58.071089
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    target = [2, *range(10), 1]
    expected = [2] + list(range(10)) + [1]

    node_transformer = StarredUnpackingTransformer()
    result = node_transformer.visit(target)

    assert result == expected

# Generated at 2022-06-23 23:00:03.102530
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]").body[0].value
    result = StarredUnpackingTransformer().visit(node)
    expected = ast.parse("[2] + list(range(10)) + [1]").body[0].value
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-23 23:00:12.500517
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astunparse
    import astor

    # Provided by user
    # ast_source = astunparse.unparse(ast.parse(
    # """
    # v = [2, *range(10), 1]
    # print(*range(1), *range(3))
    # """))

    # New astor
    ast_source = astor.to_source(ast.parse(
    """
    v = [2, *range(10), 1]
    print(*range(1), *range(3))
    """))
    print("Original:")
    print(ast_source)

    # Copy constructor
    source_tree = ast.parse(ast_source)
    source_tree = StarredUnpackingTransformer().visit(source_tree)

    result = astor.to_source(source_tree)


# Generated at 2022-06-23 23:00:14.636306
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()


# Generated at 2022-06-23 23:00:20.754449
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('StarredUnpackingTransformer.visit_Call:')
    code = """\
xs = [*range(1), *range(10)]  # type: ignore
print(*xs)
"""
    expected = """\
import builtins as __builtin__
__sum0__ = list(range(1))
__sum1__ = list(range(10))
xs = __sum0__ + __sum1__
print(*(xs))
"""
    _test(StarredUnpackingTransformer, code, expected)


# Generated at 2022-06-23 23:00:22.265093
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(tree_changed=False)._tree_changed == False


# Generated at 2022-06-23 23:00:28.675295
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    print("*" * 10, "Visit List start")
    expected_code = '[2] + range(10) + [1]'
    node = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(node)
    assert expected_code == astor.to_source(node).strip()
    print("*" * 10, "Visit List end")


# Generated at 2022-06-23 23:00:32.764112
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import UnitTestTransformer

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    transformer = UnitTestTransformer(StarredUnpackingTransformer)
    result = transformer.visit_test_data(code)
    assert result == expected



# Generated at 2022-06-23 23:00:41.091013
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTest
    from .utils import get_ast

    test = BaseNodeTransformerTest(StarredUnpackingTransformer)
    test.test(get_ast("[2, *range(10), 1]"), "[2] + list(range(10)) + [1]")
    test.test(get_ast("[1, 2, 3, *range(10)]"), "[1, 2, 3] + list(range(10))")
    test.test(get_ast("[*range(10), 2, 1]"), "list(range(10)) + [2, 1]")
    test.test(get_ast("[3, *range(10), *range(1)]"), "[3] + list(range(10)) + list(range(1))")

# Generated at 2022-06-23 23:00:53.060202
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from astor.code_gen import to_source
    from astor.source_repr import unparse
    from mtots.parser import mtots_to_ast, ast_to_mtots
    from mtots.util import ast_debug

    def check(input, expected):
        tr = StarredUnpackingTransformer()
        actual = tr.visit(input)
        expected_src = to_source(expected)
        actual_src = unparse(actual)
        assert expected_src == actual_src
        return actual

    a = mtots_to_ast('''
        [1, 2, *[3, 4], 5, 6]
    ''')
    b = mtots_to_ast('''
        [1, 2] + list([3, 4]) + [5, 6]
    ''')


# Generated at 2022-06-23 23:01:04.337989
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast
    import json
    import io, sys
    from dlx import ast_transforms, ast_utils

    print('original code:')
    print('''\
import tensorflow as tf

# 这是注释
# 这是注释
a = [1, *range(10), 2]
print(*range(10))
print('test: ', *range(10))
print(*range(10), *range(5))
''')
    print('\n')
    # original code:
    # import tensorflow as tf
    #
    # # 这是注释
    # # 这是注释
    # a = [1, *range(10), 2]
    # print(*range(10))
    # print('test: ', *

# Generated at 2022-06-23 23:01:12.604399
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return self.generic_visit(node)

    node = ast.parse("[2, *range(10), 1]")
    tree_changed, node = TestTransformer().visit(node)
    assert tree_changed
    # ast.dump(node)

# Generated at 2022-06-23 23:01:19.400298
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("""
a = 1
b = 2
print(a, *range(1), b, *range(2))
""")
    StarredUnpackingTransformer().visit(tree)
    expected = ast.parse("""
a = 1
b = 2
print(*(a, *list(range(1)), b, *list(range(2))))
""")
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-23 23:01:28.359130
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    i = ast.parse("print('hello', *['world'])").body[0]
    assert i.__repr__() == "Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Str(s='hello'), Starred(value=List(elts=[Str(s='world')], ctx=Load()))], keywords=[]))"
    assert StarredUnpackingTransformer(None).visit(i).__repr__() == "Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=Call(func=Name(id='list', ctx=Load()), args=[List(elts=[Str(s='world')], ctx=Load())], keywords=[]))], keywords=[]))"

# Generated at 2022-06-23 23:01:36.167026
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Name(id='range')),
            ast.Starred(
                value=ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(3)],
                    keywords=[])),
        ],
        keywords=[])


# Generated at 2022-06-23 23:01:45.956628
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))").body[0]
    expected = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.BinOp(left=ast.List(elts=[ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[])], keywords=[])]), right=ast.List(elts=[ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[])], keywords=[])]), op=ast.Add()))], keywords=[])


# Generated at 2022-06-23 23:01:53.070940
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print("test_StarredUnpackingTransformer")
    tester = StarredUnpackingTransformer()
    example_tree = ast.parse("print(3, *range(3), *range(100), sep=' ')", mode="eval")
    transformed_tree = tester.visit(example_tree)
    # print(ast.dump(transformed_tree))

# Generated at 2022-06-23 23:01:56.736789
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('print(*range(10))')
    StarredUnpackingTransformer().visit(tree)
    code = compile(tree, '', 'exec')
    assert code.co_code == b"d\x01\x00d\x02\x00\x83\x01}\x01\x00d\x02\x00S"

# Generated at 2022-06-23 23:02:07.672829
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import FakeTree
    from typed_ast import ast3 as ast

    source = 'print(*range(1), 2, *range(3))'
    tree = ast.parse(source)

    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert ast.dump(new_tree) == ast.dump(ast.parse("print(*(list(range(1)) + [2] + list(range(3))))"))

    transformer = StarredUnpackingTransformer()
    new_tree = transformer.visit(ast.parse("[2, *range(10), 1]"))
    assert transformer.tree_changed is True

# Generated at 2022-06-23 23:02:12.380259
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)
    expected_tree = ast.parse("[2] + list(range(10)) + [1]")
    assert ast.dump(expected_tree) == ast.dump(tree)



# Generated at 2022-06-23 23:02:13.847894
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3,4)

# Generated at 2022-06-23 23:02:23.306767
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Example 1 (List)
    example1_expected = """
        [2] + list(range(10)) + [1]
        """
    example1_input = """
        [2, *range(10), 1]
        """
    result1 = compile(
        example1_input,
        filename="<test_StarredUnpackingTransformer>",
        mode="exec"
    )
    assert str(StarredUnpackingTransformer(result1).module).rstrip() == example1_expected.rstrip()

    # Example 2 (Call)
    example2_expected = """
        print(*(list(range(1)) + list(range(3))))
        """
    example2_input = """
        print(*range(1), *range(3))
        """

# Generated at 2022-06-23 23:02:32.013172
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    code = """
foo([1, *range(2), 3], *range(20), **dict(b=2))
"""
    new_code = """
foo(list([1] + list(range(2)) + [3]) + list(range(20)), **dict(b=2))
"""
    root = ast.parse(code)
    expected = ast.parse(new_code)
    result = StarredUnpackingTransformer().visit(root)
    assert astor.to_source(result) == new_code

# Generated at 2022-06-23 23:02:38.854353
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(tree)
    assert CodeGen().visit(tree) == '[2] + list(range(10)) + [1]'

    tree = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree)
    assert CodeGen().visit(tree) == 'print(*(list(range(1)) + list(range(3))))'

# Generated at 2022-06-23 23:02:46.449798
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    test_input = '''
        [2, *range(10), 1]
        '''
    test_output = '''
        [2] + list(range(10)) + [1]
        '''
    expected = ast.parse(test_output)
    node = ast.parse(test_input)
    # When
    actual = StarredUnpackingTransformer().visit(node)
    # Then
    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-23 23:02:51.939184
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'

    tree = ast.parse(code)
    func_transformer = StarredUnpackingTransformer()
    func_transformer.visit(tree)

    result_code = astunparse.unparse(tree)
    assert result_code == expected_code


# Generated at 2022-06-23 23:03:04.219934
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    ft = StarredUnpackingTransformer()
    assert_equals_ast(ft.visit(ast.parse('print(1, 2, 3)')),
                      ast.parse('print(1, 2, 3)'))

    assert_equals_ast(ft.visit(ast.parse('print(1, 2, 3, *range(3))')),
                      ast.parse('print(1, 2, 3, *list(range(3)))'))

    assert_equals_ast(ft.visit(ast.parse('print(*range(3), 1, 2, 3, *range(3))')),
                      ast.parse('print(*(list(range(3)) + list([1, 2, 3]) + list(range(3))))'))


# Generated at 2022-06-23 23:03:09.680542
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    utils.assert_source_equal(
        "{}".format(compile('a(1, *range(10), 2)', mode='eval', flags=ast.PyCF_ONLY_AST)),
        "{}".format(StarredUnpackingTransformer().visit(utils.get_ast("a(1, *range(10), 2)")))
    )


# Generated at 2022-06-23 23:03:13.947161
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    module = ast.parse(source)
    StarredUnpackingTransformer().visit(module)
    expected = "[2] + list(range(10)) + [1]"
    assert ast.dump(module) == ast.dump(ast.parse(expected))


# Generated at 2022-06-23 23:03:19.548984
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    actual = transformer.visit(ast.parse(source))
    assert actual != None
    actual = ast.dump(actual)
    assert actual != None
    assert expected in actual


# Generated at 2022-06-23 23:03:23.039237
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = """
print(*[1, 2], 3, *range(10))
"""
    expected_result = """
list([1, 2]) + [3] + list(range(10))
"""
    assert expected_result.strip() == _exec(source).strip()



# Generated at 2022-06-23 23:03:24.011412
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()


# Generated at 2022-06-23 23:03:27.792441
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import run_transformer_on_input
    from .list_comp import ListComprehensionTransformer
    from .dict_comps import DictComprehensionTransformer
    from .set_literal import SetLiteralTransformer


# Generated at 2022-06-23 23:03:35.868503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Name(id='range'), ctx=ast.Load(lineno=0, col_offset=0))],
        keywords=[])
    
    processed_node = StarredUnpackingTransformer().visit(node)
    expected_node = ast.Call(
        func=ast.Name(id='print'),
        args=[ast.Starred(value=ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Name(id='range')],
            keywords=[]), ctx=ast.Load(lineno=0, col_offset=0))],
        keywords=[])
    
    assert ast.dump(processed_node, include_attributes=True) == ast.dump

# Generated at 2022-06-23 23:03:40.211066
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import parse
    from .test_utils import capture_out
    from .visitors import NodeVisitor
    # arrange
    qualname = 'StarredUnpackingTransformer.visit_Call'

# Generated at 2022-06-23 23:03:45.505003
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from test.parser_test import get_ast

    results = get_ast('print(*range(1), *range(3))')
    expec = get_ast('print(*(list(range(1)) + list(range(3))))')

    tran = StarredUnpackingTransformer()
    assert tran.visit(results) == expec


# Generated at 2022-06-23 23:03:55.156429
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('''
xs = [1, *range(10), 1]
''').body[0]
    StarredUnpackingTransformer().visit(tree)  # type: ignore
    assert ast.dump(tree) == "Assign(targets=[Name(id='xs', ctx=Store())], value=BinOp(left=BinOp(left=List(elts=[Num(n=1)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)]), op=Add()))"


# Generated at 2022-06-23 23:04:00.815402
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transform = StarredUnpackingTransformer()
    original = ast.parse("""func(1, 2, *x, 3, 4, *y, 5)""").body[0]
    expected = ast.parse("""func(*(list([1,2])+list(x)+list([3,4])+list(y)+list([5])))""").body[0]
    assert str(transform.visit(original)) == str(expected)


# Generated at 2022-06-23 23:04:05.292749
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import parse
    from typed_ast import ast3 as ast
    s = """
print(1, 2, *i, *range(3), 4, 5)
l = [1, 2, 3, *range(4)]
    """
    tree = parse(s).body
    # print(ast.dump(tree))
    print(ast.dump(StarredUnpackingTransformer().visit(tree)))
    assert StarredUnpackingTransformer().visit(tree) == tree

# Generated at 2022-06-23 23:04:17.288591
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node_1 = ast.List(elts=[
        ast.Starred(value=ast.Name(id='a', ctx=ast.Load()), ctx=ast.Load()),
        ast.Starred(value=ast.Name(id='b', ctx=ast.Load()), ctx=ast.Load()),
        ast.Starred(value=ast.Name(id='c', ctx=ast.Load()), ctx=ast.Load())
    ])

# Generated at 2022-06-23 23:04:27.292156
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Test(StarredUnpackingTransformer):
        def visit(self, node: ast.AST) -> ast.AST:
            return super().visit(node)

    rng1 = ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=1)], keywords=[])
    rng3 = ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=3)], keywords=[])
    src = ast.Call(func=ast.Name(id='print'), args=[rng1, ast.Starred(value=rng3)], keywords=[])
    compiler = Test()
    compiler.visit(src)
    assert compiler._tree_changed


# Generated at 2022-06-23 23:04:28.879030
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()


# Generated at 2022-06-23 23:04:33.950814
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = ast.parse('[2, *range(10), 1, *range(3)]')
    expected_code = ast.parse('[2] + list(range(10)) + [1] + list(range(3))')
    code = StarredUnpackingTransformer().visit(code)
    assert ast.dump(code) == ast.dump(expected_code)



# Generated at 2022-06-23 23:04:39.595451
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import compile_str
    from . import assert_equal_ast
    from .mixins import BlankRuleSet

    class Tr(BlankRuleSet, StarredUnpackingTransformer):
        pass

    tr = Tr()
    src = 'print(*range(10), *range(20))'
    expected = 'print(*(list(range(10)) + list(range(20))))'
    assert_equal_ast(compile_str(src, tr), compile_str(expected, tr))


# Generated at 2022-06-23 23:04:50.478028
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    from . import BaseNodeTest

    def test_summary(exp_python_code, python_code, **kwargs) -> None:
        new_tree = StarredUnpackingTransformer().visit(python_code)
        exp_tree = StarredUnpackingTransformer().visit(exp_python_code)
        assert astunparse.unparse(exp_tree) == astunparse.unparse(new_tree)


# Generated at 2022-06-23 23:05:00.733473
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert a._split_by_starred([]) == []
    assert a._split_by_starred([ast.Starred(value=42)]) == [42]
    assert a._split_by_starred([ast.Starred(value=42), ast.Starred(value=42)]) == [42, 42]
    assert a._split_by_starred([42, ast.Starred(value=42), 42]) == [[42], 42, [42]]
    assert a._split_by_starred([42, 42, 42]) == [[42, 42, 42]]
    assert a._prepare_lists([[42], 42, [42]]) == [42, ast.List(elts=[42])]
    assert a._prepare_lists([[]]) == []

# Generated at 2022-06-23 23:05:10.757726
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    t = StarredUnpackingTransformer({})
    a = ast.Call(func=ast.Name(id='func'), args=[ast.Num(n=1), ast.Starred(value=ast.Name(id='arg1')), ast.Num(n=2), ast.Starred(value=ast.Name(id='arg2'))], keywords=[])
    b = ast.Call(func=ast.Name(id='func'), args=[ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Num(n=1)], keywords=[]))], keywords=[])
    assert ast.dump(t.visit(a)) == ast.dump(b)


# Generated at 2022-06-23 23:05:11.807172
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .transforms import StarredUnpackingTransformer
    StarredUnpackingTransformer()

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:05:18.223839
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.Call(
        func=ast.Name(id='print', ctx=ast.Load()),
        args=[ast.Starred(value=ast.Name(id='range', ctx=ast.Load())(
            ast.Constant(value=1, kind=None),
    ), ctx=ast.Load()), ast.Starred(value=ast.Name(id='range', ctx=ast.Load())(
            ast.Constant(value=3, kind=None),
    ), ctx=ast.Load())],
        keywords=[],
        starargs=None,
        kwargs=None
    )

# Generated at 2022-06-23 23:05:30.177091
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """
    Tests for:
        visit_List of StarredUnpackingTransformer
    """

    from .context import Context
    from typed_astunparse import unparse

    context = Context()


# Generated at 2022-06-23 23:05:39.077634
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_transformer import (
        assert_tree_equal,
        parse_ast,
        dump_tree,
    )

    tree = parse_ast('''\
    x = [2, *range(10), 1]
    ''')
    expected_tree = parse_ast('''\
    x = [2] + list(range(10)) + [1]
    ''')
    assert_tree_equal(
        StarredUnpackingTransformer().visit(tree),
        expected_tree,
    )


# Generated at 2022-06-23 23:05:47.428957
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Tests method visit_List of class StarredUnpackingTransformer."""

    # Tests if the Starred node is transformed correctly
    ast_node = ast.parse(
            '''[2, *range(10), 1]''').body[0].value
    Starred_transformer = StarredUnpackingTransformer()
    transformed_starred = Starred_transformer.visit(ast_node)
    assert len(transformed_starred.body) == 1
    
    # Tests if the generic_visit method is called correctly
    ast_node = ast.parse(
            '''[2, 5, 1]''').body[0].value
    Starred_transformer = StarredUnpackingTransformer()
    transformed_starred = Starred_transformer.visit(ast_node)

# Generated at 2022-06-23 23:05:53.506263
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    first_ast = ast.List(elts=[ast.Num(n=2),
                               ast.Starred(value=ast.Call(
                                   func=ast.Name(id='range'),
                                   args=[ast.Num(n=10)],
                                   keywords=[])),
                               ast.Num(n=1)])


# Generated at 2022-06-23 23:06:00.348234
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    visitor = StarredUnpackingTransformer()
    node = ast.parse("print(1, *[2, 3], *range(5), 2, *[5])").body[0]
    new_node = visitor.visit(node)
    assert ast.dump(new_node) == "print(*(list([1, 2, 3]) + list([0, 1, 2, 3, 4]) + list([2]) + list([5])))"


# Generated at 2022-06-23 23:06:07.578537
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse.unparser import Unparser

    class DummyNodeTransformer(BaseNodeTransformer):
        pass

    sample_code = '[2, *range(10), 1]'

    expected_code = '[2] + list(range(10)) + [1]'

    node = ast.parse(sample_code).body[0].value
    node = StarredUnpackingTransformer().visit(node)
    node = DummyNodeTransformer().visit(node)  # type: ignore
    code = Unparser(node)

    assert code == expected_code


# Generated at 2022-06-23 23:06:13.092459
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # https://www.python.org/dev/peps/pep-3132/
    tree = ast.parse('[1, 2, *range(10), 3, 4]')
    transformer = StarredUnpackingTransformer()
    result = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(ast.parse(
        "([1, 2] + list(range(10)) + [3, 4])"))



# Generated at 2022-06-23 23:06:24.403076
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():

    from typed_ast import ast3 as ast
    from .context import Context

    trans = StarredUnpackingTransformer(Context())

    # [2, *range(10), 1]
    tree = ast.parse("[2, *range(10), 1]")
    trans.visit(tree)
    assert ast.dump(tree) == "List(elts=[Num(n=2), BinOp(left=List(elts=[Num(n=2)]), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), List(elts=[Num(n=1)])], ctx=Load())"

    # [2, [1, *range(

# Generated at 2022-06-23 23:06:35.166216
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import assert_transformation

    code = '[1, *range(10), 2]'
    expected = '[1] + list(range(10)) + [2]'
    assert_transformation(StarredUnpackingTransformer,
                          expected, code)

    code = '[[1, *range(10)], [2, *range(10)]]'
    expected = '[[1] + list(range(10)), [2] + list(range(10))]'
    assert_transformation(StarredUnpackingTransformer,
                          expected, code)

    code = '[1, *range(10), 2, *range(1)]'
    expected = '[1] + list(range(10)) + [2] + list(range(1))'

# Generated at 2022-06-23 23:06:42.066434
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    program = """print(*range(1), *range(3))"""
    expected = """print(*(list(range(1)) + list(range(3))))"""
    expected_tree = ast.dump(ast.parse(expected))
    tree = ast.parse(program)
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    assert expected_tree == ast.dump(tree)
    assert transformer._tree_changed


# Generated at 2022-06-23 23:06:45.704139
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer(tree).transform()


# Generated at 2022-06-23 23:06:50.081119
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.dump(ast.parse(
        "print(*range(2), *range(3))"
    )) == ast.dump(ast.parse(
        "print(*(list(range(2)) + list(range(3))))"
    ))



# Generated at 2022-06-23 23:06:58.992042
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[1, 2, *[3, 4], 5]'
    expected = '[1, 2] + list([3, 4]) + [5]'

    trans = StarredUnpackingTransformer()
    tree = ast.parse(source)
    result = ast.dump(tree)  # strings
    assert result == source

    trans.visit(tree)
    result = ast.dump(tree)  # strings
    assert result == expected

    # Test that subclassing works
    class TestTrans(StarredUnpackingTransformer):
        def visit_List(self, node: ast.List) -> ast.List:  # type: ignore
            assert 1 == 2  # Should not hit original method

    trans = TestTrans()
    tree = ast.parse(source)
    trans.visit(tree)

    # There is no star
    source

# Generated at 2022-06-23 23:07:09.193138
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compiler import compile
    from .assert_ast import AssertAST
    from .utils import compile_to_ast, test_compilation
    source = "[2, *range(10), 1]"
    expected_source = "[2] + list(range(10)) + [1]"
    assert_ast = AssertAST(StarredUnpackingTransformer)
    assert_ast.assert_transformation(expected_source, source)
    test_compilation(expected_source, source)
    test_compilation(expected_source, compile(source, '<test>', 'exec', ast.PyCF_ONLY_AST))


# Generated at 2022-06-23 23:07:14.073690
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    tree = """
        [2, *range(10), 1]
    """
    t = StarredUnpackingTransformer()
    t.visit(ast.parse(tree))
    assert t._tree_changed == True
    assert t.output == ast.parse("[2] + list(range(10)) + [1]")


# Generated at 2022-06-23 23:07:20.414875
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """

    tree = ast.parse(dedent(code))
    expected_tree = ast.parse(dedent(expected))
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-23 23:07:28.490491
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from ..codegen import to_source
    from ..transforms import StarredUnpackingTransformer as SUT
    from .mock import ASTFixture
    fixture = ASTFixture()

    code = fixture.code('[2, *range(10), 1]')
    result = SUT().visit(code)
    expected_code = fixture.code('[2] + list(range(10)) + [1]')

    assert result == expected_code, (to_source(result), to_source(expected_code))



# Generated at 2022-06-23 23:07:32.201197
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from ..testing_utils import compile_and_check
    source = "[2, *range(3), 1, *range(3), 5]"
    expect = "[2, 0, 1, 2, 1, 5]"
    compile_and_check(source, expect,
            pipeline=[('StarredUnpackingTransformer', StarredUnpackingTransformer)])

# Generated at 2022-06-23 23:07:41.277607
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .utils import from_source

    node = from_source(StarredUnpackingTransformer, "[2, *range(10), 1]")
    assert isinstance(node, ast.List)
    assert isinstance(node.elts[0], ast.BinOp)
    assert isinstance(node.elts[0].right, ast.Call)
    assert node.elts[0].right.func.id == 'list'
    assert node.elts[0].right.args[0].func.id == 'range'

    node = from_source(StarredUnpackingTransformer, "print(*range(1), *range(3))")
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert node.value.func.id == 'print'

# Generated at 2022-06-23 23:07:52.231293
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    class TestCase(object):
        def test(self):
            a = []
            a.append(*range(2))
            a.append(1)

    _, node = parseprint(TestCase, transformed_to=3)

# Generated at 2022-06-23 23:08:03.486096
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_astunparse import unparse as ast_unparse
    from astunparse import unparse as python_unparse
    from textwrap import dedent

    test_code = dedent('''
    print(*range(1), *range(3))
    [2, *range(10), 1]
        ''')

    node = ast.parse(test_code)
    expected_code = dedent('''
    print(*(list(range(1)) + list(range(3))))
    [2] + list(range(10)) + [1]
        ''')

    assert python_unparse(StarredUnpackingTransformer().visit(node)) == expected_code

    # and now with typed_ast, which does not have all the visitors

# Generated at 2022-06-23 23:08:05.409088
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor import dump_tree, parse_file

    Str = str


# Generated at 2022-06-23 23:08:11.591331
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    x = ast.parse("print(1, *range(3), 4)").body[0]
    assert isinstance(x, ast.Expr)
    assert isinstance(x.value, ast.Call)

    node = x.value
    assert isinstance(node.args[0], ast.Num)
    assert node.args[0].n == 1
    assert isinstance(node.args[1], ast.Starred)
    assert isinstance(node.args[1].value, ast.Call)
    assert isinstance(node.args[2], ast.Num)
    assert node.args[2].n == 4

    result = StarredUnpackingTransformer().visit(node)
    assert isinstance(result, ast.Call)
    assert len(result.args) == 1

# Generated at 2022-06-23 23:08:13.606539
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import UnitTestTransformer
    x = ast.parse("", mode="eval")
    y = UnitTestTransformer(StarredUnpackingTransformer).visit(x)

# Generated at 2022-06-23 23:08:24.404568
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    import astunparse
    import textwrap


    class Test(StarredUnpackingTransformer):
        def __init__(self):
            super().__init__()
            self._tree_changed = False

        @property
        def tree_changed(self):
            return self._tree_changed

    # test of the cases when the tree isn't changed
    def test(source):
        tree = ast.parse(source)
        t = Test()
        res = t.visit(tree)
        assert t.tree_changed == False
        assert astunparse.unparse(res).replace(" ", "").replace("\n", "") == source.replace(" ", "").replace("\n", "")

    test("[2, 3]")
    test("[2,3]")
   

# Generated at 2022-06-23 23:08:29.589014
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    expected = ast.parse("print(*(list('123')+list('45')))")
    expected_node = expected.body[0].value
    node = ast.parse("print(*'12', *'45')")
    node_ = StarredUnpackingTransformer().visit(node)
    assert ast.dump(node_) == ast.dump(expected_node)


# Generated at 2022-06-23 23:08:38.889835
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Simple case
    code = "f(2, *range(10), 1)"
    node = ast.parse(code).body[0].value
    assert isinstance(node, ast.Call)
    assert len(node.args) == 3
    assert node.args[0] == ast.Num(2)
    assert isinstance(node.args[1], ast.Starred)
    assert node.args[1].value == ast.Call(
        func=ast.Name(id='range'),
        args=[ast.Num(10)],
        keywords=[])
    assert node.args[2] == ast.Num(1)

    result = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:08:43.812660
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astunparse
    code = 'mylist = [1, *range(2), 3]'
    expected_code = 'mylist = [1] + list(range(2)) + [3]'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(tree).strip() == expected_code


# Generated at 2022-06-23 23:08:52.600729
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as pyast
    from typed_ast.ast3 import parse as parse3
    import astunparse

    unparser = astunparse.Unparser(lineno=True, col_offset=True)

    source = '[2, *range(10), 1]'

    expected = str(pyast.dump(pyast.parse(source).body[0]))

    tree = parse3(source)
    tree = StarredUnpackingTransformer().visit(tree)
    root = ast.Module(body=tree)
    untree = unparser.visit(root)

    assert untree == expected



# Generated at 2022-06-23 23:08:59.075228
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = ast.parse("""
l = [2, *range(10), 1]
""")
    b = ast.parse("""
l = [2] + list(range(10)) + [1]
""")
    t = StarredUnpackingTransformer()
    res = t.visit(a)
    # print(ast.dump(res))
    assert ast.dump(res) == ast.dump(b)



# Generated at 2022-06-23 23:09:04.959829
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = "foo(1, 2, 3, *[2, 3], *[3, 4], 1)"
    expected = ast.parse(
        "foo(*([1, 2, 3] + list([2, 3]) + list([3, 4]) + [1]))")
    transformer = StarredUnpackingTransformer()
    tree = ast.parse(code)
    transformer.visit(tree)
    assert compare_ast(tree, expected)



# Generated at 2022-06-23 23:09:13.174658
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Unit test for method visit_Call of class StarredUnpackingTransformer."""
    from .helpers import assert_equal_ast
    from .decompile import decompile
    from .compile_ import compile_

    code = 'print(1, *range(3), 4)'
    ast_tree = compile_(code, 3, 4)
    StarredUnpackingTransformer().visit(ast_tree)
    assert_equal_ast(decompile(ast_tree),
                     'print(*(list([1]) + list(range(3)) + list([4])))')