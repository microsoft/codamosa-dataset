

# Generated at 2022-06-23 22:59:28.297888
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    """Compiles:
        print(*range(1), *range(3))
    To:
        print(*(list(range(1)) + list(range(3))))
    """
    expected = \
    """
    print(*[], *[], *(list(range(1)) + list(range(3))))
    """
    t = StarredUnpackingTransformer()
    source = \
    """
    print(2, *[], *[], *range(1), *range(3), 1)
    """
    tree = ast.parse(source)
    tree = t.visit(tree)
    code = compile(tree, '<string>', 'exec')
    eval(code)



# Generated at 2022-06-23 22:59:36.338061
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    """
    Unit test for constructor of class StarredUnpackingTransformer
    """
    input_string = '''list([2, *range(10), 1])'''
    ast_tree = ast.parse(input_string)
    star_transformer = StarredUnpackingTransformer()
    star_transformer.visit(ast_tree)
    # ast.dump(ast_tree)
    import unittest.mock
    with unittest.mock.patch('sys.stdout', new=io.StringIO()) as mocked_output:
        ast.fix_missing_locations(ast_tree)
        exec(compile(ast_tree, filename="<ast>", mode="exec"))

# Generated at 2022-06-23 22:59:47.413557
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    test_ast_string_1 = """
from builtins import print
from typing import Any
print((1, 2), (3, 4), sep=Any)
"""
    test_ast_string_2 = """
from builtins import print
from typing import Any
print(1, 2, 3, 4, sep=Any)
"""
    ast_tree_1 = ast.parse(test_ast_string_1)
    ast_tree_2 = ast.parse(test_ast_string_2)
    result_ast_tree_1 = StarredUnpackingTransformer().visit(ast_tree_1)
    result_ast_tree_2 = StarredUnpackingTransformer().visit(ast_tree_2)
    ast_output_string_1 = ast.dump(result_ast_tree_1)
    ast_output_string

# Generated at 2022-06-23 22:59:48.476033
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    trans = StarredUnpackingTransformer()
    return trans

# Generated at 2022-06-23 22:59:58.018335
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = ast.parse("[2, *range(10), 1]")
    s = StarredUnpackingTransformer().visit(s)
    assert ast.dump(s) =="Module(body=[Expr(value=BinOp(left=BinOp(left=BinOp(left=List(elts=[Num(n=2)], ctx=Load()), right=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add()), right=List(elts=[Num(n=1)], ctx=Load()), op=Add()))])]"


# Generated at 2022-06-23 23:00:00.791390
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    source = 'print(*range(1), *range(3))'
    tree = ast.parse(source)
    expected = ast.parse(
        'print(*(list(range(1)) + list(range(3))))')
    transformed = transformer.visit(tree)
    assert ast.dump(transformed) == ast.dump(expected)



# Generated at 2022-06-23 23:00:09.862188
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # 1. method visit_Call must return ast.Call instance
    # 1.1 method visit_Call must return ast.Call instance when node.args does not contain any ast.Starred
    class TestNodeEvaluation(StarredUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False
    code = "print(*range(1), *range(3))"
    ast_tree = ast.parse(code, mode='eval')
    node = ast_tree.body
    assert isinstance(node, ast.Expr)
    test_node_evaluation = TestNodeEvaluation()
    result = test_node_evaluation.visit(node)
    assert isinstance(result, ast.Expr)
    assert isinstance(result.value, ast.Call)
    # 1.2 method visit_Call

# Generated at 2022-06-23 23:00:20.025042
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = '[1, *range(5), 8]'
    expected = '[1] + list(range(5)) + [8]'
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    actual = transformer.visit(tree)
    assert ast.dump(actual) == expected

    source = 'print(*range(5), *range(3))'
    expected = "print(*(list(range(5)) + list(range(3))))"
    tree = ast.parse(source)
    transformer = StarredUnpackingTransformer()
    actual = transformer.visit(tree)
    assert ast.dump(actual) == expected

    source = 'print(*range(5), 3)'
    expected = "print(*(list(range(5)) + [3]))"
    tree = ast.parse(source)

# Generated at 2022-06-23 23:00:27.951208
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    a = Ast3()
    a.parse('''
        print(*range(3))
    ''')
    StarredUnpackingTransformer().visit(a)
    assert a.dump() == \
        "Module(body=[Print(dest=None, values=[Starred(value=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=3)], keywords=[])], keywords=[]), ctx=Load())], nl=True)])"


# Generated at 2022-06-23 23:00:36.480508
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    def test(xs):
        xs = list(map(ast.parse, xs))
        for x in xs:
            assert isinstance(x, ast.Expression)
            x = x.body
            assert isinstance(x, ast.List)
            x_before = ast.dump(x)
            x_starred = StarredUnpackingTransformer().visit(x)
            x_after = ast.dump(x_starred)
            print('x_before:\n', x_before, '\nx_after:\n', x_after)
            assert x_before == x_after


# Generated at 2022-06-23 23:00:40.717281
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    import astor
    from .base import BaseNodeTransformer

    tree = ast.parse('[2, *range(10), 1]')
    expected = ast.parse('[2] + list(range(10)) + [1]')

    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == astor.to_source(expected)


# Generated at 2022-06-23 23:00:42.248508
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert set(starred.__code__.co_flags & 0x08 for starred in (StarredUnpackingTransformer, ) ) == {True}

# Generated at 2022-06-23 23:00:47.322082
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import os
    import astunparse
    import textwrap
    dir_path = os.path.dirname(os.path.realpath(__file__))
    target_path = os.path.join(dir_path, "..", "tests", "test_starred.py")
    target_ast = ast.parse(open(target_path).read())

    result_ast = StarredUnpackingTransformer().visit(target_ast)
    result_code = astunparse.unparse(result_ast)
    # print(result_code)
    print(textwrap.dedent(
        """
        expected = textwrap.dedent(result_code)
        
        assert expected == result_code
        """)
    )

test_StarredUnpackingTransformer_visit_List()

# Generated at 2022-06-23 23:00:51.264917
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import parse
    code = '[2, *range(10), *range(1), 1]'
    expected_code = '[2] + list(range(10)) + list(range(1)) + [1]'

    node = parse(code)
    StarredUnpackingTransformer().visit(node)

    assert expected_code == compile(node, '<test>', 'exec').co_consts[0]



# Generated at 2022-06-23 23:00:54.142045
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """print(2, *range(10), 1)"""
    expected = """print(*(list([2]) + list(range(10)) + list([1])))"""
    actual = StarredUnpackingTransformer.run_on_code(code)
    assert expected == actual


# Generated at 2022-06-23 23:01:03.045150
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(2, *range(10), 1)").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)

    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)

    expected_node = ast.parse("print(*([2] + list(range(10)) + [1]))").body[0]
    assert isinstance(new_node.value, ast.Call)
    assert_equal_ast(new_node.value, expected_node.value)



# Generated at 2022-06-23 23:01:04.664444
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:01:13.926656
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    a = '''[2, *range(10), 1]'''
    exp_a = '''[2] + list(range(10)) + [1]'''
    b = '''[*range(5 * 2 * 3 * 2 * 2)]'''
    exp_b = '''list(range(5 * 2 * 3 * 2 * 2))'''
    c = '''[*[*range(5 * 2 * 3 * 2 * 2)]]'''
    exp_c = '''list(range(5 * 2 * 3 * 2 * 2))'''
    d = '''[2, 3, *[*range(5 * 2 * 3 * 2 * 2)]]'''
    exp_d = '''[2, 3] + list(range(5 * 2 * 3 * 2 * 2))'''

# Generated at 2022-06-23 23:01:22.547805
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')

    # case nothing to change
    assert transformer.visit(tree) == ast.parse('[2, *range(10), 1]')
    assert not transformer.changed

    # case with change
    tree = ast.parse('[2, *range(10), 1, *range(10)]')
    expected = ast.parse('[2] + list(range(10)) + [1] + list(range(10))')
    assert transformer.visit(tree) == expected
    assert transformer.changed


# Generated at 2022-06-23 23:01:26.555345
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse("[2, *range(10), 1]")
    assert str(node.body[0]) == "[2, *range(10), 1]"
    ts = StarredUnpackingTransformer(node)
    assert str(ts.body[0]) == "[2] + list(range(10)) + [1]"



# Generated at 2022-06-23 23:01:36.833261
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    # Simple example
    node = ast.parse('print(*range(1), *range(3), sep=123)', mode='eval')
    result = StarredUnpackingTransformer().visit(node)
    expected = ast.parse('print(*(list(range(1)) + list(range(3))), sep=123)', mode='eval')
    assert ast.dump(result, include_attributes=True) == ast.dump(expected, include_attributes=True)

    # Complex example
    node = ast.parse('print(*range(1), *range(3), sep=123, end=456)', mode='eval')
    result = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:01:45.328948
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import parse

    node = parse('[2, *range(10), 1]').body[0].value
    assert isinstance(node, ast.List)
    assert node.elts[1].value.func.id == 'range'

    StarredUnpackingTransformer(node).visit(node)
    assert isinstance(node, ast.BinOp)
    assert node.left.elts[0].n == 2
    assert node.left.elts[1].n == 1

    assert isinstance(node.right, ast.BinOp)
    assert node.right.left.func.id == 'range'
    assert node.right.right.n == 1

# Generated at 2022-06-23 23:01:52.673597
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    transformer = StarredUnpackingTransformer()
    node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='argv'))], keywords=[])
    expected = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.List(elts=[ast.Name(id='argv')]))], keywords=[])
    actual = transformer.visit_Call(node)
    assert ast.dump(expected) == ast.dump(actual)
    
    expected = '%s' % expected
    actual = '%s' % actual
    assert expected == actual
    

# Generated at 2022-06-23 23:02:03.251134
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    st = ast.parse("[1, *range(10), 11, *range(12), 13, 14]")
    exc = StarredUnpackingTransformer()
    # first unit test
    result = exc.visit(st)

# Generated at 2022-06-23 23:02:11.672525
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse('print(*range(1), *range(3))').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)
    assert isinstance(new_node.value, ast.Call)
    assert isinstance(new_node.value.args[0], ast.Starred)
    assert isinstance(new_node.value.args[0].value, ast.BinOp)
    assert len(new_node.value.args[0].value.right) == 3
    assert isinstance(new_node.value.args[0].value.left, ast.Call)

# Generated at 2022-06-23 23:02:13.095211
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    a = StarredUnpackingTransformer()
    assert a is not None

# Generated at 2022-06-23 23:02:22.735300
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .util import round_trip
    from typed_ast import ast3

    printable = ast3.List(
        elts=[
            ast3.Starred(value=ast3.Name(id='range', ctx=ast3.Load()), ctx=ast3.Load()),
            ast3.Call(
                func=ast3.Name(id='range', ctx=ast3.Load()),
                args=[ast3.Num(n=2)],
                keywords=[])],
        ctx=ast3.Load())


# Generated at 2022-06-23 23:02:34.659450
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    star = ast.Starred()
    assert StarredUnpackingTransformer._has_starred([star])
    assert not StarredUnpackingTransformer._has_starred([])

    sub = ast.Subscript()
    assert StarredUnpackingTransformer._split_by_starred([]) == [[]]
    assert StarredUnpackingTransformer._split_by_starred([star]) == [[], star, []]
    assert StarredUnpackingTransformer._split_by_starred([sub, star]) == [[sub], star, []]
    assert StarredUnpackingTransformer._split_by_starred([sub, star, sub]) == [[sub], star, [sub]]
    assert StarredUnpackingTransformer._split_by_starred([sub, star, star, sub]) == [[sub], star, [], star, [sub]]
   

# Generated at 2022-06-23 23:02:39.265113
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(2, *range(10))")
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    expected = ast.parse("print(*(2, *(list(range(10, 10)))))")
    assert ast.dump(tree) == ast.dump(expected)


# Generated at 2022-06-23 23:02:50.686912
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test_ast = ast.parse('[2, *range(10), 1]', 'file')
    result_ast = StarredUnpackingTransformer().visit(test_ast)
    assert isinstance(result_ast, ast.Module)
    assert isinstance(result_ast.body[0], ast.Expr)
    assert isinstance(result_ast.body[0].value, ast.BinOp)
    left = result_ast.body[0].value.left
    assert isinstance(left, ast.List)
    assert isinstance(left.elts[0], ast.Num)
    assert left.elts[0].n == 2
    right = result_ast.body[0].value.right
    assert isinstance(right, ast.List)
    assert isinstance(right.elts[0], ast.Num)

# Generated at 2022-06-23 23:03:01.186973
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = textwrap.dedent('''
    # target: (3, 4)
    [2, *range(10), 1]
    list([2, *range(10), 1])
    call([2, *range(10), 1])
    ''')
    expected_code = textwrap.dedent('''
    [2] + list(range(10)) + [1]
    list([2] + list(range(10)) + [1])
    call([2] + list(range(10)) + [1])
    ''')
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert expected_code == astor.to_source(tree)


# Generated at 2022-06-23 23:03:05.114999
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    check_ast(StarredUnpackingTransformer, 'foo(*[1, 2, 3], *[4, 5, 6])', 'foo(*(list([1, 2, 3]) + list([4, 5, 6])))')


# Generated at 2022-06-23 23:03:07.714511
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = "print(*range(1), *range(3))"
    expected = "print(*(list(range(1)) + list(range(3))))"

    assert expected == str(StarredUnpackingTransformer().visit(ast.parse(code)))

# Generated at 2022-06-23 23:03:16.736562
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    x = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(
        func=ast.Name(id='range'),
        args=[ast.Num(n=10)],
        keywords=[]
    )), ast.Num(n=1)])

# Generated at 2022-06-23 23:03:22.406939
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    result = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(result) == ast.dump(ast.parse('[2] + list(range(10)) + [1]'))


if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:03:27.929591
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    subj = StarredUnpackingTransformer()
    code = '''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    '''
    tree = ast.parse(code)
    subj.visit(tree)
    assert subj.tree_changed
    exec(compile(tree, '<test>', 'exec'))

# Generated at 2022-06-23 23:03:36.807044
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    node1 = ast.List()
    node2 = ast.List()
    node3 = ast.List()
    node4 = ast.List()
    node5 = ast.List()
    node1.elts = [ast.Constant(value=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load())), ast.Constant(value=1)]
    node2.elts = [ast.Constant(value=2), ast.Starred(value=ast.Name(id='range', ctx=ast.Load()))]
    node3.elts = [ast.Starred(value=ast.Name(id='range', ctx=ast.Load())), ast.Constant(value=1)]

# Generated at 2022-06-23 23:03:47.984742
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("""
    func(*a, b, *c, *d, e)
    """
    ).body[0].value
    assert isinstance(node, ast.Call)
    result = StarredUnpackingTransformer(node).visit()
    assert isinstance(result, ast.Call)
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.Starred)
    assert isinstance(result.args[0].value, ast.BinOp)

    left = result.args[0].value.left
    right = result.args[0].value.right

    assert isinstance(left, ast.BinOp)
    assert isinstance(left.left, ast.BinOp)
    assert isinstance(left.right, ast.BinOp)

# Generated at 2022-06-23 23:03:49.553243
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    stup = StarredUnpackingTransformer()
    assert isinstance(stup, StarredUnpackingTransformer)

# Generated at 2022-06-23 23:03:50.750845
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer('[2, *range(10), 1]')

# Generated at 2022-06-23 23:03:57.741471
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected_code = "[2] + list(range(10)) + [1]"

    module = ast.parse(code)
    tree_transformer = BaseNodeTransformer()
    tree_transformer.visit(module)
    tree_transformer = StarredUnpackingTransformer()
    tree_transformer.visit(module)
    code_gen = CodeGenerator()
    code_gen.visit(module)

    assert code_gen.result == expected_code


# Generated at 2022-06-23 23:04:06.429502
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = """
    [1, *range(2), 3]
    """

    t1 = ast.parse(code)
    t2 = StarredUnpackingTransformer().visit(t1)

    assert t1.body[0].value.elts == [
        ast.Num(n=1),
        ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()),
        ast.Num(n=2),
        ast.Num(n=3),
    ]

    assert t2.body[0].value.elts[0].func.id == 'list'
    assert t2.body[0].value.elts[0].args[0].func.id == 'range'

# Generated at 2022-06-23 23:04:14.108646
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    import astor
    code = astor.to_source(ast.parse("""print(1, *range(10), end=" ")"""))
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == """print(*({0} + list(range(10)) + [1]))""".format(ast.Num(n=1));


# Generated at 2022-06-23 23:04:21.293798
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    targeted_statement = "print(*range(1), *range(3))"
    targeted_ast = ast.parse(targeted_statement)
    # When
    result_ast, _ = StarredUnpackingTransformer().visit_tree(targeted_ast,
                                                             file_name="",
                                                             debug=True)
    # Then
    expected_statement = "print(*(list(range(1)) + list(range(3))))"
    expected_ast = ast.parse(expected_statement)
    assert ast.dump(result_ast) == ast.dump(expected_ast)



# Generated at 2022-06-23 23:04:25.688338
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import sys
    import unittest

    sys.path.append('../')
    from test_helper import BasicTestCase

    class TestStarredUnpackingTransformer(BasicTestCase):
        def test(self):
            self.check_ast(
                """
                [2, *range(10), 1]
                print(*range(1), *range(3))
            """, """
                list([2]) + list(range(10)) + list([1])
                print(*(list(range(1)) + list(range(3))))
            """)
    unittest.main()

# Generated at 2022-06-23 23:04:36.216192
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import tempfile
    import os
    code = '''\
    print(*range(1), *range(3))
    [2, *range(10), 1]
    '''
    expected = '''\
    print(*(list(range(1)) + list(range(3))))
    [2] + list(range(10)) + [1]
    '''
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpfilename = os.path.join(tmpdirname, 'test.py')
        with open(tmpfilename, 'w') as outfile:
            outfile.write(code)
        t1 = StarredUnpackingTransformer()
        with open(tmpfilename, 'r') as infile:
            tree = ast.parse(infile.read())
        t1.visit(tree)


# Generated at 2022-06-23 23:04:45.801851
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import TestTransformerBase

    node = ast.parse(
        '[2, *range(10), 1]',
        mode='eval')

    expected_node = ast.parse(
        '([2] + list(range(10)) + [1])',
        mode='eval')

    # pylint: disable=super-init-not-called
    transformer = StarredUnpackingTransformer()
    transformed_node = transformer.visit(node)

    TestTransformerBase.check_transformed_node(
        transformed_node,
        expected_node,
        transformer,
    )



# Generated at 2022-06-23 23:04:48.094127
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer([[1], [2]]) == [[1], [2]]

# Generated at 2022-06-23 23:04:58.656390
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # [2, *range(10), 1]
    expected_node = ast.List(
        elts=[ast.Num(n=2),
              ast.Call(
                  func=ast.Name(id='list'),
                  args=[ast.Call(
                      func=ast.Name(id='range'),
                      args=[ast.Num(n=10)],
                      keywords=[])],
                  keywords=[]),
              ast.Num(n=1)])

    node = ast.List(
        elts=[ast.Num(n=2),
              ast.Starred(value=ast.Call(
                  func=ast.Name(id='range'),
                  args=[ast.Num(n=10)],
                  keywords=[])),
              ast.Num(n=1)])

    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:05:08.679870
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class TestVisitor(BaseNodeTransformer):
        target = (3, 6)

        def visit_List(self, node: ast.List) -> ast.List:
            if "test" in node.elts[0].s:
                return ast.List(elts=["test", *node.elts[1:]])
            else:
                return self.generic_visit(node)

    code = """
        [1, *range(10), 2, *range(5)]
        [1] + [2, *range(5)]
    """
    expected_converted_code = """
        ["test", *range(10), 2, *range(5)]
        [1] + [2, *range(5)]
    """

    test = StarredUnpackingTransformer()
    visitor = TestVisitor()
   

# Generated at 2022-06-23 23:05:18.363805
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    star_unpack = StarredUnpackingTransformer()

    list_ = ast.List(elts=[
        ast.Starred(value=ast.Name(id="range")),
        ast.Num(n=1)
    ])
    star_unpack.visit(list_)
    assert len(list_.elts) == 1
    assert isinstance(list_.elts[0], ast.Call)
    assert list_.elts[0].func.id == 'list'
    assert list_.elts[0].args[0].id == 'range'

    list_ = ast.List(elts=[
        ast.Num(n=1),
        ast.Starred(value=ast.Name(id="range")),
        ast.Num(n=3)
    ])

# Generated at 2022-06-23 23:05:30.267970
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    assert not StarredUnpackingTransformer.supports_version((3, 0, 0))
    assert StarredUnpackingTransformer.supports_version((3, 4, 0))
    assert StarredUnpackingTransformer.supports_version((3, 5, 0))
    assert StarredUnpackingTransformer.supports_version((3, 6, 0))
    assert not StarredUnpackingTransformer.supports_version((3, 7, 0))

    code = "[2, *range(10), 1]"
    node = ast.parse(code).body[0].value
    assert isinstance(node, ast.List)
    node = StarredUnpackingTransformer().visit(node)
    assert isinstance(node, ast.BinOp)

# Generated at 2022-06-23 23:05:42.413177
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    test_source_1 = "print(*range(1), *range(3))"
    test_expected_1 = "print(*(list(range(1)) + list(range(3))))"
    test_source_2 = "print(1, *range(3), *range(5))"
    test_expected_2 = "print(1, *(list(range(3)) + list(range(5))))"

    tree_1 = ast.parse(test_source_1)
    tree_2 = ast.parse(test_source_2)

    t_1 = StarredUnpackingTransformer()
    t_2 = StarredUnpackingTransformer()
    tree_1 = t_1.visit(tree_1)
    tree_2 = t_2.visit(tree_2)

    result

# Generated at 2022-06-23 23:05:53.677081
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test case for input: print(*range(1), *range(3))
    # Expected output: print(*(list(range(1)) + list(range(3))))
    node = ast.parse("print(*range(1), *range(3))").body[0]
    result = StarredUnpackingTransformer().visit(node)
    assert ast_equal(result, ast.parse("print(*(list(range(1)) + list(range(3))))").body[0])

    # Test case for input: func(*range(1), *range(3))
    # Expected output: func(*(list(range(1)) + list(range(3))))
    node = ast.parse("func(*range(1), *range(3))").body[0]
    result = StarredUnpackingTransformer().visit(node)
   

# Generated at 2022-06-23 23:05:57.654613
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    mod = ast.parse('foo(*iterator())')
    transformer = StarredUnpackingTransformer()
    mod = transformer.visit(mod)

    exp_mod = ast.parse('foo(*list(iterator()))')
    assert mod == exp_mod


# Generated at 2022-06-23 23:06:06.919412
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast
    import astor
    node = ast.parse('[2, *range(10), 1]')
    node = StarredUnpackingTransformer().visit(node)
    assert 'Add' in astor.to_source(node)
    assert 'list(range(10))' in astor.to_source(node)
    node = ast.parse('[2, 1]')
    node = StarredUnpackingTransformer().visit(node)
    assert 'Add' not in astor.to_source(node)
    assert 'list(range(10))' not in astor.to_source(node)
    assert '2, 1' in astor.to_source(node)


# Generated at 2022-06-23 23:06:13.167779
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    mod = ast.parse('''
        import sys
        print(*range(10))
    '''.strip())
    print(mod)
    for stmt in mod.body:
        print(stmt.__class__.__name__)
        if isinstance(stmt, ast.Expr):
            # stmt.value = StarredUnpackingTransformer().visit(stmt.value)
            print(str(stmt))
    # print(str(mod))


if __name__ == "__main__":
    test_StarredUnpackingTransformer_visit_Call()

# Generated at 2022-06-23 23:06:24.449710
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    def test(source: str, expected: str):
        tree = ast.parse(source)
        expected = ast.parse(expected)

        actual = StarredUnpackingTransformer().visit(tree)

        assert ast.dump(actual) == ast.dump(expected)

    test(
        """print(*range(1), *range(2))""",
        """print(*(list(range(1)) + list(range(2))))"""
    )

    test(
        """print(*range(1), *range(2), *range(3))""",
        """print(*(list(range(1)) + list(range(2)) + list(range(3))))"""
    )

    test(
        """print(1, *range(1))""",
        """print(1, *(list(range(1))))"""
    )

# Generated at 2022-06-23 23:06:29.675372
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .compat import B3

    code = 'print(*list(range(1)), *list(range(3)))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    StarredUnpackingTransformer(B3).visit(tree)
    transformed = ast.dump(tree)
    assert expected == transformed

# Generated at 2022-06-23 23:06:36.681142
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .test_utils import assert_program

    assert_program(
'''c=[2, *range(10), 1]''',
'''from builtins import range
from builtins import list
c = [2] + list(range(10)) + [1]''')

    assert_program(
'''
from builtins import range
print(*range(1), *range(3))
''',
'''
from builtins import range
from builtins import list
print(*(list(range(1)) + list(range(3))))
''')

# Generated at 2022-06-23 23:06:43.649839
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Test transformation of list comprehension with starred unpacking."""
    transformer = StarredUnpackingTransformer(optimizations=None)
    transformer._tree_changed = False
    input_string = """[2, *range(10), 1]"""
    result_string = """list([2] + list(range(10)) + [1])"""

    tree = ast.parse(input_string)
    transformer.visit(tree)

    assert str(tree) == result_string
    assert transformer._tree_changed is True


# Generated at 2022-06-23 23:06:52.940717
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import compile_func

    def test():
        return [2, *range(10), 1]

    expected = [
        ast.List(
            elts=[
                ast.Num(n=2),
                ast.Call(
                    func=ast.Name(id='list'),
                    args=[ast.Call(
                        func=ast.Name(id='range'),
                        args=[ast.Num(n=10)],
                        keywords=[])],
                    keywords=[]),
                ast.Num(n=1)],
            ctx=ast.Load())]

    assert compile_func(test, StarredUnpackingTransformer).body == expected


# Generated at 2022-06-23 23:06:54.269869
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(1).target == (3, 4)

# Generated at 2022-06-23 23:07:01.399623
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:07:03.008881
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3,4)

# Generated at 2022-06-23 23:07:04.361845
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    st = StarredUnpackingTransformer()
    assert st

# Generated at 2022-06-23 23:07:05.420207
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-23 23:07:13.481504
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    source = '''
print(1, *range(3), 2, *range(3), 5)
'''
    expected = '''
print(*(list([1]) + list(range(3)) + list([2]) + list(range(3)) + list([5])))
'''

    tree = ast.parse(source)  # type: ignore
    tree = StarredUnpackingTransformer().visit(tree)  # type: ignore
    actual = ast.unparse(tree)

    assert expected == actual

# Generated at 2022-06-23 23:07:21.834244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import compile_and_run_in_exec

    source = '''
        l = [2, *range(10), 1]
        print(l)
    '''

    # Output of this test will appear before the output of the unit test itself
    print("\n{}\n".format(source))

    new_source = compile_and_run_in_exec(source, StarredUnpackingTransformer)
    print(new_source)

    # Output of this test will appear after the output of the unit test itself
    print("\n{}\n".format(new_source))

    assert '[2] + list(range(10)) + [1]' in new_source


# Generated at 2022-06-23 23:07:32.031720
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformerTestCase

    codestring = """\
        [*range(5)]
        [*range(20), *range(4)]
        [2, *range(5), *range(3), 1]
        print(*range(5))
        print(1, *range(2), 3)
        print(123, *range(5), *range(3), *range(2), 456)
    """

    expected_ast = ast.parse(codestring)

    class StarredUnpackingTestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
    #   The next line is a workaround for the pytest bug:
    #       https://github.com/pytest-dev/pytest/issues/1935

# Generated at 2022-06-23 23:07:37.861318
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Test 1
    t = StarredUnpackingTransformer()
    node_list = ast.parse("[2, *range(10), 1]")
    node_result = t.visit(node_list)
    assert node_result == ast.parse("[2] + list(range(10)) + [1]")

    # Test 2
    t = StarredUnpackingTransformer()
    node_call = ast.parse("print(*range(1), *range(3))")
    node_result = t.visit(node_call)
    assert node_result == ast.parse("print(*(list(range(1)) + list(range(3))))")

test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:07:43.869372
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    tree = ast.parse(source)  # type: ignore
    compiled = StarredUnpackingTransformer().visit(tree)  # type: ignore
    assert ast.dump(compiled) == expected


# Generated at 2022-06-23 23:07:47.954649
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from compile_python_files.parse_python_file import create_code_generator
    from compile_python_files.create_python_ast import create_python_ast
    module_ast = create_python_ast("""
    [1, 2, 3, *range(10), 5, 6, 7]
    """)
    transform_package_ast = StarredUnpackingTransformer.transform(module_ast)
    assert transform_package_ast
    transformed_ast = transform_package_ast[0]
    generator = create_code_generator()
    expected = """
    [1, 2, 3] + list(range(10)) + [5, 6, 7]
    """
    assert generator.visit(transformed_ast) == expected

# Generated at 2022-06-23 23:07:55.914906
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .basetest import ASTTestCase

    class Test(ASTTestCase):
        def setUp(self):
            self.tr = StarredUnpackingTransformer()

        def test_case1(self):
            node = ast.List(elts=[ast.Num(n=1), ast.Num(n=2)], ctx=ast.Load())
            self.assert_transformed(
                node,
                ast.List(elts=[ast.Num(n=1), ast.Num(n=2)], ctx=ast.Load()),
            )

        def test_case2(self):
            node = ast.List(elts=[ast.Starred(value=ast.Num(n=1)), ast.Num(n=2)], ctx=ast.Load())


# Generated at 2022-06-23 23:07:57.293139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Setup
    src_name = 'example.py'

# Generated at 2022-06-23 23:08:06.049388
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse('''
a = *range(10), 1
''')
    print(ast.dump(tree))
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Tuple(elts=[Starred(value=Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])), Num(n=1)], ctx=Load()))])\n"



# Generated at 2022-06-23 23:08:11.084178
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tt = StarredUnpackingTransformer()
    assert isinstance(tt, BaseNodeTransformer)
    assert tt._has_starred(0) is False
    assert tt._has_starred([]) is False
    assert tt._has_starred([1]) is False
    assert tt._has_starred([ast.Starred(value=1)]) is True


# Generated at 2022-06-23 23:08:18.067077
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Tests that the method visit_List of class StarredUnpackingTransformer
    correctly transforms lists with starred unpacking to lists of lists.
    """
    node = ast.parse('[1, *range(10), 2]')

    trans = StarredUnpackingTransformer()
    new_node = trans.visit(node)


# Generated at 2022-06-23 23:08:23.021934
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse("print(*range(1), *range(3))")

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    expected_tree = ast.parse("print(*(list(range(1)) + list(range(3))))")

    assert tree == expected_tree

# Generated at 2022-06-23 23:08:33.654194
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3


# Generated at 2022-06-23 23:08:34.459635
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:08:40.538122
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .. import transform
    test_tree = """
    print(2, *range(10), *range(8))
    """
    tree = ast.parse(test_tree)
    new_tree = StarredUnpackingTransformer().visit(tree)
    # If used on Python 2.7 code it should be `print(*(list(range(2)) + list(range(8))))`
    # If used on Python 3.6 or later code it should be `print(*(range(2) + range(8)))`
    exec(compile(new_tree, filename="<ast>", mode="exec")) # Should not raise any exception

# Generated at 2022-06-23 23:08:51.728146
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from ast_unparse import dump
    class MockVisitor(ast.NodeVisitor):
        def visit(self, node):
            return node

    class MockNodeTransformer(ast.NodeTransformer):
        def visit(self, node):
            return node

    mock_transformer = MockNodeTransformer()


# Generated at 2022-06-23 23:09:02.952937
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source1 = "[2, *range(10), 1]"

# Generated at 2022-06-23 23:09:10.501345
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from typed_ast.ast3 import Call, Name, Num
    m = StarredUnpackingTransformer()
    code = "print(*[1],*[2,3],*[])"
    tree = ast3.parse(code)
    res = m.visit(tree)
    assert isinstance(res.body[0].value, Call)
    assert isinstance(res.body[0].value.func, Name)
    assert res.body[0].value.func.id == 'print'
    assert isinstance(res.body[0].value.args[0], List)
    assert isinstance(res.body[0].value.args[0].elts[0], BinOp)

# Generated at 2022-06-23 23:09:20.419535
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """test visit_List method of class StarredUnpackingTransformer"""
    node1 = ast.parse('[2, *range(10), 1]')
    node2 = ast.parse('[2, 1]')
    ast.fix_missing_locations(node1)
    ast.fix_missing_locations(node2)
    transformer = StarredUnpackingTransformer()
    result1 = transformer.visit(node2)
    result2 = transformer.visit(node1)
    assert transformer._tree_changed == True
    assert ast.dump(result1) == ast.dump(node2)
    assert ast.dump(result2) == ast.dump(ast.parse('[2] + list(range(10)) + [1]'))
