

# Generated at 2022-06-23 22:59:18.483008
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-23 22:59:29.016785
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    test_code_1 = '''[2, *range(10), 1]'''
    result_code_1 = '''[2] + list(range(10)) + [1]'''
    
    test_code_2 = '''[2, *range(10), 1, *range(4), 3]'''
    result_code_2 = '''[2] + list(range(10)) + [1] + list(range(4)) + [3]'''
    
    test_code_3 = '''[2, *range(10), 1, 3, *range(3)]'''
    result_code_3 = '''[2] + list(range(10)) + [1, 3] + list(range(3))'''
    

# Generated at 2022-06-23 22:59:30.563961
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert isinstance(transformer, ast.NodeTransformer)
    assert transformer._tree_changed == False

# Generated at 2022-06-23 22:59:41.287249
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    print('Test StarredUnpackingTransformer visit_Call()')
    code_1 = 'a = [1, 2, 3]'
    node_tree_1 = ast.parse(code_1)
    StarredUnpackingTransformer().visit(node_tree_1)
    assert ast.dump(node_tree_1) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=List(elts=[Num(n=1), Num(n=2), Num(n=3)], ctx=Load()))])"
    code_2 = 'a = [1, *range(10), 3]'
    node_tree_2 = ast.parse(code_2)
    StarredUnpackingTransformer().visit(node_tree_2)

# Generated at 2022-06-23 22:59:49.394921
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    ts = StarredUnpackingTransformer()
    unit = ast.parse('[1, *range(2), 3, *range(4), 5]')
    expected = ast.parse(
        '_main.__a0_StarredUnpackingTransformer.__to_sum_of_lists'
        '([1, _main.__a0_StarredUnpackingTransformer.__to_sum_of_lists([list(range(2)), list(range(4))]), 5])'
    )
    assert ts.visit(unit) == expected



# Generated at 2022-06-23 22:59:59.665203
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:00:05.358380
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def create_transformer(self):
            return StarredUnpackingTransformer()

    TestCase.add_transform_tests(
        'list',
        [
            ("[2, *range(10), 1]", "[2] + list(range(10)) + [1]"),
        ]
    )



# Generated at 2022-06-23 23:00:15.903633
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astunparse
    import sys
    # Test for line number
    src = '''class Demo():
    def foo(self, args1, args2, args3):
        print(*range(1), *range(3))
    def bar(self):
        [2, *range(10), 1]
        [2, *range(10), 1]
        [2, *range(10), 1]
    def baz(self):
        list(*range(1), *range(3))
        dict(**{'a': 'b'})'''

    # Compile the above source code
    node = compile(src, '<test>', 'exec', dont_inherit=True, optimize=0)
    StarredUnpackingTransformer(verbose=1).visit(node)

# Generated at 2022-06-23 23:00:24.029613
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # from list to sum of lists
    tree = ast.parse("[1, *[2, *[3, *[4]]]]")
    StarredUnpackingTransformer().visit(tree)
    result = ast.dump(tree)
    assert result == "Module(body=[Expr(value=BinOp(left=1, op=Add(), right=BinOp(left=2, op=Add(), right=BinOp(left=3, op=Add(), right=List(elts=[4], ctx=Load())))))])"

    # from list to sum of lists
    tree = ast.parse("[1, *[2, *[3, *range(4)]], 5]")
    StarredUnpackingTransformer().visit(tree)
    result = ast.dump(tree)

# Generated at 2022-06-23 23:00:33.383615
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .unparse import Unparser
    from .transformer import Transformer
    from .cleanup import CleanupTransformer
    from .optimizer import Optimizer
    from .unused import UnusedTransformer
    with open("pipeline/tests/starred_unpacking.py") as fp:
        module_node = ast.parse(fp.read(), "test.py")

    trans = Transformer()
    trans.add(StarredUnpackingTransformer)
    trans.apply(module_node)

    cleanup = CleanupTransformer()
    cleanup.apply(module_node)

    optimizer = Optimizer()
    optimizer.apply(module_node)

    unused = UnusedTransformer()
    unused.apply(module_node)

    code = Unparser(module_node).unparse()


# Generated at 2022-06-23 23:00:38.826031
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    test1 = ast.List(elts = [ast.Name(id='a'), ast.Starred(value=ast.Name(id='b')), ast.Name(id='c')])
    test2 = StarredUnpackingTransformer().visit(test1)
    assert(isinstance(test2, ast.BinOp) and isinstance(test2.right, ast.Call))

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:44.783461
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """some_list = [2, *range(10), 1]\n"""
    expected_result = """some_list = (2) + list(range(10)) + [1]\n"""
    tree = compile(code, filename="<ast>", mode="exec", optimize=0)
    expected_tree = compile(expected_result, filename="<ast>", mode="exec", optimize=0)
    
    # if you want to see what the AST looks like
    #import astor
    #print(astor.to_source(tree))
    
    StarredUnpackingTransformer().visit(tree)
    
    assert ast.dump(tree) == ast.dump(expected_tree)

test_StarredUnpackingTransformer()

# Generated at 2022-06-23 23:00:57.143489
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import ast, sys
    import typed_ast.ast3 as typed_ast
    
    i = StarredUnpackingTransformer()

    test_arg = [typed_ast.Num(n = 2), typed_ast.Starred(value = typed_ast.Name(id = 'range', ctx = typed_ast.Load()), ctx = typed_ast.Load()), typed_ast.Num(n = 1)]

# Generated at 2022-06-23 23:01:03.257989
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import inspect
    import astor
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = StarredUnpackingTransformer()
        expected_output = """[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 1]"""
        code = \
"""
[2, *range(3, 12), 1]
"""

    Test.check()


# Generated at 2022-06-23 23:01:12.032699
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = ast.parse('x = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]')
    assert StarredUnpackingTransformer.can_be_applied(source)

    expected = ast.parse('x = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]')
    assert StarredUnpackingTransformer.transform(source) == expected

    source = ast.parse('x = [2, *range(10), 1]')
    assert StarredUnpackingTransformer.can_be_applied(source)

    expected = ast.parse('x = [2] + list(range(10)) + [1]')
    assert StarredUnpackingTransformer.transform(source) == expected


# Generated at 2022-06-23 23:01:18.047529
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'
    transformer = StarredUnpackingTransformer()
    self = BaseNodeTransformerTestCase(transformer=transformer, code=code)
    assert self.node_equals_code(expected_code=expected_code)


# Generated at 2022-06-23 23:01:23.559541
# Unit test for method visit_List of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:01:32.551023
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.List(elts=[ast.Num(n=2)], ctx=ast.Load())
    tree = StarredUnpackingTransformer().visit(node)
    print(ast.dump(tree, include_attributes=False))

    node = ast.List(elts=[ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[]))], ctx=ast.Load())
    tree = StarredUnpackingTransformer().visit(node)
    print(ast.dump(tree, include_attributes=False))


# Generated at 2022-06-23 23:01:38.576632
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    source = "print(*range(1), *range(3))"
    node = parse(source, mode="exec")
    transformed = StarredUnpackingTransformer().visit(node)
    result = astor.to_source(transformed)
    expected = "print(*(list(range(1)) + list(range(3))))"
    assert expected in result


# Generated at 2022-06-23 23:01:41.517794
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None, 'Unit test failed: Could not create StarredUnpackingTransformer'

# Generated at 2022-06-23 23:01:42.774353
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer((3,4)).target == (3,4)



# Generated at 2022-06-23 23:01:46.194123
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .unparse import Unparser
    from .unparse import format_ast

    node = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(node)
    Unparser(node, {'print': print})
    print(format_ast(node))



# Generated at 2022-06-23 23:01:51.846244
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astunparse
    source_code = "foo(1, 2, *[3, 4, 5], 6, 7)"
    parsed_ast = ast.parse(source_code)
    expected_ast = ast.parse("foo(*(([1, 2] + list([3, 4, 5])) + [6, 7]))")

    assert StarredUnpackingTransformer().visit(parsed_ast) == expected_ast
    assert astunparse.unparse(StarredUnpackingTransformer().visit(parsed_ast)) == \
        astunparse.unparse(expected_ast)



# Generated at 2022-06-23 23:01:58.873329
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""
    # test empty list
    transformer = StarredUnpackingTransformer()
    tree = ast.List(elts=[], ctx=ast.Load())
    new_tree = transformer.transform(tree)
    assert isinstance(new_tree, ast.List)
    assert not transformer.tree_changed
    assert new_tree.elts == []

    # test list without *x
    tree = ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)], ctx=ast.Load())
    new_tree = transformer.transform(tree)
    assert isinstance(new_tree, ast.List)
    assert not transformer.tree_changed

# Generated at 2022-06-23 23:02:09.357127
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_ = StarredUnpackingTransformer()
    list_ = ast.List(elts=[
        ast.Num(n=2),
        ast.Starred(value=ast.Name(id='range')),
        ast.Num(n=1)
    ])
    args = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(
                value=ast.Name(id='range')
            ),
        ],
        keywords=[]
    )

    assert class_._has_starred(list_.elts)
    assert class_._has_starred(args.args)


# Generated at 2022-06-23 23:02:19.546324
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .remove_insignificant_whitespace import RemoveInsignificantWhitespaceTransformer
    from .exhaustive_visitor import ExhaustiveTransformer
    from .lift_list_comprehension import LiftListComprehensionTransformer
    tree = ast.parse('[2, *range(10), 1]')
    tree = StarredUnpackingTransformer(tree).visit(tree)
    tree = RemoveInsignificantWhitespaceTransformer(tree).visit(tree)
    RestoreTransformer(tree).visit(tree)
    tree = LiftListComprehensionTransformer(tree).visit(tree)
    tree = StarredUnpackingTransformer(tree).visit(tree)
    tree = ExhaustiveTransformer(tree).visit(tree)

# Generated at 2022-06-23 23:02:20.141105
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:02:21.430933
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    obj = StarredUnpackingTransformer()



# Generated at 2022-06-23 23:02:28.127726
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    class Test:
        def __init__(self, unpack_sequence=True):
            self.unpack_sequence = unpack_sequence

        def run(self, source: str) -> str:
            node = ast.parse(source)

            if self.unpack_sequence:
                node = StarredUnpackingTransformer().visit(node)

            return compile(node, '<string>', 'exec')

    test = Test()

    source = '''
print(*[1], *[2])
'''

    expected_code = '''
print(*([1] + [2]))
'''

    assert test.run(source).co_code == compile(expected_code, '<string>', 'exec').co_code

    source = '''
print([1], [2])
'''

# Generated at 2022-06-23 23:02:34.965757
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1]')
    assert(tree.body[0].value.elts[0].n == 2), 'Ast tree should have correct value' 
    trans = StarredUnpackingTransformer().visit(tree)
    assert(trans.body[0].value.op.right.elts[0].elts[0].n == 1), 'Starred unpacking should have correct value'

# Generated at 2022-06-23 23:02:41.623340
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    code = """
list_a = [2, *range(10), 1]
"""
    code_ast = ast.parse(code)
    expected_ast = ast.parse("""
list_a = [2] + list(range(10)) + [1]
""")
    result_ast = transformer.visit(code_ast)
    assert ast.dump(result_ast) == ast.dump(expected_ast)


# Generated at 2022-06-23 23:02:49.848058
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    parser = ast.CParser()
    test_input = parser.parse(
        """a = print(*range(1), *range(3))""", mode='exec')
    expected_output = parser.parse(
        """a = print(*(list(range(1)) + list(range(3))))""", mode='exec')

    result = StarredUnpackingTransformer().visit(test_input)
    print(ast.dump(result))
    print(ast.dump(expected_output))
    assert ast.dump(result) == ast.dump(expected_output)

# Generated at 2022-06-23 23:02:56.900414
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    s = StarredUnpackingTransformer()
    data = [
        ast.List(elts=[
            ast.Num(n=2),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
            ast.Num(n=1)
        ],
        ),
        ast.List(elts=[
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
            ast.Starred(value=ast.Name(id='range', ctx=ast.Load())),
        ]),
        ast.List(elts=[ast.Num(n=5)])
    ]
    # We have to recreate module each time, because it will be used once by visitor
    for i, d in enumerate(data, 1):
        m = ast.parse

# Generated at 2022-06-23 23:03:08.443420
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    nodelist = [ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])), ast.Num(n=1)]
    instance = StarredUnpackingTransformer()
    assert isinstance(instance, StarredUnpackingTransformer) 
    assert isinstance(instance, BaseNodeTransformer)
    arglist = [ast.Num(n=2), ast.Starred(value=ast.Call(func=ast.Name(id='list'), args=[ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])], keywords=[])), ast.Num(n=1)]

# Generated at 2022-06-23 23:03:11.079080
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:03:18.970139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import python_minifier.ast_compare
    import astor

    test_code_input = [
        'print(*range(1), *range(3))',
        'print(',
        '    *range(1),',
        '    *range(3),',
        ')',
    ]

    test_code_output = [
        'print(*(list(range(1)) + list(range(3))))',
        'print(',
        '    *(list(range(1)) + list(range(3))),',
        ')',
    ]

    for code_input, code_output in zip(test_code_input, test_code_output):
        tree_input = ast.parse(code_input)
        tree_expected_output = ast.parse(code_output)
        StarredUnpacking

# Generated at 2022-06-23 23:03:26.632312
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = 'l = [2, *range(10), 1]\n' \
           'print(1, *range(1), *range(3))'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit_Module(tree)

    expected_code = 'l = [2] + list(range(10)) + [1]\n' \
                    'print(*(list(range(1)) + list(range(3))))'
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 23:03:35.063952
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    t = StarredUnpackingTransformer()

    s = """\
    def f():
        [2, *range(10), 1]
        print(*range(1), *range(3))
        """
    tree = ast.parse(s)
    new_tree = t.visit(tree)

    assert isinstance(new_tree, ast.Module)
    assert isinstance(new_tree.body[0], ast.FunctionDef)
    assert isinstance(new_tree.body[0].body[0], ast.Expr)
    assert isinstance(new_tree.body[0].body[0].value, ast.BinOp)
    assert isinstance(new_tree.body[0].body[1], ast.Expr)

# Generated at 2022-06-23 23:03:46.617596
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()._split_by_starred([]) == [[]]
    assert StarredUnpackingTransformer()._split_by_starred([ast.Num(1)]) == [[ast.Num(1)]]
    assert StarredUnpackingTransformer()._split_by_starred([ast.Starred(ast.Name('__test__'), ast.Store())]) == [[ast.Starred(ast.Name('__test__'), ast.Store())]]
    assert StarredUnpackingTransformer()._split_by_starred([ast.Name('__test__'), ast.Name('__test__2__')]) == [[ast.Name('__test__'), ast.Name('__test__2__')]]

# Generated at 2022-06-23 23:03:50.749605
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Test input
    code = "print(*range(1), *range(3))"

    # Expecting output
    expected_code = "print(*(list(range(1)) + list(range(3))))"

    # Transform code
    actual_code = StarredUnpackingTransformer().visit_code_string(code)

    # Actual output
    assert actual_code == expected_code


# Generated at 2022-06-23 23:03:57.357835
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    source = """\
        [2, *range(10), 1]
        print(*range(1), *range(3))"""
    from typed_astunparse import unparse
    from ..wrapper import compile_source

    transpiled = compile_source(source, star=True)
    expected = """\
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))"""
    assert unparse(transpiled).rstrip() == expected

# Generated at 2022-06-23 23:03:58.767431
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-23 23:04:07.069752
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    stmnts = [
        "print(*range(1), *range(3))",
        "list(range(10))[*range(2), 1, *range(2), -1, *range(2)]",
        ]

    for stmt in stmnts:
        try:
            tree = ast.parse(stmt)
        except SyntaxError:
            pytest.skip("Syntax error")

        StarredUnpackingTransformer().visit(tree)
        if stmt != '\n'.join(ast.unparse(tree).splitlines()[1:-1]):
            print('\n', stmt)
            print(ast.unparse(tree))
        assert stmt == '\n'.join(ast.unparse(tree).splitlines()[1:-1])


# Generated at 2022-06-23 23:04:18.412551
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Simple list with unstarred elements
    tree_before_ls = ast.List([ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])
    tree = StarredUnpackingTransformer.visit(tree_before_ls)
    tree_after_ls = ast.List([ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])
    assert tree == tree_after_ls

    # Simple list with starred element
    tree_before_ls = ast.List([ast.Num(n=1), ast.Num(n=2), ast.Starred(
        value=ast.Name(id='range'))])
    tree = StarredUnpackingTransformer.visit(tree_before_ls)
    tree_after_ls = ast.List

# Generated at 2022-06-23 23:04:22.723323
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from check_ast import is_same_ast

    code = "[2, *range(10), 1]"

    tree = ast.parse(code)
    expected = ast.parse('[2] + list(range(10)) + [1]')

    result = StarredUnpackingTransformer(tree).result()

    assert is_same_ast(result, expected)


# Generated at 2022-06-23 23:04:25.477012
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # given
    code = '[2, *range(10), 1]'
    expected_code = '[2] + list(range(10)) + [1]'

    # when
    compiled_code = run_transforms(code, StarredUnpackingTransformer)

    # then
    assert compiled_code == expected_code



# Generated at 2022-06-23 23:04:27.504707
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import transform_source

# Generated at 2022-06-23 23:04:36.672651
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    node = ast.parse('print(*range(10))')
    new_node = StarredUnpackingTransformer().visit(node)
    assert ast.dump(new_node) == \
        "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Starred(value=Call(func=Name(id='__add__', ctx=Load()), args=[Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[])], keywords=[]))], keywords=[]))], type_ignores=[])"

# Generated at 2022-06-23 23:04:48.215141
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    class NodeVisitor(ast.NodeVisitor):
        def visit_Num(self, node: ast.Num):
            assert node.n == 2
            return True

        def visit_Starred(self, node: ast.Starred):
            assert isinstance(node.value, ast.Call)
            return True

    node = ast.parse('[2, *range(10), 1]', mode='eval').body
    assert isinstance(node, ast.List)
    node = StarredUnpackingTransformer().visit(node)
    assert isinstance(node, ast.BinOp)
    assert isinstance(node.left, ast.List)
    assert isinstance(node.right, ast.BinOp)
    assert isinstance(node.right.right, ast.List)

# Generated at 2022-06-23 23:04:50.607569
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    x = StarredUnpackingTransformer()
    assert isinstance(x, StarredUnpackingTransformer)
    print('Passed!')


# Generated at 2022-06-23 23:05:00.903976
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    tree = ast.parse(
        dedent(
            """\
            print(*range(1), *range(3))
            """
        )
    )
    res = StarredUnpackingTransformer().visit(tree)
    res = ast.fix_missing_locations(res)

# Generated at 2022-06-23 23:05:08.471344
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    code = """
        [2, *range(10), 1]
        print(2, *range(10), 1)
        print(2, *range(10), *range(4), 1)
    """
    expected = """
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
        print(*(list(range(1)) + list(range(3))))
    """
    resp, msg = compiler.ast_test_helper(code, expected, StarredUnpackingTransformer)
    print(msg)
    assert resp, msg

    code = """
        square = lambda x: x ** 2
        print(*map(square, range(4)))
    """

# Generated at 2022-06-23 23:05:14.991886
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Convert list of arguments / list to sum of lists."""
    _source = [
        'a_list = [2, *range(10), 1]',
        'list_of_list = [[1, 2], *list_of_list, [3]]']
    _expected = [
        'a_list = [2] + list(range(10)) + [1]',
        'list_of_list = ['
        '[1, 2]] + list(list_of_list) + [[3]]']
    for src, exp in zip(_source, _expected):
        cmp_expected_actual(
            StarredUnpackingTransformer, src, exp,
            ignore_whitespace=True)


# Generated at 2022-06-23 23:05:16.892864
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    for ver in (3, 4):
        assert StarredUnpackingTransformer.ver_supported(ver) == True

# Generated at 2022-06-23 23:05:19.100848
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from unittest.mock import Mock
    from ..utils import get_code

    assert get_code(StarredUnpackingTransformer()) == 'StarredUnpackingTransformer()'

# Generated at 2022-06-23 23:05:30.829396
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_helpers import round_trip, round_trip_with_ast_compare

    test_cases = [
        ("[a for b in c]", "[a for b in c]"),
        ("[*range(10)]", "[*list(range(10))]"),
        ("print(*range(1), *range(3))", "print(*(list(range(1)) + list(range(3))))"),
        ("print(*range(1))", "print(*list(range(1)))"),
        ("[**a]", "[**a]"),
        ("[*a, *b, c]", "([*a] + [*b] + [c])"),
    ]


# Generated at 2022-06-23 23:05:39.415453
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    from .ast_transformer import ASTTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = """
    [1, 2, *range(1), 3]
    """
    tree = ast.parse(code)
    trans = StarredUnpackingTransformer()
    tree = trans.visit(tree)
    print(unparse(tree))
    

# Generated at 2022-06-23 23:05:50.930986
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from compiler.transformer import Transformer
    from compiler.utils import dump

    def test(s: str) -> str:
        return dump(Transformer(
            version=(3, 4),
            plugins=[StarredUnpackingTransformer]).visit(ast.parse(s)))

    assert test('*args') == '*(args)\n'
    assert test('a(*args)') == "a(*(args))\n"
    assert test('a(b, *args)') == "a(b, *(args))\n"
    assert test('a(b, c, *args)') == "a(b, c, *(args))\n"
    assert test('print(1)') == "print(*(1))\n"

# Generated at 2022-06-23 23:06:01.689656
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from textwrap import dedent
    from ..fixtures.compile_test import CompileTestCase
    
    # Example 1
    # node = ast.parse(dedent('''
    #     [2, *range(10), 1]
    #     print(*range(1), *range(3))
    # '''))
    # target_node = ast.parse(dedent('''
    #     [2] + list(range(10)) + [1]
    #     print(*(list(range(1)) + list(range(3))))
    # '''))
    # CompileTestCase(StarredUnpackingTransformer()).assert_compile(node, target_node)
    
    # Example 2

# Generated at 2022-06-23 23:06:03.035110
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ast1 = StarredUnpackingTransformer()


# Generated at 2022-06-23 23:06:10.619353
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Set DATA to a value
    DATA = """\
print(*range(1), *range(3))\
"""
    # Call function parse with argument DATA and keyword arguments mode='exec'
    # Assign to root the value returned
    root = ast.parse(DATA, mode='exec')
    # Assign to StarredUnpackingTransformer the class StarredUnpackingTransformer
    StarredUnpackingTransformer = StarredUnpackingTransformer
    # Assign to StarredUnpackingTransformer_instance the value instanciated from class StarredUnpackingTransformer
    StarredUnpackingTransformer_instance = StarredUnpackingTransformer()
    # Assign to func_call the value returned by method visit_Call of StarredUnpackingTransformer_instance with argument root

# Generated at 2022-06-23 23:06:17.748721
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    fr = '''print(*range(1), *range(3))'''
    expected = '''print(*(list(range(1)) + list(range(3))))'''
    tree = ast.parse(fr)
    tree_expected = ast.parse(expected)
    cur_transformer = StarredUnpackingTransformer()
    new_tree = cur_transformer.visit(tree)
    assert(astor.to_source(new_tree) == astor.to_source(tree_expected))


# Generated at 2022-06-23 23:06:24.171433
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import LazyNodeTransformer

    source = 's = [2, *range(10), 1]'
    expected = 's = [2] + list(range(10)) + [1]'
    tr = LazyNodeTransformer(StarredUnpackingTransformer)
    BaseNodeTransformerTestCase(source, expected, transformers=[tr]).test()


# Generated at 2022-06-23 23:06:34.961484
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    node = ast.parse(
        textwrap.dedent("""
            l = [2, *range(10), 1]
            [2, *range(10), 1]
            l2 = [2, *range(10), 1]
        """)).body

    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-23 23:06:40.008359
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    tree = ast.parse('[2, *range(10), 1]')
    transformer.visit(tree)
    assert transformer.tree_changed
    assert str(transformer.tree) == '[2] + list(range(10)) + [1]'


# Generated at 2022-06-23 23:06:48.847875
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    assert ast.parse('''d = dict(a='1', b='2')
d.update(a='3', *[])''') == StarredUnpackingTransformer.run('''d = dict(a='1', b='2')
d.update(a='3', *[])''')

    assert ast.parse('''L = list(range(10))
L1 = L + [1]
L1''') == StarredUnpackingTransformer.run('''L = list(range(10))
L1 = L + [1]
L1''')


# Generated at 2022-06-23 23:06:53.265791
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = source_code_of(StarredUnpackingTransformer)
    tree = ast.parse(source)

    new_tree = StarredUnpackingTransformer().visit(tree)

    assert source == to_code(tree)
    assert source != to_code(new_tree)



# Generated at 2022-06-23 23:07:00.799703
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    # Given
    node = ast.parse("[2, *range(10), 1]").body[0]

    # When
    result = StarredUnpackingTransformer.run(node)

    # Then
    expected = ast.BinOp(
        left=ast.List(elts=[
            ast.Num(n=2),
        ]),
        right=ast.Call(
            func=ast.Name(id='list'),
            args=[
                ast.Call(
                    func=ast.Name(id='range'),
                    args=[
                        ast.Num(n=10),
                    ],
                    keywords=[]
                )
            ],
            keywords=[]
        ),
        op=ast.Add()
    )

# Generated at 2022-06-23 23:07:12.023544
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
            print(1, *range(10), 2)
            print()
            """

    # Without StarredUnpackingTransformer
    tree = ast.parse(code)
    expected_tree = ast.parse(code)
    assert tree == expected_tree

    # With StarredUnpackingTransformer
    tree = ast.parse(code)
    expected_tree = ast.parse(
        """
            print(*(list(range(10)) + [1] + [2]))
            print()
            """)
    tree = StarredUnpackingTransformer().visit(tree)
    expected_tree = StarredUnpackingTransformer().visit(expected_tree)
    assert tree == expected_tree



# Generated at 2022-06-23 23:07:13.917165
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print('Testing constructor of class StarredUnpackingTransformer')
    StarredUnpackingTransformer()
    print('Constructor of class StarredUnpackingTransformer works')


# Generated at 2022-06-23 23:07:14.841700
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer is not None

# Generated at 2022-06-23 23:07:16.238650
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().__doc__ is not None


# Generated at 2022-06-23 23:07:21.322156
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse('list(a, *b, *c, d)')
    StarredUnpackingTransformer().visit(tree)

    ref = ast.parse('list(*(list(a) + list(b) + list(c) + list(d)))')

    assert ast.dump(tree) == ast.dump(ref)


# Generated at 2022-06-23 23:07:29.718214
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import pytest
    from ministall.ast_transformations import StarredUnpackingTransformer

    code = 'print(*range(1), *range(2))'
    expected_code = 'print(*(list(range(1)) + list(range(2))))'

    result = StarredUnpackingTransformer().visit(ast.parse(code))

    import astor
    assert astor.to_source(result) == expected_code

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        StarredUnpackingTransformer().visit('foo')



# Generated at 2022-06-23 23:07:34.748720
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    ''' Tests that the constructor of class StarredUnpackingTransformer
    raises no exceptions and returns a StarredUnpackingTransformer object.
    '''
    # Arrange
    expected = StarredUnpackingTransformer
    
    # Act
    actual = StarredUnpackingTransformer()
    
    # Assert
    assert isinstance(actual, expected)

# Generated at 2022-06-23 23:07:40.341991
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    body = [
        ast.List(elts=[
            ast.List(elts=[
                ast.Call(
                    func=ast.Name(id='range'),
                    args=[ast.Num(n=10)],
                    keywords=[])
            ]),
        ]),
        ast.Name(id='20')
    ]

    expected_elts = [
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(n=10)],
                keywords=[])],
            keywords=[]),
        ast.Num(n=20)
    ]

    expected = ast.List(elts=expected_elts)

    t = StarredUnpackingTransformer()

# Generated at 2022-06-23 23:07:51.727341
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer([2, *range(1, 4), *range(5, 6), 1], scope={
        'range': range, 'list': list}).run_code() == '[2, 1, 2, 3, 5, 1]'
    assert StarredUnpackingTransformer([1, *range(1, 4), *range(5, 6), 2], scope={
        'range': range, 'list': list}).run_code() == '[1, 1, 2, 3, 5, 2]'
    assert StarredUnpackingTransformer([1, *range(1, 4), *range(5, 6), 1], scope={
        'range': range, 'list': list}).run_code() == '[1, 1, 2, 3, 5, 1]'

# Generated at 2022-06-23 23:07:53.175871
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None
    

# Generated at 2022-06-23 23:07:54.796314
# Unit test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-23 23:08:06.602544
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    t = StarredUnpackingTransformer()
    t._tree_changed = False

    # 1.1. test_StarredUnpackingTransformer_visit_List-1
    expr = ast.parse("[2, *range(10), 1]")
    result = t.visit(expr)
    assert str(result) == "[2, *list(range(10)), 1]"
    assert t._tree_changed is False

    # 1.2. test_StarredUnpackingTransformer_visit_List-2
    t._tree_changed = False
    expr = ast.parse("[2, *range(10), 1, *range(12,20)]")
    result = t.visit(expr)

# Generated at 2022-06-23 23:08:14.494669
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():

    def trans(func):

        class T(StarredUnpackingTransformer):

            def visit_Call(self, node):

                if node.func.id == 'foo':
                    # return ast.Name(id="bar")
                    node.func.id = "bar"
                    return node
                else:
                    return self.generic_visit(node)

        parsed = ast.parse(inspect.getsource(func))
        parsed = T().visit(parsed)
        return parsed

    def foo(x, *args):
        # foo(1, *(2, 3))
        print(x)
        # print(args)
        foo(x, *args)

    trans(foo)



# Generated at 2022-06-23 23:08:26.162469
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    print(StarredUnpackingTransformer)
    assert StarredUnpackingTransformer is not None
    print(StarredUnpackingTransformer._merge_lists)
    assert StarredUnpackingTransformer._merge_lists is not None
    print(StarredUnpackingTransformer._prepare_lists)
    assert StarredUnpackingTransformer._prepare_lists is not None
    print(StarredUnpackingTransformer._split_by_starred)
    assert StarredUnpackingTransformer._split_by_starred is not None
    print(StarredUnpackingTransformer._to_sum_of_lists)
    assert StarredUnpackingTransformer._to_sum_of_lists is not None
    testdata = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """


# Generated at 2022-06-23 23:08:32.035061
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import ast as py_ast
    import typed_ast.ast3 as typed_ast
    import astor
    expected_source = f'[2, *range(10), 1]\n'
    source = f'[2, *range(10), 1]\n'
    expected_code = py_ast.parse(expected_source)
    expected_code = expected_code.body[0].value
    node = py_ast.parse(source)
    node = node.body[0].value
    actual_code = StarredUnpackingTransformer().visit(node)
    assert astor.to_source(actual_code) == astor.to_source(expected_code)


# Generated at 2022-06-23 23:08:33.472233
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()



# Generated at 2022-06-23 23:08:40.377090
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor

    original_tree = ast.parse("[2, *range(10), 1]")
    optimized_tree = ast.parse("[2] + list(range(10)) + [1]")
    new_tree = StarredUnpackingTransformer(original_tree)

    original_code = astor.to_source(original_tree)
    optimized_code = astor.to_source(optimized_tree)
    code = astor.to_source(new_tree.tree)

    print("ORIGINAL:", original_code)
    print("CHANGED:", code)

    assert original_code != optimized_code
    assert code == optimized_code


# Generated at 2022-06-23 23:08:42.317562
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .constructor_test import check_transformer
    check_transformer(StarredUnpackingTransformer)

# Generated at 2022-06-23 23:08:53.539238
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source

    source = '[2, *range(10), 1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    code = compile_source(tree)
    context = {}
    exec(code, context)
    assert context['__builtins__'] is globals()['__builtins__']
    assert context['__name__'] == '__main__'
    assert context['__package__'] is None
    assert context['__loader__'] is None
    assert context['__doc__'] is None
    assert context['__spec__'] is None
    assert context['norm_list'] == [2] + list(range(10)) + [1]
    
if __name__ == '__main__':
    test_StarredUnpackingTransformer_visit_List

# Generated at 2022-06-23 23:08:57.315471
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    assert StarredUnpackingTransformer().visit(
        ast.parse("[2, *range(10), 1]")
    ) == ast.parse("[2] + list(range(10)) + [1]")



# Generated at 2022-06-23 23:08:57.962627
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    pass

# Generated at 2022-06-23 23:09:04.023518
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test code
    test_code = "[2, *range(10), 1]\n"

    # Test node
    test_node = ast.parse(test_code)

    # Test transformer
    test_transformer = StarredUnpackingTransformer()
    test_transformer.visit(test_node)

    # Asserts
    assert test_code != astor.to_source(test_node)



# Generated at 2022-06-23 23:09:11.122887
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    tree = ast.parse('[2, *range(10), 1] + print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-23 23:09:16.505251
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    tree = ast.parse("func(1, *range(2), 3)")
    E = StarredUnpackingTransformer("<fake_file>").run(tree)
    
    # Then
    assert E(tree) == E("""
    func(*(list(range(1)) + list(range(2)) + [3]))
    """)
