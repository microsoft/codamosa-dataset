

# Generated at 2022-06-18 00:30:36.678824
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    src = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    assert round_trip(src, StarredUnpackingTransformer) == expected


# Generated at 2022-06-18 00:30:47.608052
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import Starred, List, Call, Name, Add, BinOp
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import ASTError
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import ASTError
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import ASTError
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import AST

# Generated at 2022-06-18 00:30:59.628952
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:31:08.173937
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        CODE = 'print(*range(1), *range(3))'
        AST = parse(CODE).body[0]


# Generated at 2022-06-18 00:31:17.563847
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:24.756035
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:32.611858
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            code = '[2, *range(10), 1]'
            expected = '[2] + list(range(10)) + [1]'
            self.assertTransformEquals(code, expected)

        def test_empty(self):
            code = '[]'
            expected = '[]'
            self.assertTransformEquals(code, expected)

        def test_empty_with_starred(self):
            code = '[*[]]'
            expected = '[]'
            self.assertTransformEquals(code, expected)


# Generated at 2022-06-18 00:31:42.867692
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer_visit_Call
    from .base import BaseNodeTransformer_visit_List
    from .base import BaseNodeTransformer_visit_Starred
    from .base import BaseNodeTransformer_visit_Call_args
    from .base import BaseNodeTransformer_visit_Call_func
    from .base import BaseNodeTransformer_visit_Call_keywords
    from .base import BaseNodeTransformer_visit_List_elts
    from .base import BaseNodeTransformer_visit_Starred_value
    from .base import BaseNodeTransformer_visit_BinOp_left
    from .base import BaseNodeTransformer_visit_BinOp_op
    from .base import Base

# Generated at 2022-06-18 00:31:50.925779
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        target_class = TestTransformer

        def test_empty(self):
            self.assertTransformedEquals(
                '[]',
                '[]')

        def test_no_starred(self):
            self.assertTransformedEquals(
                '[1, 2, 3]',
                '[1, 2, 3]')


# Generated at 2022-06-18 00:32:00.261026
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:15.980581
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: Call) -> Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: Call) -> Call:
            return node

    # Test 1

# Generated at 2022-06-18 00:32:27.295360
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap
    import sys

    code = textwrap.dedent('''
    print(*range(1), *range(3))
    ''')

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    print(astunparse.unparse(tree))

    code = textwrap.dedent('''
    print(*range(1), *range(3), sep=' ')
    ''')

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    print(astunparse.unparse(tree))


# Generated at 2022-06-18 00:32:36.342365
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:48.055223
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
            print(*range(1), *range(3))
        To:
            [2] + list(range(10)) + [1]
            print(*(list(range(1)) + list(range(3))))
            
        """
        target = (3, 4)

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True

            return False


# Generated at 2022-06-18 00:32:55.868785
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

# Generated at 2022-06-18 00:33:05.483479
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'
        target = (3, 4)

        def test_simple(self):
            node = ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])
            expected = ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])
            self.check(node, expected)


# Generated at 2022-06-18 00:33:15.332382
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import assert_equal_ast
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse("""
        print(*range(1), *range(3))
    """).body[0]

    expected = ast.parse("""
        print(*(list(range(1)) + list(range(3))))
    """).body[0]

    assert_equal_ast(
        StarredUnpackingTransformer(TestTransformer()).visit(node),
        expected
    )


# Generated at 2022-06-18 00:33:24.748695
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:28.795145
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-18 00:33:30.365443
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:33:49.905497
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTest

# Generated at 2022-06-18 00:34:00.230888
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node):
            return node

    def test_transformer(transformer):
        tree = ast.parse("""
        print(*range(1), *range(3))
        """)
        tree = transformer().visit(tree)
        assert str(tree) == """
        print(*(list(range(1)) + list(range(3))))
        """

    test_transformer(TestTransformer)

# Generated at 2022-06-18 00:34:11.318137
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:20.669722
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:31.144529
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:43.254017
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer

        def test_simple(self):
            tree = ast.parse('print(1)')
            self.assert_transformed(tree, 'print(1)')

        def test_starred(self):
            tree = ast.parse('print(*range(1))')
            self.assert_transformed(tree, 'print(*list(range(1)))')


# Generated at 2022-06-18 00:34:54.212240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Test 1
    tree = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Expr(value=BinOp(left=List(elts=[Num(n=2)]), op=Add(), right=BinOp(left=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=10)], keywords=[])], keywords=[]), op=Add(), right=List(elts=[Num(n=1)]))))])"

    # Test 2
    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)
   

# Generated at 2022-06-18 00:35:04.957112
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add

    tree = ast.parse('print(*range(1), *range(3))')
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:35:09.559954
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    assert round_trip(code, StarredUnpackingTransformer) == expected


# Generated at 2022-06-18 00:35:19.851011
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:47.751441
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import roundtrip_unparse
    from .test_utils import roundtrip_visit
    from .test_utils import roundtrip_visit_unparse
    from .test_utils import roundtrip_visit_unparse_compare
    from .test_utils import roundtrip_visit_unparse_compare_ast
    from .test_utils import roundtrip_visit_unparse_compare_ast_source
    from .test_utils import roundtrip_visit_unparse_compare_source
    from .test_utils import roundtrip_visit_unparse_compare_source_ast
    from .test_utils import roundtrip_visit_unparse_compare_source_ast_source
    from .test_utils import roundtrip_visit_unparse_compare_source_source

# Generated at 2022-06-18 00:35:54.436065
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from . import ast_converter
    from . import ast_unparser
    from . import ast_parser

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast_converter.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected

    code = """
    print(*range(1), *range(3), sep=' ')
    """
    expected = """
    print(*(list(range(1)) + list(range(3))), sep=' ')
    """
    tree = ast_converter.parse(code)
    tree = StarredUn

# Generated at 2022-06-18 00:35:58.624922
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-18 00:36:03.680487
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:36:09.916450
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import assert_equal_ast
    from .test_utils import round_trip

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    tree = round_trip(tree)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:36:18.144015
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import _ast
    from .base import _ast_gen
    from .base import _ast_list
    from .base import _ast_obj
    from .base import _ast_str
    from .base import _ast_tuple
    from .base import _ast_type
    from .base import _ast_unaryop
    from .base import _ast_unaryop_type
    from .base import _ast_unaryop_value
    from .base import _ast_value
    from .base import _ast_visit

# Generated at 2022-06-18 00:36:24.404269
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:36:33.866991
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
    import astunparse
    import astor
    import ast
   

# Generated at 2022-06-18 00:36:37.242037
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))")

    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-18 00:36:47.994073
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:34.194966
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import compile_source
    from .. import ast_utils
    from .. import source_utils

    source = "[2, *range(10), 1]"
    expected_source = "[2] + list(range(10)) + [1]"

    tree = compile_source(source, mode='eval')
    assert ast_utils.dump_ast(tree) == source

    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    assert ast_utils.dump_ast(tree) == expected_source
    assert transformer.tree_changed


# Generated at 2022-06-18 00:37:37.663031
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected


# Generated at 2022-06-18 00:37:48.105308
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer_visit_Call as visit_Call
    from .base import BaseNodeTransformer_generic_visit as generic_visit
    from .base import BaseNodeTransformer_visit as visit
    from .base import BaseNodeTransformer_visit_List as visit_List
    from .base import BaseNodeTransformer_visit_Starred as visit_Starred
    from .base import BaseNodeTransformer_visit_Name as visit_Name
    from .base import BaseNodeTransformer_visit_BinOp as visit_BinOp
    from .base import BaseNodeTransformer_visit_Add as visit_Add
    from .base import BaseNodeTransformer_visit_Call as visit_Call

# Generated at 2022-06-18 00:37:54.088148
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:37:56.346426
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    class_ = StarredUnpackingTransformer()
    assert class_ is not None

# Generated at 2022-06-18 00:38:06.229835
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast, load_ast

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = load_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert dump_ast(tree) == expected

    code = "[*range(10), 1]"
    expected = "list(range(10)) + [1]"

    tree = load_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert dump_ast(tree) == expected

    code = "[2, *range(10)]"

# Generated at 2022-06-18 00:38:10.147575
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import compare_source

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    tree = round_trip(source, StarredUnpackingTransformer)
    compare_source(tree, expected)


# Generated at 2022-06-18 00:38:17.336153
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        ([2] + list(range(10)) + [1])
        """

    Test().test()


# Generated at 2022-06-18 00:38:24.566600
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:35.362444
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast

    class DummyNodeTransformer(ast.NodeTransformer):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=1)])

    class DummyNodeVisitor(ast.NodeVisitor):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=2)])

    class DummyNodeTransformer2(ast.NodeTransformer):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=3)])

    class DummyNodeVisitor2(ast.NodeVisitor):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=4)])

    # Test that NodeTrans

# Generated at 2022-06-18 00:40:19.713712
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(BaseNodeTransformerTestCase):
        target_class = TestTransformer

        def test_Call(self):
            tree = ast.parse('print(*range(1), *range(3))')
            expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
            self.check_ast(tree, expected)

# Generated at 2022-06-18 00:40:26.305212
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
    import astor
    import astunparse
    import sys
   