

# Generated at 2022-06-18 00:30:29.738527
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(BaseNodeTransformerTestCase):
        target_class = TestTransformer

        def test_StarredUnpackingTransformer_visit_Call(self):
            code = """
            print(*range(1), *range(3))
            """
            expected = """
            print(*(list(range(1)) + list(range(3))))
            """
            self.check(code, expected)


# Generated at 2022-06-18 00:30:36.852524
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:30:42.713501
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    import ast
    code = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    print(astor.to_source(tree))

if __name__ == '__main__':
    test_StarredUnpackingTransformer()

# Generated at 2022-06-18 00:30:43.955225
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:30:49.486494
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:31:00.155028
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:08.673207
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])

    class TestTransformer2(BaseNodeTransformer):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=1), ast.Num(n=2), ast.Starred(value=ast.Name(id='a'))])


# Generated at 2022-06-18 00:31:09.551351
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:31:16.148220
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = """
    print(*range(1), *range(3))
    """
    expected_code = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert BaseNodeTransformer.dump_ast(tree) == expected_code


# Generated at 2022-06-18 00:31:22.144824
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = 'print(*range(1), *range(3))'
    tree = parse(code)
    StarredUnpackingTransformer.run_on_tree(tree)
    assert BaseNodeTransformer.tree_changed is True

# Generated at 2022-06-18 00:31:28.213542
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:31:38.527718
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:45.329905
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import astunparse
    import textwrap

    code = textwrap.dedent('''
        print(*range(1), *range(3))
    ''')
    expected = textwrap.dedent('''
        print(*(list(range(1)) + list(range(3))))
    ''')

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(tree) == expected



# Generated at 2022-06-18 00:31:52.208051
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_no_starred(self):
            self.check_equal_source(
                '[1, 2, 3]',
                '[1, 2, 3]',
            )


# Generated at 2022-06-18 00:31:58.943122
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    node = ast.parse('[2, *range(10), 1]')
    node = DummyTransformer().visit(node)
    node = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:32:09.051739
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:16.273966
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer

        def test_simple(self):
            code = "[2, *range(10), 1]"
            expected = "[2] + list(range(10)) + [1]"
            self.assertCodeTransformed(code, expected)

    Test().test_simple()


# Generated at 2022-06-18 00:32:27.746166
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_simple(self):
            tree = ast.parse('[1, 2, 3]')
            expected = ast.parse('[1, 2, 3]')
            self.assertTransformEqual(tree, expected)

        def test_starred(self):
            tree = ast.parse('[1, 2, *range(3)]')

# Generated at 2022-06-18 00:32:36.723714
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTest

# Generated at 2022-06-18 00:32:48.150541
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Num, Starred, Name, Call, Add, Load
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:33:08.230307
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:33:14.382418
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_output = """
        [2] + list(range(10)) + [1]
        """
        tree = ast.parse("""
        [2, *range(10), 1]
        """)

    TestCase.validate()


# Generated at 2022-06-18 00:33:16.792576
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'

# Generated at 2022-06-18 00:33:17.950252
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:33:26.850401
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import round_trip_with_transformer

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    assert round_trip_with_transformer(code, StarredUnpackingTransformer) == expected

    code = '[2, *range(10), 1, *range(3)]'
    expected = '[2] + list(range(10)) + [1] + list(range(3))'
    assert round_trip_with_transformer(code, StarredUnpackingTransformer) == expected

    code = '[2, *range(10), 1, *range(3), *range(4)]'

# Generated at 2022-06-18 00:33:31.114580
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected


# Generated at 2022-06-18 00:33:40.567367
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class DummyTransformer2(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class DummyTransformer3(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class DummyTransformer4(BaseNodeTransformer):
        def visit_Call(self, node):
            return node


# Generated at 2022-06-18 00:33:50.753582
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    node = parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:34:01.195312
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load, BinOp
    from typed_ast.ast3 import parse

    # Test 1
    node = Call(func=Name(id='print', ctx=Load()),
                args=[Starred(value=Name(id='range', ctx=Load()), ctx=Load()),
                      Starred(value=Name(id='range', ctx=Load()), ctx=Load())],
                keywords=[])

# Generated at 2022-06-18 00:34:03.002441
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:34:32.159599
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:34:43.682742
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap
    import io
    import sys

    code = textwrap.dedent('''\
        [2, *range(10), 1]
        ''')
    expected_code = textwrap.dedent('''\
        [2] + list(range(10)) + [1]
        ''')
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)
    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)
    out = io.StringIO()
    sys.stdout = out
    astunparse

# Generated at 2022-06-18 00:34:54.406489
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    import astunparse
    from . import ast_converter
    from . import ast_optimizer
    from . import ast_transformer

    code = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """
    expected = """
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    """

    tree = ast_converter.parse(code)
    tree = ast_optimizer.optimize(tree)
    tree = ast_transformer.transform(tree, StarredUnpackingTransformer)
    result = astunparse.unparse(tree)
    print(result)
    assert result == expected

# Generated at 2022-06-18 00:35:05.131771
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:15.732818
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:27.542128
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer

# Generated at 2022-06-18 00:35:38.422649
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer3(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return

# Generated at 2022-06-18 00:35:40.106743
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:35:49.883754
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:35:55.845886
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.ast3 import parse
    from typed_ast.transforms import StarredUnpackingTransformer

    tree = parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:36:47.196621
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:58.387151
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:37:06.069721
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:15.647470
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    import astor
    import textwrap

    source = textwrap.dedent("""
        [2, *range(10), 1]
        [2, *range(10), 1, *range(10)]
        [2, *range(10), 1, *range(10), *range(10)]
        [2, *range(10), 1, *range(10), *range(10), *range(10)]
    """)

# Generated at 2022-06-18 00:37:18.957596
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import assert_equal_ast
    from .test_utils import assert_equal_source

    source = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    tree = round_trip(source)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)
    assert_equal_source(expected, tree)


# Generated at 2022-06-18 00:37:28.205525
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.ast3 import BinOp, Add
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.ast3 import BinOp, Add
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.ast3 import BinOp, Add
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.ast3 import BinOp, Add
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.ast3 import BinOp, Add

# Generated at 2022-06-18 00:37:38.535855
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .transformer_test_case import TransformerTestCase

    class Test(TransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            node = ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])
            expected = ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])
            self.assertEqualAst(node, expected)

        def test_simple_starred(self):
            node = ast.List(elts=[ast.Num(n=1), ast.Starred(value=ast.Name(id='a'))])

# Generated at 2022-06-18 00:37:48.253123
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:38:00.203816
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast
    from .utils import compile_ast
    from .utils import eval_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = [ast.Starred(value=ast.Name(id='range'))]
            return node

    class TestTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = [ast.Starred(value=ast.Name(id='range'))]
            return node


# Generated at 2022-06-18 00:38:10.130445
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class MockTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    node = ast.parse("[2, *range(10), 1]")
    node = node.body[0].value
    assert isinstance(node, ast.List)

    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert transformer.tree_changed

    node = MockTransformer().visit(node)
    assert isinstance(node, ast.BinOp)
    assert isinstance(node.left, ast.List)
    assert isinstance(node.right, ast.BinOp)

# Generated at 2022-06-18 00:39:44.457811
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:39:47.999658
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    result = StarredUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(result) == expected


# Generated at 2022-06-18 00:39:57.874008
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import _ast
    from .base import _ast_fields
    from .base import _ast_mapping
    from .base import _ast_module
    from .base import _ast_node
    from .base import _ast_num_types
    from .base import _ast_str
    from .base import _ast_type_repr
    from .base import _ast_unary_op
    from .base import _ast_unary_ops
    from .base import _builtin_type
    from .base import _collections_abc

# Generated at 2022-06-18 00:40:02.431163
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import textwrap

    code = textwrap.dedent('''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    ''')

    expected = textwrap.dedent('''
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    ''')

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-18 00:40:11.470496
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import textwrap
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_visit_Call(self):
            code = textwrap.dedent('''\
            print(*range(1), *range(3))
            ''')
            tree = ast.parse(code)

# Generated at 2022-06-18 00:40:17.736841
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        target = (3, 4)

        def test_simple(self):
            code = 'print(1)'
            expected = 'print(1)'
            self.assertTransformEquals(code, expected)

        def test_starred(self):
            code = 'print(*range(1), *range(3))'
            expected = 'print(*(list(range(1)) + list(range(3))))'