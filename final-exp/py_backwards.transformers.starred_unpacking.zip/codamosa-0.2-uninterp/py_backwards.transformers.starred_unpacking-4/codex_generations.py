

# Generated at 2022-06-18 00:30:33.455283
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_load
    from .test_utils import round_trip_load_dump
    from .test_utils import round_trip_dump_load
    from .test_utils import round_trip_load_dump_load
    from .test_utils import round_trip_dump_load_dump
    from .test_utils import round_trip_load_dump_load_dump
    from .test_utils import round_trip_dump_load_dump_load
    from .test_utils import round_trip_load_dump_load_dump_load
    from .test_utils import round_trip_dump_load_dump_load_dump

# Generated at 2022-06-18 00:30:36.960681
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformed_ast(
                before='''
                    [2, *range(10), 1]
                ''',
                after='''
                    [2] + list(range(10)) + [1]
                '''
            )

    TestCase().run()


# Generated at 2022-06-18 00:30:47.859469
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_load
    from .test_utils import round_trip_eval
    from .test_utils import round_trip_exec
    from .test_utils import round_trip_exec_eval
    from .test_utils import round_trip_dump_load
    from .test_utils import round_trip_dump_exec
    from .test_utils import round_trip_dump_exec_eval
    from .test_utils import round_trip_dump_load_eval
    from .test_utils import round_trip_dump_load_exec
    from .test_utils import round_trip_dump_load_exec_eval
    from .test_utils import round_trip

# Generated at 2022-06-18 00:30:49.832315
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:30:57.031752
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import assert_equal_ast

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = round_trip(code, StarredUnpackingTransformer)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:31:06.157884
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap
    code = textwrap.dedent('''
    print(*range(1), *range(3))
    ''')
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    print(astunparse.unparse(tree))
    assert astunparse.unparse(tree) == textwrap.dedent('''
    print(*(list(range(1)) + list(range(3))))
    ''')


# Generated at 2022-06-18 00:31:07.188621
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None)

# Generated at 2022-06-18 00:31:16.673538
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load, Expr
    from typed_ast.ast3 import Module, FunctionDef, arguments, arg
    from typed_ast.ast3 import Assign, Store, NameConstant, Return, Str
    from typed_ast.ast3 import keyword, alias, withitem, comprehension, ExceptHandler
    from typed_ast.ast3 import arguments, arg, keyword, alias, withitem, comprehension, ExceptHandler
    from typed_ast.ast3 import arguments, arg, keyword, alias, withitem, comprehension, ExceptHandler
    from typed_ast.ast3 import arguments, arg, keyword, alias, withitem, comprehension, ExceptHandler
    from typed_ast.ast3 import arguments, arg, keyword, alias, withitem, comprehension, ExceptHandler


# Generated at 2022-06-18 00:31:24.149485
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTest

# Generated at 2022-06-18 00:31:32.339053
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    import inspect
    import sys
    import os
    import astunparse
    import astor
    import textwrap
    import io
    import tokenize
    import token
    import re
    import unittest
    from typing import Union, Iterable, List
    Splitted = Union[List[ast.expr], ast.Starred]
    ListEntry = Union[ast.Call, ast.List]

# Generated at 2022-06-18 00:31:45.785548
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
   

# Generated at 2022-06-18 00:31:52.495847
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
   

# Generated at 2022-06-18 00:31:59.115089
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer5(BaseNodeTransformer):
        def visit_List(self, node):
            return node


# Generated at 2022-06-18 00:32:09.168101
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:32:18.551771
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:32:29.305939
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:37.749500
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = parse("print(*range(1), *range(3))")
    node = StarredUnpackingTransformer().visit(node)
    node = TestTransformer().visit(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.args[0], ast.Starred)
    assert isinstance(node.args[0].value, ast.BinOp)
    assert isinstance(node.args[0].value.left, ast.Call)

# Generated at 2022-06-18 00:32:49.119429
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor


# Generated at 2022-06-18 00:32:56.511097
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = StarredUnpackingTransformer
        __doc__ = StarredUnpackingTransformer.__doc__

        def _test_tree_changed(self, tree: ast.AST, expected: ast.AST) -> None:
            self.assertEqual(self.TRANSFORMER().visit(tree), expected)

    class Test_visit_List(Test, BaseNodeTransformerTestCase):
        def test_empty(self):
            tree = ast.parse('[]')
            expected = ast.parse('[]')
            self._test_tree_changed(tree, expected)


# Generated at 2022-06-18 00:33:01.875771
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:10.970478
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip
    from .test_utils import assert_equal_code

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert_equal_code(round_trip(tree), expected)



# Generated at 2022-06-18 00:33:21.360060
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Call, Name, Add, Num
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return List(elts=[Starred(value=Call(func=Name(id='list'), args=[Num(n=1)], keywords=[])),
                              Starred(value=Call(func=Name(id='list'), args=[Num(n=2)], keywords=[])),
                              Starred(value=Call(func=Name(id='list'), args=[Num(n=3)], keywords=[]))])


# Generated at 2022-06-18 00:33:28.365258
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:38.019242
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer


# Generated at 2022-06-18 00:33:48.488262
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:58.819143
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_simple(self):
            tree = ast.parse('[1, 2, 3]')
            expected = ast.parse('[1, 2, 3]')

            self.assertTransformEqual(tree, expected)

        def test_starred(self):
            tree = ast.parse('[1, 2, *range(3), 4]')

# Generated at 2022-06-18 00:34:05.037220
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:34:15.603910
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:34:22.650538
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, BinOp, Load, Num

    tree = List(
        elts=[
            Num(n=2),
            Starred(value=Name(id='range', ctx=Load())),
            Num(n=1)
        ],
        ctx=Load())

# Generated at 2022-06-18 00:34:32.135845
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:49.004344
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import typed_ast.ast3
    import astor
    import astunparse
    import typed_ast.ast3
    import astor
    import astunparse
    import typed_ast.ast3
    import astor
    import astunparse
    import typed_ast.ast3
    import astor
    import astunparse
    import typed_ast.ast3
    import astor
    import astunparse
    import typed_ast.ast3
    import astor
    import astunparse
    import typed_ast

# Generated at 2022-06-18 00:34:59.144244
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    """Unit test for method visit_List of class StarredUnpackingTransformer."""
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists

# Generated at 2022-06-18 00:35:10.426391
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:35:16.243601
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    actual = round_trip(tree)

    assert actual == expected


# Generated at 2022-06-18 00:35:28.020421
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        target_class = TestTransformer

        def test_simple(self):
            code = '[1, 2, 3]'
            expected = '[1, 2, 3]'
            self.assertTransformEquals(code, expected)

        def test_starred(self):
            code = '[1, 2, *range(3), 4]'
            expected = '[1, 2] + list(range(3)) + [4]'
            self.assertTransformEquals(code, expected)


# Generated at 2022-06-18 00:35:38.747889
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import _ast
    from .base import _ast_fields
    from .base import _ast_mapping
    from .base import _ast_module
    from .base import _ast_node
    from .base import _ast_type
    from .base import _ast_visitor
    from .base import _ast_walk
    from .base import _ast_walkers
    from .base import _generic_visit
    from .base import _generic_visitor
    from .base import _walk
    from .base import _walkers

# Generated at 2022-06-18 00:35:45.101903
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        [2] + list(range(10)) + [1]
        """

    TestCase.run()


# Generated at 2022-06-18 00:35:48.800267
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = """
        [2, *range(10), 1]
    """
    expected = """
        [2] + list(range(10)) + [1]
    """
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-18 00:35:55.110903
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num

    node = List(elts=[
        Starred(value=Name(id='a')),
        Name(id='b'),
        Starred(value=Name(id='c')),
        Name(id='d'),
        Starred(value=Name(id='e')),
    ])


# Generated at 2022-06-18 00:36:05.264064
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:22.886651
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:36:31.645915
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            tree = parse("[2, *range(10), 1]")
            expected = parse("[2] + list(range(10)) + [1]")
            self.assertTransformEquals(tree, expected)

    TestCase.run()


# Generated at 2022-06-18 00:36:41.551061
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformed_code(
                '''
                [2, *range(10), 1]
                ''',
                '''
                [2] + list(range(10)) + [1]
                '''
            )

        def test_nested(self):
            self.assert_transformed_code(
                '''
                [2, *range(10), *range(1), 1]
                ''',
                '''
                [2] + list(range(10)) + list(range(1)) + [1]
                '''
            )

        def test_empty(self):
            self.assert_transformed

# Generated at 2022-06-18 00:36:49.838398
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num

    node = List(elts=[
        Num(n=2),
        Starred(value=Name(id='range', ctx=Load())),
        Num(n=1)
    ])
    expected = List(elts=[
        Num(n=2),
        Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load())], keywords=[]),
        Num(n=1)
    ])
    expected = Add(left=expected, right=Call(func=Name(id='list', ctx=Load()), args=[Name(id='range', ctx=Load())], keywords=[]))

    transformer = StarredUnpackingTransformer

# Generated at 2022-06-18 00:37:00.967204
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class Dummy(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    dummy = Dummy()
    node = ast.List(elts=[ast.Starred(value=ast.Name(id='a'), ctx=ast.Load()), ast.Num(n=1)])
    expected = ast.BinOp(left=ast.List(elts=[]), right=ast.List(elts=[ast.Num(n=1)]), op=ast.Add())

# Generated at 2022-06-18 00:37:11.489569
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:37:22.880540
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import walk
    from .base import walk_fields
    from .base import walk_lineno
    from .base import walk_recursive
    from .base import walk_recursive_to_parent
    from .base import walk_recursive_to_parent_with_parents
    from .base import walk_recursive_to_parent_with_parents_and_child_index
    from .base import walk_recursive_to_parent_with_parents_and_siblings
    from .base import walk_recursive_to

# Generated at 2022-06-18 00:37:33.300211
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor


# Generated at 2022-06-18 00:37:40.837085
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:47.003233
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        list([2]) + list(range(10)) + list([1])
        """

    Test().test()


# Generated at 2022-06-18 00:38:12.623337
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_no_starred(self):
            tree = ast.parse('[1, 2, 3]')
            expected = ast.parse('[1, 2, 3]')
            self.assertTransformEqual(tree, expected)

        def test_one_starred(self):
            tree = ast.parse('[1, 2, *range(3)]')

# Generated at 2022-06-18 00:38:21.374337
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:31.528938
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:38:38.255685
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from ast import parse

    code = "[2, *range(10), 1]"
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == "[2] + list(range(10)) + [1]"

    code = "[2, *range(10), *range(10), 1]"
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == "[2] + list(range(10)) + list(range(10)) + [1]"

    code = "[2, *range(10), *range(10), *range(10), 1]"
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor

# Generated at 2022-06-18 00:38:44.144180
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Given
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    # When
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    result = compile(node, '<string>', 'exec')

    # Then
    assert expected == result.co_consts[0]


# Generated at 2022-06-18 00:38:49.826053
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_simple(self):
            self.assertEqual(
                self.transform(
                    '''
                    [2, *range(10), 1]
                    '''
                ),
                '''
                [2] + list(range(10)) + [1]
                '''
            )

    TestCase.run()


# Generated at 2022-06-18 00:38:59.223192
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        target = (3, 4)

        def test_simple(self):
            code = '[1, 2, 3]'
            expected = '[1, 2, 3]'
            self.assertTransformEquals(code, expected)

        def test_starred(self):
            code = '[1, 2, *range(3)]'
            expected = '[1, 2] + list(range(3))'
            self.assertTransformEqu

# Generated at 2022-06-18 00:39:10.545480
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer

        def test_simple_list(self):
            self.assert_transformed_code_is(
                code_before='''
                    [2, *range(10), 1]
                ''',
                code_after='''
                    [2] + list(range(10)) + [1]
                '''
            )


# Generated at 2022-06-18 00:39:17.437404
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_no_starred(self):
            node = ast.parse('[1, 2, 3]')
            expected = ast.parse('[1, 2, 3]')
            self.assertEqualAst(node, expected)

        def test_one_starred(self):
            node = ast.parse('[1, *range(10), 3]')

# Generated at 2022-06-18 00:39:25.947327
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer_visit_List
    from .base import BaseNodeTransformer_visit_List_test_parameters

    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
            print(*range(1), *range(3))
        To:
            [2] + list(range(10)) + [1]
            print(*(list(range(1)) + list(range(3))))
            
        """
        target = (3, 4)
