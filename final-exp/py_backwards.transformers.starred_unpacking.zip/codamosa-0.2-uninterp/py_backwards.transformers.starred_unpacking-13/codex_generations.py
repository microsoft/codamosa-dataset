

# Generated at 2022-06-18 00:30:35.926990
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_load
    from .test_utils import round_trip_dump_load
    from .test_utils import round_trip_load_dump
    from .test_utils import round_trip_load_dump_load
    from .test_utils import round_trip_dump_load_dump
    from .test_utils import round_trip_dump_load_dump_load
    from .test_utils import round_trip_dump_load_dump_load_dump
    from .test_utils import round_trip_dump_load_dump_load_dump_load
    from .test_utils import round_trip_dump_load_dump_load_dump_load_dump
    from .test_utils import round_trip

# Generated at 2022-06-18 00:30:37.503716
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:30:48.317466
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:30:59.763775
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    import astor
    import astunparse
    import sys
    import os
    import ast
    import astunparse
    import astor
    import sys
    import os
    import ast
    import astunparse
    import astor
    import sys
    import os
    import ast
    import astunparse
    import astor
    import sys
    import os
    import ast
    import astunparse
    import astor
    import sys
    import os
    import ast
    import astunparse
    import astor
    import sys
    import os
    import ast
    import astunparse


# Generated at 2022-06-18 00:31:08.233103
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:09.807231
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:31:11.614304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:31:18.607034
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .utils import dump_ast
    from .utils import parse_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    code = '''
    print(*range(1), *range(3))
    '''
    expected_code = '''
    print(*(list(range(1)) + list(range(3))))
    '''
    tree = parse_ast(code)
    StarredUnpackingTransformer().visit(tree)
    TestTransformer().visit(tree)
    assert dump_ast(tree) == expected_code


# Generated at 2022-06-18 00:31:29.127343
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap

    code = textwrap.dedent('''\
        [2, *range(10), 1]
        ''')
    expected = textwrap.dedent('''\
        [2] + list(range(10)) + [1]
        ''')

    tree = ast.parse(code)
    StarredUnpackingTransformer.run_on_tree(tree)
    result = astunparse.unparse(tree)

    assert result == expected


# Generated at 2022-06-18 00:31:40.155908
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_starred_in_list(self):
            self.assert_transform(
                '[2, *range(10), 1]',
                '[2] + list(range(10)) + [1]')

        def test_starred_in_list_with_other_starred(self):
            self.assert_transform(
                '[2, *range(10), *range(1), 1]',
                '[2] + list(range(10)) + list(range(1)) + [1]')


# Generated at 2022-06-18 00:31:47.810697
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:31:52.408390
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import roundtrip_unparse
    from typed_ast import ast3 as ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert roundtrip_unparse(tree) == expected



# Generated at 2022-06-18 00:31:56.737683
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .test_utils import roundtrip

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == expected

    roundtrip(code, expected)


# Generated at 2022-06-18 00:32:06.832025
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_transformer import run_test_on_file
    import inspect
    import astor
    import ast
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_transformer import run_test_on_file
    import inspect
    import astor
    import ast
    import sys
    import os

# Generated at 2022-06-18 00:32:13.809336
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .test_utils import round_trip

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:32:19.690090
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:30.361259
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:40.896574
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:52.101689
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:03.223015
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import _ast
    from .base import _ast_fields
    from .base import _ast_mapping
    from .base import _ast_module
    from .base import _ast_node
    from .base import _ast_type_repr
    from .base import _ast_visitor
    from .base import _builtin_ast
    from .base import _constant_ast
    from .base import _copy_ast
    from .base import _generic_ast
    from .base import _literal_ast
    from .base import _mod_

# Generated at 2022-06-18 00:33:12.147692
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:33:22.380775
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerT

# Generated at 2022-06-18 00:33:28.985910
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:38.937877
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_utils import expect_equal
    from test_utils import expect_type_error
    from test_utils import expect_value_error

    # Test 1:
    # Test for constructor of class StarredUnpackingTransformer
    # Input:
    #     StarredUnpackingTransformer()
    # Expected output:
    #     StarredUnpackingTransformer()
    expect_equal(StarredUnpackingTransformer(), StarredUnpackingTransformer())

    # Test 2:
    # Test for constructor of class StarredUnpackingTransformer

# Generated at 2022-06-18 00:33:49.187777
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:59.543437
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method_name = 'visit_List'

        def test_no_starred(self):
            tree = ast.parse('[1, 2, 3]')
            expected = ast.parse('[1, 2, 3]')
            self.assertTransformEqual(tree, expected)

        def test_one_starred(self):
            tree = ast.parse('[1, 2, *range(3)]')
            expected

# Generated at 2022-06-18 00:34:10.713194
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import roundtrip_unparse
    from .utils import roundtrip_parse

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = roundtrip_parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert roundtrip_unparse(tree) == expected

    source = "[*range(10), 1]"
    expected = "list(range(10)) + [1]"
    tree = roundtrip_parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert roundtrip_unparse(tree) == expected

    source = "[2, *range(10)]"
    expected = "[2] + list(range(10))"
    tree = roundtrip_parse(source)
    StarredUn

# Generated at 2022-06-18 00:34:20.198181
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:34:31.082961
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    node = ast.Call(func=ast.Name(id='print'), args=[ast.Starred(value=ast.Name(id='range'), ctx=ast.Load()), ast.Starred(value=ast.Name(id='range'), ctx=ast.Load())], keywords=[])

# Generated at 2022-06-18 00:34:43.252799
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = io.BytesIO()
        yield
        sys.stdout = save_stdout

    code = '''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    '''
    tree = ast.parse(code)
    expected = ast.parse('''
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    ''')

# Generated at 2022-06-18 00:35:02.772130
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, Num, List, Add, BinOp
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typing import Union, Iterable, List

    # Test 1
    node = parse("print(*range(1), *range(3))")
    expected = Call(func=Name(id='print'), args=[Starred(value=BinOp(left=List(elts=[Num(n=1)]), right=List(elts=[Num(n=3)]), op=Add()))], keywords=[])
    actual = StarredUnpackingTransformer().vis

# Generated at 2022-06-18 00:35:12.734156
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred
    from typed_ast.ast3 import List
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Add
    from typed_ast.ast3 import BinOp
    from typed_ast.ast3 import Num
    from typed_ast.ast3 import Expr
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import fix_missing_locations
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import AST
    from typed_ast.ast3 import ASTError
    from typed_ast.ast3 import parse

# Generated at 2022-06-18 00:35:23.906089
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:32.698935
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Add, Call
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_List(self, node):
            return node

    def test_visit_List_no_starred():
        node = parse('[1, 2, 3]').body[0].value
        assert isinstance(node, List)
        assert not any(isinstance(elt, Starred) for elt in node.elts)

        transformer = Test

# Generated at 2022-06-18 00:35:37.270796
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:35:46.844656
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester
    from .base import BaseNodeTransformerTester

# Generated at 2022-06-18 00:35:53.841627
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:36:04.593401
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import _ast
    from .base import _ast3
    from .base import _ast27
    from .base import _ast35
    from .base import _ast36
    from .base import _ast37
    from .base import _ast38
    from .base import _ast_gen
    from .base import _ast_module
    from .base import _ast_obj
    from .base import _ast_real_obj
    from .base import _ast_real_obj_type
    from .base import _ast_

# Generated at 2022-06-18 00:36:11.720357
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:36:19.785550
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:36:48.442163
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_helpers import round_trip

    def check(code: str, expected: str) -> None:
        tree = ast.parse(code)
        StarredUnpackingTransformer().visit(tree)
        result = round_trip(tree)
        assert result == expected

    check('[2, *range(10), 1]', '[2] + list(range(10)) + [1]')
    check('[2, *range(10), *range(1), 1]', '[2] + list(range(10)) + list(range(1)) + [1]')

# Generated at 2022-06-18 00:37:00.145051
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import get_ast_node
    from .test_utils import get_ast_node_list
    from .test_utils import get_ast_node_list_list
    from .test_utils import get_ast_node_list_list_list
    from .test_utils import get_ast_node_list_list_list_list
    from .test_utils import get_ast_node_list_list_list_list_list
    from .test_utils import get_ast_node_list_list_list_list_list_list
    from .test_utils import get_ast_node_list_list_list_list_list_list_list
    from .test_utils import get_ast_node_list_list_list_list_list_list_list_list

# Generated at 2022-06-18 00:37:06.562479
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    node = parse("[2, *range(10), 1]")
    expected = parse("[2] + list(range(10)) + [1]")

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)
    assert result == expected

    node = parse("[2, *range(10), 1, *range(5)]")
    expected = parse("[2] + list(range(10)) + [1] + list(range(5))")

    transformer = StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:08.681669
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import compile_source
    from . import dump_tree
    from . import dump_source


# Generated at 2022-06-18 00:37:19.285136
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformation(
                before="[2, *range(10), 1]",
                after="[2] + list(range(10)) + [1]")

        def test_empty(self):
            self.assert_transformation(
                before="[*[]]",
                after="[]")

        def test_nested(self):
            self.assert_transformation(
                before="[2, *range(10), *[1]]",
                after="[2] + list(range(10)) + list([1])")

    TestCase.run()


# Generated at 2022-06-18 00:37:24.081278
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import compile_source
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_output = "[2, 3, 4, 5, 6, 7, 8, 9, 10, 1]"
        code = "[2, *range(10), 1]"

    Test().test()


# Generated at 2022-06-18 00:37:34.744860
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer3(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return

# Generated at 2022-06-18 00:37:41.646825
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast

# Generated at 2022-06-18 00:37:50.745877
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:38:00.890892
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:47.110144
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num

    # [2, *range(10), 1]
    node = List(
        elts=[
            Num(n=2),
            Starred(value=Name(id='range', ctx=Load())),
            Num(n=1)
        ],
        ctx=Load())

    expected = List(
        elts=[
            Num(n=2),
            Add(
                left=Call(
                    func=Name(id='list', ctx=Load()),
                    args=[Name(id='range', ctx=Load())],
                    keywords=[]),
                right=Num(n=1),
                op=Add()),
        ],
        ctx=Load())

    assert Star

# Generated at 2022-06-18 00:38:49.349084
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:38:58.397848
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node


# Generated at 2022-06-18 00:39:04.504491
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:39:12.741402
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:39:23.459521
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import roundtrip_unparse
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load, Store, Expr, Assign, Module


# Generated at 2022-06-18 00:39:32.742819
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import textwrap
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_StarredUnpackingTransformer(self):
            code = textwrap.dedent('''
            [2, *range(10), 1]
            print(*range(1), *range(3))
            ''')
            tree = ast3.parse(code)
            StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:39:33.415833
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:39:41.150337
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:39:50.521283
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists
   