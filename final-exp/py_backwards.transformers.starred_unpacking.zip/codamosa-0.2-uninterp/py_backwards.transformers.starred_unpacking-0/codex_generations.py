

# Generated at 2022-06-18 00:30:25.035064
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:30:35.146921
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:30:37.026208
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:30:38.554315
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:30:48.808794
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    node = List(
        elts=[
            Num(n=2),
            Starred(value=Name(id='range', ctx=Load())),
            Num(n=1)
        ],
        ctx=Load())

    expected = Call(
        func=Name(id='list', ctx=Load()),
        args=[
            Call(
                func=Name(id='range', ctx=Load()),
                args=[],
                keywords=[]
            )
        ],
        keywords=[]
    )


# Generated at 2022-06-18 00:30:50.479244
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:31:00.553387
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import round_trip_on_ast
    from .test_utils import round_trip_on_source
    from .test_utils import round_trip_on_source_as_ast
    from .test_utils import round_trip_on_source_as_ast_as_source
    from .test_utils import round_trip_on_source_as_source

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    assert round_trip(source) == expected
    assert round_trip_on_ast(source) == expected
    assert round_trip_on_source(source) == expected
    assert round_trip_on_source_as_ast(source) == expected
    assert round_trip

# Generated at 2022-06-18 00:31:08.833201
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Starred, Name, List, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer

# Generated at 2022-06-18 00:31:18.170228
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from utils import dump_python_source
    from utils import assert_equal_source
    from utils import assert_equal_ast

    class TestStarredUnpackingTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            if not self._has_starred(node.elts):
                return self.generic_visit(node)  # type: ignore

            self._tree_changed = True


# Generated at 2022-06-18 00:31:29.852813
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, Call, Name, List, BinOp, Add
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:31:44.873217
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip, compare_ast
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            node.elts = node.elts[1:]
            return node

    code = "[1, 2, 3]"
    expected = "[2, 3]"

    tree = ast.parse(code)
    tree = TestTransformer().visit(tree)
    compare_ast(tree, expected)

    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    compare_ast(tree, expected)

    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:31:54.174478
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:05.572685
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _

# Generated at 2022-06-18 00:32:16.480094
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            self.assert_transformation(
                '[2, *range(10), 1]',
                '[2] + list(range(10)) + [1]')

        def test_empty(self):
            self.assert_transformation(
                '[]',
                '[]')

        def test_no_starred(self):
            self.assert_transformation(
                '[2, 3, 4]',
                '[2, 3, 4]')


# Generated at 2022-06-18 00:32:27.881584
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.target == (3, 4)
    assert StarredUnpackingTransformer.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__qualname__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__module__ == 'typed_astunparse.starred_unpacking'
    assert StarredUnpackingTransformer._fields == ('_tree_changed',)
    assert StarredUnpackingTransformer.__annotations__ == {'_tree_changed': bool}
    assert StarredUnpackingTransformer.__

# Generated at 2022-06-18 00:32:36.822188
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Call, Name, Num

    node = List(
        elts=[
            Num(n=2),
            Starred(value=Call(
                func=Name(id='range'),
                args=[Num(n=10)],
                keywords=[])),
            Num(n=1)])

    expected = List(
        elts=[
            Num(n=2),
            Call(
                func=Name(id='list'),
                args=[Call(
                    func=Name(id='range'),
                    args=[Num(n=10)],
                    keywords=[])],
                keywords=[]),
            Num(n=1)])


# Generated at 2022-06-18 00:32:48.197857
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:49.463392
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:32:56.659352
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:33:01.814293
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import compile_source
    from . import dump_tree

    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = compile_source(source, mode='exec')
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert dump_tree(tree) == expected



# Generated at 2022-06-18 00:33:22.114806
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:28.843242
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import parse_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node


# Generated at 2022-06-18 00:33:32.881347
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    actual = StarredUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(actual) == expected


# Generated at 2022-06-18 00:33:40.200598
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from astor.code_gen import to_source
    from ast_tools.transformers.starred_unpacking import StarredUnpackingTransformer
    from ast_tools.transformers.base import BaseNodeTransformer

    code = """
    print(*range(1), *range(3))
    """
    tree = ast.parse(code)
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert to_source(tree) == expected


# Generated at 2022-06-18 00:33:50.326044
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, List, Call, Name, Add, BinOp
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer5(BaseNodeTransformer):
        def visit_List(self, node):
            return node



# Generated at 2022-06-18 00:34:00.619735
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast

    class DummyTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return super().visit_Call(node)

    code = 'print(*range(1), *range(3))'
    tree = ast.parse(code)
    DummyTransformer().visit(tree)
    TestTransformer().visit(tree)

# Generated at 2022-06-18 00:34:11.600682
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:20.873706
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .unpacking import UnpackingTransformer
    from .unpacking_assignment import UnpackingAssignmentTransformer
    from .unpacking_in_comprehensions import UnpackingInComprehensionsTransformer
    from .unpacking_in_for import UnpackingInForTransformer
    from .unpacking_in_with import UnpackingInWithTransformer
    from .unpacking_in_yield import UnpackingInYieldTransformer
    from .unpacking_in_yield_from import UnpackingInYieldFromTransformer
    from .unpacking_in_except import UnpackingInExceptTransformer
    from .unpacking_in_except_handler import UnpackingInExceptHandlerTransformer
   

# Generated at 2022-06-18 00:34:31.330195
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num

    node = List(elts=[Starred(value=Name(id='a', ctx=ast.Load())),
                      Starred(value=Name(id='b', ctx=ast.Load())),
                      Starred(value=Name(id='c', ctx=ast.Load()))])


# Generated at 2022-06-18 00:34:38.260341
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        (list([2]) + list(range(10)) + [1])
        """

    Test().run()


# Generated at 2022-06-18 00:35:12.173379
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse('print(*range(1), *range(3))').body[0]
    expected = ast.parse('print(*(list(range(1)) + list(range(3))))').body[0]
    actual = StarredUnpackingTransformer(TestTransformer()).visit(node)
    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-18 00:35:13.230319
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:35:25.048428
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    from .test_utils import round_trip

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = round_trip(code, StarredUnpackingTransformer)
    assert unparse(tree) == expected

    code = '[2, *range(10), 1, *range(3)]'
    expected = '[2] + list(range(10)) + [1] + list(range(3))'
    tree = round_trip(code, StarredUnpackingTransformer)
    assert unparse(tree) == expected

    code = '[2, *range(10), 1, *range(3), *range(5)]'

# Generated at 2022-06-18 00:35:32.985107
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_visit_Call(self):
            source = """
            print(*range(1), *range(3))
            """
            expected = """
            print(*(list(range(1)) + list(range(3))))
            """
            tree = parse(source)
            StarredUnpackingTransformer().visit(tree)
            self.assertEqual(expected, ast.unparse(tree))

    unittest.main(argv=[''], verbosity=2, exit=False)


# Generated at 2022-06-18 00:35:40.288475
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:35:50.122915
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import parse

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected

    code = '[2, *range(10), 1, *range(5)]'
    expected = '[2] + list(range(10)) + [1] + list(range(5))'
    tree = parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected

    code = '[2, *range(10), 1, *range(5), *range(3)]'

# Generated at 2022-06-18 00:35:50.864896
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:36:01.289723
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:10.327526
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer5(BaseNodeTransformer):
        def visit_Call(self, node):
            return node


# Generated at 2022-06-18 00:36:15.595869
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import parse_ast

    code = """
    print(*range(1), *range(3))
    """
    expected_code = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = parse_ast(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected_code


# Generated at 2022-06-18 00:37:15.596181
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    node = ast.parse('[2, *range(10), 1]')
    node = StarredUnpackingTransformer().visit(node)
    node = TestTransformer().visit(node)

# Generated at 2022-06-18 00:37:26.234716
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap
    import sys
    import os
    import io
    import contextlib

    @contextlib.contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = io.BytesIO()
        yield
        sys.stdout = save_stdout

    code = textwrap.dedent('''
    print(*range(1), *range(3))
    ''')

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    with nostdout():
        compiled = compile(tree, filename='<ast>', mode='exec')

# Generated at 2022-06-18 00:37:37.058005
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.ast3 import BinOp, Load, Store, Del, AugLoad, AugStore, Param
    from typed_ast.ast3 import And, Or, BitAnd, BitOr, BitXor, Invert, Not, UAdd
    from typed_ast.ast3 import USub, Eq, NotEq, Lt, LtE, Gt, GtE, Is, IsNot, In
    from typed_ast.ast3 import NotIn, Subscript, Slice, Index, ExtSlice, ListComp
    from typed_ast.ast3 import SetComp, DictComp, GeneratorExp, Yield, YieldFrom

# Generated at 2022-06-18 00:37:48.078327
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:54.088424
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import compile_source
    from .base import dump_tree
    from .base import parse_source
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed
    from .base import tree_changed

# Generated at 2022-06-18 00:37:57.285882
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:38:07.301042
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:38:14.530070
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:38:19.258909
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:38:26.727778
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Call, Name, Add, BinOp
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer