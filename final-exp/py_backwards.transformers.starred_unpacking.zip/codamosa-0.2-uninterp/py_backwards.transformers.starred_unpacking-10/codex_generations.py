

# Generated at 2022-06-18 00:30:39.729748
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_simple(self):
            self.assert_transformed(
                StarredUnpackingTransformer,
                '''
                [2, *range(10), 1]
                ''',
                '''
                [2] + list(range(10)) + [1]
                '''
            )

        def test_nested(self):
            self.assert_transformed(
                StarredUnpackingTransformer,
                '''
                [2, *range(10), *range(1), 1]
                ''',
                '''
                [2] + list(range(10)) + list(range(1)) + [1]
                '''
            )

       

# Generated at 2022-06-18 00:30:49.712950
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:31:00.238591
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.ast3 import parse
    from typed_ast.transforms import StarredUnpackingTransformer
    from typed_ast.transforms import UnpackSequenceTransformer
    from typed_ast.transforms import UnpackSequenceTransformer

    # print(*range(1), *range(3))

# Generated at 2022-06-18 00:31:07.553377
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            self.check_on_input(
                input="[2, *range(10), 1]",
                expected_output="[2] + list(range(10)) + [1]",
            )

    Test.generate_tests()



# Generated at 2022-06-18 00:31:17.055790
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast

# Generated at 2022-06-18 00:31:21.865065
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from . import dump_tree
    from . import dump_source

    source = '[2, *range(10), 1]'
    tree = compile_source(source)
    dump_tree(tree)
    transformer = StarredUnpackingTransformer()
    tree = transformer.visit(tree)
    dump_tree(tree)
    assert dump_source(tree) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-18 00:31:23.508592
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:31:29.684797
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transform(
                'a = [2, *range(10), 1]',
                'a = [2] + list(range(10)) + [1]')

    Test().test_simple()


# Generated at 2022-06-18 00:31:35.399611
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        code = '[2, *range(10), 1]'
        expected = '[2] + list(range(10)) + [1]'

    TestCase().run_test()


# Generated at 2022-06-18 00:31:45.407573
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer3(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return

# Generated at 2022-06-18 00:31:53.357073
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:31:55.950419
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().__class__.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer().__class__.__bases__ == (BaseNodeTransformer,)


# Generated at 2022-06-18 00:31:58.083357
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'

# Generated at 2022-06-18 00:32:08.143495
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Subscript, Load, Index, Tuple, Attribute, Str, BinOp, Compare, Eq, Gt, Lt, GtE, LtE, In, NotIn, Is, IsNot, Invert, Not, UAdd, USub, NotEq, And, Or, BitAnd, BitOr, BitXor, LShift, RShift, Mult, Div, FloorDiv, Mod, Pow, Add, Sub, MatMult
    from typed_ast.ast3 import AST, ASTVisitor, NodeTransformer, NodeVisitor, fix_missing_locations, iter_fields, parse, parse_file, parse_string, dump, dump_tree, walk, iter_child_nodes, get_docstring, increment_lineno

# Generated at 2022-06-18 00:32:18.023489
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, Call, List, Name, BinOp, Add
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            if not self._has_starred(node.elts):
                return self.generic_visit(node)  # type: ignore

            self._tree_changed = True

            return self.generic_visit(self._to_sum_of_lists(node.elts))  # type: ignore


# Generated at 2022-06-18 00:32:19.006141
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:32:29.769346
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists

    # Test _split_by_starred
    assert _split_by_starred([]) == [[]]

# Generated at 2022-06-18 00:32:40.533219
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if not self._has_starred(node.args):
                return self.generic_visit(self.generic_visit(node))  # type: ignore

            self._tree_changed = True

            args = self._to_sum_of_lists(node.args)
            node.args = [ast.Starred(value=args)]
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:32:51.772114
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformation(
                '[2, *range(10), 1]',
                '[2] + list(range(10)) + [1]')

        def test_nested(self):
            self.assert_transformation(
                '[2, *range(10), 1, *range(5)]',
                '[2] + list(range(10)) + [1] + list(range(5))')

        def test_empty(self):
            self.assert_transformation(
                '[2, *[], 1]',
                '[2] + [] + [1]')


# Generated at 2022-06-18 00:33:00.889620
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class Dummy(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    node = ast.parse("print(1, *range(10), 2)").body[0]
    expected = ast.parse("print(*(list(range(10)) + [1, 2]))").body[0]
    assert StarredUnpackingTransformer().visit(node) == expected
    assert Dummy().visit(node) == node


# Generated at 2022-06-18 00:33:18.036008
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Call, Name, Add, Num
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    dummy_transformer = DummyTransformer()

    # [2, *range(10), 1]
    node = List(elts=[
        Num(n=2),
        Starred(value=Call(func=Name(id='range'), args=[Num(n=10)], keywords=[])),
        Num(n=1)
    ])

# Generated at 2022-06-18 00:33:26.879409
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .unpacking_transformer import UnpackingTransformer
    from .starred_unpacking_transformer import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking_transformer import UnpackingTransformer
    from .starred_unpacking_transformer import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking_transformer import UnpackingTransformer
    from .starred_unpacking_transformer import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking_transformer import UnpackingTransformer
    from .starred_unpacking_transformer import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking_transformer import UnpackingTransformer

# Generated at 2022-06-18 00:33:36.644958
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:44.835035
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse('print(*range(1), *range(3))')
    node = StarredUnpackingTransformer().visit(node)
    node = TestTransformer().visit(node)
    assert astor.to_source(node) == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-18 00:33:46.671462
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:33:56.533876
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:58.605375
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:34:09.872999
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:19.493014
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_Call'

        def test_simple(self):
            code = 'print(1, 2, 3)'
            expected = 'print(1, 2, 3)'
            self.assertEqual(self.transform(code), expected)

        def test_starred(self):
            code = 'print(1, *range(10), 3)'

# Generated at 2022-06-18 00:34:30.591948
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:54.573918
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import sys
    import io
    import unittest
    import contextlib

    class TestCase(unittest.TestCase):
        def assertAST(self, code: str, expected: str):
            tree = parse(code)
            transformer = StarredUnpackingTransformer()
            transformer.visit(tree)
            self.assertEqual(expected, str(tree))

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-18 00:35:02.671674
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from . import dump_tree
    from . import dump_code
    from . import assert_tree_equal

    source = '[2, *range(10), 1]'
    tree = compile_source(source, mode='eval')
    expected = compile_source('[2] + list(range(10)) + [1]', mode='eval')
    assert_tree_equal(expected, StarredUnpackingTransformer().visit(tree))
    assert dump_code(expected) == dump_code(StarredUnpackingTransformer().visit(tree))


# Generated at 2022-06-18 00:35:12.640817
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists

    # Test _split_by_starred
    assert _

# Generated at 2022-06-18 00:35:23.816698
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip_load
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_dump_single_statement
    from .test_utils import round_trip_dump_single_expression

    def check(src: str, expected: str) -> None:
        tree = round_trip_load(src)
        StarredUnpackingTransformer().visit(tree)
        assert round_trip_dump(tree) == expected

    check('[2, *range(10), 1]', '[2] + list(range(10)) + [1]')
    check('[2, *range(10), *range(1), 1]', '[2] + list(range(10)) + list(range(1)) + [1]')

# Generated at 2022-06-18 00:35:32.672762
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class Dummy(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Dummy2(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Dummy3(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Dummy4(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node


# Generated at 2022-06-18 00:35:40.179540
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        target = (3, 4)

        def test_normal_call(self):
            self.assertTransformed(
                before="print(1, 2, 3)",
                after="print(1, 2, 3)")

        def test_call_with_starred(self):
            self.assertTransformed(
                before="print(1, *range(10), 2)",
                after="print(*(list(range(10)) + [2]))")


# Generated at 2022-06-18 00:35:45.730488
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    transformer = StarredUnpackingTransformer()
    node = ast.parse('[2, *range(10), 1]')
    result = transformer.visit(node)
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-18 00:35:53.038220
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    import astunparse
    import textwrap
    import astor
    import ast
    import sys
    import astunparse
    import textwrap
    import astor
    import ast
    import sys
    import astunparse
    import textwrap
    import astor
    import ast
    import sys
    import astunparse
    import textwrap
    import astor
    import ast
    import sys
    import astunparse
    import textwrap
    import astor
    import ast
    import sys
    import astunparse
    import textwrap
    import astor
    import ast
    import sys
    import astunparse

# Generated at 2022-06-18 00:35:55.253495
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:35:56.486663
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:36:33.620016
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:38.314497
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:36:48.754543
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:00.143849
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class Dummy(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse("print(*range(1), *range(3))")
    node = Dummy().visit(node)
    assert isinstance(node.body[0].value.args[0], ast.Starred)
    assert isinstance(node.body[0].value.args[0].value, ast.BinOp)
    assert isinstance(node.body[0].value.args[0].value.left, ast.Call)
    assert isinstance(node.body[0].value.args[0].value.right, ast.Call)


# Generated at 2022-06-18 00:37:06.561920
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:37:07.618575
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:08.907593
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-18 00:37:19.824329
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase
    from .test_utils import transform, dump

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            tree = ast.parse('[2, *range(10), 1]')
            expected = ast.parse('[2] + list(range(10)) + [1]')
            self.assertEqual(transform(tree, self.transformer), expected)

        def test_nested(self):
            tree = ast.parse('[2, *range(10), 1, *range(5)]')

# Generated at 2022-06-18 00:37:29.166654
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        target = (3, 4)

        def test_simple(self):
            tree = ast.parse('print(1, 2, 3)')
            self.check_tree(tree, tree)

        def test_starred(self):
            tree = ast.parse('print(1, *range(10), 2, 3)')

# Generated at 2022-06-18 00:37:31.017569
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:38:27.045217
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_Call'

        def test_simple(self):
            node = ast.parse('print(1, 2, 3)').body[0]
            expected = ast.parse('print(1, 2, 3)').body[0]
            self.assertEqual(self.transform(node), expected)

        def test_starred(self):
            node = ast.parse('print(*range(1), *range(3))').body[0]

# Generated at 2022-06-18 00:38:33.979395
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        [2] + list(range(10)) + [1]
        """

    Test().run()


# Generated at 2022-06-18 00:38:36.528240
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected


# Generated at 2022-06-18 00:38:40.410003
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:38:48.262334
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:57.787303
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists

# Generated at 2022-06-18 00:39:02.407277
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_load

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = round_trip(code, StarredUnpackingTransformer)
    assert round_trip_dump(tree) == expected
    assert round_trip_load(expected) == expected


# Generated at 2022-06-18 00:39:11.005078
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .utils import dump_ast
    from .utils import compile_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse("print(*range(1), *range(3))").body[0]
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]

    transformer = TestTransformer()
    transformer.visit(node)
    assert dump_ast(node) == dump_ast(expected)
    assert compile_ast(node) == compile_ast(expected)



# Generated at 2022-06-18 00:39:11.844427
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    StarredUnpackingTransformer()

# Generated at 2022-06-18 00:39:13.089829
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)
