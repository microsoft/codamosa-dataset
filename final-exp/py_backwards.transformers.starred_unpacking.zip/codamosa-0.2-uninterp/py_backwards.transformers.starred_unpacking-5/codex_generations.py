

# Generated at 2022-06-18 00:30:31.743515
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:30:39.699353
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:30:49.713915
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer


# Generated at 2022-06-18 00:30:53.816242
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:30:59.292234
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_tree = ast.parse("[2] + list(range(10)) + [1]")
        tree = ast.parse("[2, *range(10), 1]")

    TestCase.check()


# Generated at 2022-06-18 00:31:07.934989
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:12.633451
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        code = """
            print(*range(1), *range(3))
        """
        expected_code = """
            print(*(list(range(1)) + list(range(3))))
        """

    TestCase().run()


# Generated at 2022-06-18 00:31:18.925853
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip
    from .test_utils import parse_ast

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = parse_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:31:30.594777
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:31:41.944905
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:31:52.281639
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if not self._has_starred(node.args):
                return self.generic_visit(self.generic_visit(node))  # type: ignore

            self._tree_changed = True

            args = self._to_sum_of_lists(node.args)
            node.args = [ast.Starred(value=args)]
            return self.generic_visit(node)  # type: ignore

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer


# Generated at 2022-06-18 00:31:57.820578
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    code = """
    print(*range(1), *range(3))
    """
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)

    expected_code = """
    print(*(list(range(1)) + list(range(3))))
    """
    expected_tree = parse(expected_code)

    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-18 00:32:02.815952
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    import astunparse
    node = ast3.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(node)
    assert astunparse.unparse(node) == "print(*(list(range(1)) + list(range(3))))"


# Generated at 2022-06-18 00:32:09.371559
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNode

# Generated at 2022-06-18 00:32:15.892762
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from . import dump_tree

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = compile_source(source, '<test>', 'exec')
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert dump_tree(tree) == expected



# Generated at 2022-06-18 00:32:27.115598
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast27 as ast27
    from typed_ast import ast3 as ast3
    from typed_ast import ast35 as ast35
    from typed_ast import ast38 as ast38
    from typed_ast import ast41 as ast41
    from typed_ast import ast43 as ast43
    from typed_ast import ast46 as ast46
    from typed_ast import ast48 as ast48
    from typed_ast import ast51 as ast51
    from typed_ast import ast54 as ast54
    from typed_ast import ast56 as ast56
    from typed_ast import ast58 as ast58
    from typed_ast import ast60 as ast60
    from typed_ast import ast62 as ast62
    from typed_ast import ast64 as ast64
    from typed_ast import ast66

# Generated at 2022-06-18 00:32:33.927024
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer

        def test_simple(self):
            tree = ast.parse("""
                print(*range(1), *range(3))
            """)
            expected = ast.parse("""
                print(*(list(range(1)) + list(range(3))))
            """)
            self.assertEqual(expected, self.transform(tree))

    TestCase().run()


# Generated at 2022-06-18 00:32:44.779062
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:54.677693
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .unpacking_transformer import UnpackingTransformer
    from .starred_unpacking_transformer import StarredUnpackingTransformer
    from .compat import typed_ast_version
    from . import base
    import sys
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_visit_Call(self):
            # type: () -> None
            tree = ast.parse("""
            print(*range(1), *range(3))
            """)
            tree = UnpackingTransformer().visit(tree)
            tree = StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:33:03.145795
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List

    node = Call(func=Name(id='print'),
                args=[Starred(value=Name(id='range'), ctx=ast.Load()),
                      Starred(value=Name(id='range'), ctx=ast.Load())],
                keywords=[])

    expected = Call(func=Name(id='print'),
                    args=[Starred(value=List(elts=[Name(id='range'),
                                                   Name(id='range')],
                                           ctx=ast.Load()))],
                    keywords=[])

    assert StarredUnpackingTransformer().visit(node) == expected

# Generated at 2022-06-18 00:33:14.101741
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from . import compile_ast
    from .test_utils import assert_code_equal

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert_code_equal(compile_ast(tree), expected)


# Generated at 2022-06-18 00:33:20.954044
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = TestTransformer
        CODE = 'print(*range(1), *range(3))'
        EXPECTED_CODE = 'print(*(list(range(1)) + list(range(3))))'

    Test().test()


# Generated at 2022-06-18 00:33:25.461365
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import compile_source
    from . import dump_tree
    from . import dump_code

    source = '''
    print(*range(1), *range(3))
    '''
    tree = compile_source(source, mode='exec')
    print(dump_tree(tree))
    StarredUnpackingTransformer().visit(tree)
    print(dump_tree(tree))
    print(dump_code(tree))


# Generated at 2022-06-18 00:33:35.131051
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTest

# Generated at 2022-06-18 00:33:36.078165
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:33:37.905263
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:33:48.346113
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from utils import dump_ast

    class TestTransformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__()
            self.starred_unpacking = StarredUnpackingTransformer()

        def visit_Module(self, node: ast.Module) -> ast.Module:
            return self.starred_unpacking.visit(node)

    tree = ast.parse("[2, *range(10), 1]")
    tree = TestTransformer().visit(tree)
    assert dump_

# Generated at 2022-06-18 00:33:58.694588
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:34:05.218826
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import roundtrip_unparse
    from typed_ast import ast3 as ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert roundtrip_unparse(tree) == expected


# Generated at 2022-06-18 00:34:15.780923
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import convert
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted

# Generated at 2022-06-18 00:34:32.136055
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:34:39.289291
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = '''
        [2, *range(10), 1]
        '''

        EXPECTED = '''
        [2] + list(range(10)) + [1]
        '''

    TestCase.do_test()


# Generated at 2022-06-18 00:34:50.076264
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .. import Compiler
    from ..compiler import CompilerError

    compiler = Compiler()

    def test(code: str, expected: str) -> None:
        tree = compiler.parse(code)
        StarredUnpackingTransformer().visit(tree)
        assert compiler.compile(tree) == expected

    test('print(1, *range(1), *range(3))', 'print(*(list(range(1)) + list(range(3))))')
    test('print(1, *range(1), *range(3), *range(5))', 'print(*(list(range(1)) + list(range(3)) + list(range(5))))')

# Generated at 2022-06-18 00:35:00.948501
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    node = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:35:07.590258
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import assert_equal_ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = round_trip(code)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)


# Generated at 2022-06-18 00:35:12.594158
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    # Arrange
    node = ast.parse("[2, *range(10), 1]").body[0]
    expected = ast.parse("[2] + list(range(10)) + [1]").body[0]

    # Act
    actual = StarredUnpackingTransformer().visit(node)

    # Assert
    assert ast.dump(actual) == ast.dump(expected)


# Generated at 2022-06-18 00:35:23.767088
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class MockNodeTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class MockStarredUnpackingTransformer(StarredUnpackingTransformer):
        def _has_starred(self, xs: List[ast.expr]) -> bool:
            return True

        def _split_by_starred(self, xs: Iterable[ast.expr]) -> List[Splitted]:
            return [[ast.Starred(value=ast.Name(id='a'))]]


# Generated at 2022-06-18 00:35:32.599828
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:40.160084
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:35:49.954199
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    test_transformer = TestTransformer()
    test_transformer.visit(ast.parse("[2, *range(10), 1]"))
    assert test_transformer._tree_changed == False
    test_transformer.visit(ast.parse("[2, *range(10), 1]", mode='eval'))
    assert test_transformer._tree_changed == True

    test_transformer = TestTransformer()
    test_transformer.visit(ast.parse("[2, *range(10), 1]"))
    assert test_transformer._

# Generated at 2022-06-18 00:36:11.452343
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:13.034002
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'

# Generated at 2022-06-18 00:36:20.431306
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__qualname__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.target == (3, 4)
    assert StarredUnpackingTransformer.__doc__ is not None
    assert StarredUnpackingTransformer._has_starred.__doc__ is not None
    assert StarredUnpackingTransformer._split_by_starred.__doc__ is not None
    assert StarredUnpackingTransformer._prepare_lists.__doc__ is not None
    assert StarredUnpackingTransformer._merge_lists.__doc

# Generated at 2022-06-18 00:36:31.152490
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists

# Generated at 2022-06-18 00:36:35.678948
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_simple(self):
            self.assert_transformed_code_equal(
                """
                print(*range(1), *range(3))
                """,
                """
                print(*(list(range(1)) + list(range(3))))
                """
            )

    TestCase().run()


# Generated at 2022-06-18 00:36:47.055028
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer

        def test_simple(self):
            self.assertTransformed(
                'print(1, 2, 3)',
                'print(1, 2, 3)')

        def test_starred_unpacking(self):
            self.assertTransformed(
                'print(*range(1), *range(3))',
                'print(*(list(range(1)) + list(range(3))))')

        def test_starred_unpacking_in_list(self):
            self.assertTrans

# Generated at 2022-06-18 00:36:57.952245
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:36:58.917841
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:06.365955
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        transformer = TestTransformer

        def test_simple(self):
            code = '[2, *range(10), 1]'
            expected = '[2] + list(range(10)) + [1]'
            self.assertCodeTransformed(code, expected)

        def test_call(self):
            code = 'print(*range(1), *range(3))'

# Generated at 2022-06-18 00:37:11.089890
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    code = '[2, *range(10), 1]'
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert_equal_ast(StarredUnpackingTransformer().visit(ast.parse(code)), expected)



# Generated at 2022-06-18 00:37:48.584624
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = 'print(*range(1), *range(3))'
    tree = parse(code)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True
    assert transformer._tree_changed == True

# Generated at 2022-06-18 00:38:00.202781
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer

        def test_simple(self):
            tree = self.get_ast("[2, *range(10), 1]")
            expected = self.get_ast("[2] + list(range(10)) + [1]")
            self.assertEqualAst(tree, expected)

        def test_nested(self):
            tree = self.get_ast("[2, *range(10), [1, *range(3)]]")
            expected = self.get_ast("[2] + list(range(10)) + [1] + list(range(3))")
            self.assertEqualAst(tree, expected)



# Generated at 2022-06-18 00:38:06.091062
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:38:11.841313
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import assert_equal_ast
    from .test_utils import assert_equal_source

    source = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = round_trip(source)
    assert_equal_ast(StarredUnpackingTransformer().visit(tree), expected)
    assert_equal_source(tree, expected)


# Generated at 2022-06-18 00:38:17.212215
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        [2] + list(range(10)) + [1]
        """

    Test().test()


# Generated at 2022-06-18 00:38:18.411111
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:38:26.051049
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:38:36.580877
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:38:47.111587
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:38:57.289757
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:40:23.693137
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer