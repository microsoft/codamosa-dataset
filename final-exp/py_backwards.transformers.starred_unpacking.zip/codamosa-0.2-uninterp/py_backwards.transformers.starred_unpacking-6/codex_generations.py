

# Generated at 2022-06-18 00:30:34.484053
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import assert_equal_ast
    from typed_ast import ast3 as ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:30:46.144585
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestTransformer3(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestTransformer4(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node


# Generated at 2022-06-18 00:30:53.842370
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:30:54.834787
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:31:02.362095
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:13.923460
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer5(BaseNodeTransformer):
        def visit_Call(self, node):
            return node


# Generated at 2022-06-18 00:31:21.890006
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.target == (3, 4)
    assert StarredUnpackingTransformer.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__qualname__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__module__ == 'py_mini_racer.transforms.starred_unpacking'
    assert StarredUnpackingTransformer.__doc__ is not None


# Generated at 2022-06-18 00:31:31.333328
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:42.093602
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse('print(*range(1), *range(3))').body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'print'
    assert len(node.value.args) == 2
    assert isinstance(node.value.args[0], ast.Starred)

# Generated at 2022-06-18 00:31:50.424434
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Starred, Name, List
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:06.231529
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = StarredUnpackingTransformer

        def _test(self, before, after):
            self.assertEqual(
                self.transform(before),
                after
            )

        def test_simple(self):
            self._test(
                """
                [2, *range(10), 1]
                """,
                """
                [2] + list(range(10)) + [1]
                """
            )


# Generated at 2022-06-18 00:32:16.894944
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:28.190348
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Starred, Name, List, Num, Add, BinOp
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: Call) -> Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: Call) -> Call:
            return node

    # Test 1
    node = Call(func=Name(id='print'), args=[Starred(value=Name(id='range'), ctx=Load()), Starred(value=Name(id='range'), ctx=Load())], keywords=[])

# Generated at 2022-06-18 00:32:37.041495
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:48.390123
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import get_ast_node_from_source

    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    node = get_ast_node_from_source(source)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)

    assert isinstance(result, ast.Expr)
    assert isinstance(result.value, ast.Call)
    assert transformer.tree_changed
    assert ast.dump(result)

# Generated at 2022-06-18 00:32:56.115531
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import source_to_ast as sta

    source = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = sta(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected

    source = """
    print(*range(1), *range(3), sep=' ')
    """
    expected = """
    print(*(list(range(1)) + list(range(3))), sep=' ')
    """
    tree = sta(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree)

# Generated at 2022-06-18 00:33:05.770416
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:33:16.712381
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:22.780299
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Subscript, Attribute, Load, Store, Tuple, Expr, Str, BinOp, Compare, Eq, Gt, Lt, GtE, LtE, In, NotIn, Is, IsNot, Invert, Not, UAdd, USub, NotEq, And, Or, Mult, MatMult, Div, FloorDiv, Mod, Pow, LShift, RShift, BitOr, BitXor, BitAnd, BitNot, BoolOp, BoolOp, UnaryOp, IfExp, Dict, Set, ListComp, SetComp, DictComp, GeneratorExp, Await, Yield, YieldFrom, Compare, Call, keyword, arg, arguments, alias, With, withitem, Raise, Try, TryExcept

# Generated at 2022-06-18 00:33:29.170845
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if not self._has_starred(node.args):
                return self.generic_visit(self.generic_visit(node))  # type: ignore

            self._tree_changed = True

            args = self._to_sum_of_lists(node.args)
            node.args = [ast.Starred(value=args)]
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:33:49.377083
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None)._split_by_starred([]) == [[]]
    assert StarredUnpackingTransformer(None)._split_by_starred([ast.Name(id='a')]) == [[ast.Name(id='a')]]
    assert StarredUnpackingTransformer(None)._split_by_starred([ast.Name(id='a'), ast.Starred(value=ast.Name(id='b'))]) == [[ast.Name(id='a')], ast.Starred(value=ast.Name(id='b')), []]
    assert StarredUnpackingTransformer(None)._split_by_starred([ast.Starred(value=ast.Name(id='b'))]) == [ast.Starred(value=ast.Name(id='b')), []]
    assert Starred

# Generated at 2022-06-18 00:33:59.681683
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:34:10.834603
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:34:20.294665
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:34:31.082904
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry

# Generated at 2022-06-18 00:34:43.251266
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:54.166259
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:04.911475
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    import astunparse
    import sys
    import io
    code = '''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    '''
    expected_code = '''
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    '''
    old_stdout = sys.stdout
    result = io.StringIO()
    sys.stdout = result
    node = ast.parse(code)
    StarredUnpackingTransformer().visit(node)
    ast.fix_

# Generated at 2022-06-18 00:35:15.505509
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_load
    from .test_utils import round_trip_load_dump
    from .test_utils import round_trip_dump_load
    from .test_utils import round_trip_load_dump_load
    from .test_utils import round_trip_dump_load_dump
    from .test_utils import round_trip_load_dump_load_dump
    from .test_utils import round_trip_dump_load_dump_load
    from .test_utils import round_trip_load_dump_load_dump_load
    from .test_utils import round_trip_dump_load_dump_load_dump

# Generated at 2022-06-18 00:35:27.368109
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformed_code_equal(
                '[2, *range(10), 1]',
                '[2] + list(range(10)) + [1]')

        def test_empty(self):
            self.assert_transformed_code_equal(
                '[*[]]',
                '[]')

        def test_empty_list(self):
            self.assert_transformed_code_equal(
                '[*[], *[]]',
                '[]')


# Generated at 2022-06-18 00:35:53.622868
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:36:04.343266
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import types
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        """Test class for StarredUnpackingTransformer."""

        def test_constructor(self):
            """Test for constructor."""
            with self.assertRaises(TypeError):
                StarredUnpackingTransformer()

        def test_visit_List(self):
            """Test for visit_List."""

# Generated at 2022-06-18 00:36:11.641475
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from typed_ast import ast27 as ast27
    import sys
    if sys.version_info[0] == 2:
        import typed_ast.ast27 as ast27
    elif sys.version_info[0] == 3:
        import typed_ast.ast3 as ast3
    else:
        raise RuntimeError("Unsupported Python version: %s" % sys.version_info[0])
    from typed_ast.transforms import StarredUnpackingTransformer
    import astunparse
    import textwrap
    code = textwrap.dedent("""
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """)
    tree = ast.parse(code)
    StarredUnpacking

# Generated at 2022-06-18 00:36:19.732042
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, Call, Name, List, Add, BinOp
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_has_starred(self):
            transformer = StarredUnpackingTransformer()
            self.assertFalse(transformer._has_starred([]))
            self.assertFalse(transformer._has_starred([Name(id='a')]))
            self.assertTrue(transformer._has_starred([Starred(value=Name(id='a'))]))

# Generated at 2022-06-18 00:36:30.650597
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .utils import dump_ast
    from .utils import parse_ast
    from .utils import compile_ast
    from .utils import eval_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = [ast.Starred(value=node.args[0])]
            return node

    code = 'print(1, 2, 3)'
    tree = parse_ast(code)
    tree = TestTransformer().visit(tree)

# Generated at 2022-06-18 00:36:31.710953
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:36:41.659218
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import os
    import astor
    import astunparse
    import textwrap
    import io
    import tokenize
    import token
    import re
    import unittest
    from contextlib import redirect_stdout

    class TestStarredUnpackingTransformer(unittest.TestCase):
        """Test StarredUnpackingTransformer."""

        def setUp(self):
            self.transformer = StarredUnpackingTransformer()

        def test_constructor(self):
            """Test for constructor."""
            self.assertIsInstance(self.transformer, BaseNodeTransformer)

# Generated at 2022-06-18 00:36:49.887418
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import convert
    from typed_ast.transforms import StarredUnpackingTransformer
    import sys
    import astunparse

    code = """
    print(*range(1), *range(3))
    """
    tree = convert(ast.parse(code), '3.4')
    StarredUnpackingTransformer().visit(tree)
    print(astunparse.unparse(tree))

    code = """
    print(*range(1), *range(3), sep=' ')
    """
    tree = convert(ast.parse(code), '3.4')
    StarredUnpackingTransformer().visit(tree)
    print(astunparse.unparse(tree))


# Generated at 2022-06-18 00:36:51.260421
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:36:52.157149
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:34.016532
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:37:41.257016
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTest

# Generated at 2022-06-18 00:37:47.725913
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import round_trip_with_transformer

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    assert round_trip_with_transformer(code, StarredUnpackingTransformer) == expected
    assert round_trip(expected) == expected


# Generated at 2022-06-18 00:37:53.873162
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:58.841397
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNode

# Generated at 2022-06-18 00:38:08.571427
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:38:15.229198
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import textwrap
    import sys
    import os

    # Test 1
    code = textwrap.dedent('''
    [2, *range(10), 1]
    ''')
    expected = textwrap.dedent('''
    [2] + list(range(10)) + [1]
    ''')
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    actual = astor.to_source(tree)
    assert expected == actual

    # Test 2

# Generated at 2022-06-18 00:38:23.685503
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from typed_ast.transforms import StarredUnpackingTransformer

    code = 'print(*range(1), *range(3))'
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:38:24.401496
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:38:25.411057
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-18 00:40:12.896287
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_output = """
        print(*(list(range(1)) + list(range(3))))
        """
        code = """
        print(*range(1), *range(3))
        """

    TestCase.do_test()


# Generated at 2022-06-18 00:40:20.499872
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from typed_ast.ast3 import List, Starred, Name, Load, Add, Call, Num
    from typed_ast.ast3 import BinOp, Expr, Module, parse
    from typed_ast.ast3 import AST, ASTError
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred

# Generated at 2022-06-18 00:40:26.765588
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_List'

        def test_empty(self):
            self.assert_transformed_ast(
                before_ast=ast.parse('[]'),
                after_ast=ast.parse('[]'),
                before_source='[]',
                after_source='[]',
            )
