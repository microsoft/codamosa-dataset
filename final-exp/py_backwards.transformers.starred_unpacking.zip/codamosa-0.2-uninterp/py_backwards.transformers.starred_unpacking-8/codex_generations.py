

# Generated at 2022-06-18 00:30:33.767328
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, BinOp
    from ..transformer import Transformer
    from .. import transformer_factory

    class TestTransformer(Transformer):
        def __init__(self):
            super().__init__()
            self.transformer = transformer_factory(StarredUnpackingTransformer)

        def visit_Call(self, node: Call) -> Call:
            return self.transformer.visit_Call(node)

    node = Call(
        func=Name(id='print'),
        args=[
            Starred(value=Name(id='range')),
            Starred(value=Name(id='range')),
        ],
        keywords=[])

# Generated at 2022-06-18 00:30:45.636553
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            node.elts.append(ast.Num(n=1))
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            node.elts.append(ast.Num(n=2))
            return node


# Generated at 2022-06-18 00:30:53.597093
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry


# Generated at 2022-06-18 00:30:58.143306
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node


# Generated at 2022-06-18 00:31:00.510223
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:31:08.801309
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:18.128471
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:29.818313
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import get_ast

    code = '[2, *range(10), 1]'
    expected = get_ast(code)
    expected.elts = [
        ast.Num(n=2),
        ast.Call(
            func=ast.Name(id='list'),
            args=[ast.Call(
                func=ast.Name(id='range'),
                args=[ast.Num(n=10)],
                keywords=[])],
            keywords=[]),
        ast.Num(n=1)
    ]
    expected = ast.List(elts=expected.elts)
    expected = ast.BinOp(left=expected.elts[0], right=expected.elts[1], op=ast.Add())

# Generated at 2022-06-18 00:31:31.960122
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-18 00:31:42.511870
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:52.140612
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from . import ast_utils
    from . import source_utils
    from . import tree_utils

    source = 'print(*range(1), *range(3))'
    tree = ast_utils.parse(source)
    tree = tree_utils.transform(tree, StarredUnpackingTransformer)
    source = source_utils.to_source(tree)
    assert source == 'print(*(list(range(1)) + list(range(3))))'


# Generated at 2022-06-18 00:31:58.899231
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:32:09.007830
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTest

# Generated at 2022-06-18 00:32:15.937996
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from .utils import get_ast
    from .utils import compare_source

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    tree = get_ast(source)
    StarredUnpackingTransformer().visit(tree)
    result = astor.to_source(tree).strip()

    compare_source(expected, result)


# Generated at 2022-06-18 00:32:25.601735
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return ast.List(elts=[ast.Num(n=1)], ctx=ast.Load())

    node = parse("[2, *range(10), 1]")
    node = StarredUnpackingTransformer().visit(node)
    node = TestTransformer().visit(node)
    assert ast.dump(node) == "List(elts=[Num(n=1)], ctx=Load())"



# Generated at 2022-06-18 00:32:32.942935
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load

    tree = ast.parse("""
    print(*range(1), *range(3))
    """)

    expected_tree = ast.parse("""
    print(*(list(range(1)) + list(range(3))))
    """)

    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed
    assert tree.body[0] == expected_tree.body[0]


# Generated at 2022-06-18 00:32:37.875553
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    assert round_trip(source, StarredUnpackingTransformer) == expected


# Generated at 2022-06-18 00:32:49.203599
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import round_trip_on_ast_node

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    assert round_trip(code, StarredUnpackingTransformer) == expected

    code = """
    print(*range(1), *range(3), sep=' ')
    """
    expected = """
    print(*(list(range(1)) + list(range(3))), sep=' ')
    """
    assert round_trip(code, StarredUnpackingTransformer) == expected

    code = """
    print(*range(1), *range(3), end='\\n')
    """

# Generated at 2022-06-18 00:32:55.174224
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from ast_helpers import get_ast
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return ast.List(elts=[ast.Num(n=1), ast.Num(n=2)])

    code = '[1, 2, 3]'
    expected = '[1, 2]'

    tree = get_ast(code)
    transformer = TestTransformer()
    new_tree = transformer.visit(tree)
    assert astor.to_source(new_tree) == expected



# Generated at 2022-06-18 00:33:04.924071
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import textwrap
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):

        def test_StarredUnpackingTransformer(self):
            code = textwrap.dedent('''
                [2, *range(10), 1]
                print(*range(1), *range(3))
            ''')
            expected_code = textwrap.dedent('''
                [2] + list(range(10)) + [1]
                print(*(list(range(1)) + list(range(3))))
            ''')
            tree = ast.parse(code)
            StarredUnpackingTransformer().vis

# Generated at 2022-06-18 00:33:22.073173
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load

# Generated at 2022-06-18 00:33:28.819070
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, BinOp
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_List(self, node):
            return node

    # Test case 1
    node = List(elts=[Starred(value=Name(id='range', ctx=Load()), ctx=Load()),
                      Name(id='range', ctx=Load())], ctx=Load())

# Generated at 2022-06-18 00:33:38.590548
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Add, Call, Load, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred

    # Test _has_starred
    assert _has_starred([Num(n=1), Num(n=2)]) == False
    assert _

# Generated at 2022-06-18 00:33:48.924784
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add

    assert StarredUnpackingTransformer().visit(
        Call(func=Name(id='print'), args=[Starred(value=Name(id='range'), ctx=Load()), Starred(value=Name(id='range'), ctx=Load())], keywords=[])) == Call(func=Name(id='print'), args=[Starred(value=List(elts=[Name(id='range')], ctx=Load()) + List(elts=[Name(id='range')], ctx=Load()))], keywords=[])

# Generated at 2022-06-18 00:33:59.309342
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:34:06.523700
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from astor.code_gen import to_source
    from .utils import compare_source

    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    tree = astor.parse_file(source)
    StarredUnpackingTransformer().visit(tree)
    result = to_source(tree).strip()

    compare_source(expected, result)


# Generated at 2022-06-18 00:34:14.869100
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import compile_to_ast
    from .utils import dump_ast
    from .utils import dump_code
    from .utils import assert_equal_code

    code = """
    print(*range(1), *range(3))
    """
    expected_code = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = compile_to_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_code(dump_code(tree), expected_code)


# Generated at 2022-06-18 00:34:20.872100
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            code = 'print(*range(1), *range(3))'
            expected = 'print(*(list(range(1)) + list(range(3))))'
            self.assertTransformEquals(code, expected)

    TestCase.run()


# Generated at 2022-06-18 00:34:31.299371
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import _ast
    from .base import _ast_str
    from .base import _ast_repr
    from .base import _ast_pprint
    from .base import _ast_dump
    from .base import _ast_parse
    from .base import _ast_iter
    from .base import _ast_iter_fields
    from .base import _ast_iter_child_nodes
    from .base import _ast_get_docstring
    from .base import _ast_copy_location
    from .base import _ast_fix_missing_

# Generated at 2022-06-18 00:34:39.877411
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_astunparse import unparse
    from .test_utils import roundtrip
    from .test_utils import roundtrip_and_compare_with_original

    code = '[2, *range(10), 1]'
    expected = 'list([2]) + list(range(10)) + list([1])'

    tree = roundtrip(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert unparse(tree) == expected

    roundtrip_and_compare_with_original(code, StarredUnpackingTransformer)



# Generated at 2022-06-18 00:35:00.685086
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'


# Generated at 2022-06-18 00:35:11.381837
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:22.486562
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:31.595226
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer


# Generated at 2022-06-18 00:35:37.424466
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List

    node = Call(func=Name(id='print'), args=[Starred(value=Name(id='range'), ctx=ast.Load()), Starred(value=Name(id='range'), ctx=ast.Load())], keywords=[])
    expected = Call(func=Name(id='print'), args=[Starred(value=List(elts=[Name(id='range'), Name(id='range')], ctx=ast.Load()))], keywords=[])
    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-18 00:35:38.412783
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:35:48.264516
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_env import TestEnv
    test_env = TestEnv()
    test_env.check_ast(ast.parse("[2, *range(10), 1]"),
                       StarredUnpackingTransformer)
    test_env.check_ast(ast.parse("print(*range(1), *range(3))"),
                       StarredUnpackingTransformer)

# Generated at 2022-06-18 00:35:59.117652
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse('print(*range(1), *range(3))')
    node = TestTransformer().visit(node)
    node = StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:36:09.075964
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer_class = TestTransformer
        transformer_module = '__main__'
        transformer_class_name = 'TestTransformer'
        transformer_kwargs = {}

        def test_simple(self):
            code = '[2, *range(10), 1]'
            expected_code = '[2] + list(range(10)) + [1]'
            self.assertCodeTransformation(code, expected_code)


# Generated at 2022-06-18 00:36:17.854015
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Num, Add, Call
    from typed_ast.ast3 import BinOp, Expr, Load, Store, Del, AugLoad, AugStore, Param, AnnAssign
    from typed_ast.ast3 import AugDel, Pass, Break, Continue, Return, Yield, Raise, Try, Assert
    from typed_ast.ast3 import Import, ImportFrom, Global, Nonlocal, Expr, If, While, For, With
    from typed_ast.ast3 import FunctionDef, ClassDef, Lambda, Dict, Set, ListComp, SetComp, DictComp
    from typed_ast.ast3 import GeneratorExp, Await, AsyncFor, AsyncWith, AsyncFunctionDef, NameConstant

# Generated at 2022-06-18 00:37:04.275861
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:15.467968
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_simple(self):
            self.assert_transformed(
                StarredUnpackingTransformer,
                'l = [1, 2, *range(3), 4]',
                'l = [1, 2] + list(range(3)) + [4]')

        def test_empty(self):
            self.assert_transformed(
                StarredUnpackingTransformer,
                'l = [1, 2, *[], 4]',
                'l = [1, 2, 4]')


# Generated at 2022-06-18 00:37:26.126166
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .unpacking import UnpackingTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .unpacking_assignment import UnpackingAssignmentTransformer
    from .unpacking_assignment_target import UnpackingAssignmentTargetTransformer
    from .unpacking_assignment_target_list import UnpackingAssignmentTargetListTransformer
    from .unpacking_assignment_target_tuple import UnpackingAssignmentTargetTupleTransformer
    from .unpacking_assignment_target_dict import UnpackingAssignmentTargetDictTransformer
    from .unpacking_assignment_target_set import UnpackingAssignmentTargetSetTransformer
    from .unpacking_assignment_target_set_literal import UnpackingAssignmentTargetSetLiteral

# Generated at 2022-06-18 00:37:27.003240
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:34.566852
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import compile_source
    from . import ast_equal

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'

    tree = compile_source(source, '<test>', 'exec')
    StarredUnpackingTransformer().visit(tree)
    compiled = compile_source(tree, '<test>', 'exec')

    assert ast_equal(compiled, expected)



# Generated at 2022-06-18 00:37:41.555749
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load, Expr
    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:50.717230
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer

# Generated at 2022-06-18 00:38:00.901596
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:10.947157
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:16.904966
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        print(*range(1), *range(3))
        """
        EXPECTED = """
        print(*(list(range(1)) + list(range(3))))
        """

    Test().test()


# Generated at 2022-06-18 00:39:02.750163
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists

# Generated at 2022-06-18 00:39:07.866454
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .test_helpers import assert_source_equal

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert_source_equal(expected, tree)


# Generated at 2022-06-18 00:39:15.597120
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:39:22.713189
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    node = ast.parse('[2, *range(10), 1]').body[0].value
    expected = ast.parse('[2] + list(range(10)) + [1]').body[0].value
    assert StarredUnpackingTransformer().visit(node) == expected
    assert TestTransformer().visit(node) == node


# Generated at 2022-06-18 00:39:27.370367
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .. import compile_ast
    from .. import parse

    code = '[2, *range(10), 1]'
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert compile_ast(tree) == '[2] + list(range(10)) + [1]'



# Generated at 2022-06-18 00:39:28.234433
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-18 00:39:34.823445
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:39:42.048395
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:39:51.359696
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import io

    class Dummy(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class Dummy2(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class Dummy3(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class Dummy4(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class Dummy5(BaseNodeTransformer):
        def visit_Call(self, node):
            return node


# Generated at 2022-06-18 00:39:56.250066
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__doc__ is not None
