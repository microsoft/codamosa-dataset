

# Generated at 2022-06-18 00:30:27.530745
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = """
    print(*range(1), *range(3))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == """
    print(*(list(range(1)) + list(range(3))))
    """


# Generated at 2022-06-18 00:30:29.170648
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == "StarredUnpackingTransformer"


# Generated at 2022-06-18 00:30:36.799401
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num

    node = Call(func=Name(id='print'), args=[Starred(value=List(elts=[Num(n=1)], ctx=ast.Load()))], keywords=[])
    expected = Call(func=Name(id='print'), args=[Starred(value=List(elts=[Num(n=1)], ctx=ast.Load()))], keywords=[])
    assert StarredUnpackingTransformer().visit(node) == expected


# Generated at 2022-06-18 00:30:47.732600
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    import astunparse
    import textwrap
    import ast
    import sys
    import io

    code = textwrap.dedent('''\
        [2, *range(10), 1]
        ''')
    expected_code = textwrap.dedent('''\
        [2] + list(range(10)) + [1]
        ''')
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    StarredUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-18 00:30:49.758091
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:31:00.237557
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:03.842531
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    actual = StarredUnpackingTransformer().visit(ast.parse(source))
    assert ast.dump(actual) == expected


# Generated at 2022-06-18 00:31:13.189077
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = 'print(*range(1), *range(3))'
    node = parse(code)
    StarredUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:31:22.134479
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer3(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return

# Generated at 2022-06-18 00:31:28.095420
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_StarredUnpackingTransformer(self):
            self.assertIsInstance(StarredUnpackingTransformer(), BaseNodeTransformer)

    unittest.main()

# Generated at 2022-06-18 00:31:43.400496
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:31:51.093280
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:31:52.003262
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:31:57.170575
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import roundtrip
    from typed_ast import ast3 as ast
    from typed_ast import ast27 as ast27
    from typed_ast import ast35 as ast35

    for ast_module in (ast, ast27, ast35):
        node = ast_module.parse("print(*range(1), *range(3))")
        node = StarredUnpackingTransformer().visit(node)
        assert roundtrip(node) == "print(*(list(range(1)) + list(range(3))))"



# Generated at 2022-06-18 00:32:07.224182
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import BinOp, Call, Name, Starred, List, Num, Add, Load

# Generated at 2022-06-18 00:32:17.482644
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

    class Dummy(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    node = ast.parse("print(*range(1), *range(3))").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'print'
    assert len(node.value.args) == 2
    assert isinstance(node.value.args[0], ast.Starred)

# Generated at 2022-06-18 00:32:28.233092
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast
    from typed_ast import parse

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        TARGET_VERSION = (3, 4)

        def test_simple(self):
            tree = parse("[2, *range(10), 1]")
            expected = parse("[2] + list(range(10)) + [1]")
            self.assertEqualAst(tree, expected)

        def test_nested(self):
            tree = parse("[2, *range(10), 1, *range(2)]")
            expected = parse("[2] + list(range(10)) + [1] + list(range(2))")

# Generated at 2022-06-18 00:32:32.898204
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    code = """
        print(*range(1), *range(3))
    """
    expected = """
        print(*(list(range(1)) + list(range(3))))
    """
    transformer = StarredUnpackingTransformer()
    tree = ast.parse(code)
    transformer.visit(tree)
    assert ast.dump(tree) == expected


# Generated at 2022-06-18 00:32:40.423361
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num, BinOp

# Generated at 2022-06-18 00:32:51.661858
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:33:11.876151
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return StarredUnpackingTransformer.visit_List(self, node)

    node = ast.parse("[2, *range(10), 1]")
    TestTransformer().visit(node)
    assert astor.to_source(node) == "[2] + list(range(10)) + [1]"

    node = ast.parse("[2, *range(10), 1, *range(10)]")
    TestTransformer().visit(node)
    assert astor.to_source(node) == "[2] + list(range(10)) + [1] + list(range(10))"

# Generated at 2022-06-18 00:33:22.146535
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:33:28.865030
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        def test_simple(self):
            tree = ast.parse('[2, *range(10), 1]')
            expected = ast.parse('[2] + list(range(10)) + [1]')
            self.check(tree, expected, StarredUnpackingTransformer)

        def test_empty(self):
            tree = ast.parse('[2, *[], 1]')
            expected = ast.parse('[2] + [] + [1]')
            self.check(tree, expected, StarredUnpackingTransformer)


# Generated at 2022-06-18 00:33:38.646933
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpacking

# Generated at 2022-06-18 00:33:48.969567
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import sys

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_List(self, node):
            return node

        def visit_Call(self, node):
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_List(self, node):
            return node

        def visit_Call(self, node):
            return node


# Generated at 2022-06-18 00:33:59.361976
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3
    from typed_ast import ast27
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num
    from typed_ast.ast27 import BinOp
    from typed_astunparse import unparse
    from typed_astunparse import dump
    from typed_astunparse import round_trip
    from typed_astunparse import round_trip_unparse
    from typed_astunparse import round_trip_dump
    from typed_astunparse import round_trip_parse
    from typed_astunparse import round_trip_load
    from typed_astunparse import round_trip_loads
    from typed_astunparse import round_trip_dumps
    from typed_astunparse import round_trip_loads_dumps
    from typed_astunparse import round_trip

# Generated at 2022-06-18 00:34:10.553051
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer

        def test_simple(self):
            self.assertTransformed(
                'a = [1, 2, 3]',
                'a = [1, 2, 3]',
            )

        def test_starred(self):
            self.assertTransformed(
                'a = [1, 2, *range(10), 3]',
                'a = [1, 2] + list(range(10)) + [3]',
            )


# Generated at 2022-06-18 00:34:20.062869
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer_visit_Call
    from .base import BaseNodeTransformer_visit_List
    from .base import BaseNodeTransformer_visit_Starred
    from .base import BaseNodeTransformer_visit_BinOp
    from .base import BaseNodeTransformer_visit_Name
    from .base import BaseNodeTransformer_visit_Call
    from .base import BaseNodeTransformer_visit_List
    from .base import BaseNodeTransformer_visit_Starred
    from .base import BaseNodeTransformer_visit_BinOp
    from .base import BaseNodeTransformer_visit_Name
    from .base import BaseNodeTransformer_visit_Call
    from .base import BaseNode

# Generated at 2022-06-18 00:34:21.428935
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:34:31.729806
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:58.647551
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            node = ast.parse('[2, *range(10), 1]')
            expected = ast.parse('[2] + list(range(10)) + [1]')
            self.assertEqual(self.transform(node), expected)

    TestCase.run()


# Generated at 2022-06-18 00:35:09.842923
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_visit_List(self):
            code = textwrap.dedent('''
                [2, *range(10), 1]
            ''')
            expected_code = textwrap.dedent('''
                [2] + list(range(10)) + [1]
            ''')
            tree = ast.parse(code)
            transformer = StarredUnpackingTransformer()
            new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:35:20.100401
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

# Generated at 2022-06-18 00:35:22.267077
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-18 00:35:31.491556
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:39.840134
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:35:41.556180
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    transformer = StarredUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-18 00:35:43.161804
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:35:51.349815
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:36:01.740216
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def create_transformer(self) -> StarredUnpackingTransformer:
            return StarredUnpackingTransformer()

        def test_simple(self):
            code = 'print(1, *range(10), 2)'
            expected = 'print(*(list([1]) + list(range(10)) + list([2])))'
            self.assertCodeChanged(code, expected)

        def test_nested(self):
            code = 'print(1, *range(10), *range(2))'
            expected = 'print(*(list([1]) + list(range(10)) + list(range(2))))'
            self.assertCodeChanged(code, expected)

        def test_nested_list(self):
            code

# Generated at 2022-06-18 00:36:48.841780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:00.143255
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:06.560476
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ast_compat import ast_to_source
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:17.566318
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import astunparse
    import textwrap
    import unittest

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def test_visit_List(self):
            code = textwrap.dedent('''
                [2, *range(10), 1]
            ''')
            expected_code = textwrap.dedent('''
                [2] + list(range(10)) + [1]
            ''')
            tree = ast.parse(code)
            expected_tree = ast.parse(expected_code)
            transformer = StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:25.073948
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        target_class = TestTransformer

        def test_simple(self):
            tree = ast.parse('[2, *range(10), 1]')
            self.check_transformation(tree, '[2, *range(10), 1]')

    Test().test_simple()


# Generated at 2022-06-18 00:37:35.888626
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load, BinOp
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestTransformer2(StarredUnpackingTransformer, TestTransformer):
        pass


# Generated at 2022-06-18 00:37:42.201142
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    # Test _has_starred
    assert _has_starred([]) == False

# Generated at 2022-06-18 00:37:48.411894
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import get_ast

    code = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    tree = get_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:38:00.202583
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Starred, Name, List, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    node = Call(func=Name(id='print'), args=[Starred(value=Name(id='range'), ctx=Load()), Starred(value=Name(id='range'), ctx=Load())], keywords=[])

# Generated at 2022-06-18 00:38:10.130249
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:39:42.621360
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, List, Call, Name, Add
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:39:51.888278
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer

# Generated at 2022-06-18 00:40:00.364729
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer_visit_Call
    from .base import BaseNodeTransformer_visit_List
    from .base import BaseNodeTransformer_visit_Starred
    from .base import BaseNodeTransformer_visit_BinOp
    from .base import BaseNodeTransformer_visit_Name
    from .base import BaseNodeTransformer_visit_Attribute
    from .base import BaseNodeTransformer_visit_Subscript
    from .base import BaseNodeTransformer_visit_Index
    from .base import BaseNodeTransformer_visit_Slice
    from .base import BaseNodeTransformer_visit_ExtSlice
    from .base import BaseNodeTransformer_visit_

# Generated at 2022-06-18 00:40:06.489475
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:40:14.200948
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.ast3 import parse
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry

    # Test 1
    node = List(elts=[Starred(value=Name(id='a'), ctx=ast.Load()), Starred(value=Name(id='b'), ctx=ast.Load())])

# Generated at 2022-06-18 00:40:23.290050
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, List, Call, Name, Add, BinOp
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry

    # [2, *range(10), 1]
    node = List(elts=[
        ast.Num(n=2),
        Starred(value=ast.Call(func=ast.Name(id='range'), args=[ast.Num(n=10)], keywords=[])),
        ast.Num(n=1)
    ])

    # [2] + list(range(10)) + [1]