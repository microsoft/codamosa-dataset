

# Generated at 2022-06-18 00:30:33.756831
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer
    from typed_ast.transforms.BaseNodeTransformer import BaseNodeTransformer

# Generated at 2022-06-18 00:30:45.635217
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:30:53.597206
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast


# Generated at 2022-06-18 00:31:01.334752
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from typed_ast.transforms import StarredUnpackingTransformer
    from typed_ast.transforms import PyTreeVisitor
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import PyTreeTransformer
    from typed_ast.transforms import Py

# Generated at 2022-06-18 00:31:12.595189
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if node.func.id == 'print':
                node.func.id = 'print_'
                return node
            return self.generic_visit(node)

    class TestTransformer2(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if node.func.id == 'print_':
                node.func.id = 'print'
                return node
            return self.generic_visit(node)


# Generated at 2022-06-18 00:31:19.908277
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import walk
    from .base import walk_fields
    from .base import walk_lineno
    from .base import walk_recursive
    from .base import walk_recursive_to_parent
    from .base import walk_recursive_to_parent_with_parents
    from .base import walk_recursive_to_parent_with_parents_and_child_index
    from .base import walk_recursive_to_parent_with_parents_and_child_index_and_siblings
    from .base import walk_recursive_to_parent

# Generated at 2022-06-18 00:31:30.848993
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:41.958433
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:31:50.326188
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor

    class DummyTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class DummyVisitor(BaseNodeVisitor):
        def visit_List(self, node):
            return node

    class DummyTransformer2(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class DummyVisitor2(BaseNodeVisitor):
        def visit_List(self, node):
            return node

    class DummyTransformer3(BaseNodeTransformer):
        def visit_List(self, node):
            return node


# Generated at 2022-06-18 00:31:59.846454
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:04.939591
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:32:15.950825
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:32:27.247655
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:34.399895
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip
    from .test_utils import dump_ast
    from .test_utils import assert_equal_ast

    code = """
        print(*range(1), *range(3))
    """
    expected = """
        print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:32:45.406947
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import NodeTransformer
    from .base import NodeVisitor
    from .base import Transformer
    from .base import Visitor
    from .base import walk
    from .base import walk_fields
    from .base import walk_lineno
    from .base import walk_recursive
    from .base import walk_recursive_to_parent
    from .base import walk_recursive_to_parent_with_parents
    from .base import walk_recursive_to_parent_with_parents_and_child_index
    from .base import walk_recursive_to_parent_with_parents_and_child_index_and_siblings
    from .base import walk_recursive_to_parent

# Generated at 2022-06-18 00:32:54.981523
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load, Expr, Assign, FunctionDef, Module
    from typed_ast.ast3 import parse as ast_parse
    from typed_ast.ast3 import dump as ast_dump

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast_parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert ast_dump(tree) == expected

    round_trip(code, expected, StarredUnpackingTransformer)


# Generated at 2022-06-18 00:33:04.783661
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:15.805275
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:20.232698
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3
    from .test_utils import round_trip

    code = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = ast3.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected



# Generated at 2022-06-18 00:33:27.675379
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:44.794223
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class Test(BaseNodeTransformerTestCase):
        def test_simple(self):
            code = '[2, *range(10), 1]'
            expected = '[2] + list(range(10)) + [1]'
            tree = ast.parse(code)
            new_tree = TestTransformer().visit(tree)
            result = compile(new_tree, '<test>', 'exec')
            ns = {}
            exec(result, ns)

# Generated at 2022-06-18 00:33:54.800817
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
   

# Generated at 2022-06-18 00:34:06.164946
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Add, Num

    node = Call(func=Name(id='print'), args=[Starred(value=Name(id='range'), ctx=Load()), Starred(value=Name(id='range'), ctx=Load())], keywords=[])
    expected = Call(func=Name(id='print'), args=[Starred(value=BinOp(left=List(elts=[Call(func=Name(id='list'), args=[Name(id='range')], keywords=[])], ctx=Load()), right=List(elts=[Call(func=Name(id='list'), args=[Name(id='range')], keywords=[])], ctx=Load()), op=Add()))], keywords=[])
    result

# Generated at 2022-06-18 00:34:16.671003
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List
    from typed_ast.ast3 import BinOp, Add, Num
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: Call) -> Call:
            return node

    # Test 1
    node = parse('print(1, 2, 3)').body[0]
    assert isinstance(node, Call)
    assert isinstance(node.func, Name)
    assert node.func.id == 'print'
    assert len(node.args) == 3
    assert isinstance(node.args[0], Num)

# Generated at 2022-06-18 00:34:23.125555
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:34:32.159468
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def __init__(self):
            self._tree_changed = False

        def visit_List(self, node):
            return node

    class TestTransformer2(StarredUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False

        def visit_List(self, node):
            return node

    class TestTransformer3(StarredUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False

        def visit_List(self, node):
            return node


# Generated at 2022-06-18 00:34:32.935118
# Unit test for method visit_Call of class StarredUnpackingTransformer

# Generated at 2022-06-18 00:34:34.233789
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:34:45.330248
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast, load_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    code = """
    print(*range(1), *range(3))
    """
    tree = load_ast(code)
    tree = StarredUnpackingTransformer().visit(tree)
    tree = TestTransformer().visit(tree)

# Generated at 2022-06-18 00:34:52.999943
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import assert_source_equal
    from .test_helpers import get_ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = get_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert_source_equal(expected, tree)


# Generated at 2022-06-18 00:35:18.165471
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:29.496796
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, Num, List
    from typed_ast.ast3 import Add, Sub, Mult, Div, Mod, Pow, LShift, RShift, BitOr, BitXor, BitAnd, FloorDiv
    from typed_ast.ast3 import Invert, Not, UAdd, USub, Eq, NotEq, Lt, LtE, Gt, GtE, Is, IsNot, In, NotIn, And, Or
    from typed_ast.ast3 import Assign, AugAssign, Del, Pass, Break, Continue, Return, Yield, Raise, Assert
    from typed_ast.ast3 import If, While, For, Try, With, FunctionDef, ClassDef, Global, Nonlocal, Expr, Import, ImportFrom

# Generated at 2022-06-18 00:35:39.535418
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    node = ast.parse("[2, *range(10), 1]")
    StarredUnpackingTransformer().visit(node)
    print(astunparse.unparse(node))
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.BinOp)
    assert isinstance(node.body[0].value.left, ast.BinOp)
    assert isinstance(node.body[0].value.left.left, ast.List)

# Generated at 2022-06-18 00:35:49.366558
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import textwrap
    import unittest
    from unittest import mock

    class TestStarredUnpackingTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = StarredUnpackingTransformer()

        def test_constructor(self):
            self.assertIsInstance(self.transformer, BaseNodeTransformer)
            self.assertIsInstance(self.transformer, StarredUnpackingTransformer)

        def test_visit_List(self):
            node = ast.parse("[2, *range(10), 1]").body[0].value

# Generated at 2022-06-18 00:35:53.205072
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        [2] + list(range(10)) + [1]
        """

    TestCase.run()


# Generated at 2022-06-18 00:35:58.626429
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import assert_equal_ast
    from .utils import parse_ast

    source = '[2, *range(10), 1]'
    expected = '[2] + list(range(10)) + [1]'
    tree = parse_ast(source)
    StarredUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-18 00:36:03.680091
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:36:11.432853
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from . import compile_source
    from . import dump_ast
    from . import dump_source
    from . import parse_source

    source = '[2, *range(10), 1]'
    expected = 'list([2]) + list(range(10)) + list([1])'

    tree = parse_source(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert dump_source(tree) == expected

    tree = parse_source(source)
    tree = StarredUnpackingTransformer().visit(tree)
    assert dump_source(tree) == expected

    tree = compile_source(source, mode='exec')
    tree = StarredUnpackingTransformer().visit(tree)
    assert dump_source(tree) == expected

    tree = compile_source(source, mode='eval')
    tree

# Generated at 2022-06-18 00:36:19.613778
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:30.356966
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Starred, Name, List
    from typed_ast.ast3 import BinOp, Add, Num
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTrans

# Generated at 2022-06-18 00:37:12.155964
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCaseWithOutput

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class TestCase(BaseNodeTransformerTestCaseWithOutput):
        transformer_class = TestTransformer

        def test_visit_Call(self):
            code = 'print(*range(1), *range(3))'
            expected_code = 'print(*(list(range(1)) + list(range(3))))'
            self.assertCodeOutput(code, expected_code)

    class TestCase2(BaseNodeTransformerTestCaseWithOutput):
        transformer_class = TestTransformer


# Generated at 2022-06-18 00:37:13.111634
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-18 00:37:22.273003
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

    class Dummy(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    node = ast.parse('[2, *range(10), 1]')
    expected = ast.parse('[2] + list(range(10)) + [1]')
    assert StarredUnpackingTransformer().visit(node) == expected
    assert Dummy().visit(node) == expected


# Generated at 2022-06-18 00:37:32.654339
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted
    from typed_ast.transforms.StarredUnpackingTransformer import ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred
    from typed_ast.transforms.StarredUnpackingTransformer import _prepare_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists

    # test _split_by_starred
    assert _

# Generated at 2022-06-18 00:37:39.050304
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    import astor
    import textwrap
    code = textwrap.dedent('''
        [2, *range(10), 1]
        print(*range(1), *range(3))
    ''')
    expected = textwrap.dedent('''
        [2] + list(range(10)) + [1]
        print(*(list(range(1)) + list(range(3))))
    ''')
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-18 00:37:47.197902
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class Test(BaseNodeTransformerTestCase):
        def test_1(self):
            node = ast.parse('print(*range(1), *range(3))')
            expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
            self.assertEqual(expected, TestTransformer().visit(node))

    Test().test_1()


# Generated at 2022-06-18 00:37:53.576587
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:38:03.321861
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import textwrap

    class Dummy(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class Dummy2(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    class Dummy3(BaseNodeTransformer):
        def visit_List(self, node):
            return node

        def visit_Call(self, node):
            return node

    class Dummy4(BaseNodeTransformer):
        def visit_List(self, node):
            return node

        def visit_Call(self, node):
            return node


# Generated at 2022-06-18 00:38:12.985131
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:21.612129
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import roundtrip, roundtrip_with_transformer
    from .test_utils import assert_equal_ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = ast.parse(code)
    tree = roundtrip_with_transformer(tree, StarredUnpackingTransformer)
    assert_equal_ast(tree, expected)

    code = 'print(*range(1), *range(3), sep=" ")'
    expected = 'print(*(list(range(1)) + list(range(3))), sep=" ")'
    tree = ast.parse(code)

# Generated at 2022-06-18 00:39:35.024473
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:39:37.251573
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    assert round_trip(source, StarredUnpackingTransformer) == expected



# Generated at 2022-06-18 00:39:45.956041
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class Test(BaseNodeTransformerTestCase):
        target_class = TestTransformer

        def test_simple(self):
            code = """
                print(*range(1), *range(3))
            """
            expected = """
                print(*(list(range(1)) + list(range(3))))
            """
            self.assertCodeTransformed(code, expected)

        def test_list(self):
            code = """
                [2, *range(10), 1]
            """

# Generated at 2022-06-18 00:39:55.946970
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:40:01.733716
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.transforms import StarredUnpackingTransformer
    from typed_ast.transforms.unparse import Unparser

    node = Call(
        func=Name(id='print'),
        args=[
            Starred(value=Name(id='range')),
            Starred(value=Name(id='range'))
        ],
        keywords=[])

    expected = Call(
        func=Name(id='print'),
        args=[
            Starred(value=List(elts=[
                Call(
                    func=Name(id='list'),
                    args=[Name(id='range')],
                    keywords=[])
            ]))
        ],
        keywords=[])


# Generated at 2022-06-18 00:40:08.664511
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import roundtrip_unparse
    from .test_utils import roundtrip_parse

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"

    tree = roundtrip_parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert roundtrip_unparse(tree) == expected

    tree = roundtrip_parse(expected)
    StarredUnpackingTransformer().visit(tree)
    assert roundtrip_unparse(tree) == expected



# Generated at 2022-06-18 00:40:15.718041
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from .test_utils import round_trip_dump
    from .test_utils import round_trip_load

    code = "[2, *range(10), 1]"
    tree = round_trip(code)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.List)
    assert len(tree.body[0].value.elts) == 3
    assert isinstance(tree.body[0].value.elts[0], ast.Num)
    assert isinstance(tree.body[0].value.elts[1], ast.Call)

# Generated at 2022-06-18 00:40:23.524185
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast
    from .utils import parse_ast
    from .utils import run_on_single_node

    code = """
    print(*range(1), *range(3))
    """
    expected_code = """
    print(*(list(range(1)) + list(range(3))))
    """
    node = parse_ast(code)
    node = run_on_single_node(node, StarredUnpackingTransformer)
    assert dump_ast(node) == expected_code
