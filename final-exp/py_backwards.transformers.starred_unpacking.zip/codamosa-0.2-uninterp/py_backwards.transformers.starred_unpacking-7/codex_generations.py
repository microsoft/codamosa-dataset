

# Generated at 2022-06-18 00:30:44.705997
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .utils import roundtrip

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    assert roundtrip(source, StarredUnpackingTransformer) == expected

    source = "[2, *range(10), *range(10), 1]"
    expected = "[2] + list(range(10)) + list(range(10)) + [1]"
    assert roundtrip(source, StarredUnpackingTransformer) == expected

    source = "[2, *range(10), *range(10), *range(10), 1]"
    expected = "[2] + list(range(10)) + list(range(10)) + list(range(10)) + [1]"
    assert roundtrip(source, StarredUnpackingTransformer) == expected


# Generated at 2022-06-18 00:30:52.999384
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer()
        target = (3, 4)

        def test_simple(self):
            self.assert_transformed_ast(
                before=ast.parse('print(1, 2, 3)'),
                after=ast.parse('print(1, 2, 3)'),
            )


# Generated at 2022-06-18 00:31:01.020495
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    node = Call(func=Name(id='print'), args=[Starred(value=Name(id='range'), ctx=Load()), Starred(value=Name(id='range'), ctx=Load())], keywords=[])
    expected = Call(func=Name(id='print'), args=[Starred(value=List(elts=[List(elts=[Call(func=Name(id='list'), args=[Name(id='range')], keywords=[])]), List(elts=[Call(func=Name(id='list'), args=[Name(id='range')], keywords=[])])], ctx=Load()))], keywords=[])

# Generated at 2022-06-18 00:31:10.744375
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    import astunparse
    from astunparse import Unparser
    from io import StringIO
    from typing import Union, Iterable, List
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .starred_unpacking import Splitted
    from .starred_unpacking import ListEntry
    from .starred_unpacking import StarredUnpackingTransformer
    from .starred_unpacking import Splitted
    from .starred_unpacking import ListEntry
    from .starred_unpacking import StarredUnpackingTransformer
    from .starred_unpacking import Splitted
    from .starred_unpacking import ListEntry

# Generated at 2022-06-18 00:31:18.395457
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .utils import compile_to_ast
    from .utils import dump_ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    tree = compile_to_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert dump_ast(tree) == expected

    code = 'print(*range(1), *range(3), sep="-")'
    expected = 'print(*(list(range(1)) + list(range(3))), sep="-")'

    tree = compile_to_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert dump_ast(tree) == expected


# Generated at 2022-06-18 00:31:21.699284
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:31:31.250154
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from typed_ast.transforms import StarredUnpackingTransformer
    from typed_ast.transforms import UnpackTransformer

    source = 'print(*range(1), *range(3))'
    tree = parse(source)
    StarredUnpackingTransformer().visit(tree)
    UnpackTransformer().visit(tree)

# Generated at 2022-06-18 00:31:37.630398
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        expected_output = """\
[2] + list(range(10)) + [1]
"""
        code = """\
[2, *range(10), 1]
"""

    TestCase.run_test()


# Generated at 2022-06-18 00:31:47.107296
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:31:55.181701
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry

# Generated at 2022-06-18 00:32:09.130572
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    tree = parse("[2, *range(10), 1]")
    node = tree.body[0].value
    assert isinstance(node, ast.List)

    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert transformer._tree_changed

    tree = parse("[2, *range(10), 1]")
    node = tree.body[0].value
    assert isinstance(node, ast.List)

    transformer = StarredUnpackingTransformer()
    transformer.visit(node)
    assert transformer._tree_changed

    tree = parse("[2, *range(10), 1]")
   

# Generated at 2022-06-18 00:32:18.530521
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astor
    import ast
    import sys

    code = """
    [2, *range(10), 1]
    print(*range(1), *range(3))
    """

    tree = astor.parse_file(code)
    tree = StarredUnpackingTransformer().visit(tree)
    print(astor.to_source(tree))

    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.BinOp)
    assert isinstance(tree.body[0].value.left, ast.BinOp)

# Generated at 2022-06-18 00:32:19.483042
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:32:30.222740
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    import astunparse
    import textwrap
    import astor
    import ast
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap
    import astor
    import astunparse
    import textwrap

# Generated at 2022-06-18 00:32:39.052909
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    assert issubclass(StarredUnpackingTransformer, BaseNodeTransformer)
    assert StarredUnpackingTransformer.__name__ == 'StarredUnpackingTransformer'
    assert StarredUnpackingTransformer.__module__ == __name__
    assert StarredUnpackingTransformer.target == (3, 4)
    # __init__
    x = StarredUnpackingTransformer()
    assert isinstance(x, StarredUnpackingTransformer)
    assert isinstance(x, BaseNodeTransformer)
    assert hasattr(x, 'visit')
    assert hasattr(x, 'visit_List')
    assert hasattr(x, 'visit_Call')

# Generated at 2022-06-18 00:32:50.416014
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    source = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)
    result = round_trip(tree)
    assert result == expected

    source = "[2, *range(10), 1, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1] + list(range(10)) + [1]"
    tree = ast.parse(source)
    tree = StarredUnpackingTransformer().visit(tree)
    result = round_trip(tree)
    assert result == expected


# Generated at 2022-06-18 00:32:58.902786
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    code = '''
    print(*range(1), *range(3))
    '''
    tree = parse(code)
    transformer = StarredUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True
    assert transformer.result == '''
    print(*(list(range(1)) + list(range(3))))
    '''


# Generated at 2022-06-18 00:33:09.763980
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:15.513784
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from typed_ast import ast3 as ast

    code = """
print(*range(1), *range(3))
    """
    expected = """
print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:33:24.820313
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:33:33.771739
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:33:43.456513
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    import astor
    import textwrap
    import astunparse

    code = textwrap.dedent('''
    print(*range(1), *range(3))
    ''')
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    print(astor.to_source(tree))
    print(astunparse.unparse(tree))
    assert astor.to_source(tree) == textwrap.dedent('''
    print(*(list(range(1)) + list(range(3))))
    ''').strip()


# Generated at 2022-06-18 00:33:53.534398
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_Call'

        def test_simple(self):
            tree = ast.parse('print(1, *range(3), 2)')
            expected = ast.parse('print(*(list(range(1)) + list(range(3)) + [2]))')
            self.assertTransformEqual(tree, expected)

        def test_no_starred(self):
            tree = ast.parse('print(1, 2)')
            expected = ast.parse('print(1, 2)')
            self.assertTransformEqual(tree, expected)


# Generated at 2022-06-18 00:34:04.853029
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:34:15.424321
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class TestCase(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer

        def test_simple(self):
            tree = ast.parse('print(*range(1), *range(3))')
            expected = ast.parse('print(*(list(range(1)) + list(range(3))))')
            self.assertEqualAst(tree, expected)

        def test_simple_no_starred(self):
            tree = ast.parse('print(1, 2, 3)')
            expected = ast.parse('print(1, 2, 3)')
            self.assertEqualAst(tree, expected)


# Generated at 2022-06-18 00:34:22.566494
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer

    # Test for method _has_starred of class StarredUnpackingTransformer

# Generated at 2022-06-18 00:34:32.134924
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from typed_ast.ast3 import parse
    from typed_ast.transforms import StarredUnpackingTransformer

    node = parse("print(*range(1), *range(3))")
    expected = parse("print(*(list(range(1)) + list(range(3))))")

    actual = StarredUnpackingTransformer().visit(node)

    assert isinstance(actual, Call)
    assert isinstance(actual.func, Name)
    assert actual.func.id == 'print'
    assert isinstance(actual.args[0], Starred)
    assert isinstance(actual.args[0].value, List)

# Generated at 2022-06-18 00:34:43.394237
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Name(id='range')),
            ast.Starred(value=ast.Name(id='range'))
        ],
        keywords=[])

    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Name(id='range')],
                keywords=[]))
        ],
        keywords=[])

    transformer = StarredUnpackingTransformer()
    result = transformer.visit(node)

    assert result == expected


# Generated at 2022-06-18 00:34:44.792115
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).__class__.__name__ == 'StarredUnpackingTransformer'

# Generated at 2022-06-18 00:34:56.252410
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: List) -> List:
            return self.generic_visit(node)

    class TestTransformer2(StarredUnpackingTransformer):
        def visit_List(self, node: List) -> List:
            return self.generic_visit(node)

    class TestTransformer3(StarredUnpackingTransformer):
        def visit_List(self, node: List) -> List:
            return self.generic_visit(node)


# Generated at 2022-06-18 00:35:14.228121
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)


# Generated at 2022-06-18 00:35:25.410251
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformation(
                '[2, *range(10), 1]',
                '[2] + list(range(10)) + [1]')

        def test_empty(self):
            self.assert_transformation(
                '[2, *range(10), 1, *[]]',
                '[2] + list(range(10)) + [1]')

        def test_nested(self):
            self.assert_transformation(
                '[2, *range(10), *[1, *range(3)]]',
                '[2] + list(range(10)) + [1] + list(range(3))')

   

# Generated at 2022-06-18 00:35:33.263073
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:38.171049
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        [2, *range(10), 1]
        """
        EXPECTED = """
        [2] + list(range(10)) + [1]
        """

    Test().test()



# Generated at 2022-06-18 00:35:48.001628
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer_visit_List
    from .base import BaseNodeTransformer_visit_List_test_parameters as test_parameters
    from .base import BaseNodeTransformer_visit_List_test_values as test_values
    from .base import BaseNodeTransformer_visit_List_test_expected_values as test_expected_values
    from .base import BaseNodeTransformer_visit_List_test_expected_values_with_changed_tree as test_expected_values_with_changed_tree

    # Create instance of class StarredUnpackingTransformer
    obj = StarredUnpackingTransformer()

    # Test method visit_List of class StarredUnpackingTransformer
    BaseNodeTransformer_visit_

# Generated at 2022-06-18 00:35:59.118190
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:36:09.075539
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Starred, Name, List, Add, Num

    node = Call(
        func=Name(id='print'),
        args=[
            Starred(value=Name(id='range')),
            Starred(value=Name(id='range'))
        ],
        keywords=[])


# Generated at 2022-06-18 00:36:10.900163
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None).target == (3, 4)

# Generated at 2022-06-18 00:36:15.516850
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    # Given
    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = ast.parse(code)
    # When
    StarredUnpackingTransformer().visit(tree)
    # Then
    assert astor.to_source(tree) == expected


# Generated at 2022-06-18 00:36:23.454084
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import textwrap
    source = textwrap.dedent('''
    [2, *range(10), 1]
    print(*range(1), *range(3))
    ''')
    expected = textwrap.dedent('''
    [2] + list(range(10)) + [1]
    print(*(list(range(1)) + list(range(3))))
    ''')
    tree = ast.parse(source)
    StarredUnpackingTransformer().visit(tree)
    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-18 00:37:04.512823
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists

    # Test _split_by_starred
    assert _split_by_starred([]) == [[]]
    assert _split_by_starred([Starred(value=Name(id='a'))]) == [Starred(value=Name(id='a'))]

# Generated at 2022-06-18 00:37:15.519921
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast27 as ast27
    from typed_ast.ast27 import Call
    from typed_ast.ast3 import Call as Call3
    from typed_ast.ast3 import Starred
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import List
    from typed_ast.ast3 import BinOp
    from typed_ast.ast3 import Add
    from typed_ast.ast3 import Num
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import keyword
    from typed_ast.ast3 import arg
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import keyword
    from typed_ast.ast3 import expr
    from typed_ast.ast3 import stmt

# Generated at 2022-06-18 00:37:20.457855
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from . import compile_source
    source = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    assert compile_source(source, StarredUnpackingTransformer) == expected


# Generated at 2022-06-18 00:37:30.007173
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:37:35.280697
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    code = "[2, *range(10), 1]"
    expected = "[2] + list(range(10)) + [1]"
    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected


# Generated at 2022-06-18 00:37:41.929735
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:51.125349
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:38:01.141146
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assertTransformedAST(
                before_ast=ast.parse("[2, *range(10), 1]"),
                after_source="[2] + list(range(10)) + [1]",
                after_ast=ast.parse("[2] + list(range(10)) + [1]"))


# Generated at 2022-06-18 00:38:11.173824
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:38:13.182516
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:39:27.730537
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-18 00:39:34.517970
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:39:41.716027
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .unpacking import StarredUnpackingTransformer
    from .unpacking import Splitted
    from .unpacking import ListEntry
    from .unpacking import _has_starred
    from .unpacking import _split_by_starred
    from .unpacking import _prepare_lists
    from .unpacking import _merge_lists
    from .unpacking import _to_sum_of_lists
    import astunparse
    import textwrap
    import astor
    import astpretty
    import astor
    import astpretty
    import astor
    import astpretty
    import astor
    import astpretty
    import astor
    import astpretty
    import astor
    import astpretty
    import astor
    import astpretty
   

# Generated at 2022-06-18 00:39:51.059210
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:39:59.775627
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, Num, List, Add
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists, _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry

# Generated at 2022-06-18 00:40:10.099280
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:40:16.647115
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:40:22.092236
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        method = 'visit_List'

        def test_simple(self):
            self.check_on_input(
                input="[2, *range(10), 1]",
                expected_output="[2] + list(range(10)) + [1]",
            )

    Test().test_all()


# Generated at 2022-06-18 00:40:32.129756
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer