

# Generated at 2022-06-18 00:30:30.488870
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .test_utils import round_trip

    code = 'print(*range(1), *range(3))'
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == 'print(*(list(range(1)) + list(range(3))))'

    code = 'print(*range(1), *range(3), sep=",")'
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == 'print(*(list(range(1)) + list(range(3))), sep=",")'

    code = 'print(*range(1), *range(3), sep=",", end="\\n")'
    tree

# Generated at 2022-06-18 00:30:33.636640
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer().target == (3, 4)

# Generated at 2022-06-18 00:30:45.634610
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    def test_transformer(transformer):
        node = ast.parse('print(*range(1), *range(3))')
        node = transformer().visit(node)
        assert isinstance(node, ast.Module)
        assert isinstance(node.body[0], ast.Expr)

# Generated at 2022-06-18 00:30:53.597850
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num

    node = List(elts=[Starred(value=Name(id='a', ctx=ast.Load())),
                     Starred(value=Name(id='b', ctx=ast.Load())),
                     Starred(value=Name(id='c', ctx=ast.Load()))])


# Generated at 2022-06-18 00:31:01.334751
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import os
    import astor
    from astor.code_gen import to_source
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import os
    import astor
    from astor.code_gen import to_source
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import inspect
    import sys
    import os
    import astor
    from astor.code_gen import to_source
    from .base import BaseNodeTransformer
    from .starred_unpacking import Star

# Generated at 2022-06-18 00:31:12.715427
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:31:14.236531
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer(None, None).__class__.__name__ == 'StarredUnpackingTransformer'

# Generated at 2022-06-18 00:31:22.916041
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .utils import compile_to_ast

    node = compile_to_ast("[2, *range(10), 1]")
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.List)
    assert len(node.value.elts) == 3
    assert isinstance(node.value.elts[0], ast.Num)
    assert isinstance(node.value.elts[1], ast.Call)
    assert isinstance(node.value.elts[2], ast.Num)

    node = compile_to_ast("[2, *range(10), 1, *range(3)]")
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.BinOp)

# Generated at 2022-06-18 00:31:31.748780
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class StarredUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
            [2, *range(10), 1]
            print(*range(1), *range(3))
        To:
            [2] + list(range(10)) + [1]
            print(*(list(range(1)) + list(range(3))))
            
        """
        target = (3, 4)

        def _has_starred(self, xs: List[ast.expr]) -> bool:
            for x in xs:
                if isinstance(x, ast.Starred):
                    return True

            return False


# Generated at 2022-06-18 00:31:42.276678
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    import astor
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:31:52.671738
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from astor.code_gen import to_source
    from .base import BaseNodeTransformer
    from .unpacking import UnpackingTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .unpacking_assignment import UnpackingAssignmentTransformer
    from .unpacking_assignment_in_comprehension import UnpackingAssignmentInComprehensionTransformer
    from .unpacking_assignment_in_comprehension_with_if import UnpackingAssignmentInComprehensionWithIfTransformer
    from .unpacking_assignment_in_comprehension_with_if_and_for import UnpackingAssignmentInComprehensionWithIfAndForTransformer
    from .unpacking_assignment_in_comprehension_with_if_and_for_and_as import UnpackingAssignmentInComp

# Generated at 2022-06-18 00:31:59.196822
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:09.245054
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:16.166272
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import parse_to_ast

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = parse_to_ast(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:32:17.762160
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer() is not None

# Generated at 2022-06-18 00:32:28.457599
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:32:37.234019
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:32:48.566730
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from ast_compat import parse
    from ast_compat import dump
    from ast_compat import unparse
    from ast_compat import cmp_ast
    from ast_compat import cmp_source
    from ast_compat import get_ast
    from ast_compat import get_source
    from ast_compat import get_source_without_comments
    from ast_compat import get_source_without_comments_and_docstrings
    from ast_compat import get_source_without_docstrings
    from ast_compat import get_source_without_leading_lines
    from ast_compat import get_source_without_trailing_lines
    from ast_compat import get_source_without_trailing_whitespace
    from ast_compat import get

# Generated at 2022-06-18 00:32:56.225497
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:00.979863
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'

    tree = ast.parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:33:10.904649
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        print(*range(1), *range(3))
        """
        EXPECTED = """
        print(*(list(range(1)) + list(range(3))))
        """

    Test().run()



# Generated at 2022-06-18 00:33:21.278451
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    tree = ast.parse('[2, *range(10), 1]')
    StarredUnpackingTransformer().visit(tree)
    TestTransformer().visit(tree)

# Generated at 2022-06-18 00:33:22.106753
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:33:28.842097
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:33:38.648530
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer_class = TestTransformer

    test_case = TestCase()

    test_case.assert_transformed_ast(
        """
        print(*range(1), *range(3))
        """,
        """
        print(*(list(range(1)) + list(range(3))))
        """
    )


# Generated at 2022-06-18 00:33:48.970085
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestCase(BaseNodeTransformerTestCase):
        transformer = TestTransformer
        method = 'visit_Call'

        def test_simple(self):
            node = ast.parse('print(1)')
            expected = ast.parse('print(1)')
            self.assertEqual(self.transform(node), expected)

        def test_starred(self):
            node = ast.parse('print(*range(1), *range(3))')

# Generated at 2022-06-18 00:33:59.361629
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    import astunparse
    import sys
    import os

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            if not self._has_starred(node.elts):
                return self.generic_visit(node)  # type: ignore

            self._tree_changed = True

            return self.generic_visit(self._to_sum_of_lists(node.elts))  # type: ignore


# Generated at 2022-06-18 00:34:10.553449
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Starred, List, Call, Name, Add
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: List) -> List:
            return node

    node = List(elts=[
        Starred(value=Call(func=Name(id='range'), args=[], keywords=[])),
        Starred(value=Call(func=Name(id='range'), args=[], keywords=[])),
    ])

# Generated at 2022-06-18 00:34:20.062643
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def test_simple(self):
            self.assert_transformation(
                StarredUnpackingTransformer,
                'print(*range(1), *range(3))',
                'print(*(list(range(1)) + list(range(3))))',
            )

        def test_simple_with_keywords(self):
            self.assert_transformation(
                StarredUnpackingTransformer,
                'print(*range(1), *range(3), sep=" ")',
                'print(*(list(range(1)) + list(range(3))), sep=" ")',
            )


# Generated at 2022-06-18 00:34:30.205982
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    node = ast.parse("print(*range(1), *range(3))").body[0]
    expected = ast.parse("print(*(list(range(1)) + list(range(3))))").body[0]
    actual = StarredUnpackingTransformer(TestTransformer()).visit(node)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-18 00:34:55.286752
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:05.965020
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestTransformer2(StarredUnpackingTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestTransformer3(StarredUnpackingTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node

    class TestTransformer4(StarredUnpackingTransformer):
        def visit_List(self, node: ast.List) -> ast.List:
            return node


# Generated at 2022-06-18 00:35:16.651725
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import List, Starred, Name, Call, Add, Num
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typed_ast.transforms.StarredUnpackingTransformer import _split_by_starred, _prepare_lists, _merge_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _to_sum_of_lists
    from typed_ast.transforms.StarredUnpackingTransformer import _has_starred

    # Test _has_starred
    assert _has_starred([]) == False

# Generated at 2022-06-18 00:35:28.355828
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node = StarredUnpackingTransformer().visit(node)
            return node

    tree = ast.parse("""
        print(*range(1), *range(3))
    """)
    tree = TestTransformer().visit(tree)

# Generated at 2022-06-18 00:35:39.074218
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .unpacking_in_assignment import UnpackingInAssignmentTransformer
    from .unpacking_in_function_call import UnpackingInFunctionCallTransformer
    from .unpacking_in_function_def import UnpackingInFunctionDefTransformer
    from .unpacking_in_function_def_args import UnpackingInFunctionDefArgsTransformer
    from .unpacking_in_function_def_defaults import UnpackingInFunctionDefDefaultsTransformer
    from .unpacking_in_function_def_kwonlyargs import UnpackingInFunctionDefKwonlyargsTransformer
    from .unpacking_in_function_def_kw_defaults import UnpackingInFunctionDefKwDefaultsTrans

# Generated at 2022-06-18 00:35:48.907195
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:35:52.545254
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer

        def test_simple(self):
            self.assert_transformed_code_is(
                '[2, *range(10), 1]',
                '[2] + list(range(10)) + [1]')

    TestCase.run()


# Generated at 2022-06-18 00:35:57.520003
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as ast

# Generated at 2022-06-18 00:35:58.624572
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:36:08.727102
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:36:47.517603
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from typed_ast.transforms.StarredUnpackingTransformer import StarredUnpackingTransformer
    from typed_ast.transforms.StarredUnpackingTransformer import Splitted, ListEntry
    from typing import Union, Iterable, List
    from .utils import assert_equal_ast

    node = Call(
        func=Name(id='print', ctx=Load()),
        args=[
            Starred(value=Name(id='range', ctx=Load()), ctx=Load()),
            Starred(value=Name(id='range', ctx=Load()), ctx=Load())
        ],
        keywords=[])


# Generated at 2022-06-18 00:36:58.768277
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:00.971421
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()


# Generated at 2022-06-18 00:37:05.806139
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = StarredUnpackingTransformer
        code = 'print(*range(1), *range(3))'
        expected_code = 'print(*(list(range(1)) + list(range(3))))'

    Test().test()


# Generated at 2022-06-18 00:37:11.580217
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .test_utils import roundtrip

    code = 'print(*range(1), *range(3))'
    expected = 'print(*(list(range(1)) + list(range(3))))'
    tree = parse(code)
    StarredUnpackingTransformer().visit(tree)
    assert roundtrip(tree) == expected



# Generated at 2022-06-18 00:37:19.582126
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
            [2, *range(10), 1]
        """
        EXPECTED = """
            list([2]) + list(range(10)) + list([1])
        """

    Test().test()


# Generated at 2022-06-18 00:37:28.901314
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:37:39.083443
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:37:40.034823
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:37:49.462962
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .utils import dump_ast

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    class TestStarredUnpackingTransformer2(StarredUnpackingTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node


# Generated at 2022-06-18 00:38:50.593625
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    import astor
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer2(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer3(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer4(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer5(BaseNodeTransformer):
        def visit_List(self, node):
            return node

    class TestTransformer6(BaseNodeTransformer):
        def visit_List(self, node):
            return node

   

# Generated at 2022-06-18 00:38:51.420725
# Unit test for constructor of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer():
    assert StarredUnpackingTransformer()

# Generated at 2022-06-18 00:39:00.626216
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:39:10.736151
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    import astunparse
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:39:15.120824
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = StarredUnpackingTransformer
        EXAMPLE = """
        print(*range(1), *range(3))
        """
        EXPECTED = """
        print(*(list(range(1)) + list(range(3))))
        """

    Test().test()

# Generated at 2022-06-18 00:39:23.668405
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, Starred, List, Num, Add, Load
    from .test_utils import round_trip

    tree = ast.parse("print(*range(1), *range(3))")
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == "print(*(list(range(1)) + list(range(3))))"

    tree = ast.parse("print(*range(1), *range(3), sep=' ')")
    StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == "print(*(list(range(1)) + list(range(3))), sep=' ')"


# Generated at 2022-06-18 00:39:30.244612
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from .test_utils import round_trip
    from .test_utils import parse_ast

    code = """
    print(*range(1), *range(3))
    """
    expected = """
    print(*(list(range(1)) + list(range(3))))
    """
    tree = parse_ast(code)
    tree = StarredUnpackingTransformer().visit(tree)
    assert round_trip(tree) == expected


# Generated at 2022-06-18 00:39:35.265432
# Unit test for method visit_List of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_List():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import BaseNodeTrans

# Generated at 2022-06-18 00:39:42.566124
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import BaseNodeTransformer
    from .starred_unpacking import StarredUnpackingTransformer
    from .base import Base

# Generated at 2022-06-18 00:39:51.820446
# Unit test for method visit_Call of class StarredUnpackingTransformer
def test_StarredUnpackingTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class Dummy(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            return node

    node = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Name(id='range')),
            ast.Starred(value=ast.Name(id='range'))
        ],
        keywords=[])

    expected = ast.Call(
        func=ast.Name(id='print'),
        args=[
            ast.Starred(value=ast.Call(
                func=ast.Name(id='list'),
                args=[ast.Name(id='range')],
                keywords=[]))
        ],
        keywords=[])