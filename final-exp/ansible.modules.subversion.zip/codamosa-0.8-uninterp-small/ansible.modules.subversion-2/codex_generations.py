

# Generated at 2022-06-25 03:17:14.566086
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    str_0 = "\x0e\x14\x1a"
    tuple_0 = ()
    bool_0 = False
    list_0 = [tuple_0, bool_0]
    subversion_0 = Subversion(str_0, str_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:17:18.736692
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    str_0 = ">'xK/&kg%)L#*=\t6M"
    tuple_0 = ()
    bool_0 = False
    list_0 = [bool_0, str_0]
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    var_0 = subversion_0.is_svn_repo()


# Generated at 2022-06-25 03:17:24.656880
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    str_0 = 'I"uF0b@xK8<'
    tuple_0 = ()
    bool_0 = False
    list_0 = [str_0, bool_0]
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    var_0 = subversion_0.switch()


# Generated at 2022-06-25 03:17:31.277637
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    str_0 = "P<md\tL(jw_"
    tuple_0 = ()
    bool_0 = False
    list_0 = [bool_0, str_0]
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    var_0 = subversion_0.switch()
    assert var_0 == True


# Generated at 2022-06-25 03:17:38.302040
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    str_0 = ">'xK/&kg%)L#*=\t6M"
    tuple_0 = ()
    bool_0 = False
    list_0 = [bool_0, str_0]
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    return subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:17:39.160496
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 03:17:41.242249
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 03:17:45.831934
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    str_0 = "&\tYa3\rL"
    tuple_0 = ()
    bool_0 = True
    list_0 = [bool_0, str_0]
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    subversion_0.is_svn_repo()
    # assert not subversion_0.needs_update()


# Generated at 2022-06-25 03:17:53.030369
# Unit test for method update of class Subversion
def test_Subversion_update():
    # Declare variables
    str_0 = "f<#^J1T$"
    tuple_0 = ()
    bool_0 = True
    list_0 = [str_0, tuple_0]
    list_1 = [str_0, tuple_0]
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    # Execute function
    var_0 = subversion_0.update()



# Generated at 2022-06-25 03:17:59.907189
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    str_0 = "1\x7f_rp{OAIq1$ qE~\x7f"
    tuple_0 = ()
    bool_0 = False
    list_0 = []
    subversion_0 = Subversion(str_0, tuple_0, str_0, bool_0, bool_0, list_0, str_0, bool_0)
    var_0 = subversion_0.has_local_mods()
    assert var_0 == False


# Generated at 2022-06-25 03:18:26.886515
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    subversion_0.get_revision()
    subversion_0.get_remote_revision()
    # change_1, curr_1, head_1 = subversion_0.needs_update()


# Generated at 2022-06-25 03:18:29.702031
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)

    # Test the outputs
    assert(subversion_0.revert()) == (None, None)


# Generated at 2022-06-25 03:18:30.479228
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 03:18:36.115336
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    str_0 = 'P<md\tL(jw_'
    # How to use subversion.get_revision(arg_0)
    # Return type: tuple(int, str)
    str_1 = 'P<md\tL(jw_'
    bool_1 = True
    subversion_0 = Subversion(str_0, bool_0, str_1, bool_0, bool_0, bool_1, str_1, bool_0)
    # How to use subversion.get_remote_revision(arg_

# Generated at 2022-06-25 03:18:38.803320
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    subversion_0.switch()


# Generated at 2022-06-25 03:18:47.420568
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    tuple_0 = subversion_0.needs_update()
    str_1 = 'curr'
    str_2 = 'rev2'
    if str_2:
        bool_0 = bool_0
    if not True:
        bool_0 = not bool_0
    if str_1:
        bool_0 = bool_0
    if not True:
        bool_0 = bool_0


# Generated at 2022-06-25 03:18:53.257174
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    bool_0 = True
    str_0 = 'P<md\tL(jw_'
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    subversion_0.get_revision()


# Generated at 2022-06-25 03:18:54.169287
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 03:18:57.993590
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    subversion_0.is_svn_repo()


# Generated at 2022-06-25 03:19:03.727454
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    str_0 = 'P<md\tL(jw_'
    bool_0 = True
    subversion_0 = Subversion(str_0, bool_0, str_0, bool_0, bool_0, bool_0, str_0, bool_0)
    subversion_0.revert()


# Generated at 2022-06-25 03:19:24.433545
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:19:26.184725
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 03:19:29.743354
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():

    subversion = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    assert type(subversion.get_remote_revision()) is str


# Generated at 2022-06-25 03:19:40.811794
# Unit test for function main
def test_main():
    # Exit duty is called
    ansible_module_main_exit_called = main_mock_args['ansible_module'].exit_json.called
    assert ansible_module_main_exit_called == True

    # Exit duty is called with the default items
    ansible_module_main_exit_called_default_items = main_mock_args['ansible_module'].exit_json.call_args_list[0][0][0]
    assert ansible_module_main_exit_called_default_items == {
        'ansible_facts': {
            'ansible_svn_version': '1.7.14'
        },
        'changed': False,
        'msg': 'Subversion 1.7.14'
    }


# Generated at 2022-06-25 03:19:44.026113
# Unit test for method is_svn_repo of class Subversion

# Generated at 2022-06-25 03:19:51.590938
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    var_0 = Subversion("module", "dest", "repo", "revision", "username", "password", "svn_path", False)
    var_1 = var_0.is_svn_repo()
    assert var_1 == 0


# Generated at 2022-06-25 03:19:55.624995
# Unit test for function main
def test_main():
    import nose

    # To run the unit tests
    nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'], exit=False)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:19:59.957868
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Execution of function main has failed", sys.exc_info())
        raise

if __name__ == '__main__':
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-25 03:20:03.825435
# Unit test for method update of class Subversion
def test_Subversion_update():
    print("test_Subversion_update")
    svn = Subversion()
    svn.update()



# Generated at 2022-06-25 03:20:05.828716
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_1 = Subversion()

    # Test for return code.
    assert var_1.revert() == True


# Generated at 2022-06-25 03:20:33.524646
# Unit test for method update of class Subversion
def test_Subversion_update():
    instance_0 = Subversion(None, None, None, None, None, None, None, None)
    instance_0._exec = lambda self, args, check_rc=True: args
    instance_0._exec_result = \
        ["update", "-r", "HEAD", "."]


# Generated at 2022-06-25 03:20:38.865906
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = Subversion()
    var_1 = var_0.get_revision()
    return var_1


# Generated at 2022-06-25 03:20:45.899362
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    svn = Subversion(module,dest,repo,revision,username,password,svn_path,validate_certs)
    result = svn.switch()
    assert result != None


# Generated at 2022-06-25 03:20:48.268984
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_1 = Subversion('c', 'b', 'a', 'a', 'a', 'a', 'a', 'a')
    var_2 = var_1.get_remote_revision()


# Generated at 2022-06-25 03:20:52.465738
# Unit test for function main
def test_main():
    fix_path = os.path.dirname(__file__)
    os.chdir(fix_path)
    print(os.getcwd())
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:21:00.204819
# Unit test for method is_svn_repo of class Subversion

# Generated at 2022-06-25 03:21:09.720761
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    declared_variable_0 = AnsibleModule(
            argument_spec={
                'dest': dict(type='str', required=True),
                'repo': dict(type='str', required=True),
                'revision': dict(type='str', required=True),
                'username': dict(type='str', required=True),
                'password': dict(type='str', required=True),
                'svn_path': dict(type='str', required=True),
                'validate_certs': dict(type='str', required=True)
            },
            supports_check_mode=True)

# Generated at 2022-06-25 03:21:16.421404
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    try:
        module = AnsibleModule(argument_spec={})
        svn = Subversion(module, "", "", "", "", "", "", "")
        svn.switch()
    except Exception:
        raise Exception


# Generated at 2022-06-25 03:21:23.158707
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = main()
    var_1 = var_0.get_revision()
    var_2 = 'Révision\xa0: 1889134'
    var_3 = 'URL\xa0: svn+ssh://an.example.org/path/to/repo'

    assert compare_nested_lists(var_1, var_2) == True
    assert compare_nested_lists(var_1, var_3) == True


# Generated at 2022-06-25 03:21:26.711931
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_1 = Subversion()
    var_2 = var_1.has_option_password_from_stdin()
    assert(var_2==0)


# Generated at 2022-06-25 03:22:09.718099
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:22:12.736986
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    obj = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    ret = obj.get_revision()

    assert( isinstance(ret,tuple) )
    assert( isinstance(ret[0],str) )
    assert( isinstance(ret[1],str) )


# Generated at 2022-06-25 03:22:18.053976
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            raise


# Generated at 2022-06-25 03:22:21.404553
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    # version 0.0 - test Subversion.switch
    # test passed
    global module
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    var_0 = Subversion(module, 'val_1', 'val_2', 'val_3', 'val_4', 'val_5', 'val_6', 'val_7')
    var_0.switch()


# Generated at 2022-06-25 03:22:25.367901
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    # Test method has_option_password_from_stdin of class Subversion
    var_1 = Subversion()
    var_2 = var_1.has_option_password_from_stdin()
    assert var_2 == False


# Generated at 2022-06-25 03:22:26.819547
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Execution failed")

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:22:30.687352
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_1 = Subversion()
    var_2 = var_1.needs_update()
    assert var_2 == (False, "Unable to get revision", "Unable to get revision"), f"Expected ((False, \"Unable to get revision\", \"Unable to get revision\"), got {var_2}"


# Generated at 2022-06-25 03:22:34.037499
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    var_1 = Subversion('module_0', 'dest_0', 'repo_0', 'revision_0', 'username_0', 'password_0', 'svn_path_0', 'validate_certs_0')
    Subversion.switch(var_1)


# Generated at 2022-06-25 03:22:45.696853
# Unit test for function main
def test_main():
    var_1 = ['/usr/bin/ansible']
    var_2 = dict()
    var_2['password'] = None
    var_2['force'] = False
    var_2['repo'] = 'svn+ssh://an.example.org/path/to/repo'
    var_2['executable'] = None
    var_2['checkout'] = True
    var_2['update'] = True
    var_2['in_place'] = False
    var_2['revision'] = 'HEAD'
    var_2['switch'] = True
    var_2['dest'] = '/src/checkout'
    var_2['export'] = False
    var_2['username'] = None
    var_2['validate_certs'] = False
    var_3 = dict()
    var_

# Generated at 2022-06-25 03:22:55.052266
# Unit test for function main

# Generated at 2022-06-25 03:24:46.366768
# Unit test for function main
def test_main():
    assert main() == 'main'


# Generated at 2022-06-25 03:24:53.728362
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    var_1 = var_0.revert()
    assert var_1 == True, "Error in Subversion.revert: expected True, got %s" % var_1


# Generated at 2022-06-25 03:24:56.664804
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    var_1 = Subversion(None, None, None, None, None, None, None, None)
    var_1.switch()


# Generated at 2022-06-25 03:25:00.511874
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # Setup
    var_0 = Subversion(get_module(), ".", "ansible/ansible-modules-core", "HEAD", "",
                       "", "svn", False)
    # Exercise
    var_1 = var_0.get_revision()
    # Verify
    assert var_1[1] == "URL: https://github.com/ansible/ansible-modules-core/trunk/"


# Generated at 2022-06-25 03:25:09.637280
# Unit test for method update of class Subversion
def test_Subversion_update():
    ansible_module_args = dict(
        dest='test_dest',
        repo='test_repo',
        revision='test_revision',
        username='test_username',
        password='test_password',
        svn_path='test_svn_path',
        validate_certs=True,
    )

    var_0 = Subversion(module=AnsibleModule(argument_spec=ansible_module_args), dest='test_dest', repo='test_repo', revision='test_revision', username='test_username', password='test_password', svn_path='test_svn_path', validate_certs=True, )
    var_0.update()



# Generated at 2022-06-25 03:25:11.683621
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    obj_Subversion_0 = Subversion()
    if assert_equals(obj_Subversion_0.revert(), true):
        print('test successful')
    else:
        print('test unsuccessful')


# Generated at 2022-06-25 03:25:17.055385
# Unit test for function main
def test_main():
    src_path = os.getenv('PY_SRC_PATH')
    if src_path is not None:
        sys.path.append(src_path)



# Start program
if __name__ == "__main__":
    # Get Argument Parameters
    arguments = docopt(__doc__, version='v0.1')
    # Get Arguments
    verbose = arguments['--verbose']
    debug = arguments['--debug']
    # Create Logger object
    logger = application_log.Logger(verbose=verbose, debug=debug)
    main()
    # Start program


    # if(__name__ == '__main__'):
    #     # Get Argument Parameters
    #     arguments = docopt(__doc__, version='v0.1')
    #     # Get Arguments
    #

# Generated at 2022-06-25 03:25:20.542342
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    subversion = Subversion(None, None, None, None, None, None, None, None)
    subversion.get_revision()
    # Asserting object equality results in a deprecation warning
    # assert subversion.get_revision() is None


# Generated at 2022-06-25 03:25:21.776546
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_0 = Subversion()
    var_0.has_option_password_from_stdin()


# Generated at 2022-06-25 03:25:28.408056
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    module = AnsibleModule({}, {}, dont_register=True)
    main(module)
    svn = Subversion(module, "/src/checkout", "svn+ssh://an.example.org/path/to/repo", "HEAD", "", "", "", "no")
    result = svn.get_revision()
    assert len(result) == 2
    assert result[0] == 'Revision: 1889134'
    assert result[1] == 'URL: svn+ssh://an.example.org/path/to/repo'
