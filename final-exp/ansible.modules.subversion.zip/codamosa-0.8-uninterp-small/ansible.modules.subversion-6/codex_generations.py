

# Generated at 2022-06-25 03:17:12.596205
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    output = subversion_0.switch()
    if output is True:
        print ('Passed')
    else:
        print ('Failed')


# Generated at 2022-06-25 03:17:17.807039
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    bytes_0 = b'#'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    float_0 = 3546.0
    tuple_0 = (dict_0,)
    int_0 = -3952
    subversion_0 = Subversion(tuple_0, bytes_0, bytes_0, int_0, bytes_0, tuple_0, dict_0, int_0)
    var_0 = subversion_0.has_option_password_from_stdin()



# Generated at 2022-06-25 03:17:24.612169
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    bytes_0 = b'\xf8]'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    float_0 = 3546.0
    tuple_0 = (dict_0,)
    int_0 = -3952
    subversion_0 = Subversion(tuple_0, bytes_0, bytes_0, int_0, bytes_0, tuple_0, dict_0, int_0)
    assert subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:17:28.987141
# Unit test for method update of class Subversion
def test_Subversion_update():
    module = AnsibleModule({})
    dest = 'dest'
    repo = 'repo'
    revision = 'revision'
    username = 'username'
    password = 'password'
    svn_path = 'svn_path'
    validate_certs = True
    subversion = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    var_0 = subversion.update()


# Generated at 2022-06-25 03:17:30.750800
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    test_case_0()


# Generated at 2022-06-25 03:17:42.168701
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    bytes_0 = b'L\xad\xad\xc2\x9b\x04\xa3\xec4\x88\x15\xf2\xf3\xc3\rNWM\xdf\x06\xdb\xe1\xa1\xab\x1a\x8d\xc7\x9d\xea\xaf*\xe2\x80\xbf\x90\x87'
    dict_0 = {bytes_0: bytes_0}
    list_0 = [bytes_0]
    float_0 = 178.0
    int_0 = 5
    subversion_0 = Subversion(list_0, bytes_0, dict_0, float_0, dict_0, list_0, dict_0, int_0)
    ret_0 = subversion_

# Generated at 2022-06-25 03:17:46.977759
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    bytes_0 = b'\x03,\xed\x8a\xf1\x1a'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    float_0 = -2900.0
    tuple_0 = (dict_0,)
    int_0 = 3694
    subversion_0 = Subversion(tuple_0, bytes_0, bytes_0, int_0, bytes_0, tuple_0, dict_0, int_0)
    var_0 = subversion_0.has_local_mods()


# Generated at 2022-06-25 03:17:56.863139
# Unit test for method update of class Subversion
def test_Subversion_update():
    bytes_0 = b'(\x8b\xcc\xd7t\xc6\xbcC\xbc\x99\x9b\xdf\xab\xb0\x18'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    float_0 = 11.0
    tuple_0 = (dict_0,)
    int_0 = -2
    subversion_0 = Subversion(tuple_0, bytes_0, bytes_0, int_0, bytes_0, tuple_0, dict_0, int_0)
    bool_2 = subversion_0.update()
    assert bool_2 == bool_0


# Generated at 2022-06-25 03:18:03.194991
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    bytes_0 = b'\x8a\xce\xa6!'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    float_0 = 3546.0
    tuple_0 = (dict_0,)
    int_0 = -3952
    subversion_0 = Subversion(tuple_0, bytes_0, bytes_0, int_0, bytes_0, tuple_0, dict_0, int_0)
    var_0 = subversion_0.needs_update()


# Generated at 2022-06-25 03:18:10.936289
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    # Case 0 : nop
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    float_0 = 3546.0
    tuple_0 = (dict_0,)
    int_0 = -3952
    subversion_0 = Subversion(tuple_0, bytes_0, bytes_0, int_0, bytes_0, tuple_0, dict_0, int_0)
    var_0 = subversion_0.switch()
    # Process 2

# Generated at 2022-06-25 03:18:31.746252
# Unit test for method switch of class Subversion

# Generated at 2022-06-25 03:18:32.635298
# Unit test for method update of class Subversion
def test_Subversion_update():
    test_case_0()

test_Subversion_update()

# Generated at 2022-06-25 03:18:39.030584
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locale import get_best_parsable_locale
    from ansible.module_utils.compat.version import LooseVersion

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.exit_json = self.warn = self.fail_json = self.run_command = self.set_fact = lambda *args, **kwargs: None



# Generated at 2022-06-25 03:18:49.213324
# Unit test for function main
def test_main():
    # Setup
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.fail_json = test_case_0
            self.exit_json = test_case_0
            self.run_command = test_case_0
        def get_bin_path(self, var_0, var_1):
            return test_case_0
        def run_command(self, var_0, var_1):
            return test_case_0
    class Subversion(object):
        def __init__(self, module, dest, repo, revision, username, password, svn_path, validate_certs):
            self.module = module

# Generated at 2022-06-25 03:18:57.277442
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    rev_0 = None
    var_0 = Subversion(rev_0, rev_0, rev_0, rev_0, rev_0, rev_0, rev_0, rev_0)
    str_0 = 'Passed'
    var_1 = print(str_0)
    str_1 = 'Failed'
    var_2 = print(str_1)


# Generated at 2022-06-25 03:19:03.611741
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    # Assert true
    try:
        test_case_0()
        str_2 = 'unit test passed'
        var_2 = print(str_2)
        return True
    except:
        str_3 = 'unit test failed'
        var_3 = print(str_3)
        return False

# Generated at 2022-06-25 03:19:06.106084
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    str_0 = 'Passed'
    var_0 = print(str_0)
    str_1 = 'Failed'
    var_1 = print(str_1)


# Generated at 2022-06-25 03:19:09.483617
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    str_0 = ''
    str_1 = ''
    str_2 = str_0 + str_1
    var_0 = len(str_2)
    str_3 = 'Passed'
    var_1 = print(str_3)
    str_4 = 'Failed'
    var_2 = print(str_4)


# Generated at 2022-06-25 03:19:16.774658
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    out1 = ''.join(self._exec(["status", "--quiet", "--ignore-externals", self.dest]))
    regex = re.compile(r'^[^?X]')
    regex.match(out1)
    out2 = regex.match(out1)
    if out2 is None:
        var_2 = test_case_0()
    else:
        var_2 = test_case_1()


# Generated at 2022-06-25 03:19:22.389580
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    str_0 = 'Passed'
    var_0 = print(str_0)
    str_1 = 'Failed'
    var_1 = print(str_1)


# Generated at 2022-06-25 03:19:43.576513
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    int_0 = -3859
    boolean_0 = Subversion.revert()
    assert_equal(boolean_0, false)


# Generated at 2022-06-25 03:19:49.094405
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    bytes_0 = b'k\x9c\x9f\xaf\x8d\x95\x0b\x14\xa1\x0e\x0f\x9e[\xb3\x80'
    bytes_1 = {}
    int_0 = -13434
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_1, int_0, bytes_0, bytes_1, bytes_1, int_0)
    subversion_0.is_svn_repo()
    boolean_0 = subversion_0.switch()
    print("Result: %s"%(boolean_0))

# Generated at 2022-06-25 03:19:51.929090
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:20:01.457691
# Unit test for method update of class Subversion
def test_Subversion_update():
    # input arguments of svn command
    args = []
    str_0 = "update"
    args.append(str_0)
    str_1 = "-r"
    args.append(str_1)
    int_0 = 1
    args.append(int_0)
    int_1 = 2
    args.append(int_1)
    # output of svn command
    output = []
    str_2 = "A\tfile/to/show/modified"
    output.append(str_2)
    str_3 = "D\tfile/to/show/deleted"
    output.append(str_3)
    str_4 = "U\tfile/to/show/updated"
    output.append(str_4)
    # Expected result of the method
    expected_result = True

# Generated at 2022-06-25 03:20:02.924265
# Unit test for function main
def test_main():
    module_0 = AnsibleModule({}, False)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:20:12.493963
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    bytes_0 = b'\x1e\x99\xb0\xee\x88\x06\xa0Pd\x8d\x1c\xa6\xae\x82\x94\x80\x82'
    int_0 = 2386
    bytes_1 = b'\xc3\xb0\xb8\x88\x84\x08\xb3\x8e\x9d\xac'
    bytes_2 = b'\x1b\xd4\x97\x85\xfa\xb9\xb0\xca\xc4\x8c\x0c@\x97\x81\x07'

# Generated at 2022-06-25 03:20:22.193103
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    bytes_0 = b'\x8b\x8b\x13\xd3\xef\x08\xdb\xd8\x04\x14\x1f\xd8\xdb\xd4\x01'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)

    str_0, str_1 = subversion_0.get_revision()
    assert str_0 == 'Unable to get revision'
    assert str_1 == 'Unable to get URL'


# Generated at 2022-06-25 03:20:33.081239
# Unit test for function main
def test_main():
    module = MagicMock()
    module.check_mode = True
    module.params = {}
    module.params['validate_certs'] = True
    module.params['password'] = 'abc123'
    module.params['repo'] = 'http://example.com/repo'
    module.params['executable'] = '/usr/bin/svn'
    module.params['checkout'] = False
    module.params['dest'] = '/dest'
    module.params['switch'] = True
    module.params['update'] = False
    module.params['username'] = 'bob'
    module.params['force'] = False
    module.params['revision'] = 'HEAD'
    module.params['export'] = False
    module.params['in_place'] = False


# Generated at 2022-06-25 03:20:40.494144
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    try:
        bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
        bytes_1 = {}
        int_0 = -3952
        subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
        subversion_0.get_remote_revision()
    except:
        return False
    return True


# Generated at 2022-06-25 03:20:45.552543
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    return_value = subversion_0.is_svn_repo()
    assert isinstance(return_value, bool)


# Generated at 2022-06-25 03:21:36.221423
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    bytes_0 = b'\xab'
    bytes_1 = {}
    int_0 = -12703
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    curr = "Revision: 23056"
    head = "Revision: 23058"
    # Test case 1
    int_1 = 23056
    subversion_0.revision = int_1
    assert subversion_0.needs_update() == (True, curr, head)
    # Test case 2
    int_2 = 23055
    subversion_0.revision = int_2
    assert subversion_0.needs_update() == (False, curr, head)
    # Test case 3
    int_3

# Generated at 2022-06-25 03:21:40.748615
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b'\x10\xfa\x1d\xd7\x0b\xe7\xa6\x81\xce\xb0\xdc\x1f\x9d'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    result = subversion_0.revert()
    assert True == result


# Generated at 2022-06-25 03:21:51.136586
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    # Testing branch branch_0
    # Check if get_remote_revision raises the NotImplementedError exception
    with pytest.raises(NotImplementedError):
        subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:21:56.245517
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b"\x84\xf1\xb9p\x8f\x90\xae\x9b\x98m"
    bytes_1 = b'\xb0\x9a\x91\xf1\x14\x88\xa1\x84\xfa\x91\x97'
    bytes_2 = {}
    int_0 = -3962
    subversion_0 = Subversion(bytes_2, bytes_0, bytes_1, int_0, bytes_2, bytes_2, bytes_2, int_0)
    bool_0 = subversion_0.revert()
    assert bool_0


# Generated at 2022-06-25 03:22:03.398296
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b'\xad\n\x9f\x9c\x87j\x02\xa7\x80\x8e\x87j\x02\xa7\x80\x8e\x87j\x02\xa7\x80'
    bytes_1 = {}
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, 0, bytes_0, bytes_1, bytes_1, 0)
    result = subversion_0.revert()



# Generated at 2022-06-25 03:22:14.862739
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b'\x9a\x8a\x99\xa3w\x97\x0f\x8a\x8a'
    bytes_1 = {}
    int_0 = -14076
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    bytes_2 = b'\xa9\x8b\x98\x99\xadM\xa3\x8a\x97\x9f'
    subversion_0.repo = bytes_2
    int_1 = 8368
    subversion_0.revision = int_1

# Generated at 2022-06-25 03:22:24.773369
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    result = subversion_0.needs_update()
    assert result


# Generated at 2022-06-25 03:22:31.054879
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    bytes_0 = b'\x97\t\x9c\x8d\xde\x07\x84\x07\x8c\x1a\x9cC\x9c'
    int_0 = -17302
    subversion_0 = Subversion(bytes_0, bytes_0, bytes_0, int_0, bytes_0, bytes_0, bytes_0, int_0)
    boolean_0 = True
    assert_equal(subversion_0.has_option_password_from_stdin(), boolean_0)


# Generated at 2022-06-25 03:22:37.147113
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    assert subversion_0.revert() == None


# Generated at 2022-06-25 03:22:41.707471
# Unit test for method update of class Subversion
def test_Subversion_update():
    bytes_0 = b'\xac\x81\xac\x83\xac\x8b\xac\x8b\xac\x8b\x98\x8b'
    bytes_1 = {}
    int_0 = 9681
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    subversion_0.update()


# Generated at 2022-06-25 03:23:44.267329
# Unit test for method update of class Subversion
def test_Subversion_update():
    bytes_0 = b'{\x17\x89\x13\x02\x03\x19\x81\x16\xbf\x87\xdbU\x91\x99\xbc\x03\x91\x92\x14'
    bytes_1 = {}
    int_0 = -1511
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    # Call the method update of object subversion_0
    print(subversion_0.update())

# Generated at 2022-06-25 03:23:54.720173
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    bytes_0 = b"d"
    bytes_1 = b"/"
    bytes_2 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_3 = b"\x1c"
    int_0 = -3952
    bytes_4 = {}
    int_1 = -3887
    bytes_5 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'

# Generated at 2022-06-25 03:23:59.371861
# Unit test for function main

# Generated at 2022-06-25 03:24:09.723252
# Unit test for method update of class Subversion
def test_Subversion_update():
    bytes_0 = b'\xbc\x88l\xb2{\x84\x15\x8e\xb1\x91\xb7&\x90\x8b\x94\xb1\x9c\x85\x8d'
    bytes_1 = b'\xb2\x8d\x8e\x9a\x9d\x8b\x8c\x95\xb3'
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_0, int_0)
    subversion_1 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_0, int_0)
   

# Generated at 2022-06-25 03:24:17.789565
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    try:
        bytes_0 = b'\x0c\x91\xa6\x99\x16\x97\x03\x0c\x99\x9c\x84&\x94\x83\x0c\x8b'
        bytes_1 = {}
        int_0 = 6190
        subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
        result = subversion_0.has_local_mods()
        assert result == False
    except BaseException as exception_0:
        print(exception_0.args[0])
        raise exception_0


# Generated at 2022-06-25 03:24:21.952865
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    rc_0 = subversion_0.has_option_password_from_stdin()
    return rc_0


# Generated at 2022-06-25 03:24:22.873463
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 03:24:29.449534
# Unit test for method update of class Subversion
def test_Subversion_update():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    subversion_0.update()


# Generated at 2022-06-25 03:24:32.157609
# Unit test for function main
def test_main():
    # Test case 0 from above.
    assert main() == None

# unit tests for class Subversion

# Generated at 2022-06-25 03:24:35.716296
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    int_0 = -3952
    subversion_0 = Subversion(bytes_0, bytes_0, bytes_0, int_0, bytes_0, bytes_0, bytes_0, int_0)
    string_0 = subversion_0.get_remote_revision()
    print(string_0)



# Generated at 2022-06-25 03:26:12.831547
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    bytes_0 = b'\xf0\x81\xb10\xcf\xe8\x9a\x9b\xb6\xb7\xae\xba\x83\xab'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    str_0 = subversion_0.get_remote_revision()
    assert str_0 != ''


# Generated at 2022-06-25 03:26:20.156526
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    int_0 = -3952
    bytes_1 = {}
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    assert subversion_0.revert() is False


# Generated at 2022-06-25 03:26:30.791211
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    bytes_0 = b'\xa3\x94\x8f\xf9\x8d\x13\xce\x85\x84\x8dh\xb4\xcc'
    bytes_1 = {}
    int_0 = -3952
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    subversion_0.needs_update()


# Generated at 2022-06-25 03:26:37.439879
# Unit test for function main
def test_main():
    arguments = {}
    arguments['dest'] = {"type": "path"}
    arguments['repo'] = {"required": True, "type": "str", "aliases": ["name", "repository"]}
    arguments['revision'] = {"default": "HEAD", "type": "str", "aliases": ["rev", "version"]}
    arguments['force'] = {"default": False, "type": "bool"}
    arguments['username'] = {"type": "str"}
    arguments['password'] = {"type": "str", "no_log": True}
    arguments['executable'] = {"type": "path"}
    arguments['export'] = {"default": False, "type": "bool"}
    arguments['checkout'] = {"default": True, "type": "bool"}

# Generated at 2022-06-25 03:26:46.311963
# Unit test for method update of class Subversion
def test_Subversion_update():
    bytes_0 = b'\xa9\x1d\x81<\x14\x8a\x8c\x95'
    bytes_1 = b'\xa9\x11\x99\x91\x94\x8c'
    int_0 = -3948
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_1, int_0, bytes_1, bytes_0, bytes_0, int_0)
    bool_0 = subversion_0.update()



# Generated at 2022-06-25 03:26:53.226360
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    bytes_0 = b'\xb9l\x8c\x81\xa7\x99\x14\x8a\x82\x86&\x9a\x83o\x98'
    bytes_1 = {}
    int_0 = 3921
    subversion_0 = Subversion(bytes_1, bytes_0, bytes_0, int_0, bytes_0, bytes_1, bytes_1, int_0)
    int_0 = subversion_0.revert()
