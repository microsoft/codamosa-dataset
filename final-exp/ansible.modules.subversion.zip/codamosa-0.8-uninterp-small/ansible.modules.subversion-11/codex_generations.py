

# Generated at 2022-06-25 03:17:16.862233
# Unit test for function main

# Generated at 2022-06-25 03:17:19.018155
# Unit test for method switch of class Subversion
def test_Subversion_switch():

    # Setup
    var_0 = Subversion()

    # Testing
    # Testing
    var_0.switch()



# Generated at 2022-06-25 03:17:19.576623
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 03:17:22.219172
# Unit test for method update of class Subversion
def test_Subversion_update():
    obj_0 = Subversion(None, None, None, None, None, None, None, None)
    var_0 = obj_0.update()


# Generated at 2022-06-25 03:17:25.274323
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = Subversion(None, None, None, 'gW8=[v', None, None, None)
    int_0 = 1618
    str_0 = '^xMxE-'


# Generated at 2022-06-25 03:17:27.965259
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = Subversion(None, None, None, None, None, None, None, None)
    int_0 = -83
    str_0 = 'f[G;{l`HdS#P'


# Generated at 2022-06-25 03:17:32.338418
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    subversion = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    result = subversion.get_revision()


# Generated at 2022-06-25 03:17:35.572235
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = Subversion()
    var_0.needs_update()


# Generated at 2022-06-25 03:17:45.520200
# Unit test for method revert of class Subversion

# Generated at 2022-06-25 03:17:56.102328
# Unit test for method revert of class Subversion
def test_Subversion_revert():
  svn_path = '/bin/svn'
  repo = 'svn+ssh://an.example.org/path/to/repo'
  dest = '/src/checkout'
  revision = 'HEAD'
  username = 'Test'
  password = 'Test'
  validate_certs = False

# Generated at 2022-06-25 03:18:12.050129
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.update()



# Generated at 2022-06-25 03:18:19.814357
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_2 = None
    subversion_1 = Subversion(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    var_3 = ['a', 'b']
    var_4 = subversion_1.get_revision()
    assert var_4 == var_3


# Generated at 2022-06-25 03:18:29.041890
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    from ansible.constants import mk_boolean

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 03:18:31.744514
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.needs_update()


# Generated at 2022-06-25 03:18:33.595907
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_0 = None
    subversion_1 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_1.update()


# Generated at 2022-06-25 03:18:37.721628
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    subversion_0 = Subversion(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_6)
    subversion_0.revert()


# Generated at 2022-06-25 03:18:42.035322
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_0 = test_case_0()
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:18:46.507192
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = None
    var_1 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_0.get_revision()


# Generated at 2022-06-25 03:18:56.171904
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    var_44 = None
    var_45 = None
    var_46 = None
    var_47 = None
    var_48 = None
    var_49 = None
    var_50 = None
    var_51 = None
    subversion_1 = Subversion(var_44, var_45, var_46, var_47, var_48, var_49, var_50, var_51)
    var_52 = subversion_1.switch()

    assert(var_52==None)
    return var_52


# Generated at 2022-06-25 03:19:02.815716
# Unit test for function main
def test_main():
    # Test cases
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_0.checkout(var_0)
    subversion_0.export(var_0)
    subversion_0.switch()
    subversion_0.update()
    subversion_0.revert()
    var_0, var_1 = subversion_0.get_revision()
    subversion_0.get_remote_revision()
    subversion_0.has_local_mods()
    var_0, var_1, var_2 = subversion_0.needs_update()
    subversion_0.has_option_password_from_stdin()
    sub

# Generated at 2022-06-25 03:19:21.929783
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_option_password_from_stdin()


# Generated at 2022-06-25 03:19:27.341673
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.needs_update()


# Generated at 2022-06-25 03:19:31.965146
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_revision()


# Generated at 2022-06-25 03:19:39.196215
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.is_svn_repo()


# Generated at 2022-06-25 03:19:46.238182
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # Input arguments for the method
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Call the method
    var_1 = subversion_0.get_revision()
    return var_1



# Generated at 2022-06-25 03:19:51.537201
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    print('''Test get_remote_revision''')
    # Try to get the remote revision
    # If it gets the revision check if it has local mods
    # If it is a new directory it should not have local mods
    # If it is an old directory it should have local mods


# Generated at 2022-06-25 03:19:56.232376
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_2 = None
    subversion_1 = Subversion(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    var_3 = None
    var_4 = None
    var_3 = subversion_1.get_revision()
    assert (var_3 == var_4)



# Generated at 2022-06-25 03:20:04.305296
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    module_0 = type('', (), {})()
    module_0.run_command = lambda bits, check_rc, data = None: None
    module_0.warn = lambda msg: None
    dest_0 = "/Users/y/Code/Singularity-2.2/singularity-2.2/src/singularity/SingularityDriver.py"
    repo_0 = "file:///Users/y/Code/Singularity-2.2/singularity-2.2"
    revision_0 = "HEAD"
    username_0 = None
    password_0 = None
    svn_path_0 = "/usr/bin/svn"
    validate_certs_0 = False

# Generated at 2022-06-25 03:20:12.258487
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    # set up
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    # test
    try:
        var_1 = subversion_0.revert()
    except:
        assert False


# Generated at 2022-06-25 03:20:16.550703
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_local_mods()
    assert var_1 != False


# Generated at 2022-06-25 03:20:46.879877
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    assert None


# Generated at 2022-06-25 03:20:52.872136
# Unit test for method update of class Subversion
def test_Subversion_update():
    # Create an instance of the class
    subversion_0 = Subversion(None, None, None, None, None, None, None, None)
    # Invoke method
    retval = subversion_0.update()


# Generated at 2022-06-25 03:20:56.668985
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.needs_update()


# Generated at 2022-06-25 03:21:02.653577
# Unit test for method revert of class Subversion
def test_Subversion_revert():

    # Test case with placeholder inputs
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.revert()


# Generated at 2022-06-25 03:21:07.484468
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_option_password_from_stdin()



# Generated at 2022-06-25 03:21:13.242396
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    try:
        var_2 = None
        var_3 = None
        var_4 = None
        var_5 = None
        var_6 = None
        var_7 = None
        var_8 = True
        var_9 = None
        subversion_1 = Subversion(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)
        var_10 = subversion_1.get_remote_revision()
    except Exception as exc_obj:
        print(exc_obj)


# Generated at 2022-06-25 03:21:16.934674
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    var_1 = None
    subversion_0 = Subversion(var_1, var_1, var_1, var_1, var_1, var_1, var_1, var_1)
    var_2 = subversion_0.is_svn_repo()
    assert var_2 == False


# Generated at 2022-06-25 03:21:21.857039
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.update()


# Generated at 2022-06-25 03:21:24.166169
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    subversion_1 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = subversion_1.is_svn_repo()
    assert not var_2


# Generated at 2022-06-25 03:21:26.111287
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.needs_update()


# Generated at 2022-06-25 03:22:04.820269
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_0 = None
    var_1 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = var_1.get_remote_revision()


# Generated at 2022-06-25 03:22:10.987409
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    subversion = Subversion(None, './test/test_repo', 'https://github.com/ansible/ansible-modules-extras', None, None, None, None, None)
    # noinspection PyProtectedMember
    svn_version = subversion._exec([subversion.svn_path, '--version', '--quiet'], True)[1]
    revision = subversion.get_remote_revision()

    # No exception should be thrown
    assert revision == 'Revision: %s' % svn_version


# Generated at 2022-06-25 03:22:18.594917
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_0.has_local_mods()


# Generated at 2022-06-25 03:22:20.856653
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:22:25.982132
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_option_password_from_stdin()


# Generated at 2022-06-25 03:22:29.726673
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_0 = subversion_0.has_local_mods()
    assert var_0 is False


# Generated at 2022-06-25 03:22:33.485335
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_revision()


# Generated at 2022-06-25 03:22:37.199147
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    src_0 = None
    subversion_1 = Subversion(src_0, src_0, src_0, src_0, src_0, src_0, src_0, src_0)
    var_2 = subversion_1.switch()




# Generated at 2022-06-25 03:22:37.763533
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-25 03:22:47.773343
# Unit test for function main

# Generated at 2022-06-25 03:23:43.880750
# Unit test for function main

# Generated at 2022-06-25 03:23:46.131220
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_2 = None
    subversion_1 = Subversion(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    var_3 = subversion_1.update()


# Generated at 2022-06-25 03:23:52.219441
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.revert()


# Generated at 2022-06-25 03:23:59.106498
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_2 = None
    subversion_1 = Subversion(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    var_1, var_3, var_5 = subversion_1.needs_update()
    assert var_1 == None or var_1 == False
    assert var_3 == None or var_3 == ''
    assert var_5 == None or var_5 == ''


# Generated at 2022-06-25 03:24:06.371032
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    var_2 = None
    var_3 = "Hello"
    var_4 = "Hello"
    subversion_1 = Subversion(var_2, var_3, var_4, var_3, var_4, var_3, var_4, var_3)
    var_5 = subversion_1.switch()
    assert var_5 == True


# Generated at 2022-06-25 03:24:11.416273
# Unit test for function main
def test_main():
    try:
        test_case_1()
    except SystemExit:
        pass
    try:
        test_case_2()
    except SystemExit:
        pass
    try:
        test_case_3()
    except SystemExit:
        pass
    try:
        test_case_4()
    except SystemExit:
        pass
    try:
        test_case_5()
    except SystemExit:
        pass
    try:
        test_case_6()
    except SystemExit:
        pass


# Generated at 2022-06-25 03:24:15.352112
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.update()


# Generated at 2022-06-25 03:24:18.025435
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_revision()


# Generated at 2022-06-25 03:24:20.303184
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_local_mods()


# Generated at 2022-06-25 03:24:23.778766
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.update()
    return var_1 == None


# Generated at 2022-06-25 03:25:38.154267
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.revert()


# Generated at 2022-06-25 03:25:45.399157
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.needs_update()
    if (var_1):
        test_case_0()


# Generated at 2022-06-25 03:25:52.335241
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_0.is_svn_repo()
    if subversion_0.is_svn_repo():
        if not subversion_0.switch():
            subversion_0.update()
    else:
        subversion_0.checkout(False)
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.update()


# Generated at 2022-06-25 03:26:05.000526
# Unit test for method update of class Subversion
def test_Subversion_update():
    # Test with no parameters
    assert test_case_0() == None


#     def get_revision(self):
#         '''Revision and URL of subversion working directory.'''
#         text = '\n'.join(self._exec(["info", self.dest]))
#         rev = re.search(self.REVISION_RE, text, re.MULTILINE)
#         if rev:
#             rev = rev.group(0)
#         else:
#             rev = 'Unable to get revision'
#
#         url = re.search(r'^URL\s?:.*$', text, re.MULTILINE)
#         if url:
#             url = url.group(0)
#         else:
#             url = 'Unable to get URL'
#
#         return rev

# Generated at 2022-06-25 03:26:10.456503
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_1 = None
    subversion_0 = Subversion(var_1, var_1, var_1, var_1, var_1, var_1, var_1, var_1)
    var_2 = subversion_0.revert()


# Generated at 2022-06-25 03:26:14.759299
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_2 = None
    var_3 = 'dest'
    var_4 = 'repo'
    var_5 = 'revision'
    var_6 = 'username'
    var_7 = 'password'
    var_8 = 'svn_path'
    var_9 = 'validate_certs'
    subversion_1 = Subversion(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)
    var_10, var_11, var_12 = subversion_1.needs_update()


# Generated at 2022-06-25 03:26:17.836681
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    subversion_1 = Subversion(None, None, None, None, None, None, None, None)
    var_2 = subversion_1.switch()
    return var_2


# Generated at 2022-06-25 03:26:22.395994
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    subversion_2 = Subversion(var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10)
    var_11 = subversion_2.revert()


# Generated at 2022-06-25 03:26:29.238047
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_option_password_from_stdin()


# Generated at 2022-06-25 03:26:36.044748
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_revision()
    var_2 = subversion_0.get_remote_revision()
    var_3 = int(var_1.split(':')[1].strip())
    var_4 = int(var_2.split(':')[1].strip())
    var_5 = False
    if var_3 < var_4:
        var_5 = True
    var_6 = var_5, var_1, var_2
    return var_6

constraints = [(test_Subversion_needs_update,0,[])]

