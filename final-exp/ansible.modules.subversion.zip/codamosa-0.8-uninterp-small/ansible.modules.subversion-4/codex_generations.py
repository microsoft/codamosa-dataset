

# Generated at 2022-06-25 03:17:18.099024
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    float_1 = 643.84
    list_0 = [bytes_0, float_0, float_0]
    set_0 = {bytes_0, float_0, float_1}
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_1, list_0, set_0, float_1)
    var_0 = subversion_0.revert()


# Generated at 2022-06-25 03:17:19.099024
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    assert True


# Generated at 2022-06-25 03:17:27.275176
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    float_1 = 643.84
    list_0 = [bytes_0, float_0, float_0]
    set_0 = {bytes_0, float_0, float_1}
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_1, list_0, set_0, float_1)
    subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:17:33.456736
# Unit test for method update of class Subversion
def test_Subversion_update():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    float_1 = 643.84
    list_0 = [bytes_0, float_0, float_0]
    set_0 = {bytes_0, float_0, float_1}
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_1, list_0, set_0, float_1)
    var_0 = subversion_0.update()
    subversion_0.revert()
    var_1 = subversion_0.update()

# Generated at 2022-06-25 03:17:41.617969
# Unit test for function main
def test_main():
    try:
        import subversion
    except ImportError:
        subversion = None
    if subversion is None:
        import sys
        if sys.version_info[0] == 2:
            module.fail_json(msg='ansible.module_utils.subversion is only available on python3')
        else:
            module.fail_json(msg='ansible.module_utils.subversion is only available on python2')

    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:17:47.627461
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    float_1 = 643.84
    list_0 = [bytes_0, float_0, float_0]
    set_0 = {bytes_0, float_0, float_1}
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_1, list_0, set_0, float_1)
    var_0 = subversion_0.switch()


# Generated at 2022-06-25 03:17:58.842922
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # Float test cases
    float_0 = 0.0
    float_1 = 643.84
    bool_0 = False
    # Bytes test cases
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    # List test cases
    list_0 = [bytes_0, float_0, float_0]
    # Set test cases
    set_0 = {bytes_0, float_0, float_1}
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_1, list_0, set_0, float_1)
    subversion_0_0 = subversion_0.get_revision()


# Generated at 2022-06-25 03:18:07.441098
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'^\x9c\x90\x9a\xbb\x80/\xfe\xde\x86\xc1|>t'
    float_1 = 893.45
    list_0 = [float_0, float_0, bytes_0]
    set_0 = {float_0, float_1, bytes_0}
    subversion_0 = Subversion(bytes_0, float_0, list_0, bytes_0, float_1, float_0, set_0, float_1)
    var_0 = subversion_0.get_revision()
    assert(var_0 != None)


# Generated at 2022-06-25 03:18:13.501372
# Unit test for function main

# Generated at 2022-06-25 03:18:23.148737
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'\x9f\x89\xbf\x14\xb3\x85\xb2\x8e\x94\x1e\x9b\x9b\x90\x0f\xc1\x1bc'
    float_1 = 559.47
    list_0 = [bool_0, float_1]
    set_0 = {float_0, bytes_0, bool_0}
    subversion_0 = Subversion(bytes_0, bytes_0, set_0, list_0, bytes_0, bytes_0, float_0, float_1)
    var_0 = subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:18:48.990679
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    print('Testing needs_update')
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'bO\xa3\xe6\x8c\x86\xf4\x0e)\x8e\xfc\xdbH\x03\x1d\x8a\xfc\xc9\x9fc\xf1\x17\x0e\x82\x1c\x8b'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    var_0, var_1, var_2 = subversion_0.needs_update()
    if (var_0):
        print(var_1)
        print(var_2)



# Generated at 2022-06-25 03:18:59.710834
# Unit test for function main
def test_main():
    # Module imports
    import ansible.module_utils.basic
    import ansible.module_utils.common.locale
    import ansible.module_utils.compat.version
    import datetime
    import os
    import re
    import shutil
    import tempfile
    import time
    import types as python_types
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.configparser
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.configparser

    # from ansible.module_utils.basic import Ansible

# Generated at 2022-06-25 03:19:03.828710
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b"\x9a%\x90YS\x0e\x1d\xaf\xa2\x0c5\xc3\x84"
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    float_1, float_2, float_3 = subversion_0.needs_update()


# Generated at 2022-06-25 03:19:08.494854
# Unit test for method update of class Subversion
def test_Subversion_update():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'\xf5\x8f\xa3\x05\xaf\x9a\xd8\x1a\xb5\x06'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    subversion_0.update()


# Generated at 2022-06-25 03:19:19.843303
# Unit test for method update of class Subversion
def test_Subversion_update():
    try:
        float_0 = 0.0
        bool_0 = False
        bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
        subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
        var_0 = subversion_0.update()
    except Exception:
        import sys
        print("Unexpected exception:", sys.exc_info()[0])
        raise

# Generated at 2022-06-25 03:19:25.374299
# Unit test for function main

# Generated at 2022-06-25 03:19:32.274964
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    subversion_0.get_revision()


# Generated at 2022-06-25 03:19:41.332431
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    var_0 = subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:19:47.534743
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    var_0 = subversion_0.has_option_password_from_stdin()


# Generated at 2022-06-25 03:19:54.504669
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    bool_0 = subversion_0.revert()


# Generated at 2022-06-25 03:20:19.451909
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    subversion_0 = Subversion(None, None, None, None, None, None, None, None)
    subversion_0.revert()


# Generated at 2022-06-25 03:20:21.620881
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:20:27.088693
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'WJ|\x10\xacO\xf7\x95w\x8d\xce\x00\xabk'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    var_0, var_1, var_2 = subversion_0.needs_update()
    if var_0 and var_1 == 'Unable to get revision' and var_2 == 'Unable to get revision':
        pass
    else:
        print('Expected: ')
        print(True, 'Unable to get revision', 'Unable to get revision')
        print('Actual: ')

# Generated at 2022-06-25 03:20:37.598537
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    float_0 = 0.0
    str_0 = '\x1b\x1c\x8f\x12\x89\xab\xb9\x9d'
    bytes_0 = b'\x04\x8d\xd5\x91\x1e\xcfJ\xb4\x06\x82\xf0'
    subversion_0 = Subversion(float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0)
    subversion_1 = Subversion(float_0, str_0, float_0, float_0, float_0, float_0, float_0, float_0)

# Generated at 2022-06-25 03:20:43.889043
# Unit test for function main
def test_main():
    float_0 = 0.0
    bytes_0 = b'\x10'
    module_0 = AnsibleModule(argument_spec={}, supports_check_mode=bytes_0)
    bytes_1 = b'\x05\xfb\x84\xf3\x16o\xcf\xdc\x94\x0c\x1d\x07\x8d\xa2\xef\xbf\xbd\xef\xbf\xbd\xef\xbf\xbdi\x1f\xef\xbf\xbd_\xef\xbf\xbdG~\xef\xbf\xbd\xef\xbf\xbd'

# Generated at 2022-06-25 03:20:44.897238
# Unit test for function main
def test_main():
    test_case_0()

# Generated test for function subversion.is_svn_repo

# Generated at 2022-06-25 03:20:48.436617
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'\xab\xad\xa1\xbd\x97\xbc\xec\xf7'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    subversion_0.get_revision()


# Generated at 2022-06-25 03:20:55.451556
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'\x9e#\x8a\xa2\xf6n\x05\x0e\x1c\xac\x02\xe9'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    subversion_1 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    subversion_2 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)

# Generated at 2022-06-25 03:20:59.298367
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'@\x90d\x05\x1e\xc5\xfd\x9f\x99\x01\x8b'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    var_0 = subversion_0.switch()


# Generated at 2022-06-25 03:21:03.704700
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    float_0 = 0.0
    bool_0 = False
    bytes_0 = b'\x9fz'
    subversion_0 = Subversion(float_0, bool_0, bytes_0, bytes_0, float_0, bytes_0, float_0, float_0)
    var_0 = subversion_0.has_local_mods()


# Generated at 2022-06-25 03:21:33.115351
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_revision()


# Generated at 2022-06-25 03:21:36.096590
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = subversion_0.revert(var_1)


# Generated at 2022-06-25 03:21:41.693082
# Unit test for function main
def test_main():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.is_svn_repo()
    subversion_1 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = subversion_1.checkout(var_1)
    subversion_2 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_3 = subversion_2.update()

# Generated at 2022-06-25 03:21:47.242991
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_local_mods()


# Generated at 2022-06-25 03:21:53.591130
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    var_3 = '/var/tmp/ansible_subversion_payload_xmBc7R'
    var_2 = 'https://svn.apache.org/repos/asf/subversion/trunk'
    var_1 = None
    var_0 = None
    # Check if path is a SVN Repo
    subversion_0 = Subversion(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    var_8 = subversion_0.is_svn_repo()
    return var_8


# Generated at 2022-06-25 03:22:04.621101
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:22:13.312188
# Unit test for method update of class Subversion
def test_Subversion_update():
    # Initializing main class with all its arguments
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    subversion_0 = Subversion(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    var_8 = subversion_0.update()
    assert(var_8 == None)


# Generated at 2022-06-25 03:22:19.612876
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    try:
        var_0 = Subversion(module, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
        var_8 = var_0.revert()
    except Exception as err:
        print("Test case 0 failed: ", err)
        assert False


# Generated at 2022-06-25 03:22:20.950209
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    if __name__ == '__main__':
        test_case_0()


# Generated at 2022-06-25 03:22:27.787532
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.switch()
    assert var_1 == True
    assert subversion_0.dest == None
    assert subversion_0.revision == None
    assert subversion_0.module == None
    assert subversion_0.repo == None


# Generated at 2022-06-25 03:23:16.594253
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_1 = None
    subversion_0 = Subversion(var_1, var_1, var_1, var_1, var_1, var_1, var_1, var_1)
    var_2, var_3, var_4 = subversion_0.needs_update()
    assert var_2 or (not var_2)


# Generated at 2022-06-25 03:23:23.828155
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:23:26.342678
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    rc_0 = None
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.has_option_password_from_stdin()


# Generated at 2022-06-25 03:23:30.525530
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = Subversion(var_12, var_13, var_14, var_5, var_6, var_7, var_8, var_9)
    var_15 = var_14.get_remote_revision()
    var_16 = var_15
    assert var_15 == var_16


# Generated at 2022-06-25 03:23:33.536954
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    try:
        var_0 = test_case_0()
    except NameError:
        var_0 = False

    assert(var_0)


# Generated at 2022-06-25 03:23:35.380391
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_2 = None
    subversion_1 = Subversion(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    var_3 = subversion_1.update()


# Generated at 2022-06-25 03:23:43.006479
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_1 = None
    var_2 = '/var/tmp/ansible-tmp-1298167970.03-0/source'
    var_3 = 'https://github.com/ansible/ansible-modules-core.git'
    var_4 = 'HEAD'
    var_5 = None
    var_6 = None
    var_7 = 'git'
    var_8 = True
    subversion_0 = Subversion(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
    subversion_0.revert()


# Generated at 2022-06-25 03:23:44.260540
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    subversion_0 = Subversion(None, None, None, None, None, None, None, None)
    subversion_0.switch()


# Generated at 2022-06-25 03:23:47.451479
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    try:
        test_main()
    except:
        print("Error: {0}".format(sys.exc_info()[0]))
        print("Cause: {0}".format(sys.exc_info()[1]))
        print("Line No: {0}".format(sys.exc_info()[2].tb_lineno))
    else:
        print("Test Successful")
        sys.exit(0)

# Generated at 2022-06-25 03:23:52.607936
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_17 = None
    subversion_17 = Subversion(var_17, var_17, var_17, var_17, var_17, var_17, var_17, var_17)
    var_18 = subversion_17.needs_update()


# Generated at 2022-06-25 03:25:18.275998
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = None
    var_1 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = var_1.revert()


# Generated at 2022-06-25 03:25:28.649137
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = testcase_0.svn_path
    var_1 = testcase_0.dest
    var_2 = testcase_0.repo
    var_3 = testcase_0.revision
    var_4 = testcase_0.username
    var_5 = testcase_0.password
    var_6 = testcase_0.svn_path
    var_7 = testcase_0.validate_certs
    subversion_0 = Subversion(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    subversion_0.module = mock.MagicMock()
    subversion_0.module.run_command = mock.MagicMock()
    subversion_0.module.run_command.return_value

# Generated at 2022-06-25 03:25:32.263231
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    subversion = Subversion(None, None, None, None, None, None, None, None)
    output = subversion.switch()
    # assert output == True


# Generated at 2022-06-25 03:25:37.082330
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    subversion_0.get_revision()


# Generated at 2022-06-25 03:25:45.172138
# Unit test for method update of class Subversion
def test_Subversion_update():
    dest = '/dest'
    repo = 'repo'
    revision = 'revision'
    username = 'username'
    password = 'password'
    svn_path = 'svn_path'
    validate_certs = 'validate_certs'
    subversion = Subversion(dest, repo, revision, username, password, svn_path, validate_certs)
    result = subversion.update()


# Generated at 2022-06-25 03:25:51.610065
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    text = '\n'.join(self._exec(["info", self.dest]))
    rev = re.search(self.REVISION_RE, text, re.MULTILINE)
    if rev:
        rev = rev.group(0)
    else:
        rev = 'Unable to get revision'

    url = re.search(r'^URL\s?:.*$', text, re.MULTILINE)
    if url:
        url = url.group(0)
    else:
        url = 'Unable to get URL'

    return rev, url



# Generated at 2022-06-25 03:25:58.744542
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_0 = None
    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = subversion_0.get_remote_revision()


# Generated at 2022-06-25 03:26:05.404014
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    var_0 = [1, 2, 3]
    var_1 = [1, 2, 3]

    # Each variable is set to the appropriate type above.

    subversion_0 = Subversion(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Invoke method
    var_2 = subversion_0.is_svn_repo()

    assert(var_2 == var_1)


# Generated at 2022-06-25 03:26:07.877904
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_2 = None
    var_2 = Subversion(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    var_2.get_remote_revision()


# Generated at 2022-06-25 03:26:13.346728
# Unit test for function main
def test_main():
    var_0 = 'SVN_SSH'
    var_1 = 'svn+ssh://example.org/path/to/repo'
    var_2 = None
    var_3 = 'HEAD'
    var_4 = None
    var_5 = True
    var_6 = None
    var_7 = None
    var_8 = None
    subversion_0 = Subversion(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    var_9 = subversion_0.update()
