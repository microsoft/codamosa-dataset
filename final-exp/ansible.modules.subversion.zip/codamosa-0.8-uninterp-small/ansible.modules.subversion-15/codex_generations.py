

# Generated at 2022-06-25 03:17:19.448555
# Unit test for method update of class Subversion
def test_Subversion_update():
    int_0 = -14
    str_0 = 'l+j#!x<4\tB1q]|1'
    set_0 = {int_0, str_0, int_0}
    float_0 = 1242.49
    dict_0 = None
    tuple_0 = (float_0, dict_0, float_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    assert not subversion_0.update()


# Generated at 2022-06-25 03:17:27.944370
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    int_0 = 3878
    str_0 = '-u`D9\t|2igH8a]|/q'
    set_0 = {int_0, str_0, int_0}
    float_0 = 1259.509511
    dict_0 = None
    tuple_0 = (float_0, dict_0, float_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_Subversion_switch()

# Generated at 2022-06-25 03:17:38.186741
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    int_0 = 3878
    str_0 = '-u`D9\t|2igH8a]|/q'
    set_0 = {int_0, str_0, int_0}
    float_0 = 1259.509511
    dict_0 = None
    tuple_0 = (float_0, dict_0, float_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    int_0 = subversion_0.revert()


# Generated at 2022-06-25 03:17:44.386498
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    int_0 = 5
    str_0 = '{"i]1\x7fB\\6\x7f'
    set_0 = {int_0, str_0, int_0}
    tuple_0 = (int_0, int_0, int_0, str_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    str_1, str_2 = subversion_0.get_revision()
    return (str_1, str_2)


# Generated at 2022-06-25 03:17:47.648462
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-25 03:17:57.766382
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    int_0 = 10
    str_0 = 'j~5?f|EZJ!\x0b}H\x7fW)R8M}'
    set_0 = {int_0, float_0, float_0}
    float_0 = 5057.8195822
    dict_0 = None
    tuple_0 = (float_0, set_0, set_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    bool_0 = subversion_0.has_option_password_from_stdin()
    print(bool_0)


# Generated at 2022-06-25 03:18:07.190134
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    int_0 = 5293
    str_0 = 'eKVy}'
    set_0 = {str_0, int_0, str_0}
    float_0 = 5372.1361551
    dict_0 = None
    tuple_0 = (int_0, int_0, int_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    subversion_0.get_revision = lambda: (str_0, str_0)
    subversion_0.get_remote_revision = lambda: int_0
    output = subversion_0.needs_update()
    assert output[0]
    assert output[1] == str_0
    assert output[2]

# Generated at 2022-06-25 03:18:13.301767
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    int_0 = 3960
    str_0 = 'S5S^@Y)*5"W8`2z'
    set_0 = {str_0, int_0, int_0}
    float_0 = 1082.8120727727
    dict_0 = None
    tuple_0 = (int_0, dict_0, float_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, float_0, tuple_0, float_0, float_0)
    subversion_0.revision = set_0
    curr_0 = str_0
    head_0 = 1317
    assert (curr_0 == subversion_0.get_revision())
    assert (head_0 == subversion_0.get_revision())


# Generated at 2022-06-25 03:18:22.408504
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    int_0 = 3878
    str_0 = '-u`D9\t|2igH8a]|/q'
    set_0 = {int_0, str_0, int_0}
    float_0 = 1259.509511
    dict_0 = None
    tuple_0 = (float_0, dict_0, float_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    with pytest.raises(NotImplementedError):
        subversion_0.has_local_mods()



# Generated at 2022-06-25 03:18:30.833397
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    int_0 = 3881
    str_0 = '-u`D9\t|2igH8a]|/q'
    set_0 = {int_0, str_0, int_0}
    float_0 = 1259.509511
    dict_0 = None
    tuple_0 = (float_0, dict_0, float_0)
    subversion_0 = Subversion(int_0, str_0, int_0, set_0, int_0, tuple_0, int_0, str_0)
    str_1 = ''
    str_2 = '~'
    str_3 = 'B<'
    str_4 = 'B<'
    str_5 = ''
    str_6 = '~'
    int_1 = 1193
    float_1 = 24.

# Generated at 2022-06-25 03:18:58.594804
# Unit test for function main
def test_main():
    input_0 = module.params['dest']
    input_1 = module.params['repo']
    input_2 = module.params['revision']
    input_3 = module.params['force']
    input_4 = module.params['username']
    input_5 = module.params['password']
    input_6 = module.params['executable'] or module.get_bin_path('svn', True)
    input_7 = module.params['export']
    input_8 = module.params['switch']
    input_9 = module.params['checkout']
    input_10 = module.params['update']
    input_11 = module.params['in_place']
    input_12 = module.params['validate_certs']
    input_13 = os.path.exists(dest)
    input_14

# Generated at 2022-06-25 03:19:02.092960
# Unit test for method revert of class Subversion

# Generated at 2022-06-25 03:19:09.970369
# Unit test for method revert of class Subversion

# Generated at 2022-06-25 03:19:13.708128
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    var_1 = Subversion()
    var_2 = var_1.switch()



# Generated at 2022-06-25 03:19:19.239956
# Unit test for function main
def test_main():
    test_case_0()

# This is an automatic test to detect regressions, feel free to create more
if __name__ == '__main__':
    from test_cases.Testcases import TestCase
    suite = TestCase.suite()
    result = TestCase.run(suite)

# Generated at 2022-06-25 03:19:20.789869
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        raise

# Generated at 2022-06-25 03:19:22.675722
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_1 = Subversion()
    var_2 = var_1.needs_update()


# Generated at 2022-06-25 03:19:34.167726
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():

    import random
    import tempfile

    # Generate random repo_url
    repo_url = ""
    repo_url_length = random.randint(10, 20)
    for i in range(0, repo_url_length):
        repo_url += chr(random.randint(ord('a'), ord('z')))

    # Generate random repo_rev
    repo_rev = str(random.randint(1, 1000000))

    # Generate random repo_dest
    repo_dest = ""
    repo_dest_length = random.randint(10, 20)
    for i in range(0, repo_dest_length):
        repo_dest += chr(random.randint(ord('a'), ord('z')))    

    # Generate a mock module
    module = AnsibleModule({})

# Generated at 2022-06-25 03:19:37.011161
# Unit test for function main
def test_main():
    test_case_0()


# Run tests
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:19:39.996396
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    svn = Subversion(None, '', '', '', '', '', '', '')
    assert svn.is_svn_repo() == False


# Generated at 2022-06-25 03:19:56.033906
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    var_0 = Subversion(get_revision)
    var_0.get_revision()


# Generated at 2022-06-25 03:20:01.246547
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    module = AnsibleModule({})
    dest = "dest"
    repo = "repo"
    revision = "revision"
    username = "username"
    password = "password"
    svn_path = "svn_path"
    validate_certs = "validate_certs"
    obj = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    obj.revert()


# Generated at 2022-06-25 03:20:02.953474
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_0 = Subversion()
    var_1 = var_0.has_option_password_from_stdin()
    return var_1


# Generated at 2022-06-25 03:20:06.608406
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_0 = Subversion(module=module, dest='/src/export', repo='svn+ssh://an.example.org/path/to/repo', revision='HEAD', username=None, password=None, svn_path=None, validate_certs=False);
    var_1 = var_0.get_remote_revision()
    assert var_1 == 'Unable to get remote revision'


# Generated at 2022-06-25 03:20:13.867884
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    obj = Subversion(repo = 'repo', revision = 'revision', username = 'username', password = 'password', svn_path = 'svn_path', validate_certs = 'validate_certs')
    obj.switch()


# Generated at 2022-06-25 03:20:20.124407
# Unit test for function main
def test_main():
    dest = "/home/local/ANT/vpathak/Desktop/ansible"
    repo = "https://github.com/ansible/ansible.git"
    revision = "HEAD"
    force = False
    username = ""
    password = ""
    svn_path = ""
    export = False
    switch = True
    checkout = True
    update = True
    in_place = False
    validate_certs = False
    main()

# Generated at 2022-06-25 03:20:26.140362
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Imports
    from ansible.modules.source_control.subversion import Subversion
    import ansible.module_utils.basic
    import sys

    # Arrange
    # Create class object for class Subversion
    # and set instance variable "module" to AnsibleModule object
    my_Subversion_obj = Subversion(
        ansible.module_utils.basic.AnsibleModule(
            argument_spec = dict(
                repo = dict(type='str', required=True)
            )
        ), "", "", "", "", "", "", False
    )

    # Act
    # Call method get_remote_revision of class Subversion
    result = my_Subversion_obj.get_remote_revision()

    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-25 03:20:35.156359
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit:
        pass
    except Exception:
        import traceback
        traceback.print_exc()
        assert False

# Generated at Thu May 10 21:38:24 2018 by {py_version} {git_commit_id}
# By {user}
# Using {svn_command_name} {svn_command_version}
#
# On host '{hostname}'
# Linux {kernel_name} {kernel_release} {kernel_version} {machine}

# pylint: disable=too-many-lines

# Generated at 2022-06-25 03:20:41.856498
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    # get revisioned files have been added or modified
    # Unrevisioned files are ignored.
    # The --quiet option will return only modified files.
    # Match only revisioned files, i.e. ignore status '?'.
    # Has local mods if more than 0 modified revisioned files.
    var_0 = Subversion(None, "", "", "", "", "", "", "")
    var_1 = var_0.has_local_mods()
    assert var_1 == False


# Generated at 2022-06-25 03:20:47.326684
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    Subversion_obj = Subversion("","","","","","","")


# Generated at 2022-06-25 03:21:36.864744
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Initial setup
    var_0 = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    var_0.is_svn_repo = mock.MagicMock()
    var_0.is_svn_repo.return_value = False
    var_0.has_local_mods = mock.MagicMock()
    var_0.has_local_mods.return_value = False
    var_0.checkout = mock.MagicMock()
    var_1 = None
    var_0.checkout.return_value = var_1
    var_0.update = mock.MagicMock()
    var_2 = None
    var_0.update.return_value = var_2
    var_0.export = mock.MagicMock()
   

# Generated at 2022-06-25 03:21:41.000787
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    dest = '<PATH_TO_DEST_FOLDER>'
    repo = '<PATH_TO_REPO>'
    revision = '<REVISION>'
    username = '<USERNAME>'
    password = '<PASSWORD>'
    svn_path = '<PATH_TO_SVN_EXECUTABLE>'
    validate_certs = True
    svn = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    print(svn.needs_update())


# Generated at 2022-06-25 03:21:52.128072
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    os.mkdir('Test_0')
    os.mkdir('Test_1')
    os.mkdir('Test_2')
    f = open('Test_0/X_0.txt', 'w')
    f.close()
    f = open('Test_0/X_1.txt', 'w')
    f.close()
    f = open('Test_1/X_0.txt', 'w')
    f.close()
    f = open('Test_1/X_1.txt', 'w')
    f.close()
    f = open('Test_2/X_0.txt', 'w')
    f.close()
    f = open('Test_2/X_1.txt', 'w')
    f.close()

# Generated at 2022-06-25 03:21:59.480750
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_0 = Subversion(__file__, '/tmp/subversion', 'ansible', 'HEAD', None, None, 'subversion', None)
    var_0._exec = lambda x: True
    var_0.is_svn_repo = lambda: True
    var_0.has_local_mods = lambda: True
    var_1 = var_0.update()
    assert var_1 == True


# Generated at 2022-06-25 03:22:01.727096
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_0 = Subversion(0, 0, 0, 0, 0, 0, 0)
    o = var_0.update()
    return o


# Generated at 2022-06-25 03:22:04.202278
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_1 = Subversion()
    var_2 = var_1.revert()
    return var_2


# Generated at 2022-06-25 03:22:14.930897
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    var_dest = 'totally_real_directory123'
    var_repo = 'totally_real_repo'
    var_revision = '123'
    var_username = None
    var_password = None
    var_svn_path = 'totally_real_path'
    var_validate_certs = False
    var_force = False
    var_in_place = False
    var_checkout = True
    var_update = True
    var_export = False
    var_switch = True
    var_options = 'totally_real_options'
    var_state = 'latest'
    var_executable = None
    var_update_head_on_merge = False
    var_checkout_excl_new_dirs = False

# Generated at 2022-06-25 03:22:22.420513
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    var_Subversion = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    var_remote_revision = var_Subversion.get_remote_revision()
    if (var_remote_revision is not None):
        pass


# Generated at 2022-06-25 03:22:27.825987
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    module = AnsibleModule({})
    dest = '/dest'
    repo = 'repo'
    revision = '16'
    username = None
    password = None
    svn_path = 'svn'
    validate_certs = True
    object  = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    object.switch()


# Generated at 2022-06-25 03:22:32.013100
# Unit test for function main

# Generated at 2022-06-25 03:24:21.246325
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    var_0 = Subversion()
    var_1 = var_0.revert()


# Generated at 2022-06-25 03:24:25.657530
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    repo = "repo"
    dest = "dest"
    revision = "revision"
    username = "username"
    password = "password"
    svn_path = "svn_path"
    validate_certs = "validate_certs"
    main_0 = main()
    main_0.switch()


# Generated at 2022-06-25 03:24:33.488917
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # Params
    svn_path = '/usr/local/bin/svn'
    dest = '/home/ansible/source_code/ansible'
    repo = 'https://github.com/ansible/ansible.git'
    revision = 'HEAD'
    username = None
    password = None
    validate_certs = False

    # Set up object
    obj = Subversion(svn_path, dest, repo, revision, username, password, validate_certs)

    # Execute
    ret_val = obj.get_revision()

    # Verify
    assert ret_val[0] == 'Revision: 1048'
    assert ret_val[1] == 'URL: https://github.com/ansible/ansible.git'


# Generated at 2022-06-25 03:24:40.717712
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class_0 = Subversion(module='AnsibleModule',
                        dest='/src/checkout',
                        repo='ssh://an.example.org/path/to/repo',
                        revision='HEAD',
                        username='',
                        password='',
                        svn_path='/usr/bin/svn',
                        validate_certs=False)
    return_value_0 = class_0.needs_update()


# Generated at 2022-06-25 03:24:41.821187
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    var_0 = Subversion()
    var_1 = var_0.has_local_mods()
    assert var_1 == True


# Generated at 2022-06-25 03:24:43.289458
# Unit test for method update of class Subversion
def test_Subversion_update():
    var_1 = main()


# Generated at 2022-06-25 03:24:47.562128
# Unit test for function main
def test_main():
    # Unit test for function main
    var_0 = main()
    assert var_0 == 1


# Generated at 2022-06-25 03:24:48.691833
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    # Call Subversion.is_svn_repo()
    var_1 = Subversion.is_svn_repo()


# Generated at 2022-06-25 03:25:00.623603
# Unit test for method switch of class Subversion
def test_Subversion_switch():

    # Set up mock subversion module for testing
    os.environ['ANSIBLE_SUBVERSION_SVN_PATH'] = 'svn'
    os.environ['ANSIBLE_SUBVERSION_CWD'] = os.getcwd()
    os.environ['ANSIBLE_SUBVERSION_CHECKOUT'] = 'False'
    os.environ['ANSIBLE_SUBVERSION_REVISION'] = 'HEAD'
    os.environ['ANSIBLE_SUBVERSION_VALIDATE_CERTS'] = 'True'
    os.environ['ANSIBLE_SUBVERSION_EXPORT'] = 'False'
    os.environ['ANSIBLE_SUBVERSION_IN_PLACE'] = 'False'
    os.environ['ANSIBLE_SUBVERSION_FORCE'] = 'True'
    os.environ

# Generated at 2022-06-25 03:25:01.372502
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    var_16 = main()


# Generated at 2022-06-25 03:26:52.042277
# Unit test for function main
def test_main():
    rc, out, err = main()

if __name__ == '__main__':
    # test_main()
    main()