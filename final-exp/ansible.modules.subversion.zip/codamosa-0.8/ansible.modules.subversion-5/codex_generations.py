

# Generated at 2022-06-11 07:57:31.245014
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    from ansible.module_utils.common.collections import ImmutableDict
    import subprocess
    # Test with a directory that contains a SVN repo
    class Module:
        def __init__(self, module_args, check_rc=False, data=None):
            self.params = module_args
            self.check_rc = check_rc

        def fail_json(self, *args, **kwargs):
            pass

        def warn(self, msg):
            pass

        def run_command(self, cmd):
            assert len(cmd) == 7
            assert cmd[0] == '/path/to/svn'
            assert cmd[1] == '--non-interactive'
            assert cmd[2] == '--no-auth-cache'
            assert cmd[3] == '--trust-server-cert'


# Generated at 2022-06-11 07:57:33.635321
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    Subversion("module", "path", "url", "revision", "username", "password", "path", True).has_local_mods()


# Generated at 2022-06-11 07:57:41.410945
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    repo_path = os.path.join(os.path.dirname(
        os.path.abspath(__file__)), 'test/test_svn_repo')
    revision = "1889134"
    username = ""
    password = ""
    svn_path = "svn"
    validate_certs = True
    subversion = Subversion(object, repo_path, repo_path, revision,
                            username, password, svn_path, validate_certs)
    assert subversion.needs_update() == (True, 'Revision : 1889135', 'Revision : 1889136')



# Generated at 2022-06-11 07:57:50.422342
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    mod = AnsibleModule(argument_spec=dict(
        dest=dict(required=True, type='str'),
        repo=dict(required=True, type='str'),
        revision=dict(required=True, type='str'),
        username=dict(required=True, type='str'),
        password=dict(required=True, type='str'),
        svn_path=dict(required=True, type='str'),
        validate_certs=dict(required=True, type='bool')
    ))

    svn_class = Subversion(mod, dest='path/to/dest', repo='https://test', revision='1', username='test-user', password='test-password', svn_path='/test/svn', validate_certs=True)


# Generated at 2022-06-11 07:57:51.533313
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    assert True

# Generated at 2022-06-11 07:58:00.642865
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
        class ModuleMock(object):

                def run_command(self, args, check_rc=True, **kwargs):
                        if args[0] == 'git':
                                output = '4'
                        else:
                                output = None

                        return True, output, None

        module_mock = ModuleMock()

        subversion = Subversion(module_mock, '/home/user/project', 'https://git.example.org/project.git', 'master', None, None, None, True, False)

        assert subversion.get_remote_revision() == "4"



# Generated at 2022-06-11 07:58:09.901718
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    import unittest
    import mock
    import ansible
    from ansible.module_utils import basic
    # Construct Subversion object
    tmp_module = basic.AnsibleModule(
        argument_spec=dict(
            repo=dict(type='str', required=True),
            dest=dict(type='path'),
            revision=dict(type='str', default='HEAD', aliases=['rev', 'version']),
            username=dict(type='str'),
            password=dict(type='str'),
            executable=dict(type='path'),
            validate_certs=dict(type='bool', default='no'),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-11 07:58:21.201113
# Unit test for method update of class Subversion
def test_Subversion_update():

    # Setup the mocks
    class mock_module:
        params = {'repo': 'http://svn/repo', 'dest':'C:/dest', 'revision': '1', 'username': 'user', 'password': 'pass', 'svn_path': 'svn', 'validate_certs': False}
        def __init__(self, *args, **kwargs):
            return
        def run_command(self, *args, **kwargs):
            return [0, 'Updated to revision 1234.', '']

    class mock_check_output:
        def __init__(self, *args, **kwargs):
            return
        def __call__(self, *args, **kwargs):
            return '123'

    module = mock_module()
    Subversion.check_output = mock_check_

# Generated at 2022-06-11 07:58:30.852735
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    # Test case 1
    subversion_object_1 = Subversion(None, None, None, '34', None, None, None, None)
    subversion_object_1.get_revision = lambda: (u'Révision : 34', 'URL : svn+ssh://an.example.org/path/to/repo')
    subversion_object_1.get_remote_revision = lambda: u'Révision : 34'
    assert subversion_object_1.needs_update() == (False, u'Révision\xa0: 34', u'Révision\xa0: 34')

    # Test case 2
    subversion_object_2 = Subversion(None, None, None, '34', None, None, None, None)

# Generated at 2022-06-11 07:58:42.181090
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    import tempfile
    from unittest import TestCase

    from ansible.module_utils.six import PY2

    class TestSubversion(TestCase):
        def test_get_revision(self):
            test_path = tempfile.mkdtemp()

# Generated at 2022-06-11 07:59:06.738909
# Unit test for method update of class Subversion
def test_Subversion_update():
    from ansible.module_utils.common._collections_compat import Mapping
    import pytest
    from ansible.module_utils.common.locale import get_best_encoding
    from ansible.module_utils import basic
    import os
    import tempfile
    import sys

    tmpdir = tempfile.mkdtemp()
    svn_path = os.getenv('ANSIBLE_SVN_EXECUTABLE', None) or basic.ANSIBLE_SVN_EXECUTABLE
    subversion_executable = pytest.helpers.make_dummy_script(tmpdir, 'svn', """
echo I am svn cmd
echo 'A    foo.txt'
exit 0""")

# Generated at 2022-06-11 07:59:08.296510
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    assert Subversion.revert(self) == True

# Generated at 2022-06-11 07:59:14.138958
# Unit test for method update of class Subversion
def test_Subversion_update():
    class Subversion(object):
        def _exec(self, args, check_rc=True):
            if len(args) == 3 and args[0] == "update" and args[1] == "-r" and args[2] == "revision":
                return ['A       path/to/file/a']
            else:
                raise RuntimeError("Unexpected args: " + str(args))
    subversion = Subversion()
    assert subversion.update("revision", "/path")



# Generated at 2022-06-11 07:59:25.042297
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    import unittest
    class SubversionTestCase(unittest.TestCase):
        def setUp(self):
            class FakeModule:
                def __init__(self):
                    self.run_command_counter = 0

                def run_command(self, args, check_rc=True, data=None):
                    self.run_command_counter += 1
                    if check_rc:
                        return 0, "", ""
                    else:
                        return 1, "", ""
            self.module = FakeModule()
        def test_get_remote_revision(self):
            repo = Subversion(self.module, dest='', repo='', revision='', username='', password='', svn_path='', validate_certs=True)
            revision = repo.get_remote_revision()

# Generated at 2022-06-11 07:59:36.073046
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    import os

    module = AnsibleModule(argument_spec={})
    repo = Subversion(module, '/tmp/ansible_test_repo', 'http://localhost/test/ansible_test_repo', 'HEAD', '', '', '/bin/svn', False)

    # False if the repo does not exist
    assert os.path.exists('/tmp/ansible_test_repo') is False
    out = repo.is_svn_repo()
    assert out is False

    # Create a test repo

# Generated at 2022-06-11 07:59:47.555144
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    """Test has_local_mods method.
    Test cases:
    """
    def test_Subversion_has_local_mods_t1():
        # Test case for checking output of has_local_mods method when
        # no files are in revisioned
        module = AnsibleModule(argument_spec=dict())
        subversion = Subversion(module,None,None,None,None,None,None,None)
        class MockRepo(object):
            def __init__(self):
                self.modified = {'M': 1, 'X': 2}

        repo = MockRepo()
        self.assertEqual(subversion.has_local_mods(repo), False)
        del subversion
        del module
        del repo


# Generated at 2022-06-11 07:59:55.544461
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    m = AnsibleModule(
        argument_spec=dict(
            repo=dict(default='', type='str'),
            svn_path=dict(default='', type='str'),
        )
    )
    subversion = Subversion(m, '', 'svn://localhost:3691/test', 'HEAD', None, None, 'svn', False)
    rev = subversion.get_remote_revision()
    assert rev == 'Révision : 2'
    rev = subversion.get_revision()
    assert rev[0] == 'Révision : 2'
    assert rev[1] == 'URL : svn://localhost:3691/test'



# Generated at 2022-06-11 07:59:57.956528
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    pass
    # assertEqual(Subversion.needs_update(r1,r2),(True,r1,r2))


# Generated at 2022-06-11 08:00:05.181375
# Unit test for function main
def test_main():
  repo = "git@github.com:ansible/ansible.git"
  revision = "HEAD"
  svn_path = "svn"
  svn = Subversion(None, repo, revision, None, None, None, svn_path)
  print(svn.get_remote_revision())

if __name__ == '__main__':
  test_main()

# Generated at 2022-06-11 08:00:12.793891
# Unit test for method get_revision of class Subversion

# Generated at 2022-06-11 08:00:49.810770
# Unit test for method update of class Subversion
def test_Subversion_update():
    import ansible.module_utils.subversion
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def _sysexit(self, *args, **kwargs):
            raise SystemExit

        def fail_json(self, *args, **kwargs):
            raise self._sysexit

        def run_command(self, args, check_rc):
            return 0, 'x\ny\nz\n', ''

    subversion = ansible.module_utils.subversion.Subversion(MockModule(), None, None, None, None, None, '/bin/svn', False)
    assert subversion.update()


# Generated at 2022-06-11 08:01:01.100861
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    import mock
    # Patch module_utils.basic.run_command
    module = mock.MagicMock()
    svn_inst = Subversion(module, 'dummy_dest', 'dummy_repo', 'dummy_revision', 'dummy_username', 'dummy_password', 'dummy_svn_path', 'dummy_validate_certs')
    svn_inst.module.run_command = mock.MagicMock()
    # Mock of current revision of the local repo

# Generated at 2022-06-11 08:01:05.798313
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    module = AnsibleModule(argument_spec={})
    svn = Subversion(module, 'dest', 'repo', 'revision', 'username', 'password', 'svn_path', False)
    assert svn.get_revision() == ('Unable to get revision', 'Unable to get URL')


# Generated at 2022-06-11 08:01:14.367034
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class MockModule(object):
        def run_command(self, bits, check_rc=True, data=None):
            # Returns two respective revisions which is
            # then used to judge whether or not an update is needed
            output_info = [
                "Révision        : 21",
                "Révision        : 22",
                "URL             : http://my/url",
            ]
            output_info_r = [
                "Révision        : 21",
                "Révision        : 22",
                "URL             : http://my/url",
            ]
            if bits == ["/usr/bin/svn", "info", "/tmp/git-repos"]:
                return 0, '\n'.join(output_info), None

# Generated at 2022-06-11 08:01:16.867591
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    assert Subversion(None, None, None, None, None, None, None, None)


# Generated at 2022-06-11 08:01:27.528266
# Unit test for function main
def test_main():
    import inspect
    import sys
    import re
    import shutil
    import os

    module_real = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if module_real.params['executable'] is not None:
        svn_path = module_real.params['executable']
    else:
        svn_path = module_real.get_bin_path('svn', True)
    dest = os.path.dirname(os.path.abspath(__file__)) + '/' + 'test_subversion'
    repo = 'https://github.com/frost-nzcr4/ansible-subversion.git'
    revision = 'HEAD'
    username = None
    password = None


# Generated at 2022-06-11 08:01:38.433590
# Unit test for method revert of class Subversion
def test_Subversion_revert():

    class FakeModule(object):
        def __init__(self, dest, repo, revision, username, password, svn_path, validate_certs):
            self.params = dict(
                dest=dest,
                repo=repo,
                revision=revision,
                username=username,
                password=password,
                svn_path=svn_path,
                validate_certs=validate_certs
            )

        def run_command(self, cmd, check_rc=True, data=None):
            return 0, '', ''

    class FakeInstance(object):
        def __init__(self, module=None):
            self.module = module
            self.has_option_password_from_stdin = lambda: True

        def _exec(self, args, check_rc=True):
            return 0,

# Generated at 2022-06-11 08:01:46.679190
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = lambda **kwargs: kwargs
    module.run_command = lambda args, check_rc=True: (0, '', '')

    repo = 'svn+ssh://an.example.org/path/to/repo'
    rev = '55555'

    svn = Subversion(module, '/src/checkout', repo, rev, None, None, '/usr/bin/svn', True)
    assert svn.get_remote_revision() == 'Unable to get remote revision'

    with module.mock_command(['svn', '--non-interactive', '--no-auth-cache', 'info', repo], stdout=b'', returncode=1):
        assert svn.get

# Generated at 2022-06-11 08:01:57.577253
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    from ansible.module_utils.common.locale import get_best_parsable_locale
    get_best_parsable_locale.set_current_locale('en_US')

    class FakeModule():
        class FakeModuleRunCommand():
            def __init__(self, module):
                self.module = module

            def __call__(self, args, check_rc=True, data=None):
                return 0, '', ''

        run_command = FakeModuleRunCommand

        def __init__(self):
            self.call_args = None

    module = FakeModule()
    svn = Subversion(module, "/dest", "svn+ssh://foo/repo", "HEAD", "", "", "path/to/svn", False)
    assert svn.is_svn_repo()

# Generated at 2022-06-11 08:02:06.029218
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class SubversionTester(Subversion):
        def __init__(self):
            self.revision = '39'
            self.dest = 'test_revision'

        def _exec(self, args, check_rc=True):
            '''Execute a subversion command, and return output. If check_rc is False, returns the return code instead of the output.'''
            info = "Revision: 39\nURL: svn://svn.collab.net/repos/svn/trunk\n"
            return info

    assert SubversionTester().get_revision() == ('Revision: 39', 'URL: svn://svn.collab.net/repos/svn/trunk')


# Generated at 2022-06-11 08:03:12.153001
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    import tempfile
    # This test expects to run in a subversion sandbox with a local copy of the ansible subversion repository.
    module = AnsibleModule(argument_spec={})
    temp_dir = tempfile.mkdtemp()
    svn = Subversion(module, dest=temp_dir, repo='file:///Users/dan/subversion/ansible', revision='HEAD', username=None, password=None, svn_path='/usr/local/bin/svn')
    # Returns a string like "Revision: 1889134"
    remote_revision = svn.get_remote_revision()
    # Verify that the string is a revision
    import re
    assert re.match(r'^\w+:\s+\d+$', remote_revision)


# Generated at 2022-06-11 08:03:22.108165
# Unit test for method get_revision of class Subversion

# Generated at 2022-06-11 08:03:30.689733
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        class Parameters(object):
            def __init__(self):
                self.repo = "svn+ssh://an.example.org/path/to/repo"
                self.dest = "~/src/new_checkout"
                self.revision = "HEAD"
                self.username = "user"
                self.password = "pass"
                self.svn_path = "svn"
                self.executable = None

        def fail_json(self, *args, **kargs):
            print("FAILED")
            print(args)
            print(kargs)


# Generated at 2022-06-11 08:03:33.464402
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    test_svn = Subversion()
    assert test_svn.revert() == None

if __name__ == '__main__':
    test_Subversion_revert()


# Generated at 2022-06-11 08:03:43.918892
# Unit test for function main

# Generated at 2022-06-11 08:03:52.900623
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    repo = 'svn+ssh://an.example.org/path/to/repo'
    revision = 'HEAD'
    dest = '/src/checkout'
    username = None
    password = None
    svn_path = None
    validate_certs = False
    svn = Subversion(None, dest, repo, revision, username, password, svn_path, validate_certs)

    # Current SVN revision
    curr, url = svn.get_revision()
    rev1 = int(curr.split(':')[1].strip())
    # Latest SVN revision
    out2 = '\n'.join(svn._exec(["info", "-r", revision, dest]))
    head = re.search(svn.REVISION_RE, out2, re.MULTILINE)
   

# Generated at 2022-06-11 08:04:04.296468
# Unit test for function main
def test_main():
    import os
    import subprocess
    import sys
    import inspect
    
    path = os.path.dirname(os.path.abspath(inspect.stack()[0][1]))
    repo = ospath.join(path, '..', 'ansible-modules-core', 'system' , 'svn_repo')

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(path))))

    repo = repo.replace(' ', '\ ')
    

# Generated at 2022-06-11 08:04:09.175819
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    m = AnsibleModule(argument_spec={'executable': {'type': 'path'}})
    svn_path = m.params.get('executable') or 'svn'

    subv = Subversion(m, None, None, None, None, None, svn_path, None)
    r = subv.has_option_password_from_stdin()
    assert isinstance(r, bool)



# Generated at 2022-06-11 08:04:19.020088
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # mock the imput parameters and run the function
    # to test it
    # expected behaviour is a return value that matches
    #self.REVISION_RE = r'^\w+\s?:\s+\d+$'
    #
    # expected result is that a match is found
    class MockModule(object):
        def run_command(self2):
            return 0, r'URL http://svn.my.repo.net/app/trunk\nRevison: 12345', ''
    svn = Subversion(MockModule, '', '', '', '', '', '', '')
    # test
    ret = svn.get_remote_revision()
    #assert ret == 'Revision: 12345'

# Generated at 2022-06-11 08:04:28.989853
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    module = AnsibleModule(argument_spec={
        'name': {'type': 'str', 'default': ''},
        'revision': {'type': 'str', 'default': ''},
        'dest': {'type': 'str', 'default': ''},
        'validate_certs': {'required': False, 'default': 'no', 'type': 'bool'}
    })

    revision = '0'
    subv = Subversion(module, '.', 'svn+ssh://an.example.org/path/to/repo', revision, '', '', '')
    svn_need_update, curr, head = subv.needs_update()
    assert svn_need_update
    assert curr == 'Unable to get revision'
    assert head != curr



# Generated at 2022-06-11 08:07:04.491460
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    from ansible.module_utils.common.locale import get_best_parsable_locale
    from ansible.module_utils.compat.version import LooseVersion
    ansible.module_utils.basic.ANsIBLE_MODUlE = ansible.module_utils.basic.AnsibleModule
    ansible.module_utils.basic.LooseVersion = LooseVersion
    ansible.module_utils.common.locale.get_best_parsable_locale = get_best_parsable_locale
    ansible.module_utils.compat.version.LooseVersion = LooseVersion
    exit_json = {'before': None, 'after': None, 'changed': False}