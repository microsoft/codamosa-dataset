

# Generated at 2022-06-11 07:57:19.621868
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # FIXME: TODO
    pass


# Generated at 2022-06-11 07:57:24.601422
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    subversion = Subversion(None, None, None, None, None, None, None, None)
    print("Testing the get_remote_revision method of the Subversion class")
    print("get_remote_revision returns : %s" % subversion.get_remote_revision())

# Generated at 2022-06-11 07:57:26.156356
# Unit test for method update of class Subversion
def test_Subversion_update():
    print(Subversion.update('Subversion'))


# Generated at 2022-06-11 07:57:37.413168
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    module = AnsibleModule({})
    svn = Subversion(module, '/some/path', 'http://example.org/svn', None, None, None, 'svn', None)
    class FakeResult(object):
        def __init__(self):
            self.output = """
    Révision : 1889134
    URL : https://subversion.assembla.com/svn/test_project_doc/trunk
    No de révision racine : 1889133
    No de révision arrière : 1889133
    No de révision précédent : 1889134
    No de révision suivant : 1889133
    Date de dernière modification : (il y a 2 heures) (2018-03-27 16:35:45 +0100)
    """
    result = FakeResult()


# Generated at 2022-06-11 07:57:46.004033
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    #
    # Unit test for the function get_remote_revision
    #

    class MockModule(object):
        def __init__(self, repo, module_name, dest):
            self.run_command_called = False
            self.repo = repo
            self.module_name = module_name
            self.dest = dest

        def run_command(self, argv, check_rc=True, data=None):
            self.run_command_called = True

            if argv[0] != self.repo:
                return (1, '', '')

            cmdline = ' '.join(argv)

            if cmdline.find('svn info -r') == -1:
                return (1, '', '')

            return (0, 'Révision : 1889134', '')

    #


# Generated at 2022-06-11 07:57:47.671619
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    instance = Subversion()
    output = instance.switch()
    assert output == True


# Generated at 2022-06-11 07:57:58.882584
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        raise SkipTest("The Subversion module only runs on Python 2.")

    stdout = StringIO()
    module = AnsibleModule(
        argument_spec=dict(
            repo=dict(type='str', required=True),
            revision=dict(type='str', default='HEAD', required=False),
            username=dict(type='str', required=False),
            password=dict(type='str', no_log=True, required=False),
            dest=dict(type='str', required=False),
            executable=dict(type='str', required=False),
        ),
    )

    module.stdout = stdout

# Generated at 2022-06-11 07:58:08.064030
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    import sys
    import subprocess
    module = sys.modules['ansible.modules.source_control.subversion']
    subversion = module.Subversion(module, '/source/foo', 'http://example.com/bar', 'HEAD', None, None, 'svn', 'yes')
    subprocess.check_output = lambda args: '\n'.join(['A       foo', '?       bar', 'M       baz']).encode('utf-8')
    assert subversion.has_local_mods()

    subprocess.check_output = lambda args: '\n'.join(['A       foo', '?       bar']).encode('utf-8')
    assert not subversion.has_local_mods()

# Generated at 2022-06-11 07:58:19.539635
# Unit test for method update of class Subversion
def test_Subversion_update():
    from ansible.utils.path import unfrackpath

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def run_command(self, args, check_rc=True, data=None):
            self.command_args = args
            self.command_kwargs = {'check_rc': check_rc}
            return '', '', ''

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_kwargs = {}
            raise Exception('EXIT')


# Generated at 2022-06-11 07:58:27.531166
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    module = AnsibleModule('subversion', '',
                           {'repo': 'svn+ssh://an.example.org/path/to/repo',
                            'dest': '/tmp/result',
                            'checkout': 'no',
                            'switch': 'no',
                            'update': 'no',
                            'force': 'yes',
                            'revision': 'HEAD'})
    svn = Subversion(module, '/tmp/result', 'svn+ssh://an.example.org/path/to/repo', 'HEAD', '', '', '', '')
    assert svn.switch() is False


# Generated at 2022-06-11 07:58:43.926745
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    assert True

if __name__ == '__main__':
    test_Subversion_get_remote_revision()

# Generated at 2022-06-11 07:58:54.906653
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    from ansible.module_utils.common.removed import removed
    removed('2020-02-01')

    import sys
    import random

    # Uncoment for individual tests:
    # random.seed(0)

    svn_path = 'svn'
    dest = '/tmp'
    repo = 'svn+ssh://an.example.org/path/to/repo'
    revision = 'HEAD'
    username = ''
    password = ''
    validate_certs = True

    svn = Subversion(object, dest, repo, revision, username, password, svn_path, validate_certs)
    r, u = svn.get_revision()

    assert r == 'Revision: 1889134'
    assert u == 'URL: svn+ssh://svn.example.org/repos/example'

# Generated at 2022-06-11 07:59:05.761898
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    class test_module:
        def __init__(self, repo, dest, revision, checkout, update, svn_path, force, in_place, username, password, validate_certs):
            self.repo = repo
            self.dest = dest
            self.revision = revision
            self.checkout = checkout
            self.update = update
            self.svn_path = svn_path
            self.force = force
            self.in_place = in_place
            self.username = username
            self.password = password
            self.validate_certs = validate_certs
        def warn(self, *args):
            print("WARN: "+' '.join(args))
        def run_command(self, args, check_rc, data=None):
            cmd = ' '.join(args)

# Generated at 2022-06-11 07:59:14.933622
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    module_args={
        'repo' : 'https://svn.apache.org/repos/asf/subversion/trunk',
        'dest' : '.',
        'revision' : 'HEAD',
        'executable' : 'svn',
        'checkout' : 'no',
        'update' : 'no',
    }

# Generated at 2022-06-11 07:59:25.697284
# Unit test for function main

# Generated at 2022-06-11 07:59:27.277656
# Unit test for function main
def test_main():
    # Just a wrapper for ansible module
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:59:38.085202
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    svn = Subversion(None,"/tmp/blaat","file:///tmp/test/sometestrepo","HEAD","","","",False)
    with open("/tmp/test/sometestrepo/test.dat","w") as f:
        f.write("test1")
    svn.checkout()
    change, curr, head = svn.needs_update()
    assert change == False
    with open("/tmp/test/sometestrepo/test.dat","w") as f:
        f.write("test2")
    change, curr, head = svn.needs_update()
    assert change == True
    path = svn.dest
    assert os.path.exists(path)
    assert os.path.isdir(path)


# Generated at 2022-06-11 07:59:49.507551
# Unit test for function main

# Generated at 2022-06-11 08:00:01.376628
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    test_module = AnsibleModule(argument_spec={ 'repo': dict(required=True),
                                                'dest': dict(required=True),
                                                'revision': dict(default=None),
                                                'username': dict(default=None),
                                                'password': dict(default=None),
                                                'svn_path': dict(default=None),
                                                'validate_certs': dict(default=None) })

    # create test directory and modify a file
    test_module.run_command(['mkdir', 'test_svn'])
    test_module.run_command(['touch', 'test_svn/test_file'])
    test_module.run_command(['svn', 'add', 'test_svn'])

# Generated at 2022-06-11 08:00:06.068636
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    args = dict(
        repo='svn+ssh://an.example.org/path/to/repo',
        dest='/src/checkout',
        revision='HEAD',
        svn_path='/usr/bin/svn',
        validate_certs=True,
    )

# Generated at 2022-06-11 08:00:45.120438
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class FakeModule(object):
        def __init__(self):
            self._exec_result = ['Revision: 12345', 'Revision: 54321', 'Revision: 54321']
        def run_command(self, args, check_rc=True, data=None):
            if args[0] == 'svn':
                if args[1] == 'info':
                    if len(args) == 2 or args[2] == self.dest:
                        retval = self._exec_result[0]
                    else:
                        retval = self._exec_result[2]
                elif (args[1] == '--version' and args[2] == '--quiet'):
                    retval = '1.10.0'
            return 0, retval, None

# Generated at 2022-06-11 08:00:56.414342
# Unit test for method revert of class Subversion

# Generated at 2022-06-11 08:01:07.550617
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_outputs = [
                (0, "Reverted /repo-path/file1.txt", None),
                (0, "Reverted /repo-path/file2.txt", None),
                (0, "Reverted /repo-path/file3.txt", None),
            ]
            self.run_command_calls = []
        def run_command(self, command, check_rc, data):
            rc, out, err = self.run_command_outputs.pop(0)
            self.run_command_calls.append(
                {
                    'command': command,
                    'check_rc': check_rc,
                    'data': data,
                }
            )
            return rc

# Generated at 2022-06-11 08:01:13.426691
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    # Setup
    module = AnsibleModule(argument_spec={})
    dest = 'dest'
    repo = 'repo'
    revision = 'revision'
    username = 'username'
    password = 'password'
    svn_path = 'svn'
    validate_certs = 'validate_certs'
    object = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    # Test with no args
    assert isinstance(object.switch(), bool)

# Generated at 2022-06-11 08:01:22.960518
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    mock_module = AnsibleModule({}, check_mode=False)
    dest = "/home/test/"
    repo = "http://test.com/path/to/repo/"
    revision = "HEAD"
    username = None
    password = None
    svn_path = "svn"
    validate_certs = False
    mock_Subversion = Subversion(mock_module, dest, repo, revision, username, password, svn_path, validate_certs)
    mock_Subversion._exec = MagicMock(return_value=[r'Reverted ', r'Reverted '])
    assert mock_Subversion.revert() == False

# Generated at 2022-06-11 08:01:34.019448
# Unit test for method update of class Subversion
def test_Subversion_update():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import subprocess
    import re
    class DummyModule(object):
        def __init__(self):
            self.params = {'repo': 'svn+ssh://an.example.org/path/to/repo', 'revision': 'HEAD', 'dest': '/src/checkout'}
        def run_command(self, cmd, check_rc=True, data=None):
            if data:
                cmd = cmd + [to_bytes(data)]
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            rc = p.wait()
            so, se = p.communicate()

# Generated at 2022-06-11 08:01:43.198111
# Unit test for function main

# Generated at 2022-06-11 08:01:44.458032
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    assert len(Subversion.needs_update.__doc__) > 0


# Generated at 2022-06-11 08:01:54.703831
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class Module(object):
        def run_command(self, params, check_rc=True, data=None):
            print(params)

# Generated at 2022-06-11 08:02:04.864755
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # Use a mock module to test this function
    class FakeModule(object):
        result = dict(changed=False)
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True, data=None):
            self.run_command_calls.append(args)
            # Return a tuple of the status, output, and error.
            # Defaults are the same as the real run_command.
            rc = 0
            out = None
            err = None

            index = len(self.run_command_calls) - 1
            if index < len(self.run_command_results):
                rc, out, err = self.run_command_results[index]

# Generated at 2022-06-11 08:03:18.365655
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    class MockArgs(object):
        def __init__(self):
            self.checkout=False
            self.force=True
            self.debug=False
    mock_Subversion_obj = Subversion(MockArgs())
    mock_Subversion_obj.revert()

# Generated at 2022-06-11 08:03:23.903853
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    module = MockModule()
    repo = Subversion(module, dest="", repo="", revision="", username="", password="", svn_path="", validate_certs=False)
    version = "1.10.0"
    assert repo.has_option_password_from_stdin()
    version = "1.9.9"
    assert not repo.has_option_password_from_stdin()
    

# Generated at 2022-06-11 08:03:32.006205
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 08:03:36.073952
# Unit test for function main
def test_main():
    with patch('__builtin__.open', mock_open(read_data='data')):
        with patch.object(os, 'path', new=MagicMock()) as mock_path:
            mock_path.exists.return_value = True
            main()

# Generated at 2022-06-11 08:03:46.510616
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    class Module(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_list = []

        def run_command(self, cmd, data=None):
            self.run_command_count += 1
            self.run_command_list.append(cmd)
            if cmd == ['/usr/bin/svn', '--non-interactive', '--no-auth-cache', '--trust-server-cert', 'revert', '-R', '/src/checkout']:
                return '0', 'Reverted \n', ''
            raise Exception('Unhandled run_command: %s' % cmd)

        def fail_json(self, **kwargs):
            raise Exception('fail_json called')

    module = Module()

# Generated at 2022-06-11 08:03:52.619575
# Unit test for method update of class Subversion
def test_Subversion_update():
    try:
        import mock
    except Exception:
        print("The mock module is required to run this test")
        return
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        class MyModule:
            def __init__(self):
                self.run_command = lambda *args: (0, 'Changed', '')
        mock_module.return_value = MyModule()
        obj = Subversion(mock_module, None, None, None, None, None, None, None)
        assert obj.update()

# Generated at 2022-06-11 08:04:03.831864
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    class FakeModule():
        _ansible_options = {}
        def __init__(self):
            self.params = {
            'dest': "/tmp/test",
            'repo': "svn+ssh://an.example.org/path/to/repo",
            'revision': "HEAD",
            'username': "",
            'password': "",
            'svn_path': "svn",
            'validate_certs': False
            }
            self.run_command = run_command
        def fail_json(self, **kwargs):
            pass

    def run_command(**kwargs):
        return 0, "", ""

    fake = FakeModule()

# Generated at 2022-06-11 08:04:11.567805
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class TestModule:
        def __init__(self):
            self.run_command_result = [0, '', '']
            self.warn_list = []
            self.fail_json_dict = {}
            self.params = {}
            self.check_mode = False
            self.diff = False
            self.no_log = False
            self.run_command_cnt = 0

        def run_command(self, args, check_rc=True):
            if check_rc:
                if self.run_command_result[0] == 0:
                    return self.run_command_result[1:]
                else:
                    self.fail_json(msg='Test failure')
            else:
                return self.run_command_result[0], self.run_command_result[1], self.run_command_result

# Generated at 2022-06-11 08:04:13.037753
# Unit test for function main
def test_main():
    pass  # nothing to test in main()


# Generated at 2022-06-11 08:04:14.959218
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    remote_revision = Subversion._get_remote_revision()
    assert remote_revision == 0
