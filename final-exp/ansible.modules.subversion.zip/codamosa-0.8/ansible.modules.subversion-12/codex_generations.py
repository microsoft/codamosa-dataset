

# Generated at 2022-06-11 07:57:23.144869
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command') as mock_exec:
        with patch.object(AnsibleModule, 'get_bin_path') as mock_path:
            mock_path.return_value = 'svn'
            main()



# Generated at 2022-06-11 07:57:34.512251
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class Module(object):
        def __init__(self):
            self.params = {
                'repo': 'svn+ssh://an.example.org/path/to/repo',
                'dest': '/src/checkout'
            }
            self.run_command = mock_run_command
        def warn(self, msg):
            print(msg)

    module = Module()
    svn = Subversion(module=module,
                     dest=module.params['dest'],
                     repo=module.params['repo'],
                     revision='HEAD',
                     username=None,
                     password=None,
                     svn_path='svn',
                     validate_certs=True)
    for out, expected in mock_output:
        # test get_revision()
        rev, url = svn.get_re

# Generated at 2022-06-11 07:57:41.770630
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    result = True
    msg = None
    try:
        svn = Subversion(None, None, None, None, None, None, None, None)
        svn.REVISION_RE = r'(^|\n)R(evision|esultat|evision) : \d+(\n|$)'
        test = svn.get_remote_revision()
        result = (test[0] == 'Revision : 1889134')
    except Exception as exception:
        msg = str(exception)
    assert result and msg is None


# Generated at 2022-06-11 07:57:50.422466
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class TestModule(object):
        def __init__(self, dest, repo, revision):
            self.check_mode = False
            self.params = {'dest': dest, 'repo': repo, 'revision': revision}

        def run_command(self, args, check_rc, data=None):
            return (0, args, '')

    svn = Subversion(TestModule('/src/checkout', 'svn+ssh://an.example.org/path/to/repo', 'HEAD'), '/src/checkout', 'svn+ssh://an.example.org/path/to/repo', 'HEAD', None, None, '/usr/local/bin/svn', None)
    assert svn.needs_update()[2] == 'Unable to get revision'



# Generated at 2022-06-11 07:58:02.189692
# Unit test for function main
def test_main():
    # file fixture to set up object for test
    # for test_is_svn_repo
    sys.path.append(os.path.join(os.path.dirname(__file__), 'fixtures'))
    import test_subversion_fixtures
    module = test_subversion_fixtures.TestSubversion()
    dest = module.params['dest']
    repo = module.params['repo']
    revision = module.params['revision']
    force = module.params['force']
    username = module.params['username']
    password = module.params['password']
    svn_path = module.params['executable'] or module.get_bin_path('svn', True)
    export = module.params['export']
    switch = module.params['switch']

# Generated at 2022-06-11 07:58:10.298306
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    svn1 = Subversion(
        dest='.',
        repo='svn+ssh://an.example.org/path/to/repo',
        revision='HEAD',
        username='',
        password='',
        svn_path='/usr/bin/svn',
        validate_certs=True
    )

    class MockModule(object):
        def __init__(self, **kwargs):
            self.exit_json = Mock(return_value=kwargs)

        def fail_json(self, msg):
            return {'msg': msg}

    class MockPopen(object):
        def __init__(self, args, stdin, stdout, stderr, returncode):
            self.args = args
            self.stdin = stdin
            self.stdout = stdout
            self.st

# Generated at 2022-06-11 07:58:21.513531
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    import unittest
    from ansible.module_utils.common.parameters import StateDuplicatesError
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_text

    try:
        delattr(builtins, 'open')
    except AttributeError:
        pass
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.arguments import module_kwargs
    from ansible.module_utils.ansible_galaxy_api import GalaxyAPI
    from ansible.module_utils.ansible_galaxy.api import GalaxyAPI as GalaxyAPI_V2

# Generated at 2022-06-11 07:58:31.135263
# Unit test for function main
def test_main():
    svn_path = '/usr/bin/svn'
    locale = get_best_parsable_locale(module)
    module.run_command_environ_update = dict(LANG=locale, LC_MESSAGES=locale)
    dest = '.'
    repo = 'svn+ssh://an.example.org/path/to/repo'
    revision = 'HEAD'
    force = False
    username = None
    password = None
    svn_path = '/usr/bin/svn'
    export = module.params['export']
    checkout = module.params['checkout']
    update = module.params['update']
    in_place = module.params['in_place']

# Generated at 2022-06-11 07:58:42.591150
# Unit test for function main
def test_main():
    module_mock = Mock(params={'force': False, 'executable': None, 'repo': 'repo', 'checkout': True, 'switch': True, 'update': True, 'in_place': False,  'revision': 'HEAD', 'export': False, 'dest': 'dest', 'username': None, 'password': None})
    # function return value
    # function return value
    # function return value
    # function return value
    # function return value
    main(module_mock)
    assert module_mock.fail_json.call_count == 0
    assert module_mock.exit_json.call_count == 1
    assert module_mock.run_command.call_count == 0

if __name__ == '__main__':
    from ansible.module_utils.basic import *

# Generated at 2022-06-11 07:58:45.273150
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    subversion = Subversion(None, None, None, None, None, None, None)
    assert subversion.get_revision() == (None, None)


# Generated at 2022-06-11 07:59:11.618798
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    # test_Subversion_needs_update {{{
    subversion = Subversion(None, '/path/to/svn/repostiory', None, None, None, None, None, None)
    subversion.get_revision = lambda: ('Révision : 1889134', 'URL : svn+ssh://svn.code.sf.net/p/a/ansible/code/trunk')
    subversion.get_revision = lambda: ('Revision: 1889134','URL : svn+ssh://svn.code.sf.net/p/a/ansible/code/trunk')
    subversion.get_revision = lambda: ('Revision : 1889134', 'URL : svn+ssh://svn.code.sf.net/p/a/ansible/code/trunk')
    sub

# Generated at 2022-06-11 07:59:22.240029
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    import mock
    from ansible.module_utils._text import to_bytes

    m = mock.mock_open(read_data=to_bytes('1.9.4'))
    with mock.patch.object(Subversion, '_exec', return_value=('0', '1.9.4', 'stderr')):
        with mock.patch('io.open', m):
            assert Subversion(None, None, None, None, None, None, None, None).has_option_password_from_stdin() == False


# Generated at 2022-06-11 07:59:23.269173
# Unit test for method update of class Subversion
def test_Subversion_update():
    Subversion().update()


# Generated at 2022-06-11 07:59:24.715228
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Cannot test since it works with subversion.
    return True



# Generated at 2022-06-11 07:59:28.370980
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    # Create empty module
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.params = {}
    # Create empty instance
    subversion = Subversion(module, '', '', '', '', '', 'svn', 'no')
    assert(subversion.revert() == True)



# Generated at 2022-06-11 07:59:39.276862
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    import io
    import sys
    import tempfile
    import contextlib

    class FakeModule:

        def __init__(self, check_rc=False, **kwargs):
            self.run_command_check_rc = check_rc
            self.run_command_expect_rc = 0
            self.run_command_expect_out = ''
            self.run_command_expect_err = ''
            self.run_command_on_lines = []
            self.run_command_out_lines = []
            self.run_command_err_lines = []

        def run_command(self, cmd, check_rc=False, data=None):
            self.run_command_on_lines.extend(cmd)
            if check_rc and self.run_command_expect_rc != 0:
                raise

# Generated at 2022-06-11 07:59:50.445486
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    assert Subversion.get_revision("Revision: 42") == 42
    assert Subversion.get_revision("Had a little lamb 42") == 42
    assert Subversion.get_revision("42 Had a little lamb") == 42
    assert Subversion.get_revision("Revision:\t42") == 42
    assert Subversion.get_revision("Revision: 42\n") == 42
    assert Subversion.get_revision("Revision: 42\n") == 42
    assert Subversion.get_revision("Revision:\n42") != 42
    assert Subversion.get_revision("Revision: 42\t\t42") != 42
    assert Subversion.get_revision("Revision:") == ""
    assert Subversion.get_revision("Revision: ") == ""
    assert Subversion.get_

# Generated at 2022-06-11 08:00:02.595667
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    args = {
        'checkout': True,
        'dest': '/path/to/dest',
        'repo': 'svn+ssh://an.example.org/path/to/repo',
        'revision': 'HEAD',
        'validate_certs': True,
        'force': False,
        'update': True,
        'username': '',
        'password': ''
    }
    subversion = Subversion(None, args['dest'], args['repo'], args['revision'], args['username'], args['password'], "/usr/bin/svn", args['validate_certs'])
    subversion.checkout()
    # try to hatch some eggs
    assert subversion.revert()


# Generated at 2022-06-11 08:00:09.845910
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    dest = '/tmp/test'
    repo = 'https://github.com/geerlingguy/ansible-role-nginx'
    revision = 'HEAD'
    username = None
    password = None
    svn_path = '/usr/bin/svn'
    validate_certs = False
    test = Subversion(None, dest, repo, revision, username, password, svn_path, validate_certs)

    test.checkout()

    change, curr, head = test.needs_update()
    assert change, 'There are new versions'



# Generated at 2022-06-11 08:00:13.253215
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    import ansible.modules.source_control.subversion as s
    svn = s.Subversion(None, '.', '.', 'HEAD', None, None, 'svn', True)
    return svn.needs_update()

# Generated at 2022-06-11 08:00:39.634262
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    '''Unit test for method needs_update of class Subversion.'''

    import os
    import random
    import shutil
    import sys
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    def write_random_file(directory, filename='test'):
        '''Write a random file to the passed directory. The contents of the file will be random.
        This is done by writing 100 bytes to the file.'''
        file_path = os.path.join(directory, filename)
        with open(file_path, 'wb') as out_file:
            out_file.write(os.urandom(100))
        # Make sure that the directory containing the file is writable.
        os.chmod(os.path.join(directory, filename), 0o777)


# Generated at 2022-06-11 08:00:43.969117
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():

    class testmodule(object):
        def run_command(self, args, check_rc, data=None):
            return 0, "Revision: 1234", ""

    svn = Subversion(testmodule(), None, None, None, None, None, None, None)

    assert svn.get_remote_revision() == "Revision: 1234"



# Generated at 2022-06-11 08:00:52.050384
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    mod = AnsibleModule(argument_spec=dict())
    svn = Subversion(module=mod, dest='test', repo='test', revision=1, username=None, password=None, svn_path='test', validate_certs=False)
    assert svn._exec(["revert", "-R", svn.dest]) == [], 'revert not empty'
    assert svn.revert() == False, 'revert not empty'

if __name__ == '__main__':
    # Unit tests for Subversion
    test_Subversion_revert()



# Generated at 2022-06-11 08:01:03.563873
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    class ModuleMock(object):
        class ReturnData(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out.splitlines()
                self.err = err
        def __init__(self):
            self.run_command_calls = []
            self.run_command_return_datas = []
            self.run_command_call_counter = 0
        def run_command(self, args, check_rc=True, data=None):
            self.run_command_calls.append((args, check_rc, data))
            return_data = self.run_command_return_datas[self.run_command_call_counter]
            self.run_command_call_counter += 1
            if check_rc:
                return return_data

# Generated at 2022-06-11 08:01:13.085379
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class ModuleTest(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            raise AnsibleError(kwargs['msg'])
    class AnsibleError(Exception):
        pass
    src = "https://svn.apache.org/repos/asf/subversion/tags/1.9.0"
    mod = ModuleTest()
    mod.params['repo'] = src
    mod.params['dest'] = '/tmp/subversion'
    mod.params['executable'] = 'svn'
    mod.params['revision'] = 'HEAD'
    s = Subversion(mod, '/tmp/subversion', src, 'HEAD', '', '', 'svn')
    out = s.needs_update()

# Generated at 2022-06-11 08:01:14.219745
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 08:01:20.050155
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    '''
    subversion.Subversion._exec(svn, dest, repo, revision, username, password)
    '''
    cmd = ["revert", "-R", "dest"]
    obj = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    assert obj._exec(cmd) == output


# Generated at 2022-06-11 08:01:26.079447
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    # Create a instance of class Subversion
    # Should check wheter the given path is a svn repo
    svn = Subversion(None, "/tmp", None, None, None, None, None, None)

    # The command return code should be zero
    assert svn._exec(["info", "/tmp"], check_rc=False) == 0

    # Should return true
    assert svn.is_svn_repo() == True


# Generated at 2022-06-11 08:01:37.138138
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class MockAnsibleModuleReturn(object):
        def __init__(self, lines):
            self.lines = lines

        def splitlines(self):
            return self.lines

    class MockAnsibleModule(object):
        def __init__(self, lines):
            self.lines = lines

        def run_command(self, *args, **kwargs):
            check_rc = kwargs['check_rc']
            if check_rc:
                return 0, MockAnsibleModuleReturn(self.lines), None
            else:
                return 0

    text_match = [
        'URL: https://benchmark.domain.local/svn/Test',
        'Révision : 1234'
    ]
    # Test with valid text
    ansible_module = MockAnsibleModule(text_match)
   

# Generated at 2022-06-11 08:01:44.785782
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    # We're using globals because of the way unittest does class setup
    module = "ansible_module"
    dest = "dest_dir"
    repo = "repository"
    revision = "revision"
    username = "username"
    password = "password"
    svn_path = "svn"
    validate_certs = True

    subversion = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)

    rev_regexp = "Revision:\s+\d+"
    url_regexp = "URL:\s+.+"

# Generated at 2022-06-11 08:02:27.478919
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    import shutil

    # Create temporary directory in which we can create the test repo.
    repo_dir = 'test_dir'
    if os.path.exists(repo_dir):
        shutil.rmtree(repo_dir)
    os.mkdir(repo_dir)

    # Create test repo and add a test file
    repo_url = repo_dir + '/testrepo'
    svn_init_cmd = 'svnadmin create ' + repo_url
    svn_bump_cmd = 'svn commit --message "Bump revision" ' + repo_dir
    os.chdir(repo_dir)
    os.system(svn_init_cmd)
    open('testfile', 'w').close()

# Generated at 2022-06-11 08:02:29.448812
# Unit test for function main
def test_main():
    (rc, out, err) = main()
    assert rc == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:02:39.574529
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class AnsibleModuleMock(object):
        def run_command(self, cmd, *args, **kwargs):
            return 0, '''
URL: http://svn.example.com/svn/example/trunk
Repository Root: http://svn.example.com/svn/example
Repository UUID: e0c4be7f-5c73-0310-8c38-f5a2ef5c97d2
Revision: 1889134
Node Kind: directory
Last Changed Author: example
Last Changed Rev: 1889134
Last Changed Date: 2016-01-12 15:20:34 +0100 (Tue, 12 Jan 2016)
''', ''

# Generated at 2022-06-11 08:02:48.923139
# Unit test for function main

# Generated at 2022-06-11 08:02:55.650410
# Unit test for function main
def test_main():
    # Simple test for main function.
    import ansible.module_utils.subversion.subversion as svn

    module = AnsibleModule( dict(
        repo="/home/testuser/testrepo",
        checkout=True,
        dest="/"
    ) )

    dest = module.params['dest']
    repo = module.params['repo']
    checkout = module.params['checkout']

    svn = Subversion(module, dest, repo)
    # No assert as the checkout will fail as write permission will not be there.
    svn.checkout()


# Generated at 2022-06-11 08:03:03.791202
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    """
    TestSubversion get_revision()
    """
    class TestModule(object):
        def __init__(self):
            self.params = {
                'repo': 'url',
                'dest': 'dir'
            }
            self.run_command_results = [
                {
                    'rc': 0,
                    'stdout': '''URL: url\nRepository Root: url\nRepository UUID: bb\nRevision: 1\nNode Kind: directory\nSchedule: normal\nLast Changed Author: a\nLast Changed Rev: 1\nLast Changed Date: 2015-01-01T01:01:01.000000Z\n''',
                    'stderr': '',
                }
            ]
            self.run_command_calls = []


# Generated at 2022-06-11 08:03:09.847503
# Unit test for function main
def test_main():
    import sys
    import __builtin__
    sys.argv = ['ansible.builtin.subversion', 'repo=test', 'dest=test', 'password=test', 'username=test']

# Generated at 2022-06-11 08:03:19.216731
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    class MockModule():
        def __init__(self):
            self.params = {
                'repo': 'http://svn.apache.org/repos/asf/subversion/trunk',
                'revision': 'HEAD',
                'verbose': False,
                'username': '',
                'password': '',
                'svn_path': 'svn'
                }
            self.check_mode = False
            self.diff = False
            self.debug = False
            self.changed = False


# Generated at 2022-06-11 08:03:22.324954
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    module = AnsibleModule(argument_spec={})
    svn = Subversion(module, "/foo", "", "", "", "", "", "")
    assert svn.revert() == True


# Generated at 2022-06-11 08:03:23.222681
# Unit test for function main
def test_main():
    assert 0

# Generated at 2022-06-11 08:04:46.740163
# Unit test for method update of class Subversion
def test_Subversion_update():
    class Module(object):
        def __init__(self):
            self.params=dict(
                repo='svn+ssh://an.example.org/path/to/repo',
                revision='',
                dest='/src/checkout',
                username='',
                password='',
                svn_path='svn',
                validate_certs=True
            )

        def run_command(self, cmd, check, data=None):
            return 0, "/tmp/test/trunk", None

    class FakeActionResult(object):
        def __init__(self):
            self.rc = 0
            self.stdout = '/tmp/test/trunk'
            self.stderr = None

    module = Module()

# Generated at 2022-06-11 08:04:48.263079
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:04:57.443924
# Unit test for function main
def test_main():
        dest = 'checkout'
        repo = 'http://svn.apache.org/repos/asf/subversion/trunk'
        revision = 'HEAD'
        force = False
        username = 'username'
        password = 'password'
        svn_path = 'testexecutable' or module.get_bin_path('svn', True)
        export = False
        switch = True
        checkout = True
        update = True
        in_place = False
        validate_certs = False

        locale = get_best_parsable_locale(module)
        module.run_command_environ_update = dict(LANG=locale, LC_MESSAGES=locale)

        expected_result = True
        actual_result = not export and not update and not checkout
        assert expected_result == actual_result

# Generated at 2022-06-11 08:05:06.669508
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class AnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks, no_log, check_invalid_arguments, mutually_exclusive, required_together, required_one_of, add_file_common_args, supports_check_mode, required_by, required_if):
            self.fail_json = lambda **kwargs: exit(1)
        def run_command(self, args, check_rc=True, data=None):
            if args[1] == 'info':
                return 0, "Revision: 1\nURL: URL", ''


# Generated at 2022-06-11 08:05:15.209413
# Unit test for method update of class Subversion
def test_Subversion_update():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = None
            self.run_command_calls = []
        def run_command(self, cmd, check_rc=True, data=None):
            self.run_command_calls.append(cmd)
            if isinstance(self.run_command_results, tuple):
                if isinstance(self.run_command_results[0], Exception):
                    raise self.run_command_results[0]
                else:
                    return self.run_command_results
            self.run_command_results = self.run_command_results[1:]
            return self.run_command_results[0]
    module = FakeModule()

# Generated at 2022-06-11 08:05:22.418142
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class MockModule:
        class MockSubversion:
            def __init__(self, rev, url):
                self.rev, self.url = rev, url
            def _exec(self, args, check_rc=True):
                return [self.rev, self.url]

        def __init__(self):
            self.svn = self.MockSubversion('Révision : 1889134', 'URL : svn://an.example.org/for/repo')

        def fail_json(self, msg):
            print(msg)

    mock_module = MockModule()


# Generated at 2022-06-11 08:05:30.274009
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    import mock
    import tempfile
    def exec_side_effect(a, b):
        return 0, "", ""
    subversion = Subversion(
        module = None,
        dest = tempfile.mkdtemp(),
        repo = "svn+ssh://an.example.org/path/to/repo",
        revision = "HEAD",
        username = None,
        password = None,
        svn_path = "svn",
        validate_certs = True
    )
    subversion._exec = mock.Mock(side_effect=exec_side_effect)
    subversion.switch()

# Generated at 2022-06-11 08:05:38.307437
# Unit test for method switch of class Subversion

# Generated at 2022-06-11 08:05:46.210815
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    import builtins
    from distutils import spawn
    import tempfile
    from ansible.module_utils.six import StringIO

    class AnsibleModuleFake(object):
        def __init__(self, *args, **kwargs):
            return None

        def fail_json(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            if args[0] == ['--version', '--quiet']:
                return 0, '1.10.0', ''
            if args[0] == ['/usr/bin/svn', '--non-interactive', '--no-auth-cache', '--password-from-stdin', '--username', 'user', '--trust-server-cert', 'info', '/tmp/tmpF5HSyE']:
                return

# Generated at 2022-06-11 08:05:55.030202
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    import re
    module = None
    dest = "/tmp/test_ansible"
    repo = "http://example.com"
    revision = "1889134"
    username = None
    password = None
    svn_path = "svn"
    validate_certs = False
    svn = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    if os.path.exists(dest):
        svn._exec(["update"])
    else:
        svn.checkout()

    rev_re = Subversion.REVISION_RE
    txt = '\n'.join(svn._exec(["info", dest]))
    rev = re.search(rev_re, txt, re.MULTILINE)