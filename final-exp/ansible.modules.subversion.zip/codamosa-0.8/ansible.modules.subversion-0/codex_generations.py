

# Generated at 2022-06-11 07:57:28.325999
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    import sys
    import os
    import shutil
    import tempfile
    import contextlib

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    @contextlib.contextmanager
    def temporary_directory():
        tempdir = tempfile.mkdtemp()
        try:
            yield tempdir
        finally:
            shutil.rmtree(tempdir)


    class TestSubVersion(unittest.TestCase):

        def test_get_remote_revision(self):
            os.environ['SVN_TEST_WORK_DIR'] = os.path.join(os.path.dirname(__file__), 'testdata')
            dest = os.environ['SVN_TEST_WORK_DIR'] + "/testrepo"
            repo

# Generated at 2022-06-11 07:57:39.351036
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

        def run_command(self, *args, **kwargs):
            return 0, 'stdout', 'stderr'

    def mocked_run_command(*args, **kwargs):
        return 0, 'stdout', 'stderr'

    subversion = Subversion(MockModule(repo='repo', dest='dest', module='module'), 'dest', 'repo', 'revision', 'username', 'password', 'svn_path', 'validate_certs')
    subversion._exec = mocked_run_command


# Generated at 2022-06-11 07:57:45.159783
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    test_class = Subversion('module','dest','repo','revision','username','password','svn_path','validate_certs')
    def get_remote_revision(self):
        return 'Revision: 1234'
    test_class.get_remote_revision = get_remote_revision
    assert test_class.get_remote_revision() == 'Revision: 1234'


# Generated at 2022-06-11 07:57:55.539042
# Unit test for method update of class Subversion
def test_Subversion_update():
    class FakeAnsibleModule:
        class FakeRunCommand:
            def __init__(self):
                self.cmd = ""
                self.check_rc = True
                self.stdin_data = False
            def __call__(self,cmd,check_rc=True,data=False):
                self.cmd = cmd
                self.check_rc = check_rc
                self.stdin_data = data
                if cmd[-1] == "no":
                    output = ['ABDUCGE']
                elif cmd[-1] == "yes":
                    output = ['A     somefile']
                return (0, output, "")

        def __init__(self):
            self.fake = self.FakeRunCommand()
        def run_command(self, cmd, check_rc=True, data=False):
            return

# Generated at 2022-06-11 07:58:06.467353
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    import tempfile
    import shutil
    import os
    tmpdir = tempfile.mkdtemp()
    filename = os.path.join(tmpdir, 'test.txt')
    with open(filename, 'w') as f:
        f.write('Hello World')
    os.chdir(tmpdir)
    rc, out, err = module.run_command([module.params['executable'], 'checkout', 'file://' + tmpdir, '.'], check_rc=True)
    rc, out, err = module.run_command([module.params['executable'], 'info'], check_rc=True)

# Generated at 2022-06-11 07:58:17.394655
# Unit test for function main

# Generated at 2022-06-11 07:58:27.712960
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    from ansible.module_utils.basic import AnsibleModule
    if __name__ != '__main__':
        Subversion_revert = Subversion
        class ModuleResult:
            def __init__(self):
                self.stderr = ''
                self.stdout = ''

        class AnsibleModule:
            def __init__(self, argspec, check_mode=False, diff=False, supports_check_mode=False):
                self.check_mode = check_mode
                self.module_args = argspec
                self.result = ModuleResult()
                self.params = {}
                self.fail_json = self.exit_json = lambda: 0
                self.supports_check_mode = supports_check_mode

# Generated at 2022-06-11 07:58:35.285586
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, version, err):
                self.rc = rc
                self.version = version
                self.err = err

            def __call__(self, bin_path, module, check_rc=True):
                return self.rc, self.version, self.err

    class MockSubversion:
        def __init__(self):
            self.module = MockModule()
            self.dest = "destTest"
            self.repo = "repoTest"
            self.revision = "test"
            self.username = "usernameTest"
            self.password = "passwordTest"
            self.svn_path = "pathTest"
            self.validate_certs = True


# Generated at 2022-06-11 07:58:42.634001
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    from ansible.module_utils.basic import AnsibleModule
    import io
    import sys

    def test_run_command(command, check_rc):
        return 0, "OK\n", []

    class TModule():
        def __init__(self):
            self.run_command = test_run_command

    s = Subversion(TModule(), '', '', '', '', '', '', '')
    assert s.switch() == True

# Unit tests for method export of class Subversion

# Generated at 2022-06-11 07:58:46.771588
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    module = AnsibleModule({})
    svn = Subversion(module, None, None, None, None, None, '/usr/bin/svn', None)
    result = svn.get_remote_revision()
    assert result is not None

# Generated at 2022-06-11 07:59:08.583859
# Unit test for method update of class Subversion
def test_Subversion_update():
    # create a mock for class Module
    class Module:
        def __init__(self):
            self.run_command = lambda cmd, check_rc, data=None: (0, '', '')
    # create a mock for class Subversion
    class Subversion:
        def __init__(self, module, dest, repo, revision, username, password, svn_path, validate_certs):
            self.module = module
    # mock an instance of class Module
    module = Module()
    # mock an instance of class Subversion
    dest = '/subversion'
    repo = 'http://my.subversion.repo'
    revision = 'HEAD'
    username = 'subversion_user'
    password = 'subversion_password'
    svn_path = 'svn'
    validate_certs = 'true'


# Generated at 2022-06-11 07:59:16.867792
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3

    if PY3:
        import io
        StringIO = io.StringIO

    # Revision numbers are intentionally different to test that the
    # function correctly returns the incremented revision number.
    rev = 'Revision: 42'
    url = 'URL: http://example.com'
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '\n'.join([rev, url]), '')
    dest = '/path/to/repo'
    repo = 'svn+ssh://example.com/path/to/repo'

# Generated at 2022-06-11 07:59:27.016334
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():

    class Module():

        def __init__(self, name):
            self.name = name

        def get_bin_path(self, arg, *args, **kwargs):
            del arg, args, kwargs
            return '/usr/bin/svn'

        def run_command(self, command, check_rc=True, data=None):
            if command == ['/usr/bin/svn', '--non-interactive', '--no-auth-cache', 'info', '/path/to/repo']:
                return 0, 'Revision: 1889134\nUnrelated output', 'Unrelated error output'
            elif command == ['/usr/bin/svn', '--non-interactive', '--no-auth-cache', '--version', '--quiet']:
                return 0, '1.9.1',

# Generated at 2022-06-11 07:59:37.833224
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    # mock module
    module = Mock(AnsibleModule)
    # mock dest
    dest = 'C:\\Users\\serbest\\Desktop\\repository'
    # mock repo
    repo = 'svn+ssh://an.example.org/path/to/repo'
    # mock revision
    revision = 'HEAD'
    # mock username
    username = 'serbest'
    # mock password
    password = '@dmin.1'
    # mock svn_path
    svn_path = r'C:\Program Files\TortoiseSVN\bin\svn.exe'
    # mock validate_certs
    validate_certs = 'no'
    # initialize Subversion
    s = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
   

# Generated at 2022-06-11 07:59:49.293517
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    class ModuleFake:
        def run_command(self, bits, check_rc, data=None):
            if bits[-1] == 'info':
                stdout = '''\
Path: checkout
URL: svn+ssh://an.example.org/path/to/repo
Repository Root: svn+ssh://an.example.org/path/to/repo
Repository UUID: fa719992-f862-48b0-bd28-e7cec82440f1
Revision: 1889134
Node Kind: directory
Schedule: normal
Last Changed Author: mdehaan
Last Changed Rev: 1889134
Last Changed Date: 2016-10-12 07:57:21 -0700 (Wed, 12 Oct 2016)
'''

# Generated at 2022-06-11 08:00:00.941007
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    from ansible.module_utils.six import StringIO

    class MockModule(object):
        def __init__(self, dest):
            self.params = {
                'dest': dest,
                'force': False,
            }

        def run_command(self, args, check_rc=True, data=None):
            if args[1] == 'status':
                return 0, StringIO(status_output), ''
            else:
                return 0, '', ''

        def fail_json(self, *args, **kwargs):
            raise Exception()

    class MockSubversion(Subversion):
        def __init__(self, module):
            self.module = module

    status_output = '''\
? A
A  B
M  C'''
    module = MockModule('/does/not/exist')


# Generated at 2022-06-11 08:00:04.577540
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'dest': '',
        'repo': '',
        'revision': '',
        'force': '',
        'username': '',
        'password': '',
        'executable': '',
        'export': '',
        'checkout': '',
        'update': '',
        'switch': '',
        'in_place': '',
        'validate_certs': '',
        'supports_check_mode': '',
    })
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:00:07.695147
# Unit test for function main
def test_main():
    import sys
    if not os.path.exists('/usr/bin/svn'):
        sys.exit(77)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:00:11.083912
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    revision='1773148'
    repo='https://hg.mozilla.org/integration/mozilla-inbound'
    s = Subversion(None, repo, revision, None, None, None, False)
    assert s.needs_update()[2] == revision


# Generated at 2022-06-11 08:00:18.767527
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    repo = "https://svn.apache.org/repos/asf/subversion/trunk"
    dest = os.path.join("/tmp", "test_Subversion_is_svn_repo")
    try:
        svn = Subversion(AnsibleModule(argument_spec={}), dest, repo, "HEAD")
        svn.checkout()
        result = svn.is_svn_repo()
    finally:
        shutil.rmtree(dest)
    assert result



# Generated at 2022-06-11 08:01:00.538702
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    '''
    Placeholder for a unit test for testing Subversion.has_local_mods.
    Return True if test passes, False if test fails.
    '''
    svn = Subversion(None, None, None, None, None, None, None, None)
    svn.REVISION_RE = r'^\w+:\s+\d+$'
    svn.has_local_mods = Subversion.has_local_mods

    svn.has_local_mods()

    return True



# Generated at 2022-06-11 08:01:11.378055
# Unit test for function main

# Generated at 2022-06-11 08:01:22.011472
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    from ansible.module_utils.six.moves import StringIO
    try:
        from ansible.module_utils.ansible_release import __version__ as ansible_version
    except ImportError:
        # ansible < 2.3
        from ansible.release import __version__ as ansible_version
    if LooseVersion(ansible_version) < LooseVersion('2.5.0'):
        class AnsibleModule(object):
            def __init__(self):
                self.params = {}
                self.check_mode = False

            def fail_json(*args, **kwargs):
                raise AnsibleModuleError

            def exit_json(*args, **kwargs):
                assert False, "unexpected call"


# Generated at 2022-06-11 08:01:32.928700
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    class subversionclass():
        def __init__(self, module, dest, repo, revision, username, password, svn_path, validate_certs):
            pass

        def _exec(self, args, check_rc=True):
            text = ''
            if args == ['info', 'test']:
                text = text + 'URL: svn://an.example.org/path/to/repo/test'
                text = text + '\n属性修改的版本: 1889134'
            if args == ['info', '-r', 'test2', 'test']:
                text = text + '最后修改的版本: 1889135'
            return text.splitlines()


# Generated at 2022-06-11 08:01:42.604704
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    args = dict(
        dest='/tmp/test_svn',
        revision='19',
    )
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path', required=True),
            revision=dict(type='str', required=True),
        )
    )
    svn = Subversion(module, **args)


# Generated at 2022-06-11 08:01:52.615921
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    # setup the test
    module_args = {'repo': 'http://svn.example.com/repos/project1/branches/testing',
                   'dest': '/dest',
                   'revision': 'HEAD',
                   'username': '',
                   'password': '',
                   'checkout': True,
                   'update': True,
                   'force': False,
                   'in_place': False,
                   'export': False,
                   'switch': True,
                   'validate_certs': False,
                   'executable': '/usr/bin/svn'}
    module = AnsibleModule(argument_spec=module_args)

# Generated at 2022-06-11 08:01:58.314981
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Revision is taken from the url specified in this example
    tested_class = Subversion(None, None, 'svn://svn.freebsd.org/base/releng/11.2/etc', None, None, None, None, None)
    expected_revision = 'Revision : 343614'
    assert tested_class.get_remote_revision() == expected_revision



# Generated at 2022-06-11 08:02:03.297859
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    # testing with inline args
    module = AnsibleModule(
        argument_spec=dict(
            dest=dict(type='path'),
            revision=dict(type='str', default='HEAD'),
        )
    )

    svn = Subversion(module, dest='dest', revision='revision')
    assert svn.revert() == True


# Generated at 2022-06-11 08:02:10.678555
# Unit test for method update of class Subversion
def test_Subversion_update():
    text = '\n'.join(self._exec(["info", self.dest]))
    rev = re.search(self.REVISION_RE, text, re.MULTILINE)
    if rev:
        rev = rev.group(0)
    else:
        rev = 'Unable to get revision'

    url = re.search(r'^URL\s?:.*$', text, re.MULTILINE)
    if url:
        url = url.group(0)
    else:
        url = 'Unable to get URL'

    return rev, url




# Generated at 2022-06-11 08:02:21.243949
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError

    def run_command_mock(module, command_list, check_rc=True):
        if command_list[1] == b'info':
            return 0, to_bytes('Revision: 12'), ''
        else:
            raise AnsibleError('unexpected command')


# Generated at 2022-06-11 08:03:12.164892
# Unit test for method update of class Subversion
def test_Subversion_update():
        # self.dest
        # self.repo
        # self.revision
        # self.username
        # self.password
        # self.svn_path
        # self.validate_certs
        subversion = Subversion("self", "self", "self", "self", "self", "self", "self", "self")
        subversion.update()
        subversion.revert()
        return subversion.get_revision()

# Generated at 2022-06-11 08:03:18.891258
# Unit test for method update of class Subversion
def test_Subversion_update():
    class TestModule:
        def __init__(self):
            pass
        def run_command(self, cmd):
            class InternalTestModule:
                pass
            itm = InternalTestModule()
            itm.rc = 0
            itm.stdout = "test"
            itm.stderr = "test"
            return itm
    test_module = TestModule()
    sw = Subversion(test_module, "/tmp", "", "", "", "", "", "")
    assert sw.update() == True

# Generated at 2022-06-11 08:03:25.573642
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    import subprocess
    pipe = 'svn switch --revision 1234 svn+ssh://an.example.org/path/to/repo /src/checkout'
    subprocess.Popen.return_value.communicate.return_value = (
 [['A    /src/checkout/path/to/file'], 0 ]
)
    subversion = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    assert subversion.switch() == True


# Generated at 2022-06-11 08:03:32.847146
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Test case 1: The SVN repository to test is locally available
    # Expected output: Revision number
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, 'Revision: 1234', ''))
    svn = Subversion(module,
                     dest='/tmp',
                     repo='/tmp',
                     revision='HEAD',
                     username=None,
                     password=None,
                     svn_path='/bin/svn',
                     validate_certs=True)
    assert svn.get_remote_revision() == 'Revision: 1234'

    # Test case 2: The SVN repository to test is not locally available
    # Expected output: "Unable to get URL"

# Generated at 2022-06-11 08:03:34.929996
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    # TODO: Implement unit tests for method switch of class Subversion
    pass



# Generated at 2022-06-11 08:03:45.328735
# Unit test for method revert of class Subversion
def test_Subversion_revert():

    # Tests:
    #   - Subversion.revert
    #   - Subversion._exec
    module = AnsibleModule({})
    svn = Subversion(module, dest="/dest/checkout", repo="https://example.com", revision='HEAD', username=None, password=None, svn_path='/svn', validate_certs=True)

    class MockRunCommand(object):
        def __init__(self):
            self.matches = []

        def match(self, regex):
            for line in self.matches:
                match = re.search(regex, line, re.MULTILINE)
                if match:
                    return match

        def run_command(self, bits, check_rc=True, data=None):
            self.matches = ["Reverted", "Reverted"]
           

# Generated at 2022-06-11 08:03:53.683269
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    try:
        from mock import Mock, patch
    except ImportError:
        from unittest.mock import Mock, patch
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.subversion import Subversion
    dest = 'dest'
    repo = 'repo'
    revision = 'revision'
    username = None
    password = None
    svn_path = 'svn'
    validate_certs = False
    subversion = Subversion(Mock(), dest, repo, revision, username, password, svn_path, validate_certs)
    subversion._exec = Mock(return_value=['A       test/foo.txt'])
    assert subversion.switch()

# Generated at 2022-06-11 08:04:05.110936
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a dummy repo with no code, but a non-HEAD revision
    shutil.rmtree(tmpdir)
    os.mkdir(tmpdir)
    os.system('svnadmin create repo')

    # Get module_utils/basic.py from within the Ansible git repository,
    # since that's not provided by Ansible installation
    module_utils_basic_py = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                                         "lib/ansible/module_utils/basic.py")

# Generated at 2022-06-11 08:04:12.945562
# Unit test for method update of class Subversion
def test_Subversion_update():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = []
            self.params = {
                'repo': 'svn+ssh://an.example.org/path/to/repo',
                'dest': '/src/checkout',
                'update': True,
                'checkout': False,
                'revision': 'HEAD',
                'force': False,
                'in_place': False,
                'username': '',
                'password': '',
                'executable': ''
            }
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

# Generated at 2022-06-11 08:04:23.447435
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    mock_module = {}

    def run_command(*param):
        mock_out = ['URL: svn+ssh://an.example.org/path/to/repo',
                    'Repository Root: svn+ssh://an.example.org/path/to/repo',
                    'Repository UUID: 0002b7ae-300c-4f1f-9a22-b1dd13330c2f',
                    'Revision: 12345',
                    'Node Kind: directory',
                    'Last Changed Author: theauthor',
                    'Last Changed Rev: 12345',
                    'Last Changed Date: 2017-04-09 21:39:57 +0200 (dim., 09 avr. 2017)']
        return 0, '\n'.join(mock_out), ''

    mock_module['run_command'] = run_command

# Generated at 2022-06-11 08:06:19.370348
# Unit test for function main
def test_main():
    fake_module = type("AnsibleModule", (object, ), {"exit_json": print, "fail_json": print, "check_mode": False, "params": {"force": False, "repo": "svn+ssh://an.example.org/path/to/repo", "username": None, "executable": None, "checkout": True, "switch": True, "password": None, "in_place": False, "dest": "/src/checkout", "update": True, "validate_certs": False, "export": False, "revision": "HEAD"}})
    fake_module.run_command_environ_update = {}
    fake_module.run_command = lambda cmd, check_rc=True: print(cmd)
    fake_module.get_bin_path = lambda *args, **kwargs: print

# Generated at 2022-06-11 08:06:25.345276
# Unit test for method update of class Subversion
def test_Subversion_update():
    returncode = 0
    output = []

# Generated at 2022-06-11 08:06:31.857506
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    import mock
    import sys

    class MockSubversion(Subversion):
        def __init__(self):
            self.dest = None
            self.repo = None
            self.revision = None

        def needs_update(self):
            return True

        def _exec(self, args, check_rc=True):
            if args[2] == '--quiet':
                output = [
                    '? DummyFile1',
                    'M DummyFile2',
                    '? DummyFile3',
                    'A DummyFile4',
                ]
                return output

        def has_local_mods(self):
            return super(MockSubversion, self).has_local_mods()

    svn = MockSubversion()

    # Mock the module
    module = mock.Mock()

# Generated at 2022-06-11 08:06:35.342696
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    mock = Subversion(42, 'dest', 'repo', 'revision', 'username', 'password', 'svn_path', 'validate_certs')
    mock_exec = ['a', 'b', 'c']
    mock.exec = lambda x,y: mock_exec
    assert mock.revert() == True

if __name__ == '__main__':
    test_Subversion_revert()


# Generated at 2022-06-11 08:06:42.767587
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    class AnsibleModuleFake:
        def __init__(self, msg, **kwargs):
            self.msg = msg
            self.kwargs = kwargs
            self.invocation = kwargs.get('invocation')
            self.params = kwargs.get('params')

        def fail_json(self, *wargs, **kwargs):
            pass

        def run_command(self, args, *wargs, **kwargs):
            self.invocation = args
            return 0, 'Reverted src/foo\nReverted src/bar', ''
    module = AnsibleModuleFake('', params={})
    subversion = Subversion(module, '/src', '', '', '', '', 'svn', 'no')
    assert subversion.revert() == True

# Generated at 2022-06-11 08:06:49.866394
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    svn_revision = "Révision : 1889134"

# Generated at 2022-06-11 08:06:59.743656
# Unit test for method update of class Subversion
def test_Subversion_update():
    repo = 'svn+ssh://an.example.org/path/to/repo'
    revision = 'HEAD'
    dest = 'dest'
    svn_path = 'svn'

    module_mock = Mock()
    module_mock.params = {
        'repo': repo,
        'revision': revision,
        'dest': dest
    }
    module_mock.run_command.return_value = (0, "", "")

    # Run method
    svn = Subversion(module=module_mock, dest=dest, repo=repo, revision=revision, username=None, password=None, svn_path=svn_path, validate_certs=True)
    change = svn.update()

    assert change is True
