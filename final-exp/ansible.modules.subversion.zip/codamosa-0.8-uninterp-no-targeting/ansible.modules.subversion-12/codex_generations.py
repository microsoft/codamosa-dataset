

# Generated at 2022-06-20 22:35:33.530767
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    module = AnsibleModule(argument_spec={})
    subv = Subversion(module, repo="", dest="", revision="", username="", password="", svn_path="", validate_certs=True)
    assert not subv._is_svn_repo()
    subv.dest = "/tmp/ansible_test"
    assert not subv._is_svn_repo()
    subv.repo = "https://github.com/ansible/ansible"
    subv.checkout()
    assert subv.is_svn_repo()
    subv.update()
    subv.revert()



# Generated at 2022-06-20 22:35:43.135603
# Unit test for method checkout of class Subversion

# Generated at 2022-06-20 22:35:54.368940
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    class ModuleMock:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, command, check, data=None):
            return self.rc, self.out, self.err

    module = ModuleMock(0, 'M\nM lib/Subversion.py\n', '')
    svn = Subversion(module, '.', '', '', '', '', '', True)
    assert svn.has_local_mods()

    module = ModuleMock(0, '', '')
    svn = Subversion(module, '.', '', '', '', '', '', True)
    assert not svn.has_local_mods()


# Generated at 2022-06-20 22:36:05.204448
# Unit test for function main
def test_main():
    args = dict(
        dest='/tmp/test',
        repo='svn+ssh://foo.example.org/path/to/repo',
        revision='HEAD'
    )
    m = AnsibleModule(argument_spec=args)
    m.exit_json = exit_json
    m.fail_json = fail_json
    m.get_bin_path = get_bin_path

    # This is for unit tests only where the directories may not exist.
    m.run_command = run_command
    m.run_command_environ_update = dict()
    m._ansible_version = LooseVersion('2.10.0')


# Generated at 2022-06-20 22:36:17.265402
# Unit test for method export of class Subversion
def test_Subversion_export():
    module_mock = AnsibleModule({
        'repo': 'svn+ssh://an.example.org/path/to/repo',
        'dest': '/src/export',
        'export': 'yes',
        'revision': 'HEAD',
        'force': 'no',
        'in_place': 'no',
        'username': '',
        'password': '',
        'executable': '',
        'checkout': 'yes',
        'update': 'yes',
        'switch': 'yes',
        'validate_certs': 'no',
        '_ansible_check_mode': 'True',
        '_ansible_debug': 'True',
        '_ansible_diff': 'True'
    })
    Subversion.export(self, force=False)


# Generated at 2022-06-20 22:36:27.280811
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    import tempfile
    import shutil

    def test_has_local_mods(svn, files, expect):
        for filename in files:
            with open(filename, "w") as f:
                f.write("")
        actual = svn.has_local_mods()
        if actual != expect:
            print("ERROR in test_has_local_mods: expected %s, actual %s" % (str(expect), str(actual)))

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 22:36:32.220343
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    class MockModule:
        def __init__(self):
            pass

        def run_command(self, cmd, check_rc, data):
            return 0, '1.9.1', ''

    class MockModule2:
        def __init__(self):
            pass

        def run_command(self, cmd, check_rc, data):
            return 0, '1.10.0', ''

    class MockModule3:
        def __init__(self):
            pass

        def run_command(self, cmd, check_rc, data):
            return 1, '1.9.1', ''

    a = Subversion(MockModule(), '', '', '', '', '', '', '')
    assert a.has_option_password_from_stdin() is False


# Generated at 2022-06-20 22:36:42.856414
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class FakeModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_success = True
            self.run_command_data = None
            self.run_command_rc = 0

        def run_command(self, args, check_rc=True, data=None):
            self.run_command_count += 1
            if self.run_command_success:
                if args[0] == 'svn':
                    if args[1] == '--version':
                        return (self.run_command_rc, '1.10.0', '')
                    else:
                        return (self.run_command_rc, '', '')
            else:
                raise Exception

# Generated at 2022-06-20 22:36:44.969954
# Unit test for constructor of class Subversion
def test_Subversion():
    sc = Subversion(None, None, None, None, None, None, None, None)
    assert isinstance(sc, Subversion)



# Generated at 2022-06-20 22:36:49.877346
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    m = AnsibleModule(argument_spec=dict())
    svn = Subversion(m, dest='/path/to/repo', repo='svn+ssh://server/path/to/repo', revision='HEAD', username='user', password='pass', svn_path='/usr/bin/svn', validate_certs=False)
    rc = svn._exec(["info", '/path/to/repo'], check_rc=False)
    assert rc == 0


# Generated at 2022-06-20 22:37:13.943771
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    # setup the test
    m = type('module', (object,), {'run_command': lambda self, args, check_rc: (0, '', '')})()
    subversion = Subversion(m, '', '', '', '', '', '', '')

    # stub LooseVersion
    class LooseVersion:
        def __init__(self, version):
            self.version = version

        def __ge__(self, other):
            return self.version >= other.version

    # these are what we will call with the LooseVersion stub
    version_string_less_than_1_10_0 = '1.9.99'
    version_string_greater_or_equal_to_1_10_0 = '1.10.0'

    # ensure that a version string less than 1.10.0

# Generated at 2022-06-20 22:37:22.195435
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Setup
    module = MockModule()
    subversion = Subversion(
        module=module,
        dest="",
        repo="",
        revision="",
        username="",
        password="",
        svn_path="",
        validate_certs=False
    )

    mock_exec = Mock()
    subversion._exec = mock_exec
    mock_exec.return_value = ["Revision: 1"]

    # Call
    expected = "Revision: 1"
    actual = subversion.get_remote_revision()

    # Assert
    assert actual == expected



# Generated at 2022-06-20 22:37:28.231482
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    '''Tests if the given subversion object has a valid revision.

    :param module: subversion object
    :returns: True if the subversion object has a valid revision

    :raises: none
    '''

    s = Subversion("m", "d", "r", "1", "u", "p", "s")
    assert s.revert()


# Generated at 2022-06-20 22:37:34.734255
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    # create temporary directory
    import tempfile
    dir = tempfile.mkdtemp('-ansible')
    # create temporary temp file
    import tempfile
    temp = tempfile.NamedTemporaryFile(delete=False)
    tempname = temp.name
    temp.close()

# Generated at 2022-06-20 22:37:39.280961
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    module = MockModule()
    subversion = Subversion(module, '/src/checkout', 'svn+ssh://an.example.org/path/to/repo', 'HEAD', None, None, '/usr/bin/svn', False)
    assert subversion.is_svn_repo() == True

# Generated at 2022-06-20 22:37:50.667048
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    mock_module = {
        'run_command': lambda *args, **kwargs: (0, '1.9.9', None),
        'warn': lambda *args, **kwargs: None
    }
    Subversion(mock_module, '', '', '', '', '', '').has_option_password_from_stdin()
    Subversion(mock_module, '', '', '', '', '', '').has_option_password_from_stdin()
    mock_module = {
        'run_command': lambda *args, **kwargs: (0, '1.10.0', None),
        'warn': lambda *args, **kwargs: None
    }
    Subversion(mock_module, '', '', '', '', '', '').has_option_password_from_stdin

# Generated at 2022-06-20 22:37:59.562641
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    args = {}
    args['module'] = None
    args['dest'] = None
    args['repo'] = None
    args['revision'] = None
    args['username'] = None
    args['password'] = None
    args['svn_path'] = 'svn'
    args['validate_certs'] = 'yes'

    res = Subversion(**args)
    assert res.has_option_password_from_stdin() == False

    args['svn_path'] = 'svn2'
    res = Subversion(**args)
    assert res.has_option_password_from_stdin() == True



# Generated at 2022-06-20 22:38:02.474081
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    repo = Subversion(None, None, None, None, None, None, None, None)
    assert repo is not None
    revision, url = repo.get_revision()
    assert revision is not None
    assert url is not None

# Generated at 2022-06-20 22:38:03.431471
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    assert True == False

# Generated at 2022-06-20 22:38:14.477870
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    import shutil
    import os.path
    import tempfile

    repo = 'svn://svn.apache.org/repos/asf/subversion/trunk'

    module = AnsibleModule(
        argument_spec = {
            'repo': {'required': True},
            'username': {},
            'password': {},
            'svn_path': {'default': 'svn'},
            'validate_certs': {'default': True},
        }
    )

    dest = tempfile.mkdtemp()
    svn = Subversion(module, dest, repo, None, None, None, 'svn', False)
    svn.checkout()

    # Now we modify the working copy.

# Generated at 2022-06-20 22:38:43.084412
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    mod = AnsibleModule({})
    svn_obj = Subversion(mod, '', '', '', '', '', '', '')
    assert svn_obj.needs_update()[0] == True



# Generated at 2022-06-20 22:38:55.421906
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    # OK, this is very convoluted, but I want to test that needs_update works as expected
    # without having to create a mock for every method of Subversion.
    # So I subclass Subversion and override the methods I need to, and
    # instantiate the testing class with module args that don't really call anything.
    class SubversionForTest(Subversion):
        def __init__(self, module):
            url = module.params['repo']
            dest = module.params['dest']
            revision = module.params['revision']
            username = module.params['username']
            password = module.params['password']
            svn_path = module.params['executable']
            validate_certs = module.params['validate_certs']

# Generated at 2022-06-20 22:39:02.304040
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    from ansible.utils.unicode import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import b
    import ansible.module_utils.subversion as module_subversion
    import tempfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary svn repo
    subversion_executable = module_subversion.get_subversion_executable()
    rc, out, err = module_subversion.run_command([subversion_executable, "checkout", "svn://localhost/tmp/ansible-test-subversion/trunk", tmpdir])

    # write a file
    path = os.path.join(tmpdir, "test.txt")


# Generated at 2022-06-20 22:39:09.664027
# Unit test for method get_revision of class Subversion
def test_Subversion_get_revision():
    module = AnsibleModule(argument_spec={})
    dest = None
    repo = None
    revision = None
    username = None
    password = None
    svn_path = None
    validate_certs = None
    s = Subversion(module, dest, repo, revision, username, password, svn_path, validate_certs)
    s.REVISION_RE = r'^\w+\s?:\s+\d+$'

# Generated at 2022-06-20 22:39:21.624116
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    from mock import patch
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.params = {
        'dest': 'test',
        'repo': 'test',
        'revision': 'test',
        'svn_path': 'test',
        'username': 'test',
        'password': None,
    }
    svn = Subversion(module, module.params['dest'], module.params['repo'], 'HEAD', module.params['username'],
                     module.params['password'], module.params['svn_path'], False)

    unpatched_run_command = svn.module.run_command

    # return version 1.10.0

# Generated at 2022-06-20 22:39:26.205949
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    class AnsibleModuleFake:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return 0, "", ""

    dest = '.'
    svn = Subversion(AnsibleModuleFake(), dest, None, None, None, None, None, None)
    svn.is_svn_repo()
    c = AnsibleModuleFake()
    c.params['check_mode'] = 'true'
    svn = Subversion(c, dest, None, None, None, None, None, None)
    svn.is_svn_repo()



# Generated at 2022-06-20 22:39:32.506937
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    module = dict(
        run_command = dict(
            return_value = 0,
        ),
        warn = dict(
            return_value = None,
        ),
    )
    sv = Subversion(module)

    # Test the happy path
    sv._exec = dict(
        return_value = ['Reverted '],
    )
    assert sv.revert() is False

    # Test the unhappy path
    sv._exec = dict(
        return_value = ['Reverted ', 'Foo'],
    )
    assert sv.revert() is True


# Generated at 2022-06-20 22:39:39.308612
# Unit test for function main
def test_main():
    '''
    Test module main
    '''
    # Setup the test objects

# Generated at 2022-06-20 22:39:48.391166
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    import unittest
    import mock

    class MockModule(object):
        def __init__(self, params=None):
            self._params = {
                'dest': '/tmp/checkout',
                'revision': 'HEAD',
                'repo': 'http://example.com/repo',
                'username': None,
                'password': None,
                'svn_path': 'svn',
                'validate_certs': True,
            }
            if params:
                self._params.update(params)
        def params(self):
            return self._params

        def run_command(self, args, check_rc, data=None):
            return 0, '', ''

    class MockModuleV2(object):
        def __init__(self, params=None):
            self.params = params



# Generated at 2022-06-20 22:39:59.801761
# Unit test for method checkout of class Subversion
def test_Subversion_checkout():
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
            self.params['dest'] = '/dest/'
            self.params['repo'] = 'http://repo/'
            self.params['revision'] = 1
            self.params['username'] = 'user'
            self.params['password'] = 'pass'
            self.params['svn_path'] = 'script/svn'
            self.params['validate_certs'] = False
        def run_command(self, command, check_rc=False, data=None):
            return 0,"",""


# Generated at 2022-06-20 22:41:08.766861
# Unit test for method export of class Subversion
def test_Subversion_export():
    import tempfile
    # test_Subversion.test_export()
    # svn --version
    # svn, version 1.9.7 (r1800392)
    #   compiled Dec  1 2016, 02:41:21 on x86_64-pc-linux-gnu
    cmd = ['svn', 'checkout', '-r', 'HEAD', 'https://svn.apache.org/repos/asf/subversion/trunk/subversion/tests/cmdline/svntest', '/tmp/svntest']
    # process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    # process.wait()
    # print(process.returncode)
    # print(process.stdout)
    # print(

# Generated at 2022-06-20 22:41:19.780821
# Unit test for constructor of class Subversion
def test_Subversion():
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, check_rc, data=None):
            self.run_command_calls.append((cmd, check_rc, data))

            output = "1.9.3"
            if cmd == ['/usr/bin/svn', '--version', '--quiet']:
                return 0, output, ''
            elif cmd == ['/usr/bin/svn', '--non-interactive', '--no-auth-cache', '--username', 'user', '--password-from-stdin', 'info', '/tmp']:
                return 0, output, ''

# Generated at 2022-06-20 22:41:25.346604
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    # Test with a changed remote repo.
    repo = Subversion(None, '.', 'https://nijel.kiwix.org/svn/trunk/kiwix-tools', 'HEAD', None, None, 'svn', True)
    assert repo.get_remote_revision() != repo.get_revision()[0]
    # Test with an unchanged remote repo.
    repo = Subversion(None, '.', 'https://nijel.kiwix.org/svn/trunk/kiwix-tools', '7872', None, None, 'svn', True)
    assert repo.get_remote_revision() == repo.get_revision()[0]


# Generated at 2022-06-20 22:41:32.546758
# Unit test for method checkout of class Subversion
def test_Subversion_checkout():
    def _subversion_method_checkout_mock(args, check_rc=True):
        # This is the method return values
        return ['M\tfile1']
    # This is the replacement of the method
    Subversion.checkout = _subversion_method_checkout_mock

    # This is the class instance
    v = Subversion(object(), '/this/is/a/test', 'svn+ssh://this.is.a.test', '12345', 'test', 'test', '/test', True)
    result = v.checkout()
    assert result is False


# Generated at 2022-06-20 22:41:41.232494
# Unit test for method needs_update of class Subversion
def test_Subversion_needs_update():
    subversion = Subversion(None, '/tmp/test', 'http://svn.apache.org/repos/asf/subversion/trunk', 'HEAD', None, None, '/usr/bin/svn', False)
    old_get_revision = subversion.get_revision
    try:
        subversion.get_revision = lambda: ('Revision : 9999', 'URL : http://svn.apache.org/repos/asf/subversion/trunk')
        assert subversion.needs_update() == (True, 'Revision : 9999', 'Revision : 1234')
    finally:
        subversion.get_revision = old_get_revision


# Generated at 2022-06-20 22:41:47.726502
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    # Need to create a AnsibleModule instance to call a method or function from class or function
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:41:50.686017
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    """
    This tests the switch method of the Subversion class
    """

    assert Subversion(None, None, None, None, None, None, None, None).switch() == None




# Generated at 2022-06-20 22:41:51.626759
# Unit test for method switch of class Subversion
def test_Subversion_switch():
    subversion_module_instance = Subversion()
    assert subversion_module_instance.switch()

# Generated at 2022-06-20 22:41:56.917192
# Unit test for method has_option_password_from_stdin of class Subversion
def test_Subversion_has_option_password_from_stdin():
    test_module = AnsibleModule({})
    test_exec = Subversion(test_module, dest, repo, revision, username, password, svn_path, validate_certs)
    from ansible.module_utils.common.version import __version__
    from ansible.module_utils.common.version import __version_info__
    assert test_exec.has_option_password_from_stdin() == (LooseVersion(__version__) >= LooseVersion('2.10.0'))
# end unit test for method has_option_password_from_stdin of class Subversion



# Generated at 2022-06-20 22:42:02.913487
# Unit test for method get_remote_revision of class Subversion
def test_Subversion_get_remote_revision():
    class MockModule(object):
        def run_command(self, cmd, check_rc):
            return 0, '1321', ''
    module = MockModule()

    # make sure if revision is a string
    svn = Subversion(module, None, None, None, None, None, None, True)
    assert svn.get_remote_revision() == '1321'



# Generated at 2022-06-20 22:43:20.528358
# Unit test for method has_local_mods of class Subversion
def test_Subversion_has_local_mods():
    import tempfile
    temp_path = tempfile.mkdtemp()
    s = Subversion(None, temp_path, None, None, None, None, None, None)
    assert not s.has_local_mods()
    s.checkout()
    assert not s.has_local_mods()
    with open(os.path.join(temp_path, 'test.txt'), 'w') as file:
        file.write('test')
    assert s.has_local_mods()



# Generated at 2022-06-20 22:43:26.724957
# Unit test for method export of class Subversion
def test_Subversion_export():
    """
    This method tests export of Subversion class.
    """
    import tempfile
    import shutil
    import os
    import imp
    module = imp.load_source("svn", "modules/source_control/subversion.py")
    # Create a temp directory
    temp_dir = tempfile.mkdtemp()
    svn_dir = os.path.join(temp_dir, "svn")

    # Construct a mock module and attrs for this test case
    module.AnsibleModule = MockAnsibleModule

# Generated at 2022-06-20 22:43:27.995087
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    subversion = Subversion(None, ".", ".", ".", "","", "svn", "")
    assert subversion.is_svn_repo() == 0

# Generated at 2022-06-20 22:43:31.113136
# Unit test for constructor of class Subversion
def test_Subversion():
    d = Subversion(None, 'path', 'url', '12345', 'user', 'pass', 'svn_path', False)
    assert not d.is_svn_repo()
    assert d.dest == 'path'
    assert d.repo == 'url'
    assert d.revision == '12345'
    assert d.username == 'user'
    assert d.password == 'pass'
    assert d.svn_path == 'svn_path'
    assert d.validate_certs == False


# Generated at 2022-06-20 22:43:40.149953
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    mod_mock = AnsibleModule(
        argument_spec = dict(
            dest = dict(required=True),
            repo = dict(required=True),
            revision = dict(default='HEAD'),
            username = dict(type='str'),
            password = dict(type='str'),
            svn_path = dict(type='path', default='/usr/bin/svn'),
            validate_certs = dict(type='bool', default=True),
        )
    )
    mod_mock.run_command = basic.run_command
    mod_mock.run_command_environ_update = basic.run_command_environ_update

# Generated at 2022-06-20 22:43:40.918779
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
    c = Subversion()
    assert c

# Generated at 2022-06-20 22:43:49.246273
# Unit test for method is_svn_repo of class Subversion
def test_Subversion_is_svn_repo():
   svn_path = "/usr/bin/svn"
   repo = 'http://an.example.org/path/to/repo'
   dest = '/some/place/to/checkout/repo'
   revision = "HEAD"
   password = None
   username = None
   validate_certs = True

   def run_command_mock(cmd, check_rc=True, **kwargs):
      if cmd[0] == svn_path and cmd[1] in ('--non-interactive', '--no-auth-cache') and '--username' not in cmd and '--password' not in cmd and '--password-from-stdin' not in cmd and '--trust-server-cert' not in cmd:
         if cmd[-1] == dest:
            if cmd[-2] == 'info':
               return

# Generated at 2022-06-20 22:43:57.234906
# Unit test for method get_remote_revision of class Subversion

# Generated at 2022-06-20 22:44:06.026426
# Unit test for method revert of class Subversion
def test_Subversion_revert():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.compat import ipaddress
    from ansible.module_utils._text import to_bytes

    import os
    import pytest
    import sys

    if not os.path.isfile(to_bytes('conftest.py')):
        pytestmark = pytest.mark.skip('tests folder missing conftest.py')
        raise Exception('tests folder is missing conftest.py')

    if not os.path.isdir(to_bytes('/etc/ansible')):
        pytestmark = pytest.mark.skip('tests folder missing fixtures')
        raise Exception('tests folder is missing fixtures')


# Generated at 2022-06-20 22:44:10.892115
# Unit test for method switch of class Subversion