

# Generated at 2022-06-10 23:13:32.553326
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host = runner.get_host_manager(None).get_host()
    host.name = 'myhost'

    play = Play.load(dict(
        name = "myplay",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls', register='shell_out')),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
            ]
        ), variable_manager=None, loader=None)

    host.set_task_queue(play.compile())
    pi = PlayIterator(play)
    assert not pi.is_failed(host)

    host.set_task_queue(play.compile())
    pi = PlayIterator(play)

# Generated at 2022-06-10 23:13:41.467085
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-10 23:13:53.119357
# Unit test for method get_active_state of class PlayIterator

# Generated at 2022-06-10 23:13:54.286125
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # FIXME
    pass

# Generated at 2022-06-10 23:14:06.307585
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Create a mock object to test with
    from ansible.mock import Mock

    playbook = Mock()
    # We don't need a real Play for this test
    play = Mock()
    iterator = PlayIterator(playbooks=[playbook], play=play)

    # Set the attribute values we want for the test
    iterator._play = Mock()
    iterator._play_forks = Mock()
    iterator._play_basedirs = Mock()
    iterator._playbook_basedir = Mock()
    iterator._playbook_basedir = "/some/path/foo"
    iterator._tqm = Mock()
    iterator._inventory = Mock()
    iterator._last_host_group_seen = Mock()
    iterator.hostvars = Mock()

    # Create a mock object to test with
    host = Mock()

# Generated at 2022-06-10 23:14:07.874804
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    pass


# Generated at 2022-06-10 23:14:19.648543
# Unit test for method __str__ of class HostState
def test_HostState___str__():

    def test_HostState_copy(s):
        ret = s.copy()
        assert ret == s

    def test_HostState_get_current_block(s):
        ret = s.get_current_block()
        assert ret == '_blocks[0]'

    def test_HostState_eq(s):
        a = HostState(['_blocks'])
        assert a == a
        a.cur_block = 1
        assert a != s
        a.cur_regular_task = 1
        assert a != s
        a.cur_rescue_task = 1
        assert a != s
        a.cur_always_task = 1
        assert a != s
        a.run_state = 1
        assert a != s
        a.fail_state = 1
        assert a != s
        a.pending_setup

# Generated at 2022-06-10 23:14:32.124067
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play.load(dict(
        name = 'test',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami')),
            dict(action=dict(module='shell', args='pwd'))
        ]
    ), variable_manager=VariableManager())

    pi = PlayIterator()
    pi._play = play
    assert pi._play == play
    assert pi._play._iterator is pi
    assert pi._play._iterator._play is pi._play
    assert pi._play._iterator is pi._play._iterator._play._iterator


# Generated at 2022-06-10 23:14:40.012383
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    p = Play()
    p.hosts = "all"
    t = Task()
    t.action = "test"
    t.name = "test-task"
    b = Block()
    b.block = [t]
    p.block = [b]
    pi = PlayIterator(p)
    assert isinstance(pi, PlayIterator)


# Generated at 2022-06-10 23:14:41.393480
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
  # There are no unit tests for this method.
  pass


# Generated at 2022-06-10 23:15:22.205617
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    host_state = dict()
    host_state['host'] = 'fake_host'
    host_state['play'] = dict()
    host_state['play']['id'] = 'fake_play'
    host_state['play']['roles'] = list()
    host_state['play']['connection'] = 'fake_connection'
    host_state['play']['max_fail_percentage'] = 0
    host_state['play']['gather_facts'] = 'fake_gather_facts'
    host_state['play']['serial'] = 'fake_serial'
    host_state['play']['environment'] = list()
    host_state['play']['block'] = list()
    host

# Generated at 2022-06-10 23:15:23.489915
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    pass # TODO: no coverage



# Generated at 2022-06-10 23:15:32.731828
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method PlayIterator.is_failed
    '''
    print("<html>")
    print("Test PlayIterator.is_failed:", end="")

    # initialize data

    class Host:
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return self.name

    class MyTask:
        def __init__(self, vars):
            self.vars = vars
        def __str__(self):
            return "<MyTask %s>" % self.vars

    class MyBlock:
        def __init__(self, level, block=None, rescue=None, always=None):
            self.level = level
            self.block = block
            self.rescue = rescue
            self.always = always

# Generated at 2022-06-10 23:15:45.456788
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    test_play = Play().load({
            'name': 'test play',
            'hosts': 'all',
            'connection': 'local',
            'tasks': [
                {'action': {'module': 'setup'}},
                {'action': {'module': 'command', 'args': {'echo': 'foo'}}},
                {'action': {'module': 'command', 'args': {'echo': 'bar'}}}
            ]
        }, variable_manager=None, loader=None)

# Generated at 2022-06-10 23:15:54.944057
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    blocks = []
    blocks.append(Block())
    blocks.append(Block())
    blocks.append(Block())
    host_state = HostState(blocks)
    host_state.cur_block = 1
    host_state.cur_regular_task = 2
    host_state.cur_rescue_task = 3
    host_state.cur_always_task = 4
    host_state.run_state = 5
    host_state.fail_state = 6
    host_state.pending_setup = True
    host_state.tasks_child_state = 7
    host_state.rescue_child_state = 8
    host_state.always_child_state = 9
    host_state.did_rescue = True
    host_state.did_start_at_task = True

# Generated at 2022-06-10 23:15:55.532479
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass

# Generated at 2022-06-10 23:16:08.332474
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    class HostStateTest:
        def __init__(self):
            self.cur_block = 0
            self.cur_regular_task = 1
            self.cur_rescue_task = 2
            self.cur_always_task = 3
            self.run_state = 0
            self.pending_setup = True
            self.tasks_child_state = None
            self.rescue_child_state = None
            self.always_child_state = None
            self.fail_state = 1
            self.did_rescue = False
            self.did_start_at_task = True

    t = HostStateTest()
    t_str = str(t)


# Generated at 2022-06-10 23:16:18.452149
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    p = PlayIterator()
    assert p.is_any_block_rescuing(p.get_host_state(Host('localhost'))) == False
    assert p.is_any_block_rescuing(p.get_host_state(Host('localhost'), blocks=[Block(task_list=[])])) == False
    
    # resuce state
    assert p.is_any_block_rescuing(p.get_host_state(Host('localhost'), blocks=[Block(
        rescue=[],
        tasks=[],
        always=[])])) == False
    assert p.is_any_block_rescuing(p.get_host_state(Host('localhost'), blocks=[Block(
        rescue=[],
        tasks=[],
        always=[])],
        run_state=p.ITERATING_RESCUE)) == True

# Generated at 2022-06-10 23:16:19.841637
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    assert PlayIterator().get_host_state(None) == None

# Generated at 2022-06-10 23:16:33.314985
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():

    # This needs to return an iterator we can step over to test the code path
    class FakePlay(object):
        def __init__(self):
            self.hosts = ["a", "b", "c"]
        def get_hosts(self, pattern, ignore_errors=False):
            return self.hosts

    class FakeHost(object):
        def __init__(self, name):
            self.name = name
            self.vars = {}

    # Basic test of one host with no tasks
    p = PlayIterator()
    p.play = FakePlay()
    p._get_next_task_from_state = lambda x, y: (x, None)
    p._host_states = {
        'a': HostState(blocks=[]),
    }

# Generated at 2022-06-10 23:17:38.778136
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    iterator = PlayIterator(None, [], [])
    iterator._host_states = {
        'host1': HostState(fail_state=iterator.FAILED_TASKS),
        'host2': HostState(fail_state=iterator.FAILED_NONE),
        'host3': HostState(fail_state=iterator.FAILED_SETUP),
    }
    assert sorted(iterator.get_failed_hosts()) == ['host1','host3']



# Generated at 2022-06-10 23:17:51.633688
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    state1 = HostState([])
    assert str(state1) == \
        "HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False"
    state2 = HostState([])
    state2.cur_block = 1
    state2.cur_regular_task = 2
    state2.cur_rescue_task = 3
    state2.cur_always_task = 4
    state2.run_state = 1
    state2.fail_state = 2
    state2.pending_setup = True

# Generated at 2022-06-10 23:17:52.499668
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    pass

# Generated at 2022-06-10 23:18:04.219039
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    iterator = PlayIterator()
    host = Host('test_host')
    host.name = 'test_host'
    iterator._host_states[host.name] = HostState()
    iterator._host_states[host.name].run_state = 'ITERATING_TASKS'
    iterator._host_states[host.name].fail_state = 'FAILED_TASKS'
    """ :type : HostState"""
    res = iterator.is_failed(host)
    if res:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_PlayIterator_is_failed()

# Generated at 2022-06-10 23:18:15.505049
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from ansible.playbook import Play
    pb = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
           dict(action=dict(module='ping'), register='ping_result'),
           dict(action=dict(module='setup'), register='setup_result'),
           dict(action=dict(module='command', args=dict(echo='boo')))
        ],
    ), variable_manager=None, loader=None)

    # No hosts should give an exception
    try:
        pi = PlayIterator(None)
        assert False, "Expected exception"
    except AssertionError:
        pass

    # Empty hosts should give an exception

# Generated at 2022-06-10 23:18:23.385654
# Unit test for method is_any_block_rescuing of class PlayIterator

# Generated at 2022-06-10 23:18:35.853727
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-10 23:18:47.539148
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    hosts = [
        # a bunch of fake hosts, each with a different number of tasks
        Host(name="fake_host_0"), Host(name="fake_host_1"), Host(name="fake_host_2"),
        Host(name="fake_host_3"), Host(name="fake_host_4"), Host(name="fake_host_5"),
    ]

    tasks = [
        [ Task() for x in range(4) ],
        [ Task() for x in range(4) ],
        [ Task() for x in range(4) ],
        [ Task() for x in range(4) ],
        [ Task() for x in range(4) ],
        [ Task() for x in range(4) ],
    ]

    tasks_copy = [ list(ts) for ts in tasks ]
    # and now make sure we get the

# Generated at 2022-06-10 23:18:58.773358
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    p = Play()
    p.hosts = ['testhost']
    p.connection = 'testconnection'
    p.tasks = [
        dict(action=dict(module='test', args='args'), register='r'),
        dict(action=dict(module='test2', args='args2'), register='r2')
    ]

    pi = PlayIterator(p)
    assert len(pi._blocks) == 1

    block, task_cache = pi._blocks[0], {}
    pi._cache_block_tasks(block, task_cache, [], dict(testhost=Host('testhost', port=0), someotherhost=Host('someotherhost', port=1)))

# Generated at 2022-06-10 23:19:11.040874
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    new_play = Play().load(dict(
        name = 'testing play',
        hosts = 'all',
        gather_facts = 'yes',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=VariableManager(), loader=DummyLoader())
    new_iterator = PlayIterator(new_play)
    new_iterator.get_next_task_for_host(Host('test host'))
    new_iterator.get_next_task_for_host(Host('test host'))
    new_iterator.get_next_task_for_host(Host('test host'))

# Generated at 2022-06-10 23:21:18.269905
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    from unit_tests.mock import MagicMock
    from ansible.playbook.block import Block

    itr = PlayIterator()
    itr._play = MagicMock()
    itr._host_states = dict()

    state = HostState(blocks=[])
    state.run_state = itr.ITERATING_RESCUE
    assert itr.is_any_block_rescuing(state)

    state = HostState(blocks=[])
    state.run_state = itr.ITERATING_ALWAYS
    assert itr.is_any_block_rescuing(state)

    state = HostState(blocks=[])
    state.run_state = itr.ITERATING_TASKS
    state.tasks_child_state = HostState(blocks=[])
    state.tasks_child_

# Generated at 2022-06-10 23:21:31.644057
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    def check_blocks(pi, expected_blocks):
        if len(pi.play.blocks) != len(expected_blocks):
            raise AssertionError("Block count mismatch! %d != %d" % (len(pi.play.blocks), len(expected_blocks)))
        for (i, b) in enumerate(expected_blocks):
            if not isinstance(b, list):
                b = [b]
            if not isinstance(pi.play.blocks[i].block, list):
                pi.play.blocks[i].block = [pi.play.blocks[i].block]
            if len(pi.play.blocks[i].block) != len(b):
                raise AssertionError("Inner block count mismatch! %d != %d" % (len(pi.play.blocks[i].block), len(b)))


# Generated at 2022-06-10 23:21:42.655085
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
	play = Play()
	play.hosts = ['localhost']
	host = Host('localhost')
	host.name = 'localhost'
	host.groups = {'all': 'all'}
	task = Task()
	task.action = 'test action'
	task.atomic = True
	task.module_name = 'test module'
	task.module_args = 'test args'
	task.module_vars = {'test k': 'test v'}
	task.register = 'test register'
	task.notify = ['test notify']
	task.roles = ['test role']
	task.tags = ['test tag']
	task.when = 'test when statement'
	task.delegate_to = 'test delegate to host'
	task.first_available_file = 'test file'
	task.local

# Generated at 2022-06-10 23:21:54.439740
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    pi = PlayIterator()
    host = Host(name='local')
    group = Group(name='all')
    group.add_host(host)
    inventory = Inventory(host_list=[])
    inventory.add_group(group)
    play_context = PlayContext()

# Generated at 2022-06-10 23:22:03.026183
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    play_datastructure = create_play_ds()
    my_play = Play().load(play_datastructure, variable_manager=VariableManager(), loader=DictDataLoader())
    my_play.ITERABLE_PLAYBOOK = False
    pi = PlayIterator(my_play)

    host_state = pi.get_host_state(C.LOCALHOST)
    assert host_state.cur_block == 0
    assert host_state.cur_regular_task == 0
    assert host_state.cur_rescue_task == 0
    assert host_state.cur_always_task == 0
    assert host_state.run_state == 0
    assert host_state.fail_state == 0
    assert host_state.tasks_child_state is None
    assert host_state.rescue_child_state is None


# Generated at 2022-06-10 23:22:14.830227
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    blocks = []
    setup_block = Block(None, [Task(), Task()])
    tasks_block = Block(None, [Task(), Task(), Task()])
    rescue_block = Block(None, [Task(), Task()])
    always_block = Block(None, [Task(), Task()])
    blocks.append(setup_block)
    blocks.append(tasks_block)
    blocks.append(rescue_block)
    blocks.append(always_block)
    hs = HostState(blocks)
    hs.cur_block = 1
    hs.cur_regular_task = 2
    hs.cur_rescue_task = 1
    hs.cur_always_task = 0
    hs.run_state = PlayIterator.ITERATING_ALWAYS

# Generated at 2022-06-10 23:22:18.615243
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    print("Testing method mark_host_failed of class PlayIterator")
    # get instance
    play_iterator = PlayIterator()
    # set test values
    # set up object
    play_iterator.setup()

    play_iterator.mark_host_failed(None)


# Generated at 2022-06-10 23:22:19.315452
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
        pass

# Generated at 2022-06-10 23:22:27.683763
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.inventory

    p = ansible.playbook.Play()
    p._included_files = dict(
        a='a',
        b='b',
    )
    p._basedir = 'baz'
    p.vars = dict(
        a='a',
        b='b',
    )
    p._post_validate_callbacks = ['foo', 'bar']
    p._handlers = ['baz', 'qux']
    p._tasks = ['t1', 't2']
    p._tasks_include = ['t3', 't4']