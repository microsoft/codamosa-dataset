

# Generated at 2022-06-10 23:13:06.111729
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    my_playbook = PlaybookExecutor(10)
    my_playbook.host_blocks = {}

    for i in range(0, 2):
        my_playbook.host_blocks[i] = [Block(i, Task('my_task'))]


# Generated at 2022-06-10 23:13:19.618445
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    """
    Unit test for PlayIterator.mark_host_failed
    """
    #from ansible.playbook.play_iterator import PlayIterator
    #from ansible.cp.cloudplatform.Play import Play
    #from ansible.cp.cloudplatform.Host import Host
    #from ansible.vars.manager import VariableManager
    #from ansible.inventory.manager import InventoryManager
    #from ansible.inventory.host import Host as InventoryHost
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.utils.display import Display

    display = Display()


# Generated at 2022-06-10 23:13:30.906657
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    h = ansible.hosts.Host(name="localhost",port=22)
    p = ansible.playbook.Play()
    p.get_active_handlers = lambda : []
    m = ansible.playbook.Playbook()
    i = ansible.playbook.PlayIterator(m, p, all_vars={}, all_group_vars={})
    i.get_active_handlers = lambda : []
    i._host_states = {}
    i._host_state_map = {}
    h.name = 'localhost'
    i.get_host_state(h)
    assert i._host_states['localhost']._play == p
    assert i._host_states['localhost'].run_state == PlayIterator.ITERATING_SETUP
    assert i._host_states['localhost'].fail_

# Generated at 2022-06-10 23:13:43.787890
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play = Play().load(dict(name="test play", hosts='all', gather_facts='no', tasks=[]), variable_manager=VariableManager(), loader=None)
    iterator = PlayIterator(play)
    host = Host('localhost')
    assert iterator.get_next_task_for_host(host) == None

    play = Play().load(dict(name="test play", hosts='all', gather_facts='no', tasks=[dict(action='setup')]), variable_manager=VariableManager(), loader=None)
    iterator = PlayIterator(play)
    host = Host('localhost')
    (state, task) = iterator.get_next_task_for_host(host)
    assert task.action == 'setup'
    assert iterator.get_next_task_for_host(host) == None


# Generated at 2022-06-10 23:13:55.697722
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    t0 = time.time()

    p = Play.load('test/playbooks/test_iterator.yml', variable_manager=VariableManager(), loader=DataLoader())
    i = PlayIterator(p)

    host = p.get_variable_manager().get_vars(host=MagicMock())

    host.name = 'testhost'
    host.address = 'testhost'
    host.host_name = 'testhost'
    host.port = 22
    host._variable_manager = {}
    host._variable_manager['hostvars'] = {}

    # Test nothing set
    state = HostState()
    i._host_states[host.name] = state

    assert i.get_host_state(host) is i._host_states[host.name]

# Generated at 2022-06-10 23:14:08.023089
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    hosts = [
        Host('server0'),
        Host('server1'),
        Host('server2')
    ]
    play = Play()
    play.add_task(Task().set_name('task0'))
    play.add_task(Task().set_name('task1'))
    play.add_task(Task().set_name('task2'))
    play.add_task(Task().set_name('task3'))
    play.add_task(Task().set_name('task4'))
    play.add_task(Task().set_name('task5'))
    play.add_task(Task().set_name('task6'))
    play.add_task(Task().set_name('task7'))

    # create a play iterator
    pi = PlayIterator()
    pi._play = play

# Generated at 2022-06-10 23:14:16.896570
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    body of test
    '''
    my_var = None
    assert (isinstance(my_var, object))
    #############
    # ToDo:
    # add your own test cases here...
    # e.g.
    # my_var = True
    # assert (my_var == True)
    # or
    # from unittest import mock
    # my_var = mock.Mock()
    # assert(my_var.my_method() == 'success')
    #############
    return

# Generated at 2022-06-10 23:14:20.520140
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    Unit test for method get_next_task_for_host of class PlayIterator
    '''
    pass


# Generated at 2022-06-10 23:14:32.720747
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play = Play()
    iterator = PlayIterator(play)
    host = Host('testhost')
    state = iterator.get_host_state(host)
    state.run_state = iterator.ITERATING_TASKS
    state._blocks[0]._block[0] = dict(
        state._blocks[0]._block[0],
        action='myaction0',
    )
    state._blocks[0]._block[1] = dict(
        state._blocks[0]._block[1],
        action='myaction1',
    )
    state._blocks[0]._block[2] = dict(
        state._blocks[0]._block[2],
        action='myaction2',
    )
    state.cur_regular_task = 1

# Generated at 2022-06-10 23:14:43.699224
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    attr = dict(
        _play=dict(vars=dict(port=dict(default=22,name='port',prompt=''))),
        _hosts=set()
        )
    play = Play().load(dict(hosts='localhost',name='test_is_failed',connection='local',vars=attr['_play']['vars']),variable_manager=MockVariableManager(),loader=MockLoader())
    play._iterator = PlayIterator(play)
    play.post_validate(MockVariableManager())
    play._iterator._hosts = [Host(name='localhost')]
    play._iterator.get_next_task_for_host(Host(name='localhost'))

    assert play._iterator.is_failed(Host(name='localhost')) == False

# Generated at 2022-06-10 23:15:15.569524
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    pass


# Generated at 2022-06-10 23:15:28.369725
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    host = Host(name='testhost')
    host.set_variable('foo', 'bar')
    host.set_variable('ansible_foo', 'bar')
    play = dict(
        name = "foobar",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami')),
        ]
    )

# Generated at 2022-06-10 23:15:42.014453
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    # display.debug('test_HostState___eq__')
    class check_HostState(HostState):
        def __init__(self, blocks):
            HostState.__init__(self, blocks)

    def check(src, dest, expected):
        res = src.__eq__(dest)
        if res != expected:
            display.debug('test_HostState___eq__ %s %s %s %s' % (src, dest, expected, res))
            assert False

    blocks = [Block() for i in range(2)]
    src = check_HostState(blocks)
    dest = check_HostState(blocks)

    src.cur_block = 2
    check(src, dest, False)
    src.cur_block = 0
    dest.cur_block = 2
    check(src, dest, False)


# Generated at 2022-06-10 23:15:47.554001
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
  play_iterator = PlayIterator(play=None, inventory=None, variable_manager=None, all_vars=dict(), start_at_task=None)
  state = object()
  try:
    play_iterator.is_any_block_rescuing(state=state)
    assert False, "Exception expected"
  except:
    pass

# Generated at 2022-06-10 23:15:48.194004
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    pass

# Generated at 2022-06-10 23:15:56.892207
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host = Mock()
    host.name = 'testhost'
    play = Mock()
    play._play_context = dict()
    iterator = PlayIterator(play)
    task = PlaybookTask("test_task", "test_data")
    block1 = Block('test_block1', [task], [], [])
    block2 = Block('test_block2', [task], [], [])

    # case 1: block has not yet started
    # expected result: False
    state = HostState(blocks=[block1])
    assert iterator.is_any_block_rescuing(state) == False

    # case 2: block is running
    # expected result: False
    state = HostState(blocks=[block1])
    state.cur_block = 0
    state.cur_regular_task = 0
    state.cur_res

# Generated at 2022-06-10 23:16:10.116032
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    iterator = PlayIterator(play=Play().load(caller_dir=(test_dir / 'data' / 'plays'), var_manager=VariableManager(), loader=None))
    iterator._is_new_play = False
    iterator._play = Play()
    iterator._play._basedir = 'test_PlayIterator_get_host_state-basedir'
    iterator._play._included_file_paths = []
    iterator._play._role_paths = []
    iterator._play.hosts = ['127.0.0.1']
    iterator._play.tasks = [{'action': {'__ansible_module__': 'ping'}}]
    iterator._play._included_file_paths = 'test_PlayIterator_get_host_state-included_file_paths'
    iterator._play._role_paths

# Generated at 2022-06-10 23:16:11.526150
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # TODO: implement this test
    assert False


# Generated at 2022-06-10 23:16:20.571969
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
  test_host = "testhost"
  test_tasks_list = [
    {
      "name": "test_task_1"
    },
    {
      "include_tasks": "test_task_2.yml"
    },
    {
      "name": "test_task_3"
    },
  ]
  def test_PlayIterator_is_any_block_rescuing_iterate_through_blocks(iterating_task_state, test_result, rescue_child_state=None, always_child_state=None):
    # current host state is iterating_task_state
    if iterating_task_state is None:
      state = None

# Generated at 2022-06-10 23:16:33.634739
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    pb = Playbook()
    pl = Play()
    pl.name = "test_play"
    pb.plays = [pl]
    host1 = Host("test_host1")
    host2 = Host("test_host2")
    hosts = [host1, host2]
    pi = PlayIterator(pb, hosts)
    assert pi.hosts == hosts
    assert pi.playbook == pb
    assert pi.play == pl
    assert pi.get_next_task_for_host(host1) == (None, None)
    assert pi.get_next_task_for_host(host1) == (None, None)
    assert pi.get_next_task_for_host(host2) == (None, None)


# Generated at 2022-06-10 23:17:15.789323
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    i = PlayIterator()
    assert isinstance(i.get_host_state("foo"), HostState)



# Generated at 2022-06-10 23:17:27.419353
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host = C.DEFAULT_HOST_NAME
    block1 = Block(Block(Task('t11'), rescue=[Task('t21'), Task('t22')], always=[Task('t31'), Task('t32')]), rescue=[Task('r11'), Task('r12')], always=[Task('a11'), Task('a12')])
    block2 = Block(Block(Task('t12'), rescue=[], always=[]), rescue=[Task('r13'), Task('r14')], always=[])
    block3 = Block(Task('t13'), rescue=[Task('r14'), Task('r15')], always=[])

# Generated at 2022-06-10 23:17:35.640612
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    from ansible.playbook.block import Block
    from ansible.playbook.role.task import Task
    from ansible.playbook.play import Play

    task1 = Task()
    task2 = Task()
    block1 = Block(play=Play().load(dict(
        name = "Test block1",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='This is a task1')))
        ]
    )))

# Generated at 2022-06-10 23:17:49.792945
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-10 23:18:04.337135
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pb = Playbook()
    play = Play()
    block = Block()
    play.block = block

    p = PlayIterator(pb, play)

    class FakeHost(object):
        name = 'testhost'
    h = FakeHost()
    t1 = Task()
    t2 = Task()
    t3 = Task()
    t4 = Task()
    t5 = Task()

    block.block = [t1, t2]
    block.rescue = [t3]
    block.always = [t4]

    # Tests adding tasks to a non-failed play state
    p.set_host_state(h, HostState(blocks=[block]))

    p.add_tasks(h, [t5])

# Generated at 2022-06-10 23:18:06.358247
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''test_PlayIterator_is_failed'''
    pass

# Generated at 2022-06-10 23:18:17.229459
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    '''
    unit test for method add_tasks of class PlayIterator
    '''
    import mock

    with mock.patch('ansible.playbook.play_context.PlayContext') as mock_play_ctx:
        pi = PlayIterator()

        # Test Case : 1
        hs = pi.get_host_state(mock.MagicMock(name='host_1'))
        hs = hs._replace(run_state=pi.ITERATING_ALWAYS)
        hs = hs._replace(cur_block=0)
        hs = hs._replace(cur_always_task=1)
        hs = hs._replace(cur_regular_task=0)
        hs = hs._replace(cur_rescue_task=0)

# Generated at 2022-06-10 23:18:24.020307
# Unit test for method get_host_state of class PlayIterator

# Generated at 2022-06-10 23:18:36.299749
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    hosts = dict(
        localhost = dict(
            foo = dict(
                bar = dict(),

            ),
        )
    )
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = []
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    #print(play._variable_manager._fact_cache)
    #play._variable_manager._fact_cache = dict(localhost = dict(ansible_all_ipv4_addresses = ['127.0.0.1'], ansible_all_ipv6_addresses = []))
    #print(play._variable_manager._fact_cache)
    tqm = None
    loader = None
    variable

# Generated at 2022-06-10 23:18:47.846288
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    '''
    Constructor of PlayIterator
    '''
    host_1 = Host("host_1")
    host_2 = Host("host_2")
    host_3 = Host("host_3")
    host_4 = Host("host_4")
    host_5 = Host("host_5")
    host_6 = Host("host_6")
    host_7 = Host("host_7")
    host_8 = Host("host_8")
    host_9 = Host("host_9")
    host_10 = Host("host_10")
    host_11 = Host("host_11")
    host_12 = Host("host_12")

# Generated at 2022-06-10 23:19:58.473643
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # mock a play
    class MockPlay(object):
        pass
    mock_play = MockPlay()

    # mock a block
    class MockBlock(object):
        pass
    mock_block1 = MockBlock()
    mock_block2 = MockBlock()
    mock_block3 = MockBlock()

    # mock a task
    class MockTask(object):
        pass
    mock_task1 = MockTask()
    mock_task2 = MockTask()
    mock_task3 = MockTask()

    # make a HostState with a block containing a task
    mock_host_state = HostState(blocks=[mock_block1])
    mock_host_state.run_state = PlayIterator.ITERATING_TASKS
    mock_block1.block = [mock_task1, mock_task2, mock_task3]

# Generated at 2022-06-10 23:20:12.741460
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Purpose: Test that the iterator properly sets the failed state on the host.
    #   Asserts that it doesn't crash
    mock_play = MagicMock()
    mock_play._removed_hosts = []
    mock_play._iterator = None
    mock_play._tqm = None
    mock_play._included_paths = None
    pi = PlayIterator(mock_play)
    mock_host, mock_state = MagicMock(), MagicMock()
    mock_host.name = "test_host"
    mock_state.run_state = 'ITERATING_TASKS'
    pi._host_states[mock_host.name] = mock_state
    pi.mark_host_failed(mock_host)
    assert mock_host.name in pi._play._removed_hosts

# Generated at 2022-06-10 23:20:22.403492
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Make a fake iterator for testing purposes
    fake_iterator = FakeIterator()

    # Make a fake play to pass to the iterator
    play_obj = Play()
    pattern = 'all'
    inventory = Inventory(loader=DictDataLoader({}))
    inventory.add_host('foo')
    inventory.add_host('bar')
    inventory.add_host('baz')

    play = Play().load(dict(
        name = "test play",
        hosts = pattern,
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami'))
            ]
        ),
        variable_manager=VariableManager(),
        loader=DictDataLoader())

    # Constructor for PlayIterator
    p

# Generated at 2022-06-10 23:20:34.113495
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    ''' unit tests for method get_host_state of the PlayIterator class
    '''
    MOCK_HOST = Mock(name='host')
    MOCK_PLAY = Mock(name='Play', spec=Play)
    MOCK_PLAY.get_blocks.return_value = [HostState()]
    MOCK_PLAY_ITERATOR = PlayIterator(play=MOCK_PLAY, inventory=None)
    # no state, returns a new one
    assert isinstance(MOCK_PLAY_ITERATOR.get_host_state(MOCK_HOST), HostState)
    # state exists, returns it
    MOCK_PLAY_ITERATOR._host_states[MOCK_HOST.name] = HostState()

# Generated at 2022-06-10 23:20:42.514444
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''
    # suite_setup, setup and teardown are ok to be empty, but tasks is required.
    pb = Playbook.load(dict(
        name='test_pb',
        hosts=['host1', 'host2'],
        gather_facts='no',
        tasks=[dict(action=dict(module='debug', args='msg=foo'))],
        suite_setup=[],
        setup=[],
        teardown=[]
    ))
    p = Play().load(pb.get_plays()[0], pb)

    pi = PlayIterator(p, None)
    
    def check_host_failed(pi, host):
        assert host in pi.get_failed_hosts()

# Generated at 2022-06-10 23:20:55.352304
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    hosts = [host1, host2, host3]
    play = Play().load(dict(
        name = "foobar",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=''), register='setup_facts')
        ]
    ), variable_manager=variable_manager, loader=loader)

    pi = PlayIterator(play, variable_manager=variable_manager)
    assert len(pi._play._tasks) == 1
    assert pi._play._tasks[0].name == 'setup'
    assert pi._play._tasks[0].action == 'setup'

    tasks = list(pi.get_next_task_for_host(host1))
    assert len(tasks) == 1

# Generated at 2022-06-10 23:21:06.651440
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    """
    PlayIterator._get_next_task_for_host(host, peek=False)
    """

    # setup
    host1 = Host('host1')
    host2 = Host('host2')
    host1vars = dict(a=1, b=2)
    host2vars = dict(a=2, b=1)
    iterator = PlayIterator()
    iterator._play = MagicMock()
    iterator._play._variable_manager = VariableManager()
    iterator._play.hosts = [host1, host2]
    iterator._play.get_vars.return_value = dict(foo='bar')

    # Run tests with different combinations of hosts/blocks

# Generated at 2022-06-10 23:21:10.241116
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # The remainder of these test cases are considered legacy and need to
    # be ported to the new 2.0 play code at some point.
    # https://github.com/ansible/ansible/issues/17759
    foo = 'bar'
    assert foo == 'bar'


# Generated at 2022-06-10 23:21:18.485245
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from ansible.playbook import Play, Playbook
    from ansible.inventory import Host, Group, Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = Playbook.loader
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    test_host = Host('testhost')
    test_host.set_variable('foo', 'bar')
    inventory.add_host(test_host)


# Generated at 2022-06-10 23:21:28.933717
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    Unit test for method get_failed_hosts of class PlayIterator
    '''
    pi = PlayIterator()
    r = pi._host_states = {'host1': 'hn1', 'host2': 'hn2', 'host3': 'hn3'}
    r.keys = [lambda : ( 'host1', 'host2', 'host3' )]
    r.values = [lambda : ( 'hn1', 'hn2', 'hn3' )]
    pi._check_failed_state = lambda state: 'hn2' == state
    assert {'host2': True} == pi.get_failed_hosts()
