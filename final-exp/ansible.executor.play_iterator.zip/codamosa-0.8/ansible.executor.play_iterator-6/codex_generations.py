

# Generated at 2022-06-10 23:13:39.394230
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # This module is *not* a test case class.  Testing functions in the module
    # directly is the way to go.
    play = Play().load(
        dict(
            name = 'test play',
            hosts = 'somehost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
                dict(action=dict(module='shell', args='ls foobar')),
            ]
        )
    )

    play.post_validate(play.playbook, ('somehost',))

    iterator = PlayIterator()

    # Test when PlayIterator._check_failed_state() returns False

# Generated at 2022-06-10 23:13:50.318059
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    cat = lambda *args: args
    hosts = [cat('host1'), cat('host2'), cat('host3')]
    iterator = PlayIterator(cat(play=dict(name='dummy_iterator_play', hosts=hosts)),
                            cat(inventory=cat(get_hosts=lambda x: hosts)),
                            cat(loader=cat(path_dwim=lambda x: x)))
    # If a host has a failure, it should move to the rescue block
    host1 = hosts[0]
    iterator._host_states[host1.name] = HostState(host=host1)
    iterator._host_states[host1.name].run_state = PlayIterator._ITERATING_TASKS
    iterator._host_states[host1.name].cur_block = 0

# Generated at 2022-06-10 23:14:02.137234
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # create a play that we can try to get tasks from
    play = Play()
    play.vars = {}
    play.connection = 'smart'
    play.hosts = [ 'foo', 'bar', 'baz' ]

    # create a task
    t1 = Task()
    t1.action = 'shell'
    t1.args['free_form'] = "echo hi"

    # create a task with a loop
    t2 = Task()
    t2.action = 'shell'
    t2.args['free_form'] = "echo {{ item }}"
    t2.register = 'shell_out'
    t2.loop = { 'name': 'shell_out.stdout_lines' }

    # create a handler
    t3 = Task()
    t3.action = 'meta'
    t3

# Generated at 2022-06-10 23:14:15.167431
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Unit test for method cache_block_tasks of class PlayIterator
    '''
    # Insert your test code below
    # 1. Define target input parameters and/or variables

# Generated at 2022-06-10 23:14:23.214090
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    """
    PlayIterator.is_any_block_rescuing() returns True when in rescue mode
    """
    p = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='foo'))),
        ],
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    tqm = None

# Generated at 2022-06-10 23:14:36.078227
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    h = Host('host')

# Generated at 2022-06-10 23:14:45.814425
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # This stub will raise an exception if the code tries to write to stdout or stderr.
    def _fake_display(self, msg, *args, **kwargs):
        pass
    display.Display.display = _fake_display
    # This stub will raise an exception if the code tries to print a deprecation warning.
    def _fake_deprecated(self, msg, *args, **kwargs):
        pass
    display.DeprecatedCall.deprecated = _fake_deprecated
    # This stub will raise an exception if the code tries to write any log messages.
    def _fake_logger(self, msg, *args, **kwargs):
        raise Exception("Logging messages are not allowed in unit tests.")
    logger.Logger.write = _fake_logger

    iterator = PlayIterator()
    play = Play()
   

# Generated at 2022-06-10 23:14:54.206675
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    # a simple Block object for testing
    test_block = Block(
        rescue=[
            Task(),
            Task(),
        ],
        always=[
            Task(),
            Task(),
        ]
    )
    # create a test PlayIterator object
    test_iterator = PlayIterator()
    # test for normal case
    test_iterator.cache_block_tasks(test_block)
    assert test_iterator._cached_tasks[test_block] == [
        Task(),
        Task(),
        Task(),
        Task()
    ]



# Generated at 2022-06-10 23:15:05.189251
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    iterator = PlayIterator()
    hs = HostState(blocks=[Block(task_include='all')])
    hs.fail_state = PlayIterator.FAILED_NONE
    hs.tasks_child_state = HostState(blocks=[Block(task_include='all')])
    hs.tasks_child_state.tasks_child_state = HostState(blocks=[Block(task_include='all')])
    hs.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_RESCUE
    hs.tasks_child_state.tasks_child_state.rescue_child_state = HostState(blocks=[Block(task_include='all')])
    hs.tasks_child_state.tasks_child_state.rescue_child_

# Generated at 2022-06-10 23:15:10.586118
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    assert(str(HostState([])) == '''HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_COMPLETE, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (), rescue child state? (), always child state? (), did rescue? False, did start at task? False''')


# Generated at 2022-06-10 23:15:54.587938
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Unit test for method _is_any_block_rescuing of class PlayIterator.
    '''
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-10 23:16:06.494081
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # NOT Using the cache - we're in the middle of a play as far as the iterator is concerned
    # Replace with a mock object
    a = Host('localhost')
    a.name = 'localhost'
    a.vars = {'ansible_connection': 'local'}
    b = Host('test.example.org')
    b.name = 'test.example.org'
    b.vars = {'ansible_connection': 'local'}
    c = Host('localhost')
    c.name = 'another.example.org'
    c.vars = {'ansible_connection': 'local'}
    my_hosts = { 'localhost':a, 'test.example.org':b, 'another.example.org':c }
    # Replace with a mock object
    def host_state(name):
        return {}

# Generated at 2022-06-10 23:16:17.469534
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    it = PlayIterator()
    block1 = Block()
    block1.block = [Task(), Task(), Task(), Task()]
    block2 = Block()
    block2.block = [Task(), Task(), Task(), Task()]
    host = Host('127.0.0.1')
    hoststate = HostState(blocks=[block1, block2])
    it._host_states[host.name] = hoststate
    task_list = [Task()]
    it.add_tasks(host, task_list)
    assert it._host_states[host.name]._blocks[0].block == [Task(),Task(),Task(),Task(),Task()]
    assert it._host_states[host.name]._blocks[1].block == [Task(),Task(),Task(),Task()]


# test_PlayIterator_add_tasks()

# Generated at 2022-06-10 23:16:29.819069
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
	_data = copy.deepcopy(get_test_data())
	_data['plays'][0]['tasks'] = [make_task(_data['tasks'][0], 0), make_task(_data['tasks'][1], 1)]
	_data['plays'][0]['tasks'].append(make_task(_data['tasks'][2], 2))
	_data['plays'][0]['tasks'].append(make_task(_data['tasks'][3], 3))
	_data['plays'][0]['tasks'].append(make_task(_data['tasks'][4], 4))
	_loader = DataLoader()
	_passwords = dict(vault_pass='secret')

# Generated at 2022-06-10 23:16:39.093080
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    try:
        from . import hosts as __hosts__
        from . import blocks as __blocks__
        from . import tasks as __tasks__
        from . import loader as __loader__
    except ImportError:
        pass
    fake_play = Mock(spec=Play().__class__)
    fake_play._tqm = Mock(spec=TaskQueueManager().__class__)
    fake_play._tqm.load_callbacks = {}
    fake_play._tqm.send_callback = {}
    try:
        fake_play._tqm._stdout_callback = __loader__._create_global_plugin_loader.get_callback_plugin(fake_play._tqm.send_callback, 'stdout')
    except AttributeError:
        pass

# Generated at 2022-06-10 23:16:39.637498
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
  pass

# Generated at 2022-06-10 23:16:50.879334
# Unit test for method is_any_block_rescuing of class PlayIterator

# Generated at 2022-06-10 23:16:54.147837
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    state = HostState(blocks=[])
    assert state.is_any_block_rescuing(state) == False


# Generated at 2022-06-10 23:17:04.766444
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    host = Host("127.0.0.1")
    play = Play()
    play._included_paths = [{'file': './test/ansible/playbooks/test_play.yml', 'role': None, 'start': 0}]
    tqm = TaskQueueManager(inventory=Inventory(host_list=[host]), play=play, loader=None)

    tasks = [{'action': 'setup'}, {'action': 'ping'}, {'action': 'shell', 'args': 'whoami'}]
    block = Block(play=play, role=None, task_include=None, block=tasks)

    original_s = HostState(blocks=[block])
    s = tqm._get_state_from_task(host, original_s, None, tasks[0])

# Generated at 2022-06-10 23:17:07.869559
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pass # Skip for now

# Generated at 2022-06-10 23:17:54.590551
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Ensure PlayIterator.is_failed behaves as expected
    '''
    import pytest
    from ansible import inventory
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    test_hosts = ['localhost', 'somehost', 'someotherhost']
    test_tasks = [Task() for x in range(0, 10)]
    test_rescue = [Task() for x in range(0, 10)]
    test_always = [Task() for x in range(0, 10)]

    test_inventory = inventory.Inventory(test_hosts)

    test_blocks = [Block(task_list=test_tasks, rescue=test_rescue, always=test_always)]

# Generated at 2022-06-10 23:18:08.909805
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    def test_failed_state(host_state, expect):
        print("test_failed_state: %s expect: %s" % (host_state, expect))
        test_pi = PlayIterator()
        print("  result: %s" % test_pi._check_failed_state(host_state))
        assert expect == test_pi._check_failed_state(host_state)

    # Basic test
    test_state = PlayIterator.HostState(_blocks=[PlayIterator.Block()])
    test_failed_state(test_state, False)

    # Test when a HostState is returned with FAILED_TASK set
    test_state.fail_state = PlayIterator.FAILED_TASKS
    test_failed_state(test_state, True)

    # Test when a HostState is returned with FAILED_

# Generated at 2022-06-10 23:18:19.129451
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host = Host('localhost')
    setup_task = Task()
    setup_task._role_name = 'setup'
    task1 = Task()
    task1._role_name = 'task1'
    task2 = Task()
    task2._role_name = 'task2'
    task3 = Task()
    task3._role_name = 'task3'
    rescue_task1 = Task()
    rescue_task1._role_name = 'rescue_task1'
    rescue_task2 = Task()
    rescue_task2._role_name = 'rescue_task2'
    rescue_task3 = Task()
    rescue_task3._role_name = 'rescue_task3'
    always_task1 = Task()
    always_task1._role_name = 'always_task1'
    always_

# Generated at 2022-06-10 23:18:31.518782
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    i = PlayIterator()
    p = Play.load(dict(name="myplay", hosts='web', gather_facts='no', tasks=[dict(action='debug', msg='Hello World!')]), loader=None)
    host = Host(name="example.org", port=22)
    i._play = p
    i._tqm = None
    i._play_context = PlayContext()
    s = HostState(blocks=[p.compile()])
    s.run_state = PlayIterator.ITERATING_SETUP
    i._host_states = {host.name: s}
    assert not i.is_failed(host)
    return True

# Generated at 2022-06-10 23:18:39.862098
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():

    # create an inventory
    fake_loader = DictDataLoader({
        'hosts': '''
        localhost ansible_connection=local ansible_python_interpreter='/usr/bin/env python'
        host1
        ''',
        'vars': '''
        myvar1: "this is my var"
        myvar2: "this is another var"
        myvar3: "this is yet another var"
        myvar4: "this is yet yet another var"
        ''',
        'host_vars/host1': '''
        myvar4: "this is my host var"
        myvar5: "this is another host var"
        ''',
    })
    inv = Inventory(loader=fake_loader, variable_manager=VariableManager())

# Generated at 2022-06-10 23:18:53.896311
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
	play_iterator = PlayIterator(play=None)
	play_iterator._play_context = dict()
	play_iterator._play = Play()
	play_iterator._play.hostvars = dict()
	play_iterator._play._variable_manager = VariableManager(loader=None, inventory=None)
	play_iterator._play._variable_manager._fact_cache = dict()
	block = Block()
	block.block = [ dict(action='a', args=dict(key1='value1'), delegate_to='me'), dict(action='b', args=dict(key2='value2')) ]
	iterator_cache = dict()
	hosts = list()
	result = play_iterator.cache_block_tasks(block, iterator_cache, hosts)

# Generated at 2022-06-10 23:19:01.725430
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    TI = PlayIterator()
    host = Host('fake_host')
    state = HostState(host)

    # Check that if state doesn't have a tasks_child_state a copy of it is returned.
    assert_equal(TI.get_active_state(state), state)

    # Check that if state does have a tasks_child_state that state is returned.
    state.tasks_child_state = HostState(host)
    assert_equal(TI.get_active_state(state), state.tasks_child_state)

    # Check that if state does have a rescue_child_state that state is returned.
    state.tasks_child_state = None
    state.rescue_child_state = HostState(host)

# Generated at 2022-06-10 23:19:12.023073
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    host = Host(name="localhost")
    host.addr = "127.0.0.1"
    host_state = HostState(host) 
    host_state.vars = None
    host_state.state = None
    host_state.play = None
    host_state.task_blocks = []
    host_state.run_state = None
    host_state.cur_block = None
    host_state.cur_regular_task = None
    host_state.cur_rescue_task = None
    host_state.cur_always_task = None
    host_state.tasks_child_state = None
    host_state.rescue_child_state = None
    host_state.always_child_state = None
    host_state.fail_state = None
    host_state.did_rescue

# Generated at 2022-06-10 23:19:22.583900
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    import unittest
    class test_HostState___str___t(unittest.TestCase):
        def test_00(self):
            _test = HostState(['_blocks'])
            _test.cur_block = '_cur_block'
            _test.cur_regular_task = '_cur_regular_task'
            _test.cur_rescue_task = '_cur_rescue_task'
            _test.cur_always_task = '_cur_always_task'
            _test.run_state = PlayIterator.ITERATING_RESCUE
            _test.fail_state = PlayIterator.FAILED_ALWAYS
            _test.pending_setup = '_pending_setup'
            _test.tasks_child_state = '_tasks_child_state'
            _test

# Generated at 2022-06-10 23:19:34.396137
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # test with a state that is currently rescuing
    p = Playbook.load('test/ansible/playbooks/test_playbook.yml')
    pb = PlaybookIterator(playbook=p)
    pi = PlayIterator()
    pi.play = pb.play
    pi._tqm = pb._tqm
    pi._initialize_hosts(pb.get_hosts())
    pi._host_states['www.example.com'] = HostState(blocks=[pb.play._compiled_block_list[0]])
    pi._host_states['www.example.com'].run_state = PlayIterator.ITERATING_TASKS

# Generated at 2022-06-10 23:20:20.910254
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    '''
    Unit test for method add_tasks of class PlayIterator.
    '''

    # Setup
    host_state = HostState(blocks=[Block(block=[]), Block(block=[]), Block(block=[])])
    host_state.cur_block = 0
    host_state.cur_regular_task = 2
    expected_host_state = HostState(blocks=[Block(block=[]), Block(block=[]), Block(block=[])])
    expected_host_state.cur_block = 0
    expected_host_state.cur_regular_task = 2


    # Execution
    try:
        result = PlayIterator._insert_tasks_into_state(host_state, [])
    except:
        result = False

    # Verification
    assert not result

    # Cleanup
    # N/A

# Generated at 2022-06-10 23:20:33.622908
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play_iterator = PlayIterator(play=play)

    # test with state of None
    host = 'host'
    host_state_orig = None
    play_iterator._host_states[host] = host_state_orig
    play_iterator.mark_host_failed(host)
    assert play_iterator.is_failed(host) is True, \
           'mark_host_failed() failed with state of None'

    # test with setup task failed
    host = 'host'
    host_state_orig = HostState(host,
                                blocks=[Block(block=[Task()]),
                                        Block(block=[Task()])],
                                play=play_iterator._play,
                                run_state=PlayIterator.ITERATING_SETUP)
    play_iterator._host_states[host] = host_state_orig
   

# Generated at 2022-06-10 23:20:34.922523
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    item = HostState([1])
    print(item)


# Generated at 2022-06-10 23:20:42.979554
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Test that the mark_host_failed method properly sets the
    # fail_state and run_state of the HostState object.
    play = Play().load(dict(
        name = "test play",
        hosts = 'testhost',
        gather_facts = 'no',
        tasks = [dict(action=dict(module='shell', args='ls'))]
    ), variable_manager=VariableManager())
    iterator = PlayIterator(inventory=Inventory(host_list=[]), play=play, play_context=PlayContext())
    host = Host(name="testhost")
    host.set_variable('ansible_connection', 'local')
    iterator._host_states[host.name] = HostState(host=host)
    iterator._host_states[host.name].run_state = iterator.ITERATING_TASKS
   

# Generated at 2022-06-10 23:20:55.930700
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play().load(dict(
        hosts=dict(
            all=[
                dict(
                    name='host1',
                    gather_facts=False,
                    tasks=[
                        dict(action='shell', args='whoami')
                    ]
                )
            ]
        )
    ), variable_manager=VariableManager())

    tqm = TaskQueueManager(play)
    tqm._final_q = Queue()
    tqm._failed_hosts = dict()
    tqm._tqm_variables = dict()
    iterator = PlayIterator(play)
    iterator._play = play
    iterator._play_context = PlayContext(play=play)
    iterator._play._tqm = tqm

    host1 = Host(name='host1')
    host1.name = 'host1'
   

# Generated at 2022-06-10 23:21:07.103601
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # initial setup
    test_host = Host(name='host1')
    test_host.set_variable('taskvar', 'taskval')
    test_play_iter = PlayIterator()

# Generated at 2022-06-10 23:21:07.985462
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    pass

# Generated at 2022-06-10 23:21:20.130130
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    import tempfile
    import yaml
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    # XXX: get this from config file or command line
    results_dir = tempfile.gettempdir()
    variable_manager = VariableManager()
    loader = DataLoader()
    inv_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'ansible_hosts')
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=inv_file)

# Generated at 2022-06-10 23:21:33.618948
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    test_play = Play()
    test_play.name = 'test_play'
    test_block = Block()
    test_block.block = [Task()]
    test_play.add_block(test_block)

    test_iterator = PlayIterator(test_play)

    assert test_iterator._iterator._cur_block == 0
    assert test_iterator._iterator._cur_regular_task == 0

    new_task = Task()
    new_task.action = 'meta'
    new_task.args = 'reboot'

    test_iterator.add_tasks(None, [new_task])

    assert test_iterator._iterator._cur_block is 0

# Generated at 2022-06-10 23:21:37.559919
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Unit test for method is_any_block_rescuing of class PlayIterator
    '''
    # private method, no need to test
    pass