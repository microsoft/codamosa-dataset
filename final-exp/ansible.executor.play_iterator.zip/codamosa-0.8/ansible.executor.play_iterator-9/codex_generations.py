

# Generated at 2022-06-10 23:13:24.073961
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Test a None state
    play = Play()
    iterator = PlayIterator(play)
    state = iterator.get_active_state(None)
    assert state == None

    # Test a state with no child states
    state = HostState(blocks=[])
    active_state = iterator.get_active_state(state)
    assert state == active_state

    # Test a state with a non-iterating child state
    non_iterating_child_state = HostState(blocks=[])
    non_iterating_child_state.run_state = PlayIterator.ITERATING_COMPLETE
    state.tasks_child_state = non_iterating_child_state
    active_state = iterator.get_active_state(state)
    assert state == active_state

    # Test a state with an iterating child state
    iterating

# Generated at 2022-06-10 23:13:35.328640
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host

    p = Play().load({'name': 'myplay', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=dict(), loader=dict())
    pi = PlayIterator(p)

    # just make sure we get something sane back
    result = pi.get_host_state(Host('host1'))
    assert result.cur_block == 0
    assert len(result._blocks) == 1

    # add a test task and check the results
    task = Task()
    task.block = Block(parent_block=p._block)
    task.block.rescue = []
    task.block.always = []

# Generated at 2022-06-10 23:13:38.045962
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    iterator = PlayIterator()
    assert iterator.is_failed(None) == False


# Generated at 2022-06-10 23:13:49.267985
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    b = Block()
    b2 = Block()
    b3 = Block()
    b3.rescue = [Task()]
    b.block = [b2]
    b.rescue = [b3]
    s = PlayIterator.HostState(blocks=[b])
    s.run_state = PlayIterator.ITERATING_TASKS
    s.tasks_child_state = PlayIterator.HostState(blocks=[b2])
    s.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    s.tasks_child_state.tasks_child_state = PlayIterator.HostState(blocks=[b3])
    s.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    s.tasks_

# Generated at 2022-06-10 23:13:51.266423
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # PlayIterator.add_tasks() -> None : error condition
    raise Exception("not implemented")


# Generated at 2022-06-10 23:14:03.352866
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-10 23:14:10.989973
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    pl = Play("test play", dict(foo = 'bar'))
    pl.load(playbook=[{'hosts':'testhost1', 'gather_facts':'no'}], variable_manager=VariableManager(), loader=DictDataLoader())
    pl._included_file_local_vars = dict()

    # TODO: test this method using a wide set of data
    pl.set_variable_manager(VariableManager())
    pl.get_variable_manager().set_nonpersistent_facts(dict(foo = 'bar'))
    p = PlayIterator(pl)
    h = Host('testhost')
    h.vars = dict()
    p.mark_host_failed(h)
    assert p.is_failed(h) == True

# Generated at 2022-06-10 23:14:21.240741
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    """
    get_next_task_for_host()
    """

    # create host
    host = Host('localhost')
    display.verbosity = 3

    # constructor test
    myiterator = PlayIterator()

    # Make sure it sets the _play attribute
    play = Play()
    myiterator = PlayIterator(play)
    assert myiterator._play is play

    # Make sure it sets the inventory attribute
    inventory = Inventory(host_list=[])
    myiterator = PlayIterator(inventory=inventory)
    assert myiterator._inventory is inventory

    # Make sure it sets the _host_states attribute
    myiterator._host_states = 'foo'
    myiterator = PlayIterator()
    assert 'foo' == myiterator._host_states

    # Make sure it sets the _play_context attribute

# Generated at 2022-06-10 23:14:33.448912
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    
    b1 = Block( role = 'role1', rescue = 0, always = 0, block = 0)
    task1 = Task( action = 'action1', role = 'role1', rescue = 0, always = 0, block = 0)
    task2 = Task( action = 'action2', role = 'role1', rescue = 0, always = 0, block = 0)
    task3 = Task( action = 'action3', role = 'role1', rescue = 0, always = 0, block = 0)
    task4 = Task( action = 'action4', role = 'role1', rescue = 0, always = 0, block = 0)
    blocks = [b1]
    tasks = [task1, task2, task3, task4]

    test1 = HostState(blocks)

# Generated at 2022-06-10 23:14:44.336521
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Setup test environment
    from ansible import context
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback_loader

    context._init_global_context(options=None)

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Make a fake play

# Generated at 2022-06-10 23:15:11.722789
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    iterator = PlayIterator()
    host = Host(name='hostname')
    assert iterator.get_next_task_for_host(host) is None

# Generated at 2022-06-10 23:15:19.200761
# Unit test for constructor of class PlayIterator

# Generated at 2022-06-10 23:15:30.928075
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():

    mocker = ModifiedMock()
    mocker.patch('ansible.playbook.play_context.PlayContext.set_task_and_variable_override', return_value=None)

    play = Play()
    play.hosts = ['host1', 'host2']
    hosts = dict(zip(['host1', 'host2'], [Mock(), Mock()]))
    for host in list(hosts.values()):
        host.name = host.get_name()
        host.get_vars.return_value = dict()

    pi = PlayIterator(play, play._tqm, play._variables)
    pi.get_next_task_for_host = Mock(return_value=(Mock(), Mock()))
    pi.mark_host_failed(hosts['host1'])

    assert pi._

# Generated at 2022-06-10 23:15:43.193901
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    unit test for PlayIterator.get_failed_hosts
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.runner.return_data import ReturnData
    from ansible import callbacks
    from ansible import utils

    CALLBACK_PLUGINS=[]
    STDOUT_CALLBACK=callbacks.DefaultRunnerCallbacks()
    inventory = Inventory("/dev/null")
    stats = callbacks.AggregateStats()
    playbook = Playbook()
    runner = utils.plugins.action_loader.get("ping", class_only=True)

   

# Generated at 2022-06-10 23:15:46.322595
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    play_iterator_obj = PlayIterator(play=mock.Mock())
    assert play_iterator_obj.is_any_block_rescuing(None) is False

# Generated at 2022-06-10 23:15:55.651517
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    play_iterator = PlayIterator()
    host = Host()
    host.name = 'dummy_host'

    play_iterator._host_states = dict()
    play_iterator._host_states[host.name] = HostState()
    assert play_iterator.is_failed(host) == True

    play_iterator._host_states = dict()
    play_iterator._host_states[host.name] = HostState(run_state=PlayIterator.ITERATING_COMPLETE)
    assert play_iterator.is_failed(host) == True

    play_iterator._host_states = dict()
    play_iterator._host_states[host.name] = HostState(run_state=PlayIterator.ITERATING_COMPLETE, fail_state=PlayIterator.FAILED_NONE)

# Generated at 2022-06-10 23:16:05.842012
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play_iterator = PlayIterator()
    play_iterator._host_states = {}
    play_iterator._play = Play()
    host = Host('test')
    play_iterator._host_states['test'] = play_iterator.get_host_state(host)
    play_iterator._play._removed_hosts = ['test']
    play_iterator.mark_host_failed(host)
    assert play_iterator._host_states['test'].run_state == PlayIterator.ITERATING_COMPLETE
    assert play_iterator._host_states['test'].fail_state == PlayIterator.FAILED_SETUP

# Generated at 2022-06-10 23:16:17.142827
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play_iterator = PlayIterator()
    task_result = Result()
    state = MagicMock()
    state.run_state = 'run_state'
    state.tasks_child_state = 'tasks_child_state'
    state.rescue_child_state = 'rescue_child_state'
    state.always_child_state = 'always_child_state'
    play_iterator._play.tasks = []
    play_iterator._play.handlers = []
    play_iterator._play.post_tasks = []
    # Case 1: testing the 'if' branch in line 198
    #assert that method returns 'tasks_child_state'
    assert play_iterator.get_active_state(state) == 'tasks_child_state'
    # Case 2: testing the 'if' branch in line 201

# Generated at 2022-06-10 23:16:17.748940
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    pass

# Generated at 2022-06-10 23:16:29.165736
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    host = Host('testhost')
    play = Play()
    play._vars_per_host = { host.name: {} }
    play._removed_hosts = []
    play.hosts = [host]
    play.task_blocks = [ TaskBlock([dummy_task], rescue=[dummy_task]) ]
    play.notify_handlers = []
    play.listeners = []
    iterator = PlayIterator(play)
    play_context = PlayContext(play)
    iterator.mark_host_failed(host)
    assert iterator.is_failed(host) == True
    assert iterator.get_active_state(iterator.get_host_state(host)).run_state == PlayIterator.ITERATING_COMPLETE


# Generated at 2022-06-10 23:17:04.766391
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # PlayIterator.cache_block_tasks()  -> None


    # Passing variant 1 - normal run
    # We just call the method without raising any errors

    # set up a mock inventory
    inv = InventoryManager(['localhost'])
    inv.set_variable('localhost', 'ansible_connection', 'local')

    # set up a mock loader

# Generated at 2022-06-10 23:17:10.976567
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import Host
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    def make_block(levels, suffix="", state=None):
        blk = Block(play, [])
        if levels == 0:
            blk.block = [Task()]
        else:
            blk.block = [make_block(levels-1, "-" + suffix, state), make_block(levels-1, "+" + suffix, state)]
        blk.block[0].name = "Task-%s" % suffix
        blk.block[1].name = "Task+%s" % suffix
        return

# Generated at 2022-06-10 23:17:22.580503
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    p = Play()
    p.tasks = [
        Task(),
        Task(),
        Task(),
        Task()
    ]
    h = Host()
    h.name = 'hostname'
    pi = PlayIterator(p)
    (state, task) = pi.get_next_task_for_host(h)
    assert task == p.tasks[0]
    assert state.cur_task == 1
    (state, task) = pi.get_next_task_for_host(h)
    assert task == p.tasks[1]
    assert state.cur_task == 2
    (state, task) = pi.get_next_task_for_host(h)
    assert task == p.tasks[2]
    assert state.cur_task == 3

# Generated at 2022-06-10 23:17:32.825711
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Test the method get_original_task of class PlayIterator
    '''
    play_iterator = PlayIterator()

    # Test with only task added
    play_iterator._insert_tasks_into_state(
        state = play_iterator.get_host_state(host='dummy_host1'),
        task_list = [
            'dummy_task1',
            'dummy_task2',
            'dummy_task3',
        ]
    )

    # Test with a first block and only task added
    play_iterator = PlayIterator()

# Generated at 2022-06-10 23:17:44.457110
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
  # Init data
  host = Host(name='some host', port=22)

  # Init mocks
  mockPlay = Play()
  mockPlay._iterator = PlayIterator(play=mockPlay)
  mockPlay._tqm = PlayIteratorTest()

  # Init PlayIterator
  playIterator = mockPlay._iterator

  # Test failed host
  playIterator._host_states['some host'] = HostState(
    run_state=HostState.ITERATING_COMPLETE,
    fail_state=HostState.FAILED_SETUP,
  )
  playIterator._play._removed_hosts = []
  result = playIterator.get_next_task_for_host(host=host)
  assert result[0] is None
  assert result[1] is None

  # Test removed host
  playIterator._host_

# Generated at 2022-06-10 23:17:47.098706
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    my_iterator = PlayIterator()
    my_iterator._task_states = dict()
    assert my_iterator.get_host_state('host1') == None


# Generated at 2022-06-10 23:17:59.688220
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    class TestTask(object):
        def __init__(self):
            pass
        def run(self, tmp=None, task_vars=dict()):
            pass
    class TestPlay(object):
        def __init__(self):
            self.hosts = ["localhost", "127.0.0.1"]
            self.tasks = [TestTask()]

    class TestPlaybook(object):
        def __init__(self):
            self.become_passwords = dict()
            self.vars_prompt = list()
            self.passwords = dict()
        def get_variable_manager(self):
            return variable_manager.VariableManager()


# Generated at 2022-06-10 23:18:12.495724
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    state = HostState(blocks=None)

    # test case when the current state is in rescue mode
    state.run_state = PlayIterator.ITERATING_RESCUE
    assert PlayIterator.is_any_block_rescuing(state) == True

    # test case when the current state is not in rescue mode and there are no
    # child state
    state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state = None
    assert PlayIterator.is_any_block_rescuing(state) == False

    # test case when the current state is not in rescue mode but the child state is
    # in rescue mode
    state.tasks_child_state = HostState(blocks=None)
    state.tasks_child_state.run_state = PlayIterator.ITERATING_

# Generated at 2022-06-10 23:18:21.689495
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Test PlayIterator.get_next_task_for_host function
    mock_display = MagicMock()
    mock_display.vv = _display.debug
    mock_variable_manager = MagicMock()
    mock_loader = MagicMock()

    test_iterator = PlayIterator()
    test_iterator._logger = MagicMock()
    test_iterator._logger.getChild = MagicMock()

    test_play = Play()
    test_play._variable_manager = mock_variable_manager
    test_play._loader = mock_loader
    test_play._tqm = None
    test_play.hosts = "localhost"

    test_host = Host("localhost")
    test_host.set_vars({'test_var': 'test_value'})
    test_task = Task()

    # Setup

# Generated at 2022-06-10 23:18:34.511589
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play().load(dict(
        name = "foobar",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(raw = dict(msg = "foo")),
            dict(raw = dict(msg = "bar")),
            dict(meta = dict(end_play = True)),
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    play_context = PlayContext(play=play)
    play_context._ssh_password = "password"
    play_context._become_method='sudo'
    play_context._become_user = 'root'
    play_context._become_pass = 'password'
    play.set_loader(DictDataLoader())
    iterator = PlayIterator()

# Generated at 2022-06-10 23:19:35.706286
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Test with empty host states
    play = Play()
    assert PlayIterator(play).get_active_state(HostState([])) is None

    # Test with ITERATING_SETUP active state
    block = Block(play=play)
    host_state = HostState(blocks=[block])
    host_state.run_state = HostState.ITERATING_SETUP
    active_state = PlayIterator(play).get_active_state(host_state)
    assert active_state is host_state

    # Test with ITERATING_TASKS active state
    block = Block(play=play)
    host_state = HostState(blocks=[block])
    host_state.run_state = HostState.ITERATING_TASKS
    active_state = PlayIterator(play).get_active_state(host_state)


# Generated at 2022-06-10 23:19:36.778024
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    pass



# Generated at 2022-06-10 23:19:45.765997
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host_states = {
        'some_host': HostState(task_results={
            'task1': Result(True, 'ok')
        })
    }
    iterator = PlayIterator(None, host_states)
    assert iterator.get_failed_hosts() == {}
    host_states = {
        'some_host': HostState(task_results={
            'task1': Result(False, 'nok')
        })
    }
    iterator = PlayIterator(None, host_states)
    assert iterator.get_failed_hosts() == {'some_host': True}
    host_states = {}
    iterator = PlayIterator(None, host_states)
    assert iterator.get_failed_hosts() == {}
    host_states = {'some_host': HostState()}

# Generated at 2022-06-10 23:19:58.288485
# Unit test for method get_active_state of class PlayIterator

# Generated at 2022-06-10 23:20:06.574382
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    inventory = Inventory(loader=None, variable_manager=None, host_list=[])
    play = Play().load(dict(name='test', hosts='all', gather_facts='no'), variable_manager=None, loader=None)
    tqm = TaskQueueManager(inventory=inventory, variable_manager=None, loader=None, passwords=None)
    playlist = PlayIterator(play)
    playlist.get_original_task('Test', 'test')

# Generated at 2022-06-10 23:20:18.616532
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    play = Play().load(SAMPLE_PLAY, variable_manager=VariableManager(), loader=loader)

    host = Host(name=u"testhost.local")

    assert not PlayIterator(play=play).is_any_block_rescuing(PlayIterator.HostState([play.get_tasks()[1].block]))
    assert PlayIterator(play=play).is_any_block_rescuing(PlayIterator.HostState([play.get_tasks()[1].block], run_state=PlayIterator.ITERATING_RESCUE))
    assert not PlayIterator(play=play).is_any_block_rescuing(PlayIterator.HostState([play.get_tasks()[1].block], run_state=PlayIterator.ITERATING_ALWAYS))
    assert not PlayIterator(play=play).is_any_

# Generated at 2022-06-10 23:20:28.248588
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    hosts = [Host(name='host1')]
    tasks = [
        Task(action=dict(module='foo', args='bar'), block=Block(rescue=[
            Task(action=dict(module='foo', args='baz'))
        ])),
    ]
    iterator = PlayIterator(Play(pattern=None, hosts=hosts, name='test_play', tasks=[], vars={}), hosts, tasks)
    iterator._play._vars = compile_block_list(hosts, iterator._play.vars, iterator._play.hosts, iterator._play.task_vars)

# Generated at 2022-06-10 23:20:38.398511
# Unit test for method add_tasks of class PlayIterator

# Generated at 2022-06-10 23:20:41.517964
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
  play_iterator = PlayIterator()
  play = Play()
  play.iterator = play_iterator
  host = Host('testhost')
  block = Block()
  task = Task()
  assert play_iterator.cache_block_tasks(play, block, host) == None


# Generated at 2022-06-10 23:20:54.370394
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import Host, Inventory
    from jinja2 import Template
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from units.compat.mock import patch
    from ansible.vars import VariableManager