

# Generated at 2022-06-10 23:13:04.778855
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
  # Set up data
  host = Host("Some host")
  host2 = Host("Other host")

  block1 = Block([])
  block2 = Block([])
  block3 = Block([block1, block2])
  block4 = Block([])

  state1 = HostState(blocks=[block3])
  state2 = HostState(blocks=[block4])
  state1._host_name = host.name
  state2._host_name = host2.name

  iterator = PlayIterator()
  iterator._host_states[host.name] = state1
  iterator._host_states[host2.name] = state2

  # Test that no hosts are marked as failed.
  assert len(iterator.get_failed_hosts()) == 0

  # Test that host1 is marked as failed
  state1.fail_state = Play

# Generated at 2022-06-10 23:13:13.260909
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # PlayIterator.is_any_block_rescuing() -> Boolean
    # Method is_any_block_rescuing() of test_PlayIterator
    state = HostState(blocks=[Block(name='ok')])
    assert not PlayIterator(play=Play().load(dict(
        name = 'test',
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(debug='msg=ok')
        ]
    ))).is_any_block_rescuing(state)


# Generated at 2022-06-10 23:13:24.401488
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    class block:
        block = []
        rescue = []
        always = []

    hs = HostState(blocks=[block()])
    hs2 = HostState(blocks=[block()])
    hs3 = HostState(blocks=[block()])
    hs4 = HostState(blocks=[block()])
    hs.tasks_child_state = hs2
    hs2.tasks_child_state = hs3
    hs3.tasks_child_state = hs4

    assert not PlayIterator.is_any_block_rescuing(hs2)
    assert not PlayIterator.is_any_block_rescuing(hs3)
    assert not PlayIterator.is_any_block_rescuing(hs4)
    hs4.run_state = PlayIterator.ITERATING_RES

# Generated at 2022-06-10 23:13:35.761661
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    """
    PlayIterator.get_next_task_for_host()
    """
    mock_play = Mock()
    mock_play._removed_hosts = []

    iterator = PlayIterator()
    iterator.play = mock_play

    # Setup a host with a simple state
    host = Mock()
    host.name = 'host_name'
    mock_host_state = HostState()
    mock_host_state._blocks = [Block(block=[Mock()]), Block(block=[Mock()])]
    mock_host_state.cur_block = 0
    mock_host_state.cur_regular_task = 0
    mock_host_state.run_state = 0

    iterator._host_states[host.name] = mock_host_state
    iterator.get_next_task_for_host(host)


# Generated at 2022-06-10 23:13:43.329812
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    p0 = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='ok 1'))),
            dict(action=dict(module='debug', args=dict(msg='ok 2'))),
        ]
    ), variable_manager=VariableManager(), loader=None)
    p0._tqm = None
    p0._iterator = PlayIterator(p0)
    p0._iterator._play = p0

# Generated at 2022-06-10 23:13:55.190891
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-10 23:14:07.293638
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    Test get_failed_hosts.
    '''
    p = Play()
    i = PlayIterator(p)
    h1 = Host('host1')
    h2 = Host('host2')
    # Check fail at setup
    hs1 = HostState(host=h1, fail_state=i.FAILED_SETUP)
    i._host_states[h1.name] = hs1
    # Check fail at tasks
    hs2 = HostState(host=h2, fail_state=i.FAILED_TASKS)
    i._host_states[h2.name] = hs2
    # Check fail at rescue
    hs3 = HostState(host=h1, fail_state=i.FAILED_RESCUE)

# Generated at 2022-06-10 23:14:08.967436
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass


# Generated at 2022-06-10 23:14:20.311017
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    """Test method PlayIterator.mark_host_failed"""
    
    # setup of test environment 
    pb = Playbook()
    pb.get_inventory = mock.Mock()
    hi = HostInfo()
    pb.get_inventory.return_value = hi
    host = Host()
    host.name = 'localhost'
    hs = HostState()
    hs._blocks = [Block(Block.TASK_BLOCK, None, [Task()], [], [])]
    hi.get_host_state = mock.Mock()
    hi.get_host_state.return_value = hs
    pi = PlayIterator(pb)
    
    # test call of mark_host_failed()
    pi.mark_host_failed(host)
    
    # test execute result
   

# Generated at 2022-06-10 23:14:26.876568
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    state = HostState([])
    assert state.__str__() == 'HOST STATE: block=-1, task=-1, rescue=-1, always=-1, run_state=UNKNOWN STATE, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False'



# Generated at 2022-06-10 23:14:52.052763
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    pass

# Generated at 2022-06-10 23:15:02.914776
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
  play = Play().load('test/plays/meta_handlers.yml', variable_manager=VariableManager(), loader=Loader())
  play_state = PlayState(play)
  iterator = PlayIterator(play_state)
  iterator._play_state.get_task_meta = MagicMock(return_value={})
  inventory = Inventory(loader=None, variable_manager=None, host_list='test/inventory/hosts')
  host = MagicMock(name='localhost')
  iterator.get_host_state(host)
  assert iterator._host_states['localhost'].cur_task_num == 2

  play = Play().load('test/plays/meta_handlers.yml', variable_manager=VariableManager(), loader=Loader())
  play_state = PlayState(play)
  iterator = PlayIterator(play_state)


# Generated at 2022-06-10 23:15:12.881868
# Unit test for method mark_host_failed of class PlayIterator

# Generated at 2022-06-10 23:15:18.297332
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    host = C.hosts[0]
    iterator = PlayIterator()
    assert iterator.get_host_state(host) is None
    iterator._host_states[host.name] = HostState()
    assert iterator.get_host_state(host) is iterator._host_states[host.name]



# Generated at 2022-06-10 23:15:22.050258
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = C.Play()
    play_it = PlayIterator(play)
    assert isinstance(play_it, PlayIterator)


# Generated at 2022-06-10 23:15:26.282045
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    play_iterator = PlayIterator()
    assert play_iterator.cache_block_tasks(None, None, None) == None
    # FIXME: what's the purpose of this test?

# Generated at 2022-06-10 23:15:33.711587
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    '''
    Unit test for constructor of class PlayIterator
    '''

# Generated at 2022-06-10 23:15:46.145799
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    # Arrange
    myHostState = HostState(['Blocks'])
    myHostState.cur_block = 0
    myHostState.cur_regular_task = 1
    myHostState.cur_rescue_task = 2
    myHostState.cur_always_task = 3
    myHostState.run_state = 4
    myHostState.fail_state = 5
    myHostState.pending_setup = True
    myHostState.tasks_child_state = True
    myHostState.rescue_child_state = True
    myHostState.always_child_state = True
    myHostState.did_rescue = True
    myHostState.did_start_at_task = True

    # Act
    result = myHostState.__str__()

    # Assert

# Generated at 2022-06-10 23:15:54.980833
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    target_test = ITERATOR_DATA[1][0]
    test = copy.deepcopy(target_test)
    play = Play().load(test, variable_manager=VariableManager(), loader=DataLoader())
    play.GATHER_FACTS = 'smart'
    play.post_validate()
    test[0]['hosts'] = ['foohost']
    play._dependent_hosts = dict((h, True) for h in test[0]['hosts'])
    ti = PlayIterator(play)

    host = Host(name="foohost")
    ti.mark_host_failed(host)
    assert ti._host_states['foohost'].run_state == PlayIterator._ITERATING_COMPLETE


# Generated at 2022-06-10 23:16:07.452143
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    """Unit test for method mark_host_failed of class PlayIterator"""

    class MockPlayIterator(object):
        def __init__(self, play, inventory):
            self._play = play
            self._inventory = inventory
            self._host_states = {}
        def get_host_state(self, host):
            return self._host_states[host.name]
        def mark_host_failed(self, host):
            s = self.get_host_state(host)
            if False:
                display.debug("marking host %s failed, current state: %s" % (host, s))
            s = self._set_failed_state(s)
            if False:
                display.debug("^ failed state is now: %s" % s)
            self._host_states[host.name] = s
            self._

# Generated at 2022-06-10 23:17:08.905506
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    '''
    test_PlayIterator: tests for class PlayIterator
    '''
    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'debug': 'msg=foo'},
            {'debug': 'msg=foo'},
            {'debug': 'msg=foo'},
            {'debug': 'msg=foo'},
        ]
    }, variable_manager=VariableManager(), loader=None)

    # Test with no hosts
    hosts = []
    play_iterator = PlayIterator(play, hosts)
    assert "test play" == play_iterator.play.name
    assert hosts == list(play_iterator.hosts)
    assert not play_iterator.play_hosts
    assert not play

# Generated at 2022-06-10 23:17:20.355368
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    # set up dummy play and iterator
    play = Play(playbook=Playbook(),
                play_context=PlayContext(),
                loader=DictDataLoader(),
                variable_manager=VariableManager(),
                all_vars=dict())
    iterator = PlayIterator(play, batch=False)

    # set up some fake blocks
    block1 = Block(block=['foo', 'bar'], rescue=['baz'])
    block2 = Block(block=['boo'], rescue=[], always=['zoo'])
    block3 = Block(block=['far'], rescue=[], always=[])
    block4 = Block(block=['faz'], rescue=['zab'], always=['biz'])

    # create a state that has fully iterated through the first block
    state1 = HostState(blocks=[block1])


# Generated at 2022-06-10 23:17:26.404035
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load("test/units/loader/test_playbooks/play.yml", variable_manager=VariableManager, loader=DataLoader())
    iterator = PlayIterator(p)
    assert iterator._play == p
    assert iterator._host_states == {}
    assert iterator._start_at_task == None
    assert iterator.get_next_task_for_host(Host("localhost")) == None

# Generated at 2022-06-10 23:17:35.160911
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-10 23:17:49.217093
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    from ansible.playbook.task_include import TaskInclude

    fake_iterator = PlayIterator()
    fake_iterator._host_states = {
        'foo': HostState(blocks=[
            Block(
                block=['bar'],
                rescue=[],
                always=[]
            )
        ])
    }

    foo_state = fake_iterator.get_host_state('foo')
    fake_iterator._insert_tasks_into_state(foo_state, ['foo'])
    fake_iterator._insert_tasks_into_state(foo_state, [TaskInclude(name='foo', static=['bar'])])
    fake_iterator._insert_tasks_into_state(foo_state, ['bar'])


# Generated at 2022-06-10 23:17:59.957330
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # testing if the get_host_state method returns an expected value
    # create an instance of PlayIterator class as fixture
    play_iterator = PlayIterator()
    # create a host as fixture
    host = Host()
    # create a block as fixture
    block = Block()
    # create a list of blocks as fixture
    block_list = [block]
    # create a HostState as fixture
    host_state = HostState(block_list)
    # execute the get_host_state method and make sure the result is as expected
    assert play_iterator.get_host_state(host) == host_state

# Generated at 2022-06-10 23:18:03.322147
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    v = PlayIterator({}, [])
    assert v.get_original_task() == (None, None)


# Generated at 2022-06-10 23:18:09.799840
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # pylint: disable=too-many-branches

    ################################
    # PlayIterator.is_failed tests #
    ################################

    # Tests PlayIterator.is_failed with different HostStates and RunStates
    host = "test.host"
    host1 = "test.host1"
    host2 = "test.host2"
    host3 = "test.host3"
    host4 = "test.host4"
    host5 = "test.host5"

    testBlock1 = Block()
    testBlock2 = Block()
    testBlock3 = Block()
    testBlock4 = Block()
    testBlock5 = Block()

    test_state = HostState(blocks=[testBlock1, testBlock2, testBlock3])
    test_state1 = HostState(blocks=[testBlock4])

# Generated at 2022-06-10 23:18:19.861579
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Ensure the cache_block_tasks method of the PlayIterator class is properly caching list of tasks
    '''

    class Block(object):
        def __init__(self, block):
            self.block = block
            self.rescue = []
            self.always = []

    class Task(object):
        def __init__(self, name):
            self.name = name
            self.action = 'test'
            self.args = {}
            self.delegate_to = None
            self.notify = []

    class Host(object):
        def __init__(self, name):
            self.name = name
            self.vars = {}

    class Play(object):
        def __init__(self):
            self.connection = 'test'
            self.hosts = 'all'
            self

# Generated at 2022-06-10 23:18:23.273890
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    None
    '''
    pi = PlayIterator(True)
    assert pi
    #assert pi.cache_block_tasks(block) == (None,), pi


# Generated at 2022-06-10 23:21:06.815600
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Create a fake play
    play = Play().load(dict(name='testplay',
                            hosts=['foo', 'bar', 'baz'],
                            gather_facts='no',
                            tasks=[dict(action=dict(__ansible_module__='shell', __ansible_arguments__='ls'))]),
                        variable_manager=VariableManager(), loader=DummyLoader())

    piterator = PlayIterator(play)

    assert piterator is not None
    assert piterator._play is not None
    assert piterator._play.get_basedir() == os.getcwd()
    assert piterator._play.get_vars() == dict()
    assert piterator._tqm is None
    assert piterator._last_task_banner == 'TASK [setup]'

# Generated at 2022-06-10 23:21:19.448444
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    Unit test for method get_failed_hosts of class PlayIterator
    '''

    # setup test object
    play = Play().load(get_fixture_path(['setup_test_play.yml']), variable_manager=VariableManager())
    
    # set up legacy_play_context as 'play_context'
    play_context = PlayContext()
    play_context.network_os='default'
    play_context._init_globals()
    play_context.remote_addr='default'
    play_context.port=2222
    play_context.remote_user='default'
    play_context.connection='default'
    play_context.timeout=10
    play_context.shell='default'
    play_context.become=None
    play_context.become_method='default'

# Generated at 2022-06-10 23:21:32.933519
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    host = Host('somehost')
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    inventory.add_host(host)
    play = Play.load(dict(
                name = 'test play',
                hosts = 'all',
                gather_facts = 'no',
                tasks = [
                    dict(action=dict(module='shell', args='ls'), register='shell_out'),
                    dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
               ]
           ), variable_manager=variable_manager, loader=loader)

    play = play.copy()


# Generated at 2022-06-10 23:21:40.485329
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    iter = PlayIterator()
    host = Host("127.0.0.1")
    host_state = HostState()

    # fail_state is unset
    host_state.fail_state = iter.FAILED_NONE
    host_state.run_state = iter.ITERATING_TASKS
    assert iter.is_failed(host) == False

    # fail_state is set, but we're in ITERATING_TASKS, which is allowed to be
    # failed
    host_state.fail_state = iter.FAILED_SETUP
    host_state.run_state = iter.ITERATING_TASKS
    assert iter.is_failed(host) == False

    # fail_stat is set, and we're in a state that's not allowed to be failed
    host_state.fail_state

# Generated at 2022-06-10 23:21:43.523130
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # ansible.playbook.PlayIterator.get_original_task does not exist as of 2.8.0
    pass

# Generated at 2022-06-10 23:21:55.159586
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
  from ansible.playbook.play import Play

  p = Play.load({
    'hosts': 'all',
    'gather_facts': 'no',
    'tasks': [
      { 'shell': 'echo this is the first task' },
      { 'shell': 'echo this is the second task' },
      { 'shell': 'echo this is the third task' }
    ]
  }, base_vars=dict())

  i = PlayIterator(p)
  test_host = Host("test_host")
  # Get the first task
  (_, first_task) = i.get_next_task_for_host(test_host)
  # Now that we have a task, we can test if we can get the original task

# Generated at 2022-06-10 23:22:00.038649
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    assert HostState(["_blocks1", "_blocks2"]).__str__() == "HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False"


# Generated at 2022-06-10 23:22:11.470542
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host_name = 'Donovan'
    target_host = Host(host_name)
    target_host.vars = dict(
        ansible_python_interpreter = sys.executable
        )
    fake_loader = DictDataLoader(dict(
        host_vars = dict(),
        group_vars = dict()
        ))
    test_play = Play.load(dict(
        name = "Test play",
        hosts = host_name,
        gather_facts = False,
        tasks = [],
        ), fake_loader, variable_manager = VariableManager())
    test_play.post_validate(fake_loader)
    test_play._set_variable_manager(VariableManager())
    assert test_play.hosts[0].name == host_name


# Generated at 2022-06-10 23:22:21.236615
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    from collections import namedtuple

    b = namedtuple('b', ["name"])
    h = namedtuple('h', ["name"])

    s = HostState(blocks=[] * 2)
    s.run_state = PlayIterator.ITERATING_SETUP
    r = PlayIterator.is_any_block_rescuing(s)
    assert not r

    s.run_state = PlayIterator.ITERATING_TASKS
    r = PlayIterator.is_any_block_rescuing(s)
    assert not r

    s.tasks_child_state = HostState(blocks=[b('a')])
    r = PlayIterator.is_any_block_rescuing(s)
    assert not r

    s.tasks_child_state.run_state = PlayIterator.ITERATING_RES

# Generated at 2022-06-10 23:22:22.939530
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    print("UNTESTED: test_PlayIterator_cache_block_tasks")
    return True