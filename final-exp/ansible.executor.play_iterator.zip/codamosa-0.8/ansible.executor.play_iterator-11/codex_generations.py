

# Generated at 2022-06-10 23:13:23.965084
# Unit test for method copy of class HostState
def test_HostState_copy():
    hs = HostState(["block"])
    hs.cur_block = 1
    hs.cur_regular_task = 2
    hs.cur_rescue_task = 3
    hs.cur_always_task = 4
    hs.run_state = 5
    hs.fail_state = 6
    hs.pending_setup = True
    hs.did_rescue = False
    hs.did_start_at_task = True
    hs.tasks_child_state = "tasks_child_state"
    hs.rescue_child_state = "rescue_child_state"
    hs.always_child_state = "always_child_state"
    new_hs = hs.copy()
    assert hs.cur_block == new_hs.cur_

# Generated at 2022-06-10 23:13:33.530100
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Test PlayIterator.get_original_task()
    host = Host('test.example.com')
    play = Play().load(dict(
        name = "Test Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='echo hi')),
            dict(action=dict(module='shell', args='echo bye')),
            dict(action=dict(module='shell', args='echo later'))
        ]
    ), loader=MockLoader())

    itr = PlayIterator()
    itr._play = play
    itr.host_cache[host.name] = dict()
    itr._host_states[host.name] = itr.get_host_state(host)

    # Test getting the original task when it's the first

# Generated at 2022-06-10 23:13:41.248337
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    from collections import namedtuple
    from ansible.playbook.block import Block

    BlockState = namedtuple('BlockState', ['run_state', 'tasks_child_state', 'rescue_child_state', 'always_child_state'])

    # Setup the test condition: no child block
    bs = BlockState(run_state=PlayIterator.ITERATING_RESCUE, tasks_child_state=None, rescue_child_state=None, always_child_state=None)

    assert PlayIterator.is_any_block_rescuing(bs) == True

    # Setup the test condition: child block not rescuing
    bs = BlockState(run_state=PlayIterator.ITERATING_TASKS, tasks_child_state=bs, rescue_child_state=None, always_child_state=None)

   

# Generated at 2022-06-10 23:13:42.426596
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    pass



# Generated at 2022-06-10 23:13:54.320648
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    print('unit test for method get_next_task_for_host of class PlayIterator')
    host = Host(name="myhost")
    task = Task()
    task.name = "first task"
    task2 = Task()
    task2.name = "second task"
    tasks = [task, task2]
    block = Block(tasks)
    blocks = [block]
    play = Play()
    play._tqm = TaskQueueManager(None)
    play._iterator = PlayIterator(play=play)
    play._iterator.queue_task(host, task, task.action)
    host_state = play._iterator._host_states[host.name]
    host_state.run_state = PlayIterator.ITERATING_TASKS
    (host_state, task) = play._iterator._get_next_

# Generated at 2022-06-10 23:14:06.308537
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play = Play().load('test/fixtures/playbooks/tags.yml', 'test/fixtures')
    iterator = PlayIterator()
    iterator.load(play)
    assert iterator.get_original_task(None, dict(action=dict(__ansible_test_tag__=['test'], __ansible_skip_tags__=['skipme']))) == (None, None)
    assert iterator.get_original_task(None, dict(action=dict())) == (None, None)
    assert iterator.get_original_task(None, dict(action=dict(__ansible_test_tag__=['test']))) == (None, None)
    assert iterator.get_original_task(None, dict(action=dict(__ansible_skip_tags__=['skipme']))) == (None, None)

# Generated at 2022-06-10 23:14:07.725400
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    pass


# Generated at 2022-06-10 23:14:14.379942
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play().load(get_test_data_path('test_playbook.yml'), variable_manager=VariableManager(), loader=Loader())
    iterator = PlayIterator(play)
    assert iterator._play.name == 'foobar'
    assert iterator._play is play
    assert iterator._play_context == play._context
    assert iterator._variable_manager._fact_cache == dict()

# Generated at 2022-06-10 23:14:22.920208
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # set up the default args
    args = {}
    args['play'] = None
    args['play_context'] = {'remote_addr': '127.0.0.1', 'port': 22}
    args['new_stdin'] = None
    args['accelerate'] = False
    args['accelerate_ipv6'] = False
    args['accelerate_port'] = 5099
    args['accelerate_timeout'] = 30
    args['accelerate_connect_timeout'] = 5.0

    # create the shared play object

# Generated at 2022-06-10 23:14:35.178595
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # get_failed_hosts()
    # From units.yml:
    #    - name: get_failed_hosts returns empty dict if no hosts have failed
    hs = PlayIterator(play=play_context(), play_hosts=[])
    assert hs.get_failed_hosts() == {}

    #    - name: get_failed_hosts returns dict of failed hosts
    hs = PlayIterator(play=play_context(), play_hosts=[])
    hs.mark_host_failed(host=HOSTVARIABLE)
    assert hs.get_failed_hosts() == {HOSTVARIABLE: True}

    #    - name: get_failed_hosts returns empty dict if hosts are retried and no longer failed

# Generated at 2022-06-10 23:15:12.636382
# Unit test for constructor of class PlayIterator

# Generated at 2022-06-10 23:15:20.411639
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass
# Unit tests for class TaskResult

result = dict(
    _host=dict(name="testhostname"),
    _task=dict(name="testtaskname"),
    changed=True,
    failed=False,
    skipped=False,
    unreachable=False,
    ignored=False,
    ok=True,
)
result_copy = copy.copy(result)


# Generated at 2022-06-10 23:15:31.196193
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play_iterator = PlayIterator()

    play_iterator._play = Play()
    play_iterator._play._removed_hosts = []

    play_iterator._host_states = {}
    play_iterator._host_states['TestHost'] = HostState()
    play_iterator._host_states['TestHost'].run_state = 0
    play_iterator._host_states['TestHost'].cur_block = 0
    play_iterator._host_states['TestHost'].cur_regular_task = 0
    play_iterator._host_states['TestHost'].cur_rescue_task = 0
    play_iterator._host_states['TestHost'].cur_always_task = 0
    play_iterator._host_states['TestHost'].tasks_child_state = None

# Generated at 2022-06-10 23:15:32.275524
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    pass



# Generated at 2022-06-10 23:15:44.426228
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # test_PlayIterator_get_active_state: tests state machine of PlayIterator.get_active_state()
    # PlayIterator.get_active_state() is a recursive method which starts at the top of the 
    # state tree and returns state.run_state for the lowest child state which is not NONE. 
    # This calls for a state tree test with a number of nested levels.
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    host1 = Host(name="host1", port=22, groups=["all"])
    group1 = Group(name="group1")
   

# Generated at 2022-06-10 23:15:54.468174
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():

    tasks = [
        {"action": "set_fact", "args": {"foo": "bar"}},
        {"action": "set_fact", "args": {"bar": "baz"}},
    ]

    blocks = [
        Block(
            u'first_block',
            task_list=tasks
        ),
        Block(
            u'second_block',
            task_list=tasks
        ),
        Block(
            u'third_block',
            task_list=tasks
        ),
    ]

    i = PlayIterator(blocks=blocks)
    host_states = {
        'localhost': HostState(blocks=blocks)
    }
    i._host_states = host_states
    i.get_next_task_for_host(host=C.HOST, peek=False)
    i

# Generated at 2022-06-10 23:15:59.844736
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Create a play with a single block and a single task
    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': 'setup'},
        ],
    }, variable_manager=VariableManager(), loader=None)

    # Create a host
    host = Host(name='testhost')

    # Create a PlayIterator
    play_iterator = PlayIterator(play, [host])

    # Assert that play_iterator._play and play_iterator._hosts are as expected
    assert play_iterator._play == play
    assert play_iterator._hosts == [host]


# Generated at 2022-06-10 23:16:11.851213
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    '''
    Tests the method add_tasks of class PlayIterator
    '''
    # initialize the class
    play_iterator = PlayIterator()
    # define values
    task_list = [1,2,3]
    host_state = HostState()
    state = HostState()
    # set values
    play_iterator._host_states = {1: host_state}
    # run the method
    result = play_iterator._insert_tasks_into_state(state, task_list)
    # compare results
    assert result.run_state == state.run_state
    assert result.cur_block == state.cur_block
    assert result.cur_regular_task == state.cur_regular_task
    assert result.cur_rescue_task == state.cur_rescue_task
    assert result.cur_always

# Generated at 2022-06-10 23:16:12.785627
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    pass

# Generated at 2022-06-10 23:16:17.181946
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # initialize the PlayIterator
    # initialize the PlayIterator
    # initialize the PlayIterator
    # initialize the PlayIterator
    # initialize the PlayIterator

    # initialize the PlayIterator
    # initialize the PlayIterator
    # initialize the PlayIterator
    # initialize the PlayIterator
    # initialize the PlayIterator
    return


# Generated at 2022-06-10 23:16:54.708802
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host = Host("example.com")
    play = Play().load("/etc/ansible/hosts", name="test_play", variable_manager=VariableManager(), loader=DictDataLoader())
    iterator = PlayIterator(play)

    assert not iterator.is_failed(host)
    iterator.mark_host_failed(host)
    assert iterator.is_failed(host)
    assert len(iterator.get_failed_hosts()) == 1

# Generated at 2022-06-10 23:17:05.209503
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    from ansible.module_utils._text import to_bytes
    play = Play.load(dict(
        name = "foobar",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())

    play_it = PlayIterator()
    play_it._play = play
    play_it._host_states = {host1.name: HostState(host=host1) for host1 in set(play._hosts_cache[:2])}

    actual_add_tasks = play_it.add_t

# Generated at 2022-06-10 23:17:08.721407
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    test_obj = PlayIterator()

    # TODO implement the unit test
    assert False


# Generated at 2022-06-10 23:17:09.901270
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    print(PlayIterator())


# Generated at 2022-06-10 23:17:21.702186
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    host0 = Host('localhost')
    host1 = Host('127.0.0.1')

    all_hosts = [host0, host1]
    all_tasks = []
    for i in range(1,10):
        all_tasks.append(dict(action='task %d' % i))

    # test plain list of tasks
    play1 = Play().load({'name': 'test play', 'hosts': 'all', 'gather_facts': 'no', 'tasks': all_tasks})
    itr1 = PlayIterator(play1, all_hosts)
    hstate = itr1.get_host_state(host0)
    assert hstate.tasks_left == len(all_tasks)
    for i in range(len(all_tasks)):
        hstate, task

# Generated at 2022-06-10 23:17:32.189107
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    """
    PlayIterator.add_tasks() TestCase
    """
    play = Play().load(os.path.join(FIXTURES_DIR, 'playbooks', 'play.yml'), variable_manager=variable_manager, loader=loader)
    iterator = PlayIterator(play)
    host = play.get_hosts()[0]
    state = HostState(blocks=[])
    iterator._host_states[host.name] = state
    task = Task()
    state = iterator.insert_tasks(host, [task])
    assert state.run_state == 'ITERATING_TASKS'
    assert state.tasks_child_state is None
    state = iterator.insert_tasks(host, [task])
    assert state.run_state == 'ITERATING_TASKS'
    assert state.t

# Generated at 2022-06-10 23:17:39.209070
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Unit test for method is_any_block_rescuing of class PlayIterator
    '''
    host = mock.Mock()
    block = Block()
    block.block = []
    state = HostState(blocks=[block])
    play_iterator = PlayIterator()
    expected = False
    actual = play_iterator.is_any_block_rescuing(state)
    assert expected == actual

# Generated at 2022-06-10 23:17:40.608575
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # TODO
    pass


# Generated at 2022-06-10 23:17:51.440831
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host_state = dict(host_state=dict(host_name="host1", fail_state=1, run_state=3,
                                      cur_regular_task=None, cur_rescue_task=None, cur_always_task=None,
                                      cur_block=None, tasks_child_state=None, rescue_child_state=None,
                                      always_child_state=None, did_rescue=False, _blocks=[]))
    iterator = PlayIterator()
    iterator._host_states = dict(host1=host_state)
    result = iterator.is_failed(iterator._host_states["host1"])
    assert result is True



# Generated at 2022-06-10 23:18:05.947672
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    # initialization
    test_play = Play()

    test_task1 = Task()
    test_task1._uuid = "test_task1"
    test_task1.name = 'first task'

    test_task2 = Task()
    test_task2._uuid = "test_task2"
    test_task2.name = 'second task'

    test_task3 = Task()
    test_task3._uuid = "test_task3"
    test_task3.name = 'third task'

    test_block = Block()
    test_block._uuid = "test_block"
    test_block.block = [test_task1, test_task2]
    test_block.rescue = [test_task3]

    test_play.serialize()

    test_play_iterator = Play

# Generated at 2022-06-10 23:19:13.156592
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # given a failing task
    task = MockTask()
    task.name = "test task"
    # executed in a block
    block = Block()
    block.block = [ task ]
    # which is one of two in a play
    play = Play()
    play._tasks = [block]
    # which is run against a single host
    host = Host('testhost')

    # when we mark the host as failed
    iterator = PlayIterator(play, [host])
    iterator.mark_host_failed(host)

    # then we should have a failed state for the host
    assert iterator.get_host_state(host) is not None
    assert iterator.get_host_state(host).run_state == PlayIterator.ITERATING_COMPLETE
    assert iterator.is_failed(host) == True
    assert host.name

# Generated at 2022-06-10 23:19:23.789490
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play = Play()
    play.load(dict(name = 'test_play'), variable_manager=variable_manager, loader=loader)
    play_iterator = PlayIterator()
    play_iterator._play = play

    # check the case in which the host state is None
    play_iterator._host_states = {'host1': None}
    (orig_host, orig_task) = play_iterator.get_original_task(host=dict(name='host1'), task=dict(action='task1'))
    assert (orig_host is None)
    assert (orig_task is None)

    # check the case in which the state is present, but has never played any tasks
    play_iterator._host_states = {'host1': HostState(play = play)}
    (orig_host, orig_task) = play_iterator.get

# Generated at 2022-06-10 23:19:35.483178
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Unit test for method is_any_block_rescuing of class PlayIterator
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    test_play = Play().load(
        dict(
            name = "test play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                Block(
                    block = [
                        Task()
                    ]
                )
            ]
        ),
        loader = None,
        variable_manager = None
    )

    test_iterator = PlayIterator(
        inventory = None,
        play = test_play,
        variable_manager = None
    )

    # With a state of ITERATING_TASKS, the method should return False

# Generated at 2022-06-10 23:19:36.172221
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    pass

# Generated at 2022-06-10 23:19:45.391232
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    play = Play()
    play._is_special = True
    play._hosts = HostInventory([
        Host("host1"),
        Host("host2"),
        Host("host3")
    ])
    play._tasks = [
        Task("task1", "host1", "task1"),
        Task("task2", "host2", "task2")
    ]

# Generated at 2022-06-10 23:19:58.009808
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    """ Test add_tasks of PlayIterator class """
    # Setup test
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['somehost'])
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name = "test play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="shell", args="ls"), register='shell_out'),
            dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}"))),
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-10 23:20:09.032505
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Test for method get_original_task(self, host, task)
    # Unknown task is returned unchanged
    play, inventory, variable_manager = get_play_and_inventory()
    play._included_file = dict(path='/i/dont/exist')
    play._basedir = './playbooks'
    iterator = PlayIterator(play, inventory, variable_manager)
    task = Task()
    task.action = 'unittest_task'
    assert iterator.get_original_task(iterator._play.get_variable_manager()['inventory'].hosts[0], task) == (None, None)

# Generated at 2022-06-10 23:20:09.999183
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass


# Generated at 2022-06-10 23:20:11.470715
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    pass #TODO

# Generated at 2022-06-10 23:20:21.672223
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    iter = PlayIterator(play=None)
    state = HostState(blocks=[None])
    state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state = HostState(blocks=[None])
    state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state.tasks_child_state = HostState(blocks=[None])
    state.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_RESCUE
    state.tasks_child_state.tasks_child_state.rescue_child_state = HostState(blocks=[None])
    state.tasks_child_state.tasks_child_state.rescue_child_state.run_state

# Generated at 2022-06-10 23:21:31.566670
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # Patching is done here.
    with patch.object(Block, '_get_vars') as mock_get_vars:
        mock_get_vars.return_value = {
            'test1': 'test1',
            'test2': 'test2',
            'test3': 'test3'
        }
        mock_get_vars.side_effect = lambda ds: ds
        mock_vars_manager = MagicMock()
        mock_vars_manager.get_vars.return_value = {}
        mock_vars_manager.add_tasks.return_value = {}
        mock_loader = MagicMock()
        mock_play = MagicMock()
        mock_play.vars_manager = mock_vars_manager
        mock_play.get_loader.return_value

# Generated at 2022-06-10 23:21:39.972567
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    '''
    Test that PlayIterator.add_tasks correctly inserts new tasks into the play state.

    Until the PlayIterator class is reworked, we need to make sure add_tasks continues to work.
    '''
    pi = PlayIterator()
    pi._host = 'localhost'
    pi._play = Play()
    pi._play._included_file_names = []
    pi._play._included_files = {}
    pi._play._blocks = []
    pi._play._roles = []
    pi._play._role_names = []
    pi._play._vars = {}
    pi._play._default_vars = {}
    pi._play._handlers = []
    pi._play._role_handlers = {}
    pi._play._play_hosts = []

# Generated at 2022-06-10 23:21:53.191514
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    global test_result
    test_result = True
    import ansible
    import ansible.inventory
    import ansible.playbook
    import ansible.runner
    import ansible.utils
    import ansible.vars
    import ansible.callback
    TestCallback=ansible.callback.CallbackModule()
    import ansible.playbook.role
    '''test for method get_next_task_for_host in module ansible.playbook'''
    TestInventory = ansible.inventory.Inventory(host_list = [])
    TestPlaybook = ansible.playbook.PlayBook()
    TestPlaybook._loader = ansible.vars.VariableManager()
    TestVarManager = ansible.vars.VariableManager(loader=ansible.vars.DictDataLoader())
    TestVarManager._extra_vars

# Generated at 2022-06-10 23:22:01.668537
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # get_next_task_for_host() unit tests

    # get_next_task_for_host() should return the next task from the iterator
    # when called without parameters.
    play = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args='')),
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())

    tqm = TaskQueueManager(
        inventory=Inventory(loader=None),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords={},
        stdout_callback=None,
    )
    host = Host(name="test_host")

# Generated at 2022-06-10 23:22:13.476693
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    print('Running tests for method get_failed_hosts of class PlayIterator:')

    play_iterator = PlayIterator(play=play_cb())
    # Test 1
    from collections import OrderedDict
    try:
        play_iterator._host_states = OrderedDict([('host1', None), ('host2', None)])
        play_iterator.mark_host_failed('host1')
        result = play_iterator.get_failed_hosts()
    except:
        result = False
    print('Test 1 expected:True got:' + str(result))
    assert result

    # Test 2

# Generated at 2022-06-10 23:22:14.239965
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    pass

# Generated at 2022-06-10 23:22:23.643186
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    host = Host('webservers')
    play = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami'))
        ]
    ), variable_manager=VariableManager(), loader=Mock())

    pi = PlayIterator(play)
    res = pi.get_next_task_for_host(host)
    assert isinstance(res, Task)
    assert 'shell' == res.action
    assert 'ls' == res.args['args']

    res = pi.get_next_task_for_host(host)
    assert isinstance(res, Task)

# Generated at 2022-06-10 23:22:30.217030
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    class FakePlay(object):
        removed_hosts=[]
    class FakeHost(object):
        name=''
    class FakeTask(object):
        action=''
        block=None
        rescue=None
        always=None
        tags=''
    class FakeTaskResult(object):
        failed=False
    _play = FakePlay()
    _play.removed_hosts=[]
    _iterator=PlayIterator(_play)
    _iterator._host_states={}
    _iterator.flush_cached_state()
    _iterator._host_states={u'127.0.0.1': HostState(_blocks=[FakeTask(),FakeTask(),FakeTask()])}
    _iterator.get_host_state(FakeHost()).fail_state=0
    _iterator.get_host_state(FakeHost()).run_