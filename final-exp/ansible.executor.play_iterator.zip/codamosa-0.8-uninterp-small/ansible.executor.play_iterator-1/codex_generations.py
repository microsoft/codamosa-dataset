

# Generated at 2022-06-24 18:47:37.861474
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play().load('/etc/ansible/playbook.yml')
    #play = Play().load('/etc/ansible/playbook.yml', variable_manager=VariableManager())

    print(play)
    """
    play = Play().load('/etc/ansible/playbook.yml', variable_manager=VariableManager())
    #play = Play().load('/etc/ansible/playbook.yml', variable_manager=VariableManager(), loader=DataLoader())

    print(play)
    """


# Generated at 2022-06-24 18:47:48.318879
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host_state_0 = HostState('skipped, since %s does not exist')
    task_list_0 = []
    host_state_1 = HostState('skipped, since %s does not exist')
    host_state_0.add_tasks(task_list_0)
    assert host_state_0 == host_state_1


# Generated at 2022-06-24 18:47:52.802721
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play()
    strategy = 'linear'
    # Test for the constructor of class PlayIterator
    play_iterator = PlayIterator(play, strategy)
    assert play_iterator != None, "test_PlayIterator: Failed to initialize PlayIterator"
    return play_iterator


# Generated at 2022-06-24 18:47:58.247480
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    Iterator = PlayIterator()

    # test 1: no hosts have been run
    assert len(Iterator._host_states) == 0

    # test 2: hosts have been iterated over
    host_state_0 = HostState(test_case_0)
    Iterator._host_states['ansible'] = host_state_0

    assert Iterator.get_host_state(test_case_0) == host_state_0


# Generated at 2022-06-24 18:48:00.420340
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    iterator = PlayIterator()
    ret_val = iterator.add_tasks('host', 'task_list')
    assert ret_val is None


# Generated at 2022-06-24 18:48:05.734063
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    bytes_1 = b'\x81p\xe8\xa3\x10\xd7\xfe'
    bytes_2 = b'\xb9\x19\xdb\x1c(>\x13\x98'
    bytes_3 = b'\xe1{\xb2'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict

# Generated at 2022-06-24 18:48:18.752132
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_1 = HostState(str_0)
    play_iterator_0 = PlayIterator(str_0)
    play_iterator_0.get_host_state(str_0)
    if byte_conversion_0:
        byte_conversion_1 = byte_conversion_0
    else:
        byte_conversion_1 = byte_conversion_0
    if byte_conversion_1 == byte_conversion_0:
        byte_conversion_1 = byte_conversion_0
    else:
        byte_conversion_1 = byte_conversion_0


# Generated at 2022-06-24 18:48:20.185629
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # FIXME: test something
    pass


# Generated at 2022-06-24 18:48:25.420355
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    test_case_PlayIterator_add_tasks_0(host_state_0)
    test_case_PlayIterator_add_tasks_1()


# Generated at 2022-06-24 18:48:27.392527
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play_iterator_0 = PlayIterator()
    host_state_0 = HostState('default')
    host_state_1 = play_iterator_0.get_active_state(host_state_0)
    assert host_state_1 is not host_state_0


# Generated at 2022-06-24 18:48:58.703755
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)


# Generated at 2022-06-24 18:49:05.389569
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_0 = Play()
    play_iterator_0 = PlayIterator(play_0)
    # assert not play_iterator_0._is_empty()
    # assert play_iterator_0.get_active_state() is play_iterator_0._play_state

    play_iterator_0 = PlayIterator(play_0)
    # assert not play_iterator_0.get_next_task_for_host(None)
    # assert play_iterator_0.get_active_state() is play_iterator_0._play_state

    test_case_0()

# Generated at 2022-06-24 18:49:13.228286
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Create an instance of class PlayIterator
    play_iterator_0 = PlayIterator()
    # Set properties of class HostState
    host_state_0 = HostState()
    # Assign a new value to the property blocks of the object host_state_0
    host_state_0.blocks = ['skipped, since %s does not exist']
    # Set properties of class Host
    host_0 = Host()
    # Assign a new value to the property name of the object host_0
    host_0.name = 'localhost'
    # Call method mark_host_failed of class PlayIterator with arguments host_0 and host_state_0
    assert play_iterator_0.mark_host_failed(host_0, host_state_0) == None


# Generated at 2022-06-24 18:49:21.944409
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    task_0 = Task.load('/etc/ansible/roles/common/tasks/main.yml')
    task_1 = Task.load('/etc/ansible/roles/common/tasks/main.yml')
    task_2 = Task.load('/etc/ansible/roles/common/tasks/main.yml')
    task_3 = Task.load('/etc/ansible/roles/common/tasks/main.yml')
    task_4 = Task.load('/etc/ansible/roles/common/tasks/main.yml')

# Generated at 2022-06-24 18:49:22.515239
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    raise NotImplementedError()


# Generated at 2022-06-24 18:49:32.902626
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    p = Playbook()
    p.add_host({'localhost': {}})
    play = Play()
    play.set_playbook(p)
    play.hosts = ["localhost"]
    play.add_task(Task(task_name="task1"))
    play.add_task(Task(task_name="task2"))
    play.add_task(Task(task_name="task3"))
    play.add_task(Task(task_name="task4"))
    play.add_task(Task(task_name="task5"))

    itr = PlayIterator(play)
    play_itr = PlayIterator(play)
    itr.next_task_for_host("localhost")
    itr.next_task_for_host("localhost")
    itr.next_task_for_host("localhost")

# Generated at 2022-06-24 18:49:44.036339
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    bytes_0 = b'\xe1{\xb2\x13\xcb\x0b\xfc\x10\x81\xb1'
    bytes_1 = b'\x13\x96\x08\xef\x05\xdc\xe6\xdb\xc9\x08\x94\x95\x04'
    bytes_2 = b'\xd0\x8a\xc0\x91'
    str_0 = 'skipped, since %s does not exist'
    str_1 = 'task'
    host_0 = 'task'
    host_state_0 = HostState(str_0)
    task_0 = StubTask(bytes_1, bytes_2)

# Generated at 2022-06-24 18:49:52.185321
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    host_state_0 = HostState(None)
    host_state_1 = HostState(None)
    host_state_2 = HostState(None)
    host_state_3 = HostState(None)
    host_state_4 = HostState(None)
    host_state_5 = HostState(None)
    host_state_6 = HostState(None)
    host_state_7 = HostState(None)
    host_state_8 = HostState(None)
    host_state_9 = HostState(None)
    host_state_10 = HostState(None)
    host_state_11 = HostState(None)
    host_state_12 = HostState(None)
    host_state_13 = HostState(None)
    host_state_14 = HostState(None)
    host_state

# Generated at 2022-06-24 18:49:57.149274
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Setup
    state = HostState(name='setup')
    state.run_state = state.ITERATING_TASKS
    state._blocks.append(Block(name='setup'))
    state.cur_block = 0
    state.fail_state = 0
    state.did_rescue = False
    state.rescue_child_state = None
    state.always_child_state = None
    # Verification
    assert state.is_any_block_rescuing() == False


# Generated at 2022-06-24 18:50:01.506998
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    boolean_0 = host_state_0.is_failed(str_0)
    boolean_1 = host_state_0.is_failed(str_0)
    print(boolean_0)
    assert False


# Generated at 2022-06-24 18:51:24.996077
# Unit test for method copy of class HostState
def test_HostState_copy():
    str_0 = 'r'
    host_state_0 = HostState(str_0)
    host_state_0.copy()


# Generated at 2022-06-24 18:51:27.003689
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    sut = PlayIterator()
    result = sut.get_host_state()
    assert result == None


# Generated at 2022-06-24 18:51:30.473450
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host_0 = Host('host')
    host_state_0 = HostState()
    test_case = PlayIterator(host_0, host_state_0)
    # Verify the method returns False
    assert not test_case.is_failed(host_0)


# Generated at 2022-06-24 18:51:42.673786
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    state = HostState(blocks=[
        Block(name='foo', rescue=[])
    ])
    state.cur_block = 0
    state.cur_regular_task = 1
    state.run_state = PlayIterator.ITERATING_ALWAYS
    state.tasks_child_state = None
    state.rescue_child_state = None
    state.always_child_state = HostState(blocks=[
        Block(name='bar', rescue=[])
    ])
    state.always_child_state.run_state = PlayIterator.ITERATING_ALWAYS
    state.always_child_state.cur_block = 0
    state.always_child_state.cur_regular_task = 0
    state.always_child_state.run_state = PlayIterator.ITERATING_ALWAYS
    state.always_child_state

# Generated at 2022-06-24 18:51:55.001281
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():

    host0 = MockHost('host0')
    host1 = MockHost('host1')
    host2 = MockHost('host2')

    host_state0 = HostState()
    host_state1 = HostState()
    host_state2 = HostState()
    host_state0._blocks[0].block = [1, 2, 3]
    host_state0._blocks[0].rescue = [MockTask(1), 2, 3]
    host_state0._blocks[0].always = [MockTask(1), MockTask(2), MockTask(3)]
    host_state0._blocks[0].failed_when = True

    host_state1._blocks[0].block = [1, 2, 3]

# Generated at 2022-06-24 18:51:59.124032
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    host_state_0.get_original_task(bytes_0, bytes_0)

test_case_0()

# Generated at 2022-06-24 18:52:06.010441
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    host_state_0.task_error = str_0
    actual = host_state_0.__str__()
    assert actual == host_state_0.is_block_start, "actual %s != expected %s" % (actual, host_state_0.is_block_start)
    assert actual == str_0, "actual %s != expected %s" % (actual, str_0)
    assert actual == host_state_0.cur_block, "actual %s != expected %s" % (actual, host_state_0.cur_block)

# Generated at 2022-06-24 18:52:09.856733
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    play_iterator_0 = PlayIterator(play_0, inventory_0)
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    task_0 = Task()
    play_iterator_0.add_tasks(host_0, [task_0])



# Generated at 2022-06-24 18:52:12.553806
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host_state_0 = HostState()
    host_state_1 = HostState()
    subject = PlayIterator(host_state_0, host_state_1)
    assert subject.get_failed_hosts() == {}
    host_state_0._fail_state = False
    assert subject.get_failed_hosts() == {}


# Generated at 2022-06-24 18:52:17.752524
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host_state_0 = HostState()
    host_state_1 = HostState()
    host_state_2 = HostState()
    host_state_3 = HostState()
    host_state_3._fail_state = 8
    host_state_1._fail_state = 4
    host_state_2._fail_state = 2
    host_state_0._fail_state = 0
    host_states = {'x': host_state_0, 'y': host_state_1, 'z': host_state_2, 'zz': host_state_3}
    play_iterator = PlayIterator()
    play_iterator._host_states = host_states
    play_iterator._play = Play()
    failed_hosts = play_iterator.get_failed_hosts()


# Generated at 2022-06-24 18:53:32.419349
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    host_state_1 = HostState(str_0)
    str_1 = 's3d4Y'
    host_state_2 = HostState(str_1)


# Generated at 2022-06-24 18:53:40.628812
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # ArgSpec(args=[u'arg_1', u'arg_2', u'arg_3'], varargs=None, keywords=None, defaults=(1, 2, 3))
    byte_0 = b'\xa3\x1f'
    str_0 = 'start fred'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['1.2.3.4'] = dict_0
    str_1 = '1.2.3.4'
    dict_1[str_1] = dict_0
    dict_2 = dict()
    dict_2['1.2.3.4'] = dict_0
    dict_2[str_1] = dict_0
    dict_3 = dict()
    dict_3['1.2.3.4'] = dict_0

# Generated at 2022-06-24 18:53:48.191760
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    bytes_0 = b'*5\r\n$3\r\nMSET\r\n$3\r\na:\r\n$3\r\n0:1\r\n$5\r\na,b,c\r\n$5\r\n0,1,2\r\n'
    play_0 = Play().load(bytes_0, loader=DataLoader())
    state_0 = PlayIterator(play_0)
    host_0 = Host('testhost')
    state_0.mark_host_failed(host_0)
    test_0 = state_0.is_failed(host_0)
    assert test_0 == True


# Generated at 2022-06-24 18:53:58.110322
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    str_1 = 'xhGdHX'
    str_2 = 'xhGdHX'
    host_0 = Host(str_1)
    str_3 = 'xhGdHX'
    str_4 = 'xhGdHX'
    var_0 = dict(name=str_2, delegate_to=str_3, debug=str_4)
    task_0 = Task(var_0)
    tuple_0 = (str_4, None)
    return_value_0 = host_state_0.get_original_task(host_0, task_0)
    assert tuple

# Generated at 2022-06-24 18:54:04.692046
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play_iterator_0 = PlayIterator(test_case_0(), 1)
    host_state_0 = HostState(False)
    host_state_0.cur_regular_task = 39
    host_state_0._blocks = HostState._blocks
    host_state_0._blocks[0].block.reverse()
    host_state_0.run_state = 39
    host_state_0.always_child_state = None
    host_state_0.cur_rescue_task = HostState.cur_rescue_task
    host_state_0.fail_state = HostState.fail_state
    host_state_0.tasks_child_state = None
    host_state_0.rescue_child_state = HostState.rescue_child_state
    host_state_0.cur_block = Host

# Generated at 2022-06-24 18:54:13.015851
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator(play_0)
    block_0 = Block.load(block_0_block_1())
    state_0 = HostState((block_0, block_0))
    state_1 = state_0
    result = play_iterator_0.get_next_task_for_host(host_0, state_1)
    assert result == None


# Generated at 2022-06-24 18:54:15.961726
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Setup
    inventory = Inventory([]);
    play = Play();
    play_context = PlayContext();
    loader = None;

    # Test Constructor
    pi = PlayIterator(inventory, play, play_context, loader)


# Generated at 2022-06-24 18:54:22.780885
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    print('Testing PlayIterator.add_tasks()')
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    test_case_0()


# Generated at 2022-06-24 18:54:31.910663
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    fail = False
    try:
        play_iterator_0 = PlayIterator(play_1)
        play_iterator_1 = PlayIterator(play_0)
        play_iterator_2 = PlayIterator(play_0)
        play_iterator_3 = PlayIterator(play_0)
        play_iterator_4 = PlayIterator(play_0)
        play_iterator_5 = PlayIterator(play_0)
        play_iterator_6 = PlayIterator(play_0)
        play_iterator_7 = PlayIterator(play_0)
        play_iterator_8 = PlayIterator(play_0)
        play_iterator_9 = PlayIterator(None)
    except Exception as e:
        print(e)
        fail = True
    assert not fail, "Test failed"


# Generated at 2022-06-24 18:54:39.405097
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    bytes_0 = b'\xe1{\xb2'
    str_0 = 'skipped, since %s does not exist'
    host_state_0 = HostState(str_0)
    block_0 = Block()
    state_0 = PlayIterator(block_0, host_state_0)
    play_iterator_0 = state_0.get_active_state(host_state_0)
