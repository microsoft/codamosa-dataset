

# Generated at 2022-06-24 18:47:17.707393
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    block_state_0 = host_state_0.get_current_block()
    task_list_0 = []
    block_0 = Block()
    block_1 = block_0.copy()
    block_1.block = task_list_0
    block_list_0 = [block_1]
    play_0 = Play().load(block_list_0, loader=None, variable_manager=None, loader_cache=False)
    play_iterator_0 = PlayIterator(play_0)
    play_iterator_0.add_tasks(None, task_list_0)

# Generated at 2022-06-24 18:47:23.807614
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    bytes_0 = b'\x89'
    list_0 = [bytes_0]
    host_0 = Host(list_0, False)
    host_state_0 = HostState(list_0)
    bytes_1 = b'\x89'
    list_1 = [bytes_1]
    task_0 = Task(list_1, None)
    tuple_0 = (None, None)
    play_iterator_0 = PlayIterator(play_0)
    tuple_1 = play_iterator_0.get_original_task(host_0, task_0)
    # AssertionError: expected tuple, got tuple
    assert tuple_1 == tuple_0, "expected {}, got {}".format(tuple_0, tuple_1)

if __name__ == '__main__':
    test_case

# Generated at 2022-06-24 18:47:24.960323
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    container = PlayIterator(None)
    assert container.get_host_state(None) is None


# Generated at 2022-06-24 18:47:33.631552
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # Test with a known value, expected to be True
    host = Host()
    s = State()
    pi = PlayIterator(s, Host, Host.name)
    pi.mark_host_failed(host)
    assert pi.is_failed(host) == True, "is_failed could not find the failure state!"

    # Test with a known value, expected to be False
    host1 = Host()
    host2 = Host()
    s = State()
    pi = PlayIterator(s, Host, Host.name)
    pi.mark_host_failed(host1)
    assert pi.is_failed(host2) == False, "is_failed could not find the failure state!"


# Generated at 2022-06-24 18:47:38.224408
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    var_0 = host_state_0.is_any_block_rescuing()


# Generated at 2022-06-24 18:47:46.872389
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    param_0 = []
    var_0 = PlayIterator(param_0)
    assert var_0.run is True
    assert var_0.play is param_0
    assert var_0.inventory is param_0[0]
    assert var_0.loader is param_0[1]
    assert var_0.variable_manager is param_0[2]
    assert var_0._host_states is {}
    assert var_0._host_state is None
    assert var_0._host is None
    assert var_0._task is None
    assert var_0._last_task_banner is None
    assert var_0._last_task_name is None
    assert var_0.run_state is var_0.ITERATING_SETUP
    assert var_0._result_loop is False
    assert var_

# Generated at 2022-06-24 18:47:47.661662
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass


# Generated at 2022-06-24 18:47:49.409044
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host_state_0 = HostState(set())


# Generated at 2022-06-24 18:47:59.358482
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    p = Playbook().load('test/ansible/playbooks/test_failure.yml')
    assert len(p) == 1

    lsi = PlayIterator(p)
    assert isinstance(lsi, PlayIterator)

    assert lsi.get_failed_hosts() == {}
    lsi.mark_host_failed(Host('badhost'))
    failed_hosts = lsi.get_failed_hosts()
    assert isinstance(failed_hosts, dict)
    assert failed_hosts == {Host('badhost'):True}
    lsi.mark_host_failed(Host('badhost2'))
    failed_hosts = lsi.get_failed_hosts()
    assert isinstance(failed_hosts, dict)

# Generated at 2022-06-24 18:48:06.421650
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play().load('/home/daniel/projects/ansible/v2-devel/test/integration/targets/complex_loop')
    play.post_validate()
    play.instantiate(play._loader.get_basedir())
    play_iterator = PlayIterator(play)

    # Test with host_name = 'host_1'
    host_1 = Host("host_1")
    play_iterator.mark_host_failed(host_1)

    # Test with host_name = 'host_2'
    host_2 = Host("host_2")
    play_iterator.mark_host_failed(host_2)

    # Test with host_name = 'host_3'
    host_3 = Host("host_3")

# Generated at 2022-06-24 18:48:48.583181
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # setup
    blocks = [ Block("block 1", []) ]
    hosts = [ Host("127.0.0.1") ]
    play = Play("play 1", hosts, [], [], [])
    iterator = PlayIterator(play)
    iterator._host_states[hosts[0].name] = HostState(blocks)

    # test
    iterator.mark_host_failed(hosts[0])



# Generated at 2022-06-24 18:48:58.662381
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    output = StringIO()
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    var_0 = host_state_0.get_current_block()
    bytes_1 = b'\x89'
    set_1 = {bytes_1, bytes_1, bytes_1}
    host_state_1 = HostState(set_1)
    var_1 = host_state_1.get_current_block()
    bytes_2 = b'\x89'
    set_2 = {bytes_2, bytes_2, bytes_2}
    host_state_2 = HostState(set_2)
    var_2 = host_state_2.get_current_block()


# Generated at 2022-06-24 18:49:01.004982
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():

    playiterator_0 = PlayIterator()
    try:
        playiterator_0.add_tasks()
    except Exception as exception_0:
        print('exception: ', exception_0)


# Generated at 2022-06-24 18:49:08.546507
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    host_state_0.cur_block = 0
    host_state_0.cur_regular_task = 0
    host_state_0.cur_rescue_task = 0
    host_state_0.cur_always_task = 0
    host_state_0.run_state = 3
    host_state_0.fail_state = 2
    host_state_0.pending_setup = False
    host_state_0.did_rescue = True
    host_state_0.did_start_at_task = True
    host_state_1 = HostState(set_0)
    host_state_1.cur

# Generated at 2022-06-24 18:49:13.926871
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    play_iterator_0 = PlayIterator(host_state_0)
    host_0 = Host()
    play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:49:18.865471
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    play_iterator_0 = PlayIterator(set_0)
    host_0 = 'set'
    var_0 = play_iterator_0.get_active_state(host_0)


# Generated at 2022-06-24 18:49:26.193668
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    host_0 = Host(name='foo')
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    play_0 = Play()
    play_iterator_0 = PlayIterator(play_0)
    # If get_host_state(obj) raises SystemError and obj._play_iterator.is_failed(obj) returns False, then the return value of get_host_state(obj) should be None
    try:
        raise SystemError
    except SystemError:
        var_0 = play_iterator_0.get_host_state(host_0)
        assert var_0 is None
    # If get_host_state(obj) raises SystemError, then the return value of get_host_state(

# Generated at 2022-06-24 18:49:32.268622
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Setup
    play = Play()
    host = Host(name='foo')
    iterator = PlayIterator(play)
    t1 = Task()
    t2 = Task()
    t3 = Task()
    play._tasks = [t1, t2, t3]

    # Test REFUSED
    result = iterator.get_next_task_for_host(host)
    assert result is None

    # Test ACCEPT
    iterator.mark_host_done(host)
    result = iterator.get_next_task_for_host(host)
    assert result is t1

    # Test ACCEPT
    iterator.mark_host_done(host, t1)
    result = iterator.get_next_task_for_host(host)
    assert result is t2



# Generated at 2022-06-24 18:49:34.232385
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # TODO: Setup
    # TODO: Action
    # TODO: Assert
    pass


# Generated at 2022-06-24 18:49:36.558971
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Test instantiation of class PlayIterator
    play_iterator_0 = PlayIterator()

    # Cleanup - none

    return


# Generated at 2022-06-24 18:50:39.211860
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    pass
# }}}

# Generated at 2022-06-24 18:50:48.377260
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Arrange
    _runner = '_runner'
    _inventory = Inventory(
        host_list=['172.18.0.3', '172.18.0.2'],
        _variable_manager=VariableManager(),
        loader=DictDataLoader()
    )
    _options = '_options'
    _variable_manager = VariableManager()
    _loader = DictDataLoader()
    _play_context = PlayContext()

    play_source = dict(
        name="Ansible Play",
        hosts='webservers',
        gather_facts='no',
        tasks=[dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))]
    )

    #

# Generated at 2022-06-24 18:50:54.167963
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    play_iterator_0 = PlayIterator(set_0, host_state_0)
    host_0 = MagicMock()
    task_0 = MagicMock()
    dict_0 = dict()
    dict_1 = dict()
    dict_0[host_0] = dict_1
    play_iterator_0._host_states = dict_0
    play_iterator_0.add_tasks(host_0, task_0)


# Generated at 2022-06-24 18:50:57.858473
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # Set up mock objects

    # Invoke method
    try:
        PlayIterator.cache_block_tasks(bytes_0)
    except:
        pass



# Generated at 2022-06-24 18:51:03.472587
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    bytes_0 = b'\x89'
    set_0 = {bytes_0, bytes_0, bytes_0}
    host_state_0 = HostState(set_0)
    iterator_0 = PlayIterator()
    iterator_0._host_states[bytes_0] = host_state_0
    host_0 = Host(bytes_0)
    host_state_1 = iterator_0.get_host_state(host_0)


# Generated at 2022-06-24 18:51:07.668213
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Given
    play_iterator_0 = PlayIterator(staticmethod(), staticmethod(), staticmethod())
    host_0 = Host(staticmethod(), staticmethod())
    # When
    result_0 = play_iterator_0.get_next_task_for_host(host_0)
    # Then
    assert (result_0 == (None, None))


# Generated at 2022-06-24 18:51:16.452325
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # No need to test this because it's just a few getters and setters

    # Let's test some stuff now
    bytes_0 = b'\x89'
    bytes_1 = b'\x89'
    list_0 = [bytes_0, bytes_1, bytes_1, bytes_0]
    set_0 = {bytes_0, bytes_1, bytes_1, bytes_0}
    host_state_0 = HostState(set_0)
    host_0 = Host('localhost', name='localhost')
    play_0 = Play()
    play_iterator_0 = PlayIterator(play_0)
    var_0 = play_iterator_0.get_host_state(host_0)
    var_1 = play_iterator_0.get_active_state(var_0)


# Generated at 2022-06-24 18:51:23.274057
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play()
    all_hosts = Hosts()
    all_hosts._hosts = ['host1', 'host2']
    all_hosts._patterns = ['host1', 'host2']
    iterator = PlayIterator(play, all_hosts)
    test_case_0()

if __name__ == '__main__':
    test_PlayIterator()

# Generated at 2022-06-24 18:51:28.775068
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # unit tests are currently skipped because they are broken
    pass
    # #
    # # the host used for the test
    # #
    # test_host = Host(name = "test_host", port = 22)
    #
    # #
    # # the play used for the test
    # #
    # test_play = Play.load(dict(
    #     name = "test play",
    #     hosts = "test_host",
    #     gather_facts = "no",
    #     tasks = [
    #         dict(action=dict(module="shell", args="echo hi")),
    #         dict(action=dict(module="shell", args="echo hello")),
    #         dict(action=dict(module="shell", args="echo goodbye")),
    #         dict(action=dict(module="shell",

# Generated at 2022-06-24 18:51:34.282436
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_0 = []
    inventory_0 = []
    play_book_runner_0 = PlayBookRunner(play_0, inventory_0)
    play_iterator_0 = PlayIterator(play_book_runner_0._play, play_book_runner_0)

if __name__ == '__main__':
    import random
    test_PlayIterator()

# Generated at 2022-06-24 18:54:04.960583
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    var_0 = PlayIterator(locals(),None,None,None)
    var_0.set_host_state(None,None)
    host_state_0 = HostState('4TvE2\t\tUA9%W\nh~')
    var_1 = var_0.get_active_state(host_state_0)


# Generated at 2022-06-24 18:54:15.039903
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play_iterator_0 = PlayIterator(play=None, loader=None, play_context=None, variable_manager=None, all_vars=None)
    play_iterator_0.get_failed_hosts()
    host_state_0 = play_iterator_0._host_states
    play_iterator_0._host_states = (host_state_0)
    play_iterator_0.get_failed_hosts()
    play_iterator_0._host_states = (host_state_0)
    play_iterator_0.get_failed_hosts()


# Generated at 2022-06-24 18:54:17.050949
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play_iterator_0 = PlayIterator()
    host_0 = Host()
    host_0.name = 'test_host'
    play_iterator_0.mark_host_failed(host_0)
    play_iterator_0.get_failed_hosts()


# Generated at 2022-06-24 18:54:24.713781
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    hs = HostState()
    pl = Play()
    pl.hosts = [1,2,3]
    pl._iterator = PlayIterator(pl, pl.hosts)
    pl._iterator._host_states = {1: {1:hs}}
    if pl._iterator.get_host_state(1) != hs:
        raise Exception('expecting: {id:id} to equal: {hs}')

if __name__ == '__main__':
    pass
    test_case_0()
    test_PlayIterator_get_host_state()

# Generated at 2022-06-24 18:54:25.724242
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    print_test_48(test_case_0)


# Generated at 2022-06-24 18:54:30.103927
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    var_0 = test_case_0()
    var_1 = var_0.is_failed()
    assert var_1 == None, "Value expected: None"


# Generated at 2022-06-24 18:54:34.556120
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    t_host_0 = Host(name='test_host')
    play_iterator_0 = PlayIterator(t_host_0)
    t_host_1 = Host(name='test_host')
    play_iterator_0.mark_host_failed(t_host_1)
    assert play_iterator_0.is_failed(t_host_1)


# Generated at 2022-06-24 18:54:40.498063
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Assert that TypeError is raised when not sufficient amount of parameters are passed
    # (PlayIterator.get_host_state(host) raises TypeError)
    with pytest.raises(TypeError):
        play_iterator_obj = PlayIterator()
        play_iterator_obj.get_host_state()
    str_0 = '*'
    host_0 = Host(str_0)
    play_0 = Play()
    play_iterator_obj = PlayIterator(play=play_0)
    host_state_0 = play_iterator_obj.get_host_state(host_0)
    assert host_state_0 is play_0._iterator.get_host_state(host_0)


# Generated at 2022-06-24 18:54:47.085127
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pi = PlayIterator()
    pi._host_states = {
        "host1": HostState("host1\t0\tT\t0\t0\t0\t0\t0\t0")
    }
    play = Play.load(dict(
        name = "foo",
        hosts = "foobar",
        gather_facts = "no",
        roles = [],
        tasks = [
            dict(action=dict(module='something', args=dict())),
            dict(action=dict(module='something_else', args=dict()))
        ]
    ), loader=None, variable_manager=None)
    pi._play = play
    host = Host(name="host1")

# Generated at 2022-06-24 18:54:49.756650
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    test_case_0()

