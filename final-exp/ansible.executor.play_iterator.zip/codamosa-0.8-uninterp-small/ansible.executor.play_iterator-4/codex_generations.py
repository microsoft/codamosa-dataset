

# Generated at 2022-06-24 18:46:58.801720
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Testing if state run_state is ITERATING_TASKS, then it will check if state tasks_child_state is None or not
    state = HostState(None)
    state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state = None
    f = PlayIterator()
    assert f.is_any_block_rescuing(state) == False

    state.tasks_child_state = HostState(None)
    state.tasks_child_state.run_state = PlayIterator.ITERATING_RESCUE
    assert f.is_any_block_rescuing(state) == True

    state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    assert f.is_any_block_rescuing(state)

# Generated at 2022-06-24 18:47:02.006907
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    dict_0 = dict()
    host_state_0 = HostState(dict_0)
    play_iterator_0 = PlayIterator(None, None)
    play_iterator_0.get_active_state(host_state_0)


# Generated at 2022-06-24 18:47:04.012475
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # No need to test -- this is just state management
    return


# Generated at 2022-06-24 18:47:11.489129
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    play_context_0 = PlayContext()
    play_0 = Play().load('test/test_playbooks/valid_playbooks/test_include_tasks.yml', play_context_0, loader=Mock())
    play_iterator_0 = PlayIterator(play_0)
    dict_1 = dict()
    dict_1['testhost'] = host_state_0
    play_iterator_0._host_states = dict_1
    dict_2 = play_iterator_0.get_failed_hosts()
    assert dict_2 == dict()


# Generated at 2022-06-24 18:47:17.581736
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator(None)

    blocks_0 = [ Block(None, [], [], None) ]
    host_state_0 = HostState(blocks_0)

    host_0 = Host(dict())
    task_0 = None

    (host_state_0, task_0) = play_iterator_0.get_next_task_for_host(host_state_0, host_0)
    assert task_0 is None

    play_iterator_0.get_next_task_for_host(host_state_0, host_0) # not reached


# Generated at 2022-06-24 18:47:23.733923
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    dict_0 = {}
    dict_0['blocks'] = None
    dict_0['run_state'] = 0
    dict_0['cur_block'] = 0
    dict_0['cur_task'] = 0
    dict_0['child_state'] = None
    dict_0['defer_results_queue'] = None
    dict_0['fail_state'] = 0
    host_state_0 = HostState(dict_0)
    dict_1 = None
    dict_0['child_state'] = host_state_0
    dict_2 = {}
    dict_2['name'] = 'a'
    dict_2['vars'] = {}
    dict_3 = {}
    dict_3['block'] = None
    dict_3['run_state'] = 2

# Generated at 2022-06-24 18:47:32.723571
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    dict_0 = {}
    inventory_0 = Inventory(dict_0)
    dict_1 = {}
    variable_manager_0 = VariableManager(loader=None, inventory=inventory_0, version_info=C.DEFAULT_LOCAL_TMP, variable_manager=dict_1)
    dict_2 = {}
    play_source_0 = dict_2
    list_0 = []
    play_0 = Play().load(play_source_0, variable_manager_0, list_0)
    playbook_0 = Playbook(list_0)
    play_context_0 = PlayContext()
    play_iterator_0 = PlayIterator(playbook_0, play_0, variable_manager_0, play_context_0)
    test_case_0()
    test_case_1()
    test_case_2

# Generated at 2022-06-24 18:47:36.451676
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    print("Testing PlayIterator.get_host_state()")
    play_iterator_0 = PlayIterator(dict_0, dict_1)
    host_0 = Host('name_0')
    host_state_0 = play_iterator_0.get_host_state(host_0)


# Generated at 2022-06-24 18:47:42.414959
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    dict_0 = {}
    host_state_0 = HostState(dict_0)
    dict_1 = {}
    host_state_1 = HostState(dict_1)
    assert host_state_0 == host_state_1


# Generated at 2022-06-24 18:47:43.382223
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # fixme: implement tests
    pass


# Generated at 2022-06-24 18:48:23.709202
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Assertions
    assert PlayIterator.is_any_block_rescuing(HostState)  == False


# Generated at 2022-06-24 18:48:26.897331
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    dict_0 = dict()
    dict_0['play'] = None
    dict_0['_hosts'] = None

    playiterator_0 = PlayIterator(dict_0)
    playiterator_0.get_failed_hosts()


# Generated at 2022-06-24 18:48:28.643957
# Unit test for method copy of class HostState
def test_HostState_copy():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    host_state_1 = host_state_0.copy()


# Generated at 2022-06-24 18:48:36.320176
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_iterator_0 = PlayIterator(play_iterator_state_0, play_iterator_0)
    assert play_iterator_0.state == play_iterator_state_0
    assert play_iterator_0.play == play_iterator_0

    play_iterator_1 = PlayIterator()
    play_iterator_1.host_state = play_iterator_host_state_0
    play_iterator_1.setup_hosts()
    assert play_iterator_1.host_state == {}


# Unit tests for get_next_task_for_host

# Generated at 2022-06-24 18:48:43.561924
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    play_iterator_0 = PlayIterator()
    host_0 = Host()
    display.display("host_0:" + str(host_0))
    assert play_iterator_0.is_failed(host_0) == False
    assert play_iterator_0.is_failed(host_0) == False
    assert play_iterator_0.is_failed(host_0) == False
    assert play_iterator_0.is_failed(host_0) == False

# Generated at 2022-06-24 18:48:48.869882
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    print("Testing PlayIterator.mark_host_failed")
    play_iterator_0 = PlayIterator(None)
    play_iterator_0._host_states = {}
    play_iterator_0._host_states[0] = None
    play_iterator_0.mark_host_failed(None)


# Generated at 2022-06-24 18:48:58.849331
# Unit test for method copy of class HostState
def test_HostState_copy():
    state_0 = HostState([])
    state_0.cur_block = 0
    state_0.cur_regular_task = 0
    state_0.cur_rescue_task = 0
    state_0.cur_always_task = 0
    state_0.run_state = PlayIterator.ITERATING_SETUP
    state_0.fail_state = PlayIterator.FAILED_NONE
    state_0.pending_setup = False
    state_0.tasks_child_state = None
    state_0.rescue_child_state = None
    state_0.always_child_state = None
    state_0.did_rescue = False
    state_0.did_start_at_task = False
    state_copy = state_0.copy()
    print (state_copy)


# Generated at 2022-06-24 18:49:07.458568
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    # test if any block is rescuing
    host_state_1 = host_state_0.copy()
    host_state_1.run_state = ITERATING_RESCUE
    assert PlayIterator.is_any_block_rescuing(host_state_0) == False
    assert PlayIterator.is_any_block_rescuing(host_state_1) == True
    # test if any child block is rescuing
    host_state_2 = host_state_0.copy()
    host_state_2.tasks_child_state = host_state_0.copy()
    host_state_2.tasks_child_state.cur_regular_task = 5

# Generated at 2022-06-24 18:49:09.473943
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    if (PlayIterator._host_states != None):  # not required
        PlayIterator_get_host_state()


# Generated at 2022-06-24 18:49:13.934353
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    dict_0 = dict()
    host_0 = Host(dict_0)

    block_0 = Block(None, None, None)
    play_0 = Play(None, None, None)
    iterator_0 = PlayIterator(play_0, None)
    iterator_0._populate_block_list(block_0)
    iterator_0.cache_block_tasks(host_0, block_0)
    # Test coverage asserts here
    assert True


# Generated at 2022-06-24 18:49:45.464459
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    try:
        obj = PlayIterator(dict_0)
        obj.get_next_task_for_host()
        obj.add_tasks(host_0, task_list_0)
        obj.mark_host_failed(host_0)
        obj.get_active_state(host_state_0)
        obj.get_failed_hosts()
        obj.is_any_block_rescuing(host_state_0)
        obj.get_original_task(host_0, task_0)
        obj.is_failed(host_0)
        obj.get_host_state(host_0)
    except:
        traceback.print_exc()
        logger.error('\n%s', traceback.format_exc())
        print('\n%s', traceback.format_exc())

# Generated at 2022-06-24 18:49:46.138221
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    test_case_0()


# Generated at 2022-06-24 18:49:53.060991
# Unit test for method is_failed of class PlayIterator

# Generated at 2022-06-24 18:49:54.558976
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    '''
    Unit test for method add_tasks of class PlayIterator
    '''
    test_case_0()
    return True


# Generated at 2022-06-24 18:49:59.107199
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_0 = Play()
    hosts_0 = []
    inventory_0 = Inventory(hosts_0)
    variable_manager_0 = VariableManager()
    play_iterator_0 = PlayIterator(play_0, inventory_0, variable_manager_0)
    play_iterator_0 = PlayIterator(play_0=play_0, inventory_0=inventory_0, variable_manager_0=variable_manager_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0 = PlayIterator(play_0=play_0, inventory_0=inventory_0, variable_manager_0=variable_manager_0)


# Generated at 2022-06-24 18:50:00.932270
# Unit test for method copy of class HostState
def test_HostState_copy():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    var_1 = host_state_0.copy()



# Generated at 2022-06-24 18:50:07.435442
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    dict_0 = dict()
    dict_0['a'] = 'a'
    host_state_0 = HostState(dict_0)
    list_0 = list()
    list_0.append(host_state_0)
    list_0.append(host_state_0)
    list_0.append(host_state_0)
    list_0.append(host_state_0)
    play_iterator_0 = PlayIterator(list_0)
    dict_1 = dict()
    dict_1['a'] = 'a'
    play_iterator_0._host_states = dict_1
    host_0 = Host('a')
    host_1 = Host('a')
    dict_2 = dict()
    dict_2['a'] = 'a'

# Generated at 2022-06-24 18:50:16.666113
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    display.display("TESTING cache_block_tasks")

    # Create a test Play object
    play_0 = Play()

    # Create two test hosts
    host_1 = Host('testhost1')
    host_2 = Host('testhost2')

    # Create a test task list
    task_0 = Statement()
    task_1 = Statement()
    task_2 = Statement()
    task_list_0 = [task_0, task_1, task_2]

    # Create a test block
    block_0 = Block(task_list_0)

    # Create a test iterator
    play_iterator_0 = PlayIterator(play_0)

    # Call method using task_list_0 and block_0

# Generated at 2022-06-24 18:50:25.507010
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play_iterator_0 = PlayIterator(play_0, loader_0, variable_manager_0, options_0)
    play_iterator_0._host_states = host_states_0
    play_iterator_0._play = play_0
    play_iterator_0._play = play_0
    host_state_0 = play_iterator_0.get_host_state('127.0.0.1')
    state_0 = HostState(dict_0)
    state_0.run_state = 4
    test_result_0 = play_iterator_0.get_active_state(state_0)
    return test_result_0


# Generated at 2022-06-24 18:50:27.298370
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    # No exception is thrown if the test passes
    test_case_0()
    


# Generated at 2022-06-24 18:51:13.746070
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    assert host_state_0.__str__() == 'HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, ' \
                                     'fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), ' \
                                     'rescue child state? (None), always child state? (None), did rescue? False, ' \
                                     'did start at task? False'


# Generated at 2022-06-24 18:51:21.185004
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Test case setup
    blocks = [Block([Task()]), Block([Task()])]
    dict_0 = {'play': None,
              '_blocks': blocks,
              }
    host_0 = Host('testhost')
    host_1 = Host('testhost')
    host_list = [host_0, host_1]
    dict_1 = {'play': None,
              'hosts': host_list,
              '_hosts': host_list,
              'host_state_map': {host_0: host_state_0},
              }
    play_0 = Play(dict_1)

# Generated at 2022-06-24 18:51:26.297081
# Unit test for method copy of class HostState
def test_HostState_copy():
    # host_state_0 refers to HostState object
    # test_case_0 tests function copy of class HostState
    host_state_0 = HostState(test_case_0())
    # test_case_1 tests function __eq__ of class HostState
    host_state_1 = HostState(test_case_0())
    host_state_1 = host_state_1.copy()
    # test_case_2 tests function __eq__ of class HostState
    host_state_2 = HostState(test_case_0())
    host_state_2 = host_state_2.copy()



# Generated at 2022-06-24 18:51:38.541567
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play_0 = Play()
    playcontext_0 = PlayContext()
    host_0 = Host(name='host_0')
    host_0.name = 'host_0'
    play_0._variable_manager = VariableManager()
    play_0._variable_manager.extra_vars = dict()
    play_0._variable_manager._options_vars = dict()
    play_0._variable_manager._extra_args = dict()
    play_0._variable_manager.extra_vars = dict()
    play_0._tqm = TaskQueueManager(play_0, playcontext_0, playbook_ds=dict(), loader=None, passwords=dict())
    play_0.injectors = dict()
    play_0._tqm._variable_manager = dict()

# Generated at 2022-06-24 18:51:43.573436
# Unit test for method copy of class HostState
def test_HostState_copy():
    dict_0 = ["setup", "tasks"]
    host_state_0 = HostState(dict_0)
    host_state_0.cur_block = 2
    host_state_0.cur_regular_task = 2
    host_state_0.cur_rescue_task = 2
    host_state_0.cur_always_task = 2
    host_state_0.tasks_child_state = None
    host_state_0.rescue_child_state = None
    host_state_0.always_child_state = None
    assert_equals(host_state_0.copy(), host_state_0)


# Generated at 2022-06-24 18:51:52.488326
# Unit test for method copy of class HostState
def test_HostState_copy():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    host_state_1 = HostState(dict_0)
    assert host_state_1 is not host_state_0
    host_state_2 = host_state_1.copy()
    assert host_state_2 is not host_state_1
    assert host_state_2 is not host_state_0
    assert host_state_0 == host_state_1 == host_state_2


# Generated at 2022-06-24 18:52:01.692575
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    dict_0 = {"run_state" : "ITERATING_TASKS", "_blocks" : []}
    host_state_0 = HostState(dict_0)
    play_iterator_0 = PlayIterator("Play_0", {"hosts" : [], "gather_facts" : "smart"})
    dict_1 = {"run_state" : "ITERATING_TASKS", "_blocks" : []}
    host_state_1 = HostState(dict_1)
    play_iterator_0.play._removed_hosts = ["localhost"]
    play_iterator_0.play._removed_hosts = ["localhost"]
    dict_2 = {play_iterator_0._play._removed_hosts[0] : host_state_0, "localhost" : host_state_1}
    play_iterator

# Generated at 2022-06-24 18:52:12.233815
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    a = Task()
    b = Task()
    c = Task()
    block = Block()
    block._setup_task_blocks = [ [ a, b ] ]
    block._task_blocks = [ [ c ] ]
    block._rescue_task_blocks = [ [ a, b ] ]
    block._always_task_blocks = [ [ c ] ]

    play = Play().load(dict(
        name = 'test',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='foo'))),
            dict(action=dict(module='debug', args=dict(msg='bar'))),
        ]
    ), loader=DictDataLoader())

    play_iterator = PlayIterator(play, patterns=['all'])


# Generated at 2022-06-24 18:52:16.846361
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host_0 = Host('host-0')
    # Iterator failure expected
    # This test case is expected to end prematurely due to a fault in the iterator
    try:
        play_iterator_0 = PlayIterator(play_0, loader_0)
    except:
        pass
    else:
        raise Exception('ExpectedException')


# Generated at 2022-06-24 18:52:19.460661
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    iterator = PlayIterator()
    fake_block_tasks = FakeModule()
    empty_block_tasks = FakeModule()
    iterator.cache_block_tasks(fake_block_tasks, empty_block_tasks)
    pass


# Generated at 2022-06-24 18:54:16.344294
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    host_0 = Host('name_0')
    task_0 = MockTask()
    play_iterator_0 = PlayIterator(play_0, inventory_0, loader_0, variable_manager_0)
    host_state_0 = play_iterator_0.get_host_state(host_0)
    play_iterator_0.get_active_state(host_state_0)
    play_iterator_0.get_active_state(host_state_0)
    play_iterator_0.get_active_state(host_state_0)
# test_PlayIterator_get_active_state()



# Generated at 2022-06-24 18:54:26.176004
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    dict_0 = None
    host_state_0 = HostState(dict_0)
    dict_0 = None
    host_state_1 = HostState(dict_0)
    play_0 = Play(hosts=None, name='play_0')
    play_iterator_0 = PlayIterator(play_0, host_state_1, host_state_0)
    play_1 = Play(hosts=None, name='play_0')
    play_iterator_1 = PlayIterator(play_1, host_state_0, host_state_1)
    play_iterator_0._host_states = play_iterator_1._host_states

# Generated at 2022-06-24 18:54:36.509805
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    import copy
    p = Play.load(dict(
        name = "foobar",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='command', args=dict(cmd='/bin/echo {{ foo }}', creates='{{ create_file }}'))),
            dict(action=dict(module='shell', args='/bin/echo hello'), register='shell_out'),
            dict(action=dict(module='command', args='/bin/false', register='shell_out'), rescue=[
                dict(action=dict(module='command', args='/bin/true', register='shell_out'))
            ]),
        ]
    ), loader=DictDataLoader())
    play_context = PlayContext()
    iterator = PlayIterator(p, [], play_context)



# Generated at 2022-06-24 18:54:43.316799
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    dict_4 = None
    host_state_4 = HostState(dict_4)
    dict_5 = "regular"
    host_state_5 = HostState(dict_5)
    dict_6 = False
    host_state_6 = HostState(dict_6)
    dict_7 = False
    host_state_7 = HostState(dict_7)
    dict_8 = False
    host_state_8 = HostState(dict_8)
    dict_9 = None
    host_state_9 = HostState(dict_9)
    dict_10 = "child"
    host_state_10 = HostState(dict_10)
    dict_11 = False
    host_state_11 = HostState(dict_11)
    dict_12 = False

# Generated at 2022-06-24 18:54:46.488877
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    dict_0 = {}
    host_state_0 = HostState(dict_0)
    assert host_state_0.get_active_state() == host_state_0


# Generated at 2022-06-24 18:54:52.191595
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host_state_0 = HostState()
    play_iterator_0 = PlayIterator()
    host_0 = Host('host_0')
    play_iterator_0.mark_host_failed(host_0)
    result = play_iterator_0.is_failed(host_0)
    assert result == True


# Generated at 2022-06-24 18:54:54.555152
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    host_state_0 = HostState(dict())
    play_iterator_0 = PlayIterator(host_state_0)
    state_0 = HostState(dict())
    assert play_iterator_0.get_active_state(state_0) == state_0


# Generated at 2022-06-24 18:55:05.971976
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play()
    play.hosts = "127.0.0.1"
    play.name = "test_play"
    play.tasks = [PlaybookIterator.PlayIterator.Task(action="copy", module_args={"src": "src", "dest": "dest"}, name='task 0'),
                  PlaybookIterator.PlayIterator.Task(action="copy", module_args={"src": "src", "dest": "dest"}, name='task 1'),
                  PlaybookIterator.PlayIterator.Task(action="copy", module_args={"src": "src", "dest": "dest"}, name='task 2')]

    hosts = [Host()]
    hosts[0].name = "127.0.0.1"
    hosts[0].groups = [Group()]
    hosts[0].groups[0].name = "all"

# Generated at 2022-06-24 18:55:16.238249
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    host_0 = Host('testhost1')
    host_1 = Host('testhost2')
    dict_0 = dict()
    dict_0['hosts'] = [host_0, host_1]
    dict_1 = dict()
    dict_1['hosts'] = [host_1]
    dict_2 = dict()
    dict_2['hosts'] = [host_0]
    task_0 = Task()
    dict_0['tasks'] = [task_0]
    dict_1['tasks'] = [task_0]
    dict_2['tasks'] = [task_0]
    host_pattern_0 = HostPattern()
    dict_0['hostpattern'] = host_pattern_0
    dict_0['play'] = dict()

# Generated at 2022-06-24 18:55:19.199215
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    block_0 = Block()
    play_0 = Play()
    play_0._variable_manager = VariableManager()
    play_iterator_0 = PlayIterator(play_0)
