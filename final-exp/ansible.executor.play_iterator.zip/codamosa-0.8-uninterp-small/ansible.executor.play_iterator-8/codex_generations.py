

# Generated at 2022-06-24 18:47:19.145837
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    int_0 = 1210
    play_iterator_0 = PlayIterator()
    play_iterator_1 = PlayIterator()
    dict_0 = play_iterator_1.get_failed_hosts()
    assert dict_0 == {}, 'Expected {} but got {}'.format({}, dict_0)


# Generated at 2022-06-24 18:47:20.721032
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Verify that we can create a PlayIterator object with a valid argument
    play_iterator_0 = PlayIterator(play_0=Play())


# Generated at 2022-06-24 18:47:27.559502
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play_iterator_0 = PlayIterator()
    play_iterator_1 = PlayIterator()
    host_0 = Host('localhost')
    play_iterator_0.mark_host_failed(host_0)
    host_0 = Host('localhost')
    play_iterator_1.mark_host_failed(host_0)
    play_iterator_0.get_original_task(host_0, task_0)
    play_iterator_1.get_original_task(host_0, task_1)


# Generated at 2022-06-24 18:47:35.644718
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    host_0 = Host(name='foobar.example.com')
    host_state_0 = HostState()
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states = {'foobar.example.com': host_state_0}
    play_iterator_0._play = object()
    host_0._play = object()
    host_0._play.removed_hosts = list()
    play_iterator_0.mark_host_failed(host_0)
    assert host_state_0.fail_state == 4
    assert host_state_0.run_state == 3
    assert 'foobar.example.com' in host_0._play.removed_hosts


# Generated at 2022-06-24 18:47:39.746246
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    int_0 = 1
    host_state_0 = HostState(int_0)
    block_0 = Block('test')
    play_iterator_0 = PlayIterator(host_state_0, block_0)
    block_0.block = [{'block': []}]
    play_iterator_0.cache_block_tasks()


# Generated at 2022-06-24 18:47:47.840725
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # PlayIterator object
    # @type object
    play_iterator_0 = PlayIterator()

    # Task object
    task_0 = Task()

    # Block object
    block_0 = Block()

    # Body of a block
    block_body_0 = [task_0]

    # Set body of block_0
    block_0.block = block_body_0
    int_0 = 1210

    # HostState object
    host_state_0 = HostState(int_0)

    # Set blocks of host_state_0
    host_state_0._blocks = [block_0]

    # @type dict[Task, tuple[PlayContext, dict[str, dict[int, dict[str, {bool, str}, {bool, str}]]]]]
    block_tasks_cache_0 = {}

    #

# Generated at 2022-06-24 18:47:52.747310
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    display.debug("test_PlayIterator_add_tasks begin")
    play_iterator_0 = PlayIterator(play_0)
    play_iterator_0.add_tasks(host_0, block_0)
    display.debug("test_PlayIterator_add_tasks end")


# Generated at 2022-06-24 18:47:53.892930
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    pass


# Generated at 2022-06-24 18:47:58.076620
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    int_0 = 1210
    host_state_0 = HostState(int_0)
    play_iterator_0 = PlayIterator(None, host_state_0)
    result = play_iterator_0.get_original_task(None, None)
    assert result[0] == None
    assert result[1] == None

# Generated at 2022-06-24 18:48:00.330142
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # test_PlayIterator_get_failed_hosts()
    display.debug("test_PlayIterator_get_failed_hosts() called")
    # FIXME: implement your test here
    display.display("FIXME: implement your test here")
    return


# Generated at 2022-06-24 18:48:29.875677
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host_state_0 = HostState(0)
    play_iterator_1 = PlayIterator(None, host_state_0)
    host_state_2 = HostState(0)
    play_iterator_1._host_states[None] = host_state_2
    host_state_2.run_state = 2
    host_state_2.run_state = 3
    host_state_2.run_state = 1
    host_state_2.run_state = 4
    host_state_2.run_state = 2
    host_state_2.run_state = 3
    host_state_2.run_state = 1
    host_state_2.run_state = 4
    host_state_2.run_state = 2
    host_state_2.run_state = 3
    host_state

# Generated at 2022-06-24 18:48:41.499611
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    int_0 = 1210
    host_state_0 = HostState(int_0)
    host_state_0.cur_block = 1211
    host_state_0.cur_regular_task = 1212
    host_state_0.cur_rescue_task = 1213
    host_state_0.cur_always_task = 1214
    host_state_0.run_state = 1215
    host_state_0.fail_state = 1216
    host_state_0.pending_setup = 1217
    host_state_0.did_rescue = 1218
    host_state_0.did_start_at_task = 1219
    int_1 = 1220
    host_state_1 = HostState(int_1)
    host_state_1.cur_block = 1221


# Generated at 2022-06-24 18:48:48.736500
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Tests that the is_failed method of PlayIterator works as expected.
    '''
    int_0 = 7335
    host_state_0 = HostState(int_0)
    play_iter_0 = PlayIterator(host_state_0)
    host_0 = MagicMock()
    assert play_iter_0.is_failed(host_0) == False
    # TODO: add test for when playbook fails


# Generated at 2022-06-24 18:48:58.803613
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Test for method get_next_task_for_host of class PlayIterator
    role = 'role_0'
    play_context_0 = PlayContext()
    from ansible.playbook import Play
    play_0 = Play(name='play_0', play_context=play_context_0)
    from ansible.playbook.block import Block
    block_list_0 = [Block(role=role, play_context=play_context_0)]
    play_0._entries = block_list_0
    display_0 = Display()
    play_iterator_0 = PlayIterator(play_0, display_0, 0, False)
    from ansible.inventory import Group
    group_0 = Group(name='group_0')
    from ansible.inventory import Host

# Generated at 2022-06-24 18:49:04.337028
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    host_state_0 = HostState()
    hosts_0 = 'anaconda'
    play_iterator_0 = PlayIterator()
    play_iterator_0._play = Play(hosts=hosts_0)
    play_iterator_0._play.name = 'lions'
    play_iterator_0._play.strategy = 'anaconda'
    play_iterator_0._play.post_validate = lambda : 0
    block_0 = Block(play_iterator_0._play)
    block_1 = Block(play_iterator_0._play)
    block_2 = Block(play_iterator_0._play)
    block_3 = Block(play_iterator_0._play)
    block_4 = Block(play_iterator_0._play)
    task_0 = Task()
    task_1 = Task

# Generated at 2022-06-24 18:49:05.774663
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    """is_failed of PlayIterator"""
    test_PlayIterator_is_failed_0()


# Generated at 2022-06-24 18:49:11.062221
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Test for method get_original_task(host, task)
    # Test example from method code
    int_0 = 1210
    host_state_0 = HostState(int_0)
    task_0 = Task()
    (task_1, task_2) = host_state_0.get_original_task(task_0)
    # Assertions on results of test
    assert(task_1 is None)
    assert(task_2 is None)



# Generated at 2022-06-24 18:49:14.982833
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # FIXME: this is probably not a valid unit test, as we don't want to be testing if a
    #        method returns None, as that is likely to change
    test_instance = PlayIterator(None)
    assert test_instance.cache_block_tasks(None) is None


# Generated at 2022-06-24 18:49:16.004475
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    test_case_0()


# Generated at 2022-06-24 18:49:18.741927
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():

    test_case_0()

if __name__ == "__main__":
    display.verbosity = 3
    #test_PlayIterator_get_original_task()
    #test_case_0()

# Generated at 2022-06-24 18:50:13.669959
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    test_case_0()

if __name__ == '__main__':
    test_PlayIterator()

# Generated at 2022-06-24 18:50:20.779296
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    my_host = Host('localhost')
    # STATE_INITIALIZED
    host_state_0 = HostState()
    display.debug("host_state_0 = %s" % host_state_0)
    play_iterator_0 = PlayIterator(play=None)
    # Returns an instance of the HostState class
    play_iterator_0.get_host_state(my_host)
    # Returns a boolean
    play_iterator_0.is_failed(my_host)


# Generated at 2022-06-24 18:50:25.506798
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # GIVEN a PlayIterator object, with a non-empty cache
    int_0 = 1086
    play_iterator_0 = PlayIterator(int_0)

    # WHEN calling cache_block_tasks
    play_iterator_0.cache_block_tasks()

    # THEN the cache must be empty
    assert play_iterator_0.cache == {}


# Generated at 2022-06-24 18:50:30.263817
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Initialization
    int_0 = 0
    play_app_0 = Play(int_0)
    int_1 = 0
    PlayIterator_0 = PlayIterator(play_app_0, int_1)
    PlayIterator_0.get_failed_hosts()

    # Execution
    PlayIterator_0.get_failed_hosts()


# Generated at 2022-06-24 18:50:36.509409
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    int_0 = 159
    host_state_0 = HostState(int_0)
    return_value_0 = host_state_0.get_active_state(None)
    return_value_1 = host_state_0.get_active_state(host_state_0)
    return_value_2 = host_state_0.get_active_state(return_value_1)


# Generated at 2022-06-24 18:50:41.816330
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    int_1 = 1210
    host_state_1 = HostState(int_1)
    host_state_1.run_state = 0
    host_1 = None
    play_iterator_0 = PlayIterator(host_1, None)
    host_state_2 = play_iterator_0.get_active_state(host_state_1)
    assert host_state_2.run_state == 0
    host_state_3 = HostState(int_1)
    host_state_1.tasks_child_state = host_state_3
    host_state_3.run_state = 0
    host_state_4 = play_iterator_0.get_active_state(host_state_1)
    assert host_state_4.run_state == 0

# Generated at 2022-06-24 18:50:50.513015
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    int_0 = 1210
    host_state_0 = HostState(int_0)
    # TODO: mock for host_state_0.get_active_state -> Throw assert error at failure
    play_iterator_0 = PlayIterator()
    play_iterator_0._play = None
    play_iterator_0._play_context = None
    play_iterator_0.set_host_states([host_state_0])
    try:
        play_iterator_0.mark_host_failed(host_state_0)
    except AssertionError as ex:
        display.debug("AssertionError exception caught in test_PlayIterator_mark_host_failed")
        display.debug(ex)
        return True
    display.error("AssertionError exception not caught in test_PlayIterator_mark_host_failed")
   

# Generated at 2022-06-24 18:50:57.121223
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    play_iterator_0 = PlayIterator()
    host_state_0 = None
    play_iterator_0._host_states = {'host_state_0': host_state_0}
    # Add an element to the dictionary
    task_list_0 = None
    display.info('test_PlayIterator_add_tasks : The element added to the dictionary is: ' + str(task_list_0))
    play_iterator_0.add_tasks('host_state_0', task_list_0)
    # Add an element to the dictionary
    task_list_1 = None
    display.info('test_PlayIterator_add_tasks : The element added to the dictionary is: ' + str(task_list_1))
    play_iterator_0.add_tasks('host_state_0', task_list_1)

# Generated at 2022-06-24 18:51:03.059847
# Unit test for method get_host_state of class PlayIterator

# Generated at 2022-06-24 18:51:11.610867
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    cm = ConnectionManager()
    loader = data_loader.DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager._extra_vars = { u'hostvars': {} }
    pb = Playbook.load(u'../test/test_playbook.yml', variable_manager=variable_manager, loader=loader)
    play = pb.get_plays()[0]
    play_iterator = PlayIterator(
        play,
        variable_manager=variable_manager,
        all_vars=dict(),
        connection_manager=cm)
    host_state_1 = HostState(play_iterator._play._block)
    for task in play_iterator._play._block.block:
        if isinstance(task, Block):
            host_state_1.tasks_child_state = Host

# Generated at 2022-06-24 18:52:55.507959
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pass


# Generated at 2022-06-24 18:52:56.774114
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    test_case_0()

if __name__ == '__main__':
    test_PlayIterator()

# Generated at 2022-06-24 18:53:06.499708
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    host_0 = Host('test-host')
    test_0 = PlayIterator(host_0)
    host_1 = Host('test-host')
    task_0 = Task(name='test-task')
    result = test_0.get_original_task(host_1, task_0)
    assert result[0] == None and result[1] == None, "PlayIterator.get_original_task(): test 1 failed"

    task_1 = Task(name='test-task')
    result = test_0.get_original_task(host_1, task_1)
    assert result[0] == None and result[1] == None, "PlayIterator.get_original_task(): test 2 failed"

if __name__ == '__main__':
    test_case_0()
    test_PlayIterator_get_

# Generated at 2022-06-24 18:53:10.178794
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    output = 'first'
    int_0 = 1210
    host_state_0 = HostState(int_0)
    play_iterator_0 = PlayIterator(host_state_0)
    play_iterator_0.mark_host_failed(output)
    output_0 = play_iterator_0.is_failed(output)
    return output_0


# Generated at 2022-06-24 18:53:16.806259
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    int_0 = 678
    host_state_0 = HostState(int_0)
    host_state_0.fail_state = 2
    #host_state_0.run_state = 2
    host_0 = type('Host', (object,), dict(name='hostname'))
    play_iterator_0 = PlayIterator(None)
    for i in range(0,200,10):
        host_state_0.run_state = i
        print(i, play_iterator_0._check_failed_state(host_state_0))


# Generated at 2022-06-24 18:53:22.515535
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    int_0 = 794
    host_state_0 = HostState(int_0)
    str_0 = host_state_0.__str__()
    # AssertionError: Expected: 'HOST STATE: block=1, task=1, rescue=1, always=1, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False' Actual: 'HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state

# Generated at 2022-06-24 18:53:31.923168
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    host_0 = Host(name='host_name_0')
    play_iter_0 = PlayIterator(play_0)
    block_0 = Block(parent_block=play_0, role=play_0.get_role())
    block_0.vars = dict()

# Generated at 2022-06-24 18:53:40.153107
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    hosts = [Host(name='example.com')]
    iterator = PlayIterator(play=Play().load(dict(
        name = 'test play',
        hosts = [host.name for host in hosts],
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='ok')))
        ]
    ), variable_manager=VariableManager(), loader=Loader()),
        inventory=Inventory(loader=None, host_list=hosts),
        all_vars={},
        play_context=PlayContext(),
        variable_manager=VariableManager(),
        loader=None
    )
    (host_state, task) = iterator._get_next_task_from_state(iterator._play_state, host=hosts[0])
    assert host_state.run_state

# Generated at 2022-06-24 18:53:41.283442
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    test = PlayIterator()
    assert test, "Test returned None"



# Generated at 2022-06-24 18:53:47.292831
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    display.debug("Testcase: test_PlayIterator_mark_host_failed")
    test_case_0()
    test_case_1()
    test_case_2()
    host_state_0 = HostState(1210)
    host_state_0 = HostState(1210)
    host_state_0 = HostState(1210)
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
