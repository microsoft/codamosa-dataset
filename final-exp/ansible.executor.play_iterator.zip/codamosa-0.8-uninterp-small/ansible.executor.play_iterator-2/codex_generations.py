

# Generated at 2022-06-24 18:47:27.126527
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    pass


# Generated at 2022-06-24 18:47:35.861219
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    display.columns = 80
    display.verbosity = 3
    connection_loader = ConnectionLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['testhost'])

# Generated at 2022-06-24 18:47:43.718055
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    global host_state_0

    action_0 = Action(None)
    action_0.host = Host('host-0')
    block_0 = Block(action_0)
    task_0 = Task(action_0, block_0)

    task_list = [task_0]
    result = PlayIterator._cache_block_tasks(block_0, task_list)

    assert result[0] == 1


# Generated at 2022-06-24 18:47:49.683958
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    play_iterator_0 = PlayIterator()
    host_0 = Host(name=b'')
    host_state_0 = HostState()
    host_state_1 = play_iterator_0.get_host_state(host_0)
    assert host_state_1 == host_state_0


# Generated at 2022-06-24 18:47:57.222096
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host = Host('test')
    play = Play()
    play_iterator = PlayIterator(play)
    host_state = HostState()
    host_state.play = play
    host_state.play_context = PlayContext()
    host_state.play_context.setup_cache()
    host_state.run_state = PlayIterator.ITERATING_COMPLETE
    host_state.fail_state = PlayIterator.FAILED_NONE
    play_iterator._host_states[host.name] = host_state
    play_iterator.is_failed(host)


# Generated at 2022-06-24 18:48:02.462924
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    host_state_0 = HostState(bytes_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states = {host_state_0}
    host_0 = Host('foo')
    assert play_iterator_0.get_host_state(host_0) == host_state_0


# Generated at 2022-06-24 18:48:09.031985
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():

    print("PlayIterator_is_any_block_rescuing")

    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    it = PlayIterator(bytes_0)
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 18:48:14.279409
# Unit test for method copy of class HostState
def test_HostState_copy():
    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    host_state_0 = HostState(bytes_0)

    import copy
    host_state_1 = copy.copy(host_state_0)
    assert host_state_1 == host_state_0


# Generated at 2022-06-24 18:48:17.835788
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    import data

    iterator = PlayIterator()

    task = Task()
    task.action = 'shell'
    task.args['command'] = 'hostname'

    host = data.simple_host
    block = Block()
    block.block = [task]
    blocks = [block]
    play = Play()
    play.hosts = [host.name]
    play.set_loader(data.mock_loader)
    play.tasks = blocks

    iterator.play = play
    result = iterator.get_next_task_for_host(host)
    assert result == task


# Generated at 2022-06-24 18:48:27.715054
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    host_0 = Host('Name-0')
    host_1 = Host('Name-1')
    host_2 = Host('Name-2')
    host_3 = Host('Name-3')
    play_0 = Play()

    assert getattr(play_0, '_removed_hosts', False) == False

    host_list_0 = [host_0, host_1, host_2, host_3]
    play_iterator_0 = PlayIterator(play_0, host_list_0)

    assert getattr(play_iterator_0, '_play', False)
    assert getattr(play_iterator_0, '_play', False) == play_0
    assert getattr(play_iterator_0, '_host_states', False)

# Generated at 2022-06-24 18:48:57.408182
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # TODO: implement this
    pass


# Generated at 2022-06-24 18:49:06.572203
# Unit test for method get_failed_hosts of class PlayIterator

# Generated at 2022-06-24 18:49:08.258370
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    print("\n*** test_PlayIterator_is_any_block_rescuing ***")


# Generated at 2022-06-24 18:49:13.373486
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play_iterator_0 = PlayIterator(['test1', 'test2', 'test3'], ['test4', 'test5', 'test6'])
    host_0 = Host('testhostname001')
    play_iterator_0.mark_host_failed(host_0)
    host_state_0 = play_iterator_0.get_host_state(host_0)
    assert host_state_0.run_state == 0
    assert host_state_0.cur_block == 0


# Generated at 2022-06-24 18:49:16.900379
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    host_state_0 = HostState(bytes_0)
    play_iterator_0 = PlayIterator()
    host_0 = Host()
    result = play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:49:24.705351
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # test_case_0 =
    context = PlayContext()
    context._host_states = dict()

# Generated at 2022-06-24 18:49:32.486683
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    try:
        PlayIterator_0 = PlayIterator()
    except:
        PlayIterator_0 = None


# Generated at 2022-06-24 18:49:39.548407
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator()
    host_0 = Host()
    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    host_state_0 = HostState(bytes_0)
    result = host_state_0.get_next_task_for_host(host_0)
    print(result)


# Generated at 2022-06-24 18:49:43.601133
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Setup for method get_original_task of class PlayIterator
    play_iterator_0 = PlayIterator()

    # assertEqual(expected, actual)
    assertEqual((None, None), play_iterator_0.get_original_task(0, 0))


# Generated at 2022-06-24 18:49:46.872499
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    play_iterator_0 = PlayIterator(Play(name='', play_hosts=[], play_group_names=[]))
    try:
        play_iterator_0.is_failed(None)
    except:
        pass


# Generated at 2022-06-24 18:50:43.860114
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    iterator = PlayIterator()
    print(iterator)



# Generated at 2022-06-24 18:50:51.978044
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    host_state_0 = HostState(bytes_0)
    task_0 = Task()
    play_0 = Play()
    task_1 = Task()
    block_0 = Block(task_1)
    block_1 = Block(task_0)
    block_2 = Block(task_0, task_1)
    block_3 = Block(task_1)
    block_4 = Block(task_0, task_1)
    block_5 = Block(task_1)
    block_6 = Block(task_0, task_1)
    task_2 = Task()
    play_0._t

# Generated at 2022-06-24 18:50:53.037605
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play()
    iterator = PlayIterator(play)


# Generated at 2022-06-24 18:51:00.685762
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # FIXME: create a test that actually exercises this
    b_0 = Block(task_list=[
        Task()
    ])

    # Find the task for each host
    host_list = [Host(qname="test_host_0"), Host(qname="test_host_1")]
    play_0 = Play()
    play_0.get_iterator = MagicMock(return_value = PlayIterator())
    play_0.hosts = host_list
    play_0.tasks = [b_0]
    play_0.roles = []
    play_0.handlers = []
    play_0.dependent_tasks = []
    play_0.vars = dict()
    play_0.default_vars = dict()
    iterator_0 = PlayIterator(play=play_0)

    #

# Generated at 2022-06-24 18:51:06.287518
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    print("test_PlayIterator_get_active_state")
    bytes_0 = b'\xc1\xd3\x9a\x9c\x17\xd6\xec\xe0\x1b\x0c\xb8!\x9b\xd7\xec\x0eK;\xaa\x01'
    host_state_0 = HostState(bytes_0)
    bytes_1 = b'\x01\xe8\x0e\x12\xe9\xe6\xc3\x1b\x03U\xf7\x04\x00\x00'
    host_state_1 = HostState(bytes_1)

# Generated at 2022-06-24 18:51:13.499060
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    host_state_0 = HostState(bytes_0)
    host_state_0.run_state = PlayIterator.ITERATING_TASKS
    host_state_0.cur_block = 4
    host_state_0.cur_regular_task = 1
    host_state_0.tasks_child_state = HostState(bytes_0)
    test_case_PlayIterator_get_original_task_0(host_state_0)


# Generated at 2022-06-24 18:51:21.008608
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    host_state_0 = HostState(b'\x0e\x17\xfa\xfc\xb1\xee4\xfb\xe6\xf0\x8b\x91e\xf1\x9b\x93\x9f')
    host_0 = Host(name='noop')
    task_0 = Task()
    task_0._has_run = False
    task_0.action = 'meta'
    task_0.args['_raw_params'] = ''
    task_0.args['_uses_delegate'] = False
    task_0.args['_uuid'] = 'noop'
    task_0.set_loader(None)
    task_0.set_play_context(PlayContext())
    task_0.role_name = ''

# Generated at 2022-06-24 18:51:28.309004
# Unit test for method is_any_block_rescuing of class PlayIterator

# Generated at 2022-06-24 18:51:40.615850
# Unit test for method is_failed of class PlayIterator

# Generated at 2022-06-24 18:51:42.738260
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play_iterator_0 = PlayIterator()
    host_0 = Host()
    play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:53:44.428470
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    # case 0
    test_case_0()


# Generated at 2022-06-24 18:53:45.401693
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    test_case_0()


# Generated at 2022-06-24 18:53:49.701947
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # This is a test of the add_tasks method, but that method is currently a noop
    # so we don't really have much to test here.
    pass


# Generated at 2022-06-24 18:53:59.195986
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    Test for PlayIterator.get_host_state
    '''

    h = dict()
    h['name'] = 'test'
    h['vars'] = dict()

    h1 = Host(h)
    h2 = Host(h)
    h3 = Host(h)
    h4 = Host(h)
    i2 = PlayIterator()

    # Test: call with empty HostStates dict
    i2._host_states = dict()
    assert i2.get_host_state(h1) is None

    # Test: call with non-empty HostStates dict but not for the named Host
    i2._host_states = {'a': 'b'}
    assert i2.get_host_state(h1) is None

    # Test: call with non-empty HostStates dict and with a named Host

# Generated at 2022-06-24 18:54:04.263938
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
   #play_iterator_0 = PlayIterator(play_0)
   #host_state_0 = HostState( )
   #play_iterator_0._host_states['host_name_0'] = host_state_0
   #host_0 = Host('host_name_0')
   #play_iterator_0.get_next_task_for_host(host_0)
   #print("task_0 = ", task_0)
   #print("host_state_0 = ", host_state_0)
   #print("play_iterator_0 = ", play_iterator_0)
   return


# Generated at 2022-06-24 18:54:06.931085
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    test_case_0()


# Generated at 2022-06-24 18:54:17.168839
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    import Host
    import Play
    import PlayContext
    import Task
    import TaskResult
    a_host = Host.Host('host1')
    a_task = Task.Task()
    a_task.name = 'task1'
    a_task.action = 'action1'
    a_task.loop = 'item'
    a_task.loop_with = 'inventory'
    a_play_context = PlayContext.PlayContext()
    a_play_context.become = False
    prev_task_result = TaskResult.TaskResult(task=a_task, host=a_host)
    self_item = 'item_0'
    self_inventory = 'inventory_0'

# Generated at 2022-06-24 18:54:25.025586
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    bytes_0 = b'\xe0\xce\x8a!)\xf3\xf2\xef[\xa8\x15\xa8\x88V\xd4U\xf8'
    host_state_0 = HostState(bytes_0)
    hostname_0 = b'o\x00\x00'
    test_0 = PlayIterator(bytes_0, hostname_0)
    result_0 = test_0.get_original_task(host_state_0, b'\x1b')
    assert result_0 == (None, None)


# Generated at 2022-06-24 18:54:25.782251
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass

# Generated at 2022-06-24 18:54:28.798921
# Unit test for constructor of class PlayIterator
def test_PlayIterator():

    # create a new PlayIterator
    play_iterator = PlayIterator()
