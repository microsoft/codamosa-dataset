

# Generated at 2022-06-24 18:47:24.970209
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    assert "FAILED_NONE" in host_state_0.__str__()


# Generated at 2022-06-24 18:47:34.689071
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host_0 = Host('host_0')
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(play_0=None, host_states=dict(), host_state_map=dict(), host_cache=None)
    play_iterator_0._host_states[host_0.name] = host_state_0
    var_0 = play_iterator_0.is_failed(host_0)
    if (var_0 == False):
        raise Exception("Returned value does not match expected value: f(%s) != %s" % (host_0.name, False))
    del var_0
    del host_state_0
    del host_0
    del tuple_0
    del play_iterator_0


# Generated at 2022-06-24 18:47:37.891570
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    assert host_state_0.__str__() is not None


# Generated at 2022-06-24 18:47:46.606576
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(None, host_state_0)
    task_0 = {
        'x': 0.1051,
        'name': 'Task 0',
        'register': '',
        'when': {},
        'y': -0.0613,
        'tags': ['untagged']
        }
    task_1 = {
        'x': -0.1752,
        'name': 'Task 1',
        'register': '',
        'when': {},
        'y': -0.3641,
        'tags': ['untagged']
        }

# Generated at 2022-06-24 18:47:49.996769
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    # test 1
    print(host_state_0.__str__())


# Generated at 2022-06-24 18:47:52.911482
# Unit test for method copy of class HostState
def test_HostState_copy():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_state_1 = host_state_0.copy()


# Generated at 2022-06-24 18:48:01.545297
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    host_0 = Host('fake_host')
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)

    play_iterator_cache_block_tasks_1 = PlayIterator()
    assert play_iterator_cache_block_tasks_1._cache_block_tasks(host_0, host_state_0) == tuple_0
    play_iterator_cache_block_tasks_2 = PlayIterator()
    assert play_iterator_cache_block_tasks_2._cache_block_tasks(host_0, host_state_0) == tuple_0
    play_iterator_cache_block_tasks_3 = PlayIterator()
    assert play_iterator_cache_block_tasks_3._cache_block_tasks(host_0, host_state_0) == tuple_0

# Generated at 2022-06-24 18:48:08.251670
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Setup test environment
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    tuple_1 = (host_state_0,)
    host_state_1 = HostState(tuple_1)
    tuple_2 = (host_state_1,)
    host_state_2 = HostState(tuple_2)
    tuple_3 = (host_state_2,)
    host_state_3 = HostState(tuple_3)
    host_0 = FakeHost("host_0")
    tuple_4 = (host_0,)
    host_state_4 = HostState(tuple_4)
    tuple_5 = (host_state_4,)
    host_state_5 = HostState(tuple_5)
    tuple_6 = (host_state_5,)
   

# Generated at 2022-06-24 18:48:15.572572
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    tuple_0 = (host_state_0,)
    play_iterator_0 = PlayIterator(tuple_0)
    task_list = []
    host_name = "host"
    play_iterator_0.add_tasks(host_name, task_list)


# Generated at 2022-06-24 18:48:19.421613
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # Setup and verify preconditions
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    # Execution
    host_state_0.add_tasks(None)
    # Verification or validation
    # Cleanup


# Generated at 2022-06-24 18:48:53.300223
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    task_0 = (async_wrapper, ())
    tuple_1 = (task_0,)
    host_state_1 = HostState(tuple_1)
    host_0 = Host(name='test_host')
    task_1 = (async_wrapper, ())
    result = PlayIterator._get_original_task(host_0, host_state_1, task_1)
    assert result == (None, None)


# Generated at 2022-06-24 18:48:57.460031
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    dict_0 = dict()
    dict_0['host'] = host_state_0
    play_iterator_0 = PlayIterator(dict_0, None)
    assert play_iterator_0.get_failed_hosts() == dict()


# Generated at 2022-06-24 18:49:04.981584
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    tuple_4 = ()
    host_state_0 = HostState(tuple_4)
    tuple_3 = ('b', 'c')
    task_0 = Task(tuple_3)
    tuple_2 = ('a',)
    task_1 = Task(tuple_2)
    tuple_1 = (task_1, task_0)
    host_0 = Host(tuple_1)
    tuple_0 = ()
    play_iterator_0 = PlayIterator(tuple_0)
    tuple_5 = (host_0, task_1)
    tuple_6 = play_iterator_0.get_original_task(host_0, task_1)

# Generated at 2022-06-24 18:49:09.224269
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    string_0 = "localhost"
    host_state_1 = {}
    host_state_1[string_0] = host_state_0
    play_iterator_1 = PlayIterator(None)
    play_iterator_1._host_states = host_state_1
    dictionary_0 = play_iterator_1.get_failed_hosts()
    assert len(dictionary_0) == 0


# Generated at 2022-06-24 18:49:17.770451
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_0 = Host()
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states[host_0.name] = host_state_0
    play_iterator_1 = PlayIterator()
    out = play_iterator_0.get_failed_hosts()
    assert out == {}
    out = play_iterator_1.get_failed_hosts()
    assert out == {}
    assert play_iterator_0.get_failed_hosts() == {}
    assert play_iterator_1.get_failed_hosts() == {}


# Generated at 2022-06-24 18:49:22.534910
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    block_0 = Block()
    host_state_0._blocks.append(block_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states["host0"] = host_state_0
    host_0 = Host("host0")
    play_iterator_0.add_tasks(host_0, [])
    play_iterator_0.mark_host_failed(host_0)
    result = play_iterator_0.is_any_block_rescuing(host_state_0)
    assert result == False


# Generated at 2022-06-24 18:49:31.307690
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    tuple_0 = ()
    host_0 = Host('localhost')
    tuple_1 = (host_0, )
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(host_state_0, host_0)
    play_iterator_0._host_states[host_0.name] = host_state_0
    try:
        play_iterator_0.get_host_state(host_0)
    except KeyError as e:
        print(str(e))


# Generated at 2022-06-24 18:49:38.153823
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_0 = MagicMock()

    play_iterator_0 = PlayIterator(None)
    play_iterator_0._host_states = {}
    play_iterator_0._host_states.update({host_0:host_state_0})
    play_iterator_0.is_failed(host_0)


# Generated at 2022-06-24 18:49:38.877051
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass


# Generated at 2022-06-24 18:49:43.647502
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    tuple_1 = (host_state_0,)
    play_iterator_0 = PlayIterator(tuple_1)
    host_0 = Host()
    assert play_iterator_0.get_active_state(host_0) is None


# Generated at 2022-06-24 18:50:19.530761
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    dict_0 = {'key_0': 'val_0', 'key_1': 'val_1', 'key_2': 'val_2'}
    TaskResult_0 = TaskResult(dict_0)
    dict_1 = {'key_0': TaskResult_0, 'key_1': 'val_1', }
    dict_2 = {'key_0': TaskResult_0, 'key_1': 'val_1', 'key_2': 'val_2'}
    host_0 = Host('name_0')
    set_0 = {host_0}
    dict_3 = {'key_0': 'val_0'}
    dict_4 = {'key_0': 'val_0', 'key_1': 'val_1', 'key_2': 'val_2'}
    ans

# Generated at 2022-06-24 18:50:28.627868
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    tuple_0 = ()
    play_0 = Play(tuple_0)
    play_0._hosts_cache = set()
    play_0._play_hosts = set()
    play_0._play_hosts.add("rcbops01-qa002")
    play_0._play_hosts.add("rcbops01-qa003")
    play_0._play_hosts.add("rcbops01-qa004")
    play_0._play_hosts.add("rcbops01-qa005")
    play_0._play_hosts.add("rcbops01-qa006")
    play_0._play_hosts.add("rcbops01-qa007")
    play_0._play_hosts.add("rcbops01-qa008")
    play_0._play

# Generated at 2022-06-24 18:50:33.333746
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    P0 = (Play())
    play_iterator_0 = PlayIterator(P0)
    play_iterator_0.play = (Play())
    host_0 = Host("10.30.46.40")
    play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:50:36.973098
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_state_0.run_state = 0
    play_iterator_0 = PlayIterator(play_0, tuple_0)


# Generated at 2022-06-24 18:50:40.810977
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 18:50:45.198674
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_0 = Host()
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states[host_0.name] = host_state_0
    play_iterator_0.is_failed(host_0)


# Generated at 2022-06-24 18:50:49.959936
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(None, None, 0, host_state_0)
    host_state_1 = host_state_0
    argument_1 = host_state_1
    test_value_1 = play_iterator_0.is_any_block_rescuing(argument_1)
    assert test_value_1


# Generated at 2022-06-24 18:50:58.538121
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(None, None, None)
    boolean_0 = play_iterator_0.is_any_block_rescuing(host_state_0)
    assert not boolean_0

    # TEST CASE FOR IS ANY BLOCK RESCUE MODE
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_state_0.run_state = PlayIterator.ITERATING_RESCUE

    assert host_state_0.run_state == PlayIterator.ITERATING_RESCUE

    play_iterator_0 = PlayIterator(None, None, None)

# Generated at 2022-06-24 18:51:01.113080
# Unit test for method copy of class HostState
def test_HostState_copy():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    host_state_1 = host_state_0.copy()


# Generated at 2022-06-24 18:51:08.664997
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''

    host_state_0 = PlayIterator('../../test/integration/targets/inventory')

    host_0 = Host('localhost')
    host_1 = Host('localhost')
    host_2 = Host('localhost')
    host_3 = Host('localhost')
    host_4 = Host('localhost')
    host_5 = Host('localhost')
    host_6 = Host('localhost')
    host_7 = Host('localhost')

    try:
        host_state_0.mark_host_failed(host_1)
    except Exception as e:
        display.display(e)
        display.display(host_state_0.get_active_state(host_state_0.get_host_state(host_1)))
       

# Generated at 2022-06-24 18:52:12.488624
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Create a play context that has a self.play.hosts value of True
    tuple_0 = ()
    tuple_1 = ()
    play_context_0 = PlayContext(tuple_0, tuple_1)
    play_context_0.hostvars = dict()
    play_0 = Play().load(play_context_0, dict(), loader=None)
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ()
    tuple_5 = ()
    block_0 = Block(tuple_3, tuple_4, tuple_5, "Create the users.")
    tuple_3 = ()
    tuple_4 = ()
    tuple_5 = ()
    block_1 = Block(tuple_3, tuple_4, tuple_5, None)
    tuple_3 = ()

# Generated at 2022-06-24 18:52:16.644084
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(play_0, host_state_0)
    assert play_iterator_0.get_next_task_for_host(host_0) == None



# Generated at 2022-06-24 18:52:21.989936
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Setup - Create a PlayIterator instance and add one block
    tuple_0 = ()
    host_state_0 = HostState( tuple_0 )
    play_iterator_0 = PlayIterator( host_state_0 )

    block_0 = Block()
    play_iterator_0._host_states = {
        'localhost': host_state_0,
    }
    host_state_0._blocks = [
        block_0,
    ]

    # Test - Verify get_active_state returns the proper state
    play_iterator_0._get_active_state(host_state_0)

    # Assertion
    assert host_state_0.run_state == False


# Generated at 2022-06-24 18:52:31.589829
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Test mark_host_failed, which is a method of class PlayIterator
    '''

    # setup test variables
    test_host = Host('test.example.com')
    test_play = Play()
    test_play.playbook = Playbook()
    test_play.playbook._entries = [test_play]
    test_play.hosts = [test_host]
    test_play.hosts_map = {test_host: test_host}
    test_play.hosts.sort()
    test_play.sort_hosts()
    test_play.play_context = PlayContext()
    test_play.play_context._play = test_play

    test_iterator = PlayIterator(test_play)
    test_iterator._play = test_play

# Generated at 2022-06-24 18:52:36.006441
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    # Initialization:
    play_0 = Play()
    inventory_0 = Inventory(hosts=['localhost'])
    play_iterator_0 = PlayIterator(play_0, inventory_0)

    # Testing:
    host_0 = inventory_0.hosts['localhost']
    host_state_0 = play_iterator_0.get_host_state(host_0)


# Generated at 2022-06-24 18:52:44.422068
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = Play().load(dict(
        name = 'ansible-test',
        hosts = 'foo',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stderr}}')))
        ]
    ), variable_manager=VariableManager(), loader=DataLoader())
    host = Host(name="foo")
    iterator = PlayIterator(play, [host])
    assert iterator._host_states[host.name]
    assert iterator._host_states[host.name]._blocks
    assert iterator.get_next_task_

# Generated at 2022-06-24 18:52:49.236032
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    tuple_0 = ()
    play_0 = Play(name='foo', hosts=[], hosts_all=['localhost'], roles=['foo'], gather_facts='yes', tasks=[])
    inventory_0 = Inventory(hosts=['localhost'], pattern='all')
    test_0 = PlayIterator(play_0, inventory_0, False)

if __name__ == "__main__":
    test_case_0()
    test_PlayIterator()

# Generated at 2022-06-24 18:52:52.974778
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(tuple_0, None)
    play_iterator_0.set_host_state(None, host_state_0)
    display.debug("failed hosts: %s" % play_iterator_0.get_failed_hosts())


# Generated at 2022-06-24 18:52:53.849419
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    test_case_0()

# Generated at 2022-06-24 18:52:54.956476
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    pass


# Generated at 2022-06-24 18:55:11.007607
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    play_iterator_0 = PlayIterator()
    # recursive call goes here
    result = play_iterator_0.is_any_block_rescuing()
    assert (((isinstance(result, bool)) and result) is False)


# Generated at 2022-06-24 18:55:20.188857
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    action_0 = Action()
    block_0 = Block('notify')
    tuple_0 = (block_0,)
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ()
    tuple_5 = ()
    tuple_6 = ()
    tuple_7 = ()
    tuple_8 = ()
    tuple_9 = ()
    tuple_10 = ()
    tuple_11 = ()
    tuple_12 = ()
    tuple_13 = ()
    tuple_14 = ()
    tuple_15 = ()
    tuple_16 = ()
    tuple_17 = ()
    tuple_18 = ()
    tuple_19 = ()
    tuple_20 = ()
    tuple_21 = ()
    tuple_22 = ()
    tuple_23 = ()
    tuple_24 = ()
   

# Generated at 2022-06-24 18:55:25.436686
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    dict_0 = {}
    play_iterator_0 = PlayIterator(dict_0, tuple_0)
    # The following statement will raise a TypeError
    with pytest.raises(TypeError):
        play_iterator_0.get_host_state(host_state_0)


# Generated at 2022-06-24 18:55:32.363979
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    tuple_0 = (tuple(),)
    tuple_1 = (tuple(), tuple(), tuple())
    tuple_2 = (tuple(), tuple_0, tuple())
    tuple_3 = (tuple(), tuple_0, tuple_0)
    tuple_4 = ()

    block_0 = Block(tuple_1, tuple_0, tuple_0)
    block_1 = Block(tuple_2, tuple_0, tuple_0)
    block_2 = Block(tuple_3, tuple_0, tuple_0)
    block_3 = Block(tuple_1, tuple_0, tuple_1)
    block_4 = Block(tuple_2, tuple_0, tuple_1)
    block_5 = Block(tuple_3, tuple_0, tuple_1)

# Generated at 2022-06-24 18:55:39.223869
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    c = variable_manager.VariableManager()

    t0 = Task()
    t0._role_name = 'role1'
    t1 = Task()
    t1._role_name = 'role2'
    t2 = Task()
    t2._role_name = 'role3'

    h0 = Host(name='localhost')
    h1 = Host(name='127.0.0.1')

    r0 = Role()
    r0._role_name = 'role1'
    r1 = Role()
    r1._role_name = 'role2'

    r0._tasks = [t0]
    r1._tasks = [t1, t2]

    block_0 = Block()
    block_0._role_name = 'role1'

# Generated at 2022-06-24 18:55:44.502827
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    assert type(host_state_0.__str__()) is str


# Generated at 2022-06-24 18:55:50.790867
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    print("%s....test_get_host_state" % get_timestamp())
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    tuple_1 = (host_state_0,)
    play_iterator_0 = PlayIterator(tuple_1)
    host_0 = Host(name='foobar')
    play_iterator_0._host_states[host_0.name] = host_state_0
    host_state_1 = play_iterator_0.get_host_state(host_0)
    assert host_state_1 == host_state_0
    print(play_iterator_0._host_states)


# Generated at 2022-06-24 18:55:56.502220
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    host_state_0 = HostState({})
    host_state_0._blocks = [Block(), Block(), Block(), Block(), Block(), Block(), Block(), Block()]
    host_state_0.run_state = 2
    host_state_0.fail_state = 0
    host_state_0.cur_block = 4
    host_state_0.cur_regular_task = 0
    host_state_0.cur_rescue_task = 0
    host_state_0.cur_always_task = 0
    host_state_0.did_rescue = False
    host_state_0.tasks_child_state = None
    host_state_0.rescue_child_state = None
    host_state_0.always_child_state = None
    expected_host_state_0 = host_state_

# Generated at 2022-06-24 18:55:58.956783
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # Example usage:
    # shell> python -m test.unit.test_play_iterator.test_PlayIterator_add_tasks
    test_case_0()

# Unit test entry point

# Generated at 2022-06-24 18:56:08.183889
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    tuple_0 = ()
    host_state_0 = HostState(tuple_0)
    play_iterator_0 = PlayIterator(None, host_state_0, None)
    host_0 = Mock()
    task_0 = Mock()
    tuple_1 = play_iterator_0.get_original_task(host_0, task_0)
    assertTrue(isinstance(tuple_1, tuple))
    assertEquals(2, len(tuple_1))
    assertEquals(None, tuple_1[0])
    assertEquals(None, tuple_1[1])
