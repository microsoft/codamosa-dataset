

# Generated at 2022-06-24 18:47:04.538466
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    hoststate_0 = HostState(None)
    hoststate_1 = HostState(None)
    assert hoststate_0.__eq__(hoststate_1) == True


# Generated at 2022-06-24 18:47:06.987447
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    play_iterator_0 = PlayIterator()
    host_state_0 = play_iterator_0.get_host_state()
    assert host_state_0 == None


# Generated at 2022-06-24 18:47:11.082078
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    float_0 = 100.0
    host_0 = Host("RANDOM_STRING")
    host_state_0 = HostState(float_0)
    host_state_0.mark_host_failed(host_0)
    var_0 = host_state_0.is_failed(host_0)



# Generated at 2022-06-24 18:47:13.795066
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play_iterator_0 = PlayIterator(play_context_0, strategy_0, Host('name_0'))
    play_iterator_0.get_failed_hosts()


# Generated at 2022-06-24 18:47:15.334291
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host_state_0 = HostState(None)
    var_0 = PlayIterator.is_any_block_rescuing(host_state_0)
    assert var_0 == False


# Generated at 2022-06-24 18:47:21.640485
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator()
    inventory_0 = 'test'
    play_0 = Play()
    play_0.set_loader(loader_0)
    play_0.set_variable_manager(variable_manager_0)
    play_iterator_0.play = play_0
    play_iterator_0.play.compile()
    task_0 = dict()
    task_0['action'] = 'set_fact'
    task_0['args'] = dict()
    task_0['name'] = 'Test task 0'
    task_0['register'] = 'test'
    task_0['when'] = dict()
    task_0['with_items'] = []
    var_0 = play_iterator_0.get_next_task_for_host(inventory_0, task_0)
   

# Generated at 2022-06-24 18:47:28.316456
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    globals_0 = Globals()
    play_0 = Play()
    inventory_0 = Inventory(hosts=[Host, Host], vars=[Variable, Variable], patterns=[Pattern, Pattern], defaults=[Variable, Variable, Variable])
    play_context_0 = PlayContext()
    play_iterator_0 = PlayIterator(globals_0, play_0, inventory_0, play_context_0)
    host_state_0 = HostState()
    host_0 = Host()
    host_state_0.host = host_0
    host_state_0.fail_state = 0
    boolean_0 = play_iterator_0.is_failed(host_0)
    print(boolean_0)


# Generated at 2022-06-24 18:47:37.640919
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # setup all host state objects
    int_0 = 100
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    host_state_1 = HostState(float_0)
    # setup play iterator object
    play_iterator_0 = PlayIterator(host_state_0, host_state_1, int_0)
    host_0 = Host()
    # setup failing play iterator
    int_0 = 100
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    host_state_1 = HostState(float_0)
    play_iterator_1 = PlayIterator(host_state_0, host_state_1, int_0)
    print('Manually fail the task iteration state')

# Generated at 2022-06-24 18:47:40.582317
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    play_iterator_0 = PlayIterator()
    host_0 = Host('localhost')
    task_0 = Task()
    play_iterator_0.add_tasks(host_0, task_0)


# Generated at 2022-06-24 18:47:48.504279
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    block_0 = Block()
    block_0.vars = dict()
    block_0.vars['v1'] = 1
    block_0.vars['v2'] = 2
    block_0.block = 'block_0'
    block_0.rescue = 'rescue_0'
    block_0.always = 'always_0'
    
    p = Play()
    p.vars = dict()
    p.vars['v1'] = 1
    p.vars['v2'] = 2
    p.vars['v3'] = 3
    p.vars['v4'] = 4
    p.vars['v5'] = 5
    
    h = Host()
    h.vars = dict()
    h.name = 'host_0' 
    h.vars

# Generated at 2022-06-24 18:48:29.227620
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    target = PlayIterator()
    host_state_0 = HostState()
    host_0 = Host()
    host_0.name = u'/home/brian/temp/ansible-pull/ansible-playbook/test_data_structurer/roles/test_template/files/../tasks/main.yml'
    # Call method
    target.mark_host_failed(host_0)


# Generated at 2022-06-24 18:48:41.358805
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host_state_0 = HostState()

    state_0 = PlayIterator._HostState__block_state()
    state_0.run_state = HostState.ITERATING_TASKS
    object_0 = PlayIterator.PlayIterator(host_state_0)
    object_1 = object_0.get_active_state(state_0)
    object_2 = object_0.is_any_block_rescuing(state_0)
    object_3 = object_0.is_any_block_rescuing(object_1)
    object_4 = object_0.is_any_block_rescuing(object_2)
    object_5 = object_0.is_any_block_rescuing(object_3)
    assert object_1 is state_0
    assert not object_2
   

# Generated at 2022-06-24 18:48:44.149522
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    host_state_0 = HostState()
    host_state_0 = HostState(blocks)
    host_state_0 = HostState()
    host_state_0 = HostState(blocks)


# Generated at 2022-06-24 18:48:50.197750
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Pass
    state = HostState()
    pi = PlayIterator()
    pi.get_host_state('test')
    pi._host_states['test'] = state
    res = pi.get_host_state('test')
    assert res == state
    # Fail
    with pytest.raises(KeyError) as e_info:
        assert pi.get_host_state('test1')


# Generated at 2022-06-24 18:48:59.964388
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    h = Host('localhost')
    h.name = 'localhost'
    h.resolved = '127.0.0.1'

    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()

    task1.name = 'task1'
    task2.name = 'task2'
    task3.name = 'task3'
    task4.name = 'task4'

    task_list_0 = [task1, task2, task3, task4]

    block1 = Block()
    block2 = Block()

    block1.block = [task1]
    block1.rescue = []
    block1.always = []

    block2.block = []
    block2.rescue = [task2]
    block2.always = [task3]



# Generated at 2022-06-24 18:49:06.472020
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load(playbooks[0], variable_manager=VariableManager(), loader=Loader())
    ti = PlayIterator(p)
    all_hosts = p.get_variable_manager().get_vars()['hostvars'].keys()
    assert len(all_hosts) == len(ti._hosts)

    assert ti._host_states['jumper'] == HostState(blocks=[p._task_blocks[0], p._task_blocks[1]])
    assert ti._host_states['localhost'] == HostState(blocks=[p._task_blocks[0], p._task_blocks[1]])


# Generated at 2022-06-24 18:49:11.181887
# Unit test for method get_host_state of class PlayIterator

# Generated at 2022-06-24 18:49:19.667236
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    """
    cache_block_tasks: Unit test for the PlayIterator.cache_block_tasks() method

    Asserts expected behavior on successful and failure scenarios.
    """
    import types
    import sys

    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    # define the host state
    host_state = HostState()

    # define the play
    class TestPlay(object):
        def __init__(self):
            self.gather_facts = 'fake gather_facts'
            self.hosts = 'fake hosts'
            self.post_validate = ['fake post_validate']
            self.roles = ['fake roles']
            self.serial = 'fake serial'

# Generated at 2022-06-24 18:49:27.023473
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    state = HostState([Block([
        Task(action=ActionModule()),
        Block([Task(action=ActionModule())])
    ]), Block([
        Task(action=ActionModule()),
        Block([Task(action=ActionModule())])
    ])])

    state.cur_block = 0
    state.cur_regular_task = 1
    state.tasks_child_state = HostState([Block([Task(action=ActionModule())])])

    p = PlayIterator(None)
    active_state = p.get_active_state(state)
    assert active_state == state.tasks_child_state

    state.cur_block = 1
    state.cur_regular_task = 1

# Generated at 2022-06-24 18:49:31.097071
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Test PlayIterator.get_host_state()
    class TestPlay(object):

        def __init__(self, strategy='linear'):
            self.strategy = strategy

    play_iterator = PlayIterator()
    play_iterator._play = TestPlay()
    play_iterator._hosts = {}
    result = play_iterator.get_host_state('host_name')
    assert result is not None


# Generated at 2022-06-24 18:50:36.510792
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    host_state_0 = HostState()
    block_0 = Block(dummy_0=[])
    block_1 = Block(dummy_0=[])
    block_2 = Block(block=[block_0, block_1], rescue=[])
    block_3 = Block(block=[block_2], rescue=[])
    host_state_0._blocks = [block_3]
    host_state_0.cur_block = 0
    host_state_0.cur_regular_task = 0
    host_state_0.cur_rescue_task = 0
    host_state_0.cur_always_task = 0
    host_state_0.run_state = 0
    host_state_0.fail_state = 0
    host_state_0.tasks_child_state = None
    host_state_0

# Generated at 2022-06-24 18:50:37.707251
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass


# Generated at 2022-06-24 18:50:47.106008
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-24 18:50:56.941215
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Create a simple play
    play_source = dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(name='task1', debug='msg={{active_task_name}}'),
            dict(block=dict(
                name='inner block',
                tasks = [
                    dict(name='task2', debug='msg={{active_task_name}}'),
                    dict(name='task3', debug='msg={{active_task_name}}'),
                ]
            )),
            dict(name='task4', debug='msg={{active_task_name}}')
        ]
    )

    # Create a basic play
    play_ds = DataLoader()
    play_ds.set_basedir(os.getcwd())

# Generated at 2022-06-24 18:51:00.544312
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    host_state_0 = HostState()
    host_state_0.run_state = PlayIterator.ITERATING_SETUP
    host_state_0.fail_state = PlayIterator.FAILED_NONE


# Generated at 2022-06-24 18:51:02.169407
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 18:51:02.932481
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    pass


# Generated at 2022-06-24 18:51:06.447708
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    Unit test for method get_host_state of class PlayIterator
    '''
    # Initialize a new object
    play_iterator_0 = PlayIterator()

    # Assertions
    assert play_iterator_0, "Cannot create an object of type 'PlayIterator'"


# Generated at 2022-06-24 18:51:11.373876
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    """
    Test for method get_failed_hosts of class PlayIterator
    """
    # this is an empty test so that pytest-3 will treat it as a unit test.
    # the tests for this class were ported from the old test_utils.py ansible
    # project, and the tests were re-implemented in test_v2_playbook_execute.py
    # in the integration directory.
    pass


# Generated at 2022-06-24 18:51:19.394755
# Unit test for method __str__ of class HostState
def test_HostState___str__():

    host_state = HostState()

    # Nothing should be set in host_state
    assert host_state.__str__() == "FAILED_NONE"

    # Check when only tasks_child_state is set
    host_state.tasks_child_state = 1
    assert host_state.__str__() == "FAILED_NONE"

    # Check when only rescue_child_state is set
    host_state.rescue_child_state = 2
    assert host_state.__str__() == "FAILED_NONE"

    # Check when only always_child_state is set
    host_state.always_child_state = 3
    assert host_state.__str__() == "FAILED_NONE"

    # Check when tasks_child_state = rescue_child_state = always_child

# Generated at 2022-06-24 18:52:30.910380
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host_data = dict()
    play = Play()
    host = Host(name = 'localhost')
    host_state_0 = HostState(play)
    host_state_0.set_next_task_lock(True)
    task_list = list()
    host_0 = Host(name = 'localhost')

# Generated at 2022-06-24 18:52:39.958717
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    def test_mark_host_failed_helper(host_name, host_state, failed_hosts):
        failed_hosts_0 = failed_hosts
        host_name_0 = host_name
        play_iterator_0 = PlayIterator()
        host_state_0 = host_state
        play_iterator_0.mark_host_failed(host_name_0)
        var_0 = play_iterator_0.get_failed_hosts()
        var_1 = var_0 == failed_hosts_0
        return var_1
    
    var_2 = test_mark_host_failed_helper(host_name='', host_state=HostState(float(0)), failed_hosts={})

# Generated at 2022-06-24 18:52:43.702070
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    host_state_0.run_state = 5
    host_state_0.fail_state = 10
    host_state_0.pending_setup = True
    var_0 = host_state_0.__str__()


# Generated at 2022-06-24 18:52:52.746204
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    host_iterator_0 = PlayIterator(play=None)
    host_name_0 = 'testhost'
    host_0 = Host(host_name_0)
    host_state_0 = HostState()
    host_iterator_0.set_host_state(host=host_0, host_state=host_state_0)
    host_state_new_0 = host_iterator_0.get_host_state(host=host_0)
    assert host_state_0 == host_state_new_0


# Generated at 2022-06-24 18:52:56.258915
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    state_0 = HostState(100.0)
    play_iterator_0 = PlayIterator(state_0)
    host_0 = Host(name=None)
    result_0 = play_iterator_0.get_original_task(host_0, None)
    assert result_0 is None


# Generated at 2022-06-24 18:53:00.829346
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    float_1 = 100.0
    host_state_0 = HostState(float_1)
    play_iterator_0 = PlayIterator()
    # AssertionError raised by add_tasks on line 1146
    with pytest.raises(AssertionError):
        play_iterator_0.add_tasks(host_state_0, 123)
        pytest.fail("AssertionError not raised in PlayIterator.add_tasks")


# Generated at 2022-06-24 18:53:04.516340
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    play_iterator_0 = PlayIterator(host_state_0)
    play_iterator_0.get_next_task_for_host(host_state_0)


# Generated at 2022-06-24 18:53:07.856465
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    dict_0 = dict()
    play_iterator_0 = PlayIterator(dict_0)
    play_iterator_0.is_failed(str_0)


# Generated at 2022-06-24 18:53:10.547103
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    float_0 = 1.0
    host_state_0 = HostState(float_0)
    play_iterator_0 = PlayIterator()
    host_0 = MagicMock()
    host_0.name = ""
    str_0 = play_iterator_0.mark_host_failed(host_0)
    print (str_0)


# Generated at 2022-06-24 18:53:13.693058
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    play_iterator_0 = PlayIterator(host_state_0, float_0)
    string_0 = "localhost"
    host_0 = Host(string_0)
    boolean_0 = play_iterator_0.is_failed(host_0)


# Generated at 2022-06-24 18:55:57.028473
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0.get_active_state(host_state_0)


# Generated at 2022-06-24 18:56:03.731358
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    task_list = []
    test_iterator_0 = PlayIterator(task_list)
    task_list_0 = []
    test_iterator_0._play.tasks = task_list_0
    task_tuple_0 = (None, None)
    test_iterator_0._play.tasks.append(task_tuple_0)
    task_tuple_1 = (None, None)
    test_iterator_0._play.tasks.append(task_tuple_1)
    test_iterator_0._play.tasks.append(task_tuple_0)
    task_list_1 = []
    test_iterator_0._play.handlers = task_list_1
    task_tuple_2 = (None, None)

# Generated at 2022-06-24 18:56:07.427425
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    host_state_0 = HostState()
    play_iterator_0 = PlayIterator(host_state_0, [], {})
    host_0, block_0 = (None, None)
    play_iterator_0._cache_block_tasks(host_0, block_0)


# Generated at 2022-06-24 18:56:11.561718
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    dict_0 = dict()
    hosts_vars_0 = HostVars(dict_0)
    play_0 = Play()
    play_iterator_0 = PlayIterator(play_0, hosts_vars_0, dict_0)
    assert isinstance(play_iterator_0, PlayIterator)


# Generated at 2022-06-24 18:56:17.223284
# Unit test for method copy of class HostState
def test_HostState_copy():
    # Testing with float_0
    float_0 = float
    host_state_0 = HostState(float_0)
    host_state_0_copy = host_state_0.copy()
    assert host_state_0 == host_state_0_copy
    # Testing with host_state_1
    host_state_1 = HostState(100.0)
    host_state_1_copy = host_state_1.copy()
    assert host_state_1 == host_state_1_copy
    # Testing with host_state_2
    host_state_2 = HostState(100.0)
    host_state_2_copy = host_state_2.copy()
    assert host_state_2 == host_state_2_copy
    # Testing with host_state_3

# Generated at 2022-06-24 18:56:27.566621
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # Task 0
    float_0 = 100.0
    host_state_0 = HostState(float_0)
    float_1 = 100.0
    host_state_1 = HostState(float_1)
    # Task 1
    block_0 = Block()
    # Task 2
    # Task 3
    # Task 4
    # Task 5
    # Task 6
    # Task 7
    task_0 = Task()
    # Task 8
    # Task 9
    # Task 10
    # Task 11
    # Task 12
    # Task 13
    task_1 = Task()
    # Task 14
    # Task 15
    # Task 16
    # Task 17
    # Task 18
    # Task 19
    task_2 = Task()
    # Task 20
    # Task 21
    # Task 22
    # Task 23