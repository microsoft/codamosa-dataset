

# Generated at 2022-06-24 18:47:25.056823
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    str_0 = '-Lc*wF\\|3/<Z'
    host_state_0 = HostState(str_0)

    play_iterator_0 = PlayIterator()

    # Ensure get_host_state(host) returns HostState(host, blocks=self._play.compile())
    play_iterator_0.get_host_state(host_state_0)


# Generated at 2022-06-24 18:47:34.765893
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # mock host_state_0 is a HostState
    host_state_0 = HostState('e5Y5\\')
    assert host_state_0.run_state == 4
    # host_state_0.run_state == 4
    # mock play_iterator_0 is a PlayIterator
    play_iterator_0 = PlayIterator(play_0)
    play_iterator_0._host_states['e5Y5\\'] = host_state_0
    # play_iterator_0._host_states['e5Y5\\'] == host_state_0
    assert play_iterator_0.get_failed_hosts() == {'e5Y5\\': True}

PlayIterator.test_case_0 = test_case_0
PlayIterator.test_PlayIterator_get_failed_hosts = test_PlayIterator_get

# Generated at 2022-06-24 18:47:35.792401
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    test_case_0()


# Generated at 2022-06-24 18:47:42.925456
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pytest.skip("play_context.set_play_context is already deprecated in ansible 2.3")
    # Generate data to be used in test
    # The test will be executed when the number of tasks is greater than 0
    # And the number of tasks is even
    number_of_tasks = 6
    play_name = 'Hello'
    play_0 = Play(play_name)

    # Generate the list of the tasks for the play
    task_list = []
    for task_i in range(number_of_tasks):
        task_name = 'task_{}'.format(task_i)
        task_list.append(Task(task_name))

    # Generate the play iterator
    # The play iterator will be associated with the play
    iterator_0 = PlayIterator(play_0)
    play_context

# Generated at 2022-06-24 18:47:46.296100
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    print(PlayIterator)

if __name__ == '__main__':
    test_PlayIterator_get_next_task_for_host()

# Generated at 2022-06-24 18:47:52.191197
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    str_0 = 'S\\C;l=0o<PpZb'
    state_0 = HostState(str_0)
    assert not PlayIterator.is_any_block_rescuing(state_0)
    int_0 = 0
    int_1 = 1
    str_1 = ';kN/;]*EW}9'
    str_2 = 'rcf\\$\\R?xS*'
    str_3 = 'p`[F]9m4*q}:'
    str_4 = 'l$7r'
    str_5 = '_xb{ZGX7Zu'
    task_0 = dict()
    task_1 = dict()
    task_2 = dict()
    task_3 = dict()
    task_0['register'] = str_1
    task

# Generated at 2022-06-24 18:47:56.015953
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # FIXME: Need to get this from somewhere else.
    host_state_0 = test_case_0()
    int_0 = host_state_0.is_any_block_rescuing()
    if __debug__: print(host_state_0)


# Generated at 2022-06-24 18:47:58.333102
# Unit test for method copy of class HostState
def test_HostState_copy():
    str_0 = ['Hi']
    host_state_0 = HostState(str_0)
    host_state_1 = host_state_0.copy()


# Generated at 2022-06-24 18:48:00.814265
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    str_0 = '-Lc*wF\\|3/<Z'
    play_iterator_0 = PlayIterator(str_0)
    assert(play_iterator_0 != None)
    assert(play_iterator_0 != '-Lc*wF\\|3/<Z')


# Generated at 2022-06-24 18:48:04.708025
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    str_0 = 'ENTR'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator(None)

    host_0 = '123.123.123.123'
    play_iterator_0.add_host(host_0)
    play_iterator_0.set_host_state(host_0, host_state_0)
    play_iterator_0.mark_host_failed(host_0)
    play_iterator_0.get_failed_hosts()


# Generated at 2022-06-24 18:48:43.864899
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    play_iterator_0 = PlayIterator()
    play_iterator_0._iterator._play = Play()
    block_0 = Block()
    block_0._block = ['some','tasks']
    play_iterator_0._iterator._play._tasks = [block_0]
    test_host_0 = Host('testhost')
    test_host_0.name = 'testhost'
    test_host_0.hostname = 'testhost'
    test_host_0.port = 22
    test_host_0.vars = {u'ansible_ssh_port': 22, u'ansible_ssh_host': 'testhost', u'ansible_ssh_user': 'root'}
    test_host_0.add_task('setup')
    test_host_0.add_task('tasks')
   

# Generated at 2022-06-24 18:48:48.019232
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    play_iterator_0 = PlayIterator()
    host_0 = Host(name='myhost', port=22)
    test_is_failed_0 = play_iterator_0.is_failed(host_0)



# Generated at 2022-06-24 18:48:58.190792
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    play_iterator_0 = PlayIterator()
    s = HostState()
    s.fail_state = PlayIterator.FAILED_NONE
    assert(play_iterator_0._check_failed_state(s) == False)
    s.fail_state = PlayIterator.FAILED_SETUP
    assert(play_iterator_0._check_failed_state(s) == False)
    s.fail_state = PlayIterator.FAILED_TASKS
    assert(play_iterator_0._check_failed_state(s) == True)
    s.fail_state = PlayIterator.FAILED_RESCUE
    assert(play_iterator_0._check_failed_state(s) == True)
    s.run_state = PlayIterator.ITERATING_RESCUE

# Generated at 2022-06-24 18:49:03.059211
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    #
    # setup method test_case_0
    #
    play_iterator_0 = PlayIterator()
    #
    # test method mark_host_failed
    #
    host_state_0 = HostState()
    host_0 = Host('hostname')
    play_iterator_0.mark_host_failed(host_0)

    assert play_iterator_0._check_failed_state(host_state_0)
    #
    # teardown method test_case_0
    #


# Generated at 2022-06-24 18:49:03.882672
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    pass


# Generated at 2022-06-24 18:49:11.976982
# Unit test for method copy of class HostState
def test_HostState_copy():
    # Create play_iterator.
    play_iterator = PlayIterator()

    # Create state.
    state = HostState(play_iterator.current.block)

    # Count the number of block.
    count = 0
    for block in play_iterator.current.block:
        count += 1
    block_num = count
    print("Block num: %d" % block_num)

    # Test HostState.state.
    state.cur_block = 1
    state.cur_rescue_task = 1
    state.cur_regular_task = 2
    state.cur_always_task = 3
    state.run_state = PlayIterator.ITERATING_TASKS
    state.fail_state = PlayIterator.FAILED_SETUP
    state.pending_setup = False

# Generated at 2022-06-24 18:49:14.097628
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play_iterator_1 = PlayIterator()
    assert play_iterator_1.get_failed_hosts() == dict()


# Generated at 2022-06-24 18:49:15.887209
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    play_iterator_5 = PlayIterator()
    block_7 = Block()
    block_8 = Block()
    play_iterator_5.cache_block_tasks(block_7, block_8)


# Generated at 2022-06-24 18:49:16.921777
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    test_case_0()


# Generated at 2022-06-24 18:49:24.067875
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play_iterator_0 = PlayIterator()
    host_state_0 = play_iterator_0.get_host_state(play_iterator_0._play._hosts[0])
    host_state_0.run_state = PlayIterator.ITERATING_TASKS
    host_state_0.cur_block = 0
    host_state_0.cur_block = 0
    host_state_0.cur_rescue_task = 0
    host_state_0.cur_regular_task = 0
    host_state_0.cur_always_task = 0
    block_0 = play_iterator_0._play._blocks[0]
    host_state_0._blocks = [block_0]
    block_1 = block_0
    block_1.block = [command_0]
    host_state_1

# Generated at 2022-06-24 18:49:53.985359
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator([])

# Generated at 2022-06-24 18:50:01.662359
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    str_0 = 'zdwb-ZS[|U(A6nq7'
    state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator(state_0)
    state_1 = HostState(str_0)
    state_1.run_state = 3
    state_2 = HostState(str_0)
    state_2.run_state = 5
    state_2.tasks_child_state = state_1
    state_3 = HostState(str_0)
    state_3.run_state = 5
    state_3.tasks_child_state = state_2
    play_iterator_0._set_failed_state(state_3)
    state_4 = HostState(str_0)
    state_4.run_state = 5
    state

# Generated at 2022-06-24 18:50:08.177074
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # test that the cache is being set on the state after the cache is filled
    fake_loader, playbook, inventory, variable_manager = prepare_test_data()
    play_context = PlayContext()
    play = Play().load(playbook[0], loader=fake_loader, variable_manager=variable_manager, play_context=play_context)
    fake_play_context = MagicMock()
    fake_play_context.index = 0
    play._task_cache = dict()
    play._task_cache[0] = dict()
    play._task_cache[0]['tasks'] = [ MagicMock() ]
    play._task_cache[0]['_uuid'] = 'abcdefghijklmn'
    play._task_cache[0]['_role_name'] = 'test_role'
    play_it

# Generated at 2022-06-24 18:50:14.344666
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    str_0 = '}>Yau-JFV7n'
    host_state_0 = HostState(str_0)
    str_1 = '=z'
    hosts_0 = [str_1]
    play_0 = Play()
    play_iterator_0 = PlayIterator(play_0, hosts_0)
    play_iterator_0.set_host_state(str_1, host_state_0)
    play_iterator_0.mark_host_failed(str_1)
    answer_0 = play_iterator_0.get_failed_hosts()
    assert answer_0 == {'=z': True}, answer_0


# Generated at 2022-06-24 18:50:16.717935
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    test_case_0()

if __name__ == '__main__':
    test_PlayIterator_get_failed_hosts()

# Generated at 2022-06-24 18:50:26.642045
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    block_0 = Block('Block_0')
    block_0.vars = dict()
    block_0.vars['foo'] = 'bar'
    block_0.block = list()
    block_0.block.append(dict(action='shell', args='ls /tmp'))
    block_0.block.append(dict(action='shell', args='ls "~/a b"'))
    block_0.block.append(dict(action='shell', args='ls "~/a b/c d"'))
    block_0.rescue = list()
    block_1 = Block('Block_1')
    block_1.vars = dict()
    block_1.vars['foo'] = 'bar'
    block_1.block = list()

# Generated at 2022-06-24 18:50:37.413788
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_context import PlaybookContext
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.host import Host

    my_host = Host(name="my_host")
    block_0 = Block()
    task_0 = Task()
    play_context_0 = PlayContext

# Generated at 2022-06-24 18:50:46.907864
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host_state_0 = PlayIterator(None)
    play_0 = PlayBook('play_0', host_state_0)
    host_0 = Host('host_0', play_0)
    host_0.set_variable(str_0, str_1)
    host_0.set_variable(str_2, str_3)
    host_state_0.set_variable(str_0, str_1)
    host_state_0.set_variable(str_2, str_3)
    task_0 = Task(str_4, str_5, str_6)
    task_1 = Task(str_7, str_8, str_9)
    task_2 = Task('task_2', str_10, str_11)

# Generated at 2022-06-24 18:50:50.630926
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    print('Testing PlayIterator.get_original_task')
    # Test case 0
    print('Test case 0')
    test_case_0()

test_PlayIterator_get_original_task()

# Generated at 2022-06-24 18:50:55.715554
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    state_0 = {'play': 'play_0', 'hosts': 'hosts_0', 'blocks': 'blocks_0'}
    state_1 = state_0
    task_0 = {'task': ''}
    host_0 = {'name': 'foo'}
    iterator_0 = PlayIterator(play)
    iterator_0.cache_block_tasks(state_0, task_0, host_0)



# Generated at 2022-06-24 18:52:01.882137
# Unit test for method get_next_task_for_host of class PlayIterator

# Generated at 2022-06-24 18:52:05.472380
# Unit test for method copy of class HostState
def test_HostState_copy():
    class_with_copy = HostState.copy(HostState)


# Generated at 2022-06-24 18:52:07.579605
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    [TO BE WRITTEN]
    '''
    pass


# Generated at 2022-06-24 18:52:13.199007
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    str_0 = '-Lc*wF\\|3/<Z'
    host_state_0 = HostState(str_0)
    block_0 = Block(str_0)
    block_1 = Block(str_0)
    block_2 = Block(str_0)
    block_3 = Block(str_0)
    block_4 = Block(str_0)
    play_iterator_0 = PlayIterator(host_state_0)
    play_iterator_0._host_states[str_0] = host_state_0
    play_iterator_0._host_states[str_0] = host_state_0
    play_iterator_0._host_states[str_0] = host_state_0
    play_iterator_0._host_states[str_0] = host_state_0

# Generated at 2022-06-24 18:52:14.549331
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    global str_0
    test_case_0()
    print(str_0)


# Generated at 2022-06-24 18:52:20.184110
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    str_0 = '-Lc*wF\\|3/<Z'
    str_1 = 'i-g1bZQ$~9/|'
    play_iterator_0 = PlayIterator()
    host_0 = Host('host_name')
    play_iterator_0._host_states[host_0] = str_0
    host_state_0 = play_iterator_0.get_host_state(host_0)
    assert (host_state_0 == str_0)
    assert (play_iterator_0._host_states[host_0] == str_1)


# Generated at 2022-06-24 18:52:24.410580
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    from ansible.executor.play_iterator import PlayIterator
    play_iterator_0 = PlayIterator()
    host_0 = MagicMock()
    play_iterator_0.get_next_task_for_host(host_0)


# Generated at 2022-06-24 18:52:29.468021
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    '''
    Test PlayIterator.__init__() method
    '''

    try:
        str_0 = '-Lc*wF\\|3/<Z'
        host_state_0 = HostState(str_0)
        play_0 = Play()
        play_iterator_0 = PlayIterator(play_0)
    except Exception as err:
        print(str(err))
        assert False


# Generated at 2022-06-24 18:52:38.597634
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # example scenario where we've executed a task within a block within the tasks of another block,
    # and the rescue of the inner block is currently running
    block1 = Block(block=['task1', 'task2'], rescue=['task3'])
    block2 = Block(block=['task4', block1], rescue=['task5'])
    blocks = [block2, 'task6']
    state = HostState(blocks)
    state.run_state = PlayIterator.ITERATING_TASKS
    state._blocks = blocks
    state.cur_regular_task = 1
    state.tasks_child_state = HostState(blocks=[block1])
    state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state._blocks = [block1]

# Generated at 2022-06-24 18:52:39.628505
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    test_case_0()

# Generated at 2022-06-24 18:55:03.421658
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    original_task = PlayIterator.get_original_task(self, host, task)
    
    


# Generated at 2022-06-24 18:55:11.048383
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Testing variables
    host_states = {}
    host_0 = Host(name='192.168.9.13')
    host_1 = Host(name='192.168.9.14')
    host_2 = Host(name='192.168.9.15')
    # State 0
    state_0 = HostState(blocks=[])
    host_states[host_0.name] = state_0
    # State 1
    state_1 = HostState(blocks=[])
    host_states[host_1.name] = state_1
    # State 2
    state_2 = HostState(blocks=[])
    host_states[host_2.name] = state_2
    # Initializing object and calling method
    obj_PlayIterator = PlayIterator(host_states=host_states)
    res_0 = obj_

# Generated at 2022-06-24 18:55:20.220720
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    def test():
        str_0 = '-Lc*wF\\|3/<Z'
        host_state_0 = HostState(str_0)

        play_iterator_0 = PlayIterator()

        host_0 = MagicMock(name=str_0)
        host_0.name = str_0
        host_0.vars = dict()
        # add a host variable which will be used in the tests
        host_0.vars['ansible_connection'] = 'local'
        # and one for each of the options
        host_0.vars['ansible_python_interpreter'] = ''
        host_0.vars['ansible_shell_type'] = ''
        host_0.vars['ansible_shell_executable'] = ''

        # ensure the host is not in the cache


# Generated at 2022-06-24 18:55:23.946862
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # FIXME: How to convert string to a list?
    list_0 = ['*']
    assert PlayIterator.cache_block_tasks(list_0) == '~'


# Generated at 2022-06-24 18:55:29.346635
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    str_0 = 'C#d=6U^0QZB0l'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator()
    assert play_iterator_0.is_any_block_rescuing(host_state_0)


# Generated at 2022-06-24 18:55:31.381684
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    try:
        play_iterator_0 = PlayIterator()
        play_iterator_0.get_failed_hosts()
    except Exception as e:
        print('Exception: {}'.format(e))


# Generated at 2022-06-24 18:55:33.518837
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    str_0 = 'l^[=I~`3c$_s?8'
    host_state_0 = HostState(str_0)
    str_1 = host_state_0.__str__()
    assert len(str_1) == 59


# Generated at 2022-06-24 18:55:44.424869
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    task_0 = Task()
    host_0 = Host(name=str())
    str_0 = '-Lc*wF\\|3/<Z'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator(host_state_0)
    host_state_0 = play_iterator_0.get_active_state(host_state_0)
    host_state_0 = play_iterator_0.get_active_state(host_state_0)
    host_state_0 = play_iterator_0.get_active_state(host_state_0)
    play_iterator_0.mark_host_failed(host_0)
    # Uncomment the following line to print the host_state_0 object
    # print(host_state_0)
    play_

# Generated at 2022-06-24 18:55:52.513002
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    str_0 = 'e>c%=M|T#!xj.8Qd,Bk\\Pk'
    name_0 = '<@a0'
    str_1 = 'zvK8W]+Z`~k]l,Cq3*$n'
    host_0 = Host(name_0)
    block_0 = Block()
    block_1 = Block(hosts=host_0, block=[], rescue=[], always=[])
    block_2 = Block(hosts=host_0, block=[], rescue=[], always=[])
    str_2 = 'd@!pP0<0yD'
    block_3 = Block(hosts=host_0, block=[block_0, block_2], rescue=[], always=[])
    task_0 = Task()

# Generated at 2022-06-24 18:55:59.689697
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    input_str = '*d^k-1gB+1$'
    play_iterator_0 = PlayIterator(input_str)
    state_0 = play_iterator_0.get_next_task_for_host(input_str)
    play_iterator_0.mark_host_failed(input_str)
    state_1 = play_iterator_0.get_next_task_for_host(input_str)
    assert(state_0.run_state == state_1.run_state)
