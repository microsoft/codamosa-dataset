

# Generated at 2022-06-24 18:47:04.580948
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # Uncomment this to test just this method without running the
    # play.
    # host = Mock()
    # host.name = 'localhost'
    # host_state = HostState()
    # play_iterator = PlayIterator(play=None, inventory=None, host_state_list=[host_state])
    # task_list = []
    # play_iterator.add_tasks(host, task_list)
    # assert(play_iterator._host_states[host.name] == host_state)
    pass


# Generated at 2022-06-24 18:47:08.899921
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # setup
    str_0 = 'f_'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator(host_state_0)
    host_0 = Host(name = 'foobar')
    # method call
    play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:47:16.938236
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    host_state_0 = HostState('V7v1,gS>|')
    assert host_state_0 is not None
    host_state_0.run_state = 2
    assert host_state_0.run_state == 2
    host_state_0.tasks_child_state = HostState('|}a!')
    assert host_state_0.tasks_child_state is not None
    play_iterator_0 = PlayIterator(play=Play(), inventory=InventoryLoader(loader=None, sources=None))
    play_iterator_0._host_states[host_state_0.host] = host_state_0
    play_iterator_0.get_active_state(host_state_0)


# Generated at 2022-06-24 18:47:25.487813
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    host_state_1 = HostState(str_0)
    host_state_2 = HostState(str_0)
    host_state_3 = HostState(str_0)
    play_iterator = PlayIterator()
    play_iterator.get_failed_hosts()
    play_iterator.get_failed_hosts()
    play_iterator.get_failed_hosts()
    play_iterator.get_failed_hosts()
    play_iterator.get_failed_hosts()


# Generated at 2022-06-24 18:47:27.130731
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    test_case_0()


# Generated at 2022-06-24 18:47:35.860283
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    string_0 = 'tQaX$'
    string_1 = 'JwL'
    dict_0 = dict()
    dict_0['xJl&_'] = string_1
    dict_0['&M/Z'] = string_0
    dict_0[''] = string_0
    host_state_0 = HostState(dict_0)
    string_2 = '-LBs+'
    host_state_1 = HostState(string_2)
    play_iterator_0 = PlayIterator(play=play_0, play_context=play_context_0)
    play_iterator_0._host_states['WH[5'] = host_state_1
    play_iterator_0.get_active_state(host_state_0)

# Generated at 2022-06-24 18:47:45.639664
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    h = Host("fakehost0")
    h.name = "testhost"
    p = Play(name="test", hosts=[h])
    i = PlayIterator(p)
    p.hosts = [h]
    i.hostvars = dict()
    i.hostvars['testhost'] = dict()
    i.hostvars['testhost']['vars'] = dict()
    i.hostvars['testhost']['vars']['inventory_hostname'] = 'testhost'
    i.hostvars['testhost']['vars']['inventory_hostname_short'] = 'testhost'
    assert i.hostvars['testhost']['vars']['inventory_hostname'] == 'testhost'

# Generated at 2022-06-24 18:47:48.221735
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_0 = {}
    play_iterator_0 = PlayIterator(play_0)


# Generated at 2022-06-24 18:47:52.219514
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    print("Testing get_active_state")
    test_case_0()
    print("Testing get_active_state - Complete")

if __name__ == '__main__':
    test_PlayIterator_get_active_state()

# Generated at 2022-06-24 18:47:56.944959
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    hosts_0 = frozenset([Host('HOSTNAME_0')])
    host_name_0 = Host('HOSTNAME_0')
    block_0 = Block([])
    host_state_0 = HostState(block_0)
    play_context_0 = PlayContext()
    play_context_0.remote_addr = 'HOSTNAME_0'
    play_iterator_0 = PlayIterator(hosts_0, host_name_0, play_context_0, None)
    play_iterator_0.set_host_state(host_state_0)
    hosts_1 = frozenset([Host('HOSTNAME_1')])
    host_name_1 = Host('HOSTNAME_1')
    host_state_1 = HostState(block_0)
    play_context_1 = PlayContext()

# Generated at 2022-06-24 18:48:30.348327
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    play_0 = Play()
    play_0._hosts = '127.0.0.1'
    play_0._tasks = []
    block_0 = Block(play_0._tasks)
    task_0 = Task()
    task_0._role = None
    task_0._loader = None
    task_0._name = 'setup'
    task_0._parent = None
    task_0._action = 'setup'
    task_0._args = dict()
    task_0._task_deps = dict()
    task_0._role_names = set()
    task_0._loop_with = None
    task_0._loop = None
    task_0._vars = dict()
    task_0._when = None
    task_0._always_run = False
    task_0._

# Generated at 2022-06-24 18:48:41.881748
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    str_0 = 'X\x1dN\x0c'
    block_0 = Block(str_0)
    host_0 = Host("9\x1d\x1e")
    play_iterator_0 = PlayIterator(block_0, host_0)
    str_1 = '\x1cO\x1e\x1a'
    block_1 = Block(str_1)
    play_iterator_1 = PlayIterator(block_1, host_0)
    play_iterator_2 = PlayIterator(block_1, host_0)
    i_0 = play_iterator_0._get_next_task_from_state(play_iterator_0._host_states[host_0.name], host_0)

# Generated at 2022-06-24 18:48:43.649637
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator(0)
    assert play_iterator_0 is not None


# Generated at 2022-06-24 18:48:48.871567
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator(play_0)
    host_0 = Host('b0033c20-2505-4d0f-ad7f-cdb34b05f357')
    play_iterator_0.get_next_task_for_host(host_0)


# Generated at 2022-06-24 18:48:58.889848
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    str_0 = 'agnD'
    str_1 = 'agnD'
    str_2 = 'agnD'
    host_0 = Host(str_0, port=0, variables={})
    host_1 = Host(str_1, port=0, variables={})
    assert host_0.name == str_0
    play_iterator_0 = PlayIterator(playbook=None, variable_manager=None, all_vars={}, start_at_task=None)
    host_state_0 = HostState(str_2)
    play_iterator_0._host_states[host_0.name] = host_state_0
    dict_0 = play_iterator_0.get_failed_hosts()
    assert dict_0 == {host_0: True}


# Generated at 2022-06-24 18:49:00.189845
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Creating instance of Play for testing
    play_0 = Play()
    # Creating instance of PlayIterator for testing
    play_iterator_0 = PlayIterator(play_0)

# Generated at 2022-06-24 18:49:08.091812
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play_iterator_0 = create_test_object_PlayIterator(None, None)
    play_iterator_0.host_states = {
        'host_0': HostState('str_0')
    }
    host_0 = create_test_object_Host('host_0', [])
    host_1 = create_test_object_Host('host_1', [])
    task_0 = create_test_object_Task(play_iterator_0, None, 'block_0', 'action_0', host_1)
    task_1 = create_test_object_Task(play_iterator_0, None, 'block_1', 'action_1', host_0)
    task_2 = create_test_object_Task(play_iterator_0, None, 'block_2', 'action_2', host_0)


# Generated at 2022-06-24 18:49:15.390945
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    print ('In method HostState::test_HostState___eq__')
    my_state = HostState('')
    my_other_state = HostState('')
    my_other_state_2 = HostState('')
    my_other_state_2.cur_regular_task = 1

    assert my_state == my_other_state
    assert my_other_state != my_other_state_2




# Generated at 2022-06-24 18:49:18.867100
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    str_0 = 'agnD'
    play_iterator_0 = PlayIterator(str_0)

    str_1 = 'agnD'
    host_state_0 = play_iterator_0.get_host_state(str_1)


# Generated at 2022-06-24 18:49:20.348670
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Failed: Unsupported value type for argument 'host': str_0
    pass


# Generated at 2022-06-24 18:49:49.220801
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    print('Testing HostState::__str__')
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    str_expected = 'HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False'
    str_actual = host_state_0.__str__()
    assert str_actual == str_expected


# Generated at 2022-06-24 18:49:51.274131
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Just a smoke test to verify that the method runs without error
    play_iterator_0 = PlayIterator()
    host_0 = Host()
    play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:49:53.151958
# Unit test for method get_failed_hosts of class PlayIterator

# Generated at 2022-06-24 18:49:59.031207
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play_0 = Play()
    play_iterator_0 = PlayIterator(play_0)

    # from uuid import UUID
    # test data

# Generated at 2022-06-24 18:50:01.238570
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    str_0 = 'agnD'
    play_iterator_0 = PlayIterator()
    play_iterator_0.get_host_state(str_0)


# Generated at 2022-06-24 18:50:06.335618
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    str_0 = '\x08\n\x06blocks\x12\x06\n\x04name\x12\x04test'
    host_state_0 = HostState(str_0)
    str_1 = '\x08\n\x06blocks\x12\x06\n\x04name\x12\x04test'
    host_state_1 = HostState(str_1)
    bool_0 = host_state_0.is_any_block_rescuing(host_state_1)
    assert bool_0 == False
    assert True


# Generated at 2022-06-24 18:50:16.403495
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host_0 = Host("host_0", 'mock', name='host_0')
    host_1 = Host("host_1", 'mock', name='host_1')
    host_2 = Host("host_2", 'mock', name='host_2')
    host_3 = Host("host_3", 'mock', name='host_3')
    # Return type is dict
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    host_state_0.cur_regular_task = 0
    host_state_1 = HostState(str_0)
    host_state_1.cur_regular_task = 0
    host_state_2 = HostState(str_0)
    host_state_2.cur_regular_task = 0
    host_state

# Generated at 2022-06-24 18:50:21.427282
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states = {str_0: host_state_0}
    host_0 = Host('d6af9637e038dda8')
    assert play_iterator_0.is_failed(host_0)

if __name__ == '__main__':
    test_case_0()
    test_PlayIterator_is_failed()

# Generated at 2022-06-24 18:50:22.636687
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_iterator_0 = PlayIterator()
    test_case_0()


# Generated at 2022-06-24 18:50:30.728017
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    str_0 = 'p6\x1d\x15\n\x07include\x12\x05block'
    block_0 = Block.load(str_0)
    str_1 = '\x92\x01\n\x0c\n\x04task\x12\x0c\n\x04name\x12\x02hi\x1a\x03\x08\x01\x10\x01'
    task_0 = Task.load(str_1)
    block_1 = block_0.copy()
    block_1.block.append(task_0)
    play_iterator_0 = PlayIterator(block_1)
    host_state_0 = play_iterator_0.get_host_state(None)

# Generated at 2022-06-24 18:50:58.574601
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    str_0 = 'agnD'
    host_0 = Host(str_0)
    play_iterator_0 = PlayIterator(None)
    host_0.name = 'agnD'
    play_iterator_0.mark_host_failed(host_0)


# Generated at 2022-06-24 18:51:06.042448
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():

    display.verbosity = 3

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    t0 = Task()
    t0._role_name = 'foo'
    t0.action = 'meta'
    t1 = Task()
    t1._role_name = 'foo'
    t1.action = 'command'
    t2 = Task()
    t2._role_name = 'foo'
    t2.action = 'shell'
    t3 = Task()
    t3._role_name = 'foo'
    t3.action = 'raw'

    p0 = Play()
    p0._included_roles = [Role('bar')]

# Generated at 2022-06-24 18:51:14.227297
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play_0 = Play().load(get_fixture_path('syntax_errors/syntax_error_then_continue.yml'), variable_manager=VariableManager(), loader=Loader())
    hosts_0 = Hosts()
    host_0 = hosts_0.add_host('host_0')
    host_1 = hosts_0.add_host('host_1')
    iterator_0 = PlayIterator(play_0, hosts_0, True, None)
    iterator_0.mark_host_failed(host_0)
    iterator_0.mark_host_failed(host_1)
    result_0 = iterator_0.get_failed_hosts()
    assert 'host_0' in result_0
    assert 'host_1' in result_0


# Generated at 2022-06-24 18:51:14.744864
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    pass


# Generated at 2022-06-24 18:51:19.013027
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    test_case_0()


if __name__ == '__main__':
    test_PlayIterator()

# Generated at 2022-06-24 18:51:25.799966
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    host_state_0 = HostState()
    host_0 = Host(host_state_0)
    task_0 = Task()
    play_iterator_0 = PlayIterator(host_0, task_0)
    test_result_0 = play_iterator_0.get_original_task(host_0, task_0)
    display.info('test_result_0: %s' % test_result_0)

if __name__ == '__main__':
    test_case_0()
    test_PlayIterator_get_original_task()

# Generated at 2022-06-24 18:51:29.532415
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    test_PlayIterator_init()
    output_0 = False
    str_0 = 'PlayIterator'
    state_0 = HostState(str_0)
    ret_0 = PlayIterator.is_any_block_rescuing(state_0)
    assert ret_0 == output_0


# Generated at 2022-06-24 18:51:41.903772
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    test_name = 'get_host_state'
    test_entry = {
        'result': False,
        'message': '',
        'traceback': ''
    }
    result = False
    try:
        str_0 = 'agnD'
        host_state_0 = HostState(str_0)
        str_1 = ''
        call_0 = PlayIterator([host_state_0], None, None)
        call_0.get_host_state(str_1)
        if (str_1 == str_0):
            result = True
    except BaseException as e:
        test_entry['result'] = False
        test_entry['traceback'] = traceback.format_exc()
        test_entry['message'] = e.message
    finally:
        assert result, test_entry['message']


# Generated at 2022-06-24 18:51:47.757606
# Unit test for method copy of class HostState
def test_HostState_copy():
    host_state_0 = HostState('D')
    host_state_0.cur_block = -8
    host_state_0.cur_regular_task = 0
    host_state_0.cur_rescue_task = -1
    host_state_0.cur_always_task = -5
    host_state_0.run_state = PlayIterator.ITERATING_TASKS
    host_state_0.fail_state = PlayIterator.FAILED_TASKS
    host_state_0.pending_setup = 0
    host_state_0.did_rescue = 0
    host_state_0.did_start_at_task = 1
    host_state_1 = host_state_0.copy()

# Generated at 2022-06-24 18:51:58.228467
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator(play_0)
    host_0 = Host(str_0)
    play_iterator_0.get_next_task_for_host(host_0)
    assert play_iterator_0._host_states[host_0.name].run_state is None
    assert play_iterator_0._host_states[host_0.name].tasks_child_state is None
    assert play_iterator_0._host_states[host_0.name]._blocks is play_0._tasks
    assert play_iterator_0._host_states[host_0.name].cur_block is 0
    assert play_iterator_0._host_states[host_0.name].cur_regular_task is 0
    assert play_iterator_0._host_states[host_0.name].cur_res

# Generated at 2022-06-24 18:52:29.057442
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Initialize the class
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    str_1 = 'this_is_a_fake_play'
    play_0 = Play(str_1)
    play_iterator_0 = PlayIterator(play_0)
    # Invoke method
    #result = play_iterator_0.is_any_block_rescuing(host_state_0)
    


# Generated at 2022-06-24 18:52:33.846383
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0._host_states = {str_0: host_state_0}
    assert_equal(play_iterator_0.get_host_state(str_0), host_state_0)


# Generated at 2022-06-24 18:52:42.546485
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    iterator_0 = PlayIterator()
    block_0 = Block()
    block_1 = Block()
    block_1.block = [block_0]
    block_2 = Block()
    block_2.block = [block_1]
    host_state_0 = HostState(blocks=[block_2])
    host_state_0.run_state = 3
    host_state_0.cur_block = 0
    host_state_0.tasks_child_state = HostState(blocks=[block_1])
    host_state_0.tasks_child_state.run_state = 2
    host_state_0.tasks_child_state.cur_block = 0
    host_state_0.tasks_child_state.tasks_child_state = HostState(blocks=[block_0])
    host

# Generated at 2022-06-24 18:52:52.594207
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    host_0 = Host(name='host_0')
    str_0 = 'agnD'
    play_iterator_0 = PlayIterator(inventory=str_0)
    # Test attribute 'host_states' of Class PlayIterator
    str_1 = ';jbW'
    play_iterator_0.host_states = str_1
    # Test argument 'host' of method 'get_host_state' of Class PlayIterator
    host_state_0 = play_iterator_0.get_host_state(host_0)
    # Test method 'get_host_state' of Class PlayIterator
    test_case_0()


# Generated at 2022-06-24 18:53:00.465313
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_0 = Play()
    play_0._included_file_paths = ['tests/test_playbooks/include_playbook.yml']
    play_0._playbook = Playbook.load(play_0._ds, play_0._basedir, play_0._included_file_paths[0])
    play_iterator_0 = PlayIterator(play_0)
    host_0 = Host('fake_host_0')
    host_1 = Host('fake_host_1')
    play_iterator_0.get_next_task_for_host(host_0)
    PlayIterator_get_next_task_for_host_call_0 = PlayIterator_get_next_task_for_host_call(play_iterator_0, host_0)
    play_iterator_0.get_next_

# Generated at 2022-06-24 18:53:01.452182
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    test_case_0()


# Generated at 2022-06-24 18:53:04.002093
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_iterator_0 = PlayIterator()
    assert play_iterator_0.get_next_task_for_host() == None


# Generated at 2022-06-24 18:53:09.627234
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    str_0 = 'RS]T'
    host_state_0 = HostState(str_0)
    str_0 = "HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False"
    assert str(host_state_0) == str_0


# Generated at 2022-06-24 18:53:18.083894
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # Setup inventory for use in testing
    play = Play().load('test/ansible/playbooks/test_playbook_loops.yml', variable_manager=VariableManager(), loader=Loader())
    inventory = Inventory(loader=Loader(), variable_manager=VariableManager(), host_list=['test/ansible/hosts/test_inventory.yml'])

    # Run test
    play_iterator = PlayIterator()
    play_iterator.play = play
    play_iterator.inventory = inventory
    play_iterator.play_context = play.get_play_context()

    host_state_0 = HostState('str_0')
    play_iterator.cache_block_tasks(host_state_0, 0, 'str_1')
    host_state_1 = HostState('str_0')
    host_state_1.cur

# Generated at 2022-06-24 18:53:23.942056
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # there is no unit test for this method since it just calls _check_failed_state
    # which is tested by the above tests for _check_failed_state
    pass


# Generated at 2022-06-24 18:54:01.350849
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    state_0 = HostState('A')
    state_0.always_child_state = HostState('B')
    state_0.always_child_state.always_child_state = HostState('C')
    state_1 = HostState('A')
    state_1.always_child_state = HostState('B')
    state_1.always_child_state.always_child_state = HostState('C')
    state_1.always_child_state.always_child_state.always_child_state = HostState('C')
    assert state_1 != state_0


# Generated at 2022-06-24 18:54:07.711476
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    str_1 = 'Q;6\x1b+\x7f\x0f\x0eC\x1aS\x19'
    str_2 = 'z'
    str_3 = 'Eq8'
    str_4 = 'lS'
    str_5 = '=5X'
    str_6 = '_'
    str_7 = '\x7f'
    str_8 = '\x0f\x0e'
    str_9 = '<'
    str_10 = '\x18'
    str_11 = '\x16R'
    str_12 = '\x1b\x7f\x0f'
    str_13 = '"\x0f'
    str_14 = '\x1e\x0e'
    str_

# Generated at 2022-06-24 18:54:08.432487
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    pass


# Generated at 2022-06-24 18:54:14.033054
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    str_0 = 'agnD'
    task_0 = MagicMock(name='task')
    host_0 = MagicMock(name='host')
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator()
    play_iterator_0.get_host_state = MagicMock(return_value=host_state_0)
    play_iterator_0.is_failed = MagicMock(return_value=False)
    play_iterator_0.get_active_state = MagicMock(return_value=host_state_0)
    play_iterator_0.is_any_block_rescuing = MagicMock(return_value=True)
    play_iterator_0.get_original_task(host_0, task_0)
    host_state_0._

# Generated at 2022-06-24 18:54:17.752015
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    play_iterator_0 = PlayIterator()
    play_0 = Play()
    result = play_iterator_0.is_failed(play_0)
    print(result)


# Generated at 2022-06-24 18:54:25.347993
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    from ansible.playbook.block import Block

    pb = Playbook('test', [], None)
    host_state_0 = HostState(pb)

    block = Block()
    block.block = ['a', 'b', 'c']
    block.rescue = ['r', 'u', 'e']
    block.always = ['d', 'o', 'n', 'e']

    host_state_0._blocks.append(block)
    host_state_0.cur_block = 0
    host_state_0.cur_regular_task = 3
    host_state_0.cur_rescue_task = 3
    host_state_0.cur_always_task = 4

    active_state = PlayIterator.get_active_state(host_state_0)
    assert active_state is not None

    block

# Generated at 2022-06-24 18:54:32.429407
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    PlayIterator_instance = PlayIterator('A', "QxnL'\x1a\x1c", 123, (123, 123), ['D'])
    original_task_0 = PlayIterator_instance.get_original_task('F', 123)
    original_task_1 = PlayIterator_instance.get_original_task(123, "QxnL'\x1a\x1c")
    original_task_2 = PlayIterator_instance.get_original_task("QxnL'\x1a\x1c", PlayIterator_instance)
    original_task_3 = PlayIterator_instance.get_original_task("A", "QxnL'\x1a\x1c")
    original_task_4 = PlayIterator_instance.get_original_task("A", 123)
    original_task_

# Generated at 2022-06-24 18:54:40.306723
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    str_0 = 'agnD'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator(play=None)
    play_iterator_0._host_states[str_0] = host_state_0
    dict_0 = play_iterator_0.get_failed_hosts()
    assert dict_0.has_key('agnD')
    assert dict_0['agnD'] == True


# Generated at 2022-06-24 18:54:43.396535
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    str_0 = 'host_0'
    host_0 = Host(str_0)
    play_iterator_0 = PlayIterator(None)
    play_iterator_0.mark_host_failed(host_0)
    # EXPECTING: 'FAILED'
    print(play_iterator_0.is_failed(host_0))


# Generated at 2022-06-24 18:54:49.718685
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # Tests adding tasks to the task lists.
    play_0 = Play().load('test/playbooks/playbook.yml')
    hosts_0 = ['localhost']
    result_0 = play_0.compile()
    iterator_0 = PlayIterator(play_0, hosts_0)


# Generated at 2022-06-24 18:55:52.566726
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    test_case_0()


# Generated at 2022-06-24 18:55:53.603582
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass


# Generated at 2022-06-24 18:55:59.954661
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    str_0 = 'agnD'
    play_iterator_0 = PlayIterator(None, None, None, None, None, None)
    host_state_0 = HostState(str_0)
    play_iterator_0._host_states = {str_0: host_state_0}
    host_0 = Host('localhost', None, host_state_0)
    host_state_1 = play_iterator_0.get_host_state(host_0)


# Generated at 2022-06-24 18:56:09.380279
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    iterator_0 = PlayIterator()
    inventory_0 = MagicMock()
    inventory_0.hosts.return_value = {}
    host_0 = inventory_0.get_host.return_value = MagicMock('<Host: foo>')
    host_state_0 = MagicMock('HostState')
    iterator_0._host_states = {'foo': host_state_0}
    task_list_0 = MagicMock('task_list_0')
    task_list_0 = []
    iterator_0.add_tasks(host_0, task_list_0)
    assert host_state_0.insert_tasks_into_state.call_count == 0


# Generated at 2022-06-24 18:56:13.562947
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    str_0 = 'TzrF'
    host_state_0 = HostState(str_0)
    play_iterator_0 = PlayIterator()
    host_0 = Host(str_0)
    play_iterator_0.add_host(host_0)
    play_iterator_0._host_states[str_0] = host_state_0
    play_iterator_0.get_active_state(host_state_0)


# Generated at 2022-06-24 18:56:22.509575
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    str_0 = 'agnD'
    str_1 = '2rYr'
    str_2 = 'agnD'
    str_3 = '2rYr'
    str_4 = 'agnD'
    str_5 = 'agnD'
    str_6 = '2rYr'
    str_7 = 'agnD'
    host_state_0 = HostState(str_0)
    host_state_1 = HostState(str_1)
    host_state_2 = HostState(str_2)
    host_state_3 = HostState(str_3)
    host_state_4 = HostState(str_4)
    host_state_5 = HostState(str_5)
    host_state_6 = HostState(str_6)
    play_0 = Play()


# Generated at 2022-06-24 18:56:27.333999
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    print("Testing class 'PlayIterator'.\n")
    test_case_0()
    print("All unittests for class 'PlayIterator' passed!")

if __name__ == "__main__":
    test_PlayIterator()