

# Generated at 2022-06-16 20:55:21.919450
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Setup
    play = Play()
    play.name = 'test_play'
    play.hosts = 'test_host'

# Generated at 2022-06-16 20:55:34.520415
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    blocks = [Block(parent=None, role=None, task_include=None, use_block_args=False)]
    host_state = HostState(blocks)
    host_state.cur_block = 0
    host_state.cur_regular_task = 0
    host_state.cur_rescue_task = 0
    host_state.cur_always_task = 0
    host_state.run_state = PlayIterator.ITERATING_SETUP
    host_state.fail_state = PlayIterator.FAILED_NONE
    host_state.pending_setup = False
    host_state.tasks_child_state = None
    host_state.rescue_child_state = None
    host_state.always_child_state = None
    host_state.did_rescue = False

# Generated at 2022-06-16 20:55:47.248402
# Unit test for method get_host_state of class PlayIterator

# Generated at 2022-06-16 20:55:55.999991
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host = Host('localhost')

# Generated at 2022-06-16 20:56:00.156015
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    Unit test for method get_failed_hosts of class PlayIterator
    '''
    # Create a PlayIterator object
    play_iterator_obj = PlayIterator()
    # Create a Host object
    host_obj = Host()
    # Call method get_failed_hosts of PlayIterator object and store its return value in a variable
    ret_val = play_iterator_obj.get_failed_hosts()
    # Check if the return value is a dictionary
    assert isinstance(ret_val, dict)

# Generated at 2022-06-16 20:56:07.263939
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    play = Play()
    play.hosts = ['localhost']
    play.tasks = [
        Task(),
        Task(),
        Task()
    ]
    iterator = PlayIterator(play)
    host = Host('localhost')
    state = iterator.get_host_state(host)
    assert state.run_state == iterator.ITERATING_TASKS
    assert state.cur_block == 0
    assert state.cur_regular_task == 0
    assert state.cur_rescue_task == 0
    assert state.cur_always_task == 0
    assert state.fail_state == iterator.FAILED_NONE
    assert state.tasks_child_state is None
    assert state.rescue_child_state is None
    assert state.always_child_state is None

# Generated at 2022-06-16 20:56:17.356818
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Test with no hosts
    play = Play()
    play_iterator = PlayIterator(play)
    assert play_iterator.get_failed_hosts() == {}

    # Test with one host
    host = Host('test_host')
    play.add_host(host)
    play_iterator = PlayIterator(play)
    assert play_iterator.get_failed_hosts() == {}

    # Test with two hosts
    host2 = Host('test_host2')
    play.add_host(host2)
    play_iterator = PlayIterator(play)
    assert play_iterator.get_failed_hosts() == {}

    # Test with one host failed
    play_iterator.mark_host_failed(host)
    assert play_iterator.get_failed_hosts() == {host: True}

    # Test with two hosts

# Generated at 2022-06-16 20:56:24.603630
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Create a PlayIterator object
    play_iterator_obj = PlayIterator()
    # Create a HostState object
    host_state_obj = HostState()
    # Call method is_any_block_rescuing with state
    # Create a Block object
    block_obj = Block()
    # Create a list of tasks
    task_list = []
    # Create a Task object
    task_obj = Task()
    # Add task to list of tasks
    task_list.append(task_obj)
    # Set block's tasks
    block_obj.block = task_list
    # Set host_state's blocks
    host_state_obj._blocks = [block_obj]
    # Set host_state's run_state
    host_state_obj.run_state = play_iterator_obj.ITERATING_TASKS
   

# Generated at 2022-06-16 20:56:36.082241
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Unit test for method cache_block_tasks of class PlayIterator
    '''
    # Create a PlayIterator object
    play_iterator = PlayIterator()
    # Create a Host object
    host = Host()
    # Create a Block object
    block = Block()
    # Create a Task object
    task = Task()
    # Create a HostState object
    host_state = HostState()
    # Create a HostState object
    host_state_2 = HostState()
    # Create a HostState object
    host_state_3 = HostState()
    # Create a HostState object
    host_state_4 = HostState()
    # Create a HostState object
    host_state_5 = HostState()
    # Create a HostState object
    host_state_6 = HostState()
    # Create a HostState object

# Generated at 2022-06-16 20:56:42.741380
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Test for method is_any_block_rescuing of class PlayIterator
    '''
    # Setup test
    play_iterator = PlayIterator()
    play_iterator._host_states = {'host1': HostState(blocks=[Block(rescue=[])])}
    state = play_iterator.get_host_state('host1')
    state.run_state = PlayIterator.ITERATING_RESCUE
    # Test
    assert play_iterator.is_any_block_rescuing(state) == True


# Generated at 2022-06-16 20:57:20.781801
# Unit test for method __str__ of class HostState

# Generated at 2022-06-16 20:57:32.299360
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Create a play
    play = Play().load(dict(
        name = "foobar",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())

    # Create a play iterator
    piterator = PlayIterator(play)

    # Create a host
    host = Host(name="foobar")

    # Create a task
    task = Task()

    # Test get_next_task_for_host

# Generated at 2022-06-16 20:57:38.724055
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())

    pi = PlayIterator(p)
    assert pi._play is p
    assert pi._host_states == {}
    assert pi._play_context is None
    assert pi._iterator is None
    assert pi._last_task_banner is None
    assert pi._last_task_name is None
    assert pi._last_task_action is None
    assert pi._last_task_

# Generated at 2022-06-16 20:57:51.505499
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Setup
    play_iterator = PlayIterator()
    state = HostState()
    state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state = HostState()
    state.tasks_child_state.run_state = PlayIterator.ITERATING_RESCUE
    state.tasks_child_state.rescue_child_state = HostState()
    state.tasks_child_state.rescue_child_state.run_state = PlayIterator.ITERATING_ALWAYS
    state.tasks_child_state.rescue_child_state.always_child_state = HostState()
    state.tasks_child_state.rescue_child_state.always_child_state.run_state = PlayIterator.ITERATING_COMPLETE
    # Exercise
    result

# Generated at 2022-06-16 20:57:58.073178
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    Unit test for method get_host_state of class PlayIterator
    '''
    # Create a PlayIterator object
    play_iterator = PlayIterator()
    # Create a Host object
    host = Host()
    # Call method get_host_state of PlayIterator object
    result = play_iterator.get_host_state(host)
    assert result == None


# Generated at 2022-06-16 20:58:08.164825
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Setup
    play = Play()
    play.hosts = 'host1'
    play.name = 'test_play'
    play.tasks = [DictObj(action=dict(module='test_module', args=dict(arg1=1, arg2=2)))]
    play.handlers = []
    play.post_tasks = []
    play.roles = []
    play.vars = dict()
    play.tags = []
    play.gather_facts = 'no'
    play.serial = 1
    play.max_fail_percentage = 0
    play.any_errors_fatal = False
    play.notify = []
    play.deprecate_tags = []
    play.no_log = []
    play.force_handlers = False

# Generated at 2022-06-16 20:58:15.878009
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load(os.path.join(os.path.dirname(__file__), 'test_playbooks/playbook_empty.yml'), variable_manager=VariableManager(), loader=Loader())
    pi = PlayIterator(p)
    assert pi._play is p
    assert pi._host_states == {}
    assert pi._play_context is None
    assert pi._play_context_path is None
    assert pi._play_context_original is None
    assert pi._play_context_original_path is None
    assert pi._play_context_original_vars is None
    assert pi._play_context_original_vars_path is None
    assert pi._play_context_path_cache == {}
    assert pi._play_context_path_cache_lock is None
    assert pi._play_context_path_cache_

# Generated at 2022-06-16 20:58:17.304186
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass

# Generated at 2022-06-16 20:58:29.572534
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Unit test for method cache_block_tasks of class PlayIterator
    '''
    # Create a PlayIterator object
    play_iterator = PlayIterator()

    # Create a Block object
    block = Block()

    # Create a Task object
    task = Task()

    # Create a Host object
    host = Host()

    # Create a HostState object
    host_state = HostState()

    # Create a HostState object
    host_state_2 = HostState()

    # Create a HostState object
    host_state_3 = HostState()

    # Create a HostState object
    host_state_4 = HostState()

    # Create a HostState object
    host_state_5 = HostState()

    # Create a HostState object
    host_state_6 = HostState()

    # Create a HostState object

# Generated at 2022-06-16 20:58:36.210755
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Create a PlayIterator object
    play_iterator = PlayIterator()

    # Create a Play object
    play = Play()

    # Create a Host object
    host = Host()

    # Call method get_next_task_for_host of PlayIterator object and store its return value in a variable
    result = play_iterator.get_next_task_for_host(play, host)

    # Assert the return value is None
    assert result is None

# Generated at 2022-06-16 20:59:07.426429
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''
    # Create a PlayIterator object
    play_iterator_obj = PlayIterator()

    # Create a Host object
    host_obj = Host(name='host_name')

    # Call method mark_host_failed with parameters: host
    # The call to method mark_host_failed is not yet implemented
    try:
        play_iterator_obj.mark_host_failed(host=host_obj)
    except NotImplementedError:
        pass


# Generated at 2022-06-16 20:59:16.607222
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Setup
    play = Play()
    play.hosts = 'localhost'
    play.tasks = [dict(action='setup')]
    play.post_tasks = [dict(action='debug', msg='post_task')]
    play.handlers = [dict(action='debug', msg='handler')]
    play.roles = ['role1']
    play.tasks[0]['block'] = [dict(action='debug', msg='task1')]
    play.tasks[0]['block'][0]['rescue'] = [dict(action='debug', msg='rescue1')]
    play.tasks[0]['block'][0]['always'] = [dict(action='debug', msg='always1')]

# Generated at 2022-06-16 20:59:26.823856
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Test with a play that has no hosts
    p = Play()
    pi = PlayIterator(p)
    assert pi.get_failed_hosts() == {}

    # Test with a play that has one host
    p = Play()
    h = Host('host1')
    p.add_host(h)
    pi = PlayIterator(p)
    assert pi.get_failed_hosts() == {}

    # Test with a play that has two hosts
    p = Play()
    h1 = Host('host1')
    h2 = Host('host2')
    p.add_host(h1)
    p.add_host(h2)
    pi = PlayIterator(p)
    assert pi.get_failed_hosts() == {}

    # Test with a play that has one host and that host has failed
    p

# Generated at 2022-06-16 20:59:39.956889
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # Test with a block that has no rescue or always
    block = Block(play=Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami')),
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader()))
    block._role = Role()
    block._role.compile()
    block._role.post_validate(block, False)
    block._role._parent_block = block
    block._role._parent_block_type = 'tasks'
    block._role._role_path = '/etc/ansible/roles/test_role'
    block._role._

# Generated at 2022-06-16 20:59:42.826558
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Create a PlayIterator object
    play_iterator_obj = PlayIterator()
    # Call method get_failed_hosts of PlayIterator object
    play_iterator_obj.get_failed_hosts()


# Generated at 2022-06-16 20:59:53.752618
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    Unit test for method get_host_state of class PlayIterator
    '''
    # Create a mock Play
    play = Play()
    # Create a mock Host
    host = Host(name='hostname')
    # Create a mock Block
    block = Block()
    # Create a mock HostState
    host_state = HostState(blocks=[block])
    # Create a PlayIterator
    play_iterator = PlayIterator(play)
    # Create a mock Task
    task = Task()
    # Create a mock TaskResult
    task_result = TaskResult(host=host, task=task, task_fields=dict())
    # Create a mock TaskQueueManager
    task_queue_manager = TaskQueueManager(play_iterator=play_iterator)
    # Create a mock PlayContext

# Generated at 2022-06-16 21:00:05.461528
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Setup
    play = Play()
    play.hosts = ['localhost']
    play.name = 'test'

# Generated at 2022-06-16 21:00:14.054055
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play()
    p.hosts = ['a', 'b', 'c']
    p.tasks = [dict(action='debug', msg='hello')]
    p.handlers = [dict(action='debug', msg='hello')]
    p.post_tasks = [dict(action='debug', msg='hello')]
    p.roles = [dict(name='foo', tasks=[dict(action='debug', msg='hello')])]
    p.post_roles = [dict(name='foo', tasks=[dict(action='debug', msg='hello')])]
    p.vars = dict(a=1, b=2)
    p.default_vars = dict(c=3, d=4)
    p.playbook = 'test.yml'

# Generated at 2022-06-16 21:00:21.476051
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    Unit test for method get_host_state of class PlayIterator
    '''
    # Create a PlayIterator object
    play_iterator = PlayIterator()

    # Create a Host object
    host = Host()

    # Call method get_host_state of PlayIterator object
    result = play_iterator.get_host_state(host)

    # AssertionError: <ansible.playbook.host.HostState object at 0x7f0f9a0c9c50> != None
    assert result != None


# Generated at 2022-06-16 21:00:32.763799
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Create a play with a single task
    play = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())

    # Create a play iterator to iterate over tasks in the play
    piterator = PlayIterator(play)

    # Create a host
    host = Host(name="testhost")

    # Make sure the play iterator returns the first task
    (state, task) = piterator.get_next_task_for_host(host)
    assert task

# Generated at 2022-06-16 21:01:24.880732
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    # Create an instance of class PlayIterator
    play_iterator = PlayIterator()
    # Create an instance of class Host
    host = Host()
    # Create an instance of class HostState
    host_state = HostState()
    # Call method is_failed of class PlayIterator
    result = play_iterator.is_failed(host)
    # Assert the result
    assert result == False


# Generated at 2022-06-16 21:01:37.236994
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # setup
    play_iterator = PlayIterator()
    state = HostState()
    state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state = HostState()
    state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state.tasks_child_state = HostState()
    state.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    state.tasks_child_state.tasks_child_state.tasks_child_state = HostState()
    state.tasks_child_state.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    state

# Generated at 2022-06-16 21:01:50.993765
# Unit test for method cache_block_tasks of class PlayIterator

# Generated at 2022-06-16 21:01:58.867721
# Unit test for method is_any_block_rescuing of class PlayIterator

# Generated at 2022-06-16 21:02:10.778463
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # Create a play object
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DictDataLoader())

    # Create a task list and populate it with 3 tasks
    task_list = TaskList(play=play)
    task_list.add(Task(action=dict(module='shell', args='ls')))

# Generated at 2022-06-16 21:02:22.814926
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    Unit test for method get_next_task_for_host of class PlayIterator
    '''
    # Setup
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
   

# Generated at 2022-06-16 21:02:35.707182
# Unit test for method add_tasks of class PlayIterator

# Generated at 2022-06-16 21:02:46.856754
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # Setup
    play = Play()
    play.hosts = ['localhost']
    play.tasks = [dict(action='setup'), dict(action='debug', msg='hello world')]
    play.post_tasks = [dict(action='debug', msg='goodbye world')]
    play.handlers = [dict(action='debug', msg='handler world')]
    play.post_handlers = [dict(action='debug', msg='post handler world')]
    play.roles = [dict(name='test_role', tasks=[dict(action='debug', msg='role world')])]
    play.post_roles = [dict(name='test_role', tasks=[dict(action='debug', msg='post role world')])]
    play.vars = dict(a=1, b=2)
    play.vars

# Generated at 2022-06-16 21:03:00.090246
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Unit test for method cache_block_tasks of class PlayIterator
    '''
    # Create a play
    play = Play()
    play.name = "test play"
    play.hosts = "localhost"
    play.gather_facts = "no"
    play.tasks = [
        dict(action=dict(module="shell", args="ls"), register="shell_out"),
        dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}"))),
        dict(action=dict(module="shell", args="ls /tmp"), register="shell_out"),
        dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}"))),
    ]

    # Create a play iterator
    play_iterator = PlayIterator()
    play

# Generated at 2022-06-16 21:03:09.743186
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # test with a state that has no child states
    state = HostState(blocks=[])
    state.run_state = PlayIterator.ITERATING_TASKS
    state.cur_block = 0
    state.cur_regular_task = 0
    state.cur_rescue_task = 0
    state.cur_always_task = 0
    state.tasks_child_state = None
    state.rescue_child_state = None
    state.always_child_state = None
    state.did_rescue = False
    state.fail_state = PlayIterator.FAILED_NONE
    state._blocks = [Block(block=[]), Block(block=[])]
    assert PlayIterator.get_active_state(state) == state

    # test with a state that has a child state