

# Generated at 2022-06-20 14:06:01.047696
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    mock_play = create_autospec(Play().__class__, spec_set=True, instance=True)
    mock_play._removed_hosts = []
    mock_play.failed_hosts = {}
    mock_task1 = create_autospec(Task().__class__, spec_set=True, instance=True)
    mock_task1.name = 'task 1'
    mock_task2 = create_autospec(Task().__class__, spec_set=True, instance=True)
    mock_task2.name = 'task 2'
    mock_task3 = create_autospec(Task().__class__, spec_set=True, instance=True)
    mock_task3.name = 'task 3'

# Generated at 2022-06-20 14:06:04.664866
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # Creation of the object
    play_iterator = PlayIterator()
    play_iterator._play = Play()

    # Testing the method
    assert play_iterator.get_failed_hosts() == {}

# Generated at 2022-06-20 14:06:15.396899
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Setup
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    p = Play()
    p._tasks = [
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
    ]
    block1 = Block()
    block1._parent_block = p
    block1._task_include = "tasks.yml"

    b1t1 = Task()
    b1t2 = Task()
    b1t3 = Task()
    b1t4 = Task()

# Generated at 2022-06-20 14:06:28.299801
# Unit test for constructor of class PlayIterator

# Generated at 2022-06-20 14:06:29.081252
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    pass

# Generated at 2022-06-20 14:06:35.297088
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host = fake_host()
    tasks = [TQM._send_task_start, TQM._send_task_start, TQM._send_task_start]
    (state, task) = TQM._get_next_task_from_state(TQM.get_host_state(host), host=host)
    state = TQM._insert_tasks_into_state(state, tasks)
    assert state.run_state == 18
    assert state._blocks[0].block[0:3] == tasks
    remove_host(host)


# Generated at 2022-06-20 14:06:47.612367
# Unit test for constructor of class HostState
def test_HostState():
    test_HostState = HostState(blocks=[Block()])
    assert test_HostState._blocks == [Block()]
    assert test_HostState.cur_block == 0
    assert test_HostState.cur_regular_task == 0
    assert test_HostState.cur_rescue_task == 0
    assert test_HostState.cur_always_task == 0
    assert test_HostState.run_state == PlayIterator.ITERATING_SETUP
    assert test_HostState.fail_state == PlayIterator.FAILED_NONE
    assert test_HostState.pending_setup == False
    assert test_HostState.tasks_child_state == None
    assert test_HostState.rescue_child_state == None
    assert test_HostState.always_child_state == None
    assert test_HostState.did

# Generated at 2022-06-20 14:06:48.995734
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # TODO
    return


# Generated at 2022-06-20 14:07:03.146406
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # The test PlayIterator object
    play_iterator = PlayIterator()

    # The test HostState object
    host_state = HostState()
    host_state.cur_block = 0
    mock_block = mock.Mock(spec=[])
    mock_block.cur_regular_task = 0
    mock_block.cur_rescue_task = 0
    mock_block.cur_always_task = 0
    host_state._blocks.append(mock_block)
    host_state.run_state = PlayIterator.ITERATING_TASKS
    play_iterator._host_states['test_host'] = host_state
    play_iterator._host_states['test_host2'] = HostState()

    # Calling get_next_task_for_host() with the test objects
    result = play_iterator.get_next

# Generated at 2022-06-20 14:07:09.365976
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    state = HostState()
    state.run_state = PlayIterator.ITERATING_TASKS
    test_child_state = HostState()
    test_child_state.run_state = PlayIterator.ITERATING_RESCUE
    state.tasks_child_state = test_child_state
    assert PlayIterator(play=None).get_active_state(state) == test_child_state


# Generated at 2022-06-20 14:08:04.148256
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    def get_mock_block_class(mocker):
        mock_block = mocker.MagicMock(name="Mock Block")
        mock_block.__repr__ = mocker.MagicMock(name="mock_block.__repr__", return_value="mock_block")
        mock_block_class = mocker.MagicMock(name="Mock Block Class")
        mock_block_class.return_value = mock_block
        return mock_block_class

    def get_mock_blocks(mocker):
        mock_block1 = mocker.MagicMock(name="Mock Block 1")
        mock_block1.__repr__ = mocker.MagicMock(name="mock_block1.__repr__", return_value="mock_block1")
        mock_block1

# Generated at 2022-06-20 14:08:14.170934
# Unit test for method copy of class HostState
def test_HostState_copy():
    # Testing HostState method copy
    # The method copy creates a copy of the current object's attributes, but only if the object isn't None. 
    # If the method and the object are None, the method returns the object itself.
    new_state = HostState([1,2,3])
    assert new_state.copy() == new_state

    new_state = HostState([1,2,3])
    assert new_state.copy() != None

    new_state = HostState([1,2,3])
    new_state.cur_block = 1
    assert new_state.copy() != None

    new_state = HostState([1,2,3])
    new_state.cur_regular_task = 1
    assert new_state.copy() != None

    new_state = HostState([1,2,3])
   

# Generated at 2022-06-20 14:08:22.445402
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    mock_display = MagicMock()
    mock_display.debug = MagicMock()
    mock_play = MagicMock()

    mock_play.get_variable_manager = MagicMock()
    mock_play.get_variable_manager.return_value.extra_vars = dict()
    mock_play.get_variable_manager.return_value.get_vars = MagicMock()
    mock_play.get_variable_manager.return_value.get_vars.return_value = dict()

    mock_play.get_variable_manager.return_value.set_host_variable = MagicMock()
    mock_task_vars = dict()
    mock_play.get_variable_manager.return_value.set_nonpersistent_facts = MagicMock(return_value=dict())


# Generated at 2022-06-20 14:08:25.150395
# Unit test for method cache_block_tasks of class PlayIterator

# Generated at 2022-06-20 14:08:37.288012
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    p = Play()
    p.hosts = [
        Host('test1'),
        Host('test2'),
    ]
    p.tasks = [
        Task(block=Block(
            tasks=[
                Task(),
                Task(),
            ],
            rescue=[
                Task(),
            ],
            always=[
                Task(),
            ]
        ))
    ]
    i = PlayIterator(p)

    for h in i._play.hosts:
        i.get_next_task_for_host(h)

# Generated at 2022-06-20 14:08:42.581965
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    block_name = "test_block_name"
    test_block = Block(block_name)
    test_host_state = HostState([test_block])
    print(test_host_state)
    assert(test_host_state.__repr__() == "HostState([Block(%s)])" % (block_name))

# Generated at 2022-06-20 14:08:49.832363
# Unit test for method get_active_state of class PlayIterator

# Generated at 2022-06-20 14:09:02.780790
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    state1 = HostState([Block([Task()])])
    state1.cur_block = 0
    state1.cur_regular_task = 0
    state1.cur_rescue_task = 0
    state1.cur_always_task = 0
    state1.run_state = PlayIterator.ITERATING_SETUP
    state1.fail_state = PlayIterator.FAILED_NONE
    state1.pending_setup = False
    state1.tasks_child_state = None
    state1.rescue_child_state = None
    state1.always_child_state = None
    state1.did_rescue = False
    state1.did_start_at_task = False


# Generated at 2022-06-20 14:09:19.316240
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    tests that get_original_task() correctly finds the originial task object
    by iterating to the top of the chain of child state objects, where the
    task is actually saved
    '''
    iterator = PlayIterator()
    host = Host('testhost', groups=['all'])
    iterator.set_play(Play().load({
        'name': 'foobar',
        'hosts': 'testhost',
        'gather_facts': 'no',
        'tasks': [
            { 'action': 'setup', 'foo': 'bar' },
            { 'action': 'shell', 'args': 'id'},
        ]
    }))

    # the setup task both is itself and has no parent
    state = iterator.get_next_task_for_host(host)
    assert state == iterator.get_original

# Generated at 2022-06-20 14:09:28.325997
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    from mock import Mock
    from types import MethodType
    hs = HostState([Mock()])
    hs1 = HostState([Mock()])
    hs.cur_block = 1
    hs1.cur_block = 1
    hs.cur_regular_task = 1
    hs1.cur_regular_task = 1
    hs.cur_rescue_task = 1
    hs1.cur_rescue_task = 1
    hs.cur_always_task = 1
    hs1.cur_always_task = 1
    hs.run_state = 1
    hs1.run_state = 1
    hs.fail_state = 1
    hs1.fail_state = 1
    hs.pending_setup = 1

# Generated at 2022-06-20 14:10:59.796099
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    #from ansible.playbook.play import Play
    import os
    import imp
    import sys
    import json

    #-----------------------
    #The codes below are used to get the test data, which is got from real environment.
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    #from lib.ansible import Ansible
    #from lib.ansible import AnsibleRunner
    #from lib.

# Generated at 2022-06-20 14:11:07.502360
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
  from ansible.playbook.play import Play
  from ansible.playbook.block import Block, BlockList
  from ansible.playbook.task import Task
  from ansible.inventory import Inventory
  from ansible.inventory.host import Host
  from ansible.inventory.group import Group

  # Build play with all blocks (pre_tasks, roles, post_tasks, rescue, always)
  play = Play()
  play.name = "test play"
  play.hosts = "test host"
  play.connection = "local"

  pre_tasks_block = BlockList()
  pre_tasks_block.append(Task(action=dict(module='setup', args=dict())))

# Generated at 2022-06-20 14:11:09.632347
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''
    pass

# Generated at 2022-06-20 14:11:11.874919
# Unit test for constructor of class HostState
def test_HostState():
    # test empty list
    HostState([])
    # test one block list
    HostState([Block()])


# Generated at 2022-06-20 14:11:21.827317
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    iterator = PlayIterator()

    # Test the add_tasks method on the PlayIterator class
    host = FakeHost()
    host.name = 'testhost'
    test_play = Play()
    test_play.name = 'testplay'
    test_play.hosts = [host]

    # Add tasks without a child state
    original_state = HostState(host=host)
    original_state.run_state = PlayIterator.ITERATING_TASKS
    original_state._blocks = [Block(name='block1')]
    original_state.cur_block = 0
    original_state.cur_regular_task = 0
    original_state.cur_rescue_task = 0
    original_state.cur_always_task = 0
    iterator._host_states[host.name] = original_state
    task

# Generated at 2022-06-20 14:11:33.082893
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    import pytest
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.playbook.role as role
    task1 = task.Task()
    task2 = task.Task()
    task3 = task.Task()
    b = block.Block([task1, task2, task3])
    r = role.Role('test')
    r.compile()
    r.block = b
    host = FakeHost()
    host.name = "testhost"
    play_iterator = PlayIterator([])
    play_iterator._play = FakePlay()
    play_iterator._play._iterator = play_iterator
    play_iterator._play.hosts = [host]
    play_iterator._tqm = FakeTqm()
    play_iterator._play.get_v

# Generated at 2022-06-20 14:11:49.271147
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():

    iterator = PlayIterator()
    test_host = Host('testhost')
    test_block = Block()
    test_tasklist = [EmptyTask()]
    test_block.block = test_tasklist
    test_tasklist = [EmptyTask()]
    test_block.rescue = test_tasklist
    test_tasklist = [EmptyTask()]
    test_block.always = test_tasklist

    iterator.get_host_state(test_host).cur_regular_task = 0
    iterator.get_host_state(test_host).cur_rescue_task = 0
    iterator.get_host_state(test_host).cur_always_task = 0
    iterator.get_host_state(test_host)._blocks = [test_block]


# Generated at 2022-06-20 14:12:01.718276
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    PlayIterator - is_failed
    '''
    
    # Tests
    
    iterator = PlayIterator()
    assert iterator.is_failed(None)
    play = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='/usr/bin/false'), register='shell_out'),
        ]
    ))
    
    host = Host(name='localhost')
    iterator = PlayIterator(play)
    iterator.get_next_task_for_host(host)
    iterator.mark_host_failed(host)
    
    assert iterator.is_failed(host)
    assert iterator.is_failed(None)



# Generated at 2022-06-20 14:12:06.230849
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    blocks = [
        Block([]),
        Block([])
    ]
    state = HostState(blocks)
    assert state.get_current_block() == blocks[0]
    state.cur_block = 1
    assert state.get_current_block() == blocks[1]
    blocks.append(Block([]))
    assert state.get_current_block() == blocks[1]



# Generated at 2022-06-20 14:12:07.703345
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    pass


# Generated at 2022-06-20 14:13:39.656149
# Unit test for method copy of class HostState
def test_HostState_copy():
    block_1 = Block([Task()], rescue=[Task()], always=[Task()])
    block_2 = Block([Task()], rescue=[Task()], always=[Task()])
    host_state = HostState([block_1, block_2])
    host_state.cur_block = 0
    host_state.cur_regular_task = 0
    host_state.cur_rescue_task = 0
    host_state.cur_always_task = 0
    host_state.run_state = PlayIterator.ITERATING_SETUP
    host_state.fail_state = PlayIterator.FAILED_NONE
    host_state.pending_setup = False
    host_state.did_rescue = False
    host_state.did_start_at_task = False


# Generated at 2022-06-20 14:13:41.097581
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    print('No test for PlayIterator.get_original_task().')


# Generated at 2022-06-20 14:13:49.480226
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host = C.Host('localhost')
    play = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [dict(action=dict(module='fail', args=dict(msg='test fail')))]
    ), variable_manager=VariableManager(), loader=DataLoader())
    play_context = PlayContext(play=play)

    itr = PlayIterator()
    itr._play = play
    itr._host_states[host.name] = HostState(host=host, blocks=[Block(play.tasks)], play_context=play_context)
    itr.mark_host_failed(host)
    assert itr.is_failed(host)

# Generated at 2022-06-20 14:14:01.763282
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():

    h = Host('localhost')
    p = Play().load(dict(name = "Test Play", hosts = 'all', gather_facts = 'no', tasks = [
                        dict(action=dict(module='shell', args='ls')),
                        dict(action=dict(module='shell', args='pwd')),
                        dict(action=dict(module='shell', args='ps'))
                        ]), variable_manager=VariableManager(), loader=DataLoader())
    tqm = TaskQueueManager(inventory=Inventory(loader=DataLoader(), sources=None), variable_manager=VariableManager(), loader=DataLoader())
    pi = PlayIterator(p, tqm)
    pi.get_hosts_left()

    state = pi.get_active_state(pi.get_host_state(h))


# Generated at 2022-06-20 14:14:08.584491
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    This is testing the PlayIterator._get_next_task_for_host function.
    '''

    # Setup

    # Dict with blocks for each state.
    blocks = {
        'ITERATING_SETUP': [{'setup': []}, {'setup': []}],
        'ITERATING_TASKS': [{'tasks': []}, {'tasks': []}],
        'ITERATING_RESCUE': [{'rescue': []}, {'rescue': []}],
        'ITERATING_ALWAYS': [{'always': []}, {'always': []}],
        'ITERATING_COMPLETE': [{'complete': []}, {'complete': []}],
    }

    # Dict with states for each test case, including which state and block should be returned.
   

# Generated at 2022-06-20 14:14:21.385231
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # This might be the easiest way to test something:
    host = 'host'
    #host = Host(host)
    play = Play()
    play.hosts = [host]
    play.tasks = [{"action": "debug", "task1": "task1"}]
    play.handlers = [
        {"action": "debug", "task1": "task1"},
        {"action": "debug", "task1": "task1"}]
    play.post_tasks = [
        {"action": "debug", "task1": "task1"},
        {"action": "debug", "task1": "task1"}]
    play.roles = [None]
    play.post_tasks = [{"action": "debug", "task1": "task1"}]

# Generated at 2022-06-20 14:14:28.965421
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    """
    Test case for method add_tasks of class PlayIterator
    """
    # create mock objects for testing
    p = MagicMock()
    h = MagicMock()
    t1 = MagicMock()
    t2 = MagicMock()
    b1 = MagicMock()
    b2 = MagicMock()

    # create object under test
    play_iterator = PlayIterator(p)

    # create test data
    h_name = 'mock_host'
    h.name = h_name
    tasks_list = [t1, t2]

    # instantiate mocks required for test_method
    p.get_blocks.return_value = [b1, b2]
    h.get_vars.return_value = {}

    # test method

# Generated at 2022-06-20 14:14:36.921167
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    [ plays | t2 | t3 ]
    '''
    p = Play.load(dict(
        name = "test play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Test Task 1'))),
            dict(action=dict(module='debug', args=dict(msg='Test Task 2'))),
        ]
    ), loader=DummyLoader())
    h = Host(name="example.com")
    p._tqm._initialize_host_queues()
    pi = PlayIterator(p, p._tqm)
    (state, task) = pi.get_next_task_for_host(h)


# Generated at 2022-06-20 14:14:41.184285
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks = [Block(task_include='main.yml', role='foo')]
    s = HostState(blocks)
    assert s == HostState(blocks)
    s2 = HostState(blocks)
    s2.cur_block = 1
    assert s != HostState(blocks)
    s2 = HostState(blocks)
    s2.cur_regular_task = 1
    assert s != HostState(blocks)
    s2 = HostState(blocks)
    s2.cur_rescue_task = 1
    assert s != HostState(blocks)
    s2 = HostState(blocks)
    s2.cur_always_task = 1
    assert s != HostState(blocks)
    s2 = HostState(blocks)
    s2.run_state = PlayIterator.ITERATING_TASKS
    assert s

# Generated at 2022-06-20 14:14:43.690409
# Unit test for constructor of class HostState
def test_HostState():
    state = HostState([])
    #  call the constructor of class HostState
    assert state is not None
