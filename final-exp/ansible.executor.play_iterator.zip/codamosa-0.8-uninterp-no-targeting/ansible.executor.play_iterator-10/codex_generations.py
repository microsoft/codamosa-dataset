

# Generated at 2022-06-20 14:05:30.540337
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    pass


# Generated at 2022-06-20 14:05:38.936967
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # create an empty HostState
    hs = HostState()
    # add a block containing one task to it
    hs._blocks.append(Block(block=[Task()]))

    # get a new PlayIterator
    pi = PlayIterator()

    # add one task to the HostState
    pi.add_tasks(Mock(), [Task()])
    # assert that the HostState had it's task list multiplied by 2
    assert len(hs._blocks[0].block) == 2
    # add two tasks to the HostState
    pi.add_tasks(Mock(), [Task(), Task()])
    # assert that the HostState had it's task list multiplied by 3
    assert len(hs._blocks[0].block) == 6

    # set the current task to the first task in the HostState's task list
    hs.cur_

# Generated at 2022-06-20 14:05:43.199632
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    my_block1 = Block()
    my_block2 = Block()
    my_block3 = Block()
    my_task1 = Task()
    my_task1.at_path = '{{ playbook_dir }}/roles/foo/tasks/bar.yml:5'
    my_task2 = Task()
    my_task3 = Task()
    my_block1.block = [my_task1]
    my_block2.block = [my_task2]
    my_block3.block = [my_task3]
    blocks = [my_block1, my_block2, my_block3]
    run_state = PlayIterator.ITERATING_SETUP
    fail_state = PlayIterator.FAILED_NONE
    pending_setup = False
    tasks_child_state = None
   

# Generated at 2022-06-20 14:05:44.848126
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
   assert True

# Generated at 2022-06-20 14:05:55.240340
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    display.debug("TEST: test_HostState___str__()")
    # Initialize state variable
    state = HostState(None)
    state.cur_block = 0
    state.cur_regular_task = 1
    state.cur_rescue_task = 2
    state.cur_always_task = 3
    state.run_state = 0
    state.fail_state = 15
    state.pending_setup = False
    state.tasks_child_state = None
    state.rescue_child_state = None
    state.always_child_state = None
    state.did_rescue = False
    state.did_start_at_task = False
    #print("state: "+str(state))
    display.debug("state: "+str(state))

    # Expected __str__ method output of state

# Generated at 2022-06-20 14:05:58.098565
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    host_state = HostState()
    host_state.__repr__()


# Generated at 2022-06-20 14:06:02.260677
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
  '''
  This is a stub for a unit test
  Create an instance of PlayIterator
  Call get_original_task with an instance of InventoryHost and an instance of Task
  '''
  pass


# Generated at 2022-06-20 14:06:14.336565
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    cur_state = HostState(blocks=test_blocks_empty)
    cur_state.run_state = PlayIterator.ITERATING_TASKS
    assert not PlayIterator.is_any_block_rescuing(cur_state)

    assert PlayIterator.is_any_block_rescuing(cur_state.tasks_child_state)

    cur_state.run_state = PlayIterator.ITERATING_RESCUE
    assert PlayIterator.is_any_block_rescuing(cur_state)

    cur_state.run_state = PlayIterator.ITERATING_ALWAYS
    assert not PlayIterator.is_any_block_rescuing(cur_state)


# Generated at 2022-06-20 14:06:27.422407
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    b1 = Block(
            role=None,
            task_include=None,
            always_include=None,
            rescue_include=None,
            block=None,
            loop=None,
            loop_with_items=None,
            when=None,
            vars=dict(),
            tags=list(),
            fail_when=False,
            any_errors_fatal=False,
            become=False,
            become_method=None,
            become_user=None,
            connection=None,
            remote_user=None,
            run_once=False,
            no_log=False,
            until=False,
            retries=0,
            delegate_to=None,
            run_tree=False,
    )


# Generated at 2022-06-20 14:06:32.359189
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # FIXME: implement python unit test for method PlayIterator.get_host_state ???
    pass


# Generated at 2022-06-20 14:07:02.381949
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    my_blocks = [Block(None, None, None, None, None, None)]
    my_HostState = HostState(my_blocks)
    assert my_HostState.get_current_block() == my_blocks[0]


# Generated at 2022-06-20 14:07:07.265068
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    import play, action, task, block, loader
    from action import Action
    from task import Task
    from block import Block
    from play import Play
    from loader import Loader
    loader_cls = DictDataLoader
    variable_manager_cls = VariableManager
    inventory_cls = Inventory
    pass


# Generated at 2022-06-20 14:07:15.522677
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    it = PlayIterator()

    # Setup a HostState we can call is_any_block_rescuing against
    it._host_states = dict()
    block = Block()
    block.block = [dict(action=dict(module='test')) for _ in range(4)]
    block.rescue = [dict(action=dict(module='test')) for _ in range(2)]
    block.always = [dict(action=dict(module='test')) for _ in range(2)]
    state = HostState(blocks=[block])
    state.fail_state = it.FAILED_NONE
    it._host_states['test'] = state

    # Make sure that is_any_block_rescuing returns False if the current run_state is
    # run_state is anything other than ITERATING_RESCUE


# Generated at 2022-06-20 14:07:19.596033
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    iter = PlayIterator()
    iter.mark_host_failed('test')
    assert iter.is_failed('test') == True
    assert iter.is_failed('test_unknown') == False


# Generated at 2022-06-20 14:07:31.006588
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():

    fake_play = Mock()
    fake_play._get_next_task_lock = threading.RLock()
    fake_play.hostvars = dict()
    fake_play.handlers = [
        Mock(**{
            'name': 'my handler',
            'run.return_value': 0
        })
    ]
    fake_play.notified_handlers = list()
    fake_play.notified_handlers_results = dict()
    fake_play.get_handler.side_effect = lambda x: fake_play.handlers[0]
    fake_play.notify.side_effect = lambda x, y: fake_play.notified_handlers.append(x)

    fake_host = Mock()
    fake_host.get_name.return_value = 'fake_host'

    # test

# Generated at 2022-06-20 14:07:43.313544
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Test module for PlayIterator class
    This utility module is used for to test method mark_host_failed() of class PlayIterator
    '''

    # Create an instance of class PlayIterator
    my_play_iterator = PlayIterator()

    # Make an instance of Play()
    my_play = Play()

    # Make an instance of InMemoryInventory()
    my_InMemoryInventory = InMemoryInventory()

    # Create a host
    my_host = Host()

    # Get the host name of the host
    my_hostname = my_host.get_name()

    # Get the HostState
    my_host_state = my_play_iterator.get_host_state(my_host)

    # Mark the host as failed
    my_play_iterator.mark_host_failed(my_host)

    #

# Generated at 2022-06-20 14:07:53.716984
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    module_loader = 'ansible.plugins.loader.action_loader'
    my_loader = 'daiquiri.loader.action_loader'
    if 'ansible.plugins.loader.action_loader' in sys.modules:
        sys.modules[my_loader] = sys.modules[module_loader]

    play = Play.load(dict(
        name = "foobar",
        hosts = 'hostname',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='ok'))),
        ]
    ), variable_manager=VariableManager())
    play._included_files = dict()
    play._role_names = dict()
    play._roles = dict()
    iterator = PlayIterator(play)

    assert play.hosts == 'hostname'

# Generated at 2022-06-20 14:07:58.045402
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # Setup
    play_iterator = PlayIterator()
    host_name = 'test_host'
    host_state = HostState(blocks=[])
    play_iterator._host_states = { host_name: host_state }

    # Exercise
    actual_host_state = play_iterator.get_host_state(Host(name=host_name))

    # Verify
    assert actual_host_state == host_state




# Generated at 2022-06-20 14:08:01.756361
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Unit test for method get_original_task of class PlayIterator
    '''
    # TODO: currently this is a noop because we've changed the way we do caching
    pass

# Generated at 2022-06-20 14:08:10.510401
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''test_PlayIterator_get_host_state()'''

    # Local objects
    inventory = Inventory(loader=None, variable_manager=VariableManager(), host_list=[])
    play = Play().load({}, loader=None, variable_manager=VariableManager())

    # Remote objects
    my_host = Host(name="my_host")

    # Test code
    inventory.add_host(my_host)
    play_iterator = PlayIterator(inventory, play)
    result = play_iterator.get_host_state(my_host)
    print("result: %s" % result)
    assert isinstance(result, HostState)



# Generated at 2022-06-20 14:08:46.606188
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    from mock import patch, Mock, sentinel, create_autospec
    mock_play = Mock()
    mock_play.get_iterator.return_value = sentinel.iterator
    mock_play_context = Mock()
    mock_play_context._play_context.reset_connection.return_value = None
    mock_host_state = Mock()
    mock_host_state.get_active_state.return_value = sentinel.state
    mock_host = Mock()
    mock_host.name = 'mock_host_name'
    mock_host.get_vars.return_value = {}

    # Verify that if the host is not in self._host_states and that the reset_connection method of PlayContext is called

# Generated at 2022-06-20 14:08:59.986555
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [('setup', [('ansible1', 'ansible1')]), ('tasks', [('ansible2', 'ansible2')])]
    hs = HostState(blocks)
    hs.cur_block = 1
    hs.cur_regular_task = 1
    hs.cur_rescue_task = 2
    hs.cur_always_task = 3
    hs.run_state = 1
    hs.fail_state = 2
    hs.pending_setup = True
    hs.did_rescue = True
    hs.did_start_at_task = True
    ansible2 = ('ansible2', 'ansible2')
    hs.tasks_child_state = PlayIterator.HostState(hs.get_current_block()).tasks_child_state


# Generated at 2022-06-20 14:09:01.322071
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    pass # TODO

# Generated at 2022-06-20 14:09:09.207014
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # 8 tests, 13 branches, 5 statements
    block = Block(None, None)
    state = HostState(blocks=[block])
    state.run_state = PlayIterator.ITERATING_TASKS

    # initial conditions
    assert state.run_state != PlayIterator.ITERATING_RESCUE
    assert state.tasks_child_state is None
    assert PlayIterator.is_any_block_rescuing(None, state) == False
    
    # 0 - set tasks_child_state, then check for is_any_block_rescuing
    block2 = Block(None, None)
    state.tasks_child_state = HostState(blocks=[block2])
    assert state.tasks_child_state is not None

# Generated at 2022-06-20 14:09:23.251416
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play_context = PlayContextAdapter(play_context=play_context_from_vault_secrets_lookup())
    play = Play().load("test/unit/common/test_play_iterator.yml", variable_manager=VariableManagerAdapter(), loader=DictDataLoaderAdapter({}))
    play_iterator = PlayIterator()
    play_iterator.load_play(play, play_context.variable_manager)
    result = play_iterator.get_next_task_for_host(host=Host(name=u'foo'), peek=False)
    assert result.action == u'alpha', result
    assert result._role is play.get_role('foo'), result._role
    assert result.task_vars == dict(foo=u'bar', alpha=u'beta'), result.task_vars
    result = play_iterator.get

# Generated at 2022-06-20 14:09:33.502561
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    HostState_block = ["block0","block1","block2","block3"]
    # test
    test_object = HostState(HostState_block)
    result = test_object.get_current_block()
    # assert the result is true or false
    assert result == "block0"
test_HostState_get_current_block()




# Generated at 2022-06-20 14:09:34.511809
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = []
    hostState = HostState(blocks)
    assert hostState.__repr__() == "HostState(%r)" % blocks

# Generated at 2022-06-20 14:09:36.925560
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    block1 = Block([Task()])
    block2 = Block([Task()])
    list_block = [block1,block2]
    host_state = HostState(list_block)
    host_state.run_state = 0
    host_state.fail_state = 0
    host_state.pending_setup = False
    assert str(host_state).startswith("HOST STATE")


# Generated at 2022-06-20 14:09:44.879874
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play = Play().load(dict(
        name = "test play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls fjdksla')),
            dict(action=dict(module='shell', args='ls fjdksla')),
            dict(action=dict(module='shell', args='ls fjdksla'), when='dne'),
        ]
    ), loader=DummyLoader())

    iterator = PlayIterator()
    iterator._play = play

    play_context = dict(
        basedir = '/home/foo'
    )

    iterator._play_context = play_context

    hosts = sorted({'host1', 'host2'})

    assert iterator.get_failed_hosts() == dict()

# Generated at 2022-06-20 14:09:50.193064
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Create a bare-minimum fake inventory to pass to PlayIterator
    # (PlayContext is created inside the class, so we don't need to create that)
    inventory = Mock()
    inventory.get_host.return_value = None

    # Create fake play and play context
    play = Mock()
    play.hosts = ['spam']
    play.play_hosts = {'spam' : 'spam'}
    play.ROOT_PATH = '.'

    # Create play iterator
    pi = PlayIterator(inventory=inventory, play=play)

    # Call get_original_task
    (original_task, original_block) = pi.get_original_task(host=None, task=None)

    # Assertions
    assert (original_task is None)
    assert (original_block is None)

# Unit

# Generated at 2022-06-20 14:10:16.468361
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    pass

# Generated at 2022-06-20 14:10:26.727403
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    def create_state(current_state):
        state = HostState(blocks=[])
        state.run_state = current_state
        return state

    state = create_state(PlayIterator.ITERATING_SETUP)
    assert state == PlayIterator.get_active_state(state)

    state = create_state(PlayIterator.ITERATING_COMPLETE)
    assert state == PlayIterator.get_active_state(state)

    state = create_state(PlayIterator.ITERATING_TASKS)
    state.tasks_child_state = create_state(PlayIterator.ITERATING_RESCUE)
    state.tasks_child_state.rescue_child_state = create_state(PlayIterator.ITERATING_ALWAYS)
    state.tasks_child_state.rescue_child_state.always

# Generated at 2022-06-20 14:10:39.322775
# Unit test for constructor of class HostState
def test_HostState():
    testBlocks = []
    testBlocks.append(Block([Task()], rescue=[Task()], always=[Task()]))
    testBlocks.append(Block([Task()], rescue=[Task()], always=[Task()]))
    testBlocks.append(Block([Task()], rescue=[Task()], always=[Task()]))
    newHostState = HostState(testBlocks)
    assert(newHostState._blocks == testBlocks)
    assert(newHostState.cur_block == 0)
    assert(newHostState.cur_regular_task == 0)
    assert(newHostState.cur_rescue_task == 0)
    assert(newHostState.cur_always_task == 0)
    assert(newHostState.run_state == PlayIterator.ITERATING_SETUP)

# Generated at 2022-06-20 14:10:43.931177
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    print('in test_PlayIterator_is_any_block_rescuing')


# Generated at 2022-06-20 14:10:57.223459
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    mock_get_connection = MagicMock(return_value=Connection('ssh', host=MagicMock()))
    plugin_loader = MagicMock()
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    inventory._hosts_cache = {
        u'host_1': {'vars': {u'ansible_host': u'localhost'}},
        u'host_2': {'vars': {u'ansible_host': u'localhost'}}
    }
    inventory.detect_range = MagicMock(return_value=[Host(name=u'host_1')])
    inventory.get_host = MagicMock(return_value=inventory._hosts_cache[u'host_1'])



# Generated at 2022-06-20 14:11:05.824693
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    import pytest

    test_play = Play()

# Generated at 2022-06-20 14:11:14.819303
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # Test method get_next_task_for_host() of class PlayIterator
    # Create a simple block consisting of a single task
    block = Block('test block', [Task('test task')])
    # Create a simple play that just contains the block
    play = Play('test play', [], [], [block], [])
    # Create a Host object, which we will pass to the method
    host = Host('test_host')
    # Create an iterator and call the method with our test play, host and block
    pi = PlayIterator(play)
    (state, task) = pi.get_next_task_for_host(host, block)

    # Test assertions
    assert isinstance(state, HostState)
    assert task is not None


# Generated at 2022-06-20 14:11:30.768670
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = '''
- block:
    - block:
        - setup:
        - task:
            - task:
    - rescue:
        - task:
    - always:
        - task:
        - task:
    - block:
        - task:
'''
    hs = HostState(blocks)
    hs.cur_block = 2
    hs.cur_regular_task = 2
    hs.cur_rescue_task = 2
    hs.cur_always_task = 2
    hs.run_state = 3
    hs.fail_state = 2
    hs.pending_setup = False
    hs.tasks_child_state = 2
    hs.rescue_child_state = 2
    hs.always_child_state = 2
    hs.did

# Generated at 2022-06-20 14:11:37.269607
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # set up
    play = Play()
    play._removed_hosts = ['a', 'b']

    # create a new PlayIterator object
    pi = PlayIterator(play)
    pi._host_states = dict(a=HostState(), b=HostState(), c=HostState())

    # check the is_failed method for existing host states
    for host in ['a', 'b']:
        assert pi.is_failed(host) == True

    # check the is_failed method for non-existing host states
    assert pi.is_failed('c') == False


# Generated at 2022-06-20 14:11:41.941915
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    iterator = PlayIterator()
    iterator._host_states = {
        'a':None,
        'b':None,
        }
    assert iterator.get_failed_hosts() == {
        'a':True,
        'b':True,
        }


# Generated at 2022-06-20 14:12:46.027841
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    play = dict(
        name = "a",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="shell", args="ls")),
            dict(action=dict(module="shell", args="ls")),
            dict(action=dict(module="shell", args="ls")),
            dict(action=dict(module="shell", args="ls")),
            dict(action=dict(module="shell", args="ls")),
        ]
    )
    hosts = [
        'foo',
        'bar',
        'baz',
    ]
    tqm = TaskQueueManager(None, hosts, None, None)
    p = Play().load(play, tqm.loader)
    hosts = [Host(hostname=host) for host in hosts]

# Generated at 2022-06-20 14:12:59.876431
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    print("UNIT TEST: test_PlayIterator_is_failed")
    # Test with empty tasks
    pi = PlayIterator()
    # Test with empty tasks
    state = HostState(tasks=[])
    print("tasks=[], state={}".format(state))
    assert pi.is_failed(None)==False
    print("\tcorrectly returned False")
    # Test with single task
    state = HostState(tasks=[{'action': 'test'}])
    print("tasks=[{'action': 'test'}], state={}".format(state))
    assert pi.is_failed(None)==False
    print("\tcorrectly returned False")
    # Test with multiple tasks

# Generated at 2022-06-20 14:13:06.925587
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play = Play.load(dict(
        name = "foobar",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
          ]
        ), variable_manager=VariableManager(), loader=None)
    host = Host(name="foo")
    host.set_variable('ansible_ssh_user', 'bob')
    play_iter = PlayIterator(play, variable_manager=VariableManager(), all_vars={})
    host_state = HostState(host=host)
    host_state.play = play
    play_iter.add_host(host_state)

   

# Generated at 2022-06-20 14:13:18.357615
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play_iterator = PlayIterator(play=dict())
    play_iterator._host_states = {host: HostState(blocks=[Block(task_list=[task]) for task in task_list]) for host, task_list in {'foo': [], 'bar': [FakeTask('b'), FakeTask('c')], 'baz': []}.items()}
    # Test empty task_list
    assert play_iterator.get_original_task(host=FakeHost('foo'), task=FakeTask('a')) == (None, None)
    # Test task_list that contains task
    assert play_iterator.get_original_task(host=FakeHost('bar'), task=FakeTask('c')) == (1, 'bar')


# Generated at 2022-06-20 14:13:25.811941
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [
            Block(
                role=None,
                task_include=None,
                always_include=None,
                rescue_include=None,
                blocks=[Block(
                    role=None,
                    task_include=None,
                    always_include=None,
                    rescue_include=None,
                    blocks=[],
                    tasks=[Task()],
                    rescue=[Task()],
                    always=[Task()],
                    loop=None,
                    loop_args=[]
                    )]
                )]

# Generated at 2022-06-20 14:13:33.490354
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    class BlockTest:
        def __init__(self,block_name):
            self._block_name = block_name

        def __repr__(self):
            return "BlockTest(%r)" % self._block_name
    block1 = BlockTest('block1')
    block2 = BlockTest('block2')
    hs = HostState([block1, block2])
    assert isinstance(hs.__str__(),str)

# Generated at 2022-06-20 14:13:44.876737
# Unit test for method copy of class HostState
def test_HostState_copy():

    # initialise 2 blocks
    blocks = []
    task1 = Task()
    task1.name = "task_one"
    task2 = Task()
    task2.name = "task_two"
    task3 = Task()
    task3.name = "task_three"
    task4 = Task()
    task4.name = "task_four"
    block1 = Block( [task1, task2] )
    blocks.append(block1)
    block2 = Block( [task3, task4] )
    blocks.append(block2)

    # initialise HostState object
    hs = HostState(blocks)
    hs.cur_block = 1
    hs.cur_regular_task = 1
    hs.cur_rescue_task = 0

# Generated at 2022-06-20 14:13:57.052888
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    # Setup mock objects
    hostname = 'host1'
    playbook_basedir = '/tmp/'
    # playbook_filename = 'site.yml'
    loader = 'loader' 
    variable_manager = 'variable_manager' 
    block = Block()

    # Create HostState object
    hoststate = HostState(
        [block],
        hostname,
        playbook_basedir,
        #playbook_filename,
        loader,
        variable_manager,
        run_once=False
    )

    # Call method __repr__ and verify result
    assert hoststate.__repr__() == ("HostState('host1', [%s], '/tmp/', 'loader', 'variable_manager', False)" % block.__repr__())



# Generated at 2022-06-20 14:14:06.302799
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    play = Play()
    
    play.hosts = ['hostA']
    play.name = 'TestPlay'
    play.tasks = [{'action': 'set_fact', 'name': 'myfact', 'value': 'myvalue'}]
    
    play_iterator = PlayIterator(play)
    
    play_iterator.init_tasks(play)
    play_iterator.get_next_task_for_host('hostA')
    
    play_iterator.add_tasks('hostA', [{'action': 'set_fact', 'name': 'myfact2', 'value': 'myvalue2'}])
    
    state = play_iterator.get_host_state('hostA')

# Generated at 2022-06-20 14:14:17.779702
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    play = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='test')))
        ]
    ), loader=DummyLoader())

    iterator = PlayIterator(play)

    # test that iteration stops when a block is rescued
    host = Host('example')
    iterator.get_next_task_for_host(host, peek=True)
    iterator.mark_host_failed(host)
    assert iterator.is_any_block_rescuing(iterator.get_host_state(host))

