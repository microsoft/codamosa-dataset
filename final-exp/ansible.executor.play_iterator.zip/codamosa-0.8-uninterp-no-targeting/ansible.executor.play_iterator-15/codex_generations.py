

# Generated at 2022-06-20 14:05:36.631097
# Unit test for method get_current_block of class HostState

# Generated at 2022-06-20 14:05:41.764378
# Unit test for constructor of class HostState
def test_HostState():
    b1 = Block()
    t1 = Task()
    t1.block = b1
    t2 = Task()
    t2.block = b1
    b1.block()
    b1.append(t1)
    b1.append(t2)

    b2 = Block()
    b2.block()
    t3 = Task()
    t3.block = b2
    b2.append(t3)

    b3 = Block()
    b3.rescue()
    t4 = Task()
    t4.block = b3
    b3.append(t4)

    b4 = Block()
    b4.always()
    t5 = Task()
    t5.block = b4
    b4.append(t5)

    b1.rescue(b3)

   

# Generated at 2022-06-20 14:05:53.702758
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    host = Host('testhost')
    host_state = HostState(blocks=[])
    host_state.run_state = 1
    host_state.cur_block = 1
    host_state.tasks_child_state = HostState(blocks=[])
    host_state.tasks_child_state.run_state = 1
    host_state.tasks_child_state.cur_block = 2
    host_state.tasks_child_state.tasks_child_state = None
    
    # since we're only testing the mark_host_failed method, mock out the rest of the class
    play_iterator = PlayIterator({}, None, None)
    play_iterator._host_states = {'testhost': host_state}
    play_iterator._play = None
    play_iterator._iterator._play = None
    


# Generated at 2022-06-20 14:05:55.767762
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    state = HostState([])
    print(state)


# Generated at 2022-06-20 14:06:01.878239
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    p = Play().load(dict(
        name = 'test play',
        hosts = 'localhost',
        gather_facts = 'no',
        vars = dict(foo='bar'),
        tasks = [
            dict(action=dict(module='command', args='echo {{ foo }}')),
            dict(action=dict(module='command', args='false')),
        ]
    ), variable_manager=VariableManager())
    tqm = TaskQueueManager(play=p)
    pit = PlayIterator(p, tqm.host_list, tqm)

    (t,l) = pit.get_original_task(tqm.host_list[0], p.tasks[1])

    assert l == -1
    assert t == p.tasks[1]


# Generated at 2022-06-20 14:06:14.231954
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    """
    :return: ``True`` if the module tests ran successfully.
    """

    from pprint import pprint
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from unit_tests.test_data_structures import TestDataStructures

    results = TestDataStructures()

    for host in results._hosts_results:
        results.add_task_result(host, Task(), dict(failed=True))


# Generated at 2022-06-20 14:06:20.913873
# Unit test for method add_tasks of class PlayIterator

# Generated at 2022-06-20 14:06:32.033641
# Unit test for constructor of class PlayIterator

# Generated at 2022-06-20 14:06:45.455935
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play()
    play.get_loader().set_basedir(testdir)

    # the blocks are in fact loaded in the order they are defined, so we can
    # be sure of this order
    play.load(playbook_name, variable_manager=play.get_variable_manager(), loader=play.get_loader())

    # run the play
    iterator = PlayIterator(play)
    host = play.get_hosts()[0]

    state = iterator.get_next_task_for_host(host)
    assert not iterator.is_failed(host)

    # this is the first task, so we should be here
    assert state.run_state == iterator.ITERATING_TASKS
    assert state._cur_block == 0
    assert state._cur_regular_task == 0
    assert not state._did

# Generated at 2022-06-20 14:06:49.733419
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=True, implicit=False, block=None)]
    state = HostState(blocks)
    copy = state.copy()
    assert state == copy



# Generated at 2022-06-20 14:07:14.760708
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    assert True

# Generated at 2022-06-20 14:07:28.318430
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    blocks_1 = []
    blocks_1.append(Block([Task().load({'action': {'__ansible_module__': 'command', '__ansible_arguments__': {'_raw_params': 'echo hi'}}})],
                          'all', []))
    blocks_1.append(Block([Task().load({'action': {'__ansible_module__': 'command', '__ansible_arguments__': {'_raw_params': 'echo hi'}}})],
                          'all', []))
    obj1 = HostState(blocks_1)
    obj1.cur_block = 0
    obj1.cur_regular_task = 0
    obj1.cur_rescue_task = 0
   

# Generated at 2022-06-20 14:07:30.120090
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    iterator = PlayIterator()
    assert iterator.get_host_state() is None
    
    

# Generated at 2022-06-20 14:07:42.893595
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # success starts with True, will set to false if any tests fail
    success = True
    print("\nTESTING PLAYITERATOR:")

    # create an example inventory and play
    my_inventory = Inventory()
    my_play = Play()
    
    # test with no hosts and no tasks
    print("\tTesting empty inventory and play list")

# Generated at 2022-06-20 14:07:54.641513
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    host = MagicMock()
    host_state = HostState(blocks=[MagicMock()])
    host_state.run_state = PlayIterator.ITERATING_TASKS
    host_state.tasks_child_state = HostState(blocks=[MagicMock()])
    host_state.tasks_child_state.run_state = PlayIterator.ITERATING_RESCUE
    host_state.tasks_child_state.rescue_child_state = HostState(blocks=[MagicMock()])
    host_state.tasks_child_state.rescue_child_state.run_state = PlayIterator.ITERATING_ALWAYS
    host_state.tasks_child_state.rescue_child_state.always_child_state = HostState(blocks=[MagicMock()])
    host_state.t

# Generated at 2022-06-20 14:08:00.494117
# Unit test for method copy of class HostState
def test_HostState_copy():
    import collections
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task = Task()
    block = Block()
    block.block = [task]

    h = HostState([block])
    h.cur_block = 15
    h.cur_regular_task = 30
    h.cur_rescue_task = 45
    h.cur_always_task = 60
    h.run_state = 7
    h.fail_state = 11
    h.pending_setup = True
    h.tasks_child_state = collections.OrderedDict(a=1, b=2, c=3)
    h.rescue_child_state = collections.OrderedDict(d=4, e=5, f=6)
    h.always_child_state = collections

# Generated at 2022-06-20 14:08:08.900805
# Unit test for method __str__ of class HostState
def test_HostState___str__():
	block = Block([Task.load(dict(action='debug', args=dict(var='var')))])
	a = HostState([block])
	assert str(a) == ("HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, "
		"pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), "
		"did rescue? False, did start at task? False")

# Generated at 2022-06-20 14:08:22.907386
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play = Play().load('test/playbooks/iterator_get_original_task.yml')
    host_state_dict = {}
    play_iterator = PlayIterator(play)
    host_name = 'localhost'
    host = play_iterator.get_host_state(host_name)
    host.populate_task_list()
    current_task1 = play_iterator.get_next_task_for_host(host)
    current_task2 = play_iterator.get_next_task_for_host(host)
    current_task3 = play_iterator.get_next_task_for_host(host)
    next_task = play_iterator.get_next_task_for_host(host)
    first_listed_task = play_iterator.get_original_task(host, next_task)

# Generated at 2022-06-20 14:08:27.552435
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    Test for method get_failed_hosts of class PlayIterator
    '''
    # Initializing objects
    play_iterator = PlayIterator()
    # Now we test if the get_failed_hosts method returns a dictionary of failed hosts
    assert_is_instance(play_iterator.get_failed_hosts(), dict)


# Generated at 2022-06-20 14:08:41.121753
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    p = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=variable_manager, loader=loader)

    assert PlayIterator(p).is_failed(p.get_hosts()[0]) is False
    p.get_tasks()[0].action._fail_task = True
    assert PlayIterator(p).is_failed(p.get_hosts()[0]) is True
test_PlayIterator

# Generated at 2022-06-20 14:09:19.315774
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='foo is {{foo}}')))
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    tqm = TaskQueueManager(
        inventory=play.inventory,
        variable_manager=play.variable_manager,
        loader=play.loader,
        options=Options(),
        passwords=dict(conn_pass=None, become_pass=None),
    )

    h = play.inventory.get_host("localhost")
    assert h is not None
    assert not tqm._failed_hosts

    pi = PlayIterator(play)
    assert not pi.is_failed

# Generated at 2022-06-20 14:09:22.872572
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    print(HostState([Block()]))
    print(HostState([Block(), Block()]))



# Generated at 2022-06-20 14:09:39.747774
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play().load({
        'name': 'test play',
        'hosts': ['somehost'],
        'gather_facts': 'no',
        'tasks': [{'debug': 'foo'}],
        'roles': [{'role': 'somerole'}]
    }, variable_manager=VariableManager())

    play_iterator = PlayIterator()

    try:
        play_iterator._check_failed_state('invalid state')
        assert False, "PlayIterator._check_failed_state did not reject invalid state"
    except:
        pass

    try:
        play_iterator.mark_host_failed('invalid host')
        assert False, "PlayIterator.mark_host_failed did not reject invalid host"
    except:
        pass


# Generated at 2022-06-20 14:09:45.195755
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    block = Block(None, [])
    host_state = HostState([block])
    result = str(host_state)
    print(result)


# Generated at 2022-06-20 14:09:57.936829
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # Setup
    host = MagicMock()
    block_a = MagicMock()
    block_a.name = "test_block_a"
    block_b = MagicMock()
    block_b.name = "test_block_b"
    block_b.rescue = []
    block_c = MagicMock()
    block_c.name = "test_block_c"
    block_c.rescue = []
    block_d = MagicMock()
    block_d.name = "test_block_d"
    block_e = MagicMock()
    block_e.name = "test_block_e"
    block_e.rescue = []

    # Test 1: first block is in rescue mode, no children
    block_a.rescue = [MagicMock()]
    state

# Generated at 2022-06-20 14:10:03.063872
# Unit test for method copy of class HostState
def test_HostState_copy():
    block_1 = Block()
    block_2 = Block()
    state_1 = HostState([block_1, block_2])
    state_2 = state_1.copy()
    assert state_1 == state_2
    state_1.cur_regular_task = 1
    assert state_1 != state_2
    state_3 = state_2.copy()
    state_3.tasks_child_state = PlayIterator()
    assert state_2 != state_3



# Generated at 2022-06-20 14:10:16.964998
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    host = Host('localhost')
    ti = Task()
    ti._role = None
    ti._play = Play().load(caller_file=__file__, caller_dir=os.getcwd(), task_loader=NullLoader())
    ti._role_name = None
    ti._block = Block(parent_block=None, role=None, task_include=None)
    ti._parent = None
    ti._loop = None
    ti._loop_args = None
    ti._loop_for = None
    ti._loop_with = None
    ti._when = None
    ti._changed_when = None
    ti._always_run = False
    ti._notify = []
    ti._use_role = None
    ti._include_role = []
    ti._role_params = {}

# Generated at 2022-06-20 14:10:31.999574
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    host_state = HostState([])
    host_state.cur_block = 0
    host_state.cur_regular_task = 0
    host_state.cur_rescue_task = 0
    host_state.cur_always_task = 0
    host_state.run_state = PlayIterator.ITERATING_SETUP
    host_state.fail_state = PlayIterator.FAILED_NONE
    host_state.pending_setup = False
    host_state.tasks_child_state = None
    host_state.rescue_child_state = None
    host_state.always_child_state = None
    host_state.did_rescue = False
    host_state.did_start_at_task = False    
    
    print(host_state)


# Generated at 2022-06-20 14:10:44.792556
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # Test that get_active_state finds the active state in a complicated hierarchy
    blocks = [
        Block(
            u'child block 1',
            [
                Task(name='task 1')
            ]
        ),
        Block(
            u'child block 2',
            [
                Task(name='task 2')
            ]
        )
    ]
    outer_blocks = [
        Block(
            u'outer block',
            [
                Task(name='setup task'),
                Block(
                    u'outer child block',
                    [
                        Task(name='setup task 2')
                    ],
                    rescue=blocks,
                    always=blocks
                ),
                Task(name='teardown task')
            ],
            rescue=blocks,
            always=blocks
        )
    ]
    p = Playbook()

# Generated at 2022-06-20 14:10:57.892435
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks = [Block([]), Block([])]
    state = HostState(blocks)
    assert state.__eq__(state)
    assert not state.__eq__(None)
    assert not state.__eq__('')

    new_state = HostState(blocks)
    assert state.__eq__(new_state)

    new_state = HostState(blocks)
    new_state._blocks = [Block([])]
    assert not state.__eq__(new_state)

    new_state = HostState(blocks)
    new_state.cur_block = -1
    assert not state.__eq__(new_state)

    new_state = HostState(blocks)
    new_state.cur_regular_task = -1
    assert not state.__eq__(new_state)

    new_state

# Generated at 2022-06-20 14:11:21.146387
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    assert False, "No test written for PlayIterator.cache_block_tasks"

# Generated at 2022-06-20 14:11:32.616353
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    PlayIterator.mark_host_failed() Manages a task's state for a given host
    '''
    # Initializing the class
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    iterator = PlayIterator(play, play._tqm)
    host = 'testHost'
    assert isinstance(iterator, PlayIterator)

    # Testing with a task and a host as

# Generated at 2022-06-20 14:11:36.845010
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    Unit test for method get_host_state of class PlayIterator
    '''
    host = FakeHost('test_host')
    host.get_vars = MagicMock(return_value={})
    play = FakePlay()
    play_iterator = PlayIterator(play)
    assert play_iterator.get_host_state(host) == None

# Generated at 2022-06-20 14:11:37.999538
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pass

# Generated at 2022-06-20 14:11:49.953687
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    basedir = tempfile.mkdtemp()

# Generated at 2022-06-20 14:12:00.028638
# Unit test for method copy of class HostState
def test_HostState_copy():
    d = HostState(['block1', 'block2', 'block3'])

    d.cur_block = 2
    d.cur_regular_task = 1
    d.cur_rescue_task = 4
    d.cur_always_task = 3
    d.run_state = 3
    d.fail_state = 5
    d.pending_setup = True
    d.did_rescue = True
    d.did_start_at_task = True

    e = d.copy()
    assert d == e
# end of unit test for method copy of class HostState


# Generated at 2022-06-20 14:12:08.162089
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Unit test of PlayIterator.get_original_task
    '''
    # FIXME: this works mostly, but doesn't do any tests covering use of include tasks, or other complex cases
    # (such as the insert_before/after action plugin params)
    play = Play().load(dict(name="test_play_get_original_task", hosts='localhost', gather_facts='no', tasks=[dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))]), variable_manager=VariableManager(), loader=DictDataLoader())

    # pretend the play is actually part of a playbook, which is required for the iterator to work
    play.playbook = Playbook()
    # also required is the base

# Generated at 2022-06-20 14:12:20.643755
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    test PlayIterator.is_any_block_rescuing()
    '''
    pi = PlayIterator(play=1)
    assert pi.is_any_block_rescuing(pi._HostState__new()) == False

    # from _play_iterator_class._play_iterator_class_main.py
    # class HostState(object):
    #     ITERATING_SETUP    = 1
    #     ITERATING_TASKS     = 2
    #     ITERATING_RESCUE    = 3
    #     ITERATING_ALWAYS    = 4
    #     ITERATING_COMPLETE  = 5
    # class HostState(object):
    #     FAILED_NONE      = 0
    #     FAILED_SETUP     = 1
    #     FAILED_TAS

# Generated at 2022-06-20 14:12:31.832767
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    invocation = Play.play_context.make_play_context()

# Generated at 2022-06-20 14:12:43.759892
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # setup
    test_state = HostState()
    test_state.run_state = PlayIterator.ITERATING_TASKS
    test_state.tasks_child_state = HostState()
    test_state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    test_state.tasks_child_state.tasks_child_state = HostState()
    test_state.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_ALWAYS
    test_state.tasks_child_state.tasks_child_state.always_child_state = HostState()
    test_state.tasks_child_state.tasks_child_state.always_child_state.run_state = PlayIterator.ITERATING_TAS

# Generated at 2022-06-20 14:13:52.089916
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    PlayIterator(play=None)

# Generated at 2022-06-20 14:13:55.761014
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # initialization of the test values
    play_iterator = None
    # execution of the tested code
    result = play_iterator.is_failed()
    # evaluation of the tested results
    assert result == False



# Generated at 2022-06-20 14:14:05.735322
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    """Test add_tasks, which inserts tasks into the hosts' HostState objects.
    """

    tasks = [
        Task('A', None),
        Task('B', None),
        Task('C', None),
    ]

    blocks = [Block('block A', tasks)]

    hosts = [Host('host_a'), Host('host_b'), Host('host_c')]

    p = Play('foo', hosts=hosts, tasks=blocks)
    p.post_validate(loader=DummyLoader())

    i = PlayIterator(p)

    # Before adding any tasks, the iterator should consider all hosts to be done.
    assert i.is_failed(hosts[0])
    assert i.is_failed(hosts[1])
    assert i.is_failed(hosts[2])

    # Add tasks for all of

# Generated at 2022-06-20 14:14:19.391964
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():

    # Mark that we are running within a unit test
    C.DEFAULT_MODULE_PATH = "tests/unit/modules"

    class MyTest(BaseTest):

        def setUp(self):
            self.setup_loader()
            self.play = Play().load(_play, variable_manager=self.variable_manager, loader=self.loader)
            self.play_context = PlayContext()

        def tearDown(self):
            pass

        def test_add_tasks_ok(self):

            host = self.play.get_variable_manager().get_vars()['inventory_hostname']

            # Create a mock host and inventory
            self.mock_host = FakeHost()


# Generated at 2022-06-20 14:14:33.496814
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play()
    p.hosts = frozenset(['a', 'b', 'c', 'd'])
    p.strategy = 'linear'
    p.tasks = [
        Task.load(dict(action='debug', msg='do a')),
        Task.load(dict(action='debug', msg='do b')),
        Task.load(dict(action='debug', msg='do c')),
    ]
    p.name = 'test play'
    p.post_tasks = []
    p.tags = []

    p.notify = []
    p.handlers = []
    p.max_fail_percentage = None

    pi = PlayIterator(p)

    hosts = set()

# Generated at 2022-06-20 14:14:48.411750
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    class TestIterPlay(object):
        pass
    class TestIterTask(object):
        def __init__(self):
            self.role = None

    p = TestIterPlay()
    pi = PlayIterator(p)
    assert pi._play == p
    assert not pi._host_states
    assert pi._cur_batch_num == 0
    assert pi._cur_batch_count == 0
    assert pi._cur_batch_start == -1

    # Run this once just to make sure it doesn't hang
    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    pi._hosts = [h1, h2, h3]
    pi.get_next_batch()

    # TODO: test that it returns hosts in proper order, and is
    #      

# Generated at 2022-06-20 14:14:49.026795
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    pass


# Generated at 2022-06-20 14:15:01.746773
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = []
    for y in range(0,3):
        tasks = []
        for x in range(0,3):
            tasks.append(Task())
        blocks.append(Block(tasks))
    hostState = HostState(blocks)