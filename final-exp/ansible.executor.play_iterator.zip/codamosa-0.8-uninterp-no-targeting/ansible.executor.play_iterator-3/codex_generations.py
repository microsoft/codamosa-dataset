

# Generated at 2022-06-20 14:05:49.396611
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    play = Play()
    playContext = PlayContext(play)
    pi = PlayIterator(playContext)
    host = Host('test_host')
    pi.mark_host_failed(host)
    assert pi.get_failed_hosts() == {'test_host' : True}

# Generated at 2022-06-20 14:05:57.390699
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    Ensure _check_failed_state returns the correct value
    '''

    class TestPlay(object):
        def __init__(self):
            _removed_hosts = []

    class TestHost(object):
        def __init__(self, name):
            self.name = name

    class TestBlock(object):
        def __init__(self):
            self.tasks = []

    class TestState(object):
        def __init__(self,
                failed_state=0,
                tasks_child_state=None,
                rescue_child_state=None,
                always_child_state=None,
                did_rescue=False):
            self.fail_state = failed_state
            self.tasks_child_state = tasks_child_state
            self.rescue_child_state

# Generated at 2022-06-20 14:05:58.149349
# Unit test for method copy of class HostState
def test_HostState_copy():
    pass


# Generated at 2022-06-20 14:06:00.777335
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    mock_play = MagicMock()
    mock_block = MagicMock()
    testPlayIterator = PlayIterator("testPlayIterator", mock_play)
    testPlayIterator.cache_block_tasks("mock_block")
    pass # test passes by reaching this line

# Generated at 2022-06-20 14:06:14.379258
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host1 = Host(name='host1')
    task1 = Task()
    block1 = Block(block=[task1])
    block2 = Block(rescue=[task1])
    play1 = Play(hosts=[host1],
        tasks=[block1, block2])
    iterator1 = PlayIterator(play=play1)
    state1 = iterator1.get_host_state(host=host1)
    assert iterator1.is_any_block_rescuing(state=state1) == False
    (state1, task1) = iterator1.get_next_task_for_host(host=host1)
    assert task1 == task1
    assert iterator1.is_any_block_rescuing(state=state1) == False
    (state1, task2) = iterator1.get_next_task_

# Generated at 2022-06-20 14:06:18.624810
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p1 = Play.load(dict(name="#1", hosts=["h1"], tasks=[{"action" : "ok"}]))
    p2 = Play.load(dict(name="#2", hosts=["h2"], tasks=[{"action" : "ok"}]))

    # it = PlayIterator([p1, p2], True, False, False)
    it = PlayIterator([p1, p2])

    for play in it.plays():
        assert isinstance(play, Play)


# Generated at 2022-06-20 14:06:25.154310
# Unit test for method copy of class HostState
def test_HostState_copy():
    setup_block = Block([])
    tasks_block = Block([])
    rescue_block = Block([])
    always_block = Block([])
    setup_block.name = 'setup'
    tasks_block.name = 'tasks'
    rescue_block.name = 'rescue'
    always_block.name = 'always'
    hoststate = HostState([setup_block, tasks_block, rescue_block, always_block])
    hoststate.cur_block = 1
    hoststate.cur_regular_task = 3
    hoststate.cur_rescue_task = 2
    hoststate.cur_always_task = 1
    hoststate.run_state = PlayIterator.ITERATING_RESCUE
    hoststate.fail_state = PlayIterator.FAILED_RESCUE | PlayIterator.FAILED_SET

# Generated at 2022-06-20 14:06:30.866680
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    PlayIterator_inst = PlayIterator(None, None)
    PlayIterator_inst._host_states = dict()
    PlayIterator_inst._host_states["host"] = "value"

    assert PlayIterator_inst.get_host_state("host") == "value"
    assert PlayIterator_inst.get_host_state("non-existant") is None


# Generated at 2022-06-20 14:06:44.355407
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # Create mock objects, with desired return values
    host = Host('127.0.0.1')
    host.name = '127.0.0.1'
    task = Task()
    task.action = 'action'
    task_list = [task]
    play = Play()
    play.hosts = {'127.0.0.1': host}
    play.tasks = [task]
    play._removed_hosts = {'127.0.0.1': '127.0.0.1'}
    play.iterator_class = PlayIterator
    # Instantiate object with mock objects
    play_iterator = PlayIterator(play, [host], play.iterator_class)
    # Set return values of mock objects, method add_tasks

# Generated at 2022-06-20 14:06:53.978169
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    # test passes if no exception is raised
    # play iterator
    pitr = PlayIterator()

    # host state
    host_state = pitr.HostState()

    # block
    blk = Block()
    task = Task('task1')
    blk.add_task(task)
    # block2
    blk2 = Block()
    task2 = Task('task2')
    blk2.add_task(task2)
    blk.add_block(blk2)

    # block3
    blk3 = Block()
    task3 = Task('task3')
    blk3.add_task(task3)
    blk.add_block(blk3)

    res = Block()
    task4 = Task('task4')
    res.add_task(task4)
    blk

# Generated at 2022-06-20 14:07:25.944375
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks = []
    block = Block(plays=None, ds=dict(name='test_block', tasks=[dict(name='test_task')]))
    blocks.append(block)
    host_state = HostState(blocks)
    assert host_state == host_state


# Generated at 2022-06-20 14:07:33.437467
# Unit test for constructor of class HostState
def test_HostState():
    blocks = [Block(Task()), Block(Task(), rescue=Block(Task()), always=Block(Task())), Block(Task())]
    h = HostState(blocks)
    assert h._blocks == blocks
    assert h.cur_block == 0
    assert h.cur_regular_task == 0
    assert h.cur_rescue_task == 0
    assert h.cur_always_task == 0
    assert h.run_state == PlayIterator.ITERATING_SETUP
    assert h.fail_state == PlayIterator.FAILED_NONE
    assert h.pending_setup == False
    assert h.tasks_child_state == None
    assert h.rescue_child_state == None
    assert h.always_child_state == None
    assert h.did_rescue == False
    assert h.did_

# Generated at 2022-06-20 14:07:46.613889
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    from ansible.playbook import Playbook, Play
    from collections import namedtuple
    from ansible.inventory import Host, Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    VariableManager = namedtuple('VariableManager', ('_fact_cache',))
    Host = namedtuple('Host', ('name', 'vars'))
    Play = namedtuple('Play', ('hosts', 'name'))
    PlayContext = namedtuple('PlayContext', ('play', 'vars', 'variable_manager'))

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager({'fact1': 'value1'}))

    play = Play()
    play.hosts = ['host1', 'host2', 'host3']


# Generated at 2022-06-20 14:08:02.261216
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    host_state = HostState([])
    host_state.cur_block = 1
    host_state.cur_regular_task = 1
    host_state.cur_rescue_task = 1
    host_state.cur_always_task = 1
    host_state.run_state = PlayIterator.ITERATING_SETUP
    host_state.fail_state = PlayIterator.FAILED_SETUP
    host_state.pending_setup = True
    host_state.tasks_child_state = None
    host_state.rescue_child_state = None
    host_state.always_child_state = None
    host_state.did_rescue = True
    host_state.did_start_at_task = True

# Generated at 2022-06-20 14:08:12.812181
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    it = PlayIterator(play=None, play_context=Context())
    setattr(it, "_play", MagicMock(spec_set=Play))
    setattr(it, "_host_states", {'test-host': MagicMock(spec_set=HostState)})
    setattr(it, "_check_failed_state", MagicMock(spec_set=None))
    setattr(it, "_insert_tasks_into_state", MagicMock(spec_set=None))
    task_list = [MagicMock()]
    host = MagicMock(spec_set=Host)
    it.add_tasks(host, task_list)
    it._insert_tasks_into_state.assert_has_calls([call(it.get_host_state(host), task_list)])
# Unit test

# Generated at 2022-06-20 14:08:25.191990
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Tests that method is_any_block_rescuing returns True if the current HostState is in rescue mode or if any child
    HostState is in rescue mode.
    '''
    def get_new_state():
        '''
        Creates a new HostState object and returns it
        '''
        state = HostState(blocks=[])
        state.run_state = PlayIterator.ITERATING_TASKS
        state.tasks_child_state = None
        state.rescue_child_state = None
        state.always_child_state = None

        return state

    state = get_new_state()
    state.run_state = PlayIterator.ITERATING_RESCUE
    assert(PlayIterator.is_any_block_rescuing(state) == True)
    state = get_new_

# Generated at 2022-06-20 14:08:35.881297
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    """
    PlayIterator.get_original_task() Test
    """
    # Set up mock objects:
    host = Mock(Host)
    task = Mock(Task)
    iterator = PlayIterator(Mock())

    # Call function being tested:
    (orig_task, orig_block) = iterator.get_original_task(host=host, task=task)

    # This function has no assert statements, so we can't really test it.
    return

# Generated at 2022-06-20 14:08:46.268317
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    host = Host('testhost.com')
    host2 = Host('testhost2.com')
    play = Play().load({
        'name': 'testplay',
        'hosts': 'testhost.com,testhost2.com',
        'tasks': [
            {'debug': {'msg': 'this is task1'}}
        ]
    }, variable_manager=VariableManager(), loader=DictDataLoader())

    play_iterator = PlayIterator(play)
    assert play_iterator.get_active_state(play_iterator.get_host_state(host)) == play_iterator.get_host_state(host)


# Generated at 2022-06-20 14:08:58.225866
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    host = inventory.get_host("localhost")
    play = Play().load("auto-gen-tests/hostvars.yml", variable_manager=variable_manager, loader=loader)
    play_context = PlayContext("localhost", 123)
    play_context.inventory = inventory
    play_context.variable_manager = variable_manager
    play_iterator = PlayIterator(play, play_context)
    play_iterator.mark_host_failed(host)


# Generated at 2022-06-20 14:09:03.037862
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    original_host = Host(name='foo')
    original_task = Task()
    iterator = PlayIterator()
    (original_host, original_task) = iterator.get_original_task(original_host, original_task)

    assert original_host == None
    assert original_task == None


# Generated at 2022-06-20 14:10:17.644311
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():

    #############################
    # Mock the host's state 
    # and fail the setup with
    # error FAILED_SETUP
    #############################
    host_state = HostState(play=play0, vars={})
    host_state.cur_block = 0
    host_state.run_state = 2
    host_state.fail_state = 1
    host_state._blocks = [Block(plays=play0.get_plays())]
    #############################
    # Mock the host's state 
    # and fail the task with
    # error FAILED_TASKS
    #############################
    host_state2 = HostState(play=play0, vars={})
    host_state2.cur_block = 0
    host_state2.run_state = 1
    host_state2

# Generated at 2022-06-20 14:10:22.717029
# Unit test for method copy of class HostState
def test_HostState_copy():
    state = HostState(None)
    state2 = state.copy()
    assert state == state2


# Generated at 2022-06-20 14:10:35.672409
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    class dummy_class:
        def __init__(self, i, j):
            self.i = i
            self.j = j


    state = PlayIterator.HostState(blocks=[dummy_class(0,0)])
    state2 = PlayIterator.HostState(blocks=[dummy_class(0,0)])
    state.tasks_child_state = state2
    assert id(state) == id(state.get_active_state(state))
    assert id(state2) == id(state.get_active_state(state2))
    state3 = PlayIterator.HostState(blocks=[dummy_class(0,0)])
    state4 = PlayIterator.HostState(blocks=[dummy_class(0,0)])

# Generated at 2022-06-20 14:10:37.844758
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    assert False # TODO: implement your test here


# Generated at 2022-06-20 14:10:54.180934
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    def mock_get_host_state(host):
        return state
    mock_play = MagicMock(spec_set=Play)
    mock_play._iterator = PlayIterator(mock_play)
    mock_play._iterator.get_host_state = mock_get_host_state
    # Test PlayIterator.get_active_state function
    state = HostState()
    # No child states
    assert mock_play._iterator.get_active_state(state) == state
    # tasks_child_state
    state.tasks_child_state = HostState()
    assert mock_play._iterator.get_active_state(state) == state.tasks_child_state
    # rescue_child_state
    state.rescue_child_state = HostState()

# Generated at 2022-06-20 14:11:04.616733
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    p = Play()
    pi = PlayIterator(p)
    # Test on already failed states
    failed_state = HostState(blocks=[])
    failed_state.fail_state = pi.FAILED_TASKS
    assert pi.get_active_state(failed_state) == failed_state
    # Test on state which is currently running
    running_state = HostState(blocks=[])
    running_state.run_state = pi.ITERATING_TASKS
    assert pi.get_active_state(running_state) == running_state
    # Test on state which is not running and not failed
    not_running_state = HostState(blocks=[])
    not_running_state.run_state = pi.ITERATING_COMPLETE
    assert pi.get_active_state(not_running_state) == not_

# Generated at 2022-06-20 14:11:08.931496
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    blocks = [Block(
    )]
    state = HostState(blocks)
    assert state.__str__() == 'HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, ' \
                              'fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), ' \
                              'rescue child state? (None), always child state? (None), did rescue? False, ' \
                              'did start at task? False'

# Generated at 2022-06-20 14:11:11.174313
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
  itr = PlayIterator()
  assert itr.get_original_task(None, None) == (None, None)


# Generated at 2022-06-20 14:11:17.102761
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    def get_task(**kwargs):
        t = Task()
        t.action = 'shell'
        t.args = kwargs
        return t

    def get_block(**kwargs):
        block = Block()
        for k, v in iteritems(kwargs):
            setattr(block, k, v)
        return block

    b1 = get_block(tasks=[get_task(name='task1'), get_task(name='task2')])
    b2 = get_block(tasks=[get_task(name='task3'), get_task(name='task4')])
    blocks = [b1, b2]

    state = HostState(blocks)
    state.cur_block = 0
    state.cur_regular_task = 0

    assert state.get_current_block() == b1

# Generated at 2022-06-20 14:11:26.121100
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    '''
    get_failed_hosts should return a dict containing the names of the hosts for which
    the play has failed
    '''

    serial = 1

    # create a Play() and a PlayContext()
    play = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        serial = 1,
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='this is a task'))),
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    play.post_validate(base_vars=dict())
    runner = PlayIterator(play)
    context = PlayContext()
    
    # create two Host objects
    host1 = Host(name='host1')
    host2 = Host

# Generated at 2022-06-20 14:12:37.957357
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    p = Play().load(dict(
        name = 'test_play',
        hosts = 'all'
    ), variable_manager=variable_manager, loader=loader)
    p._included_roles = set()
    p._role_names = []
    p.post_validate(loader=loader)
    pi = PlayIterator(p)
    h = Host('foobar')
    t = Task().load(dict(
        name = 'task1',
        action = 'action1',
        tags = None,
        when = None
    ), variable_manager=variable_manager, loader=loader)
    result_useless = pi.get_original_task(h, t)
    assert result_useless == (None, None)

# Generated at 2022-06-20 14:12:47.266735
# Unit test for method copy of class HostState
def test_HostState_copy():
    """
    Initialize a HostState instance and call the method copy
    """
    block_1 = Block()
    block_1.block = [Task()]
    block_2 = Block()
    block_2.block = [Task(), Task()]
    blocks = [block_1, block_2]
    h = HostState(blocks)
    new_h = h.copy()
    
    for attr in ('_blocks', 'cur_block', 'cur_regular_task', 'cur_rescue_task', 'cur_always_task',
                     'run_state', 'fail_state', 'pending_setup',
                     'tasks_child_state', 'rescue_child_state', 'always_child_state'):
        assert getattr(h, attr) == getattr(new_h, attr)
   

# Generated at 2022-06-20 14:13:00.836840
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    fixture_data = {'test_PlayIterator_cache_block_tasks': {'hosts': ['foobar']}}
    fixture_data['test_PlayIterator_cache_block_tasks']['hosts'].append('webservers')
    fixture_data['test_PlayIterator_cache_block_tasks']['hostvars'] = {}
    fixture_data['test_PlayIterator_cache_block_tasks']['hostvars']['foobar'] = {'foo': 'bar'}
    fixture_data['test_PlayIterator_cache_block_tasks']['playbook_basedir'] = 'test/units/lib/ansible/playbook'


# Generated at 2022-06-20 14:13:05.711453
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    iterator = PlayIterator()
    # add_tasks() has no unit tests yet.

# Unit tests for class IteratorBase

# Generated at 2022-06-20 14:13:10.897483
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pl = Play().load(FIXTURE_PLAYBOOK, variable_manager=VariableManager(), loader=DictDataLoader())
    iterator = PlayIterator(pl)
    assert iterator.get_original_task() == (None, None) is True

# Generated at 2022-06-20 14:13:21.659433
# Unit test for constructor of class HostState
def test_HostState():
    block = Block()
    tasks = [ 
        Task().load({
            'action': 'setup'
        }),
        Task().load({
            'action': 'setup'
        }),
        Task().load({
            'action': 'setup'
        })
    ]
    block.block = tasks
    
    tasks = [ 
        Task().load({
            'action': 'setup'
        }),
        Task().load({
            'action': 'setup'
        }),
        Task().load({
            'action': 'setup'
        })
    ]
    block.rescue = tasks


# Generated at 2022-06-20 14:13:28.422354
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Test if method get_original_task returns the hostname and
    the task name for a given task.
    '''
    this_host = C.localhost
    play_hosts = [this_host]
    play_context = PlayContext()
    play = Play().load(dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup'), register='setup_facts'),
            dict(action=dict(module='debug', args=dict(msg='{{setup_facts.ansible_eth0.ipv4.address}}')))
        ]
    ))
    play_iterator = PlayIterator(play, play_context)
    play_iterator.play_context.network_os = 'default'
    play_iterator

# Generated at 2022-06-20 14:13:32.112730
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
	test_obj = HostState([])
	test_repr = repr(test_obj)
	assert test_repr == "HostState([])"


# Generated at 2022-06-20 14:13:34.739151
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # Get the task from the cache
    # play_iterator.get_original_task(host, task)
    pass

# Generated at 2022-06-20 14:13:45.773073
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    PlayIterator._play:
    :type play: Play
    PlayIterator._play_context:
    :type play_context: PlayContext
    :return:
    '''
    # prepare play
    play = Play().load(dict(
        name="test_play",
        hosts='all',
        roles=[],
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ))

    # prepare inventory
    test_host = Host(name="test_host")
    inventory = Inventory(
        hosts=[test_host],
        runner_callbacks=PlayIterator(play=play)
    )

   