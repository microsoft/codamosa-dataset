

# Generated at 2022-06-20 14:06:10.701123
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    my_play = Play()
    my_iterator = PlayIterator(my_play)
    my_iterator._host_states = {"localhost" : HostState(blocks = [Block(name = "test_block")])}
    host = Host("localhost")
    assert my_iterator.is_any_block_rescuing(my_iterator.get_host_state(host)) == False
    my_iterator._host_states["localhost"].run_state = PlayIterator.ITERATING_RESCUE
    assert my_iterator.is_any_block_rescuing(my_iterator.get_host_state(host)) == True
    my_iterator._host_states["localhost"].run_state = PlayIterator.ITERATING_TASKS

# Generated at 2022-06-20 14:06:24.441777
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks = []
    hs1 = HostState(blocks)
    hs2 = HostState(blocks)
    hs1.cur_block = hs2.cur_block = 1
    hs1.cur_regular_task = hs2.cur_regular_task = 2
    hs1.cur_rescue_task = hs2.cur_rescue_task = 3
    hs1.cur_always_task = hs2.cur_always_task = 4
    hs1.run_state = hs2.run_state = 5
    hs1.fail_state = hs2.fail_state = 6
    hs1.pending_setup = hs2.pending_setup = True
    hs1.did_rescue = hs2.did_rescue = True
    h

# Generated at 2022-06-20 14:06:34.231870
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    playlist = Play()

    task1 = Task()
    task1._role = 'role1'
    task2 = Task()
    task2._role = 'role2'
    task3 = Task()
    task3._role = 'role3'
    block1 = Block()
    block1._role = 'block1'
    block2 = Block()
    block2._role = 'block2'
    task4 = Task()
    task4._role = 'role4'
    task5 = Task()
    task5._role = 'role5'
    task6 = Task()
    task6._role = 'role6'
    block3 = Block()
    block3._role = 'block3'

    playlist.add_task(task1)
    playlist.add_task(task2)

# Generated at 2022-06-20 14:06:46.800754
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play = Play()
    play.name = 'mock.play'
    play.hosts = 'localhost'
    play.gather_facts = None
    play.tasks = [
        Task()
    ]
    pi = PlayIterator(play)

# Generated at 2022-06-20 14:07:03.039513
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():

    testinventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['jumper.oreilly.com'])

    testplay = Play().load(dict(
        name = "Test Play",
        hosts = 'jumper.oreilly.com',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='/bin/false')),
            dict(action=dict(module='shell', args='/bin/true')),
            dict(action=dict(module='shell', args='/bin/false')),
            dict(action=dict(module='shell', args='/bin/true'))
        ]
    ), variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-20 14:07:03.843858
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass

# Generated at 2022-06-20 14:07:13.401214
# Unit test for constructor of class HostState
def test_HostState():
    block = []
    host_state = HostState(block)
    assert host_state._blocks == block
    assert host_state.cur_block == 0
    assert host_state.cur_regular_task == 0
    assert host_state.cur_rescue_task == 0
    assert host_state.cur_always_task == 0
    assert host_state.run_state == PlayIterator.ITERATING_SETUP
    assert host_state.fail_state == PlayIterator.FAILED_NONE
    assert host_state.pending_setup == False
    assert host_state.tasks_child_state == None
    assert host_state.rescue_child_state == None
    assert host_state.always_child_state == None
    assert host_state.did_rescue == False
    assert host_state.did_

# Generated at 2022-06-20 14:07:16.099318
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    print("Running method get_host_state...")
    
    # TODO: error handling
    pass

# Generated at 2022-06-20 14:07:29.169126
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
  from ansible.playbook.play import Play
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.block import Block
  from ansible.playbook.task import Task
  from ansible.playbook.handler import Handler
  from ansible.playbook.role import Role
  from ansible.playbook.role_include import IncludeRole
  from ansible.playbook.hosts import Hosts
  from ansible.inventory.manager import InventoryManager
  import ansible.constants as C

  C.HOST_KEY_CHECKING = False


# Generated at 2022-06-20 14:07:34.442873
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    '''
    Tests get_active_state.
    '''
    state = PlayIterator()
    state._host_states = {'localhost': HostState(blocks=[Block('a')])}
    state._host_states['localhost'].run_state = PlayIterator.ITERATING_TASKS
    state._host_states['localhost'].tasks_child_state = HostState(play=None, blocks=[Block('a')])
    state._host_states['localhost'].tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
    state._host_states['localhost'].tasks_child_state.tasks_child_state = HostState(play=None, blocks=[Block('a')])

# Generated at 2022-06-20 14:08:08.095349
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
  pass # No test needed


# Generated at 2022-06-20 14:08:22.264819
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    '''
    PlayIterator.get_active_state is a method of PlayIterator
    '''
    # state = self._host_states[host.name]
    # active_state = self.get_active_state(state)

    # Imports
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    import json
    import collections

    # state_data = json.load(open('~/ansible-test/test-data/test_PlayIterator_get_active_state.json'), object_pairs_hook=collections.OrderedDict)

# Generated at 2022-06-20 14:08:31.630136
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # create an iterator
    play = Play().load('test/ansible/p.yml', variable_manager=variable_manager, loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='test/ansible/hosts')
    tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=dict(), stdout_callback=results_callback)
    iterator = PlayIterator(inventory=inventory, play=play, play_context=PlayContext(), all_vars=dict(), options=options)
    # run a task that should call get_next_task_for_host
    host = inventory.get_host('testhost')
    tqm._add_host(host)
    t = Task()
    t.action = 'setup'

# Generated at 2022-06-20 14:08:41.790041
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    # create a mock play, and iterate through it
    play = Play.load(
        dict(
            name = "test play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
            ]
        )
    )
    # play._hosts is of type InventoryManager, but PlayIterator.__init__ accepts a list.
    # So we must call the latter's constructor with a list of hosts
    play_iter = PlayIterator(play, PlayContext(), list(play._hosts))
    # play_iter._host_states will be a dict mapping host names to states

# Generated at 2022-06-20 14:08:46.827969
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    """
    # Failed hosts are reflected in get_failed_hosts (get_failed_hosts)
    # The failed hosts should be reflected in the list of failed hosts
    # Case 1: failed host is None
    # Case 2: failed host is List
    # Case 3: failed host is List that have some non-failed host in it
    """
    assert PlayIterator(play=None).get_failed_hosts() is None


# Generated at 2022-06-20 14:08:47.628183
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass

# Generated at 2022-06-20 14:09:01.015370
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play()
    play.hosts = 'localhost'
    play.tasks = [
        Task()
    ]
    play.post_tasks = [
        Task()
    ]
    play.handlers = [
        Task()
    ]
    play.pre_tasks = [
        Task()
    ]
    iterator = PlayIterator()
    iterator._play = play
    host = Host()
    host.name = 'localhost'
    # Create a test state object
    state = HostState(blocks=[
        Block(rescue=[
            Task(),
            Block(),
            Task(),
        ],
        tasks=[
            Task()
        ],
        always=[
            Task()
        ])])
    iterator._host_states[host.name] = state

    iterator.mark_host_failed(host)

# Generated at 2022-06-20 14:09:08.996649
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [Block(task_include=dict(tasks=[]), role=None, rescue=None, always=None)]
    host_state = HostState(blocks)
    assert host_state.copy() == host_state
    host_state.cur_block = 1
    assert host_state.copy() != host_state
    host_state.cur_block = 0
    assert host_state.copy() == host_state
    host_state.cur_regular_task = 1
    assert host_state.copy() != host_state
    host_state.cur_regular_task = 0
    assert host_state.copy() == host_state
    host_state.cur_rescue_task = 1
    assert host_state.copy() != host_state
    host_state.cur_rescue_task = 0
    assert host_

# Generated at 2022-06-20 14:09:12.067697
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    assert PlayIterator().get_next_task_for_host(host=host) == None


# Generated at 2022-06-20 14:09:12.855385
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pass


# Generated at 2022-06-20 14:09:49.255123
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    it = PlayIterator()
    it.get_host_state(None)
    it.get_host_state(None)


# Generated at 2022-06-20 14:09:52.099575
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [Block('task1')]
    state = HostState(blocks)
    copy = state.copy()
    assert copy == state


# Generated at 2022-06-20 14:10:02.333738
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    pb = Playbook(
        playbook='/dev/null',
        loader=DictDataLoader({}),
        variable_manager=VariableManager(),
        options=Options.from_file('/dev/null', [], False, False, False, False, False, 1, True)
        )

    # empty play

# Generated at 2022-06-20 14:10:07.472201
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
  """
  Unit test for method add_tasks of class PlayIterator
  """
  iterator = PlayIterator(play=Play.load(loader=None, playbooks=[], variable_manager=None))
  tasks = [Task()]
  host = Host('hostname')
  iterator.add_tasks(host, tasks)
  cond = iterator._host_states[host.name]._blocks[0].block == tasks
  assert (cond), "values do not match ({0} != {1})".format(iterator._host_states[host.name]._blocks[0].block, tasks)
#_________________________________________________________________________________________

#   add_tasks

#_________________________________________________________________________________________

#   get_active_state


# pylint: disable=protected-access,too-many-branches,too-many-statements,too-many-locals

# Generated at 2022-06-20 14:10:14.716577
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    '''
    Test get_active_state method of PlayIterator
    '''
    iter = PlayIterator()
    # _insert_tasks_into_state(None, None)
    s = iter._insert_tasks_into_state(None, None)
    assert s == None
    # _insert_tasks_into_state(None, [])
    s = iter._insert_tasks_into_state(None, [])
    assert s == None
    # _insert_tasks_into_state(empty PlayState, [])
    s = iter._insert_tasks_into_state(PlayState(), [])
    assert s == None
    # _insert_tasks_into_state(empty PlayState, None)
    s = iter._insert_tasks_into_state(PlayState(), None)

# Generated at 2022-06-20 14:10:18.878771
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load(os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'playbooks', 'test_async.yml'))
    pi = PlayIterator(p)
    assert isinstance(pi, PlayIterator)


# Generated at 2022-06-20 14:10:20.415057
# Unit test for constructor of class HostState
def test_HostState():
    state = HostState([])
    assert(state.cur_block == 0)



# Generated at 2022-06-20 14:10:22.585656
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    # TODO: this test is not complete
    pass



# Generated at 2022-06-20 14:10:27.241294
# Unit test for method copy of class HostState
def test_HostState_copy():
    from ansible.playbook.taggable import Taggable
    c = Taggable()
    c.tags = set(['foo','bar','baz'])
    x = HostState(blocks)
    y = x.copy()
    print(x==y)


# Generated at 2022-06-20 14:10:39.659043
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
  state = HostState()
  state.cur_block = 0
  state._blocks = [
      Block('all', []),
      Block('all', []),
  ]
  state.cur_regular_task = 3
  state.cur_rescue_task = 0
  state.cur_always_task = 0
  state.run_state = 1
  state.tasks_child_state = HostState()
  state.tasks_child_state.cur_block = 0
  state.tasks_child_state._blocks = [
      Block('all', []),
      Block('all', []),
  ]
  state.tasks_child_state.cur_regular_task = 0
  state.tasks_child_state.cur_rescue_task = 0
  state.tasks_child_state.cur_always_

# Generated at 2022-06-20 14:11:50.883174
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    # no setup required
    # PlayIterator.get_failed_hosts(self)
    pass


# Generated at 2022-06-20 14:11:51.884191
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    pass

# Generated at 2022-06-20 14:12:03.814307
# Unit test for method get_failed_hosts of class PlayIterator

# Generated at 2022-06-20 14:12:15.858759
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test the method is_failed of the PlayIterator class

    Returns:
        True if unit tests pass, otherwise False
    '''

    # setup
    test_host_name = "testhost"
    test_task_run_state = "ok"
    test_task_host = "somehost"
    test_task_name = "some task"
    test_host = Host(test_host_name)
    test_task = Task()
    test_task.action = lambda: 0
    test_task.set_loader(DictDataLoader())
    test_task.register = MagicMock()
    test_task.run = MagicMock(return_value=test_task_run_state)
    test_task.name = test_task_name
    test_task.module_name = test_task_

# Generated at 2022-06-20 14:12:26.035224
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayBookPlay
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    pb_play = PlayBookPlay()
    host_list = ['localhost']
    host_list.extend(['localhost']*(C.DEFAULT_FORKS-1))  # -1 for serial

# Generated at 2022-06-20 14:12:31.724174
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    # Initialize a play object

    # Initialize a host object

    # Initialize a PlayIterator object

    # Initialize a HostState object

    # Check if host is failed

# Generated at 2022-06-20 14:12:41.330751
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    #block = Block()
    #block.append(Task())
    #state = HostState(block)
    #state.cur_block = 1
    #state.cur_regular_task = 2
    #state.cur_rescue_task = 3
    #state.cur_always_task = 4
    #state.run_state = PlayIterator.ITERATING_RESCUE
    #state.fail_state = PlayIterator.FAILED_SETUP
    #state.pending_setup = False
    #state.did_rescue = True
    #state.did_start_at_task = True
    #print state
    pass

# Generated at 2022-06-20 14:12:47.427173
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    p = Play()
    pi = PlayIterator(p)
    h = Host('foo')
    pi.mark_host_failed(h)
    assert pi.is_failed(h) == True


# Generated at 2022-06-20 14:12:53.346807
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play = dict(
        name = 'test play',
        hosts = 'all',
    )
    hosts = C.localhost
    variables = dict()
    iterator = PlayIterator(play, hosts, variables)
    assert(iterator.hosts == hosts)
    assert(iterator.variables == variables)


# Generated at 2022-06-20 14:13:04.352749
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    play_iterator = PlayIterator()

    # Test with 2 levels of children
    active_state = play_iterator._create_host_state(blocks=1)
    active_state.run_state = play_iterator.ITERATING_ALWAYS
    active_state.always_child_state = active_state.rescue_child_state = active_state.tasks_child_state = active_state

    play_iterator.set_host_state(Host('localhost'), active_state)
    assert play_iterator.get_active_state(active_state) == active_state

    # Test with task being done by a child state
    active_state = play_iterator._create_host_state(blocks=1)
    active_state.cur_block = 0
    active_state.run_state = play_iterator.ITERATING_TASKS

# Generated at 2022-06-20 14:14:12.105189
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    pass

# Generated at 2022-06-20 14:14:23.646350
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():

    block = Block()
    state = HostState([block])
    state.cur_block = 2
    state.cur_regular_task = 3
    state.cur_rescue_task = 4
    state.cur_always_task = 5
    state.run_state = 6
    state.fail_state = 7
    state.pending_setup = True
    state.tasks_child_state = Block()
    state.rescue_child_state = Block()
    state.always_child_state = Block()
    state.did_rescue = True
    state.did_start_at_task = True

    state2 = HostState([block])
    state2.cur_block = 2
    state2.cur_regular_task = 3
    state2.cur_rescue_task = 4
    state2.cur_always

# Generated at 2022-06-20 14:14:34.285443
# Unit test for constructor of class HostState
def test_HostState():
    blocks = [
        Block([]),
        Block([])
    ]

    hs = HostState(blocks)
    assert len(blocks) == 2
    assert hs.cur_block == 0
    assert hs.cur_regular_task == 0
    assert hs.cur_rescue_task == 0
    assert hs.cur_always_task == 0
    assert hs.run_state == PlayIterator.ITERATING_SETUP
    assert hs.fail_state == PlayIterator.FAILED_NONE
    assert hs.pending_setup == False
    assert hs.tasks_child_state == None
    assert hs.rescue_child_state == None
    assert hs.always_child_state == None
    assert hs.did_rescue == False
    assert hs.did_

# Generated at 2022-06-20 14:14:39.678445
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load(FIXTURE_PLAYBOOK, variable_manager=VariableManager(), loader=Loader())
    pit = PlayIterator(p)

# Generated at 2022-06-20 14:14:51.004623
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # init the necessary data to pass to _get_original_task
    host = MagicMock()
    task = MagicMock()
    task._ds = None
    task._hosts = None
    task._loop_args = None
    tasks = [MagicMock(), MagicMock()]
    hosts = [MagicMock(), MagicMock(), MagicMock()]
    tasks[0]._ds = None
    tasks[0]._hosts = None
    tasks[0]._loop_args = None
    tasks[1]._ds = None
    tasks[1]._hosts = None
    tasks[1]._loop_args = None
    hosts[0].name = 'host1'
    hosts[1].name = 'host2'
    hosts[2].name = 'host3'

# Generated at 2022-06-20 14:14:56.802496
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
	host = Host("hostname")
	inventory = Inventory(hosts=[host])
	play = Play().load(dict(
		name = "foobar",
		hosts = 'all',
		gather_facts = 'no',
		tasks = [
			dict(action=dict(module='debug', args=dict(msg='fail')))
		]
	), variable_manager=VariableManager(), loader=DataLoader())
	iterator = PlayIterator(inventory=inventory, play=play)
	iterator._host_states[host.name] = HostState(host)
	iterator._host_states[host.name]._blocks[0]._failed = True
	failed_hosts = iterator.get_failed_hosts()
	assert len(failed_hosts) == 1
	assert host.name in failed_host