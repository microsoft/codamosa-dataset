

# Generated at 2022-06-20 14:05:53.015210
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host = Host('hostname')
    play = Play()
    block = Block()
    play_iterator = PlayIterator(play, None)
    play_iterator.get_host_initial_state(host)

    # Test the empty case:
    task_list = []
    play_iterator._insert_tasks_into_state(play_iterator.get_host_state(host), task_list)
    tasks = play_iterator.get_host_state(host)._blocks[0].block

    assert tasks == []

    # Test that when we add a task to the beginning of a block it is actually added
    # to the block:
    task_list = [DummyTask()]
    play_iterator._insert_tasks_into_state(play_iterator.get_host_state(host), task_list)
    tasks = play_

# Generated at 2022-06-20 14:05:54.139774
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    assert str(repr(HostState([]))) == "''"


# Generated at 2022-06-20 14:06:00.749262
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    This method tests the execution of mark_host_failed method in PlayIterator class.
    '''

    # setup play object
    host = C.HOSTS[0]
    play = Play().load(dict(
        name = "test play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami')),
        ]
    ), variable_manager=variable_manager, loader=loader)

    # create iterator
    iterator = PlayIterator(play, variable_manager=variable_manager)

    # create HostState
    host_state = iterator.get_initial_state(host)

    # create block

# Generated at 2022-06-20 14:06:01.567000
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pass



# Generated at 2022-06-20 14:06:15.217428
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    PLUGIN_CLASSES = ('test.unit.callback.log_plays',)
    (options, args) = CLI.parser.parse_args([])
    loader, inventory, variable_manager = CLI.create_play_environment(options=options, args=args, plugin_class_list=PLUGIN_CLASSES)
    hosts = [Host(name='testhost')]
    any_host = Host(name='testhost', groups={'testgroup': 'testhost'})
    relevant_host = Host(name='testhost', groups={'testgroup': 'testhost'}, vars={'test_var': 'testvar'})
    task1 = dict(action=dict(module='test', args=dict()))
    task2 = dict(action=dict(module='test2', args=dict()))

# Generated at 2022-06-20 14:06:27.807620
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='hello world')))
        ]
    )

    # FIXME: make a proper host here
    myhost = Host(name='fake')

    play = Play().load(play_source, variable_manager=VariableManager(), loader=DummyLoader())

    itr = PlayIterator(play)
    host_itr = itr._play_iters[myhost.name]

    for result in host_itr:
        print (result)


# Generated at 2022-06-20 14:06:36.491124
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():

    random.seed(0)

    class MyPlay(Play):
        def __init__(self, name, tasks=None):
            super(MyPlay, self).__init__(name, [], play_context=dict())
            self._tasks = tasks

        def get_tasks(self):
            return self._tasks

    class MyTask(object):
        def __init__(self, name):
            self._name = name

        def __repr__(self):
            return self._name

        def __eq__(self, other):
            return isinstance(other, MyTask) and self._name == other._name

    class MyHost(object):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    # Test 7: tasks

# Generated at 2022-06-20 14:06:42.281525
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    str1='''
- name: myblock
  hosts: local
  tasks:
  - include: test.yml
               '''
    import io
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-20 14:06:52.911740
# Unit test for constructor of class HostState

# Generated at 2022-06-20 14:07:06.165299
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    p = Play().load(dict(
        name = "foo",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{bar}}'))),
        ]
    ), loader=DummyLoader())

    all_hosts = [Host(name) for name in ('foo', 'bar')]

    # first test without child state
    all_host_states = dict((host.name, HostState(blocks=[load_list_of_blocks(p.compile())])) for host in all_hosts)

# Generated at 2022-06-20 14:07:38.436190
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = [Block([]), Block([])]
    state = HostState(blocks)
    archive = state.__repr__()
    assert archive == "HostState([Block(), Block()])"
    print("test HostState___repr__() ok")

# Generated at 2022-06-20 14:07:46.658544
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    PlayIterator.is_any_block_rescuing(self, state)
    '''
    state = HostState()
    state.tasks_child_state = HostState()
    state.tasks_child_state.run_state = 'ITERATING_BLOCK'
    play = FakePlay()
    play.serial = 1
    iterator = PlayIterator(play)
    assert iterator.is_any_block_rescuing(state) == False


# Generated at 2022-06-20 14:07:50.212650
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    pass

# Generated at 2022-06-20 14:07:57.597730
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    blocks = [Block.load(dict(block=dict(),), Task.load(dict(task=dict(),)), []), Block.load(dict(block=dict(),), Task.load(dict(task=dict(),)), [])]
    hoststate = HostState(blocks)
    hoststate.cur_block = 0
    original_block = hoststate.get_current_block()
    assert original_block == blocks[0]


# Generated at 2022-06-20 14:08:09.342569
# Unit test for constructor of class HostState
def test_HostState():

    blocks = []

    for i in range(4):
        tasks = []
        for t in range(5):
            tasks.append(Task())

        block = Block(str(i), tasks)
        block.always = tasks
        block.rescue = tasks

        blocks.append(block)

    host_state = HostState(blocks)

    assert host_state.cur_block == 0
    assert host_state.cur_regular_task == 0
    assert host_state.cur_always_task == 0
    assert host_state.cur_rescue_task == 0

    assert host_state.run_state == PlayIterator.ITERATING_SETUP
    assert host_state.fail_state == PlayIterator.FAILED_NONE

    assert host_state.pending_setup == False
    assert host_state.did_res

# Generated at 2022-06-20 14:08:15.266499
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
  """Unit test for method get_failed_hosts of class PlayIterator"""
  initializer.global_verbosity = 2
  initializer.global_log_path = None
  initializer.global_debug = False
  iterator = PlayIterator()
  assert iterator.get_failed_hosts() == {}
  

# Generated at 2022-06-20 14:08:26.991101
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Test the is_failed method of PlayIterator
    '''
    host_name = 'test-host'
    host = Mock()
    host.get_name.return_value = host_name

    # Test 1: No failure
    play = Mock()
    play.get_removed_hosts.return_value = []

    play_iter = PlayIterator(play, [], None)
    play_iter.next_task_for_host(host)

    assert play_iter.is_failed(host) is False

    # Test 2: Failure
    play = Mock()
    play.get_removed_hosts.return_value = [host_name]

    play_iter = PlayIterator(play, [], None)
    play_iter.next_task_for_host(host)


# Generated at 2022-06-20 14:08:28.442949
# Unit test for constructor of class HostState
def test_HostState():
    assert HostState([]) is not None


# Generated at 2022-06-20 14:08:29.859444
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass


# Generated at 2022-06-20 14:08:42.581727
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    class Mock(object):

        def __init__(self, play_hosts=[], play_all_hosts=False):
            self.hosts         = play_hosts
            self.all_hosts     = play_all_hosts

    class Block(object):
        def __init__(self, block=[], rescue=[], always=[]):
            self.block = block
            self.rescue = rescue
            self.always = always

    play = Mock(play_hosts=['localhost', 'remotehost'], play_all_hosts=False)
    block = Block(block=[1, 2])
    iterator = PlayIterator(play=play)
    iterator.add_tasks(play.hosts[0], block)


# Generated at 2022-06-20 14:09:24.775840
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    hb1 = Block()
    hb2 = Block()
    hb1.block = [Task()]
    hb2.block = [Task()]
    state1 = HostState([hb1])
    state2 = HostState([hb2])
    state1.cur_block = 0
    state1.cur_regular_task = 0
    state1.cur_rescue_task = 0
    state1.cur_always_task = 0
    state1.run_state = PlayIterator.ITERATING_SETUP
    state1.fail_state = PlayIterator.FAILED_NONE
    state1.pending_setup = False
    state1.tasks_child_state = None
    state1.rescue_child_state = None
    state1.always_child_state = None
    state1

# Generated at 2022-06-20 14:09:26.285959
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
  pytest.xfail("Not yet implemented")


# Generated at 2022-06-20 14:09:39.982366
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    '''
    Test case for add_tasks of class PlayIterator
    '''
    print("test_PlayIterator_add_tasks")
    hostname = "test_host"

    #setup module
    setup_loader()
    group_vars_dict = {}
    group_vars_str = {}
    host_vars_dict = {}
    host_vars_str = {}
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=Inventory())
    variable_manager.set_inventory(Inventory(hosts=[hostname]))
    variable_manager.set_host_variables(host_vars_dict, hostname)
    variable_manager.set_host_variable(hostname, "ansible_foo", "bar")
    variable_manager.set_group_variables

# Generated at 2022-06-20 14:09:55.157210
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    play = Play()
    play.hosts = ['localhost']
    play._iterator = PlayIterator(play)
    block = Block()
    assert play._iterator.cache_block_tasks(block, 5) == 0
    play._iterator.add_tasks('localhost', block.block)
    play._iterator.add_tasks('localhost', block.block)
    assert play._iterator._num_cache_objects() == 1
    assert play._iterator.cache_block_tasks(block, 5) == 1
    play._iterator.add_tasks('localhost', block.block)
    play._iterator.add_tasks('localhost', block.block)
    assert play._iterator._num_cache_objects() == 2
    assert play._iterator.cache_block_tasks(block, 5) == 2
    play._iterator.add_t

# Generated at 2022-06-20 14:10:06.774951
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    play = Play()

    t1 = Task()
    t1._uuid = "1"
    t2 = Task()
    t2._uuid = "2"
    t3 = Task()
    t3._uuid = "3"
    t4 = Task()
    t4._uuid = "4"
    t5 = Task()
    t5._uuid = "5"
    t6 = Task()
    t6._uuid = "6"

    h1 = Host("host1")
    h2 = Host("host2")
    h3 = Host("host3")

    play._tasks_cache = [t1, t2, t3, t4, t5, t6]
    play._set_parent_block(t1, t2)

# Generated at 2022-06-20 14:10:19.089553
# Unit test for method add_tasks of class PlayIterator

# Generated at 2022-06-20 14:10:26.564698
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    """
    PlayIterator.is_failed() - test that PlayIterator.is_failed() works as expected
    """
    # Mark task failed, should have a failed state
    iterator = PlayIterator()
    foo_host = Host('foo_host')
    foo_task = Task()
    iterator.mark_host_failed(foo_host)
    assert iterator.is_failed(foo_host) == True
    # Reset task, should be not failed now
    iterator = PlayIterator()
    assert iterator.is_failed(foo_host) == False


# Generated at 2022-06-20 14:10:29.555397
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    _blocks = [Block(0, [])]
    hs = HostState(_blocks)
    assert _blocks[0] == hs.get_current_block()


# Generated at 2022-06-20 14:10:43.153621
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    host = Host(name='example.com')
    play = Play()
    iterator = PlayIterator(play)
    iterator.test_done_state(host)
    play.hosts = ['example.com']

# Generated at 2022-06-20 14:10:53.096227
# Unit test for method copy of class HostState
def test_HostState_copy():
    hs_1 = HostState([])
    hs_2 = hs_1.copy()
    assert hs_1 is not hs_2
    assert hs_1 == hs_2

    hs_1._blocks = [Block()]
    hs_1.tasks_child_state = HostState([])
    hs_2 = hs_1.copy()
    assert hs_1 is not hs_2
    assert hs_1 != hs_2
    assert hs_1.tasks_child_state == hs_2.tasks_child_state



# Generated at 2022-06-20 14:11:24.770848
# Unit test for method copy of class HostState
def test_HostState_copy():
    hostname = "localhost"
    state = HostState([Block()])
    state2 = State(hostname, [Block()])
    state.copy()
    state2.copy()



# Generated at 2022-06-20 14:11:29.294774
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    unit test for method is_any_block_rescuing of class PlayIterator
    '''
    pb = Playbook()
    p = pb.create_play(None, dict())
    PlayIterator.get(p)
    pass



# Generated at 2022-06-20 14:11:38.092948
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host = Host('localhost')
    host._set_name = host.name
    task = Task()
    task._role = None
    task._role_name = None
    host.set_task_facts = lambda *args: task
    host.get_variables = lambda *args: dict()
    task.get_dep_chain = lambda *args, **kwargs: task
    
    inventory = Mock()

# Generated at 2022-06-20 14:11:43.744593
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks1 = []
    blocks1.append(Block(parent=None))
    blocks1[0].block = ['tasks']
    blocks1[0].vars = {'name': 'my first block'}
    blocks1[0].task('setup', args={'action': 'setup'})
    blocks1[0].task('debug', args={'action': 'debug', 'msg': 'my first task'})
    blocks1.append(Block(parent=None))
    blocks1[1].block = ['tasks']
    blocks1[1].vars = {'name': 'my second block'}
    blocks1[1].task('setup', args={'action': 'setup'})
    blocks1[1].task('debug', args={'action': 'debug', 'msg': 'my second task'})
    blocks1.append

# Generated at 2022-06-20 14:11:48.805771
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load(load_yaml("""
    - hosts: localhost
      gather_facts: no
      tasks:
      - debug:
          msg: "hello"
    """, path='test_playiterator'))
    pi = PlayIterator(p)
    assert isinstance(pi, PlayIterator)


# Generated at 2022-06-20 14:12:01.340498
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    my_blocks = [Block(task_list=[dict(action='task0', delegate_to='127.0.0.1')]),
                 Block(task_list=[dict(action='task1', delegate_to='127.0.0.1')])]
    my_play = Play()
    my_play.post_validate()
    my_iterator = PlayIterator(my_play)
    my_host = Host('127.0.0.1')
    my_host.name = '127.0.0.1'
    my_iterator.add_tasks(my_host, my_blocks[1].block)
    my_iterator._host_states[my_host.name]._blocks += my_blocks

# Generated at 2022-06-20 14:12:09.331368
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    block = Block(None, None)
    block.block = [Task()]
    block.rescue = [Task()]
    block.always = [Task()]

    host_state = HostState(blocks=[block])
    host_state.run_state = PlayIterator.ITERATING_TASKS
    host_state.cur_regular_task = 0

    p = Play()

    play_iterator = PlayIterator(p, [host_state])
    host = Host('test_host')
    play_iterator.mark_host_failed(host)

    assert host_state.cur_rescue_task == 0

    host_state.cur_rescue_task = 1
    play_iterator.mark_host_failed(host)

    assert host_state.cur_always_task == 1
# END OF UNIT TESTS FOR

# Generated at 2022-06-20 14:12:18.481807
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    block1 = Block()
    block1.vars = {'a': 1}
    block1.block = [Task()]
    block2 = Block()
    block2.vars = {'a': 2}
    block2.block = [Task()]
    blocks = [block1, block2]
    state = HostState(blocks)
    
    assert state.get_current_block() == block1
    state.cur_block = 1
    assert state.get_current_block() == block2


# Generated at 2022-06-20 14:12:26.837530
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''
    _playbook = '''
- hosts: local
  roles:
    - role: test
'''
    pb = Playbook().load(yaml.safe_load(_playbook))
    p = pb.get_plays()[0]
    pe = PlayExecutor(pb, p)
    pi = PlayIterator(pe)
    h = Host("local")
    assert pi.get_host_state(h).run_state == PlayIterator.ITERATING_TASKS
    pi.mark_host_failed(h)
    assert pi.get_host_state(h).run_state == PlayIterator.ITERATING_COMPLETE

# Generated at 2022-06-20 14:12:40.343341
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class
    ansible.executor.task_queue_manager.PlayIterator
    '''
    # Create a Mock object for the Play
    mock_play = MagicMock()
    mock_play.removed_hosts = [ ] # Non-compliant attribute
    mock_play.serial = 8

    # Create a collection of Mock objects for the Hosts
    mock_host = MagicMock()
    mock_host.name = 'host0'
    mock_host.play = mock_play
    mock_host.serial = 0
    mock_host_0 = mock_host
    mock_host = MagicMock()
    mock_host.name = 'host1'
    mock_host.play = mock_play
    mock_host.serial = 1
    mock_host_

# Generated at 2022-06-20 14:13:09.743829
# Unit test for method copy of class HostState
def test_HostState_copy():
    #unittest_state = HostState()
    pass


# Generated at 2022-06-20 14:13:20.893228
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    # Test with test data (mocked inventory and variables), as defined in
    # test/unit/test_loader.py

    # Verify that the results are empty when there are no hosts
    iterator = PlayIterator(None, None, None)
    assert iterator.get_host_state(None) is None

    # Add a host, but no tasks
    host_state = iterator.get_host_state(inventory_localhost)
    assert host_state is not None
    assert host_state._blocks == []

    # Add a task
    task = Task()
    task.action = 'setup'
    block = Block()
    block.block = [task]
    iterator = PlayIterator(None, None, None)
    iterator.set_host_tasks(inventory_localhost, [block])

# Generated at 2022-06-20 14:13:31.532359
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    blocks = []
    state = HostState(blocks)
    assert state.__str__() == 'HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, ' \
                              'fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), ' \
                              'rescue child state? (None), always child state? (None), did rescue? False, ' \
                              'did start at task? False'


# Generated at 2022-06-20 14:13:43.114140
# Unit test for method copy of class HostState
def test_HostState_copy():
    host = HostState(
        blocks=[
            Block(
                task_include=None,
                block_parents=[],
                always_run=False,
                rescue=None,
                vars={},
                block=[
                    Task(action='common', always_run=False),
                ],
            ),
            Block(
                task_include=None,
                block_parents=[],
                always_run=False,
                rescue=None,
                vars={},
                block=[
                    Task(action='deploy', always_run=False),
                ],
            ),
        ],
    )
    host.cur_block = 0
    host.cur_regular_task = 0
    host.cur_rescue_task = 0
    host.cur_always_task = 0
    host.run_state = PlayIterator.ITER

# Generated at 2022-06-20 14:13:56.205074
# Unit test for constructor of class HostState
def test_HostState():
    blocks = []
    block = Block()

    task = Task()
    task.action = "test"
    block.block  = [ task ]

    blocks.append(block)

    host_state = HostState(blocks)
    result = display.plugin_vars(host_state)

# Generated at 2022-06-20 14:14:05.981478
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    ordered_tasks, blocks = build_blocks_from_playbook(get_playbook_path('playbook_with_include.yml'))

    host = Host(name='test_PlayIterator_cache_block_tasks_host')
    iterator = PlayIterator()
    block = blocks[0] # first block at top of playbook
    iterator.cache_block_tasks(block, host)

    # block 1
    block = blocks[0]
    assert host.name in iterator._cache, 'host is not in cache'
    assert block in iterator._cache[host.name], 'block was not cached'
    tasks = iterator._cache[host.name][block]
    assert len(tasks) == 2, 'wrong number of tasks returned'

# Generated at 2022-06-20 14:14:19.474100
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks = [
        Block([Task()]),
        Block([Task(), Task()])
    ]
    state1 = HostState(blocks)
    state2 = HostState(blocks)
    state3 = HostState(blocks)
    state3.cur_block = 1
    state3.cur_regular_task = 1
    state3.cur_rescue_task = 1
    state3.cur_always_task = 1
    state3.run_state = PlayIterator.ITERATING_ALWAYS
    state3.fail_state = PlayIterator.FAILED_SETUP
    state3.pending_setup = True
    state3.tasks_child_state = state2
    state3.rescue_child_state = state2
    state3.always_child_state = state2
    state3.did_rescue = True

# Generated at 2022-06-20 14:14:25.340836
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    block = Block()
    hosts = HostState(block)
    assert isinstance(hosts.__str__(), str)

# Generated at 2022-06-20 14:14:27.694879
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Unit test for method get_original_task of class PlayIterator
    '''
    # ToDo: Implement this unit test
    #raise NotImplementedError()


# Generated at 2022-06-20 14:14:37.498370
# Unit test for constructor of class HostState
def test_HostState():
    blocks = [
        Block(-1, -1, "tasks", None, None, None),
        Block(-1, -1, "rescue", None, None, None),
        Block(-1, -1, "always", None, None, None),
    ]

    host_state = HostState(blocks)

    assert (host_state._blocks == blocks), 'In constructor of HostState, host_state._blocks should be blocks'
    assert (host_state.cur_block == 0), 'In constructor of HostState, host_state.cur_block should be 0'
    assert (host_state.cur_regular_task == 0), 'In constructor of HostState, host_state.cur_regular_task should be 0'