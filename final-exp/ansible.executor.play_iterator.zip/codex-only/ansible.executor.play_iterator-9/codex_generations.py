

# Generated at 2022-06-22 19:54:13.901731
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # Test with a single host in the play:
    #   host1
    # and a simple block with one task:
    #   - debug: msg="This is a test"
    # which succeeds.
    #
    # marked failed on the setup step.
    # assert host1 state is FAILED_SETUP
    # assert host1 state run_state is ITERATING_COMPLETE
    # assert host1 not in get_failed_hosts
    # assert host1 state is_failed is True
    play_source = dict(
        name = "Test Play",
        hosts = 'host1',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='This is a test')))
        ]
    )


# Generated at 2022-06-22 19:54:25.923534
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    class MyTask(object):
        def __init__(self, name):
            self.name=name
            self.block = MyBlock(name)
        def get_name(self):
            return self.name
    class MyBlock(object):
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return self.name
    class MyChildState(object):
        def __init__(self, name):
            self.name = name
    def my_play_name(self):
        return "myplay"
    block1 = MyBlock("block1")
    task1 = MyTask("task1")
    task2 = MyTask("task2")
    task3 = MyTask("task3")
    task4 = MyTask("task4")
    task5 = MyTask

# Generated at 2022-06-22 19:54:28.217661
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    HostState(['test_1', 'test_2']).__eq__(HostState(['test_1', 'test_2']))


# Generated at 2022-06-22 19:54:39.169392
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    '''
    Unit test for method is_failed of class PlayIterator
    '''
    host = 'test_host'


# Generated at 2022-06-22 19:54:41.730188
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    blocks = []
    a = HostState(blocks)
    b = HostState(blocks)

    assert(a == b)


# Generated at 2022-06-22 19:54:54.010220
# Unit test for method copy of class HostState
def test_HostState_copy():
    from  ansible.playbook.block import Block
    from  ansible.playbook.task import Task
    block = Block.load(None, dict(tasks=[dict(action='task one'), dict(action='task two')]), None, None)
    blocks = [block]
    host_state = HostState(blocks)
    host_state.cur_block = 1
    host_state.cur_regular_task = 0
    host_state.cur_rescue_task = 0
    host_state.cur_always_task = 0
    host_state.run_state = PlayIterator.ITERATING_SETUP
    host_state.fail_state = PlayIterator.FAILED_NONE
    host_state.pending_setup = True
    host_state.did_rescue = False
    host_state.did_start

# Generated at 2022-06-22 19:54:55.949594
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    PlayIterator: get_next_task_for_host()
    '''
    pass

# Generated at 2022-06-22 19:55:05.318212
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    # set up a play with a single task, and a single host
    loader = DictLoader({'playbook.yml':'''
                    - name: play 1
                      hosts: all
                      tasks:
                      - name: task 1
                        debug: msg="ok"
                    ''', 'hosts': 'qwerty',})
    inventory = Inventory(loader, variable_manager=VariableManager())
    play = Play.load(dict(
        name = 'test play',
        hosts = 'testhosts',
        gather_facts = 'yes',
        tasks = [
          dict(action=dict(module='debug', args=dict(msg='ok'))),
        ]
    ), loader=loader, variable_manager=inventory._variable_manager)
    tqm = None

    iterator = PlayIterator()
    host = inventory._hosts.get

# Generated at 2022-06-22 19:55:17.350655
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    it = PlayIterator()
    it.set_play(Play())
    it.set_play_context(PlayContext())
    state = HostState()

    it._insert_tasks_into_state(state, None)
    it._insert_tasks_into_state(state, [])
    state_tasks_child_state = HostState()
    state.tasks_child_state = state_tasks_child_state
    it._insert_tasks_into_state(state, [])

    state = HostState()
    it._insert_tasks_into_state(state, [])
    state_rescue_child_state = HostState()
    state.rescue_child_state = state_rescue_child_state
    it._insert_tasks_into_state(state, [])

    state = Host

# Generated at 2022-06-22 19:55:27.744998
# Unit test for constructor of class HostState
def test_HostState():
    block1 = Block()
    block2 = Block()
    blocks = [block1, block2]
    obj = HostState(blocks)
    assert obj._blocks == blocks
    assert obj.cur_block == 0
    assert obj.cur_regular_task == 0
    assert obj.cur_rescue_task == 0
    assert obj.cur_always_task == 0
    assert obj.run_state == PlayIterator.ITERATING_SETUP
    assert obj.fail_state == PlayIterator.FAILED_NONE
    assert obj.pending_setup == False
    assert obj.tasks_child_state == None
    assert obj.rescue_child_state == None
    assert obj.always_child_state == None
    assert obj.did_rescue == False
    assert obj.did_start_at_task == False


# Generated at 2022-06-22 19:55:31.518207
# Unit test for constructor of class HostState
def test_HostState():
    blocks = ["block1", "block2", "block3"]
    hs = HostState(blocks)
    assert hs is not None

# Make sure that HostState is a value type

# Generated at 2022-06-22 19:55:37.110045
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    hostState = HostState([{"blockType":"1"}, {"blockType":"2"}, {"blockType":"3"}])
    assert hostState.get_current_block() == {"blockType":"1"}
    hostState.cur_block = 1
    assert hostState.get_current_block() == {"blockType":"2"}
    hostState.cur_block = 2
    assert hostState.get_current_block() == {"blockType":"3"}


# Generated at 2022-06-22 19:55:48.096658
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
  def fail():
    raise RuntimeError()
  def test(expected, state, block=None):
    if block:
      state._blocks[state.cur_block] = block
    actual = PlayIterator.is_any_block_rescuing(state)
    assert actual == expected, "%s != %s (state=%s, block=%s)" % (actual, expected, state, block)
  def test_block(expected, state, block_list, rescue=None, always=None):
    for block in block_list:
      block = Block(block, rescue=rescue, always=always)
      state._blocks.append(block)
      test(expected, state)
      state._blocks.pop()
  s = PlayIterator()
  state = HostState(host=Host("foo"), blocks=[])

# Generated at 2022-06-22 19:56:00.325017
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # create a play which just installs apache and mysql
    play_source =  dict(
        name = "test play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='apt', args='name=apache2 state=latest'), register='apt'),
            dict(action=dict(module='apt', args='name=mysql state=latest'), register='mysql'),
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DictDataLoader())
    play._included_file_processing()
    host_list  = [Host(name='testhost')]

# Generated at 2022-06-22 19:56:02.880735
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    # Given a HostState object
    blocks = [Block([]), Block([])]
    host_state = HostState(blocks)
    
    # When calling get_current_block method
    host_state.cur_block = 1
    block = host_state.get_current_block()
    
    # Then the block returned should be the second block of the list
    assert block == blocks[1]


# Generated at 2022-06-22 19:56:13.954530
# Unit test for method copy of class HostState
def test_HostState_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    blocks = [Block([Task().load(dict(action=dict(module='m', args=dict(a='b'))))]), 
              Block([Task().load(dict(action=dict(module='m1', args=dict(a='b'))))])]
    blocks[1].block = [Task().load(dict(action=dict(module='m2', args=dict(a='b'))))]
    blocks[1].always = [Task().load(dict(action=dict(module='m3', args=dict(a='b'))))]

# Generated at 2022-06-22 19:56:25.829129
# Unit test for constructor of class HostState
def test_HostState():
    state = HostState(['block 0', 'block 1', 'block 2'])
    assert state.cur_block == 0
    assert state._blocks == ['block 0', 'block 1', 'block 2']
    assert state.cur_regular_task == 0
    assert state.cur_rescue_task == 0
    assert state.cur_always_task == 0
    assert state.run_state == PlayIterator.ITERATING_SETUP
    assert state.fail_state == PlayIterator.FAILED_NONE
    assert state.pending_setup is False
    assert state.tasks_child_state is None
    assert state.rescue_child_state is None
    assert state.always_child_state is None
    assert state.did_rescue is False
    assert state.did_start_at_task is False

# Unit

# Generated at 2022-06-22 19:56:29.879022
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    # tests need to be able to handle: PlayIterator(play, variable_manager, loader, connections)
    pass # TODO: implement your test here


# Generated at 2022-06-22 19:56:40.716373
# Unit test for method copy of class HostState
def test_HostState_copy():
    ansible_playbook_path = '../data/ansible-playbook_data/'
    sequence = 'playbook_2'
    play_path = ansible_playbook_path + sequence
    play_data = Playbook.load(play_path, loader=play_path, variable_manager=variable_manager, loader_plugin_manager=loader_plugin_manager)
    play_ds = play_data.get_plays()[0]
    # print(play_ds._attributes['tasks'])
    blocks = []
    block = Block(play_ds, play_ds.compile())
    blocks.append(block)
    host_state = HostState(blocks)
    host_state.get_current_block()
    host_state.cur_block = 0
    host_state.cur_regular_task = 0


# Generated at 2022-06-22 19:56:43.205419
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    This is a test of the method PlayIterator.mark_host_failed
    '''
    pass


# Generated at 2022-06-22 19:56:43.877388
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    pass

# Generated at 2022-06-22 19:56:56.365315
# Unit test for method mark_host_failed of class PlayIterator

# Generated at 2022-06-22 19:57:02.953885
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    # Verify the python __eq__ method with different run_state input
    blocks = [Block.load(None, {'block': 0, 'block': 0, 'tasks': [{'debug': {'msg': 'ok'}}, {'debug': {'msg': 'ok'}}]})]
    a = HostState(blocks)
    b = HostState(blocks)
    assert a == b

    a = HostState(blocks)
    a.run_state = 1
    b = HostState(blocks)
    b.run_state = 1
    assert a == b

    a = HostState(blocks)
    a.run_state = 2
    b = HostState(blocks)
    b.run_state = 1
    assert not a == b

    # Verify the python __eq__ method with different fail_state input
    a = Host

# Generated at 2022-06-22 19:57:13.565345
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    playbook = Playbook()
    hosts = ['host1', 'host2']
    inventory = Inventory(hosts=hosts)
    host = inventory.get_host(hosts[0])
    play_context = PlayContext()


# Generated at 2022-06-22 19:57:25.491633
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = [Block([Task()]), Block([Task()])]
    assert str(HostState(blocks)) == "HostState([Block([Task(name=None, action=None, args=None, delegate_to=None, notify=None, poll=0, sudo=False, sudo_user=None, tags=None, when=None,)], always=None, rescue=None, block=None, register=None, ignore_errors=False,), Block([Task(name=None, action=None, args=None, delegate_to=None, notify=None, poll=0, sudo=False, sudo_user=None, tags=None, when=None,)], always=None, rescue=None, block=None, register=None, ignore_errors=False,)])"


# Generated at 2022-06-22 19:57:38.326097
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    import ansible
    from ansible.inventory import Inventory
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Create a mock Playbook and Play which will allow us to mock the PlayIterator
    mock_playbook = Mock()
    mock_play = Mock(Play,
                     playbook=mock_playbook,
                     hosts=Mock(Inventory),
                     _variable_manager=Mock(VariableManager),
                     _task_vars={},
                     _internal_vars={},
                     _tqm=Mock(TaskQueueManager),
                     basedir='/foo')
    
    # Create an instance of the PlayIterator, mocking the underlying Play

# Generated at 2022-06-22 19:57:48.860801
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    # Create a HostState object:
    #    HostState(_blocks=['a', 'b', 'c'], cur_block=0, cur_regular_task=0, cur_rescue_task=0, cur_always_task=0, run_state=0, fail_state=0, pending_setup=False, tasks_child_state=None, rescue_child_state=None, always_child_state=None) 
    hoststate = HostState(["a", "b", "c"])

    # Test method get_current_block
    # In this case, current block of host state is 'a'
    assert(hoststate.get_current_block() == "a")


# Generated at 2022-06-22 19:57:49.437868
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    pass

# Generated at 2022-06-22 19:57:57.470792
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    Unit test for method get_next_task_for_host of class PlayIterator
    '''
    print(test_PlayIterator_get_next_task_for_host.__doc__)

    Play.load = lambda *args, **kwargs: Play()
    Play.load.general_fail_rule = lambda *args: True
    Play.load.task_blocks = lambda *args, **kwargs: []
    Play.load.handler_blocks = lambda *args, **kwargs: []
    Play.load.roles = lambda *args, **kwargs: []

    Host = namedtuple('Host', ['name'])
    Task = namedtuple('Task', ['action', 'args'])

    host = Host('myhost')

    play = Play.load()

# Generated at 2022-06-22 19:58:09.761694
# Unit test for constructor of class PlayIterator
def test_PlayIterator():

    # test default initialization
    p = Play()
    pi = PlayIterator(p)
    assert pi._play == p
    assert pi._playbooks == None
    assert pi._play_context == pi._play._context
    assert pi._play_context.remote_addr == None
    assert pi._play_context.remote_user == None
    assert pi._play_context.remote_pass == None
    assert pi._play_context.port == None
    assert pi._host_states.keys() == []
    assert pi._host_results.keys() == []
    assert pi._iterator is None
    assert pi._last_task_banner == None
    assert pi._last_task_type == None
    assert pi._last_task_name == None
    assert pi._last_task_hosts == []
    assert pi._last_task_results

# Generated at 2022-06-22 19:58:16.652242
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    hs1 = HostState([Block()])
    hs1.cur_block = 1
    hs1.cur_regular_task = 2
    hs1.cur_rescue_task = 3
    hs1.cur_always_task = 4
    hs1.run_state = 5
    hs1.fail_state = 6
    hs1.pending_setup = True
    hs1.tasks_child_state = 123
    hs1.rescue_child_state = 345
    hs1.always_child_state = 567
    hs2 = HostState([Block()])
    hs2.cur_block = 1
    hs2.cur_regular_task = 2
    hs2.cur_rescue_task = 3
    hs2.cur_always_task

# Generated at 2022-06-22 19:58:28.508060
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    state = PlayIterator._HostState(blocks=[
        Block(
            block=[
                Task(action=dict(module='debug', args=dict(msg='foo')), name='foo'),
                Task(action=dict(module='debug', args=dict(msg='bar')), name='bar'),
            ],
            rescue=[
                Task(action=dict(module='debug', args=dict(msg='foofoo')), name='foofoo'),
                Task(action=dict(module='debug', args=dict(msg='barbar')), name='barbar'),
                ],
        )
    ])

    p = PlayIterator()

    assert p.get_active_state(state) == state
    state.cur_regular_task = 1
    assert p.get_active_state(state) == state
    state.cur_rescue_task

# Generated at 2022-06-22 19:58:38.436538
# Unit test for constructor of class HostState
def test_HostState():
    b1 = Block()
    b1.block  = [ Task() ]

    b2 = Block()
    b2.block  = [ Task() ]
    b2.rescue = [ Task() ]

    b3 = Block()
    b3.block  = [ Task() ]
    b3.always = [ Task() ]

    b4 = Block()
    b4.block  = [ Task() ]
    b4.rescue = [ Task() ]
    b4.always = [ Task() ]

    assert HostState([b1]) == HostState([b1])
    assert HostState([b1]) != HostState([b2])
    assert HostState([b1]) != HostState([b3])
    assert HostState([b1]) != HostState([b4])


# Generated at 2022-06-22 19:58:49.805943
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
  # Test case 1: the play is not active.
  play = Play()
  play.name = 'test_play'
  play.hosts = [Host(name='127.0.0.1'), Host(name='localhost')]
  play.tasks = [Task() for i in range(0, 10)]
  play.post_validate()
  iterator = PlayIterator(play)
  iterator.host_state = {}
  assert(len(iterator.get_failed_hosts()) == 0)

  # Test case 2: all hosts are active, but none has failed.
  for host in play.hosts:
    host_state = HostState()
    host_state.host = host
    host_state.task_index = 0
    host_state.fail_state = PlayIterator.FAILED_NONE

# Generated at 2022-06-22 19:58:59.870949
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host = Host("localhost")
    play = Play().load(dict(name="Test Play", hosts=["localhost"]), VariableManager(), loader=None)
    play._variable_manager = VariableManager()
    play_context = PlayContext(play=play)
    iterator = PlayIterator(play, play_context)
    host.set_variable("testvar", "testval")
    host.set_variable("testvar2", "testval2")
    host.set_variable("testvar3", "testval3")
    host.set_variable("testvar4", "testval4")
    host.set_variable("testvar5", "testval5")
    host.set_variable("testvar6", "testval6")
    host.set_variable("testvar7", "testval7")
    #
    # Setup the host state

# Generated at 2022-06-22 19:59:13.167253
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
  class C(object):
    def __init__(self):
      self.name = 'test_host'
  class D(object):
    def __init__(self, blocks=None):
      self.blocks = blocks
      self.rescue = None
      self.always = None
  class E(object): pass
  class F(object):
    def __init__(self):
      self.tasks = [E() for _ in range(4)]
  play = C()
  play.hosts = 'all'
  play.connection = 'host'
  play.remote_user = 'user'
  play.become = False
  play.become_user = None
  block0 = D(blocks=[D(blocks=[F()])])
  block1 = D(blocks=[D(blocks=[F()])])
 

# Generated at 2022-06-22 19:59:16.643803
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    # No setup needed
    # Run method
    get_result = iterator.get_next_task_for_host(host, peek=None)
    # Assert the results
    assert (get_result == None)

# Generated at 2022-06-22 19:59:28.846142
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    is_any_block_rescuing(self, state)
    '''
    loopback = False
    import ansible.playbook.block
    import ansible.playbook.task
    pb = Playbook(loader=DictDataLoader())
    p = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='ls'))
        ]
    ), variable_manager=pb._variable_manager, loader=pb._loader)


# Generated at 2022-06-22 19:59:36.378350
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class AnsiblePlaybookRun
    '''
    # prep
    host_name_1 = 'host_name_1'
    host_name_2 = 'host_name_2'
    host_1 = Host(host_name_1)
    host_2 = Host(host_name_2)
    block_1 = Block(block=['block 1'])
    block_2 = Block(block=['block 2'])
    block_3 = Block(block=['block 3'], rescue=['rescue 3'])
    playbook = Playbook([Play([block_1, block_2, block_3])])
    play_iterator = PlayIterator(playbook, playbook.playbook_files, [host_1, host_2])
    play_iterator._play._rem

# Generated at 2022-06-22 19:59:48.248394
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    expected_result = [
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task(),
        Task()
    ]
    expected_result[0].action = 'task0'
    expected_result[1].action = 'task1'
    expected_result[2].action = 'task2'
    expected_result[3].action = 'task3'
    expected_result[4].action = 'task4'
    expected_result[5].action = 'task5'
    expected_result[6].action = 'task6'
    test_block = Task()
    test_block.block = [
        expected_result[0],
        expected_result[1],
        expected_result[2]
    ]

# Generated at 2022-06-22 20:00:00.083456
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    from ansible.playbook import Play, Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestPlay(Play):
        pass

    class TestPlaybook(Playbook):
        pass
    class TestOptions(object):
        def __init__(self):
            self.verbose = True
            self.extra_vars = dict()
            self.connection = 'ssh'
    class TestCallback(object):
        def __init__(self):
            self.task = dict()
            self.task_ok = dict()
            self.task_failed = dict()
            self.task_skipped = dict()
            self.task_unreachable = dict()
            self.task_changed = dict()

# Generated at 2022-06-22 20:00:09.573459
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():

    class A:
        def __init__(self, name, state):
            self.name = name
            self.state = state

    class B:
        def __init__(self, block):
            self.block = block

    class C:
        def __init__(self, blocks):
            self.blocks = blocks

    # Simple test
    #
    # play = [ task1, task2 ]
    #
    play = [ A('task1', None), A('task2', None) ]
    pit = PlayIterator(C(blocks=play))
    (state, task) = pit.get_next_task_for_host(A('foo', None))
    assert task.name == 'task1'
    (state, task) = pit.get_next_task_for_host(A('foo', None))

# Generated at 2022-06-22 20:00:22.371936
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    mock_loader = MagicMock()
    mock_inventory = MagicMock()
    mock_variable_manager = MagicMock()
    mock_hosts = [MagicMock(name='host1'), MagicMock(name='host2')]
    mock_inventory.get_hosts.return_value = mock_hosts
    mock_play = MagicMock(loader=mock_loader, inventory=mock_inventory, variable_manager=mock_variable_manager)
    mock_play._removed_hosts = []

    play_iterator = PlayIterator(play=mock_play)
    play_iterator.mark_host_failed(mock_hosts[0])
    assert len(play_iterator.get_failed_hosts()) == 1
    assert 'host1' in play_iterator.get_failed_hosts()


# Generated at 2022-06-22 20:00:23.821219
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    assert HostState(None) == HostState(None)


# Generated at 2022-06-22 20:00:29.381310
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    play = Play()
    iterator = PlayIterator(play)
    iterator.mark_host_failed(Host('testhost'))
    assert iterator.is_failed(Host('testhost')) == True
    iterator.mark_host_failed(Host('testhost'))
    assert iterator.is_failed(Host('testhost')) == True



# Generated at 2022-06-22 20:00:36.932319
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():

    from collections import namedtuple
    from ansible.playbook.task import Task

    test_cases = []
    TestCase = namedtuple("TestCase", "name initial_state task_list expected_state expected_task")

    # Case 1
    # Initial State:
    #   run_state              : ITERATING_SETUP
    #   cur_block              : 0
    #   cur_regular_task       : 0
    #   cur_rescue_task        : 0
    #   cur_always_task        : 0
    #   fail_state             : FAILED_NONE
    #   tasks_child_state      : None
    #   rescue_child_state     : None
    #   always_child_state     : None
    #   did_rescue             : False

# Generated at 2022-06-22 20:00:47.527114
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    This test is to ensure that is_any_block_rescuing()
    correctly determines that a given host state is
    currently executing a block in rescue mode.

    This happens when we fail and continue, or when we
    continue, but only if we haven't continued out of
    the current block.
    '''
    from ansible.playbook.block import Block

    pb = HostState(blocks=[Block('')])
    pi = PlayIterator()

    # test when we're in the regular task list, but not at the end
    pb.cur_regular_task = 1
    pb.cur_block = 0
    pb.run_state = pi.ITERATING_TASKS
    pb.tasks_child_state = None

# Generated at 2022-06-22 20:00:59.339299
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockList
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    new_stdin = open(os.devnull, 'r')
    old_stdin = sys.stdin
    sys.stdin = new_stdin

    # setup a fake inventory
    class FakeVarManager():
        def get_vars(self, host, new_play=None):
            return dict()

    fake_inventory = Inventory(host_list=[])
    fake_inventory.set_variable_manager(FakeVarManager())



# Generated at 2022-06-22 20:01:00.289174
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    pass

# Generated at 2022-06-22 20:01:04.880510
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    testinput = HostState([Block([Task()])])
    expected = "HostState([" \
               "Block(['setup']," \
               "[Task(name='setup')])" \
               "])"
    assert repr(testinput) == expected


# Generated at 2022-06-22 20:01:17.568302
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Unit test for method get_original_task of class PlayIterator
    '''
    ansible_options = ansible.constants.Defaults()
    ansible_options.module_defaults = {}
    loader = ansible.vars.VarsPluginLoader(ansible_options)
    variable_manager = ansible.vars.VariableManager(loader=loader)
    variable_manager._extra_vars = {}
    variable_manager._options = ansible_options
    variable_manager.set_inventory(ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager))
    variable_manager.extra_vars = {}
    variable_manager._fact_cache = {}
    variable_manager._fact_cache_persist = []
    variable_manager._play = ansible.playbook.Play()
   

# Generated at 2022-06-22 20:01:27.351247
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    p = Play()
    blocks = [Block(block=['task1', 'task2', 'task3'])]
    hs = HostState(blocks=blocks)
    pi = PlayIterator(p)
    hs.cur_block = 0
    hs.cur_regular_task = 0
    assert pi.is_any_block_rescuing(hs) == False

    hs.run_state = pi.ITERATING_RESCUE
    hs.fail_state = hs.FAILED_TASKS
    assert pi.is_any_block_rescuing(hs) == True

    hs.tasks_child_state.cur_block = 0
    hs.tasks_child_state.cur_regular_task = 0
    hs.tasks_child_state.run_state = pi

# Generated at 2022-06-22 20:01:38.308363
# Unit test for constructor of class HostState
def test_HostState():
    test_block = Block()
    test_block._play = "test"
    test_block._parent_block = None
    test_block._role = None
    test_block._loop = None
    test_block._vars = dict(test_var="test")
    test_block._block = [dict(task1=[], rescue=[], always=[])]
    test_block._any_errors_fatal = False
    test_block.current_task = [0]
    test_block._always_run = False
    test_block._deprecated = False
    test_block._strict = False
    test_block._name = "<string>"
    test_block.fail_state = 0

    test_host_state = HostState([test_block])


# Generated at 2022-06-22 20:01:46.924871
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [Block([]), Block([]), Block([])]
    host = 'host1'
    state = HostState(blocks)
    state.cur_block = 1
    state.cur_regular_task = 2
    state.cur_rescue_task = 3
    state.cur_always_task = 4
    state.run_state = PlayIterator.ITERATING_RESCUE
    state.fail_state = PlayIterator.FAILED_RESCUE
    state.pending_setup = True
    state.did_rescue = False
    state.did_start_at_task = True
    copy = state.copy()
    assert state.cur_block == copy.cur_block
    assert state.cur_regular_task == copy.cur_regular_task

# Generated at 2022-06-22 20:01:49.507882
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = []
    hoststate = HostState(blocks)
    assert hoststate.__repr__() == "HostState(%r)" % blocks


# Generated at 2022-06-22 20:01:55.920165
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    create a play object
    initialize a iterator object by passing the play
    test the cache_block_tasks method
    '''
    _play_data = dict(
        name = "Ansible Play 0",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Task 0')), register='debug_out'),
            dict(action=dict(module='debug', args=dict(msg='Task 1')), register='debug_out'),
            dict(action=dict(module='debug', args=dict(msg='Task 2')), register='debug_out')
        ]
    )
    _play = Play().load(_play_data, variable_manager=VariableManager(), loader=loader)
    _iterator = PlayIterator(_play)

# Generated at 2022-06-22 20:02:02.241950
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    block_marker = Block()
    block = Block()
    task = Task()
    task.block = block
    block.block = block_marker
    block.tasks = [task]
    assert repr(HostState([block])) == "HostState([%r])" % block

# Generated at 2022-06-22 20:02:03.494521
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
  pass


# Generated at 2022-06-22 20:02:15.549816
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    # host is a fake host
    host = Host(name='host')
    # play is a fake play
    play = Play.load(dict(
        name = "fake play",
        hosts = 'host',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    # play_context is a fake play_context
    play_context = PlayContext()

    # play_iterator is the object to be tested
    play_iterator = PlayIterator(play, play_context)

    # Create a HostState object for testing
    task_state = Host

# Generated at 2022-06-22 20:02:26.491043
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # FIXME: This unit test should be done outside of Ansible core as a proper unit test.
    import unitsh
    unitsh.setup()
    p = Play().load(dict(
            name = "test play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
                ]
            ), loader=None, variable_manager=None)
    h = Host(name='fake_host')

    # test inserting tasks before the host's current position
    itr = PlayIterator(p, inventory=Inventory(loader=None, hosts=['fake_host']))

# Generated at 2022-06-22 20:02:34.423713
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Ensure mark_host_failed correctly sets the task state and removes host
    '''
    play = Play().load('test/playbooks/minimal.yaml', variable_manager=VariableManager(), loader=set_loader())
    play_iterator = PlayIterator()

    pb_hosts = play._entries.get('play')
    host1 = pb_hosts[0]
    host2 = pb_hosts[1]
    host3 = pb_hosts[2]

    # test that a host is set to failed correctly
    task1 = dict(action='task1 action')
    task2 = dict(action='task2 action')
    task3 = dict(action='task3 action')
    task4 = dict(action='task4 action')
    task5 = dict(action='task5 action')
   

# Generated at 2022-06-22 20:02:46.840559
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    block1 = Block(None, None, None, None, None)
    block2 = Block(None, None, None, None, None)
    block3 = Block(None, None, None, None, None)
    block4 = Block(None, None, None, None, None)
    block5 = Block(None, None, None, None, None)
    block6 = Block(None, None, None, None, None)
    block7 = Block(None, None, None, None, None)
    block8 = Block(None, None, None, None, None)
    block9 = Block(None, None, None, None, None)
    block10 = Block(None, None, None, None, None)
    block11 = Block(None, None, None, None, None)

# Generated at 2022-06-22 20:02:51.485604
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    blocks = [
        Block(
            task_include=Task.load(
                None,
                dict(
                    name='task test',
                )
            )
        )
    ]
    state = HostState(blocks)
    assert state.get_current_block() == blocks[0]


# Generated at 2022-06-22 20:03:03.514696
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [Block([]), Block([]), Block([])]
    h = HostState(blocks)
    h.cur_block = 1
    h.cur_regular_task = 2
    h.cur_rescue_task = 3
    h.cur_always_task = 4
    h.run_state = PlayIterator.ITERATING_TASKS
    h.fail_state = PlayIterator.FAILED_SETUP
    h.pending_setup = True
    h.did_rescue = True
    h.did_start_at_task = False
    h.tasks_child_state = None
    h.rescue_child_state = None
    h.always_child_state = None
    h1 = h.copy()
    assert h != h1



# Generated at 2022-06-22 20:03:06.768915
# Unit test for method copy of class HostState
def test_HostState_copy():
    blocks = [Block.load(dict(tasks=[dict(action=dict(module='test'))]))]
    h = HostState(blocks)
    new_state = h.copy()
    assert h == new_state


# Generated at 2022-06-22 20:03:12.402280
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    block_1 = Block()
    block_2 = Block()
    block_3 = Block()

    host_state=HostState([block_1,block_2,block_3])
    host_state.cur_block = 0
    assert(host_state.get_current_block() == block_1)
    host_state.cur_block = 1
    assert(host_state.get_current_block() == block_2)
    host_state.cur_block = 2
    assert(host_state.get_current_block() == block_3)

# Generated at 2022-06-22 20:03:23.430510
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
  play_name = 'foo'
  sentinel = object()
  state = sentinel

  play = MagicMock(name='play', spec=Play)
  play.name = play_name
  host = MagicMock(name='host', spec=Host)
  host.name = 'host_name'
  task = MagicMock(name='task', spec=Task)
  task_list = [task]
  state_entry = MagicMock(name='state_entry', spec=HostState)
  state_entry.run_state = 'run_state'
  state_entry.fail_state = 'fail_state'
  state_entry.tasks_child_state = 'tasks_child_state'
  state_entry.rescue_child_state = 'rescue_child_state'
  state_entry.always_

# Generated at 2022-06-22 20:03:33.980854
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    def check_results(state):
        active = p._get_active_state(state)
        active_list = [a.index for a in active.index]
        index_list = [i.index for i in state.index]
        assert active_list == index_list, 'Index mismatch (%s != %s)' % (active_list, index_list)
        return active

    p = PlayIterator()
    s = HostState(blocks=[])
    assert p._get_active_state(s).run_state == PlayIterator.ITERATING_COMPLETE, 'State was not marked complete'
    s = HostState(blocks=[Block()])
    s.run_state = PlayIterator.ITERATING_TASKS
    s.cur_block = 0
    assert p._get_active_state(s).run_state == PlayIterator

# Generated at 2022-06-22 20:03:36.317645
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    state = HostState([Block([Task()])])
    assert repr(state) == "HostState([Block(tasks=[Task()])])"


# Generated at 2022-06-22 20:03:37.990766
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    pass



# Generated at 2022-06-22 20:03:40.652149
# Unit test for method copy of class HostState
def test_HostState_copy():
    test_object = HostState([])
    assert test_object.copy() == test_object
    assert test_object.copy() is not test_object



# Generated at 2022-06-22 20:03:53.320397
# Unit test for constructor of class HostState
def test_HostState():
    blocks = [Block(
        task_include={"tasks": []},
        rescue=[]
    )]

    host_state = HostState(blocks)
    assert host_state._blocks == blocks
    assert host_state.cur_block == 0
    assert host_state.cur_regular_task == 0
    assert host_state.cur_rescue_task == 0
    assert host_state.cur_always_task == 0
    assert host_state.run_state == PlayIterator.ITERATING_SETUP
    assert host_state.fail_state == PlayIterator.FAILED_NONE
    assert host_state.pending_setup is False
    assert host_state.tasks_child_state is None
    assert host_state.rescue_child_state is None
    assert host_state.always_child_state is None

# Generated at 2022-06-22 20:03:58.972743
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    # test simple one level, running state
    hi = HostInfo()
    hi.vars = dict(ansible_ssh_user='testuser')
    hi.groups = ['group1']
    ha = Host("testhost", "testhost")
    pi = PlayIterator("testplay", ha, None, None)
    pi._host_states['testhost'] = HostState(host=ha)
    pi._host_states['testhost'].run_state = pi.ITERATING_TASKS
    assert not pi.is_failed(ha)

    # test three levels
    pi._host_states['testhost'] = HostState(host=ha, blocks=[Block(rescue=[], always=[])])
    pi._host_states['testhost'].run_state = pi.ITERATING_RESCUE
    pi._host_states

# Generated at 2022-06-22 20:04:03.426391
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    h = MagicMock()
    play = MagicMock()
    blocks = [Block(role=None)]
    iterator = PlayIterator(play)
    assert iterator.get_host_state(h) is None
