

# Generated at 2022-06-22 19:54:11.342182
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    '''
    Ensure PlayIterator.get_next_task_for_host returns the correct task
    '''
    if C.TEST_LOG_PROTOCOL:
        def vvv(msg, host=None):
            global play_logger
            play_logger.test_vvv(msg, host)
        display.vvv = vvv
        global play_logger
        play_logger = PlayLogger()
    global play_context
    play_context = PlayContext()


# Generated at 2022-06-22 19:54:23.227726
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
	play = Play.load(dict(
				name = 'test play',
				hosts = 'localhost',
				gather_facts = 'no',
				tasks = [dict(action='debug', msg='hello world'),
                                 dict(action='debug', msg='hello world', register='debug_register')]
				), 
				play_basedirs=[os.path.join(os.path.dirname(__file__), '../../test_playbooks')]
				)

# Generated at 2022-06-22 19:54:31.171830
# Unit test for constructor of class HostState
def test_HostState():
    # Setup
    blocks = [
        Block(
            tasks=[
                Task(name='test_task_1'),
                Task(name='test_task_2'),
            ],
            rescue=Block(
                tasks=[
                    Task(name='test_rescue_task_1'),
                    Task(name='test_rescue_task_2'),
                ],
            ),
            always=Block(
                tasks=[
                    Task(name='test_always_task_1'),
                    Task(name='test_always_task_2'),
                ],
            ),
        ),
    ]

    # Test
    state = HostState(blocks)

    # Verify
    assert state.cur_block == 0
    assert state.cur_regular_task == 0
    assert state.cur_rescue_task == 0
    assert state.cur_always

# Generated at 2022-06-22 19:54:39.809876
# Unit test for constructor of class HostState
def test_HostState():
    blocks = ['block1', 'block2']
    a = HostState(blocks)
    assert a._blocks == blocks
    assert a.cur_block == 0
    assert a.cur_regular_task == 0
    assert a.cur_rescue_task == 0
    assert a.cur_always_task == 0
    assert a.run_state == PlayIterator.ITERATING_SETUP
    assert a.fail_state == PlayIterator.FAILED_NONE
    assert a.pending_setup == False
    assert a.tasks_child_state == None
    assert a.rescue_child_state == None
    assert a.always_child_state == None


# Generated at 2022-06-22 19:54:52.450086
# Unit test for constructor of class HostState

# Generated at 2022-06-22 19:55:03.810181
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    display.verbosity = 3
    host = FakeHost()
    host.name = 'myhost'
    play = Play().load(dict(
        name = "test play",
        hosts = 'webservers',
        gather_facts = 'no',
        roles = [ 'test_role' ],
        tasks = [
            dict(action=dict(module='shell', args='echo 1'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')), when='shell_out is defined')
        ]
    ), variable_manager=variable_manager, loader=loader)

    itr = PlayIterator()
    itr.play = play

    results = itr.get_next_task_for_host(host)

# Generated at 2022-06-22 19:55:14.835958
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Test get_original_task of class PlayIterator
    '''
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ description }}'))),
            dict(action=dict(module='debug', args=dict(msg='{{ instructions }}'))),
            dict(action=dict(module='debug', args=dict(msg='{{ name }}'))),
        ]
    ), variable_manager=variable_manager, loader=None)
    tqm = None

# Generated at 2022-06-22 19:55:27.256848
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Test PlayIterator is_any_block_rescuing
    '''
    from ansible.playbook.play import Play

    play = Play().load(dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
        ]
    ), variable_manager=VariableManager(), loader=DataLoader())
    iterator = PlayIterator(play)

    # test a failed block

# Generated at 2022-06-22 19:55:34.134238
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    # instantiate an object for testing
    pb_instance = Playbook().load(os.path.realpath(__file__))
    pi_instance = PlayIterator(pb_instance.get_plays()[0])
    # call mark_host_failed on a host that has no state
    result = pi_instance.mark_host_failed("TEST_HOST")
    assert result == None
    result = pi_instance.mark_host_failed("TEST_HOST")
    assert result == None
    # assert that we get False when we call is_failed on this host
    result = pi_instance.is_failed("TEST_HOST")
    assert result == False
    # add a host with state to our host_states
    pi_instance._host_states["TEST_HOST_2"] = HostState(blocks=[])


# Generated at 2022-06-22 19:55:36.608186
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    blocks = []
    host_state = HostState(blocks)
    print(host_state)
    print(repr(host_state))
    return

# Generated at 2022-06-22 19:55:47.748971
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():

    # Construct a mock_task for the 'task' function
    original_task = PlayIterator.task
    original_add_tasks = PlayIterator.add_tasks

    # Set up necessary mocks
    class mock_task(object):

        def __init__(self):
            pass

    # Construct necessary mocks
    task = mock_task()

    # Set up mock returns
    task_mock_return = None

    # Set up mocks
    PlayIterator.task = Mock(return_value=task_mock_return)
    PlayIterator.add_tasks = Mock(return_value=None)

    # Set up object to test
    playiterator_obj = PlayIterator()

    # Exercise the function
    playiterator_obj.get_host_state(host=None)

    # Verify the mocks
    PlayIterator.task

# Generated at 2022-06-22 19:56:00.202716
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    import unittest

    class TestPlay_get_failed_hosts(unittest.TestCase):
        def test_get_failed_hosts(self):
            pass

    global test_get_failed_hosts
    test_get_failed_hosts = TestPlay_get_failed_hosts()
    from unit.test_loader import LoaderModuleMock
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    import ansible.inventory.manager
    from ansible.utils.vars import combine_vars
    from collections import deque
    import ansible.vars.manager
    import ansible.vars.hostvars


# Generated at 2022-06-22 19:56:06.645172
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    execution_block1 = Block()
    execution_block2 = Block()
    execution_block1.add_task(Task())
    execution_block1.add_task(Task())
    execution_block2.add_task(Task())
    execution_block2.add_task(Task())
    host_state = HostState([execution_block1,execution_block2])
    assert host_state.get_current_block() == execution_block1


# Generated at 2022-06-22 19:56:16.128135
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():    
    blocks = []
    test_state = HostState(blocks)
    test_state.cur_block = 1
    test_state.cur_regular_task = 1
    test_state.cur_rescue_task = 1
    test_state.cur_always_task = 1
    test_state.run_state = PlayIterator.ITERATING_TASKS
    test_state.fail_state = PlayIterator.FAILED_TASKS
    test_state.pending_setup = True
    test_state.did_rescue = True
    test_state.did_start_at_task = True

    expected_string = "HostState([])"
    assert test_state.__repr__() == expected_string


# Generated at 2022-06-22 19:56:25.996787
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    blocks = [Block(task_include='task_1'), Block(task_include='task_2')]

    h1 = HostState(blocks)
    h2 = HostState(blocks)
    h1.cur_block = 0
    h2.cur_block = 1

    current_block_h1 = h1.get_current_block()
    current_block_h2 = h2.get_current_block()

    assert current_block_h1.task_include == 'task_1'
    assert current_block_h2.task_include == 'task_2'



# Generated at 2022-06-22 19:56:28.240469
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    # Test with a simple value.
    blocks = ["asd", "asd", "asd"]
    host_state = HostState(blocks)
    assert str(host_state) == "HOST: asd"
    assert repr(host_state) == "HOST: asd"


# Generated at 2022-06-22 19:56:37.103113
# Unit test for constructor of class HostState
def test_HostState():
    blocks = [Block(task_include='tasks/main.yml', role=None)]
    h = HostState(blocks)
    assert h.cur_block == 0
    assert h.cur_regular_task == 0
    assert h.cur_rescue_task == 0
    assert h.cur_always_task == 0
    assert h.run_state == PlayIterator.ITERATING_SETUP
    assert h.fail_state == PlayIterator.FAILED_NONE
    assert h.pending_setup == False
    assert h._blocks == blocks


# Generated at 2022-06-22 19:56:40.196175
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''
    pass
    # TODO
    #raise AnsibleError("unimplemented test case for method")

# Generated at 2022-06-22 19:56:46.139057
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    host1 = Host('host1')
    host2 = Host('host2')
    play = Play.load({'hosts': ['host1', 'host2']})
    play.iterator = PlayIterator(play)
    play.iterator.mark_host_failed(host1)
    play.iterator.mark_host_failed(host2)
    assert play.iterator.is_failed(host1)
    assert play.iterator.is_failed(host2)


# Generated at 2022-06-22 19:56:57.166061
# Unit test for method __eq__ of class HostState

# Generated at 2022-06-22 19:57:00.278710
# Unit test for method get_next_task_for_host of class PlayIterator
def test_PlayIterator_get_next_task_for_host():
    block = Block()
    block.block = [dict(action='skip'), dict(action='skip')]
    host = Mock()
    host.name = 'fake_host'
    play = Mock(spec=Play)
    play.get_blocks.return_value = [block]
    iterator = PlayIterator(play)
    iterator.get_next_task_for_host(host)


# Generated at 2022-06-22 19:57:08.554448
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    state = HostState([])
    assert repr(state) == "HostState([])"
    assert str(state) == ("HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False")


# Generated at 2022-06-22 19:57:20.852498
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    '''
    Test get_active_state of class PlayIterator
    '''
    # Initialize some variables
    host = MagicMock()
    display.verbosity = 3
    checkmode = False
    iterator = PlayIterator(None)
    iterator._tqm = None
    iterator._inventory = None
    iterator._last_task_banner = None
    iterator._last_task_name = None
    iterator._last_task_host = None

    # Test get_active_state(0)
    state = HostState(blocks=[])
    state.run_state = iterator.ITERATING_COMPLETE
    assert iterator.get_active_state(state) == state

    # Test get_active_state(1)
    state = HostState(blocks=[])
    state.run_state = iterator.ITERATING_ALWAYS


# Generated at 2022-06-22 19:57:31.825876
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
  '''
  Test that PlayIterator works as expected with regard to the method add_tasks.
  '''
  from ansible.playbook.play import Play
  from ansible.playbook.block import Block
  from ansible.playbook.task import Task
  from ansible.playbook.role import Role
  from ansible.playbook.role.include import RoleInclude
  from ansible.playbook.task import Task


# Generated at 2022-06-22 19:57:36.307673
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    # tests a regular expression match
    assert re.match(r"HostState\(\[\]\)", repr(HostState(None)))
    assert re.match(r"HostState\(.+\)", repr(HostState([])))


# Generated at 2022-06-22 19:57:47.209046
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():
    host = MagicMock()
    host.name = 'foo'
    play = MagicMock()
    play.vars = dict()
    play.vars_prompt = dict()
    play.vars_files = list()
    play.vars_prompt.values = list()
    play.vars_files.values = list()
    play.default_vars = dict()
    play.handlers = dict()
    play.get_vars = MagicMock()
    play.get_vars.return_value = dict()
    play.hosts = 'hosts'
    play.serial = 0
    play.iterator = 'iterator'
    play.get_variables = MagicMock()
    play.get_variables.return_value = dict()
    play.host_vars_files = dict()

# Generated at 2022-06-22 19:57:56.421778
# Unit test for method get_failed_hosts of class PlayIterator
def test_PlayIterator_get_failed_hosts():

    # Setup
    play = Play.load(dict(
        name="foobar play",
        hosts=dict(all=dict()),
        vars=dict(),
        tasks=[]
    ), variable_manager=VariableManager())
    play.post_validate(_play_ds=play._play_ds, variable_manager=play._variable_manager)
    pi = PlayIterator()
    pi._play = play

    mock_play = MagicMock(spec=Play)

# Generated at 2022-06-22 19:58:08.814655
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host = Host(name="test_host_ok")
    inventory = Inventory(host_list=[host])

# Generated at 2022-06-22 19:58:11.970974
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():

    host_state_test = HostState([1,2,3])
    assert host_state_test == HostState([1,2,3]), "Unit test of _repr__ of class HostState failed."

# Generated at 2022-06-22 19:58:22.471121
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    # An exception must be generated in case of unequal types of objects being compared
    try:
        assert HostState([]) == Block()
    except:
        assert True
    # Testing equality of two identical objects
    blocks = [Block([Task()])]
    hs_4 = HostState(blocks)
    assert HostState(blocks) == hs_4
    # Testing inequality of two objects
    hs_5 = hs_4.copy()
    hs_5.cur_block = 100
    assert HostState(blocks) != hs_5


# Generated at 2022-06-22 19:58:32.426920
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    '''
    unit test for PlayIterator.get_host_state
    '''
    from ansible.playbook.play import Play

    play = Play().load({'name': 'testplay'}, variable_manager={}, loader=None)
    pi = PlayIterator(play)
    h = Host('foobar')
    hs = HostState(host=h)
    pi._host_states[h.name] = hs
    hs2 = pi.get_host_state(h)
    assert hs is hs2
    assert hs2.host.name == h.name
    print("created HostState=%s" % repr(hs2))


# Generated at 2022-06-22 19:58:38.885727
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
  # Add a play, a play iterator and tasks
  play1 = Play()
  play2 = Play()
  play_iterator = PlayIterator(None, [play1, play2])
  task1 = Task()
  task2 = Task()
  play1.add_task(task1)
  play2.add_task(task2)
  # Test
  assert play_iterator._play == play1


# Generated at 2022-06-22 19:58:44.129546
# Unit test for constructor of class HostState
def test_HostState():
    block = Block()
    block.block  = [{ "action": { "__ansible_module__": "setup" } }]
    block.rescue = [{ "action": { "__ansible_module__": "noop" } }]
    blocks = [block]
    host_state = HostState(blocks)
    assert host_state.get_current_block() == block



# Generated at 2022-06-22 19:58:55.757975
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
	play = Play()
	play.iterator = PlayIterator(play=play)
	play.iterator._host_states[None] = HostState(blocks=[Block(block=[Task()])])
	state = play.iterator._host_states[None]
	state.run_state = PlayIterator.ITERATING_TASKS
	state.tasks_child_state = HostState(blocks=[Block(block=[Task()])])
	state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
	state.tasks_child_state.tasks_child_state = HostState(blocks=[Block(block=[Task()])])
	state.tasks_child_state.tasks_child_state.run_state = PlayIterator.ITERATING_TASKS
	active_state = play.iterator.get

# Generated at 2022-06-22 19:59:03.620732
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Unit test for method cache_block_tasks of class PlayIterator.
    '''
    # initialize a play object, which is required by the constructor of PlayIterator
    play = Play()
    # initialize a play iterator object
    play_iterator = PlayIterator(play)
    # initialize a block object
    block = Block()
    # initialize a tasks dictionary to be used as a test argument
    tasks = {}
    # call cache_block_tasks() to cache a block of tasks for a particular host
    play_iterator.cache_block_tasks('test-host', block, tasks)

# Generated at 2022-06-22 19:59:04.639827
# Unit test for constructor of class HostState
def test_HostState():
    assert HostState([])


# Generated at 2022-06-22 19:59:14.854893
# Unit test for method __str__ of class HostState
def test_HostState___str__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    blocks = [Block(Block.TASKS, [Task().load(dict(action='setup'))])]
    host_state = HostState(blocks)
    assert str(host_state) == ("HOST STATE: block=0, task=0, rescue=0, always=0, run_state=ITERATING_SETUP, fail_state=FAILED_NONE, pending_setup=False, tasks child state? (None), rescue child state? (None), always child state? (None), did rescue? False, did start at task? False")


# Generated at 2022-06-22 19:59:25.756541
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    # test that block is replaced correctly
    test_block = Block(task_include='/path/to/foo')
    hi = HostState(blocks=[test_block])
    hi_after = HostState(blocks=[test_block])
    hi_after._blocks[0].block = [u'added new task'] + hi_after._blocks[0].block
    pi = PlayIterator(play=None)
    test_host = Host('localhost')
    pi._host_states[test_host.name] = hi
    pi.add_tasks(test_host, [u'added new task'])
    assert pi.get_host_state(test_host) == hi_after


# Generated at 2022-06-22 19:59:30.528983
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    print("Testing method add_tasks of class PlayIterator")
    # we should have tests here
    # !!! more tests required !!!
    # !!! we should test various play states (setup, task, rescue, always) !!!
    # !!! we should test various block states (setup, task, rescue, always) !!!


# Generated at 2022-06-22 19:59:38.414330
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    print('Testing get_active_state...')
    pi = PlayIterator()
    hs = HostState(blocks=[])

    # state.run_state is ITERATING_ALWAYS and always_child_state is not None
    hs.run_state = PlayIterator.ITERATING_ALWAYS
    hs.always_child_state = HostState(blocks=[])
    assert pi.get_active_state(hs) == hs.always_child_state
    hs.always_child_state.run_state = PlayIterator.ITERATING_COMPLETE
    assert pi.get_active_state(hs) == hs.always_child_state

    # state.run_state is ITERATING_RESCUE and rescue_child_state is not None
    hs.run_state = PlayIterator.ITERATING_RESC

# Generated at 2022-06-22 19:59:49.353668
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    from ansible.playbook import Play, Playbook, PlaybookIterator
    from ansible.task import Task
    from ansible.playbook.block import Block

    host_state = HostState(blocks=[Block(block=['one'])])
    host_state.run_state = PlayIterator.ITERATING_TASKS
    host_state.cur_regular_task = 0

    # Test adding tasks to the start of a block
    host_state = PlayIterator._insert_tasks_into_state(host_state, ['start'])
    assert host_state._blocks[0].block == ['start', 'one']

    host_state.cur_regular_task = 1

    # Test adding tasks to the middle of a block
    host_state = PlayIterator._insert_tasks_into_state(host_state, ['middle'])


# Generated at 2022-06-22 20:00:00.998751
# Unit test for method mark_host_failed of class PlayIterator
def test_PlayIterator_mark_host_failed():
    '''
    Unit test for method mark_host_failed of class PlayIterator
    '''
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play = Play().load(dict(name='test_play',
                            hosts='hosts',
                            gather_facts=True,
                            tasks=[dict(action=dict(module='foo', args=dict(x=1))),
                                   dict(action=dict(module='foo', args=dict(x=2)))]),
                        variable_manager=play_context.variable_manager, loader=play_context.loader)

# Generated at 2022-06-22 20:00:08.293407
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    '''
    Unit test for method get_original_task of class PlayIterator
    '''
    iterator = PlayIterator(Play().load(load_fixture('play_iteration_test.yaml'), variable_manager=VariableManager()))
    results = []
    for host, task in iterator.get_original_task(('host1', 'host2')):
        results.append((host.name, task.action))

    assert results == [('host1', 'setup'),
                       ('host1', 'task1'),
                       ('host1', 'task2'),
                       ('host2', 'setup'),
                       ('host2', 'task1'),
                       ('host2', 'task2')]



# Generated at 2022-06-22 20:00:09.388133
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    pass

# Generated at 2022-06-22 20:00:18.433617
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    #"""
    #Test get_active_state of class PlayIterator
    #
    #:return:
    #"""
    b1 = Block()
    b2 = Block(block=b1)
    b3 = Block(block=b2)
    b4 = Block(block=b3)
    b5 = Block(block=b4)
    b6 = Block(block=b5)

    active_state = PlayIterator.get_active_state(b3)

    assert(active_state == b3)


# Generated at 2022-06-22 20:00:30.110234
# Unit test for constructor of class HostState
def test_HostState():
    host, blocks = 'host', [Block(role=None)]
    h = HostState(blocks)
    assert h._blocks == blocks
    assert h.blocks == blocks
    assert h.cur_block == 0
    assert h.cur_regular_task == 0
    assert h.cur_rescue_task == 0
    assert h.cur_always_task == 0
    assert h.run_state == PlayIterator.ITERATING_SETUP
    assert h.fail_state == PlayIterator.FAILED_NONE
    assert h.pending_setup == False
    assert h.tasks_child_state == None
    assert h.rescue_child_state == None
    assert h.always_child_state == None
    assert h.did_rescue == False
    assert h.did_start_at_task == False




# Generated at 2022-06-22 20:00:41.492444
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    # set up const object
    testHost = HostState([])
    testEqual = True
    testHost.cur_block = 1
    testHost.cur_regular_task = 2
    testHost.cur_rescue_task = 3
    testHost.cur_always_task = 4
    testHost.run_state = 5
    testHost.fail_state = 6
    testHost.pending_setup = 7
    testHost.tasks_child_state = 8
    testHost.rescue_child_state = 9
    testHost.always_child_state = 10
    testHost.did_rescue = 11
    testHost.did_start_at_task = 12

    # set up test object
    testObject = HostState([])

    # declare function output
    function_output = None

    # call function
   

# Generated at 2022-06-22 20:00:48.523580
# Unit test for method add_tasks of class PlayIterator
def test_PlayIterator_add_tasks():
    host = 'hostname'
    task_list = []
    state = HostState(hostname=host, task_list=[])
    state = HostState(hostname=host, task_list=[])
    pi = PlayIterator(None)
    # There is probably a better test for this, but we don't test the rest of
    # the methods, so it's better than nothing.  :)
    assert pi._insert_tasks_into_state(state, task_list) is not None
    return True


# Generated at 2022-06-22 20:00:50.185643
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    # There is not enough functionality yet to be able to test.
    pass


# Generated at 2022-06-22 20:01:01.333149
# Unit test for method copy of class HostState
def test_HostState_copy():
    host_state = HostState('_blocks')
    host_state.cur_block = 'cur_block'
    host_state.cur_regular_task = 'cur_regular_task'
    host_state.cur_rescue_task = 'cur_rescue_task'
    host_state.cur_always_task = 'cur_always_task'
    host_state.run_state = 'run_state'
    host_state.fail_state = 'fail_state'
    host_state.pending_setup = 'pending_setup'
    host_state.did_rescue = 'did_rescue'
    host_state.did_start_at_task = 'did_start_at_task'
    assert host_state.copy() == host_state



# Generated at 2022-06-22 20:01:14.667445
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    make sure that block tasks get cached properly
    '''

# Generated at 2022-06-22 20:01:25.595494
# Unit test for method copy of class HostState
def test_HostState_copy():
    class MyHostState(HostState):
        def __init__(self, x):
            super(MyHostState, self).__init__(x)
    h = MyHostState([0, 1])
    assert h.cur_block == 0
    assert h.tasks_child_state is None
    assert h.rescue_child_state is None
    assert h.always_child_state is None
    assert h.copy().tasks_child_state is None
    assert h.copy().rescue_child_state is None
    assert h.copy().always_child_state is None
    # assert h.copy() == MyHostState([0, 1])
    h.cur_block = 1
    h.tasks_child_state = 'tasks_child_state'

# Generated at 2022-06-22 20:01:30.212638
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    p = Play().load('test/test_playbooks/include_vars.yml', 'test', loader=BaseLoader())
    pi = PlayIterator(p)
    assert not pi._play.handlers
    assert pi._play.tasks


# Generated at 2022-06-22 20:01:40.788583
# Unit test for constructor of class PlayIterator
def test_PlayIterator():
    '''
    This test asserts that the constructor of PlayIterator creates the
    following attributes:
    1) playbook (where the attributes of a playbook can be accessed)
    2) hosts (contains the list of hosts in the inventory)
    3) vars_manager (contains information about variables to be used for the
                     play)
    4) iterator (is an instance of HostState)
    '''
    loader = DictDataLoader({
        "hello.yml": """
        - hosts: all
          tasks:
            - ping:
        """
    })
    play = Play.load(dict(name="hello play", hosts=['localhost'], gather_facts='no'), loader=loader, variable_manager=VariableManager())

    play_iterator = PlayIterator()
    play_iterator.vars_manager = VariableManager()

# Generated at 2022-06-22 20:01:52.265217
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    '''
    Unit test for method cache_block_tasks of class ansible.executor.play_iterator.PlayIterator
    '''
    from ansible.playbook import Play, Task, RoleTask
    from ansible.playbook.block import Block
    from ansible.inventory import Host, Inventory, Group
    from ansible.vars import VariableManager

    # create empty play
    play = Play()
    play._included_files = dict()
    play.basedir = 'test'
    play.hosts = Host('hostname')
    play.hosts.name = 'hostname'
    play.hosts.groups = dict()
    play.hosts.groups['groupname'] = Group('groupname')

    # create tasks
    task1 = Task()
    task1._attributes = dict()
    task1._parent

# Generated at 2022-06-22 20:01:59.744174
# Unit test for method get_original_task of class PlayIterator
def test_PlayIterator_get_original_task():
    def _get_ids(task):
        return [(isinstance(b, Block), id(b)) for b in task]
    #### Test a simple non-nested block
    # With an empty task list, the original task should be None
    tasks = [Block(None, [])]
    p = PlayIterator(tasks, {})
    assert (None, None) == p.get_original_task(Host('localhost'), tasks[0].block[0])
    # With a single task, the original task should be the task itself
    tasks = [Block(None, [Task()])]
    p = PlayIterator(tasks, {})

# Generated at 2022-06-22 20:02:00.963753
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    pass



# Generated at 2022-06-22 20:02:06.614674
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    print("Test start: method __repr__ of class HostState")
    try:
        # simple example
        blocks = ['a', 'b', 'c']
        HS = HostState(blocks)
        print("Test passed")
    except:
        print("Test failed")
    return
test_HostState___repr__()


# Generated at 2022-06-22 20:02:08.718203
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    block = Block()
    host_state = HostState([block])
    assert(host_state.get_current_block() == block)

# Generated at 2022-06-22 20:02:16.509764
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    host = Host('host')
    state = HostState(host=host)
    state.run_state = PlayIterator.ITERATING_TASKS
    child_state_1 = HostState(host=host)
    child_state_1.run_state = PlayIterator.ITERATING_RESCUE
    child_state_2 = HostState(host=host)
    child_state_2.run_state = PlayIterator.ITERATING_ALWAYS
    state.tasks_child_state = child_state_1
    child_state_1.tasks_child_state = child_state_2

    expected = True
    result = PlayIterator.is_any_block_rescuing(state)
    assert result == expected, "expected %s but got %s" % (expected, result)

# test method is_any

# Generated at 2022-06-22 20:02:27.294833
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    '''
    Unit test for method is_any_block_rescuing of class PlayIterator
    '''
    # The tests here are mostly just checking that it returns True when we expect it to, and
    # False when we expect it to. The logic inside the method is tested more thoroughly elsewhere.
    play_iterator = PlayIterator()
    play_iterator._blocks = [Block(rescue=[])]

    play_iterator._host_states = {
        'test': HostState(blocks=play_iterator._blocks),
    }
    play_iterator._host_states['test'].run_state = ITERATING_TASKS
    play_iterator._host_states['test'].tasks_child_state = HostState(blocks=play_iterator._blocks)
    play_iterator._host_states['test'].tasks_child_state.run

# Generated at 2022-06-22 20:02:34.930704
# Unit test for method get_current_block of class HostState
def test_HostState_get_current_block():
    # We need to create a fake play, as the HostState objects
    # are created from a play.
    fakePlay = Block(serial=None)

    # We fake a block for this unit test
    fakeBlock = Block(serial=None)
    # Set block name to "fake"
    fakeBlock.block = ["fake"]
    # Set the block to execute "if host is fakehost"
    fakeBlock.when = "fakehost in fakehostgroup"
    # Fake a task in the block
    fakeTask = Task()
    fakeTask.name = "fake task"
    fakeTask.action = "fake action module"
    fakeTask.when = "fakehost in fakehostgroup"
    # Set the task to the block
    fakeBlock.block = [fakeTask]
    # Add the fake block to the fake play

# Generated at 2022-06-22 20:02:46.973486
# Unit test for method is_any_block_rescuing of class PlayIterator
def test_PlayIterator_is_any_block_rescuing():
    #
    # first test: block not rescuing
    #

    # setup
    b = Block(play=playbook_succeeds(''))

    hs = HostState(blocks=[b])

    # test
    if PlayIterator.is_any_block_rescuing(hs):
        print("FAILED: block not rescuing")

    #
    # second test: block in rescue
    #

    # setup
    hs.run_state = PlayIterator.ITERATING_RESCUE

    # test
    if not PlayIterator.is_any_block_rescuing(hs):
        print("FAILED: block in rescue")

    #
    # third test: child block in rescue
    #

    # setup
    b = Block(play=playbook_succeeds(''))
    b2 = Block

# Generated at 2022-06-22 20:02:54.948024
# Unit test for method cache_block_tasks of class PlayIterator
def test_PlayIterator_cache_block_tasks():
    host = Host(name='192.168.1.1')
    block = Block(block=['block'])
    play = Play()
    play.hosts = ['192.168.1.1']
    play.tasks = block
    iterator = PlayIterator(play)
    iterator.cache_block_tasks(host.name, block, play.basedir)
    utils.assertEqual(dict, type(iterator._host_blocks_tasks_cache))
    utils.assertEqual(1, len(iterator._host_blocks_tasks_cache))
    utils.assertEqual(dict, type(iterator._host_blocks_tasks_cache[host.name]))
    utils.assertEqual(1, len(iterator._host_blocks_tasks_cache[host.name]))

# Generated at 2022-06-22 20:03:07.316973
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    play = Play().load(dict(
        name = "test play",
        hosts = 'test_host',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=VariableManager(), loader=DictDataLoader())
    iterator = PlayIterator()
    iterator.load_play(play)
    host = Host('test_host')
    host.set_variable('ansible_ssh_host', 'localhost')
    host.set_variable('ansible_ssh_port', 22)

    all_hosts = iterator.get_hosts()
    assert len(all_hosts) == 1


# Generated at 2022-06-22 20:03:12.431048
# Unit test for method get_host_state of class PlayIterator
def test_PlayIterator_get_host_state():
    host_states_dict = {"host1": HostState(blocks=[{"task1": None, "task2": None}, {"task2": None, "task3": None}])}
    state = HostState(blocks=[{"task1": None, "task2": None}, {"task2": None, "task3": None}])
    play = Play()
    iterator = PlayIterator(play)
    iterator._host_states = host_states_dict
    assert iterator.get_host_state("host1") == state


# Generated at 2022-06-22 20:03:23.456070
# Unit test for method is_failed of class PlayIterator
def test_PlayIterator_is_failed():
    host = Host('example.org')
    play = Play()
    task = Task()
    iterator = PlayIterator(play, lambda x: False, lambda x: None, [host])
    state = HostState(blocks=[Block(block=task)])
    iterator._host_states = { host.name: state }
    state.fail_state = PlayIterator.FAILED_SETUP
    assert iterator.is_failed(host)
    state.fail_state = PlayIterator.FAILED_TASKS
    assert iterator.is_failed(host)
    state.fail_state = PlayIterator.FAILED_RESCUE
    assert iterator.is_failed(host)
    state.fail_state = PlayIterator.FAILED_ALWAYS
    assert iterator.is_failed(host)

# Generated at 2022-06-22 20:03:33.945508
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    a = HostState([])
    b = HostState([])

    assert a == b
    assert not a != b

    b.cur_block = 1
    assert a != b
    assert b != a

    b = a.copy()
    b.cur_regular_task = 1
    assert a != b
    assert b != a

    b = a.copy()
    b.cur_rescue_task = 1
    assert a != b
    assert b != a

    b = a.copy()
    b.cur_always_task = 1
    assert a != b
    assert b != a

    b = a.copy()
    b.run_state = 1
    assert a != b
    assert b != a

    b = a.copy()
    b.fail_state = 8
    assert a != b
    assert b

# Generated at 2022-06-22 20:03:37.984592
# Unit test for method __repr__ of class HostState
def test_HostState___repr__():
    blocks = [Block([Task()]), Block([Task()])]
    block1 = HostState(blocks)
    assert block1.__repr__() == "HostState([Block(tasks=[]), Block(tasks=[])])"



# Generated at 2022-06-22 20:03:43.573999
# Unit test for method __eq__ of class HostState
def test_HostState___eq__():
    from ansible.playbook.block import Block

    # test different objects
    block1 = Block()
    block2 = Block()
    state1 = HostState([block1])
    state2 = HostState([block2])

    assert state1 != state2

    # test equal objects
    state3 = HostState([block1])

    assert state1 == state3


# Generated at 2022-06-22 20:03:49.452135
# Unit test for method get_active_state of class PlayIterator
def test_PlayIterator_get_active_state():
    '''
    PlayIterator._get_active_state()
    '''

    # Assert number of failures for PlayIterator._get_active_state == 0
    # Assert number of failures for get_active_state == 0
    assert test.run_asserts(PlayIterator, 'get_active_state') == 0


# Generated at 2022-06-22 20:04:01.552525
# Unit test for method __str__ of class HostState