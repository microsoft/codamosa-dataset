

# Generated at 2022-06-10 22:09:46.350367
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console = ConsoleCLI()
    console.default('ping')


# Generated at 2022-06-10 22:09:47.293416
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    pass

# Generated at 2022-06-10 22:09:51.936179
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    from ansible.cli.console import ConsoleCLI
    cli = ConsoleCLI()
    cli.cwd = '*'
    cli.remote_user = 'root'
    cli.become = True
    cli.become_user = 'admin'
    cli.check_mode = True
    prompt = cli.set_prompt()

    assert prompt == 'root@* (become:admin, check:True)$ '

# Generated at 2022-06-10 22:10:01.142077
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    hostlist = [
        dict(name='elk-01', groups=['elk'], vars=dict(ansible_host='10.10.10.10')),
        dict(name='logstash-01', groups=['logstash'], vars=dict(ansible_host='10.10.10.11')),
        dict(name='elk-02', groups=['elk'], vars=dict(ansible_host='10.10.10.12')),
    ]

# Generated at 2022-06-10 22:10:05.272759
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console = ConsoleCLI()
    ansible_module = "get_url"
    expected = '''GET DATA FROM A URL\n      Supports HTTP, HTTPS, and FTP.\n      Returns a hash of the file, with the filename and MIME type\n      as keys.\n'''
    result = console.helpdefault(ansible_module)
    assert isinstance(result,type(None))


# Generated at 2022-06-10 22:10:15.015225
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
  cli = ConsoleCLI()
  cli.inventory = Mock(spec=Inventory)
  cli.inventory.list_hosts = Mock(return_value=[])
  cli.inventory.get_hosts = Mock(return_value=[])
  cli.inventory.get_group = Mock(return_value=Mock(spec=Group))
  # Call method
  cli.do_cd("")
  # Asserts
  cli.inventory.list_hosts.assert_called_with('*')
  assert cli.cwd == '*'


# Generated at 2022-06-10 22:10:22.570091
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    demo_host = Host('host1')
    demo_host.set_variable('ansible_host', 'host1')
    demo_host.set_variable('ansible_port', '22')
    demo_host.set_variable('ansible_user', 'root')
    demo_host.set_variable('ansible_become_user', 'root')
    demo_host.set_variable('ansible_ssh_pass', 'password')
    demo_host.set_variable('ansible_become_password', 'password')
    demo_host.set_variable('ansible_connection', 'ssh')
    demo_host.set_variable('ansible_network_os', 'unix')
    demo_host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    demo_host.set

# Generated at 2022-06-10 22:10:24.442923
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    cli = ConsoleCLI()
    cli.run()


# Generated at 2022-06-10 22:10:37.287318
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    ConsoleCLI_obj = ConsoleCLI()
    module_name = 'hostname'
    if module_name in ConsoleCLI_obj.modules:
        in_path = module_loader.find_plugin(module_name)
        if in_path:
            oc, a, _, _ = plugin_docs.get_docstring(in_path, fragment_loader)
            if oc:
                display.display(oc['short_description'])
                display.display('Parameters:')
                for opt in oc['options'].keys():
                    display.display('  ' + stringc(opt, ConsoleCLI_obj.NORMAL_PROMPT) + ' ' + oc['options'][opt]['description'][0])
            else:
                display.error('No documentation found for %s.' % module_name)
       

# Generated at 2022-06-10 22:10:51.729052
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    from ansibleconsole.console import ConsoleCLI
    from ansibleconsole.console import Inventory
    from ansibleconsole.console import VarsManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from six import StringIO
    from ansible.inventory.host import Host

    class InventoryMock(object):
        def __init__(self):
            pass

        def get_hosts(self, pattern):
            return [Host(name="test", port=22)]

    class LoaderMock(object):
        def __init__(self):
            pass

    class VariableManagerMock(object):
        def __init__(self):
            pass

    hosts = [Host(name="test", port=22), Host(name="test2", port=22)]


# Generated at 2022-06-10 22:11:10.184718
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cli = ConsoleCLI()
    cli.do_verbosity(arg=None)
    cli.do_verbosity(arg='10')
    cli.do_verbosity(arg=1)
    cli.do_verbosity(arg='abcd')



# Generated at 2022-06-10 22:11:11.440791
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    mycli = ConsoleCLI()
    mycli.run()


# Generated at 2022-06-10 22:11:16.502311
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console = ConsoleCLI()
    modules = console.list_modules()
    assert isinstance(modules, set)
    assert 'ping' in modules
    assert 'shell' in modules
    assert 'command' in modules
    assert 'debug' in modules
    assert 'set_fact' in modules
    assert 'include' in modules
    assert 'include_vars' in modules

# Generated at 2022-06-10 22:11:17.124961
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    assert False

# Generated at 2022-06-10 22:11:18.208949
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    pass

# Generated at 2022-06-10 22:11:27.939422
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    """Test do_cd"""
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    builtins.__dict__['_'] = lambda x: x
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.inventory as inventory_loader
    import ansible.plugins.connection as connection_loader

# Generated at 2022-06-10 22:11:32.889086
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    import sys
    import io
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display

    display = Display()
    c = ConsoleCLI(callback=display, args=dict())
    c.cmdloop()

# Generated at 2022-06-10 22:11:39.762518
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.callback.default import CallbackModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import __builtin__
    setattr(__builtin__, 'display', MagicMock())

# Generated at 2022-06-10 22:11:48.907209
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Store test fixture
    import sys
    import textwrap

    from ansibullbot.utils.ansible_compat import ModuleMock, MockV2Module


# Generated at 2022-06-10 22:12:00.296229
# Unit test for method complete_cd of class ConsoleCLI

# Generated at 2022-06-10 22:12:28.056541
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    args = create_args()
    args.pattern = None
    args.host_pattern = None
    args.remote_user = None
    args.become = None
    args.become_user = None
    args.become_method = None
    args.check = None
    args.diff = None
    args.forks = None
    args.task_timeout = None
    args.subset = None
    context.CLIARGS = args
    def test_list_modules():
        self = ConsoleCLI()
        self.module_cache = {}
        self.module_load_count = 0
        return self.list_modules()
    def test_do_shell(self, arg, forceshell=False):
        return self.default(arg)
    def test_do_forks(self, arg):
        return

# Generated at 2022-06-10 22:12:32.760487
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    # Set env variable ANSIBLE_VAULT_PASS
    os.environ['ANSIBLE_VAULT_PASS'] = 'test_env_ansible_vault_pass'

    # Test method default when variable tqm has a value
    test_tqm = object
    test_self = ConsoleCLI(["ansible-console", "--private-key", "test_key", "all"], 'test_context')
    test_self._tqm = test_tqm
    test_self.default("test_arg", False)
    assert test_self._tqm == test_tqm
    assert test_self.selected == ['all']



# Generated at 2022-06-10 22:12:42.744453
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    # create instance of class
    mockConsoleCLI = ConsoleCLI()

    # create mock function used by function under test
    mock_filter_completion = MagicMock()
    mockConsoleCLI._filter_completion = mock_filter_completion

    path = "fake_path"

    # execute function under test
    with patch("ansible_console.console.module_loader", MockedModuleLoader()):
        result = mockConsoleCLI._list_modules(path)

    # validate results
    assert result == ["fake_module", "fake_module2"], "result does not match expectation"


# Generated at 2022-06-10 22:12:49.563925
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cli = ConsoleCLI()
    ansible_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    print(os.path.join(ansible_path, 'lib', 'ansible', 'modules'))
    #console_cli._find_modules_in_path(os.path.join(ansible_path, 'lib', 'ansible', 'modules'))
    #assert list(console_cli.list_modules()) != []
    pass

# Generated at 2022-06-10 22:12:58.165886
# Unit test for method set_prompt of class ConsoleCLI

# Generated at 2022-06-10 22:13:02.676313
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    output = BytesIO()
    helper = ConsoleCLI()
    helper.helpdefault('setup')
    out = output.getvalue().strip()
    assert out == b"Gather facts from a remote system"

# Generated at 2022-06-10 22:13:09.219724
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    args = ['playbook', '--help']

# Generated at 2022-06-10 22:13:19.782680
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    # Set up mock objects
    class Mock_CLI(object):
        class Mock_module(object):
            def __init__(self):
                self.argument_spec = None
                self.supports_check_mode = True

        class Mock_module_loader(object):
            def find_plugin(module_name):
                return True

    # Set up mock objects
    class Mock_VariableManager(object):
        def __init__(self):
            self.extra_vars = None

    class Mock_Loader(object):
        def __init__(self):
            self.cleanup_all_tmp_files = None

    class Mock_Play(object):
        def __init__(self):
            self.load = None

    class Mock_TaskQueueManager(object):
        def __init__(self):
            self.run

# Generated at 2022-06-10 22:13:23.091333
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # create instance of the class
    cli = ConsoleCLI([])
    cli.do_cd('localhost')
    # run method helpdefault
    cli.helpdefault(cli.modules[0])


# Generated at 2022-06-10 22:13:24.834091
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    """
        Unit test for method do_list of class ConsoleCLI
    """
    pass
    

# Generated at 2022-06-10 22:16:04.391510
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    consolecli = ConsoleCLI()
    consolecli.inventory = MagicMock()
    consolecli.get_host_list = MagicMock()
    consolecli.set_prompt = MagicMock()
    consolecli.parse_kv = MagicMock()
    consolecli.ask_passwords = MagicMock()
    def get_hosts(value):
        return [dict(name='localhost')]
    consolecli.inventory.get_hosts.side_effect = get_hosts
    consolecli.do_cd('localhost')
    consolecli.inventory.get_hosts.assert_called_once_with('localhost')
    consolecli.set_prompt.assert_called_once_with()


# Generated at 2022-06-10 22:16:09.392426
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console = ConsoleCLI()
    line = ""
    text = ""
    begidx = 0
    endidx = 0 
    res = console.completedefault(text, line, begidx, endidx)
    assert res is None


# Generated at 2022-06-10 22:16:10.057382
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    pass

# Generated at 2022-06-10 22:16:17.129954
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():

    try:
        if sys.platform in ('darwin', 'win32'):
            raise AssertionError
        import readline  # noqa
    except (ImportError, AssertionError):
        # We can't do this in a py3.5 unit test
        return

    groups = [
        inventory.Group('foo'),
        inventory.Group('Foo Bar'),
        inventory.Group(' FooBar '),
        inventory.Group('foo'),
        inventory.Group('foobar')
    ]
    inv = inventory.Inventory(groups=groups)

    # We need to set a display that is not a class for this test
    def dummy_display(msg):
        return msg

    display.display = dummy_display

# Generated at 2022-06-10 22:16:25.128981
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    class MockCLI(ConsoleCLI):
        def __init__(self):
            pass
    cli = MockCLI()

    # LANG environment variable is not set (None)
    assert 'arg1' in cli.module_args('echo')

    # LANG environment variable has been set to en_US.utf8
    assert 'arg1' in cli.module_args('echo')

    assert 'msg' not in cli.module_args('debug')

test_ConsoleCLI_module_args()

# Generated at 2022-06-10 22:16:26.289475
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
  cl = ConsoleCLI()
  cl.cmdloop()


# Generated at 2022-06-10 22:16:35.771067
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    class Host(object):
        def __init__(self, port=22):
            self.name = 'localhost'
            self.port = port
            self._variable_manager = variables.VariableManager()

        def set_variable(self, key, value):
            self._variable_manager.set_host_variable(self, key, value)

    class Inventory(object):
        def __init__(self):
            self.hosts = dict()

        def add_host(self, host):
            self.hosts[host.name] = host

        def get_hosts(self, pattern):
            return []

        def list_groups(self):
            return ['/etc/ansible/hosts']

    class Play(object):
        def __init__(self):
            self.hosts = None
            self.remote_user

# Generated at 2022-06-10 22:16:37.459682
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    c = ConsoleCLI()
    c.cmdloop()
    assert c is not None

# Generated at 2022-06-10 22:16:40.574880
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    o = ConsoleCLI()
    o.do_list("")


# Generated at 2022-06-10 22:16:46.971732
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    arg1 = mock()
    arg2 = mock()
    arg3 = mock()
    arg4 = mock()
    arg1.split = MagicMock(return_value=['something'])
    testObject = ConsoleCLI()
    testObject.modules = ['something']
    assert testObject.completedefault(arg1, arg2, arg3, arg4) == []

# Generated at 2022-06-10 22:18:33.677816
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    """ Test setup """
    from ..plugins.callback import CallbackBase
    from ..plugins.callback import MutedCallbackBase

    class CallbackModule(CallbackBase):
        ''' Test class for the Ansible Callback Module '''
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'console_testing'

        def v2_runner_on_ok(self, res, ignore_errors=False):
            ''' Runner on OK for Test '''
            self._display.display(res['msg'])

        def v2_runner_on_failed(self, res, ignore_errors=False):
            ''' Runner on Failed for Test '''
            self._display.display('FAILED!')


# Generated at 2022-06-10 22:18:35.615741
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    c = ConsoleCLI()
    c.list_modules()


# Generated at 2022-06-10 22:18:44.754007
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    obj = ConsoleCLI()
    module_path = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_list_modules_%s' % random.randint(0, 2**48))
    module_files = ['file1', 'file2', 'file3']
    os.makedirs(module_path)
    for file in module_files:
        with open(os.path.join(module_path, file), 'w') as f:
            f.write('test')

    # Modules path not set and not using system's default
    module_loader.add_directory(module_path)
    modules = obj.list_modules()

    assert all(x in modules for x in module_files)

    # Modules path not set and using system's default
    module_loader.clear_

# Generated at 2022-06-10 22:18:53.822315
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    c = ConsoleCLI()
    c.module_args = MagicMock(return_value = ['baz'])
    assert c.module_args('foo') == ['baz']
    output = c.completedefault('baz', 'foo bar baz', 10, 11)
    assert output == ['=', '=', '=']
    assert c.module_args.called
    c.module_args.assert_called_with('foo')

# Generated at 2022-06-10 22:19:00.104216
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_cli = ConsoleCLI('ansible-console')
    input_text = 'a'
    line = 'cd ' + input_text
    begidx = len(line) - len(input_text)
    endidx = len(line)
    expected_output = ['all']
    output = console_cli.complete_cd(input_text, line, begidx, endidx)
    assert output == expected_output