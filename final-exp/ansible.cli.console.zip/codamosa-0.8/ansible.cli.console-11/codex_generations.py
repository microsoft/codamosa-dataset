

# Generated at 2022-06-10 22:09:48.513381
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    # setup context
    context._init_global_context(None)

    # Setup args

# Generated at 2022-06-10 22:09:54.237657
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    args = dict()
    args['inventory'] = './ansible/test/units/modules/inventory'
    args['pattern'] = 'all'
    context.CLIARGS = args
    app = ConsoleCLI()
    app.cwd = '*'
    hostname = 'app'
    line = 'app'
    app.completedefault(hostname, hostname, 0 ,len(hostname))


if __name__ == '__main__':
    app = ConsoleCLI()
    app.run()

# Generated at 2022-06-10 22:09:55.841901
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_cli = ConsoleCLI()
    console_cli.helpdefault(module_name = None)


# Generated at 2022-06-10 22:10:01.099128
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # test without parameters
    # expected: help message with error 'module_name is a mandatory argument'
    try:
        parms = {}
        module_name = ''
        result = ConsoleCLI.helpdefault(module_name)
        assert False # if we got here then parameter error not detected
    except Exception as e:
        assert "module_name is a mandatory argument" in str(e)
        assert True # exception was raised as expected


# Generated at 2022-06-10 22:10:03.605731
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console = ConsoleCLI()
    modules = console.list_modules()
    assert modules == ['shell']

# Generated at 2022-06-10 22:10:17.098918
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Assert 'cd' method raises NotImplementedError
    fake_args = 'foo'
    fake_self = ConsoleCLI()
    # with pytest.raises(NotImplementedError):
    #     fake_self.do_cd(fake_args)
    
    # Assert 'cd' method raises NotImplementedError
    fake_args = None
    fake_self = ConsoleCLI()
    # with pytest.raises(NotImplementedError):
    #     fake_self.do_cd(fake_args)

    from ansible.cli.console import ConsoleCLI

    cli = ConsoleCLI()
    cli.do_become_user('root')
    cli.do_cd('foo')
    cli.do_cd('/')
    cli.do_become_

# Generated at 2022-06-10 22:10:21.698935
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    mock_loader = MockModuleLoader()
    mock_loader.modules = {'test_module': 'Test Module', 'unittest1': 'Fake Unittest', 'unittest2': 'Fake Unittest'}
    cli = ConsoleCLI(mock_loader)
    modules = cli.list_modules()
    # unittest modules are removed
    assert 'unittest1' not in modules
    assert 'unittest2' not in modules
    # test_module is returned
    assert 'test_module' in modules



# Generated at 2022-06-10 22:10:35.409095
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_cli = ConsoleCLI()
    console_cli.cwd = "all"
    console_cli.remote_user = ""
    console_cli.become = False
    console_cli.become_user = ""
    console_cli.become_method = ""
    console_cli.task_timeout = ""
    console_cli.check_mode = False
    console_cli.diff = False
    console_cli.forks = 0
    console_cli.passwords = {"conn_pass": sshpass, "become_pass": becomepass}
    console_cli.loader, console_cli.inventory, console_cli.variable_manager = console_cli._play_prereqs()

# Generated at 2022-06-10 22:10:49.836710
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    cli = ConsoleCLI()
    cli.inventory = Inventory('localhost')
    cli.inventory.add_host(Host('localhost'))
    cli.inventory.add_host(Host('host1'))
    cli.inventory.add_host(Host('host2'))
    cli.inventory.add_group(Group('group1'))
    cli.inventory.add_group(Group('group2'))
    cli.inventory.add_host(Host('host3'), 'group1')
    cli.inventory.add_host(Host('host4'), 'group1')
    cli.inventory.add_host(Host('host5'), 'group2')
    cli.inventory.add_host(Host('host6'), 'group2')

# Generated at 2022-06-10 22:10:58.789542
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    '''
    Test class ConsoleCLI, method default
    '''

    # Test execution with mandatory parameters only
    test_obj = ConsoleCLI()
    test_obj.pattern = '*'
    test_obj.cwd = '/home/user'
    test_obj.remote_user = 'user'
    test_obj.become = True
    test_obj.become_user = 'user'
    test_obj.become_method = 'su'
    test_obj.check_mode = True
    test_obj.diff = False
    test_obj.forks = 10
    test_obj.task_timeout = 10
    test_obj.modules = [ 'ping' ]

    test_obj.loader = mock.MagicMock()
    type(test_obj.loader).module_loader = mock.PropertyMock

# Generated at 2022-06-10 22:11:22.001331
# Unit test for method do_list of class ConsoleCLI

# Generated at 2022-06-10 22:11:31.242001
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    from ansible.cli.adhoc import AdHocCLI
    from ansible.cli import CLI

    cli = ConsoleCLI()
    cli._base_parser = CLI.base_parser(constants.DEFAULT_MODULE_PATH, 'config_info')
    cli._base_parser.add_argument('--version', dest='version', action='version', version='%(prog)s {}'.format(constants.__version__))
    cli._shared_parser = CLI.shared_parser(constants.DEFAULT_MODULE_PATH, 'config_info')
    cli._connect_shared_args(cli._base_parser)

    cli._dispatch_shared_parser(cli._base_parser, 'base_cli_options')


# Generated at 2022-06-10 22:11:37.556699
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    console = ConsoleCLI(['ansible-console', '--playbook-dir', '/tmp/ansible'])
    console.inventory = Mock()
    console.set_prompt = Mock()
    console.timeout = 10
    console.do_timeout('5')
    assert console.timeout == 5

# Generated at 2022-06-10 22:11:41.407435
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    print('Testing ConsoleCLI - run')
    # Create a ConsoleCLI object
    cc = ConsoleCLI()
    # Test the run() method
    cc.run()

# Generated at 2022-06-10 22:11:49.314376
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console = ConsoleCLI()
    console.cwd = 'localhost'
    host = Host(name='localhost', port=22)
    host.vars = {'ansible_connection': 'ssh'}
    host.set_variable('ansible_ssh_pass', 'sshpass')
    host.set_variable('ansible_become_pass', 'becomepass')

    group = Group('all')
    group.add_host(host)
    group.set_variable('ansible_remote_user', 'test')
    group.set_variable('ansible_become', True)

    # Create the inventory, with the host and group
    inventory = Inventory(loader=None,  host_list=[host],  group_list=[group])

    # Create a variable manager
    variable_manager = VariableManager()

# Generated at 2022-06-10 22:11:52.472714
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_cli = ConsoleCLI()
    console_cli.do_list('hosts')
    console_cli.do_list('groups')


# Generated at 2022-06-10 22:11:53.162733
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    pass

# Generated at 2022-06-10 22:11:56.346891
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    m = MagicMock()
    c = ConsoleCLI(m)
    c.do_list("groups")
    c.do_list("")
    c.do_list("test")


# Generated at 2022-06-10 22:11:57.921558
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    pass



# Generated at 2022-06-10 22:12:02.037159
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    print(get_stdout(lambda: ConsoleCLI.post_process_args(args=None, parse=True)))
    print(get_stdout(lambda: ConsoleCLI.post_process_args(args=['a', 'b', 'c'], parse=True), True))


# Generated at 2022-06-10 22:12:30.395051
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    '''
    Unit test for method complete_cd of class ConsoleCLI
    '''
    fake_command = "mycommand"
    fake_complete_text = "1234"
    fake_line = "line"
    fake_begidx = "1"
    fake_endidx = "10"
    fake_options = "options"
    fake_inventory = "inventory"

    results = ConsoleCLI.complete_cd(fake_command, fake_complete_text, fake_line, fake_begidx, fake_endidx, fake_options, fake_inventory)

    # Testing result types
    assert isinstance(results, list)
    for entry in results:
        assert isinstance(entry, str)

# Generated at 2022-06-10 22:12:39.844860
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    test_obj = ConsoleCLI()
    # Testing for completion of a shell module command
    assert test_obj.completedefault('', 'shell ls -l ', 10, 15) == [' ']
    # Testing for completion of a non-shell module command
    assert test_obj.completedefault('', 'ping ', 5, 10) == ['dest= ', 'data= ', 'count= ', 'state= ', 'timeout= ']
    # Testing for completion of a non-existent module command
    assert test_obj.completedefault('', 'blah ', 5, 10) == []



# Generated at 2022-06-10 22:12:49.818496
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    """
    Test do_list of class ConsoleCLI
    """
    args = context.CLIARGS
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, args['inventory'])
    hosts = inventory.list_hosts()  
    
    cli = ConsoleCLI(args)
    cli.hosts = []
    cli.groups = []
    cli.hosts.extend([host.name for host in hosts])
    cli.groups.append("all")
    cli.cwd = 'all'
    cli.do_list("")

    cli.do_list("groups")


# Generated at 2022-06-10 22:12:56.918896
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_cli = ConsoleCLI()
    console_cli.cwd = 'host1'
    console_cli.forks = 3
    console_cli.passwords = {}
    console_cli.inventory = []
    console_cli.variable_manager = []

    console_cli.modules = ['ping', 'setup']
    result = console_cli.default('ping', True)
    assert result is False


# Generated at 2022-06-10 22:13:07.220256
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():

    class FakeModuleLoader(object):

        def find_plugin(self, module):
            return '/path/to/module'

    class FakeFragmentLoader(object):

        def get(self, path, *args, **kwargs):
            return ''

    def test_console(args=None):
        c = ConsoleCLI(args)
        c.module_loader = FakeModuleLoader()
        c.fragment_loader = FakeFragmentLoader()
        c.modules = ['command']
        c.run()

    # Test normal initialization
    args = []

# Generated at 2022-06-10 22:13:18.225083
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Dummy class for the purpose of testing.
    class Dummy_ConsoleCLI(object):
        cmdloop_called = False
        def __init__(self):
            return
        def cmdloop(self):
            ConsoleCLI.cmdloop(self)
            Dummy_ConsoleCLI.cmdloop_called = True

    # Test 1:
    # Test if cmdloop calls do_exit when user enters exit.
    do_exit_called = False
    def do_exit_test(self, args):
        ConsoleCLI.do_exit(self, args)
        nonlocal do_exit_called
        do_exit_called = True
    # Monkey patch do_exit method of ConsoleCLI.
    ConsoleCLI.do_exit = do_exit_test
    # Create an instance of Dummy_ConsoleCLI
    dummy_

# Generated at 2022-06-10 22:13:28.950673
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cli = ConsoleCLI()
    moduledir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../../plugins/modules')
    modules = [f for f in os.listdir(moduledir) if os.path.isfile(os.path.join(moduledir, f))]
    assert(list(console_cli.list_modules(moduledir, modules)) == sorted(['user', 'ping']))

    moduledir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../../plugins/action')
    modules = [f for f in os.listdir(moduledir) if os.path.isfile(os.path.join(moduledir, f))]

# Generated at 2022-06-10 22:13:35.193425
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():

    inventory = InventoryManager(Loader(), VariableManager())
    current_path = os.path.dirname(os.path.realpath(__file__))
    inventory.load_inventory(current_path + '/../../ansible_test_inventory')
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    console = ConsoleCLI(None, loader, inventory, variable_manager)
    console.default("setup", True)


# Generated at 2022-06-10 22:13:39.050606
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_cli_obj = cli.ConsoleCLI(['-i', './inventory', '-f', '10'])
    console_cli_obj.do_list('hosts')

# Generated at 2022-06-10 22:13:47.572715
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_cli = ConsoleCLI()
    console_cli.cwd = '*'
    console_cli.pattern = 'web*'
    console_cli.selected = ['test_host']
    console_cli.groups = ['foo', 'bar']
    console_cli.hosts = ['test_host']
    console_cli.modules = ['ping']
    console_cli.loader = None
    console_cli.inventory = None
    console_cli.variable_manager = None
    console_cli.passwords = {'become_pass': '', 'conn_pass': ''}
    console_cli.remote_user = 'test_user'
    console_cli.become = True
    console_cli.become_user = 'test_become_user'
    console_cli.become_method = 'sudo'
   

# Generated at 2022-06-10 22:14:06.455574
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    cls = ConsoleCLI()
    cls.default = lambda arg, forceshell=False: False
    cls.do_cd('/')
    cls.do_cd('/*')
    cls.do_cd('nohost')
    cls.selected = True
    cls.do_cd('host')


# Generated at 2022-06-10 22:14:10.160628
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cli = ConsoleCLI()
    cli.do_verbosity('2')
    assert display.verbosity == 2
    cli.do_verbosity('3')
    assert display.verbosity == 3
    cli.do_verbosity('')
    assert display.verbosity == 3


# Generated at 2022-06-10 22:14:11.070340
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    assert True==False


# Generated at 2022-06-10 22:14:14.602461
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    assert ConsoleCLI.do_list(self, arg='groups')
    assert ConsoleCLI.do_list(self, arg='test')


# Generated at 2022-06-10 22:14:18.008952
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    """ConsoleCLI do_verbosity: should set verbosity level"""
    cli = ConsoleCLI()
    cli.do_verbosity('1')
    assert display.verbosity == 1


# Generated at 2022-06-10 22:14:26.668684
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Initializing an object of class ConsoleCLI
    cli = ConsoleCLI()
    # Test if method do_cd correctly changes the current path when it exists
    cli.cwd = 'windows'
    cli.do_cd('linux')
    assert cli.cwd == 'linux' 
    # Test if method do_cd correctly changes the value of the string cwd to 'all' when substring '*' is given
    cli.do_cd('*/')
    assert cli.cwd == 'all'
    cli.do_cd('/*')
    assert cli.cwd == 'all'
    # Test if method do_cd correctly changes the value of the string cwd to 'all' when substring '*' is given
    cli.do_cd('*')

# Generated at 2022-06-10 22:14:34.915468
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    cli = ConsoleCLI()

# Generated at 2022-06-10 22:14:36.360827
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_cli = ConsoleCLI()
    assert console_cli.cmdloop() == -1


# Generated at 2022-06-10 22:14:42.001330
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    inv = Inventory(loader_class=InventoryFileLoader)
    loader = DataLoader()
    vm = VariableManager(loader, inv)
    pb = Playbook(playbook='/etc/ansible/playbooks/hdp.yml')
    c = ConsoleCLI(loader, inv, vm, pb)
    c.run()
    return c

# Generated at 2022-06-10 22:14:53.172071
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    fake_play = None
    fake_options = None
    fake_passwords = None
    fake_inventory = None
    fake_variable_manager = None
    fake_loader = None
    fake_tqm = None
    fake_variable_manager = None
    fake_loader = None
    fake_options = None
    fake_inventory = None
    fake_variable_manager = None
    fake_loader = None
    fake_tqm = None
    fake_variable_manager = None
    fake_loader = None
    fake_options = None
    fake_inventory = None
    fake_variable_manager = None
    fake_loader = None
    fake_tqm = None
    fake_variable_manager = None
    fake_loader = None
    fake_options = None
    fake_inventory = None
    fake_variable_

# Generated at 2022-06-10 22:15:32.113737
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    print("\n=== test_ConsoleCLI_helpdefault ===")
    console = ConsoleCLI()
    console.modules = ['ping']
    console.helpdefault('ping')
    print("=== test_ConsoleCLI_helpdefault ===")


# Generated at 2022-06-10 22:15:34.948882
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    # file: test_console.py
    # Line: 77
    assert True == False

# Generated at 2022-06-10 22:15:42.050052
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():

    c = ConsoleCLI()
    c.inventory = None
    c.variable_manager = None
    c.loader = None

    # Use '--private-key' to fix the issue.
    original_args = dict(private_key='/home/test/test.pem')
    expected_args = dict(private_key='/home/test/test.pem')

    c.post_process_args(original_args)

    assert original_args == expected_args

# Generated at 2022-06-10 22:15:49.630370
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    import inspect
    import ansible

    class dummy_class:
        display = ansible.cli.display.Display()
        verbosity = 0
        config = ansible.config.loader.ConfigLoader()

    c = dummy_class()
    c.display = ansible.cli.display.Display()
    c.verbosity = 0
    c.config = ansible.config.loader.ConfigLoader()

    # test valid input
    try:
        ansible.plugins.callback.console.ConsoleCLI.do_verbosity(c, '1')
    except Exception as e:
        assert isinstance(e, AssertionError)
        
        # test TypeError

# Generated at 2022-06-10 22:16:00.230975
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console_cli = ConsoleCLI()
    console_cli._display = Mock()
    console_cli._display.verbosity = 0
    console_cli.normalize_become_options = Mock()
    console_cli.ask_passwords = Mock()
    console_cli.ask_passwords.return_value = ('sshpass', 'becomepass')
    console_cli._play_prereqs = Mock()
    console_cli._play_prereqs.return_value = ('loader', 'inventory', 'variable_manager')
    console_cli.get_host_list = Mock()
    console_cli.get_host_list.return_value = ('hosts')
    console_cli.inventory = Mock()
    console_cli.inventory.list_groups.return_value = ('groups')
    console_cli.list_modules = Mock

# Generated at 2022-06-10 22:16:11.988110
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    def fake_display(s, **kwargs):
        pass

    def fake_readline(prompt):
        return "shell uptime"

    def fake_get_history_length():
        return 0

    display.display = fake_display
    readline.readline = fake_readline
    readline.get_history_length = fake_get_history_length

    def fake_default(arg, forceshell=False):
        pass

    def fake_do_shell(arg):
        pass


# Generated at 2022-06-10 22:16:17.826438
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Setup
    set_runner(get_runner('local'))
    console_cli = ConsoleCLI()
    set_inventory(console_cli.inventory)
    set_loader(console_cli.loader)
    set_variable_manager(console_cli.variable_manager)
    sshpass = None
    becomepass = None


    # Test
    console_cli.default('ping')
    print(to_text(console_cli.output))
    console_cli.default('copy')
    print(to_text(console_cli.output))
    console_cli.default('debug')
    print(to_text(console_cli.output))
    console_cli.default('win_ping')
    print(to_text(console_cli.output))



# Generated at 2022-06-10 22:16:19.558712
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # No way to test readline :(
    pass

# Generated at 2022-06-10 22:16:30.997108
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    my_console_cli = ConsoleCLI()

    ansible_vars = dict(ansible_connection='ssh', ansible_user='foo', ansible_ssh_pass='bar', ansible_port=22)
    ansible_vars['ansible_ssh_host'] = 'localhost'
    ansible_host = Host(name='localhost', port=ansible_vars['ansible_port'])
    ansible_host.set_variable('ansible_user', ansible_vars['ansible_user'])
    ansible_host.set_variable('ansible_ssh_pass', ansible_vars['ansible_ssh_pass'])
    ansible_host.set_variable('ansible_port', ansible_vars['ansible_port'])


# Generated at 2022-06-10 22:16:33.499331
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    obj = ConsoleCLI()
    obj.set_prompt(prompt='test_prompt')
    output = obj.prompt.__str__
    expected = "test_prompt"
    assert output == expected

# Generated at 2022-06-10 22:17:34.085597
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console = ConsoleCLI()
    assert console.list_modules()

# Generated at 2022-06-10 22:17:34.745900
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    pass

# Generated at 2022-06-10 22:17:35.744604
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    cli = ConsoleCLI()


# Generated at 2022-06-10 22:17:36.829525
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    return None


# Generated at 2022-06-10 22:17:45.844160
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    """
    Test the method helpdefault of class ConsoleCLI
    """
    # Load a playbook as an example
    current_directory = os.path.dirname(os.path.abspath(__file__))
    output_file = open('output_example.json', 'w')
    input_file = os.path.join(current_directory, 'files/playbook_example.yml')
    display.display('Running ansible-playbook.yml on playbook_example.yml')
    cmd = [sys.executable, 'ansible-playbook.yml', '-i', 'inventory', '-t', 'json', input_file]
    p = subprocess.Popen(cmd, stdout=output_file)
    p.wait()

    # Parse output

# Generated at 2022-06-10 22:17:56.064195
# Unit test for method completedefault of class ConsoleCLI

# Generated at 2022-06-10 22:17:58.151822
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
  cli = ConsoleCLI() 
  cli.modules = []
  assert cli.list_modules() == ['ping', 'setup', 'shell', 'user']


# Generated at 2022-06-10 22:18:08.274881
# Unit test for method helpdefault of class ConsoleCLI

# Generated at 2022-06-10 22:18:18.871406
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console_cli = ConsoleCLI()

# Generated at 2022-06-10 22:18:20.551186
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    cli = ConsoleCLI()
    cli.list_modules()