

# Generated at 2022-06-20 13:03:17.931183
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    pass

# Generated at 2022-06-20 13:03:24.944381
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    """
    This function is used to test if the method run() of class ConsoleCLI works
    as expected. Here, it's expected the user to answer two questions and then
    the cmdloop method in the ConsoleCLI class to be called
    """
    console_object = ConsoleCLI()
    with patch('ansible.cli.console.ConsoleCLI._ask_passwords', return_value=('sshpass','becomepass')), patch('ansible.cli.console.ConsoleCLI.cmdloop', return_value=None) as cmd_mock:
        console_object.run()
        cmd_mock.assert_called_once_with()

# Generated at 2022-06-20 13:03:31.348648
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Setup argument parser to parse command-line arguments.
    arg_parser = argparse.ArgumentParser()
    # Setup argument parser to parse command-line arguments.
    arg_parser.add_argument('--inventory', default=["tests/inventory"], nargs='+',
                            help="specify inventory host path "
                            "(default: %(default)s) or comma separated host list.")
    arg_parser.add_argument('--list-hosts', action='store_true',
                            help="outputs a list of matching hosts; does not execute anything else")

# Generated at 2022-06-20 13:03:37.454609
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    host = MockHost()
    cli_input = 'hostname'
    cli_output = 'hostname'

    cli = ConsoleCLI(host)
    cli.default = Mock(cli)
    cli.default(cli_input)

    cli.default.assert_called_with(cli_output)


# Generated at 2022-06-20 13:03:46.874098
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    # ansible.module_utils.basic.AnsibleModule.run_command = lambda self, args=None, check_rc=True:
    #     if isinstance(args, list):
    #         args[0] = 'echo'
    #         return (0, ' '.join(args), '')
    #     else:
    #         return (0, 'echo ' + args, '')
    # ansible.module_utils.basic.AnsibleModule.run_command = lambda self, args=None, check_rc=True:
    #     if isinstance(args, list):
    #         args[0] = 'echo'
    #         return (0, ' '.join(args), '')
    #     else:
    #         return (0, 'echo ' + args, '')
    cl = console.ConsoleCL

# Generated at 2022-06-20 13:03:48.898153
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    cli = ConsoleCLI()
    cli.do_become_method("None")
    cli.do_become_method("sudo")
    cli.do_become_method("su")

# Generated at 2022-06-20 13:03:52.765655
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    host = 'host1'
    user = 'root'
    input_params = {'host': host, 'user': user, 'verbose': True}
    input_args = ' '.join(['%s=%s' % (k, v) for k, v in input_params.items()])
    cli = ConsoleCLI([input_args])
    
    # Set up context
    context._init_global_context(
        cliargs=input_params
    )

    cli.do_remote_user(user)



# Generated at 2022-06-20 13:03:56.263610
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    import ansible.inventory.manager
    import ansible.constants as C
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    #################################################################################
    # ConsoleCLI is tested in integration test "test_ansible_console_cd.py"
    #################################################################################
    pass

# Generated at 2022-06-20 13:03:59.976459
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    a = ConsoleCLI()
    try:
        b = a.get_names()
    except Exception as e:
        assert 0, "Raised exception is not expected: " + str(e)
    assert(type(b) == list)


# Generated at 2022-06-20 13:04:07.491927
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    """Unit test for method 'do_verbosity' of class ConsoleCLI"""
    import sys
    import contextlib
    from io import StringIO
    
    from ansible.cli import CLI

    try:
        from ansible.plugins.loader import module_loader
        module_loader.add_directory(os.getcwd())
    except:
        pass
    
    def call_do_verbosity(self, arg, output):
        stdout = sys.stdout
        stdout_stringio = StringIO()
        sys.stdout = stdout_stringio
        with contextlib.redirect_stdout(stdout_stringio):
            self.do_verbosity(arg)
        sys.stdout = stdout
        # get output of method
        output['value1'] = stdout_stringio.getvalue()

   

# Generated at 2022-06-20 13:04:45.904369
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    console_cli = ConsoleCLI()
    console_cli._find_modules_in_path(os.getcwd() + '/../../plugins/modules')
    console_cli.modules.sort()

# Generated at 2022-06-20 13:04:47.116733
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    ConsoleCLI = ConsoleCLI()
    res = ConsoleCLI.do_forks(1)

# Generated at 2022-06-20 13:04:48.955841
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    # create test object
    console_cli = ConsoleCLI()
    # call method under test
    console_cli.do_timeout("10")

# Generated at 2022-06-20 13:04:52.905916
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    console_cli = ConsoleCLI()
    console_cli.diff = None
    console_cli.do_diff('true')
    assert console_cli.diff == True



# Generated at 2022-06-20 13:04:54.463778
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cli = ConsoleCLI()
    assert len(console_cli.list_modules()) > 10


# Generated at 2022-06-20 13:04:56.579755
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    my_ansible = ConsoleCLI() 
    print(my_ansible.completedefault(text="-name", line="command -name", begidx=7, endidx=12))


# Generated at 2022-06-20 13:05:12.689336
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_cli = ConsoleCLI()
    inventory = InventoryManager()
    console_cli.inventory = inventory
    console_cli.cwd = 'localhost'
    assert console_cli.default('TEST') == False
    assert console_cli.default('TEST') == False
    assert console_cli.default('TEST') == False
    assert console_cli.default('TEST') == False
    console_cli.cwd = '?'
    assert console_cli.default('TEST') == False
    console_cli.become = True
    console_cli.become_method = 'su'
    console_cli.become_user = 'root'
    console_cli.check_mode = False
    console_cli.diff = False
    console_cli.forks = 0
    console_cli.hosts = ['localhost']


# Generated at 2022-06-20 13:05:20.545936
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    display.verbosity = 0
    cc = ConsoleCLI()
    cc.do_verbosity('0')
    assert display.verbosity == 0
    cc.do_verbosity('1')
    assert display.verbosity == 1
    cc.do_verbosity('something')
    assert display.verbosity == 1
    try:
        cc.do_verbosity('1')
        cc.do_verbosity('2')
        cc.do_verbosity('3')
        cc.do_verbosity('4')
    except SystemExit:
        assert False, 'Ansible-console should not exit when executing do_verbosity'
    assert display.verbosity == 4

# Generated at 2022-06-20 13:05:22.341446
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    assert None != ConsoleCLI.complete_cd()

# Generated at 2022-06-20 13:05:29.515793
# Unit test for method do_become_user of class ConsoleCLI
def test_ConsoleCLI_do_become_user():
    console = ConsoleCLI()
    console.cwd = 'all'
    console.become_user = 'jenkins'
    console.become_method = 'su'
    console.become = True
    console.selected = ['host1', 'host2']
    arg = 'become_user root'
    console.do_become_user(arg)
    assert console.become_user != 'root'

# Generated at 2022-06-20 13:06:21.336236
# Unit test for method do_become_user of class ConsoleCLI
def test_ConsoleCLI_do_become_user():
        # Setup
        console_obj = ConsoleCLI()
        console_obj.do_become_user("test")
        # Exercise and assert
        assert_equals('test', console_obj.become_user)

# Generated at 2022-06-20 13:06:32.665352
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    fake_display = type('', (), dict(verbosity=0, display=''))

    fake_context = type('', (), dict(CLIARGS=dict(verbosity=0)))

    # Create an instance of class ConsoleCLI
    mock_cwd = 'all'
    mock_become_user = 'root'
    mock_remote_user = 'ubuntu'
    mock_become = True
    mock_check_mode = True
    mock_forks = 3
    mock_diff = True
    mock_hosts = ['host1', 'host2']
    mock_groups = ['group1', 'group2']
    mock_module = 'shell'
    mock_module_args = 'echo hello'
    mock_cmdline = ' '.join((mock_module, mock_module_args))

    # Create an instance of

# Generated at 2022-06-20 13:06:36.234985
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    print("Test: ConsoleCLI: do_timeout")
    # Setup test
    c = ConsoleCLI()
    c.task_timeout = -1
    # Execute test
    c.do_timeout("5")
    # Verify result
    assert c.task_timeout == 5

# Generated at 2022-06-20 13:06:44.115051
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    ans1 = ConsoleCLI(args=['-i', 'default/hosts', 'host1,host2'])
    ans1.ansible_playbook_stdout = MagicMock(return_value="")
    ans1.run()

    ans2 = ConsoleCLI(args=['-i', 'default/hosts', 'host1,host2'])
    ans2.ansible_playbook_stdout = MagicMock(side_effect=AnsibleError())
    ans2.run()

    assert True



# Generated at 2022-06-20 13:06:50.792158
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    #instantiate fake objects
    display = BaseCLI.display
    BaseCLI.display = mock.Mock(return_value=None)
    #instantiate obj
    obj = ConsoleCLI()

    #populate fake objects with data
    text = 'a'
    line = 'test a'
    begidx = 1
    endidx = 3

    # call method under test
    actual_result = obj.completedefault(text=text, line=line, begidx=begidx, endidx=endidx)

    # assert
    assert actual_result is None

# Generated at 2022-06-20 13:06:53.571906
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    inst = ConsoleCLI()
    inst.default = lambda x: False  # Test compatibility with basic Cmd class
    inst.cmdloop()



# Generated at 2022-06-20 13:07:05.517730
# Unit test for method completedefault of class ConsoleCLI

# Generated at 2022-06-20 13:07:11.033604
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    '''
    Unit test for method post_process_args of class ConsoleCLI
    '''
    # Input parameters for the unit test
    args = dict()
    args['pattern'] = 'all'

# Generated at 2022-06-20 13:07:24.386641
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():

    # Create an instance of ConsoleCLI
    cli = ConsoleCLI()

    # Make sure all the values are set to default value
    assert getattr(cli, 'cwd') == '*'
    assert getattr(cli, 'remote_user') is None
    assert getattr(cli, 'become') is False
    assert getattr(cli, 'become_user') is None
    assert getattr(cli, 'become_method') is None
    assert getattr(cli, 'check_mode') is False
    assert getattr(cli, 'diff') is False
    assert getattr(cli, 'forks') == 5
    assert getattr(cli, 'task_timeout') is None

    # Make sure these following methods raise NotImplementedError

# Generated at 2022-06-20 13:07:31.195597
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    from ansible.cli import CLI as cli
    cli = CLI()
    cli.set_prompt()
    assert 1==1



# Generated at 2022-06-20 13:11:52.989488
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    print()
    arg = ""
    ConsoleCLI().do_list(arg)

test_ConsoleCLI_do_list()


# Generated at 2022-06-20 13:11:54.916286
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    self = ConsoleCLI()
    assert self.do_list('groups') == None
    assert self.do_list(None) == None


# Generated at 2022-06-20 13:11:57.719319
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    ast_config = mock.Mock()
    inventory = mock.Mock()
    loader = mock.Mock()
    variable_manager = mock.Mock()
    ShellCLI(ast_config, inventory, loader, variable_manager)
