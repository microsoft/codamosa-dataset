

# Generated at 2022-06-20 13:02:44.837993
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    x = ConsoleCLI()
    x.cwd = 'testhost'
    assert x.prompt == 'testhost > ','ansible-console fails to prompt'


# Generated at 2022-06-20 13:02:51.348491
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    # set up
    test_name = 'test_ConsoleCLI_get_names'
    print('Running test function: {}'.format(test_name))
    test_ConsoleCLI = ConsoleCLI()
    
    # run get_names method
    names = test_ConsoleCLI.get_names()
    print('Testing if output is of type list')
    test_result = type(names)
    print('Expecting type: {}'.format(type([])))
    print('Result: {}'.format(test_result))
    assert test_result == type([]), '{} failed'.format(test_name)

    print('Successfully ran test function: {}'.format(test_name))
    print()
    print()
    return


# Generated at 2022-06-20 13:02:53.410853
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    pass


# Generated at 2022-06-20 13:03:04.233628
# Unit test for method post_process_args of class ConsoleCLI

# Generated at 2022-06-20 13:03:06.145225
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print('Executing unit test for cmdloop')


# Generated at 2022-06-20 13:03:09.116986
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    # test for normal execution
    module = ConsoleCLI(args=None)
    module.post_process_args(Bunch(subset=None, pattern='/etc/foo.conf', inventory=None))
    assert module.pattern == 'foo.conf'

# Generated at 2022-06-20 13:03:09.718987
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    pass

# Generated at 2022-06-20 13:03:14.870147
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():

    # Create an instance of the class we want to test (ConsoleCLI)
    cli = ConsoleCLI()

    # Define arguments to be passed to the parser
    args = "ansible-console -i hosts".split()

    # Uncomment to display arguments to be passed to the parser
    #print(args)

    # Initialise the parser
    cli.init_parser(args)

    # Obtain the parser object from the class instance
    parser = cli.parser

    # Test that the parser object has been initialised
    assert parser is not None


# Generated at 2022-06-20 13:03:18.646253
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    c = ConsoleCLI()

    c.groups = list()
    c.hosts = list()

    assert c.do_list("groups") == None

    c.groups = ["a", "b", "c"]
    assert c.do_list("groups") == None

    c.groups = []
    assert c.do_list("") == None

    c.hosts = ["a", "b", "c"]
    assert c.do_list("") == None

# Generated at 2022-06-20 13:03:26.883453
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    from ansible.cli.console import ConsoleCLI
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_provider
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig
    from ansible.inventory.manager import InventoryManager
    def _read_cli_args(args):
        if args is not None:
            if not isinstance(args, dict):
                raise AssertionError("Arg is not a dict: %s" % args)
            return args

    context.CLIARGS = _read_cli_args({})
    cwd = 'hosts'
    console = ConsoleCLI()
    load_provider(console.loader, console.variable_manager)

# Generated at 2022-06-20 13:05:04.745317
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    # FIXME: implement proper tests
    pass


# Generated at 2022-06-20 13:05:06.033023
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    assert True



# Generated at 2022-06-20 13:05:17.381097
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    """
    Test function `do_list` in class ConsoleCLI
    """
    # Test if arg is 'groups'
    # When arg is 'groups'
    # Expect:
    # 1. display
    x = ConsoleCLI()
    x.groups = ['a','b','c']
    x.do_list('groups')
    data = x.get_output()
    expect_data = 'a\nb\nc\n'
    assert_equal(data, expect_data, 'Output does not match')
    # Test if arg is not 'groups'
    # When arg is not 'groups'
    # Expect:
    # 1. display
    x.do_list('notgroups')
    data = x.get_output()
    expect_data = 'a\nb\nc\n'

# Generated at 2022-06-20 13:05:21.003980
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
  c = ConsoleCLI()
  c.check_mode = False
  c.do_check('yes')
  assert c.check_mode == True
  c.do_check('no')
  assert c.check_mode == False
  c.do_check(None)
  assert c.check_mode == True
  

# Generated at 2022-06-20 13:05:26.649652
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    console_cli = ConsoleCLI()
    console_cli.do_forks = MagicMock()
    arg = "2"
    console_cli.do_forks(arg)
    assert 1 == console_cli.do_forks.call_count
    assert arg == console_cli.do_forks.call_args_list[0][0][0]

# Generated at 2022-06-20 13:05:27.383942
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    pass

# Generated at 2022-06-20 13:05:29.467448
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    """Test do_verbosity function of ConsoleCLI class"""


# Generated at 2022-06-20 13:05:34.832252
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    consolecli = ConsoleCLI()
    consolecli.do_timeout('10')
    assert consolecli.task_timeout == 10
    consolecli.do_timeout('12')
    assert consolecli.task_timeout == 12
    consolecli.do_timeout('-1')
    assert consolecli.task_timeout == 12
    consolecli.do_timeout('a')
    assert consolecli.task_timeout == 12


# Generated at 2022-06-20 13:05:40.974477
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    """Test the method default of the class ConsoleCLI"""
    # Trailing ws are removed
    module_name = 'setup'
    console = ConsoleCLI()
    console.pattern = "all"
    console.inventory.unserialize(
        """{"all": {"hosts": {"host1": {}, "host2": {}}}, "_meta": {"hostvars": {"host2": {"ansible_host": "host2.example.com"}}}}""")
    console.hosts = ['host1', 'host2']
    console.selected = console.inventory.get_hosts('all')
    console.task_timeout = None
    console.forks = 1
    console.become = False
    console.become_method = 'sudo'
    console.become_user = 'root'
    console.remote_user

# Generated at 2022-06-20 13:05:43.432619
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    cli = ConsoleCLI()
    parser = cli.init_parser()
    assert parser
