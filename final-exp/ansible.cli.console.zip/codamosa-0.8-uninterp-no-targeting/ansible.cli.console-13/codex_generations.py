

# Generated at 2022-06-20 13:02:44.123615
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    consoleCLI = ConsoleCLI()
    consoleCLI.do_become_method("arg")

# Generated at 2022-06-20 13:02:47.369998
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    stdout = StringIO()
    sys.stdout = stdout
    test_instance = ConsoleCLI()
    test_instance.list_modules()
    sys.stdout = sys.__stdout__
    test_result = stdout.getvalue()

# Generated at 2022-06-20 13:02:53.731217
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    import os
    import tempfile
    from ansible_collections.community.general.plugins.modules import shell
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_provider
    import ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config
    cli = ConsoleCLI()
    cli.modules = ['shell']
    old_run = shell.run
    old_check_provider = ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config.check_provider
    old_load_provider = load_provider
    old_execute = ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils.execute
    old_run_comm

# Generated at 2022-06-20 13:03:04.478163
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console = ConsoleCLI()
    roles = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'integration', 'targets', 'test_collections_role', 'roles')
    plugins = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'integration', 'targets', 'test_collections_plugin', 'plugins')

# Generated at 2022-06-20 13:03:10.705436
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    c = ConsoleCLI(context.CLIARGS)
    # TODO: This is not really a unit test, just a smoke test.  Write proper unit tests
    #       when refactoring class ConsoleCLI. 
    c.cwd = 'all'
    assert 'all' == c.cwd
    c.do_cd('test')
    assert 'test' == c.cwd
    c.do_cd('')
    assert '*' == c.cwd
    c.do_cd('/*')
    assert 'all' == c.cwd



# Generated at 2022-06-20 13:03:11.696111
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    my_cli = ConsoleCLI()
    my_cli.do_list('groups')
    pass


# Generated at 2022-06-20 13:03:13.394107
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    console = ConsoleCLI()
    display.error = lambda x: None
    console.do_become_method("sudo")


# Generated at 2022-06-20 13:03:24.551766
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    context.CLIARGS = ImmutableDict()
    context.CLIARGS['diff'] = True
    context.CLIARGS['verbosity'] = 3
    context.CLIARGS['inventory'] = ['/test/test/test']
    context.CLIARGS['listhosts'] = 'example.com'
    context.CLIARGS['subset'] = 'foo'
    context.CLIARGS['syntax'] = True
    context.CLIARGS['timeout'] = 444
    context.CLIARGS['ask_vault_pass'] = True
    context.CLIARGS['vault_password_file'] = 'foo'
    context.CLIARGS['tags'] = ['foo', 'bar']
    context.CLIARGS['skip_tags'] = ['baz']
    context

# Generated at 2022-06-20 13:03:25.482991
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    pass


# Generated at 2022-06-20 13:03:29.918517
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    _, inventory, _ = ConsoleCLI._play_prereqs(['-t', 'console', 'all', '-i', 'localhost,'])
    selected_hosts = inventory.list_hosts('all')
    module_name = 'ping'
    # call check_raw_arg module directly, since it has been set to true in the code
    modules = ConsoleCLI._find_modules_in_path(module_name, selected_hosts, C.DEFAULT_MODULE_PATH)
    assert module_name in modules

# Generated at 2022-06-20 13:03:48.657855
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    pass



# Generated at 2022-06-20 13:03:53.811190
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    args = ['a', 'b', 'c']
    cli = ConsoleCLI(args)
    cli.default(*args)
    cli.default.__globals__['display'] = Mock(return_value = None)

    module = 'ping'
    module_args = None

    def func():
        class FakeTaskQueueManager:
            def run(self, play):
                return None

            def cleanup(self):
                return None

        cli.default.__globals__['TaskQueueManager'] = FakeTaskQueueManager
        try:
            cli.default(module, module_args)
        except Exception as e:
            assert False, 'Test failed with exception ' + str(e)

    func()


# Generated at 2022-06-20 13:03:54.511367
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    assert False

# Generated at 2022-06-20 13:04:02.979431
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Monkey patching
    args = dict(
        connection='ssh',
        module_path='/path/to/mymodules',
        forks=10,
        become=False,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        syntax=False,
        start_at_task=None
    )
    context.CLIARGS = ImmutableDict(args)

    # Args

# Generated at 2022-06-20 13:04:04.258271
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    pass

# Generated at 2022-06-20 13:04:07.449112
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cli=ConsoleCLI()
    #arg is not given
    display.verbosity=0
    cli.do_verbosity('')
    assert display.verbosity==0
    
    #arg is given
    cli.do_verbosity('3')
    assert display.verbosity==3
    

# Generated at 2022-06-20 13:04:17.250430
# Unit test for method do_become of class ConsoleCLI
def test_ConsoleCLI_do_become():
  # Input parameters
  arg = 'ansible_become'
  cli=ConsoleCLI()
  cli.become = 'ansible_become'
  cli.become_method = 'ansible_become_method'
  cli.become_user = 'ansible_become_user'
  cli.check_mode = 'ansible_check_mode'
  cli.diff = 'ansible_diff'
  cli.inventory = ''
  cli.remote_user = 'ansible_remote_user'
  cli.set_prompt = ''
  cli.task_timeout = 'ansible_task_timeout'
  # Expected return value
  output=False
  # Invoke method

# Generated at 2022-06-20 13:04:20.659268
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():

    console = ConsoleCLI()
    console.modules = ['setup', 'shell']

    try:
        console.helpdefault('setup')
        assert True
    except:
        assert False
    
    try:
        console.helpdefault('shell')
        assert True
    except:
        assert False

    try:
        console.helpdefault('shells')
        assert False
    except:
        assert True


# Generated at 2022-06-20 13:04:23.829717
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cli = ConsoleCLI()
    from ansible.cli.arguments import AnsibleCliArgs
    cli.options = AnsibleCliArgs( cli.parser, cli.sub, 'playbook', 'playbook')
    cli.options.verbosity = 2
    cli.display = display
    cli.do_verbosity('10')
    assert display.verbosity == 10


# Generated at 2022-06-20 13:04:27.629331
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    obj = ConsoleCLI(['console', '-i', 'hosts', '--extra-vars', '{"test_var": 7}'])
    cmd = 'yes'
    args = cmd.split()
    assert obj.do_diff(cmd) is False
    assert obj.do_diff('') is None



# Generated at 2022-06-20 13:05:53.614065
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    c = ConsoleCLI()
    c.set_prompt()


# Generated at 2022-06-20 13:05:59.971202
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    cli = ConsoleCLI(args=(), context=None)
    cli.modules = ['ping']
    cli.module_args('ping')



# Generated at 2022-06-20 13:06:03.823890
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    from ansible.cli.console import ConsoleCLI
    cli = ConsoleCLI()
    assert cli.default("shell ps uax") == False


# Generated at 2022-06-20 13:06:06.743014
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    p = ConsoleCLI()
    p.do_EOF()

if __name__ == "__main__":
    sys.exit(main())

# Generated at 2022-06-20 13:06:08.246573
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():

    consolecli = ConsoleCLI()

    consolecli.default()

# Generated at 2022-06-20 13:06:11.693667
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    consoleCLI = ConsoleCLI()
    host_list = consoleCLI.inventory.list_hosts("all")
    assert consoleCLI.get_host_list(consoleCLI.inventory, host_list, "all") == host_list

# Generated at 2022-06-20 13:06:19.790401
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    consoleCLI = ConsoleCLI()
    consoleCLI.cwd = "mygroup"
    consoleCLI.hosts = ['host1', 'host2', 'host3']
    consoleCLI.groups = ['group1', 'group2', 'group3']
    text = ''
    line = 'cd '
    begidx = 0
    endidx = 0
    assert consoleCLI.complete_cd(text, line, begidx, endidx) == consoleCLI.hosts + consoleCLI.groups
    
    consoleCLI.cwd = "all"
    assert consoleCLI.complete_cd(text, line, begidx, endidx) == consoleCLI.hosts + consoleCLI.groups
    
    consoleCLI.cwd = "*"
    assert consoleCLI.complete_cd

# Generated at 2022-06-20 13:06:21.011256
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    pass


# Generated at 2022-06-20 13:06:24.147549
# Unit test for method do_become of class ConsoleCLI
def test_ConsoleCLI_do_become():
    cli = ConsoleCLI()
    cli.do_become('')
    assert cli.become == False

# Generated at 2022-06-20 13:06:28.909370
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    context.CLIARGS['task_timeout'] = 0
    screen_manager.push_screen(ConsoleCLI)
    screen_manager.set_screen(ConsoleCLI)
    ret_val = ConsoleCLI().do_timeout("120")
    args = ''
    timeout = 0
    return (ret_val,args,timeout)


# Generated at 2022-06-20 13:07:20.492138
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
	assert True

# Generated at 2022-06-20 13:07:31.871171
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    # args is a instance of Namespace.
    args = mock.MagicMock()
    args.listtags = False
    args.listtasks = False
    args.listhosts = False
    args.syntax = False
    args.connection = 'ssh'
    args.module_path = None
    args.private_key_file = None
    args.forks = 5
    args.become_method = 'sudo'
    args.check = False
    args.diff = False
    args.remote_user = 'zhengchunyu'
    args.verbosity = 3
    args.timeout = 10
    args.pattern = ''
    args.start_at_task = None
    args.inventory = './inventory'
    args.ask_vault_pass = 'ask'
    args.ask_pass = False


# Generated at 2022-06-20 13:07:41.844634
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    my_consolecli = ConsoleCLI()
    try:
        my_consolecli.do_timeout('30')
        assert my_consolecli.task_timeout == 30
    except AssertionError:
        print('Test passed')
    try:
        my_consolecli.do_timeout('0')
        assert my_consolecli.task_timeout == 0
    except AssertionError:
        print('Test passed')
    x = my_consolecli.do_timeout('-1')
    assert x == None
    x = my_consolecli.do_timeout('abc')
    assert x == None
    x = my_consolecli.do_timeout('')
    assert x == None


# Generated at 2022-06-20 13:07:49.227466
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():

    class MyConsoleCLI(ConsoleCLI):

        def do_diff(self, arg):
            assert arg == 'yes'

    console = MyConsoleCLI()
    console.do_diff('yes')

# Generated at 2022-06-20 13:07:53.271938
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    console_no_keys = ConsoleCLI(args=dict(ask_pass=False, private_key_file=None))
    console_no_keys.onecmd("EOF")


# Generated at 2022-06-20 13:08:01.661508
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    # Create an object ConsoleCLI
    console_cli = ConsoleCLI()
    console_cli.do_remote_user("")
    console_cli.do_remote_user("root")
    console_cli.do_remote_user("")
    console_cli.do_remote_user("root")
    console_cli.do_remote_user("")
    console_cli.do_remote_user("root")
    console_cli.do_remote_user("root")
    console_cli.do_remote_user("")
    console_cli.do_remote_user("root")
    console_cli.do_remote_user("")
    console_cli.do_remote_user("root")

# Generated at 2022-06-20 13:08:03.323296
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    consoleCLI = ConsoleCLI()
    assert consoleCLI.do_exit() == -1, 'do_exit returned unexpected value'


# Generated at 2022-06-20 13:08:10.241630
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_cli = ConsoleCLI()
    console_cli._load_plugins()
    module_name = 'yum'
    mline = 'command'
    offs = 0
    assert(console_cli.module_args(module_name) == ['name', 'list', 'state', 'disablerepo', 'enablerepo', 'exclude', 'install_repoquery', 'installroot'])

# Generated at 2022-06-20 13:08:13.539748
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    args = context.CLIARGS
    console_cli = ConsoleCLI(args)
    console_cli.run()

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop()

# Generated at 2022-06-20 13:08:22.900052
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    import ansible
    import ansible.cli.console
    import ansible.inventory.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.plugins.callback
    import ansible.vars.manager
    import os
    import sys
    import yaml
    inv_content = '''all:
  hosts:
    localhost:
      ansible_connection: local'''
    inventory = ansible.inventory.manager.InventoryManager(
        loader=ansible.parsing.dataloader.DataLoader(),
        sources=[inv_content]
    )

    play_context = ansible.playbook.play.PlayContext()