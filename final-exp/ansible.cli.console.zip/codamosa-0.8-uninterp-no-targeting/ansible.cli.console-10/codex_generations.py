

# Generated at 2022-06-20 13:03:54.293456
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    # setup
    cli = ConsoleCLI()

    # execute
    cli.do_forks("test")

    # assert
    assert cli.forks == "test"



# Generated at 2022-06-20 13:03:58.805163
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    # Initialize the object ConsoleCLI
    console=ConsoleCLI()
    # Call the method do_check with an argument
    console.do_check("yes")
    # Check the result  
    assert console.check_mode == True
    # Check the result
    console.do_check("no")
    assert console.check_mode == False

# Generated at 2022-06-20 13:03:59.426989
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    pass

# Generated at 2022-06-20 13:04:01.983737
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    builtins.display = Display()
    obj = ConsoleCLI()
    obj.do_timeout('1')


# Generated at 2022-06-20 13:04:09.747704
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        with patch('sys.stderr') as m_stderr:
            ConsoleCLI().post_process_args(options=None, args=None)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        with patch('sys.stderr') as m_stderr:
            ConsoleCLI().post_process_args(options=MagicMock(subset=True, pattern=True), args=None)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1


# Generated at 2022-06-20 13:04:12.839075
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    # setup
    cli = ConsoleCLI()

    # invocation
    modules = cli.list_modules()

    # assertions
    assert len(modules) > 20
    assert 'ping' in modules
    assert 'command' in modules



# Generated at 2022-06-20 13:04:15.354737
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_cli = ConsoleCLI()
    console_cli.cmdloop()

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop() # pragma: no cover

# Generated at 2022-06-20 13:04:20.732658
# Unit test for method do_shell of class ConsoleCLI

# Generated at 2022-06-20 13:04:21.846183
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    # ansible.console tests.unit.test_console.test_ConsoleCLI_do_EOF()
    assert True

# Generated at 2022-06-20 13:04:29.097555
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    consoleCLI = ConsoleCLI()
    consoleCLI.cwd = ['localhost']
    consoleCLI.task_timeout = 60
    consoleCLI.forks = 5
    consoleCLI.become = False
    consoleCLI.become_method = 'sudo'
    consoleCLI.become_user = 'root'
    consoleCLI.check_mode = False
    consoleCLI.diff = False
    consoleCLI.remote_user = 'vagrant'
    consoleCLI.selected = ['localhost']
    consoleCLI.inventory = 1
    consoleCLI.variable_manager = 1
    consoleCLI.loader = 1
    consoleCLI._play_prereqs_for_host = 1

    #Testing for existence of a module that does exist
    assert consoleCLI.default('setup') == False

    #

# Generated at 2022-06-20 13:04:54.430095
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    cli = ConsoleCLI()
    cli.modules = ['ping']
    assert cli.completedefault('', 'ping', 0, 4) == ['password=']
    cli.modules = ['setup']
    assert cli.completedefault('', 'setup', 0, 5) == ['ansible_architecture', 'ansible_all_ipv4_addresses', 'ansible_all_ipv6_addresses', 'ansible_all_unique_ipv4_addresses', 'ansible_all_unique_ipv6_addresses']

# Generated at 2022-06-20 13:04:59.581185
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    consoleCLI = ConsoleCLI()
    assert consoleCLI.get_names() == [ 'EOF', 'become', 'become_method', 'become_user', 'cd', 'check', 'diff', 'do_become', 'do_become_method', 'do_become_user', 'do_cd', 'do_check', 'do_diff', 'do_forks', 'do_list', 'do_remote_user', 'do_shell', 'do_timeout', 'do_verbosity', 'emptyline', 'helpdefault', 'start', 'start_shell', 'test', 'test_ConsoleCLI_get_names', 'test_ConsoleCLI_run' ]

# Generated at 2022-06-20 13:05:03.440827
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    console = ConsoleCLI()
    parser = console.init_parser()
    assert isinstance(parser, argparse.ArgumentParser)


# Generated at 2022-06-20 13:05:15.187803
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    config_instance = config.Config()
    config_instance.parse()
    display_instance = display.Display()
    cli_instance = ConsoleCLI(config_instance, display_instance)
    # test case 1
    cli_instance.diff = True
    cli_instance.do_diff('no')
    assert cli_instance.diff == False
    # test case 2
    cli_instance.do_diff('yes')
    assert cli_instance.diff == True
    # test case 3
    cli_instance.do_diff()
    # test case 4
    cli_instance.do_diff('')
    # test case 5
    cli_instance.do_diff('test')
    # test case 6
    cli_instance.do_diff('1')
    assert cli_instance.diff

# Generated at 2022-06-20 13:05:23.085805
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console = ConsoleCLI()
    console.modules = ['command']
    module_name = 'command'

    in_path = module_loader.find_plugin(module_name)
    if in_path:
        oc, a, _, _ = plugin_docs.get_docstring(in_path, fragment_loader)
        if oc:
            display.display(oc['short_description'])
            display.display('Parameters:')
            for opt in oc['options'].keys():
                display.display('  ' + stringc(opt, self.NORMAL_PROMPT) + ' ' + oc['options'][opt]['description'][0])
        else:
            display.error('No documentation found for %s.' % module_name)

# Generated at 2022-06-20 13:05:31.858602
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Dummy class, just to instantiate
    class DummyCLIArgs:
        inventory = None
        subset = None
        module_path = None
        pattern = None
        forks = None
        ask_pass = None
        ask_become_pass = None
        become_ask_pass = None
        diff = None
        remote_user = None
        become_user = None
        become = None
        become_method = None
        check = None

    console_cli = ConsoleCLI(DummyCLIArgs)
    assert console_cli.cmdloop() == -1

# Generated at 2022-06-20 13:05:37.908547
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Should set group list to groups
    try:
        c = ConsoleCLI()
        c.groups = ['group1','group2','group3','group4','group5','group6']
        c.do_list('groups')
        assert True
    except:
        assert False
    # Should set host list to hosts
    try:
        c = ConsoleCLI()
        c.groups = ['group1','group2','group3','group4','group5','group6']
        c.do_list('')
        assert True
    except:
        assert False

# Generated at 2022-06-20 13:05:41.792656
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    #arrange
    console_cli = ConsoleCLI()
    
    #act
    console_cli.do_diff(True)
    #assert
    assert True

# Generated at 2022-06-20 13:05:44.161288
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    cli = ConsoleCLI()
    res = cli.emptyline()
    assert res == None


# Generated at 2022-06-20 13:05:53.245161
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    # This unit test will pass if the do_verbosity method of the class ConsoleCLI
    # is called as 'do_verbosity'.
    # In other words, it tests if the method do_verbosity calls set_verbosity method.
    print('Test do_verbosity of class ConsoleCLI')
    try:
        print('Execute real program')
        main()
        print('Successful test')
    except Exception as err:
        print('Failed test')
        raise err

if __name__ == '__main__':
    test_ConsoleCLI_do_verbosity()

# Generated at 2022-06-20 13:07:22.765990
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    ansible_console_cli = ConsoleCLI()
    runner = CliRunner()
    result = runner.invoke(ansible_console_cli.post_process_args, [])
    assert result.exit_code == 0

# Generated at 2022-06-20 13:07:24.602408
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    with pytest.raises(SystemExit):
        cli = ConsoleCLI()
        cli.list_modules()

# Generated at 2022-06-20 13:07:34.988120
# Unit test for method do_remote_user of class ConsoleCLI

# Generated at 2022-06-20 13:07:45.368656
# Unit test for method complete_cd of class ConsoleCLI

# Generated at 2022-06-20 13:07:50.611353
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
  '''
  Test method get_names of ConsoleCLI class
  '''
  console = ConsoleCLI()
  console.get_names()
  assert True

test_ConsoleCLI_get_names()

# Generated at 2022-06-20 13:07:55.909826
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    # Mock the constructor of ConsoleCLI class, since it's impossible to call the super class constructor __init__()
    # outside of it.
    with patch.object(ConsoleCLI, '__init__', lambda self: None):
        # Make sure the constructor of ConsoleCLI class won't raise any exceptions.
        ConsoleCLI()

# Generated at 2022-06-20 13:07:56.521275
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    pass

# Generated at 2022-06-20 13:07:59.066504
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    from ansible.cli.console import ConsoleCLI
    module = 'command'
    # c = ConsoleCLI()
    # c.module_args(module_name)


# Generated at 2022-06-20 13:08:04.671866
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    ccli = ConsoleCLI()
    assert ccli.check_mode == None 
    ccli.do_check('True')
    assert ccli.check_mode == True

# Generated at 2022-06-20 13:08:16.700609
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    args = lambda: None
    args.forks = 5
    args.become = False
    args.become_method = 'sudo'
    args.become_user = 'root'
    args.check = False
    args.diff = False
    args.listhosts = None
    args.module_path = None
    args.pattern = None
    args.remote_user = 'root'
    args.subset = None
    args.tags = 'all'
    args.skip_tags = None
    args.ask_vault_pass = False
    args.ask_sudo_pass = False
    args.ask_su_pass = False
    args.vault_password_file = None
    args.new_vault_password_file = None
    args.module_paths = None

# Generated at 2022-06-20 13:09:03.217438
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    assert len(ConsoleCLI().list_modules()) > 0

# Generated at 2022-06-20 13:09:17.580880
# Unit test for constructor of class ConsoleCLI

# Generated at 2022-06-20 13:09:23.962660
# Unit test for method do_timeout of class ConsoleCLI

# Generated at 2022-06-20 13:09:25.926591
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    from ansible.cli.console import ConsoleCLI
    ConsoleCLI.do_forks(self, arg)


# Generated at 2022-06-20 13:09:32.763238
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cli_inst = ConsoleCLI()
    assert 'ping' in console_cli_inst.list_modules()
    assert 'setup' in console_cli_inst.list_modules()

# Generated at 2022-06-20 13:09:35.630220
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    # Instantiates class
    shell = ConsoleCLI()

    # Unit test
    assert shell.do_EOF() == -1

# Generated at 2022-06-20 13:09:38.120766
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    ccli = ConsoleCLI()
    ccli.do_verbosity("3")
    assert display.verbosity==3


# Generated at 2022-06-20 13:09:41.406648
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    console_cli = ConsoleCLI()
    console_cli.do_become_method("su")
    assert console_cli.become_method == "su"


# Generated at 2022-06-20 13:09:49.644733
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    # Instantiate a mock ConsoleCLI object
    console = ConsoleCLI()

    # Set the 'remote_user' attribute
    console.remote_user = 'mock_remote_user'

    # Set the 'prompt' attribute
    console.prompt = 'mock_prompt'

    # Create a mock set_prompt method
    def mock_set_prompt():
        console.prompt = 'mock_set_prompt'
    console.set_prompt = mock_set_prompt

    # Create a mock display.display method
    def mock_display_display(msg):
        return msg
    display.display = mock_display_display


    # Call the method do_remote_user with arg
    console.do_remote_user('mock_arg')

    # Check that the function call was successful

# Generated at 2022-06-20 13:09:56.026877
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
        
    ConsoleCLI = console.ConsoleCLI()

# Generated at 2022-06-20 13:11:11.628299
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    pass

# Generated at 2022-06-20 13:11:14.557111
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    ccli = ConsoleCLI()
    arg = "1"
    ccli.do_verbosity(arg)
    assert display.verbosity == 1


# Generated at 2022-06-20 13:11:22.738974
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    # create object
    console_cli = ConsoleCLI()
    # test with valid input
    timeout = '120'
    console_cli.do_timeout(timeout)
    # test with invalid input
    timeout = '-1'
    console_cli.do_timeout(timeout)
    timeout = 'invalid'
    console_cli.do_timeout(timeout)

if __name__ == '__main__':
    test_ConsoleCLI_do_timeout()

# Generated at 2022-06-20 13:11:23.918184
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    console_cli = ConsoleCLI()
    console_cli.do_timeout(3)

# Generated at 2022-06-20 13:11:25.773393
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    console = ConsoleCLI()
    console.do_forks('')
    assert 1


# Generated at 2022-06-20 13:11:30.957190
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    args = []
    with pytest.raises(AnsibleOptionsError):
        ConsoleCLI(args)


# Generated at 2022-06-20 13:11:42.738603
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    obj = ConsoleCLI()
    cli_options = obj.option_parser.parse_args([])
    context.CLIARGS = AttributeDict(**cli_options.__dict__)

    # Setting default values
    obj.remote_user = context.CLIARGS['remote_user']
    obj.become = context.CLIARGS['become']
    obj.become_user = context.CLIARGS['become_user']
    obj.become_method = context.CLIARGS['become_method']
    obj.check_mode = context.CLIARGS['check']
    obj.diff = context.CLIARGS['diff']
    obj.forks = context.CLIARGS['forks']

# Generated at 2022-06-20 13:11:48.291071
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    cli = ConsoleCLI({
        'inventory': "tests/test_inventories/test_inventory",
        'module_path': "tests/test_modules/",
        'module_lang': "powershell",
        'pattern': 'all',
        'forks': 100,
        'ask-pass': False,
        'ask-become-pass': False,
    })
    cli.do_cd('webservers')
    cli.do_list([])
    cli.do_cd('../')
    cli.do_list('groups')

if __name__ == "__main__":
    ConsoleCLI().run()

# Generated at 2022-06-20 13:11:57.947812
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    consolecli = ConsoleCLI()
    consolecli.modules = ['ping', 'wait_for']
    consolecli.module_args = mock.MagicMock(side_effect=["foo", "bar"])
    module_args_result_1 = ["foo", "bar"]

    module_args_result_2 = ["command", "path", "use_regex"]
    consolecli.module_args = mock.MagicMock(side_effect=[module_args_result_1, module_args_result_2])

    text = "w"
    line = "wait_for command"
    begidx = 0
    endidx = 0
    result = consolecli.completedefault(text, line, begidx, endidx)
    assert  result == ["ait_for command"]
