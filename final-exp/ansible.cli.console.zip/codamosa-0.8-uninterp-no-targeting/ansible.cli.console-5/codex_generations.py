

# Generated at 2022-06-20 13:02:55.067166
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    # create an instance of class ConsoleCLI
    test_obj = ConsoleCLI()
    # test if the first argument is equal to the second argument
    assert test_obj.do_shell("shell ps uax | grep java | wc -l") == False
    # test if the first argument is equal to the second argument
    assert test_obj.do_shell("shell killall python") == False
    # test if the first argument is equal to the second argument
    assert test_obj.do_shell("shell halt -n") == False
    # test if the first argument is equal to the second argument
    assert test_obj.do_shell("!ps aux | grep java | wc -l") == False



# Generated at 2022-06-20 13:03:06.056845
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Arrange
    command_line_args = Mock()
    command_line_args.verbosity = None
    context.CLIARGS = command_line_args
    command_line_args.connection = None
    context.settings = {}
    context.settings['DEFAULT_MODULE_PATH'] = '/usr/local/lib/python3.4/dist-packages/ansible/modules/'
    command_line_args.become_method = None
    command_line_args.subset = None
    command_line_args.ask_pass = None
    command_line_args.private_key_file = None
    command_line_args.timeout = None
    command_line_args.remote_user = None
    command_line_args.check = None
    command_line_args.step = None

# Generated at 2022-06-20 13:03:10.497283
# Unit test for method get_names of class ConsoleCLI

# Generated at 2022-06-20 13:03:11.557961
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    assert hasattr(ConsoleCLI, 'get_names')

# Generated at 2022-06-20 13:03:18.254555
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    # The following two lines are to work around a bug in pytest. You may remove them if you're not using pytest.
    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..')))

    # Now we can import stuff from the top-level directory
    from ansible import context
    from ansible.cli import CLI
    from ansible.cli.console import ConsoleCLI

    # Initialize the interactive shell
    cli = CLI(['ansible-console'])
    cli.parse()
    context.CLIARGS = cli.args
    consolecli = ConsoleCLI()
    consolecli.setup()

    # Check that argument becomes enabled
    consolecli.do_check("True")
   

# Generated at 2022-06-20 13:03:26.641342
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    '''
    Unit test method ConsoleCLI.do_become_method()
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', dest='targets')
    parser.add_argument('-T', dest='timeout')
    parser.add_argument('--private', dest='private')
    parser.add_argument('--host-key-check', dest='host_key_check')
    parser.add_argument('--syntax-check', dest='syntax_check', action='store_true')
    parser.add_argument('--list-hosts', dest='list_hosts', action='store_true')
    parser.add_argument('-i', dest='inventory', required=True)

# Generated at 2022-06-20 13:03:29.345852
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    a = ConsoleCLI()
    assert a.get_names() == ['do_cd', 'do_check', 'do_diff', 'do_exit', 'do_forks', 'do_list', 'do_shell', 'do_verbosity', 'emptyline', 'help_EOF']


# Generated at 2022-06-20 13:03:30.317463
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    ConsoleCLI.do_EOF('arg')

# Generated at 2022-06-20 13:03:40.164395
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    # test args
    # args
    parser = ConsoleCLI.init_parser(None, None, None)


# Generated at 2022-06-20 13:03:41.130850
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    #FIXME
    pass



# Generated at 2022-06-20 13:04:07.281865
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    play = dict(
        name="Ansible Shell"
    )
    play = Play().load(play, variable_manager=VariableManager(), loader=DataLoader())
    console = ConsoleCLI(play)
    console.set_prompt()

# Generated at 2022-06-20 13:04:12.046312
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    """
    Tests that ConsoleCLI.do_EOF() returns -1
    """
    cli = ConsoleCLI()
    assert cli.prepare() != -1
    assert cli.do_EOF(None) == -1


# Generated at 2022-06-20 13:04:19.647059
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    # Unit test for method do_EOF of class ConsoleCLI

    from ansible.plugins.loader import module_loader
    # test case for module ansible.plugins.loader
    # test case for class AnsibleLoader

    # Test subprocess.call
    assert subprocess.call(["sleep","0.01"])==0

    # Test os.chdir
    ospath = os.path.join(os.path.dirname(__file__), '../lib/ansible/module_utils')
    try:
        os.chdir(ospath)
    except OSError:
        assert False

    # Test os.environ
    try:
        os.environ['HOME']
    except KeyError:
        assert False

    # Test sys.stdout.isatty
    assert sys.stdout.isatty

# Generated at 2022-06-20 13:04:23.103729
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    results = check_args(ConsoleCLI.do_timeout)
    if isinstance(results, list):
        for i in results:
            assert i[0]
            if i[0]:
                assert i[1] == i[2]


# Generated at 2022-06-20 13:04:26.249472
# Unit test for method do_become_user of class ConsoleCLI
def test_ConsoleCLI_do_become_user():
    """Test method ConsoleCLI.do_become_user"""
    console = ConsoleCLI()
    console.init()

    assert console.do_become_user('') == None
    assert console.do_become_user('test') == None



# Generated at 2022-06-20 13:04:33.512530
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    from ansible.cli.console import ConsoleCLI

    console = ConsoleCLI()
    console.selected = [
        Host('example1', None),
        Host('example2', None),
        Host('example3', None),
    ]

    console.do_list('')
    assert console.stdout.getvalue() == 'example1\nexample2\nexample3\n'

    console.do_list('groups')
    assert console.stdout.getvalue() == 'example1\nexample2\nexample3\n'



# Generated at 2022-06-20 13:04:35.024636
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():

    c = ConsoleCLI()
    c.do_remote_user("root")


# Generated at 2022-06-20 13:04:37.538736
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    cli = ConsoleCLI()
    pats = "*"
    res_list_modules = cli._find_modules_in_path(pats)
    assert type(res_list_modules) == str

# Generated at 2022-06-20 13:04:38.081218
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    pass

# Generated at 2022-06-20 13:04:44.796757
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible_collections.ansible.community.plugins.module_utils.common.text.converters import to_text
    from ansible_collections.ansible.community.plugins.module_utils.connection import Connection
    from ansible_collections.ansible.community.plugins.loader import fragment_loader
    from ansible_collections.ansible.community.plugins.loader import module_loader
    from ansible_collections.ansible.community.plugins.loader import AnsibleLoader
    from ansible_collections.ansible.community.plugins.module_utils.splitter import split_args

    class TestConsoleCLI():
        def __init__(self):
            self.connection = Connection(None)
            self.loader

# Generated at 2022-06-20 13:07:38.267975
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    
    # Initializing test case
    setUpTestCase()
    
    def _mock_do_timeout_called(self, arg):
        _mock_do_timeout_called.called = True
        
    def _mock_do_timeout_called_with(self, arg):
        _mock_do_timeout_called_with.called_with = arg
        
    _mock_do_timeout_called.called = False
    _mock_do_timeout_called_with.called_with = None
    
    # Testing with no timeout
    cli.ConsoleCLI.do_timeout = _mock_do_timeout_called
    
    cli.ConsoleCLI.onecmd(cli.ConsoleCLI(), "timeout")
    assert _mock_do_timeout_called.called == True
    
   

# Generated at 2022-06-20 13:07:39.865522
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Method completedefault of class ConsoleCLI
    assert False

# Generated at 2022-06-20 13:07:48.232831
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    fake_args = {}
    fake_args['host_file'] = 'hosts'
    fake_args['host'] = 'localhost'
    fake_args['user'] = 'root'
    fake_args['vault_pass'] = 'test'
    fake_args['ask_pass'] = False
    fake_args['ask_password'] = False

    # force use of ssh instead of paramiko
    fake_args['connection'] = 'ssh'
    fake_args['module_path'] = '.'
    fake_args['private_key_file'] = 'key'
    fake_args['timeout'] = 10
    fake_args['forks'] = 10
    fake_args['become'] = True
    fake_args['become_method'] = 'su'
    fake_args['become_user'] = 'admin'


# Generated at 2022-06-20 13:08:00.191340
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    mock_obj = mock.Mock()
    mock_obj.selected = None
    mock_obj.inventory = None
    mock_obj.remote_user = None
    mock_obj.become = None
    mock_obj.become_user = None
    mock_obj.become_method = None
    mock_obj.check_mode = None
    mock_obj.diff = None
    mock_obj.forks = None
    mock_obj.task_timeout = None
    mock_obj.variable_manager = None

    mock_text = 'text'
    mock_line = 'line'
    mock_begidx = 1
    mock_endidx = 10
    mock_args = [mock_text, mock_line, mock_begidx, mock_endidx]

# Generated at 2022-06-20 13:08:07.712258
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    localhost = dict(
        ansible_connection='local',
        ansible_python_interpreter='python'
    )
    def mock_list_hosts(self, pattern):
        return [inventory_manager.Host(name='localhost', vars=localhost)]

    mock_get_host_list = MagicMock(side_effect=mock_list_hosts)
    setattr(inventory_manager.InventoryManager, 'list_hosts', mock_get_host_list)

    console = ConsoleCLI(args=['--connection', 'local'])
    module_name = 'setup'
    args = console.module_args(module_name)
    assert args == ["gather_subset", "gather_timeout", "filter"]

    module_name = 'win_group'
    args = console.module_args

# Generated at 2022-06-20 13:08:11.780900
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    console = ConsoleCLI()
    assert console.do_check("yes") == False
    assert console.do_check("no") == False
    assert console.do_check("") == False
    assert console.do_check() == False

# Generated at 2022-06-20 13:08:15.181525
# Unit test for method default of class ConsoleCLI

# Generated at 2022-06-20 13:08:23.163214
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print("testing method cmdloop of class ConsoleCLI")
    ConsoleCLI.default = dummyfunc
    ConsoleCLI.emptyline = dummyfunc
    ConsoleCLI.helpdefault = dummyfunc
    ConsoleCLI.module_args = dummyfunc
    ConsoleCLI.run = dummyfunc
    ConsoleCLI.do_run = dummyfunc
    ConsoleCLI.do_play = dummyfunc
    ConsoleCLI.do_playbook = dummyfunc
    ConsoleCLI.do_launch = dummyfunc
    ConsoleCLI.do_replay = dummyfunc
    ConsoleCLI.run_tree = dummyfunc
    ConsoleCLI.do_listtasks = dummyfunc
    ConsoleCLI.do_tree = dummyfunc
    ConsoleCLI.do_syntax = dummyfunc
    ConsoleCLI.do_history = dummyfunc
    ConsoleCLI.do

# Generated at 2022-06-20 13:08:24.379063
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    sut = ConsoleCLI()
    sut.emptyline()

# Generated at 2022-06-20 13:08:29.916462
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    # Instantiation of class ConsoleCLI
    obj = ConsoleCLI()

    # Method do_forks of ConsoleCLI is called with arg '1'
    obj.do_forks('1')

    # Method cmdloop of ConsoleCLI is called
    obj.cmdloop()

    # Method postloop of ConsoleCLI is called
    obj.postloop()



# Generated at 2022-06-20 13:09:41.758655
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    print("Test: test_ConsoleCLI_do_shell")

    console = ConsoleCLI(args)
    console.run()
    return

test_ConsoleCLI_do_shell()


# Generated at 2022-06-20 13:09:44.582292
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    ansible_console = ConsoleCLI()
    module_name = 'ping'
    ansible_console.do_module_name=module_name
    ansible_console.helpdefault(module_name)

# Generated at 2022-06-20 13:09:50.420160
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    console_cli = ConsoleCLI()
    console_cli.do_check('false')
    console_cli.do_become('true')
    console_cli.do_check('true')

if __name__ == '__main__':
    test_ConsoleCLI_do_check()

# Generated at 2022-06-20 13:09:53.770395
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    consolecli = ConsoleCLI()
    assert 2 == len(consolecli.get_names())


# Generated at 2022-06-20 13:09:58.710837
# Unit test for method do_become_user of class ConsoleCLI
def test_ConsoleCLI_do_become_user():
    user = 'bob'
    mocker.patch('ansible.cli.console.ConsoleCLI.set_prompt')
    ansible_console = ConsoleCLI([])
    ansible_console.do_become_user(user)
    assert ansible_console.become_user == user


# Generated at 2022-06-20 13:10:05.258583
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_cli = ConsoleCLI()
    with mock.patch.object(ConsoleCLI, 'cmdloop') as mock_cmdloop:
        result = console_cli.cmdloop()
        assert result is None

# Generated at 2022-06-20 13:10:16.064923
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    from ansible.utils.color import colorize
    sshpass, becomepass = ansible.plugins.console.ConsoleCLI.ask_passwords()

# Generated at 2022-06-20 13:10:31.847697
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():

    # Testing defaults for function default
    display_success = True
    display_failure = False

    # Testing with valid argument
    if (ConsoleCLI.default('ping', True) != False):
        display_success = False
    if (ConsoleCLI.default('ping', False) != False):
        display_success = False

        # Testing with invalid argument
    if (ConsoleCLI.default('pingg', True) != False):
        display_success = False
    if (ConsoleCLI.default('pingg', False) != False):
        display_success = False
    if display_success:
        display.display('test_ConsoleCLI_default - Successful')
    else:
        display_failure = True
        display.display('test_ConsoleCLI_default - Failure')

    # Testing with valid arguments

# Generated at 2022-06-20 13:10:35.399639
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():

    # Throws an exception if the command cannot be loaded
    def _load_command(cmd_name):
        cls = load_callback_plugin(cmd_name, False)

    # Normal module
    _load_command('system')

    # Unit tests
    _load_command('ping')
    _load_command('setup')

# Generated at 2022-06-20 13:10:46.184849
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    from __main__ import ConsoleCLI
    print("Test of method do_diff() of class ConsoleCLI")
    # Test 1
    print("Test 1:")
    myConsole = ConsoleCLI()
    myConsole.do_diff("True")
    assert myConsole.diff
    myConsole.do_diff("False")
    assert not myConsole.diff
    myConsole.do_diff("")
    assert myConsole.diff