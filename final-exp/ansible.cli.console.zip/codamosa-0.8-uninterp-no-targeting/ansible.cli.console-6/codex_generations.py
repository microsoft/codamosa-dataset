

# Generated at 2022-06-20 13:04:09.277299
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    mocker.patch('readline.read_history_file')
    mocker.patch('readline.write_history_file')
    mocker.patch('ansible.console.api.ConsoleCLI._play_prereqs')
    mocker.patch('ansible.console.api.ConsoleCLI.get_host_list')
    mocker.patch('ansible.console.docopt.docopt')
    mocker.patch('ansible.console.docopt.format_usage')
    mocker.patch('ansible.console.docopt.format_version')
    mocker.patch('ansible.plugins.loader.fragment_loader.get')
    mocker.patch('ansible.plugins.loader.module_loader.find_plugin')

# Generated at 2022-06-20 13:04:18.127250
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    # Mock() the inputs and outputs of the modules
    monkeypatch.setattr(display, 'error', lambda x: None)
    monkeypatch.setattr(sys, 'stdout', MagicMock())
    monkeypatch.setattr(sys, 'stdout.write', MagicMock())
    monkeypatch.setattr(sys, 'stdout.flush', lambda x: None)
    monkeypatch.setattr(sys, 'stdin', MagicMock())
    monkeypatch.setattr(sys, 'stdin.readline', lambda x: 'EOF')
    monkeypatch.setattr(sys, 'stdin.read', lambda x: 'EOF')
    monkeypatch.setattr(sys, 'stdin.flush', lambda x: None)

# Generated at 2022-06-20 13:04:20.264246
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    cons = ConsoleCLI()
    command = 'apt'
    args = dict(name = 'apt')
    args_ansible = dict(name = 'apt')
    cons.default(command, args)
    assert cons.default(command, args_ansible) == False



# Generated at 2022-06-20 13:04:23.371445
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    # Test with an existing module
    m = ConsoleCLI()
    assert m.module_args('command') == ['_raw_params', '_uses_shell', 'argv',
                                       'chdir', 'creates', 'executable',
                                       'removes', 'stdin', 'warn']

    # Test with a non-existing module
    assert m.module_args('doesnothave') == []



# Generated at 2022-06-20 13:04:30.256519
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    args = CmdLineArgs(['-i', 'localhost,'])
    cli = ConsoleCLI(args)
    cli.do_check('yes')
    assert cli.check_mode == True
    cli.do_check('no')
    assert cli.check_mode == False
    cli.do_check('0')
    assert cli.check_mode == False
    cli.do_check('1')
    assert cli.check_mode == True
    cli.do_check('asdf')
    assert cli.check_mode == True
    cli.do_check('')
    assert cli.check_mode == True


# Generated at 2022-06-20 13:04:39.888341
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    import sys
    import ansible.cli.console as console

    console.context = context.CLI()
    console.context.load_config_file()

    mock_sys_exit = Mock(name='sys_exit')
    mock_sys_argv = ['/Library/Frameworks/Python.framework/Versions/3.6/bin/ansible', 'console', '-i', 'localhost,']
    mock_sys_argv2 = ['/Library/Frameworks/Python.framework/Versions/3.6/bin/ansible', 'console', '-i', 'localhost,', '-m', 'setup']
    mock_sys_stdin = Mock()
    mock_sys_stdout = Mock()
    mock_sys_stdout.encoding = 'UTF-8'
    mock_sys_stdout.errors = 'strict'

   

# Generated at 2022-06-20 13:04:41.415204
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console = ConsoleCLI()
    console.default('ping')


# Generated at 2022-06-20 13:04:44.235522
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    modules_list = ConsoleCLI.list_modules()
    assert(type(modules_list) == list)
    assert(len(modules_list) > 0)
    assert(isinstance(modules_list[0], str))


if __name__ == '__main__':
    ConsoleCLI().run()

# Generated at 2022-06-20 13:04:54.274255
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    """
        ansible console --module-path <module_path> --inventory <inventory_file>
    """
    module_path = "../plugins/modules/"
    inventory_file = "./hosts"

    modules = [x for x in os.listdir(module_path) if not x.endswith('.pyc') and not x.startswith('.')]
    modules = [x[:-3] for x in modules if os.path.isfile(os.path.join(module_path, x))]

    def parametrize_assert(obj, module_name):
        in_path = module_loader.find_plugin(module_name)
        if in_path:
            oc, a, _, _ = plugin_docs.get_docstring(in_path, fragment_loader)

# Generated at 2022-06-20 13:04:55.388441
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
  # FIXME: Write unit test
  pass

# Generated at 2022-06-20 13:05:28.251045
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():

    # basic constructor invocation
    args = ['-v', '-k', '-K', '-u', 'remote_user', '-b', '-B', '10', '-T', '10',
            '-t', 'tags', '--list-hosts', '--list-tasks', '--list-tags', '--list-all',
            '-m', 'module_name', '--syntax-check', '--diff', '--check', 'become_method', 'become_user',
            'inventory', 'host_pattern']

    console_cli = ConsoleCLI(args)

    assert console_cli

# Generated at 2022-06-20 13:05:33.580359
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console = ConsoleCLI()
    assert console.module_args('rabbitmq_user') == ['name', 'password', 'force', 'login_user', 'login_password',
                                                    'login_host', 'login_port', 'vhost', 'tags']


if __name__ == '__main__':
    cli = ConsoleCLI()
    cli.run()

# Generated at 2022-06-20 13:05:37.828236
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    pass

# Generated at 2022-06-20 13:05:50.781443
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    cm = context.CLIARGS

    def _reload_context():
        cm.reload()

    _reload_context()

    # set some valid values for context.CLIARGS
    cm['become'] = True
    cm['become_method'] = 'su'
    cm['become_user'] = 'root'
    cm['module_path'] = './lib'
    cm['forks'] = 10
    cm['pattern'] = 'all'
    cm['subset'] = 'all'
    cm['diff'] = False
    cm['remote_user'] = 'root'
    cm['check'] = False
    cm['task_timeout'] = 60
    cm['listhosts'] = False
    cm['listtasks'] = False
    cm['listtags'] = False
    cm['syntax']

# Generated at 2022-06-20 13:05:54.536222
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    # Given
    cli = ConsoleCLI()
    user = 'jenkins'

    # When
    cli.do_remote_user(user)
    res = cli.remote_user

    # Then
    assert res == user


# Generated at 2022-06-20 13:05:55.795523
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    cli = ConsoleCLI()
    assert cli.emptyline() == None


# Generated at 2022-06-20 13:06:04.367860
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    plugin_dir = 'plugins/action/'
    test_module_loader = ModuleLoader(plugin_dir)
    cli = ConsoleCLI(module_loader=test_module_loader)
    assert set(cli.list_modules()) == set(['ping', 'setup', 'ping', 'setup', 'ping', 'setup', 'ping', 'setup'])
# Test pattern parsing for more than one host:

# Generated at 2022-06-20 13:06:15.006971
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    consolecli = ConsoleCLI()

# Generated at 2022-06-20 13:06:18.305239
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    test_obj = ConsoleCLI()
    assert test_obj.do_forks("4") == None

# Generated at 2022-06-20 13:06:21.586469
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    test_case = unittest.TestCase()
    test_case.assertEqual(ConsoleCLI.do_EOF(None, None), -1)


# Generated at 2022-06-20 13:07:17.676971
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    """
    Test function for class ConsoleCLI's method do_check

         :param self:
    """
    self = ConsoleCLI()
    arg = argparse.Namespace()
    arg.become = False
    self.do_check(arg)



# Generated at 2022-06-20 13:07:23.435949
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    r = ConsoleCLI()
    # Testing when arg is set
    r.do_remote_user('foo')
    assert r.remote_user == 'foo'
    # Testing when arg is not set
    r.do_remote_user(None)
    assert r.remote_user is None


# Generated at 2022-06-20 13:07:24.771264
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
  consolecli = ConsoleCLI()
  consolecli.default("module")


# Generated at 2022-06-20 13:07:30.279131
# Unit test for method do_become of class ConsoleCLI
def test_ConsoleCLI_do_become():
    console_cli = ConsoleCLI(args=dict(pattern='all'))
    with pytest.raises(Exception) as excinfo:
        console_cli.do_become('')
    assert 'Please specify become value, e.g. `become yes`' in to_text(excinfo.value)



# Generated at 2022-06-20 13:07:41.502449
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    # Test with subset of hosts
    class DummyCLIArgs(object):
        def __init__(self):
            self.subset = 'localhost,'
            self.pattern = 'all'
            self.become = False
            self.become_user = 'root'
            self.become_method = 'sudo'
            self.check = False
            self.diff = False
            self.forks = 5
            self.remote_user = 'root'
            self.timeout = 10
            self.extra_vars = None

    context.CLIARGS = DummyCLIArgs()

    cli = ConsoleCLI()
    cli.run()

    # Test without subset of hosts
    class DummyCLIArgs(object):
        def __init__(self):
            self.subset = None

# Generated at 2022-06-20 13:07:46.812470
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cc = ConsoleCLI()
    cc._play_prereqs = Mock(return_value=(None, None, None))
    cc.prompt = '(ansible-console:test) >'

    cc.do_verbosity('2')
    assert display.verbosity == 2

    cc.do_verbosity('')
    assert display.verbosity == 2

    cc.do_verbosity('3')
    assert display.verbosity == 3


# Generated at 2022-06-20 13:07:51.022987
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    console_cli = ConsoleCLI()
    console_cli.init_parser()
    assert console_cli.parser.__class__.__name__=='Parser'


# Generated at 2022-06-20 13:07:55.025042
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    console = ConsoleCLI()
    console.do_verbosity("1")
    console.do_verbosity("")
    console.do_verbosity("abc")
    display.verbosity = 0

# Generated at 2022-06-20 13:07:59.771823
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    host = 'test_host'
    become_method = 'test_become_method'
    _consoleCLI = ConsoleCLI()
    _consoleCLI.become_method = become_method
    _consoleCLI.do_become_method(become_method)
    assert(_consoleCLI.become_method == become_method)

# Generated at 2022-06-20 13:08:06.433864
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    consolecli = ConsoleCLI()
    result = consolecli.init_parser()
    assert result is not None, "ConsoleCLI.init_parser should return a value"

# Generated at 2022-06-20 13:10:15.296064
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    #import pdb; pdb.set_trace()
    cli = ConsoleCLI()
    vars_mock = MagicMock()
    vars_mock.all.return_value = False
    cli.variable_manager = MagicMock()
    cli.variable_manager.get_vars.return_value = vars_mock
    cli.inventory = MagicMock()
    conn_pass = os.environ.get('ANSIBLE_CONN_PASS')
    become_pass = os.environ.get('ANSIBLE_BECOME_PASS')

# Generated at 2022-06-20 13:10:18.484397
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cli = ConsoleCLI()
    cli.do_verbosity("0")
    cli.do_verbosity("1")
    cli.do_verbosity("2")
    cli.do_verbosity("3")


if __name__ == '__main__':
    test_ConsoleCLI_do_verbosity()

# Generated at 2022-06-20 13:10:24.103935
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    class MockConsoleCLI(ConsoleCLI):
        def __init__(self):
            self.inv_pat = MagicMock()
            self.inv_pat.list_hosts.return_value = ['127.0.0.1', '192.168.1.1']

            self.inv_groups = MagicMock()
            self.inv_groups.list_groups.return_value = ['group1', 'group2']

            self.inv_all = MagicMock()
            self.inv_all.list_hosts.return_value = ['192.168.1.3', '192.168.1.4']

            self.inventory = {'pattern': self.inv_pat, 'groups': self.inv_groups, 'all': self.inv_all}
            self.cwd = ''

    console = MockConsoleCL

# Generated at 2022-06-20 13:10:27.854454
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    print("\nRunning Test: test_ConsoleCLI_list_modules")
    cmd = ConsoleCLI()
    result = cmd.list_modules()
    print(result)



# Generated at 2022-06-20 13:10:36.740532
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    p = ConsoleCLI()

    # args that would be normally provided by ansible-playbook
    # use a simple list for this test
    p.remote_user = ['remote_user']
    p.become = [False]
    p.become_user = ['become_user']
    p.become_method = ['become_method']
    p.check_mode = [False]
    p.diff = [False]
    p.forks = [1]
    p.task_timeout = [30]

    # substitute the actual tell_password method with a lambda
    p.ask_passwords = lambda: ('sshpass', 'becomepass')

    # substitute the actual run method with a lambda
    # this will be called instead of the actual run
    # this way we can test if this method can be called without error


# Generated at 2022-06-20 13:10:37.539951
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    pass


# Generated at 2022-06-20 13:10:39.648921
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    object = ['ping2']
    try:
        con = ConsoleCLI(object)
        con.helpdefault('ping2')
    except:
        assert False



# Generated at 2022-06-20 13:10:46.093483
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    c = ConsoleCLI()
    c.do_remote_user('bar')
    assert c.remote_user == 'bar'
    c.do_remote_user('')
    assert c.remote_user == 'bar'
    c.do_remote_user(None)
    assert c.remote_user == 'bar'


# Generated at 2022-06-20 13:10:53.818091
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    p = ConsoleCLI()
    # Make the class instance accessible to the method under test
    p.__dict__['_ConsoleCLI__instance'] = p
    # The method under test requires use of the class variable
    p.__class__.modules = ['ping', 'ping6']
    # The method under test loads modules which require
    #  Ansible options to be defined
    from ansible.constants import Options
    options = Options()
    p.__class__.options = options

    # The class method load_module_source() requires the Ansible plugin loader
    p.__class__.plugin_loader_class = AnsiblePluginLoader
    p.__class__.module_loader = AnsiblePluginLoader.module_loader
    p.__class__.fragment_loader = AnsiblePluginLoader.fragment_loader

    # Create

# Generated at 2022-06-20 13:10:55.526792
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    obj = ConsoleCLI()
    arg = None
    retval = obj.do_EOF(arg)
    assert retval == -1
