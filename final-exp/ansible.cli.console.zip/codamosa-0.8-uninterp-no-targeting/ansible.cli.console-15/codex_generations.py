

# Generated at 2022-06-20 13:03:08.824122
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    pattern = 'webservers'
    hosts = ['h1', 'h2', 'h3', 'h4']
    cwd = 'webservers'
    groups = ['webservers', 'dbservers', 'staging']
    inventory = MagicMock()
    inventory.list_hosts.return_value = [MagicMock(name=x) for x in hosts]
    console_cli = ConsoleCLI(args=MagicMock(pattern=pattern))
    console_cli.groups = groups
    console_cli.inventory = inventory
    console_cli.cwd = cwd
    expected = ['h1', 'h2', 'h3', 'h4']
    actual = console_cli.complete_cd('', 'cd ', 0, 0)
    assert expected == actual


# Generated at 2022-06-20 13:03:16.150241
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    from ansible.utils.color import colorize, hostcolor
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import os
    import sys

    class TestPlaybookExecution:
        '''
        This is a test class to provide a test harness for the CLI class.
        '''


# Generated at 2022-06-20 13:03:22.756102
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    inventory = InventoryManager(loader=None, sources='localhost')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    consoleCLI = ConsoleCLI(None, variable_manager=variable_manager, inventory=inventory)
    assert consoleCLI.do_cd('/') == '*'
    assert consoleCLI.do_cd('/ahost') == 'None'
    assert consoleCLI.do_cd('') == '*'

if __name__ == '__main__':
    test_ConsoleCLI_do_cd()

# Generated at 2022-06-20 13:03:29.861693
# Unit test for method do_become of class ConsoleCLI
def test_ConsoleCLI_do_become():
    from units.compat.mock import MagicMock
    from units.compat.mock import patch
    from ansible.cli.console import ConsoleCLI

    mock_in_path = MagicMock()
    mock_oc = MagicMock()


# Generated at 2022-06-20 13:03:32.030872
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    import imp
    from ansible.module_utils.six import with_metaclass
    from ansible.cli import CLI

    c = CLI([])
    console_cli = ConsoleCLI(c.options)
    console_cli.do_EOF()

# Generated at 2022-06-20 13:03:37.052267
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    console_cli = ConsoleCLI()
    console_cli.do_forks('1')
    assert console_cli.forks == 1

    console_cli.do_cd('all')
    assert '*' in console_cli.cwd


# Generated at 2022-06-20 13:03:39.041465
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    cli = ConsoleCLI()
    assert type(cli.get_names()).__name__ == "list"


# Generated at 2022-06-20 13:03:40.385856
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console = ConsoleCLI()
    console.run()

# Generated at 2022-06-20 13:03:46.115768
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Check if the method has a call to cmdloop
    fixture_path = "test/fixtures/exec.py"
    with mock.patch('ansible_console.console.AnsibleConsole.cmdloop') as mock_cmdloop:
        with open(fixture_path, 'r') as f:
            fixture_data = f.read()
        exec(fixture_data)
        assert mock_cmdloop.called == True

# Generated at 2022-06-20 13:03:52.542672
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    parser = cli.CLI.base_parser(
        usage='usage: %prog [options] PATTERN HOSTS...',
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        diff_opts=True,
        vault_opts=True,
        fork_opts=True,
        modules=defined_options(),
        desc="Ansible Interactive Console",
    )

    # make sure all the base options are present
    options = docopt(parser.option_list, [])
    opt_names = [opt.get_opt_string().lstrip('-') for opt in parser.option_list]

    assert 'help' in opt_names
    assert 'module-path'

# Generated at 2022-06-20 13:04:12.227889
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    # input args
    args = 'foo'

    # object instance of class ConsoleCLI
    cli = ConsoleCLI(args)

    # test do_become_method
    cli.do_become_method(args)

# Generated at 2022-06-20 13:04:19.798693
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from io import StringIO
    from ansible_collections.notstdlib.moveitallout.tests.unit.mock.loader import DictDataLoader

    test_inventory = InventoryManager(loader=DictDataLoader({'host_list': ['katherine', 'fearnleys', 'whittingstall']}), sources='')
    test_variable_manager = VariableManager(loader=DictDataLoader({'host_vars': {'katherine': {'ansible_connection': 'local'}, 'fearnleys': {'ansible_connection': 'local'}, 'whittingstall': {'ansible_connection': 'local'}}}), inventory=test_inventory)
    
    test_stdout = StringIO()
    console

# Generated at 2022-06-20 13:04:26.349477
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    from multiprocessing import Queue
    from ansible.errors import AnsibleError
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.vars import VariableManager
    imported_objects = dict()
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())
    imported_objects.update(dict())

# Generated at 2022-06-20 13:04:36.451854
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    import collections
    test_parser = collections.namedtuple('test_parser', ['module_name'])

# Generated at 2022-06-20 13:04:37.919026
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    consoleCLI = ConsoleCLI()
    assert consoleCLI is not None

if __name__ == '__main__':
    prompt = ConsoleCLI()
    prompt.run()

# Generated at 2022-06-20 13:04:45.864964
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    from ansible.module_utils._text import to_bytes

    # FIXME: use custom test inventory

# Generated at 2022-06-20 13:04:47.249376
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    pass


# Generated at 2022-06-20 13:04:49.539745
# Unit test for method do_shell of class ConsoleCLI

# Generated at 2022-06-20 13:04:56.018846
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
        my_consoleCLI=ConsoleCLI()
        my_consoleCLI.do_forks(0)
        my_consoleCLI.do_forks(1)
        my_consoleCLI.do_forks(2)
        my_consoleCLI.do_forks(3)
        my_consoleCLI.do_forks(4)
        my_consoleCLI.do_forks(5)
        my_consoleCLI.do_forks(6)
        my_consoleCLI.do_forks(7)
        my_consoleCLI.do_forks(8)

# Generated at 2022-06-20 13:04:57.871375
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    console = ConsoleCLI()
    console.do_become_method("su")
    assert(console.become_method == 'su')


# Generated at 2022-06-20 13:05:18.334169
# Unit test for method do_become of class ConsoleCLI
def test_ConsoleCLI_do_become():
    console_cli = ConsoleCLI()
    console_cli.do_become = MagicMock(return_value = True)
    assert console_cli.do_become('yes') == True
    console_cli.do_become = MagicMock(return_value = False)
    assert console_cli.do_become('no') == False
    console_cli.do_become = MagicMock(return_value = True)
    assert console_cli.do_become('up') == True
    console_cli.do_become = MagicMock(return_value = False)
    assert console_cli.do_become('down') == False
  

# Generated at 2022-06-20 13:05:23.125808
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    consoleCLI = ConsoleCLI()
    parser = consoleCLI.init_parser()
    assert isinstance(parser, ArgumentParser)
    assert parser.prog == 'ansible-console'
    assert parser.description == 'Ansible Console (experimental)'

# Generated at 2022-06-20 13:05:34.592989
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    inst = ConsoleCLI(
        stdin = Mock(
            read = Mock(return_value='<Ctrl-C>'),
        ),
    )
    inst.ask_passwords = Mock(return_value=('sshpass', None))
    inst.default = Mock()
    inst.get_host_list = Mock(return_value=[])
    inst._play_prereqs = Mock(return_value=(None, None, None))
    inst.loader = Mock()
    inst.inventory = Mock()
    inst.variable_manager = Mock()
    inst.complete_cd = Mock()
    inst.completedefault = Mock()
    inst.module_args = Mock()
    inst.set_prompt = Mock()
    inst.cmdloop = Mock()

    inst.do_timeout('1')

# Generated at 2022-06-20 13:05:37.949020
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    cli = ConsoleCLI()
    args = Mock()
    args.private_key_file = 'a'
    args.become_method = 'a'
    context.CLIARGS = dict(private_key_file='a',become_method='a')
    res = cli.post_process_args(args)
    assert res is None

# Generated at 2022-06-20 13:05:43.499211
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    
    consolecli = ConsoleCLI()

    # Empty string
    arg = ""
    consolecli.do_remote_user(arg)

    # Valid user
    arg = "joe"
    consolecli.do_remote_user(arg)


# Generated at 2022-06-20 13:05:54.821333
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
  consoleCLI_obj = ConsoleCLI()
  from units.mock.loader import DictDataLoader
  from units.plugins.lookup import LookupModule
  import os
  import os.path
  from ansible.plugins.loader import module_loader
  consoleCLI_obj.loader = DictDataLoader({'vars': {'test_var1': 'test_val1', 'test_var2': 'test_val2', 'test_var3': 'test_val3'}})
  consoleCLI_obj.invocation_vars = {'test_inv_var1': 'test_inv_val1', 'test_inv_var2': 'test_inv_val2'}
  consoleCLI_obj.modules = ['include_role']

# Generated at 2022-06-20 13:05:57.011601
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    argv = ["ansible-console"]
    options = parse_options(argv)
    context._init_global_context(options)
  

# Generated at 2022-06-20 13:06:10.740650
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    #assert False
    base_dir = os.path.dirname(globals()['__file__'])
    ansible_dir = os.path.join(base_dir, '..', '..')
    # This is necessary to import module_utils in the init of the test
    # it's because module_utils itself imports modules in its init.
    sys.path.append(os.path.join(ansible_dir, 'lib'))
    ansible_module_utils_dir = os.path.join(ansible_dir, 'module_utils')
    sys.path.append(ansible_module_utils_dir)
    import module_utils
    sys.path.pop()
    sys.path.pop()
    sys.path.pop()
    sys.path.pop()
    test_subject = ConsoleCLI().get

# Generated at 2022-06-20 13:06:11.999769
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    input_arg = 10
    main_cli = ConsoleCLI()
    main_cli.do_timeout(input_arg)

# Generated at 2022-06-20 13:06:17.710919
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
  pass


if __name__ == '__main__':
  unittest.main()

# Generated at 2022-06-20 13:06:55.186476
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    runner = mock.MagicMock()
    console_cli = ConsoleCLI(runner)

    # Testing with different `complete_cd` values
    complete_cd_str = 'abc'
    complete_cd_list = ['a', 'ab', 'abc', 'abcd']
    for complete_cd in complete_cd_list:
        with mock.patch('ansible_collections.ansible.community.plugins.module_utils.common.completion.AnsibleShellCompleter.complete') as mock_complete:
            mock_complete.return_value = complete_cd_list
            complete_cd_return = console_cli.complete_cd(complete_cd, complete_cd_str, 1, 1)
        assert complete_cd_return[:] == complete_cd_list[complete_cd_list.index(complete_cd):]

   

# Generated at 2022-06-20 13:07:00.122565
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_cli = ConsoleCLI()
    console_cli.cmdloop = MagicMock(return_value=None)
    console_cli.run()
    console_cli.cmdloop.assert_called_once_with()



# Generated at 2022-06-20 13:07:02.258211
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    # Load testvars
    test_vars_loader(loader, context.CLIARGS['vault_password'])

    result = ConsoleCLI()
    assert True


# Unit tests for do_cd()

# Generated at 2022-06-20 13:07:09.256116
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.runtime_inventory import create_runtime_inventory
    from ansible.cli import CLI
    import ansible.constants as C

    # Set-up a mock inventory
    create_runtime_inventory(default_hosts_file=False)
    (options, args) = CLI.parse()
    options.connection = 'local'
    options.module_path = '/dev/null'
    options.forks = 1
    options.become = False
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.check = False
    options.diff = False
    options.remote_user = 'jdoe'
    # Create the cli

# Generated at 2022-06-20 13:07:12.476950
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    """ConsoleCLI.do_check()"""

    my_test = ConsoleCLI()
    assert my_test.do_check('yes') == True



# Generated at 2022-06-20 13:07:15.423339
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():

    a = ConsoleCLI()
    assert a.get_names() == 'do_back'


# Generated at 2022-06-20 13:07:27.216238
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    print("Executing method test_ConsoleCLI_run")

# Generated at 2022-06-20 13:07:39.458039
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console = ConsoleCLI()
    console.inventory = MagicMock()
    console.cwd = 'all'
    console.do_cd('')
    assert(console.cwd == '*')
    console.do_cd('/')
    assert(console.cwd == 'all')
    console.do_cd('not_exist')
    assert(console.cwd == 'all')
    console.inventory.get_hosts.return_value = True
    console.do_cd('test')
    assert(console.cwd == 'test')
    console.do_cd('test2:test3')
    assert(console.cwd == 'test2:test3')
    console.do_cd('test2:!test4')
    assert(console.cwd == 'test2:!test4')

# Generated at 2022-06-20 13:07:48.125707
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    # Test for verbosity when valid integer is passed
    args = dict(verbosity=4)
    context.CLIARGS = ImmutableDict(args)
    ac = ConsoleCLI()
    ac.do_verbosity('2')
    assert display.verbosity == 2

    # Test for verbosity when invalid integer is passed
    args = dict(verbosity=4)
    context.CLIARGS = ImmutableDict(args)
    ac = ConsoleCLI()
    ac.do_verbosity('a')
    assert display.verbosity == 4

    # Test for verbosity when empty string is passed
    args = dict(verbosity=4)
    context.CLIARGS = ImmutableDict(args)
    ac = ConsoleCLI()
    ac.do_verbosity('')

# Generated at 2022-06-20 13:08:00.158893
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Test Case 1
    print("Test Case 1")
    data_args = ['groups']
    ansible_console = ConsoleCLI(['-c', 'local'])
    ansible_console.do_list(data_args)
    for group in ansible_console.groups:
        display.display(group)
    ansible_console.do_list(data_args)
    for host in ansible_console.selected:
        display.display(host.name)
    ansible_console.do_list(data_args)
    ansible_console.do_list(data_args)
    # Test Case 2
    print("Test Case 2")
    data_args = ['groups']
    ansible_console = ConsoleCLI(['-c', 'local'])

# Generated at 2022-06-20 13:09:05.224665
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    def do_diff(self, arg):
        """Toggle whether plays run with diff"""
        if arg:
            self.diff = boolean(arg, strict=False)
            display.display("diff mode changed to %s" % self.diff)
        else:
            display.display("Please specify a diff value, e.g. `diff yes`")
            display.v("diff mode is currently %s" % self.diff)

# Generated at 2022-06-20 13:09:06.892173
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    assert False

# Generated at 2022-06-20 13:09:10.632480
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    p = load_fixture('run_console_cli.py')
    output = p['out'] # noqa

    options = context.CLIARGS
    # Input of do_EOF
    args = None
    # Expect output
    results = -1

    cc = ConsoleCLI(args, **options)
    assert cc.do_EOF(args) == results

# Generated at 2022-06-20 13:09:24.582350
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    cli = ConsoleCLI()
    args = dict(pattern='localhost')
    cli.post_process_args(args)

# Generated at 2022-06-20 13:09:27.987484
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    # create an instance
    console_cli = ConsoleCLI()
    # build the module list
    console_cli.modules = console_cli.list_modules()
    # run the test
    for module in console_cli.modules:
        console_cli.module_args(module)

# Generated at 2022-06-20 13:09:39.598544
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    fixture = os.path.join(os.path.dirname(__file__), '..', 'fixtures', 'inventory')
    loader = DataLoader()
    inv_obj = InventoryManager(loader=loader, sources=fixture)
    display = Display()
    cli = ConsoleCLI(None, inv_obj, display, None, None, None, None)
    cli.do_cd('localhost')
    assert cli.cwd == 'localhost'
    cli.do_cd(None)
    assert cli.cwd == '*'


# Generated at 2022-06-20 13:09:41.032862
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
  console_cli = ConsoleCLI()



# Generated at 2022-06-20 13:09:43.099661
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    arg = 'root'
    cli = ConsoleCLI()
    cli.do_remote_user(arg)


# Generated at 2022-06-20 13:09:46.173008
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    import ansible.constants as C
    C.DEFAULT_RUN_CALLABLE_PLUGINS = False
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = False
    ConsoleCLI(args=None)

# Generated at 2022-06-20 13:09:49.267169
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    """
    :return:
    """
    test_obj = ConsoleCLI()
    # test whether the attributes and method exist
    assert hasattr(test_obj, '_play_prereqs') and callable(getattr(test_obj, '_play_prereqs'))
