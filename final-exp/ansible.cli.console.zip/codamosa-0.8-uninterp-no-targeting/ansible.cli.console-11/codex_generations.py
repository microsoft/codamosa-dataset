

# Generated at 2022-06-20 13:02:55.111452
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    cli = ConsoleCLI()
    result = cli.complete_cd(line="cd test", text="test")
    assert result == ["test"], result


# Generated at 2022-06-20 13:03:06.096646
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    cliconsolecli = ConsoleCLI()
    cliconsolecli.inventory = 'inventory'
    cliconsolecli.loader = 'loader'
    cliconsolecli.variable_manager = 'variable_manager'
    cliconsolecli.passwords = 'passwords'
    cliconsolecli._tqm = '_tqm'
    cliconsolecli.selected = 'selected'
    cliconsolecli.cwd = 'cwd'
    cliconsolecli.pattern = 'pattern'
    cliconsolecli.remote_user = 'remote_user'
    cliconsolecli.become = 'become'
    cliconsolecli.become_user = 'become_user'
    cliconsolecli.become_method = 'become_method'

# Generated at 2022-06-20 13:03:07.941580
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    consoleCLI = ConsoleCLI()
    parser = consoleCLI.init_parser()
    assert parser is not None

# Generated at 2022-06-20 13:03:10.909635
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Create an instance of the test class
    testobj = ConsoleCLI()
    # Create a class instance to pass as argument to class method
    arg = 'groups'
    # Call the method
    testobj.do_list(arg)
    # Assert the call is correct
    assert arg == 'groups'


# Generated at 2022-06-20 13:03:13.934568
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    cli = ConsoleCLI()
    assert cli.module_args('setup') == []
    cli.modules = ['setup']
    assert cli.module_args('setup') == ['filter', 'gather_subset', 'gather_timeout', 'fact_path', 'module_path']

# Generated at 2022-06-20 13:03:24.602085
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    t = {}

# Generated at 2022-06-20 13:03:26.578052
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    # test case: test_become_method
    x = ConsoleCLI()
    arg = "su"
    x.do_become_method(arg)

# Generated at 2022-06-20 13:03:30.686802
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    import ansible.plugins.loader

    # test with an actual module
    c = ConsoleCLI(context.CLIARGS)
    module_name = 'user'
    result = c.module_args(module_name)

    assert 'name' in result
    assert 'password' in result

    # test with a role
    module_name = 'role1'
    result = c.module_args(module_name)

    assert 'role1' in result
    assert 'var_role1' in result

# Generated at 2022-06-20 13:03:33.752902
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console = ConsoleCLI()
    # check for no argument
    assert console.do_list('') == None
    # check for invalid argument
    assert console.do_list('abc') == None
    # check for valid argument
    assert console.do_list('groups') == None


# Generated at 2022-06-20 13:03:41.422641
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    import builtins
    builtins.display = Display()
    ansible_console = ConsoleCLI()
    ansible_console.do_diff("yes")
    display.display("Diff mode changed to True")
    ansible_console.do_diff("no")
    display.display("Diff mode changed to False")
    ansible_console.do_diff("any string")
    display.display("Diff mode changed to False")
    display.errors = []
    display.display("Diff mode changed to False")
    assert not display.errors

# Generated at 2022-06-20 13:04:05.315958
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    import sys
    import os.path

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

    from ansible.cli.console import ConsoleCLI
    from ansible.context import context
    from ansible.inventory import Inventory
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    #from ansible.executor.playbook_executor import PlaybookCLI
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-20 13:04:08.139856
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    # create a class 
    CLI = ConsoleCLI()
    # def method do_shell of class ConsoleCLI
    CLI.do_shell()

# Generated at 2022-06-20 13:04:11.258008
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    osh = ConsoleCLI()
    arg = None
    osh.do_diff(arg)
    arg = 'xxx'
    osh.do_diff(arg)

# Generated at 2022-06-20 13:04:19.126430
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    #
    # Arguments in this method will produce other methods that test the
    # actual Ansible code
    #
    args = {}
    args['--connection'] = 'connection'
    args['--subset'] = 'subset'
    args['--check'] = 'False'
    args['--diff'] = 'False'
    args['--remote-user'] = 'cliuser'
    args['--inventory'] = 'inventory.ini'
    args['--list-hosts'] = 'False'
    args['--list-groups'] = 'False'
    args['--syntax'] = 'False'
    args['--host'] = 'host'
    args['--timeout'] = '0'
    args['--sudo'] = 'False'
    args['--sudo-user'] = 'sudo_user'

# Generated at 2022-06-20 13:04:24.901616
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    console_cli = ConsoleCLI()
    console_cli.become = False
    console_cli.check_mode = True
    console_cli.diff = True
    console_cli.do_check('yes')
    assert console_cli.become == True
    assert console_cli.check_mode == False
    assert console_cli.diff == False

# Generated at 2022-06-20 13:04:27.628383
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    consolecli = ConsoleCLI()
    assert consolecli.module_args('ping') == ['data', 'ping']
    assert consolecli.module_args('debug') == ['msg', 'var']
    assert consolecli.module_args('fail') == ['msg']


# Generated at 2022-06-20 13:04:37.755565
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    # expect to receive an ArgumentParser method from CreateRemoteUserAction.return_argument_parser()
    # and will set the default value for option remote_user to None
    fake_create_remote_user_action_return_argument_parser = MagicMock(return_value=MagicMock(set_defaults=MagicMock()))

# Generated at 2022-06-20 13:04:44.540986
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    # Setup
    console_cli = ConsoleCLI()
    console_cli.check_mode = False
    console_cli.selected = [
        Host("host1"),
        Host("host2")
    ]
    console_cli.modules = {
        "test_module1": [
            "test_module1_arg1",
            "test_module1_arg2"
        ],
        "test_module2": [
            "test_module2_arg1",
            "test_module2_arg2"
        ]
    }
    # Exercise
    test_list = [
        "YES",
        "true",
        "y",
        "t",
        "1",
        "",
        "NO",
        "false",
        "n",
        "f",
        "0"
    ]


# Generated at 2022-06-20 13:04:45.221462
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    assert True

# Generated at 2022-06-20 13:04:54.393011
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    """
    Exercises the cmdloop method of ConsoleCLI.

    Requires an active network connection and a running ansible-console to test.

    Returns:
        None

    """
    import os
    import shutil
    import subprocess
    import tempfile
    import time

    def wait_for_console_to_start():
        """
        Wait up to 10 seconds for ansible-console to finish starting up.

        Returns:
            None

        """
        elapsed_time = 0
        while elapsed_time < 10:
            if b'127.0.0.1' in subprocess.check_output('lsof -n -i :5099 | grep LISTEN | grep ansible', shell=True):
                break
            time.sleep(1)
            elapsed_time += 1

# Generated at 2022-06-20 13:05:18.457295
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():

    check_raw = module in C._ACTION_ALLOWS_RAW_ARGS

    obj = ConsoleCLI()
    arg = arg
    forceshell = False

    assert arg.startswith("#") == obj.default(arg, forceshell)

    assert obj.cwd == True == obj.default(arg, forceshell)

    assert any(module.endswith(x) for x in C.REJECT_EXTS) == True == obj.default(arg, forceshell)

    assert module in C.IGNORE_FILES == True == obj.default(arg, forceshell)

    assert module.startswith('_') == obj.default(arg, forceshell)

    assert module.startswith('_') == True == obj.default(arg, forceshell)


# Generated at 2022-06-20 13:05:23.067273
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console = ConsoleCLI("ansible-console")
    assert console.cwd is None
    assert console.remote_user is None
    assert console.become is None
    assert console.become_user is None
    assert console.become_method is None
    assert console.check_mode is None
    assert console.diff is None
    assert console.forks is None
    assert console.task_timeout is None
    assert console.modules is None
    assert console.prompt_format is None



# Generated at 2022-06-20 13:05:27.108989
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    inventory=InventoryManager(loader=DataLoader())
    variable_manager=VariableManager(loader=DataLoader(), inventory=inventory)
    consoleCLI=ConsoleCLI(inventory, variable_manager)
    consoleCLI.do_list("groups")

# Generated at 2022-06-20 13:05:33.054974
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    cli_obj = CLI()
    obj = ConsoleCLI(cli_obj)
    obj.do_verbosity(3)
    obj.do_verbosity('3')
    obj.do_verbosity('')
    obj.do_verbosity('3.3')

if __name__ == '__main__':
    test_ConsoleCLI_do_verbosity()

# Generated at 2022-06-20 13:05:35.088108
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    obj = ConsoleCLI()
    result = obj.do_forks('')
    assert result == (None)



# Generated at 2022-06-20 13:05:37.568768
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print("Test cmdloop of the class ConsoleCLI.")

    config_file = "playbooks/console/console.cfg"
    my_console = ConsoleCLI(config_file=config_file)

    my_console.cmdloop()




# Generated at 2022-06-20 13:05:50.592667
# Unit test for constructor of class ConsoleCLI
def test_ConsoleCLI():
    console_cli = ConsoleCLI()

    # Verify variable initializations
    assert console_cli.cwd is None
    assert console_cli.prompt == "*"
    assert console_cli.prompt_sep == ">"
    assert isinstance(console_cli.groups, list)
    assert len(console_cli.groups) == 0
    assert console_cli.selected is None
    assert console_cli.pattern is None
    assert console_cli.hosts is None
    assert console_cli.inventory is None
    assert console_cli.variable_manager is None
    assert console_cli.loader is None
    assert console_cli._tqm is None
    assert console_cli.diff is False

    assert console_cli.remote_user == 'root'
    assert console_cli.become is False

# Generated at 2022-06-20 13:05:56.861795
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    # Create a mock object with a mocked method.
    # We need to mock walk_packages because it is an imported method
    # and we want to test only the ConsoleCLI method list_modules.
    mock_walk_pkgs = lambda x: [("", "", ["foo.py"])]
    with mock.patch("ansible.executor.console.walk_packages", mock_walk_pkgs):
        console_cli = ConsoleCLI()
        assert console_cli.list_modules() == ["foo"]

# Generated at 2022-06-20 13:06:10.741396
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    display = Display()
    playbook_path = '/etc/ansible/playbook.yml'
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources='localhost,')

# Generated at 2022-06-20 13:06:11.624823
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg = arg
    forceshell = True

    return True

# Generated at 2022-06-20 13:06:45.333610
# Unit test for method do_shell of class ConsoleCLI
def test_ConsoleCLI_do_shell():
    test_mocker = pytest.importorskip('mock')
    mocker = test_mocker.Mock()
    cli = ConsoleCLI([])
    cli.default = mocker
    cli.do_shell('ls')



# Generated at 2022-06-20 13:06:46.893854
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    c = ConsoleCLI()
    parser = c.init_parser()
    assert parser



# Generated at 2022-06-20 13:06:47.500967
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
  pass

# Generated at 2022-06-20 13:06:50.382881
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    # Setup
    consolecli = ConsoleCLI()
    arg = ''
    # Execute the method under test
    consolecli.do_remote_user(arg)
    # Verify the results
    assert True


# Generated at 2022-06-20 13:07:03.771783
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    cli = ConsoleCLI()
    cli.cwd = 'all'
    cli.inventory = None
    cli.variable_manager = None
    cli.loader = None
    cli.passwords = {'conn_pass': 'connpass', 'become_pass': 'becomepass'}
    cli.remote_user = ''
    cli.become = True
    cli.forks = 5
    cli.task_timeout = 10
    cli.become_user = 'become_user'
    cli.become_method = 'become_method'
    cli.check_mode = True
    cli.diff = True
    cli.task_timeout = 5
    cli.default("ping")
    assert cli.cwd == 'all'
    assert cli

# Generated at 2022-06-20 13:07:10.978022
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # pwd: <ansible_dir>/lib/ansible/utils/module_docs_fragments
    # That is where the module docs fragments reside.
    # Set parameter 'module_docs_path' to the modules fragment dir.
    # Set the module name for which the docs are to be generated
    # Run the test to generate the docs for the module.

    # Set the module name for which the docs are to be generated
    module_name = 'setup'
    # path to the module fragment files
    fp = '../../../../module_docs_fragments'

    # Set the module_name and module_docs_path
    c = ConsoleCLI(module_name=module_name, module_docs_path=fp, parse_options=False)
    c.pattern = '*'

# Generated at 2022-06-20 13:07:17.304187
# Unit test for method do_check of class ConsoleCLI
def test_ConsoleCLI_do_check():
    cli = ConsoleCLI([])
    module_mock = MagicMock(return_value=True)
    cli.default = module_mock
    mod = 'module'
    args = 'arg'
    cli.do_check(None)
    cli.default.assert_called_with(mod + ' ' + args)

# Generated at 2022-06-20 13:07:29.805435
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():

    # instance
    a = ConsoleCLI()

    display.verbosity = 0
    display.vv("method is being tested with verbosity level: "+str(display.verbosity))

    with pytest.raises(SystemExit):
        a.do_verbosity("1")

    with pytest.raises(SystemExit):
        a.do_verbosity("2")

    with pytest.raises(SystemExit):
        a.do_verbosity("3")

    display.verbosity = 4
    display.vv("method is being tested with verbosity level: "+str(display.verbosity))
    a.do_verbosity("0")

    display.verbosity = 5
    display.vv("method is being tested with verbosity level: "+str(display.verbosity))

    with pytest.raises(SystemExit):
        a

# Generated at 2022-06-20 13:07:35.568023
# Unit test for method do_diff of class ConsoleCLI
def test_ConsoleCLI_do_diff():
    console = ConsoleCLI()
    console.do_diff('yes')
    assert console.diff
    console.do_diff('no')
    assert not console.diff
    try:
        console.do_diff()
    except Exception as e:
        pass
    console.do_diff('nothing')  # Should not crash
    # Reset the value
    console.diff = False


# Generated at 2022-06-20 13:07:45.868896
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    cliargs = Mock()
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks
    # Build mocks

# Generated at 2022-06-20 13:08:57.481762
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    AnsibleConsoleCLI=ConsoleCLI()
    AnsibleConsoleCLI.do_list("")


# Generated at 2022-06-20 13:09:02.575867
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    consoleCLI = ConsoleCLI()
    assert(consoleCLI.module_args('command')==['_raw_params', '_uses_shell', 'chdir', 'creates', 'executable', 'removes', 'warn'])


# Generated at 2022-06-20 13:09:17.084358
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Instanciate a ConsoleCLI object using context
    # and mocks
    context._init_global_context(
        ['ansible-console'],
        args={'verbosity': 1},
        in_data={'inventory': mock.MagicMock()},
        prog='ansible-console'
    )

    console = ConsoleCLI()

    # We put the state of the class back to the initial state
    # Then, we mock the two methods that the method we want
    # to test calls.
    console.default = mock.MagicMock()
    console.completenames = mock.MagicMock(return_value=['test1', 'test2'])

    # We test the behavior of the method when we enter
    # the name of a command that exists

# Generated at 2022-06-20 13:09:27.027911
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_cli = ConsoleCLI()
    module_name = 'command'
    line = 'command '
    module_args_list = ['free_form', 'creates', 'chdir', 'executable','warn', 'removes','stdin','strip_empty_ends','stdin_add_newline','stdout_add_newline','stdout','binary','_uses_shell','_raw_params','_raw_params_files','_uses_delegate','_raw_params_as_single_value','_uses_async','_uses_never_cache','uses_delegate_to','_uses_loops','_uses_fileglobs','chomp','_raw_params_sort_keys']

# Generated at 2022-06-20 13:09:37.246672
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    C = ConsoleCLI()
    C.inventory.get_hosts = lambda x: []
    C.do_cd("")
    assert C.cwd == "*"
    C.do_cd("/")
    assert C.cwd == "all"
    C.inventory.get_hosts = lambda x: [Mock()]
    C.do_cd("A")
    assert C.cwd == "A"

# Generated at 2022-06-20 13:09:41.446169
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    # TODO
    # am = ArgumentError
    # cls():
    # cls.post_process_args('foo')
    # assert am.called_once_with(message='foo')
    pass


# Generated at 2022-06-20 13:09:42.454142
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    ShellCLI().default('')

# Generated at 2022-06-20 13:09:43.424564
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    # TODO
    return


# Generated at 2022-06-20 13:09:44.865502
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    assert ConsoleCLI.get_names() == ['ansible-console']

# Generated at 2022-06-20 13:09:49.278863
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cmd = Console()
    assert console_cmd is not None

    # Run method with empty module path
    modules = console_cmd.list_modules()
    assert modules is not None and len(modules) == 0

    # Assign to module path
    C.DEFAULT_MODULE_PATH = 'test_console_cli'
    modules = console_cmd.list_modules()
    assert modules is not None and len(modules) == 6

# Generated at 2022-06-20 13:10:40.910367
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    command = ""
    expected = -1
    actual = ConsoleCLI().do_timeout(command)
    assert actual == expected


# Generated at 2022-06-20 13:10:44.212639
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console = ConsoleCLI()
    modules = console.list_modules()
    assert 'ping' in modules
    assert 'debug' in modules

# Generated at 2022-06-20 13:10:48.422508
# Unit test for method do_become_user of class ConsoleCLI
def test_ConsoleCLI_do_become_user():
    _console_cli = ConsoleCLI()
    _console_cli.do_become_user('root')
    assert _console_cli.become_user == 'root'



# Generated at 2022-06-20 13:10:49.537497
# Unit test for method get_names of class ConsoleCLI
def test_ConsoleCLI_get_names():
    pass

# Generated at 2022-06-20 13:10:52.862691
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    console = ConsoleCLI()
    try:
        console.do_EOF()
    except SystemExit as e:
        pass
    else:
        assert False, "SystemExit expected"
    assert len(sys.stdout.getvalue().strip()) == 0

# Generated at 2022-06-20 13:10:59.043108
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    test_obj = ConsoleCLI()
    test_obj._split_path = lambda x, y: ['test']
    test_obj.cwd = 'test'
    expected = 'test > '
    actual = test_obj.prompt
    assert actual == expected

# Generated at 2022-06-20 13:11:02.430056
# Unit test for method emptyline of class ConsoleCLI
def test_ConsoleCLI_emptyline():
    console_cli = ConsoleCLI()
    try:
        console_cli.emptyline()
    except Exception:
        utils.fail("Unit test for method 'emptyline' of class 'ConsoleCLI' failed")


# Generated at 2022-06-20 13:11:10.744451
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    import ansible.plugins.loader as loader_mock
    context.CLIARGS = AttributeDict()
    context.CLIARGS['connection'] = 'local'
    context.CLIARGS['subset'] = None
    context.CLIARGS['pattern'] = None
    context.CLIARGS['forks'] = 5
    context.CLIARGS['remote_user'] = None
    context.CLIARGS['private_key_file'] = None
    context.CLIARGS['ssh_common_args'] = None
    context.CLIARGS['ssh_extra_args'] = None
    context.CLIARGS['sftp_extra_args'] = None
    context.CLIARGS['scp_extra_args'] = None

# Generated at 2022-06-20 13:11:13.235386
# Unit test for method init_parser of class ConsoleCLI
def test_ConsoleCLI_init_parser():
    import argparse
    parser = argparse.ArgumentParser()
    my_consoleCLI=ConsoleCLI()
    my_consoleCLI.init_parser(parser)
    assert isinstance(parser,argparse.ArgumentParser)

# Generated at 2022-06-20 13:11:15.824662
# Unit test for method do_EOF of class ConsoleCLI
def test_ConsoleCLI_do_EOF():
    obj = ConsoleCLI()
    res = obj.do_EOF('exit')
    assert res == -1