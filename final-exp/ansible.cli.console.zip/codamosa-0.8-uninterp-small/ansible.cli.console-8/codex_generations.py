

# Generated at 2022-06-24 17:45:26.583734
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    if console_c_l_i_0.completedefault('', '', '', ''):
        raise ValueError()
    if not console_c_l_i_0.completedefault(console_c_l_i_0.random_string(), '', console_c_l_i_0.random_string(), console_c_l_i_0.random_string()):
        raise ValueError()


# Generated at 2022-06-24 17:45:38.866707
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_0 = 'l,W\\]^</O\\)#0`'
    str_1 = 'l,W\\]^</O\\)#0`'
    str_2 = 'l,W\\]^</O\\)#0`'
    str_3 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0.do_cd(str_0)
    console_c_l_i_0.do_cd(str_1)
    console_c_l_i_0.do_cd(str_2)
    console_c_l_i_0.do_cd

# Generated at 2022-06-24 17:45:41.529868
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)


# Generated at 2022-06-24 17:45:48.714903
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    # Init ConsoleCLI object
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    # Set timeout
    str_0 = '20'
    console_c_l_i_0.do_timeout(str_0)


# Generated at 2022-06-24 17:45:52.708658
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.list_modules()


# Generated at 2022-06-24 17:45:55.543413
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # Initialize class
    console_c_l_i_1 = ConsoleCLI()
    # Apply method
    console_c_l_i_1.set_prompt()



# Generated at 2022-06-24 17:45:57.121867
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    test_case_0()


# Generated at 2022-06-24 17:46:00.186076
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
	# Test for case 0
	console_c_l_i_0 = ConsoleCLI("");
	# Test for case 1


# Generated at 2022-06-24 17:46:04.704435
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    p_1 = '6exZK|_p>z\\4}Ac'
    p_2 = True
    console_c_l_i_0 = ConsoleCLI(p_1)
    console_c_l_i_0.default(p_1, p_2)


# Generated at 2022-06-24 17:46:13.341850
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    argument_0 = 'module_0'
    argument_1 = 'module_0 argument_0'
    argument_2 = 'module_0 argument_0 argument_1'
    argument_3 = 'module_0 argument_0 argument_1 argument_2'
    argument_4 = 'module_0 argument_0 argument_1 argument_2 argument_3'
    argument_5 = 'module_0 argument_0 argument_1 argument_2 argument_3 argument_4'
    argument_6 = 'module_0 argument_0 argument_1 argument_2 argument_3 argument_4 argument_5'
    argument_7 = 'module_0 argument_0 argument_1 argument_2 argument_3 argument_4 argument_5 argument_6'

# Generated at 2022-06-24 17:46:38.341865
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'M,\\_!4}f\\-~%c\\<'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_0 = 'N`8F[W/%v+'
    str_1 = '-`D'
    str_2 = '9O=V7'
    str_3 = 'B_Q|'
    str_4 = 'c%Fb'
    str_5 = 'A>R;'
    str_6 = '5@g0'
    str_7 = 'U89>'
    str_8 = 'OM'
    str_9 = 'hM'
    str_10 = '7'
    str_11 = 'Vd'
    str_12 = ''
    int_0 = console_c_l

# Generated at 2022-06-24 17:46:42.928569
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.cmdloop()

# Generated at 2022-06-24 17:46:45.186707
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Arrange
    # Act
    # Assert
    assert True


# Generated at 2022-06-24 17:46:54.056710
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = '`v?k^z,p|'
    console_c_l_i_2 = ConsoleCLI(str_0)
    arg_0 = 'R_f!_y'
    arg_1 = 't'
    arg_2 = 0
    arg_3 =  1
    result_0 = console_c_l_i_2.completedefault(arg_0, arg_1, arg_2, arg_3)
    print(result_0)


# Generated at 2022-06-24 17:46:59.479902
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = 'l,W\\]^</O\\)#0`'
    str_1 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_2 = 'l,W\\]^</O\\)#0`'
    str_3 = 'l,W\\]^</O\\)#0`'
    str_4 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0.complete_cd(str_2, str_3, str_0, str_4)


# Generated at 2022-06-24 17:47:02.189445
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:47:12.125180
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    # Input parameters
    arg = 'arg_str_0'
    forceshell = 'forceshell_str_0'

    # Set up context object
    context = Context()
    context.CLIARGS = CLIARGS
    context.become = False
    context.become_method = 'become_method_str_0'
    context.become_user = 'become_user_str_0'
    context.check = False
    context.connection = 'connection_str_0'
    context.diff = False
    context.forks = 'forks_str_0'
    context.inventory = 'inventory_str_0'
    context.module_path = 'module_path_str_0'
    context.module_paths = 'module_paths_str_0'

# Generated at 2022-06-24 17:47:15.832136
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg0 = int()
    forceshell = str()
    str_0 = '1,14'
    console_c_l_i_0 = ConsoleCLI(str_0)
    ret_1 = console_c_l_i_0.default(arg0, forceshell)
    assert_equals(ret_1, False)


# Generated at 2022-06-24 17:47:18.772135
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    console_c_l_i_0 = ConsoleCLI(True)
    console_c_l_i_0.do_timeout('<timeout>')


# Generated at 2022-06-24 17:47:32.326502
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_cli = ConsoleCLI(str_0)
    str_1 = 'X=0`0x'
    str_2 = 'zO\\^UX'
    if os.path.exists(str_1) is False:
        os.makedirs(str_1)
    if os.path.exists(str_2) is False:
        os.makedirs(str_2)
    list_0 = console_cli.list_modules()
    if os.path.exists(str_1) is True:
        os.removedirs(str_1)
    if os.path.exists(str_2) is True:
        os.removedirs(str_2)
    return list_0



# Generated at 2022-06-24 17:47:55.674465
# Unit test for method complete_cd of class ConsoleCLI

# Generated at 2022-06-24 17:48:00.487709
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():

    source_file = 'console.py'
    source_path = os.path.join(HERE, source_file)

    # Test with source_path, source_file, source_line.
    check_completedefault(source_path, source_file, 115)


# Generated at 2022-06-24 17:48:02.099100
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()


# Generated at 2022-06-24 17:48:05.035603
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    test_case_0()


# Generated at 2022-06-24 17:48:15.157870
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Test: Method do_cd exists in class ConsoleCLI and is a method
    test_0 = hasattr(ConsoleCLI, 'do_cd') and type(getattr(ConsoleCLI, 'do_cd')) == types.MethodType
    # Test: do_cd has 2 args
    test_1 = getattr(ConsoleCLI, 'do_cd').__code__.co_argcount == 2
    # Test: do_cd accepts arg '*'
    test_2 = ConsoleCLI('w]^<)#0`').do_cd('*') is None
    return test_0 & test_1 & test_2


# Generated at 2022-06-24 17:48:22.615908
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = 'Ug]p9As-6U'
    console_c_l_i_0.helpdefault(str_1)


# Generated at 2022-06-24 17:48:27.616417
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    # TODO: implement test do_cd


# Generated at 2022-06-24 17:48:36.198816
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = '#'
    bool_0 = console_c_l_i_0.default(str_1)
    bool_1 = bool_0 == False
    str_2 = 'module'
    bool_2 = str_2 in console_c_l_i_0.modules
    if bool_2:
        str_3 = 'module'
        str_4 = ' '
        str_5 = 'arg'
        str_6 = str_3 + str_4 + str_5
        bool_3 = console_c_l_i_0.default(str_6)

# Generated at 2022-06-24 17:48:43.501861
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    # Initialization
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_0 = 'vNG\\q3Bt{,O\\O\\'
    str_1 = ';dHX,`r'
    int_0 = 0
    int_1 = 8
    int_2 = 8
    # Invocation
    result = console_c_l_i_0.complete_cd(str_0, str_1, int_0, int_1)
    # Verification
    assert (result, int_2)
    # Cleanup


# Generated at 2022-06-24 17:48:46.342228
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    arg = 'show_out'
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.helpdefault(arg)

# Generated at 2022-06-24 17:49:15.620284
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_cli_obj_0 = ConsoleCLI()
    console_cli_obj_0.completedefault('text', 'module=', 0, 9)
    console_cli_obj_0.completedefault('text', 'module=', 0, 9)


# Generated at 2022-06-24 17:49:24.943192
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    module_name_0 = 'l,W]^</O))#0`'
    line_0 = 'Z.GI='
    console_c_l_i_0.module_args = MagicMock(return_value = module_name_0)
    text_0 = '`'
    begidx_0 = 1
    endidx_0 = 1
    return_value_1 = console_c_l_i_0.module_args(module_name_0)
    return_value_2 = console_c_l_i_0.module_args(module_name_0)
    return_value_3 = console_c_l_

# Generated at 2022-06-24 17:49:28.828101
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.list_modules()


# Generated at 2022-06-24 17:49:35.534077
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = 'text'
    str_2 = 'line'
    int_0 = 0
    int_1 = 0
    value = console_c_l_i_0.completedefault(str_1, str_2, int_0, int_1)
    assert value != None


# Generated at 2022-06-24 17:49:41.646113
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.run()

if __name__ == "__main__":
    test_case_0()
    test_ConsoleCLI_run()

# Generated at 2022-06-24 17:49:51.240161
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console_c_l_i_0 = ConsoleCLI('/')
    module_0 = 'file'
    res_0 = console_c_l_i_0.module_args(module_0)
    assert len(res_0) > 0


# Generated at 2022-06-24 17:50:06.087703
# Unit test for method complete_cd of class ConsoleCLI

# Generated at 2022-06-24 17:50:08.721792
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = 'T,w\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)


# Generated at 2022-06-24 17:50:14.204602
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i = ConsoleCLI()
    console_c_l_i.cmdloop()


# Generated at 2022-06-24 17:50:15.391354
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    test_case_0()


# Generated at 2022-06-24 17:50:48.503496
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Initialization
    str_0 = '{"vE\\y!=-2(+'
    str_1 = ')#0`'
    str_2 = 'l,W\\]^</O\\)'
    str_3 = 't`G<*#R=9E)'
    str_4 = '()YBq{zg#p'
    str_5 = 'v>e*`r0Bl0'
    console_c_l_i_0 = ConsoleCLI(str_0)
    module_name_0 = str_1 + str_2
    text_0 = str_3
    line_0 = str_4 + module_name_0 + str_5
    begidx_0 = None
    endidx_0 = None

    # Function call
    ret_0 = console_c_

# Generated at 2022-06-24 17:50:52.997646
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    return console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:50:57.259598
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = 'l,W\\]^</O\\)#0`'
    str_1 = 'Ng  P$Ny9Kv'
    str_2 = 'RZ#hb^!+[;'
    str_3 = '3-Pt+O[Qx%'
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.complete_cd(str_1, str_2, str_3, str_3)


# Generated at 2022-06-24 17:51:03.826161
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Test case 0
    '''
    We can run arbitrary shell commands that are not part of the
    shell module by using the shell module.

    eg.:
    shell ps uax | grep java | wc -l
    shell killall python
    shell halt -n

    You can use the ! to force the shell module. eg.:
    !ps aux | grep java | wc -l
    '''
    str_0 = ' '
    console_c_l_i_0 = ConsoleCLI(str_0)
    test_arg_0 = str()

    desc_0 = '''
    e.g.
    help <command>
    '''
    # Create an instance of StringIO
    string_i_o_0 = StringIO()

    # Save the original stdout
    stdout_0 = sys.stdout



# Generated at 2022-06-24 17:51:08.662054
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:51:12.226829
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI('h')
    assert ('AIX' in console_c_l_i_0.helpdefault('ping')) or ('Darwin' in console_c_l_i_0.helpdefault('ping'))


# Generated at 2022-06-24 17:51:16.319876
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # TODO: write those tests
    pass


# Generated at 2022-06-24 17:51:22.093254
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = '@*'
    console_c_l_i_0 = ConsoleCLI(str_0)

    print('test_ConsoleCLI_list_modules')
    str_0 = '@*'
    console_c_l_i_0 = ConsoleCLI(str_0)


# Generated at 2022-06-24 17:51:31.269030
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'e'
    arg_str_0 = str_0
    arg_text_0 = 'y'
    arg_line_0 = 'O^:GeF\n'
    arg_begidx_0 = 3
    arg_endidx_0 = 5
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.default(arg_str_0)
    console_c_l_i_0.completedefault(arg_text_0, arg_line_0, arg_begidx_0, arg_endidx_0)

## Unit test for method module_args of class ConsoleCLI
#def test_ConsoleCLI_module_args():
#    str_0 = 'd'
#    arg_

# Generated at 2022-06-24 17:51:39.117761
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0_1 = '#~\\u`7'
    int_0_1 = console_c_l_i_0.default(str_0_1)
    str_0_2 = 's^.P\\'
    int_0_2 = console_c_l_i_0.default(str_0_2)
    str_0_3 = 't,_l0^'
    int_0_3 = console_c_l_i_0.default(str_0_3)
    str_0_4 = 'P^Imp'
    int_0_4 = console_c_l_i_0.default(str_0_4)
    str_0_5 = '^.1C*H'

# Generated at 2022-06-24 17:52:06.837660
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = '<module>'
    console_c_l_i_0.helpdefault(str_1)
    assert True


# Generated at 2022-06-24 17:52:15.134234
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    module_arg_0 = 'webservers'
    module_arg_1 = 'test'

    console_c_l_i_0.helpdefault(module_arg_0)
    console_c_l_i_0.helpdefault(module_arg_1)


# Generated at 2022-06-24 17:52:20.891142
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Case0. Text and line are both empty.
    assert ConsoleCLI.completedefault('', '', 0, 0) == []
    # Case1. Line only has module name.
    assert ConsoleCLI.completedefault('', 'copy', 0, 0) == ['arg=', 'backup=', 'content=', 'dest=', 'directory_mode=', 'follow=', 'force=', 'group=', 'local_follow=', 'mode=', 'owner=', 'regexp=', 'remote_src=', 'selevel=', 'serole=', 'setype=', 'seuser=', 'src=', 'unsafe_writes=', 'validate=', 'verify=']
    # Case2. Line has module name and option_0.

# Generated at 2022-06-24 17:52:27.845994
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = 'a'
    console_c_l_i_0.completedefault(str_1, 'a', 0, 1)


# Generated at 2022-06-24 17:52:31.760286
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = 'groups'
    console_c_l_i_0.do_list(str_1)


# Generated at 2022-06-24 17:52:38.128711
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():

    console_c_l_i_1 = ConsoleCLI('10')

    try:
        print(console_c_l_i_1.default('', False))
    except Exception as exc:
        print(exc)


# Generated at 2022-06-24 17:52:43.351523
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Init an object ConsoleCLI and test
    console_c_l_i_0 = ConsoleCLI('all')
    # Test method completedefault of class ConsoleCLI
    assert console_c_l_i_0.completedefault('', '', 0, 0) == []
    assert console_c_l_i_0.completedefault('', '', 0, 0) == []

# Generated at 2022-06-24 17:52:47.539065
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_c_l_i_0 = ConsoleCLI()
    # Get the value of attribute 'modules' of console_c_l_i_0
    var___modules = console_c_l_i_0.modules
    assert type(var___modules) == str
    print(var___modules)


# Generated at 2022-06-24 17:52:50.986389
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = '?l,W\\]^</O\\)#0`'

# Generated at 2022-06-24 17:52:58.118821
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_1 = 'G\\]^=P\\)#0`'
    console_c_l_i_1 = ConsoleCLI(str_1)
    console_c_l_i_1.do_list('groups')
    console_c_l_i_1.do_list('')


# Generated at 2022-06-24 17:53:44.168846
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_1 = '3q4j'
    console_c_l_i_1 = ConsoleCLI(str_1)
    str_2 = 'x@B'
    console_c_l_i_1.helpdefault(str_2)
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError:

# Generated at 2022-06-24 17:53:52.335598
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = '\\/'
    str_1 = 'l,W\\]^</O\\)#0`'
    str_2 = 'l,W\\]^</O\\)#0`'
    console_c_l_i_0 = ConsoleCLI(str_2)
    tuple_0 = ('\\/', 'l,W\\]^</O\\)#0`', 'l,W\\]^</O\\)#0`', 'l,W\\]^</O\\)#0`')
    console_c_l_i_0.complete_cd(*tuple_0)
    str_3 = '/'
    str_4 = 'l,W\\]^</O\\)#0`'
    str_5 = 'l,W\\]^</O\\)#0`'
   