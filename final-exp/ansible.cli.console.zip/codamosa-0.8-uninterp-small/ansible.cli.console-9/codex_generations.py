

# Generated at 2022-06-24 17:44:49.950659
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Test not implemented
    pass


# Generated at 2022-06-24 17:44:56.495013
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    bytes_0 = b't\x92\xea\xfe\xbe\x01\xcaA\xb2\x9c\xdd\x16\x01'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    bytes_0 = b'\xfd\x1c\xdd\x87i\xd1d\xec\x9e\x87[\x04\x1f'
    console_c_l_i_0.do_list(bytes_0)


# Generated at 2022-06-24 17:45:07.612073
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    print('Testing method default of class ConsoleCLI')
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    bool_0 = console_c_l_i_0.default('#', False)
    assert bool_0
    bool_0 = console_c_l_i_0.default('#', False)
    assert bool_0
    bool_0 = console_c_l_i_0.default('#', False)
    assert bool_0


# Generated at 2022-06-24 17:45:10.798986
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:20.354364
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    pos_args_0 = ['groups']
    _arg_0 = pos_args_0[0] if pos_args_0 else None
    _args = (_arg_0,)
    try:
        assert console_c_l_i_0._play_prereqs()
    except SystemExit:
        pass
    try:
        console_c_l_i_0.do_list(_args)
    except SystemExit:
        pass


# Generated at 2022-06-24 17:45:26.018366
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:38.667117
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    m_check_mode = ansible.module_utils.basic.AnsibleModule.check_mode
    ansible.module_utils.basic.AnsibleModule.check_mode = False
    console_c_l_i_0 = ConsoleCLI(b'\x7f\x19\x81\xde\x7f\x19\x81\xde\x19\x94\xd5\x88\x99\xcd\xe5C\xee\xbd\x06')
    bytes_0 = b'\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0.do_list(bytes_0)
    ansible.module_utils.basic.AnsibleModule.check_mode = m_check_mode



# Generated at 2022-06-24 17:45:48.374202
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI()

    # set correct return value for get_host_list
    hosts = ['127.0.0.1']
    console_c_l_i_0.inventory.list_hosts = MagicMock(name='list_hosts', return_value=hosts)

    # set correct return value for list_modules
    modules = ['command']
    console_c_l_i_0.list_modules = MagicMock(name='list_modules', return_value=modules)
    console_c_l_i_0.cmdloop()

    # check if get_host_list is called with expected arguments

# Generated at 2022-06-24 17:45:54.602435
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    print('Test #0')
    bytes_0 = b'\r\xbe\n\xb2E\x05\xae\x08\xa4E\xc4'
    ConsoleCLI_0 = ConsoleCLI(bytes_0)
    ConsoleCLI_0.completedefault()


# Generated at 2022-06-24 17:46:03.520374
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    text = 'text'
    line = 'line'
    begidx = 'begidx'
    endidx = 'endidx'
    try:
        console_c_l_i_0.completedefault(text, line, begidx, endidx)
    except TypeError:
        return
    raise AssertionError('Unreachable')


# Generated at 2022-06-24 17:46:24.947423
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'b\xb6\x1d\x1b\xab\xf3@\x0c\x8a\xfb'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    result = console_c_l_i_0.default(console_c_l_i_0.integers_0, console_c_l_i_0.booleans_0)


# Generated at 2022-06-24 17:46:26.607280
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(None)
    console_c_l_i_0.cmdloop()
    pass


# Generated at 2022-06-24 17:46:34.111809
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'd\xad\xa9\xe8\x1dH\x1fB\xef\x8e\xbf\xc4\xfc\xb9\xf8\x98\x95\x97d\x1c\x17\xf3\x9b'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    module_name_0 = b'\xed\xf9\xce\xa7'
    console_c_l_i_0.helpdefault(module_name_0)


# Generated at 2022-06-24 17:46:46.206648
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    print("Testing ConsoleCLI_helpdefault")
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0.default('', bytes_0)
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'

# Generated at 2022-06-24 17:46:48.531938
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop(bytes_0)


# Generated at 2022-06-24 17:46:54.864982
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI('\x14\xa7\x15\x17')
    var_19 = '\xa2\x16\xf7\xba\xb4\xb7\x11\xbf\x9a\x12\x15'
    console_c_l_i_0.helpdefault(var_19)
    var_20 = '\x12\x0c\xa5\x14\x0c\x14\x10\x07\x9e\x13\x10'
    console_c_l_i_0.helpdefault(var_20)


# Generated at 2022-06-24 17:47:01.065851
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:47:07.613713
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_1 = b'\xc5\x8c\x13\x1e\x1a\xca\xf3\xadX&'
    console_c_l_i_1 = ConsoleCLI(bytes_1)
    console_c_l_i_1.modules = ['foo', 'bar']
    test_module = 'foo'
    console_c_l_i_1.helpdefault(test_module)


# Generated at 2022-06-24 17:47:15.541001
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Initialize test environment
    args = ['-i', '/Users/tbarbini/Documents/workspace/play/inventories/dev-cn/hosts']
    context.CLIARGS = context.CLI.parse(args)[0]
    ansible_console_c_l_i_0 = ConsoleCLI(None)

    # Generate test data

    # Assert pre-conditions

    # Execute test method
    ansible_console_c_l_i_0.do_list(None)

    # Verify results


# Generated at 2022-06-24 17:47:23.674332
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:48:01.192548
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    text_0 = "\x89\xe3"
    line_0 = "\x89\xe3"
    begidx_0 = 0x5
    endidx_0 = 0x2a
    mline_0 = "\x89\xe3"
    offs_0 = 0x13
    completions_0 = [ ]
    text_1 = "\x89\xe3"
    line_1 = "\x89\xe3"
    begidx_1 = 0x5
    endidx_1 = 0x2a
    mline_1 = "\x89\xe3"
    offs_1 = 0x13


# Generated at 2022-06-24 17:48:10.048777
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'i\x89=\x0c\x8f\x11\x05\xc0\x95\x8bt\xae\xae\x9f\xc7\xab\xb2\x95\x82\xc4\xe4\xd4\x9b\x81\x90\xed\xfc\xcc\xb5\xc2\x8c\xe5f'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    arg_0 = b'\xa4)X\x94\x1c\xdb\xce\xee\xa2\xf2\xf5\x08D\xd3\xe2\xc2\xed\x11\xfb\xb7\x96'
    console_c_l_

# Generated at 2022-06-24 17:48:11.736396
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    cmdloop_0 = ConsoleCLI(None)
    cmdloop_0.cmdloop()


# Generated at 2022-06-24 17:48:18.153851
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.do_list(str())


# Generated at 2022-06-24 17:48:24.832814
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    module_name = 'gcs_acl'
    console_c_l_i_0 = ConsoleCLI('\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06')
    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:48:33.216819
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Positive case
    # Verify cmdloop() is called
    # Since ConsoleCLI class does not have a cmdloop() method,
    # it will attempt to call the parent's class - Cmd - method cmdloop()
    # Verify cmdloop() is called without exception
    c = ConsoleCLI(None)
    try:
        c.cmdloop()
        print('[+] test_ConsoleCLI_cmdloop(): Passed')
    except Exception as e:
        print('[-] test_ConsoleCLI_cmdloop(): Failed: %s' % (str(e)))


# Generated at 2022-06-24 17:48:37.572323
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.helpdefault("test_ConsoleCLI_helpdefault") # Should not crash


# Generated at 2022-06-24 17:48:43.375503
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:48:47.733776
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    bytes_0 = b'\xaf\xfe(W\x1b\xb5\xcc\xc5\x0e\x9c\x9d\x82\x8e'
    console_c_l_i_0 = ConsoleCLI(bytes_0)


# Generated at 2022-06-24 17:48:48.984321
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    assert 1 != 1


# Generated at 2022-06-24 17:49:24.047931
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    bytes_0 = b'j\x1b\x87\x9fS\x17\x18\xa2\x85\x1a\x1f'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    text = 'w!\xda\xa2\xdc\x9f\x9aZ\xdd0\xd7\x0f\x87\xdb\xad\xf7\x9a\x05\xef\xe4\x0fD\x15\x1f\x82\xd4\x9f\x87\x04\x99j\x7f\xde\xea\xdb\x1d\x82\x9d\xe7\x18\xa2\x85\x1a\x1f'

# Generated at 2022-06-24 17:49:29.664114
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'Q[\x7fae\xb4\xcb\x82\x9a\xd0\x08\xe7\x81\r\x1a\x1b'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.default(bytes_0, True)


# Generated at 2022-06-24 17:49:45.626529
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:49:58.651393
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i_0 = ConsoleCLI(b'0\x02q\x19\x13\xd5!\x1e\x16\x92\xa9\x84\x19\x17B\x83\x82\x01\x14\xda\x1e\x16\xc9\xa4\x15\x1d\x19\x11\x8a\x81\x19\x1b\xc9\x1e\x1c\x87\x99\x8bc')
    console_c_l_i_0.selected = set()
    console_c_l_i_0.inventory = None
    console_c_l_i_0.do_list(console_c_l_i_0.selected)


# Generated at 2022-06-24 17:50:09.836254
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\r\xa4\x9d\xec\xce\xf4\x11\x8b\xeb\x1a\x89'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    bytes_1 = b'\xff\x07\xff\x98\x1f\x8c\xbf\xa4\x81\xa0\x9d'
    module_name = to_native(bytes_1)
    bytes_2 = b'\xcc\xb9\xe9\x99\xda\xac\xbf\x83\x1f\xe7\x93'
    text = to_native(bytes_2)

# Generated at 2022-06-24 17:50:16.490960
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    bytes_0 = b'y`\x96\x1d\xa1\x07\xbe\xfd\xef\xf6\x83\xc5'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cwd = '09!\x8d'
    out = console_c_l_i_0.set_prompt()
    assert out is None


# Generated at 2022-06-24 17:50:20.695243
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Testing the following parameters
    # arg = 'groups'
    console_c_l_i_4 = ConsoleCLI()
    console_c_l_i_4.inventory._hosts_cache = {}
    console_c_l_i_4.groups = console_c_l_i_4.inventory.list_groups()
    console_c_l_i_4.hosts = console_c_l_i_4.inventory.list_hosts()
    console_c_l_i_4.do_list('groups')


# Generated at 2022-06-24 17:50:26.396271
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg = 'bash -c "cd / ; sleep 100"'
    forceshell = True
    C._ACTION_ALLOWS_RAW_ARGS = ['shell']
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    try:
        console_c_l_i_0._tqm = None
    except Exception as e:
        print("Exception %s" %(e))
    console_c_l_i_0.set_prompt()
    console_c_l_i_0.cwd = None
    console_c_l_i_0.list_modules = lambda: ['shell']
    console_

# Generated at 2022-06-24 17:50:32.395227
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    assert True


# Generated at 2022-06-24 17:50:42.107499
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    text_0 = '\x13\x81\xe4\x0c'
    line_0 = 'cd \x13\x81\xe4\x0c'
    begidx_0 = None
    endidx_0 = None
    console_c_l_i_0.complete_cd(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:51:19.520158
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()

# Generated at 2022-06-24 17:51:30.768593
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    # Test case 1
    bytes_1 = b'*'
    arg_1 = 'arg'
    forceshell_1 = False
    console_c_l_i_1 = ConsoleCLI(bytes_1)
    console_c_l_i_1.default(arg_1, forceshell_1)
    
    # Test case 2
    bytes_2 = b'\x1c'
    arg_2 = 'arg'
    forceshell_2 = False
    console_c_l_i_2 = ConsoleCLI(bytes_2)
    console_c_l_i_2.default(arg_2, forceshell_2)
    
    # Test case 3
    bytes_3 = b'\t\xb7\xe8'
    arg_3 = 'arg'
    forceshell_3 = True


# Generated at 2022-06-24 17:51:38.185740
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    str_0 = 'bash'
    int_0 = 0
    int_1 = 0
    int_2 = console_c_l_i_0.completedefault(str_0, str_0, int_0, int_1)


# Generated at 2022-06-24 17:51:39.880051
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:51:43.905757
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    assert console_c_l_i_0.list_modules() == True


# Generated at 2022-06-24 17:51:48.854360
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    try:
        console_c_l_i_0 = ConsoleCLI()
        console_c_l_i_0.do_list("console_c_l_i_0")
    except Exception:
        print("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-24 17:51:51.792748
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_c_l_i_0 = ConsoleCLI()
    module_name = 'file'
    assert console_c_l_i_0.list_modules() == [module_name]


# Generated at 2022-06-24 17:51:53.124677
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    assert False, "Test not implemented"


# Generated at 2022-06-24 17:52:01.284895
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    test_module_name = 'test_0x1'
    console_c_l_i_0.modules = [test_module_name]
    console_c_l_i_0.module_args(test_module_name)


# Generated at 2022-06-24 17:52:08.366144
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bytes_0 = b'\r7f\x13\x81\xe4\r\x9f\x1ca\xa8\xce\xbd\x06'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    str_0 = console_c_l_i_0.module_args('ping')
    # AssertionError
