

# Generated at 2022-06-24 17:44:27.161401
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.do_list(__name__)


# Generated at 2022-06-24 17:44:34.432307
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # creating context object
    context = {}
    from ansible.playbook.play import Play
    setattr(context,'Play',Play)
    from ansible.playbook.play_context import PlayContext
    setattr(context,'PlayContext',PlayContext)
    from ansible.parsing.yaml.objects import AnsibleUnicode
    setattr(context,'AnsibleUnicode',AnsibleUnicode)
    from ansible.parsing.vault import VaultLib
    setattr(context,'VaultLib',VaultLib)
    from ansible.utils.vars import combine_vars
    setattr(context,'combine_vars',combine_vars)
    from ansible.utils.display import Display
    setattr(context,'Display',Display)
    from ansible.utils.color import string

# Generated at 2022-06-24 17:44:41.626262
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    try:
        str_0 = '%n"*0TJ!3&qo'
        set_0 = {str_0, str_0, str_0, str_0}
        console_c_l_i_0 = ConsoleCLI(set_0, True)
        list_0 = console_c_l_i_0.list_modules()
    except Exception as exc:
        print('Exception from test_ConsoleCLI_list_modules = ', exc)


# Generated at 2022-06-24 17:44:49.810530
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    init_str = '-i /home/michael/test/test_files/test_inventory_file,test -k -u root --private-key=/home/michael/test/test_files/test_key_file -m /home/michael/test/test_files/test_module'
    sys.argv = ['ansible-console', init_str]
    try:
        test_case_0()
    except Exception as e:
        raise Exception('ConsoleCLI test failed: {0}'.format(e))

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop()

# Generated at 2022-06-24 17:44:52.184926
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI({})
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:44:55.923917
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    str_0 = 'I67%'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:45:02.703347
# Unit test for method do_become_method of class ConsoleCLI
def test_ConsoleCLI_do_become_method():
    str_0 = 'et'
    str_1 = '|'
    str_2 = 'fE~W'
    set_0 = {str_0, str_1, str_2}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.do_become_method(None)


# Generated at 2022-06-24 17:45:05.859959
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    x = ConsoleCLI(set_0)
    assert x.complete_cd(text, line, begidx, endidx) != logging


# Generated at 2022-06-24 17:45:09.521952
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    str_0 = '^\nQ\n%&;X#--eAo'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)

    test_case_0()

# Generated at 2022-06-24 17:45:13.594016
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI()


# Generated at 2022-06-24 17:45:37.123080
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():

    console_c_l_i_0 = ConsoleCLI()

    arg_0 = None

    try:
        console_c_l_i_0.do_exit(arg_0)
        arg_1 = None

        console_c_l_i_0.helpdefault(arg_1)

    except TypeError as e:
        assert False

# Unit tests for class ConsoleCLI

# Generated at 2022-06-24 17:45:39.544552
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:40.827714
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # str -> str
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:45:42.021009
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:45.280533
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_0 = ConsoleCLI()

    text = "g"
    line = "cd g"
    begidx = 3
    endidx = 4

    expectedResult = ["roups"]
    actualResult = console_c_l_i_0.complete_cd(text,line,begidx,endidx)

    assert expectedResult == actualResult
    assert isinstance(actualResult, list)


# Generated at 2022-06-24 17:45:48.411542
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.helpdefault('shell')


# Generated at 2022-06-24 17:45:53.326004
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    timeout = 42
    console_c_l_i = ConsoleCLI()
    console_c_l_i.do_timeout(timeout)


# Generated at 2022-06-24 17:45:55.765720
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print("Testing cmdloop")
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:59.638066
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI()
    # Test error condition:
    try:
        console_c_l_i_0.cmdloop()
    except:
        print('An exception is raised')


# Generated at 2022-06-24 17:46:02.365689
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i = ConsoleCLI()
    console_c_l_i.do_list("")
    test_case_0()


# Generated at 2022-06-24 17:46:23.892098
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Generate input parameter
    arg = 'arg'
    # Generate list of output values
    # Execute method
    result = ConsoleCLI.do_cd(ConsoleCLI(set()),arg)
    # Check output values
    check_result_ConsoleCLI_do_cd_0(result)


# Generated at 2022-06-24 17:46:34.835146
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    list_0 = ['', '', '', '', '', '', '', '', '', '']
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    list_0_0 = ['', '', '', '', '', '', '', '', '', '']
    str_0_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0_0 = {str_0_0, str_0_0, str_0_0, str_0_0}
    console_c_l_i_0_0 = ConsoleCL

# Generated at 2022-06-24 17:46:39.637660
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    int_0 = ConsoleCLI.set_prompt()


# Generated at 2022-06-24 17:46:49.634887
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    str_1 = 'b~n1@\n'
    str_2 = 'P\x0c'
    str_3 = 'zG'
    str_4 = '|T'
    str_5 = '<I'
    str_6 = ']\x95\x0e'
    str_7 = 'q\x10\x01]'
    str_8 = 'c~\x1e'
    str_9 = '\x1f\x05\x00'
    str_10 = 'a'


# Generated at 2022-06-24 17:46:54.145219
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    str_0 = ',NB%\x7f+r5w_7aTB\n'
    int_1 = -9
    console_c_l_i_0 = ConsoleCLI(set({str_0, str_0}))
    with pytest.raises(TypeError, match='.*required positional argument:.*'):
        console_c_l_i_0.do_cd(int_1)


# Generated at 2022-06-24 17:47:00.679736
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    assert False
    # Additional tests for method complete_cd of class ConsoleCLI
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.complete_cd(str_0)
    console_c_l_i_0.complete_cd(str_0, str_0, str_0, str_0)


# Generated at 2022-06-24 17:47:05.477538
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = "1"
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    result = console_c_l_i_0.list_modules()
    assert result == None


# Generated at 2022-06-24 17:47:12.206837
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    assert console_c_l_i_0.default(1) == False


# Generated at 2022-06-24 17:47:13.652045
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    pass


# Generated at 2022-06-24 17:47:19.675278
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)

    assert True


# Generated at 2022-06-24 17:47:42.351264
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():

    str_0 = 'F+-L>5}5+t\x0bM\r!r'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)

    # Testing branch do_cd#0
    console_c_l_i_0.do_cd(str_0)



# Generated at 2022-06-24 17:47:54.515117
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    h_0_0 = [0] * 10
    assert type(ConsoleCLI.complete_cd(h_0_0, None, None, None)) == list
    assert type(ConsoleCLI.complete_cd(h_0_0, 0, None, None)) == list
    assert type(ConsoleCLI.complete_cd(h_0_0, 0, 0, None)) == list
    assert type(ConsoleCLI.complete_cd(h_0_0, 0, 0, 0)) == list


# Generated at 2022-06-24 17:47:57.772304
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print('\n########## Testing ConsoleCLI.cmdloop ##########')

    if test_case_0():
        print('Success!')
    else:
        print('Failed!')

    print('###############################################\n')

    return


# Generated at 2022-06-24 17:48:08.456718
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = 'a$ee'
    lst_0 = list()
    lst_1 = list()
    lst_0.append(str_0)
    lst_0.append(str_0)
    lst_1.append(str_0)
    lst_0.append(str_0)
    lst_1.append(lst_0)
    lst_0.append(lst_1)
    tpl_0 = tuple(lst_0)
    tpl_1 = ('C', 'QW1\x7f')
    set_0 = {tpl_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.inventory = tpl_1

# Generated at 2022-06-24 17:48:21.591676
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():

    # Set up test objects
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    int_0 = 153

# Generated at 2022-06-24 17:48:29.957809
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    str_1 = 'w#_WKF8]\x7f\x1b\x13'
    maybe_str_0 = console_c_l_i_0.default(str_1)
    return maybe_str_0


# Generated at 2022-06-24 17:48:34.559012
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = '{B+oOE:[gX'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    str_0 = ')QaYIY[$'
    str_1 = '*A~t\x1d\x07'
    str_2 = 'C;vvH=s+}3)IA\n"$] 4K'
    int_0 = console_c_l_i_0.default(str_0, boolean_0 = boolean(str_1, str_2))


# Generated at 2022-06-24 17:48:37.116204
# Unit test for method helpdefault of class ConsoleCLI

# Generated at 2022-06-24 17:48:38.460987
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    pass


# Generated at 2022-06-24 17:48:49.288452
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = 'S'
    str_1 = 'b'
    dict_1 = {str_0: str_1}
    console_c_l_i_0 = ConsoleCLI(dict_1)
    str_4 = '6'
    list_0 = [str_4]
    dict_1 = {str_0: list_0}
    console_c_l_i_0 = ConsoleCLI(dict_1)
    str_7 = 'b'
    set_0 = {str_0, str_7}
    console_c_l_i_0 = ConsoleCLI(set_0)
    str_11 = 'y'
    dict_1 = {str_0: str_11}
    console_c_l_i_0 = ConsoleCLI(dict_1)
    str_

# Generated at 2022-06-24 17:49:17.173880
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = '\x1d\x1b$\x0e9\x04f\x03\x0c\x0b\x04\x0e\x1f\x00\x1e\x0f\x0c\x14\x1ci\x17\x08\x06\x14\x11'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    int_0 = console_c_l_i_0.do_list('')
    assert int_0 == 0


# Generated at 2022-06-24 17:49:23.169289
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    str_0 = 'Jhx\x03\x1a\x1c'
    console_c_l_i_0.do_verbosity(str_0)


# Generated at 2022-06-24 17:49:37.402784
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    list_0 = ['T', 'Ng>f\x77%c', 'C', 'L', '!', '\x15', 'P', 'l', '\x5d']
    console_c_l_i_0 = ConsoleCLI(list_0)
    console_c_l_i_0.selected = list_0
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    console_c_l_i_0.do_list(str_0)
    console_c_l_i_0.selected = list_0
    console_c_l_i_0.do_list(str_0)


# Generated at 2022-06-24 17:49:43.309044
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)


# Generated at 2022-06-24 17:49:48.073385
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    print("\nTest Case 1:")
    console_c_l_i_1 = ConsoleCLI()
    module_name = 'shell'
    set_1 = {'127.0.0.1', '', ''}
    console_c_l_i_1.helpdefault(module_name)


# Generated at 2022-06-24 17:49:52.813205
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI(args={})
    arg_0 = '*'
    console_c_l_i_0.default(arg_0)


# Generated at 2022-06-24 17:50:06.647769
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    set_0 = {'gTp|\nsP', 'gTp|\nsP', 'gTp|\nsP', 'gTp|\nsP'}
    console_c_l_i_0 = ConsoleCLI(set_0)

    str_0 = 'at*hC6'
    str_1 = 'b(^6 B}'
    str_2 = 'rV*zA'
    str_3 = ';\'~Y'
    console_c_l_i_0.modules = [str_0, str_1, str_2, str_3]
    console_c_l_i_0.helpdefault('at*hC6')
    console_c_l_i_0.helpdefault('b(^6 B}')
    console_c_l_i_

# Generated at 2022-06-24 17:50:10.687196
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    set_0 = {'S)`', 'S)`', 'S)`'}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.cmdloop()
    print(repr(console_c_l_i_0))


# Generated at 2022-06-24 17:50:14.547461
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    print("Running test test_ConsoleCLI_set_prompt...")
    assert ConsoleCLI(set())

    print('PASSED')


# Generated at 2022-06-24 17:50:25.661305
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")

# Generated at 2022-06-24 17:52:11.305235
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = '4d,p:)J8P|3Z>U\n=T2$?#'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.cmdloop()
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:52:21.789187
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Unit test for method do_cd of class ConsoleCLI
    with mock.patch.object(SysArgParser, 'parse_args', autospec=True) as mock_parse_args_0:
        str_0 = '!r'
        set_0 = {str_0, str_0, str_0, str_0}
        mock_parse_args_0.return_value = set_0

        str_1 = '4n^sxCzvk\nFQy'
        tuple_0 = (str_1, str_1, str_1)
        dict_0 = {str_1: '=Ng+N'}
        dict_1 = {tuple_0: dict_0, tuple_0: dict_0, tuple_0: dict_0}
        console_c_l_i_0

# Generated at 2022-06-24 17:52:30.521176
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    try:
        str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
        set_0 = {str_0, str_0, str_0, str_0}
        console_c_l_i_0 = ConsoleCLI(set_0)
    except Exception as e:
        display.error(str(e))
        raise AssertionError
    try:
        console_c_l_i_0.do_list("")
    except Exception as e:
        display.error(str(e))
        raise AssertionError

# Generated at 2022-06-24 17:52:37.441155
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    str_0 = "webservers:&staging:!phoenix:dbservers"
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.do_cd(str_0)


# Generated at 2022-06-24 17:52:46.915239
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = 'I!o^x'
    list_0 = ['invalid-params', 'no-op', int(0), int(0)]
    int_0 = int(0)
    str_1 = 'TOiyp&%H|d.I'
    set_0 = set(['', '', int(0), float(0.0)])
    int_1 = int(0)
    int_2 = int(0)
    str_2 = 'T$,P\x0f\x7fS*m\x7f}C'
    int_3 = int(0)
    int_4 = int(0)
    console_c_l_i_0 = ConsoleCLI(set_0)
    str_3 = '`pZF7fO'

# Generated at 2022-06-24 17:52:50.131435
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI(None)
    set_0 = {console_c_l_i_0}
    console_c_l_i_0.helpdefault(set_0)



# Generated at 2022-06-24 17:53:02.688230
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    set_0 = {'C;vvH=s+}3)IA\n"$] 4K', 'C;vvH=s+}3)IA\n"$] 4K', 'C;vvH=s+}3)IA\n"$] 4K', 'C;vvH=s+}3)IA\n"$] 4K'}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0._play_prereqs()
    console_c_l_i_0.get_host_list(console_c_l_i_0.inventory, console_c_l_i_0.pattern, 0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:53:13.682052
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    text_0 = chr(114) * 2
    line_0 = 'o:u'
    begidx_0 = 2
    endidx_0 = 2
    completedefault_retval_0 = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)
    print('completedefault_retval_0:', completedefault_retval_0)


# Generated at 2022-06-24 17:53:19.267532
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    print('Start test of method default for class ConsoleCLI')
    print('#######Test 1#######')
    console_c_l_i_1 = ConsoleCLI()
    str_0 = '-{x n4o)mvb8W'
    print('Expected Output: False')
    print('Actual Output:', console_c_l_i_1.default(str_0, False))
    print('#######Test 2#######')
    str_0 = 'h>@ 1T(+%cRo'
    print('Expected Output: False')
    print('Actual Output:', console_c_l_i_1.default(str_0, True))
    print('#######Test 3#######')
    console_c_l_i_2 = ConsoleCLI()

# Generated at 2022-06-24 17:53:25.332255
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = 'C;vvH=s+}3)IA\n"$] 4K'
    set_0 = {str_0, str_0, str_0, str_0}
    console_c_l_i_0 = ConsoleCLI(set_0)
    console_c_l_i_0.cmdloop()
