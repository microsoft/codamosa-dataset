

# Generated at 2022-06-24 17:44:51.110413
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    bytes_0 = None
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    bytes_1 = None
    byte_flags_2 = None
    byte_args_3 = None
    byte_parser_4 = None
    byte_display_5 = None
    byte_options_6 = None
    byte_args_7 = None
    byte_options_8 = None
    byte_args_9 = None
    byte_parser_10 = None
    byte_options_11 = None
    byte_args_12 = None
    byte_options_13 = None
    byte_args_14 = None
    byte_options_15 = None
    byte_args_16 = None
    byte_options_17 = None
    byte_args_18 = None
    byte_options_19 = None
    byte_

# Generated at 2022-06-24 17:45:01.245923
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI(argparse.Namespace(
        ask_pass=None,
        ask_become_pass=None,
        become_method='sudo',
        connection='smart',
        check=False,
        diff=False,
        forks=100,
        inventory=None,
        pattern='all',
        remote_user=None,
        subset=None,
        timeout=30,
        tree=None,
        verbosity=3,
    ))
    arg_0 = 'ping'
    forceshell_0 = False
    # default(arg='ping', forceshell=False)
    console_c_l_i_0.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:45:04.932286
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bytes_0 = None
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    module_name_0 = 'yum'
    console_c_l_i_0.module_args(module_name_0)


# Generated at 2022-06-24 17:45:07.722845
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = None
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:08.997622
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    ansible_console = ConsoleCLI("sshpass,becomepass")
    assert ansible_console.help_ping() == "nothing to see here"


# Generated at 2022-06-24 17:45:17.094625
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console_c_l_i_0 = ConsoleCLI()
    s_0 = """ConsoleCLI.run()"""
    assertEqual(console_c_l_i_0.run(), s_0, "Object >%s< has attribute >%s< but the function failed" %(console_c_l_i_0,s_0))


# Generated at 2022-06-24 17:45:23.571234
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    display.debug("Test case: completedefault")

    console_c_l_i_0 = ConsoleCLI(None)
    console_c_l_i_0.modules = ['ping', 'setup', 'shell']
    console_c_l_i_0.do_ping('ping')
    console_c_l_i_0.completedefault('ping', 'ping', 3, 3)
    console_c_l_i_0.do_cd('cd')
    console_c_l_i_0.complete_cd('cd', 'cd', 2, 2)


# Generated at 2022-06-24 17:45:25.923199
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = None
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    arg_0 = "*"
    forceshell_0 = False
    return_value_0 = console_c_l_i_0.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:45:33.386095
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    sys.argv = ['ansible-console']
    bytes_0 = None
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    _arg_0 = 'ping'

    # Call method default of console_c_l_i_0
    result_0 = console_c_l_i_0.default(_arg_0)


# Generated at 2022-06-24 17:45:45.521794
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():

    console_c_l_i_0 = ConsoleCLI(None)

    # The method do_verbosity needs a defined class atribute display
    # since the method do_verbosity uses the method display.v which
    # is defined in the class AnsibleConsoleDisplay

    # Define class attribute display
    console_c_l_i_0.display = AnsibleConsoleDisplay()

    # Define class attribute verbosity
    console_c_l_i_0.verbosity = 0

    # Test Case 1
    console_c_l_i_0.do_verbosity(None)
    # Test Case 2
    console_c_l_i_0.do_verbosity('0')
    # Test Case 3
    console_c_l_i_0.do_verbosity('1')
    # Test Case 4
    console_

# Generated at 2022-06-24 17:46:07.544739
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI
    module_name_0 = 'fablest'
    console_c_l_i_0.helpdefault(module_name_0)


# Generated at 2022-06-24 17:46:09.861320
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = None
    console_c_l_i_0 = ConsoleCLI(bytes_0)



# Generated at 2022-06-24 17:46:18.057598
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    with patch('builtins.open') as mock_open:
        with patch('os.path.join') as mock_join:
            with patch('os.path.isdir') as mock_isdir:
                with patch('os.listdir') as mock_listdir:
                    # setup test
                    file_path = os.path.abspath(__file__)
                    mock_open.return_value.__iter__.return_value = ['module_utils']
                    mock_listdir.return_value = ['module_utils']
                    mock_join.return_value = '/mock/path/module_utils'

                    # test
                    console_c_l_i_0 = ConsoleCLI(file_path)
                    console_c_l_i_0.list_modules()

                    # assertions
                    mock_listdir.assert_

# Generated at 2022-06-24 17:46:28.366525
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    # Case1: starts with 'cd ' and text is ''
    text_1 = ''
    line_1 = 'cd '
    begidx_1 = 3
    endidx_1 = 3
    result_1 = console_c_l_i_0.complete_cd(text_1, line_1, begidx_1, endidx_1)
    # Case2: starts with 'cd ' and text is 'all'
    text_2 = 'all'
    line_2 = 'cd '
    begidx_2 = 3
    endidx_2 = 3

# Generated at 2022-06-24 17:46:37.411252
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    arg = ''
    import sys
    sys.modules['__main__'].__dict__.clear() # Clear stdout cache before each test run
    print('Test Case 1: No Arguments')
    console_c_l_i_1 = ConsoleCLI(None)
    console_c_l_i_1.do_timeout(arg)
    assert sys.stdout.getvalue() == 'Usage: timeout <seconds>\n'
    print('Test Case 2: Valid Input')
    arg = '0'
    sys.stdout.getvalue().clear() # Clear stdout cache before each test run
    console_c_l_i_2 = ConsoleCLI(None)
    console_c_l_i_2.do_timeout(arg)

# Generated at 2022-06-24 17:46:47.623446
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    try:
        print('Testing list_modules of class ConsoleCLI')
        bytes_0 = None
        console_c_l_i_0 = ConsoleCLI(bytes_0)
        # One iteration of the loop should be enough
        break
    except:
        pass
    try:
        print('Testing list_modules of class ConsoleCLI')
        bytes_0 = None
        console_c_l_i_0 = ConsoleCLI(bytes_0)
        # One iteration of the loop should be enough
        break
    except:
        pass

# Generated at 2022-06-24 17:46:49.602468
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    module_exists_0 = ansible_module_exists_0()

# Mocking of function ansible_module_exists

# Generated at 2022-06-24 17:46:55.762419
# Unit test for method helpdefault of class ConsoleCLI

# Generated at 2022-06-24 17:46:58.994691
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    args = ''
    console_c_l_i_0 = ConsoleCLI(args)
    to_text_0 = console_c_l_i_0.do_list(args)
    assert to_text_0 == None

# Generated at 2022-06-24 17:47:09.427254
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    import sys
    sys.argv = [sys.argv[0]] + ["--tree", "/tmp/ansible-sandboxtest_case_0/"] + ["--inventory", "/tmp/ansible-sandboxtest_case_0/.ansible/tmp6U4bDF", "--forks", "10"] + ["localhost"]
    sys.argv = [sys.argv[0]] + ["--tree", "/tmp/ansible-sandboxtest_case_0/"] + ["--inventory", "/tmp/ansible-sandboxtest_case_0/.ansible/tmp6U4bDF", "--forks", "10"] + ["localhost"]

# Generated at 2022-06-24 17:47:28.913087
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    test_case_0()
    # 
    # 
    # 
    # 
    # 
    # 
    assert False, "Unit test failed."


# Generated at 2022-06-24 17:47:42.879349
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    list_modules = ConsoleCLI.list_modules()

# Generated at 2022-06-24 17:47:54.218681
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_cli_0 = ConsoleCLI()
    try:
        console_cli_0.set_prompt()
    except:
        pass
    arg_0 = 'my_test_console_cli'
    arg_1 = 'my_test_console_cli'
    arg_2 = 22
    arg_3 = 22
    console_cli_0.completedefault(arg_0, arg_1, arg_2, arg_3)

# Generated at 2022-06-24 17:48:02.161344
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_cli_0 = ConsoleCLI()
    text_0 = 'fablest'
    line_0 = 'fablest'
    begidx_0 = 'fablest'
    endidx_0 = 'fablest'
    console_cli_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:48:06.264319
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    print("==== ConsoleCLI::default ====")
    print("Not implemented")


# Generated at 2022-06-24 17:48:08.518187
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    consoleCLI_0 = ConsoleCLI(test_case_0)

test_ConsoleCLI_run()

# Generated at 2022-06-24 17:48:21.623976
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    c = ConsoleCLI()
    c.cwd = 'all'
    c.inventory = Inventory(loader=c.loader, variable_manager=c.variable_manager, host_list='hosts')
    c.selected = 'all'
    c.remote_user = 'dummy_user'
    c.become = True
    c.become_user = 'dummy_user'
    c.become_method = 'sudo'
    c.check_mode = False
    c.diff = True
    c.forks = 5
    c.task_timeout = 5
    c.modules = c.list_modules()
    c.passwords = {'conn_pass': 'dummy_conn_pass', 'become_pass': 'dummy_become_pass'}
    c.cmdloop()

    assert c

# Generated at 2022-06-24 17:48:23.720010
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    obj_0 = ConsoleCLI()
    print(obj_0.list_modules())
    print(obj_0.list_modules())


# Generated at 2022-06-24 17:48:28.762202
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = getTempFileName()
    str_0 = os.path.abspath(str_0)

    # test_case_0
    str_0 = 'fablest'
    str_1 = ConsoleCLI().cmdloop()

# Generated at 2022-06-24 17:48:30.504298
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_cli = ConsoleCLI()
    console_cli.helpdefault()


# Generated at 2022-06-24 17:48:49.133153
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = 'fablest'
    con = ConsoleCLI()
    con.do_list(ConsoleCLI_do_list_0)


# Generated at 2022-06-24 17:48:51.740675
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    cli = ConsoleCLI()
    cli.run()
    assert cli.inventory is cli._inventory


# Generated at 2022-06-24 17:48:56.996172
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    unittest.main()
    console = ConsoleCLI(args=[])
    console.list_modules()
    console.ask_vault_passwords()
    #print console.ask_passwords()
    #console.run()


# Generated at 2022-06-24 17:49:02.565896
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    # Create an instance of class ConsoleCLI
    cli_0 = ConsoleCLI()
    # Call method run of class ConsoleCLI
    cli_0.run()

# Testing the methods of class ConsoleCLI


# Generated at 2022-06-24 17:49:04.037852
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    str_0 = 'fablest'
    x = ConsoleCLI()
    x.run()

# Generated at 2022-06-24 17:49:09.043069
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    obj_0 = ConsoleCLI()
    str_0 = 'fablest'
    obj_0.cmdloop()
    return None

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop()

# Generated at 2022-06-24 17:49:14.275902
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    console_cli_0 = ConsoleCLI()
    console_cli_0.post_process_args(str_0)


# Generated at 2022-06-24 17:49:18.581043
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Verify that no exception is thrown for the following test cases

    # Test case 1
    str_0 = 'groups'
    self_1 = ConsoleCLI()
    self_1.do_list(str_0)


# Generated at 2022-06-24 17:49:26.404829
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    obj = ConsoleCLI()
    str_0 = 'syntax: verbosity'
    try:
        obj.do_verbosity('')
    except Exception as e:
        print(e)
        assert str_0 == str(e)


# Generated at 2022-06-24 17:49:36.865179
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    host = '172.93.53.53'
    host_list = [host]
    port = 22
    username = 'root'
    password = 'root'
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.extra_vars = {'ansible_ssh_host': host,
                                   'ansible_ssh_port': port,
                                   'ansible_ssh_user': username,
                                   'ansible_ssh_pass': password}
    ssh_args = "-o StrictHostKeyChecking=no -o PasswordAuthentication=no"
    password = None
    become = False
    become_method = None
    become_user = None
    become_pass = None
    become_exe = None
    become

# Generated at 2022-06-24 17:50:14.898445
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    first_try = True
    local_0 = None
    local_1 = None
    local_2 = None
    local_3 = None
    local_4 = None
    local_5 = None
    local_6 = None
    local_7 = None
    local_8 = None
    local_9 = None

# Generated at 2022-06-24 17:50:17.273908
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg_0 = "fablest"
    forceshell_0 = False

    cur_console = ConsoleCLI()
    cur_console.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:50:23.480983
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = 'fablest'
    console_0 = ConsoleCLI()
    # No exception expected for invoking default method
    try:
        console_0.default(str_0)
    except:
        print('Exception: ' + str(sys.exc_info()))
        raise
    pass



# Generated at 2022-06-24 17:50:24.919569
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    assert test_case_0() == 'fablest'


# Generated at 2022-06-24 17:50:27.026998
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    console_cli_0 = ConsoleCLI()
    console_cli_0.set_prompt()


# Generated at 2022-06-24 17:50:29.447996
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console = ConsoleCLI(None)
    console.list_modules()


# Generated at 2022-06-24 17:50:35.429612
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    # 
    # Test case #5 - "host_list" parameter is a tuple
    # 
    c = ConsoleCLI()
    c.optparser.values.host_list = ('localhost',)
    # 
    # Test case #6 - "host_list" parameter is a tuple
    # 
    c = ConsoleCLI()
    c.optparser.values.host_list = ('localhost', 'localhost')

# Generated at 2022-06-24 17:50:37.828170
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    obj_ConsoleCLI = ConsoleCLI()
    str_1 = 'fablest'
    ret_2 = obj_ConsoleCLI.default(str_1)
    assert ret_2 == False


# Generated at 2022-06-24 17:50:39.683256
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    consolecli = ConsoleCLI()
    consolecli.cmdloop()


# Generated at 2022-06-24 17:50:43.878814
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    param_0 = ConsoleCLI()
    param_1 = str
    # try:
    param_0.helpdefault(param_1)
    # except Exception as e:
    #     raise e
    # else:
    #     raise Exception('Failed to raise exception')


# Generated at 2022-06-24 17:51:35.833718
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    ans = ConsoleCLI()
    ans.post_process_args(None)
    ans.post_process_args([])
    ans.post_process_args(["-h"])

# Generated at 2022-06-24 17:51:38.266467
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    ansible_console = ConsoleCLI()
    ansible_console.helpdefault(str_0)

# Generated at 2022-06-24 17:51:41.233287
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Unit test for method helpdefault of class ConsoleCLI
    print('\n==== Test Case 0 ====')
    str = 'fablest'

    ConsoleCLI.helpdefault(str)

test_ConsoleCLI_helpdefault()
test_case_0()

# Generated at 2022-06-24 17:51:43.408592
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    ans_console_0 = ConsoleCLI(context.CLIARGS, str_0)
    ans_console_0.list_modules()


# Generated at 2022-06-24 17:51:45.712772
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
	console_0 = ConsoleCLI()
	assert console_0.do_list('') == None


# Generated at 2022-06-24 17:51:48.339864
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    obj_0 = ConsoleCLI()
    obj_0.do_list('groups')
    obj_0.do_list('')


# Generated at 2022-06-24 17:51:50.716983
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    cli = ConsoleCLI()
    cli.default('fablest')
    ConsoleCLI.default(cli, 'fablest')


# Generated at 2022-06-24 17:51:53.505921
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    myConsoleCLI = ConsoleCLI()
    test_ConsoleCLI_run_0(myConsoleCLI)
    return 1


# Generated at 2022-06-24 17:52:04.557049
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Local variables:
    arg = None
    # Unit test for method do_list of class ConsoleCLI
    # Tests that list() prints something when given no argument
    test_str_0 = 'test string'
    str_0 = 'fablest'
    arg = str_0
    test_ConsoleCLI_do_list_0 = ConsoleCLI(test_str_0)
    test_ConsoleCLI_do_list_1 = test_ConsoleCLI_do_list_0.do_list(arg)
    # Tests that list() accepts a valid argument
    str_1 = 'groups'
    arg = str_1
    test_ConsoleCLI_do_list_2 = test_ConsoleCLI_do_list_0.do_list(arg)



# Generated at 2022-06-24 17:52:12.245158
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    '''
    Unit test for method set_prompt of class ConsoleCLI
    '''
    # Set up test data
    console_cli = ConsoleCLI()
    console_cli.cwd = 'fablest'
    console_cli.remote_user = 'test'
    console_cli.become = True
    console_cli.become_user = 'test'
    console_cli.check_mode = False

    # Execute the tested method
    console_cli.set_prompt()
    ret = console_cli.prompt
    assert(ret == 'fablest:test:test:False$ ')


# Generated at 2022-06-24 17:52:48.900707
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    _console_cli_0 = ansible.cli.console.ConsoleCLI()
    _console_cli_0.completedefault('text', 'line', begidx=0, endidx=0)


# Generated at 2022-06-24 17:52:54.485034
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_1 = 'ansible-console'
    str_2 = 'string'
    bool_0 = False
    bool_1 = 0.8746984379945587

    # Call method default of class ConsoleCLI using following parameters:
    # bool_0: bool: False
    # bool_1: bool: True
    # str_1: str: 'ansible-console'
    # str_2: str: 'string'
    ConsoleCLI.default(bool_0, bool_1, str_1, str_2)



# Generated at 2022-06-24 17:52:57.450973
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console_cli = ConsoleCLI(description='Ansible Shell Tool')
    console_cli.run()


# Generated at 2022-06-24 17:53:00.957300
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    cli = ConsoleCLI()
    assert cli.default('', False) == False
    assert cli.helpdefault('ping') == None


# Generated at 2022-06-24 17:53:12.745315
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    print("Testing ConsoleCLI.list_modules()")

# Generated at 2022-06-24 17:53:14.508691
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    if (test_case_0()):
        return False
    return True


# Generated at 2022-06-24 17:53:16.085794
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    pass
    # TODO



# Generated at 2022-06-24 17:53:25.802955
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    os.environ['ANSIBLE_CONSOLE_HOSTS'] = ','.join(['192.168.0.1', '192.168.0.2', '192.168.0.8'])
    os.environ['ANSIBLE_CONSOLE_MODULE'] = 'shell'
    os.environ['ANSIBLE_CONSOLE_ARGS'] = 'hostname'
    os.environ['ANSIBLE_CONSOLE_VERBOSITY'] = '0'
    os.environ['ANSIBLE_CONSOLE_ASK_PASS'] = '0'

    a = ConsoleCLI()
    a.run()


# Generated at 2022-06-24 17:53:36.443439
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console_cli_obj_0 = ConsoleCLI()
    console_cli_obj_0.run()
    open_mock = mock.open()
    with open_mock as f_mock, mock.patch('ansible_mitogen.ansible_mitogen.target.inject_directory', side_effect=lambda p:True):
        console_cli_obj_0.mitogen_target = mock.MagicMock()
        console_cli_obj_0.mitogen_target.inject_directory = mock.MagicMock()
        console_cli_obj_0.run()
        console_cli_obj_0.mitogen_target.inject_directory.assert_called_with('fablest')

if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_run

# Generated at 2022-06-24 17:53:42.620696
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    global str_0
    x = ConsoleCLI()
    x.test_var = str_0
    x.cmdloop()
    print(x.test_var)

# This class should be instantiated and run, no command line args