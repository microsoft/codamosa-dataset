

# Generated at 2022-06-24 17:44:50.905236
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI()
    assert False, "Unit test not implemented"


# Generated at 2022-06-24 17:44:52.006576
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()


# Generated at 2022-06-24 17:44:55.621253
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bool_0 = False
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_name_0 = 'ping'
    var_1 = console_c_l_i_0.module_args(module_name_0)
    print("var_1: %s" % var_1)


# Generated at 2022-06-24 17:45:05.321107
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    # String
    text_0 = 'abc'
    # String
    line_0 = 'abc'
    # Integer
    begidx_0 = randrange(2147483647)
    # Integer
    endidx_0 = randrange(2147483647)
    var_0 = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:45:07.065221
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.default("", True)


# Generated at 2022-06-24 17:45:08.227557
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # test case 0
    assert test_case_0() == 0
    return 0

# Generated at 2022-06-24 17:45:09.622342
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Test 1
    assert test_case_0() == None

# Test of class ConsoleCLI

# Generated at 2022-06-24 17:45:20.072345
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg = "shell"
    forceshell = True
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.default(arg, forceshell)
    console_c_l_i_0.default(arg)


# Generated at 2022-06-24 17:45:21.013685
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    assert True == True


# Generated at 2022-06-24 17:45:33.688560
# Unit test for method module_args of class ConsoleCLI

# Generated at 2022-06-24 17:46:08.494095
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    with mock.patch.multiple(
        ConsoleCLI,
        modules=[],
    ):
        test_case_0()

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='ansible-console %s' % __version__)

    parser.add_argument('--version', action='version',
                        version='ansible-console %s' % __version__)

    parser.add_argument('pattern', nargs='?', default='*',
                        help='The host pattern to select, by default all hosts are selected')

    parser.add_argument('--subset', default=None,
                        help='The subset pattern to select, by default all groups are selected')


# Generated at 2022-06-24 17:46:11.440827
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = 'test_str'
    bool_1 = True
    console_c_l_i_0.default(str_0, bool_1)


# Generated at 2022-06-24 17:46:15.640857
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    for boolean_0 in range(TestInput.boolean_test_cases):
        test_case_0()

# Generated at 2022-06-24 17:46:20.455113
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bool_0 = False
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = 'sysctl'
    console_c_l_i_0.helpdefault(str_0)


# Generated at 2022-06-24 17:46:25.026898
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    int_0 = console_c_l_i_0.default('shell ps aux | grep root')


# Generated at 2022-06-24 17:46:28.190813
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_name_0 = 'ping'
    var_0 = console_c_l_i_0.module_args(module_name_0)

if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_module_args()

# Generated at 2022-06-24 17:46:31.478007
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    bool_0 = True
    console_c_l_i_1 = ConsoleCLI(bool_0)
    var_1 = console_c_l_i_1.set_prompt()
    del bool_0
    del console_c_l_i_1
    del var_1


# Generated at 2022-06-24 17:46:36.335004
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print('>>> Running test_ConsoleCLI_cmdloop...')
    test_case_0()
    print('<<< Test complete.')


# Generated at 2022-06-24 17:46:39.836336
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # verify access to class attribute modules
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    completedefault_return_value_0 = console_c_l_i_0.completedefault(text='text_0', line='line_0', begidx='line_1', endidx='line_2')
    assert completedefault_return_value_0 is None
    # verify access to class attribute modules
    # verify access to class method module_args


# Generated at 2022-06-24 17:46:45.210232
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    method_name = 'do_cd'
    test_case_ConsoleCLI_do_cd_0()
    test_case_ConsoleCLI_do_cd_1()
    test_case_ConsoleCLI_do_cd_2()
    test_case_ConsoleCLI_do_cd_3()


# Generated at 2022-06-24 17:46:59.308930
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    console_c_l_i_obj_0 = ConsoleCLI()
    console_c_l_i_obj_0.set_prompt()


# Generated at 2022-06-24 17:47:03.786718
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    arg_0 = u'ping'
    forceshell_0 = False
    var_0 = console_c_l_i_0.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:47:13.193412
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Test 1 : with input as module_name in self.modules
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_name = 'authorize'
    console_c_l_i_0.helpdefault(module_name)

    # Test 2 : without input as module_name in self.modules
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_name = 'authorize1'
    console_c_l_i_0.helpdefault(module_name)



# Generated at 2022-06-24 17:47:18.607876
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Create and set up an instance of ConsoleCLI
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    var_0 = console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:47:29.318410
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = 'test_str_0'
    str_1 = 'test_str_1'
    int_0 = 1
    int_1 = 1
    str_2 = console_c_l_i_0.completedefault(str_0, str_1, int_0, int_1)
    pass


# Generated at 2022-06-24 17:47:34.985729
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    is_test_case = True
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    string_0 = "fail"
    bool_1 = False
    tuple_0 = (string_0, bool_1)
    return tuple_0

test_classes = [ConsoleCLI]

if __name__ == "__main__":
    import sys
    ret = 0
    x = None
    if len(sys.argv) == 2 and sys.argv[1] == "--test":
        print("Unit testing...")
        for i in test_classes:
            x = test_ConsoleCLI_default()
            if x != None:
                print("Failed test case: " + i.__name__)
                ret = ret + 1

# Generated at 2022-06-24 17:47:35.940141
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    test_case_0()

    assert True


# Generated at 2022-06-24 17:47:42.849972
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    var_0 = 'seconds'
    var_1 = console_c_l_i_0.do_timeout(var_0)
    assert var_1 == None


# Generated at 2022-06-24 17:47:49.545240
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
  console_c_l_i_0 = ConsoleCLI(True)
  # Run the method and check the output
  console_c_l_i_0.helpdefault("docker")


# Generated at 2022-06-24 17:47:54.807494
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    try:
        test_case_0()
    except IOError as e:
        raise
        # Unit test for method load_from_file of class ConsoleCLI


# Generated at 2022-06-24 17:48:07.785642
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    console_c_l_i_var_0 = ConsoleCLI()


# Generated at 2022-06-24 17:48:11.595325
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = "k0"
    str_1

# Generated at 2022-06-24 17:48:13.357064
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()


# Generated at 2022-06-24 17:48:16.112659
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    pass


# Generated at 2022-06-24 17:48:19.440073
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_1 = ConsoleCLI()
    var_x_1 = console_c_l_i_1.default("#")
    assert var_x_1 is False


# Generated at 2022-06-24 17:48:23.436592
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = "cd"
    console_c_l_i_0.helpdefault(str_0)


# Generated at 2022-06-24 17:48:25.317177
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # AssertionError: False is not true : Test with failure
    assert True


# Generated at 2022-06-24 17:48:35.230786
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    test_case_0()

if __name__ == '__main__':
    test_ConsoleCLI_helpdefault()

#  def helpdefault(self, module_name):
#      """ displays help on a module """
#      if module_name in self.modules:
#          in_path = module_loader.find_plugin(module_name)
#          if in_path:
#              oc, a, _, _ = plugin_docs.get_docstring(in_path, fragment_loader)
#              if oc:
#                  display.display(oc['short_description'])
#                  display.display('Parameters:')
#                  for opt in oc['options'].keys():
#                      display.display('  ' + stringc(opt, self.NORMAL_PROMPT) + ' ' + oc['options

# Generated at 2022-06-24 17:48:40.379277
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_name = 'ping'
    var_0 = console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:48:42.811331
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    ConsoleCLI_0 = ConsoleCLI(True)
    ConsoleCLI_0.cmdloop()

# Generated at 2022-06-24 17:49:36.945477
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_c_l_i_0 = ConsoleCLI(False)
    var_0 = console_c_l_i_0.list_modules()

if __name__ == '__main__':
    test_ConsoleCLI_list_modules()

# Generated at 2022-06-24 17:49:43.369764
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    var_0 = console_c_l_i_0.completedefault('', True, 1, 2)
    expected = None  # TODO
    if var_0 != expected:
        raise AssertionError(var_0)

# Generated at 2022-06-24 17:49:48.857538
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    print("Test 0 : ")
    # console_c_l_i_0 = new object of class ConsoleCLI
    console_c_l_i_0 = ConsoleCLI(False)
    # console_c_l_i_0.completedefault()
    # test that there is No exception and the output is non - negative
    assert (0 <= var_0)
    print("passed test 0")


# Generated at 2022-06-24 17:49:53.251739
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Instantiate ConsoleCLI
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    # Assign parameter
    text_0 = 'ping'
    line_0 = 'ping'
    begidx_0 = 0
    endidx_0 = 0
    # Invoke method
    completedefault_0 = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)
    # Check return value
    if (completedefault_0 != 'ping='):
        raise Exception("Return value mismatch in test_ConsoleCLI_completedefault")


# Generated at 2022-06-24 17:49:57.490348
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_name_0 = "ytSt4z"
    console_c_l_i_0.helpdefault(module_name_0)


# Generated at 2022-06-24 17:50:01.694442
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    var_0 = 'shell'
    var_1 = console_c_l_i_0.helpdefault(var_0)


# Generated at 2022-06-24 17:50:05.026187
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:50:14.049628
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = False
    console_c_l_i_0 = ConsoleCLI(bool_0)
    module_0 = 'shell'
    module_args_0 = ""
    var_0 = console_c_l_i_0.default(module_0, module_args_0)

    module_0 = 'shell'
    module_args_0 = "ps aux | grep java | wc -l"
    var_0 = console_c_l_i_0.default(module_0, module_args_0)

    module_0 = 'shell'
    module_args_0 = 'killall python'
    var_0 = console_c_l_i_0.default(module_0, module_args_0)

    module_0 = 'shell'

# Generated at 2022-06-24 17:50:15.890993
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop()

# Generated at 2022-06-24 17:50:19.537796
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # Args:
    bool_2 = True
    console_c_l_i_2 = ConsoleCLI(bool_2)
    console_c_l_i_2.set_prompt()


# Generated at 2022-06-24 17:51:14.905617
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_0 = ConsoleCLI()
    string_0 = ''
    string_1 = ''
    int_0 = 0
    int_1 = 0
    var_0 = console_c_l_i_0.complete_cd(string_0, string_1, int_0, int_1)
    if var_0:
        print("Test 1 passed")
    else:
        print("Test 1 failed")

    string_0 = ' '
    string_1 = ' '
    int_0 = 0
    int_1 = 0
    var_0 = console_c_l_i_0.complete_cd(string_0, string_1, int_0, int_1)
    if var_0:
        print("Test 2 passed")
    else:
        print("Test 2 failed")

# Generated at 2022-06-24 17:51:16.449093
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Test case class init
    test_case_0()


# Generated at 2022-06-24 17:51:19.094262
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:51:23.203237
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    # Create an instance from a given class
    console_c_l_i_0 = ConsoleCLI(True)
    # Create a local variable
    var_0 = "1"
    var_1 = (console_c_l_i_0.do_verbosity(var_0))


# Generated at 2022-06-24 17:51:25.696639
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:51:32.489664
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(True)
    test_case_0()
    var_0 = console_c_l_i_0.cmdloop()
    var_0 = console_c_l_i_0.cmdloop()
    var_0 = console_c_l_i_0.cmdloop()
    var_0 = console_c_l_i_0.cmdloop()
    var_0 = console_c_l_i_0.cmdloop()
    if var_0:
        pass


# Generated at 2022-06-24 17:51:35.957429
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.do_verbosity("3")


# Generated at 2022-06-24 17:51:39.853401
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    list_0 = console_c_l_i_0.list_modules()
    bool_1 = isinstance(list_0, ListType)


# Generated at 2022-06-24 17:51:46.996761
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    #@UnresolvedImport
    #from ansible.console.console import ConsoleCLI
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)

    #@UnresolvedImport
    #from ansible.module_utils._text import to_bytes
    to_bytes(bool_0, 'utf-8', errors='surrogate_or_strict')
    str_0 = '/tmp'
    str_1 = 'linux'
    str_2 = 'yum'
    str_3 = 'shell'
    str_4 = 'debug'
    str_5 = 'setup'
    str_6 = 'apt'
    str_7 = 'lineinfile'
    str_8 = 'file'
    str_9 = 'user'

# Generated at 2022-06-24 17:51:53.926763
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = "ansible-console"
    str_1 = "ansible-console"
    str_2 = "ansible-console $"
    str_3 = ""
    int_0 = 0
    int_1 = 1
    console_c_l_i_0.completedefault(str_0, str_1, int_0, int_1)



# Generated at 2022-06-24 17:52:55.057708
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    var_0 = console_c_l_i_0.cmdloop()



# Generated at 2022-06-24 17:53:01.167773
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    start_time = datetime.now()

# Generated at 2022-06-24 17:53:07.615920
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = '#'
    bool_1 = False
    var_0 = console_c_l_i_0.default(str_0, bool_1)
    assert var_0 == False


# Generated at 2022-06-24 17:53:08.586953
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    pass


# Generated at 2022-06-24 17:53:11.637226
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # Calling method set_prompt of ConsoleCLI
    test_case_0()


if __name__ == '__main__':
    test_ConsoleCLI_set_prompt()

# Generated at 2022-06-24 17:53:24.513777
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i_0 = ConsoleCLI(False)
    var_0 = console_c_l_i_0.cmdloop()
    console_c_l_i_1 = ConsoleCLI(False)
    var_1 = console_c_l_i_1.cmdloop()
    console_c_l_i_2 = ConsoleCLI(True)
    var_2 = console_c_l_i_2.cmdloop()
    console_c_l_i_3 = ConsoleCLI(False)
    var_3 = console_c_l_i_3.cmdloop()
    console_c_l_i_4 = ConsoleCLI(True)
    var_4 = console_c_l_i_4.cmdloop()

if __name__ == '__main__':
    test

# Generated at 2022-06-24 17:53:31.081148
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    try:
        global var_0
        global var_1
        var_0 = None
        console_c_l_i_0 = ConsoleCLI(True)
        console_c_l_i_0.do_cd('hosts')
        if var_0 is not None:
            print('Failed at line no:', var_0)
        if var_1 is not None:
            print('Failed at line no:', var_1)
    except Exception:
        print('Exception at line no:', var_1)
    

# Generated at 2022-06-24 17:53:37.729530
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    const_0 = 1
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = 'test'
    var_0 = console_c_l_i_0.completedefault(str_0, str_0, const_0, const_0)
    assert var_0 == 't'


# Generated at 2022-06-24 17:53:49.650849
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_0 = ConsoleCLI(arg_0=False)
    var_0  = console_c_l_i_0.do_cd("")
    console_c_l_i_1 = ConsoleCLI(arg_0=False)
    var_1  = console_c_l_i_1.do_cd("")
    console_c_l_i_2 = ConsoleCLI(arg_0=False)
    var_2  = console_c_l_i_2.do_cd("")
    console_c_l_i_3 = ConsoleCLI(arg_0=False)
    var_3  = console_c_l_i_3.do_cd("")