

# Generated at 2022-06-24 17:44:29.758692
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = -5.524048193015582
    console_c_l_i_0 = ConsoleCLI(float_0)
    float_1 = -65.32845758877673
    console_c_l_i_0.forks = float_1
    str_0 = "z@9"
    str_1 = "O|+un>8"
    str_2 = "\t5"
    str_3 = "}g"
    str_4 = "HjW8b"
    string_0 = str_0 + str_1 + str_2 + str_3 + str_4
    console_c_l_i_0.become_user = string_0
    # Call of method list_modules 
    list_0 = console_c_l_i_0.list_

# Generated at 2022-06-24 17:44:36.082149
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = -11.776271339476501
    console_c_l_i_0 = ConsoleCLI(float_0)
    list_0 = console_c_l_i_0.list_modules()
    assert(len(list_0) == 3)
    assert(list_0[0] == 'loop_control')
    assert(list_0[1] == 'template')
    assert(list_0[2] == 'wait_for')


# Generated at 2022-06-24 17:44:39.028997
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():

    console_c_l_i_1 = ConsoleCLI()
    console_c_l_i_1.do_list("test_arg_0")



# Generated at 2022-06-24 17:44:41.734974
# Unit test for method post_process_args of class ConsoleCLI
def test_ConsoleCLI_post_process_args():
    console_c_l_i_0 = ConsoleCLI()
    assert(console_c_l_i_0.post_process_args() == None)

# Generated at 2022-06-24 17:44:45.051141
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = -67.12019500491469
    console_c_l_i_0 = ConsoleCLI(float_0)
    print(console_c_l_i_0.list_modules())


# Generated at 2022-06-24 17:44:48.690230
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.list_modules()


# Generated at 2022-06-24 17:45:00.152229
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)
    # set up
    try:
        shutil.rmtree('test-console-modules')
    except:
        pass
    shutil.copytree('lib/ansible/modules', 'test-console-modules')

# Generated at 2022-06-24 17:45:13.707929
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    int_0 = 0
    string_0 = "|>6u~7zO5_6u5{G&%oSpO8kd@w^4uL7v`%F&f8G>q^9@|72H^I&;2[8Yk#wZ{'B@wbH"
    int_1 = 0
    string_1 = "pkf:_hEqG+^~>Z"
    int_2 = 0
    string_2 = "E#J*F[kA{%c<wOF+Z"
    int_3 = 0
    console_c_l_i_0 = ConsoleCLI(string_0)

# Generated at 2022-06-24 17:45:23.495814
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.do_timeout(-1)
    console_c_l_i_0.do_timeout(-2)
    console_c_l_i_0.do_timeout(-3)
    console_c_l_i_0.do_timeout(-4)
    console_c_l_i_0.do_timeout(-5)
    console_c_l_i_0.do_timeout(-6)
    console_c_l_i_0.do_timeout(-7)
    console_c_l_i_0.do_timeout(-8)


# Generated at 2022-06-24 17:45:26.442511
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    args = 'groups'
    console_c_l_i_0 = ConsoleCLI(args)
    console_c_l_i_0.do_list(args)


# Generated at 2022-06-24 17:46:40.208581
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    ConsoleCLI(123)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:46:45.187326
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    float_0 = -0.30959586257163823
    module_name = 'arbitrary string'
    console_c_l_i_0 = ConsoleCLI(float_0)
    module_name = 'arbitrary string'
    assert console_c_l_i_0.helpdefault(module_name) == False


# Generated at 2022-06-24 17:46:51.290606
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)
    module_name_0 = '__hostname__'
    console_c_l_i_0.helpdefault(module_name_0)


# Generated at 2022-06-24 17:46:56.826487
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    float_0 = 29.35020758061722
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = console_c_l_i_0.complete_cd(text_0, line_0, begidx_0, endidx_0)
    print(text_0)


# Generated at 2022-06-24 17:46:59.531026
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)

# Generated at 2022-06-24 17:47:03.014959
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    float_0 = -53.8
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:47:07.554080
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i_0 = ConsoleCLI()
    #TODO: figure out the tests for this method


# Generated at 2022-06-24 17:47:15.946836
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)
    module_name = 'debug'

    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:47:21.537329
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)
    assert hasattr(console_c_l_i_0, 'list_modules')
    print('\nComputed: ' + str(console_c_l_i_0.list_modules()) + '\nExpected: ' + str(['ping', 'setup', 'debug']))
    assert console_c_l_i_0.list_modules() == ['ping', 'setup', 'debug']


# Generated at 2022-06-24 17:47:30.036277
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    text = (2.1 + 7.1)
    line = -51.6957
    begidx = -8808.5769
    endidx = 9.0
    console_cli_class_object = ConsoleCLI(-629.41)
    assert_expect(console_cli_class_object.complete_cd(text, line, begidx, endidx) , -8168.966683801445)


# Generated at 2022-06-24 17:48:06.710729
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    try:
        console_c_l_i_0.helpdefault()
    except Exception as err:
        print(err)
    try:
        console_c_l_i_0.helpdefault(module_name='os_floating_ip_associate')
    except Exception as err:
        print(err)
    try:
        console_c_l_i_0.helpdefault(module_name='os_floating_ip_disassociate')
    except Exception as err:
        print(err)
    try:
        console_c_l_i_0.helpdefault(module_name='os_floating_ip_pools_facts')
    except Exception as err:
        print(err)

# Generated at 2022-06-24 17:48:21.333439
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    from ansible.cli import CLI
    import sys

    # Initialize class object
    console_c_l_i_0 = ConsoleCLI()
    # Initialize argument parser
    console_c_l_i_0.parser = CLI.base_parser(
        usage='ansible %prog console [hostfile] --ask-pass',
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        diff_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        desc='Provides an interactive console to Ansible')
    console_c_l_i_0.options = {}
    console_c_l_

# Generated at 2022-06-24 17:48:27.724947
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_1 = ConsoleCLI()
    text = 'foo'
    line = 'cd'
    begidx = 0
    endidx = 3
    test_case_0()
    assert_equal(console_c_l_i_1.complete_cd(text, line, begidx, endidx), [])


# Generated at 2022-06-24 17:48:30.446239
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    print("start test: ConsoleCLI_default_0")
    arg = "ping"
    forceshell = False
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.default(arg, forceshell)


# Generated at 2022-06-24 17:48:35.588279
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Test case 0
    console_c_l_i_0 = ConsoleCLI()
    text_0 = '  '
    line_0 = '  '
    begidx_0 = 0
    endidx_0 = 0
    # ret_value = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)
    # assert ret_value == None


# Generated at 2022-06-24 17:48:40.245577
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI()
    arg = '#'
    forceshell = False
    assert console_c_l_i_0.default(arg, forceshell) == False


# Generated at 2022-06-24 17:48:45.982718
# Unit test for method list_modules of class ConsoleCLI

# Generated at 2022-06-24 17:48:52.493162
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    ansible_console_c_l_i_0 = ConsoleCLI()
    ansible_console_c_l_i_0.run()
    input = 'cd'
    text = 'cd'
    line = 'cd'
    begidx = 0
    endidx = 0
    ansible_console_c_l_i_0.complete_cd(text, line, begidx, endidx)


# Generated at 2022-06-24 17:48:54.687732
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_1 = ConsoleCLI()
    console_c_l_i_1.cmdloop()


# Generated at 2022-06-24 17:49:05.396786
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_1 = ConsoleCLI()
    console_c_l_i_1.selected = [1, 2]
    console_c_l_i_1.hosts = [1, 2]
    console_c_l_i_1.groups = [1, 2]
    console_c_l_i_1.inventory = [1, 2]
    assert(console_c_l_i_1.complete_cd(text=1, line=1, begidx=1, endidx=1) == [1, 2])


# Generated at 2022-06-24 17:49:55.448086
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_1 = ConsoleCLI()
    text = 'text'
    line = 'line'
    begidx = 0
    endidx = 0
    return console_c_l_i_1.completedefault(text, line, begidx, endidx)


# Generated at 2022-06-24 17:49:58.282141
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    print('in test_ConsoleCLI_do_verbosity')
    console_c_l_i_0 = ConsoleCLI()
    arg = '1'
    console_c_l_i_0.do_verbosity(arg)


# Generated at 2022-06-24 17:50:09.475312
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_1 = ConsoleCLI()
    console_c_l_i_1.args = Mock()
    console_c_l_i_1.args.subset = ''
    console_c_l_i_1.args.pattern = ''
    console_c_l_i_1.args.refresh_inventory = False
    console_c_l_i_1.args.list_hosts = False
    console_c_l_i_1.args.list_groups = False

    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.args = Mock()
    console_c_l_i_0.args.subset = ''
    console_c_l_i_0.args.pattern = ''
    console_c_l

# Generated at 2022-06-24 17:50:13.627916
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console_c_l_i_0 = ConsoleCLI()


# Generated at 2022-06-24 17:50:14.715712
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_1 = ConsoleCLI()


# Generated at 2022-06-24 17:50:25.505857
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI()
    assert console_c_l_i_0.default("arg", None) == False
    assert console_c_l_i_0.default("arg", False) == False
    assert console_c_l_i_0.default("arg", True) == False
    assert console_c_l_i_0.default("arg", False) == False
    assert console_c_l_i_0.default("arg", True) == False
    assert console_c_l_i_0.default("arg") == False

if __name__ == "__main__":
    if PY3:
        sys.exit(main())
    else:
        sys.exit(main(sys.argv[1:]))

# Generated at 2022-06-24 17:50:26.967630
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    assert True == True


# Generated at 2022-06-24 17:50:31.182363
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_c_l_i_1 = ConsoleCLI()
    ConsoleCLI.list_modules(console_c_l_i_1)


# Generated at 2022-06-24 17:50:35.081613
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console_c_l_i_0 = ConsoleCLI()
    module_name = 'setup'
    actual = console_c_l_i_0.module_args(module_name)
    expected = ['gather_default_fact',
                'gather_subset',
                'filter']

    assert actual==expected

# Generated at 2022-06-24 17:50:38.488481
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    with pytest.raises(AttributeError):
        console_c_l_i_0.helpdefault('module_name')


# Generated at 2022-06-24 17:51:32.843380
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    pass


# Generated at 2022-06-24 17:51:39.098169
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:51:41.233949
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)


# Generated at 2022-06-24 17:51:46.205127
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    float_0 = 4.59849905563413
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = 'q'
    line_0 = 'name: d s h a = s'
    begidx_0 = 0
    endidx_0 = 1000
    # answer = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)
    # print('answer =', answer)


# Generated at 2022-06-24 17:51:48.381362
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    test_case_0()


if __name__ == '__main__':
    test_ConsoleCLI_run()

# Generated at 2022-06-24 17:51:54.053145
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # Setup test data
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)

    # Invoke method
    console_c_l_i_0_result = console_c_l_i_0.set_prompt()
    assert type(console_c_l_i_0_result) == bool


# Generated at 2022-06-24 17:51:58.779132
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    float_0 = -139.46612834126213
    console_c_l_i_0 = ConsoleCLI(float_0)
    return_value_0 = console_c_l_i_0.do_list(float_0)


# Generated at 2022-06-24 17:52:04.036221
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    module_name = 'mockserver'
    # Create an instance of the class
    float_0 = -169.79
    console_c_l_i_0 = ConsoleCLI(float_0)
    # Invoke the method
    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:52:10.566392
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    float_0 = -0.9490607893673193
    console_c_l_i_0 = ConsoleCLI(float_0)
    string_0 = ''
    string_1 = ' '
    int_0 = 0
    int_1 = 0
    list_0 = console_c_l_i_0.completedefault(string_0, string_1, int_0, int_1)
    assert len(list_0) == 0


# Generated at 2022-06-24 17:52:20.004574
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = -191.37174968290574
    console_c_l_i_0 = ConsoleCLI(float_0)

    module_list_list_0 = []
    module_list_list_0 = console_c_l_i_0.list_modules()
    console_c_l_i_0.modules = module_list_list_0
    print("\nList of modules:\n")
    for module in console_c_l_i_0.modules:
        print("  " + module)
    print("\n")
    console_c_l_i_0.run()
