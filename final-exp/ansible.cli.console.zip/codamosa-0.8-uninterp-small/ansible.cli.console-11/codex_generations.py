

# Generated at 2022-06-24 17:44:36.629972
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()


# Generated at 2022-06-24 17:44:39.125591
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # FIXME:
    # This function is not tested properly.
    # See the specific test case for more details.
    test_case_0()


# Generated at 2022-06-24 17:44:42.277732
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Test case 0
    global console_c_l_i_0
    console_c_l_i_0.do_list("")


# Generated at 2022-06-24 17:44:45.896612
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI()
    print(console_c_l_i_0)
    bool_0 = True
    str_0 = 'not a real module'
    console_c_l_i_0.default(str_0, bool_0)


# Generated at 2022-06-24 17:44:52.583056
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    bool_0 = True
    int_0 = 94296
    console_c_l_i_0 = ConsoleCLI(int_0)
    module_loader_0 = ConsoleCLI.setup_module_loader(console_c_l_i_0)
    bool_1 = module_loader_0.has_plugin('user')
    assert not bool_1



# Generated at 2022-06-24 17:44:53.943443
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()


# Generated at 2022-06-24 17:44:58.384390
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI(4798)
    module_name = ''
    module_args = ''
    forceshell = False
    result = console_c_l_i_0.default(module_name, module_args, forceshell)
    assert(result)



# Generated at 2022-06-24 17:45:07.008859
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():


    # Variable definitions for test_case_0
    arg_0 = 'shell ls -la'
    forceshell_1 = True
    # Expected return value
    return_value_0 = None

    # Calling test_case_0
    test_case_0()

    # Testing ConsoleCLI.default
    return_value = console_c_l_i_0.default(arg_0, forceshell_1)
    # Assertion
    assert return_value == return_value_0


# Generated at 2022-06-24 17:45:14.057845
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    try:
        test_case_0()
    except Exception:
        pass


if __name__ == '__main__':
    print('### Unit test cases ###')
    print('Test case 0: ')
    test_ConsoleCLI_helpdefault()

# Generated at 2022-06-24 17:45:23.414519
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bool_0 = False
    int_0 = 1
    console_c_l_i_0 = ConsoleCLI(int_0)
    text_0 = 'test string'
    line_0 = 'test string'
    begidx_0 = 0
    endidx_0 = 'test string'.count('test string')
    if console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0) == ['test string'] :
        bool_0 = True
    # Output:
    #   0:
    assert(bool_0)



# Generated at 2022-06-24 17:45:59.638598
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Create an object of the class ConsoleCLI
    concli_obj = ConsoleCLI()
    concli_obj.cmdloop()
    if concli_obj is None:
        raise TypeError
if __name__ == '__main__':
    try:
        test_case_0()
        test_ConsoleCLI_cmdloop()
    except:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-24 17:46:01.442236
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    arg0 = None
    arg1 = None
    arg2 = None
    consolecli_inst = ConsoleCLI()
    consolecli_inst.cmdloop(arg0, arg1, arg2)


# Generated at 2022-06-24 17:46:03.884519
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    node = test_case_0()
    obj = ConsoleCLI(node)
    obj.list_modules()


# Generated at 2022-06-24 17:46:05.305559
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    consolecli = ConsoleCLI()
    consolecli.cmdloop()


# Generated at 2022-06-24 17:46:06.359545
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    assert ConsoleCLI().helpdefault() is None


# Generated at 2022-06-24 17:46:08.444708
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    consoleCLI_0 = ConsoleCLI()
    consoleCLI_0.default(arg_0,arg_1)


# Generated at 2022-06-24 17:46:09.951729
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    obj_0 = ConsoleCLI()
    obj_0.do_list('groups')


# Generated at 2022-06-24 17:46:25.897501
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    cli = ConsoleCLI()
    # Test 1
    str_0 = ''
    result = cli.default(str_0, False)
    # assert result ==
    # Test 2
    str_0 = ''
    result = cli.default(str_0, True)
    # assert result ==
    # Test 3
    str_0 = ''
    result = cli.default(str_0, False)
    # assert result ==
    # Test 4
    str_0 = ''
    result = cli.default(str_0, True)
    # assert result ==
    # Test 5
    str_0 = ''
    result = cli.default(str_0, False)
    # assert result ==
    # Test 6
    str_0 = ''

# Generated at 2022-06-24 17:46:28.982469
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg_0 = 'shell'
    forceshell_0 = False
    # class_instance = ConsoleCLI()
    # (return_value, ) = class_instance.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:46:30.385711
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = ''


# Generated at 2022-06-24 17:46:45.732229
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console = ConsoleCLI()
    console.cmdloop()


# Generated at 2022-06-24 17:46:48.536467
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    cli = ConsoleCLI()

    assert cli.helpdefault(str_0) == 'None'


# Generated at 2022-06-24 17:46:50.157741
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    cli = ConsoleCLI(None, None)
    cli.do_list(None)


# Generated at 2022-06-24 17:46:52.656260
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    obj = ConsoleCLI()
    obj.complete_cd('text_0', 'line_1', 'begidx_2', 'endidx_3')
    # No exception raised.
    pass


# Generated at 2022-06-24 17:46:55.153315
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    global ConsoleCLI
    test_ConsoleCLI = ConsoleCLI()
    try:
        test_ConsoleCLI.cmdloop()
    except:
        print("An exception occured")
    else:
        print("Error")


# Generated at 2022-06-24 17:46:59.147705
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    rt = ConsoleCLI()
    text_0 = ''
    line_0 = ''
    begidx_0 = 0
    endidx_0 = 0
    rt.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:47:03.388589
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    global str_0
    str_0 = ''
    try:
        obj_0 = ConsoleCLI()
        obj_0.set_prompt()
        assert(False)
    except:
        assert(True)
    #print(str_0)


# Generated at 2022-06-24 17:47:08.818516
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print('Test: cmdloop')
    # self, loader, inventory, variable_manager, passwords
    console = ConsoleCLI(None, None, None, None, None)
    #test_case_0
    assert console.cmdloop() == True


# Generated at 2022-06-24 17:47:11.410785
# Unit test for method default of class ConsoleCLI

# Generated at 2022-06-24 17:47:12.380442
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = ''


# Generated at 2022-06-24 17:48:19.905307
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    print("--> test_ConsoleCLI_set_prompt")
    str_0 = ''
    consolecli = ConsoleCLI()
    consolecli.set_prompt(str_0)
    print("<-- test_ConsoleCLI_set_prompt")


# Generated at 2022-06-24 17:48:22.128751
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    consoleCLI = ConsoleCLI()
    consoleCLI.helpdefault()


# Generated at 2022-06-24 17:48:23.221352
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    _ConsoleCLI_list_modules()


# Generated at 2022-06-24 17:48:27.469025
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    print(ConsoleCLI)

    print(test_case_0)


if __name__ == "__main__":
    test_ConsoleCLI_helpdefault()

# Generated at 2022-06-24 17:48:39.628176
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
	a = ConsoleCLI()
	# mock out display.display
	a.display.display = lambda x: x
	a.modules = [u'ping', u'raw']
	a.helpdefault(u'ping')
    # no printout
    # assert a.display.display('ping') == 'ping'
	a.helpdefault(u'raw')
    # no printout
    # assert a.display.display('raw') == 'raw'
	a.helpdefault(u'non_existent')
    # no printout
	# assert a.display.display('non_existent') == 'non_existent'


# Generated at 2022-06-24 17:48:50.010609
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    basic_role = {
        "id": 0,
        "name": "basic",
        "use": "basic",
        "options": {
            "hosts": "test_host_0",
            "gather_facts": "no",
            "tasks": [
                {
                    "action": {
                        "module": "shell",
                        "args": "ls"
                    },
                    "name": "test task"
                }
            ]
        },
        "comment": "A basic role"
    }

# Generated at 2022-06-24 17:48:53.789576
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # construct object of the class
    obj = ConsoleCLI(infile=None, stdin=None, stdout=None, cmdclass=None)
    # get parameters
    begidx = 0
    endidx = 0
    # call method
    method_return = obj.completedefault('', '', begidx, endidx)
    # compare with expected
    assert method_return == None


# Generated at 2022-06-24 17:48:56.333185
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    obj_0 = ConsoleCLI()
    obj_0.helpdefault(str_0)


# Generated at 2022-06-24 17:48:59.830247
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    # Create an instance of class ConsoleCLI
    consolecli_obj = ConsoleCLI()
    # No error


# Generated at 2022-06-24 17:49:07.233630
# Unit test for method default of class ConsoleCLI

# Generated at 2022-06-24 17:49:46.943287
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Initialise the runner's object
    new_ans = ansible.runner.Runner(
    pattern='webserver', forks=10, remote_user='username', remote_pass='password',
    private_key_file='/path/to/file', module_name='command', module_args='uptime',
    sudo=False, sudo_user='root', sudo_pass=None, transport='paramiko',
    private_key_file='/path/to/file', only_tags=[], skip_tags=[],
    inventory=None, subset='webserver', setup_cache=None, timeout=10, tree=None)
    new_hash = hashlib.md5(b'10000').hexdigest()
    new_ans._initialize_process(new_hash)

# Generated at 2022-06-24 17:49:50.710037
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    obj = ConsoleCLI()
    test_case_0()


# Generated at 2022-06-24 17:50:05.872333
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    (sshpass, becomepass) = ask_passwords(prompt=None)
    obj = ConsoleCLI(['ansible-console', '-v'])
    obj.cwd = str_0
    obj.remote_user = str_0
    obj.become = bool_0
    obj.become_user = str_0
    obj.become_method = str_0
    obj.check_mode = bool_0
    obj.diff = bool_0
    obj.forks = int_0
    obj.task_timeout = int_0
    obj.modules = obj.list_modules()
    obj.passwords = dict_0
    obj.loader = obj._play_prereqs()
    obj.inventory = obj._play_prereqs()
    obj.variable_manager = obj._play_prereqs

# Generated at 2022-06-24 17:50:14.581763
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_cli = ConsoleCLI(["ansible-console"], "/home/lei/ansible")
    console_cli.default("ping")
    console_cli.default("ping --help")
    console_cli.default("ping -h")
    console_cli.default("ping", True)
    console_cli.default("ping", False)
    console_cli.default("")
    console_cli.default("#")
    console_cli.default("# this is test")
    console_cli.default("# this is test\n")
    console_cli.default("shell")
    console_cli.default("shell")
    console_cli.cwd = ''
    console_cli.default("test")
    console_cli.variable_manager = "test"
    console_cli.default("shell")

# Generated at 2022-06-24 17:50:16.985112
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # args
    arg = ''
    # ret
    ret = None
    # function
    ret = ConsoleCLI.do_list(arg)
    # compare
    assert(ret == None)



# Generated at 2022-06-24 17:50:24.500422
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console = ConsoleCLI()
    console.cmdloop()
    console.complete_cd(str_0, str_0, 0, 0)
    console.completedefault(str_0, str_0, 0, 0)
    str_0 = str_0
    console.module_args(str_0)
    try:
        console.run()
    except Exception:
        assert False

# Generated at 2022-06-24 17:50:26.334885
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    myobj = ConsoleCLI()
    myobj.do_cd('arg')



# Generated at 2022-06-24 17:50:29.253301
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    # Initialize object
    obj = ConsoleCLI()

    # Test Body
    assert(False)


# Generated at 2022-06-24 17:50:36.461241
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console = ConsoleCLI()
    try:
        console.cmdloop()
    except KeyboardInterrupt:
        sys.stdout.write('\nAnsible-console was exited.\n')
        cli.logger.error('Ansible-console was exited.', exc_info=True)
        return False
    except Exception as e:
        display.error(to_text(e))
        cli.logger.error("Exception: %s" % to_text(e), exc_info=True)
        return False
    return True


# Generated at 2022-06-24 17:50:37.890716
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    obj_0 = ConsoleCLI(str_0)
    obj_0.cmdloop()


# Generated at 2022-06-24 17:53:05.126860
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Try to call the method without required parameters
    # Return the name of the docstring's first parameter.
    # Raise an exception if the method has no parameters.
    try:
        arg0 = ConsoleCLI()
        return_value = arg0.cmdloop()
        assert return_value == str_0
    except Exception as e:
        raise Exception("When using the cmdloop() method of class 'ConsoleCLI', an exception is raised: " + str(e))


if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_cmdloop()

# Generated at 2022-06-24 17:53:07.483728
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_0 = ConsoleCLI()
    console_0.cmdloop()


# Generated at 2022-06-24 17:53:12.832615
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    print("\n")
    case_id = int(sys.argv[1])
    test_case = Test_case_0()
    if case_id == 1:
        test_case.test_ConsoleCLI_do_timeout_1()
    else:
        print("test_case_" + str(case_id) + " does not exist")


# Generated at 2022-06-24 17:53:14.637699
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    med = ConsoleCLI()
    med.do_list('')


# Generated at 2022-06-24 17:53:22.352985
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Test case with wrong type of value for argument str_0
    # Argument:
    # Desc:
    # Test code:
    t = ConsoleCLI()
    t.cmdloop(str_0=dict())
    # Test case with wrong type of value for argument prompt_0
    # Argument:
    # Desc:
    # Test code:
    t = ConsoleCLI()
    t.cmdloop(prompt_0=dict())


# Generated at 2022-06-24 17:53:22.806152
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = ''

# Generated at 2022-06-24 17:53:25.330872
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print('test_ConsoleCLI_cmdloop')
    test_case = ConsoleCLI()
    result = test_case.cmdloop()
    print('test_ConsoleCLI_cmdloop result:', result)


# Generated at 2022-06-24 17:53:29.412777
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    consoleCLI_0 = ConsoleCLI()
    consoleCLI_0.do_timeout(str_0)
    # assert <condition>, <error message>
    assert True, "Test case failed"

if __name__ == "__main__":
    pytest.main()

# Generated at 2022-06-24 17:53:36.496657
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    text_0 = ""
    line_0 = ""
    begidx_0 = 0
    endidx_0 = 0
    ConsoleCLI_obj_0 = ConsoleCLI()
    ConsoleCLI_completedefault_ret_0 = ConsoleCLI_obj_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:53:38.015392
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    arg_0 = ConsoleCLI()
    arg_0.cmdloop()
