

# Generated at 2022-06-24 17:44:29.171845
# Unit test for method helpdefault of class ConsoleCLI

# Generated at 2022-06-24 17:44:34.469672
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    print('Testing run')
    str_1 = "help('modules'):"
    console_c_l_i_0 = ConsoleCLI(str_1)
    console_c_l_i_0.run()
    print('Done')

# Unit tests for class ConsoleCLI

# Generated at 2022-06-24 17:44:39.584096
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    print('Testing module_args of ConsoleCLI')
    arg = arg = ConsoleCLI()
    assert arg.module_args('shell') ==  ['chdir', 'creates', 'executable', 'removes', 'stdin', 'warn', '_raw_params', '_uses_shell', '_uses_interpreter', 'argv', 'chdir', 'creates', 'executable', 'free_form', 'removes', 'stdin', 'warn', '_raw_params', '_uses_shell', '_uses_interpreter', 'argv']
    assert arg.module_args('debug') ==  ['msg', 'var', 'verbosity', 'msg', 'var', 'verbosity']
    assert arg.module_args('fail') ==  ['msg', 'msg']

# Generated at 2022-06-24 17:44:50.166450
# Unit test for method do_list of class ConsoleCLI

# Generated at 2022-06-24 17:44:57.089360
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    str_2 = '\n    Return a list of lists containing the IP addresses of all interfaces,\n    excluding localhost, with all aliases removed and only IPv4 addresses,\n    if no interface is specified.\n    '
    # Parameter: str
    console_c_l_i_0 = ConsoleCLI(str_2)
    str_0 = 'a'
    # Call method module_args of console_c_l_i_0 with parameter: str
    console_c_l_i_0.module_args(str_0)


# Generated at 2022-06-24 17:45:09.082608
# Unit test for method list_modules of class ConsoleCLI

# Generated at 2022-06-24 17:45:10.541802
# Unit test for method do_forks of class ConsoleCLI
def test_ConsoleCLI_do_forks():
    test_case_0()

# Generated at 2022-06-24 17:45:23.880457
# Unit test for method run of class ConsoleCLI

# Generated at 2022-06-24 17:45:31.007338
# Unit test for method do_list of class ConsoleCLI

# Generated at 2022-06-24 17:45:33.386622
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    console_c_l_i_0 = ConsoleCLI.ConsoleCLI()


# Generated at 2022-06-24 17:46:34.695160
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console_c_l_i_0 = ConsoleCLI()

    print("Run unit test for ConsoleCLI method module_args")


# Generated at 2022-06-24 17:46:39.504553
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console_c_l_i_1 = ConsoleCLI()
    assert isinstance(console_c_l_i_1.module_args("user_module"), list)


# Generated at 2022-06-24 17:46:43.807613
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0=ConsoleCLI()
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:46:49.085613
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Instantiate ConsoleCLI instance
    console_c_l_i = ConsoleCLI()
    # Function returned by factory function console_c_l_i.helpdefault
    helpdefault = console_c_l_i.helpdefault
    # Expected module_name
    module_name = 'ping'
    # Calling function helpdefault
    assert helpdefault(module_name) is None


# Generated at 2022-06-24 17:46:52.897028
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    line = raw_input('Enter a line of text: ')
    begidx = input('Enter the beginning index: ')
    endidx = input('Enter the ending index: ')



# Generated at 2022-06-24 17:46:55.088934
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    print("Testing cmdloop of ConsoleCLI:")
    console_c_l_i_1 = ConsoleCLI()
    console_c_l_i_1.cmdloop()


# Generated at 2022-06-24 17:47:01.222275
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    """
    unit test for method default
    """
    console_c_l_i_1 = ConsoleCLI()
    console_c_l_i_1.unexpanded_variables = dict()
    console_c_l_i_1.inventory = Mock(return_value='')
    console_c_l_i_1.variable_manager = Mock(return_value='')
    console_c_l_i_1.cwd = ''
    console_c_l_i_1.task_timeout = Mock(return_value='')
    console_c_l_i_1.become = False
    console_c_l_i_1.become_user = ''
    console_c_l_i_1.become_method = ''

# Generated at 2022-06-24 17:47:04.328609
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.completedefault('text', 'line', 'begidx', 'endidx')


# Generated at 2022-06-24 17:47:12.107100
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Test against a class that inherits from ConsoleCLI
    console_c_l_i_0 = ConsoleCLI()
    # Call static method of class ConsoleCLI
    ConsoleCLI.helpdefault(console_c_l_i_0, 'ping')
    # Call instance method of class ConsoleCLI
    console_c_l_i_0.helpdefault('ping')


# Generated at 2022-06-24 17:47:15.027432
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    print('test_ConsoleCLI_complete_cd')
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.complete_cd()


# Generated at 2022-06-24 17:50:30.212339
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.default("shell","")


# Generated at 2022-06-24 17:50:38.761665
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    #
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.inventory = inventory.Inventory(loader=None, variable_manager=None, host_list=None)
    #
    # 'module_loader_0' is a module_loader.ModuleLoader
    module_loader_0 = module_loader.ModuleLoader(None)
    assert hasattr(module_loader_0, 'module_loader')
    assert isinstance(module_loader_0, object)
    #
    assert hasattr(module_loader_0.module_loader, '_module_cache')
    assert isinstance(module_loader_0.module_loader._module_cache, dict)
    #
    list_modules_ret_0 = console_c_l_i_0.list_modules()
    #

# Generated at 2022-06-24 17:50:41.469257
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    module_name0 = None
    oc0 = None
    a0 = None
    _0 = None
    console_c_l_i_0 = ConsoleCLI()
    assert console_c_l_i_0.module_args(module_name0) == oc0


# Generated at 2022-06-24 17:50:44.905569
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console_c_l_i_0 = ConsoleCLI()
    arg = 'webservers:dbservers:&staging:!phoenix'
    console_c_l_i_0.do_cd(arg)


# Generated at 2022-06-24 17:50:52.385477
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    console_c_l_i_0 = ConsoleCLI()
    text = '--list-hosts'
    line = 'exit'
    begidx = 0
    endidx = 0
    assert console_c_l_i_0.complete_cd(text, line, begidx, endidx) == '--list-hosts'


# Generated at 2022-06-24 17:50:57.433282
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI()
    console_c_l_i_0.active = 'test'
    assert console_c_l_i_0.completedefault('test', '', 0, 0) is None


# Generated at 2022-06-24 17:50:58.566399
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_1 = ConsoleCLI()
    test_case_0()


# Generated at 2022-06-24 17:51:00.386423
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    module_name = ''
    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:51:04.113699
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i = ConsoleCLI()
    console_c_l_i.cmdloop()


# Generated at 2022-06-24 17:51:08.422692
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    module_name = "user"
    console_c_l_i_0.helpdefault(module_name)
