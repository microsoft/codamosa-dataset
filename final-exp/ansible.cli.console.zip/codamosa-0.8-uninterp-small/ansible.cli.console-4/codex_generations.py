

# Generated at 2022-06-24 17:44:49.690401
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Run test.
    try:
        test_case_0()
    except:
        raise AssertionError("Test case failed")
    

# Generated at 2022-06-24 17:44:52.097167
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    container = ConsoleCLI([])
    cmdloop = getattr(container, 'cmdloop')
    method_output = cmdloop()



# Generated at 2022-06-24 17:44:54.481031
# Unit test for method do_remote_user of class ConsoleCLI
def test_ConsoleCLI_do_remote_user():
    console_c_l_i_0 = ConsoleCLI(True)
    console_c_l_i_0.do_remote_user("remote_user")


# Generated at 2022-06-24 17:44:59.831709
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI(True)
    console_c_l_i_0.run()
    var_0 = console_c_l_i_0.modules
    var_1 = var_0[2]
    console_c_l_i_0.helpdefault(var_1)


# Generated at 2022-06-24 17:45:03.644835
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.selected = set()
    var_0 = console_c_l_i_0.do_list('help')


# Generated at 2022-06-24 17:45:07.828755
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    str_0 = 'arg'
    bool_true = True
    console_c_l_i_0.default(str_0, bool_true)


# Generated at 2022-06-24 17:45:09.457407
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    console_c_l_i_0 = ConsoleCLI(True)
    module_name = ''
    console_c_l_i_0.module_args(module_name)


# Generated at 2022-06-24 17:45:14.265716
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.default('')


# Generated at 2022-06-24 17:45:17.650633
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()

# Generated at 2022-06-24 17:45:21.311868
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    module_name = 'command'
    bool_0 = True
    console_c_l_i_0 = ConsoleCLI(bool_0)
    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:45:51.555877
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Unit test for method cmdloop of class ConsoleCLI
    ConsoleCLI.cmdloop()

    # Cannot execute cmdloop because 'do_cd' is not defined.


# Generated at 2022-06-24 17:46:02.186391
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    module_name = 'test_module'
    console_c_l_i_0 = ConsoleCLI('')

# Generated at 2022-06-24 17:46:04.278839
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    module_name = str()
    print(ConsoleCLI.helpdefault(module_name))


# Generated at 2022-06-24 17:46:09.515602
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_1 = ConsoleCLI(b'\xbb\xa2\xb5\x19\x0f\xce\xfd\xea\x08\xbb\xe7\xbd\x05\xc0')
    module_name_0 = ''
    console_c_l_i_1.helpdefault(module_name_0)


# Generated at 2022-06-24 17:46:16.070879
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI("gz2Xt$!")
    with mock.patch("readline.get_line_buffer") as get_line_buffer:
        get_line_buffer.return_value = "do_echo.py test"
        console_c_l_i_0.completedefault("test", "String echo test", 4, 4)

if __name__ == '__main__':
    console_c_l_i = ConsoleCLI()
    console_c_l_i.run()

# Generated at 2022-06-24 17:46:21.939509
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:46:27.551736
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    if console_c_l_i_0:
        print("ConsoleCLI inited")
        console_c_l_i_0.do_cd("")


# Generated at 2022-06-24 17:46:36.325173
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = to_native(b'\x9d\xc4\xc0\xbf\xbb\xda\x1d\x1c\xca\x9f\xb4\xfa\xdb\xcf\x8c')
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    text_0 = to_native(b'\x11\xa6\x88\xd0\x1e\x9a\x80Z\x1a\x8c\xdd')
    line_0 = to_native(b' \xa1\x88\xd0\x1e\x9a\x80Z\x1a\x8c\xdd')

# Generated at 2022-06-24 17:46:43.832529
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'\x1d\x9b\x82\xa4\xb8\x91\xe3\x1e\x1a\x8d'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.do_cd('')
    console_c_l_i_0.do_exit('')


# Generated at 2022-06-24 17:46:51.694009
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'\xc8W\xac\xb0\x03\x0c\x14\x87\x0c\x88\xa9\xc6\xd3\x80\xe1\xa7\x8d\x15\xc8\x92\x01\x99\x86\x1f\x86\x9f\x8d\x14\xcc\xde\x0b\x8d'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:47:52.314741
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    c = ConsoleCLI()
    c.cmdloop()


# Generated at 2022-06-24 17:47:55.701972
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    print("Testing method helpdefault...")
    tmp_ConsoleCLI = ConsoleCLI()
    tmp_ConsoleCLI.helpdefault(var_0 = str())


# Generated at 2022-06-24 17:48:03.225649
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    with patch.object(ConsoleCLI, 'get_host_list', return_value=list()):
        with patch.object(ConsoleCLI, 'inventory', spec=Inventory) as mock_Inventory:
            mock_Inventory.list_groups.return_value = list()
            mock_Inventory.list_hosts.return_value = list()

            mock_ConsoleCLI = ConsoleCLI()
            assert mock_ConsoleCLI.set_prompt() == 'None'

# Generated at 2022-06-24 17:48:10.562965
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    # ---------------------------------
    # Test cases
    # ---------------------------------
    #
    class test_case_0():
        test_module = [
            {
                'path': 'module1.py',
                'module': 'module1',
                'output': 'module1'
            },
            {
                'path': 'directory/module2.py',
                'module': 'module2',
                'output': 'module2'
            },
            {
                'path': '__init__.py',
                'module': '',
                'output': None
            }
        ]

        def test_generator():
            for module in test_module:
                yield module

    #
    # ---------------------------------
    # Initialization
    # ---------------------------------
    #
    generator = test_case_0.test_generator()
    module

# Generated at 2022-06-24 17:48:11.602229
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    var_0 = str()


# Generated at 2022-06-24 17:48:19.312287
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    var_0 = ConsoleCLI()
    var_1 = str()
    var_2 = str()
    var_3 = int()
    var_4 = int()
    # var_0.completedefault(arg_0, arg_1, arg_2, arg_3)
    pass


# Generated at 2022-06-24 17:48:22.055762
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():  
    # form a instance of class ConsoleCLI
    var_1 = ConsoleCLI()
    # load the test data
    var_2 = str()
    
    # call the function under test
    var_1.helpdefault(var_2)


# Generated at 2022-06-24 17:48:28.601992
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Init
    shell1 = ConsoleCLI()
    shell2 = ConsoleCLI()
    shell= ConsoleCLI()
    # Test
    shell1.helpdefault("shell")
    shell2.helpdefault("setup")
    shell.helpdefault("shell")  # difference is here
    shell2.helpdefault("setup")
    shell1.helpdefault("shell")


# Generated at 2022-06-24 17:48:33.221208
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    consolecli = ConsoleCLI()
    module_name = str()
    consolecli.helpdefault(module_name)


# Generated at 2022-06-24 17:48:37.021155
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    var_0 = ConsoleCLI()
    arg = str()
    var_0.do_cd(arg)


# Generated at 2022-06-24 17:49:17.224996
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    print(fore.BLUE + "\n***************************************************************" + style.RESET)
    print(fore.BLUE + "Testing method list_modules of class ConsoleCLI" + style.RESET)
    print(fore.BLUE + "***************************************************************" + style.RESET)

    console_c_l_i_1 = ConsoleCLI("07ebe2f0-26b8-11e6-a10e-00163e4c8d4e")
    for i in [0,1,2,3]:
        console_c_l_i_1.list_modules()

    ConsoleCLI("28aeea10-26b8-11e6-a10e-00163e4c8d4e")



# Generated at 2022-06-24 17:49:25.523199
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    bytes_0 = b'\xae\xb0\x1b\x05\xa6\xd4\xa7\xad\xea'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    str_0 = '\x9e\x9d\x9d\x9f\x9cP'
    str_1 = 'rm.'
    str_2 = '\x9e\x9d\x9d\x9f\x9cP'
    str_3 = 'rm.'
    console_c_l_i_0.cwd = 'all'
    str_4 = '\x9e\x9d\x9d\x9f\x9cP'
    str_5 = 'rm.'
    console_c_l_i_0

# Generated at 2022-06-24 17:49:29.270211
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    console_c_l_i_0 = ConsoleCLI()
    for _ in range(1000):
        arg = randint(1, 10)
    console_c_l_i_0.do_verbosity(arg)


# Generated at 2022-06-24 17:49:31.596426
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    h = ConsoleCLI()
    assert h.completedefault() == None


# Generated at 2022-06-24 17:49:35.580341
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:49:36.551179
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    test_case_0()


# Generated at 2022-06-24 17:49:41.006749
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    module_name_0 = b'\x7f\x04\r\x068\x1f\x80\xc2\xae'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.helpdefault(module_name_0)


# Generated at 2022-06-24 17:49:50.332991
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Available attributes and methods of the class ConsoleCLI
    cli_console_c_l_i_0 = ConsoleCLI(b'') # instance ConsoleCLI
    cli_console_c_l_i_0.do_activate_session = mock.MagicMock()
    cli_console_c_l_i_0.completedefault = mock.MagicMock()
    cli_console_c_l_i_0.do_complete = mock.MagicMock()
    cli_console_c_l_i_0.help_complete = mock.MagicMock()
    cli_console_c_l_i_0.do_reset_output_field = mock.MagicMock()
    cli_console_c_l_i_0.help_reset_output_field = mock.MagicMock

# Generated at 2022-06-24 17:49:57.303353
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():

    # Use a try/except block to catch the NameError raised from accessing an undefined variable
    try:
        
        # Instantiate an object of type ConsoleCLI
        console_c_l_i_0 = ConsoleCLI()

        # Call set_prompt method of the object
        console_c_l_i_0.set_prompt()

    except NameError as err:
        raise RuntimeError('Variable %s is not defined' % err)
    else:
        pass


# Generated at 2022-06-24 17:50:05.610416
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    for i in range(10):
        bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
        console_c_l_i_0 = ConsoleCLI(bytes_0)
        text_0 = String()
        line_0 = String()
        begidx_0 = Int()
        endidx_0 = Int()
        var_0 = console_c_l_i_0.complete_cd(text_0, line_0, begidx_0, endidx_0)



# Generated at 2022-06-24 17:50:58.713771
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    min_arg_cnt = 1
    max_arg_cnt = 1
    console_c_l_i_0 = ConsoleCLI(b'\x04\xee\xff\xfe\xc0\x15')
    module_name = 'module_name'
    module_name = ConsoleCLI.module_args(console_c_l_i_0, module_name)



# Generated at 2022-06-24 17:51:02.847203
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    # Verify that the method helpdefault exists
    assert callable(getattr(console_c_l_i_0, "helpdefault"))


# Generated at 2022-06-24 17:51:13.645932
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg = 'some_string'
    forceshell = True
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    display.verbosity = 0
    display.verbose = 0
    display.display_ok_hosts = 0
    display.display_failed_hosts = 0
    display.display_skipped_hosts = 0
    display.display_ok_hosts = 0
    display.display_failed_hosts = 0
    display.display_skipped_hosts = 0
    display.display_ok_hosts = 0
    display.display_failed_hosts = 0
    display.display_skipped_hosts = 0
    display.display_ok

# Generated at 2022-06-24 17:51:24.800725
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    str_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 17:51:26.951892
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(b'\xd6\x8f\x1c\xcc\xa4)')

# Generated at 2022-06-24 17:51:32.946769
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # Call method with arguments
    arg_0 = 'module_name'
    console_c_l_i_helpdefault(arg_0)


# Generated at 2022-06-24 17:51:40.049461
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    # pylint: disable-msg=protected-access
    null = None
    console_c_l_i_

# Generated at 2022-06-24 17:51:47.129570
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    text_0 = b'\xf4\xc1\x06\x1b\xac\xe2\x0e\x0c\xce\xd6U\xc6'
    line_0 = b'\x1f\xac\xee:E\x02\xf6\xde\xd3\xf7\xab\xaa4\xe4#\x15\xbd\xc5'
    begidx_0 = 0x1c
    endidx_0 = 0x26

# Generated at 2022-06-24 17:51:52.476905
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    module_name = str()
    test_case_0(console_c_l_i_0, module_name)

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 17:52:00.651282
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    
    # Arrange
    text = "modules"
    line = "modules"
    begidx = 0
    endidx = 0
    bytes_1 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_1 = ConsoleCLI(bytes_1)

    # Act
    print(console_c_l_i_1.completedefault(text,line,begidx,endidx))


# Generated at 2022-06-24 17:53:42.448809
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    bytes_1 = b'x\x16\xf9\x81o\x13\xc1\x06'
    console_c_l_i_1 = ConsoleCLI(bytes_1)
    argument_1 = 'module_name'

    # Calling method module_args of class ConsoleCLI
    try:
        method_result_return_value_1 = console_c_l_i_1.module_args(argument_1)
    except Exception as e:
        print('Exception message: ', e)

if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_module_args()

# Generated at 2022-06-24 17:53:51.120085
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    bytes_0 = b'\xc6\xe2e7\x1e\x88\x01\xe3x'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.run()
