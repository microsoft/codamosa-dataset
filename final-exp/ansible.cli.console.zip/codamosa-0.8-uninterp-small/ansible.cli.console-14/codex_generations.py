

# Generated at 2022-06-24 17:45:05.072298
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    bytes_1 = b'\x1c\x00\xed\x8d\xf2\xde\x98\xa0\x8cz\xda\x1c\x00\xed\x8d\xf2\xde\x98\xa0\x8cz\xda'
    console_c_l_i_0.do_cd(bytes_1)



# Generated at 2022-06-24 17:45:18.940708
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    bytes_0 = b'&\xbe\xfe\x1c\x80\x17\x81\x0b\x85\x10\x95\x1d\xcf\x8b\x89\xf1\x88\x8b\xe0\xef\xde\xa8\xe8\xf0\x80\xae\x8d\xab\x8b\x1e\x9f\xa0\xb6\xdf'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.inventory = console_c_l_i_0.hosts = console_c_l_i_0.groups = console_c_l_i_0._tqm = console_c_l_i_0

# Generated at 2022-06-24 17:45:27.496400
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'^\x8f\x99r\x1a\x1f\xa3\xad\x06\x0f'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:45:38.197610
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Argument to ConsoleCLI() can be any string
    bytes_1 = b'\xdd\xd8b\xf0\x7f\x17\xb9\x88\xaf\xae\x9c\x10\x0b'
    console_c_l_i_1 = ConsoleCLI(bytes_1)
    assert console_c_l_i_1.do_list("") is None
    assert console_c_l_i_1.do_list("") is None
    assert console_c_l_i_1.do_list("") is None


if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_do_list()

# Generated at 2022-06-24 17:45:44.879715
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI(False)
    console_c_l_i_0.modules = ['module_page', 'module_page', 'module_page']
    text_0 = 'module_page'
    line_0 = 'module_page module_page module_page'
    begidx_0 = 'module_page'.__len__()
    endidx_0 = 'module_page'.__len__()
    console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:45:47.720549
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    assert ConsoleCLI.completedefault("completedefault") != None


# Generated at 2022-06-24 17:45:55.420453
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'(\x1c\x14\x8c\xd6\xb3\x0f^\xba\xdd{\x9f\xf7\xcd\x87\xcd'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    str_0 = 'shell'
    console_c_l_i_0.helpdefault(str_0)


# Generated at 2022-06-24 17:46:00.503875
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    bytes_0 = b'\xed\xca\xcf\x08\xe2\x02D\x1a'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    str_0 = console_c_l_i_0.get_opt('subset')
    str_1 = console_c_l_i_0.get_opt('subset')
    console_c_l_i_0.do_list(str_1)


# Generated at 2022-06-24 17:46:10.198752
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    bytes_0 = b'\xb0\xbc\x8a\xa5\xbb\x19\x03\x8d\xbd\x1b\xa1\xf6'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:46:18.328515
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.do_cd('*')


# Generated at 2022-06-24 17:46:53.730012
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    obj_ConsoleCLI = ConsoleCLI()
    text_0='text_0'
    line_0='line_0'
    begidx_0='begidx_0'
    endidx_0='endidx_0'
    test_case_0_expected_result=obj_ConsoleCLI.complete_cd(text_0,line_0,begidx_0,endidx_0)
    print("\n")
    print("------------------------------------------------------------------------------------------------")
    print("Calling the method complete_cd of class ConsoleCLI with arguments text_0,line_0,begidx_0,endidx_0 ")
    print("Expected result: ", test_case_0_expected_result)
    print("-------------------------------------------------------------------------------------------------")
    print("\n")


# Generated at 2022-06-24 17:46:55.633989
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():

    print("testing method ConsoleCLI.helpdefault of class ConsoleCLI")

    ansible.cli.console.test_case_0()

test_ConsoleCLI_helpdefault()

# Generated at 2022-06-24 17:46:56.410203
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = 'helpdefault'


# Generated at 2022-06-24 17:46:57.690106
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    print(" ---- test_ConsoleCLI_complete_cd() ---- ")
    str_0 = 'complete_cd'


# Generated at 2022-06-24 17:47:00.923608
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # A test case.
    print("\n==============================================================")
    print("Unit test for method helpdefault of class ConsoleCLI")
    print("==============================================================")
    test_ConsoleCLI = ConsoleCLI()
    # test_ConsoleCLI.helpdefault("")
    test_ConsoleCLI.helpdefault("setup")
    test_ConsoleCLI.helpdefault("show")


# Generated at 2022-06-24 17:47:10.356798
# Unit test for method helpdefault of class ConsoleCLI

# Generated at 2022-06-24 17:47:19.068761
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():

    # Get an instance of the class
    obj_ConsoleCLI = ConsoleCLI()

    # check if the method exists
    assert 'complete_cd' in vars(ConsoleCLI), 'Expected method complete_cd to exist on ConsoleCLI.'

    # Call the method
    result_complete_cd = obj_ConsoleCLI.complete_cd(str_0)

    # Check if the result is empty
    assert not result_complete_cd, 'Expected empty list, but got, %s' % result_complete_cd


# Generated at 2022-06-24 17:47:24.386679
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cli = ConsoleCLI()
    assert console_cli.list_modules() is not None


# Generated at 2022-06-24 17:47:26.764803
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    arg_0 = ConsoleCLI()
    arg_0.cmdloop()


# Generated at 2022-06-24 17:47:30.206689
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    pass



# Generated at 2022-06-24 17:48:51.816006
# Unit test for method completedefault of class ConsoleCLI

# Generated at 2022-06-24 17:48:58.666055
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.run()
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:49:07.451341
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'T\x80\xb0W\x8c\x9bs\x88\xd6\xbe\xb0\x96\x91\xa1\xbf\x8a'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()



# Generated at 2022-06-24 17:49:22.502235
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    byte_0 = b'sX\x0b\x80\x00e\x1b'
    bytes_0 = b'\xd5\x04\x9d\x8f\xafL\xdf\x82\x0c\x83\x08\x19\xf9\x92L\x97\xce\xed\x95\xaa\xcd\xf3p\xb0\x9fg\x83\x94]\xbf\xd4\x12\xa8\xec\xfd\xca\xd9\xee\x8b\xad\x95\xa0\xb6\x8a\x14\x1d'
    console_c_l_i_0 = ConsoleCLI(bytes_0)

# Generated at 2022-06-24 17:49:28.520735
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:49:38.380904
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    byte_0 = b'\x00'
    byte_1 = b'\x01'
    #assert(console_c_l_i_0.default(byte_0,byte_0) == None)
    #assert(console_c_l_i_0.default(byte_1,byte_0) == None)
    #assert(console_c_l_i_0.default(byte_0,byte_1) == None)
    #assert(console_c_l_i_0.default(byte_1,byte_1) == None)

if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_default()

# Generated at 2022-06-24 17:49:44.946428
# Unit test for method completedefault of class ConsoleCLI

# Generated at 2022-06-24 17:49:58.219042
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    ansible_console_args_0 = {'yaml': 'yaml', 'json': 'json', 'graph': 'graph', 'tree': 'tree'}
    console_c_l_i_0.run(ansible_console_args_0)
    module_name_0 = 'shell'
    # Test case 0
    test_case_0(module_name_0)

    # Test case 1
    module_name_1 = 'package'
    test_case_0(module_name_1)

    # Test case 2
    module_name_2 = 'user'

# Generated at 2022-06-24 17:50:09.385527
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    print('Testing Test_ConsoleCLI_do_list()')

# Generated at 2022-06-24 17:50:16.836058
# Unit test for method default of class ConsoleCLI

# Generated at 2022-06-24 17:51:57.128975
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # The default value of buffer_size is 0, so do not test with 0
    # buffer_size = 0
    buffer_size = 1
    # bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    # bytes_1 = b'(^\xdf\xd7\xaf\xdc\xd7\x1b\x1d'
    # bytes_2 = b'5\x88\x04\x8f\x91;\x1c\x08\x1d'
    # bytes_3 = b'\x10\xb3\x1a\x12\xbc\xef\x13\x87'
    # bytes_4 = b'8W\x05\xbd\xbd\x7f\xab\

# Generated at 2022-06-24 17:51:58.518631
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    arg = 'groups'
    cmd = ConsoleCLI()
    result = cmd.do_list(arg)


# Generated at 2022-06-24 17:52:00.536898
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    bytes_0 = b'J\x9a\xb2\xfc'
    __console_c_l_i = ConsoleCLI(bytes_0)
    __console_c_l_i.list_modules()


# Generated at 2022-06-24 17:52:11.909695
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    bytes_0 = b'\x8d\x0e\xe5\xa6\x960\x8e\xf3\xfb\x01\xd9\x8d\x0e\xe5\xa6\x960\x8e\xf3\xfb\x01\xd9'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.find_modules_in_path = MagicMock(name='find_modules_in_path')

# Generated at 2022-06-24 17:52:22.083255
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    arg_0 = """x=      rf
rjrzcsp
d sds
kds
"""
    forceshell_0 = '\x06\x1a\x04\xc9\x0e\xea\xde\x11\xb0\x04\x1f\x82\xa3\x9c\xeb\x8c'
    console_c_l_i_0.default(arg_0, forceshell_0)

if __name__ == "__main__":
    test_case_0()
    test_ConsoleCLI_default()

# Generated at 2022-06-24 17:52:28.860052
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'k%I\x86kR\xa2]\x95\x11Z\xd4'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    # Call the method
    console_c_l_i_0.cmdloop()
    # Call the method
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:52:40.250330
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    bytes_0 = b':0?0\x80\x8f\x9f\x1e'
    console_c_l_i_0 = ConsoleCLI(bytes_0)


# Generated at 2022-06-24 17:52:43.692100
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # unit test for method do_list
    args_0 = b''
    console_c_l_i_0 = ConsoleCLI(args_0)
    console_c_l_i_0.do_list('')


# Generated at 2022-06-24 17:52:47.853726
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    bytes_0 = b'\xa3\x11\x1b\x16m\x1b\xe1\x9a\x9e'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:52:55.670586
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    bytes_0 = b'\xec\x81\xcd\x9b\x9b\xbf\x93\xad'
    console_c_l_i_0 = ConsoleCLI(bytes_0)
    # call to method run of class ConsoleCLI
    console_c_l_i_0.run()