

# Generated at 2022-06-24 17:44:50.777116
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    var_0 = None
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.init_parser = var_0
    test_case_0()


# Generated at 2022-06-24 17:44:55.010514
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    dict_0 = {}
    module_name_0 = "XFzZB"
    console_c_l_i_0 = ConsoleCLI(dict_0)
    # No exception thrown by console_c_l_i_0.helpdefault(module_name_0)


# Test function for method helpdefault of class ConsoleCLI

# Generated at 2022-06-24 17:45:07.580445
# Unit test for method helpdefault of class ConsoleCLI

# Generated at 2022-06-24 17:45:09.814966
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.default("arg1", 1)


# Generated at 2022-06-24 17:45:18.688586
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Initialize a class object of ConsoleCLI
    console_c_l_i_0 = ConsoleCLI({})

    # Initialize arguments for the method
    text_0 = string('')
    line_0 = string('')
    begidx_0 = integer(1)
    endidx_0 = integer(1)
    # Call method
    obj_0 = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:45:21.558433
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:45:31.029637
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Create object ConsoleCLI
    console_c_l_i_0 = ConsoleCLI()

    # From parameters 'text' and 'line' get arguments for function call
    text_0 = 'feo'
    line_0 = 'bef'
    begidx_0 = 0
    endidx_0 = 1
    # Call method completedefault from object console_c_l_i_0
    console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:45:41.317709
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    module_name = 'add_host'
    in_path = module_loader.find_plugin(module_name)
    oc, a, _, _ = plugin_docs.get_docstring(in_path, fragment_loader)
    if oc:
        display.display(oc['short_description'])
        display.display('Parameters:')
        for opt in oc['options'].keys():
            display.display('  ' + stringc(opt, console_c_l_i_0.NORMAL_PROMPT) + ' ' + oc['options'][opt]['description'][0])
    else:
        display.error('No documentation found for %s.' % module_name)

# Unit

# Generated at 2022-06-24 17:45:44.189721
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    text_0 = ''
    line_0 = ''
    begidx_0 = 0
    endidx_0 = 0
    var_0 = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:45:46.336088
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # TODO: replace with real unit test for ConsoleCLI.cmdloop
    assert True


# Generated at 2022-06-24 17:46:09.875455
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.do_module_name = None
    console_c_l_i_0.init_parser()
    console_c_l_i_0.helpdefault('module_name')

if __name__ == '__main__':
    console_c_l_i = ConsoleCLI()
    #console_c_l_i.run()
    console_c_l_i.init_parser()

# Generated at 2022-06-24 17:46:25.897174
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():

    # Init
    (sshpass, becomepass) = console_c_l_i_0.ask_passwords()
    console_c_l_i_0.passwords = {'conn_pass': sshpass, 'become_pass': becomepass}

    console_c_l_i_0.loader, console_c_l_i_0.inventory, console_c_l_i_0.variable_manager = console_c_l_i_0._play_prereqs()

    hosts_0 = console_c_l_i_0.get_host_list(console_c_l_i_0.inventory, context.CLIARGS['subset'], console_c_l_i_0.pattern)

    console_c_l_i_0.groups = console_c_l_i_0.inventory

# Generated at 2022-06-24 17:46:30.797833
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.cwd = "all"
    console_c_l_i_0.set_prompt = MagicMock()
    console_c_l_i_0.do_cd("")
    console_c_l_i_0.do_cd("")


# Generated at 2022-06-24 17:46:38.874824
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    modulename_0 = 'pwd'
    console_c_l_i_0.helpdefault(modulename_0)
    return None


# Generated at 2022-06-24 17:46:44.405007
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.init_parser()
    var_2 = console_c_l_i_0.parse()


# Generated at 2022-06-24 17:46:46.507050
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:46:49.634434
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.completedefault(text='', line='', begidx='', endidx='')


# Generated at 2022-06-24 17:46:54.733969
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    forceshell_0 = False
    arg_0 = "#"
    expected = None

    console_c_l_i_0.cwd = None
    out = console_c_l_i_0.default(arg_0,forceshell_0)

# Generated at 2022-06-24 17:47:02.183140
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    print("Testing do_list of ConsoleCLI class")
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = False
    if var_0:
        cmd_0 = ["ansible-console", "--list"]
        var_1 = console_c_l_i_0.init_parser()
        var_2 = var_1().parse_args(cmd_0)
        console_c_l_i_0.run()
        var_3 = getattr(console_c_l_i_0, "do_list")(console_c_l_i_0, var_2.list)
        print("var_3 is %s" % var_3)
    else:
        cmd_1 = ["ansible-console", "--list"]

# Generated at 2022-06-24 17:47:08.699099
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.modules = {}
    console_c_l_i_0.cwd = '/tmp'
    console_c_l_i_0.passwords = {}
    var_0 = console_c_l_i_0.init_parser()
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:50:01.180981
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:50:05.503863
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Invoke method
    console_c_l_i_do_cd_0 = ConsoleCLI({})
    console_c_l_i_do_cd_0.do_cd('arg_1')


# Generated at 2022-06-24 17:50:09.338743
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.init_parser()
    console_c_l_i_0.do_list("")


# Generated at 2022-06-24 17:50:15.570496
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    string_0 = 'neutron'
    console_c_l_i_0.helpdefault(string_0)


if __name__ == '__main__':
    import sys
    sys.exit(main())

# Generated at 2022-06-24 17:50:17.830814
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_1 = ConsoleCLI()
    var_1 = console_c_l_i_1.completedefault()


# Generated at 2022-06-24 17:50:24.812020
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI()
    # Pass
    text_0 = ''
    line_0 = ''
    begidx_0 = 0
    endidx_0 = 0
    console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:50:36.153577
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.init_parser()

# Generated at 2022-06-24 17:50:39.330907
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    module_name_0 = 'shell'
    # Call method helpdefault of class ConsoleCLI with argument module_name_0
    console_c_l_i_0.helpdefault(module_name_0)


# Generated at 2022-06-24 17:50:46.173158
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_1 = {}
    console_c_l_i_1 = ConsoleCLI(dict_1)
    console_c_l_i_1.modules = ['test_1']
    text_1 = 'test'
    line_1 = 'test'
    begidx_1 = 1
    endidx_1 = 2
    # test.result = console_c_l_i_1.completedefault(text_1, line_1, begidx_1, endidx_1)


# Generated at 2022-06-24 17:50:55.040983
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = 'a'
    var_1 = 'b'
    var_2 = 'c'
    var_3 = 'd'
    var_4 = console_c_l_i_0.completedefault(var_0, var_1, var_2, var_3)


# Generated at 2022-06-24 17:52:26.567841
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    try:
        test_case_0()
    except NameError as var_0:
        print(var_0)
        print('No method ConsoleCLI.cmdloop')


# Generated at 2022-06-24 17:52:39.560923
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_0 = {'ssh_user': 'pytest1'}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.init_parser()
    console_c_l_i_0.pkg_mgr = {'install':'?', 'name':'?', 'state':'?', 'update_cache':'?', 'validate_certs':'?'}
    console_c_l_i_0.modules = ['ping', 'get_url', 'ping', 'ping', 'ping', 'ping', 'pkgmgr', 'ping']
    console_c_l_i_0.completedefault(None, 'pkgmgr install', None, None)


# Generated at 2022-06-24 17:52:43.503200
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    text_0 = "lib"
    line_0 = "ping"
    begidx_0 = 0xffffffff
    endidx_0 = 0xffffffff
    var_0 = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:52:45.179290
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:52:53.738042
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    '''
    Unit test for method list_modules of class ConsoleCLI
    '''
    # Setup the environment
    dict_1 = {}
    console_c_l_i_0 = ConsoleCLI(dict_1)

    # Invoke the method

# Generated at 2022-06-24 17:53:00.787401
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.list_modules()

# Unit test runner
if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_list_modules()

# Generated at 2022-06-24 17:53:05.204632
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
  dict_0 = {}
  console_c_l_i_0 = ConsoleCLI(dict_0)
  if cmdline.valid_completion_environment(dict_0):
    console_c_l_i_0.run()

test_ConsoleCLI_run()

# Generated at 2022-06-24 17:53:10.357046
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.list_modules()
    print(var_0)


# Generated at 2022-06-24 17:53:16.724263
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    text_0 = ''
    line_0 = ''
    begidx_0 = 0
    endidx_0 = 0
    console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:53:20.918659
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    dict_0 = {}
    console_c_l_i_0 = ConsoleCLI(dict_0)
    var_0 = console_c_l_i_0.list_modules()
