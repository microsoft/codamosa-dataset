

# Generated at 2022-06-24 17:44:56.192350
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_0 = "Pk5\r!_K(Ym~.\x15\rR\x14H\x1c"
    console_c_l_i_0.helpdefault(str_0)


# Generated at 2022-06-24 17:44:59.493976
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    arg_0 = 'null'
    forceshell_0 = False
    console_c_l_i_0 = ConsoleCLI(str_0)
    result_0 = console_c_l_i_0.default(arg_0, forceshell_0)
    assert result_0 == False


# Generated at 2022-06-24 17:45:05.622571
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = "sjt8)"
    int_0 = 0
    str_1 = "T&ZCT9O"
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.default(int_0, str_1)


# Generated at 2022-06-24 17:45:12.793347
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = "ex;ox#\x0cRh'xv=\txEr"
    str_1 = string(str_1)
    int_0 = 1673643737
    int_0 = int(int_0)
    str_2 = ""
    str_2 = string(str_2)
    int_1 = 1673643737
    int_1 = int(int_1)
    TEST_0 = console_c_l_i_0.complete_cd(str_1, str_2, int_0, int_1)
    return TEST_0


# Generated at 2022-06-24 17:45:18.527927
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    console_c_l_i_0 = ConsoleCLI()
    assert_equals(console_c_l_i_0.set_prompt(), None)


# Generated at 2022-06-24 17:45:23.879254
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Create an instance of ConsoleCLI
    console_c_l_i_0 = ConsoleCLI("<>" \
            "wv*\x1d\x0c#\x06'\x02\x13\x0e\x1d")
    # Invoke method do_list of class ConsoleCLI with arguments "groups"
    console_c_l_i_0.do_list("groups")

    # Invoke method do_list of class ConsoleCLI with arguments ""
    console_c_l_i_0.do_list("")


# Generated at 2022-06-24 17:45:25.164862
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    test_case_0()

# Generated at 2022-06-24 17:45:38.518712
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = "1jb7\x0e(r\x19\x15\xa8\x17\x1d\x0b\x0f\x1f\x02i\x10\t0\x1f\x1f"
    console_c_l_i_0 = ConsoleCLI(str_0)

    str_1 = "v"
    str_2 = "5"
    int_0 = 2
    int_1 = 3
    int_2 = 4
    str_3 = console_c_l_i_0.completedefault(str_1, str_2, int_0, int_1)
    assert str_3 == str_1
    str_4 = "x"
    str_5 = "v"
    int_3 = 4
    int_4

# Generated at 2022-06-24 17:45:48.257163
# Unit test for method set_prompt of class ConsoleCLI

# Generated at 2022-06-24 17:45:52.708925
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_c_l_i_0 = ConsoleCLI()
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0.list_modules(str_0)


# Generated at 2022-06-24 17:46:18.040534
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    result = ConsoleCLI.complete_cd('', '', '', '')
    assert result == '', 'Expected: '', but got: ' + result

test_case_0()
test_ConsoleCLI_complete_cd()

# Generated at 2022-06-24 17:46:22.972649
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    # Since list_modules is private, we call it through a public method
    console_c_l_i_0 = ConsoleCLI()
    list_0 = console_c_l_i_0.list_modules()
    assert len(list_0) > 0, "ConsoleCLI::list_modules: List of modules should not be empty"
    assert len(list_0) < 3500, "ConsoleCLI::list_modules: List of modules too large: {}".format(len(list_0))
    assert not "ConsoleCLI" in list_0, "ConsoleCLI::list_modules: ConsoleCLI should not be a module"

if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_list_modules()

# Generated at 2022-06-24 17:46:28.749442
# Unit test for method do_timeout of class ConsoleCLI
def test_ConsoleCLI_do_timeout():
    str_1 = "Z!@h\x0ch7x\x1b\x7f\\J\x1bF\x0f\x1b\x1e|r\x1a\x0b\x11\x15\x1b\x1c"
    console_c_l_i_1 = ConsoleCLI(str_1)
    str_2 = "g1"
    console_c_l_i_1.do_timeout(str_2)


# Generated at 2022-06-24 17:46:30.662375
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    x = ConsoleCLI()
    x.default()


# Generated at 2022-06-24 17:46:38.079223
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI()
    arg_0 = "0"
    forceshell_0 = True
    console_c_l_i_0.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:46:43.441277
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    arg_0 = "", True
    test_case_0()
    console_c_l_i_0.default(arg_0)


# Generated at 2022-06-24 17:46:49.531273
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    # Initialize test variables
    text = "'\n"
    line = "'\n"
    begidx = 0
    endidx = 1
    # Create an instance of class ConsoleCLI
    console_c_l_i_0 = ConsoleCLI(text)
    # Call the complete_cd method of the class ConsoleCLI
    console_c_l_i_0.complete_cd(text, line, begidx, endidx)


# Generated at 2022-06-24 17:46:54.112064
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    str_1 = console_c_l_i_0.do_list(str_0)
    print(str_1)



# Generated at 2022-06-24 17:46:57.244077
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = ""
    str_1 = ""
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.cwd = str_1
    str_3 = "shell /bin/echo \"test_string\""
    bool_1 = console_c_l_i_0.default(str_3, True)
    assert bool_1 == False


# Generated at 2022-06-24 17:46:59.992528
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = "chmod"
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.helpdefault(str_0)
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:47:19.833095
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    display.display(helpdefault(str_0))

if __name__ == '__main__':
    print("This is a test program for the ConsoleCLI class")
    print("To run the program use: python ConsoleCLI.py")
    print("To run the tests use: pytest ConsoleCLI.py")

# Generated at 2022-06-24 17:47:28.757806
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    test = ConsoleCLI()
    
    # case 1
    try:
        module_name = ''
        test._ConsoleCLI__helpdefault(module_name)
    except:
        pass

    # case 2
    try:
        module_name = ''
        test._ConsoleCLI__helpdefault(module_name)
    except:
        pass

    # case 3
    try:
        module_name = ''
        test._ConsoleCLI__helpdefault(module_name)
    except:
        pass

    # case 4
    try:
        module_name = ''
        test._ConsoleCLI__helpdefault(module_name)
    except:
        pass

    # case 5
    try:
        module_name = ''
        test._ConsoleCLI__helpdefault(module_name)
    except:
        pass

# Generated at 2022-06-24 17:47:31.146136
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_ConsoleCLI_default_0()
    test_ConsoleCLI_default_1()
    test_ConsoleCLI_default_2()
    test_ConsoleCLI_default_3()
    test_ConsoleCLI_default_4()
    test_ConsoleCLI_default_5()


# Generated at 2022-06-24 17:47:32.395487
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    pass


# Generated at 2022-06-24 17:47:33.732840
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    obj = ConsoleCLI()
    obj.run()

# Generated at 2022-06-24 17:47:47.824774
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    ansible_args = ['-m', 'ping', 'localhost']
    context.CLIARGS['module_path'] = './module_utils'
    ansible_cmd = C.ANSIBLE_CALLBACK_PLUGINS
    ansible_module = 'ping'
    ansible_host = 'localhost'
    cmd_str = '@test.yml'
    t = T.Test_PlaybookExec(ansible_cmd, ansible_module, ansible_args, ansible_config, ansible_host, cmd_str)
    #t.test_playbookexec()
    ret = t.test_playbookexec()
    print(ret)


if __name__ == '__main__':
    test_ConsoleCLI_completedefault()

# Generated at 2022-06-24 17:47:51.576692
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    console_cli = ConsoleCLI()
    console_cli.list_modules()


# Generated at 2022-06-24 17:47:57.072607
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console_0 = ConsoleCLI()
    console_0.do_cd(str_0)
    console_0.do_cd('all')
    console_0.do_cd('*')
    console_0.do_cd(console_0.cwd)
    console_0.do_cd('/')
    console_0.do_cd('\\')

# Generated at 2022-06-24 17:48:02.568111
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    text_0 = ''
    line_0 = ''
    begidx_0 = 0
    endidx_0 = 0
    console_0 = ConsoleCLI(None, None)
    console_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:48:05.512374
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    assert True


# Generated at 2022-06-24 17:48:31.785389
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = "lbhPbqrarq"
    str_1 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_1)
    str_2 = "lbhPbqrarq"
    str_3 = "ex;ox#\x0cRh'xv=\txEr"
    str_4 = "ex;ox#\x0cRh'xv=\txEr"
    str_5 = "lbhPbqrarq"
    str_6 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0.complete_cd(str_2, str_3, str_4, str_5, str_6)

#

# Generated at 2022-06-24 17:48:32.811003
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()



# Generated at 2022-06-24 17:48:39.970409
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)


# Generated at 2022-06-24 17:48:47.680211
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_0 = "X6U"
    str_1 = "Q\x18"
    str_2 = "u~\n"
    str_3 = "U\x0b"
    console_c_l_i_0.completedefault(str_0, str_1, str_2, str_3)


# Generated at 2022-06-24 17:48:56.334228
# Unit test for method completedefault of class ConsoleCLI

# Generated at 2022-06-24 17:49:10.443501
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI('ex;ox#\x0cRh\'xv=\txEr')
    console_c_l_i_1 = ConsoleCLI('ex;ox#\x0cRh\'xv=\txEr')
    console_c_l_i_0._tqm = TaskQueueManager(
        inventory=Mock(),
        variable_manager=Mock(),
        loader=Mock(),
        passwords=Mock(),
        stdout_callback=Mock(),
        run_additional_callbacks=Mock(),
        run_tree=Mock(),
        forks=Mock(),
    )

# Generated at 2022-06-24 17:49:16.758209
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    console_c_l_i_0 = ConsoleCLI("k2]^&Y+l")
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    arg_0 = "Gm$sU\x15\x16\x1e\x03\x11"
    forceshell_0 = False
    console_c_l_i_0.default(arg_0, forceshell_0)


# Generated at 2022-06-24 17:49:25.296010
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    import math
    import random


# Generated at 2022-06-24 17:49:28.674405
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)


# Generated at 2022-06-24 17:49:38.487535
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    try:
        str_2 = "\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b"
        console_c_l_i_1 = ConsoleCLI(str_2)
    except Exception as e:
        display.error(to_text(e))


# Generated at 2022-06-24 17:50:13.526350
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Test 1 : check that ConsoleCLI.cmdloop() runs (does not throw an exception)
    try:
        console_c_l_i_0 = ConsoleCLI()
        console_c_l_i_0.cmdloop()
    except Exception as exception_0:
        print("Exception occurred: " + str(type(exception_0)))
        assert False
    # Test 2 : check that ConsoleCLI() is a subclass of cmd.Cmd
    try:
        assert issubclass(ConsoleCLI, cmd.Cmd)
    except Exception as exception_1:
        print("Exception occurred: " + str(type(exception_1)))
        assert False

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop()
    test_case_0()

# Generated at 2022-06-24 17:50:19.699289
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)

    # Test with valid data
    text_0 = ""
    line_0 = ""
    begidx_0 = -1
    endidx_0 = 0
    ret_0 = console_c_l_i_0.complete_cd(text_0, line_0, begidx_0, endidx_0)
    assert ret_0 == None

    # Test with valid data
    text_1 = "0"
    line_1 = "\u0000\u0000"
    begidx_1 = -1
    endidx_1 = 0

# Generated at 2022-06-24 17:50:22.813006
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    #self.assertEquals(self.cwd, arg)
    print(self.cwd)


# Generated at 2022-06-24 17:50:25.442559
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    module_name = "STRING"
    console_c_l_i = ConsoleCLI()
    console_c_l_i.module_args(module_name)


# Generated at 2022-06-24 17:50:33.568852
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # mock console_c_l_i_0
    # mock str_0
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    # mock console_c_l_i_0
    console_c_l_i_0 = ConsoleCLI(str_0)
    # try and except clause
    try:
        console_c_l_i_0.cmdloop()
    except:
        pass


# Generated at 2022-06-24 17:50:37.392912
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = "exo"

    console_c_l_i_0.helpdefault(str_1)


# Generated at 2022-06-24 17:50:42.886986
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.default("ex;ox#\x0cRh'xv=\txEr")


# Generated at 2022-06-24 17:50:45.915340
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    module_name_0 = "xh"
    console_c_l_i_0 = ConsoleCLI("xh")
    module_args_0 = console_c_l_i_0.module_args(module_name_0)


# Generated at 2022-06-24 17:50:50.477306
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    console_c_l_i_0 = ConsoleCLI('[(,{:*')
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:50:51.835092
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    test_case_0()


# Generated at 2022-06-24 17:51:29.669264
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    p_passwords = (None, None)
    p_loader = None
    p_inventory = None
    p_variable_manager = None
    str_0 = "C:\\Users\\user\\Anaconda3\\lib\\site-packages\\ansible-console\\playbooks"
    ConsoleCLI_0 = ConsoleCLI(str_0)
    ConsoleCLI_0.inventory = p_inventory
    ConsoleCLI_0.variable_manager = p_variable_manager
    ConsoleCLI_0.loader = p_loader
    ConsoleCLI_0.passwords = p_passwords
    ConsoleCLI_0.run()


# Generated at 2022-06-24 17:51:39.467681
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    # Test if the correct dictionary is created
    if len(console_c_l_i_0.loader) != 7:
        sys.stderr.write('Error: Incorrect dictionary created by ansible.parsing.dataloader.DataLoader(ex;ox#\x0cRh\'xv=\txEr)\n')
        sys.exit(1)
    # Test if the correct dictionary is created

# Generated at 2022-06-24 17:51:45.341487
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_1 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_1 = ConsoleCLI(str_1)
    text_1 = "x"
    line_1 = "ex;ox#\x0cRh'xv=\txEr"
    begidx_1 = 7
    endidx_1 = 8
    res_1 = console_c_l_i_1.completedefault(text_1, line_1, begidx_1, endidx_1)
    assert res_1 == None


# Generated at 2022-06-24 17:51:49.500675
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
	str_2 = "q"
	str_3 = "q"
	console_c_l_i_2 = ConsoleCLI(str_2)
	console_c_l_i_2.complete_cd(str_3, str_2, 1, 1)


# Generated at 2022-06-24 17:52:01.457714
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    arg_0 = arg_1 = arg_2 = arg_3 = arg_4 = arg_5 = arg_6 = arg_7 = arg_8 = arg_9 = arg_10 = arg_11 = arg_12 = arg_13 = arg_14 = arg_15 = arg_16 = arg_17 = arg_18 = arg_19 = arg_20 = None
    str_0 = str_1 = str_2 = str_3 = str_4 = str_5 = str_6 = str_7 = str_8 = str_9 = str_10 = str_11 = str_12 = str_13 = str_14 = str_15 = str_16 = str_17 = str_18 = str_19 = str_20 = ""

# Generated at 2022-06-24 17:52:06.336208
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i_0 = ConsoleCLI()
    result_0 = console_c_l_i_0.do_list('groups')
    assert result_0 == None


# Generated at 2022-06-24 17:52:12.057187
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
  import random
  import socket
  import string
  import zlib
  str_0 = "ex;ox#\x0cRh'xv=\txEr"
  console_c_l_i_0 = ConsoleCLI(str_0)
  arg_0 = ""
  random.choice(string.letters)
  console_c_l_i_0.default(arg_0)
  return console_c_l_i_0.default(arg_0)


# Generated at 2022-06-24 17:52:17.155983
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.helpdefault("")


# Generated at 2022-06-24 17:52:21.812958
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    text = ''
    line = ''
    begidx = 0
    endidx = 0
    assert console_c_l_i_0.completedefault(text, line, begidx, endidx) == []


# Generated at 2022-06-24 17:52:22.752821
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    pass


# Generated at 2022-06-24 17:52:47.136850
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    assert type(console_c_l_i_0) == ConsoleCLI




# Generated at 2022-06-24 17:52:51.222181
# Unit test for method list_modules of class ConsoleCLI

# Generated at 2022-06-24 17:52:52.518163
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():

    test_case_0()


# Generated at 2022-06-24 17:52:54.398621
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    pass


# Generated at 2022-06-24 17:52:56.705181
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    # Instantiate ConsoleCLI
    test_case_0()


# Generated at 2022-06-24 17:53:01.617150
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    # Creating an object of class ConsoleCLI
    console_c_l_i_0 = ConsoleCLI()

    # Call method do_cd of class ConsoleCLI with argumen "ex;ox#\x0cRh'xv=\txEr"
    test_case_0()

# Generated at 2022-06-24 17:53:13.451987
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)

# Generated at 2022-06-24 17:53:22.178674
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = "}4e'X|\t\x0c\x1c\x1dg\x7f\x19]5K7\x1b\x18\x0e"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = "a/R6U\x0b\x0bN\x19\x1e"
    console_c_l_i_0.do_list(str_1)


# Generated at 2022-06-24 17:53:26.389616
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = "ex;ox#\x0cRh'xv=\txEr"
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = console_c_l_i_0.list_modules()
    assert str_1 != None


# Generated at 2022-06-24 17:53:29.490216
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    with pytest.raises(TypeError):
        display = Mock()
        console_c_l_i_0 = ConsoleCLI("Mock")
        console_c_l_i_0.helpdefault()
