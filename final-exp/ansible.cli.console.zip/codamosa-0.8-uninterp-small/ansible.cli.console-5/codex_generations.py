

# Generated at 2022-06-24 17:44:46.294991
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    # Test case 0
    # No exception throgh
    test_case_0()


# Generated at 2022-06-24 17:44:51.962286
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    str_0 = None
    console_c_l_i_0 = ConsoleCLI(str_0)
    var_0 = console_c_l_i_0.post_process_args(str_0)
    console_c_l_i_0.ask_passwords(var_0)



# Generated at 2022-06-24 17:44:55.365087
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():

    console_c_l_i_0 = ConsoleCLI(None)
    console_c_l_i_0.helpdefault('shell')


if __name__ == '__main__':
    test_case_0()
    test_ConsoleCLI_helpdefault()

# Generated at 2022-06-24 17:44:59.032280
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    str_0 = None
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:45:09.909116
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():

    # Initialization of object
    console_c_l_i_0 = ConsoleCLI(None)

    # Case with normal input
    try:
        # Test for corner case
        console_c_l_i_0.do_cd("*")
        print("1st test case passed")

        # Test for corner case
        console_c_l_i_0.do_cd("/")
        print("2nd test case passed")
    except Exception:
        print("Test case failed")
    finally:
        print("-----------------")
    try:
        # Test for valid input
        console_c_l_i_0.do_cd("temp")
        print("3rd test case passed")
    except Exception:
        print("Test case failed")
    finally:
        print("-----------------")

# Generated at 2022-06-24 17:45:16.927438
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    str_0 = None
    console_c_l_i_0 = ConsoleCLI(str_0)
    str_1 = None
    res_0 = console_c_l_i_0.do_list(str_1)
    assert_equal(res_0, None)


# Generated at 2022-06-24 17:45:18.501676
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i_0 = ConsoleCLI(None)
    console_c_l_i_0.do_list("groups")


# Generated at 2022-06-24 17:45:21.467254
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    str_0 = None
    console_c_l_i_0 = ConsoleCLI(str_0)
    var_0 = console_c_l_i_0.list_modules()


# Generated at 2022-06-24 17:45:29.285580
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    module = ['ping']
    for m in module:
        console_c_l_i_0 = ConsoleCLI()
        assert (m in console_c_l_i_0.modules) == true
    module = ['invalid_modul']
    for m in module:
        assert m in console_c_l_i_0.module == false

# test class ConsoleCLI

# Generated at 2022-06-24 17:45:33.080034
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    str_0 = None
    console_c_l_i_0 = ConsoleCLI(str_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:45:54.502774
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)

    console_c_l_i_0.do_cd("webservers")
    console_c_l_i_0.do_list("")


# Generated at 2022-06-24 17:45:59.696859
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    console_c_l_i_0.do_unarchive = lambda self, var_1, var_2, var_3: None
    console_c_l_i_0.module_args('unarchive')


# Generated at 2022-06-24 17:46:05.726786
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    print('Testing method do_list of class ConsoleCLI...')
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = 'groups'
    var_2 = 'test'
    console_c_l_i_0.do_list(var_1)
    console_c_l_i_0.do_list(var_2)


# Generated at 2022-06-24 17:46:13.527428
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Test without context
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.cmdloop()

    # Test with context
    var_0 = None
    console_c_l_i_1 = ConsoleCLI(var_0)
    console_c_l_i_1.cmdloop()

    # Test without context
    var_0 = None
    console_c_l_i_2 = ConsoleCLI(var_0)
    console_c_l_i_2.cmdloop()

    # Test with context
    var_0 = None
    console_c_l_i_3 = ConsoleCLI(var_0)
    console_c_l_i_3.cmdloop()


# Generated at 2022-06-24 17:46:19.290552
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI(None)
    module_name = 'ping'
    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:46:26.105637
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Create an instance of class ConsoleCLI
    console_c_l_i_0 = ConsoleCLI(None)

    # Invoke method do_list of ConsoleCLI with argument arg
    console_c_l_i_0.do_list('groups')
    # Invoke method do_list of ConsoleCLI with argument arg
    console_c_l_i_0.do_list('hosts')


# Generated at 2022-06-24 17:46:27.436222
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # TODO Auto-generated code
    pass


# Generated at 2022-06-24 17:46:30.332319
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    console_c_l_i_0.do_list(var_1)


# Generated at 2022-06-24 17:46:44.132257
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    var_1 = None
    var_2 = None
    var_3 = None
    console_c_l_i_1 = ConsoleCLI(var_1)
    var_4 = None
    var_5 = None
    try:
        console_c_l_i_1.default(var_2, var_3)
    except Exception as var_6:
        if type(var_6).__name__ == 'SystemExit':
            raise
        var_5 = var_6
    else:
        var_5 = None
    if var_5 is None:
        var_4 = True
    else:
        var_4 = False
    return var_4


# Generated at 2022-06-24 17:46:48.179908
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    var_1 = None
    console_c_l_i_1 = ConsoleCLI(var_1)
    var_2 = console_c_l_i_1.list_modules()
    # Test type of var_2
    assert(isinstance(var_2, list))


# Generated at 2022-06-24 17:48:00.081126
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    # TODO: Write test case
    raise NotImplementedError


# Generated at 2022-06-24 17:48:09.629964
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    ret_0 = console_c_l_i_0.module_args(var_1)
    print("Testing return type of %s" % type(ret_0))
    if (type(ret_0) == list):
        print("Return type is correct")
    else:
        print("Return type is not correct")


# Generated at 2022-06-24 17:48:22.116193
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    cwd = None
    module = 'ping'
    module_args = None
    forceshell = None
    result = None

# Generated at 2022-06-24 17:48:23.133986
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()


# Generated at 2022-06-24 17:48:26.381174
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    var_0 = dict()
    console_c_l_i_0 = ConsoleCLI(var_0)


# Generated at 2022-06-24 17:48:30.764325
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    var_2 = None
    console_c_l_i_0.do_list(var_1, var_2)


# Generated at 2022-06-24 17:48:39.390897
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:48:48.352406
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Pre-condition:
    # Instantiate ConsoleCLI
    console_c_l_i_0 = ConsoleCLI(None)
    # Parameter text:
    var_0 = None
    # Parameter line:
    var_1 = None
    # Parameter begidx:
    var_2 = None
    # Parameter endidx:
    var_3 = None
    # Call completedefault
    var_4 = console_c_l_i_0.completedefault(var_0, var_1, var_2, var_3)
    # Post-condition:
    assert var_4 == None


# Generated at 2022-06-24 17:49:03.852049
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    var_0 = [{'become': False, 'hosts': '*', 'check': False, 'diff': False, 'become_user': 'root', 'become_method': 'sudo', 'remote_user': 'me'}]
    con_cli_inst_0 = ConsoleCLI(var_0)
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = None
    ret_0 = con_cli_inst_0.completedefault(arg_0, arg_1, arg_2, arg_3)
    assert type(ret_0) == list
    assert len(ret_0) == 0


# Generated at 2022-06-24 17:49:05.201296
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()


# Generated at 2022-06-24 17:49:25.539529
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:49:28.516733
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0) 
    console_c_l_i_0.run()


# Generated at 2022-06-24 17:49:31.179743
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    # Ensures that we can actually call cmdloop.
    console_c_l_i_0 = ConsoleCLI(None)


# Generated at 2022-06-24 17:49:32.560790
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    test_case_0()


# Generated at 2022-06-24 17:49:36.341266
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:49:39.020339
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console_c_l_i_0 = ConsoleCLI(None)
    var_1 = None
    #
    # Invoke method
    #
    console_c_l_i_0.do_cd(var_1)


# Generated at 2022-06-24 17:49:44.033649
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = "test"
    console_c_l_i_0.helpdefault(var_1)


# Generated at 2022-06-24 17:49:48.733380
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    console_c_l_i_0.completedefault(var_1, var_2, var_3, var_4)


# Generated at 2022-06-24 17:49:50.738690
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    """
    Test the method default in class ConsoleCLI.
    """
    # console_c_l_i = ConsoleCLI()
    # console_c_l_i.default('network_cli', False)


# Generated at 2022-06-24 17:49:54.478552
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Pass
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    arg = 'groups'
    console_c_l_i_0.do_list(arg)

# Generated at 2022-06-24 17:51:22.840011
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # Testcase 0
    try:
        test_case_0()
    except Exception as err:
        print("Exception in testcase 0 : " + str(err))
    print("Testcase 0 Finished")

# Run the testcases
test_ConsoleCLI_set_prompt()

# Generated at 2022-06-24 17:51:25.516939
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI()
    module_name = 'test'
    print(console_c_l_i_0.helpdefault(module_name))


# Generated at 2022-06-24 17:51:27.243862
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()

if __name__ == '__main__':
    test_ConsoleCLI_cmdloop()

# Generated at 2022-06-24 17:51:32.019399
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    try:
        var_0 = None
        console_c_l_i_0 = ConsoleCLI(var_0)
        test_case_0()
        assert True
    except AssertionError as e:
        print(e)
        pytest.fail("Test case test_case_0 failed.")
        

# Generated at 2022-06-24 17:51:36.667659
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = console_c_l_i_0
    var_2 = "function"
    var_3 = True
    var_1.default(var_2, var_3)


# Generated at 2022-06-24 17:51:39.911336
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    var_2 = console_c_l_i_0.do_list(var_1)


# Generated at 2022-06-24 17:51:42.430340
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.list_modules()


# Generated at 2022-06-24 17:51:48.123792
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    var_0 = None
    var_1 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.set_prompt()
    console_c_l_i_0.set_prompt(var_1)


# Generated at 2022-06-24 17:51:49.145185
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()

# Generated at 2022-06-24 17:51:51.677587
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:52:39.875063
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    from ansible.cli import CLI
    from ansible.plugins import module_finder
    plugin_finder = module_finder.ModuleFinder()
    var_0 = CLI(args=[1, 1])
    var_0.create_parser()

    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.completedefault(var_1, var_2, var_3, var_4)


# Generated at 2022-06-24 17:52:47.066499
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)

    # Call method completedefault of class ConsoleCLI
    # var_text = None
    # var_line = "ping 192.168.1.1"
    # var_begidx = 12
    # var_endidx = 20

    var_text = "ping 192.168.1."
    var_line = "ping 192.168.1."
    var_begidx = 12
    var_endidx = 20

    var_ret = console_c_l_i_0.completedefault(var_text, var_line, var_begidx, var_endidx)


# Generated at 2022-06-24 17:52:49.919521
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:52:54.592945
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    var_1 = None
    console_c_l_i_0.do_cd(var_1)


# Generated at 2022-06-24 17:52:58.252403
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)


# Generated at 2022-06-24 17:52:59.943517
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    test_case_0()


# Generated at 2022-06-24 17:53:00.682539
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    test_case_0()


# Generated at 2022-06-24 17:53:03.236479
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console_c_l_i_0 = ConsoleCLI()
    # No need to test console_c_l_i_0.do_cd


# Generated at 2022-06-24 17:53:07.889602
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    console_c_l_i_0.do_list(arg)


# Generated at 2022-06-24 17:53:11.713491
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    var_0 = None
    console_c_l_i_0 = ConsoleCLI(var_0)
    module_name = "ping"
    console_c_l_i_0.helpdefault(module_name)
