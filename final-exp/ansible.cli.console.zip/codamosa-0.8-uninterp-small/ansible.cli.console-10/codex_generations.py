

# Generated at 2022-06-24 17:45:47.156995
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    float_0 = 505.86
    console_c_l_i_0 = ConsoleCLI(float_0)
    string_0 = '-'
    console_c_l_i_0.do_verbosity(string_0)


# Generated at 2022-06-24 17:45:52.050712
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    ansible_console_path_0 = "console"
    console_c_l_i_0 = ConsoleCLI(ansible_console_path_0)
    module_name_0 = 'put'
    console_c_l_i_0.module_args(module_name_0)


# Generated at 2022-06-24 17:45:55.338506
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    float_0 = 157.048067
    console_c_l_i_0 = ConsoleCLI(float_0)
    str_0 = 'ping'
    console_c_l_i_0.helpdefault(str_0)

# Generated at 2022-06-24 17:46:00.034527
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Unit test for method do_list of class ConsoleCLI
    float_0 = 3730.85876
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.do_list('groups')
    console_c_l_i_0.do_list('dev')


if __name__ == '__main__':
    test_ConsoleCLI_do_list()

# Generated at 2022-06-24 17:46:04.129502
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    string_0 = ''
    return console_c_l_i_0.module_args(string_0)


# Generated at 2022-06-24 17:46:06.622116
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(0)
    # Start a command loop
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:46:12.164674
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    print("\tTest method ConsoleCLI.helpdefault() ...")
    # public void helpdefault(String module_name)
    ConsoleCLI_0 = ConsoleCLI()
    ConsoleCLI_0.helpdefault('module_name_0')
    ConsoleCLI_1 = ConsoleCLI(1)
    ConsoleCLI_1.helpdefault('module_name_1')
    ConsoleCLI_2 = ConsoleCLI(2)
    ConsoleCLI_2.helpdefault('module_name_2')


# Generated at 2022-06-24 17:46:16.175337
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():

    # Unit test for method helpdefault of class ConsoleCLI

    module_name = 'login_defs'

    # string_0 = 'shell'
    # line_0 = 'list (groups)'

    console_c_l_i_0 = ConsoleCLI(2.7)

    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:46:18.607173
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    foo__8 = ConsoleCLI()
    foo__8.default("foo")

# Generated at 2022-06-24 17:46:27.268914
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    float_0 = 511.816701
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.prompt = "S!%cXG"
    console_c_l_i_0.cwd = "02Ea"
    console_c_l_i_0.forks = float_0
    console_c_l_i_0.set_prompt()
    float_0 = console_c_l_i_0.forks
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:46:57.021098
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    line_0 = ""
    line_1 = "shell ps uax | grep java | wc -l"
    line_2 = "shell killall python"
    line_3 = "shell halt -n"
    line_4 = "ping"
    line_5 = "ping -f"
    line_6 = "setup"
    line_7 = "setup -f"
    line_8 = "yum"
    line_9 = "yum -f"
    line_10 = "command"
    line_11 = "command -f"
    line_12 = "shell"
    line_13 = "shell -f"
    line_14 = "ping -t"
    line_15 = "ping -t -f"
    line_16 = "setup -t"

# Generated at 2022-06-24 17:46:58.766233
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    float_0 = 369.130859
    console_c_l_i_0 = ConsoleCLI(float_0)
    # Assign values for arguments
    console_c_l_i_0.set_prompt()


# Generated at 2022-06-24 17:47:02.846396
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    float_0 = 481.180127
	# Invoke method module_args of class ConsoleCLI
    # (ConsoleCLI)(443.140029).module_args()
    console_c_l_i_0 = ConsoleCLI(float_0)


# Generated at 2022-06-24 17:47:07.666753
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(97.0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:47:11.181839
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:47:17.079102
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    arg_str = 'arg'
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.do_list(arg_str)


# Generated at 2022-06-24 17:47:23.124326
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    print("Testing method module_args of class ConsoleCLI")
    float_0 = 7.244
    console_c_l_i_0 = ConsoleCLI(float_0)
    string_0 = ""
    string_1 = console_c_l_i_0.module_args(string_0)
    assert string_1 == "", "Error in test_ConsoleCLI_module_args: expected %s, got %s" % ("", string_1)
    string_2 = "cd"
    string_3 = console_c_l_i_0.module_args(string_2)
    assert string_3 == "", "Error in test_ConsoleCLI_module_args: expected %s, got %s" % ("", string_3)
    string_4 = "doesnotexist"
    string_5 = console

# Generated at 2022-06-24 17:47:31.079318
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.do_cd('cd ')
    console_c_l_i_0.do_cd('cd /*')
    console_c_l_i_0.do_cd('cd /*')
    console_c_l_i_0.do_cd('cd /')


# Generated at 2022-06-24 17:47:40.379274
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = "25"
    line_0 = "cd "
    begidx_0 = 2
    endidx_0 = 3
    ans_0 = console_c_l_i_0.complete_cd(text_0, line_0, begidx_0, endidx_0)
    print(ans_0)


# Generated at 2022-06-24 17:47:43.709289
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    test_case_0()

if __name__ == "__main__":
    test_ConsoleCLI_default()


if __name__ == '__main__':
    cli = ConsoleCLI()
    cli.run()

# Generated at 2022-06-24 17:48:07.474537
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # TODO: Implement test
    pass


# Generated at 2022-06-24 17:48:12.054112
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.list_modules()

# Generated at 2022-06-24 17:48:19.288554
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    float_0 = 542.79627
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = 'm'
    line_0 = 'm'
    int_0 = 394
    int_1 = 559
    # exception should have been raised
    assert_raises(AttributeError, console_c_l_i_0.completedefault, text_0, line_0, int_0, int_1)


# Generated at 2022-06-24 17:48:22.932321
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = 370.85
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.list_modules()


# Generated at 2022-06-24 17:48:28.809873
# Unit test for method default of class ConsoleCLI
def test_ConsoleCLI_default():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    string_0 = "l"
    boolean_0 = False
    console_c_l_i_0.default(string_0, boolean_0)


# Generated at 2022-06-24 17:48:29.827905
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    consoleCLI = ConsoleCLI()


# Generated at 2022-06-24 17:48:33.028970
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    # Test 1
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.do_list(None)


# Generated at 2022-06-24 17:48:40.571634
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console_c_l_i_0 = ConsoleCLI(0.0)
    string_0 = 'webservers'
    console_c_l_i_0.do_cd(string_0)
    string_0 = 'webservers'
    assert console_c_l_i_0.cwd == string_0


# Generated at 2022-06-24 17:48:47.336610
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    float_0 = 9.859273523
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = "8"
    line_0 = "ansible-console -v"
    begidx_0 = 6
    endidx_0 = 5
    
    result = console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)
    assert result is True


# Generated at 2022-06-24 17:48:52.874292
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    console_c_l_i_0 = ConsoleCLI(100.0)
    text = '0'
    line = '0'
    begidx = 0
    endidx = 1

    print(ConsoleCLI.completedefault(console_c_l_i_0, text, line=line, begidx=begidx, endidx=endidx))


# Generated at 2022-06-24 17:49:18.863718
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    float_0 = 899.868377
    console_c_l_i_0 = ConsoleCLI(float_0)

    module_name = 'ping'

    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:49:31.652815
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():

    console_c_l_i_0 = ConsoleCLI(8.39)

    try:
        console_c_l_i_0.module_args(str(593))
        success = True
    except Exception:
        success = False
    assert not success
    
    try:
        console_c_l_i_0.module_args(float(994))
        success = True
    except Exception:
        success = False
    assert success
    
    try:
        console_c_l_i_0.module_args(20.7)
        success = True
    except Exception:
        success = False
    assert success
    

# Generated at 2022-06-24 17:49:33.255168
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    console_c_l_i_0 = ConsoleCLI(None)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:49:37.002278
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    # Test for an invalid argument
    try:
        test_case_0()
        assert False
    except ValueError as error:
        assert error.message == 'Input argument forks is not a valid number (type = float64)'

# Generated at 2022-06-24 17:49:41.082661
# Unit test for method cmdloop of class ConsoleCLI
def test_ConsoleCLI_cmdloop():
    float_0 = 990020.1
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.cmdloop()


# Generated at 2022-06-24 17:49:43.296399
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    float_0 = 0.019
    console_c_l_i_0 = ConsoleCLI(float_0)
    string_0 = 'test_string'
    console_c_l_i_0.helpdefault(string_0)


# Generated at 2022-06-24 17:49:51.376124
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    console_c_l_i_0 = ConsoleCLI(float_0)
    module_name = ''
    # Execution of method helpdefault in class ConsoleCLI
    console_c_l_i_0.helpdefault(module_name)


# Generated at 2022-06-24 17:50:01.284120
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = "W8V"
    line_0 = "vHT"
    begidx_0 = 511
    endidx_0 = 859
    return console_c_l_i_0.completedefault(text_0, line_0, begidx_0, endidx_0)


# Generated at 2022-06-24 17:50:03.950779
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    # Create Object
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)

# Generated at 2022-06-24 17:50:13.461615
# Unit test for method complete_cd of class ConsoleCLI
def test_ConsoleCLI_complete_cd():
    float_0 = 481.287842
    console_c_l_i_0 = ConsoleCLI(float_0)
    text_0 = ''
    line_0 = 'cd '
    begidx_0 = len('cd ')
    endidx_0 = len(line_0)
    var_0 = console_c_l_i_0.complete_cd(text_0, line_0, begidx_0, endidx_0)
    float_0 = float(var_0[0])
    float_1 = float(var_0[1])
    float_2 = float(var_0[2])
    float_3 = float(var_0[3])
    float_4 = float(var_0[4])
    float_5 = float(var_0[5])



# Generated at 2022-06-24 17:51:16.897805
# Unit test for method completedefault of class ConsoleCLI
def test_ConsoleCLI_completedefault():
    # Unit test for method completedefault of class ConsoleCLI

    test_case_0()


# Generated at 2022-06-24 17:51:21.333146
# Unit test for method do_list of class ConsoleCLI
def test_ConsoleCLI_do_list():
    console_c_l_i_0 = ConsoleCLI(1.0)
    args = None
    console_c_l_i_0.do_list(args)


# Generated at 2022-06-24 17:51:23.139019
# Unit test for method list_modules of class ConsoleCLI
def test_ConsoleCLI_list_modules():
    float_0 = 729.387519
    console_c_l_i_0 = ConsoleCLI(float_0)


# Generated at 2022-06-24 17:51:30.825286
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    float_0 = 481.180127
    console_c_l_i_0 = ConsoleCLI(float_0)

    # !!! Note that the argument to this method is used as follows:
    # !!!   * If the argument is None, then os.environ['PWD'] is used.
    console_c_l_i_0.cmdloop = mock.Mock()
    console_c_l_i_0.cmdloop(None)
    console_c_l_i_0.cmdloop.assert_called_once_with(os.environ['PWD'])


# Generated at 2022-06-24 17:51:33.795534
# Unit test for method set_prompt of class ConsoleCLI
def test_ConsoleCLI_set_prompt():
    float_0 = 918.819747
    console_c_l_i_0 = ConsoleCLI(float_0)
    console_c_l_i_0.set_prompt()
    assert True


# Generated at 2022-06-24 17:51:37.827860
# Unit test for method helpdefault of class ConsoleCLI
def test_ConsoleCLI_helpdefault():
    string_arg = 'tar'
    float_arg = 537.170090
    console_c_l_i_arg = ConsoleCLI(float_arg)
    
    console_c_l_i_arg.helpdefault(string_arg)
    
test_case_0.test_ConsoleCLI_helpdefault = test_ConsoleCLI_helpdefault


# Generated at 2022-06-24 17:51:45.343737
# Unit test for method do_verbosity of class ConsoleCLI
def test_ConsoleCLI_do_verbosity():
    global ConsoleCLI
    global C
    global display
    global args
    global get_current_args
    tmp_0 = ConsoleCLI(3.1)
    tmp_0.args = args
    tmp_0.get_current_args = get_current_args
    tmp_0.C = C
    tmp_0.display = display
    global test_do_verbosity
    test_do_verbosity = 0
    tmp_0.do_verbosity('')
    assert test_do_verbosity == 0
    tmp_0.do_verbosity('0')
    assert test_do_verbosity == 1
    tmp_0.do_verbosity('1')
    assert test_do_verbosity == 2
    tmp_0.do_verbosity('2')
    assert test_do_verbosity == 3


# Generated at 2022-06-24 17:51:54.236680
# Unit test for method do_cd of class ConsoleCLI
def test_ConsoleCLI_do_cd():
    console_c_l_i_0 = ConsoleCLI("1.0")
    console_c_l_i_0.do_cd("webservers")
    console_c_l_i_0.do_cd("webservers:dbservers")
    console_c_l_i_0.do_cd("webservers:!phoenix")
    console_c_l_i_0.do_cd("webservers:&staging")
    console_c_l_i_0.do_cd("webservers:dbservers:&staging:!phoenix")


# Generated at 2022-06-24 17:51:58.046405
# Unit test for method run of class ConsoleCLI
def test_ConsoleCLI_run():
    console_c_l_i_0 = ConsoleCLI()
    assert console_c_l_i_0.run() == 0
    display.display("test_ConsoleCLI_run() executed successfully")


# Generated at 2022-06-24 17:52:05.522174
# Unit test for method module_args of class ConsoleCLI
def test_ConsoleCLI_module_args():
    module_name = 'command'

    console_c_l_i_0 = ConsoleCLI(float(0))
    console_c_l_i_1 = ConsoleCLI(float(0))

    oc_0, a_0, _, _ = console_c_l_i_0.module_args(module_name)

    oc_1, a_1, _, _ = console_c_l_i_1.module_args(module_name)

    assert(oc_0 == oc_1)
    assert(a_0 == a_1)
