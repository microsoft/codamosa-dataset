

# Generated at 2022-06-22 23:35:20.222803
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    result = dn.parse_media_line(['media:', 'autoselect', '<unknown type>', 'status:', 'inactive'], None, None)
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == 'unknown type'
    assert result['media_options'] == ''

# Generated at 2022-06-22 23:35:27.343059
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    myClass = DarwinNetworkCollector()
    assert [f._platform for f in myClass._fact_class] == ['Darwin']
    assert [f._platform for f in myClass._fact_classes] == ['Darwin']
    assert myClass.platform == 'Darwin'
    myClass._set_fact_class()
    assert myClass._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:35:34.940857
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create test object
    network = DarwinNetwork()
    current_if = dict()
    ips = dict()
    # test media line for Ethernet
    words = [None, 'Ethernet', 'autoselect', '(1000baseT)']
    # test media line for WiFi
    #words = [None, 'Wi-Fi', 'autoselect', '(none)']
    network.parse_media_line(words, current_if, ips)
    assert current_if['media']  == 'Unknown'
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == '(1000baseT)'
    assert current_if['media_options'] == []
    # test media line for WiFi
    words = [None, 'Wi-Fi', 'autoselect', '(none)']
   

# Generated at 2022-06-22 23:35:46.236586
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:35:54.893759
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:','IEEE','802.11','autoselect','status:','inactive']
    current_if = {'name':'en0', 'macaddress':'00:11:22:33:44:55'}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == words[1]
    assert current_if['media_type'] == words[2]
    assert current_if['media_options'] == dn.get_options(words[3])

# Generated at 2022-06-22 23:35:56.658926
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork()
    assert isinstance(facts, DarwinNetwork)
    assert facts.platform == 'Darwin'


# Generated at 2022-06-22 23:36:08.512789
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    test_iface = DarwinNetwork()
    test_iface.parse_media_line(['media:', 'autoselect', '<unknown type>'], {}, {})
    assert test_iface['media'] == 'Unknown'
    assert test_iface['media_select'] == 'autoselect'
    assert test_iface['media_type'] == 'unknown type'

    test_iface = DarwinNetwork()
    test_iface.parse_media_line(['media:', '<unknown type>', '100baseTX'], {}, {})
    assert test_iface['media'] == 'Unknown'
    assert test_iface['media_select'] == '<unknown type>'

# Generated at 2022-06-22 23:36:16.108628
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ''' Unit test for method parse_media_line of class DarwinNetwork '''

    ###############################################################
    # macOS bridge interface
    darwin_bridge_network = DarwinNetwork()
    current_if = {}
    darwin_bridge_network.parse_media_line(words=['media:', '<unknown', 'type>'], current_if=current_if, ips=[])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    ###############################################################
    # macOS ethernet interface
    darwin_ethernet_network = DarwinNetwork()
    current_if = {}
    darwin_ethernet_

# Generated at 2022-06-22 23:36:25.879716
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test data
    test_data = { 'lines': [ "media: <unknown type>",
                             "media: autoselect <unknown type>",
                             "media: <unknown type> <unknown type>",
                             "media: autoselect (none)",
                             "media: autoselect <unknown type> full-duplex"
                             ],
     'iface': {"name": "bridge0" }
    }

    # Proposed result
    test_result = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '<unknown type>', 'media_options': 'full-duplex' }

    # The test
    #  Prepare instance of class DarwinNetwork and call method parse_media_line
    darwin_network = DarwinNetwork()

# Generated at 2022-06-22 23:36:27.060938
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dw = DarwinNetwork(None)
    assert dw.version == 1


# Generated at 2022-06-22 23:36:34.935335
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # unit test for method parse_media_line of class DarwinNetwork
    current_if = {}
    ifc = DarwinNetwork()
    ifc.parse_media_line('media: autoselect (1000baseT <full-duplex>) status: '.split(), current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['full-duplex']

# Generated at 2022-06-22 23:36:38.378269
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == "Darwin" 


# Generated at 2022-06-22 23:36:39.969484
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    f = DarwinNetwork()
    assert f.platform == 'Darwin'



# Generated at 2022-06-22 23:36:41.450166
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:36:42.799255
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:36:44.984380
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Creates an instance of DarwinNetworkCollector class.
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:48.564580
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert 'Unknown' == module.parse_media_line(['<unknown','type>'], {}, {})['media_select']

# Generated at 2022-06-22 23:36:49.977688
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    obj.get_all_network_interfaces()

# Generated at 2022-06-22 23:36:57.738414
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type>'
    words = media_line.split()

    current_if = {}
    current_if['media'] = 'Unknown'
    current_if['media_select'] = words[1]
    current_if['media_type'] = 'unknown type'

    retrieved_if = DarwinNetwork.parse_media_line(words, current_if, None)
    assert retrieved_if['media'] == current_if['media']
    assert retrieved_if['media_select'] == current_if['media_select']
    assert retrieved_if['media_type'] == current_if['media_type']

# Generated at 2022-06-22 23:36:59.464936
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # DarwinNetwork is a subclass of GenericBsdNetwork
    assert issubclass(DarwinNetwork, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:37:04.556786
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    facts = obj.collect()

    assert facts['all_ipv4_addresses'] is not None
    assert facts['all_ipv6_addresses'] is not None
    assert facts['default_ipv4'] is not None
    assert facts['default_ipv6'] is not None


# Generated at 2022-06-22 23:37:05.586480
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()
#

# Generated at 2022-06-22 23:37:06.154759
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:09.080949
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test construction of class DarwinNetwork with empty data
    dn = DarwinNetwork(dict())
    assert dn
    assert dn.get_interfaces() == []



# Generated at 2022-06-22 23:37:20.658655
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d_if = {}
    # Parse a media line that looks like a default FreeBSD media line
    DarwinNetwork.parse_media_line(DarwinNetwork, 'media: BSD autoselect (1000baseT full-duplex,flowcontrol,rxpause,txpause) status: active', d_if, [])
    assert d_if['media'] == 'BSD autoselect'
    assert d_if['media_select'] == '1000baseT'
    assert d_if['media_type'] == 'full-duplex,flowcontrol,rxpause,txpause'
    assert d_if['media_options'] == ['full-duplex', 'flowcontrol', 'rxpause', 'txpause']

    # Parse a media line with a media type that looks like a default FreeBSD media line

# Generated at 2022-06-22 23:37:21.370499
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:22.333787
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetworkCollector._fact_class is DarwinNetwork

# Generated at 2022-06-22 23:37:24.052671
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network is not None

# Generated at 2022-06-22 23:37:26.219532
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test instance creation
    d = DarwinNetwork()

    # test instance variable
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:37:31.235088
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test the constructor of the class DarwinNetwork"""
    module = AnsibleModule(argument_spec={})
    collector = DarwinNetworkCollector(module=module)
    network = DarwinNetwork(collector=collector)
    assert network.parser == 'generic_bsd'


# Generated at 2022-06-22 23:37:39.825104
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fake_if = {'media': 'Unknown', 'media_select': None, 'media_type': None, 'media_options': None}
    test_DarwinNetwork = DarwinNetwork()
    test_DarwinNetwork.parse_media_line(['Media:', 'autoselect'], fake_if, {})
    assert fake_if['media_select'] == 'autoselect'

    test_DarwinNetwork.parse_media_line(['Media:', 'autoselect', '(1000baseT)'], fake_if, {})
    assert fake_if['media_select'] == 'autoselect'
    assert fake_if['media_type'] == '1000baseT'

# Generated at 2022-06-22 23:37:41.156782
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net_config = DarwinNetwork()
    print(darwin_net_config.facts)

# Generated at 2022-06-22 23:37:43.502439
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetwork = DarwinNetworkCollector()
    assert (darwinNetwork._platform == 'Darwin')

# Generated at 2022-06-22 23:37:46.274406
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:37:55.796367
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'device': 'bridge3',
        'type': 'bridge'
    }
    configuration = [
        'media: <unknown type>',
        'status: inactive',
        'bridge3.ether.peer: ae:ee:aa:11:55:55'
    ]
    expected = {
        'device': 'bridge3',
        'type': 'bridge',
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type'
    }
    dn = DarwinNetwork()
    dn.parse_media_line(configuration[0].split(), current_if, None)
    assert current_if == expected

# Generated at 2022-06-22 23:38:06.185045
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()

    # test parse_media_line of class DarwinNetwork
    # case 1: normal media line
    words = ['media:', 'autoselect', '(']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '('
    assert current_if['media_options'] is None

    # case 2: empty media line
    words = []
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] is None
    assert current_if['media_type']

# Generated at 2022-06-22 23:38:14.980459
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ''' Testing DarwinNetwork.parse_media_line() method
        Input:  ifconfig output contains line ' media: <unknown type>'
        Result: media type is Unknown
    '''
    words = ['bridge1:', 'media:', '<unknown', 'type>', 'status:', 'active']
    current_if = {}
    ips = []
    result = DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_select'] == 'Unknown'



# Generated at 2022-06-22 23:38:22.719009
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:38:24.820443
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Instantiate test class
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:38:27.548492
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Current DarwinNetwork has no constructor arguments
    darwin_net = DarwinNetwork()
    assert(darwin_net._platform == 'Darwin')


# Generated at 2022-06-22 23:38:28.590291
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    results = DarwinNetworkCollector()
    assert results

# Generated at 2022-06-22 23:38:33.592675
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(invalid_opt_args=dict())
    assert dn.platform == 'Darwin'
    assert dn.get_options('') == dict()
    assert dn.get_options(None) == dict()
    assert dn.get_options('one') == dict()
    assert dn.get_options('one two') == {'one':True, 'two':True}
    assert dn.get_options('one two three') == {'one':True, 'two':True, 'three':True}
    assert dn.get_options('one=foo') == {'one':'foo'}
    assert dn.get_options('one=foo two=bar') == {'one':'foo', 'two':'bar'}

# Generated at 2022-06-22 23:38:36.552881
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    test that DarwinNetworkCollector produces a DarwinNetwork instance
    """
    darwinNet = DarwinNetworkCollector()
    assert darwinNet.platform == 'Darwin'
    assert darwinNet.strategy == 'ifconfig'

# Generated at 2022-06-22 23:38:36.955790
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:38.420824
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    DarwinNetwork()


# Generated at 2022-06-22 23:38:38.894676
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector

# Generated at 2022-06-22 23:38:50.257580
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None, None, None, None)
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork
    assert obj._config.connection == 'network_cli'
    assert obj._config.cache == '/dev/shm/ansible_darwin_network'
    assert obj._config.cache_expiration == 3600
    assert obj._config.network_cli_transport == 'network_cli'
    assert obj._config.content_path == '/usr/share/ansible_facts/facts.d/network'
    assert obj._config.content_prefix == 'ansible_net_'
    assert obj._config.sanitize == 'yes'
    assert obj._config.gather_subset == ['all']


# Generated at 2022-06-22 23:38:53.554491
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_input = 'media: <unknown type> 10baseT/UTP <full-duplex>'
    test_current_if = {}
    test_ips = {}
    test_output = {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'unknown type', 'media_options': ['full-duplex']}
    DarwinNetwork.parse_media_line(test_input.split(), test_current_if, test_ips)
    assert test_current_if == test_output

# Generated at 2022-06-22 23:38:59.950195
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn
    assert dn.platform == 'Darwin'
    assert dn.media_supported
    assert dn.media_field_header == 'media'
    assert dn.media_select_field == 'media_select'
    assert dn.media_type_field == 'media_type'
    assert dn.media_options_field == 'media_options'

# Generated at 2022-06-22 23:39:00.948233
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None).platform == 'Darwin'

# Generated at 2022-06-22 23:39:10.963699
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.parse_media_line(['media:', 'autoselect', '(none)'], dn.interfaces['lo0'], None)
    assert dn.interfaces['lo0']['media'] == 'Unknown'
    assert dn.interfaces['lo0']['media_select'] == 'autoselect'
    assert dn.interfaces['lo0']['media_options'] == '(none)'

    dn = DarwinNetwork()
    dn.parse_media_line(['media:', 'autoselect', '(100baseTX)'], dn.interfaces['lo0'], None)
    assert dn.interfaces['lo0']['media'] == 'Unknown'
    assert dn.interfaces['lo0']['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:39:11.855911
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    res = DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:13.372792
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector()
    assert darwin_network is not None

# Generated at 2022-06-22 23:39:14.521064
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'

# Generated at 2022-06-22 23:39:15.834579
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Initialize object
    network = DarwinNetwork()

    # Check type of object
    assert isinstance(network, DarwinNetwork)

# Generated at 2022-06-22 23:39:16.933797
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-22 23:39:21.164819
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == "Darwin"
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector.platform == "Darwin"

# Generated at 2022-06-22 23:39:31.358630
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:39:37.966045
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ This function tests the constructor of class DarwinNetworkCollector"""
    # create an instance of DarwinNetworkCollector
    my_obj = DarwinNetworkCollector()
    # check parameter '_fact_class' of DarwinNetworkCollector
    assert my_obj._fact_class == DarwinNetwork
    # check parameter '_platform' of DarwinNetworkCollector
    assert my_obj._platform == 'Darwin'


# Generated at 2022-06-22 23:39:43.837231
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import pytest
    dn = DarwinNetwork({})
    current_if = dict()
    words = ['media:', 'auto', '10baseT/UTP', '<full-duplex>']
    ips = dict()
    result = dn.parse_media_line(words, current_if, ips)
    expected = dict([('media', 'Unknown'), ('media_select', 'auto'), ('media_type', '10baseT/UTP'), ('media_options', 'full-duplex')])
    assert result == expected

# Generated at 2022-06-22 23:39:45.572067
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_info = DarwinNetwork()
    assert net_info.platform == 'Darwin'

# Generated at 2022-06-22 23:39:57.136293
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinNetwork = DarwinNetwork()
    # test with media line '<up,broadcast,running,simplex,multicast> mtu 1500'
    list_of_words = ['<up,broadcast,running,simplex,multicast>', 'mtu', '1500']
    current_if = {}
    darwinNetwork.parse_media_line(list_of_words,current_if,{})
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == '<up,broadcast,running,simplex,multicast>')
    assert(current_if['media_type'] == 'mtu')
    assert(current_if['media_options'] == {'1500': ''})
    # test with media line '<up,broadcast,running,simplex,

# Generated at 2022-06-22 23:40:08.803716
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    Unit test to validate the media line
    '''
    d_network = DarwinNetwork()
    assert d_network.parse_media_line(['media:', '(none)', '(none)', '(none)'], {'name': 'lo0'}, {'name': 'lo0'}) == {'name': 'lo0', 'media': 'Unknown', 'media_select': '(none)', 'media_type': '(none)', 'media_options': '(none)'}

# Generated at 2022-06-22 23:40:15.889405
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetworkCollector()
    d.get_facts()
    # we get a dictionary
    assert (isinstance(d, dict))
    # we get keys like 'eth0'
    assert ('eth0' in d)
    # we get a dictionary which contains some keys like 'media_type'
    assert ('media_type' in d['eth0'])

# Generated at 2022-06-22 23:40:22.880743
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Assuming correct input, this test shows that the output is correct
    darwin_input = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    output = DarwinNetwork.parse_media_line(darwin_input, 'en3', {})
    assert output == {
        'en3': {
            'media_select': 'autoselect',
            'media_type': '(none)',
            'media': 'Unknown',
            'media_options': ''
        }
    }



# Generated at 2022-06-22 23:40:24.344689
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d_network = DarwinNetwork({}, [''], '')
    assert d_network.platform == 'Darwin'

# Generated at 2022-06-22 23:40:28.849440
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Create an instance of DarwinNetworkCollector
    darwin_net_collector = DarwinNetworkCollector()
    # Check that the class of the instance is DarwinNetworkCollector
    assert(darwin_net_collector.__class__ == DarwinNetworkCollector)


# Generated at 2022-06-22 23:40:39.969155
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # simulate the line returned by macOS ifconfig command
    # ifconfig bridge100
    # bridge100: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    # options=10b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING>
    # media: <unknown type> <unknown subtype>
    # status: inactive
    # output of the media line
    line = 'media: <unknown type> <unknown subtype>'
    # calling the tested method
    current_if = {}
    DarwinNetwork().parse_media_line(line.rstrip().split(), current_if, {})
    # expected output

# Generated at 2022-06-22 23:40:48.768339
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    # create a network collector object

# Generated at 2022-06-22 23:41:00.907776
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'name': 'en0'}
    ips = []
    test_data = [
        # test data for parse media line
        {'input': "media: <unknown type>", 'expected': 'Unknown',
         'assert': 'equal'},
        {'input': "media: autoselect (100baseTX <full-duplex>)",
         'expected': '100baseTX', 'assert': 'equal'},
        {'input': "media: autoselect (100baseTX <full-duplex>)",
         'expected': 'full-duplex', 'assert': 'in'},
    ]
    for td in test_data:
        dn.parse_media_line(td['input'].split(), current_if, ips)

# Generated at 2022-06-22 23:41:02.912573
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert NetworkCollector.__subclasses__()[0].__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-22 23:41:03.997588
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    q = DarwinNetwork({})
    assert q != None

# Generated at 2022-06-22 23:41:13.950298
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    os_facts = {'distribution': 'Darwin'}
    test_obj = DarwinNetwork(os_facts, False)
    test_if = {}
    test_if['media'] = ''
    test_if['media_select'] = ''
    test_if['media_type'] = ''
    test_words = ['Media:', '<unknown', 'type>']
    test_obj.parse_media_line(test_words, test_if, [])
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:41:20.269888
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # expected input line
    input_line = "media: <unknown type>"
    # expected output line
    expected_if = {'media': 'Unknown', 'media_select': '<unknown' , 'media_type': 'type>'}
    # Test init
    darwin_network = DarwinNetwork(None)
    # Test parse line
    test_if = darwin_network.parse_media_line(input_line.split(), {}, None)
    # Compare expected and test results
    assert test_if == expected_if

# Generated at 2022-06-22 23:41:31.683629
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Define test environment
    t_current_if = {'media': 'ethernet',
                    'media_select': 'none',
                    'media_type': 'none',
                    'media_options': 'none'}

    # Define test list of words
    t_words = ['media:', 'ethernet', 'auto', 'status:', 'active']

    # Instantiate object
    test_DarwinNetwork = DarwinNetwork()

    # Execute method parse_media_line with parameters t_words and t_current_if
    test_DarwinNetwork.parse_media_line(t_words, t_current_if, 'none')

    # Define expected result

# Generated at 2022-06-22 23:41:39.283763
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    ifc = dict()

    words = ['media:', 'auto', '1000baseT', '(none)']
    ifc = dn.parse_media_line(words, ifc, dict())
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'auto'
    assert ifc['media_type'] == '1000baseT'
    assert ifc['media_options'] == dict()

    words = ['media:', 'auto', '1000baseT', 'full-duplex,rxpause,txpause']
    ifc = dn.parse_media_line(words, ifc, dict())
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'auto'

# Generated at 2022-06-22 23:41:40.093442
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:41:49.992810
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # given
    d = {'media': 'Unknown',
         'media_select': 'autoselect',
         'media_type': 'autoselect',
         'media_options': {'status': 'active',
                           'sonic': 'disabled',
                           'full-duplex': True,
                           '100baseTX': True,
                           '10baseT': True,
                           '10baseT-FDX': True,
                           '100baseTX-FDX': '',
                           '100baseT2': '',
                           '100baseT2-FDX': '',
                           '1000baseT': '',
                           '1000baseT-FDX': '',
                           'flow-control': True}}

    # when
    n = DarwinNetwork()

    # then
    assert n.get_

# Generated at 2022-06-22 23:41:53.440987
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'
    assert dnc._fact_class.platform == 'Darwin'
    assert isinstance(dnc._fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:41:54.902619
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:41:55.533121
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:42:00.553165
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>']
    darwin_if = DarwinNetwork()
    darwin_if.parse_media_line(words, {}, {})
    assert 'media' in darwin_if.interfaces['Media']
    assert darwin_if.interfaces['Media']['media'] == 'Unknown'

# Generated at 2022-06-22 23:42:02.068058
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    x = DarwinNetwork()
    assert x.platform == 'Darwin'

# Generated at 2022-06-22 23:42:06.041014
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetworkCollector.load_collector()
    assert darwin._facts == {}
    assert darwin._fact_class == DarwinNetwork
    assert darwin._platform == 'Darwin'


# Generated at 2022-06-22 23:42:06.602528
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:42:10.657520
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()

    assert obj.platform == 'Darwin'
    assert obj._fact_class._platform == 'Darwin'
    assert issubclass(obj._fact_class, GenericBsdIfconfigNetwork) is True

# Generated at 2022-06-22 23:42:15.315810
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    unit test for DarwinNetwork constructor. See https://docs.python.org/2/library/unittest.html
    """
    macNetwork = DarwinNetwork()
    assert macNetwork.platform == 'Darwin'
    assert macNetwork.media_select == ''
    assert macNetwork.media_type == ''
    assert macNetwork.media_options == ''



# Generated at 2022-06-22 23:42:18.100647
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    actual = DarwinNetwork({})
    assert 'GenericBsdIfconfigNetwork' in str(actual)

# Generated at 2022-06-22 23:42:28.575425
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork(None, None)

    test_if = {}
    test_obj.parse_media_line(['media:', '1000baseTX', '(Jabber)'], test_if, None)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == '1000baseTX'
    assert test_if['media_type'] == 'Jabber'
    assert test_if['media_options'] == None

    test_if = {}
    test_obj.parse_media_line(['media:', 'auto', '(1000baseTX<full-duplex>)'], test_if, None)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'auto'

# Generated at 2022-06-22 23:42:32.576265
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for constructor of class DarwinNetwork.
    """
    darwin_obj = DarwinNetwork()
    assert isinstance(darwin_obj, DarwinNetwork)


# Generated at 2022-06-22 23:42:40.145053
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    print('Test DarwinNetwork.parse_media_line with unknown type')
    w = ['media:', '<unknown', 'type>', 'status:', 'active']
    ifconfig_data = {'interfaces': {'en0': {}}}
    test_object = DarwinNetwork(ifconfig_data)
    test_object.parse_media_line(w, ifconfig_data['interfaces']['en0'], None)
    expected_media_select = 'Unknown'
    expected_media_type = 'unknown type'
    assert ifconfig_data['interfaces']['en0']['media_select'] == expected_media_select
    assert ifconfig_data['interfaces']['en0']['media_type'] == expected_media_type

    print('Test DarwinNetwork.parse_media_line with full data')


# Generated at 2022-06-22 23:42:40.900350
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:42:42.640889
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-22 23:42:45.017963
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-22 23:42:46.974894
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == DarwinNetworkCollector._platform
    assert obj._fact_class == DarwinNetworkCollector._fact_class

# Generated at 2022-06-22 23:42:49.679535
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert(isinstance(dnc, DarwinNetworkCollector))

# Generated at 2022-06-22 23:43:00.947028
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {'media': 'Unknown',
                 'media_select': 'autoselect',
                 'media_type': '100BaseTX',
                 'media_options': ['full-duplex', '100baseTX-FD']}
    words = ['media:', 'autoselect', '(100baseTX)', 'full-duplex,', '100baseTX-FD']
    DarwinNetwork().parse_media_line(words, interface, None)
    assert interface == {'media': 'Unknown',
                        'media_select': 'autoselect',
                        'media_type': '100BaseTX',
                        'media_options': ['full-duplex', '100baseTX-FD']}


# Generated at 2022-06-22 23:43:02.352287
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'
    assert DarwinNetwork().platform == 'Darwin'


# Generated at 2022-06-22 23:43:05.373079
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'

# Generated at 2022-06-22 23:43:12.180115
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_n = DarwinNetwork('net0')
    darwin_n.parse_media_line(['media:', '<unknown', 'type>'], {}, [])
    assert darwin_n.facts['interfaces']['net0']['media_select'] == 'Unknown'
    assert darwin_n.facts['interfaces']['net0']['media_type'] == 'unknown type'


# Generated at 2022-06-22 23:43:12.943003
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'



# Generated at 2022-06-22 23:43:13.615746
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector != None

# Generated at 2022-06-22 23:43:24.473427
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_darwin_network = DarwinNetwork()
    assert my_darwin_network.platform == 'Darwin'
    assert my_darwin_network.name == 'DarwinNetwork'
    assert my_darwin_network.media_regexp == r'media: .*'
    assert my_darwin_network.mediaopt_regexp == r'media: .* status: .*'
    assert my_darwin_network.status_regexp == r'^\s*status: .*'
    assert my_darwin_network.flags_regexp == r'^\s*flags=.*'
    assert my_darwin_network.mpls_regexp is None


# Generated at 2022-06-22 23:43:27.299115
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    f = DarwinNetworkCollector()

    assert f.get_facts() is None
    assert f._fact_class is not None
    assert f._platform is not None

# Generated at 2022-06-22 23:43:39.012178
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'media': {}}
    # Not sure why this is used but we need to provide it to call the method
    ips = [{'address': '1.2.3.4'}]
    # Test the media line that is used in the json facts
    # This is used in the json facts created by the darwin fact collection
    # that is copied from the bsd facts to see what data is in this field
    dn.parse_media_line(['media:', 'autoselect', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == {}

# Generated at 2022-06-22 23:43:40.682856
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:43:42.883195
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Testing for class DarwinNetwork

# Generated at 2022-06-22 23:43:44.398841
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:43:54.570503
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:43:57.309612
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collect = DarwinNetworkCollector()
    assert collect.platform == 'Darwin'


# Generated at 2022-06-22 23:44:01.668920
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = {}
    darwin_net.parse_media_line(['media:','<unknown','type>'], current_if, {})
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:02.001764
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:03.288364
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork(None)
    assert 'Darwin' in obj.platform

# Generated at 2022-06-22 23:44:05.845574
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Note: This is a pseudo test.
    # All it ensures is that the class can successfully be constructed.
    # All the real initialisation and testing is done by the super class.
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:07.519790
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinnet = DarwinNetwork()

    # Make sure that platform is Darwin
    assert darwinnet.platform == 'Darwin'

# Generated at 2022-06-22 23:44:08.769586
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module is not None


# Generated at 2022-06-22 23:44:10.285344
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test DarwinNetworkCollector constructor"""
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-22 23:44:21.876205
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test DarwinNetwork class
    assert DarwinNetwork.platform == 'Darwin'
    assert DarwinNetwork.ipv4_dev_regex == r'(?:interface )?(?P<interface>\S*):\s+flags=.*?<(?P<inet_flags>[\S ]*)>\s+mtu (?P<mtu>\d+)'
    assert DarwinNetwork.ipv6_dev_regex == r'(?:interface )?(?P<interface>\S*):\s+flags=.*?<(?P<inet6_flags>[\S ]*)>\s+mtu (?P<mtu>\d+)'

# Generated at 2022-06-22 23:44:22.311514
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
     DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:23.632766
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_object = DarwinNetwork()
    assert test_object.platform == 'Darwin'


# Generated at 2022-06-22 23:44:25.641070
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test object constructor"""
    data = DarwinNetwork()
    assert data.platform == 'Darwin'

# Generated at 2022-06-22 23:44:30.632580
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    # Create a NetworkCollector object
    DarwinNetworkCollector.setup_platform_subclass()

    # initialize
    DarwinNetworkCollector.init()

    # check it is of the correct class
    assert isinstance(DarwinNetworkCollector.fact_class(), DarwinNetwork)

# Generated at 2022-06-22 23:44:36.301676
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.parse_media_line(['media:', 'autoselect', '(<unknown type>)'], {}, [])
    assert dn.ifconfig_info['media_select'] == 'autoselect'
    assert dn.ifconfig_info['media'] == 'Unknown'
    assert dn.ifconfig_info['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:37.814226
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class == DarwinNetwork
    assert collector._platform == 'Darwin'

# Generated at 2022-06-22 23:44:38.645360
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:39.530113
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    foo = DarwinNetwork()
    assert foo is not None

# Generated at 2022-06-22 23:44:41.231034
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:44:41.805358
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:48.710604
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', '']
    current_if = {}
    ips = ''
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert 'Unknown' == current_if['media_select']
    assert 'unknown type' == current_if['media_type']
    assert 'Unknown' == current_if['media']

# Generated at 2022-06-22 23:45:00.386191
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    # test media select without type and without options
    words = 'media: autoselect'.split()
    DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if
    del current_if
    del ips
    # test media select with a type and without options
    current_if = {}
    ips = {}
    words = 'media: autoselect (1000baseT)'.split()
    DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media']

# Generated at 2022-06-22 23:45:12.544594
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.parse_media_line(['media:', '1-Gigabit', '<unknown type>'], {}, {}) == {'media': 'Unknown', 'media_select': '1-Gigabit', 'media_type': 'unknown type'}
    assert dn.parse_media_line(['media:', '10baseT/UTP', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': '10baseT/UTP', 'media_type': '(none)'}

# Generated at 2022-06-22 23:45:14.702952
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test DarwinNetworkCollector"""
    (dnc) = DarwinNetworkCollector()
    print(dnc)

# Generated at 2022-06-22 23:45:21.730482
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}
    ips = []
    words = ['', '<unknown', 'type>']
    result = network.parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == 'unknown type'
    words = ['', 'Connected', '<unknown type>']
    result = network.parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_select'] == 'Connected'
    words = ['', 'Connected', '<unknown type>', '"Duplex Full"']
    result = network.parse_media_line(words, current_if, ips)