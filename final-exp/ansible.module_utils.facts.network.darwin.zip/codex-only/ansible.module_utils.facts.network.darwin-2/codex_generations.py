

# Generated at 2022-06-22 23:35:24.189300
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    networks = DarwinNetwork(None)
    test_data = {
        'media_line': ['media:', 'autoselect', '100baseTX'],
        'expected_dict': {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX', 'media_options': ''},
    }
    result = networks.parse_media_line(test_data['media_line'], {}, {})
    assert result == test_data['expected_dict']


if __name__ == '__main__':
    test_DarwinNetwork_parse_media_line()

# Generated at 2022-06-22 23:35:35.303760
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print('test_DarwinNetwork')
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-22 23:35:37.386078
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == 'Darwin'

# Generated at 2022-06-22 23:35:48.048534
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = []
    words = ['media:', 'auto', '(none)', 'status:', 'inactive']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == {}

    current_if = {}
    ips = []
    words = ['media:', 'auto', '(1000baseT)', 'status:', 'inactive']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
   

# Generated at 2022-06-22 23:35:54.308536
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.media_regexp == (r'^\s*media: (?P<media_select>[\w\d-]+)(?P<media_type>[a-z0-9\s-]+)?.*mediaopt: (?P<media_options>[a-z0-9\s-]+)?.*$')

# Generated at 2022-06-22 23:35:59.828096
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    line = "    media: <unknown type> <unknown subtype>".split()
    dn.parse_media_line(line, {}, [])
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == "Unknown"

# Generated at 2022-06-22 23:36:00.398769
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:05.622185
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', '<unknown type>'], {}, {})
    result = ('Unknown', 'unknown type')
    assert (ifc.current_if['media_select'], ifc.current_if['media_type']) == result

# Generated at 2022-06-22 23:36:14.704153
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_cases = [
        {
            "current_if": {},
            "line": "media: autoselect status: active",
            "expected": {
                "media": "Unknown",
                "media_select": "autoselect",
                "media_type": "status:",
                "media_options": "active",
            }
        },
        {
            "current_if": {},
            "line": "media: autoselect",
            "expected": {
                "media": "Unknown",
                "media_select": "autoselect",
            }
        },
    ]
    for test_case in test_cases:
        generic_obj = DarwinNetwork()
        generic_obj.parse_media_line(test_case["line"].split(), test_case["current_if"], {})

# Generated at 2022-06-22 23:36:25.154637
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'media': 'media',
                  'media_select': 'media_select',
                  'media_type': 'media_type',
                  'media_options': 'media_options'}
    words = ['media', 'Selector', 'Command', '<Link', 'duplex>']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Selector'
    assert current_if['media_type'] == 'Link'
    assert current_if['media_options'] == 'duplex'
    words = ['media', 'Selector', 'Command', '<unknown', 'type>']

# Generated at 2022-06-22 23:36:26.376309
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork('/sbin/ifconfig')


# Generated at 2022-06-22 23:36:37.554484
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == 'Darwin'
    assert darwin.use_ipv6 == True
    assert darwin.route6_path == ''
    assert darwin.route6_file == 'netstat_fib_inet6.txt'    #darwin specific
    assert darwin.route_path == ''
    assert darwin.route_file == 'netstat_fib_inet.txt'      #darwin specific
    assert darwin.interface_path == ''
    assert darwin.interface_file == 'ifconfig_em0.txt'       #darwin specific
    assert darwin.ping_path == '/sbin/ping'
    assert darwin.ping_count == 2
    assert darwin.ping_options == '-c'
   

# Generated at 2022-06-22 23:36:40.531115
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test DarwinNetwork class constructor
    """
    # Values for checking
    p1 = 'Darwin'
    p2 = '/sbin/ifconfig'
    p3 = 'lo0'

    # Create object
    network = DarwinNetwork()

    # Compare result with original value
    assert network.platform == p1
    assert network.ifconfig_path == p2
    assert network.lo_interface == p3

# Generated at 2022-06-22 23:36:41.099910
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:36:42.514270
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:36:43.055202
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:43.574738
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:47.531846
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == "Darwin"
    assert d.facts == {}
    assert d.interfaces == {}


# Generated at 2022-06-22 23:36:51.655617
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ DarwinNetworkCollector(module) constructor test """
    mocked_module = {
    }
    obj = DarwinNetworkCollector(mocked_module)
    assert obj.__class__.__name__ == "DarwinNetworkCollector"


# Generated at 2022-06-22 23:37:00.035145
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    sample_interface_dict = {'macaddress': 'c8:2a:14:22:01:b6',
                             'mtu': '1500', 'type': 'Ethernet',
                             'description': 'Wi-Fi', 'active': True,
                             'macaddress_driver': 'c8:2a:14:22:01:b6',
                             'media': 'Unknown', 'media_select': 'autoselect',
                             'media_options': 'none', 'media_status': 'active',
                             'media_type': 'supported', 'media_capabilities': 'Ethernet',
                             'mtu_ipv6': '1500', 'mediasize': '10M',
                             'carrier_delay': '1', 'hwassist': 'TCP-Checksum-RX'}

# Generated at 2022-06-22 23:37:01.712397
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj._fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:37:04.020905
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_obj = DarwinNetwork()
    assert my_obj.platform == 'Darwin'


# Generated at 2022-06-22 23:37:06.740556
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_network = DarwinNetwork()
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    mac_network.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-22 23:37:18.632170
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    DN = DarwinNetwork({}, {})

    # Test 1: default FreeBSD output 'media: Ethernet autoselect (100baseTX <full-duplex>)'
    words = ['media:', 'Ethernet', 'autoselect', '(100baseTX', '<full-duplex>)']
    current_if = {}
    ips = {}
    DN.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == 'autoselect'
    assert current_if['media_options'] == ['100baseTX', 'full-duplex']

    # Test 2: MacOSX output

# Generated at 2022-06-22 23:37:21.474713
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:37:22.864969
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_obj = DarwinNetwork()
    assert isinstance(network_obj, DarwinNetwork)

# Generated at 2022-06-22 23:37:25.161099
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj._fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:37:33.893874
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line_part_5 = ['media', 'auto', 'select']
    current_if = dict()
    ips = dict()
    # Call the method being tested
    DarwinNetwork().parse_media_line(media_line_part_5, current_if, ips)
    # Assert that the expected values for the current_if dict are set
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'select'
    assert current_if['media_options'] == None

    media_line_part_5 = ['media', '100baseTX', '(100baseTX', 'full-duplex)']
    # Call the method being tested

# Generated at 2022-06-22 23:37:43.436757
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = ['media:', 'autoselect', '<unknown type>']
    DarwinNetwork.parse_media_line(None, words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

    current_if = dict()
    words1 = ['media:', 'autoselect', '10baseT/UTP']
    DarwinNetwork.parse_media_line(None, words1, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '10baseT/UTP'

    current_

# Generated at 2022-06-22 23:37:45.375456
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork(dict())
    assert (net is not None)

# Generated at 2022-06-22 23:37:47.504986
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
  obj = DarwinNetworkCollector()
  assert isinstance(obj, NetworkCollector)


# Generated at 2022-06-22 23:37:48.877182
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:37:50.850914
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnw = DarwinNetwork()
    assert dnw.platform == 'Darwin'



# Generated at 2022-06-22 23:37:57.432720
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'device': 'bridge0'}

    # test bridge interface
    words = ['unknown', '<unknown', 'type>']
    DarwinNetwork().parse_media_line(words, test_if, {})
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == list()
    assert test_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:38:01.982486
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Check that we can generate a new DarwinNetworkCollector object
    dnc=DarwinNetworkCollector()
    # assert that the object is not None
    assert dnc is not None
    # Check that we have created a DarwinNetworkCollector object
    assert isinstance(dnc,DarwinNetworkCollector)



# Generated at 2022-06-22 23:38:09.597386
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line_1 = ['media:', '<unknown type>', 'full-duplex,', '1000baseT', '(flow-control,', 'asym-pause)']
    media_line_2 = ['media:', 'autoselect']
    media_line_3 = ['media:', '10baseT', '/', 'UTP']

    iface = {'device': 'bridge0', 'media_options': ''}
    DarwinNetwork.parse_media_line(media_line_1, iface, None)
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'
    assert iface['media_options'] == 'full-duplex, 1000baseT (flow-control, asym-pause)'


# Generated at 2022-06-22 23:38:16.474201
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line = ["media:", "--", "status:", "active"]
    current_if = {}
    ips = {}
    darwin = DarwinNetwork()
    darwin.parse_media_line(test_line, current_if, ips)
    assert current_if['media_select'] == '--'
    assert current_if['media_type'] == 'status:'
    assert current_if['media_options'] == {}



# Generated at 2022-06-22 23:38:19.693983
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
     This method unit tests the DarwinNetworkCollector constructor
    """
    assert DarwinNetworkCollector._fact_class is DarwinNetwork
    assert DarwinNetworkCollector._platform is 'Darwin'

# Generated at 2022-06-22 23:38:23.473293
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dictionary = {}

    # Test parsing of lines like this:
    # media: autoselect (<unknown type>)
    words = ['media:','autoselect','(<unknown','type>)']

# Generated at 2022-06-22 23:38:27.549074
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert isinstance(DarwinNetworkCollector(None, None), DarwinNetworkCollector)


# Generated at 2022-06-22 23:38:29.141648
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()


# Generated at 2022-06-22 23:38:30.083729
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collec = DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:31.873821
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:38:33.664744
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({},{},{},{})
    assert repr(dn)

# Generated at 2022-06-22 23:38:39.418852
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test DarwinNetwork object creation
    DarwinNetwork_object = DarwinNetwork()
    # Unit test for method get_default_interface
    assert DarwinNetwork_object.get_default_interface() == 'en0', 'Unit test failed'
    # Unit test for method get_files
    assert DarwinNetwork_object.get_files() == ['/sbin/ifconfig', '/usr/sbin/ifconfig'], 'Unit test failed'
    # Unit test for method platform
    assert DarwinNetwork_object.platform == 'Darwin', 'Unit test failed'


# Generated at 2022-06-22 23:38:43.011561
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetworkCollector = DarwinNetworkCollector()
    assert darwinNetworkCollector._fact_class == DarwinNetwork
    assert darwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:38:44.873018
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    dn = DarwinNetwork()
    
    assert dn is not None


# Generated at 2022-06-22 23:38:52.406391
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # class instantiation
    darwin_network = DarwinNetwork()

    # get_device_values
    device_data = {}
    device_data['media_select'] = '0x0001'
    device_data['media_options'] = 'none'
    device_data['media_type'] = '10baseT/UTP'
    device_data['media_status'] = 'active'
    device_data['media'] = 'Unknown'
    assert darwin_network.get_device_values(device_data) == \
        dict(status='up', type='ether', duplex='', speed=0)

# Generated at 2022-06-22 23:38:55.119495
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor test of this DarwinNetwork class
    """
    assert DarwinNetwork is not None

# Generated at 2022-06-22 23:38:58.951226
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn
    assert dn.platform == 'Darwin'
    assert dn.interfaces == []
    assert dn.facts == {}
    assert dn.ifconfig == {}


# Generated at 2022-06-22 23:39:07.481192
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    iface = DarwinNetwork()
    iface.populate()
    assert iface.data['interfaces']['lo0'] == {
        'active': True,
        'device': 'lo0',
        'mtu': 16384,
        'promisc': False,
        'type': 'Loopback',
        'up': True,
        'macaddress': '00:00:00:00:00:00',
        'capabilities': {'tx-udld-off': True,
                         'tx-flow-control-off': True,
                         'tx-pause-off': True,
                         'tx-zero-copy-off': True,
                         'tx-tso-off': True}}

# Generated at 2022-06-22 23:39:08.358129
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:16.791338
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Verify parsing of media line of output of ifconfig command for Mac OSX
    Expected behavior: For a line split by spaces and
    '>' or '<' or ',': the first word to be in 'media_select',
    the word between '>', '<' or ',' to be in 'media_type', and
    remaining words (if any) to be in 'media_options'
    """
    test = DarwinNetworkCollector()
    test_line = '100baseTX <full-duplex,flow-control>'
    test_if = dict()
    test.parse_media_line(test_line.split(), test_if, dict())
    assert test_if['media_select'] == '100baseTX'
    assert test_if['media_type'] == 'full-duplex,flow-control'
   

# Generated at 2022-06-22 23:39:21.122107
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    linux = DarwinNetworkCollector()
    assert isinstance(linux, NetworkCollector)
    assert isinstance(linux, DarwinNetworkCollector)
    assert isinstance(linux.get_facts(), DarwinNetwork)

# Generated at 2022-06-22 23:39:23.729859
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit tests for DarwinNetworkCollector() class"""
    collect_obj = DarwinNetworkCollector()
    assert isinstance(collect_obj, DarwinNetworkCollector)

# Generated at 2022-06-22 23:39:25.755355
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, NetworkCollector)


# Generated at 2022-06-22 23:39:27.607351
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dwn = DarwinNetwork({})
    assert dwn.platform == 'Darwin'

# Generated at 2022-06-22 23:39:33.022326
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    print(darwin.get_facts()['all_ipv4_addresses'])
    print(darwin.get_facts()['default_ipv4']['address'])

# Generated at 2022-06-22 23:39:39.434167
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinnet = DarwinNetwork()
    assert darwinnet._platform == 'Darwin', "Platform is incorrect"
    assert darwinnet.parse_media_line(["media:", "autoselect", "<unknown type>", "status:active"], {}, {}) == {'media': 'Unknown', 'media_options': None, 'media_select': 'autoselect', 'media_type': 'unknown type'}, "Media line parsing is incorrect"


# Generated at 2022-06-22 23:39:40.819046
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert(dn.media_freebsd_re == DarwinNetwork.media_freebsd_re)

# Generated at 2022-06-22 23:39:43.547222
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test instantiating this class
    # test DarwinNetwork class exists
    DarwinNet = DarwinNetwork()
    assert DarwinNet.platform == "Darwin"



# Generated at 2022-06-22 23:39:44.093856
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:47.317040
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    test the constructor of DarwinNetwork
    """

    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'



# Generated at 2022-06-22 23:39:58.410358
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # INPUTS
    test_if = {}
    test_ip = {}
    test_type = {}
    test_words = {}
    # OUTPUTS
    expected_if = {}
    # INPUTS - Set up inputs
    # TEST 1 - Test with a known value
    test_if['en2'] = test_ip
    test_words['en2'] = ['en2:', 'media:', '<unknown', 'type>', 'status:', 'inactive']
    # OUTPUTS - Set up outputs
    expected_if['en2'] = {'media': 'Unknown', 'media_select': 'media:', 'media_type': 'unknown type'}
    # RUN CODE

# Generated at 2022-06-22 23:40:09.829520
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    # Test normal output
    dn.parse_media_line(['media:', 'media_select', 'media_type', 'media_options'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    assert current_if['media_options'] == 'media_options'
    # Test output that occurs if bridge
    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current

# Generated at 2022-06-22 23:40:14.091026
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect()['lo0']['macaddress'] == '00:00:00:00:00:00'

# Generated at 2022-06-22 23:40:15.889670
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:40:17.643352
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    f = DarwinNetwork()
    assert f.platform == 'Darwin'
    assert f.media_re() == '(\S+)'

# Generated at 2022-06-22 23:40:18.146173
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:21.168741
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    darwin_network_collector = DarwinNetworkCollector()
    darwin_network_collector.collect()
    darwin_network_collector.get_device_data()

# Generated at 2022-06-22 23:40:23.825920
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    '''Unit tests for DarwinNetworkCollector()'''
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-22 23:40:35.423324
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_case = [
        (
            ['media:', '<unknown', 'type>', 'status:', 'inactive', 'type:'], 
            {'media_select': '<unknown', 'media_type': 'unknown type'}
        ),
        (
            ['media:', 'autoselect', '(1000baseT)', 'status:', 'inactive', 'type:'], 
            {'media_select': 'autoselect', 'media_type': '1000baseT'}
        ),
        (
            ['media:', '10baseT/UTP', '(10baseT/UTP)', 'status:', 'inactive', 'type:'], 
            {'media_select': '10baseT/UTP', 'media_type': '10baseT/UTP'}
        )
    ]

    d

# Generated at 2022-06-22 23:40:45.518962
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test get_interfaces
    darwin_test = DarwinNetwork()
    darwin_test.get_interfaces()

    # Test parse_ifconfig_output
    darwin_test.interfaces = {}
    darwin_test.parse_ifconfig_output(map(lambda x: x.strip(), darwin_test.ifconfig_paths.split(' ')))

    ansible_facts = darwin_test.populate()
    assert ansible_facts['ansible_all_ipv4_addresses']
    assert ansible_facts['ansible_default_ipv4']['address']
    assert ansible_facts['ansible_default_ipv4']['alias']
    assert ansible_facts['ansible_default_ipv4']['broadcast']
    assert ansible_

# Generated at 2022-06-22 23:40:53.669299
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instance of DarwinNetwork
    obj = DarwinNetwork()
    # Create dict to pass to parse_media_line method
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = {}
    # Call parse_media_line method with dict and dict as argument
    obj.parse_media_line(words, current_if, ips)
    # Assert that the result is as expected
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == {}

# Generated at 2022-06-22 23:40:54.674252
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:58.157542
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Instantiate DarwinNetworkCollector
    """
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:41:00.211051
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructor test for class DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:11.163637
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    # without media_type
    words = ['en2:', 'autoselect', '(unknown)' ]
    result = DarwinNetwork().parse_media_line(words, current_if, [])
    assert result == {'media': 'Unknown', 'media_select':'autoselect', 'media_type': '(unknown)'}

    # with media_type
    words = ['en2:', 'autoselect', 'no carrier', '<none>']
    result = DarwinNetwork().parse_media_line(words, current_if, [])
    assert result == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'no carrier', 'media_options': '<none>'}

# Generated at 2022-06-22 23:41:20.723991
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    foo = DarwinNetwork()
    current_if = {}
    ips = {}
    words = ['media:', 'autoselect', '(none)']
    foo.parse_media_line(words, current_if, ips)
    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_options'] == ('none',)
    assert current_if['media_type'] is None
    current_if = {}
    ips = {}
    words = ['media:', '<unknown', 'type>']
    foo.parse_media_line(words, current_if, ips)
    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == "Unknown"

# Generated at 2022-06-22 23:41:22.680291
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__doc__ == NetworkCollector.__doc__

# Generated at 2022-06-22 23:41:29.400124
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type> <unknown> status: inactive'
    ifconfig = DarwinNetwork()
    ifconfig.parse_media_line(line.split(), {}, {})
    assert ifconfig._current_if['media'] == 'Unknown'
    assert ifconfig._current_if['media_select'] == 'Unknown'
    assert ifconfig._current_if['media_type'] == 'unknown type'
    assert ifconfig._current_if['media_options'] == 'unknown'

# Generated at 2022-06-22 23:41:33.432543
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'
    assert net.media_line_re == '(?P<media_select>media:)\s*(?P<media_type>[^\s]+)\s*(?P<media_options>(?:options\:[^\s]+\s*)+)?'

# Generated at 2022-06-22 23:41:37.007832
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = DarwinNetwork()
    line = 'media: <unknown type>'
    data.parse_media_line(line.split(), {}, {})
    assert 'Unknown' == data.interfaces['media']
    assert 'Unknown' == data.interfaces['media_select']
    assert 'unknown type' == data.interfaces['media_type']

# Generated at 2022-06-22 23:41:42.618571
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Initialize DarwinNetworkCollector object
    darwinnc = DarwinNetworkCollector()
    # Assert that the class name is DarwinNetworkCollector
    assert darwinnc.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-22 23:41:47.693101
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    This is the unit test for method parse_media_line of class DarwinNetwork
    """
    dn = DarwinNetwork()
    current_if = {}
    # Test with media_type
    words = ["media:", "autoselect", "(none)", "status:", "inactive"]
    result = dn.parse_media_line(words, current_if, None)
    expected_result = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none'}
    assert result == expected_result

# Generated at 2022-06-22 23:41:49.833667
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector.platform == 'Darwin'
    assert net_collector._fact_class == DarwinNetwork
    assert net_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:41:55.508909
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:42:02.994914
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    actual = DarwinNetwork(
        module=MockNetworkModule(),
        collected_facts={},
        args=dict()
    )
    actual.collect()
    assert actual.facts['all_ipv4_addresses'] == ['10.0.0.1', '10.0.0.1']
    assert actual.facts['all_ipv6_addresses'] == ['fe80::4c4d:32ff:fef4:9d78', 'fe80::4c4d:32ff:fef4:9d78']

# Generated at 2022-06-22 23:42:12.394178
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This is the test for DarwinNetwork
    """
    darwin_network_instance = DarwinNetwork()
    assert darwin_network_instance.platform == 'Darwin'
    assert darwin_network_instance.exclude == ['lo0', 'gif*', 'stf*']
    assert darwin_network_instance.exclude_ifconfig_bridge
    assert darwin_network_instance.exclude_ifconfig_bond
    assert darwin_network_instance.ipv6_capable_interfaces == set()
    assert darwin_network_instance.data == {}

# Generated at 2022-06-22 23:42:13.883358
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dwn = DarwinNetwork()
    assert dwn.platform == 'Darwin'

# Generated at 2022-06-22 23:42:15.013015
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:16.638757
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network
    assert darwin_network._platform == 'Darwin'

# Generated at 2022-06-22 23:42:25.682019
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_interfaces = {'lo0': {'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'hwaddr': '00:00:00:00:00:00', 'inet': ['127.0.0.1', 'fe80::1'], 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'Ethernet', 'media_options': ['none'], 'mtu': 16384, 'type': 'loopback'}}
    assert DarwinNetwork(None).populate() == darwin_interfaces

# Generated at 2022-06-22 23:42:27.652054
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test to instantiate class DarwinNetworkCollector
    """
    assert DarwinNetworkCollector() is not None

# Generated at 2022-06-22 23:42:28.333282
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork()

# Generated at 2022-06-22 23:42:31.858675
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:42:34.290162
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Validate DarwinNetworkCollector class constructor"""
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    cm = DarwinNetworkCollector(module=module)
    assert cm.platform == 'Darwin'

# Generated at 2022-06-22 23:42:46.592990
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork('eth0')
    test_ifconfig_output = {
        'eth0': """media: <unknown type> (none)
status: active
lladdr: 52:54:00:12:34:56""",

        'eth1': """media: <unknown type> (none)
status: active
lladdr: 52:54:00:12:34:56""",
        }

# Generated at 2022-06-22 23:42:55.070499
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    a_dict = {}
    d_dict = {}
    d_dict['media'] = 'Unknown'
    d_dict['media_select'] = 'autoselect'
    d_dict['media_type'] = 'status: inactive'
    d_dict['media_options'] = 'none'
    DarwinNetwork._parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], a_dict)
    assert a_dict == d_dict


# Generated at 2022-06-22 23:42:58.183359
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class is not None
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:43:01.663072
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _fact_class = DarwinNetworkCollector()._fact_class
    assert 'Darwin' == _fact_class.platform
    assert 'Unknown' == _fact_class.get_default_interface().get('macaddress')
# end of test_DarwinNetworkCollector


# Generated at 2022-06-22 23:43:05.125494
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork(None, None)

    assert isinstance(d, DarwinNetwork)

    assert d.collector == 'Darwin'


# Generated at 2022-06-22 23:43:15.511002
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of class DarwinNetwork
    darwin_network = DarwinNetwork()
    # test with no option
    words = ['media:', '<unknown', 'type>']
    current_if = {}
    darwin_network.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

    # test with option
    words = ['media:', 'autoselect', '(100baseTX', '<full-duplex>)']
    current_if = {}
    darwin_network.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:43:18.032465
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    m = DarwinNetwork()
    assert m.lines[0] == 'Please read darwin_network.py - it is empty'


# Generated at 2022-06-22 23:43:21.947470
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert isinstance(dn.facts, dict)
    assert dn.facts == {}


# Generated at 2022-06-22 23:43:33.432894
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:43:44.950304
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork = NetworkCollector._fact_class()
    # parameters for the parse_media_line() method
    test_mac_media_line1 = "media: <unknown type> status: inactive"
    test_mac_media_line2 = "media: autoselect (1000baseT <full-duplex>) status: active"
    words1 = test_mac_media_line1.split()
    words2 = test_mac_media_line2.split()
    current_if = {}
    ips = {}
    current_if, ips = DarwinNetwork.parse_media_line(words1, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'

# Generated at 2022-06-22 23:43:46.273866
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:55.323156
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    current_if['media'] = '10baseT/UTP'
    current_if['media_select'] = '10baseT/UTP'
    current_if['media_type'] = '10baseT/UTP'
    current_if['media_options'] = []

    words = ['media:', '10baseT/UTP', '(100baseTX <full-duplex>)']
    DarwinNetwork().parse_media_line(words, current_if)
    assert current_if['media_select'] == '10baseT/UTP'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == ['full-duplex']

    words = ['media:', '<unknown type>']
    DarwinNetwork().parse_media_line

# Generated at 2022-06-22 23:44:05.576991
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from collections import namedtuple
    from ansible.module_utils.facts.network import ifconfig_result
    #import pdb; pdb.set_trace()
    words = ['media:', 'none', 'status:', 'inactive']
    media_line = "media: none status: inactive"
    current_if = {}
    ips = []
    mac_net = DarwinNetwork({})
    mac_net.parse_media_line(words, current_if, ips)
    assert(current_if['media']                == 'Unknown')
    assert(current_if['media_select']         == 'none')
    assert(current_if['media_type']           == '')
    assert(current_if['media_options']        == {})
    assert(current_if['media_options_string'] == '')
   

# Generated at 2022-06-22 23:44:07.284392
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dwn = DarwinNetwork()
    assert dwn.platform == 'Darwin'


# Generated at 2022-06-22 23:44:14.661271
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifacenetwork = DarwinNetwork()
    test_iface = {}
    test_iface['media'] = ''
    test_iface['media_select'] = ''
    test_iface['media_type'] = ''
    test_iface['media_options'] = ''
    media_line_array = ['media:', 'autoselect', '<unknown', 'type>']
    ifacenetwork.parse_media_line(media_line_array, test_iface, [])
    assert test_iface['media'] == 'Unknown'
    assert test_iface['media_select'] == 'autoselect'
    assert test_iface['media_type'] == 'unknown type'
    assert test_iface['media_options'] == ''

# Generated at 2022-06-22 23:44:25.126163
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:44:28.049979
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    m = DarwinNetwork()
    assert IPv4Obj.re_addr.match('127.0.0.1')


# Generated at 2022-06-22 23:44:35.474370
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'auto', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = {}
    exp_current_if = {'media': 'Unknown', 'media_select': 'auto', 'media_type': '(none)', 'media_options': []}
    darwin_net = DarwinNetwork()
    darwin_net.parse_media_line(words, current_if, ips)
    assert exp_current_if == current_if

# Generated at 2022-06-22 23:44:46.024037
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['', '<unknown', 'type>']
    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    del current_if['media_select']
    del current_if['media_type']
    assert current_if == {}
    words = ['', 'autoselect', '(none)', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, ips)
    assert current_if == {}
    words = ['media:', 'autoselect', '(100baseTX', '<full-duplex>)', 'status:', 'active']

# Generated at 2022-06-22 23:44:51.775200
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["media:", "<unknown", "type>"]
    current_if = {}
    ips = {}
    data = DarwinNetwork()
    data.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:53.975392
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor test for class DarwinNetwork
    """
    my_network = DarwinNetwork()
    for (test_key,test_value) in my_network.facts.items():
        assert test_key in my_network.__dict__, test_key
        assert my_network.__dict__[test_key] == test_value, my_network.__dict__[test_key]

# Generated at 2022-06-22 23:45:00.878830
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    t_DarwinNetwork = DarwinNetwork()
    result = t_DarwinNetwork.parse_media_line(['media:', '<unknown type>'], {}, {})
    assert 'media' in result
    assert result['media'] == 'Unknown'
    assert 'media_type' in result
    assert result['media_type'] == 'unknown type'
    assert 'media_select' in result
    assert result['media_select'] == 'Unknown'

# Generated at 2022-06-22 23:45:08.247401
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive', 'supports', 'auto-speed']
    current_if = {}
    ips = []
    darwinnw = DarwinNetwork(None)

    darwinnw.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type'

# Generated at 2022-06-22 23:45:17.615000
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for class DarwinNetworkCollector"""

    assert DarwinNetworkCollector.__doc__
    assert DarwinNetworkCollector._platform
    assert DarwinNetworkCollector._fact_class
    assert DarwinNetworkCollector.collect
    assert DarwinNetworkCollector.get_facts
    assert DarwinNetworkCollector.get_interfaces
    assert DarwinNetworkCollector.get_bond_interfaces
    assert DarwinNetworkCollector.get_bridge_interfaces
    assert DarwinNetworkCollector.get_default_interface
    assert DarwinNetworkCollector.get_by_interface
    assert DarwinNetworkCollector.get_facts_from_facts
