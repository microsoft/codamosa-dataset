

# Generated at 2022-06-22 23:35:30.702943
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    default_words = ['media:', '<unknown type>', '(none)', '(none)']
    # Test with default words
    dwn = DarwinNetwork()
    current_if = {}
    ips = {}

    dwn.parse_media_line(default_words, current_if, ips)

    # Test for correct return
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

    # Test with different words
    custom_words = ['media:', 'autoselect', '(1000baseT', 'full-duplex,flowcontrol)']
    current_if = {}
    ips = {}


# Generated at 2022-06-22 23:35:33.257386
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()

    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'


# Generated at 2022-06-22 23:35:34.378658
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:35:36.319075
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_nw = DarwinNetwork()
    assert darwin_nw.platform == 'Darwin'



# Generated at 2022-06-22 23:35:42.066089
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This test verifies the DarwinNetworkCollector class constructor
    """
    print("test_DarwinNetworkCollector:")
    darwin = DarwinNetworkCollector()

    print()


# Execute unit tests if executed directly
if __name__ == '__main__':
    test_darwin = test_DarwinNetworkCollector()
    # print(test_darwin)

# Generated at 2022-06-22 23:35:44.072645
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:35:49.755245
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnw = DarwinNetwork()
    dnw.populate()
    interfaces = dnw.interfaces()
    interface_list = dnw.get_interface_list()
    # check if all of them are present in the interface list
    assert all(x in interface_list for x in interfaces.keys())
    assert isinstance(dnw.interface_capabilities(), dict)

# Generated at 2022-06-22 23:35:58.504461
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create an instance of DarwinNetwork class
    darwin_network = DarwinNetwork()

    # Check that the instance is of DarwinNetwork class
    assert isinstance(darwin_network, DarwinNetwork)

    # Call the function that gets the interface name
    darwin_network.get_interface_name(
        'status: active\naddress: 172.16.10.12\np2p: p2p0\n\nstatus: inactive\naddress: 0.0.0.0\n')

    # Check the value of current_if dict
    assert darwin_network.current_if == {'status': 'inactive', 'address': '0.0.0.0'}

    # Call the function that gets the mac address

# Generated at 2022-06-22 23:36:09.035677
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Unit test for class DarwinNetworkCollector
    """
    obj_facts_network = DarwinNetworkCollector(module=None,
                                               command_line_value=None,
                                               gather_subset=["min"],
                                               gather_network_resources=None,
                                               init_on_load=True,
                                               ansible_facts_module=None,
                                               network_resources_fact_name="ansible_network_resources",
                                               min_values_root_key=None,
                                               add_local_interfaces=True,
                                               local_interface_fact_name="ansible_local",
                                               network_resources_resource_exclusion=[])

    assert obj_facts_network is not None

# Generated at 2022-06-22 23:36:10.491576
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_obj = DarwinNetwork(None, None, None)
    assert my_obj

# Generated at 2022-06-22 23:36:11.679177
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    "Test the constructor of the class DarwinNetworkCollector"
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:36:16.209537
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test the default constructor of DarwinNetwork
    objDN = DarwinNetwork()
    assert objDN.platform == 'Darwin'
    assert objDN.ifconfig_path == "/sbin/ifconfig"


# Generated at 2022-06-22 23:36:25.953693
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    class_object = DarwinNetwork()
    assert class_object.platform == 'Darwin'
    assert class_object.media_regexp == r'^\s(\d+|<unknown type>)\s+([A-Za-z0-9]+[A-Za-z0-9\-]*\s*[0-9]+[A-Za-z0-9\-]*|none)\s+(.*)$'
    assert class_object.inet_regexp == r'^\s+inet\s+(.*)$'
    assert class_object.inet6_regexp == r'^\s+inet6\s+(.*)$'
    assert class_object.options_regexp == r'^\s+options\s+(.*)$'
    assert class_object.ether_regexp

# Generated at 2022-06-22 23:36:33.138812
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_iface = DarwinNetwork()
    test_iface._interfaces['test_iface'] = {'test_iface': 'test_iface'}
    test_iface.parse_media_line(['media:', 'manual', '100baseTX', '(100baseTX)'], 'test_iface', None)
    assert test_iface._interfaces['test_iface']['media'] == 'Unknown'
    assert test_iface._interfaces['test_iface']['media_select'] == 'manual'
    assert test_iface._interfaces['test_iface']['media_type'] == '100baseTX'
    assert test_iface._interfaces['test_iface']['media_options'] == ['100baseTX']

# Generated at 2022-06-22 23:36:37.364724
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test creation of DarwinNetwork class
    """
    dwn = DarwinNetwork()
    assert dwn != None
    assert isinstance(dwn, DarwinNetwork)
    assert dwn._platform == 'Darwin'
    assert dwn._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:36:40.208233
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector.platform == 'Darwin'
    assert net_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:36:46.866559
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'media': 'Unknown', 'media_select': 'autoselect', \
                 'media_type': 'none', 'media_options': [] }
    test_line = 'media autoselect None'
    test_if = DarwinNetwork()
    # pass empty list [] rather than None
    test_if.parse_media_line(test_line.split(), {}, [] )
    assert test_if['media'] == test_dict['media']
    assert test_if['media_select'] == test_dict['media_select']
    assert test_if['media_type'] == test_dict['media_type']
    assert test_if['media_options'] == test_dict['media_options']

# Generated at 2022-06-22 23:36:53.998819
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Object creation
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    # Function calls
    dn.get_options('some text')
    dn.parse_media_line(['media', 'type', 'media_type', 'media_options'], {'_ansible_lo': 'some text'}, {})
    dn.parse_line(['mac1', 'mac2', 'mac3', 'mac4'])
    # TODO: add unit tests for public methods

# Generated at 2022-06-22 23:37:00.422734
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Set up the input to the method
    current_if = {'interface': 'en0'}
    media_line = ['media:', 'autoselect', '<unknown', 'type>']
    ips = 'ipv4'
    # Create the object and call the method
    net_obj = DarwinNetwork()
    net_obj.parse_media_line(media_line, current_if, ips)
    # Check the results
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:37:02.542036
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network._fact_class.platform == 'Darwin'
    assert network._platform == 'Darwin'

# Generated at 2022-06-22 23:37:04.397512
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    device = DarwinNetwork()
    assert device.platform == 'Darwin'

# Generated at 2022-06-22 23:37:11.087864
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instance of DarwinNetwork for test
    test_inst = DarwinNetwork()

    # line1 is a valid media line
    line1 = "media: autoselect (<unknown type>)"
    words1 = line1.split()
    current_if = dict()
    ips = list()
    test_inst.parse_media_line(words1, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

    # line2 is a valid media line
    line2 = "media: autoselect (100baseTX <full-duplex>)"
    words2 = line2.split()
    current_if = dict()
    ips = list()

# Generated at 2022-06-22 23:37:18.762468
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork({})
    dn.parse_media_line(['media:', 'autoselect', '(none)'],
                        {'media': None, 'media_select': None, 'media_type': None, 'media_options': None},
                        {})
    assert dn.interfaces['media'] == 'Unknown'
    assert dn.interfaces['media_select'] == 'autoselect'
    assert dn.interfaces['media_type'] == '(none)'
    assert dn.interfaces['media_options'] == {}

# Generated at 2022-06-22 23:37:29.739425
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': '', 'media_options': '', 'media_select': '', 'media_type': ''}
    ips = {'ipv4': [], 'ipv6': []}
    words = ['media', 'autoselect', 'status:', 'active']
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'active'
    assert current_if['media_options'] == 'status:'
    current_if = {'media': '', 'media_options': '', 'media_select': '', 'media_type': ''}
    words = ['media', '<unknown', 'type>']

# Generated at 2022-06-22 23:37:38.127343
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This test case is used to test the constructor of the class
    DarwinNetworkCollector and its initial variables.
    :return: Nothing
    """
    module = ansible_module_mock()
    darwin_collector = DarwinNetworkCollector(module=module)

    assert darwin_collector._name == 'Darwin'
    assert darwin_collector._platform == 'Darwin'
    assert darwin_collector._fact_class == DarwinNetwork
    assert darwin_collector._module == module
    assert darwin_collector._facts == {}
    assert darwin_collector._data == {}

# Generated at 2022-06-22 23:37:42.492538
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    line1 = 'media: autoselect (none)'
    words1 = line1.split()
    current_if1 = {'name': 'bridge0'}
    ips1 = None
    d.parse_media_line(words1, current_if1, ips1)
    assert current_if1['media'] ==  'Unknown'
    assert current_if1['media_select'] ==  'autoselect'
    assert current_if1['media_type'] ==  'none'
    assert current_if1['media_options'] ==  None

    line2 = 'media: <unknown type> (0xffff)'
    words2 = line2.split()
    current_if2 = {'name': 'bridge0'}
    ips2 = None
    d.parse_media_

# Generated at 2022-06-22 23:37:48.821338
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # create an instance of DarwinNetworkCollector
    obj = DarwinNetworkCollector()
    assert obj._platform == "Darwin"
    assert obj._fact_class.__name__ == "DarwinNetwork"
    assert obj._fact_class.platform == "Darwin"
    assert obj._fact_class.__module__ == "ansible.module_utils.facts.network.darwin"

# Generated at 2022-06-22 23:37:59.658401
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['foo', '1000baseT', '(None)']
    current_if = {}
    ips = []
    generic_bsd_ifconfig_network = DarwinNetwork()
    generic_bsd_ifconfig_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1000baseT'
    assert not current_if.get('media_type')
    assert not current_if.get('media_options')

    words = ['foo', '<unknown', 'type>']
    current_if = {}
    ips = []
    generic_bsd_ifconfig_network = DarwinNetwork()
    generic_bsd_ifconfig_network.parse_media_line(words, current_if, ips)


# Generated at 2022-06-22 23:38:05.420473
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'
    assert darwin_net.media_line_regex == \
        '/^\s+media:\s+(.+)/'
    assert darwin_net.media_type_regex == \
        "/^\s+(?:media\s+)?(\S+)\s+media\s+type:\s+(.+)/"

# Generated at 2022-06-22 23:38:11.419863
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for a usual media_line
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:', 'autoselect', '10baseT/UTP', '(<unknown type>)'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == '(<unknown type>)'

    # Test for a media_line with only media_select
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:', 'autoselect'], current_if, None)

# Generated at 2022-06-22 23:38:20.721834
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    dn = DarwinNetwork()

    words = ["media:", 'autoselect', '(none)', '<unknown type>']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

    current_if = {}
    ips = {}
    dn = DarwinNetwork()
    words = ["media:", '40baseT', '<unknown type>', 'full-duplex']
    dn.parse_media_line(words, current_if, ips)

# Generated at 2022-06-22 23:38:22.887506
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:38:24.930908
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)


# Generated at 2022-06-22 23:38:27.239690
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj._fact_class, DarwinNetwork)
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:38:29.238314
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetworkCollector().get_facts()['ansible_network_resources'], DarwinNetwork)

# Generated at 2022-06-22 23:38:30.559150
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector constructor
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:32.865491
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector.platform == 'Darwin'


# Generated at 2022-06-22 23:38:38.754687
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    current_if = dict()
    ips = dict()
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'inactive']
    current_if = dict()
    ips = dict()
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:38:50.631867
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # most_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    # media_unknown_type = ['media:', '<unknown', 'type>', 'status:', 'active']
    media = ['media:', '10BaseT/UTP']
    current_if = dict()

    # test1 = DarwinNetwork._parse_media_line(most_words, current_if)
    # assert test1['media'] == 'Unknown'
    # assert test1['media_select'] == 'autoselect'
    # assert test1['media_type'] == '(none)'

    # test2 = DarwinNetwork._parse_media_line(media_unknown_type, current_if)
    # assert test2['media'] == 'Unknown'
    # assert test2['media_select'] == 'Unknown

# Generated at 2022-06-22 23:38:51.185803
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:51.914907
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:54.110190
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect() == DarwinNetworkCollector._fact_class(DarwinNetworkCollector._platform).populate()

# Generated at 2022-06-22 23:39:05.068835
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Check that constructor attributes are set correctly
    """
    # Check initialisation of DarwinNetwork class
    my_obj = DarwinNetwork()
    assert my_obj.platform == 'Darwin'
    assert my_obj.media_regexp == GenericBsdIfconfigNetwork.media_regexp
    assert my_obj.flags_regexp == GenericBsdIfconfigNetwork.flags_regexp
    assert my_obj.macaddr_regexp == GenericBsdIfconfigNetwork.macaddr_regexp
    assert my_obj.inet_regexp == GenericBsdIfconfigNetwork.inet_regexp
    assert my_obj.naddr_regexp == GenericBsdIfconfigNetwork.naddr_regexp
    assert my_obj.inet6_regexp == GenericBsdIfconfigNetwork.inet6_

# Generated at 2022-06-22 23:39:07.636465
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create an instance of class DarwinNetwork
    darwin_network = DarwinNetwork()
    # Check if instance is created correctly
    assert isinstance(darwin_network, DarwinNetwork) == True


# Generated at 2022-06-22 23:39:09.216465
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().platform == 'Darwin'


# Generated at 2022-06-22 23:39:10.097830
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test creation of DarwinNetwork class """
    DarwinNetwork()

# Generated at 2022-06-22 23:39:11.440706
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = {}
    DarwinNetwork(facts=facts)
    assert isinstance(facts['ansible_network_resources'], dict)

# Generated at 2022-06-22 23:39:19.044778
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:39:30.137177
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()

    # test media_select, media_type and media_options
    words = ['media:', 'autoselect', '(none)']
    ifc.parse_media_line(words, ifc.current_if, ifc.ips)
    assert ifc.current_if['media_select'] == 'autoselect'
    assert ifc.current_if['media_type'] == 'none'
    assert ifc.current_if['media_options'] == []

    # test media_type, media_options and media changed
    words = ['media:', '10baseT/UTP', '<link>']
    ifc.parse_media_line(words, ifc.current_if, ifc.ips)

# Generated at 2022-06-22 23:39:41.196119
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork('_ifconfig_path')
    assert obj._ifconfig_path == '_ifconfig_path'
    assert obj._platform == 'Darwin'
    assert obj._ifconfig_device_pattern == r'^(\S+)'
    assert obj._ifconfig_bridge_pattern == r'^(\S+)'
    assert obj._ifconfig_hw_pattern == r'^\s+ether (\S+)'
    assert obj._ifconfig_inet_pattern == r'^\s+inet\s+(\S+)'
    assert obj._ifconfig_inet6_pattern == r'^\s+inet6\s+(\S+)'
    assert obj._ifconfig_link_pattern == r'^\s+link\/\S+\s+(\S+)'
    assert obj._ifconfig_mask_pattern == r

# Generated at 2022-06-22 23:39:47.104017
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create instance of class DarwinNetwork
    instance = DarwinNetwork()
    # call method parse_media_line with all possible variations of media line
    instance.parse_media_line(['media:', 'autoselect', '(none)', 'status:', 'inactive'], {}, {})
    instance.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], {}, {})
    instance.parse_media_line(['media:', 'autoselect', 'unknown type', 'status:', 'inactive'], {}, {})
    instance.parse_media_line(['media:', 'autoselect', '(unknown type)', 'status:', 'inactive'], {}, {})

# Generated at 2022-06-22 23:39:53.147442
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type><unknown type> status: inactive'
    words = line.split()
    mac_network=DarwinNetwork(None)
    mac_network.parse_media_line(words, {}, {})
    assert mac_network.current_iface['media_select'] == 'Unknown'
    assert mac_network.current_iface['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:40:04.290167
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    words = ['', 'autoselect', '<unknown type>']
    darwin_network.parse_media_line(words, current_if, ips=None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

    current_if = {}
    words = ['', 'autoselect', '10baseT/UTP']
    darwin_network.parse_media_line(words, current_if, ips=None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:40:10.243793
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test the class constructor
    darwin_network = DarwinNetwork({})
    assert len(darwin_network.interfaces.keys()) > 0
    assert isinstance(darwin_network.interfaces.values()[0], dict)
    assert darwin_network.interfaces.values()[0]['if_type'] != ''
    assert darwin_network.interfaces.values()[0]['name'] != ''

# Generated at 2022-06-22 23:40:15.432177
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    ''' unit test for the DarwinNetworkCollector class '''
    from ansible.module_utils.facts.network import DarwinNetworkCollector

    darwin_net = DarwinNetworkCollector()
    assert isinstance(darwin_net, DarwinNetworkCollector)
    assert hasattr(darwin_net, '_cache_expiration')


# Generated at 2022-06-22 23:40:20.223498
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinnc = DarwinNetworkCollector()
    assert darwinnc.platform == 'Darwin'
    assert 'DarwinNetwork' in str(darwinnc.__class__)
    assert isinstance(darwinnc.platform, str)
    assert darwinnc._platform == 'Darwin'
    assert darwinnc._fact_class == DarwinNetwork
    assert isinstance(darwinnc._fact_class, type)


# Generated at 2022-06-22 23:40:21.556362
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:40:23.059840
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()

    assert module.platform == "Darwin"

# Generated at 2022-06-22 23:40:25.889221
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork
    assert isinstance(obj._fact_class, type)

# Generated at 2022-06-22 23:40:36.894501
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    data = {'lo0': {'flags': ['UP', 'LOOPBACK', 'RUNNING']}}

# Generated at 2022-06-22 23:40:44.848488
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    tests = []

    def test(n):
        f = DarwinNetworkCollector()
        assert(f.__class__.__name__ == 'DarwinNetworkCollector')
        assert(f._platform == 'Darwin')
        assert(f._fact_class.platform == 'Darwin')
    tests.append(test)

    def test_get_facts():
        f = DarwinNetworkCollector()
        result = f.get_facts()
        assert(result.__class__.__name__ == 'dict')
    tests.append(test_get_facts)

    for test in tests:
        test()



# Generated at 2022-06-22 23:40:45.917424
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Unit test to test DarwinNetworkCollector Constructor """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:47.572027
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:40:49.505291
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result.platform == "Darwin"


# Generated at 2022-06-22 23:41:01.202804
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Given
    dn = DarwinNetwork()

    # When
    test_media_lines = [
        ['media:', 'auto', '1000baseT', 'mediaopt', 'full-duplex'],  # media: auto 1000baseT mediaopt full-duplex
        ['media:', '<unknown', 'type>'],  # media: <unknown type>
        ['media:', 'auto', '1000baseT', 'mediaopt', 'full-duplex', 'aopt1', 'aopt2'],  # media: auto 1000baseT mediaopt full-duplex aopt1 aopt2
    ]


# Generated at 2022-06-22 23:41:08.094709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = [
        'media:',
        'autoselect',
        'status:',
        'active'
    ]
    current_if = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_options': [
            'status:',
            'active'
        ]
    }
    parsed_if = DarwinNetwork.parse_media_line(words)
    assert parsed_if == current_if

# Generated at 2022-06-22 23:41:10.436978
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork({}, {}, {}, {})
    assert n is not None


# Generated at 2022-06-22 23:41:19.867146
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # input to parse_media_line
    words = ['media:', '<unknown', 'type>', 'full-duplex']
    # output from parse_media_line
    current_if = {}
    ips = {}

    # set known values for attributes
    current_if['media'] = 'Unknown'
    current_if['media_select'] = words[1]
    current_if['media_type'] = words[2][1:-1]
    current_if['media_options'] = {'full-duplex': None}

    # run parse_media_line
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)

    # check the output
    assert current_if == current_if

# Generated at 2022-06-22 23:41:20.420306
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:26.916834
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    if_line = 'media: <unknown type>.'

    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    expected_result = {'media_select': 'Unknown',
                       'media_type': 'unknown type'}
    dn.parse_media_line(if_line.split(' '), current_if, ips)
    assert current_if == expected_result

# Generated at 2022-06-22 23:41:29.173791
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:41:34.512813
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    words = ['unknown', '<unknown type>']
    current_if = {}
    ips = {}
    obj.parse_media_line(words, current_if, ips)
    try:
        assert current_if['media_select'] == 'Unknown'
        assert current_if['media_type'] == 'unknown type'
    except AssertionError:
        print("Failed to parse media line")

# Generated at 2022-06-22 23:41:36.545403
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test that class constructs and gives proper object
    """
    darw = DarwinNetworkCollector()
    assert darw._platform == 'Darwin'

# Generated at 2022-06-22 23:41:48.492751
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {'name': 'en0'}
    ips = []
    d.parse_media_line(['media:', 'auto', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'none'
    d.parse_media_line(['media:', '<unknown type>'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    d.parse_media_line(['media:', 'autoselect'], current_if, ips)
   

# Generated at 2022-06-22 23:41:51.574356
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_obj = DarwinNetworkCollector(
        module=None,
        subcmds=None
    )
    assert darwin_network_obj._platform == 'Darwin'
    assert darwin_network_obj.platform == 'Darwin'
    assert darwin_network_obj._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:41:53.659115
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Constructor test
    module = DarwinNetwork()
    assert module.platform == 'Darwin'

# Generated at 2022-06-22 23:41:55.532165
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This will provide a docstring for this class
    """

# Generated at 2022-06-22 23:41:56.173004
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:07.846702
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:42:13.915422
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # create the instance
    darwin_network_collector = DarwinNetworkCollector()

    # check it's the correct instance
    assert isinstance(darwin_network_collector, NetworkCollector)
    assert isinstance(darwin_network_collector, DarwinNetworkCollector)

    # check the class variables
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:42:26.012264
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork('')

    # Test 1
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    dn.parse_media_line(words, current_if)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect'}

    # Test 2
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {'bsd_type': 'bridge'}
    dn.parse_media_line(words, current_if)
    assert current_if == {'bsd_type': 'bridge', 'media': 'Unknown', 'media_select': 'autoselect'}

    # Test 3

# Generated at 2022-06-22 23:42:26.871913
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:32.689997
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Unit test for constructor of class DarwinNetworkCollector"""
    module = type('',(object,),{'params':{'gather_subset':[]}})
    def get_module():
        return module
    DarNet = DarwinNetworkCollector(get_module)
    assert DarNet._platform == 'Darwin'


# Generated at 2022-06-22 23:42:36.123686
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    expected_result = {'description': 'en0', 'ifindex': 0, 'ipv4': [], 'macaddress': 'xx:xx:xx:xx:xx:xx'}
    result = DarwinNetwork('en0')
    assert result.ifinfo['en0'] == expected_result


# Generated at 2022-06-22 23:42:47.532684
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    x = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = []
    x.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    current_if = {}  # clear the dict
    words = ['media:', 'autoselect', '(none)', '(none)', '(none)', '(none)']
    x.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:42:49.793482
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    myObj = DarwinNetwork()
    myObj.get_facts()

# Generated at 2022-06-22 23:42:53.649868
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # check that the class could be initialized with provided platform
    facts = DarwinNetworkCollector(None, NetworkCollector._platform)
    assert facts._fact_class.__name__ == 'DarwinNetwork'
    assert facts._platform == 'Darwin'

# Generated at 2022-06-22 23:42:57.764106
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    mydarwinnw = DarwinNetworkCollector(None, None)
    assert mydarwinnw is not None
    assert mydarwinnw._fact_class is DarwinNetwork
    assert mydarwinnw._platform == 'Darwin'

# Generated at 2022-06-22 23:43:05.149580
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac = DarwinNetwork()

# Generated at 2022-06-22 23:43:07.869298
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None)

    assert obj.platform == "Darwin"
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:43:10.108529
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert (obj.platform == 'Darwin')

# Generated at 2022-06-22 23:43:13.117229
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ This method will instantiate the DarwinNetwork class
        and test the constructor.
    """
    # Create an instance of DarwinNetwork
    Darwin_net = DarwinNetwork({})

    # Here we check if instance was created successfully
    assert Darwin_net

# Generated at 2022-06-22 23:43:18.360448
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': None, 'media_select': None, 'media_options': None, 'media_type': None, 'device': None}
    line = "media: autoselect (<unknown type>)"
    words = line.split()
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '<unknown type>'
    assert current_if['media_options'] == {}


# Generated at 2022-06-22 23:43:21.750549
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector_obj = DarwinNetworkCollector()
    assert DarwinNetworkCollector._platform == 'Darwin'


# Generated at 2022-06-22 23:43:33.204188
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words_1 = ['media', 'auto', '(none)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words_1, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'auto', 'media_type': '(none)'}
    current_if = {}
    words_2 = ['media', 'auto', '1000baseT']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words_2, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'auto', 'media_type': '1000baseT'}
    current_if = {}
    words_3 = ['media', 'auto', '1000baseT', 'media_opt']
    DarwinNetwork.parse_media_line

# Generated at 2022-06-22 23:43:39.095973
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pylint: disable=protected-access
    ifn = DarwinNetwork()
    ifn.parse_media_line(['media:', '<unknown', 'type>'], {}, [])
    assert ifn.interfaces['media'] == 'Unknown'
    assert ifn.interfaces['media_select'] == 'Unknown'
    assert ifn.interfaces['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:43:43.732969
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    dn.populate()
    data = dn.data
    assert isinstance(data, dict)
    assert 'all_ipv4_addresses' in data
    assert 'all_ipv6_addresses' in data

# Generated at 2022-06-22 23:43:48.197166
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This test is meant to verify that get_collector() works correctly.
    It checks whether it returns a DarwinNetworkCollector.
    """
    assert DarwinNetworkCollector.get_collector(None, None) == DarwinNetworkCollector

# Generated at 2022-06-22 23:43:49.918983
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork(None)
    assert net
    assert isinstance(net, DarwinNetwork)


# Generated at 2022-06-22 23:43:53.507092
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a simple test to see if we can create a DarwinNetworkCollector
    instance and make it return the fact class it is supposed to return.
    This could be done without the test but in a test setup it is easier
    to test the constructor and its returned class.
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:54.887165
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == "Darwin"


# Generated at 2022-06-22 23:43:59.669664
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector("/usr/bin/ifconfig")
    assert collector.platform == "Darwin"
    assert collector._fact_class.platform == "Darwin"
    assert collector._platform == "Darwin"
    assert collector.command == "/usr/bin/ifconfig"

# Generated at 2022-06-22 23:44:01.355863
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork()
    assert facts.platform == 'Darwin'
    assert isinstance(facts, dict)

# Generated at 2022-06-22 23:44:02.667916
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc is not None

# Generated at 2022-06-22 23:44:10.370101
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from system_tests import collect_only
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.network.darwin import DarwinNetworkCollector

    data = collect_only(DarwinNetworkCollector)
    assert 'ansible_facts' in data

    # Unit test for DarwinNetworkCollector
    assert data['ansible_facts']['ansible_net_interfaces'] == Collector.fetch_file_lines(DarwinNetworkCollector._platform, DarwinNetworkCollector._fact_class, 'interfaces')
    assert data['ansible_facts']['ansible_net_all_ipv4_addresses'] == Collector.fetch_file_lines(DarwinNetworkCollector._platform, DarwinNetworkCollector._fact_class, 'all_ipv4_addresses')

# Generated at 2022-06-22 23:44:12.142522
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:44:13.840105
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test constructor of DarwinNetwork class """

    test_obj = DarwinNetwork()
    assert test_obj

# Generated at 2022-06-22 23:44:16.906251
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class.__name__ == 'DarwinNetwork'

# Generated at 2022-06-22 23:44:20.181951
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector('Darwin')

    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'


# Generated at 2022-06-22 23:44:22.158647
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ This will initialize the class and run any constructor test cases. """
    DarwinNetwork()


# Generated at 2022-06-22 23:44:33.539031
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = 'media: <unknown type> status: inactive'
    words = data.split()

    darwin_network = DarwinNetwork()
    current_if = {}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'

    # Parse a typical media line
    data = 'media: autoselect (none) status: inactive'
    words = data.split()

    darwin_network = DarwinNetwork()
    current_if = {}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)

    assert current

# Generated at 2022-06-22 23:44:41.382832
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:44:43.560286
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork()
    assert isinstance(facts, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:44:47.218256
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.command == 'ifconfig'

# Generated at 2022-06-22 23:44:58.862261
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import Network

    # Setup
    parser = DarwinNetwork()
    current_if = {'name': 'en0', 'state': '', 'enabled': True,
                  'macaddress': '', 'mtu': '', 'media': '',
                  'media_select': '', 'media_options': ''}
    interfaces = {}
    ips = {}

    # Test
    parser.parse_media_line(['media:', 'autoselect', '<unknown type>', '(none)'],
                            current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:45:08.147627
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = {
        'interval': 3,
        'mode': 'Autoselect',
        'options': {
            'autoselect': None,
            'full-duplex': None,
            'ieee80211': 'ht',
            'media': 'autoselect'
        },
        'up': True
    }
    media_line = 'media: <unknown type>'
    ips = {}

    result = darwin_net.parse_media_line(media_line.split(), current_if, ips)
    assert result == current_if

# Generated at 2022-06-22 23:45:09.466657
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork({})


# Generated at 2022-06-22 23:45:21.223603
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()

    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': []}

    #  media line with no media_options
    line = 'media: autoselect ()'
    words = line.split()
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == '' and current_if['media_select'] == 'autoselect' and current_if['media_type'] == '' and current_if['media_options'] == []

    # media line with media_options
    line = 'media: autoselect (1000baseT <full-duplex>)'
    words = line.split()