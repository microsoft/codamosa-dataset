

# Generated at 2022-06-22 23:35:28.563616
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    darwin_network_obj = DarwinNetwork()

    # test media_select only
    words = ['media:', 'autoselect']
    current_if = {}
    ips = []
    darwin_network_obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # test media_select and media_options
    words = ['media:', 'autoselect', 'media_type', 'media_options']
    current_if = {}
    ips = []
    dar

# Generated at 2022-06-22 23:35:35.665990
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_class = DarwinNetwork()
    current_if = {'active': False, 'device': 'p1p1', 'bmac': 'ee:ee:ee:ee:ee:ee', 'alias': 'p1p1', 'up': False, 'netmask': '255.255.255.0', 'ipv4': {}, 'ipv6': {}}
    words = ['inet', 'p1p1', 'media:', '<unknown', 'type>']
    network_class.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert not current_if['media_options']

# Generated at 2022-06-22 23:35:42.720972
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # GIVEN an instance of DarwinNetwork
    test_data = DarwinNetwork()

    # WHEN
    test_data.parse_media_line(['media:', '<unknown', 'type>'], {}, {})

    # THEN
    assert test_data.current_if['media'] == 'Unknown'
    assert test_data.current_if['media_select'] == 'Unknown'
    assert test_data.current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:35:44.027882
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    d = DarwinNetwork()

    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:35:47.093629
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    o = DarwinNetwork()
    assert o.platform == 'Darwin'
    assert o.get_default_interface() == 'lo0'
    assert o.get_interface('lo0')

# Generated at 2022-06-22 23:35:48.127697
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    unittest.main(DarwinNetwork)

# Generated at 2022-06-22 23:35:57.675878
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pylint: disable=line-too-long
    # Set up test data
    current_if = {}
    ips = {}
    # Test against expected results
    dn = DarwinNetwork()
    # Test against expected results
    result = dn.parse_media_line(['media:', 'autoselect', '(1000baseT)', 'status:', 'active'], current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(1000baseT)'}
    assert result == ['status:', 'active']
    current_if = {}

# Generated at 2022-06-22 23:36:02.505637
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector(None)
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == 'Darwin'
    assert network_collector._cache_file == '/etc/ansible/facts.d/network_Darwin.fact'

# Generated at 2022-06-22 23:36:05.490306
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork
    assert dnc._platform == 'Darwin'

# Generated at 2022-06-22 23:36:06.417280
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector


# Generated at 2022-06-22 23:36:07.131975
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:08.726613
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetwork(), DarwinNetwork)


# Generated at 2022-06-22 23:36:14.810816
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = 'en0'
    words = ['media:', 'autoselect', '(100baseTX)']
    current_if = dict()
    ips = dict()
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == dict()



# Generated at 2022-06-22 23:36:17.527028
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    try:
        assert DarwinNetwork is not None
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-22 23:36:18.170609
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:20.045901
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'
    assert network.parse_media_line

# Generated at 2022-06-22 23:36:28.815060
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # check media line with 4 elements
    words = ['media:', 'auto', '<unknown type>', 'status:', 'active']
    current_if = {}
    obj = DarwinNetwork()
    obj.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'unknown type'

    # check media line with 3 elements
    words = ['media:', 'auto', 'status:', 'active']
    current_if = {}
    obj = DarwinNetwork()
    obj.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'

# Generated at 2022-06-22 23:36:34.884678
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fact_network = DarwinNetwork('en0', [], [])
    fact_network.parse_media_line(['media:', 'autoselect', '<unknown type>'], {}, {})
    fact_network.parse_media_line(['en1:', 'autoselect', '100baseTX'], {}, {})
    fact_network.parse_media_line(['en0:', 'autoselect', '100baseTX', 'full-duplex'], {}, {})

    fact_network.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], {}, {})
    fact_network.parse_media_line(['media:', 'full-duplex', 'mediaopt', 'media:', 'full-duplex', '(none)'], {}, {})
    fact_

# Generated at 2022-06-22 23:36:44.850759
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network import DarwinNetwork as DarwinNetworkTest
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    obj = DarwinNetworkTest()
    # initialize vars to test method
    current_if = {}
    current_if['device'] = 'lo0'
    current_if['peer'] = None
    current_if['addresses'] = []
    current_if['media'] = ''
    current_if['media_select'] = ''
    current_if['media_type'] = ''
    current_if['media_options'] = []
    current_if['type'] = 'loopback'
    current_if['link'] = True

# Generated at 2022-06-22 23:36:48.898715
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    data_path = '/Users/foo/ansible/test/unit/module_utils/facts/network/test_darwin_ifconfig_data.txt'
    DarwinNetwork(data_path)

# Generated at 2022-06-22 23:36:51.748865
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()
    assert(darwinNetwork.platform == 'Darwin')
    assert(darwinNetwork.parser_class == 'bsd')



# Generated at 2022-06-22 23:36:53.483753
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:37:01.215141
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'status: active',
        'media_options': {}
    }
    module = DarwinNetwork()

    # test autoselect status active
    module.parse_media_line(['media:', 'autoselect', 'status:', 'active'], {}, [])
    assert module.current_if == test_data

    # test autoselect <unknown type>
    test_data['media_select'] = 'autoselect',
    test_data['media_type'] = '<unknown type>'
    module.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {}, [])
    assert module.current_if == test_data

    #

# Generated at 2022-06-22 23:37:10.057900
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

    # test parse_media_line method
    words = ['media', 'autoselect', '(none)']
    d.parse_media_line(words, {}, [])
    assert d.current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)'}

    words = ['media', 'autoselect', '(none)', 'mediaopt', 'options']
    d.parse_media_line(words, {}, [])
    assert d.current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': 'options'}


# Generated at 2022-06-22 23:37:21.472082
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test different line formats
    assert DarwinNetwork(None, None).parse_media_line(['media:', 'autoselect'], {}, {}) == dict(media_select='autoselect')
    assert DarwinNetwork(None, None).parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == dict(media='Unknown', media_select='Unknown', media_type='unknown type')
    assert DarwinNetwork(None, None).parse_media_line(['media:', 'autoselect', '(1000baseT'], {}, {}) == dict(media='Unknown', media_select='autoselect', media_type='1000baseT')

# Generated at 2022-06-22 23:37:26.693208
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for constructor of class DarwinNetworkCollector"""
    darwinnw = DarwinNetworkCollector()
    assert darwinnw._fact_class == DarwinNetwork
    assert darwinnw._platform == 'Darwin'
    assert darwinnw.platform == 'Darwin'
    assert isinstance(darwinnw.facts, dict)

# Generated at 2022-06-22 23:37:28.470201
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:37:35.143836
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    drw_network = DarwinNetwork()

    # test empty case
    words = []
    current_if = {}
    ips = {}
    drw_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if == {'media': 'Unknown'}

    # test unknown case
    words = ['<unknown', 'type>']
    current_if = {}
    ips = {}
    drw_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-22 23:37:37.918889
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dwn = DarwinNetwork()
    assert dwn
    assert dwn.platform == 'Darwin'

# Generated at 2022-06-22 23:37:41.487893
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test parsing of media line
    media_test_string = 'media: autoselect (<unknown type>)'
    words = media_test_string.split()
    interface_config = dict()
    ips = dict()
    net = DarwinNetwork()
    # check if the media line is parsed correctly
    net.parse_media_line(words, interface_config, ips)
    assert interface_config.get('media') == 'Unknown'
    assert interface_config.get('media_select') == 'autoselect'
    assert interface_config.get('media_type') == 'unknown type'
    assert interface_config.get('media_options') is None

# Generated at 2022-06-22 23:37:53.337929
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # setup
    d = DarwinNetwork()
    d.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    # check
    assert d.media_select == 'autoselect'
    assert d.media_type == '(none)'

    # setup
    d.parse_media_line(['media:', 'autoselect', '(1000baseT)'], {}, {})
    # check
    assert d.media_select == 'autoselect'
    assert d.media_type == '(1000baseT)'

    # setup
    d.parse_media_line(['media:', 'autoselect', '(100baseTX)'], {}, {})
    # check
    assert d.media_select == 'autoselect'
    assert d.media_type == '(100baseTX)'

   

# Generated at 2022-06-22 23:37:58.582261
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(None, words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:38:01.356075
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # when
    darwin_network = DarwinNetworkCollector()

    # then
    assert darwin_network.fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:38:09.261161
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    parsed_media_lines = DarwinNetwork({}).parse_media_line(['', 'not-autoselect', 'status:', 'active'], {}, {})
    assert parsed_media_lines['media'] == 'Unknown'
    assert parsed_media_lines['media_select'] == 'not-autoselect'
    assert parsed_media_lines['media_type'] == 'status:'
    assert parsed_media_lines['media_options'] == 'active'

    parsed_media_lines = DarwinNetwork({}).parse_media_line(['', '<unknown', 'type>'], {}, {})
    assert parsed_media_lines['media'] == 'Unknown'
    assert parsed_media_lines['media_select'] == 'Unknown'
    assert parsed_media_lines['media_type'] == 'unknown type'
    assert parsed_media

# Generated at 2022-06-22 23:38:19.587081
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # media line with unknown media type
    words = ['media:', 'autoselect', '<unknown>']
    current_if = {}
    current_if['media'] = 'Unknown'  # Mac does not give us this
    current_if['media_select'] = words[1]
    current_if['media_type'] = 'unknown type'
    current_if['media_options'] = {}
    # Instantiate DarwinNetwork
    darwinNetwork = DarwinNetwork()
    assert darwinNetwork.parse_media_line(words, current_if, None) == current_if

    # media line with known media type
    words = ['media:', 'autoselect', '(1000baseT)']
    current_if = {}
    current_if['media'] = 'Unknown'  # Mac does not give us this

# Generated at 2022-06-22 23:38:31.291451
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # This test verifies that the media line parameters are parsed correctly
    # when running the script
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    dn = DarwinNetwork()
    current_if = {}
    current_if['media_select'] = ''
    current_if['media_type'] = ''
    current_if['media_options'] = {}

    dn.parse_media_line(['media:', 'autoselect', '(none)'], current_if, '')
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == {}

    dn.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], current_if, '')

# Generated at 2022-06-22 23:38:40.181930
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # old test data
    #words = ['media:', 'auto', '(none)', 'status:', 'inactive']
    #current_if = {'media_select': '', 'media_type': ''}
    #media_options = ''
    # GenericBsdIfconfigNetwork.parse_media_line(self, words, current_if, media_options)
    #assert current_if['media'] == 'Unknown'
    #assert current_if['media_select'] == 'auto'
    #assert current_if['media_type'] == '(none)'

    current_if = {'media_select': '', 'media_type': ''}
    current_if['media'] = 'Unknown'  # this was added after the old test data was written
    # media line has no useful info

# Generated at 2022-06-22 23:38:40.714325
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:46.370830
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    collector = DarwinNetworkCollector()
    obj = collector.get_facts()
    assert obj.get_network_gather_subset() == ['!all', '!min']
    assert obj.get_network_gather_network_resources() == [
        'interfaces', 'defaults', 'config']

# Generated at 2022-06-22 23:38:46.958008
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetwork()

# Generated at 2022-06-22 23:38:50.300641
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    c = DarwinNetworkCollector()
    assert repr(c) == "<DarwinNetworkCollector: 'Darwin'>"
    assert type(c._fact_class) == DarwinNetwork
    assert c._fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:39:02.037304
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    d.parse_media_line(['media:','<unknown','type>'], {}, {})
    assert  d.ifconfig_lines[0]['media_select'] == 'Unknown'
    assert  d.ifconfig_lines[0]['media_type'] == 'unknown type'

    d.parse_media_line(['media:', 'autoselect', '100baseTX', 'full-duplex', 'mediaopt', 'mediaopt'], {}, {})
    assert  d.ifconfig_lines[1]['media_select'] == 'autoselect'
    assert  d.ifconfig_lines[1]['media_type'] == '100baseTX'
    assert  d.ifconfig_lines[1]['media_options'] == 'full-duplex mediaopt mediaopt'

    d

# Generated at 2022-06-22 23:39:03.374100
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), DarwinNetworkCollector)

# Generated at 2022-06-22 23:39:03.937403
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:06.293755
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector(None, None)
    assert dnc is not None
    assert dnc._fact_class is DarwinNetwork
    assert dnc._platform is "Darwin"

# Generated at 2022-06-22 23:39:14.261591
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'status: active\n'
    iface = {'name': 'lo0', 'hwaddr': '', 'inet': [], 'inet6': [], 'media': '', 'media_select': '', 'media_type': '', 'media_options': '', 'status': 'active'}
    iface = DarwinNetwork.parse_media_line(DarwinNetwork, line.split(), iface, None)
    assert iface['media_select'] == 'active'

    line = 'link: unknown\n'
    iface = DarwinNetwork.parse_media_line(DarwinNetwork, line.split(), iface, None)
    assert iface['media_select'] == 'unknown'

    line = 'link: none\n'

# Generated at 2022-06-22 23:39:15.014691
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    return DarwinNetworkCollector


# Generated at 2022-06-22 23:39:16.220201
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
   d = DarwinNetwork('lo0')
   assert d.name == 'lo0'
   assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:39:17.533432
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:39:29.328425
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinNetwork = DarwinNetwork()

    media_lines_truth = []
    media_lines_truth.append(['media', 'autoselect', 'status', 'inactive'])
    media_lines_truth.append(['media', 'autoselect', 'media', '<unknown type>'])
    media_lines_truth.append(['media', 'autoselect', 'media:', '<unknown type>'])
    media_lines_truth.append(['media', '100basetX', 'status', 'success'])
    media_lines_truth.append(['media', '100basetX', 'media:', '100baseTX <half-duplex>'])
    media_lines_truth.append(['media', '100basetX', 'media:', '100baseTX <full-duplex>'])
   

# Generated at 2022-06-22 23:39:32.969683
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector() ,DarwinNetworkCollector), 'DarwinNetworkCollector is not a DarwinNetworkCollector'

# Generated at 2022-06-22 23:39:39.729892
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    test_if = dict()
    test_ips = dict()
    mac.parse_media_line(words, test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert 'media_type' not in test_if
    assert 'media_options' not in test_if



# Generated at 2022-06-22 23:39:41.232982
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__.__name__ == "DarwinNetworkCollector"

# Generated at 2022-06-22 23:39:49.568798
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    current_if = {}
    ips = {}

    # checks for handling of unknown values
    words = ['media:', '<unknown', 'type>']
    darwin_if.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-22 23:39:55.827097
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    ips = []

    # Act
    DarwinNetwork().parse_media_line(words, current_if, ips)

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:40:07.176440
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = []

    # line 1
    words = "media: <unknown type>".split()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # line 2
    #Test that media is set to None when words is empty
    words = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:40:08.395743
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect()


# Generated at 2022-06-22 23:40:14.911373
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test class DarwinNetwork
    """
    network_class = DarwinNetwork
    obj_network = network_class()
    assert isinstance(obj_network, DarwinNetwork)
    assert isinstance(obj_network, GenericBsdIfconfigNetwork)
    assert obj_network.platform == 'Darwin'

# Generated at 2022-06-22 23:40:15.732613
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()



# Generated at 2022-06-22 23:40:23.575518
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:40:25.805502
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:40:36.849935
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create instance of DarwinNetwork
    darwin_network_obj = DarwinNetwork()

    # Test def parse_media_line
    # This is a private function so we test it via public function parse_interfaces
    current_if = {}
    ips = {}
    words = ['media:', '<unknown type>', 'full-duplex', '(1000baseT/full)']
    darwin_network_obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'unknown type'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

    words = ['media:', 'autoselect', '10baseT/UTP', '(none)']


# Generated at 2022-06-22 23:40:37.534772
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:44.973763
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collect = DarwinNetwork()
    if1 = {}
    media_line1 = 'media: <unknown type> status: inactive'
    if2 = {}
    media_line2 = 'media: none status: inactive'
    collect.parse_media_line(media_line1.split(), if1, [])
    collect.parse_media_line(media_line2.split(), if2, [])
    assert (if1['media_select'] == 'Unknown')
    assert (if1['media'] == 'Unknown')
    assert (if2['media'] == 'none')



# Generated at 2022-06-22 23:40:47.499299
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.platform == 'Darwin'
    assert darwin_network_collector.fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:40:49.419127
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    a = DarwinNetworkCollector(None, None, None)
    assert a.platform == "Darwin"

# Generated at 2022-06-22 23:40:52.219131
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == "Darwin"
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:41:03.630266
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_if = {}
    my_ips = []
    # splitting is different to FreeBSD
    # also, get_options needs to be mocked
    # and the media line is different to FreeBSD
    def mock_get_options(arg):
        return arg

    DarwinNetwork.get_options = mock_get_options

    DarwinNetwork.parse_media_line(['media:', 'autoselect', '(none)'], my_if, my_ips)
    assert my_if == {'media': 'Unknown', 'media_select': 'autoselect',
                     'media_type': 'none'}

    my_if = {}
    DarwinNetwork.parse_media_line(['media:', '<unknown', 'type>'], my_if, my_ips)

# Generated at 2022-06-22 23:41:05.458669
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork('fake_interface')
    assert n.interface == 'fake_interface'

# Generated at 2022-06-22 23:41:06.136353
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:07.901934
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetwork(None,None), DarwinNetwork)


# Generated at 2022-06-22 23:41:19.034995
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    correct_output = {'media': 'Unknown', 'media_select': '100baseTX', 'media_type': 'full-duplex', 'media_options': {'Jabber': None, 'flow-control': None, 'rxpause': None, 'txpause': None}}

    test_mac_media_line = '100baseTX full-duplex,flow-control,Jabber,rxpause,txpause'

    test_MacOSX_media_line = '<unknown type> full-duplex'

    darwin_network = DarwinNetwork()

    assert (correct_output == darwin_network.parse_media_line(test_mac_media_line.split(' '), {}, set()))

# Generated at 2022-06-22 23:41:30.640307
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # initialize the test
    darwin_network = DarwinNetwork('test_if')
    # initialize the expected results

# Generated at 2022-06-22 23:41:38.603393
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    darwin_network = DarwinNetwork()
    darwin_network.interfaces = {}
    # test case 1: media line with 2 words
    darwin_network.parse_media_line(
        ['media:', 'autoselect', '(none)'],
        darwin_network.current_if,
        darwin_network.ips
    )
    assert (darwin_network.current_if['media'] == 'Unknown')
    assert (darwin_network.current_if['media_select'] == 'autoselect')
    assert (darwin_network.current_if['media_type'] == '(none)')
    # test case 2: media line with 3 words

# Generated at 2022-06-22 23:41:39.537243
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:41.605770
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class is DarwinNetwork

# Generated at 2022-06-22 23:41:44.642204
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork(None)
    assert d.platform == "Darwin"
    assert d.ifconfig_path == "/sbin/ifconfig"
    assert d.route_path == "/sbin/route"

# Generated at 2022-06-22 23:41:46.900320
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    Unit test for constructor of class DarwinNetwork
    '''
    darwin_network = DarwinNetwork()
    assert isinstance(darwin_network, DarwinNetwork)

# Generated at 2022-06-22 23:41:53.511700
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    n = DarwinNetwork()
    n.parse_media_line(['media:', '<unknown type>'], {'ifname': 'en0'}, {})
    assert n._interfaces.get('en0').get('media') == 'Unknown'
    assert n._interfaces.get('en0').get('media_select') == 'Unknown'
    assert n._interfaces.get('en0').get('media_type') == 'unknown type'
    n = DarwinNetwork()
    n.parse_media_line(['media:', 'IEEE', '802.11', 'autoselect'], {'ifname': 'en0'}, {})

# Generated at 2022-06-22 23:42:05.055042
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # create an instance of DarwinNetwork
    dn = DarwinNetwork()

    # test a normal line
    from io import StringIO
    buf = StringIO('!1234')
    words = [buf.read(4)]
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1234'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # test a line with a media_type
    buf = StringIO('!1234<5678>')
    words = [buf.read(8)]
    current_if = {}
    ips = {}
    dn.parse_media_

# Generated at 2022-06-22 23:42:06.284232
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()



# Generated at 2022-06-22 23:42:08.482949
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'
    assert obj.gather_facts()


# Generated at 2022-06-22 23:42:17.533690
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    # Test with media line with all options
    words = ["media:", "autoselect", "(none)", "status:", "inactive"]
    result = darwin_network.parse_media_line(words, current_if, [])
    assert result == ({'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': 'status:inactive'}, {})
    # Test without media_type
    words = ["media:", "autoselect"]
    result = darwin_network.parse_media_line(words, current_if, [])

# Generated at 2022-06-22 23:42:20.162898
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    m = DarwinNetwork(None, None)

    assert m is not None
    assert m._platform == 'Darwin'
    assert m._packages == {}
    assert m._ifconfig == {}

    assert len(m._interfaces) == 0
    assert m._interfaces == {}
    assert m._interfaces_aliases == {}

    assert m._ipv4 == {}
    assert m._ipv6 == {}


# Generated at 2022-06-22 23:42:24.497840
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'



# Generated at 2022-06-22 23:42:29.893459
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    dict_in_ = {'media_options': None, 'media_type': 'unknown type', 'media_select': 'autoselect'}
    list_in_ = ['media:', 'autoselect', '<unknown', 'type>']
    d = DarwinNetwork()
    dict_out = d.parse_media_line(list_in_, dict_in_, None)
    assert dict_out == dict_in_


if __name__ == '__main__':
    test_DarwinNetwork_parse_media_line()

# Generated at 2022-06-22 23:42:38.933448
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if_before = {'media_options': None, 'media_select': None, 'media': None, 'media_type': None, 'media_speed': None}
    current_if_out = dict(current_if_before)
    words = ['media:', 'autoselect', '(none)']
    my_DarwinNetwork = DarwinNetwork()
    my_DarwinNetwork.parse_media_line(words, current_if_out, {})
    assert current_if_out == dict(current_if_before)
    words = ['media:', '<unknown', 'type>', '(none)']
    my_DarwinNetwork.parse_media_line(words, current_if_out, {})
    assert current_if_out['media'] == 'Unknown'

# Generated at 2022-06-22 23:42:45.149069
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This is a constructor test of the DarwinNetwork class
    """
    import sys
    import platform
    if sys.platform == 'darwin':
        darwin = DarwinNetwork()
        assert darwin.platform == platform.system()
        assert darwin.platform == 'Darwin'
    else:
        assert sys.platform == 'darwin'


# Generated at 2022-06-22 23:42:45.719134
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:48.529339
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Constructing DarwinNetworkCollector must set platform to Darwin """
    collector = DarwinNetworkCollector("ansible_network_resources")
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:42:51.324744
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert instance.platform == 'Darwin'


# Generated at 2022-06-22 23:42:56.093893
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector
    """

    darwin_network_collector = DarwinNetworkCollector()
    assert isinstance(darwin_network_collector, NetworkCollector)
    assert isinstance(darwin_network_collector.fact_class, DarwinNetworkCollector)

# Generated at 2022-06-22 23:42:58.052732
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for DarwinNetwork class"""
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'

# Generated at 2022-06-22 23:43:05.299261
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from ansible.module_utils.facts.network.darwin import DarwinNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import timeout

    def fake_run_commands():
        return [['Hello BSD', '', 0]]

    def fake_collect(self):
        return {'interfaces': {'lo0': {}} }

    fake_Facts = Facts({})
    fake_Facts.populate(timeout=1)
    fake_timeout = timeout.Timeout(1)

    darwin_network = DarwinNetworkCollector(fake_Facts, timeout=fake_timeout)
    darwin_network.run_commands = fake_run_commands
    darwin

# Generated at 2022-06-22 23:43:15.615316
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc_data = """en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
        options=10b<RXCSUM,TXCSUM,VLAN_HWTAGGING,AV>
        ether a0:99:9b:7e:18:26
        inet6 fe80::a299:9bff:fe7e:1826%en0 prefixlen 64 secured scopeid 0x4
        inet 192.168.0.7 netmask 0xffffff00 broadcast 192.168.0.255
        nd6 options=201<PERFORMNUD,DAD>
        media: <unknown type>
        status: active"""

    ifc = DarwinNetwork()
    ifc.lines = ifc_data.splitlines()
   

# Generated at 2022-06-22 23:43:19.302216
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    N = DarwinNetworkCollector({}, [], None)
    assert isinstance(N, DarwinNetwork)
    assert isinstance(N, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:43:30.785424
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:43:32.378433
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    print(obj)

# Generated at 2022-06-22 23:43:43.997332
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    d.parse_media_line(['media:', 'autoselect', '<unknown type>'], current_if, [])
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    d.parse_media_line(['media:', '<unknown', 'type>'], current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    d.parse_media_line(['media:', 'autoselect', '100baseTX', 'full-duplex'], current_if, [])
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:43:54.283179
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = dict()
    network.parse_media_line(['media:', '<unknown type>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

    # Test for bridge interface (see BUG 21064)
    network = DarwinNetwork()
    current_if = dict()
    network.parse_media_line(['media:', '<unknown', 'type>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-22 23:43:59.714497
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector.__name__ == 'DarwinNetworkCollector'
    assert DarwinNetworkCollector._network_provider == 'ifconfig'

# Generated at 2022-06-22 23:44:08.227730
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This test is to verify the DarwinNetworkCollector class is working as expected
    """
    from ansible.module_utils.facts.network.darwin import DarwinNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    # check that class exists
    assert DarwinNetworkCollector

    # check object is of the right class
    obj = DarwinNetworkCollector()
    assert isinstance(obj, NetworkCollector)

    # check the subclass of DarwinNetworkCollector
    assert issubclass(DarwinNetworkCollector, NetworkCollector)

    # check the super class of DarwinNetworkCollector
    assert issubclass(DarwinNetworkCollector, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:44:10.610571
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net1 = DarwinNetworkCollector()
    # Testing that the class was initialized correctly
    assert net1._fact_class.platform == 'Darwin'
    assert net1._platform == 'Darwin'

# Generated at 2022-06-22 23:44:15.691312
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = \
        {
            "media": "Unknown",
            "media_options": {
                "autoselect": "",
                "full-duplex": "",
                "running": ""
            },
            "media_select": "autoselect",
            "media_type": "Ethernet"
        }

    d = DarwinNetwork()
    current_if = {}
    words = ['media:', 'autoselect', '(Ethernet)', 'status:', 'active']
    d.parse_media_line(words, current_if, {})
    assert test_data == current_if

# Generated at 2022-06-22 23:44:25.663614
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    # Parse media line with a known media type
    words = ['media:', 'autoselect', 'WiFi']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'WiFi'
    # Parse media line with an unknown media type
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
   

# Generated at 2022-06-22 23:44:26.942769
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:44:28.816994
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:44:38.931729
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    parse_media_line = DarwinNetwork.parse_media_line
    current_if = {'name': 'en0', 'inet': ['192.168.1.1']}

    # testing media selection
    parse_media_line(['media:', 'autoselect', '(none)'], current_if, {})
    assert current_if['media_select'] == 'autoselect'
    assert not current_if.get('media_type')
    assert not current_if.get('media_options')

    # testing media type
    parse_media_line(['media:', 'autoselect', '(1000baseT)'], current_if, {})
    assert current_if['media_type'] == '1000baseT'

    # testing media options
    # note, 'media_options' is a list

# Generated at 2022-06-22 23:44:39.489729
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:40.803499
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ test class constructor """
    DarwinNetwork()

# Generated at 2022-06-22 23:44:41.755348
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetwork = DarwinNetworkCollector()


# Generated at 2022-06-22 23:44:53.709413
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # first test - a standard media line
    test_if = {
        'iface': 'en0',
        'ifname': 'en0',
        'hwaddr': '00:00:00:00:00:00'
    }
    test_ips = {
        'en0': {
            'ipv4': [],
            'ipv6': []
        }
    }
    test_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(test_words, test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == 'none'

# Generated at 2022-06-22 23:44:56.402912
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    Test constructoring of the class DarwinNetwork
    '''
    d = DarwinNetwork()
    assert d is not None

# Generated at 2022-06-22 23:45:05.281933
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.darwin import DarwinNetwork
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.facts import Facts

    test_class = DarwinNetwork(Facts({}))

    test_input = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = {}
    test_class.parse_media_line(test_input, current_if, ips)
    expected_output = {'media': 'Unknown',
                       'media_select': 'autoselect',
                       'media_type': '(none)'}
    assert current_if == expected_output

# Unit testing for DarwinNetworkCollector

# Generated at 2022-06-22 23:45:16.945731
# Unit test for constructor of class DarwinNetwork