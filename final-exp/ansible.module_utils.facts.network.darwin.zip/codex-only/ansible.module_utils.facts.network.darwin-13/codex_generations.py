

# Generated at 2022-06-22 23:35:15.112226
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:35:15.930047
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:35:27.826799
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = [ ('media: ', '', 'Unknown', '', ''),
                  ('media: autoselect (100baseTX <full-duplex>)',
                   'autoselect', '100baseTX', 'full-duplex', ''),
                  ('media: <unknown type>', '<unknown',
                   'unknown type', '', ''),
                  ('media: autoselect (<unknown type>,half-duplex)',
                   'autoselect', 'unknown type', '', 'half-duplex')]
    for data in test_data:
        line = data[0]
        current_if = dict()
        dn = DarwinNetwork()
        dn.parse_media_line(line.split(), current_if, None)
        assert current_if['media_select'] == data[1]

# Generated at 2022-06-22 23:35:32.535796
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # arrange
    words = ['media:', 'autoselect', '<unknown type>']
    current_if = {}
    ips = {}

    # act
    DarwinNetwork.parse_media_line(None, words, current_if, ips)

    # assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:35:44.113198
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:35:46.797030
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_obj = DarwinNetworkCollector()
    assert net_obj.platform == 'Darwin'
    assert net_obj._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:35:56.827252
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork()
    assert facts['all_ipv4_addresses'] == ['10.0.0.1', '10.0.0.2', '10.0.0.3', '192.168.1.2']
    assert facts['all_ipv6_addresses'] == ['fe80::6b0:42ff:fe6d:f6e1']
    assert facts['all_ipv6_addresses'] == ['fe80::6b0:42ff:fe6d:f6e1']
    assert facts['interfaces'] == ['lo0', 'gif0', 'stf0', 'en0', 'en1', 'en2', 'en3', 'en4', 'bridge0', 'p2p0']

# Generated at 2022-06-22 23:36:08.598482
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = NetworkCollector(None, None)._platform_data(None)

    current_if = {'name': 'lo0', 'type': 'Unknown', 'flags': 'UP,LOOPBACK'}
    words = ['media', 'fdx', '10Gbase-CR', 'mediaopt', 'txpause', 'mediaopt', 'rxpause']
    expected_if = {'name': 'lo0', 'type': 'Unknown', 'flags': 'UP,LOOPBACK',
                   'media': 'Unknown', 'media_select': 'fdx', 'media_type': '10Gbase-CR',
                   'media_options': 'txpause,rxpause'}

    DarwinNetwork().parse_media_line(words, current_if, data)
    assert current_if == expected_if


# Generated at 2022-06-22 23:36:11.166283
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    f = DarwinNetwork()
    assert isinstance(f, GenericBsdIfconfigNetwork)
    assert f.platform == 'Darwin'

# Generated at 2022-06-22 23:36:13.306165
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-22 23:36:17.527314
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    uut = DarwinNetwork()
    uut.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert('<unknown type>' == uut.current_if['media_select'])

# Generated at 2022-06-22 23:36:26.984240
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Unit test for constructor of class DarwinNetwork
    """
    # Test with valid mac address values

# Generated at 2022-06-22 23:36:33.769468
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(['media:', 'autoselect', '(1000baseSX)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(1000baseSX)'}
    assert darwin_network.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-22 23:36:35.626215
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    results = DarwinNetworkCollector()
    assert results._fact_class == DarwinNetwork
    assert results._platform == 'Darwin'

# Generated at 2022-06-22 23:36:45.293754
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    This tests the constructor of the DarwinNetwork class
    '''
    # Set up required dependencies for the DarwinNetwork class
    mock_module = type('', (), {'params': {'gather_network_resources': '', 'gather_subset': 'hardware'}})
    mock_module.params.get = lambda self, key: self[key]
    mock_module.params.get.__dict__ = mock_module.params
    mock_module.params['gather_network_resources'] = ['all']
    mock_module.run_command = lambda x, **kwargs: ('output', 'error')
    mock_module.fail_json = lambda x, **kwargs: False

    # Define the required data

# Generated at 2022-06-22 23:36:47.478847
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_fact = DarwinNetwork()
    assert network_fact


# Generated at 2022-06-22 23:36:57.743608
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    module = DarwinNetwork()
    iface = {'name': 'dummy_ifname'}

    # test default case
    module.parse_media_line(['media:', 'auto', '(none)'], iface, [])
    assert 'media_select' in iface
    assert iface['media_select'] == 'auto'
    assert 'media_type' in iface
    assert iface['media_type'] == '(none)'
    assert 'media_options' not in iface
    iface.clear()
    module.parse_media_line(['media:', '1000baseT', '(none)'], iface, [])
    assert 'media_select' in iface
    assert iface['media_select'] == '1000baseT'
    assert 'media_type' in iface

# Generated at 2022-06-22 23:37:01.888799
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d1 = DarwinNetwork()
    assert d1.facts['all_ipv4_addresses'] == None
    assert d1.facts['all_ipv6_addresses'] == None
    assert d1.facts['default_ipv4'] == {}
    assert d1.facts['default_ipv6'] == {}

# Generated at 2022-06-22 23:37:02.544597
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:10.632998
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Empty data, ifconfig command does not fail, no iface provided
    test_data = {
        'command_output': '',
        'ifname': '',
    }
    test_obj = DarwinNetwork(test_data)
    assert isinstance(test_obj, DarwinNetwork)


# Generated at 2022-06-22 23:37:21.659900
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    current_if = {'ifname': 'lo0'}
    darwin_net = DarwinNetwork({'network': {}})

    # media line is different to FreeBSD one
    words = ['<unknown type>', 'autoselect', '(none)']
    darwin_net.parse_media_line(words, current_if, None)
    assert current_if == {'ifname': 'lo0', 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': '(none)'}

    # media line is different to FreeBSD one
    words = ['<unknown type>', 'autoselect']
    darwin_net.parse_media_line(words, current_if, None)

# Generated at 2022-06-22 23:37:23.394357
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork('Darwin')
    assert obj
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-22 23:37:30.793225
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {'name': 'vboxnet0'}
    # Example output 'autoselect <unknown type>'
    words = ['autoselect', '<unknown', 'type>']
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:37:33.428851
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    obj.populate()
    assert 'lo0' in obj.facts['interfaces']


# Generated at 2022-06-22 23:37:38.280096
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class is DarwinNetwork
    assert obj._platform is DarwinNetwork.platform
    del obj


# Generated at 2022-06-22 23:37:41.703323
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork_instance = DarwinNetwork()
    assert DarwinNetwork_instance.collect_cmd == "ifconfig -a"
    assert DarwinNetwork_instance.platform == 'Darwin'
    assert DarwinNetwork_instance.interfaces == {}
    assert DarwinNetwork_instance._current_if == {}
    assert DarwinNetwork_instance.ifname == ''


# Generated at 2022-06-22 23:37:45.429138
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector
    """
    my_test = DarwinNetworkCollector()
    my_test.collect()
    my_test.get_facts()

# Generated at 2022-06-22 23:37:56.690989
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    drwin_network = DarwinNetwork()

    # Test the 'media line without type'
    test_data = ['media:', 'auto', 'status:', 'active']
    result = drwin_network.parse_media_line(test_data, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'auto'
    assert result['media_type'] is None

    # Test the 'media line with type'
    test_data = ['media:', 'auto', '(10baseT/UTP)']
    result = drwin_network.parse_media_line(test_data, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'auto'
    assert result['media_type'] == '10baseT/UTP'

# Generated at 2022-06-22 23:38:00.197908
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d
    assert d.platform == 'Darwin'
    assert d.primary_ip_interface is None
    assert d.primary_ipv4_interface is None
    assert d.primary_ipv6_interface is None

# Generated at 2022-06-22 23:38:08.752435
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector().collect()
    # Ensure we have gathered the correct data
    assert result['interfaces'] == ['lo0', 'gif0', 'stf0',
                                    'en0', 'en1', 'en2', 'en3',
                                    'fw0', 'bridge0', 'utun0']
    # Check we have all the correct keys for en1
    assert result['all_ipv4_addresses']['en1'] == ['fe80::fa1e:dfff:feaf:816c%en1']
    assert result['all_ipv6_addresses']['en1'] == ['24:65:11:af:81:6c']

# Generated at 2022-06-22 23:38:13.462958
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This method tests the constructor of the DarwinNetworkCollector class
    """
    # Base class constructor takes single parameter (self)
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:38:15.370073
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    #check initialization
    collector = DarwinNetwork()
    assert collector is not None


# Generated at 2022-06-22 23:38:16.333326
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect()

# Generated at 2022-06-22 23:38:23.374863
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Unit test for constructor of class DarwinNetworkCollector
    """
    print('Testing DarwinNetworkCollector')
    # Test constructor of class DarwinNetworkCollector
    # Result:
    #  DarwinNetworkCollector initialized
    DarwinNetworkCollector()
    print('Finished testing DarwinNetworkCollector')


if __name__ == "__main__":
    # Test DarwinNetworkCollector
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:26.733958
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Tests the constructor of the class DarwinNetwork.
    """
    module = DarwinNetwork()
    assert module._platform =="Darwin"
    assert module.platform =="Darwin"


# Generated at 2022-06-22 23:38:28.144203
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'


# Generated at 2022-06-22 23:38:38.047773
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    w1 = DarwinNetwork()
    test_data = dict()
    test_data['journaling'] = ['media:', 'Journaled', 'HFS+', '(Journaled', 'HFS+)']
    test_data['journaling_unknown'] = ['media:', 'Journaled', '<unknown', 'type>']
    test_data['journaling_no_type'] = ['media:', 'Journaled']

    for test in test_data:
        result = dict()
        w1.parse_media_line(test_data[test], result, dict())
        assert result['media'] == 'Unknown'
        assert result['media_select'] == 'Journaled'
        if test == 'journaling':
            assert result['media_type'] == 'HFS+'

# Generated at 2022-06-22 23:38:38.529742
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:50.500429
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d.platform == 'Darwin'
    fact = d.collect()
    assert fact.get('default_ipv4').cidr == '8.8.4.4/32'
    assert fact.get('default_ipv4').interface == 'en0'
    assert fact.get('default_ipv6').cidr == 'fe80::e9d6:9bff:feb6:8a6a/64'
    assert fact.get('default_ipv6').interface == 'en0'
    assert fact.get('interfaces') == ['en0', 'en1', 'en2', 'en3', 'en4', 'en5', 'en6', 'en7', 'en8', 'en9', 'bridge0', 'gif0']
    assert fact.get

# Generated at 2022-06-22 23:38:57.366942
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    x = DarwinNetwork([])
    assert x.data['all_ipv4_addresses'] == []
    assert x.data['all_ipv6_addresses'] == []
    assert x.data['default_ipv4'] == {}
    assert x.data['default_ipv6'] == {}
    assert x.data['interfaces'] == {}
    assert x.data['local'] == []

# Generated at 2022-06-22 23:39:07.038108
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ Unit test for method parse_media_line of class DarwinNetwork """

    # Test case: Unknown media type
    # Expected output:
    #   "media": "Unknown", "media_select": "autoselect", "media_type": "unknown type"
    test_case = ["media: <unknown type>"]
    expected = {"media": "Unknown", "media_select": "autoselect", "media_type": "unknown type"}
    test_obj = DarwinNetwork()
    current_if = {}
    ips = []
    test_obj.parse_media_line(test_case, current_if, ips)
    assert expected == current_if

    # Test case:
    #   "media: autoselect <full-duplex> status: inactive"
    # Expected output:
    #   "media": "Unknown

# Generated at 2022-06-22 23:39:14.798013
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """test for parse_media_line method"""
    fact_collector = DarwinNetworkCollector()
    fact_net = fact_collector._fact_class()
    assert fact_net.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == \
        {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)'}, "Test failed"
    assert fact_net.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == \
        {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}, "Test failed"

# Generated at 2022-06-22 23:39:16.143098
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.get_device_info('en0')



# Generated at 2022-06-22 23:39:17.204935
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork(dict())
    assert module.platform == 'Darwin'

# Generated at 2022-06-22 23:39:19.748435
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fact_collector_obj = DarwinNetworkCollector()
    assert fact_collector_obj.platform == 'Darwin'

# Generated at 2022-06-22 23:39:26.097845
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # create the instance under test
    instance = DarwinNetworkCollector()
    # verify that the object is of the correct type
    assert isinstance(instance, DarwinNetworkCollector)
    # verify that we get the correct platform
    assert instance._platform == 'Darwin'
    # verify that we get the correct fact class
    assert instance._fact_class == DarwinNetwork

# unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:39:33.406092
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    # Test case 1: media line does not contain 'options'
    media_line = ['Supported', 'autoselect']
    current_if = {}
    ips = []
    darwin_if.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'None'
    assert current_if['media_options'] == {}
    # Test case 2: media line contains 'options'
    media_line = ['media', 'autoselect', '(1000baseT)', 'status:', 'active', 'options:', 'none']
    current_if = {}
    ips = []
    dar

# Generated at 2022-06-22 23:39:39.826619
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # arrange
    test_darwin = DarwinNetwork()
    test_line = "media: autoselect <unknown type>"
    test_line_split = test_line.split()
    test_current_if = {}

    # act
    test_darwin.parse_media_line(test_line_split, test_current_if, {})

    # assert
    assert test_current_if['media'] == 'Unknown'
    assert test_current_if['media_select'] == 'autoselect'
    assert test_current_if['media_type'] == 'unknown type'
    assert test_current_if['media_options'] == ''

# Generated at 2022-06-22 23:39:50.302274
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork({})
    current_if = {}
    ips = []

    # media line is different to the default FreeBSD one
    # test missing media type
    media = ['/usr/sbin/ifconfig', 'en0', 'inet', '10.0.1.1', 'netmask', '0xffffff00',
             'broadcast', '10.0.1.255']
    network.parse_media_line(media, current_if, ips)
    assert current_if == {
        'media': 'Unknown',
        'media_select': 'en0',
        'media_type': 'inet',
        'media_options': {
            'broadcast': ['10.0.1.255'],
            'netmask': ['0xffffff00'],
        }
    }

    # test

# Generated at 2022-06-22 23:39:57.773681
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    words = ['media:','autoselect','none','inactive']
    iface = {'media':'','media_select':'','media_type':'','media_options':''}
    dwn.parse_media_line(words,iface,None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'none'
    assert iface['media_options'] == 'inactive'
    return

# Generated at 2022-06-22 23:40:01.739520
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fixture_path = os.path.join(fixture_path, 'Darwin')
    assert DarwinNetworkCollector(fixture_path)._facts['all_ipv4_addresses'] == ['::1', '192.168.1.102', '127.0.0.1']

# Generated at 2022-06-22 23:40:06.270509
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetworkCollector = DarwinNetworkCollector()
    assert darwinNetworkCollector != None
    assert darwinNetworkCollector._fact_class == DarwinNetwork
    assert darwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:40:12.422717
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'media': 'Unknown'
    }
    # parse media line with "<unknown type>"
    DarwinNetwork.parse_media_line(('unknown', '<unknown', 'type>'), current_if, {})
    assert current_if['media_select'] == 'Unknown' and current_if['media_type'] == 'unknown type'


# Generated at 2022-06-22 23:40:20.859166
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test object creation """
    module = DarwinNetwork()
    assert module.platform == 'Darwin'
    assert module.media_line_re == r'^(\w+): ([^\s]+)(?: <([^>]+)>)?(?: ([^\s]+))?$'
    assert module.speed_line_re == r'^\s+([\w ]+)$'
    assert module.addr_line_re == r'^\s+inet (?:([\d\.]+))?(?: netmask ([a-f0-9]+))?(?: (broadcast|destination))? ([\d\.]+)'
    assert module.lladdr_line_re == r'^\s+ether ([0-9a-fA-F:]+)'

# Generated at 2022-06-22 23:40:31.892569
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    tests = []
    tests.append(('Media: autoselect (1000baseT <full-duplex>)'))
    tests.append(('Media: autoselect <full-duplex>'))
    tests.append(('Media: autoselect (1000baseT <full-duplex>) status: inactive'))
    tests.append(('Media: 1000baseT <full-duplex>'))
    tests.append(('Media: 1000baseT <full-duplex,rxpause,txpause>'))
    tests.append(('Media: 1000baseT <full-duplex,rxpause,txpause>, auto'))

    test_options = []
    test_options.append(('Media: autoselect (1000baseT <full-duplex>)'))

# Generated at 2022-06-22 23:40:36.270492
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_darwin_network = DarwinNetwork()
    assert my_darwin_network.facts is None
    assert my_darwin_network.interfaces is None
    assert my_darwin_network.custom_fact_exists() == False
    assert my_darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:40:46.240278
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict(media='', media_select='', media_type='Unknown', media_options=[])
    test_object = DarwinNetwork()
    assert test_object.parse_media_line(["media:", "COPPER", "1000baseT", "(autoselect)"], current_if, None) == (current_if, True)

    # This is not valid media line but it should still not break
    # unit test for the above issue
    current_if = dict(media='', media_select='', media_type='Unknown', media_options=[])
    test_object = DarwinNetwork()
    test_object.parse_media_line(["media:", "COPPER", "(Unknown)", "1000baseT", "(autoselect)"], current_if, None)
    assert current_if['media_type'] == 'Unknown'

# Generated at 2022-06-22 23:40:53.528971
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test the constructor of the DarwinNetwork class"""
    #pylint: disable=too-few-public-methods
    class Options:
        """Class for mocking up options for unittesting"""
        gather_subset = None
        gather_network_resources = None
        filter = None
        config = "tests/unit/module_utils/network/Darwin/ifconfig"

    mock_module = Options()
    dn = DarwinNetwork(mock_module)
    assert dn.platform == 'Darwin'
    assert len(dn.interfaces) == 3

# Generated at 2022-06-22 23:40:54.924917
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect()

# Generated at 2022-06-22 23:41:06.752809
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # 802.11 WiFi
    darwin_wifi_if = DarwinNetwork()
    darwin_wifi_if.parse_media_line(["media:", "IEEE", "802.11", "(autoselect)"])
    assert darwin_wifi_if.current_if['media'] == 'Unknown'
    assert darwin_wifi_if.current_if['media_select'] == 'IEEE'
    assert darwin_wifi_if.current_if['media_type'] == '802.11'
    assert darwin_wifi_if.current_if['media_options'] == {'autoselect': True}

    # Ethernet
    darwin_ethernet_if = DarwinNetwork()

# Generated at 2022-06-22 23:41:17.792422
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = dict(self=None, words=['media:', '<unknown', 'type>'],
                     current_if='test', ips='test')

    # run test for given data
    darwin_network = DarwinNetwork(test_data['self'])
    test_result = darwin_network.parse_media_line(test_data['words'],
                                                  test_data['current_if'],
                                                  test_data['ips'])

    # get expected result from the test data
    expected_result = dict(media='Unknown',
                           media_select='Unknown',
                           media_type='unknown type',
                           media_options=None
                           )

    # check if test and expected results are equal
    assert test_result == expected_result

# Generated at 2022-06-22 23:41:29.308341
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:41:31.301182
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fn = DarwinNetworkCollector()
    assert isinstance(fn, NetworkCollector)



# Generated at 2022-06-22 23:41:33.768783
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mac_network = DarwinNetwork()
    assert mac_network.get_interfaces() == {}
    assert mac_network.get_default_interface() is None
    assert mac_network.get_interfaces_ip() == {}
    assert mac_network.get_default_ip() is None


# Generated at 2022-06-22 23:41:34.580915
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:41:47.015668
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = dict()

    # test_parse_media_line_1:
    # Test parse_media_line with a valid media line
    words = [
        'media',
        'autoselect',
        '(none)',
        'status:',
        'inactive',
        'active',
    ]
    darwin_net.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options']['status'] == 'inactive'

    # test_parse_media_line_2:
    # Test parse_media_line with a

# Generated at 2022-06-22 23:41:53.565462
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['<unknown type>', 'verbose', 'media', 'autoselect']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, [])
    assert current_if['media_select'] == words[1]
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == words[2]
    assert current_if['media_options'] == ['autoselect']

    current_if = {}
    words = ['<unknown type>', 'verbose', '<unknown type>']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:41:58.050699
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test = GenericBsdIfconfigNetwork()
    test.parse_media_line(['media:', '<unknown type>', '<unknown type>'], {}, {})
    assert test.facts['ansible_interfaces']['bge0']['media'] == 'Unknown'

# Generated at 2022-06-22 23:42:00.746323
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
  my_if = DarwinNetwork()
  assert my_if.platform == 'Darwin'
  assert my_if.__class__.__name__ == 'DarwinNetwork'



# Generated at 2022-06-22 23:42:02.265833
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.get_interfaces() != None

# Generated at 2022-06-22 23:42:06.237387
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector is not None
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork
    assert collector._config == {'fail_on_errors': 'off'}


# Generated at 2022-06-22 23:42:08.074694
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class is DarwinNetwork

# Generated at 2022-06-22 23:42:17.291253
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    new_dict = {}
    ips = []
    # Parse words to test if media_options are extracted
    words = ['media', 'auto', 'autoselect', 'status:', 'active']
    new_dict = darwin_network.parse_media_line(words, new_dict, ips)
    assert 'media_options' in new_dict
    assert new_dict['media_options'] == 'status:' # Media options extracted
    # Parse words to test if media_type is extracted
    words = ['media', '1000baseT', 'status:', 'active']
    new_dict = darwin_network.parse_media_line(words, new_dict, ips)
    assert 'media_type' in new_dict

# Generated at 2022-06-22 23:42:18.710764
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:42:20.086584
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'

# Generated at 2022-06-22 23:42:23.654883
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    Test the DarwinNetwork constructor
    '''
    test = DarwinNetwork()
    assert test.platform == 'Darwin'

# Generated at 2022-06-22 23:42:25.002659
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'


# Generated at 2022-06-22 23:42:32.199295
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test DarwinNetworkCollector"""
    facts = {}
    DarwinNetworkCollector(facts, None).collect()
    assert 'network' in facts
    for iface in facts['network']['interfaces'].values():
        assert 'hwaddr' in iface
        assert 'ipv4' in iface
        assert 'ipv6' in iface
        assert 'media_select' in iface
        assert 'media_type' in iface

# Generated at 2022-06-22 23:42:34.136051
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d=DarwinNetwork()
    assert d.platform=='Darwin'
    assert d._platform=='Darwin'

# test DarwinNetworkCollector constructor

# Generated at 2022-06-22 23:42:42.847827
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork({})
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = {}

    darwin_network.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'status:inactive' in current_if['media_options']

# Generated at 2022-06-22 23:42:45.189532
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor test
    """
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-22 23:42:52.555605
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = DarwinNetwork()
    media_line = 'media: autoselect <unknown type>'
    words = media_line.split()
    current_if = {'name': 'test_if'}
    ips = {}
    data.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:42:53.234048
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:55.422111
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector(None, None, None)


# Generated at 2022-06-22 23:42:56.654882
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None


# Generated at 2022-06-22 23:42:58.737270
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:43:01.768136
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Unit test for DarwinNetwork class constructor.
    """
    def assert_class_variables(test_obj):
        assert test_obj.platform == 'Darwin'

    assert_class_variables(DarwinNetwork())

# Generated at 2022-06-22 23:43:12.676834
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import textwrap
    input = textwrap.dedent('''\
        media: autoselect (1000baseT <full-duplex>)
        status: active
    ''')
    d = DarwinNetwork(input)

    current_if = {'name': 'en0'}
    ips = {}
    d.parse_media_line(input.split(), current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'

# Generated at 2022-06-22 23:43:16.588617
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'supported media: autoselect <unknown type>'
    d = DarwinNetwork()
    d.parse_media_line(line.split(), {}, {})
    assert d.current_if['media_select'] == "autoselect"
    assert d.current_if['media_type'] == "unknown type"

# Generated at 2022-06-22 23:43:17.701925
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:43:30.067090
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    DarwinNetwork.parse_media_line(DarwinNetwork, ["media:", "media-select", "(media-type)"], current_if, ips)
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "media-select"
    assert current_if["media_type"] == "(media-type)"
    assert "media_options" not in current_if
    assert ips == {}
    DarwinNetwork.parse_media_line(DarwinNetwork, ["media:", "media-select", "(media-type)",
                                                   "(media-options)"], current_if, ips)
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "media-select"

# Generated at 2022-06-22 23:43:32.995705
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Unit test to test the DarwinNetworkCollector
    """
    obj = DarwinNetworkCollector()
    assert obj._fact_class is not None
    assert obj.platform == obj._platform

# Generated at 2022-06-22 23:43:44.494147
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:43:46.736607
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj1 = DarwinNetwork()
    assert obj1
    assert repr(obj1)

# Generated at 2022-06-22 23:43:47.949295
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetworkCollector()
    DarwinNetwork(None)

# Generated at 2022-06-22 23:43:48.928234
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:43:53.634413
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn1 = DarwinNetwork()
    assert dn1._fact_class == DarwinNetwork
    assert dn1._platform == 'Darwin'
    assert dn1.version == 2
    assert dn1.options == None
    assert dn1.stats == []



# Generated at 2022-06-22 23:44:04.036537
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # This section is only for unit testing
    darwin_iface = DarwinNetwork()
    assert darwin_iface.parse_media_line(['media:','autoselect','100baseTX','full-duplex'],{},{})['media'] == 'Unknown'
    assert darwin_iface.parse_media_line(['media:','autoselect','100baseTX','full-duplex'],{},{})['media_select'] == 'autoselect'
    assert darwin_iface.parse_media_line(['media:','autoselect','100baseTX','full-duplex'],{},{})['media_type'] == '100baseTX'

# Generated at 2022-06-22 23:44:05.675072
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:11.842540
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test 'bge0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500'
    # should give the following output:
    test_media_line = 'media: autoselect (1000baseT <full-duplex>)'
    words = test_media_line.split()
    test_dict = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '1000baseT',
        'media_options': 'full-duplex'
    }
    DarwinNetwork = NetworkCollector._supported_facts['Darwin']['DarwinNetwork']
    test_obj = DarwinNetwork()
    result = test_obj.parse_media_line(words, {}, {})
    assert result == test_dict

# Generated at 2022-06-22 23:44:13.220838
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Constructor of DarwinNetwork
    DarwinNetwork()



# Generated at 2022-06-22 23:44:13.681290
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:16.702863
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'
    assert network.ifconfig == '/sbin/ifconfig'

# Generated at 2022-06-22 23:44:20.381711
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:44:26.167376
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_interface = DarwinNetwork(None)
    assert darwin_interface.ipv4_addrs == dict()
    assert darwin_interface.ipv6_addrs == dict()
    assert darwin_interface.all_ipv4_addresses == dict()
    assert darwin_interface.all_ipv6_addresses == dict()
    assert darwin_interface.interfaces == dict()
    assert darwin_interface.default_ipv4 == dict()
    assert darwin_interface.default_ipv6 == dict()

# Generated at 2022-06-22 23:44:37.538007
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a fake network interface
    current_if = {}
    ips = {}
    # first test case
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media_select'] == words[1]
    assert current_if['media_type'] == words[2]
    assert current_if['media_options'] == None
    assert current_if['media'] == 'Unknown'
    current_if.clear()
    # second test case
    words = ['media:', '10baseT/UTP', '(10baseT/UTP <half-duplex>)', 'status:', 'active']

# Generated at 2022-06-22 23:44:49.443932
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    # Test media:media_select:media_type:media_options
    current_if['media'] = 'Autoselect 10baseT/UTP'
    DarwinNetwork.parse_media_line(None, [None, "media", "media_select", "media_type", "media_options", "a", "b"], current_if, None)
    assert current_if['media'] == 'Autoselect'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    assert current_if['media_options'] == 'a b'
    # Test weird MacOSX case
    DarwinNetwork.parse_media_line(None, [None, "<unknown", "type>"], current_if, None)

# Generated at 2022-06-22 23:44:50.414181
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None).platform == 'Darwin'

# Generated at 2022-06-22 23:44:55.617757
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    line_1 = ["media:", "select", "(default", "to", "autoselect)"]
    line_2 = ["media:", "select", "(default", "to", "autoselect)"]
    line_3 = ["media:", "select", "(default", "to", "autoselect)", "based", "on", "user"]
    line_4 = ["media:", "select", "(default", "to", "autoselect)", "based", "on", "user"]
    line_5 = ["media:", "select", "(default", "to", "autoselect)", "based", "on", "user"]

    current_if = {'media': "", 'media_select': "", 'media_type': "", 'media_options': []}

    # line_1
    obj.parse

# Generated at 2022-06-22 23:45:04.866699
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    dn = DarwinNetwork(None, None)
    # test empty list
    words = []
    current_if = dict()
    ips = dict()
    dn.parse_media_line(words, current_if, ips)
    assert not current_if

    # test an example line
    words = "media: autoselect (1000baseT <full-duplex>)"
    words = words.split()
    dn.parse_media_line(words, current_if, ips)
    assert current_if
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'


# Generated at 2022-06-22 23:45:09.416471
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _fact_class = DarwinNetwork
    _platform = 'Darwin'
    network_collector = DarwinNetworkCollector(_fact_class, _platform)
    assert network_collector.platform == "Darwin"
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == "Darwin"

# Generated at 2022-06-22 23:45:19.914220
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type> <unknown subtype>'
    words = media_line.split()
    current_if = {'media' : '', 'media_select' : '', 'media_type' : '', 'media_options' : ''}
    ips = []

    test_obj = DarwinNetwork()
    test_obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'unknown subtype'