

# Generated at 2022-06-22 23:35:16.650264
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    foo = DarwinNetwork()
    assert foo.platform == 'Darwin'


# Generated at 2022-06-22 23:35:17.026704
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:35:18.578471
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    darwin_obj = DarwinNetwork(module)
    assert darwin_obj.platform == "Darwin"

# Generated at 2022-06-22 23:35:21.221910
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collect_net_obj = DarwinNetworkCollector()
    assert isinstance(collect_net_obj._fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:35:31.931751
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    fact = {'en0': {'inet': ['169.254.123.123'], 'inet6': ['fe80::123:123:123:123%en0'], 'status': 'active', 'type': 'ethernet', 'macaddress': '00:01:02:03:04:05'}, 'en1': {'inet': ['192.0.2.1'], 'inet6': ['fe80::0001:0002:0003:0004%en1'], 'status': 'active', 'type': 'ethernet', 'macaddress': '00:01:02:03:04:05'}}
    darwin_network = DarwinNetwork()
    assert darwin_network.get_all_network_interfaces() == fact


# Generated at 2022-06-22 23:35:42.369864
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test for method DarwinNetwork.parse_media_line
    """
    wlo1_dict = {}
    wlo1_ips = []
    media_line = "media autoselect status: inactive"
    # test for media line:
    # media autoselect status: inactive
    DarwinNetwork.parse_media_line(DarwinNetwork(), media_line.split(),
                               wlo1_dict, wlo1_ips)
    assert wlo1_dict['media'] == 'Unknown'
    assert wlo1_dict['media_select'] == 'autoselect'
    assert wlo1_dict['media_options'] == 'status: inactive'


# Generated at 2022-06-22 23:35:43.665829
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector,NetworkCollector)


# Generated at 2022-06-22 23:35:48.272153
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert isinstance(darwin_network_collector, DarwinNetworkCollector)
    assert isinstance(darwin_network_collector._fact_class, DarwinNetwork)
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:35:50.255595
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork({}, "FakeOS")
    assert obj.get_file_path() == '/sbin/ifconfig'

# Generated at 2022-06-22 23:35:52.759849
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print("++++ Testing DarwinNetwork class")
    fact_class = DarwinNetwork()
    print(fact_class._platform)


# Generated at 2022-06-22 23:35:59.914501
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    m = {}

    w = ['media:', 'autoselect', 'status:', 'inactive']
    d.parse_media_line(w, m, None)
    assert m['media'] == 'Unknown'
    assert m['media_select'] == 'autoselect'
    assert m['media_type'] is None
    assert m['media_options'] == 'status: inactive'

    w = ['media:', '<unknown', 'type>', '(no', 'opts)']
    d.parse_media_line(w, m, None)
    assert m['media'] == 'Unknown'
    assert m['media_select'] == 'Unknown'
    assert m['media_type'] == 'unknown type'
    assert m['media_options'] == 'opts) (no'


# Generated at 2022-06-22 23:36:11.504690
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test parse_media_line of DarwinNetwork class
    dif = DarwinNetwork()
    dif.parse_media_line(['media:','autoselect','any','status:','active'], {}, [])

    dif.parse_media_line(['media:','autoselect','<unknown type>','status:','active'], {}, [])


# Generated at 2022-06-22 23:36:17.853492
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()

    # positive test case
    test_object.parse_media_line(['media:','<unknown','type>','status:','active'], {}, {})

    # negative test case
    test_object.parse_media_line(['<unknown','type>'], {}, {})


# Generated at 2022-06-22 23:36:24.529199
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = "media: autoselect (1000baseT <full-duplex>)"
    current_if = {}
    ips = []
    darwin = DarwinNetwork()
    darwin.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['full-duplex']

# Generated at 2022-06-22 23:36:32.189773
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}

    mac_network = DarwinNetwork()

    # media line is different to the default FreeBSD one
    # 1st test:
    media_line = ['media:', 'autoselect', '100baseTX']
    mac_network.parse_media_line(media_line, test_if, {})
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '100baseTX'

    # 2nd test:
    test_if = {}
    media_line = ['media:', 'autoselect', '100baseTX', 'full-duplex']
    mac_network.parse_media_line(media_line, test_if, {})
    assert test_if['media'] == 'Unknown'


# Generated at 2022-06-22 23:36:34.935314
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructor of DarwinNetworkCollector should initialize _fact_class as DarwinNetwork.
    """
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class is DarwinNetwork

# Generated at 2022-06-22 23:36:38.949084
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector(None, None, None, None)
    assert dnc.platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:36:42.408066
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'


# Generated at 2022-06-22 23:36:49.930328
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: autoselect (<unknown type>)'
    d = DarwinNetwork()
    words = line.split()
    current_if = {}
    ips = []
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:36:52.709495
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # This will fail when this is used as a module
    assert DarwinNetworkCollector is not None
    assert DarwinNetworkCollector().get_network_facts() is not None

# Generated at 2022-06-22 23:37:00.690349
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:37:01.624337
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork is not None


# Generated at 2022-06-22 23:37:10.285880
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    facts = DarwinNetwork()
    current_if = dict()

    # media_select is not set
    current_if['media_select'] = None
    facts.parse_media_line(['media:', '100baseTX', 'full-duplex'], current_if, dict())
    assert current_if['media_select'] == '100baseTX'
    assert current_if['media_type'] == 'full-duplex'

    # media_select is set
    current_if['media_select'] = 'test'
    facts.parse_media_line(['media:', '100baseTX', 'full-duplex'], current_if, dict())
    assert current_if['media_select'] == '100baseTX'
    assert current_if['media_type'] == 'full-duplex'

# Generated at 2022-06-22 23:37:12.270620
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_class = DarwinNetwork()
    assert test_class.platform == 'Darwin'


# Generated at 2022-06-22 23:37:16.369095
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    Unit test for constructor of class DarwinNetwork
    '''
    result = DarwinNetwork()
    # We can add specific assertions for the darwin facts here
    assert result.platform == 'Darwin'


# Generated at 2022-06-22 23:37:25.796580
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    # mock the facts and test the constructor of class DarwinNetwork
    net_facts = dict()
    net_facts["interfaces"] = dict()
    net_facts["all_ipv4_addresses"] = dict()
    net_facts["default_ipv4"] = dict()
    darwin_network = DarwinNetwork(net_facts)

    # check the attributes of constructed class DarwinNetwork
    assert darwin_network.platform == "Darwin"
    assert darwin_network.interfaces == dict()
    assert darwin_network.all_ipv4_addresses == dict()
    assert darwin_network.default_ipv4 == dict()


# Generated at 2022-06-22 23:37:27.261601
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'


# Generated at 2022-06-22 23:37:34.921104
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()  # instantiate the class under test
    # test media line with one word
    line = "media: <unknown type> status: inactive"
    words = line.split()  # split into words
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    # assert if dict media has the right value
    assert current_if['media'] == "Unknown"

    # test media line with two words
    line = "media: <unknown type> unknown type status: inactive"
    words = line.split()  # split into words
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    # assert if dict media has the right value

# Generated at 2022-06-22 23:37:36.414551
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork


# Generated at 2022-06-22 23:37:37.169619
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:39.041612
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc is not None

# Generated at 2022-06-22 23:37:41.509479
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test the constructor of DarwinNetworkCollector
    """
    darwin_network = DarwinNetworkCollector()
    assert darwin_network.platform == 'Darwin'
    assert darwin_network._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:37:53.388233
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import os
    import textwrap

    output = textwrap.dedent("""\
    media: autoselect ('<unknown type>' removed)
    status: active
    
    media: autoselect ('<unknown type>' removed)
    status: active
    """)
    output = os.linesep.join([s for s in output.splitlines() if s])

    interface = 'bridge0'
    current_if = {}
    current_if['name'] = interface
    current_if['type'] = 'ethernet'
    current_if['operstate'] = 'down'
    current_if['macaddress'] = None
    current_if['ipv4'] = []
    current_if['ipv6']

# Generated at 2022-06-22 23:37:55.601483
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:05.847502
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork('lo0', '127.0.0.1', 'link#1') == {
        'active': True,
        'description': None,
        'device': 'lo0',
        'dnsservers': [],
        'gateway': None,
        'ifalias': None,
        'ifindex': '1',
        'ipaddresses': ['127.0.0.1'],
        'macaddress':  None,
        'mtu': '16384',
        'netmask': '255.0.0.0',
        'network': '127.0.0.0',
        'promisc': False,
        'type': 'Loopback',
        'operstate': 'UNKNOWN',
        'aggregated_ether_address': None
    }

# Generated at 2022-06-22 23:38:13.015868
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = {}
    # Execute
    DarwinNetwork().parse_media_line(words, current_if, ips)
    # Verify
    assert '<?>' == current_if['media_select']
    assert 'unknown type' == current_if['media_type']
    assert 'inactive' == current_if['media_options']

# Generated at 2022-06-22 23:38:14.583260
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    myfact = DarwinNetwork()
    assert myfact.platform == 'Darwin'

# Generated at 2022-06-22 23:38:15.943465
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork()
    assert result is not None


# Generated at 2022-06-22 23:38:19.659035
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    nc = DarwinNetworkCollector()
    assert nc.platform == 'Darwin'
    assert isinstance(nc.facts, DarwinNetwork)
    assert nc.facts._platform == 'Darwin'
    assert nc.facts.platform == 'Darwin'
    assert nc.facts.ifconfig_path == '/sbin/ifconfig'

# Generated at 2022-06-22 23:38:26.518426
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    darwin_network_collector = DarwinNetworkCollector()
    assert isinstance(darwin_network_collector._fact_class(), DarwinNetwork)
    assert repr(darwin_network_collector) == "<DarwinNetworkCollector('Darwin', <class 'ansible.module_utils.facts.network.darwin.DarwinNetwork'>)>"


# Generated at 2022-06-22 23:38:28.325953
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:38.164427
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork({})
    current_if = {}
    d.parse_media_line(["media:", "autoselect", "status:", "inactive"], current_if, {})
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_status': 'inactive'}
    current_if = {}
    d.parse_media_line(["media:", "10baseT/UTP", "status:", "active"], current_if, {})
    assert current_if == {'media_type': 'UTP', 'media_select': '10baseT', 'media_status': 'active'}
    current_if = {}

# Generated at 2022-06-22 23:38:42.663590
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert issubclass(DarwinNetworkCollector._fact_class, DarwinNetwork)


# Generated at 2022-06-22 23:38:45.250721
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class is DarwinNetwork



# Generated at 2022-06-22 23:38:56.144858
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test the constructor of DarwinNetwork"""
    darwin_network = DarwinNetwork({}, None, None)
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.ipv4_interfaces == 'autoaddr'
    assert darwin_network.ipv6_interfaces == 'autoconf'
    assert darwin_network.link_detect is True
    assert darwin_network.ifconfig is False
    assert darwin_network.media_based is True
    assert darwin_network.media_lines is True
    assert darwin_network.media_words is True
    assert darwin_network.media_channels is True
    assert darwin_network.media_hardware is True
    assert darwin_network.media_options is True

# Generated at 2022-06-22 23:39:06.419126
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    def options_list():
        return_list = []
        return_list.append(('UP', True, '', ''))
        return_list.append(('BROADCAST', True, '', ''))
        return_list.append(('SMART', True, '', ''))
        return_list.append(('RUNNING', True, '', ''))
        return_list.append(('SIMPLEX', True, '', ''))
        return_list.append(('MULTICAST', True, '', ''))
        return_list.append(('LINK0', True, '', ''))
        return_list.append(('AUTOCONFIGURING', True, '', ''))
        return return_list
    os_net = DarwinNetwork()

# Generated at 2022-06-22 23:39:14.409361
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'none', 'status:', 'active']
    current_if = {}
    ifconfig_data = {'eth0': {}}
    d = DarwinNetwork(module=None, params=None)
    d._interfaces = ifconfig_data
    d.parse_media_line(words, current_if, {})
    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == "Unknown"
    assert current_if['media_type'] == 'unknown type'

    words = ['media:', 'auto', '10baseT/UTP', 'status:', 'active']
    d.parse_media_line(words, current_if, {})
    assert current_if['media'] == "Unknown"

# Generated at 2022-06-22 23:39:20.667895
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # media line is different to the default FreeBSD one, they just vary in the select name
    # As a result, this method is the same as FreeBSDNetwork.parse_media_line()
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    #media_line = "media: <unknown type> autoselect "
    my_test_interfaces = ['test_in1', 'test_in2']

# Generated at 2022-06-22 23:39:31.046645
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create test object
    darwin_network = DarwinNetwork(None)

    # Test with the 'Unknown' button
    expected_current_if = {
        'media': 'Unknown',
        'media_select': 'none',
        'media_type': 'ieee80211',
        'media_options': ['autoselect'],
    }
    words = ['802.11', 'none', '<unknown', 'type>', 'autoselect']
    current_if = {}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert expected_current_if == current_if

    # Test with the AirPort button

# Generated at 2022-06-22 23:39:32.493816
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:39:39.348633
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    words = ['<unknown', 'type>']
    current_if = {}
    ips = []
    obj = DarwinNetwork(module=None, collect_default=True)
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:39:40.890485
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network._fact_class is DarwinNetwork
    assert network._platform == 'Darwin'

# Generated at 2022-06-22 23:39:41.321289
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:43.878306
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNet = DarwinNetwork({})
    assert darwinNet.get_file_path() == '/sbin/ifconfig'

# Generated at 2022-06-22 23:39:51.084928
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    ifnet = DarwinNetwork()
    ifnet.collect()
    assert ifnet.facts is not None
    assert ifnet.facts['all_ipv4_addresses'] is not None
    assert ifnet.facts['all_ipv6_addresses'] is not None
    assert ifnet.facts['default_ipv4'] is not None
    assert ifnet.facts['default_ipv6'] is not None
    assert ifnet.facts['interfaces'] is not None


# Generated at 2022-06-22 23:39:54.693073
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.platform == 'Darwin'
    assert darwin_network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:40:05.565895
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    inet_mock = DarwinNetwork('unknown', 'Darwin')
    current_if_mock = {}
    ips_mock = {}
    inet_mock.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)'],
                               current_if_mock, ips_mock)
    assert current_if_mock['media'] == 'Unknown'
    assert current_if_mock['media_select'] == 'Ethernet'
    assert current_if_mock['media_type'] == 'autoselect'
    assert current_if_mock['media_options'] == '1000baseT'
    current_if_mock = {}

# Generated at 2022-06-22 23:40:10.133414
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    fake_args = dict()

    # Construct a fake DarwinNetwork class to test
    dwn = DarwinNetwork(fake_args)
    assert dwn._platform == 'Darwin'
    assert dwn.structure == dict()
    assert dwn.warnings == list()
    assert dwn.ignore == dict()

# Generated at 2022-06-22 23:40:20.549708
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    test_words = []
    test_if = {}
    test_ips = []
    test_net = DarwinNetwork()

    # Test normal case
    test_words = ['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']
    test_if = {}
    test_ips = []
    test_net.parse_media_line(test_words, test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '(1000baseT <full-duplex>)'

# Generated at 2022-06-22 23:40:22.841675
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print('Testing DarwinNetwork instantiation')
    darwinif = DarwinNetwork()

    assert darwinif.platform == 'Darwin'



# Generated at 2022-06-22 23:40:28.208418
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(['media:','autoselect','<unknown','type>','status:','active'], {}, {}) == \
           {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': 'status: active'}

# Generated at 2022-06-22 23:40:39.212242
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pylint: disable=protected-access
    # test input and expected output
    test_input = ['media:', 'autoselect', 'status:', 'inactive']
    test_output = {'media': 'Unknown', 'media_select': 'autoselect', 'media_status': 'inactive'}
    # create new instance of class DarwinNetwork
    darwinTest = DarwinNetwork()
    # call method parse_media_line and parse the test_input
    darwinTest._parse_media_line(test_input, {})
    # compare method's output with test_output
    assert darwinTest.current_if == test_output
    # test input and expected output
    test_input = ['media:', 'autoselect', '(none)']

# Generated at 2022-06-22 23:40:41.658020
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._platform == 'Darwin'

################################################################################
# Unit tests for class DarwinNetwork

# Generated at 2022-06-22 23:40:43.363592
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_iface = DarwinNetwork("en0")
    assert darwin_iface.name == "en0"

# Generated at 2022-06-22 23:40:50.320705
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    drwin_network = DarwinNetwork()
    current_if = {}
    drwin_network.parse_media_line(['media:', 'autoselect', '(none)'], current_if, [])
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media'] == 'Unknown'
    current_if = {}
    drwin_network.parse_media_line(['media:', '<unknown', 'type>'], current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:41:01.949108
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc._interfaces = {}
    current_if = {}
    ifc.parse_media_line(['media:','autoselect','(none)'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert not current_if.get('media_options')

    current_if = {}
    ifc.parse_media_line(['media:','autoselect', '(none)'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert not current_if

# Generated at 2022-06-22 23:41:14.337708
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:41:16.904603
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:41:28.342042
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:41:31.212259
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test DarwinNetworkCollector constructor"""
    fact_class = network_module.DarwinNetworkCollector
    assert fact_class._platform == 'Darwin'


# Generated at 2022-06-22 23:41:38.970661
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup test data
    current_if = {}
    ips = []

    # Test 1: vboxnet0
    # Expected Result 1: media_select='Autoselect',
    #                    media_type='vboxnet',
    #                    media_options=None
    words = ['media:', 'Autoselect', '(vboxnet)']
    DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Autoselect'
    assert current_if['media_type'] == 'vboxnet'
    assert current_if['media_options'] is None

    # Test 2: en0
    # Expected Result 2: media='Unknown',
    #                    media_select='Autoselect',


# Generated at 2022-06-22 23:41:46.579093
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test the module constructor with expected attributes"""
    DarwinNetworkCollector._platform = 'Darwin'  # pylint: disable=protected-access
    darwin_network_collector = DarwinNetworkCollector()
    assert hasattr(darwin_network_collector, '_fact_class') and darwin_network_collector._fact_class == DarwinNetwork
    assert hasattr(darwin_network_collector, '_platform') and darwin_network_collector._platform == 'Darwin'  # pylint: disable=protected-access

# Generated at 2022-06-22 23:41:48.536228
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork({'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': 'none', 'media_options': 'none'})

# Generated at 2022-06-22 23:41:52.528940
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        )
    )
    ifc = DarwinNetwork(module)
    assert isinstance(ifc, DarwinNetwork)
    assert ifc.ifconfig_path == ifc.ifconfig_path == '/sbin/ifconfig'

# Generated at 2022-06-22 23:42:01.039287
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test for issue #37558
    # assumed behavior: skipped words
    darwin_network = DarwinNetwork()
    current_if = {'name': 'lo0'}
    words = ['unknown', 'type', '>', 'status:', 'active']
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:42:04.958057
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    m = DarwinNetwork()
    assert m.platform == 'Darwin'
    assert m.media_select == 'media:'
    assert m.media_type == 'type:'
    assert m.media_options == 'options:'


# Generated at 2022-06-22 23:42:07.419542
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ constructor test """
    darwin_network = DarwinNetwork()
    assert darwin_network


# Generated at 2022-06-22 23:42:16.840767
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    lines = ['media: unknown <unknown type>',
             'media: autoselect (none)',
             'media: autoselect status: inactive',
             'supported media: none 10baseT/UTP 10baseT/UTP <link>autoselect']
    d = DarwinNetwork()
    for line in lines:
        words = line.split()
        current_if = {}
        d.parse_media_line(words, current_if, 'ips')
        if line == lines[0]:
            assert current_if['media_select'] == '<unknown'
            assert current_if['media_type'] == 'unknown type'
        elif line == lines[1]:
            assert current_if['media_select'] == 'none'
            assert 'media_type' not in current_if

# Generated at 2022-06-22 23:42:27.994402
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    expected_result = {
        'default_interface': 'en0',
        'interfaces': {
            'lo0': {
                'active': True,
                'device': 'lo0',
                'type': 'loopback'
            },
            'en0': {
                'device': 'en0',
                'ipv4': {'address': '192.168.1.4', 'netmask': '255.255.255.0',
                         'network': '192.168.1.0'},
                'macaddress': '00:02:2d:11:66:f9',
                'mtu': 1500,
                'type': 'ether',
                'active': True,
            }
        }
    }


# Generated at 2022-06-22 23:42:31.613861
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'



# Generated at 2022-06-22 23:42:39.524981
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # construct object for testing
    dn = DarwinNetwork()

    # test with media_line without options
    current_if = {}
    dn.parse_media_line(['media:', 'autoselect', 'none'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'

    # test with media_line with options
    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>', '(none)'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'

# Generated at 2022-06-22 23:42:41.984326
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_facts_instance = DarwinNetwork()
    assert network_facts_instance._platform == 'Darwin'

# Generated at 2022-06-22 23:42:50.680989
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 1: test media line parsing results with a known media line
    # from a MacOSX interface
    hn = DarwinNetwork()
    test_if = {}
    hn.parse_media_line(['media:', '<unknown', 'type>', 'status:', 'active'],
                        test_if, {})
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == []

# Generated at 2022-06-22 23:43:01.594285
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Given
    test_obj = DarwinNetwork()
    test_words = []
    test_current_if = {}
    test_ips = {}
    # When
    test_obj.parse_media_line(test_words, test_current_if, test_ips)
    # Then
    assert test_current_if == {'media': 'Unknown', 'media_select': 'Unknown'}
    # Clean up
    test_words = []
    test_current_if = {}
    test_ips = {}
    # When
    test_words = ['media:', '<unknown', 'type>']
    test_obj.parse_media_line(test_words, test_current_if, test_ips)
    # Then

# Generated at 2022-06-22 23:43:13.786589
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Testing correct parsing of media line by DarwinNetwork
    """
    from ansible.module_utils.facts.network.darwin import DarwinNetwork, _word_opts_handler
    from ansible.module_utils._text import to_native
    from sys import version_info

    current_if = {'device': 'en0'}
    ips = []

    words = to_native(['media:', '100baseTX', '<full-duplex>', '<100Mb/s>', 'flow-control', '<tx>', '<rx>', '<half-duplex>', '<100Mb/s>', 'flow-control', '<tx>', '<rx>'])
    current_if = DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
   

# Generated at 2022-06-22 23:43:17.164572
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network._get_interfaces_info_cmd == ['/sbin/ifconfig', '-a']


# Generated at 2022-06-22 23:43:21.277605
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    Unit test for constructor of class DarwinNetwork
    '''
    darwin_network = DarwinNetwork()
    assert darwin_network.name == 'Darwin'


# Generated at 2022-06-22 23:43:32.739318
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    test_if_obj = {}
    # test for other media line
    darwin_if.parse_media_line(["status:", "active", "media:", "10BaseT/UTP", "media", "selection:", "auto"], test_if_obj, "")
    assert test_if_obj['media'] == 'Unknown'
    assert test_if_obj['media_type'] == "10BaseT/UTP media selection: auto"
    # test for media line of a bridge interface
    test_if_obj = {}
    darwin_if.parse_media_line(["status:", "active", "media:", "<unknown", "type>"], test_if_obj, "")
    assert test_if_obj['media'] == 'Unknown'
    assert test_

# Generated at 2022-06-22 23:43:35.221214
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector().get_facts()['ansible_facts']['ansible_net_interfaces'], dict)

# Generated at 2022-06-22 23:43:40.582531
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_input = ['media:', 'autoselect', '<unknown type>', '(none)', 'status:', 'inactive']
    expected_output = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}
    darwin = DarwinNetwork()
    assert darwin.parse_media_line(test_input,{},{}) == expected_output

# Generated at 2022-06-22 23:43:41.833848
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:52.827075
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:43:57.846509
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == "Darwin"
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'
    assert obj._fact_class.__name__ == 'DarwinNetwork'
    assert obj._fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:44:06.873870
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'media':'Ethernet', 'media_select':'autoselect', 'media_type':'none',
                  'media_options':['none']}
    # This is a regular line
    words = ['media:','', '', '', 'autoselect', '(none)']
    dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert 'none' in current_if['media_options']
    # This is the line from a bridge interface with an unknown media type.

# Generated at 2022-06-22 23:44:14.598993
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit tests for DarwinNetwork class"""

    f = DarwinNetwork('em0')
    assert f
    assert f.interface == 'em0'
    assert f.mac == '00:0c:29:1d:39:c2'
    assert f.ipv4 == '192.168.0.1'
    assert f.ipv6 == 'fe80::20c:29ff:fe1d:39c2'
    assert f.module == 'igb'
    assert f.media == 'Unknown'
    assert f.media_select == 'Autoselect'
    assert f.media_type == '10baseT/UTP'
    assert f.media_options == '<full-duplex>'
    assert f.mtu == 1500
    assert f.bitrate == 100

# Generated at 2022-06-22 23:44:25.127895
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()

    iface.parse_media_line(["media:", "autoselect", "(none)"], {}, {})
    assert iface._current_if['media'] == 'Unknown'
    assert iface._current_if['media_select'] == 'autoselect'
    assert iface._current_if['media_type'] == 'none'
    assert iface._current_if['media_options'] == ''

    iface.parse_media_line(["media:", "<unknown", "type>"], {}, {})
    assert iface._current_if['media_select'] == 'Unknown'
    assert iface._current_if['media_type'] == 'unknown type'
    assert iface._current_if['media_options'] == ''


# Generated at 2022-06-22 23:44:27.197735
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

if __name__ == '__main__':
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:30.686858
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.name == 'Darwin'
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:44:37.969983
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'
    assert DarwinNetwork.media_line_regex == r'media:((.*? )?(<.*?>)) ?(.*?(\d+)\w*(\s*\([^()]+\))?)?'
    assert DarwinNetwork.inet4_line_regex == NetworkCollector.inet4_line_regex
    assert DarwinNetwork.inet6_line_regex == NetworkCollector.inet6_line_regex
    assert DarwinNetwork.link_line_regex == NetworkCollector.link_line_regex


# Generated at 2022-06-22 23:44:49.866830
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_obj = DarwinNetwork()

    assert darwin_network_obj._facts['all_ipv4_addresses'] == list()
    assert darwin_network_obj._facts['all_ipv6_addresses'] == list()
    assert darwin_network_obj._facts['default_ipv4']['address'] == '1.1.1.1'
    assert 'default_ipv4' in darwin_network_obj._facts['interfaces']
    assert 'default_ipv6' in darwin_network_obj._facts['interfaces']
    assert 'lo0' in darwin_network_obj._facts['interfaces']
    assert 'en1' in darwin_network_obj._facts['interfaces']
    assert 'en2' in darwin_network_

# Generated at 2022-06-22 23:45:01.479705
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # This test is used to test the media line parsing method in DarwinNetwork

    # Create a dictionary that will be used to collect the information
    test_dict = {'media': 'Unknown',
                 'media_select': 'autoselect',
                 'media_type': '<unknown type>',
                 'media_options': [(['autoselect'], None, None)]}

    # Create a list that will be used as input to the media line parser
    test_list = ['media:', 'autoselect', '<unknown type>', 'autoselect']

    # Create empty dictionary that will be used to collect information from ifconfig command
    # This is the output from ifconfig command

# Generated at 2022-06-22 23:45:03.363914
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:45:06.097661
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_fact = DarwinNetworkCollector(None, {})
    assert darwin_network_fact.platform == "Darwin"

# Generated at 2022-06-22 23:45:07.996285
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_obj = DarwinNetwork()
    assert net_obj.platform == 'Darwin'

# Generated at 2022-06-22 23:45:20.310285
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # test default
    words = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','']
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == ''
    assert 'media_type' not in current_