

# Generated at 2022-06-22 23:35:19.238607
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:35:21.699290
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:35:24.172382
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_obj = DarwinNetwork()
    assert network_obj.platform == 'Darwin'

# Generated at 2022-06-22 23:35:35.256054
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_input = ["media: <unknown type>", "media: <unknown type> <unknown subtype>", "media: autoselect (none)",
                  "media: none", "media: autoselect (100baseTX <full-duplex>)", "media: autoselect (100baseTX <half-duplex>)",
                  "media: autoselect (100baseTX <full-duplex,flow-control>)"]

# Generated at 2022-06-22 23:35:46.588236
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bsd = DarwinNetwork()
    bsd.parse_media_line(['Media:', '<unknown type>', '(none)'], {}, {})
    assert bsd.interfaces['eth0']['media'] == 'Unknown'
    assert bsd.interfaces['eth0']['media_select'] == 'Unknown'
    assert bsd.interfaces['eth0']['media_type'] == 'unknown type'
    assert bsd.interfaces['eth0']['media_options'] == ''
    bsd.parse_media_line(['Media:', 'autoselect', '(none)'], {}, {})
    assert bsd.interfaces['eth0']['media'] == 'Unknown'
    assert bsd.interfaces['eth0']['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:35:56.690923
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    current_if = dict()
    # existing behaviour
    words = ['media:', '', '']
    ips = dict()
    dnet.parse_media_line(words, current_if, ips)
    # this is the expected behaviour
    assert current_if == dict(media='Unknown')
    # existing behaviour
    words = ['media:', 'media_select', 'media_type', 'media_options']
    ips = dict()
    dnet.parse_media_line(words, current_if, ips)
    # this is the expected behaviour
    assert current_if == dict(media='Unknown', media_select='media_select', media_type='media_type', media_options='media_options')
    # new behaviour

# Generated at 2022-06-22 23:35:58.170218
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()._platform == 'Darwin'


# Generated at 2022-06-22 23:36:05.359265
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarrenNet = DarwinNetwork()
    assert(DarrenNet.platform == 'Darwin')
    assert(DarrenNet.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {
                                                                                    'media': 'Unknown',
                                                                                    'media_select': 'Unknown',
                                                                                    'media_type': 'unknown type'
                                                                                    })


# Generated at 2022-06-22 23:36:05.937507
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:09.665400
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network.platform == 'Darwin'
    assert network._fact_class == DarwinNetwork
    assert network._fact_class.platform == DarwinNetwork.platform
    assert isinstance(network, NetworkCollector)

# Generated at 2022-06-22 23:36:11.626110
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork()
    assert result.platform == 'Darwin', 'Test Failed'


# Generated at 2022-06-22 23:36:13.487932
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test = DarwinNetwork({})
    assert test is not None

# Generated at 2022-06-22 23:36:15.586553
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj is not None

# Generated at 2022-06-22 23:36:16.642048
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()

# Generated at 2022-06-22 23:36:18.117064
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert isinstance(dn, DarwinNetwork)

# Generated at 2022-06-22 23:36:23.097253
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:36:31.323372
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = dict()
    ips = dict()
    tb = DarwinNetwork()
    tb.parse_media_line(words, current_if, ips)
    # media line is different to the default FreeBSD one
    # not sure if this is useful - we also drop information
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'none'

# Generated at 2022-06-22 23:36:33.752897
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-22 23:36:35.626649
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d._fact_class == DarwinNetwork
    assert d._platform == 'Darwin'

# Generated at 2022-06-22 23:36:38.643523
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None)
    assert obj._fact_class.platform == 'Darwin'
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:36:46.743951
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This will test the constructor of DarwinNetwork.
    """
    # Check that an exception is raised if the wrong platform is passed.
    try:
        dn = DarwinNetwork('RedHat')
        raise Exception("This should not have happened!")
    except Exception as e:
        if e.args[0] != "This class only works on Darwin":
            raise Exception("This should not have happened!")
    try:
        dn = DarwinNetwork('RedHat')
        raise Exception("This should not have happened!")
    except Exception as e:
        if e.args[0] != "This class only works on Darwin":
            raise Exception("This should not have happened!")

# Generated at 2022-06-22 23:36:48.796004
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == "Darwin"

# Generated at 2022-06-22 23:36:50.831692
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    ifc = DarwinNetwork(None, None)
    assert ifc.platform == 'Darwin'

# Generated at 2022-06-22 23:36:59.515429
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = []
    # Media line when interface is a bridge
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}
    # Media line when interface is not a bridge
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, ips)

# Generated at 2022-06-22 23:37:09.087984
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_net_c = DarwinNetwork()

    # test for case with and without media options
    media_line_with_options = "media: <unknown type>"
    media_line_without_options = "media: <unknown type> autoselect (100baseTX <full-duplex,hw-loopback>)"
    mac_net_c.parse_media_line(media_line_with_options.split(), {}, {})
    mac_net_c.parse_media_line(media_line_without_options.split(), {}, {})

    # test for case with and without media options
    media_line_with_options = "media: autoselect (1000baseT <full-duplex,flow-control>)"

# Generated at 2022-06-22 23:37:20.659235
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwinn = DarwinNetwork()

    # Simple test case for media line parsing of ifconfig output
    words_simple = "media: autoselect (none)".split()
    current_if_simple = {'interface': 'en0'}
    ips_simple = []
    darwinn.parse_media_line(words_simple, current_if_simple, ips_simple)

    assert current_if_simple == {
        'interface': 'en0',
        'media': 'Unknown',  # Mac does not give us this
        'media_select': 'autoselect',
        'media_type': '(none)',
        'media_options': None,
    }

    # Complex test case for media line parsing of ifconfig output

# Generated at 2022-06-22 23:37:21.370490
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:31.652396
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This test creates an DarwinNetwork object:
    d = DarwinNetwork()
    and verifies that its platform is "Darwin"

    It also populates an DarwinNetwork dictionary and verifies that media_select is
    set to 'UNKNOWN' as the MacOSX fact module doesn't populate this
    """

    d = DarwinNetwork()
    assert d.platform == 'Darwin'


# Generated at 2022-06-22 23:37:42.423090
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # set the class with no output lines
    dnw = DarwinNetwork()
    # set the current interface
    current_if = {}
    # set the list of IP addresses
    ips = []
    # empty list for the media line
    words = []
    # run the method
    dnw.parse_media_line(words, current_if, ips)
    # check that both media and media_select have been set to Unknown
    if (current_if['media'] != 'Unknown') or (current_if['media_select'] != 'Unknown'):
        raise AssertionError('media or media_select not set to Unknown')
    # 2nd set of input to mimic a bridge interface
    words = ['media:', '<unknown', 'type>']
    # run the method

# Generated at 2022-06-22 23:37:44.052619
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Unit test for constructing DarwinNetworkCollector """
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:37:45.935627
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    i = DarwinNetwork()
    assert i.platform == 'Darwin'

# Generated at 2022-06-22 23:37:57.195481
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_object = DarwinNetwork()
    node = dict()
    node['interfaces'] = dict()
    node['interfaces']['lo0'] = dict()
    darwin_network_object.parse_media_line(
        ['media:', 'autoselect', '(none)'], node['interfaces']['lo0'], []
    )
    assert node['interfaces']['lo0']['media'] == 'Unknown'
    assert node['interfaces']['lo0']['media_select'] == 'autoselect'
    assert node['interfaces']['lo0']['media_type'] == 'none'
    assert node['interfaces']['lo0']['media_options'] == []
    node['interfaces']['lo0'] = dict()
    darwin

# Generated at 2022-06-22 23:38:04.152921
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ["media:", "autoselect", "status:", "active"]
    current_if = dict()
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'
    assert current_if['media_options'] == 'active'

# Generated at 2022-06-22 23:38:15.610495
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_instance = DarwinNetwork()

    # test for media line handling for network - MacOSX
    # line "media: autoselect (<unknown type>)"
    media_line1 = 'media: autoselect (<unknown type>)'
    words1 = media_line1.split()
    current_if1 = {}
    network_instance.parse_media_line(words1, current_if1, None)
    assert current_if1['media'] == 'Unknown'
    assert current_if1['media_select'] == 'autoselect'
    assert current_if1['media_type'] == 'unknown type'
    assert current_if1['media_options'] == []

    # test for media line handling for network - MacOSX
    # line "media: autoselect (1000baseT <full-duplex>)"
    media_

# Generated at 2022-06-22 23:38:19.594723
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # data for one interface
    sample_data = [['media:', 'autoselect', '(none)'],
                   ['status:', 'active']]
    current_if = {'inet': [], 'inet6': [], 'addrs': [], 'media-options': [],
                  'media-status': []}
    ips = []
    # expected result
    expected_result = {'media': 'Unknown', 'media_select': 'autoselect',
                       'media_options': None, 'media_type': '(none)'}

    # create an instance of the class to be tested
    test_DarwinNetwork = DarwinNetwork()
    # run the test
    test_DarwinNetwork.parse_media_line(sample_data[0], current_if, ips)
    # compare the result

# Generated at 2022-06-22 23:38:31.291687
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test a line
    words = ['lladdr', '00:11:22:33:44:55', 'media:', 'autoselect', '(none)', 'status:', 'inactive']
    cif = {}
    ips = []
    DarwinNetwork.parse_media_line(words, cif, ips)
    assert cif['media'] == 'Unknown'
    assert cif['media_select'] == '00:11:22:33:44:55'
    assert cif['media_type'] == 'autoselect (none)'
    assert cif['media_options'] == 'status: inactive'

    # Test a line with only two words, e.g. for a bridge interface of MacOSX

# Generated at 2022-06-22 23:38:40.181784
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if_list = []
    test_if = {
        'name': "en0",
    }
    test_if_list.append(test_if)
    current_if = {
        'name': "en0",
    }
    test_if_list[0] = current_if
    test_ips = []
    test_words = ["media:", "<unknown type>"]
    test_obj = DarwinNetwork(test_if_list, test_ips)
    test_obj.parse_media_line(test_words, current_if, test_ips)
    assert test_if_list[0]['media'] == "Unknown"
    assert test_if_list[0]['media_select'] == "<unknown type>"
    assert test_if_list[0]['media_type'] == "unknown type"

# Generated at 2022-06-22 23:38:51.399431
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork({})

    words = ['media:', 'autoselect', 'status:', 'active']
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == {'status': 'active'}

    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:39:03.194456
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test DarwinNetwork.parse_media_line
    :return:
    """
    # Test with a line for a normal interface
    ifc_line = 'media: autoselect (1000baseT <full-duplex>)'
    ifc_words = ifc_line.split()
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(DarwinNetwork, ifc_words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'
    # Test with a line for a bridge interface
    ifc_line = 'media: <unknown type>'
    ifc_words = ifc_line

# Generated at 2022-06-22 23:39:11.378513
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fact_class, platform, tests_dir, test_dir = DarwinNetworkCollector, 'Darwin', 'small', 'local'
    fact_collector_instance = fact_class(platform, tests_dir, test_dir)
    assert fact_collector_instance.platform == platform
    assert fact_collector_instance.tests_dir == tests_dir
    assert fact_collector_instance.test_dir == test_dir
    assert len(fact_collector_instance.fact_class_list) == 1
    assert isinstance(fact_collector_instance.fact_class_list[0], DarwinNetwork)
    assert fact_collector_instance.fact_class_list[0].platform == platform

# Generated at 2022-06-22 23:39:19.019313
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words
    mod = DarwinNetwork()

    current_if = {}
    words = ['media:', '<unknown', 'type>']
    mod.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    current_if = {}
    words = ['media:', 'autoselect', '(none)', 'status:', 'no', 'carrier']
    mod.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:39:20.721355
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'


# Generated at 2022-06-22 23:39:22.141864
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn=DarwinNetwork()
    assert(dn.platform == 'Darwin')

# Generated at 2022-06-22 23:39:31.899411
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()

# Generated at 2022-06-22 23:39:35.648662
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test if the constructor works correctly
    """
    o = DarwinNetwork()
    assert o.platform == 'Darwin'
    assert o._fact_class == DarwinNetwork
    assert o._platform == 'Darwin'

# Generated at 2022-06-22 23:39:36.649563
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:39:39.441740
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
   d = DarwinNetwork()
   assert d.platform == 'Darwin'
   assert d.media_type == 'unknown type'

# Generated at 2022-06-22 23:39:49.714401
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    DarwinNetwork class' method parse_media_line should return a
    dictionary with the correct values
    """
    # create a DarwinNetwork object to use in test
    darwin_network_collector = DarwinNetworkCollector()

    # create an empty dictionary that will be passed to the
    # method parse_media_line
    current_if = {}

    # create a list with the words that make a line in ifconfig
    # output, this line would be media: <unknown type> status: active
    words = ['media:', '<unknown', 'type>', 'status:', 'active']

    # call the method parse_media_line with the created objects
    darwin_network_collector.fact_class.parse_media_line(words, current_if, 0)

    # assert if the method parse_media_line returned the

# Generated at 2022-06-22 23:39:51.472979
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform=='Darwin', "Platform must be 'Darwin'"

# Generated at 2022-06-22 23:39:53.041233
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:40:04.146686
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    n = DarwinNetwork()
    ifc = dict()
    ips = dict()
    words = ["media:", "Autoselect", "status:", "inactive"]
    n.parse_media_line(words, ifc, ips)
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'Autoselect'
    assert ifc['media_status'] == 'inactive'
    ifc = dict()
    ips = dict()
    words = ["media:", "Autoselect", "(autoselect)", "status:", "active"]
    n.parse_media_line(words, ifc, ips)
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'Autoselect'

# Generated at 2022-06-22 23:40:06.270267
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:40:16.797786
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    current_if = {'name': 'en0', 'type': 'be', 'addr': '172.16.3.3', 'netmask': '255.255.0.0', 'macaddr': '00:50:56:a7:43:bf', 'media': 'Unknown', 'media_select': 'none', 'media_options': None, 'media_type': 'Unknown'}
    t = DarwinNetwork()
    assert t.get_interface(current_if) == ['en0', 'be', '172.16.3.3', '255.255.0.0', '00:50:56:a7:43:bf', 'None', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown']


# Generated at 2022-06-22 23:40:25.722278
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {'media': 'Unknown',
                 'media_select': 'autoselect',
                 'media_type': 'ieee80211',
                 'media_options': [{'status': 'inactive'}]}
    test_words = ['media', 'autoselect', 'ieee80211', '(status', 'inactive)']
    darwin_network_test = DarwinNetwork()
    darwin_network_test.parse_media_line(test_words, interface, [])
    assert interface == {'media': 'Unknown',
                         'media_select': 'autoselect',
                         'media_type': 'ieee80211',
                         'media_options': [{'status': 'inactive'}]}

# Generated at 2022-06-22 23:40:36.716760
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork({})
    # test a single word media line
    words = ('media:', '<unknown type>')
    current_if = {}
    ips = []
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # test a two word media line
    words = ('media:', 'autoselect', '(none)')
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'

    #

# Generated at 2022-06-22 23:40:40.925127
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    iface.parse_media_line(['media:','<unknown','type>'],{},[])
    assert iface.current_if['media_select'] == 'Unknown'
    assert iface.current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:40:47.429092
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    ips = []
    words = ['<unknown', 'type>']
    d.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

    current_if = {}
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    d.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': {}}

# Generated at 2022-06-22 23:40:56.603722
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifinfo = {'device': 'en1', 'inet': list()}
    words = ['media:', 'autoselect', '(none)']
    current_if = ifinfo.copy()
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ifinfo)
    expected_ifinfo = dict(ifinfo)
    expected_ifinfo['media'] = 'Unknown'  # MacOS does not give us this
    expected_ifinfo['media_select'] = 'autoselect'
    expected_ifinfo['media_type'] = '(none)'
    assert expected_ifinfo == current_if

# Generated at 2022-06-22 23:41:05.643519
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    #
    # Setup test data
    #
    media_line_in = "media: <unknown type>"
    words_in = media_line_in.split()

    #
    # Execute the code to be tested
    #
    darwin_network = DarwinNetworkCollector.get_instance()
    darwin_network.parse_media_line(words_in, {}, {})

    #
    # Verify results
    #
    assert words_in[0] == "media:"
    assert words_in[1] == "<unknown"
    assert words_in[2] == "type>"

# Generated at 2022-06-22 23:41:17.538629
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:41:21.015290
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert isinstance(facts, NetworkCollector)
    assert isinstance(facts, DarwinNetworkCollector)
    assert facts.platform() == 'Darwin'
    assert facts.fact_class() == DarwinNetwork

# Generated at 2022-06-22 23:41:26.688036
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.collector == 'ifconfig'
    assert darwin_network.default_interface_command == 'netstat -rn -f inet'
    assert darwin_network.interfaces_command == 'ifconfig -a'

# Generated at 2022-06-22 23:41:28.939141
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()._platform == 'Darwin'
    assert DarwinNetworkCollector()._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:41:30.494063
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'


# Generated at 2022-06-22 23:41:31.811011
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for constructor of class DarwinNetworkCollector"""
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:34.317079
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector.__doc__ == '\'Darwin\' platform network collector'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    

# Generated at 2022-06-22 23:41:34.828681
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:47.360125
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    d._current_if = {'name': 'bridge0'} # not sure if this is used during parsing...

# Generated at 2022-06-22 23:41:49.272228
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)
    assert obj.platform == 'Darwin'
    assert isinstance(obj.facts, DarwinNetwork)

# Generated at 2022-06-22 23:41:51.123417
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork()
    assert facts.platform == 'Darwin'
    assert facts.ifconfig_path == '/sbin/ifconfig'
    assert facts.cache_expiration == 3600

# Generated at 2022-06-22 23:41:52.875243
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:41:54.372878
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    LinuxNetwork(None, {}, [], [])

# Generated at 2022-06-22 23:42:02.363170
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac = DarwinNetwork({})
    mac.parse_media_line(["media:", "autoselect", "(none)"], {}, {'addresses': []})
    assert mac['media_select'] == 'autoselect'
    assert mac['media_type'] == '(none)'

    mac = DarwinNetwork({})
    mac.parse_media_line(["media:", "<unknown", "type>"], {}, {'addresses': []})
    assert mac['media_select'] == 'Unknown'
    assert mac['media_type'] == 'unknown type'


# Generated at 2022-06-22 23:42:05.992588
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector is not None
    assert network_collector.fact_class is not None
    assert network_collector._platform == 'Darwin'


# Generated at 2022-06-22 23:42:08.173073
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-22 23:42:12.880670
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()

    assert collector._platform == 'Darwin'
    assert collector._fact_class.platform == 'Darwin'
    assert isinstance(collector._fact_class, DarwinNetwork)

if __name__ == '__main__':
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:13.647936
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:42:25.724390
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instance
    darwin_network = DarwinNetwork()
    # Define the test data
    test_params = [
        # media line, expected media_select, expected media_type, expected media_options
        (['media:', 'autoselect', '10baseT/UTP', '(none)'], ['autoselect', None, None]),
        (['media:', '<unknown', 'type>', '(none)'], ['Unknown', 'unknown type', None]),
        (['media:', 'autoselect', '<unknown type>', '(none)'], ['autoselect', 'unknown type', None]),
        (['media:', 'autoselect', '<unknown type>', '(flowcontrol)'], ['autoselect', 'unknown type', 'flowcontrol']),
    ]
    # Create empty interface
    current_if = {}
   

# Generated at 2022-06-22 23:42:27.084357
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:27.843557
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None)

# Generated at 2022-06-22 23:42:38.211751
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Check if we are running on the supported platform
    import platform
    current_platform = platform.system()
    if current_platform != 'Darwin':
        return
    # run the unit test
    import unittest
    from . import print_test_result

    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    class TestDarwinNetwork(unittest.TestCase):
        '''
        Test class to check if the DarwinNetwork works.
        '''

        def test_darwin_network_constructor(self):
            '''
            Test constructor with sample output.
            '''

# Generated at 2022-06-22 23:42:47.146258
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_iface = DarwinNetwork()
    darwin_iface.parse_media_line(['media:', 'GigabitEthernet', 'autoselect', '(1000baseT)'], {}, None)
    assert darwin_iface.current_if['media'] == 'Unknown'
    assert darwin_iface.current_if['media_select'] == 'GigabitEthernet'
    assert darwin_iface.current_if['media_type'] == 'autoselect'
    assert darwin_iface.current_if['media_options'] == '(1000baseT)'

# Generated at 2022-06-22 23:42:57.350941
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test the constructor of a DarwinNetwork class instance
    """
    fake_environ = None
    fake_file = 'this_is_just_a_file_fake'
    darwin_network = DarwinNetwork(fake_environ, fake_file)
    assert isinstance(darwin_network, DarwinNetwork)
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.file == fake_file
    assert darwin_network.file_type == 'ifconfig'
    assert darwin_network.file_type == darwin_network.get_file_type()


# Generated at 2022-06-22 23:43:00.070323
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_class = DarwinNetwork('/sbin/ifconfig')
    assert darwin_network_class._platform == 'Darwin'


# Generated at 2022-06-22 23:43:01.109266
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'


# Generated at 2022-06-22 23:43:05.204019
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert type(obj) == DarwinNetworkCollector
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:43:15.546238
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a DarwinNetwork
    network = DarwinNetwork()

    # Create a dictionary to store the current interface information
    current_if = {}

    # Create a list to store all the ips
    ips = []

    # Test with first example
    words = ['media:', 'autoselect', 'status:', 'active']
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_status'] == 'active'

    # Test with second example
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    network.parse_media_line(words, current_if, ips)


# Generated at 2022-06-22 23:43:17.794346
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert  darwin is not None


# Generated at 2022-06-22 23:43:30.153008
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    current_if = {}
    # Test 1: usual word[1]
    dnet.parse_media_line(['media:', 'IEEE802.11', '(autoselect)'],
                          current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'IEEE802.11'
    assert current_if['media_type'] == 'autoselect'
    # Test 2: unknown type
    dnet.parse_media_line(['media:', '<unknown', 'type>'],
                          current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    # Test 3: unknown type, other words

# Generated at 2022-06-22 23:43:31.952400
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:43:32.895875
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:36.936439
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert dn.interface == 'en0'
    assert dn.ipv4 == dict()
    assert dn.ipv6 == dict()


# Generated at 2022-06-22 23:43:48.834140
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>']
    media_line = 'media: <unknown type>'
    current_if = {'name': 'eth0', 'macaddress': '08:00:27:a3:3c:50', 'operstate': 'up', 'mtu': '1500', 'carrier': True,
                  'media_select': '', 'media_type': '', 'media_options': ''}

    expected_if = {'name': 'eth0', 'macaddress': '08:00:27:a3:3c:50', 'operstate': 'up', 'mtu': '1500', 'carrier': True,
                   'media_select': 'unknown', 'media_type': 'type', 'media_options': ''}

# Generated at 2022-06-22 23:43:56.508068
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'IEEE802.11', '(autoselect)', 'status:', 'inactive\n']
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, ['192.168.1.1'])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == 'autoselect'
    assert not current_if['media_options']
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive\n']
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, ['192.168.1.1'])

# Generated at 2022-06-22 23:44:05.927623
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = []
    # media_select = None, media_type = None, media = None, media_options = None
    darwin_network.parse_media_line(['media:','','','',''], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == ''
    assert current_if['media_type'] is None
    assert current_if['media_options'] is None

    current_if = {}
    # media_select = 'Inactive', media_type = None, media = None, media_options = None
    darwin_network.parse_media_line(['media:', 'Inactive', '', '', ''], current_if, ips)
   

# Generated at 2022-06-22 23:44:08.156984
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.fact_class == DarwinNetwork
    assert dnc._platform == 'Darwin'
    assert dnc.data == {}


# Generated at 2022-06-22 23:44:15.345395
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dm = DarwinNetwork()
    # expected output of parse_media_line('media: <unknown type>')
    current_if_test1 = {
        'media': 'Unknown',
        'media_options': None,
        'media_select': 'media',
        'media_type': 'unknown type'
    }
    # expected output of parse_media_line('media: <unknown type> mediaopt')
    current_if_test2 = {
        'media': 'Unknown',
        'media_options': {'mediaopt': True},
        'media_select': 'media',
        'media_type': 'unknown type'
    }
    # test 1
    r = dm.parse_media_line(['media:', '<unknown', 'type>'], {}, [])
    assert r == current_if_test

# Generated at 2022-06-22 23:44:23.066026
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    # create a list of words to test
    words_test = ['<unknown', 'type>']
    dn.parse_media_line(words_test, current_if, None)
    # check that media and media_select, media_type were set properly
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:34.880825
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
	darwin_if = DarwinNetwork()
    # Case 1: words list has correct number of elements
	words = ['media:', 'autoselect', '(none)']
	current_if = dict()
	current_if['media'] = dict()
	ips = dict()
	darwin_if.parse_media_line(words, current_if, ips)
	assert current_if['media'] == 'Unknown'
	assert current_if['media_select'] == 'autoselect'
	assert current_if['media_type'] == 'none'
	assert current_if['media_options'] == []
    # Case 2: words list has incorrect number of elements - <unknown type> will be parsed into 2 words
	words = ['media:', '<unknown', 'type>']
	current_if = dict()

# Generated at 2022-06-22 23:44:45.971132
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line_full = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    media_line_bridge = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    media_line_active = ['media:', '100baseTX', '<full-duplex>', 'status:', 'active']
    media_line = media_line_active
    current_if = dict()
    ips = dict()
    DarwinNetwork.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '100baseTX'
    assert current_if['media_type'] == 'full-duplex'

# Generated at 2022-06-22 23:44:48.939206
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test DarwinNetwork"""

    facts_module = DarwinNetwork()

    assert facts_module.platform == 'Darwin'



# Generated at 2022-06-22 23:44:58.590857
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'name': 'en0'}
    # the media line split into words
    words = ['media:', '<unknown', 'type>', 'autoselect (none) status:', 'inactive']

    dn = DarwinNetwork(None, None)
    dn.parse_media_line(words, current_if, None)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'autoselect (none)'



# Generated at 2022-06-22 23:45:05.466285
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create instance of DarwinNetwork with
    # MacOS 10.13.6 version info.
    # This tests the first 2 lines of DarwinNetwork.
    dn = DarwinNetwork({'kernel': '17.7.0'})
    assert dn.platform == DarwinNetwork.platform
    assert dn.module_name == 'generic_bsd'
    assert dn.module_exec == 'ifconfig {{ ansible_net_interface }} | sed -En \'/^([^\\t]+): flags=/s/^\\1: flags=\\(([^\\)]+)\\).*/flags=\\2/p\''  # noqa
    assert dn.default_iface == 'en0'


# Generated at 2022-06-22 23:45:06.472045
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:45:14.980232
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This tests the constructor of the class DarwinNetwork
    """
    network_collector = DarwinNetwork()
    assert (network_collector._platform == 'Darwin')
    assert (network_collector.platform == 'Darwin')

    # check for proper inheritance from baseclass
    assert (network_collector._fact_class == DarwinNetwork)
    assert (network_collector._platform == 'Darwin')
    assert (network_collector.platform == 'Darwin')
    assert (network_collector._fallback_nic == 'bridge0')

# Generated at 2022-06-22 23:45:25.265050
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()  # class under test
    # all these media lines should give the same result
    media_lines = [
        'autoselect (<unknown type>) status: inactive',
        'autoselect (none) status: inactive',
        'autoselect (none) status: active',
        'media autoselect (none) status: inactive',
        'media 100baseTX <full-duplex> status: active'
    ]
    words = []
    current_if = {}
    ips = []
    for ml in media_lines:
        words = ml.split(' ')
        ifc.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'