

# Generated at 2022-06-22 23:35:29.958620
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ Unit test for method DarwinNetwork.parse_media_line """

    # 1st test
    network = DarwinNetwork()
    words = ["media:", "autoselect"]
    current_if = {}
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "autoselect"

    # 2nd test
    network = DarwinNetwork()
    words = ["media:", "autoselect", "(100baseTX)"]
    current_if = {}
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "autoselect"
   

# Generated at 2022-06-22 23:35:36.873182
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Example media line (from Darwin 15.6, macOS 10.11.6)
    # media: auto (1000baseT <full-duplex>,unknown type)
    media_line_words = 'media: auto (1000baseT,unknown type)'
    current_if = dict()
    ips = dict()
    DarwinNetwork.parse_media_line(DarwinNetwork, media_line_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options']['unknown type'] == True
    # Example media line (from Darwin 15.6, macOS 10.11.6)
    # media: auto (1000baseT <full-duplex

# Generated at 2022-06-22 23:35:38.526354
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert (DarwinNetworkCollector._platform == 'Darwin')
    assert (DarwinNetworkCollector._fact_class == DarwinNetwork)

# Generated at 2022-06-22 23:35:49.322395
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    current_if['ipv4'] = None
    current_if['ipv6'] = None
    current_if['media'] = ""
    dn = DarwinNetwork(current_if)
    words = ['media:', 'autoselect', '(none)']
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    words = ['media:', '10baseT/UTP', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == 'unknown type'
    words = ['media:', '<unknown', 'type>', '(none)']

# Generated at 2022-06-22 23:35:52.205978
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'
    assert isinstance(obj._facts, dict)

# Generated at 2022-06-22 23:35:53.170828
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork().platform == 'Darwin'

# Generated at 2022-06-22 23:35:54.513069
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:06.676546
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    ips = {}

    d.parse_media_line(['media:', 'autoselect', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'][0] == 'none'

    d.parse_media_line(['media:', '1000baseT', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1000baseT'
    assert current_if['media_type'] == '(none)'

# Generated at 2022-06-22 23:36:08.418733
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    test = DarwinNetwork('BSD', 'en3')
    print (test)

# Generated at 2022-06-22 23:36:09.928877
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None).platform == 'Darwin'


# Generated at 2022-06-22 23:36:17.207686
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork({}, {}, {})
    assert darwin_net.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)'},\
        "The media line parser didn't work correctly"
    assert darwin_net.parse_media_line(['media:', '1000baseT', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': '1000baseT', 'media_type': '(none)'},\
        "The media line parser didn't work correctly"

# Generated at 2022-06-22 23:36:24.882272
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup
    d = DarwinNetwork()
    words = ['media:', 'autoselect']
    current_if = {}
    ips = None

    # Set current_if['media'] to 'Unknown'
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

    # Set current_if['media_select'] to 'autoselect'
    d.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'

    # Set current_if['media_select'] to '<unknown' and
    # current_if['media_type'] to 'unknown type'
    words = ['media:', '<unknown', 'type>']

# Generated at 2022-06-22 23:36:25.745923
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:36:27.862459
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:36:29.669878
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == "Darwin"


# Generated at 2022-06-22 23:36:30.475257
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:41.349848
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = []
    current_if = {}
    ips = []

    # MacOSX el Capitan
    words = ['<unknown type>', 'active', 'autoselect', '(none)']
    current_if = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown type>'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-22 23:36:43.007174
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result.platform == 'Darwin'
    assert result.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:36:54.800994
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    testcases = {
        'media_select': ['autoselect', '10GbaseT', '10GbaseT'],
        'media_type': ['n/a', '<unknown type>', 'Full'],
        'media_options': [{}, {}, {'Flow-control': 'on', 'status': 'active'}]
    }
    # each line is a testcase
    inputlines = [
        'media: autoselect (n/a)',
        'media: 10GbaseT <unknown type>',
        'media: 10GbaseT (Full-duplex, Flow-control, Rx-flow-control, status: active)'
    ]
    for line in inputlines:
        words = line.split()
        current_if = dict()
        d.parse_media_line

# Generated at 2022-06-22 23:36:57.889489
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert isinstance(darwin_network, DarwinNetwork)
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-22 23:37:04.879506
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    sample_line = ['media:', '<unknown type>', 'full-duplex']
    ifc_dict = {}

    obj = DarwinNetwork()
    obj.parse_media_line(sample_line, ifc_dict, {})

    assert ifc_dict['media'] == 'Unknown'
    assert ifc_dict['media_select'] == 'Unknown'
    assert ifc_dict['media_type'] == 'unknown type'
    assert ifc_dict['media_options'] == {'full-duplex': ''}

# Generated at 2022-06-22 23:37:05.916445
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()
    assert True

# Generated at 2022-06-22 23:37:07.379721
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None, None).platform == 'Darwin'

# Generated at 2022-06-22 23:37:10.884845
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork({}, {}, {})
    assert facts.platform == 'Darwin'
    assert facts.parse_media_line([], {}, {}) == None



# Generated at 2022-06-22 23:37:21.897567
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from collections import namedtuple
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeRunner(object):
        def __init__(self, results={}, fail=False):
            self.results = results
            self.fail = fail

        def run(self, module, args, check_rc=True):
            facts = dict(ansible_facts=dict(ansible_network_resources=dict()))
            if self.fail:
                return namedtuple('result', 'failed rc stderr')(
                    fail=True, rc=1, stderr='not ok')
            else:
                return namedtuple('result', 'failed rc stderr')(
                    fail=False, rc=0, stderr=self.results)

    runner = FakeRunner()
    collector = DarwinNetworkCollector

# Generated at 2022-06-22 23:37:25.427313
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Check that the Darwin network class is properly created.
    
    :return: None
    """
    network = DarwinNetwork()
    assert network.platform == 'Darwin'
    assert network.state == {}

# Generated at 2022-06-22 23:37:28.889532
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector._platform = DarwinNetwork.platform
    collector = DarwinNetworkCollector()
    assert collector.platform == DarwinNetwork.platform
    assert collector.fact_class == DarwinNetwork
    assert collector.fact_class._platform == DarwinNetwork.platform

# Generated at 2022-06-22 23:37:30.462626
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d1 = DarwinNetwork()
    assert d1.platform == 'Darwin'

# Generated at 2022-06-22 23:37:31.910154
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)

# Generated at 2022-06-22 23:37:42.666804
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:37:54.214882
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ Test the parse_media_line method of the DarwinNetwork class.
    """
    iface = dict()
    cif = DarwinNetwork()

    cif.parse_media_line(['media:', 'none', 'status:', 'inactive'], iface, dict())
    assert iface['media_select'] == 'none'
    assert 'media_type' not in iface
    assert 'media_options' not in iface

    iface = dict()
    cif.parse_media_line(['media:', '1000baseT', '(none)'], iface, dict())
    assert iface['media_select'] == '1000baseT'
    assert iface['media_type'] == '(none)'
    assert 'media_options' not in iface

    iface = dict()
    cif.parse_media_line

# Generated at 2022-06-22 23:37:55.747255
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # pylint: disable=no-member
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:57.575695
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:38:07.171114
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    # Test 1: word list with only one entry
    test_word_list = ['media:', 'type', 'unknown', 'type', 'status:', 'active']
    ifc.parse_media_line(test_word_list, {}, None)
    assert(ifc.current_if['media'] == 'Unknown')
    assert(ifc.current_if['media_select'] == 'type')
    # Test 2: word list with three entries
    test_word_list = ['media:','autoselect','(none)','status:','active']
    ifc.parse_media_line(test_word_list, {}, None)
    assert(ifc.current_if['media'] == 'Unknown')
    assert(ifc.current_if['media_select'] == 'autoselect')

# Generated at 2022-06-22 23:38:08.757550
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:38:19.516511
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(["media:", "autoselect", "status:", "inactive"], {}, {})
    assert ifc.current_if['media'] == 'Unknown'
    assert ifc.current_if['media_select'] == "autoselect"
    assert ifc.current_if['media_status'] == 'inactive'

    ifc.parse_media_line(["media:", "<unknown", "type>"], {}, {})
    assert ifc.current_if['media'] == 'Unknown'
    assert ifc.current_if['media_select'] == "Unknown"
    assert ifc.current_if['media_type'] == 'unknown type'


# Generated at 2022-06-22 23:38:31.244166
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mif = {}
    mips = ''
    mac_test_line0 = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    mac_test_line1 = ['media:', 'autoselect', '(1000baseT)', 'full-duplex', 'status:', 'active']
    mac_test_line2 = ['media:', '<unknown type>', 'status:', 'inactive']

    print(mif)
    DarwinNetwork.parse_media_line(DarwinNetwork, mac_test_line0, mif, mips)
    print(mif)

    DarwinNetwork.parse_media_line(DarwinNetwork, mac_test_line1, mif, mips)
    print(mif)


# Generated at 2022-06-22 23:38:40.152488
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()

    current_if = {}
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    test_object.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    test_object.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-22 23:38:51.358272
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    fake_ifconfig_path = 'tests/unit/module_utils/facts/network/utils/fake_ifconfig_darwin'
    fake_netstat_path = 'tests/unit/module_utils/facts/network/utils/fake_netstat_darwin'
    fake_route_path = 'tests/unit/module_utils/facts/network/utils/fake_route_darwin'
    network = DarwinNetwork(fake_ifconfig_path, fake_netstat_path, fake_route_path)
    # There are 4 interfaces
    assert len(network._interfaces) == 4

    assert network.get_interface_names() == ['lo0', 'gif0', 'stf0', 'en0']


# Generated at 2022-06-22 23:38:53.670227
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:55.288233
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj

# Generated at 2022-06-22 23:38:57.220178
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == "Darwin"

# Generated at 2022-06-22 23:39:00.516283
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _unittest_DarwinNetworkCollector = DarwinNetworkCollector()
    assert _unittest_DarwinNetworkCollector.platform == 'Darwin'
    assert _unittest_DarwinNetworkCollector.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:39:06.418970
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    current_if = {'name': 'bridge0'}
    ips = []

    words = ['media:', '<unknown', 'type>', 'status:', '<active>']
    dwn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:39:15.529412
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # generate a line for the macOS media line
    line = 'media: <unknown type>'

    # create a DarwinNetwork
    darwin = DarwinNetwork()

    # create a dict with the interface name
    interface = dict()
    interface['name'] = 'en0'

    # build a dict of dictionaries
    interfaces = dict()
    interfaces[interface['name']] = interface

    # call the method with the line, the interface name and the dict of dict
    darwin.parse_media_line(line.split(), interface['name'], interfaces)

    # check if the media_select element has 'Unknown' as value
    assert(interfaces['en0']['media_select'] == 'Unknown')

    # check if the media_type element has 'unknown type' as value

# Generated at 2022-06-22 23:39:16.650274
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()


# Generated at 2022-06-22 23:39:17.629960
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:39:20.225846
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # The class should instantiate with no error for any platform
    dp = DarwinNetwork({})
    assert dp is not None


# Generated at 2022-06-22 23:39:22.693000
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:39:30.245852
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = "media: <unknown type>"
    # the line parser splits the line in words
    words = (line.split(':', 1))[1].split()
    iface = {'iface': 'bond0', 'type': 'ether'}
    MacNetwork = DarwinNetwork()
    MacNetwork.parse_media_line(words, iface, None)
    if iface['media'] != 'Unknown':
        print(iface)
        raise Exception('DarwinNetwork parse_media_line: failed to parse media line: ' + line)

# Generated at 2022-06-22 23:39:34.051465
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    nc = DarwinNetworkCollector()
    assert nc.fact_class == DarwinNetwork
    assert nc.platform == 'Darwin'

# Generated at 2022-06-22 23:39:35.737616
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'


# Generated at 2022-06-22 23:39:43.914900
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:39:44.810407
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj=DarwinNetwork()
    assert obj


# Generated at 2022-06-22 23:39:56.524827
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from copy import deepcopy
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import Mock

    network = Mock(spec=GenericBsdIfconfigNetwork)
    network.parse_media_line.__globals__['get_options'] = Mock()
    network.parse_media_line.__globals__['get_options'].return_value = None

    if_list = deepcopy(GenericBsdIfconfigNetwork.if_list)
    current_if = {}
    ips = []

    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']

# Generated at 2022-06-22 23:39:57.674954
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork({}, {})

# Generated at 2022-06-22 23:40:09.201322
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    macos = DarwinNetwork({}, {}, {})
    # parse_media_line(words, current_if, ips)
    # Default case - media_select, media_type
    words = ['media:', 'autoselect', '100baseTX', 'mediaopt', 'none']
    current_if = {}
    media_options = []

    macos.parse_media_line(words, current_if, media_options)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX', 'media_options': []}
    # Bridge case - media_select, <unknown type>
    words = ['media:', '<unknown', 'type>', 'mediaopt', 'none']
    current_if = {}
    media_options = []

    macos

# Generated at 2022-06-22 23:40:13.408772
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert(isinstance(obj, DarwinNetworkCollector))


# Generated at 2022-06-22 23:40:14.606996
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork("em1")
    assert d is not None

# Generated at 2022-06-22 23:40:25.220154
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    if1 = {'device': 'en0', 'flags': ['UP', 'RUNNING'], 'mtu': '1500', 'media': 'Unknown'}
    if2 = {'device': 'lo0', 'flags': ['UP', 'RUNNING', 'LOOPBACK', 'MULTICAST']}
    if3 = {'device': 'gif0', 'flags': ['UP', 'RUNNING', 'POINTOPOINT', 'MULTICAST', 'NOARP'],
           'media_select': 'IEEE', 'media_type': '802.3', 'media_options': '10baseT/UTP', 'mtu': '1280', 'metric': '0'}

# Generated at 2022-06-22 23:40:33.940667
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    class FakeWords(list):
        def __str__(self):
            return ' '.join(self)
    words = FakeWords(['<unknown', 'type>'])
    current_if = dict()
    ips = dict()
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media'] == 'Unknown'
    assert 'media_options' not in current_if

# Generated at 2022-06-22 23:40:40.254342
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    current_if = dict()
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    assert net.parse_media_line(words, current_if, None) is None
    assert 'media' not in current_if
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-22 23:40:40.815326
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:40:49.279254
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words=[]
    current_if={}
    ips=[]
    # Test 1
    words=['media:','<unknown','type>','options']
    current_if=DarwinNetwork.parse_media_line(words,current_if,ips)
    assert(current_if['media_select']=='Unknown')
    assert(current_if['media_type']=='unknown type')
    assert(current_if['media_options']==['options'])

    # Test 2
    words=['media:','autoselect','(1000baseT)','full-duplex,','flow-control']
    current_if=DarwinNetwork.parse_media_line(words,current_if,ips)
    assert(current_if['media_select']=='autoselect')

# Generated at 2022-06-22 23:40:57.817029
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_collector = DarwinNetwork()
    current_if = {}
    ips = {}
    words = ['media:', 'autoselect', 'status:', 'active']
    network_collector.parse_media_line(words, current_if, ips)
    assert current_if["media"] == 'Unknown'
    assert current_if["media_select"] == 'autoselect'
    assert current_if["media_type"] == 'status:'
    assert current_if["media_options"] == 'active'

# Generated at 2022-06-22 23:41:05.883441
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    hostname = 'darwin'
    interface_name = 'en0'
    current_if = {}
    media_info = ['media:', 'autoselect', '(none)']
    darwin_network = DarwinNetwork(hostname, interface_name, current_if, media_info)

    assert darwin_network._hostname == hostname
    assert darwin_network._interface_name == interface_name
    assert darwin_network._current_if == current_if
    assert darwin_network._media_info == media_info



# Generated at 2022-06-22 23:41:07.705515
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj is not None

# Generated at 2022-06-22 23:41:18.885824
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test if method parse_media_line of class DarwinNetwork works correctly.
    The test is done by checking if method adds the keys media,
    media_select, media_type and media_options correctly to the dictionary
    given to it.
    """
    testobj = DarwinNetwork()
    testobj._module = ""
    testobj.enumerate_interfaces = {}
    testobj.current_if = {}

    # Test for when words[0:3] are correct - the correct fields are added
    # to the dictionary
    words = ['media:', 'none', 'status:', 'active']
    testobj.parse_media_line(words, testobj.current_if, testobj.ips)
    assert testobj.current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:41:20.049245
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork


# Generated at 2022-06-22 23:41:28.431164
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'media': None,
        'media_select': None,
        'media_type': None,
        'media_options': None,
    }
    dn = DarwinNetwork()
    dn.parse_media_line(['media:', '<unknown type>'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None



# Generated at 2022-06-22 23:41:31.255380
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # create an object for testing the DarwinNetwork class
    my_object = DarwinNetwork({})
    # check if object is an instance of DarwinNetwork
    assert isinstance(my_object, DarwinNetwork)

# Generated at 2022-06-22 23:41:39.031093
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Running test with a simulated media line in which a media_type
    # is given and options are present
    line = "media: autoselect (1000baseT <full-duplex>) status: active"
    words = line.split()
    current_if = {}
    ips = {}
    mac_network = DarwinNetwork()
    result = mac_network.parse_media_line(words, current_if, ips)
    assert result ==  True
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT <full-duplex>'
    assert current_if['media_options'] == {'status': 'active'}
    # Running test with a simulated media line in which only a media_type


# Generated at 2022-06-22 23:41:42.523729
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    try:
        # Instantiate DarwinNetworkCollector
        DarwinNetworkCollector()
        # If we reach here, the constructor worked
        assert True
    except:
        assert False

# Generated at 2022-06-22 23:41:49.937414
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork({})

    # test 1: media line with all options, refer to Darwin-16.7.0
    words = ["media:", "autoselect", "(100baseTX", "<full-duplex>,", "100Mb/s)"]
    current_if = {}
    ips = {}
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == { 'full-duplex': None, '100Mb/s': None }

    # test 2: media line for bridge interface, refer to Darwin-16.7.0

# Generated at 2022-06-22 23:42:01.422864
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # Test for bridge media line
    line = ['media:', '<unknown', 'type>']
    result = dn.parse_media_line(line, {}, [])
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'Unknown'
    assert result['media_type'] == 'unknown type'

    # Test for vlan media line
    line = ['media:', 'autoselect', '(vlan)', 'status:', 'active']
    result = dn.parse_media_line(line, {}, [])
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == 'vlan'

    # Test for wifi media line

# Generated at 2022-06-22 23:42:13.142150
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['foo']
    current_if = dict()
    ips = dict() # not used here
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == ''
    assert current_if['media_select'] == 'foo'
    assert current_if['media_options'] == dict()

    words = ['foo', 'bar']
    current_if = dict()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == ''
    assert current_if['media_select'] == 'foo'

# Generated at 2022-06-22 23:42:17.202150
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '<unknown', 'type>']
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:42:19.449259
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:42:20.845290
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'



# Generated at 2022-06-22 23:42:30.456709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import re
    # Mock the current interface object

# Generated at 2022-06-22 23:42:32.958569
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    retval = DarwinNetwork()
    assert retval.platform == 'Darwin'
    assert retval.media_lines[0].search_re.pattern == r'media: (\S+ )?(<unknown type>|\S+)( \((.+)\))?'

# Generated at 2022-06-22 23:42:34.403378
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'

# Generated at 2022-06-22 23:42:36.977260
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'


# Generated at 2022-06-22 23:42:48.152285
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': 'Unknown'}
    darwin = DarwinNetwork()
    # tests on a valid line
    words = darwin.parse_media_line(['media:', 'autoselect', '(100baseTX <full-duplex>)'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX <full-duplex>'
    assert len(current_if) == 3
    # tests on a line missing optional fields
    words = darwin.parse_media_line(['media:', 'autoselect'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select']

# Generated at 2022-06-22 23:42:55.483634
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    line = ['media: <unknown type>', '<unknown type>', 'unknown type']
    current_if = {}
    ips = {}

    DarwinNetwork().parse_media_line(line, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:42:59.643291
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This function is used to test the constructor of the class DarwinNetworkCollector.
    """
    test_obj = DarwinNetworkCollector()
    assert isinstance(test_obj._fact_class, DarwinNetwork)
    assert test_obj._platform == 'Darwin'


# Generated at 2022-06-22 23:43:01.565672
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:43:03.056600
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Just test that the module can be instantiated
    object = NetworkCollector()
    assert object

# Generated at 2022-06-22 23:43:05.886846
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect()

# Generated at 2022-06-22 23:43:07.825556
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._fact_class is not None
    assert DarwinNetworkCollector._platform is not None

# Generated at 2022-06-22 23:43:12.918643
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    os = NetworkCollector._parse_os_release()
    Darwin_obj = DarwinNetworkCollector()
    # Check OS and Platform variables are correct
    assert Darwin_obj._platform == "Darwin"
    assert Darwin_obj._fact_class == DarwinNetwork
    # Check _parse_os_release method returns correct data
    assert os == 'Darwin'

# Generated at 2022-06-22 23:43:24.522889
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Testing the method parse_media_line of class DarwinNetwork
    """
    # Test case where media line is fine
    test_if = {'ipv4': {}}
    test_ifconfig = 'media: autoselect\n'
    test_words = test_ifconfig.split()
    DarwinNetwork.parse_media_line(test_words, test_if, test_if['ipv4'])
    assert 'media' in test_if
    assert test_if['media'] == 'Unknown'
    assert 'media_select' in test_if
    assert test_if['media_select'] == 'autoselect'
    assert 'media_type' not in test_if
    assert 'media_options' not in test_if

    # Test case where media_type is given

# Generated at 2022-06-22 23:43:26.574419
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    klass = collector._fact_class
    assert klass == DarwinNetwork

# Generated at 2022-06-22 23:43:27.161785
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:38.873707
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test constructor of DarwinNetwork class"""
    darwinNet = DarwinNetwork()
    assert darwinNet
    assert darwinNet.platform == "Darwin"
    assert darwinNet.parse_uptime(["13:41:07", "up", "1165", "days,", "20:08,", "0", "users,", "load", "averages:", "0.00,", "0.00,", "0.00", "127", "packages", "can", "be", "updated.", "0", "updates", "are", "security", "updates."]) == (1165.0, 0.0)

# Generated at 2022-06-22 23:43:50.766227
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pylint: disable=line-too-long,invalid-name
    # Test case 1
    current_if = dict()
    ips = dict()
    words = ['media:', 'Ethernet', 'autoselect', '(100baseTX', '<full-duplex>']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == dict(media='Unknown', media_select='Ethernet', media_type='autoselect', media_options=dict(full_duplex='full-duplex'))

    # Test case 2
    current_if = dict()
    ips = dict()
    words = ['media:', 'Ethernet', 'autoselect', '(100baseTX', '<half-duplex>']

# Generated at 2022-06-22 23:43:53.884309
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # create instance of DarwinNetworkCollector
    obj = DarwinNetworkCollector()
    # check if DarwinNetworkCollector is subclass of NetworkCollector
    assert isinstance(obj, NetworkCollector)


# Generated at 2022-06-22 23:43:57.260258
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''Unit test for constructor of DarwinNetwork'''
    device = DarwinNetwork()
    assert device.platform == 'Darwin'
    assert isinstance(device, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:44:00.170208
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

if __name__ == "__main__":
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:05.656762
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    current_if = {}
    ips = []
    words = ['media:', 'autoselect', '(1000baseT)', 'status:', 'active']
    expected = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(1000baseT)'}

    # Act
    DarwinNetwork.parse_media_line(words, current_if, ips)

    # Assert
    assert current_if == expected

# Generated at 2022-06-22 23:44:06.234674
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), DarwinNetworkCollector)

# Generated at 2022-06-22 23:44:08.520516
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ test the DarwinNetworkCollector constructor """
    facts = DarwinNetworkCollector()
    assert facts is not None
    assert facts.platform == DarwinNetworkCollector._platform

# Generated at 2022-06-22 23:44:15.558293
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create mock data and instance of class to test
    darwin_current_if = {'media_select': '', 'media': '', 'media_type': '', 'media_options': []}
    darnwin_net = DarwinNetwork()

    # words is an array of mock data, the function will be run on them
    words = ['foo', 'bar', 'baz']

    # run parse_media_line on the mock data
    darwin_current_if = darnwin_net.parse_media_line(words, darwin_current_if, {})

    # check the result are as expected
    assert darwin_current_if['media_select'] == 'bar'
    assert darwin_current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:44:17.005958
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    test_DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:20.282487
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class.platform == 'Darwin'


# Generated at 2022-06-22 23:44:26.307078
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: autoselect <unknown type> status: inactive'
    current_if = {}
    ips = {}

    ifconfig = DarwinNetwork({'config' : {'network' : {'config': 'bsd'}}})
    ifconfig._current_if = current_if
    ifconfig._current_ips = ips
    ifconfig.parse_media_line(line.split(), current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:29.229011
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test Darwin Network class constructor
    """
    collector = DarwinNetwork()
    assert collector.platform == 'Darwin'

# Generated at 2022-06-22 23:44:39.033568
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    input_str_1 = ["media:", "<unknown type>", "status:", "active"]
    input_str_2 = ["media:", "<unknown type>"]
    input_str_3 = ["media:", "autoselect", "(1000baseT)", "status:", "inactive"]
    input_str_4 = ["media:", "autoselect", "en0", "status:", "inactive"]
    input_str_5 = ["status:", "active"]
    input_str_6 = ["media:", "1000baseT", "status:", "active"]

    # stores the expected result corresponding to the input
    expected_output = dict()
    expected_output['media'] = 'Unknown'
    expected_output['media_select'] = 'Unknown'
    expected_output['media_type'] = 'unknown type'


# Generated at 2022-06-22 23:44:40.661840
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network is not None


# Generated at 2022-06-22 23:44:48.637257
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    inter = {}
    words = ['media:', '<unknown', 'type>', 'speed:', 'auto', 'requested', 'speed:', '12', 'priority:', '6', 'full-duplex']
    darwin_net = DarwinNetwork()
    darwin_net.parse_media_line(words, inter, None)
    assert inter['media'] == 'Unknown'
    assert inter['media_select'] == 'Unknown'
    assert inter['media_type'] == 'unknown type'


# Generated at 2022-06-22 23:44:51.673460
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_net_collector = DarwinNetworkCollector('3.10.0_Darwin')
    assert isinstance(darwin_net_collector._fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:45:01.182162
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mac = DarwinNetwork()
    # we call the get_interfaces method to initialise the property self.interfaces
    mac.get_interfaces()
    # test output for a given interface
    mac_en0 = mac.interfaces.get('en0')
    assert mac_en0['mtu'] == '1500'
    assert mac_en0['pci_bus_id'] == '0x00'
    assert mac_en0['macaddress'] == '0:0:0:0:0:0'
    # test output for another interface
    mac_en1 = mac.interfaces.get('en1')
    assert mac_en1['mintu'] == '1500'

# Generated at 2022-06-22 23:45:13.051735
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', '(autoselect)']
    current_if = {}
    ips = []
    d.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'Unknown'
    assert 'media_type' in current_if
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' in current_if
    assert current_if['media_options'] == ['autoselect']

    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)']

# Generated at 2022-06-22 23:45:15.277130
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({})
    assert dn.platform == "Darwin"


# Generated at 2022-06-22 23:45:16.632511
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    o = DarwinNetworkCollector()
    assert o._platform == 'Darwin'

# Generated at 2022-06-22 23:45:19.226203
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_nd = DarwinNetwork()
    assert darwin_nd.__class__.platform == 'Darwin'

