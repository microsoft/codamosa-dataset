

# Generated at 2022-06-22 23:35:29.225806
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a test object for the class
    import collections
    testobj = DarwinNetwork()
    testobj.interfaces = collections.OrderedDict()

    # test the parse media line method
    test_words = ['fixed', 'IEEE', '100baseTX']
    testobj.parse_media_line(test_words, testobj.interfaces['test'], [])
    assert testobj.interfaces['test'] == {'media': 'Unknown',
                                          'media_select': 'IEEE',
                                          'media_type': '100baseTX',
                                          'media_options': []}

    test_words = ['fixed', '100baseTX']
    testobj.parse_media_line(test_words, testobj.interfaces['test'], [])

# Generated at 2022-06-22 23:35:29.754680
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork

# Generated at 2022-06-22 23:35:36.759828
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

  # word list with 'media' line
  words_media = ['media:', 'autoselect', '(100baseTX', 'full-duplex)', 'status:', 'active']
  # create the test object
  darwin_network = DarwinNetwork(dict())

  # argument 'words' should be set correctly from the list above
  assert darwin_network.words == words_media

  # argument 'current_if' is an empty dictionary
  assert darwin_network.current_if == dict()

  # argument 'ips' is an empty dictionary
  assert darwin_network.ips == dict()

  # execute method
  darwin_network.parse_media_line()

  # 'media' should be set to 'Unknown'
  assert darwin_network.current_if['media'] == 'Unknown'

  # '

# Generated at 2022-06-22 23:35:44.669671
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_input = [
        ('media: <unknown type>', 'Unknown', 'unknown type', 0),
        ('media: autoselect status: inactive', 'autoselect', 'inactive', 0),
        ('media: autoselect (1000baseT <full-duplex,flow-control>)', 'autoselect', '1000baseT', 'full-duplex,flow-control'),
        ('media: 10baseT/UTP <full-duplex>', '10baseT/UTP', 'full-duplex', 0),
        ('media: 10baseT/UTP <full-duplex,flow-control>', '10baseT/UTP', 'full-duplex', 'flow-control')
    ]
    for media_line, media_select, media_type, media_options in test_input:
        assert DarwinNetwork.parse

# Generated at 2022-06-22 23:35:55.421533
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import parse_media_line
    current_if = {'ifconfig_interfaces': {}}

    # normal line
    words = ['media:', 'auto', '1Gbit/s', 'full', '(1000baseT/']
    parse_media_line(words, current_if, {})
    assert 'media' in current_if
    assert current_if['media'] == 'auto'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'auto'
    assert 'media_type' in current_if
    assert current_if['media_type'] == '1Gbit/s'
    assert 'media_options' in current_if

# Generated at 2022-06-22 23:35:59.163445
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_darwin_network = DarwinNetwork()
    assert test_darwin_network.platform == 'Darwin'
    print("TEST PASS: DarwinNetwork")


# Generated at 2022-06-22 23:36:10.861722
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:36:15.586337
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    words = ['inet', '<unknown', 'type>', ',']
    with pytest.raises(IndexError):
        dn.parse_media_line(words, current_if)

# Generated at 2022-06-22 23:36:16.209992
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:36:19.311539
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_test_DarwinNetwork = DarwinNetwork()
    assert my_test_DarwinNetwork.platform == 'Darwin'
    assert isinstance(my_test_DarwinNetwork.collect(), dict)

# Generated at 2022-06-22 23:36:20.821087
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net

# Generated at 2022-06-22 23:36:22.892333
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.name == 'Darwin'
    assert dn.platform == 'Darwin'


# Generated at 2022-06-22 23:36:30.876123
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(['media:', 'Autoselect', '10baseT/UTP'], {}, {'inet4': [], 'inet6': []}) == {
        'media_options': '10baseT/UTP',
        'media_select': 'Autoselect',
        'media_type': 'UTP',
        'media': 'Unknown'
    }

# Generated at 2022-06-22 23:36:32.235565
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:34.138037
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class is DarwinNetwork

# Generated at 2022-06-22 23:36:35.971812
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Check that an DarwinNetworkCollector class constructor works correctly
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:45.499439
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    os_net = DarwinNetwork()

    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}
    os_net.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == None
    assert current_if['media_options'] == None

    words = ['media:', 'autoselect', 'status:', 'active']
    current_if = {}
    ips = {}
    os_net.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:36:46.595340
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:56.629909
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    dwn.interface = {}
    dwn.interface['name'] = 'lo0'
    dwn.interface['network'] = '127.0.0.0'
    dwn.interfaces = ['lo0']
    expected = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'ieee80211', 'media_options': {'nonegotiate': None}}
    dwn.parse_media_line(['media:', 'autoselect', '(ieee80211)', 'nonegotiate'], dwn.interface, dwn.facts)
    assert dwn.interface == expected

# Generated at 2022-06-22 23:37:03.024280
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:', 'autoselect', '(none)'], current_if, {})
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect'}

    current_if = {}
    dn.parse_media_line(['media:', 'autoselect', '(unknown type)'], current_if, {})
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}

    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>'], current_if, {})

# Generated at 2022-06-22 23:37:06.456391
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Constructor requires collect_ipv4 and collect_ipv6
    # which may be used for generating facts
    obj = DarwinNetworkCollector(True, True)
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:37:18.000797
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w1 = "media: <unknown type>"
    w2 = "media: <unknown> <unknown type>"
    w3 = "media: <unknown> <unknown type> d"
    w4 = "media: <unknown> <unknown type> (none)"
    w5 = "media: <unknown> <unknown type> (ext:"
    words = w1.split()
    darwin_net = DarwinNetwork()
    org_if = {'media': 'Unknown'}
    exp_if = {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>'}
    assert darwin_net.parse_media_line(words, org_if, None) == exp_if
    words = w2.split()
    org_if = {'media': 'Unknown'}
    exp_

# Generated at 2022-06-22 23:37:21.682276
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    test_dict = dict()
    test_dict['media']     = 'Unknown'
    test_dict['media_select'] = 'media_select_value'
    test_dict['media_type'] = 'media_type_value'
    test_dict['media_options'] = dict()
    test_dict['media_options']['test_key'] = 'test_value'
    test_list = list()
    test_list.append('test_string_1')
    test_list.append('test_string_2')
    test_list.append('test_string_3')
    test_list.append('test_key=test_value')
    darwin_network.parse_media_line(test_list, test_dict, dict())  # The unused ips parameter

# Generated at 2022-06-22 23:37:30.754181
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This is a unit test for the DarwinNetwork constructor
    """
    an = DarwinNetwork()
    assert an.platform == 'Darwin'
    assert an.media_select == "select"
    assert an.media_options == "Options"
    assert an.media_type == "Type"
    assert an.media == "Media"
    assert an.inet == 'inet'
    assert an.inet6 == 'inet6'
    assert an.scan_interfaces == '/sbin/ifconfig -a'
    assert an.supports_cloned_interfaces is False
    assert an.supports_multiple_interface_names is False
    assert an.supports_bonding is False

# Generated at 2022-06-22 23:37:33.846204
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # NB cannot include ifconfig -a as macOS gives
    # WARNING: ifconfig output is not satisfying the following expectations
    # test the other branches of the 'if'
    assert True


# Generated at 2022-06-22 23:37:39.042120
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork()
    assert darwin.parse_media_line(['media:','<unknown','type>'], {}, {}) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-22 23:37:51.387738
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This is a unittest for the DarwinNetwork class.
    """

# Generated at 2022-06-22 23:37:53.103884
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert facts._platform == 'Darwin'
    assert isinstance(facts, DarwinNetwork)

# Generated at 2022-06-22 23:37:56.669182
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """

    test_words = ['media:', '<unknown', 'type>']
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}
    ips = []
    DarwinNetwork.parse_media_line(test_words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''



# Generated at 2022-06-22 23:38:06.554700
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    intf = DarwinNetwork(None)
    # Media line for Ethernet
    words = [None, 'Autoselect', '10baseT/UTP']
    current_if = {'media': '10baseT/UTP', 'media_select': 'Autoselect', 'media_type': '10baseT/UTP'}
    assert intf.parse_media_line(words, current_if, None) == current_if

    # Media line for a bridge Interface
    words = [None, '<unknown', 'type>', 'full-duplex']
    current_if = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type',
                  'media_options': 'full-duplex'}
    assert intf.parse_media_line(words, current_if, None) == current_

# Generated at 2022-06-22 23:38:12.067329
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    iface = {}
    obj.parse_media_line(['media:', '<unknown', 'type>', 'status:', 'inactive'], iface, None)
    assert iface == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'status': 'inactive'}

# Generated at 2022-06-22 23:38:21.124881
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ DarwinNetwork_parse_media_line() returns dict. """
    obj = DarwinNetwork(None)
    # TODO : dict()s below give different results between Python 2.7 and 3.7
    if1_words = dict({
                      'default': ['media:', 'autoselect', '(1000baseT)'],
                      'bridge': ['media:', '<unknown', 'type>']
                      })
    for word_set, word_list in if1_words.items():
        ret = obj.parse_media_line(word_list, dict(), dict())
        assert(ret['media'] == 'Unknown')
        assert(ret['media_select'] == word_list[1])
        if word_set == 'default':
            assert(ret['media_type'] == word_list[2][1:-1])

# Generated at 2022-06-22 23:38:23.796660
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.get_interfaces() == dict()


# Generated at 2022-06-22 23:38:26.184365
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test object constructor of DarwinNetwork
    """
    test = DarwinNetwork(None)
    assert test is not None


# Generated at 2022-06-22 23:38:27.239495
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector('Darwin')

# Generated at 2022-06-22 23:38:31.095628
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    # Test some definitional aspects
    assert dn.platform == 'Darwin'
    assert dn.media_line_pattern == r'\s*media:\s*(.+)'
    assert dn.ifconfig_path == '/sbin/ifconfig'

# Generated at 2022-06-22 23:38:37.449134
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
            gather_network_resources=dict(default=[], type='list'),
        )
    )
    # Instantiate the DarwinNetworkCollector class with the mocked module
    inst = DarwinNetworkCollector(module=module)

    # Assert if the subclass and platform attributes are correctly set
    assert inst._fact_class == DarwinNetwork
    assert inst._platform == 'Darwin'


# Generated at 2022-06-22 23:38:49.243451
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This will test the DarwinNetwork class by passing it a "fake" set of
    data from ifconfig -a and seeing if it parses it correctly.

    Output from MacOSX Mojave 10.14.3 is used here.
    """

# Generated at 2022-06-22 23:38:59.040431
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize the DarwinNetwork object
    net = DarwinNetwork()

    # Reference dictionary to return
    # NOTE: dictionary values must be in the same order as method parsing
    ref_dict = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'status: inactive'}

    # Ifconfig output is a list of character (strings)
    # NOTE: list values must be in the same order as method parsing
    ifconf_lines = ['media: autoselect', 'status: inactive']

    # Parse line to dictionary
    parsed_dict = net.parse_media_line(ifconf_lines, None, None)

    assert parsed_dict == ref_dict

# Generated at 2022-06-22 23:39:05.559164
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetworkCollector(None, None).collect()
    # Check we are on the Darwin platform
    assert facts['facts']['darwin_version'] == facts['facts']['distribution_version']
    # Make sure DarwinNetwork is the only class in the list of possible classes
    # for this platform
    assert 'DarwinNetwork' == [fact_class.__name__ for fact_class in NetworkCollector._possible_fact_classes if fact_class.platform == 'Darwin'][0]

# Generated at 2022-06-22 23:39:14.846569
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Dictionary returned by method parse_media_line has
    key media with value 'Unknown' and
    key media_select with value <value of words[1]>
    """

# Generated at 2022-06-22 23:39:16.214427
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:39:16.819242
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net = DarwinNetworkCollector()
    assert net

# Generated at 2022-06-22 23:39:21.612677
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test Darwin Network class constructor
    dn = DarwinNetwork()

    # Test the class attributes are correctly initialised
    assert dn.facts == dict()
    assert dn.data == dict()
    assert dn.ifconfig == dict()



# Generated at 2022-06-22 23:39:31.614849
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    NetworkCollector._platform = 'Darwin'
    test_network_inst = DarwinNetwork(None)
    current_if = {'device': 'en0'}
    ips = []
    words = ['media', 'select', '10baseT/UTP', '(none)']
    test_network_inst.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'  # check media
    assert current_if['media_select'] == 'select'  # check media_select
    assert current_if['media_type'] == '10baseT/UTP'  # check media_type
    assert current_if['media_options'] == {}  # check media_options
    current_if = {'device': 'en0'}  # reset current interface

# Generated at 2022-06-22 23:39:35.251681
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == 'Darwin'



# Generated at 2022-06-22 23:39:37.104080
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert isinstance(darwin_network, DarwinNetwork)

# Generated at 2022-06-22 23:39:40.109633
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This function is the unit test for the constructor of the class DarwinNetworkCollector
    """
    # Initialize the object
    obj = DarwinNetworkCollector()
    # The object shall not be empty
    assert obj is not None

# Generated at 2022-06-22 23:39:46.508775
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # This was originally a unit test for the entire class DarwinNetwork,
    # but there are no tests for the class so it was moved here
    # because some version of this was already listed as part of the class.
    #
    # The 'Unknown' test was broken; replaced with a more minimal test.
    # The 'InfiniBand' test had a syntax error that needed fixing.
    # These were discovered by running these tests.
    #
    # I also re-factored to use a dict as a return value,
    # and expected=dict as a parameter,
    # in order to use more standard Python unit test functions
    # and thereby make it possible to look at the diff of a failure.

# Generated at 2022-06-22 23:39:50.797418
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'
    # assert darwin_network.get_options('a') == ['a']
    # assert darwin_network.get_options('b') == ['b']



# Generated at 2022-06-22 23:40:01.294592
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    t = DarwinNetwork()
    # tests on media_line
    current_if = {}
    # media line with media_select and media_type
    t.parse_media_line(['media:', 'autoselect', '(none)'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    # media line with media_select and media_type and media_options
    t.parse_media_line(['media:', 'autoselect', '(none)', '(none)'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type']

# Generated at 2022-06-22 23:40:05.114706
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert 'DarwinNetwRokCollector' in str(DarwinNetworkCollector)
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:40:06.804872
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnet = DarwinNetwork()
    assert dnet.platform == 'Darwin'

# Generated at 2022-06-22 23:40:17.675155
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinnetwork = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = dict()
    ips = dict()
    darwinnetwork.parse_media_line(words, current_if, ips)
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if

    words = ['media:', '<unknown', 'type>']
    darwinnetwork.parse_media_line(words, current_if, ips)
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'Unknown'
    assert 'media_type' in current_if

# Generated at 2022-06-22 23:40:21.519419
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = {}
    network = DarwinNetworkCollector(module=None, facts=facts)
    assert set(network.collect()) == set(['all_ipv4_addresses',
                                          'all_ipv6_addresses',
                                          'network'])

# Generated at 2022-06-22 23:40:25.069355
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Check that DarwinNetworkCollector is properly initialized.
    """
    DarwinNetworkCollector()

if __name__ == '__main__':
    # Unit test for DarwinNetworkCollector class
    module = AnsibleModule(argument_spec=dict())
    test_DarwinNetworkCollector()
    module.exit_json(changed=False)

# Generated at 2022-06-22 23:40:25.596850
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:27.203239
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for constructor of class DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:31.538905
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # class initialization
    darwin_net_collector = DarwinNetworkCollector()
    # check if the class is correctly initialized
    assert darwin_net_collector._fact_class.platform == "Darwin"
    assert darwin_net_collector._platform == "Darwin"

# Generated at 2022-06-22 23:40:32.114645
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:40:35.423664
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert dn._fact_class == DarwinNetwork
    assert dn._platform == 'Darwin'


# Generated at 2022-06-22 23:40:37.073127
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is an integration test that just test the DarwinNetworkCollector
    """
    DarwinNetworkCollector().collect()

# Generated at 2022-06-22 23:40:46.919874
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup
    dn = DarwinNetwork()

    # Test - media line with all values:
    words = ['Media:', 'autoselect', '10baseT/UTP', '(<unknown option>)' ]
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == {'<unknown option>': ''}

    # Test - media line with all values:
    words = ['Media:', 'autoselect', '10baseT/UTP']
    current_if = {}
    ips = {}

# Generated at 2022-06-22 23:40:48.336560
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:40:49.309200
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork(None, None)
    assert network
    assert network.collect()

# Generated at 2022-06-22 23:41:01.075183
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Collect vars to be passed to the object
    current_if = dict()  # type: dict
    ips = dict()  # type: dict

    # Create the object under test
    obj_under_test = DarwinNetwork(None)  # type: DarwinNetwork

    # First test
    words = ['media:', 'autoselect', 'status:', 'active']
    # Run the method under test
    obj_under_test.parse_media_line(words, current_if, ips)
    # assert the outputs
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == 'status: active'

    # Second test
    words = ['media:', 'autoselect', '(none)', 'active']
   

# Generated at 2022-06-22 23:41:03.948904
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    hostname = 'TestHostname'
    cache = dict()
    collect_fn = lambda: dict()
    DarwinNetwork(hostname, cache, collect_fn)

# Generated at 2022-06-22 23:41:16.317203
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:41:16.953893
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:28.342560
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of DarwinNetwork
    darwin_net = DarwinNetwork()
    # call parse_media_line with the set of words to check
    # the correctness of media, media_select and media_options
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    darwin_net.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if
    # call parse_media_line with the set of words to check
    # the correctness of media, media_select, media_type and media_options
    words = ['media:', 'autoselect', '(1000baseT)']

# Generated at 2022-06-22 23:41:30.442311
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'



# Generated at 2022-06-22 23:41:36.827704
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()
    test_if = {'device': 'eth0', 'type': 'Unknown', 'enabled': True, 'layer3': True, 'ipv4': {}}
    test_words = ['media', 'media_select', 'media_type', 'media_options']
    test_object.parse_media_line(test_words, test_if, 'ipv4')
    assert test_words[1] == test_if['media_select']
    assert test_words[2] == test_if['media_type']
    assert test_words[3] == test_if['media_options']

# Generated at 2022-06-22 23:41:40.029966
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == DarwinNetwork.platform

# Generated at 2022-06-22 23:41:49.947698
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Define words and current_if
    words = ['media:', '<unknown', 'type>']

# Generated at 2022-06-22 23:41:52.047600
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert isinstance(instance, DarwinNetworkCollector)


# Generated at 2022-06-22 23:41:52.611265
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:42:01.470528
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.device == 'en0'
    assert dn.platform == 'Darwin'
    assert dn.mask_length == 0
    assert dn.media == 'Unknown'
    assert dn.media_type == 'unknown type'
    assert not dn.media_select
    assert not dn.media_options
    assert dn.flags == 'unknown flag'
    assert dn.operstate == 'unknown operstate'
    assert dn.inet == '127.0.0.1'
    assert dn.inet6 == '::1'


# Generated at 2022-06-22 23:42:03.795923
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dar = DarwinNetwork({})
    assert dar._platform == 'Darwin'
    assert dar.platform == 'Darwin'


# Generated at 2022-06-22 23:42:07.847620
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _obj = DarwinNetworkCollector('Darwin')
    assert _obj.platform == 'Darwin'
    assert _obj._fact_class == DarwinNetwork
    assert _obj._platform == 'Darwin'


# Generated at 2022-06-22 23:42:12.572692
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn._platform == 'Darwin'
    assert dn._fact_class == DarwinNetwork
    assert dn.platform == 'Darwin'
    assert dn.fact_class == DarwinNetwork
    assert dn.parse_media_line


# Generated at 2022-06-22 23:42:15.985043
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.default_interface_name == 'bridge0'
    assert darwin_network_collector.platform == 'Darwin'
    assert darwin_network_collector.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:42:18.559774
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector(None, None, None)
    assert network.platform == 'Darwin'

# Generated at 2022-06-22 23:42:28.886437
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}

    # Test with the word media_select only
    words = ['bge0:', 'DFT', ' ', ' ', ' ', ' ']
    media_type = network.parse_media_line(words, current_if, {})
    assert current_if['media_select'] == words[1]
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # Test with the word media_select and media_type
    words = ['bge0:', 'manual', '<full-duplex>', ' ', ' ', ' ']
    media_type = network.parse_media_line(words, current_if, {})
    assert current_if['media_select'] == words[1]

# Generated at 2022-06-22 23:42:31.566295
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    collector = DarwinNetwork()
    assert collector._platform == 'Darwin'

# Generated at 2022-06-22 23:42:37.904584
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print("Testing constructor of class DarwinNetwork")
    darwin_network_test = DarwinNetwork()
    assert hasattr(darwin_network_test, 'get_interfaces')
    assert hasattr(darwin_network_test, 'parse_interfaces')
    assert hasattr(darwin_network_test, '_parse_all_interfaces')
    assert hasattr(darwin_network_test, 'parse_interface')
    assert hasattr(darwin_network_test, 'parse_duplex')
    assert hasattr(darwin_network_test, 'parse_media_line')


# Generated at 2022-06-22 23:42:49.739775
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    macDarwinNet = DarwinNetworkCollector()

    assert(macDarwinNet.platform == 'Darwin')
    macDarwinNet = macDarwinNet.get_network_facts()

    # Check the interfaces list
    assert(type(macDarwinNet['interfaces']) is list)
    assert(macDarwinNet['interfaces'])

    # Check the all_ipv4_addresses
    assert(type(macDarwinNet['all_ipv4_addresses']) is list)
    assert(macDarwinNet['all_ipv4_addresses'])

    # Check the mac address for first interface
    assert(type(macDarwinNet['default_ipv4']['macaddress']) is str)
    assert(macDarwinNet['default_ipv4']['macaddress'])

    # Check

# Generated at 2022-06-22 23:43:00.983511
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'active': True, 'device': 'bridge0', 'description': '', 'enabled': True}
    test_words = ['media:', '<unknown', 'type>', '(autoselect)']
    test_words2 = ['media:', 'Autoselect', '(100baseTX)']
    test_ips = None
    dnet = DarwinNetwork(None, None)
    dnet.parse_media_line(test_words, test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == '(autoselect)'

# Generated at 2022-06-22 23:43:03.564502
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # initialize DarwinNetwork()
    network = DarwinNetwork()
    # check if DarwinNetwork is an instance of class DarwinNetwork
    assert isinstance(network, DarwinNetwork)


# Generated at 2022-06-22 23:43:08.089863
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '10baseT/UTP', 'media_options': 'half-duplex'}
    test_line = "media: autoselect <10baseT/UTP half-duplex>"
    test_words = test_line.split()
    DarwinNetwork().parse_media_line(test_words, test_if, None)
    assert test_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '10baseT/UTP', 'media_options': 'half-duplex'}
    test_words = ["media:", "up", "<unknown", "type>"]

# Generated at 2022-06-22 23:43:09.059433
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:43:09.626058
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:43:16.616619
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'media_select', 'media_type', 'media_options']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, {})
    assert words[1] == 'media_select'
    assert words[2] == 'media_type'
    assert words[3] == 'media_options'
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    assert current_if['media_options'] == 'media_options'


# Generated at 2022-06-22 23:43:17.365935
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:43:29.700826
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instances of required classes/functions
    iface = DarwinNetwork()

    # Test with a normal ethernet line
    words = ['media:', 'autoselect', '(1000baseT)']
    current_if = {}
    ips = {}
    iface.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == '()'

    # Test with a wireless interface
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}

# Generated at 2022-06-22 23:43:35.302089
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {}
    line = ['media:', 'Ethernet', 'auto', '(100baseTX)']
    DarwinNetwork.parse_media_line(interface, line)
    assert interface == {'media': 'Unknown', 'media_select': 'Ethernet', 'media_type': 'auto', 'media_options': ['100baseTX']}



# Generated at 2022-06-22 23:43:42.137829
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    current_if = {'name': 'en0'}
    ips = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:43:53.065981
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'name': 'lo0'}

    # media line with media_select, media_type and media_options
    DarwinNetwork._parse_media_line(['media:', 'autoselect', '(none)'], current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == []

    # media line with media_select and media_type
    DarwinNetwork._parse_media_line(['media:', 'autoselect', '(none)'], current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == []

    # media line

# Generated at 2022-06-22 23:43:53.927669
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork

# Generated at 2022-06-22 23:43:54.446582
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:57.942685
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dar_n = DarwinNetworkCollector()
    assert dar_n._fact_class is DarwinNetwork
    assert dar_n._platform is 'Darwin'



# Generated at 2022-06-22 23:43:59.714929
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    ob = DarwinNetworkCollector()
    assert ob._fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:44:03.905517
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.parse_media_line(['media:', 'status', 'unknown', 'link', 'configured'], "eth0", [])
    assert module.parse_media_line(['media:', '802.11', 'Unknown', 'link', 'configured', 'foo', 'bar'], "eth0", [])

# Generated at 2022-06-22 23:44:13.471611
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    # Test case 1
    current_if = {}
    ips = {}
    words = ['media:','autoselect','status:','active','inactive','','','','','','','','','','','','','','','','','','','','','']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if
    # Test case 2
    current_if = {}
    ips = {}

# Generated at 2022-06-22 23:44:18.530768
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for constructor of class DarwinNetworkCollector"""
    fact_class = DarwinNetwork
    platform = 'Darwin'
    obj = DarwinNetworkCollector(fact_class, platform)
    assert obj.fact_class is fact_class
    assert obj.platform is platform
    assert obj.collect() is not None

# Generated at 2022-06-22 23:44:23.531758
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network.facts['all_ipv4_addresses'] == ['192.168.1.2']
    assert network.facts['all_ipv6_addresses'] == ['fe80::d7ff:501:c6d6:d8c%en0']

# Generated at 2022-06-22 23:44:28.255789
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is the test for the class constructor DarwinNetworkCollector.
    It checks if the right platform and fact class are used.
    """
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:44:38.609464
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
        Unit test for method parse_media_line of class DarwinNetwork
    '''
    data = [
        {
            'test_input': ['media:','autoselect','<unknown','type>'],
            'test_output': {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}
        },
        {
            'test_input': ['media:','autoselect','10baseT/UTP'],
            'test_output': {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '10baseT/UTP'}
        }
    ]
    test_object = DarwinNetwork({})
    for test in data:
        test_input = test['test_input']

# Generated at 2022-06-22 23:44:45.613080
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '<unknown type>']
    current_if = dict()
    ips = dict()
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert not 'media_options' in current_if

# Generated at 2022-06-22 23:44:50.184004
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    obj = DarwinNetwork()
    assert isinstance(obj, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:44:52.523627
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, NetworkCollector)


# Generated at 2022-06-22 23:44:56.349828
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'
    assert network.media_regex == ('^(\d+):(\S+):(<[^>]+>)?(<[^>]+>)?')



# Generated at 2022-06-22 23:45:05.255848
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:45:16.847862
# Unit test for constructor of class DarwinNetwork