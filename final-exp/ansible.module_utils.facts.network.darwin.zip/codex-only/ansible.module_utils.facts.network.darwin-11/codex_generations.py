

# Generated at 2022-06-22 23:35:30.781782
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = generic_ansible_module()
    networkCollector = DarwinNetworkCollector(module=module)
    networkCollector.populate()
    facts = networkCollector.get_facts()
    facts_platform = facts['ansible_facts']['ansible_network_resources']['platform']
    assert facts_platform == 'Darwin'
    facts_interfaces = facts['ansible_facts']['ansible_network_resources']['interfaces']
    facts_interfaces_lo0 = facts_interfaces['lo0']
    assert len(facts_interfaces) == len(interfaces_expected()) + 1
    assert facts_interfaces_lo0['ipv4']['address'] == 'fe80::1'

# Generated at 2022-06-22 23:35:31.220370
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:35:33.284115
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test class DarwinNetworkCollector"""
    net_collector = DarwinNetworkCollector()

# Generated at 2022-06-22 23:35:35.880458
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class.platform == 'Darwin'
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:35:38.051082
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_facts = DarwinNetwork()

    assert network_facts.platform == 'Darwin'

# Generated at 2022-06-22 23:35:42.065112
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork('eth1', True)
    assert dn
    assert dn.name == 'eth1'
    assert dn.ignore

if __name__ == "__main__":
    dn = DarwinNetwork('eth1', True)
    print(dn)

# Generated at 2022-06-22 23:35:52.950981
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = None

    # --- test case 1: media line with all three values defined ---
    words = 'media: autoselect (100baseTX >full-duplex,flow-control,txpause,rxpause)'.split(' ')
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'  # this parameter is not given on macOS
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == 'full-duplex,flow-control,txpause,rxpause'

    # --- test case 2: media line with only two values defined ---
    words = 'media: autoselect (100baseTX)'.split

# Generated at 2022-06-22 23:36:00.003227
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # list of values for words for testing
    words_list = [
        # normal case
        ['media:', 'autoselect', '(none)', '(none)'],
        # Bridge case
        ['media:', '<unknown', 'type>', '(none)'],
        ]

    # list of expected values of current_if['media_type'] for each
    # member of words_list for testing
    media_type_list = [
        'none',
        'unknown type',
        ]

    # list of expected values of current_if['media_select'] for each
    # member of words_list for testing
    media_select_list = [
        'autoselect',
        'Unknown',
        ]

    # test DarwinNetwork.parse_media_line()
    current_if = {}
    ips = []
    dar

# Generated at 2022-06-22 23:36:02.456894
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert isinstance(darwin_network, DarwinNetwork)


# Generated at 2022-06-22 23:36:09.665498
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test DarwinNetwork constructor
    """
    bufferd = ["media: autoselect (1000baseT <full-duplex>) status: active\n"]
    darwin_network = DarwinNetwork(bufferd)

    assert darwin_network.media_select == "autoselect"
    assert darwin_network.media == "Unknown"
    assert darwin_network.media_type == "1000baseT"
    assert darwin_network.media_options == "full-duplex"



# Generated at 2022-06-22 23:36:11.296906
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'


# Generated at 2022-06-22 23:36:23.096064
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a mock interface with some data
    iface = dict(
        name='bridge1',
    )
    # call method to test
    DarwinNetwork.parse_media_line(None, [u'UP', u'<unknown', u'type>'], iface, None)
    # check results
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'

    # create a mock interface with some data
    iface = dict(
        name='bridge1',
    )
    # call method to test
    DarwinNetwork.parse_media_line(None, [u'UP', u'full-duplex', u'10baseT/UTP', u'flow-control'], iface, None)
    # check results

# Generated at 2022-06-22 23:36:34.003419
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import Darwin

    d = Darwin()
    current_if = {}

    words = ['media:', 'autoselect', '(1000baseT)']
    d.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] is None

    current_if = {}
    words = ['media:', '<unknown', 'type>']
    d.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-22 23:36:42.126728
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test constructor of DarwinNetwork
    facts = DarwinNetwork()
    assert facts.platform == 'Darwin'
    assert facts.ifconfig_path == '/sbin/ifconfig'

    # Test constructor of DarwinNetwork with the right platform
    facts = DarwinNetwork('Darwin')
    assert facts.platform == 'Darwin'
    assert facts.ifconfig_path == '/sbin/ifconfig'

    # Test constructor of DarwinNetwork with a wrong platform
    facts = DarwinNetwork('AIX')
    assert facts.platform == 'AIX'
    assert facts.ifconfig_path == 'ifconfig'



# Generated at 2022-06-22 23:36:53.874662
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

    words = ['foo', '1', '100Base-TX']
    current_if = {}
    d.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1'
    assert current_if['media_type'] == '100Base-TX'
    assert 'media_options' not in current_if

    words = ['foo', '<unknown', 'type>']
    current_if = {}
    d.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-22 23:36:59.167220
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    media_line = ['media:', 'autoselect', '100baseTX', '(100baseTX)']
    current_if = dict()
    ips = dict()
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if["media_select"] == "autoselect"
    assert current_if["media_type"] == "100baseTX"

# Unit tests for class DarwinNetworkCollector

# Generated at 2022-06-22 23:37:00.982532
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Unit test for DarwinNetworkCollector
    """
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class is DarwinNetwork
    assert dnc._platform is 'Darwin'


# Generated at 2022-06-22 23:37:06.621005
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = dict()
    ips = dict()
    DarwinNetwork.parse_media_line(words,current_if,ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'


# Generated at 2022-06-22 23:37:09.268135
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert(dn.platform == 'Darwin')
    assert(dn.fact_class.platform == 'Darwin')

# Generated at 2022-06-22 23:37:20.815887
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}

    words = ['media:', 'IEEE', '802.11', '(autoselect)']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'IEEE'
    assert current_if['media_type'] == '802.11'
    assert current_if['media_options'] == {'autoselect': None}

    words = ['media:', 'IEEE', '802.11', '(autoselect)', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:37:24.195740
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    assert isinstance(DarwinNetworkCollector()._fact_class(),GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:37:28.326896
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    fact = DarwinNetwork()
    assert fact.platform == 'Darwin'
    # assert fact.interfaces == ['lo0', 'gif0', 'stf0', 'en0', 'en1',
                                 # 'fw0', 'vmnet1', 'vmnet8']

# Generated at 2022-06-22 23:37:32.787780
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-22 23:37:36.796195
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net = DarwinNetworkCollector()
    assert net.get_facts().__name__ == 'DarwinNetwork'

# Generated at 2022-06-22 23:37:38.766709
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'

# Generated at 2022-06-22 23:37:39.930728
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None, None, "virtual interface") == None


# Generated at 2022-06-22 23:37:41.652142
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj,NetworkCollector) == True

# Generated at 2022-06-22 23:37:53.552086
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:38:04.531941
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork({})
    media = {}
    words = ['media:', 'autoselect', '<unknown type>', 'none']
    d.parse_media_line(words, media, [])
    assert media['media'] == 'Unknown'
    assert media['media_select'] == 'autoselect'
    assert media['media_type'] == 'unknown type'
    assert media['media_options'] == {}

    words = ['media:', 'autoselect', '<unknown type>', 'mediaopt', 'mediaopt2']
    d.parse_media_line(words, media, [])
    assert media['media_options'] == {'mediaopt': None, 'mediaopt2': None}

    words = ['media:', 'autoselect', '(none)', 'full-duplex']
    d.parse_media

# Generated at 2022-06-22 23:38:16.235281
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}

    words = ['media:', 'undefined', 'status:', 'inactive']
    expected_result = {'media': 'Unknown', 'media_select': 'undefined', 'media_options': ''};
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if == expected_result

    words = ['media', '10baseT/UTP', 'status:', 'active']
    expected_result = {'media': 'Unknown', 'media_select': '10baseT/UTP', 'media_type': 'UTP', 'media_options': ''}
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if == expected_result


# Generated at 2022-06-22 23:38:20.902612
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._fact_class.platform == 'Darwin'
    assert network_collector.platform == 'Darwin'
    assert network_collector._fact_class.media_regexp is not None


# Generated at 2022-06-22 23:38:26.185189
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = mock.MagicMock()

    darwinNetwork_module = DarwinNetworkCollector(module)
    assert darwinNetwork_module._platform == 'Darwin'
    assert darwinNetwork_module._fact_class == DarwinNetwork
    assert darwinNetwork_module.interfaces == []

# Generated at 2022-06-22 23:38:26.831451
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:29.592079
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create a DarwinNetwork instance
    dn = DarwinNetwork()

    # Check the network_facts, of DarwinNetwork is empty
    assert dict() == dn.get_facts()

# Generated at 2022-06-22 23:38:35.495682
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = dict()
    collector = DarwinNetworkCollector()
    assert collector.__dict__['_fact_class'] == DarwinNetwork
    expected = dict()
    expected['default_interface'] = 'en0'
    expected['interfaces'] = dict()
    expected['all_ipv4_addresses'] = list()
    expected['all_ipv6_addresses'] = list()
    expected['neighbors'] = dict()
    assert facts == expected

# Generated at 2022-06-22 23:38:36.456012
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == "Darwin"


# Generated at 2022-06-22 23:38:40.876981
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test initialize of DarwinNetwork
    fixture_network = DarwinNetwork()
    # Test parse_media_line
    test_words = ['<unknown', 'type>']
    test_current_if = {}
    test_ips = {}
    fixture_network.parse_media_line(test_words, test_current_if, test_ips)
    assert test_current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-22 23:38:41.847013
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__module__ == 'ansible.module_utils.facts.network.darwin'
    assert DarwinNetworkCollector.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-22 23:38:44.256233
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_test = DarwinNetwork()
    assert darwin_network_test.platform == 'Darwin'

# Generated at 2022-06-22 23:38:45.627933
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d is not None


# Generated at 2022-06-22 23:38:49.374667
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'
    assert obj.fact_class.__class__.__name__ == 'DarwinNetwork'
    assert obj.fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:38:50.675788
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork._platform == 'Darwin'


# Generated at 2022-06-22 23:39:00.268799
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    if_dict = {}
    if_dict['media'] = 'Unknown'  # Mac does not give us this
    if_dict['media_select'] = 'autoselect'
    test_net = DarwinNetwork()
    test_net.parse_media_line(['media:', 'autoselect', 'invalid', 'mediaopt'], if_dict, {})
    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == 'autoselect'
    assert 'invalid' == if_dict['media_type']
    assert 'mediaopt' == if_dict['media_options']


# Generated at 2022-06-22 23:39:09.986716
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    example_lines = {
        'media: <unknown type>': {
          'current_if': {
            'media_select': 'Unknown',
            'media_options': None,
            'media': 'Unknown'
          }
        },
        'media: autoselect 10baseT/UTP <link>': {
          'current_if': {
            'media_select': 'autoselect',
            'media_options': 'link',
            'media_type': '10baseT/UTP',
            'media': 'Unknown'
          }
        }
    }

    for line, result in example_lines.items():
        words = line.split()
        current_if = result['current_if']
        ifconfig = DarwinNetwork(platform='Darwin')

# Generated at 2022-06-22 23:39:16.686813
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test constructor fill in defaults
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'
    assert obj.cache_expiration == 0
    assert obj.default_ipv4_address_field == 'address'
    assert obj.default_ipv6_address_field == 'address'
    assert obj.default_ipv6_scope_field == 'scope'
    assert obj.default_interface_name_format == 'long'
    assert obj.default_interface_name_mangle == 'no'
    assert obj.default_ipv4_address_display_format == 'none'
    assert obj.default_ipv6_address_display_format == 'none'

# Generated at 2022-06-22 23:39:18.745262
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-22 23:39:29.878069
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # generate fake interface name
    ifname = 'lo123'

    # generate fake media line
    line_1 = 'media: autoselect (1000baseT <full-duplex,flow-control>) status: active'
    line_2 = 'media: autoselect <unknown type> status: active'

    media = DarwinNetwork({})
    ifc = {}
    media.parse_media_line(line_1.split(), ifc, {})
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'autoselect'
    assert ifc['media_type'] == '1000baseT'
    assert ifc['media_options'] == 'full-duplex,flow-control'
    ifc = {}
    media.parse_media_line(line_2.split(), ifc, {})

# Generated at 2022-06-22 23:39:41.047445
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:39:52.581809
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}

    # Test media line with media select and media type
    words = ['media:', '<unknown type>', '1000baseT', '<full-duplex>']
    dn.parse_media_line(words, current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert 'media_type' not in current_if

    # Test media line with media select, media type and media options
    words = ['media:', '<unknown type>', '1000baseT', '<full-duplex,autoselect>']
    dn.parse_media_line(words, current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert 'media_type' not in current_if
    assert current_if

# Generated at 2022-06-22 23:39:53.790111
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:39:56.096506
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collectorname = "DarwinNetwork"
    DarwinNetworkCollector(collectorname)
    assert collectorname == 'DarwinNetwork'

# Generated at 2022-06-22 23:39:59.306858
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # call with a fake inet4 line
    d = DarwinNetwork('\tinet 192.168.1.1 netmask 0xffffff00 broadcast 192.168.1.255')
    assert d.is_valid

# Generated at 2022-06-22 23:40:00.869710
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test for DarwinNetwork constructor
    """
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:40:03.837458
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    c = DarwinNetworkCollector()
    assert(c.platform == 'Darwin')
    assert(c.fact_class == DarwinNetwork)

# Generated at 2022-06-22 23:40:04.481620
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:08.348594
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ test_DarwinNetwork: tests constructor of class DarwinNetwork """
    # For darwin we will just run the normal generic bsd one
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:40:18.945750
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    _if = {'name': 'mock_if'}

    _obj = DarwinNetwork(None)

    _obj.parse_media_line(['media', 'autoselect', '(none)'], _if, None)
    assert _if['media'] == 'Unknown'
    assert _if['media_select'] == 'autoselect'
    assert _if['media_type'] == '(none)'

    _if = {'name': 'mock_if'}

    _obj.parse_media_line(['media', '<unknown', 'type>'], _if, None)
    assert _if['media'] == 'Unknown'
    assert _if['media_select'] == 'Unknown'
    assert _if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:40:20.333799
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'



# Generated at 2022-06-22 23:40:21.108986
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    a = DarwinNetwork()



# Generated at 2022-06-22 23:40:27.831625
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork=DarwinNetwork()

    # test media line parsing for 'media' key
    media_line_test_zero = 'media: autoselect (100baseTX <full-duplex>)'
    media_line_test_one = 'media: autoselect <full-duplex>'
    #test media: <unknown type> with line breaking
    media_line_test_two = 'media: autoselect <unknown'
    media_line_test_three = 'type>'
    #test media: <unknown type> without line breaking
    media_line_test_four = 'media: autoselect <unknown type>'

    media_line_output_zero = "Unknown"
    media_line_output_one = "Unknown"
    media_line_output_two = "Unknown"

# Generated at 2022-06-22 23:40:29.912966
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_collector = DarwinNetwork()
    # Check if the OS is as expected
    assert test_collector.platform == "Darwin"

# Generated at 2022-06-22 23:40:31.585709
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().get_facts()

# Generated at 2022-06-22 23:40:35.244671
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = DarwinNetworkCollector(module=module)
    if (collector.platform == 'Darwin'):
        assert True
    else:
        assert False


# Generated at 2022-06-22 23:40:37.251310
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.fact_module == "ansible.module_utils.facts.network.darwin"

# Generated at 2022-06-22 23:40:39.629139
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # just testing the constructor to make sure the class get's instantiated
    collector = DarwinNetworkCollector()
    assert collector is not None

# Generated at 2022-06-22 23:40:40.778763
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network is not None

# Generated at 2022-06-22 23:40:43.643388
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fact_class=DarwinNetworkCollector()
    assert fact_class.platform == 'Darwin'
    assert fact_class._fact_class == DarwinNetwork
    assert fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:40:50.653496
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    x = DarwinNetwork()
    assert(x.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>'})
    assert(x.parse_media_line(['media:', '<unknown', 'type>', 'autoselect'], {}, {}) == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>', 'media_options': 'autoselect'})
    assert(x.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)'})

# Generated at 2022-06-22 23:40:52.986393
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert facts._fact_class is DarwinNetwork
    assert facts._platform is DarwinNetwork.platform

# Generated at 2022-06-22 23:40:55.201844
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test the constructor of the DarwinNetworkCollector class
    :return:
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:01.540351
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    instances = DarwinNetwork()
    assert instances._facts == {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
        'default_ipv4': {},
        'default_ipv6': {},
        'device_links': {},
        'device_interfaces': {},
        'interfaces': {},
        'network_lo': {},
    }

# Generated at 2022-06-22 23:41:03.673928
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # init class with no args
    audio = DarwinNetworkCollector()
    assert audio.platform == 'Darwin'

# Generated at 2022-06-22 23:41:04.718366
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:09.368234
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = AnsibleModule(argument_spec={})
    fact_class = DarwinNetwork(module=module)
    fact_class.get_facts()
    assert(fact_class.facts['default_ipv4']['address'] == '192.168.1.100')

# Generated at 2022-06-22 23:41:19.770517
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test to check __init__ and setup method of class DarwinNetworkCollector
    """
    darwin_collector = DarwinNetworkCollector()
    assert darwin_collector._platform == 'Darwin'
    darwin_collector.setup()
    darwin_collector.collect()
    assert darwin_collector.facts['default_ipv4']['address'] == '10.243.2.49'
    assert darwin_collector.facts['default_ipv4']['broadcast'] == '10.243.2.255'
    assert darwin_collector.facts['default_ipv4']['mask'] == '255.255.255.0'

# Generated at 2022-06-22 23:41:21.115079
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:41:24.285402
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # check if new instance of DarwinNetwork was created
    darwin_net = DarwinNetwork()
    assert darwin_net.__class__.__name__ == "DarwinNetwork"

# Generated at 2022-06-22 23:41:34.512645
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    config1 = ['autoselect', 'active']
    config2 = ['none']
    config3 = ['autoselect', '<unknown type>']
    config4 = ['<unknown type>']
    config5 = ['10baseT', '/', 'half']
    config6 = ['10baseT', '/', 'full', 'mediaopt', 'half-duplex']
    # test config1
    new_config1 = DarwinNetwork.parse_media_line(config1, "", "")
    assert new_config1 == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'active'}
    # test config2
    new_config2 = DarwinNetwork.parse_media_line(config2, "", "")

# Generated at 2022-06-22 23:41:46.900589
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
        }
    )

# Generated at 2022-06-22 23:41:48.572512
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork()
    assert result._fact_class == DarwinNetwork
    assert result._platform == 'Darwin'

# Generated at 2022-06-22 23:41:50.370345
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    try:
        DarwinNetwork()
    except Exception:
        raise AssertionError("Instantiation of DarwinNetwork class failed")

# Generated at 2022-06-22 23:41:58.871097
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': 'Unknown', 'media_select': 'none', 'media_type': 'none', 'media_options': 'none' }
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    result = DarwinNetwork._parse_media_line(words, current_if, None)
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'Unknown'
    assert result['media_type'] == 'unknown type'
    assert result['media_options'] == 'none'

# Generated at 2022-06-22 23:42:00.607360
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinnet = DarwinNetwork()
    assert darwinnet.platform == "Darwin"

# Generated at 2022-06-22 23:42:12.438671
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()

    # line 'media: <unknown type>'
    words = ["media:", '<unknown', 'type>']
    current_if = {}
    current_if = ifc.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

    # line 'media: autoselect (100baseTX <full-duplex>)'
    words = ["media:", "autoselect", "(100baseTX", "<full-duplex>"]
    current_if = {}
    current_if = ifc.parse_media_line(words, current_if, [])

# Generated at 2022-06-22 23:42:24.737529
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    words = ['media:', '<unknown type>', '(autoselect)']
    current_if = {}
    ips = None
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown type>'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None

    words = ['media:', '<unknown type>', 'none', '(autoselect)']
    current_if = {}
    ips = None
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown type>'

# Generated at 2022-06-22 23:42:32.045064
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media_options': None, 'media_select': None, 'media': None, 'media_type': None}
    words = ['media:', 'autoselect', '(none)', 'status:', 'active']
    DarwinNetwork.parse_media_line(current_if, words)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert not current_if['media_options']

    current_if = {'media_options': None, 'media_select': None, 'media': None, 'media_type': None}
    words = ['media:', '<unknown', 'type>', 'autoselect', '(none)', 'status:', 'active']
    DarwinNetwork

# Generated at 2022-06-22 23:42:33.598506
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Create an instance of DarwinNetworkCollector
    """
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)

# Generated at 2022-06-22 23:42:35.161164
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    myfact = DarwinNetworkCollector()
    assert myfact._platform == 'Darwin'

# Generated at 2022-06-22 23:42:41.705997
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    current_if = {}

    # media_select/media_type
    dwn.parse_media_line(['media:', 'none', '(none)'], current_if, [])
    assert current_if['media_select'] == 'none'
    assert current_if['media_type'] == 'none'

    # media
    dwn.parse_media_line(['media:', 'autoselect', '(none)'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

    # media_options
    dwn.parse_media_line(['media:', 'autoselect', '(none)', 'opts:none'], current_if, [])

# Generated at 2022-06-22 23:42:44.106653
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'



# Generated at 2022-06-22 23:42:45.400730
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_class = DarwinNetwork()
    assert test_class.platform == 'Darwin'

# Generated at 2022-06-22 23:42:46.331625
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-22 23:42:48.450243
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert isinstance(obj, GenericBsdIfconfigNetwork)
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:42:49.957083
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:51.794692
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform=='Darwin'
    assert DarwinNetworkCollector._fact_class==DarwinNetwork

# Generated at 2022-06-22 23:42:52.930169
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # create a class object of DarwinNetwork
    fact = DarwinNetwork ()
    # check whether the class defined by us is generated
    assert fact.__class__.__name__ == "DarwinNetwork"

# Generated at 2022-06-22 23:43:03.014017
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    t = DarwinNetwork()

    assert t.platform == 'Darwin'

# Generated at 2022-06-22 23:43:06.909419
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:43:16.346109
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert dn.command == 'ifconfig'
    assert dn.ifconfig_path == '/sbin/ifconfig'
    assert dn.parse_flags == 'klmn'
    assert dn.used_default_flag == ''
    assert dn.iface_line_regex == '^(\S+?)(?:(?:\s+\S+)|$)'
    assert dn.mac_regex == '(?:ether|lladdr)\s+((?:[0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2})'
    assert dn.ipv4_regex == 'inet\s+(\S+)'
    assert dn.ipv6_re

# Generated at 2022-06-22 23:43:22.051599
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    bsd_network_instance = DarwinNetwork([], [], [])
    assert bsd_network_instance.platform == 'Darwin'

    bsd_network_instance = DarwinNetwork(None, None, None)
    assert bsd_network_instance.platform == 'Darwin'


# Generated at 2022-06-22 23:43:22.830236
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:34.204030
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    method = DarwinNetwork() # create instance
    current_if = {
        'media': None,
        'media_select': None,
        'media_type': None,
        'media_options': None,
    }
    # test for bridge interface
    words = ['media:', '<unknown', 'type>', 'None']
    method.parse_media_line(words, current_if, None)
    # assert results
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None
    # reset current_if

# Generated at 2022-06-22 23:43:36.545850
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test the constructor of the DarwinNetwork class
    """
    DarwinNetwork()



# Generated at 2022-06-22 23:43:37.483290
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net is not None

# Generated at 2022-06-22 23:43:48.689730
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    sample_words = ['media:', '<unknown', 'type>', 'status:']
    test_current_if = {'name': 'test'}
    test_ips = {}
    expected_test_current_if = {'name': 'test',
                                'media': 'Unknown',
                                'media_select': 'Unknown',
                                'media_type': 'unknown type',
                                'media_options': {}}
    expected_test_ips = {}
    dn = DarwinNetwork()
    dn.parse_media_line(sample_words, test_current_if, test_ips)
    assert (expected_test_current_if == test_current_if)
    assert (expected_test_ips == test_ips)

# Generated at 2022-06-22 23:43:49.320164
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:50.943540
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj
    assert isinstance(obj, DarwinNetwork)


# Generated at 2022-06-22 23:43:52.339122
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork()
    assert n.platform == 'Darwin'

# Generated at 2022-06-22 23:43:54.006693
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork()
    assert n.platform == 'Darwin'

# Generated at 2022-06-22 23:44:01.214287
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork({})
    current_if = {}
    ips = []
    # testing with bridge interface
    darwin_network.parse_media_line(['media:', '<unknown', 'type>', 'status:'],
                                    current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'


# Generated at 2022-06-22 23:44:06.236741
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    macos_ifdata = {'media': 'Unknown', 'media_type': '<unknown type>', 'media_select': '<unknown type>', 'media_options': None}
    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    ips = dict()

    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == macos_ifdata

# Generated at 2022-06-22 23:44:12.073680
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'
    assert module.get_options(['media:', 'autoselect']) == {}
    assert module.get_options(['media:', '10baseT/UTP', '<full-duplex>']) == {}
    assert module.get_options(['media:', '10baseT/UTP', '<full-duplex>', '(100baseTX <full-duplex>)']) == {
        'full-duplex': 'on', 'speed': '100baseTX'}
    assert 'media_' not in module.parse_media_line(['media:', 'autoselect'], {}, {}) == {}

# Generated at 2022-06-22 23:44:13.478133
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'

# Generated at 2022-06-22 23:44:16.500860
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    coll = DarwinNetworkCollector(None, 'Darwin')
    assert coll._platform == 'Darwin'
    assert coll._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:44:19.449849
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class == DarwinNetwork
    assert collector._platform == 'Darwin'


# Generated at 2022-06-22 23:44:21.680526
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().__class__.__name__ == 'DarwinNetworkCollector'


# Generated at 2022-06-22 23:44:24.045411
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    q = DarwinNetwork()
    qq = DarwinNetwork()
    assert (q is qq)
    assert (q.__dict__ == qq.__dict__)

# Generated at 2022-06-22 23:44:29.272592
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Ensuring the DarwinNetwork class constructor, returns a object with
    the correct type
    """
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)


# Generated at 2022-06-22 23:44:39.070396
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'none', '(none)', '']
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'none'}
    words = ['media:', '<unknown', 'type>', '(none)', '']
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    words = ['media:', 'autoselect', '(none)', '(none)', '']
    DarwinNetwork().parse_media_line(words, current_if, None)

# Generated at 2022-06-22 23:44:41.084345
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj,DarwinNetworkCollector)


# Generated at 2022-06-22 23:44:43.607868
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork



# Generated at 2022-06-22 23:44:44.951473
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector != None

# Generated at 2022-06-22 23:44:54.222610
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test constructor of class DarwinNetwork
    network = DarwinNetwork()
    assert network.platform == DarwinNetwork.platform
    assert network.ethtool_path == DarwinNetwork.ethtool_path
    assert network.ethtool_bin == DarwinNetwork.ethtool_bin
    assert network.route_path == DarwinNetwork.route_path
    assert network.route_bin == DarwinNetwork.route_bin
    assert network.nstat_path == DarwinNetwork.nstat_path
    assert network.nstat_bin == DarwinNetwork.nstat_bin
    assert network.ifconfig_path == DarwinNetwork.ifconfig_path
    assert network.ifconfig_bin == DarwinNetwork.ifconfig_bin

# Generated at 2022-06-22 23:45:04.285351
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:45:06.957301
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()._fact_class is DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'


# Generated at 2022-06-22 23:45:08.395818
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:45:20.660431
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    d.parse_media_line(['media:', '<unknown', 'type>'], {}, '')
    assert d._interfaces['eth0']['media_select'] == 'Unknown'
    assert d._interfaces['eth0']['media_type'] == 'unknown type'
    d.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], {}, '')
    assert d._interfaces['eth0']['media_select'] == 'autoselect'
    assert d._interfaces['eth0']['media_type'] == '10baseT/UTP'
    d.parse_media_line(['media:', 'autoselect', '10baseT/UTP', '(none)'], {}, '')
    assert d._interfaces