

# Generated at 2022-06-22 23:35:25.833971
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test data
    words_one = ['<unknown', 'type>']
    words_two = ['status:', 'active', '(connected)']
    current_if = {}
    # test line 1
    DarwinNetwork.parse_media_line(None, words_one, current_if, None)
    assert current_if['media_type'] == 'unknown type'

    # test line 2
    DarwinNetwork.parse_media_line(None, words_two, current_if, None)
    assert current_if['media_select'] == 'active'

# Generated at 2022-06-22 23:35:29.077448
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:35:30.793286
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_value = DarwinNetwork({'memory_capable': True, 'enabled': True})
    assert test_value.platform == 'Darwin'

# Generated at 2022-06-22 23:35:31.676179
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == 'Darwin'

# Generated at 2022-06-22 23:35:33.338874
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:35:35.111616
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:35:37.177521
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Create an object of the DarwinNetwork Class
    """
    DarwinNetwork()

# Generated at 2022-06-22 23:35:38.230133
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:35:49.022507
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'interfaces': {}}
    test_if = {'if': 'lo0', 'addresses': {}, 'flags': []}
    test_words = ['media:', 'autoselect']
    test_ip = '0.0.0.0'
    dn = DarwinNetwork(test_dict)
    dn.parse_media_line(test_words, test_if, test_ip)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'

    test_words_2 = ['media:', 'autoselect', '<unknown', 'type>']
    dn.parse_media_line(test_words_2, test_if, test_ip)
    assert test_if['media_select'] == 'Unknown'
   

# Generated at 2022-06-22 23:35:50.513293
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None, None, None)
    assert obj

# Generated at 2022-06-22 23:35:53.445082
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork({})
    assert d.platform == 'Darwin'
    assert d.ipv4_interfaces() == []
    assert d.ipv6_interfaces() == []

# Generated at 2022-06-22 23:35:58.378983
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX <full-duplex>'



# Generated at 2022-06-22 23:35:59.168056
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn is not None


# Generated at 2022-06-22 23:36:10.860995
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test generic_bsd_ifconfig fact with macOS 10.12.16
    """
    darwin = DarwinNetwork()
    # Create the facts for facts/network/generic_bsd_ifconfig using macOS ifconfig output
    #

# Generated at 2022-06-22 23:36:22.600101
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_ips = {}
    # test case for media line with different words
    jy_net = DarwinNetwork()
    test_words=['media:','autoselect','status:','active','supported','capability','none']
    jy_net.parse_media_line(test_words,test_if,test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == 'status'
    assert test_if['media_options'] == {'active': '', 'supported': '', 'capability': 'none'}
    # test case for media line with 3 words
    jy_net = DarwinNetwork()
    test_words=['media:','autoselect','status']


# Generated at 2022-06-22 23:36:30.640738
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_DarwinNetworkCollector = DarwinNetworkCollector()
    my_DarwinNetwork = my_DarwinNetworkCollector._fact_class()
    test_if = dict()
    test_ips = list()
    test_words = ['status:', 'active' , 'media:', '<unknown', 'type>', 'supported']
    my_DarwinNetwork.parse_media_line(test_words, test_if, test_ips)
    assert test_if == dict({'media': 'Unknown', 'media_type': 'unknown type', 'media_select': 'active', 'media_options': set(['supported'])})

# Generated at 2022-06-22 23:36:42.360485
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    network = collector.facts
    assert network["eth0"]["media"] == "Unknown"
    assert network["eth0"]["media_options"] == "-full"
    assert network["eth0"]["media_select"] == "autoselect"
    assert network["eth0"]["media_type"] == "10baseT/UTP"
    assert network["eth0"]["interface"] == "en0"
    assert network["eth0"]["mtu"] == "1500"
    assert network["eth0"]["type"] == "Ethernet"
    assert network["eth0"]["type_description"] == "en0"
    assert network["eth0"]["macaddress"] == "00:26:ab:03:74:44"

# Generated at 2022-06-22 23:36:43.571539
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector is not None


# Generated at 2022-06-22 23:36:48.905536
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create a DarwinNetwork object
    dn = DarwinNetwork([])

    #Check the data type
    assert type(dn) == DarwinNetwork
    assert type(dn.facts) == dict
    assert type(dn.get_option_list) == instancemethod

# Generated at 2022-06-22 23:36:58.397199
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_ip = []
    dn = DarwinNetwork()

    # With media_select and media_type
    test_words_1 = ['media:', 'autoselect', '(none)']
    dn.parse_media_line(test_words_1, test_if, test_ip)
    assert test_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)'}

    # With media_select, media_type and media_options
    test_words_2 = ['media:', 'autoselect', '(1000baseT', 'full-duplex)']
    test_if = {}
    dn.parse_media_line(test_words_2, test_if, test_ip)

# Generated at 2022-06-22 23:37:06.783508
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = {}

    # This is a line from ifconfig -a media output with unknown media
    dn.parse_media_line(['media:', '<unknown type>', 'status:', 'inactive'], current_if, ips)
    assert current_if['media'] == 'Unknown', 'Did not set media to Unknown'
    assert current_if['media_type'] == 'unknown type', 'Did not set media_type to unknown type'
    assert current_if['media_options'] == {}, 'Did not set media_options to empty dict'



# Generated at 2022-06-22 23:37:08.600884
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector()


# Generated at 2022-06-22 23:37:10.389320
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj

# Generated at 2022-06-22 23:37:11.124303
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector

# Generated at 2022-06-22 23:37:12.893735
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:37:14.808810
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'

# Generated at 2022-06-22 23:37:15.411676
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:17.530065
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    # Create an instance of DarwinNetwork class
    mac_network = DarwinNetwork()

    assert mac_network._platform == 'Darwin'

# Generated at 2022-06-22 23:37:19.107874
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)

# Generated at 2022-06-22 23:37:20.725314
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:37:22.237340
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({})
    assert dn is not None

# Generated at 2022-06-22 23:37:23.904222
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:37:25.583544
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == "Darwin"

# Generated at 2022-06-22 23:37:31.135520
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    parsed_media_line = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '<unknown type>',
        'media_options': []
    }
    darwin_network = DarwinNetwork()
    assert  parsed_media_line == darwin_network.parse_media_line(
        ['media:', 'autoselect', '<unknown', 'type>'], {}, {})

# Generated at 2022-06-22 23:37:41.210052
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    iface = DarwinNetwork()
    iface.parse_media_line('media: autoselect (100baseTX <full-duplex>) status: active', current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX <full-duplex>'

    current_if = dict()
    ips = dict()
    iface = DarwinNetwork()
    iface.parse_media_line('media: autoselect status: active', current_if, ips)
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

# Generated at 2022-06-22 23:37:53.057098
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork()
    # input = 'media: autoselect (autoselect)'
    input = 'media: autoselect', '(autoselect)'
    current_if = {'macaddress': '00:00:00:00:00:00', 'interface': 'eth0'}
    darwin.parse_media_line(input, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'autoselect'
    assert current_if['media'] == 'Unknown'
    assert 'media_options' not in current_if
    # input = 'media: <unknown type> (none)'
    input = 'media: <unknown', 'type>', '(none)'

# Generated at 2022-06-22 23:37:53.820421
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-22 23:37:55.699542
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-22 23:37:57.577264
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Create DarwinNetworkCollector object.
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:04.162462
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'name': 'en0', 'device': 'en0', 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX', 'media_options': 'none'}
    words = ['media:', 'autoselect', '(100baseTX)', 'status:', 'inactive']
    DarwinNetwork().parse_media_line(words, current_if, 'ips')
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:38:06.288306
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:38:09.146505
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'
    assert hasattr(dnc, '_fact_class')
    assert hasattr(dnc, '_platform')

# Generated at 2022-06-22 23:38:10.144324
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:11.056229
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:11.918057
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:21.026334
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup
    class DarwinNetwork:
        def __init__(self):
            self.facts = dict()
            self.facts['interfaces'] = dict()
            self.facts['all_ipv4_addresses'] = dict()
            self.facts['all_ipv6_addresses'] = dict()
            self.current_if = ['not_set', 'not_set']

    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    darwin_network.current_if = 'en0'

    # Exercise
    darwin_network.parse_media_line(words, darwin_network.current_if, darwin_network.facts)

    # Verify

# Generated at 2022-06-22 23:38:26.728893
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {}
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)']
    DarwinNetwork().parse_media_line(words, interface, None)
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] == '100baseTX <full-duplex>'

# Generated at 2022-06-22 23:38:27.343599
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:28.330034
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert(DarwinNetwork)

# Generated at 2022-06-22 23:38:30.214820
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:38:32.957707
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # create a darwin network object
    darwin_network = DarwinNetwork()
    assert darwin_network


# Generated at 2022-06-22 23:38:40.847863
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create instance of class DarwinNetwork
    darwin_network = DarwinNetwork()
    # the media_line we want to parse
    media_line = 'media: <unknown type>'
    # we want to parse the line into a dict
    current_if = {}
    # as the media_line does not contain IP information we don't need the ips array for parsing
    ips = []
    # split the media_line into words
    words = media_line.split()
    # call the parse_media_line method
    darwin_network.parse_media_line(words, current_if, ips)
    # set expectes result from media_line
    expected_media = 'Unknown'
    expected_media_select = 'Unknown'
    expected_media_options = {}
    # assert media, media select and media options of the

# Generated at 2022-06-22 23:38:41.315038
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()


# Generated at 2022-06-22 23:38:45.300150
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ test creation of DarwinNetworkCollector class
    """
    darwin_network_fact_class = DarwinNetworkCollector()
    assert darwin_network_fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:38:46.234418
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector(None)


# Generated at 2022-06-22 23:38:48.612632
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:53.673618
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    # DarwinNetworkCollector should set _fact_class to the name of the class
    # that inherits from _GenericBsdIfconfigNetwork
    assert dnc._fact_class == DarwinNetwork
    # DarwinNetworkCollector should set _platform to 'Darwin'
    assert dnc._platform == 'Darwin'

# Generated at 2022-06-22 23:38:57.020372
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Creates an instance of DarwinNetwork
    """
    result = DarwinNetwork()
    assert isinstance(result, DarwinNetwork)

# Generated at 2022-06-22 23:39:02.919539
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = dict()
    ips = dict()
    x = DarwinNetwork()
    x.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': dict()}

# Generated at 2022-06-22 23:39:04.535359
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()

    assert darwinNetwork.ifconfig_path == '/sbin/ifconfig'

# Generated at 2022-06-22 23:39:11.857474
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = {
        'interface': 'fake0',
        'options': {},
        'addresses': {},
        'type': 'Unknown',
        'media': 'Unknown',
        'media_select': 'none',
        'media_type': 'none',
        'media_status': 'none',
        'media_duplex': 'full',
        'media_options': 'none'
    }

    test_data = ['media:', 'none']
    DarwinNetwork().parse_media_line(test_data, data, None)
    assert data['media_select'] == 'none' and data['media_type'] == 'none'
    assert data['media_status'] == 'none' and data['media_duplex'] == 'full'

    test_data = ['media:', 'none', '(autoselect)']


# Generated at 2022-06-22 23:39:12.654607
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork()


# Generated at 2022-06-22 23:39:17.662788
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # given
    dn = DarwinNetwork(None)
    words = ['media:', '<unknown type>']
    current_if = dict()
    ips = None

    # when
    dn.parse_media_line(words, current_if, ips)

    # then
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:39:19.503704
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:39:22.028447
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # instantiate DarwinNetworkCollector
    darwinCollector = DarwinNetworkCollector()
    assert isinstance(darwinCollector, DarwinNetworkCollector)

# Generated at 2022-06-22 23:39:28.062867
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    f = DarwinNetworkCollector()
    assert isinstance(f, NetworkCollector)
    assert f._platform == 'Darwin'
    assert f._fact_class == DarwinNetwork
    assert isinstance(f._fact_class, type)
    assert issubclass(f._fact_class, GenericBsdIfconfigNetwork)


# unit test for the class DarwinNetwork

# Generated at 2022-06-22 23:39:40.026037
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # input parameters
    data = {
        'words': ['media:', '<unknown', 'type>'],
        'current_if': {'name': 'bridge0', 'ipv4': [], 'ipv6': [], 'type': 'bridge'},
        'ips': [],
    }
    # expected output
    exp = {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type',
        'media_options': None,
    }
    # instantiate DarwinNetwork class
    darwin = DarwinNetwork()
    # set the desired attribute
    darwin.parse_media_line(**data)
    # compare expected and actual result
    assert exp == darwin.interfaces['bridge0'].copy()

# Generated at 2022-06-22 23:39:41.481066
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert (obj.platform == 'Darwin')

# Generated at 2022-06-22 23:39:42.478677
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn


# Generated at 2022-06-22 23:39:43.341764
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:55.023100
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # check media_type option
    line = "  media: autoselect (1000baseT <full-duplex>)"
    words = line.split()
    dn.check_values({})
    dn.parse_media_line(words, dn.current_if, dn.interfaces)
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == "autoselect"
    assert dn.current_if['media_type'] == "1000baseT"
    assert dn.current_if['media_options'] == "<full-duplex>"

    # check media_select option
    line = "  media: autoselect"
    words = line.split()
    dn.check_values({})
    d

# Generated at 2022-06-22 23:39:56.308062
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj1 = DarwinNetworkCollector(None, None, None)
    assert obj1

# Generated at 2022-06-22 23:39:58.610702
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create a DarwinNetwork object
    bsdn = DarwinNetwork()
    assert bsdn
    assert bsdn._platform == 'Darwin'

# Generated at 2022-06-22 23:39:59.718889
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:00.276552
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-22 23:40:12.528943
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # make a DarwinNetwork object with the parse_media_line method to call
    dn = DarwinNetwork(None)
    # set up a dummy interface to get results into
    current_if = {}
    # create a dummy list of words to pass to the method
    words = []
    # call the method and check the results
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, ips=None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    words = ['media:', 'autoselect', '(none)']

# Generated at 2022-06-22 23:40:13.561189
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'

# Generated at 2022-06-22 23:40:19.403821
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnw = DarwinNetwork({}, {}, {})
    assert dnw.platform == 'Darwin'
    assert dnw.facts['default_ipv4']['address'] == '10.4.4.4'
    assert dnw.facts['default_ipv4']['network'] == '10.4.4.4'
    assert dnw.facts['default_ipv4']['netmask'] == '255.255.255.255'
    assert dnw.facts['default_ipv4']['gateway'] == '10.4.4.4'

# Generated at 2022-06-22 23:40:21.072055
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_class = DarwinNetwork()
    assert network_class.platform == 'Darwin', "Platform should be Darwin"


# Generated at 2022-06-22 23:40:22.167528
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network._platform == 'Darwin'


# Generated at 2022-06-22 23:40:23.647571
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for constructor of class DarwinNetwork"""
    module = DarwinNetwork()
    assert module != None

# Generated at 2022-06-22 23:40:26.864245
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector.platform == 'Darwin'
    assert network_collector.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:40:37.630473
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # testing method parse_media_line of class DarwinNetwork
    # simple case
    current_if = {'name': 'lo0'}
    darwinn = DarwinNetwork()
    darwinn.parse_media_line(['media:', 'autoselect', '<unknown type>'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    # complex case
    current_if = {'name': 'lo0'}
    darwinn.parse_media_line(['media:', '100baseTX', '<full-duplex>'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_

# Generated at 2022-06-22 23:40:47.257866
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    This method tests the parse_media_line method of class DarwinNetwork
    """
    current_if = {}
    # Test 1: test normal media line
    words = ['media:', '1000baseT', '(<unknown type>)', 'status:', 'active']
    DarwinNetwork.parse_media_line(None, words, current_if, None)
    assert current_if == {'media': 'Unknown',
                          'media_select': '1000baseT',
                          'media_type': 'unknown type',
                          'media_options': {}}

    # Test 2: test bridge media line
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(None, words, current_if, None)

# Generated at 2022-06-22 23:40:51.247778
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = {}
    DarwinNetworkCollector(facts, None).collect()

    assert 'interface_ip' in facts
    assert 'all_ipv4_addresses' in facts['interface_ip']
    assert 'all_ipv6_addresses' in facts['interface_ip']

# Generated at 2022-06-22 23:40:52.174008
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:53.974443
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class is not None
    assert obj._platform is not None

# Generated at 2022-06-22 23:40:56.066305
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork('foo')
    assert dn.which_ifconfig() == '/sbin/ifconfig'

# Generated at 2022-06-22 23:41:05.112063
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # set up test variables
    dn = DarwinNetwork()
    current_if = {}
    # Perform test and check for error
    dn.parse_media_line(['media:','100baseTX','<full-duplex>','mediaopt','autoselect','status:','active'],
                        current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '100baseTX'
    assert current_if['media_type'] == 'full-duplex'
    assert current_if['media_options'] == 'mediaopt,autoselect'

# Generated at 2022-06-22 23:41:07.705446
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_facts = DarwinNetworkCollector()
    assert net_facts._fact_class == DarwinNetwork
    assert net_facts._platform == 'Darwin'

# Generated at 2022-06-22 23:41:18.252722
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Call the parse_media_line method of class DarwinNetwork and make sure the
    # right values are assigned to media_select, media_type, and media_options
    result = DarwinNetwork().parse_media_line(['media:', '<unknown type>'], {}, {})
    assert result['media_select'] == 'Unknown'
    assert result['media_type'] == 'Unknown'

    result = DarwinNetwork().parse_media_line(['media:', 'autoselect', '10baseT', 'full-duplex'], {}, {})
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == '10baseT'
    assert result['media_options'] == ['full-duplex']

# Generated at 2022-06-22 23:41:20.615887
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert facts._fact_class is DarwinNetwork
    assert facts._platform == 'Darwin'

# Generated at 2022-06-22 23:41:31.937171
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Tests the parse_media_line method of the DarwinNetwork class.
    """

    class DummyDarwinNetwork(DarwinNetwork):
        def __init__(self):
            self.cache = {'exists': set(), 'ipv4': {}, 'ipv6': {}}

    dut = DummyDarwinNetwork()

    # Basic check of media line
    interface = {'address': [], 'bond': {}, 'bridge': {}, 'broadcast': []}
    dut.parse_media_line(['media:', 'autoselect', 'nonegotiate', 'status:', 'active'], interface, [])
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] == 'nonegotiate'

# Generated at 2022-06-22 23:41:33.799075
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert dn._platform == "Darwin"
    assert dn._fact_class == DarwinNetwork
    assert dn._config_file == '/sbin/ifconfig'

# Generated at 2022-06-22 23:41:34.399386
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:46.739349
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mn = DarwinNetwork()
    mn.current_if = {}
    mn.ips = {}
    mn.parse_media_line(['media:', 'autoselect', '(none)', '(none)'], mn.current_if, mn.ips)
    assert mn.current_if['media'] == 'Unknown'
    assert mn.current_if['media_select'] == 'autoselect'
    assert mn.current_if['media_type'] == '(none)'
    assert mn.current_if['media_options'] == '(none)'

    mn.current_if = {}
    mn.ips = {}
    mn.parse_media_line(['media:', '1000baseT', '(none)', 'full-duplex'], mn.current_if, mn.ips)


# Generated at 2022-06-22 23:41:50.861737
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    darwin_net.parse_media_line(['media:', '<unknown', 'type>'], dict(), dict())
    assert darwin_net._current_if['media_select'] == 'Unknown'
    assert darwin_net._current_if['media_type'] == 'unknown type'
    assert 'media_options' not in darwin_net._current_if

# Generated at 2022-06-22 23:42:02.738085
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown type>', 'status:', 'inactive', 'nwid', '0.16', 'rx', 'antenna', '-1', 'tx', 'antenna', '-1', 'ecollision', '0', 'ixtx', '0', 'ixrx', '0', 'i2tx', '0', 'i2rx', '0', 'autortry', '0', 'half-duplex', '0', 'ttl', '0', 'nt', '0', 'nc', '0']
    current_if = {'if_description': 'appletv', 'if_alias': 'appletv', 'if_duplex': 'Unknown', 'if_name': 'en2'}
    ips = ['192.168.0.1']
    dn = DarwinNetwork()

# Generated at 2022-06-22 23:42:13.184838
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    a = DarwinNetwork()
    b = a.parse_media_line(["media:", "auto", "1000baseT(auto)"], {}, [])
    assert b['media'] == 'Unknown'
    assert b['media_select'] == 'auto'
    assert b['media_type'] == '1000baseT'
    assert b['media_options'] == {'media': 'auto'}
    c = a.parse_media_line(["media:", "<unknown", "type>"], {}, [])
    assert c['media'] == 'Unknown'
    assert c['media_select'] == 'Unknown'
    assert c['media_type'] == 'unknown type'
    assert c['media_options'] == {}

# Generated at 2022-06-22 23:42:25.265383
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Media line is parsed as follows:
    media: Supported, Supported
    media: autoselect <unknown type>
    media: autoselect 10baseT/UTP <full-duplex>
    media: none
    media: autoselect <full-duplex>
    media: 1000baseT <full-duplex>
    """
    iface = dict()

    # Test 1 - Media is 'Supported'
    darwin = DarwinNetwork()
    media_line = "media: Supported, Supported"
    iface = darwin.parse_media_line(media_line.split(), iface, dict())
    assert (iface['media'] == 'Supported')

    # Test 2 - Check media is defaulted to 'Unknown'
    darwin = DarwinNetwork()

# Generated at 2022-06-22 23:42:30.936346
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    testDarwinNetwork = DarwinNetwork()
    testinterface = {}
    testlist = []
    testlist.append("<unknown type>")
    testlist.append("unknown type")
    testlist.append("status: active")
    testlist.append("autoselect")
    testresult = testDarwinNetwork.parse_media_line(testlist, testinterface, "")
    assert testresult['media'] == 'Unknown'
    assert testresult['media_select'] == 'Unknown'
    assert testresult['media_type'] == 'unknown type'
    assert testresult['media_options'] == 'status: active autoselect'

# Generated at 2022-06-22 23:42:32.876431
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = None
    try:
        # create the DarwinNetworkCollector module
        DarwinNetworkCollector(module)
    except Exception:
        raise AssertionError('Cannot create DarwinNetworkCollector')

# Generated at 2022-06-22 23:42:40.348689
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Testing with valid parameters
    test_DarwinNtwk = DarwinNetwork('docker0', 'Link encap:Ethernet  HWaddr 02:42:3e:45:71:e5', [], [], {}, {})
    assert test_DarwinNtwk.name == 'docker0'
    assert test_DarwinNtwk.link_capabilities == 'Link encap:Ethernet  HWaddr 02:42:3e:45:71:e5'
    assert test_DarwinNtwk.addresses == []
    assert test_DarwinNtwk.options == {}
    assert test_DarwinNtwk.ipv4 == {}
    assert test_DarwinNtwk.ipv6 == {}
    assert test_DarwinNtwk.invalid_options == {}

# Generated at 2022-06-22 23:42:51.136108
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']

    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, None)

    assert ('media' in current_if)
    assert ('media_select' in current_if)
    assert ('media_type' in current_if)
    assert ('media_options' in current_if)

    assert (current_if['media'] == 'Unknown')
    assert (current_if['media_select'] == 'Unknown')
    assert (current_if['media_type'] == 'unknown type')
    assert (current_if['media_options'] == {})

# Generated at 2022-06-22 23:42:55.070527
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork()
    assert isinstance(facts,DarwinNetwork)
    assert facts.platform == "Darwin"
    assert facts._fact_class == DarwinNetwork
    assert facts._platform == 'Darwin'

# Generated at 2022-06-22 23:43:03.594890
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Testing DarwinNetwork
    """
    data = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384\n'
    data += '\toptions=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>\n'
    data += '\tinet 127.0.0.1 netmask 0xff000000\n'
    data += '\tinet6 ::1 prefixlen 128\n'
    data += '\tinet6 fe80::1%lo0 prefixlen 64 scopeid 0x1\n'
    data += '\tnd6 options=201<PERFORMNUD,DAD>\n'
    data += 'gif0: flags=8010<POINTOPOINT,MULTICAST> mtu 1280\n'

# Generated at 2022-06-22 23:43:08.124651
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork(None)

    current_if = {'media': 'Ethernet',
                  'media_select': 'autoselect',
                  'media_type': 'none'}
    ips = []
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    network.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Ethernet',
                          'media_select': 'autoselect',
                          'media_type': '(1000baseT)',
                          'media_options': None}

    current_if = {'media': 'Autoselect',
                  'media_select': '10baseT/UTP',
                  'media_type': 'none'}
    ips = []

# Generated at 2022-06-22 23:43:09.475335
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:11.269381
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:43:15.326638
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_ifconfig_path = '../../ansible/module_utils/facts/network/test_files/darwin_ifconfig'
    dn = DarwinNetwork(darwin_ifconfig_path, None)
    assert dn.get_interfaces() is not None
    assert dn.interfaces is not None
    assert len(dn.interfaces) > 0



# Generated at 2022-06-22 23:43:17.494063
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # print("Test DarwinNetwork")
    t = DarwinNetwork()
    assert t is not None


# Generated at 2022-06-22 23:43:20.066371
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()
    print("done")

# Generated at 2022-06-22 23:43:23.220943
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Check for no parameters returns macOS
    my_darwin = DarwinNetwork()
    assert my_darwin.platform == 'Darwin'
    assert 'wlp2s0' in my_darwin.get_interfaces()

# Generated at 2022-06-22 23:43:28.762473
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork({})
    test_object.fact_subset = {}
    words = ['foo', 'bar', 'baz']
    current_if = {}
    ips = {}
    test_object.parse_media_line(words, current_if, ips)
    assert "foo" == current_if['media']

# Generated at 2022-06-22 23:43:29.743859
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector().collect()

# Generated at 2022-06-22 23:43:31.901079
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    print(network)
    assert network
    assert network.platform == 'Darwin'


# Generated at 2022-06-22 23:43:34.556795
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork({})
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-22 23:43:46.789246
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an empty iface dict to be used
    iface = {}
    # create an empty ip dict to be used
    ips = {}
    # invoke the parse_media_line method of DarwinNetwork
    DarwinNetwork(None).parse_media_line(['media:', 'autoselect'], iface, ips)
    # assert the resulting iface dict
    assert iface == {'media': 'Unknown', 'media_select': 'autoselect'}
    # invoke the parse_media_line method of DarwinNetwork
    DarwinNetwork(None).parse_media_line(['media:', 'autoselect', '(1000baseT)'], iface, ips)
    # assert the resulting iface dict

# Generated at 2022-06-22 23:43:55.609559
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from collections import namedtuple
    from ansible.module_utils.facts import collector

    # Constructor test
    DarwinNetworkCollector()
    # ModuleUtilsNetworkCommon test
    # Assign member variables to the class DarwinNetworkCollector
    DarwinNetworkCollector.platform = 'Darwin'
    DarwinNetworkCollector.DEFAULT_DETAIL_LEVELS = ['min', 'default', 'custom']

    # Default value test
    assert 'Darwin' == DarwinNetworkCollector.platform
    assert ['min', 'default', 'custom'] == DarwinNetworkCollector.DEFAULT_DETAIL_LEVELS

    # Instantiates the class DarwinNetwork with namedtuple defaults
    # instantiate member variable
    DarwinNetworkCollector.fact_class = DarwinNetwork
    # create namedtuple

# Generated at 2022-06-22 23:43:57.599933
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    net.platform = 'Darwin'
    return net

# Generated at 2022-06-22 23:44:02.667566
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork({})
    assert facts.get_file_path() == '/sbin/ifconfig'
    assert facts.get_interfaces() == []
    assert facts.get_interface_details() == {}
    assert facts.get_interfaces_ip() == {}
    assert facts.get_configured_interfaces() == []

# Function to test constructor of class DarwinNetworkCollector

# Generated at 2022-06-22 23:44:05.617129
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Very simple test, as all the heavy lifting is done by GenericBsdIfconfigNetwork.
    darwin_network = DarwinNetwork('command_getter', 'config_getter')
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-22 23:44:13.843436
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:44:22.113542
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_network = DarwinNetwork()
    words = ['media:', 'auto', '10baseT']
    current_if = {}
    ips = {}
    mac_network.parse_media_line(words,current_if,ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '10baseT'
    assert len(current_if['media_options']) == 0

# Generated at 2022-06-22 23:44:26.991683
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Constructor of class DarwinNetwork
    dwn = DarwinNetwork()
    
    # Unit test for constructor of class DarwinNetwork
    assert dwn.name_to_number['lo0'] == '1'
    assert dwn.name_to_number['en0'] == '2'
    assert dwn.name_to_number['bridge0'] == '3'


# Generated at 2022-06-22 23:44:30.067052
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    # At present, this only tests the class was initialised.
    # TODO: add tests for iflist, etc.

# Generated at 2022-06-22 23:44:30.688369
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:33.729263
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector(None)
    assert dnc.platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:44:39.612643
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_device_words = "media: <unknown type> status: inactive"
    test_current_if = dict()
    test_current_ip = dict()
    test_network = DarwinNetwork()
    test_media_line = test_network.parse_media_line(test_device_words.split(),
                                                    test_current_if,
                                                    test_current_ip)
    assert test_media_line['media_select'] == 'Unknown'
    assert test_media_line['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:41.326750
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    dn


# Generated at 2022-06-22 23:44:44.667354
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    res = DarwinNetwork({'module': object()})
    assert res.platform == 'Darwin'
    assert isinstance(res.module, object)


# Generated at 2022-06-22 23:44:56.402895
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:45:01.839983
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Write unit test for class DarwinNetwork
    """
    module = 'test_module'
    task = 'test_task'

    # Test DarwinNetwork __init__
    network = DarwinNetwork(module, task)
    assert network.module == module
    assert network.task == task
    assert network.facts == {}
    assert network.interfaces == []
    assert network.excludes == []

# Generated at 2022-06-22 23:45:13.681014
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Testcase 1: not sure if this case is useful for us - we also drop information
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)']
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX <full-duplex>'
    assert 'media_options' not in current_if

    # Testcase 2: not sure if this case is useful for us - we also drop information
    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = []
   

# Generated at 2022-06-22 23:45:24.621727
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}
    result = network.parse_media_line(['media:', 'autoselect', 'RJ45'], current_if, '192.168.1.5')
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'RJ45'
    assert result == '192.168.1.5'
    current_if = {}
    result = network.parse_media_line([], current_if, '192.168.1.5')
    assert current_if['media'] == 'Unknown'
    assert result == '192.168.1.5'
    current_if = {}