

# Generated at 2022-06-22 23:35:30.153621
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    iface = dict()
    dn.parse_media_line(words=['media:', 'P2P', 'autoselect', 'status:', 'associated'], current_if=iface, ips=[])
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'P2P'
    assert iface['media_type'] == 'autoselect'
    assert iface['media_options'] == dict()  # not used on Mac
    # Test this special case
    dn.parse_media_line(words=['media:', '<unknown', 'type>', 'status:', 'associated'], current_if=iface, ips=[])
    assert iface['media'] == 'Unknown'

# Generated at 2022-06-22 23:35:41.931330
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup
    network = DarwinNetwork()

# Generated at 2022-06-22 23:35:43.194604
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:35:54.266184
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # verify media_select and media_type are set correctly for media line
    # with 1, 2 and 4 words
    assert dn.parse_media_line(['foo', 'select', 'type'], {}, {}) == {
        'media': 'Unknown',
        'media_select': 'select',
        'media_type': 'type'
    }
    assert dn.parse_media_line(['foo', 'select'], {}, {}) == {
        'media': 'Unknown',
        'media_select': 'select',
        'media_type': '<unknown type>'
    }

# Generated at 2022-06-22 23:36:06.675794
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork(None)
    current_if = {'device': 'en2', 'ipv4': [], 'ipv6': [], 'media': '', 'media_select': '', 'media_type': '',
                  'media_options': ''}
    # test case 1 - media_line = 'media auto (1000baseT)'
    dn.parse_media_line(['media', 'auto', '(1000baseT)'], current_if, [])
    assert current_if == {'device': 'en2', 'ipv4': [], 'ipv6': [], 'media': 'Unknown', 'media_select': 'auto',
                         'media_type': '1000baseT', 'media_options': {}}
    # test case 2 - media = 'media <unknown type>'
    dn.parse_media

# Generated at 2022-06-22 23:36:15.333688
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig_data = {
        'en4': [
            'en4: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500\n',
            '\tether d4:9a:20:ff:81:2c\n',
            '\tmedia: autoselect <unknown type>\n',
            '\tstatus: inactive\n',
            '\tcaps: ethernet\n',
            '\tbwf_key: 8:d:a1:c3:b3\n'
        ]
    }
    network_object = DarwinNetwork()
    network_object.all_interfaces = ifconfig_data

# Generated at 2022-06-22 23:36:15.908438
# Unit test for constructor of class DarwinNetworkCollector

# Generated at 2022-06-22 23:36:22.686097
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test for method parse_media_line of class DarwinNetwork
    In the default configuration it should drop the media line
    """
    dnw = DarwinNetwork()
    dnw.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert 'media' not in dnw.facts
    assert 'media_select' not in dnw.facts
    assert 'media_type' not in dnw.facts
    assert 'media_options' not in dnw.facts

# Generated at 2022-06-22 23:36:25.187414
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = {}
    expected = 'DarwinNetwork'
    actual = DarwinNetworkCollector(facts, None).get_network_collector()
    assert actual == expected

# Generated at 2022-06-22 23:36:25.747496
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork({})

# Generated at 2022-06-22 23:36:27.861875
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This creates an instance of the DarwinNetworkCollector class and returns
    it as an object.
    """
    return DarwinNetworkCollector('Darwin', 'DarwinNetwork')

# Generated at 2022-06-22 23:36:34.316654
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test the parse_media_line method of class DarwinNetwork
    """

    # create an instance of the class
    DarwinNet = DarwinNetwork()

    # set the current_if dictionary
    current_if = {}

    words = 'link/ether 00:1c:42:00:00:08 ssid dave-2GHz channel 11 (2462 MHz 11a) bssid'
    ips = None
    DarwinNet.parse_media_line(words.split(" "), current_if, ips)

    # Media data should be set
    print(current_if)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'ssid'
    assert 'media_type' in current

# Generated at 2022-06-22 23:36:36.177002
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-22 23:36:38.791285
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructor of DarwinNetworkCollector can be called.
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:41.227886
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_mac_darwin_network = DarwinNetwork()
    assert my_mac_darwin_network.platform == "Darwin"

# Generated at 2022-06-22 23:36:42.927034
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructs class DarwinNetwork
    """
    net = DarwinNetwork()
    assert net.platform == "Darwin"

# Generated at 2022-06-22 23:36:44.744984
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    my_collector = DarwinNetworkCollector()
    assert my_collector is not None

# Generated at 2022-06-22 23:36:55.872314
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    temp = DarwinNetwork({'name': 'test'})
    # test media line with media type
    result = {}
    temp.parse_media_line(['<link>', 'none', '10Gbase-T', 'full-duplex,1000baseT,flow-control'], result, None)
    assert result['media_select'] == 'none', \
           'test case 1.1: %s != none' % result['media_select']
    assert result['media_type'] == '10Gbase-T', \
           'test case 1.2: %s != 10Gbase-T' % result['media_type']
    assert result['media_options'] == 'full-duplex,1000baseT,flow-control', \
           'test case 1.3: %s != full-duplex,1000baseT,flow-control'

# Generated at 2022-06-22 23:37:06.663085
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """test the logic of parse_media_line method of class DarwinNetwork"""
    test_if = {'macaddress': None, 'ipv4': [], 'state': None, 'speed': None,
               'mtu': None, 'ipv6': [], 'device': 'wifi0', 'media_select': None,
               'media_options': None, 'media_type': None, 'mediachange': None,
               'media': None, 'description': None}

# Generated at 2022-06-22 23:37:09.755014
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

if __name__ == '__main__':
    # Unit test for constructor of class DarwinNetworkCollector
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:12.442350
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    h = DarwinNetwork()
    assert h.platform == 'Darwin'


if __name__ == "__main__":
    test_DarwinNetwork()

# Generated at 2022-06-22 23:37:15.210390
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    NetworkCollector.collector['Darwin'] = DarwinNetworkCollector()
    assert NetworkCollector.collector['Darwin'] != None

# Generated at 2022-06-22 23:37:15.763803
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:26.906197
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create a test class for data that would be on a real system
    class IfconfigDarwinMock:
        # First Interface from 'ifconfig' command
        # Not sure if this is useful - we also drop information
        if1_output = """
en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
	ether 60:33:4b:14:68:8e
	inet6 fe80::6233:4bff:fe14:688e%en0 prefixlen 64 secured scopeid 0x6
	inet 192.168.1.2 netmask 0xffffff00 broadcast 192.168.1.255
	nd6 options=201<PERFORMNUD,DAD>
	media: autoselect
	status: active
"""
        # Second Interface

# Generated at 2022-06-22 23:37:38.235964
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    expected_if_dict = {
        'address': '172.16.87.1',
        'broadcast': '172.16.87.255',
        'netmask': '255.255.255.0',
        'network': '172.16.87.0',
        'type': 'ether',
    }
    expected_if_map = {
        'en0': expected_if_dict,
        'en1': expected_if_dict,
        'fw0': expected_if_dict,
        'bridge0': expected_if_dict,
    }
    platform_truth = [
        'Darwin',
        'macOS',
    ]
    expected_result = {
        'interfaces': expected_if_map,
        'ipv4': {},
        'ipv6': {},
    }

# Generated at 2022-06-22 23:37:39.779159
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This function is testing the constructor of class DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:41.337529
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_facts = DarwinNetworkCollector()
    assert isinstance(darwin_facts, DarwinNetworkCollector)


# Generated at 2022-06-22 23:37:43.308051
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_nw = DarwinNetwork()


# Generated at 2022-06-22 23:37:45.221010
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert isinstance(d, DarwinNetwork)

# Generated at 2022-06-22 23:37:51.337537
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert not current_if.has_key('media')

# Generated at 2022-06-22 23:37:51.883691
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork()

# Generated at 2022-06-22 23:37:52.447698
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:54.192121
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface={}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(interface, words)
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:37:56.990559
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:37:57.578205
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:59.177794
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:38:01.982475
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Test instance of DarwinNetworkCollector
    DarwinNetworkCollector_instance = DarwinNetworkCollector()
    assert isinstance(DarwinNetworkCollector_instance, NetworkCollector)


# Generated at 2022-06-22 23:38:08.077180
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': {}, 'media_type': 'none'}
    words = ['media:', 'autoselect', 'none']  # words split from ifconfig -a
    darwin_if = DarwinNetwork({'ifconfig': [{'iface': 'en0'}]})
    darwin_if.parse_media_line(words, darwin_if.interfaces['en0'], {})
    assert test_dict == darwin_if.interfaces['en0']

# Generated at 2022-06-22 23:38:10.093982
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fc = DarwinNetworkCollector()
    assert fc.platform == 'Darwin'

# Generated at 2022-06-22 23:38:15.468389
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.facts['all_ipv4_addresses'] == []
    assert dnc.facts['all_ipv6_addresses'] == []
    assert dnc.facts['interfaces'] == {}
    assert dnc.facts['default_ipv4'] == {}



# Generated at 2022-06-22 23:38:18.389734
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    test_DarwinNetworkCollector: test instantiation of class DarwinNetworkCollector
    """
    c = DarwinNetworkCollector()
    assert c is not None

if __name__ == '__main__':
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:21.223443
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    # use __name__ here is because class name is 'NetworkCollector'
    assert DarwinNetworkCollector.__module__ == __name__

# Generated at 2022-06-22 23:38:21.905741
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:24.506483
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mod = DarwinNetwork()
    assert mod.platform == "Darwin"
    assert mod.use_ipv6 is False

# Generated at 2022-06-22 23:38:28.143986
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector.fact_class == DarwinNetwork
    assert isinstance(network_collector.fact_class(), DarwinNetwork)
    assert network_collector.platform == 'Darwin'

# Generated at 2022-06-22 23:38:38.047597
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork('', '')
    fake_if = {'name': 'ens160', 'type': 'ethernet'}
    fake_ips = []

    # Success
    fake_words = ['media:', 'autoselect', '10baseT/UTP', '(<unknown connector>)', '<full-duplex>']
    assert dn.parse_media_line(fake_words, fake_if, fake_ips) == {'media': 'Unknown',
                                                                  'media_select': 'autoselect',
                                                                  'media_type': '10baseT/UTP',
                                                                  'media_options': 'full-duplex'}

    fake_if = {'name': 'ens160', 'type': 'ethernet'}
    fake_ips = []

# Generated at 2022-06-22 23:38:38.529222
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:40.787244
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork({})
    assert net.get_file_path() == '/sbin/ifconfig'

# Generated at 2022-06-22 23:38:42.878878
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork()
    assert result

# Generated at 2022-06-22 23:38:45.489011
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    '''
    Run the constructor of DarwinNetworkCollector
    '''
    darwinnetwork = DarwinNetworkCollector()
    return darwinnetwork

# Generated at 2022-06-22 23:38:46.780184
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    n = DarwinNetworkCollector(None, None, None)



# Generated at 2022-06-22 23:38:47.349192
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:58.820029
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # init instance for testing
    dn = DarwinNetwork()
    # init test data
    # media line / media select / media type / media options / result
    test_data = (
        ('media: autoselect (1000baseT <full-duplex>)',
         'autoselect', '1000baseT', 'full-duplex',
         {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '1000baseT', 'media_options': 'full-duplex'}),
        ('media: <unknown type> (none)',
         '<unknown', 'type>', 'none',
         {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': 'none'})
    )
    # set test data

# Generated at 2022-06-22 23:39:01.648360
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class is not DarwinNetworkCollector
    assert isinstance(dnc._fact_class, type)

# Generated at 2022-06-22 23:39:03.016825
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:39:05.727689
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Unit test for constructor of class DarwinNetworkCollector
    """
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:39:14.993099
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_device_name = 'test_device'
    test_media_select = 'test_media_select'
    test_media_type = 'test_media_type'

    test_in_line = test_media_select + ' ' + test_media_type
    test_out_line = ['', test_media_select, '[' + test_media_type + ']']

    network = DarwinNetwork()
    network.interface = test_device_name
    network.interfaces[test_device_name] = {}
    network.parse_media_line(test_out_line, network.interfaces[test_device_name], {})

    assert network.interfaces[test_device_name]['media'] == 'Unknown'
    assert network.interfaces[test_device_name]['media_select'] == test_media_

# Generated at 2022-06-22 23:39:20.856902
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test for media line
    media_line = 'media: <unknown type> <unknown subtype>'
    test_if = {'device': 'lo0', 'type': 'loopback', 'inet': [], 'inet6': [], 'flags': []}
    test_if_expected = {'device': 'lo0', 'type': 'loopback', 'inet': [], 'inet6': [], 'flags': [], 'media_select': 'Unknown', 'media_type': 'unknown type'}
    test_ips = ['127.0.0.1']
    test_DarwinNetwork = DarwinNetwork()
    test_DarwinNetwork.parse_media_line(media_line.split()[1:], test_if, test_ips)
    assert test_if == test_if_expected

# Generated at 2022-06-22 23:39:22.356501
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net = DarwinNetworkCollector()
    assert net.platform == 'Darwin'

# Generated at 2022-06-22 23:39:24.972511
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:39:26.532175
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-22 23:39:29.328293
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'
    assert module.media_types == ['media', 'media_select', 'media_type', 'media_options']

# Generated at 2022-06-22 23:39:36.597370
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    # create darwin network object
    darwin_net = DarwinNetwork()

    # check the platform attribute of the object
    assert darwin_net.platform == 'Darwin'
    # check the fact class attribute of the object
    assert darwin_net.fact_class == DarwinNetwork
    # check the platform attribute of the object
    assert darwin_net.platform == 'Darwin'



# Generated at 2022-06-22 23:39:39.771380
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.__class__.__name__ == 'DarwinNetworkCollector'
    assert collector.platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:39:50.252294
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>)']
    current_if = dict()
    ips = dict()
    dwn.parse_media_line(words, current_if, ips)
    # Check media values for parsed words
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown' # Mac does not give us this
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' in current_if
    assert current_if['media_type'] == '1000baseT <full-duplex>'
    assert 'media_options' not in current_if
    # Test with more than 3 words, words[3] should contain options

# Generated at 2022-06-22 23:39:52.991300
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a basic unit test of the constructor
    """
    dnc = DarwinNetworkCollector()
    assert (dnc.platform == 'Darwin')

# Generated at 2022-06-22 23:39:55.553113
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:39:56.833469
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:39:59.337396
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork('/sbin/ifconfig')
    assert isinstance(dn,GenericBsdIfconfigNetwork)


# Generated at 2022-06-22 23:40:01.253040
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin = DarwinNetworkCollector()
    assert darwin._fact_class == DarwinNetwork
    assert darwin._platform == 'Darwin'

# Generated at 2022-06-22 23:40:07.597053
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # instantiates the class with argument data
    dn = DarwinNetwork(None)
    assert dn is not None
    assert dn.platform == 'Darwin'
    assert dn.get_platform is not None
    assert dn.get_interfaces is not None
    assert dn.get_interfaces_ip is not None


# Generated at 2022-06-22 23:40:17.855950
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Construct a fake ifconfig response
    media = [
        ['media', 'autoselect', 'media_type', '(none)'],
        ['media', '<unknown', 'type>'],
        ['media', 'autoselect', 'media_type', '(none)', '[none]']
    ]
    # populate the object
    iface = {'address': '', 'netmask': '', 'broadcast': ''}
    for line in media:
        DarwinNetwork.parse_media_line(DarwinNetwork, line, iface, None)

    # assert the expected contents of the object
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'none'
    assert iface['media_options'] == 'none'

# Generated at 2022-06-22 23:40:28.709072
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ test the parse_media_line method of class DarwinNetwork """

    # Testing data for parse_media_line
    media_test_data = [
        ["media","autoselect", "(none)"],
        ["media:","autoselect","<unknown type>"],
        ["media:","autoselect","(none)"],
        ["media:","autoselect","10baseT/UTP <full-duplex>"],
        ["media:","autoselect","10baseT/UTP"],
        ["media:","autoselect","10baseT/UTP","status:","active"]
    ]


# Generated at 2022-06-22 23:40:39.681695
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = None
    ips = []
    darwinNet = DarwinNetwork()

    words = ['media:', 'autoselect', '(none)']
    darwinNet.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': '(none)'}

    words = ['media:', '<unknown', 'type>']
    darwinNet.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': 'type>'}


# Generated at 2022-06-22 23:40:48.629461
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Unit test for class DarwinNetwork
    """
    # Test a basic case of instanciation and testing a sample
    # facts extraction
    module = DarwinNetwork()

# Generated at 2022-06-22 23:41:00.820980
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    current_if['media_select'] = 'autoselect'
    current_if['media_type'] = 'none'
    current_if['media_options'] = ''
    try:
        darwin_network.parse_media_line(words = ['-', 'autoselect', 'none'],
                                        current_if = current_if,
                                        ips = [])
    except AttributeError:
        pass
    else:
        raise AssertionError("parse_media_line did not raise AttributeError")

    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == ''

# Generated at 2022-06-22 23:41:13.070940
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = dict()
    ips = dict()
    # test 1
    words = ['']
    expected_current_if = {
        'media': 'Unknown'
    }
    dn.parse_media_line(words, current_if, ips)
    assert current_if == expected_current_if
    # test 2
    words = ['media:', 'autoselect', '100baseTX', '(100baseTX<full-duplex>,']
    expected_current_if = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '100baseTX',
        'media_options': '(100baseTX<full-duplex>,)'
    }

# Generated at 2022-06-22 23:41:16.027521
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({})
    assert dn._platform == 'Darwin'
    assert hasattr(dn, 'get_all_interfaces')


# Generated at 2022-06-22 23:41:27.050944
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    iface = {}
    words = ["media", "auto"]
    DarwinNetwork.parse_media_line(DarwinNetwork, words, iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'auto'
    iface.clear()
    words = ["media", "<unknown", "type>"]
    DarwinNetwork.parse_media_line(DarwinNetwork, words, iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'
    iface.clear()
    words = ["media", "mediaoptions", "media_type", "mediaoptions"]
    DarwinNetwork.parse

# Generated at 2022-06-22 23:41:31.448473
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # DarwinNetworkCollector() creates and returns an object of class DarwinNetworkCollector.
    darwin_network_collector = DarwinNetworkCollector()
    # The returned object is of type DarwinNetworkCollector.
    assert isinstance(darwin_network_collector, DarwinNetworkCollector)


# Generated at 2022-06-22 23:41:39.116470
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinn = DarwinNetwork()
    current_if = {'name': 'en0', 'type': 'ether'}
    # First test with a normal media line
    line = 'media: autoselect (1000baseT <full-duplex>) status: active'
    darwinn.parse_media_line(line.split(), current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'
    # Now test with a media line from the bridge interface
    current_if = {'name': 'bridge0', 'type': 'ether'}

# Generated at 2022-06-22 23:41:42.571942
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # dummy data to pass to constructor
    net_info={'interfaces': {}}
    data=DarwinNetworkCollector(net_info)
    assert data._platform == 'Darwin'

# Generated at 2022-06-22 23:41:52.175396
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # GIVEN
    dn = DarwinNetwork()

    # WHEN macOS interface with bridge
    bridge = "media: <unknown type> status: inactive\n"
    dn._update_interface_info(bridge.split(), {'name': 'bridge'})

    # THEN
    assert dn.interface_info['bridge']['media'] == 'Unknown'
    assert dn.interface_info['bridge']['media_select'] == '<unknown'
    assert dn.interface_info['bridge']['media_type'] == 'unknown type'
    assert dn.interface_info['bridge']['media_options'] == ''

    # WHEN macOS interface without bridge
    eth = "media: autoselect (none)\n"
    dn._update_interface_info(eth.split(), {'name': 'eth'})

   

# Generated at 2022-06-22 23:42:03.568179
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'macaddress': '00:01:02:03:04:05', 'device': 'bridge0', 'type': 'Bridge', 'inet': [{'address': '172.16.0.1', 'netmask': '255.255.0.0', 'cidr': '172.16.0.1/16'}], 'inet6': []}
    words = ['media:', '<unknown', 'type>', '(none)', '(none)', '(none)']
    current_if = test_dict
    ips = []
    DarwinNetwork(None).parse_media_line(words, current_if, ips)

# Generated at 2022-06-22 23:42:06.379478
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    dn = DarwinNetwork()
    print(dn)


# Generated at 2022-06-22 23:42:07.470919
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:09.806805
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
  test = DarwinNetwork()
  assert test.get_ifconfig_path() == "/sbin/ifconfig", "Failed to set ifconfig path"

# Generated at 2022-06-22 23:42:18.078567
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collector = DarwinNetworkCollector()
    fact_class = collector.get_network_gather_platform()
    obj = fact_class()

    # Success
    current_if = {}
    ips = []
    obj.parse_media_line(['media:', 'autoselect', '(none)'], current_if, ips)

    assert ('media' in current_if and current_if['media'] == 'Unknown')
    assert ('media_select' in current_if and current_if['media_select'] == 'autoselect')
    assert ('media_type' in current_if and current_if['media_type'] == '(none)')
    assert ('media_options' not in current_if)

    current_if = {}
    ips = []

# Generated at 2022-06-22 23:42:18.711281
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:20.845051
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == 'Darwin'
    assert darwin.facts == {}

# Generated at 2022-06-22 23:42:21.755960
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNet = DarwinNetwork()
    assert darwinNet.platform == 'Darwin'


# Generated at 2022-06-22 23:42:30.575195
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = []
    words = []

    # Test the correct handling of a first line of the media section
    current_if['name'] = 'en0'
    words = ['media:', 'autoselect', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown', 'Media value not Unknown'
    assert current_if['media_select'] == 'autoselect', \
        'Media select value not autoselect'
    assert 'media_type' not in current_if, \
        'Media type should not be in current_if'
    assert 'media_options' not in current_if, \
        'Media options should not be in current_if'

    # Test the

# Generated at 2022-06-22 23:42:31.985227
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'



# Generated at 2022-06-22 23:42:39.628601
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'valid': 'valid'}
    test_ips = {}
    test_words = ['media:', '<unknown', 'type>', 'status:', 'inactive', 'description:', 'bridge0']
    DarwinNetwork.parse_media_line(DarwinNetwork, test_words, test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == {}

# Generated at 2022-06-22 23:42:44.593125
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    ifc = DarwinNetwork('/sbin/ifconfig')
    res = ifc()
    assert 'lo0' in res['all_ipv4_addresses']
    assert 'en0' in res['all_ipv6_addresses']


# Generated at 2022-06-22 23:42:46.207749
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_darwinNetwork=DarwinNetwork()
    assert test_darwinNetwork is not None

# Generated at 2022-06-22 23:42:51.701437
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from ansible.module_utils.facts import custom_class_loader
    from ansible.module_utils.facts.network.darwin import DarwinNetworkCollector
    DarwinNetworkCollector = custom_class_loader(DarwinNetworkCollector)
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:42:58.502252
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    result = {}
    current_if = {}
    test_input = 'autoselect <unknown type>'
    test_output = {'media': 'Unknown', 'media_options': {}, 'media_select': 'autoselect', 'media_type': 'unknown type'}
    dnw = DarwinNetwork()
    dnw.parse_media_line(test_input.split(), current_if, result)
    assert result == test_output

# Generated at 2022-06-22 23:43:00.721987
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()._platform == 'Darwin'
    assert DarwinNetworkCollector()._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:43:09.959887
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    test_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': '', 'addresses': {}}
    darwin_net.parse_media_line(['media:', 'link', 'status:', 'active'], test_if, [])
    assert 'link' == test_if['media_select']
    assert 'active' == test_if['media_options']
    assert 'Unknown' == test_if['media']

# Generated at 2022-06-22 23:43:11.877712
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    my_DarwinNetworkCollector = DarwinNetworkCollector()
    assert my_DarwinNetworkCollector.platform == 'Darwin'
    assert my_DarwinNetworkCollector.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:43:15.019373
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_test = DarwinNetwork()
    assert(my_test.platform == 'Darwin')
    assert(len(my_test.interfaces) == 0)
    assert(my_test.exclude_iface == [])
    assert(my_test.exclude_iftype == ['bridge'])


# Generated at 2022-06-22 23:43:16.073417
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'


# Generated at 2022-06-22 23:43:17.316876
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:20.267607
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    class_inst = DarwinNetworkCollector()
    assert class_inst.platform == 'Darwin'

# Generated at 2022-06-22 23:43:31.346094
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {"name": "en0", "macaddress": "48:5b:39:bc:c9:9d",
                 "type": "Ethernet", "mtu": 1500, "full_duplex": True,
                 "speed": 100, "active": True, "permanent": True,
                 "promisc": False, "prefixlen": 64, "addresses": {}}
    network = DarwinNetwork(None, None, None)
    network.parse_media_line(['media:', '<unknown', 'type>'], interface, {})
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'
    assert 'media_options' not in interface

# Generated at 2022-06-22 23:43:37.304572
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    # Assert default constructor values
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.interfaces == {}
    assert darwin_network.defaults['ifconfig_path'] == '/sbin/ifconfig'
    assert darwin_network.defaults['route_path'] == '/sbin/route'

# Generated at 2022-06-22 23:43:39.420586
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:43:51.246915
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

    # test for undefined media
    words = ['media:', '<unknown>', 'status:', 'active']
    result = d.parse_media_line(words, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'Unknown'
    assert 'media_type' not in result

    # test for defined media
    words = ['media:', '10baseT/UTP', '<full-duplex>', 'status:', 'active']
    result = d.parse_media_line(words, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == '10baseT/UTP'
    assert result['media_type'] == 'full-duplex'
    assert 'media_options' not in result

# Generated at 2022-06-22 23:44:02.074204
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.parse_media_line(['<unknown', 'type>'], {}, {})
    assert dn.current_if['media_select'] == 'Unknown'
    assert dn.current_if['media_type'] == 'unknown type'

    dn.parse_media_line(['media:', '10baseT/UTP', '(none)'], {}, {})
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == '10baseT/UTP'
    assert dn.current_if['media_options'] == '(none)'

    dn.parse_media_line(['media:', '10baseT/UTP'], {}, {})

# Generated at 2022-06-22 23:44:09.958948
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    words = ['media:', 'none', 'status:', 'inactive']
    current_if = {
        'device': 'en0',
    }
    ips = {}
    darwin_network.parse_media_line(words=words, current_if=current_if, ips=ips)
    assert current_if.get('media') == 'Unknown'
    assert current_if.get('media_type') == 'none'
    assert current_if.get('media_options') == 'status: inactive'

    words = ['media:', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = {
        'device': 'en0',
    }
    ips = {}
    darwin_network.parse_media_

# Generated at 2022-06-22 23:44:21.777939
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Unit test for method parse_media_line of class DarwinNetwork."""
    class_object = DarwinNetwork()
    # test case 1
    test_line = "      media: <unknown type>"
    expected = {
        'media': 'Unknown',
        'media_select': '<unknown',
        'media_type': 'unknown type'
    }
    class_object.parse_media_line(test_line.split(), {}, [])
    assert expected == class_object.interfaces[0]
    # test case 2
    test_line = "      media: IEEE 802.11 Wireless Ethernet autoselect mode 11b"

# Generated at 2022-06-22 23:44:24.160329
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # constructor creates an object that is a subclass of NetworkCollector
    assert issubclass(DarwinNetworkCollector, NetworkCollector)

    # constructor creates an object of class DarwinNetworkCollector
    assert isinstance(DarwinNetworkCollector, DarwinNetworkCollector)

# Generated at 2022-06-22 23:44:36.173461
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    x = DarwinNetworkCollector()
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['all'])
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['!all'])
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['minimal'])
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['!minimal'])
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['foo'])
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['!foo'])
    assert x
    x1 = DarwinNetworkCollector(gather_subset=['*'])
    assert x

# Generated at 2022-06-22 23:44:37.656508
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Unit Test for DarwinNetwork Constructor. """
    assert DarwinNetwork('eth0') is not None

# Generated at 2022-06-22 23:44:49.626086
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_darwin_network = DarwinNetwork()
    test_words = ['media:', 'auto', '1000baseT', 'full-duplex,flow-control(rxtx)']
    my_darwin_network.parse_media_line(test_words, {}, [])
    assert my_darwin_network['media'] == 'Unknown'
    assert my_darwin_network['media_select'] == test_words[1]
    assert my_darwin_network['media_type'] == test_words[2][1:-1]
    assert my_darwin_network['media_options'][0] == test_words[3].split('(')[0]
    assert my_darwin_network['media_options'][1] == test_words[3].split('(')[1].split(')')[0]
    test

# Generated at 2022-06-22 23:44:52.342001
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:45:03.016243
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:45:07.742585
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    dn = DarwinNetwork()
    dn.parse_media_line(['<unknown', 'type>'], current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:45:09.073578
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:45:11.666449
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-22 23:45:13.369145
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_obj = DarwinNetwork(None)
    assert my_obj.platform == 'Darwin'



# Generated at 2022-06-22 23:45:24.109183
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = []

    words = ["media:", "autoselect", "(none)", "status:", "active"]
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == "autoselect"
    assert not current_if.get('media_type')
    assert current_if['media_options'] == "none"

    words = ["media:", "10baseT/UTP", "(none)", "status:", "active"]
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == "10baseT/UTP"