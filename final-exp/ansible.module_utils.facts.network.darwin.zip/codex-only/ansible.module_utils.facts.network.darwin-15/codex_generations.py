

# Generated at 2022-06-22 23:35:28.654294
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    test_class = DarwinNetwork(None)
    test_class.parse_media_line(['	inet6', 'fe80::9eb7:abff:fea8:6f3f%en0', 'prefixlen', '64', 'scopeid', '0x9'], current_if, False)
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == '0x9'
    assert current_if['media_type'] == 'scopeid'
    assert current_if['media_options'] == '64'

    current_if = {}

# Generated at 2022-06-22 23:35:32.133831
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    thisDarwin = DarwinNetwork()
    assert thisDarwin.platform == 'Darwin'
    assert isinstance(thisDarwin, DarwinNetwork)
    assert isinstance(thisDarwin, GenericBsdIfconfigNetwork)
    assert isinstance(thisDarwin, NetworkCollector)
    assert isinstance(thisDarwin, dict)


# Generated at 2022-06-22 23:35:37.512999
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Build up a fake interface dictionary
    current_if = {"name": "en6", "type": "en", "number": "6", "subinterfaces": [], "flags": [], "state": []}
    ips = []

    # Call the method
    test_DarwinNetwork = DarwinNetwork()
    test_DarwinNetwork.parse_media_line(['media:', 'auto'], current_if, ips)

    # Check results
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if



# Generated at 2022-06-22 23:35:40.867468
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork('')
    assert d.platform == 'Darwin'
    assert isinstance(d.facts, dict)
    assert 'ifconfig' in d.facts
    assert 'netstat' in d.facts

# Generated at 2022-06-22 23:35:43.711175
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''
    test the constructor for the module
    '''
    darwin_net_obj = DarwinNetwork(None)
    assert isinstance(darwin_net_obj, DarwinNetwork)

if __name__ == '__main__':
    print('INFO: Running tests')
    test_DarwinNetwork()
    print('INFO: Tests Completed')

# Generated at 2022-06-22 23:35:48.695539
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork("name", "ipv4")
    assert d.name == "name"
    assert d._ipv4_fact_name == "ipv4"
    assert d._ipv6_fact_name == "ipv6"
    assert d._default_iface_filter == ['bridge', 'lo*']


# Generated at 2022-06-22 23:35:53.773286
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    # While testing the constructor, make sure we test the base class constructor.
    # The following will make sure the code for the base class' constructor gets covered by the unittest

    darwin_network = DarwinNetwork(module=None)

    assert(darwin_network is not None)


if __name__ == '__main__':
    test_DarwinNetwork()

# Generated at 2022-06-22 23:35:55.965821
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    iface = DarwinNetwork(None, None, None)
    assert iface


# Generated at 2022-06-22 23:36:08.288401
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_word1 = ["10Gbase-T", "<full-duplex>"]
    test_word2 = ["<unknown", "type>"]
    test_word3 = ["<full-duplex>"]
    test_word4 = ["none", "<full-duplex>"]

    dnw = DarwinNetwork()
    result1 = dnw.parse_media_line(test_word1, dict(), dict())
    assert result1['media'] == 'Unknown' and result1['media_select'] == test_word1[0] and result1['media_type'] == test_word1[1][1:-1]
    result2 = dnw.parse_media_line(test_word2, dict(), dict())

# Generated at 2022-06-22 23:36:10.861441
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj._fact_class, DarwinNetwork)
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:36:13.306280
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__ is DarwinNetworkCollector


# Generated at 2022-06-22 23:36:16.690512
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.get_interfaces() == []
    assert d.get_remote_addr() == []
    assert d.get_remote_port() == []

# Generated at 2022-06-22 23:36:18.734621
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor of DarwinNetwork class without arguments
    """
    facts = DarwinNetwork('en0')
    facts.populate()
    interfaces = facts.get_interfaces()

    assert interfaces is not None
    assert 'en0' in interfaces

# Generated at 2022-06-22 23:36:27.863960
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    if_name='wm0'
    cur_if={'name': if_name}
    ips=[]

    #Examples of media lines of Darwin
    # wm0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    #  lladdr 00:0c:29:33:f6:a6
    #  media: Ethernet autoselect (1000baseT full-duplex,master)
    #  status: active
    #
    # bridge0: flags=8823<UP,BROADCAST,SMART,SIMPLEX,MULTICAST> mtu 1500
    #  inet 192.168.0.255 netmask 0xffffff00 broadcast 192.168.0.255
    #  inet6

# Generated at 2022-06-22 23:36:30.275542
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert(dnc._platform == 'Darwin')
    assert(dnc._fact_class is DarwinNetwork)

# Generated at 2022-06-22 23:36:33.611758
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector(None)
    assert network.platform == 'Darwin'
    assert network._fact_class.platform == 'Darwin'


# Generated at 2022-06-22 23:36:43.998126
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This function is used to test constructor of class 'DarwinNetworkCollector'
    """

# Generated at 2022-06-22 23:36:48.795571
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork(None, NetworkCollector.LINKS_UP, NetworkCollector.ipv4_interfaces(), NetworkCollector.ipv6_interfaces())
    assert network.platform == 'Darwin'

# Generated at 2022-06-22 23:36:50.165995
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(None)
    assert dn._facts is None

# Generated at 2022-06-22 23:36:52.119055
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_DarwinNetwork = DarwinNetwork()
    assert test_DarwinNetwork.get_default_device() == b'self'

# Generated at 2022-06-22 23:36:58.324666
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["media:", "<unknown", "type>", "autoselect"]
    current_if = dict()
    ips = dict()
    expected_if = dict()
    expected_if['media'] = 'Unknown'
    expected_if['media_select'] = '<unknown'
    expected_if['media_type'] = 'unknown type'
    expected_if['media_options'] = {'autoselect': ''}
    DarwinNetwork._parse_media_line(words, current_if, ips)
    assert expected_if == current_if

# Generated at 2022-06-22 23:37:07.016997
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork(None)
    test_if = {
        'iface': 'bridge0',
        'hw_mac': '00:00:00:00:00:00'
    }
    test_ips = set()
    test_words = ['media:', '<unknown', 'type>', '<full-duplex>']
    test_if = darwin_network.parse_media_line(test_words, test_if, test_ips)
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == 'full-duplex'

# Generated at 2022-06-22 23:37:07.608204
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:19.282085
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # Test when empty list is passed
    words = []
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if == {}
    # Test when list with one element is passed
    words = ['lorem']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if == {}
    # Test when list with two elements is passed
    words = ['lorem', 'ipsum']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media']

# Generated at 2022-06-22 23:37:30.296631
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # media line is different to the default FreeBSD one
    dn.parse_media_line(words=['media:', '100baseTX', '<full-duplex>'],
                        current_if={}, ips=[])
    assert dn.media == 'Unknown'
    assert dn.media_select == '100baseTX'
    assert dn.media_type == 'full-duplex'
    assert dn.media_options == ''
    dn.parse_media_line(words=['media:', 'autoselect', 'status:', 'inactive'],
                        current_if={}, ips=[])
    assert dn.media == 'Unknown'
    assert dn.media_select == 'autoselect'
    assert dn.media_type == ''

# Generated at 2022-06-22 23:37:34.166561
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Get DarwinNetwork
    dn = DarwinNetwork()

    # Check if instance is of NetworkCollector
    assert isinstance(dn, NetworkCollector)

    # Check if DarwinNetwork is a subclass of NetworkCollector
    assert issubclass(DarwinNetwork, NetworkCollector)

# Generated at 2022-06-22 23:37:45.733549
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_obj = DarwinNetwork(None, None)
    assert darwin_network_obj
    words = ["media:", "autoselect", "(none)"]
    current_if = dict()
    ips = dict()
    darwin_network_obj.parse_media_line(words, current_if, ips)
    assert current_if.get('media') is None   # macOS does not give us this
    assert current_if.get('media_select') == "autoselect"
    assert current_if.get('media_type') is None
    assert current_if.get('media_options') is None

    current_if = dict()
    words = ["media:", "<unknown", "type>"]

# Generated at 2022-06-22 23:37:48.872054
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(
        DarwinNetwork(),
        DarwinNetwork
    )
    assert isinstance(
        DarwinNetwork(),
        GenericBsdIfconfigNetwork
    )

# Generated at 2022-06-22 23:37:52.501466
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    m = DarwinNetwork()
    words = ['<unknown', 'type>']
    current_if = {}
    ips = {}
    m.parse_media_line(words, current_if, ips)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == 'Unknown')
    assert(current_if['media_type'] == 'unknown type')
    assert(current_if['media_options'] == None)

# Generated at 2022-06-22 23:37:53.910522
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.platform == 'Darwin'
    assert darwin_network_collector.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:04.859771
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnw = DarwinNetwork()
    # test case 1, media line 1
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    # dictionary for expected output
    expected_result_1 = {'media': 'Unknown', 'media_select': 'autoselect',
        'media_type': '(none)', 'media_options': {'status': 'inactive'}}
    # test case 2, media line 2
    words = ['media:', '<unknown', 'type>', '(none)', 'status:', 'active']
    # dictionary for expected output
    expected_result_2 = {'media': 'Unknown', 'media_select': '<unknown type>',
        'media_type': '(none)', 'media_options': {'status': 'active'}}


# Generated at 2022-06-22 23:38:06.787602
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)



# Generated at 2022-06-22 23:38:17.793692
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    # missing
    d = iface.parse_media_line(['media', '1000baseLH'], {}, None)
    assert d == {'media': 'Unknown', 'media_select': '1000baseLH'}
    # with options
    d = iface.parse_media_line(['media', '1000baseLH', '<full-duplex>'], {}, None)
    assert d == {'media': 'Unknown', 'media_select': '1000baseLH', 'media_type': 'full-duplex'}
    # with options
    d = iface.parse_media_line(['media', '1000baseLH', 'full-duplex>', 'TX-flow-control'], {}, None)

# Generated at 2022-06-22 23:38:29.860577
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_test_line = "media: <unknown type> <unknown subtype>"
    mac_test_words = mac_test_line.split()
    mac_test_current_if = dict()
    mac_test_media_select = 'Unknown'
    mac_test_media_type = 'unknown type'
    mac_test_media = 'Unknown'
    mac_test_ips = dict()
    DarwinNetwork().parse_media_line(mac_test_words, mac_test_current_if, mac_test_ips)
    assert mac_test_current_if['media'] == mac_test_media
    assert mac_test_current_if['media_select'] == mac_test_media_select
    assert mac_test_current_if['media_type'] == mac_test_media_type

# Generated at 2022-06-22 23:38:39.203849
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = []
    words = ['media', 'autoselect', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    current_if = {}
    ips = []
    words = ['media', 'autoselect', '10baseT/UTP']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current

# Generated at 2022-06-22 23:38:40.417091
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector(None, None, None)
    assert isinstance(dnc, DarwinNetworkCollector)

# Generated at 2022-06-22 23:38:42.673110
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinnetwork_collector = DarwinNetworkCollector()
    assert darwinnetwork_collector
    assert darwinnetwork_collector._fact_class
    assert darwinnetwork_collector._fact_class.platform == "Darwin"
    assert not darwinnetwork_collector._fact_class.meta

# Generated at 2022-06-22 23:38:53.298305
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for case with no media_type
    current_if = {}  # the processed interface data
    ips = []  # the processed ip addresses
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect'}

    # Test for case with media_type
    current_if = {}
    ips = []
    words = ['media:', 'autoselect', '(none)', '10baseT/UTP']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)

# Generated at 2022-06-22 23:38:56.144699
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj=DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:39:04.622023
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'
    assert isinstance(darwin_network.ifconfig_path, str)
    assert darwin_network.ifconfig_path == 'ifconfig'
    assert darwin_network.ifconfig_exceptions == ('lo0',)
    assert isinstance(darwin_network.ifconfig_exceptions, tuple)
    assert darwin_network.route_path == '/sbin/route'
    assert darwin_network.v4_network_prefix == 'inet '
    assert darwin_network.v6_network_prefix == 'inet6 '

# Generated at 2022-06-22 23:39:14.049862
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # This test is for Darwin and runs only when unittest2 is installed
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    d = DarwinNetwork()

    # Assuming parsing output of `netstat -in`
    media = ['media:', '1000baseT', '<full-duplex>', 'status:', 'active']
    current_if = dict()
    ips = dict()
    d.parse_media_line(media, current_if, ips)
    assert current_if['media_select'] == '1000baseT'
    assert current_if['media_type'] == 'full-duplex'
    assert current_if['media_options'] == 'status: active'

    media = ['media:', '<unknown type>']
    current_if = dict

# Generated at 2022-06-22 23:39:15.157818
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:39:17.371073
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_net_collector = DarwinNetworkCollector()
    assert(darwin_net_collector._fact_class == DarwinNetwork)
    assert(darwin_net_collector._platform == 'Darwin')

# Generated at 2022-06-22 23:39:19.747556
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class is DarwinNetwork
    assert obj._platform is 'Darwin'

# Generated at 2022-06-22 23:39:22.356805
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert isinstance(DarwinNetworkCollector().get_network_facts(), DarwinNetwork)

# Generated at 2022-06-22 23:39:24.180094
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector is not None

# Generated at 2022-06-22 23:39:29.529193
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'name': 'en0'}
    media = DarwinNetwork.parse_media_line(['media:', 'auto', '(none)'], current_if, None)
    assert media['name'] == 'en0' and media['media_select'] == 'auto' \
        and media['media_type'] == '(none)' and media['media_options'] == None



# Generated at 2022-06-22 23:39:40.932066
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_network = {'_interfaces': {}}
    interface = dict()
    test_network['_interfaces']['en0'] = interface

    test_input = ['media:','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    test_words = test_input[1:]
    test_instance = DarwinNetwork()
    test_instance.parse_media_line(test_words,interface,test_network)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'a'
    assert interface['media_type'] == 'b'

# Generated at 2022-06-22 23:39:44.399256
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    keys = [
        'macaddress',
        'mtu',
        'media',
        'media_select',
        'media_type',
        'media_options',
    ]
    assert DarwinNetwork.get_option_keys() == keys

# Generated at 2022-06-22 23:39:56.138132
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = "autoselect (none) status: active"
    words = media_line.split()
    current_if = { 'media': 'Unknown' }
    ips = {}

    # Case 1: media_type
    words = "autoselect <unknown type> status: active".split()
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == 'unknown type'

    # Case 2: media_options
    words = "autoselect (100baseTX,HD,100baseTX,FD) status: active".split()
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_options'][0]['opt_val'] == '100baseTX'

# Generated at 2022-06-22 23:39:57.047758
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:39:58.610123
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # make sure we get a Network object
    assert isinstance(DarwinNetwork(), Network)

# Generated at 2022-06-22 23:40:10.023443
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    # check that the right fact class was initiated
    assert darwin_network.__class__.__name__ == 'DarwinNetwork'
    # check that the parent class was also initiated
    assert issubclass(darwin_network.__class__, NetworkCollector)
    # check that the platform attribute is set correctly
    assert darwin_network.platform == 'Darwin'
    # check that the example configuration is empty
    assert darwin_network.get_configuration() == {}
    # check that the interfaces are empty
    assert darwin_network.get_interfaces() == {}
    # check that the ip addresses are empty
    assert darwin_network.get_interface_ipaddr() == {}
    # check that the mac addresses are empty
    assert darwin_network.get

# Generated at 2022-06-22 23:40:20.442522
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # This tests the case where the media line is similar to default BSD case
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    current_if = dict()
    ips = dict()
    dn.parse_media_line(words, current_if, ips)
    expected = dict()
    expected['media'] = 'Unknown'
    expected['media_select'] = words[1]
    expected['media_type'] = words[2][1:-1]
    expected['media_options'] = dn.get_options(words[3])
    assert current_if == expected
    # This tests the case where the media line is a bit different from default BSD case
    words = ['media:', '<unknown', 'type>', '(none)']


# Generated at 2022-06-22 23:40:27.389124
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwin = DarwinNetwork('en0')
    current_if = dict()

    #test case 1
    words = ['media:', '<unknown', 'type>']
    result = dwin.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    #test case 2
    words = ['media:', 'auto', '10baseT/UTP']
    result = dwin.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '10baseT/UTP'

# Generated at 2022-06-22 23:40:31.717900
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector(None)
    assert darwin_network._platform == 'Darwin'
    assert darwin_network._fact_class == DarwinNetwork
    assert darwin_network._fact_class().platform == 'Darwin'

# Generated at 2022-06-22 23:40:36.806092
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ifconf = DarwinNetwork()
    ifconf.parse_media_line(['media:', 'autoselect', '<unknown type>'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:40:46.398616
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create object of class DarwinNetwork
    darwin_net = DarwinNetwork(None)

    # Create dictionary to store the parsed line
    current_if = {}

    # This is the line that is parsed, this line is part of the output of
    # ifconfig command on MacOSX
    words = ['media:', '<unknown type>', '(none)', 'status:', 'inactive']
    darwin_net.parse_media_line(words, current_if, None)

    # assert that the dictionary has the correct values
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == []

# Generated at 2022-06-22 23:40:57.769540
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test the DarwinNetwork Collector class
    :return:
    """
    # Sample ifconfig output

# Generated at 2022-06-22 23:40:58.349390
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:08.387310
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # initiate a DarwinNetwork object
    _DarwinNetwork = DarwinNetwork()
    # define the words list with a generic media line
    words = ['media:','autoselect','status:','active','en1s0']
    # execute the parse_media_line method
    current_if = {}
    ips = {}
    _DarwinNetwork.parse_media_line(words,current_if,ips)
    # verify the result
    assert current_if['media_select'] == words[1]
    assert current_if['media_type'] == words[2][1:-1]
    assert current_if['media_options'] == _DarwinNetwork.get_options(words[3])


# Generated at 2022-06-22 23:41:19.419173
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Constructor test without optional arguments
    darwin_network = DarwinNetwork()

# Generated at 2022-06-22 23:41:23.063328
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_collector = DarwinNetworkCollector()
    assert net_collector is not None
    assert net_collector._fact_class == DarwinNetwork
    assert net_collector._platform == 'Darwin'


# Generated at 2022-06-22 23:41:25.895281
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert(DarwinNetworkCollector.platform == 'Darwin')
    assert(DarwinNetworkCollector.fact_class == DarwinNetwork)

# Generated at 2022-06-22 23:41:35.299833
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test for a media line with only one word
    darwin_net = DarwinNetwork()
    current_if = {
        "name": "en0",
        "bsd_name": "en0",
        "type": "ether",
        "macaddress": "68:09:27:6f:3b:4c",
    }
    ips = {
        "address": "10.9.28.188",
        "netmask": "255.255.255.0",
        "broadcast": "10.9.28.255",
    }
    assert darwin_net.parse_media_line(["autoselect"], current_if, ips) == \
        {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': None, 'media_options': None}



# Generated at 2022-06-22 23:41:38.450518
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _fact_class = DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:41.764871
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # when
    obj = DarwinNetworkCollector()
    # assert
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:41:42.382520
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:51.960326
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Testing parsing of media line with 'media'
    words = ['media:', 'autoselect', 'status:', 'inactive']
    current_if = {}
    ips = {}
    network_obj = DarwinNetwork({},{}, {}, {}, {})
    network_obj.parse_media_line(words,current_if, ips)
    assert 'autoselect' == current_if['media_select']
    assert 'status' not in current_if.keys()

    # Testing parsing of empty media line
    words = []
    current_if = {}
    ips = {}
    network_obj.parse_media_line(words,current_if, ips)
    assert 'Unknown' == current_if['media']
    assert not current_if.get('media_select')
    assert not current_if.get

# Generated at 2022-06-22 23:41:55.178180
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:41:55.847093
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:07.609142
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_mac = DarwinNetwork()
    assert net_mac.platform == 'Darwin'
    assert net_mac.accumulator == {'default_ipv4': {},
                                   'default_ipv6': {},
                                   'interfaces': {},
                                   'all_ipv4_addresses': set(),
                                   'all_ipv6_addresses': set()}
    assert net_mac.interfaces == net_mac.accumulator['interfaces']
    assert net_mac.default_ipv4 == net_mac.accumulator['default_ipv4']
    assert net_mac.default_ipv6 == net_mac.accumulator['default_ipv6']

# Generated at 2022-06-22 23:42:16.993844
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = None
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    darwin_network = DarwinNetwork()

    # Test for media_type
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == '1000baseT'

    # ethernet: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    # media: autoselect
    # status: active
    words = ['media:', 'autoselect']
    darwin

# Generated at 2022-06-22 23:42:26.881104
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test to parse correct media line
    """
    # set up words and current_if dictionaries
    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    ips = dict()

    # create DarwinNetwork object
    d_network = DarwinNetwork()

    # parse media line
    d_network.parse_media_line(words, current_if, ips)

    # assert result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == dict()

# Generated at 2022-06-22 23:42:27.909226
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == 'Darwin'

# Generated at 2022-06-22 23:42:38.284234
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = [
        'media:',
        'IEEE802.11',
        '<unknown type>',
        'supported',
        'autoselect',
        'hostap',
        'status:',
        'active'
    ]
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    # check that media_select and media_type are correct
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    assert current_if['media_select'] == "IEEE802.11"
    assert current_if['media_type'] == "unknown type"
    # check that media_options available and correct

# Generated at 2022-06-22 23:42:42.592366
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = AnsibleModule(argument_spec={})
    # instantiate the network collector
    fact_class = DarwinNetworkCollector(module)
    assert fact_class._fact_class == DarwinNetwork
    assert fact_class._platform == 'Darwin'


# Generated at 2022-06-22 23:42:44.252074
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()


# Generated at 2022-06-22 23:42:56.094678
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    # Verify that when the media_select is 'auto', the media_type is 'Autoselect'
    assert network._parse_media_line(['media:', 'auto', '<unknown', 'type>'], {}, [])['media_type'] == 'Autoselect'
    assert network._parse_media_line(['media:', 'auto', '<unknown', 'type>'], {}, [])['media_select'] == 'autoselect'
    # Verify that when the media_select is set, the media_type is set
    assert network._parse_media_line(['media:', '1000baseT', '<full-duplex>', 'status:', 'active'], {}, [])['media_type'] == 'full-duplex'

# Generated at 2022-06-22 23:43:03.325665
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test data
    line = 'media: autoselect (1000baseT <full-duplex>) status: inactive\n'
    words = line.split()
    current_if = {}
    ips = []

    # call function under test
    result = DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)

    # check result
    assert result is None
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'

# Generated at 2022-06-22 23:43:03.693476
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:08.171735
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line(): # noqa: F811
    iface = {}
    words = ['media', 'autoselect', '100baseTX']
    DarwinNetwork().parse_media_line(words, iface, [])
    assert iface['media_type'] == '100baseTX'
    assert iface['media_select'] == 'autoselect'

    words = ['media', 'autoselect', '(none)']
    DarwinNetwork().parse_media_line(words, iface, [])
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'none'

    words = ['media', '<unknown', 'type>']
    DarwinNetwork().parse_media_line(words, iface, [])
    assert iface['media_select'] == 'Unknown'

# Generated at 2022-06-22 23:43:11.221520
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert not dn.lines_to_skip

# Generated at 2022-06-22 23:43:13.431683
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Create an instance of the DarwinNetwork class without arguments
    """
    darwin_network = DarwinNetwork()
    assert darwin_network


# Generated at 2022-06-22 23:43:19.581756
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:43:30.824160
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create the test object
    darwin_network = DarwinNetwork()
    # prepare arbitrary input
    media_line = ['media', 'autoselect', '(<unknown type>)', 'mediaopt', 'mediaopts']
    current_if = {}
    ips = {}

    # run the method to test
    darwin_network.parse_media_line(media_line,current_if, ips)

    # verify the results
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

    # prepare arbitrary input
    media_line = ['media', '10baseT/UTP', 'status', 'no', 'cable']

    #

# Generated at 2022-06-22 23:43:34.763881
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    unit = DarwinNetwork(None)
    # This will fail if no class name is returned
    assert unit is not None
    # This will fail if object is not of class DarwinNetwork
    assert isinstance(unit, DarwinNetwork)


# Generated at 2022-06-22 23:43:44.097444
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig = [
        "stf0: flags=0x100<PROMISC>",
        "group: bridge",
        "status: inactive"]

    # test if media is set to 'Unknown' if config line
    # starts with '<unknown type>'
    ifconfig.append("media: <unknown type> (none)")
    d = DarwinNetwork()
    d.set_current_if(ifconfig)
    d.parse_media_line(d.current_if.get('media').split(), d.current_if,
                       d.current_ip_addresses)
    assert 'Unknown' == d.current_if.get('media')

# Generated at 2022-06-22 23:43:48.148606
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert type(collector) == DarwinNetworkCollector
    assert collector._fact_class == DarwinNetwork
    assert collector._platform == 'Darwin'


# Generated at 2022-06-22 23:43:56.198390
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test with a 'media' line
    testdata = ["\tmedia: autoselect (1000baseT <full-duplex>) status: active"]
    facts = DarwinNetwork()
    parsed = facts.parse_media_line(testdata[0].split(' '), {}, [])
    assert parsed['media'] == 'Unknown'
    assert parsed['media_select'] == 'autoselect'
    assert parsed['media_type'] == '1000baseT'
    assert parsed['media_options'] == ['full-duplex']

    # Test with a 'media' line from a bridge interface with 'unknown' media
    testdata = ["\tmedia: <unknown type> status: active"]
    facts = DarwinNetwork()
    parsed = facts.parse_media_line(testdata[0].split(' '), {}, [])

# Generated at 2022-06-22 23:44:05.657044
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Setup
    current_if = {}
    current_if['ips'] = []
    current_if['flags'] = []

    # Test
    # words = ['media:', '<unknown type>', '(unknown)'];
    words = ['media:', '<unknown', 'type>', '(unknown)']
    DarwinNetwork.parse_media_line(None, words, current_if, current_if['ips'])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

    # words = ['media:', 'autoselect', '(none)'];
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media

# Generated at 2022-06-22 23:44:11.806976
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test for method parse_media_line of class DarwinNetwork
    """
    # Initialize
    dnw = DarwinNetwork()

    # Initialize keys
    current_if = {}
    current_if['media'] = None
    current_if['media_select'] = None
    current_if['media_type'] = None
    current_if['media_options'] = None

    words = []

    # Parse media line
    ips = []
    words = ['media:', 'autoselect (<unknown type>)', 'status:', 'active']
    dnw.parse_media_line(words=words, current_if=current_if, ips=ips)
    # Assert
    assert current_if['media'] == 'Unknown', "Media should be Unknown"

# Generated at 2022-06-22 23:44:21.435296
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    # create class instance
    DarwinNetInstance = DarwinNetwork()
    # test object creation
    assert isinstance(DarwinNetInstance, DarwinNetwork)
    # test parent of object
    assert isinstance(DarwinNetInstance, GenericBsdIfconfigNetwork)
    assert isinstance(DarwinNetInstance, NetworkCollector)
    # test object has all required attributes
    assert hasattr(DarwinNetInstance, 'platform')


# Generated at 2022-06-22 23:44:27.452087
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    ips = {}
    ifname = 'en0'
    words = ['en0:', 'media:', 'autoselect', '(100baseTX)']
    media = darwin_network.parse_media_line(words, {}, ips)
    assert media['media_select'] == 'autoselect'
    assert media['media_type'] == '100baseTX'
    assert media['media_options'] == ''

    words = ['en0:', 'media:', '<unknown', 'type>', '(100baseTX)']
    media = darwin_network.parse_media_line(words, {}, ips)
    assert media['media_select'] == 'Unknown'
    assert media['media_type'] == 'unknown type'
    assert media['media_options']

# Generated at 2022-06-22 23:44:31.145810
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector.get_network_facts()
    assert 'default_ipv4' in facts['ansible_facts']
    assert 'interfaces' in facts['ansible_facts']

# Generated at 2022-06-22 23:44:40.273037
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:44:52.388486
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test case:
    #   - Test case of general media line
    #   - Test case of media line wihout media type
    #   - Test case of media line with bridge interface
    #   - Test case of media line in Darwin 15
    #   - Test case of media line in Darwin 16, 17, 18
    #   - Test case of media line with huawei USB dongle in Darwin 15
    #   - Test case of media line with huawei USB dongle in Darwin 16, 17, 18
    current_if = {}
    ip_dict = {}
    # Test case of general media line
    words = ['media', 'auto', '10baseT/UTP', '(none)']
    DarwinNetwork.parse_media_line(words, current_if, ip_dict)

# Generated at 2022-06-22 23:44:53.751807
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()
    assert 1 == 1


# Generated at 2022-06-22 23:45:04.045342
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dm = DarwinNetwork()

    words = ['media:', 'autoselect', '(none)']
    current_if = {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': ''}
    ips = list()
    dm.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '', 'media_options': ''}

    words = ['media:', '10baseT/UTP', '<unknown>', '(none)']
    current_if = {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': ''}
    ips = list()
    dm.parse_media_line

# Generated at 2022-06-22 23:45:16.265375
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor for DarwinNetwork class should return an object
    """
    # Mac OS X 10.10 'Darwin Kernel Version 14.0.0: Mon Aug 25 16:57:51 PDT 2014; root:xnu-2782.1.52~2/RELEASE_X86_64'

# Generated at 2022-06-22 23:45:19.185993
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork(None, 'lo0')
    assert n.name == 'lo0'
    assert n.get_facts()['media'] == 'Unknown'