

# Generated at 2022-06-22 23:35:25.201051
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    iface = {}
    words = ['media:', '<unknown', 'type>']
    net.parse_media_line(words, iface, [])
    assert iface.get('media') == 'Unknown'
    assert iface.get('media_select') == 'Unknown'
    assert iface.get('media_type') == 'unknown type'
    words = ['media:', 'autoselect', '(1000baseT', 'full-duplex)', 'status:', 'active']
    net.parse_media_line(words, iface, [])
    assert iface.get('media') == 'Unknown'
    assert iface.get('media_select') == 'autoselect'
    assert iface.get('media_type') == '1000baseT'

# Generated at 2022-06-22 23:35:27.637544
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:35:29.977565
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test that the DarwinNetwork class can be initialized
    """

    dn = DarwinNetwork({},{},{},{})
    assert isinstance(dn, DarwinNetwork)


# Generated at 2022-06-22 23:35:30.511259
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:35:32.202559
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test the constructor of class DarwinNetworkCollector"""
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:35:34.338316
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == "Darwin"

# Generated at 2022-06-22 23:35:45.573692
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    import re

    dn = DarwinNetwork()
    current_if = {
        'name': 'bridge0',
        'address': '',
        'macaddress': '02:0f:ca:5a:2f:d8'
    }

# Generated at 2022-06-22 23:35:46.186557
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()

# Generated at 2022-06-22 23:35:48.413663
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinCollector = DarwinNetworkCollector()
    assert DarwinCollector.platform == 'Darwin'
    assert DarwinCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:35:57.847355
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    dwn.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    assert dwn.current_if['media'] == 'Unknown'
    assert dwn.current_if['media_select'] == 'autoselect'
    assert dwn.current_if['media_type'] == '(none)'
    assert dwn.current_if['media_options'] == {}

    dwn.parse_media_line(['media:', '<unknown', 'type>', '(none)'], {}, {})
    assert dwn.current_if['media'] == 'Unknown'
    assert dwn.current_if['media_select'] == 'Unknown'
    assert dwn.current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:36:00.443218
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork
    assert dnc._platform == 'Darwin'


# Generated at 2022-06-22 23:36:02.165198
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork().platform == 'Darwin'

# Generated at 2022-06-22 23:36:12.782468
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork({})
    current_if = {}
    ips = []
    # media line with no options
    dn.parse_media_line(
        ['media:', 'autoselect', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    # media line with options
    dn.parse_media_line(
        ['media:', 'autoselect', '(none)', '(none)'], current_if, ips)
    assert current_if['media_options'] == 'none'
    # media line with options but with mix of quotes

# Generated at 2022-06-22 23:36:14.595277
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:36:21.704153
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector is not None
    assert collector.__class__.__name__ == 'DarwinNetworkCollector'
    assert collector is not None
    assert collector.platform == 'Darwin'
    assert collector.fact_class is not None
    assert collector.fact_class.__class__.__name__ == 'DarwinNetwork'
    assert collector.fact_class is not None
    assert collector.fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:36:26.664891
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''Unit test for class DarwinNetwork
    '''
    ifc = DarwinNetwork([])

    assert hasattr(ifc, 'platform')
    assert hasattr(ifc, 'collect')
    assert hasattr(ifc, 'get_ifconfig_path')
    assert hasattr(ifc, 'set_options')
    assert hasattr(ifc, 'parse_media_line')

    assert ifc.platform == 'Darwin'


# Generated at 2022-06-22 23:36:28.083337
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(dict())
    assert dn.platform == 'Darwin'


# Generated at 2022-06-22 23:36:30.820393
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector(None, NetworkCollector._module_params)
    assert dnc.platform == 'Darwin'
    assert dnc.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:36:37.551552
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    ifconfigParser = DarwinNetwork('')
    ifconfigParser.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'



# Generated at 2022-06-22 23:36:43.963288
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mytest = DarwinNetwork()
    mytest.reset()
    # Initialize an empty dict
    result = mytest.parse_media_line(['media:', '<unknown', 'type>'], {}, [])
    # Uncomment the following line for detailed debugging of the test
    # print "RESULT: " + repr(result)
    # We expect the following result:
    expected = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    assert result == expected

# Generated at 2022-06-22 23:36:44.986309
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:56.020735
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector.collect()

# Generated at 2022-06-22 23:37:06.783233
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test parsing of media and media_select from test data
    """
    mac = DarwinNetwork(None)

    # Test 1
    words = ['media:', 'autoselect', '(none)', 'status:', 'active']

    mac.parse_media_line(words, mac.current_if, mac.ips)
    assert mac.current_if['media'] == 'Unknown'
    assert mac.current_if['media_select'] == 'autoselect'
    assert mac.current_if['media_type'] == '(none)'

    # Test 2
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    mac.parse_media_line(words, mac.current_if, mac.ips)
    assert mac.current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:37:08.980680
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector({}, None)
    assert obj._fact_class._platform == 'Darwin'

# Generated at 2022-06-22 23:37:17.791849
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # test with an empty list
    testmedia = []
    dn.parse_media_line(testmedia, {}, {})
    # test with a a line with unknown media type and media type is split up
    testmedia = ('media:', '<unknown', 'type>')
    currentif = {}
    ips = {}
    dn.parse_media_line(testmedia, currentif, ips)
    assert currentif['media'] == 'Unknown'
    assert currentif['media_select'] == 'Unknown'
    assert currentif['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:37:20.065052
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert isinstance(dnc, DarwinNetworkCollector)

# Generated at 2022-06-22 23:37:30.721964
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork(None)

    # media line is different to the default FreeBSD one
    # ['/sbin/ifconfig', 'xxxx', 'media', 'autoselect', '(none)']
    # create the test case
    current_if = {'device': "xxxx", 'options': {}, 'state': None, 'inet': [], 'inet6': [], 'media': None,
                  'media_select': None, 'media_type': None, 'media_options': None, 'vrf': None, 'addresses': []}
    words = ['media', 'autoselect', '(none)']
    # call the object's method
    obj.parse_media_line(words, current_if, None)
    # check it matches test case
    assert current_if['media'] == "Unknown"

# Generated at 2022-06-22 23:37:41.211089
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    def get_media(media_select, media_type, media_options):
        macos = DarwinNetwork()
        current_if = {}
        macos.parse_media_line(['media:', media_select, media_type, media_options], current_if, 0)
        return current_if

    assert get_media('10baseT', '(none)', '(none)') == {'media': 'Unknown', 'media_select': '10baseT',
                                                        'media_type': '(none)', 'media_options': '(none)'}

    assert get_media('<unknown', 'type>', '(none)') == {'media': 'Unknown', 'media_select': 'Unknown',
                                                        'media_type': 'unknown type', 'media_options': '(none)'}


# Generated at 2022-06-22 23:37:53.058037
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # This is the test dictionary used to store a mock interface
    # media line parsed from `ifconfig -a`
    i = {}

    # This is the list of words used in testing
    # split from the sample media line
    w = ['unknown']

    # This is a sample media line taken
    # from `ifconfig -a` on macOS Mojave
    # words are split and passed to parse_media_line
    line = 'media: <unknown type>'
    words = line.split()

    # Tested module is imported
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    # parse_media_line() is called with words argument
    # and i dictionary as current_if argument
    DarwinNetwork.parse_media_line(DarwinNetwork(), w, i)

    # Failed test for invalid media_select


# Generated at 2022-06-22 23:37:59.853471
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-22 23:38:02.800091
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert instance._fact_class.__name__ == "DarwinNetwork"
    assert instance._platform == "Darwin"

# Generated at 2022-06-22 23:38:04.788875
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:38:06.799218
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn._fact_class == DarwinNetwork
    assert dn._platform == 'Darwin'
    assert dn.platform == 'Darwin'

# Generated at 2022-06-22 23:38:15.706122
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import ansible.module_utils.facts.network.darwin as darwin
    words = ["media:", "<unknown", "type>", "(autoselect)"]
    current_if = {'name': 'unknown'}
    ips = []
    darwin.DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if == {'name': 'unknown', 'media': 'Unknown',
                          'media_select': 'Unknown', 'media_type': 'unknown type',
                          'media_options': {'(autoselect)': None}}

# Generated at 2022-06-22 23:38:23.004374
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    Tests for method parse_media_line of class DarwinNetwork.
    '''
    current_if = dict()
    ips = dict()
    dn = DarwinNetwork()

    # tests for media_select
    words = ['media:', 'none', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'none'

    words = ['media:', 'auto', '(autoselect)' ]
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'auto'

    # test for media_type
    words = ['media:', 'autoselect', 'none']
    dn.parse_media_line(words, current_if, ips)

# Generated at 2022-06-22 23:38:24.332921
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for constructor of class DarwinNetworkCollector"""
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.platform == 'Darwin'
    assert darwin_network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:35.072472
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # media line for tap0 interface of macOS-Sierra
    line = ['media:', 'autoselect', '(none)']
    # expected output
    result = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'none'
    }
    dn.parse_media_line(line, {}, {})
    assert dn.current_if == result
    # media line for tap0 interface of macOS-HighSierra
    line = ['media:', 'autoselect', '(100baseTX <full-duplex>)']
    # expected output
    result = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '100baseTX <full-duplex>'
    }

# Generated at 2022-06-22 23:38:36.732790
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    test_obj = DarwinNetworkCollector(None, None)
    assert test_obj
    assert isinstance(test_obj._fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:38:48.256197
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line_1 = 'media: <unknown type> status: inactive'
    test_line_2 = 'media: autoselect (1000baseT <full-duplex>) status: inactive'
    test_line_3 = 'media: autoselect (none) status: active'
    test_line_4 = 'media: 10baseT/UTP <half-duplex>'
    test_line_5 = 'media: 10baseT/UTP <full-duplex>'
    test_line_6 = 'media: 10baseT/UTP <full-duplex> mediaopt: testmediaopt'

    # Create a new instance of class DarwinNetwork
    darwin_network = DarwinNetwork()

    # Test parsing of input media line

# Generated at 2022-06-22 23:38:51.706018
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''Unit test for DarwinNetwork class'''
    # Setup the data to running test
    test_class = DarwinNetwork({}, {}, {})
    assert test_class.platform == "Darwin"
    # teardown


# Generated at 2022-06-22 23:38:55.696379
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test the constructor of DarwinNetworkCollector class.
    """
    network_collector = DarwinNetworkCollector()

    # Check the result
    assert network_collector.platform == 'Darwin'

# Generated at 2022-06-22 23:39:06.020806
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of DarwinNetwork
    darwin_network = DarwinNetwork()
    # define a dictionary for current_if as it is used inside parse_media_line
    current_if = {}
    # test case where it has to set current_if mac, media_select and media_type
    words = ['media:', 'autoselect', '(10baseT/UTP,<unknown type>)'
             '', 'status:', 'active']
    darwin_network.parse_media_line(words, current_if, '')
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': 'unknown type'}
    # test case where it has to set current_if mac, media_select, media_type
    # and media_options

# Generated at 2022-06-22 23:39:11.675946
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()

    assert dn.platform == 'Darwin'
    assert dn.type == 'Darwin'
    assert dn.facts == dict()
    assert dn.interface_name == 'lo0'
    assert dn.parsed_lines == list()
    assert dn.parsed_lines_filtered == list()
    assert dn.interfaces == dict()
    assert dn.bridge_interfaces == dict()
    assert dn.bond_interfaces == dict()
    assert dn.vlan_interfaces == dict()


# Generated at 2022-06-22 23:39:13.896137
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_facts = DarwinNetworkCollector(None, None).collect()
    assert 'en0' in network_facts['interfaces'].keys()

# Generated at 2022-06-22 23:39:14.412289
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:15.777543
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(None)
    assert dn
    assert dn.platform == "Darwin"

# Generated at 2022-06-22 23:39:20.954432
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_platform = 'Darwin'
    test_path = '/sbin:/usr/sbin:/usr/bin:/bin'
    test_commands = {
        'ifconfig': test_path + '/ifconfig',
        'route': test_path + '/route'
    }

# Generated at 2022-06-22 23:39:24.585065
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import sys
    import types
    import unittest2 as unittest

    sys.path.insert(1, 'network/plugins/modules')
    module_tmp = __import__('DarwinNetwork')

    class VariantDict(dict):
        def __getitem__(self, name):
            try:
                return super(VariantDict, self).__getitem__(name)
            except KeyError:
                return super(VariantDict, self).__getitem__(name.lower())

    darwin = module_tmp.DarwinNetwork()
    darwin.parse_media_line(['media:', '<unknown', 'type>', '<none>'], VariantDict(), None)
    assert darwin.current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:39:32.887405
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    print('test_DarwinNetwork_parse_media_line')
    # Test with media_line = 'media: autoselect (1000baseT <full-duplex,flow-control>) status: active'
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex,flow-control>)'
             'status:', 'active']
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    # Test with media_line = 'media: <unknown type> status: inactive'
    current_if = dict()

# Generated at 2022-06-22 23:39:34.850874
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    c = DarwinNetworkCollector()
    assert isinstance(c, DarwinNetworkCollector)

# Generated at 2022-06-22 23:39:36.596050
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    

# Generated at 2022-06-22 23:39:40.201082
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert issubclass(DarwinNetwork, NetworkCollector)
    assert issubclass(DarwinNetwork, GenericBsdIfconfigNetwork)
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:39:41.288759
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mytests = DarwinNetwork({}, {}, {})
    assert type(mytests) == DarwinNetwork

# Generated at 2022-06-22 23:39:52.488500
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork(None, None)
    assert darwinNetwork.platform == 'Darwin', \
        'Unexpected value for variable platform, got %s instead of Darwin' \
        % darwinNetwork.platform
    assert darwinNetwork.MEDIA_RE == \
        r'^\s+media:\s+([^ \t\n,]+)\s+(< ([^ \t\n,]+) >)?(.*)?', \
        'Unexpected value for variable MEDIA_RE, got %s instead of '\
        % darwinNetwork.MEDIA_RE

# Generated at 2022-06-22 23:39:54.119447
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_foo = DarwinNetwork()
    assert test_foo.platform == 'Darwin'

# Generated at 2022-06-22 23:39:58.670194
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {'name': 'eth0'}
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)', 'status:', 'active']
    d = DarwinNetwork()
    d.parse_media_line(words, iface, 0)
    assert iface['media_select'] == 'autoselect'
    assert iface.get('media', None) is None
    assert iface['media_type'] == '(100baseTX <full-duplex>)'
    assert 'media_options' not in iface

# Generated at 2022-06-22 23:40:07.961273
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    o = DarwinNetwork({}, {}, {}, [], None)
    assert o
    assert hasattr(o, 'get_ifconfig_path')
    assert hasattr(o, 'get_default_route')
    assert hasattr(o, 'get_ipv4_addresses')
    assert hasattr(o, 'get_ipv6_addresses')
    assert hasattr(o, 'get_interfaces')
    assert hasattr(o, 'get_interfaces_info')
    assert hasattr(o, 'get_network_facts')


# Unit test the constructor of class DarwinNetworkCollector

# Generated at 2022-06-22 23:40:18.085892
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test method parse_media_line of DarwinNetwork"""
    darwin = DarwinNetwork(None)
    # Test media line not containing media_type info
    words1 = ['media:', 'autoselect', "(none)"]
    fact_value1 = {'media': 'Unknown', 'media_select': 'autoselect',
                   'media_options': "(none)"}
    fact_value_ret1 = darwin.parse_media_line(words1, fact_value1, "ips")
    assert fact_value_ret1 == fact_value1
    # Test media line containing media_type info
    words2 = ['media:', '<unknown', 'type>', '(none)']

# Generated at 2022-06-22 23:40:19.213556
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), NetworkCollector)


# Generated at 2022-06-22 23:40:26.509683
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # just test that the media line parsing works as expected

    # set up some data to use
    words = ["media:", "autoselect", "(none)"]

    # create an instance of DarwinNetwork
    darwin_net = DarwinNetwork()

    # call method parse_media_line of DarwinNetwork
    # with data from words and some defaults
    darwin_net.parse_media_line(words, {}, {})

    # get the media_select value that was set
    media_select = darwin_net.current_if['media_select']

    # should be autoselect
    assert media_select == 'autoselect'

    # get the media_type value that was set
    media_type = darwin_net.current_if['media_type']

    # should be none

# Generated at 2022-06-22 23:40:28.299276
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    interface = DarwinNetwork()
    assert interface.is_default('123.123.123.123') == False

# Generated at 2022-06-22 23:40:32.249200
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test instantiation with no parameters
    # Results should be defaults.
    network = DarwinNetwork()
    assert network
    assert network.platform == 'Darwin'
    assert network.interfaces == {}
    assert network.data == {}



# Generated at 2022-06-22 23:40:35.556008
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    # Null instantiation
    result = DarwinNetworkCollector()
    assert type(result) == DarwinNetworkCollector


if __name__ == '__main__':
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:37.696760
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinCollector = DarwinNetworkCollector()
    assert type(darwinCollector) is DarwinNetworkCollector


# Generated at 2022-06-22 23:40:40.628278
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    # Basic initialization test
    assert isinstance(darwin_network_collector, NetworkCollector)

# Generated at 2022-06-22 23:40:47.445856
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac = DarwinNetwork()
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    mac.parse_media_line(words, current_if, {})
    assert 'Unknown' == current_if['media_select']
    assert 'unknown type' == current_if['media_type']
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    mac.parse_media_line(words, current_if, {})
    assert '(none)' == current_if['media_type']

# Generated at 2022-06-22 23:40:48.296274
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None, None, None)

# Generated at 2022-06-22 23:40:48.774961
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:00.562205
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork()
    current_if = {}
    test_obj._parse_media_line(["media:", 'autoselect', 'status:', 'active'], current_if)
    assert "media" not in current_if
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'
    assert current_if['media_options'] == 'active'

    current_if = {}
    test_obj._parse_media_line(["media:", '<unknown', 'type>'], current_if)
    assert "media" not in current_if
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:41:12.775449
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    from collections import OrderedDict

    drwin_if = DarwinNetwork()
    test_if = GenericBsdIfconfigNetwork()
    test_if.platform = 'Darwin'

    drwin_if.freebsd_media_line = True
    assert drwin_if.parse_media_line(['media:', 'media_select', 'media_type', 'media_options'], OrderedDict(), OrderedDict())['media'] == 'Unknown'
    assert drwin_if.parse_media_line(['media:', '<unknown', 'type>', 'media_options'], OrderedDict(), OrderedDict())['media']

# Generated at 2022-06-22 23:41:17.961225
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector.fact_class == DarwinNetwork

if __name__ == '__main__':
    # Unit test this module by calling it as a script
    test_DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:21.366444
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector class constructor
    """
    darwin_network_collector = DarwinNetworkCollector()

    assert darwin_network_collector._fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:41:24.099095
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'


# Generated at 2022-06-22 23:41:26.827893
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNet = DarwinNetwork()
    # test for correct platform name
    assert darwinNet.platform == 'Darwin'


# Generated at 2022-06-22 23:41:36.099977
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # Test data
    # media: 42baseT <full-duplex> media: autoselect (1000baseT <full-duplex,flow-control>) media: autoselect <flow-control> media: 10baseT/UTP <half-duplex> media: 10baseT/UTP <full-duplex> media: 10baseT/UTP <full-duplex,flow-control> media: <unknown type>

# Generated at 2022-06-22 23:41:38.642675
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:41.506880
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.__class__.__name__ == 'DarwinNetwork'

# Generated at 2022-06-22 23:41:44.911925
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector.platform == 'Darwin'
    assert net_collector._fact_class == DarwinNetwork
    assert net_collector._platform == 'Darwin'


# Generated at 2022-06-22 23:41:55.129754
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    data = dict(current_if={}, ips={})
    words = ['en4:', 'media:', '<unknown', 'type>']
    network.parse_media_line(words, data['current_if'], data['ips'])
    assert data['current_if']['media'] == 'Unknown'
    assert data['current_if']['media_select'] == 'Unknown'
    assert data['current_if']['media_type'] == 'unknown type'
    words = ['en0:', 'media:', 'autoselect', '(none)']
    network.parse_media_line(words, data['current_if'], data['ips'])
    assert data['current_if']['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:42:01.711007
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network import DarwinNetwork
    darwin_network=DarwinNetwork(None, None)
    current_if = {}
    darwin_network.parse_media_line(['media:','Unknown','<unknown','type>'],current_if,'')
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:42:03.604144
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dar = DarwinNetwork()
    assert dar.__class__ == DarwinNetwork


# Generated at 2022-06-22 23:42:05.006402
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:42:08.223065
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = 'ansible.module_utils.facts.network.darwin'
    darwin = DarwinNetworkCollector()
    assert darwin._module == module

# Generated at 2022-06-22 23:42:08.812262
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    pass

# Generated at 2022-06-22 23:42:17.633636
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}

    # type is unknown
    words = ['media', '<unknown', 'type>']
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert 'media_select' not in current_if
    assert current_if['media_type'] == 'unknown type'

    # media is auto
    words = ['media', 'auto']
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert 'media_select' not in current_if
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

   

# Generated at 2022-06-22 23:42:18.736763
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector(None)
    assert network._fact_class == DarwinNetwork
    assert network._platform == 'Darwin'

# Generated at 2022-06-22 23:42:20.130066
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    c = DarwinNetworkCollector()
    assert (c.platform == 'Darwin')

# Generated at 2022-06-22 23:42:23.257363
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.get_platform() == 'Darwin'

# Generated at 2022-06-22 23:42:24.205955
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnet = DarwinNetwork()
    assert not dnet.version_info()
    assert dnet.platform == 'Darwin'



# Generated at 2022-06-22 23:42:25.318695
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test DarwinNetwork class constructor"""
    # Test if DarwinNetwork class can be constructed
    DarwinNetwork()

# Unit Test for DarwinNetwork.get_interfaces method

# Generated at 2022-06-22 23:42:27.116248
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-22 23:42:35.204143
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # define some words that will fake the ifconfig output
    words = ["media:", "autoselect", "(none)"]
    current_if = {}
    # call method that is to be tested
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, None)
    # expected result after parsing the output
    # it should have the attributes media and media_select
    media_select = "autoselect"
    media = "Unknown"
    assert current_if['media_select'] == media_select
    assert current_if['media'] == media


# Generated at 2022-06-22 23:42:36.586169
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork


# Generated at 2022-06-22 23:42:45.997784
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Fake Darwin network interface
    ifname = 'lo0'
    ifstate = 'UP'
    ifaddr = []
    iflist = dict([(ifname, (ifaddr, ifstate))])

    # Parse fake media line
    media_line = [ifname, 'media', '<unknown', 'type>']
    fake_if = dict()
    network = DarwinNetwork()
    network.parse_media_line(media_line, fake_if, ifaddr)
    assert 'Unknown' == fake_if['media']
    assert '<unknown' == fake_if['media_select']
    assert 'unknown type' == fake_if['media_type']

# Generated at 2022-06-22 23:42:48.109226
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    nc = DarwinNetworkCollector()
    assert nc.platform == 'Darwin'
    assert nc.fact_class == DarwinNetwork


# Generated at 2022-06-22 23:42:56.828104
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    ips = {}
    darwin_if = DarwinNetwork()
    darwin_if.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == []



# Generated at 2022-06-22 23:42:59.611093
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector(None, None, None)
    assert dnc.__class__.__name__ == 'DarwinNetworkCollector'


# Generated at 2022-06-22 23:43:00.095372
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:00.878463
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()


# Generated at 2022-06-22 23:43:02.280627
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:43:07.313936
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Construct a class to be tested
    :return: an instance of the DarwinNetwork class
    """
    test_class = DarwinNetwork()
    assert test_class.platform == 'Darwin'


# Generated at 2022-06-22 23:43:07.872090
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:10.885599
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class.platform == 'Darwin'
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:43:18.247751
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test without media_type specified
    darwin_network_test_obj = DarwinNetwork()
    line = ['media:', 'autoselect', '(none)']
    line_words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}
    darwin_network_test_obj.parse_media_line(line_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if

    # Test with media_type specified
    darwin_network_test_obj = DarwinNetwork()
    line = ['media:', 'autoselect', '(none)']

# Generated at 2022-06-22 23:43:29.202525
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['<unknown type>','<unknown type>','unknown type']
    network = DarwinNetwork()
    current_if = {}
    current_if['media'] = 'Unknown'  # Mac does not give us this
    network.parse_media_line(words,current_if)
    for key, value in current_if.items():
        print(key, end='')
        print('=', end='')
        print(value)
    # <unknown type> media_select=<unknown type> media_type=unknown type media_options=None
    # media is obtained from other place while media_select, media_type and media_options are updated


# Generated at 2022-06-22 23:43:39.689128
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_collector = DarwinNetwork()
    assert darwin_network_collector.__module__ == "module_utils.facts.network.darwin"
    assert darwin_network_collector.platform == 'Darwin'
    # Note: no Darwin network sample output to test with - use FreeBSD
    assert darwin_network_collector.get_facts()['lo0'] == {'addresses': {}, 'active': True, 'device': 'lo0', 'duplex': 'Full', 'enabled': True, 'media': 'Unknown', 'media_select': 'Autoselect', 'media_type': 'Ethernet', 'mtu': 16384, 'promisc': False, 'type': 'loopback', 'up': True}


# Generated at 2022-06-22 23:43:43.996318
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    # Assert the constructor
    assert DarwinNetworkCollector(None, None).__class__.__name__ == 'DarwinNetwork'
    # Assert the platform
    assert DarwinNetworkCollector(None, None)._platform == 'Darwin'

# Generated at 2022-06-22 23:43:46.597271
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    facts = d.populate()
    assert isinstance(facts, dict)

# Generated at 2022-06-22 23:43:48.640367
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    # We do not have any assert for the constructor for now
    assert True

# Generated at 2022-06-22 23:43:49.666166
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-22 23:43:55.989530
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # arrange
    words = [
        '100baseTX',
        '(Half-duplex,',
        '100Mbps)',
        'status:',
        'active'
    ]

    # act
    current_if = {'media': 'Unknown'}
    ips = ['something']
    mac_darwin = DarwinNetwork()
    mac_darwin.parse_media_line(words, current_if, ips)

    # assert
    assert current_if['media_select'] == '100baseTX'
    assert current_if['media_type'] == 'Half-duplex,'
    assert current_if['media_options'] == '100Mbps)'

# Generated at 2022-06-22 23:43:58.040272
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork({}, {}, {})
    assert net.platform == 'Darwin'


# Generated at 2022-06-22 23:44:00.169830
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'
    assert network._ifconfig_path == '/sbin/ifconfig'

# Generated at 2022-06-22 23:44:02.577999
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fact_class = DarwinNetworkCollector(None,None)
    assert fact_class._platform == 'Darwin'
    assert fact_class._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:44:03.510121
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector('ignore')

# Generated at 2022-06-22 23:44:06.360768
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:44:07.934179
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert isinstance(darwin_network, DarwinNetwork)

# Generated at 2022-06-22 23:44:09.152542
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()

    assert obj
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:44:10.881415
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetworkCollector = DarwinNetworkCollector('test_object')
    assert darwinNetworkCollector.platform == 'Darwin'


# Generated at 2022-06-22 23:44:22.542423
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:44:29.723131
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = '   media: <unknown type> <unknown subtype>'
    words = line.split()
    interface = dict()
    DarwinNetwork().parse_media_line(words, interface, None)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'
    assert interface['media_options'] == 'unknown subtype'
    # other things might be there but that is unrelated to media for example vendor

# Generated at 2022-06-22 23:44:36.303704
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['', 'autoselect', '<unknown type>']
    result = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_options': '',
        'media_type': 'unknown type'
    }
    # macOS sets the media to '<unknown type>' for bridge interface
    darwin_network = DarwinNetwork()
    assert result == darwin_network.parse_media_line(words, 'interface', 'ip')

# Generated at 2022-06-22 23:44:44.903164
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = "media: autoselect (none)"
    current_if = {}
    ips = []
    collector = DarwinNetwork()
    collector.parse_media_line(line.split(), current_if, ips)
    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

# method is not tested because it can be tested in the same way as in FreeBSD
# and test is already defined in facts/network/generic_bsd/test_generic_bsd_ifconfig_network.py

# Generated at 2022-06-22 23:44:45.482794
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:57.307802
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-22 23:44:59.763048
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({}, {}, {})
    assert dn.platform == 'Darwin'

# Generated at 2022-06-22 23:45:03.771541
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    test_DarwinNetworkCollector = DarwinNetworkCollector()
    assert test_DarwinNetworkCollector.__class__.__name__ == 'DarwinNetworkCollector'
    assert test_DarwinNetworkCollector._platform == 'Darwin'


# Generated at 2022-06-22 23:45:05.303224
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()

# Generated at 2022-06-22 23:45:16.892496
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    line = 'media: <unknown type>'
    words = line.split()
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if.keys()

    line = 'media: 100baseTX <full-duplex>'
    words = line.split()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '100baseTX'
    assert current