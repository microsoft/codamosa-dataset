

# Generated at 2022-06-22 23:35:28.611017
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', 'status:', 'active', 'last', 'active',
             '<unknown', 'type>', 'supported', 'media:', 'none',
             'supported', 'capabilities:', 'none']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['macaddress'] == 'unknown'
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''
    assert current_if['media_status'] == 'active'

# Generated at 2022-06-22 23:35:29.397338
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None)

# Generated at 2022-06-22 23:35:30.494323
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class is DarwinNetwork

# Generated at 2022-06-22 23:35:33.083497
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for DarwinNetworkCollector"""
    assert DarwinNetworkCollector.__name__ == "DarwinNetworkCollector"
    assert DarwinNetworkCollector.platform == "Darwin"
    assert DarwinNetworkCollector.is_supported("Darwin") is True

# Generated at 2022-06-22 23:35:34.197447
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)

# Generated at 2022-06-22 23:35:35.930316
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert NetworkCollector._platform == 'Generic'
    assert DarwinNetworkCollector._platform == 'Darwin'



# Generated at 2022-06-22 23:35:38.888525
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    x = DarwinNetworkCollector()
    assert x._platform == 'Darwin', "Failed to set _platform correctly"


# Generated at 2022-06-22 23:35:49.646115
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize a dictionary containing interface data
    ifdata = {}
    # Initialize an instance of the DarwinNetwork class
    darwin_nw_class = DarwinNetwork()
    # Build the list of words to be passed to parse_media_line method
    words = ['gibberish', '<unknown', 'type>']
    # Call parse_media_line method of DarwinNetwork class and store the result
    darwin_nw_class.parse_media_line(words=words, current_if=ifdata, ips={})
    # Assert the value of media_select field in ifdata dictionary
    assert ifdata['media_select'] == 'Unknown'
    # Assert the value of media_type field in ifdata dictionary
    assert ifdata['media_type'] == 'unknown type'
    # Assert the value of media field in ifdata

# Generated at 2022-06-22 23:35:50.877160
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'

# Generated at 2022-06-22 23:35:52.711109
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    a = DarwinNetwork()
    assert type(a).__name__ == 'DarwinNetwork'


# Generated at 2022-06-22 23:35:57.992341
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor updates the 'facts' instance
    """
    # Not using constructor
    # but using inherited function to test
    facts = dict()

    # instance being tested
    darwin_network = DarwinNetwork({})
    # pass the current instance facts as argument to the function
    darwin_network.populate(facts)

    # assert
    assert 'interfaces' in facts
    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts



# Generated at 2022-06-22 23:36:09.879725
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # test media line with all options
    test_line = 'autoselect  (100baseTX <full-duplex>) status: active'
    current_if = {}
    darwin_network.parse_media_line(test_line.split(), current_if, [])
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': '100baseTX', 'media_options': 'full-duplex'}

    # test media line with one option
    test_line = 'autoselect  (100baseTX <full-duplex>) status: active'
    current_if = {}
    darwin_network.parse_media_line(test_line.split(), current_if, [])
    assert current_if

# Generated at 2022-06-22 23:36:12.073654
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:36:14.409422
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dm = DarwinNetwork()
    assert dm.platform == 'Darwin'


# Generated at 2022-06-22 23:36:24.992877
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

    # test a valid line
    current_medias = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'status: active', 'media_options': [None]}
    current_if = {}
    line_for_parse = 'media: autoselect  status: active'
    words = line_for_parse.split()
    d.parse_media_line(words, current_if, current_medias)
    assert current_if == current_medias

    # test a line with an unknown type
    current_medias = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': [None]}
    current_if = {}

# Generated at 2022-06-22 23:36:31.472681
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    defs = {'media': 'Unknown',
            'media_select': 'none',
            'media_type': 'none',
            'media_options': '0x0'}
    d = DarwinNetwork()
    ifname = 'ut'
    ifd = d.parse_media_line(['media:', 'none', 'none', 'mediaopt:', '0x0'], ifname)
    assert ifd['media'] == defs['media']
    assert ifd['media_select'] == defs['media_select']
    assert ifd['media_type'] == defs['media_type']
    assert ifd['media_options'] == defs['media_options']

# Generated at 2022-06-22 23:36:42.766084
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = 'ansible.module_utils.facts.network.darwin'
    DarwinNetwork = getattr(__import__(module, fromlist=['DarwinNetwork']), 'DarwinNetwork')

# Generated at 2022-06-22 23:36:47.364350
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    print('dn (DarwinNetworkCollector) = ' + str(dn))
    assert(dn.platform == 'Darwin')
    assert(dn.fact_class.platform == 'Darwin')

# Generated at 2022-06-22 23:36:57.665123
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = {}
    # common lines
    words = {
        'media': 'media',
        'media_select': 'media_select',
        'media_type': 'media_type',
        'media_options': 'media_options',
    }

    # Test for media line with unknown type - example from MacOSX
    darwin_network.parse_media_line(['', '<unknown', 'type>'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # Test for media line - example from MacOSX
    # with media_select, no media_type, and

# Generated at 2022-06-22 23:37:00.335527
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    kwargs = dict()
    obj = DarwinNetworkCollector(kwargs=kwargs)
    assert obj.kwargs == kwargs
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:37:00.957091
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:02.682778
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-22 23:37:06.153335
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    spec = dict(facts=dict(network=dict(interfaces=dict())))
    facts = DarwinNetwork(spec)
    assert facts
    assert facts.fact_subclass == 'generic_bsd'



# Generated at 2022-06-22 23:37:11.650022
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type>'
    collector = DarwinNetwork()
    result = collector.parse_media_line(line.split(), {}, None)
    assert(result['media'] == 'Unknown')
    assert(result['media_select'] == 'Unknown')
    assert(result['media_type'] == 'unknown type')

# Generated at 2022-06-22 23:37:17.918860
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w = DarwinNetwork()
    words = 'lladdr 44:a8:42:f2:3e:87'.split()
    w.parse_media_line(words, {}, {})
    assert w._current_if['media'] == 'Unknown'
    assert w._current_if['media_select'] == 'lladdr'
    assert w._current_if['media_type'] == '44:a8:42:f2:3e:87'

# Generated at 2022-06-22 23:37:19.854189
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Test DarwinNetworkCollector constructor """
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:37:30.507512
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    current_if = dict()
    # adding some values to have a non-empty dict
    # this is important because this dict gets passed to other methods
    current_if['name'] = 'lo0'
    current_if['type'] = 'Loopback'
    ips = dict()
    words = ['media:', '1000baseT', 'media_type', 'media_options']
    dnet.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1000baseT'
    assert current_if['media_type'] == 'media_type'
    assert current_if['media_options'] == {'media_options': 'media_options'}


# Generated at 2022-06-22 23:37:32.358415
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''Unit test for constructor of class DarwinNetwork'''
    dwin_nw_inst = DarwinNetwork()

# Generated at 2022-06-22 23:37:43.353653
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    bn = DarwinNetwork()
    assert bn.facts['all_ipv4_addresses'] == []
    assert bn.facts['all_ipv6_addresses'] == []
    assert bn.facts['default_ipv4']['gateway'] == ''
    assert bn.facts['default_ipv4']['interface'] == ''
    assert bn.facts['default_ipv4']['address'] == ''
    assert bn.facts['default_ipv4']['netmask'] == ''
    assert bn.facts['default_ipv4']['network'] == ''
    assert bn.facts['default_ipv6']['gateway'] == ''
    assert bn.facts['default_ipv6']['interface'] == ''

# Generated at 2022-06-22 23:37:51.568627
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    media_line = "media: <unknown type> <unknown subtype>"
    words = media_line.split()
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-22 23:37:54.043563
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    try:
        obj = DarwinNetworkCollector()
    except Exception as e:
        assert False, "Failed to create new DarwinNetworkCollector object: " + str(e)

# Generated at 2022-06-22 23:37:55.551267
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    m = DarwinNetwork()
    assert m._platform == 'Darwin'

# Generated at 2022-06-22 23:37:59.953541
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.facts == {}
    ifconfig_path = '/sbin/ifconfig'
    obj = DarwinNetwork(ifconfig_path)
    assert obj.facts == {}
    assert obj.ifconfig_path == ifconfig_path


# Generated at 2022-06-22 23:38:08.610703
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifcape = DarwinNetwork()

    # media line is different to the default FreeBSD one
    media_line_1 = 'media: <unknown type>'
    media_line_1_words = media_line_1.split()
    current_ifc_1 = {}
    ifcape.parse_media_line(media_line_1_words, current_ifc_1, {})
    assert current_ifc_1['media_select'] == 'Unknown'
    assert current_ifc_1['media_type'] == 'unknown type'
    assert not current_ifc_1.has_key('media_options')

    media_line_2 = 'media: autoselect (none)'
    media_line_2_words = media_line_2.split()
    current_ifc_2 = {}
    ifcape.parse_

# Generated at 2022-06-22 23:38:19.443916
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media', '<unknown', 'type>']
    current_if = {}
    ips = []
    ifc = DarwinNetwork()
    ifc.parse_media_line(words,current_if,ips)
    assert current_if['media']=='Unknown'
    assert current_if['media_select']=='Unknown'
    assert current_if['media_type']=='unknown type'
    words = ['media', 'auto', '<unknown type>']
    current_if = {}
    ips = []
    ifc = DarwinNetwork()
    ifc.parse_media_line(words,current_if,ips)
    assert current_if['media']=='Unknown'
    assert current_if['media_select']=='auto'
    assert current_if['media_type']=='unknown type'


# Generated at 2022-06-22 23:38:30.803939
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork({}, [], [])
    assert net.platform == 'Darwin'
    assert net.ipv4_interfaces is None
    assert net.ipv6_interfaces is None
    assert net.netmask6 is None
    assert net.netmask4 is None
    assert net.ifname == ''
    assert net.alias == ''
    assert net.address == ''
    assert net.netmask is None
    assert net.address6 is None
    assert net.netmask6 is None
    assert net.bcast is None
    assert net.hwaddr is None
    assert net.media is None
    assert net.media_select is None
    assert net.media_type is None
    assert net.media_options is None

# Constructor of class DarwinNetworkCollector

# Generated at 2022-06-22 23:38:37.206649
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    darwin = DarwinNetwork()
    assert(darwin.platform == 'Darwin')
    assert(darwin.lo0['ipv4'] == ['127.0.0.1'])
    assert(darwin.lo0['ipv6'] == ['localhost',
                                  'ip6-localhost',
                                  'ip6-loopback'])
    assert(darwin.lo0['mac'] == '00:00:00:00:00:00')
    assert(darwin.lo0['active'] == True)

# Generated at 2022-06-22 23:38:45.719303
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.current_if = {'name': 'eth0'}
    ifc.parse_media_line(['media:', 'autoselect', '(none)', 'status:', 'inactive'], ifc.current_if, [])
    assert 'media' in ifc.current_if
    assert ifc.current_if['media'] == 'Unknown'
    assert ifc.current_if[
        'media_select'] == 'autoselect'

# Generated at 2022-06-22 23:38:47.771110
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'
    assert d.use_ipv6 is False



# Generated at 2022-06-22 23:38:48.343948
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:38:51.811172
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Unit test for DarwinNetwork class constructor
    """
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.command == 'ifconfig'

# Generated at 2022-06-22 23:38:54.886587
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert isinstance(collector, DarwinNetworkCollector)
    assert isinstance(collector.fact, DarwinNetwork)

# Generated at 2022-06-22 23:38:58.049203
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_test = DarwinNetwork()
    assert my_test.platform == 'Darwin'
    assert my_test.media_regexp is not None


# Generated at 2022-06-22 23:39:02.449713
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test creation of an instance of the DarwinNetwork class
    """
    # create an instance of the DarwinNetwork class
    darwin_net = DarwinNetwork(None, None)
    # check if it is an instance of DarwinNetwork
    assert isinstance(darwin_net, DarwinNetwork)
    # check if it is an instance of NetworkCollector
    assert isinstance(darwin_net, NetworkCollector)
    # check if it is an instance of BaseNetwork
    from ansible.module_utils.facts.network.base import BaseNetwork
    assert isinstance(darwin_net, BaseNetwork)
    # check for platform
    assert darwin_net.platform == 'Darwin'


# Generated at 2022-06-22 23:39:03.725110
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # instantiate DarwinNetwork
    my_darwinnet = DarwinNetwork()
    assert(isinstance(my_darwinnet, DarwinNetwork))



# Generated at 2022-06-22 23:39:13.212480
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    A simple unit test to check the parse_media_line method
    with different typical input and validating the returned dict
    """

    test_facts = {
        'eth0': {
            'media': 'Ethernet',
            'media_select': 'autoselect',
            'media_type': 'status: active',
            'media_options': 'none'
        },
        'bridge0': {
            'media': 'Unknown',
            'media_select': 'autoselect',
            'media_type': 'unknown type',
            'media_options': 'none'
        },
        'bridge100': {
            'media': 'Unknown',
            'media_select': 'autoselect',
            'media_type': 'unknown type',
            'media_options': 'none'
        }
    }



# Generated at 2022-06-22 23:39:14.364985
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collect = DarwinNetworkCollector()
    assert collect.platform == 'Darwin'

# Generated at 2022-06-22 23:39:20.113221
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Tests DarwinNetwork's parse_media_line method.
    """
    # Skip if we don't have netifaces
    if not HAS_NETIFACES:
        pytest.skip('No netifaces module present')

    # Test with valid input
    test_words = ['media:',
                  'autoselect',
                  '<unknown type>',
                  '(none)']
    test_current_if = {}
    test_ips = None
    DarwinNetwork().parse_media_line(test_words, test_current_if, test_ips)
    assert test_current_if['media_select'] == 'autoselect'
    assert test_current_if['media_type'] == 'unknown type'
    assert test_current_if['media_options'] == None

# Generated at 2022-06-22 23:39:28.790766
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = ['<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>', 'unknown', 'type', 'status:active']
    current_if = {'ifconfig_interfaces': {}}
    DarwinNetwork.parse_media_line(DarwinNetwork, line, current_if, {'media': 'Unknown'})
    assert current_if == {'ifconfig_interfaces': {}, 'media': 'Unknown', 'media_options': {'status': 'active'},
                          'media_select': 'unknown', 'media_type': 'type'}

# Generated at 2022-06-22 23:39:30.223839
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:39:41.268918
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
   words = ["media:", "autoselect", "(none)", "status:", "inactive"]
   current_if = {'media': 'Autoselect', 'media_type': '', 'media_select': '(none)', 'media_options': ''}
   DarwinNetwork().parse_media_line(words,current_if, None)
   assert current_if['media'] == 'Autoselect'
   assert current_if['media_type'] == ''
   assert current_if['media_select'] == '(none)'
   assert current_if['media_options'] == ''
   words = ["media:", "<unknown", "type>", "status:", "inactive"]
   current_if = {'media': 'Unknown', 'media_type': '', 'media_select': '<unknown', 'media_options': ''}
   DarwinNetwork

# Generated at 2022-06-22 23:39:52.942709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    Test method of class DarwinNetwork.
    '''

    # Test parse_media_line method
    Darwin = DarwinNetwork()
    # Test 1
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = dict()
    Darwin.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

    # Test 2
    words = ['media:', 'autoselect', '(none)', 'full-duplex']
    current_if = {}
    ips = dict()
    Darwin.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:39:55.869351
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert(dnc._fact_class == DarwinNetwork)
    assert(dnc._platform == 'Darwin')


# Generated at 2022-06-22 23:39:59.422729
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.get_default_interfaces() == ['lo0', 'gif0', 'stf0', 'en0', 'p2p0', 'awdl0', 'utun0', 'bridge0']

# Generated at 2022-06-22 23:40:01.000957
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork(False)
    assert network.platform == 'Darwin'


# Generated at 2022-06-22 23:40:09.157316
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    ips = []
    d = DarwinNetwork()
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-22 23:40:13.031873
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork({})
    assert (result is not None)


# Generated at 2022-06-22 23:40:19.586227
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # test empty args
    result = DarwinNetworkCollector({})
    assert (result._platform == 'Darwin')
    assert(isinstance(result._fact_class,DarwinNetwork))
    # test if 1 arg passed
    result = DarwinNetworkCollector({'test': 1})
    assert (result._platform == 'Darwin')
    assert(isinstance(result._fact_class,DarwinNetwork))
    # test if more args passed
    result = DarwinNetworkCollector({'test': 1, 'test2': 2})
    assert (result._platform == 'Darwin')
    assert(isinstance(result._fact_class,DarwinNetwork))

# Generated at 2022-06-22 23:40:26.785353
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Tests are using a dictionary to hold the interface data
    current_if = dict()

    # Test words variable is returned unmodified when media_select
    # is not present
    words = ["asdf", "media:", "autoselect", "status:", "active"]
    DarwinNetwork.parse_media_line(words, current_if, None)
    assert words == ["asdf", "media:", "autoselect", "status:", "active"]
    assert 'media' not in current_if.keys()
    assert 'media_select' not in current_if.keys()
    assert 'media_type' not in current_if.keys()
    assert 'media_options' not in current_if.keys()
    current_if.clear()

    # Test media_select and media_select are parsed correctly when media_type
    #

# Generated at 2022-06-22 23:40:37.582159
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Simple unit test for DarwinNetwork
    """
    dn = DarwinNetwork(None)
    myfacts = dict()
    myif = dict()
    myif['name'] = 'em1'
    myif['macaddress'] = '00:00:00:00:00:00'
    myif['ipv4'] = dict()
    myif['ipv4']['address'] = '192.168.1.1'
    myif['ipv4']['netmask'] = '255.255.255.0'
    myif['ipv4']['broadcast'] = '192.168.1.255'
    myif['ipv6'] = dict()
    myif['ipv6']['address'] = '2001:0:0:0:0:0:0:1'
   

# Generated at 2022-06-22 23:40:38.570320
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print(repr(DarwinNetwork('em0')))

# Generated at 2022-06-22 23:40:47.965519
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = {}
    DarwinNetworkCollector(facts)
    assert facts['ansible_net_gather_network_resources'] == 2
    assert facts['ansible_net_hostname'] == 'localhost'
    assert facts['ansible_net_all_ipv4_addresses'] == ['192.168.0.250', 'fe80::7ebd:f19:bb7']
    assert facts['ansible_net_all_ipv6_addresses'] == ['fe80::7ebd:f19:bb7']
    assert facts['ansible_net_all_ipv6_addresses'] == ['fe80::7ebd:f19:bb7']
    assert facts['ansible_net_all_ipv6_addresses'] == ['fe80::7ebd:f19:bb7']
    #assert facts

# Generated at 2022-06-22 23:40:50.096455
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:41:01.732321
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    test_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    test_if = {}
    test_ips = {}
    dn.parse_media_line(test_words, test_if, test_ips)
    assert test_if == {'media': 'Unknown', 'media_select': 'autoselect'}

    test_words = ['media:', 'none', 'media_type_example', 'media_options_example']
    test_if = {}
    test_ips = {}
    dn.parse_media_line(test_words, test_if, test_ips)

# Generated at 2022-06-22 23:41:14.096494
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Unittest is run in ansible/test/unit/module_utils/facts/network
    # and the platform is detected via the module_utils/facts/__init__.py
    # hence tricking the system for testing
    import ansible.module_utils.facts.network.darwin as darwin

    # Create a new instance of DarwinNetwork
    fact_darwin = darwin.DarwinNetwork()

    # This dictionary will be used to match the current_if dictionary
    # returned from fact_darwin.parse_media_line
    current_if = dict()

    # Returns the same dictionary for empty media line
    current_if = fact_darwin.parse_media_line([], current_if, dict())

    # Test that media and media_select has been set to 'Unknown'
    # media_type and media_options set

# Generated at 2022-06-22 23:41:14.751121
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:18.576833
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.all_ipv4_addresses == []
    assert obj.all_ipv6_addresses == []
    assert obj.interfaces == []
    assert obj.default_interfaces == {}

# Generated at 2022-06-22 23:41:26.543094
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}


# Generated at 2022-06-22 23:41:27.096719
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:41:35.104878
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    ifconfig_path_value = dn.ifconfig_path
    platform_value = dn.platform
    ifconfig_starts_with_value = dn.ifconfig_simple_match_string
    ifconfig_ends_with_value = dn.ifconfig_simple_match_string_end

    assert ifconfig_path_value == '/sbin/ifconfig'
    assert platform_value == 'Darwin'
    assert ifconfig_starts_with_value == ['media:', 'ether']
    assert ifconfig_ends_with_value == ['Logical', 'address', 'inet', 'inet6']


# Generated at 2022-06-22 23:41:36.214092
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    test_obj = DarwinNetwork()
    assert test_obj.platform == 'Darwin'

# Generated at 2022-06-22 23:41:45.968324
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_words = ['media:', 'autoselect', '<unknown type>', '(100baseTX)']
    current_if = dict()

    network_class = DarwinNetwork()
    network_class.parse_media_line(test_words, current_if, None)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == '100baseTX'

# Generated at 2022-06-22 23:41:48.115017
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result._platform == 'Darwin'
    assert isinstance(result._fact_class(None, None), DarwinNetwork)

# Generated at 2022-06-22 23:41:49.445902
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test the DarwinNetwork constructor"""
    network_class = DarwinNetwork()
    assert network_class.platform == 'Darwin'

# Generated at 2022-06-22 23:41:55.269914
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    dn = DarwinNetwork()
    media_line = ['media:', 'autoselect', '(unknown)', 'status:', 'inactive']
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown'
    assert current_if['media_options'] == {}
    current_if = {}
    media_line = ['media:', 'autoselect', '(1000baseT)', 'status:', 'inactive']
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'


# Generated at 2022-06-22 23:42:06.556464
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    netif = NetworkCollector()
    netif.set_platform('Darwin')
    words = ['media:','autoselect','status:','active','type:','10baseT/UTP']
    current_if = {'name': 'en0'}
    words2 = ['media:', '<unknown', 'type>', 'status:', 'active']
    ips = {'192.168.1.1': {'broadcast': '192.168.1.255', 'netmask': '255.255.255.0', 'network': '192.168.1.0'}}

    netif.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-22 23:42:07.187356
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnw = DarwinNetwork()
    assert dnw is not None

# Generated at 2022-06-22 23:42:16.708372
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    parms = {'interfaces': {}, 'defaults': {}}
    tst_ifc_parm = {}
    words = ['media:', 'media_select', 'media_type', 'media_options']

    # method parse_media_line is tested with a number of test cases
    # in class GenericBsdIfconfigNetworkTestCase, as the method is unchanged
    # in class DarwinNetwork
    DarwinNetwork(parms).parse_media_line(words, tst_ifc_parm, set())
    assert tst_ifc_parm == {
        'media': 'Unknown', 'media_select': 'media_select',
        'media_type': 'media_type', 'media_options': 'media_options'
    }

    words = ['media:', 'media_select', 'media_type']
    Darwin

# Generated at 2022-06-22 23:42:18.959022
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None)
    assert obj._fact_class.platform == 'Darwin'

# Generated at 2022-06-22 23:42:20.709236
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetCollect = DarwinNetworkCollector()
    assert DarwinNetCollect is not None


# Generated at 2022-06-22 23:42:23.899354
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = DarwinNetworkCollector()
    assert module.platform == 'Darwin'
    assert module._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:42:25.885345
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a test for the constructor of class DarwinNetworkCollector
    """
    DarwinNetworkCollector(None, None)

# Generated at 2022-06-22 23:42:28.408822
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result.platform == 'Darwin'
    assert result._fact_class.platform == 'Darwin'



# Generated at 2022-06-22 23:42:38.625049
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # parse_media_line should set current_if['media'] and current_if['media_select']
    # current_if['media_type'] and current_if['media_options'] might also be set

    current_if = {}

    DarwinNetwork.parse_media_line(None, ['media', 'autoselect'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    current_if = {}
    DarwinNetwork.parse_media_line(None, ['media', '100baseTX', 'full-duplex'], current_if, None)

    assert current_if['media'] == 'Unknown'
    assert current_if

# Generated at 2022-06-22 23:42:41.044613
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:42:41.643769
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:42:53.023023
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize DarwinNetwork
    net = DarwinNetwork()
    # Set up dictionary with current interface that is being analyzed
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': {}}
    # Test a line from ifconfig output of MacOSX of a vlan interface
    # List of words: ['media:', 'autoselect', 'status:', 'active', 'media:', '1000baseT', 'media:', '1000baseT', '<full-duplex>']

# Generated at 2022-06-22 23:43:03.013894
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.interface_type == 'physical'
    assert d.interface_name == 'en0'
    assert d.mac_address == '33:33:00:00:00:01'
    assert d.inet_address == '192.168.0.1'
    assert d.inet_subnet == '192.168.0.0'
    assert d.inet_netmask == '255.255.255.0'
    assert d.inet_broadcast == '192.168.0.255'
    assert d.inet6_address == 'fe80::1'
    assert d.inet6_prefix == '64'
    assert d.inet6_scope == 'link'
    assert not d.inet6_duplicate_address_detection
    assert d.inet6_link_local_

# Generated at 2022-06-22 23:43:10.445159
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    line = '    media: autoselect (<unknown type>)'
    assert darwin_network.parse_media_line(line.split(), {}, None) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': {}}

# Generated at 2022-06-22 23:43:19.302346
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    test_words = ['media:', 'autoselect', '(none)']
    ifc = {'device': 'en0', 'name': 'en0'}
    dn.parse_media_line(test_words, ifc, None)
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'autoselect'
    assert ifc['media_type'] == '(none)'
    assert ifc['media_options'] == None
    test_words = ['media:', '<unknown', 'type>']
    ifc = {'device': 'bridge0', 'name': 'bridge0'}
    dn.parse_media_line(test_words, ifc, None)
    assert ifc['media'] == 'Unknown'

# Generated at 2022-06-22 23:43:28.557555
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test DarwinNetwork Class constructor"""

    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'
    assert darwin_network.ipv4_interfaces == 'lo0'
    assert isinstance(darwin_network.interfaces, dict)
    assert darwin_network.exclude_interfaces == []
    assert isinstance(darwin_network.all_ipv4_addresses, dict)
    assert darwin_network.get_ipv4_addr_scope == 2
    assert isinstance(darwin_network.interface_speed, dict)

# Generated at 2022-06-22 23:43:29.879758
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({})
    assert dn is not None

# Generated at 2022-06-22 23:43:34.044416
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_nc = DarwinNetworkCollector()
    # Test that _fact_class is set to DarwinNetwork
    assert darwin_nc._fact_class == DarwinNetwork
    # Test that _platform is set to Darwin
    assert darwin_nc._platform == 'Darwin'

# Generated at 2022-06-22 23:43:46.214411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Tests the situation where media_type is a single word
    words = ['media:', 'autoselect', '(1000baseT)']
    current_if = {}
    ips = []
    darwinNetwork = DarwinNetwork()
    darwinNetwork.parse_media_line(words, current_if, ips)
    assert (current_if == {'media': 'Unknown',
                           'media_select': 'autoselect',
                           'media_type': '1000baseT',
                           'media_options': []})
    # Tests the situation where media_type is a multi-word phrase
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    darwinNetwork.parse_media_line(words, current_if, ips)

# Generated at 2022-06-22 23:43:55.032982
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test the method DarwinNetwork.parse_media_line()

    # just call the method to see if it fails.
    test_if = {'inet': '1.1.1.1'}
    test_ips = {}
    test_words = ['media:', '<unknown', 'type>']
    test_result = DarwinNetwork.parse_media_line(DarwinNetwork, test_words, test_if, test_ips)

    # assert if the test result does not match the expected result
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == '<unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == []
    assert test_result is None

# Generated at 2022-06-22 23:44:04.499503
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = "media: autoselect (<unknown type>)"
    words = media_line.split()
    current_if = {}
    ips = []
    network = DarwinNetwork(None)
    network.parse_media_line(words, current_if, ips)
    print("current_if: %s\n" % current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if
    
if __name__ == '__main__':
    test_DarwinNetwork_parse_media_line()

# Generated at 2022-06-22 23:44:12.638914
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = {}
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork().parse_media_line(words, data, None)
    data = {'media_options': 'none',
            'media': 'Unknown',
            'media_select': 'autoselect',
            }
    assert data == data
    data = {}
    words = ['media:', '<unknown', 'type>', '(none)']
    DarwinNetwork().parse_media_line(words, data, None)
    data = {'media_options': 'none',
            'media': 'Unknown',
            'media_select': 'Unknown',
            'media_type': 'unknown type'
            }
    assert data == data

# Generated at 2022-06-22 23:44:24.079490
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test the DarwinNetwork class constructor
    """
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert dn.media_regexp == r'^\s*media:\s+(?P<media_select>.*?)\s+(?P<media_type>.*?)\s?(?P<media_options>.*)$'
    assert dn.media_opts_regexp == r'\b(?P<optname>\S*)=(?P<optvalue>\S*)'
    assert dn.ip_regexp == r"^\s*inet\s+(?P<inet>\S+)\s+.*?(?:broadcast|peer)\s+(?P<broadcast>\S+).*?$"
    assert dn.ip6_regexp

# Generated at 2022-06-22 23:44:26.895149
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._platform == 'Darwin'


# Generated at 2022-06-22 23:44:30.787703
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork({}, [], None)
    assert net is not None
    assert net._config_file == '/sbin/ifconfig'
    assert len(net.facts) == 0


# Generated at 2022-06-22 23:44:40.090207
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type>'
    words = media_line.split(' ', 1)
    current_if = {}
    ips = []
    network = DarwinNetwork()
    network.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'Unknown'
    assert 'media_type' in current_if
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if
    media_line = 'media: autoselect (1000baseT <full-duplex>)'
    words = media_line.split(' ')
    network.parse_media_

# Generated at 2022-06-22 23:44:43.704720
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    # Check if we have a pointer to the right object
    assert darwin.platform == 'Darwin'


# Generated at 2022-06-22 23:44:55.362185
# Unit test for constructor of class DarwinNetworkCollector

# Generated at 2022-06-22 23:44:56.403079
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()



# Generated at 2022-06-22 23:45:06.520561
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line(): # pylint: disable=too-many-branches
    """
    Test the method parse_media_line of class DarwinNetwork.
    """
    darwin_if = DarwinNetwork()
    # Test with a word list of length 0
    words = []
    iface = {}
    ips = {}
    darwin_if.parse_media_line(words, iface, ips)
    assert iface == {'media': 'Unknown', 'media_select': ''}
    # Test with a word list of length 1
    words = ['blah']
    iface = {}
    ips = {}
    darwin_if.parse_media_line(words, iface, ips)
    assert iface == {'media': 'Unknown', 'media_select': words[0]}
    # Test with a word list of length

# Generated at 2022-06-22 23:45:18.686366
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig = {'AMTU': 1500,
                'LLADDR': '00:1d:09:13:6e:1a',
                'MTU': 1500,
                'OPTIONS': 'none',
                'state': 'up',
                'status': 'active'}
    dnet = DarwinNetwork(None, None)

    dnet.parse_media_line(words=['media:', '<unknown', 'type>'], current_if=ifconfig, ips=[])