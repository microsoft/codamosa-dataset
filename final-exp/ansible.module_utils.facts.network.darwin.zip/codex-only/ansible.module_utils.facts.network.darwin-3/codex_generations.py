

# Generated at 2022-06-22 23:35:27.044109
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test1 = DarwinNetwork({})
    test_data = []
    test_if = {'media': 'Unknown' , 'media_select': '', 'media_type' : '', 'media_options': ''}
    test_result = {'media': 'Unknown' , 'media_select': 'autoselect', 'media_type' : '', 'media_options': ''}
    test_data.append([['media:', 'autoselect'], test_if, test_result])
    test_result = {'media': 'Unknown' , 'media_select': 'autoselect', 'media_type' : '100baseTX', 'media_options': 'full-duplex'}

# Generated at 2022-06-22 23:35:28.024358
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # FIXME: write this
    pass

# Generated at 2022-06-22 23:35:30.946299
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_data = '''
    output from ifconfig on MacOS
    '''
    result = DarwinNetwork(test_data)
    assert result.platform == 'Darwin'
    assert result.ifconfig_path == '/sbin/ifconfig'


# Generated at 2022-06-22 23:35:31.731608
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    foo = DarwinNetworkCollector()


# Generated at 2022-06-22 23:35:34.970269
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
        darwincollector = DarwinNetworkCollector()
        assert darwincollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:35:40.583284
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'autoselect status: inactive'
    current_if = {}
    ips  = []
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(media_line.split(' '), current_if, ips)
    assert {'media_select': 'autoselect'} == current_if

# Generated at 2022-06-22 23:35:49.021750
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    words = ['media:', 'autoselect', '(100baseTX', 'full-duplex)']
    current_if = {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': ''}
    # Action
    DarwinNetwork(None).parse_media_line(words, current_if, True)
    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == 'full-duplex'

# Generated at 2022-06-22 23:35:51.501910
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_darwin_network = DarwinNetwork()
    assert isinstance(my_darwin_network, DarwinNetwork)


# Generated at 2022-06-22 23:35:53.397341
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():  # pylint: disable=no-self-use
    assert DarwinNetwork({})


# Generated at 2022-06-22 23:35:55.424497
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_test = DarwinNetwork({})
    assert darwin_network_test is not None


# Generated at 2022-06-22 23:35:57.534198
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(None)
    dn = DarwinNetwork()


# Generated at 2022-06-22 23:36:01.367179
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Runs the tests for DarwinNetworkCollector class
    """
    nc = DarwinNetworkCollector()
    assert nc._fact_class == DarwinNetwork
    assert nc._platform == 'Darwin'

# Generated at 2022-06-22 23:36:04.612397
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create DarwinNetwork object
    darwin_network = DarwinNetwork()
    # Check if media_line is None
    assert darwin_network.media_line == None

# Generated at 2022-06-22 23:36:08.960510
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}
    ips = {}
    words = []
    # test case 1: media line normal
    words = ['media:', 'autoselect', '(none)']
    network.parse_media_line(words, current_if, ips)
    assert 'media' not in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # test case 2: media line normal
    words = ['media:', 'autoselect', '(1000baseSX)']
    network.parse_media_line(words, current_if, ips)
    assert 'media' not in current_if

# Generated at 2022-06-22 23:36:14.028751
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Testing creating an instance of DarwinNetwork
    # on macOS Mojave:
    # Darwin omgwtf-MacBook-Pro-2.local 18.7.0 Darwin Kernel Version 18.7.0: Mon Mar 11 20:30:22 PDT 2019; root:xnu-4903.271.2~2/RELEASE_X86_64 x86_64
    assert DarwinNetwork(None, "", "", "").platform == "Darwin"


# Generated at 2022-06-22 23:36:22.685901
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this test checks that
    # that interface is handled correctly
    test_if = {}
    test_words = ['media:', '<unknown', 'type>', '(none)']
    DarwinNetwork.parse_media_line(DarwinNetwork, test_words, test_if)
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert 'media_options' not in test_if
    assert 'media' in test_if

# Generated at 2022-06-22 23:36:24.283210
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    x = DarwinNetwork()
    assert isinstance(x, DarwinNetwork)


# Generated at 2022-06-22 23:36:28.083024
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # create DarwinNetwork object
    network_class = DarwinNetwork()

    # if not an object of class DarwinNetwork
    if not isinstance(network_class, DarwinNetwork):
        raise AssertionError()

    # if is not an object of NetworkCollector
    if not isinstance(network_class, NetworkCollector):
        raise AssertionError()

# Generated at 2022-06-22 23:36:31.910298
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_net_col = DarwinNetworkCollector()
    assert darwin_net_col.__class__.__name__ == 'DarwinNetworkCollector'
    assert darwin_net_col.platform == 'Darwin'
    assert darwin_net_col._fact_class.__name__ == 'DarwinNetwork'
    assert isinstance(darwin_net_col._fact_class, type)

# Generated at 2022-06-22 23:36:42.848128
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    b = DarwinNetwork(dict())
    current_if = dict()
    ips = dict()
    b.parse_media_line(['media:', '<unknown', 'type>'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # test if there are no parameters
    b.parse_media_line(['media:', '<unknown', 'type>', 'options'],
                       current_if, ips)
    assert current_if['media_options'] == 'options'

    # test if there are many parameters

# Generated at 2022-06-22 23:36:43.382725
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:36:50.357195
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    words = ["media:", "<unknown", "type>"]
    current_if = {}
    ips = {}
    darwin_if.parse_media_line(words, current_if, ips)
    assert (current_if['media_select'] == 'Unknown')
    assert (current_if['media_type'] == 'unknown type')

# Generated at 2022-06-22 23:36:52.212591
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-22 23:36:53.792397
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.get_device_info()

# Generated at 2022-06-22 23:36:54.323805
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    o = DarwinNetwork()

# Generated at 2022-06-22 23:37:05.383796
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinNetwork = DarwinNetwork()
    test_default_dict = {}
    test_default_line = "  media: autoselect (none)"
    test_default_words = test_default_line.split()
    test_default_dict = darwinNetwork.parse_media_line(test_default_words, test_default_dict, [])
    assert test_default_dict['media'] == 'Unknown' and test_default_dict['media_select'] == 'autoselect' and \
           test_default_dict['media_type'] == 'none'

    test_one_dict = {}
    test_one_line = "  media: <unknown type> (none)"
    test_one_words = test_one_line.split()

# Generated at 2022-06-22 23:37:05.967144
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork

# Generated at 2022-06-22 23:37:08.841464
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == "Darwin"
    assert obj.fact_class is not None
    assert issubclass(obj.fact_class, DarwinNetwork)

# Generated at 2022-06-22 23:37:11.602054
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for constructor of class DarwinNetwork"""
    darwin_network = DarwinNetwork(None)
    assert darwin_network is not None

# Generated at 2022-06-22 23:37:22.625888
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    uname = 'Darwin'
    platform = 'Darwin'
    version = '15.4.0'
    network = DarwinNetwork(uname, platform, version)
    assert network.uname == uname
    assert network.platform == platform
    assert network.version == version
    assert network.sys_path == '/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources'
    assert network.get_ifconfig_path() == 'ifconfig'
    assert network.get_route_path() == 'route'
    assert network.get_ip_path() == 'ip'
    assert network.get_hwconf_path() == 'arp'
    assert network.get_ss_path() == 'ss'
    assert network.get_netstat_path() == 'netstat'
    assert network.get_iw

# Generated at 2022-06-22 23:37:26.219704
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.collector import BaseFactCollector

    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)
    assert isinstance(obj, BaseFactCollector)



# Generated at 2022-06-22 23:37:27.261525
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    fact_class = DarwinNetwork({})



# Generated at 2022-06-22 23:37:29.733304
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), NetworkCollector)

# Generated at 2022-06-22 23:37:31.338843
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mynet = DarwinNetwork()
    assert mynet.platform == 'Darwin'

# Generated at 2022-06-22 23:37:34.343953
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinnet = DarwinNetwork({})
    assert darwinnet.platform == 'Darwin'
    assert darwinnet.ifconfig_path == '/sbin/ifconfig'

# Generated at 2022-06-22 23:37:35.362977
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:37:37.214819
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), NetworkCollector)


# Generated at 2022-06-22 23:37:40.306601
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_clct = DarwinNetworkCollector()
    assert isinstance(net_clct,NetworkCollector)
    assert net_clct.platform == 'Darwin'
    assert net_clct._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:37:51.148877
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    test_dict = {
        'media': '',
        'media_select': '',
        'media_type': '',
        'media_options': '',
    }
    out_dict = {
        'media': 'Unknown'
    }
    test_words = ['media:','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','']
    dn.parse_media_line(test_words, test_dict, [])
    assert test_dict == out_dict


# Generated at 2022-06-22 23:38:01.988247
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import default_collectors

    # Test for parse_media_line method
    facts = Facts({'GATHER_SUBSET': 'all'}, default_collectors)
    fact_class = DarwinNetwork()

    media_line1 = ['media:', '<unknown type>']
    media_line2 = ['media:', 'autoselect', '10baseT/UTP']
    media_line3 = ['media:', 'autoselect', '(none)']
    media_line4 = ['media:', 'autoselect', 'status:', 'active']

    result1 = fact_class.parse_media_line(media_line1, {}, {})

# Generated at 2022-06-22 23:38:05.847877
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:38:11.674721
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of a dictionary to store the result of the parse_media_line method
    current_if = dict()
    # create an instance of DarwinNetwork class
    dif = DarwinNetwork()
    # set the media in current_if to a known value
    current_if['media'] = 'Unknown'
    # create a list of words for the parse_media_line method
    words = ['<unknown type>', 'status:', 'active']
    # call the parse_media_line method of DarwinNetwork
    dif.parse_media_line(words, current_if, 0)
    # check the value of media in current_if
    assert current_if['media'] == 'Unknown'
    # check the value of media_select in current_if
    assert current_if['media_select'] == '<unknown type>'
    # check

# Generated at 2022-06-22 23:38:15.709366
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert facts.__class__.__name__ == 'DarwinNetworkCollector', \
        "Failed to create DarwinNetworkCollector instance"
    assert type(facts.get_all()) is dict, "Failed to return a dictionary"

# Generated at 2022-06-22 23:38:18.313400
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Test construction of DarwinNetwork class
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-22 23:38:30.345680
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    facter = DarwinNetwork()
    facter.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    assert facter.current_if['media'] == 'Unknown'
    assert facter.current_if['media_select'] == 'autoselect'
    assert facter.current_if['media_type'] == '(none)'
    assert facter.current_if['media_options'] == {}
    facter.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert facter.current_if['media'] == 'Unknown'
    assert facter.current_if['media_select'] == 'Unknown'
    assert facter.current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:38:31.388277
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:33.621372
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 23:38:41.256055
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.parse_media_line(["media:", "autoselect"], dn.interfaces['en0'], dn.interfaces['en0']['ipv4'])
    assert dn.interfaces['en0']['media'] == 'Unknown'
    assert dn.interfaces['en0']['media_select'] == 'autoselect'
    assert 'media_type' not in dn.interfaces['en0']
    assert 'media_options' not in dn.interfaces['en0']
    dn.parse_media_line(["media:", "autoselect", "(100baseTX)"], dn.interfaces['en0'], dn.interfaces['en0']['ipv4'])

# Generated at 2022-06-22 23:38:44.166363
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result._fact_class == DarwinNetwork
    assert result._platform == 'Darwin'

# Generated at 2022-06-22 23:38:45.540151
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # initialize test class
    DarwinNetwork(None)
    return

# Generated at 2022-06-22 23:38:47.217268
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork

# Generated at 2022-06-22 23:38:50.588684
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'
    assert net.get_options('media') == {}
    assert net.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {}

# Generated at 2022-06-22 23:38:52.010488
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Raw test of DarwinNetworkCollector class"""
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:38:58.414827
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network=DarwinNetwork()
    assert darwin_network
    # test init with no data
    darwin_network=DarwinNetwork(data=None)
    assert darwin_network
    # test init with empty data
    darwin_network=DarwinNetwork(data={})
    assert darwin_network


# Generated at 2022-06-22 23:39:00.997800
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = AnsibleModuleStub()
    dnc = DarwinNetworkCollector(module)
    assert dnc.module == module


# Test class DarwinNetwork

# Generated at 2022-06-22 23:39:02.969866
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert dn.platform == 'Darwin'



# Generated at 2022-06-22 23:39:05.336838
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
        instance = DarwinNetworkCollector()
        assert instance._fact_class.platform == 'Darwin'
        assert instance._platform == 'Darwin'


# Generated at 2022-06-22 23:39:07.480227
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork


# Generated at 2022-06-22 23:39:11.855833
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type>'
    network = DarwinNetwork()
    words = network.parse_ifconfig_line(line)
    current_if = {}
    ips = {}
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-22 23:39:18.036637
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: autoselect (<unknown type>)'
    iface = {}
    ipaddrs = []
    # create the ifconfig object and test it
    ifconfig = DarwinNetwork()
    ifconfig._collect_from_media = True
    ifconfig.parse_media_line(line.split(), iface, ipaddrs)
    assert ifconfig._collect_from_media is False
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'unknown type'
    assert iface['media_options'] == ''

# Generated at 2022-06-22 23:39:22.836956
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    # For Darwin platform
    assert network_collector.platform == 'Darwin'
    # For DarwinNetwork class
    assert network_collector.fact_class == DarwinNetwork
    # For DarwinNetworkCollector object
    assert isinstance(network_collector.fact_class, object)

# Generated at 2022-06-22 23:39:32.232353
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork()
    line = ["media:", "autoselect", "(10baseT/UTP)", "status:"]
    test_obj.parse_media_line(line, {}, {})
    assert test_obj._interfaces[test_obj._current_if]['media'] == 'Unknown'
    assert test_obj._interfaces[test_obj._current_if]['media_select'] == 'autoselect'
    assert test_obj._interfaces[test_obj._current_if]['media_type'] == '10baseT/UTP'
    assert test_obj._interfaces[test_obj._current_if]['media_options'] is None

    line = ["media:", "autoselect", "(10baseT/UTP,<unknown type>)", "status:"]
    test_obj.parse

# Generated at 2022-06-22 23:39:35.029195
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector(None)._platform == 'Darwin'
    assert DarwinNetworkCollector(None)._fact_class is DarwinNetwork


# Generated at 2022-06-22 23:39:37.645991
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = NetworkCollector()
    darwin_module = DarwinNetworkCollector()
    assert(module is not None)
    assert(darwin_module is not None)

# Generated at 2022-06-22 23:39:38.919849
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    detectClass = DarwinNetworkCollector()
    assert detectClass._platform == 'Darwin'

# Generated at 2022-06-22 23:39:40.810906
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:39:42.681789
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == DarwinNetwork._platform
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector().get_device_information() is not None

# Generated at 2022-06-22 23:39:44.230726
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    DarwinNetwork tests
    """
    DarwinNetwork()



# Generated at 2022-06-22 23:39:55.959833
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:39:57.822515
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:40:06.049785
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    # media_select not set
    test = ['media:','Ethernet','<unknown','type>','autoselect','full-duplex']
    network.parse_media_line(test, network.current_if, network.interfaces)
    assert network.current_if['media'] == 'Unknown'
    assert network.current_if['media_select'] == 'Ethernet'
    assert network.current_if['media_type'] == 'unknown type'
    assert network.current_if['media_options'] == 'autoselect, full-duplex'

# Generated at 2022-06-22 23:40:06.659864
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-22 23:40:09.983633
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == 'Darwin'
    assert isinstance(network_collector._fact_class(network_collector), DarwinNetwork)

# Generated at 2022-06-22 23:40:20.403277
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(context_wrap(DARWIN_NETWORK_DATA))


# Generated at 2022-06-22 23:40:31.718143
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # initialisation for the test
    darwin_net = DarwinNetwork()
    current_if = {'name': 'en0'}
    ips = ['192.168.254.254']
    # expected result
    expected_media_select = 'autoselect'
    expected_media_type = '10baseT/UTP'
    # test with the different input
    words = ['media:', 'autoselect', '(10baseT/UTP)', '']
    darwin_net.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == expected_media_select
    assert current_if['media_type'] == expected_media_type
    # test with the different input

# Generated at 2022-06-22 23:40:34.244850
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:40:41.756150
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize the class DarwinNetwork
    dn = DarwinNetwork()
    # Create a test data
    test_data = ['foo', '<unknown', 'type>']
    # Call the parse_media_line method with the test data
    dn.parse_media_line(test_data, {}, {})
    # Check the result for the expected value
    assert(dn.current_if['media'] == 'Unknown')
    assert(dn.current_if['media_select'] == 'Unknown')
    assert(dn.current_if['media_type'] == 'unknown type')

# Generated at 2022-06-22 23:40:42.336459
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:40:50.171737
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {
        'name': 'lo0',
        'type': 'Ethernet',
        'mtu': 16384,
        'macaddress': '00:00:00:00:00:00',
        'flags': ['UP', 'LOOPBACK', 'RUNNING'],
        'inet': ['127.0.0.1', '255.0.0.0']
    }

    test_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']


# Generated at 2022-06-22 23:40:52.557580
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    test_instance = DarwinNetworkCollector()
    assert isinstance(test_instance, NetworkCollector)

# Generated at 2022-06-22 23:40:53.625376
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test creation of DarwinNetwork object """
    DarwinNetwork()

# Generated at 2022-06-22 23:41:05.407811
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    media_line = 'media: autoselect status: active'
    dn.parse_media_line(dn.tokenize(media_line), {}, [])
    assert dn.ifconfig_interfaces['media'] == 'Unknown'
    assert dn.ifconfig_interfaces['media_select'] == 'autoselect'
    assert dn.ifconfig_interfaces['media_type'] == 'active'
    assert dn.ifconfig_interfaces['media_options'] == {}
    media_line = 'media: <unknown type> status: active'
    dn.parse_media_line(dn.tokenize(media_line), {}, [])
    assert dn.ifconfig_interfaces['media'] == 'Unknown'

# Generated at 2022-06-22 23:41:09.624488
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    print("Testing DarwinNetworkCollector")
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork
    assert dnc._platform == 'Darwin'
    print("DarwinNetworkCollector construction OK")


# Generated at 2022-06-22 23:41:11.211267
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:41:13.017858
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork(None, None)
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:41:13.997599
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-22 23:41:20.516137
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()

    #  print(dwn.parse_media_line(words, current_if, ips))
    assert dwn.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    assert dwn.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': '(none)'}

# Generated at 2022-06-22 23:41:31.856049
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'media': 'Unknown', 'media_select': 'none', 'media_type': 'none', 'media_options': []}
    # Test a line that is split on whitespace
    test_words = ['media:', 'none', '(none)']
    DarwinNetwork().parse_media_line(test_words, test_if, None)
    assert test_if == {'media': 'Unknown', 'media_select': 'none', 'media_type': 'none', 'media_options': []}
    # Test a line that is split on whitespace, now with a media type
    test_words = ['media:', 'autoselect', '(none)']
    DarwinNetwork().parse_media_line(test_words, test_if, None)

# Generated at 2022-06-22 23:41:32.463459
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-22 23:41:38.131731
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    args = {'config': {'default_ipv4': {'address': '192.168.1.1', 'broadcast': '192.168.1.255', 'netmask': '192.168.1.0', 'network': '192.168.1.0'}}}
    result = DarwinNetwork(args)
    assert isinstance(result, dict)

# Generated at 2022-06-22 23:41:45.218424
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    expected = [
        'Address', 'Broadcast', 'Cell', 'Ether',
        'IEEE 802.11', 'IP', 'Link', 'Media',
        'Mtu', 'Prefixlen', 'RX packets', 'RX bytes', 'Status', 'Type',
        'Tx-Power', 'TX packets', 'TX bytes', 'UP', 'encapsulation']
    assert sorted(DarwinNetwork.fact_sub_structures) == expected

# Generated at 2022-06-22 23:41:55.483893
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork = __import__('ansible.module_utils.facts.network.darwin').module_utils.facts.network.darwin.DarwinNetwork
    d = DarwinNetwork()
    assert d.parse_media_line(["present", "enabled"], {}, []) == {
        'media': 'Unknown',
        'media_select': 'enabled'}
    assert d.parse_media_line(["present", "autoselect", "(none)"], {}, []) == {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '(none)'}

# Generated at 2022-06-22 23:41:56.936106
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    o = DarwinNetwork({})
    assert o.platform == 'Darwin'

# Generated at 2022-06-22 23:41:59.512973
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    # Assert network_api is 'ifconfig'
    assert dn.network_api == 'ifconfig'

# Generated at 2022-06-22 23:42:06.378941
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    expected = {'media_select': '<unknown type>',
                'media': 'Unknown',
                'media_type': 'unknown type'}
    line = ['media:', '<unknown', 'type>']
    darwin_network = DarwinNetwork()
    current_if = {'name': 'if6'}
    ips = {}
    darwin_network.parse_media_line(line, current_if, ips)
    assert expected == current_if

# Generated at 2022-06-22 23:42:07.846411
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None)

# Generated at 2022-06-22 23:42:10.196502
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    darwin_network = DarwinNetworkCollector
    assert darwin_network

# Generated at 2022-06-22 23:42:13.394798
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector.platform == 'Darwin'
    assert network_collector.fact_class == DarwinNetwork
    assert network_collector.get_facts() is not None

# Generated at 2022-06-22 23:42:15.803079
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._platform == 'Darwin'
    assert darwin_network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-22 23:42:27.426249
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    # Test 1: media_type and media_options are undefined
    current_if = {} # Must be empty dictionary
    words = ['media:', 'autoselect', '100baseTX', 'full-duplex']
    dwn.parse_media_line(words, current_if, [])
    assert current_if.get('media', None) == 'Unknown'
    assert current_if.get('media_select', None) == 'autoselect'
    assert current_if.get('media_type', None) == '100baseTX'
    assert current_if.get('media_options', None) == 'full-duplex'
    # Test 2: '<unknown type>' is defined as media type
    current_if = {} # Must be empty dictionary

# Generated at 2022-06-22 23:42:31.650270
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_class = DarwinNetwork()
    assert network_class.platform == 'Darwin'
    assert network_class.media_regex == network_class.media_regex


# Generated at 2022-06-22 23:42:32.850463
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_obj = DarwinNetwork()
    assert test_obj.platform == 'Darwin'

# Generated at 2022-06-22 23:42:33.946373
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert dn != None

# Generated at 2022-06-22 23:42:38.214723
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test constructor of class DarwinNetwork
    """
    # pylint: disable=unused-variable
    darwin_net = DarwinNetwork(load_on_init=False)

# Generated at 2022-06-22 23:42:42.123014
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    ifconfig_path = '/sbin/ifconfig'
    network_collector = DarwinNetworkCollector(ifconfig_path)
    assert isinstance(network_collector._fact_class(network_collector._ifconfig_path), DarwinNetwork)

# Generated at 2022-06-22 23:42:45.620803
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert isinstance(obj._fact_class, type(DarwinNetwork))
    assert isinstance(obj._fact_class(), DarwinNetwork)

# Generated at 2022-06-22 23:42:49.740058
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # we have to monkeypatch because it is not a regular Linux machine
    import ansible.module_utils.facts.network.darwin as module
    module.platform = 'Darwin'
    n = module.DarwinNetwork()
    assert n is not None

# Generated at 2022-06-22 23:43:00.983687
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()

    words = ['media:', 'autoselect', 'status:', 'active']
    current_if = {'media': 'Unknown'}
    darwin_net.parse_media_line(words, current_if, ips=[])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert not 'media_type' in current_if
    assert not 'media_options' in current_if

    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>,']
    current_if = {'media': 'Unknown'}
    darwin_net.parse_media_line(words, current_if, ips=[])

# Generated at 2022-06-22 23:43:13.157638
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()

    # Check attributes were set properly
    assert set(darwin.interfaces.keys()) == {'lo0', 'gif0', 'stf0', 'en0', 'en1', 'en2', 'en3', 'en4', 'p2p0', 'awdl0', 'bridge0'}
    assert set(darwin.all_ipv4_addresses) == {'fe80::1', '10.0.1.8', '169.254.255.255', '192.168.12.33'}
    assert set(darwin.all_ipv6_addresses) == {'fe80::1', 'fe80::2ded:2ff:fea6:b84'}

# Generated at 2022-06-22 23:43:24.935163
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test DarwinNetwork constructor and common generic methods."""
    dar_net = DarwinNetwork()

    assert dar_net.platform == 'Darwin'

    # Check ifconfig_path
    assert dar_net.ifconfig_path == '/sbin/ifconfig'

    # Check link_capabilities
    assert dar_net.link_capabilities == ['rx', 'tx', 'autoneg', 'tp', 'tp-fd',
                                         'tp-hd', 'aui', 'bnc', 'tpe', 'mii',
                                         'fibre', 'fibre-hd', 'sfp']

    # Check ifconfig_path
    assert dar_net.ifconfig_path == '/sbin/ifconfig'

    # Check link_capabilities

# Generated at 2022-06-22 23:43:26.988378
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-22 23:43:32.390198
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    dnet.parse_media_line(['media', '<unknown type>'], {}, None)
    assert dnet._current_if['media'] == 'Unknown'
    assert dnet._current_if['media_select'] == 'Unknown'
    assert dnet._current_if['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:43:34.475829
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork({'ansible_lo0': {'ipv4': [], 'active': True, 'device': 'lo0', 'has_carrier': False,
                                        'description': 'lo0', 'ipv6': [], 'type': 'Loopback', 'macaddress': ''}})
    assert d


# Generated at 2022-06-22 23:43:36.840759
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == "Darwin"


# Generated at 2022-06-22 23:43:48.790228
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    words1 = ['media:', '<unknown', 'type>', '(none)']
    current_if1 = {}
    ips1 = {}
    obj.parse_media_line(words1, current_if1, ips1)
    assert current_if1['media'] == 'Unknown'
    assert current_if1['media_select'] == 'Unknown'
    assert current_if1['media_type'] == 'unknown type'
    assert current_if1['media_options'] == {}
    words2 = ['media:', 'auto', '10baseT/UTP', '(none)']
    current_if2 = {}
    ips2 = {}
    obj.parse_media_line(words2, current_if2, ips2)

# Generated at 2022-06-22 23:43:49.467934
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:43:50.721837
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)

# Generated at 2022-06-22 23:43:52.299830
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network._platform == 'Darwin'


# Generated at 2022-06-22 23:44:00.216116
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    # mac does not give the line in a standard form - the ifconfig
    # parsing is done in get_network_interfaces of class DarwinNetwork
    ci = {}
    ips = {}
    dwn.parse_media_line(['10baseT/UTP', '<unknown type>'], ci, ips)
    assert ci['media'] == 'Unknown'
    assert ci['media_select'] == '10baseT/UTP'
    assert ci['media_type'] == 'unknown type'

# Generated at 2022-06-22 23:44:01.533574
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn is not None

# Generated at 2022-06-22 23:44:02.125090
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-22 23:44:09.197674
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    # Testcase 1: words = ['media:', 'IEEE', '802.3', 'CSMA/CD']
    words = ['media:', 'IEEE', '802.3', 'CSMA/CD']
    current_if = {}
    ips = None
    exp_result = {'media_select': 'IEEE', 'media_type': '802.3', 'media_options': 'CSMA/CD', 'media': 'Unknown'}
    d = DarwinNetwork()
    d.parse_media_line(words, current_if, ips)
    assert exp_result == current_if, "Failed test case 1"

# Generated at 2022-06-22 23:44:10.975200
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class == DarwinNetwork
    assert collector._platform == 'Darwin'

# Generated at 2022-06-22 23:44:22.626987
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict(media=None, media_select=None, media_type=None, media_options=None)

    # media_line_one has a media_type with a type in parenthesis
    media_line_one = ['status:', 'active', '(autoselect)', 'full-duplex']
    DarwinNetwork.parse_media_line(media_line_one, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'active'
    assert current_if['media_type'] == '(autoselect)'
    assert current_if['media_options'] == 'full-duplex'

    # media_line_two has a media_type with an unknown type

# Generated at 2022-06-22 23:44:34.264800
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    # test platform
    assert darwin_net.platform == 'Darwin'

    # test media line parsing

# Generated at 2022-06-22 23:44:41.715222
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {}
    mac_sample_output = ('media: <unknown type>\n'
                         '    supported media: none none\n'
                         '    supported media: 10baseT/UTP <full-duplex>\n'
                         '    media: <half-duplex>\n'
                         '    supported media: 10baseT/UTP 10baseT/UTP')
    mn = DarwinNetwork()
    mn.parse_media_line(['media:', '<unknown type>'], iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == '<unknown type>'
    assert iface['media_type'] == 'unknown type'
    assert not iface.get('media_options')

# Generated at 2022-06-22 23:44:46.267183
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test default constructor
    obj = DarwinNetwork()
    assert obj.facts['default_interfaces'] == ['lo0']
    assert obj.facts['all_ipv4_addresses'] == []
    assert obj.facts['all_ipv6_addresses'] == []


# Generated at 2022-06-22 23:44:50.184087
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This unit test insures that DarwinNetworkCollector is constructed properly
    """
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork
    assert dnc._platform == 'Darwin'
    assert dnc._requirements

# Generated at 2022-06-22 23:45:01.762867
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-22 23:45:13.646660
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = []

    # Here we test a valid media line
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # Testing media lines with 'Unknown' and different type
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-22 23:45:24.620326
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    netif = DarwinNetwork()
    netif.add_ifconfig_intf('lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384\
    inet6 ::1 prefixlen 128\
    inet 127.0.0.1 netmask 0xff000000')
    netif.add_ifconfig_line('inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1')
    netif.add_ifconfig_line('nd6 options=1<PERFORMNUD>')
    netif.add_ifconfig_line('groups: lo')
    netif.add_ifconfig_intf('gif0', 'flags=8010<POINTOPOINT,MULTICAST> metric 0 mtu 1280')
    netif.add_ifconfig_line