

# Generated at 2022-06-20 17:49:00.602893
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # test 1
    media = ['media:', 'autoselect', '<unknown type>', 'status:', 'inactive']
    dn.parse_media_line(media, {}, {})
    assert media == ['media:', 'autoselect', '<unknown type>', 'status:', 'inactive']
    assert dn._current_if.get('media') == 'Unknown'
    assert dn._current_if.get('media_select') == 'autoselect'
    assert dn._current_if.get('media_type') == 'unknown type'
    assert dn._current_if.get('media_options') is None

# Generated at 2022-06-20 17:49:05.981715
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    a = DarwinNetwork()
    assert a.facts == dict()
    assert a._platform == 'Darwin'
    assert a._fact_class == DarwinNetwork
    assert a._fact_subclass == GenericBsdIfconfigNetwork
    assert a.parse_media_line('a b c d e'.split(), dict(), dict()) == None

# Generated at 2022-06-20 17:49:12.321219
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork(None, None)
    # media line is different to the default FreeBSD one
    # media default <unknown type>
    words = ['media', 'default', '<unknown', 'type>']
    current_if = {}
    ips = []
    net.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'default'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {'type': 'unknown type'}

# Generated at 2022-06-20 17:49:20.470321
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'media': 'Unknown',
        'media_select': 'None',
        'media_type': 'None',
        'media_options': 'None'
    }
    words = ['media:', 'autoselect', '<unknown type>']
    result = DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if)
    expected_result = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'unknown type',
        'media_options': 'None'
    }
    assert result == expected_result

# Generated at 2022-06-20 17:49:27.046285
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    network = DarwinNetwork()
    attr = NetworkCollector.__getattribute__
    words = ['media', 'autoselect', 'status:', 'active']
    current_if = dict()

    # Act
    network.parse_media_line(words, current_if, dict())

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status:'
    assert current_if['media_options'] == 'active'

# Generated at 2022-06-20 17:49:28.096233
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:29.265903
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__doc__ != "Implementation for Darwin"

# Generated at 2022-06-20 17:49:30.508749
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test class DarwinNetwork for instantiation with no parameters
    """
    dn = DarwinNetwork()
    assert dn

# Generated at 2022-06-20 17:49:40.729894
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of the DarwinNetwork class
    net_tool = DarwinNetwork()
    # create a sample interface
    iface = {'active': 'True', 'device': 'bridge0', 'inet': [], 'inet6': [], 'macaddress': '', 'mtu': 1500, 'netmask': '', 'options': {}, 'rxpackets': 0, 'rxbytes': 0, 'txpackets': 0, 'txbytes': 0, 'type': 'bridge', 'up': 'True'}
    # initialize the media line
    media_line = ''
    # validate the results of the method parse_media_line
    assert net_tool.parse_media_line(media_line, iface, []) == None
    # create an expected result

# Generated at 2022-06-20 17:49:42.066964
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:49:54.561367
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}
    words = ['media:', 'auto', '10baseT/UTP', '<full-duplex>']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type']

# Generated at 2022-06-20 17:49:55.939535
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork(list())
    assert n.platform == 'Darwin'

# Generated at 2022-06-20 17:49:59.002758
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Check if constructor correctly initialises values
    network_collector = DarwinNetworkCollector(None)

    assert network_collector._platform == "Darwin"
    assert network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:08.408236
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Default test
    line = ['<unknown type>', 'auto', '1000baseT', '-full']
    ifinfo = {}
    ifinfo['media'] = 'Unknown'
    ifinfo['media_select'] = 'auto'
    ifinfo['media_type'] = '1000baseT'
    ifinfo['media_options'] = {'full': ''}
    DarwinNetwork().parse_media_line(line, ifinfo)
    assert ifinfo == {'media': 'Unknown', 'media_select': 'auto', 'media_type': '1000baseT', 'media_options': {'full': ''}}

    # Test with bridge
    line = ['<unknown', 'type>', 'auto', '1000baseT', '-full']
    ifinfo = {}
    DarwinNetwork().parse_media_line(line, ifinfo)
   

# Generated at 2022-06-20 17:50:19.712151
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # If used as a constructor, DarwinNetwork requires an argument
    # since no default argument is specified
    try:
        DarwinNetwork()
        # Should not reach here since the above code should have raised an
        # exception with an argument
        assert(False)
    except TypeError:
        # Expected Exception. So pass
        pass
    except:
        # Unexpected exception
        assert(False)
        # If the constructor fails, we can not run the tests. But we
        # can run our tests against a class variable. So we will use
        # the variable DarwinNetwork._fact_class to test
        DarwinNetwork._fact_class = DarwinNetwork
    # This is the list of keys that should be present in the fact
    # dict returned by DarwinNetwork._fact_class.

# Generated at 2022-06-20 17:50:20.740160
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetwork({}), DarwinNetwork)

# Generated at 2022-06-20 17:50:22.027161
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin=DarwinNetworkCollector()
    assert darwin is not None

# Generated at 2022-06-20 17:50:26.552696
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a unit test that checks to see if a DarwinNetworkCollector class can be instantiated and, if so,
    attempts to collect facts.
    """
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == 'Darwin'
    facts = network_collector.collect()
    assert 'interfaces' in facts
    assert 'default_ipv4' in facts

# Generated at 2022-06-20 17:50:30.725596
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_obj = DarwinNetwork()
    # Testing Media line
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    expected_output = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    output = darwin_network_obj.parse_media_line(words, 'current_interface', 'ips_dict')
    assert output == expected_output

# Generated at 2022-06-20 17:50:34.493218
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj1 = DarwinNetworkCollector()
    obj2 = DarwinNetworkCollector(gather_subset="!all", gather_network_resources="lo")


# Generated at 2022-06-20 17:50:45.769641
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a fake network interface
    current_if = {}
    # Create a fake IPs holder object
    ips = {}
    # Create a DarwinNetwork object
    network_obj = DarwinNetwork(None)
    # media line is different to the default FreeBSD one
    words = ['media:', 'autoselect', 'status:', 'inactive']

    current_if = network_obj.parse_media_line(words, current_if, ips)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == 'autoselect')
    assert(current_if['media_type'] == 'inactive')

# Generated at 2022-06-20 17:50:48.077554
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    p = DarwinNetworkCollector()
    assert p
    assert p._platform == 'Darwin'
    assert p._fact_class == DarwinNetwork
    assert p.facts == {}

# Generated at 2022-06-20 17:50:49.306452
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    inst = DarwinNetworkCollector(None, {}, [], False)
    assert inst

# Generated at 2022-06-20 17:50:54.647296
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Test DarwinNetwork constructor
    """
    darwin_network = DarwinNetwork({}, None)
    assert hasattr(darwin_network, 'facts')
    assert hasattr(darwin_network, 'logger')
    try:
        import netifaces
    except ImportError:
        assert hasattr(darwin_network, 'netifaces')



# Generated at 2022-06-20 17:50:57.001499
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:50:58.822686
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Validate the DarwinNetworkCollector Instantiation """
    assert DarwinNetworkCollector

# Generated at 2022-06-20 17:51:00.609016
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert dn._platform == 'Darwin'

# Generated at 2022-06-20 17:51:10.797323
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    darwin_network = DarwinNetwork({})
    darwin_network.parse_media_line(["media:", "autoselect", "<unknown", "type>"], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "unknown type"

    current_if = {}
    darwin_network.parse_media_line(["media:", "autoselect", "<unknown", "type>", "status:", "active"], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "unknown type"

# Generated at 2022-06-20 17:51:13.101261
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:51:24.197834
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    darwin_tmp_if = {}
    media_line = ['<unknown type>']
    network.parse_media_line(media_line, darwin_tmp_if, [])
    assert darwin_tmp_if['media'] == 'Unknown'
    assert darwin_tmp_if['media_type'] == 'unknown type'
    assert darwin_tmp_if['media_options'] == {}
    assert darwin_tmp_if['media_select'] == 'Unknown'

    darwin_tmp_if = {}
    media_line = ['1000baseT', '(full-duplex,flow-control,rxpause,txpause)']
    network.parse_media_line(media_line, darwin_tmp_if, [])
    assert darwin_tmp_if

# Generated at 2022-06-20 17:51:32.481908
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    obj_fact_class = facts._fact_class
    obj_platform = facts._platform

    assert obj_fact_class == DarwinNetwork
    assert obj_platform == 'Darwin'


# Generated at 2022-06-20 17:51:33.014115
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:34.535383
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    c = DarwinNetworkCollector()
    assert c.platform == 'Darwin'
    assert c._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:51:37.109839
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'], type='list')))
    result = DarwinNetwork(module)
    assert result.platform == 'Darwin'
    assert result.module == module

# Generated at 2022-06-20 17:51:42.862879
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create an instance of the DarwinNetwork class
    network_collector = DarwinNetwork()
    assert network_collector.platform == 'Darwin'

    # Create an instance of the DarwinNetworkCollector class
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:51:46.401924
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_collector = DarwinNetworkCollector()
    assert darwin_collector._fact_class == DarwinNetwork
    assert darwin_collector._platform == 'Darwin'



# Generated at 2022-06-20 17:51:55.065193
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    interface = {}
    words = ["media:", "<unknown", "type>"]
    d.parse_media_line(words, interface, [])
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'
    words = ["media:", "autoselect", "(none)", "status:" , "inactive"]
    d.parse_media_line(words, interface, [])
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] == '(none)'
    assert interface['media_options'] == 'status:'

# Generated at 2022-06-20 17:51:56.849325
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network
    assert network.platform == 'Darwin'
    assert network.facts == {}


# Generated at 2022-06-20 17:52:07.894624
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    i = DarwinNetwork()
    assert i.get_file_path() == '/sbin/ifconfig'

# Generated at 2022-06-20 17:52:10.241913
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:52:19.875097
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Instantiation with default values
    darwinnet = DarwinNetwork()
    assert darwinnet.platform == "Darwin"


# Generated at 2022-06-20 17:52:23.657016
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    parsed_darwin_collector = DarwinNetworkCollector('Darwin', 'MacOSX')
    assert parsed_darwin_collector.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:52:33.647496
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    generic_bsd_ifconfig_network = DarwinNetwork({})
    assert generic_bsd_ifconfig_network.platform == 'Darwin'
    assert generic_bsd_ifconfig_network.ifconfig_path == '/sbin/ifconfig'
    # The media line is different in Darwin
    test_string = "media: <unknown type>\n"
    test_words = test_string.split()
    # not sure if this is useful - we also drop information
    media = 'unknown type'  # Mac does not give us this
    assert generic_bsd_ifconfig_network.parse_media_line(test_words, {}, {}) == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': media}

# Generated at 2022-06-20 17:52:45.563961
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test the DarwinNetwork class"""
    dn = DarwinNetwork()
    # The class is insantiated with the correct platform
    assert dn.platform == 'Darwin'

    # The static media line parser function
    parsed_media_line = dn.parse_media_line(['media:', 'select', 'autoselect', 'status:', 'active', 'supported', 'features:', 'none'], {'name': 'en0'}, {})
    assert parsed_media_line['media'] == 'Unknown'
    assert parsed_media_line['media_select'] == 'select'
    assert parsed_media_line['media_type'] == 'autoselect'
    assert parsed_media_line['media_options'] == ''

    # The static media line parser function should handle split strings
    parsed_media_line = dn.parse

# Generated at 2022-06-20 17:52:46.360647
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:52.068072
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    import sys
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    # create a instance of DarwinNetwork class
    darwin_network = DarwinNetwork()

    # create a dictionary to input and output during test
    test_dict = {'words': (), 'current_if': {}, 'ips': {}}

    # testing words
    test_dict['words'] = ['media:', '<unknown', 'type>', 'status:', 'active']
    darwin_network.parse_media_line(test_dict['words'], test_dict['current_if'], test_dict['ips'])

# Generated at 2022-06-20 17:52:59.323934
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    test.parse_media_line(words, {}, {})
    assert words == ['media:', 'autoselect', '(none)']

    words = ['media:', '1000baseT', '(none)']
    test.parse_media_line(words, {}, {})
    assert words == ['media:', '1000baseT', '(none)']

    words = ['media:', '1000baseT', '<unknown', 'type>']
    test.parse_media_line(words, {}, {})
    assert words == ['media:', '1000baseT', '<unknown', 'type>']

# Generated at 2022-06-20 17:53:10.263239
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = {'inet': {}}
    words = ['media:', 'auto', 'full-duplex', '100baseTX', 'PCS']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_options']['full-duplex'] == 'full-duplex'
    assert current_if['media_options']['100baseTX'] == '100baseTX'
    assert current_if['media_options']['PCS'] == 'PCS'

    # Test when words == ['media:', '<unknown', 'type>']

# Generated at 2022-06-20 17:53:18.539437
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork

    test_if = {}
    test_ips = {}
    d.parse_media_line(['media:', 'autoselect', '100baseTX'], test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '100baseTX'

    test_if = {}
    test_ips = {}
    d.parse_media_line(['media:', '<unknown', 'type>'], test_if, test_ips)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:53:24.809590
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    current_if = {'name': 'lo0'}
    # Test with media line (Mac OSX Yosemite)
    macosx_media_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(None, macosx_media_words, current_if, {})
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    # Test with media line (Mac OSX Mountain Lion - El Capitan)
    macosx_media_words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(None, macosx_media_words, current_if, {})

# Generated at 2022-06-20 17:53:46.122079
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dummy_module = NetworkCollector()
    test_if = {}
    # Test case 1
    # The media_types in the media line are separated by spaces.
    words = ['Media:',
             '<unknown type>',
             '(none)',
             '[<none>',
             '<full-duplex>]']
    DarwinNetwork.parse_media_line(
        dummy_module,
        words,
        test_if,
        None
    )
    assert test_if == {'media_options': ['<none>', '<full-duplex>'],
                       'media': 'Unknown',
                       'media_type': 'none',
                       'media_select': '<unknown type>'}

    # Test case 2
    # The media_types in the media line are separated by spaces.
    # There is no options


# Generated at 2022-06-20 17:53:48.430661
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector._platform == 'Darwin'
    assert net_collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:53:49.910008
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Constructor is only present in network collection code
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:53:52.863406
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    myCollector = DarwinNetworkCollector()
    assert myCollector
    assert myCollector._fact_class is DarwinNetwork
    assert myCollector._platform is 'Darwin'

# Generated at 2022-06-20 17:53:55.423215
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert hasattr(DarwinNetworkCollector, '_fact_class'), "Class DarwinNetworkCollector has no attribute _fact_class"

# Generated at 2022-06-20 17:54:03.620168
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    # known good line
    words = ['media:', 'autoselect', '(<unknown type>', '--)',
        'status:', 'active']
    net_fact_class = DarwinNetwork()
    net_fact_class._current_if = current_if
    net_fact_class.parse_media_line(words, current_if, None)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' in current_if
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' in current_if
    assert current_if['media_options'] == '--'

# Generated at 2022-06-20 17:54:04.533836
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:12.371487
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    # It uses the GenericBsdIfconfigNetwork unchanged
    assert darwin.platform == 'Darwin'
    # media line is different to the default FreeBSD one
    words = ['<unknown', 'type>']
    current_if = {}
    darwin.parse_media_line(words, current_if)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'



# Generated at 2022-06-20 17:54:14.622748
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Init the class and call constructor
    tnm = DarwinNetwork()
    # Assert if class is an instance of the class it should be
    assert isinstance(tnm, DarwinNetwork)

# Generated at 2022-06-20 17:54:15.084118
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:57.971467
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    words = ['media:', 'Manual', '1000baseT', '<full-duplex>']
    ips = []
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Manual'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == {'full': True, 'duplex': True}
    words = ['media:', 'Manual', '1000baseT']
    d.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Manual'

# Generated at 2022-06-20 17:54:59.539987
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)


# Generated at 2022-06-20 17:55:09.084195
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinNetwork = DarwinNetwork()
    current_if = {}
    ips = []

    # test with empty words
    darwinNetwork.parse_media_line(words=[], current_if=current_if, ips=ips)
    assert (current_if['media'] == 'Unknown')
    assert (current_if['media_select'] == 'a')

    # test with one word
    darwinNetwork.parse_media_line(words=['bb'], current_if=current_if, ips=ips)
    assert (current_if['media'] == 'Unknown')
    assert (current_if['media_select'] == 'bb')

    # test with two words
    darwinNetwork.parse_media_line(words=['aa', 'bb'], current_if=current_if, ips=ips)

# Generated at 2022-06-20 17:55:11.996238
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork('/sbin/ifconfig', '/sbin/route', 'lo0')
    assert d is not None


# Generated at 2022-06-20 17:55:13.240846
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'


# Generated at 2022-06-20 17:55:22.775095
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Sample media line [Taken from en0]
    media_line = "media: autoselect (1000baseT <full-duplex>) status: active"
    words = media_line.split(' ')

    # Declare a dummy instance of class DarwinNetwork
    darwin = DarwinNetwork()

    current_if = {}
    ips = []

    # Call parse_media_line method of class DarwinNetwork
    darwin.parse_media_line(words, current_if, ips)

    # We expect these values from the sample media line
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'

# Generated at 2022-06-20 17:55:23.430644
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Create an instance of DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:29.687332
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == 'Darwin'
    assert collector.__doc__ == '''
    This is the Mac macOS Darwin Network Class.
    It uses the GenericBsdIfconfigNetwork unchanged
    '''
    assert isinstance(collector._fact_class(), GenericBsdIfconfigNetwork)
    assert collector._fact_class.__doc__ == '''
     This is the Mac macOS Darwin Network Class.
     It uses the GenericBsdIfconfigNetwork unchanged
     '''

# Generated at 2022-06-20 17:55:31.170694
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.collect()


# Generated at 2022-06-20 17:55:34.072119
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # This test function is used to construct and validate that constructor of
    # class DarwinNetworkCollector will work with only expected arguments and
    # wont throw any exception
    a = DarwinNetworkCollector()
    assert a._platform == 'Darwin'


# Generated at 2022-06-20 17:56:52.845558
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # instantiate DarwinNetworkCollector
    my_obj = DarwinNetworkCollector()
    assert my_obj
    assert issubclass(type(my_obj), NetworkCollector)
    assert my_obj.platform == 'Darwin'
    assert my_obj._fact_class == DarwinNetwork
    assert my_obj._platform == 'Darwin'
    assert my_obj.get_facts() == dict()


# Generated at 2022-06-20 17:56:54.774491
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dwn = DarwinNetwork()
    assert dwn.platform == 'Darwin'
    dwn.gather_ifconfig_info()

# Generated at 2022-06-20 17:56:56.027188
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = {'type': 'ether'}
    test_words = ["<unknown", "type>"]
    DarwinNetwo

# Generated at 2022-06-20 17:56:58.883239
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_facts = DarwinNetwork()
    result = net_facts.get_facts()
    assert not result['ansible_all_ipv4_addresses']
    assert result['ansible_interfaces']

# Generated at 2022-06-20 17:57:02.825942
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["media:", "<unknown type>"]
    current_if = dict()
    ips = dict()
    net = DarwinNetwork()
    net.parse_media_line(words, current_if, ips)
    assert current_if["media_select"] == "Unknown"



# Generated at 2022-06-20 17:57:14.779595
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    dn = DarwinNetwork()
    mac_media_line = ['', 'media:', 'autoselect', 'status:', 'inactive']
    mac_if = {}
    mac_ips = {}
    dn.parse_media_line(mac_media_line, mac_if, mac_ips)
    assert mac_if == {'media': 'Unknown', 'media_select': 'autoselect'}
    assert mac_ips == {}

    # Test for the case reported in issue #58606
    mac_media_line = ['', 'media:', '<unknown', 'type>', 'status:', 'inactive']
    mac_if = {}
    mac_ips = {}

# Generated at 2022-06-20 17:57:20.534884
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a dummy interface object
    iface = DarwinNetwork()
    iface.ifname = 'en0'
    ips = {'127.0.0.1': {'prefixlen': 24, 'broadcast': '127.255.255.255', 'netmask': '255.0.0.0'}}

    # test a media line with all fields
    line = 'media: autoselect (1000baseT <full-duplex,flow-control>) '
    iface.parse_media_line(line.split(), iface.iface, ips)
    assert iface.iface['media_select'] == 'autoselect'
    assert iface.iface['media_type'] == '1000baseT'

# Generated at 2022-06-20 17:57:24.533492
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, NetworkCollector) is True


# Generated at 2022-06-20 17:57:25.088746
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None).platform == 'Darwin'

# Generated at 2022-06-20 17:57:32.678248
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Initialize class object
    ifc = DarwinNetwork()

    # Empty input
    words = []
    current_if = {}
    ips = []

    # Parse media line
    ifc.parse_media_line(words, current_if, ips)

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == ''
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # Initialize class object
    ifc = DarwinNetwork()

    # Empty input
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = []

    # Parse media line