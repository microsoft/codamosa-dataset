

# Generated at 2022-06-20 17:48:54.142624
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    current_if = {}

    # Valid media line
    line = ["      media: autoselect ethernet"]
    darwin_if.parse_media_line(line, current_if, '')
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'ethernet'

    # Invalid media line
    line = ["      media: autoselect <unknown type>"]
    darwin_if.parse_media_line(line, current_if, '')
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

    #

# Generated at 2022-06-20 17:48:55.995172
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class._platform == 'Darwin'

# Generated at 2022-06-20 17:49:03.425060
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:49:05.838169
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnw = DarwinNetwork({}, None)
    assert dnw.name == 'Darwin'
    assert not dnw.facts

# Generated at 2022-06-20 17:49:07.560303
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector.platform == 'Darwin'


# Generated at 2022-06-20 17:49:20.089760
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    test_input = 'media: <unknown type>'
    test_current_if = {}
    test_ips = {}
    dnet.parse_media_line(test_input.split(), test_current_if, test_ips)
    assert test_current_if['media'] == 'Unknown'
    assert test_current_if['media_select'] == 'Unknown'
    assert test_current_if['media_type'] == 'unknown type'

    test_input = 'media: <unknown type> status: active'
    test_current_if = {}
    test_ips = {}
    dnet.parse_media_line(test_input.split(), test_current_if, test_ips)
    assert test_current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:49:27.900154
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: autoselect status: active'
    words = media_line.split(" ")
    # to be supplied to the method parse_media_line
    current_if = {}
    ips = ""
    darwin_if_net = DarwinNetwork("e0")
    darwin_if_net.parse_media_line(words, current_if, ips)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == 'autoselect')
    assert(current_if['media_type'] == 'status:')
    assert(current_if['media_options'] == 'active')

# Generated at 2022-06-20 17:49:33.845812
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['en0:', '<unknown', 'type>', 'status:', 'active']
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:49:42.460365
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {'media_select': '', 'media_type': '', 'media_options': ''}
    darwin_network.parse_media_line(['media', 'type', 'autoselect', 'options'], current_if, '')
    assert current_if['media_select'] == 'type'
    assert current_if['media_type'] == 'autoselect'
    assert current_if['media_options'] == 'options'
    assert current_if['media'] == 'Unknown'

    darwin_network.parse_media_line(['media', 'type', 'unknown type'], current_if, '')
    assert current_if['media_select'] == 'type'
    assert current_if['media_type'] == 'unknown type'
    assert current

# Generated at 2022-06-20 17:49:45.453758
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert(DarwinNetwork.platform == 'Darwin')
    assert('%s.%s' % (DarwinNetwork.__module__, DarwinNetwork.__name__,) in globals())


# Generated at 2022-06-20 17:49:51.637458
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnw = DarwinNetworkCollector()
    assert dnw.platform == 'Darwin'
    assert dnw._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:49:53.219678
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj_constructor = DarwinNetwork()
    assert obj_constructor.platform == 'Darwin'


# Generated at 2022-06-20 17:49:57.048444
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # GIVEN
    # WHEN
    darwin_network_collector = DarwinNetworkCollector()
    # THEN:
    assert darwin_network_collector._fact_class is DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'



# Generated at 2022-06-20 17:49:59.329873
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == "Darwin"
    assert d.ip_command == "/sbin/ifconfig"

# Generated at 2022-06-20 17:50:00.764346
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:50:02.849072
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''Unit test that tests constructor of class DarwinNetwork'''
    fact_class = DarwinNetwork()
    assert fact_class.platform == 'Darwin'


# Generated at 2022-06-20 17:50:04.443224
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetworkCollector.parse_media_line(None, [
        'media: ',
        'autoselect',
        '(none)'], None, None)

# Generated at 2022-06-20 17:50:07.382162
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None, None)
    assert isinstance(obj._fact_class, DarwinNetwork)
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:50:14.175331
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:50:18.885783
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', '']
    current_if = {}
    ips = {}
    DarwinNetwork(None, None).parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown',
                          'media_select': 'Unknown',
                          'media_type': 'unknown type'}