

# Generated at 2022-06-20 17:48:57.515389
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # set up object to test
    darwin_net = DarwinNetwork()
    darwin_net.ifconfig_path = '/bin/ifconfig'
    darwin_net.route_path = '/sbin/route'

    # create a generic interface data structure
    current_if = dict()
    ips = dict()
    current_if['ips'] = ips
    current_if['iface'] = 'eth0'
    current_if['active'] = True
    current_if['flags'] = ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    current_if['ipv4'] = dict()
    current_if['ipv4']['broadcast'] = '192.168.1.255'

# Generated at 2022-06-20 17:49:09.464517
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test with media line of Ethernet interface
    ifc = DarwinNetwork({})
    current_if = dict()
    ifc.parse_media_line(['media:', '<unknown type>',
                          '(autoselect)'], current_if, ips=[])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ['autoselect']
    # Test with media line of Bridge interface
    ifc = DarwinNetwork({})
    current_if = dict()
    ifc.parse_media_line(['media:', '<unknown', 'type>',
                          '(autoselect)'], current_if, ips=[])

# Generated at 2022-06-20 17:49:11.316479
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network._platform == 'Darwin'
    assert network._fact_class.__name__ == 'DarwinNetwork'


# Generated at 2022-06-20 17:49:12.662948
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector(None)

# Generated at 2022-06-20 17:49:23.158457
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-20 17:49:31.157041
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    obj.parse_media_line(['media:', '<unknown type>', '(unknown)'],
                         obj.current_if, obj.ips)
    assert obj.current_if['media'] == 'Unknown'
    assert obj.current_if['media_select'] == 'Unknown'
    assert obj.current_if['media_type'] == 'unknown type'
    assert obj.ips == {}

    obj.parse_media_line(['media:', 'autoselect', '(none)'],
                         obj.current_if, obj.ips)
    assert obj.current_if['media'] == 'Unknown'
    assert obj.current_if['media_select'] == 'autoselect'
    assert obj.current_if['media_type'] == '(none)'
    assert obj.ips == {}

# Generated at 2022-06-20 17:49:33.047075
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork({}, {}, {})
    assert net.platform == 'Darwin'


# Generated at 2022-06-20 17:49:42.057434
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = [
        [['media:','<unknown','type>','status:','active'], 'Unknown', 'unknown type'],
        [['media:','autoselect','status:','active'], 'autoselect', None],
        [['media:','none','status:','inactive'], 'none', None],
        [['media:','autoselect','(none)','status:','active'], 'autoselect', 'none']
    ]
    test_obj = DarwinNetwork()

    for test in test_data:
        test_obj.parse_media_line(test[0], {}, [])
        assert test_obj.interfaces['eth0']['media_select'] == test[1]
        assert test_obj.interfaces['eth0']['media_type'] == test[2]

# Generated at 2022-06-20 17:49:44.076824
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mod = DarwinNetwork({})
    assert mod.platform == 'Darwin'



# Generated at 2022-06-20 17:49:45.814012
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test constructor
    d_net = DarwinNetwork()
    assert d_net is not None

