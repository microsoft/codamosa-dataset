

# Generated at 2022-06-20 17:48:49.501611
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_class = DarwinNetwork()
    assert test_class.platform == 'Darwin'


# Generated at 2022-06-20 17:49:00.098724
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:49:03.660333
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d_obj = DarwinNetwork()
    # Checking for platform attribute
    assert d_obj.platform == 'Darwin'
    # Checking for platform attribute
    assert d_obj.command == 'ifconfig -a'

# Generated at 2022-06-20 17:49:05.680153
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test the DarwinNetworkCollector"""

    # create the collector object
    darwin_network_collector = DarwinNetworkCollector()

    # check if the object is an instance of DarwinNetworkCollector
    assert isinstance(darwin_network_collector, DarwinNetworkCollector)


# Generated at 2022-06-20 17:49:07.431289
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    my_DarwinNetworkCollector = DarwinNetworkCollector()
    assert my_DarwinNetworkCollector is not None

# Generated at 2022-06-20 17:49:11.132998
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork(None)
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:49:12.882081
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'


# Generated at 2022-06-20 17:49:23.407147
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    test_cases = [
        {'line': 'media: <unknown type>', 'out': {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': {}}},
        {'line': 'media: autoselect (100baseTX full-duplex)', 'out': {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX full-duplex', 'media_options': {}}}
    ]
    for case in test_cases:
        network.parse_media_line(case['line'].split(), {}, [])
        assert network.current_if == case['out']

# Generated at 2022-06-20 17:49:33.945923
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collector = DarwinNetwork()

    # test for media line with 802.11n
    line = "supported media: autoselect <unknown type>"
    words = line.split()
    current_if = {}
    ips = []

    collector.parse_media_line(words, current_if, ips)

    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "<unknown type>"
    assert current_if['media_options'] == ""

    # test for media line with Ethernet
    current_if = {}

    line = "supported media: autoselect <full-duplex> <100baseTX>"
    words = line.split()

    collector.parse_media_line(words, current_if, ips)

   

# Generated at 2022-06-20 17:49:34.642353
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:37.061537
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()

# Generated at 2022-06-20 17:49:46.672230
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_interface = DarwinNetwork()
    mac_interface.init_tree()
    mac_interface.parse_media_line(['media:', 'autoselect', '(1000baseT)'], mac_interface.tree, [])
    assert mac_interface.tree['media'] == 'Unknown'
    assert mac_interface.tree['media_select'] == 'autoselect'
    assert mac_interface.tree['media_type'] == '1000baseT'
    assert mac_interface.tree['media_options'] == ''
    mac_interface.init_tree()
    mac_interface.parse_media_line(['media:', 'autoselect', '(<unknown', 'type>)'], mac_interface.tree, [])
    assert mac_interface.tree['media'] == 'Unknown'

# Generated at 2022-06-20 17:49:49.480917
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:49:51.398232
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'


# Generated at 2022-06-20 17:49:55.299110
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """test initialization of class DarwinNetwork"""
    dn = DarwinNetworkCollector(None, None, None)
    assert dn.__class__.__name__ == 'DarwinNetwork'
    assert dn.__class__.platform == 'Darwin'
    assert dn.__class__._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:03.542597
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Here we show how to use the Network Class
    And output the collected vars
    :return:
    """
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = GenericBsdIfconfigNetwork()
    ifaces_lines = open("tests/network/resources/ifconfig_Darwin", "r").read()
    module.parse_ifconfig_output(ifaces_lines)

    print("Dumping collected data")
    import json
    print(json.dumps(module.get_interfaces_facts(), indent=4, sort_keys=True))

if __name__ == '__main__':
    test_DarwinNetwork()

# Generated at 2022-06-20 17:50:07.053743
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _fact = DarwinNetworkCollector()
    assert isinstance(_fact, DarwinNetworkCollector)
    assert _fact._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:18.292627
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line_simple = [
            "media:",
            "(none)",
            "status:",
            "inactive"
    ]
    media_line_unknown_type = [
            "media:",
            "<unknown",
            "type>",
            "status:",
            "inactive"
    ]
    current_if = {}
    DarwinNetwork().parse_media_line(media_line_simple, current_if, "")
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'none'
    assert not 'media_type' in current_if
    DarwinNetwork().parse_media_line(media_line_unknown_type, current_if, "")
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type']

# Generated at 2022-06-20 17:50:27.880439
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '100baseTX', '<full-duplex>', '<100baseTX-FD>']
    current_if = {'media': 'Unknown'}

    DarwinNetwork.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == words[1]
    assert current_if['media_type'] == words[2][1:-1]
    assert current_if['media_options'] == '100baseTX-FD'

    words = ['media:', 'autoselect', '<unknown type>', '<none>']
    current_if = {'media': 'Unknown'}

    DarwinNetwork.parse_media_line(words, current_if, [])

# Generated at 2022-06-20 17:50:30.657719
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()

    assert isinstance(instance, DarwinNetworkCollector)
    assert isinstance(instance._fact_class, DarwinNetwork)


# Generated at 2022-06-20 17:50:34.812787
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == "Darwin"

# Generated at 2022-06-20 17:50:45.210100
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork(None)
    result = dict()


# Generated at 2022-06-20 17:50:46.760973
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'



# Generated at 2022-06-20 17:50:49.053595
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = dict()
    darwin_network = DarwinNetwork('fake_data', facts)
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:51:00.464700
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_iface_info_dict = dict(name='e1000g0',
                                  type='Ethernet',
                                  macaddress='00:00:00:00:00:00',
                                  addresses=[dict(address='10.0.0.1', netmask='255.255.255.0', broadcast='10.0.0.255'),
                                             dict(address='192.168.0.1', netmask='255.255.255.0')])
    darwin_iface_dict = dict(e1000g0=darwin_iface_info_dict)
    darwin_network = DarwinNetwork()
    darwin_network.interfaces = darwin_iface_dict

# Generated at 2022-06-20 17:51:03.155952
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Constructor of class DarwinNetworkCollector
    #assert isinstance(DarwinNetworkCollector, NetworkCollector)
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:51:03.898171
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()


# Generated at 2022-06-20 17:51:06.046482
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This function test the constructor of class DarwinNetworkCollector
    """
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert len(obj.facts) == 0
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-20 17:51:09.646139
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'
    assert obj._fact_class.__name__ == 'DarwinNetwork'
    assert obj._platform == 'Darwin'


# Generated at 2022-06-20 17:51:11.644990
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    '''
    Unit test for DarwinNetworkCollector constructor
    '''
    module = NetworkCollector()
    assert module is not None

# Generated at 2022-06-20 17:51:18.099241
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork(dict())
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:51:27.919689
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert type(obj.facts['all_ipv4_addresses']) is list
    assert type(obj.facts['all_ipv6_addresses']) is list
    assert type(obj.facts['default_ipv4']) is dict
    assert type(obj.facts['default_ipv6']) is dict
    assert 'interface_ip' in obj.facts['default_ipv4']
    assert 'address' in obj.facts['default_ipv4']
    assert 'interface_ip' in obj.facts['default_ipv6']
    assert 'address' in obj.facts['default_ipv6']
    assert type(obj.facts['interfaces']) is dict

# Generated at 2022-06-20 17:51:31.518847
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.fact_class == dnc._fact_class
    assert dnc.platform == dnc._platform



# Generated at 2022-06-20 17:51:37.950123
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test the DarwinNetwork.parse_media_line method.
    """
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(['media:', 'autoselect', '100baseTX', '(100baseTX)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'][0]['value'] == '100baseTX'



# Generated at 2022-06-20 17:51:39.999306
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:47.843685
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector constructor with default
    value and with specified values
    """
    darwin_network_collector_default = DarwinNetworkCollector()
    assert darwin_network_collector_default._platform == 'Darwin'
    assert darwin_network_collector_default._fact_class == DarwinNetwork
    darwin_network_collector = DarwinNetworkCollector('DARWIN', 'NETWORK')
    assert darwin_network_collector._platform == 'DARWIN'
    assert darwin_network_collector._fact_class == 'NETWORK'

# Generated at 2022-06-20 17:51:57.720393
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ''' Test the parse_media_line method of DarwinNetwork
    '''
    # Typical input lines to parse_media_line
    # 'media: autoselect (1000baseT full-duplex,flow-control,rxpause,txpause)'
    # 'media: autoselect (1000baseT full-duplex)'
    # 'media: autoselect  status: active'
    # 'media: <unknown type>'
    # 'media: <unknown type>  status: active'
    #
    # Test media: <unknown type> with status: active
    IF = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'options': 'status: active'}
    dn = DarwinNetwork()

# Generated at 2022-06-20 17:52:02.326707
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    # Make sure we actually set the collection class
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    # and the inherited constructor seems to set the right collection class
    assert DarwinNetworkCollector()._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:52:11.856225
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # create class instance
    dn = DarwinNetwork()

    current_if = {}
    words = "media: autoselect"
    ips = None

    dn.parse_media_line(words.split(), current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert not current_if.get('media_type')
    assert not current_if.get('media_options')

    current_if = {}
    words = "media: autoselect (100baseTX <full-duplex,flow-control>)"
    ips = None

    dn.parse_media_line(words.split(), current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:52:16.597398
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    Darwin = DarwinNetwork()
    test_1 = Darwin.parse_media_line(['media:', 'autoselect', '(none)'], {})    
    assert test_1 == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none'}, "Parse_media_line test failed"
    test_2 = Darwin.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {})    
    assert test_2 == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}, "Parse_media_line test failed"

# Generated at 2022-06-20 17:52:27.333378
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:52:36.123750
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initate DarwinNetwork class
    dnetwork = DarwinNetwork('foo', 'bar')

    # Test when media line is 'media: autoselect <unknown type>'
    current_if = dict()
    words = ['media:', 'autoselect', '<unknown', 'type>']
    dnetwork.parse_media_line(words, current_if, None)
    expected_res = dict(media='Unknown',
                        media_select='autoselect',
                        media_type='unknown type')
    assert current_if == expected_res

    # Test when media line is 'media: autoselect <unknown type>'
    current_if = dict()
    words = ['media:', 'autoselect']
    dnetwork.parse_media_line(words, current_if, None)

# Generated at 2022-06-20 17:52:39.405760
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    fnc = DarwinNetwork()
    assert hasattr(fnc, 'platform')
    assert hasattr(fnc, 'get_default_interface')
    assert hasattr(fnc, 'get_interfaces')



# Generated at 2022-06-20 17:52:46.358098
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test = DarwinNetwork()
    assert test.platform == 'Darwin'
    assert test.line_regex[0] == (r"^([0-9a-zA-Z]+): flags=([0-9a-f]+).*metric (.+) mtu (.+) "
                                r"([0-9a-zA-Z]+) (.+)$")
    assert test.version_cmd == 'sysctl kern.version'


# Generated at 2022-06-20 17:52:53.395835
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This tests the constructor of the DarwinNetworkCollector class
    """
    darwin_network_collector = DarwinNetworkCollector()

    assert isinstance(darwin_network_collector, NetworkCollector)
    assert isinstance(darwin_network_collector, DarwinNetworkCollector)
    # Test fact_class
    assert darwin_network_collector.fact_class == DarwinNetwork
    # Test platform
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:52:54.937285
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector(None,None)
    assert collector.platform == 'Darwin'

# Generated at 2022-06-20 17:53:00.017548
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = dict()
    current_if['media'] = dict()
    d = DarwinNetwork()
    d.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == dict()

# Generated at 2022-06-20 17:53:02.554660
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
  assert DarwinNetworkCollector._platform == 'Darwin'
  assert DarwinNetworkCollector._fact_class == DarwinNetwork
  collector = DarwinNetworkCollector()
  assert collector.get_facts()[0].platform == 'Darwin'

# Generated at 2022-06-20 17:53:05.869687
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork(None, "", "", "")
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:53:09.941134
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    results = DarwinNetwork(None, None)
    assert results.get_file_path() == '/usr/sbin/ifconfig'
    assert results.get_interface_directory() is None
    assert results.get_backup_file_path() == '/usr/sbin/ifconfig.orig'

# Generated at 2022-06-20 17:53:42.779865
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    ips = []
    words = 'media: autoselect status: active'.split()
    assert d.parse_media_line(words, current_if, ips) == None
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'
    assert current_if['media_options'] == [('active', '')]

    words = ['media:', '<unknown', 'type>', '(none)', '(none)']
    assert d.parse_media_line(words, current_if, ips) == None
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
   

# Generated at 2022-06-20 17:53:46.390810
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mac_network = DarwinNetwork()
    mac_network.collect()
    interfaces = mac_network.get_interfaces()
    # We should at least find loopback
    assert 'lo0' in interfaces


# Generated at 2022-06-20 17:53:54.960845
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface_data = []
    kwargs = {'interface_data': interface_data, 'network_type': 'unknown', 'interface_name': 'unknown'}
    test_data = ['media:', 'media_select:', 'media_type:', 'media_options:']
    darwin_network = DarwinNetwork(**kwargs)
    darwin_network.parse_media_line(test_data, kwargs, interface_data)
    assert kwargs['media'] == 'Unknown'
    assert kwargs['media_select'] == 'media_select:'
    assert kwargs['media_type'] == 'media_type:'
    assert kwargs['media_options'] == 'media_options:'
    # Test that a line with a type of '<unknown type>' is correctly parsed

# Generated at 2022-06-20 17:53:56.842231
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc


# Generated at 2022-06-20 17:53:59.050948
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_facts = DarwinNetwork('en0')
    assert(darwin_facts.platform == 'Darwin')

# Generated at 2022-06-20 17:54:01.650577
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert isinstance(collector._fact_class, DarwinNetwork)


# Generated at 2022-06-20 17:54:03.419846
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    c = DarwinNetworkCollector()
    assert c.platform == 'Darwin'
    assert c.fact_class.platform == 'Darwin'


# Generated at 2022-06-20 17:54:14.402817
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # type(ips) is dict
    # type(current_if) is dict
    ips = {}
    current_if = {}
    # Check that media line is parsed correctly
    words = ['Media:', '<unknown type>', '(none)', 'status:', 'inactive']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'none'
    assert ips == {}
    # Check that media line is parsed correctly
    current_if = {}
    ips = {}

# Generated at 2022-06-20 17:54:16.107564
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:54:17.147063
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:55:04.359943
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert isinstance(d, DarwinNetwork)



# Generated at 2022-06-20 17:55:15.599811
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    # Arrange
    # current_if does not need to be populated as it is updated 'in place'
    current_if = {}

    # Act
    darwin_net.parse_media_line(
        words=['media:', 'autoselect', '(none)'],
        current_if=current_if,
        ips={}
    )

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}

    # Act

# Generated at 2022-06-20 17:55:18.646271
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()
    assert darwinNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:55:20.715199
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Make sure we are initialized properly.
    """
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'
    assert darwin_net.ifconfig_path == '/sbin/ifconfig'
    assert darwin_net.interfaces is {}
    assert darwin_net.routes is {}

# Generated at 2022-06-20 17:55:27.392055
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {'name': 'em1'}
    ips = []
    darwin_network.parse_media_line(['media:', '<unknown', 'type>'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if
    current_if = {'name': 'em1'}
    ips = []
    darwin_network.parse_media_line(['media:', 'autoselect', '(1000baseT)'],
                                    current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current

# Generated at 2022-06-20 17:55:29.396737
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructing a DarwinNetworkCollector should not raise an Exception
    """
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:39.096612
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line((
        'media:', '<unknown type>', '(<unknown ssid>)'
    ), {}, {})

    mediadata = {
        'type': 'unknown type',
        'options': {'ssid': 'unknown ssid'}
    }

    assert mediadata == darwin_network.current_if['media']
    assert mediadata['type'] == darwin_network.current_if['media_type']
    assert mediadata['options'] == darwin_network.current_if['media_options']
    assert 'Unknown' == darwin_network.current_if['media_select']

# Generated at 2022-06-20 17:55:46.603355
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    # Test method DarwinNetwork.parse_media_line
    ifc_current_if = {'device': 'bridge0'}
    ifc_ips = {}
    ifc_words = ['media:', '<unknown', 'type>']
    dnet.parse_media_line(ifc_words, ifc_current_if, ifc_ips)
    assert ifc_current_if['media'] == 'Unknown'
    assert ifc_current_if['media_select'] == 'Unknown'
    assert ifc_current_if['media_type'] == 'unknown type'

    # Test method DarwinNetwork.parse_media_line
    ifc_current_if = {'device': 'bridge0'}
    ifc_ips = {}

# Generated at 2022-06-20 17:55:47.379450
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:55:52.590990
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a fake interface
    current_if = {}
    current_if['address'] = 'fe80::224:33ff:fe00:0%en0'
    current_if['media'] = 'Unknown'
    current_if['media_select'] = 'auto'
    current_if['media_type'] = 'Media type'
    current_if['media_options'] = 'None'
    # create a fake line
    words = ['media:','media_select','media_type','media_options']

    dn = DarwinNetwork()
    dn.parse_media_line(words,current_if,[])

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    assert current_

# Generated at 2022-06-20 17:57:13.560694
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-20 17:57:15.887420
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetworkCollector = DarwinNetworkCollector()
    assert darwinNetworkCollector._platform == 'Darwin'
    assert darwinNetworkCollector._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:57:19.831924
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    dwn.parse_media_line(['  media:','<unknown','type>'], {}, {})
    assert '<unknown type>' == dwn.current_if['media_select']
    assert 'Unknown' == dwn.current_if['media']
    assert 'unknown type' == dwn.current_if['media_type']

# Generated at 2022-06-20 17:57:31.170798
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = list()

    # create instance of DarwinNetwork
    dn = DarwinNetwork(current_if, ips)

    # test case 1:
    words = ['10baseT', '<half-duplex>', '<link>', '<active>']

    dn.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '10baseT'
    assert current_if['media_type'] == 'half-duplex'
    assert current_if['media_options'] == ['link', 'active']

    # test case 2:
    words = ['1000baseT', '<full-duplex>', '<link>', '<txpause>', '<rxpause>']



# Generated at 2022-06-20 17:57:36.495742
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork('lo0', {'device': 'lo0', 'state': 'UP'})
    assert d.name == 'lo0'
    assert d.data['device'] == 'lo0'
    assert d.data['state'] == 'UP'


# Generated at 2022-06-20 17:57:38.951561
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:57:47.938388
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Default dict of current_if
    current_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': []}
    # test where words is a list of length 1
    words = ['lan']
    DarwinNetwork().parse_media_line(words, current_if, [])
    assert (current_if['media'] == 'Unknown')
    assert (current_if['media_select'] == 'lan')
    assert (current_if['media_type'] == None)
    assert (current_if['media_options'] == [])
    # test where words is a list of length 2
    words = ['<unknown', 'type>']
    DarwinNetwork().parse_media_line(words, current_if, [])
    assert (current_if['media'] == 'Unknown')

# Generated at 2022-06-20 17:57:53.865989
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    data = {}
    dn = DarwinNetwork(data)
    assert dn.platform == 'Darwin'
    assert dn.parse_media_line(['address','','','','','','','','','',''], {}, {}) == None


# Generated at 2022-06-20 17:58:01.904105
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # list of words, current_if, ips, and expected output
    test_data = [
        (['media:', 'autoselect', '10baseT/UTP'], {}, [],
         {'media': 'Unknown',
          'media_select': 'autoselect',
          'media_type': '10baseT/UTP'}),
        (['media:', '<unknown', 'type>'], {}, [],
         {'media': 'Unknown',
          'media_select': 'Unknown',
          'media_type': 'unknown type'})
    ]

    for words, current_if, ips, expected in test_data:
        DarwinNetwork().parse_media_line(words, current_if, ips)
        assert expected == current_if

# Generated at 2022-06-20 17:58:06.484810
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork(None)
    assert d.get_device_information('lo0')['ipv4'] == ['127.0.0.1']
    assert d.get_device_information('lo0')['active']