

# Generated at 2022-06-20 17:48:52.981530
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts_from_class = DarwinNetwork()
    assert facts_from_class.platform == 'Darwin'



# Generated at 2022-06-20 17:48:55.499331
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector_object = DarwinNetworkCollector()
    assert network_collector_object.get_facts() == {}


# Generated at 2022-06-20 17:48:58.331782
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetworkCollector = DarwinNetworkCollector()
    assert darwinNetworkCollector.get_facts().__class__.__name__ == 'DarwinNetwork'

# Generated at 2022-06-20 17:49:00.205197
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # We can only test if the parser is successfully created
    parser = DisableBsdNetwork()
    assert parser

# Generated at 2022-06-20 17:49:01.804888
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    mac = DarwinNetworkCollector()
    assert mac._fact_class is DarwinNetwork
    assert mac._platform is 'Darwin'

# Generated at 2022-06-20 17:49:02.380024
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:06.527296
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = dict()
    network_collector = DarwinNetworkCollector(facts, None)
    assert (isinstance(network_collector,
                                 DarwinNetworkCollector)) is True

# Generated at 2022-06-20 17:49:07.347168
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:49:12.571615
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test DarwinNetworkCollector constructor
    """
    obj = DarwinNetworkCollector()
    assert obj
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:49:16.284683
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', 'autoselect', '(unknown)'], {}, None)
    assert({'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(unknown)'} == ifc.current)

# Generated at 2022-06-20 17:49:20.793656
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:49:29.553869
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_if['media_select'] = "aui"
    test_if['media_type'] = "10base5"
    test_if['media_options'] = ["<noop>"]

    # For default test, use media_line sample from man page ifconfig(8)
    words = ["media:", "aui", "10base5", "<noop>"]

    test_DarwinNetwork = DarwinNetwork(None)
    test_DarwinNetwork.parse_media_line(words, test_if, None)
    assert test_if['media'] == "Unknown"
    assert test_if['media_select'] == test_if['media_select']
    assert test_if['media_type'] == test_if['media_type']
    assert test_if['media_options'] == test_if

# Generated at 2022-06-20 17:49:39.272572
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetworkCollector()
    words = ['media:', 'autoselect', '<unknown type>', '(none)']
    current_if = {}
    ips = {}
    # Running parse_media_line() from DarwinNetwork class
    mm = DarwinNetwork('')
    mm.parse_media_line(words, current_if, ips)
    # test for media key
    assert 'media' in current_if
    # test for media_select key
    assert 'media_select' in current_if
    # test for media_type key
    assert 'media_type' in current_if
    # test for media_options key
    assert 'media_options' in current_if

# Generated at 2022-06-20 17:49:40.676952
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    test_class = DarwinNetwork()
    assert test_class.platform == 'Darwin'

# Generated at 2022-06-20 17:49:43.441001
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    print(str(darwin_network))
    assert darwin_network._platform == 'Darwin'

# Generated at 2022-06-20 17:49:45.680294
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:49:47.305247
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collect = DarwinNetworkCollector()
    assert collect.platform == 'Darwin'



# Generated at 2022-06-20 17:49:53.517499
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for DarwinNetwork
    """
    # We don't care about the rest of the class for this test
    # pylint: disable=unused-argument, protected-access
    def fake_up(self):
        return
    def fake_down(self):
        return
    DarwinNetwork._populate_from_ifconfig = fake_up
    DarwinNetwork._down = fake_down

    # Generate sample output
    output = DarwinNetwork.run_ifconfig()

    # Run the parse method on the output
    darwin_network = DarwinNetwork()
    darwin_network.parse(output)

    # See if the generated facts match the output

# Generated at 2022-06-20 17:49:54.535842
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    foo = DarwinNetwork({})



# Generated at 2022-06-20 17:50:03.912030
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instance of class DarwinNetwork
    network = DarwinNetwork()
    # Create dictionary with mock interface
    current_if = {}
    # Create list of words to be parsed
    words = ['media:', '<unknown', 'type>']
    # Call method to be tested
    network.parse_media_line(words, current_if, None)
    # Assert that keys 'media', 'media_select', 'media_type' are in current_if
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    # Assert that values of 'media' and 'media_select' in current_if are correct
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    # Assert that

# Generated at 2022-06-20 17:50:07.851200
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-20 17:50:09.560815
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()
    assert darwinNetwork is not None

# Generated at 2022-06-20 17:50:13.620240
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector('/tmp/', [])
    darwin_network.collect()
    assert darwin_network.fact_class == DarwinNetwork
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:50:18.712251
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """test DarwinNetwork.parse_media_line."""
    current_if = {'iface': 'en0'}
    ips = []
    # test with a media line from ifconfig
    test_line = 'media: autoselect <unknown type> status: inactive'
    darwin_net = DarwinNetwork(None)
    darwin_net.parse_media_line(test_line.split(), current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:50:19.810941
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().platform == 'Darwin'

# Generated at 2022-06-20 17:50:21.227015
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), NetworkCollector)

# Generated at 2022-06-20 17:50:22.448192
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()


# Generated at 2022-06-20 17:50:28.709361
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = "media: autoselect (1000baseT <full-duplex,flow-control>) status: active"

    current_if = {'media': 'Unknown'}

    DarwinNetwork.parse_media_line(line.split(), current_if)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == '1000baseT <full-duplex,flow-control>'
    assert current_if['media_options'] == 'full-duplex,flow-control'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-20 17:50:39.375772
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = []
    words = ['media:', '<unknown type>', '<unknown subtype>']  # parse_media_line("media: <unknown type> <unknown subtype>")
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown type>'
    assert current_if['media_type'] == 'unknown subtype'
    assert 'media_options' not in current_if



# Generated at 2022-06-20 17:50:45.857612
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = {
        'media': 'Unknown',
        'media_type': 'Ethernet',
        'media_select': 'autoselect',
        'media_options': 'full-duplex,flow-control'
    }
    words = ['media:', 'autoselect', '(Ethernet)', 'full-duplex,flow-control']
    dn = DarwinNetwork()
    dn.parse_media_line(words, dn.current_if, dn.ips)
    for k, v in test_data.items():
        assert dn.current_if[k] == v

# Generated at 2022-06-20 17:50:55.869562
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    debug = False # Set to true to print output
    # Constructor
    i = DarwinNetwork()

    if debug:
        print("DarwinNetwork:")
        # print("  keys (): ", i.keys())
        print("  keys (): ", i.keys_to_serialize())
        print("  keys (): ", i.keys_to_serialize(serialize_all=True))
        print("  interfaces (): ", i.interfaces())
        print("  interfaces (): ", i.interfaces(include_ifnames=False))
        print("  interfaces (): ", i.interfaces(include_ifnames=True))
        # print("  interfaces (): ", i.interfaces(include_ifnames=True, include_default=True))
        print("  has_interface (): ", i.has_interface("lo0"))


# Generated at 2022-06-20 17:50:56.918696
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert repr(DarwinNetworkCollector)

# Generated at 2022-06-20 17:50:59.562308
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:51:09.917431
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mod = DarwinNetwork()

    # Test normal ethernet, media=1000baseT, media_select=autoselect
    # media_type=1000baseT, media_options=none
    words = ['media:', 'autoselect', '(1000baseT)']
    current_if = dict()
    mod.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ''

    # test media is unknown, media_select and media_type are empty
    words = ['media:', 'none']
    current_if = dict()

# Generated at 2022-06-20 17:51:21.161462
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test for method parse_media_line of class DarwinNetwork
    """
    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': '(none)'}

    words = ['media:', 'autoselect', '100baseTX', '(100baseTX full-duplex)']
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)

# Generated at 2022-06-20 17:51:24.108622
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin', "Failed to create DarwinNetwork object."


# Generated at 2022-06-20 17:51:26.206557
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Initialize the DarwinNetwork object
    net_obj = DarwinNetwork()
    # Get the string representation of DarwinNetwork
    str(net_obj)

# Generated at 2022-06-20 17:51:31.518882
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This function is used to test the constructor of class DarwinNetwork
    """
    my_obj = DarwinNetwork(None, None, None)
    assert my_obj.platform == "Darwin"
    assert my_obj.get_options('\n') == ''
    assert my_obj.get_options(None) == ''



# Generated at 2022-06-20 17:51:33.129919
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:51:34.739128
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector({}, None)
    assert obj._fact_class._platform == "Darwin"

# Generated at 2022-06-20 17:51:50.225936
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test data
    # input
    words = ['media:', 'autoselect', '<unknown', 'type>']
    current_if = dict()
    ips = []
    # expected output
    expected_current_if = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'unknown type',
    }

    # test execution
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ips)

    assert current_if == expected_current_if

# Generated at 2022-06-20 17:51:59.294066
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    dnw = DarwinNetwork()
    med_line = ['media:', 'autoselect', '10baseT/UTP', '(<unknown type>)' ]
    current_if = {'device': 'en0', 'options': 'fake'}

    # Act
    dnw.parse_media_line(med_line, current_if, ['current_if'])

    # Assert
    actual = current_if['media']
    expected = 'Unknown'
    assert actual == expected, 'parse_media_line should set media = {}'.format(expected)

    actual = current_if['media_select']
    expected = 'autoselect'
    assert actual == expected, 'parse_media_line should set media_select = {}'.format(expected)

    actual = current_if['media_type']

# Generated at 2022-06-20 17:52:01.471904
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    f = DarwinNetworkCollector()
    assert f._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:52:11.292765
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    if_lines = ['media: <unknown type>', 'media: autoselect (1000baset', 'media: autoselect (1000baset <full-duplex>',
                'media: autoselect (1000baset <full-duplex> <tx-flow-control>)',
                'media: autoselect (10baset <half-duplex> <link-autoneg>)']


# Generated at 2022-06-20 17:52:17.592796
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    media_line = ['media:', '<unknown type>', 'autoselect']
    current_if = {}
    ips = {}
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'autoselect'

# Generated at 2022-06-20 17:52:19.197660
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test if the DarwinNetworkCollector class has been instantiated
    """
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:23.657285
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a unit test for the constructor of the class DarwinNetworkCollector
    """
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class is DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:52:28.162513
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    obj.collect()
    assert obj.facts['all_ipv4_addresses'] is not None
    assert obj.facts['all_ipv6_addresses'] is not None
    assert obj.facts['default_ipv4'] is not None

# Generated at 2022-06-20 17:52:30.196201
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test for DarwinNetworkCollector class
    """
    assert DarwinNetworkCollector._platform is 'Darwin'
    assert DarwinNetworkCollector._fact_class is DarwinNetwork
    assert isinstance(DarwinNetworkCollector()._fact_class(), DarwinNetwork) is True

# Generated at 2022-06-20 17:52:32.092440
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector.network_class == DarwinNetwork

# Generated at 2022-06-20 17:53:11.418031
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Without any input parameter
    darwinNetwork = DarwinNetwork()
    #
    # test parse_media_line function
    #
    # test case 1:
    # when current_if contains 'media' key, so that
    # self.parse_media_line('media', current_if, ips)
    # will do nothing and current_if['media']
    # will always be 'Unknown'
    #
    current_if = dict()
    current_if['media'] = "abcd1234"
    ips = list()
    darwinNetwork.parse_media_line("media", current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media'
    
    # test case 2:
    # when current_if does not contains '

# Generated at 2022-06-20 17:53:12.847698
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    DarwinNetwork()

# Generated at 2022-06-20 17:53:21.296119
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = dict()
    ips = dict()
    r = range(0, 9)
    current_if['name'] = 'en0'
    current_if['flags'] = list()
    current_if['ipv4'] = dict()
    current_if['ipv6'] = dict()
    current_if['ipv6']['scope'] = 'global'

    # test the None input
    assert darwin_net.parse_media_line(None, current_if, ips) == False

    # test empty list input
    assert darwin_net.parse_media_line([], current_if, ips) == False

    # test pass media line with 1 words

# Generated at 2022-06-20 17:53:32.818779
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'media': 'Unknown'}
    words = ['media:', 'autoselect', '10baseT/UTP', '(none)']
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == []

    current_if = {'media': 'Unknown'}
    words = ['media:', '<unknown', 'type>', '(none)']
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current

# Generated at 2022-06-20 17:53:41.769469
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    assert dn.parse_media_line([], {}, {}) == (None, False)  # Nothing happens when words is empty
    assert dn.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {}, {}) == (None, False)
    ifc_dict = {'media_select': 'autoselect', 'media': 'Unknown', 'media_type': 'unknown type'}
    assert dn.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == (None, True)
    assert dn.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == (None, True)

# Generated at 2022-06-20 17:53:45.403541
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    words = ['media:', '<unknown', 'type>', "status:", "active"]
    current_if = {}

    # Act
    DarwinNetwork.parse_media_line(None, words, current_if, None)

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

# Generated at 2022-06-20 17:53:47.156845
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'

# Generated at 2022-06-20 17:53:57.943325
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test without media options
    line = 'media: auto'
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(line.split(), current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert 'media_options' not in current_if

    # test with media options
    line = 'media: <unknown type> (autoselect)'
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(line.split(), current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:53:59.623406
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork('lo0', {'flags': 'UP'}, [])


# Generated at 2022-06-20 17:54:01.649670
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector(None, None, None, None)
    assert network.platform == 'Darwin'

# Generated at 2022-06-20 17:54:40.715897
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'
    assert net._get_interfaces.__name__ == 'parse_darwin_ifconfig_output'
    assert net._get_interfaces() == ''
    assert net._interfaces == {}
    assert net.get_interfaces() == {}

# Generated at 2022-06-20 17:54:48.037488
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {}
    ref_dict = {'media': 'Unknown'}
    words = ['media:', 'autoselect']
    DarwinNetwork().parse_media_line(words, test_dict, {})
    assert test_dict == ref_dict

    # test with options
    test_dict = {}
    ref_dict = {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': ['10baseT/UTP', '<flow-control>', 'full-duplex']}
    words = ['media:', 'autoselect', '(10baseT/UTP', '<flow-control>', 'full-duplex)']
    DarwinNetwork().parse_media_line(words, test_dict, {})
    assert test_dict == ref_dict

    # test with <unknown type>


# Generated at 2022-06-20 17:54:48.663351
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:56.373973
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line1 = ('media: <unknown type> <unknown subtype>',)
    test_line2 = ('media: Ethernet autoselect (none)',)
    test_line3 = ('media: Ethernet autoselect (1000baseT full-duplex,flow-control,rxpause,txpause)',)

    current_if = {}

    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this test checks this

    network_module = DarwinNetwork()
    network_module.parse_media_line(test_line1, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown type>'
    assert current_if['media_type'] == 'unknown subtype'

    # Test

# Generated at 2022-06-20 17:55:00.088778
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for constructor of class DarwinNetwork
    """
    # Run the constructor of class DarwinNetwork
    darwin_network = DarwinNetwork()

    # Test the platform property of class DarwinNetwork
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:55:09.616706
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    '''
    DarwinNetworkCollector instantiation test
    '''
    # get the path of facts/network/test_DarwinNetworkCollector.py
    import os
    test_file = os.path.abspath(__file__)
    # get the directory of facts/network/test_DarwinNetworkCollector.py
    test_dir = os.path.dirname(test_file)
    # get the root/ansible directory of facts/network/test_DarwinNetworkCollector.py
    ansible_dir = os.path.dirname(test_dir)
    # set the root directory for ansible
    os.chdir(ansible_dir)
    # instantiate DarwinNetworkCollector
    DarwinNetworkCollector()

if __name__ == '__main__':
    test_DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:20.848272
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for case when the media type contains whitespace
    line = 'media: <unknown type> 10baseT/UTP <full-duplex>'
    current_if = {'name': 'igb0', 'type': 'ether', 'macaddress': '00:0c:29:f9:80:d1'}
    expected_result = {
        'name': 'igb0', 'type': 'ether', 'macaddress': '00:0c:29:f9:80:d1',
        'media': 'Unknown',
        'media_select': '<unknown', 'media_type': 'unknown type',
        'media_options': 'full-duplex'
    }
    result = DarwinNetwork.parse_media_line(line, current_if)
    assert expected_result == result

    # Test for case when

# Generated at 2022-06-20 17:55:22.317106
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork(None)
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:55:24.552811
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    test_collector = DarwinNetworkCollector(None, None, None)
    assert(test_collector._fact_class == DarwinNetwork)
    assert(test_collector._platform == 'Darwin')


# Generated at 2022-06-20 17:55:27.480591
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:56:36.373465
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:56:44.390593
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinNetwork
    assert collector.config == {
        'gather_subset': ['!all', '!min'],
        'gather_network_resources': [
            'interfaces',
            'vlans',
            'bonds',
            'vrfs',
            'ip_addresses',
            'neighbors',
            'networks',
            'default_gateway',
            'dns',
            'routes',
            'bridge_interfaces',
        ]
    }

# Generated at 2022-06-20 17:56:46.445625
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()._fact_class._platform
    assert result == 'Darwin'


# Generated at 2022-06-20 17:56:48.416317
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    n = DarwinNetworkCollector()
    assert n.platform == 'Darwin'
    assert n.fact_class == DarwinNetwork


# Generated at 2022-06-20 17:56:49.391734
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collect = DarwinNetworkCollector()
    assert collect.platform == 'Darwin'
    assert collect.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:56:53.161823
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create an instance of DarwinNetwork
    dn = DarwinNetwork({}, {}, {})
    # Check if the instance is created properly.
    assert(isinstance(dn, DarwinNetwork))

# Generated at 2022-06-20 17:57:03.660250
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    args = {'destination': {'key': 'value'}}
    dn = DarwinNetwork(args)
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    current_if = dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    words = ['media:', 'autoselect', '(none)', 'status:', 'active']
    current_if = {}
    current_if = dn.parse_media_line(words, current_if, {})
    assert current_if['media_select'] == 'autoselect'
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    current

# Generated at 2022-06-20 17:57:06.805974
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:57:10.322430
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_facts = DarwinNetwork()
    assert str(type(network_facts)) == "<class 'ansible.module_utils.facts.network.generic_bsd.generic_bsd.GenericBsdIfconfigNetwork'>"


# Generated at 2022-06-20 17:57:18.643521
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {'name': 'en0'}
    ip = {
        'address': '10.0.1.1',
        'netmask': '255.255.255.0',
        'broadcast': '10.0.1.255',
    }
    m1 = ['media:', 'Ethernet', 'autoselect', '(100baseTX)']
    m2 = ['media:', '<unknown', 'type>']
    m3 = ['media:', 'Wi-Fi']

    for media in [m1, m2, m3]:
        iface['media_select'] = iface['media_type'] = iface['media_options'] = None
        DarwinNetwork.parse_media_line(media, iface, ip)