

# Generated at 2022-06-20 17:48:54.967715
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    interface_information = {
        'input_packets': '5',
        'output_packets': '3',
        'input_bytes': '155',
        'output_bytes': '217',
        'hwaddr': '00:00:00:00:00:00',
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'none',
        'media_options': 'none'
    }

# Generated at 2022-06-20 17:48:57.347286
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None, None)
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:48:59.067516
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:49:01.381649
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == 'Darwin'
    assert network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:49:07.258446
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface_data = {}
    words = ['media:', 'none', '(<unknown type>)', '(autoselect)']
    ips = []
    darwinNetwork = DarwinNetwork(interface_data)
    darwinNetwork.parse_media_line(words, interface_data, ips)
    assert interface_data['media'] == 'Unknown'

# Generated at 2022-06-20 17:49:11.308278
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result._platform == 'Darwin'
    assert result._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:49:23.407010
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    current_if = {'inet': [], 'inet6': []}
    ips = (None, None)

    # Simple case
    words = ['media:', 'autoselect', '(none)']
    current_if = DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    # Complex case
    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:49:28.661460
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    word_index = 0
    ips = None

    DarwinNetwork._parse_media_line(None, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:49:33.989585
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test = DarwinNetwork()
    result = test.parse_media_line(['media', 'manual', '<unknown type>'], {}, [])
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'manual'
    assert result['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:49:35.865466
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_obj = DarwinNetwork({}, None, None)


# Generated at 2022-06-20 17:49:47.551604
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    current_if = {'name': "en0"}
    ips = []

    words_good = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    net.parse_media_line(words_good, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == 'none'

    # case without media options
    words_good = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {'name': "en0"}
    net.parse_media_line(words_good, current_if, ips)
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-20 17:49:53.618510
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork('en1', 'en1 flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500 options=60<TSO4,TSO6>ether 00:1f:5b:ea:42:e2 inet6 fe80::21f:5bff:feea:42e2%en1 prefixlen 64 secured scopeid 0x8 inet 10.125.6.94 netmask 0xffffff00 broadcast 10.125.6.255 media: autoselect (1000baseT <full-duplex>) status: active ')
    assert darwin_network.name == 'en1'
    assert darwin_network.macaddr == '00:1f:5b:ea:42:e2'
    assert darwin_network

# Generated at 2022-06-20 17:49:54.621982
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Mock test
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-20 17:49:55.759146
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj != None

# Generated at 2022-06-20 17:50:04.628709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test line strings
    test_line_1 = '    media: autoselect (100baseTX <full-duplex>) status: active'
    test_line_2 = '    media: autoselect (none) status: inactive'
    test_line_3 = '    media: autoselect <unknown type> status: inactive'

    # Test object
    test_object = DarwinNetwork()

    # Expected output data
    expected_output_1 = {
        'media_select': 'autoselect',
        'media': 'Unknown',
        'media_type': '(100baseTX <full-duplex>)',
        'media_options': 'full-duplex'
    }

# Generated at 2022-06-20 17:50:08.316799
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print('*** Function test_DarwinNetwork() ***')
    mac = DarwinNetwork()
    print(mac)
    print('*** End of test_DarwinNetwork() ***\n')


# Generated at 2022-06-20 17:50:19.569883
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:50:28.781544
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.network.base import Network

    # test for a valid media line
    test_word_list = [
        'media:',
        'autoselect',
        '(1000baseT <full-duplex,flow-control>)',
    ]
    test_if = {
        'name': 'en0',
    }
    test_ip = {}
    DarwinNetwork.parse_media_line(DarwinNetwork, test_word_list, test_if, test_ip)
    assert test_if['media'] == 'Unknown'
    assert test_

# Generated at 2022-06-20 17:50:35.951244
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_instance = DarwinNetwork()

    words = ['media:', '<unknown', 'type>']
    current_if = {}
    my_instance.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None

# Generated at 2022-06-20 17:50:38.432400
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_DarwinNetwork = DarwinNetwork()
    assert test_DarwinNetwork is not None


# Generated at 2022-06-20 17:50:41.817604
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert(obj != None)


# Generated at 2022-06-20 17:50:43.450770
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:47.056815
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w = 'media: autoselect (<unknown type>)'
    iface = {}
    DarwinNetwork.parse_media_line(DarwinNetwork(), w.split(), iface, None)
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:50:58.216653
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if_dict = {'name': 'en0'}
    ips = []

    test_word_array = ['media:','none','status:' ]
    darwin_network.parse_media_line(test_word_array, current_if_dict, ips)
    assert current_if_dict['media'] == 'Unknown'
    assert current_if_dict['media_select'] == 'none'
    assert current_if_dict['media_type'] == 'status:'

    test_word_array = ['media:','none','status:' ]
    darwin_network.parse_media_line(test_word_array, current_if_dict, ips)
    assert current_if_dict['media'] == 'Unknown'

# Generated at 2022-06-20 17:51:03.642184
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    assert DarwinNetwork().platform == 'Darwin'
    assert DarwinNetwork.platform == 'Darwin'
    assert GenericBsdIfconfigNetwork is DarwinNetwork
    assert GenericBsdIfconfigNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:51:12.699493
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface_name = 'en0'

# Generated at 2022-06-20 17:51:23.799755
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    result = {
        'media': 'Unknown',
        'media_options': [],
        'media_select': 'none',
        'media_type': '<unknown type>'
    }
    darwinNetwork = DarwinNetwork()
    words = ['none', '<unknown', 'type>']
    darwinNetwork.parse_media_line(words, result, None)
    assert result == {
        'media': 'Unknown',
        'media_options': [],
        'media_select': 'none',
        'media_type': 'unknown type'
    }
    darwinNetwork = DarwinNetwork()
    words = ['none', '<unknown', 'type>', 'full-duplex,100Mbps,link=yes']
    darwinNetwork.parse_media_line(words, result, None)
    assert result

# Generated at 2022-06-20 17:51:25.897115
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:51:27.834555
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    devn = DarwinNetwork()
    assert devn is not None

# vim: fileencoding=utf-8 et ts=4 sts=4 sw=4

# Generated at 2022-06-20 17:51:37.467403
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:51:44.777662
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector, NetworkCollector)
    assert DarwinNetworkCollector._fact_class is DarwinNetwork
    assert DarwinNetworkCollector._platform is 'Darwin'

# Generated at 2022-06-20 17:51:54.754758
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_if = DarwinNetwork('test_network_if')
    network_if.parse_media_line(['media:', '1000baseTX', '(none)'], {}, [])
    assert network_if.interfaces['test_network_if']['media_select'] == '1000baseTX'
    assert network_if.interfaces['test_network_if']['media_type'] == '(none)'
    assert network_if.interfaces['test_network_if']['media_options'] == []
    network_if.parse_media_line(['media:', 'autoselect', '<unknown', 'type>', '(none)'], {}, [])
    assert network_if.interfaces['test_network_if']['media_select'] == 'autoselect'

# Generated at 2022-06-20 17:51:57.790791
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test that DarwinNetworkCollector() returns a NetworkCollector object with
    attribute collection_type equal to 'generic_bsd'
    """
    my_obj = DarwinNetworkCollector()
    assert my_obj.collection_type == 'generic_bsd'


# Generated at 2022-06-20 17:52:00.428649
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector != None

# Generated at 2022-06-20 17:52:01.382213
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net != None

# Generated at 2022-06-20 17:52:05.318979
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._fact_class.platform == 'Darwin'
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class.__doc__ != None

# Unit test DarwinNetworkCollector's extract_facts method

# Generated at 2022-06-20 17:52:13.617501
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Dictionary for test data
    test_data = []
    test_data.append({'words': ['media:', 'autoselect', 'status:', 'active'], 'type': 'Unknown'})
    test_data.append({'words': ['media:', 'none', 'status:', 'active'], 'type': 'Unknown'})
    test_data.append({'words': ['media:', 'autoselect (100baseTX <full-duplex>)'], 'type': 'Unknown'})
    test_data.append({'words': ['media:', 'autoselect', '(100baseTX', '<full-duplex>)'], 'type': 'Unknown'})

# Generated at 2022-06-20 17:52:15.331031
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork({})
    assert facts['has_ipv4']
    assert facts['has_ipv6']

# Generated at 2022-06-20 17:52:23.760450
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {'name': 'interface name'}
    dn = DarwinNetwork(module=True)

    # media line is different to the default FreeBSD one;
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this if/else helps
    words = ['media:','Installed','type','unknown','unknown','unknown','type','unknown','<unknown','type>']
    dn.parse_media_line(words, iface, {})
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Installed'
    assert iface['media_type'] == 'unknown type'
    assert iface['media_options'] == 'unknown unknown unknown type unknown'

    words = ['media:','<unknown','type>']

# Generated at 2022-06-20 17:52:34.314640
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test DarwinNetwork class parsing of line
    media: <unknown type>
    into a correct dict
    """
    current_if = {}
    current_if['media_select'] = 'unknown'
    current_if['media_type'] = 'type'
    current_if['media_options'] = {}
    current_if['media_options']['status'] = 'active'
    current_if['media_options']['supported'] = ['autoselect', 'none']
    current_if['media_options']['supported'] += ['10baseT/UTP', '10baseT-FDX/UTP']
    current_if['media_options']['supported'] += ['100baseTX', '100baseTX-FDX', '100baseTX-FDX-flow']

# Generated at 2022-06-20 17:52:50.422550
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:52:52.816262
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    coll = DarwinNetworkCollector()
    assert coll.platform == "Darwin"
    assert not coll.ignore_interface_list
    assert coll.fact_class == DarwinNetwork


# Generated at 2022-06-20 17:53:00.651180
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    def_dict = {'media': 'Unknown', 'media_select': 'none',
                'media_options': {}, 'media_type': ''}


# Generated at 2022-06-20 17:53:03.100870
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    test_DarwinNetworkCollector = DarwinNetworkCollector()
    assert test_DarwinNetworkCollector._fact_class == DarwinNetwork
    assert test_DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:53:13.700092
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'name': 'bridge100', 'type': 'bridge'}
    # test with 3 words
    test_words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    test_ip = []
    result_if = {'name': 'bridge100', 'type': 'bridge', 'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': []}
    DarwinNetwork.parse_media_line(test_words, test_if, test_ip)
    assert test_if == result_if
    # test with 4 words
    test_if = {'name': 'bridge100', 'type': 'bridge'}

# Generated at 2022-06-20 17:53:15.392185
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a unit test for DarwinNetworkCollector class
    """
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:53:16.996396
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:53:24.402532
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # Test case 1: Media line for interface with options
    words_1 = ['media:', 'autoselect', '(100baseTX)', 'full-duplex']
    current_if_1 = {}
    ips_1 = {}
    darwin_network.parse_media_line(words_1, current_if_1, ips_1)
    assert current_if_1 == {
        'media_options': ['full-duplex'],
        'media_select': 'autoselect',
        'media_type': '100baseTX',
        'media': 'Unknown'
    }

    # Test case 2: Media line for interface without options
    words_2 = ['media:', 'autoselect', '(100baseTX)']
    current_if_2 = {}


# Generated at 2022-06-20 17:53:28.294314
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network._platform == "Darwin"



# Generated at 2022-06-20 17:53:31.313193
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = {}
    iface = DarwinNetwork()
    iface.collect(facts)

    assert iface.fact_subclasses == ['lo', 'en0']
    assert facts['ansible_net_interfaces'] == ['lo0']

# Generated at 2022-06-20 17:53:48.214257
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This function test DarwinNetwork class for constructor.
    """
    x = DarwinNetwork()
    assert x.facts == {}
    assert x.facts['all_ipv4_addresses'] == []
    assert x.facts['all_ipv6_addresses'] == []
    assert x.facts['default_ipv4'] == {}
    assert x.facts['default_ipv6'] == {}


# Generated at 2022-06-20 17:53:51.366023
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork({'provider': 'TestProvider'})
    assert isinstance(obj, DarwinNetwork)
    assert obj._provider == {'provider': 'TestProvider'}


# Generated at 2022-06-20 17:53:57.783407
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = []
    # test for the Default case
    # words = ['media:', '10baseT/UTP', '(<unknown type>', '-', 'autoselect)']
    # expected = {'media': 'Unknown', 'media_select': '10baseT/UTP', 'media_type': 'unknown type', 'media_options': '-autoselect'}
    # dn.parse_media_line(words, current_if, ips)
    # assert expected == current_if
    # test for the condition where len(words) < 4
    # words = ['media:', '10baseT/UTP', '(<unknown type>']
    # expected = {'media': 'Unknown', 'media_select': '10baseT/UTP', '

# Generated at 2022-06-20 17:54:01.476615
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    constructor_test_data = [
        {'set': 'Darwin', 'expected': DarwinNetworkCollector},
    ]
    r = NetworkCollector.create_collector(constructor_test_data[0]['set'])
    assert isinstance(r, constructor_test_data[0]['expected'])

# Generated at 2022-06-20 17:54:03.022492
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:54:06.223757
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for DarwinNetwork class."""
    n = DarwinNetwork()
    assert n.platform == 'Darwin'

    # test if we can create a class of the correct type and it has the correct platform attribute
    fact_class = n.collect()
    assert fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:54:07.717216
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:15.947965
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_ips = {}
    key = ('media', 'media_select', 'media_type', 'media_options')

    words = ['media:', 'none', 'status:', 'active']
    DarwinNetwork.parse_media_line(None,  words, test_if, test_ips)
    assert test_if[key[0]] == 'Unknown'
    assert test_if[key[1]] == words[1]
    assert test_if[key[2]] is None
    assert test_if[key[3]] is None

    words = ['media:', 'Wi-Fi', '(autoselect)', 'status:', 'active']
    DarwinNetwork.parse_media_line(None,  words, test_if, test_ips)
    assert test_if[key[0]] == 'Unknown'

# Generated at 2022-06-20 17:54:18.719205
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    A basic test of the constructor of DarwinNetworkCollector
    """
    # Just create a simple object of DarwinNetworkCollector
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)

# Generated at 2022-06-20 17:54:19.283601
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:52.411931
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork({})
    current_if = {}
    words = ['media:', '<unknown', 'type>', '(none)']
    darwin.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    words = ['media:', 'autoselect', '(none)']
    darwin.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] is None

# Generated at 2022-06-20 17:55:02.393744
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    cls = DarwinNetwork()

    # test case 1: media line with 4 words
    media_line = ['media:', '<unknown type>', '(none)', 'full-duplex']
    current_if = dict()
    ips = dict()
    cls.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == media_line[1]
    assert current_if['media_type'] == media_line[2][1:-1]
    assert current_if['media_options'] == cls.get_options(media_line[3])

    # test case 2: media line with 3 words
    media_line = ['media:', '<unknown type>', '(none)']
    current_if = dict

# Generated at 2022-06-20 17:55:03.544223
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.executable == '/sbin/ifconfig'

# Generated at 2022-06-20 17:55:04.027220
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:05.687403
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'


# Generated at 2022-06-20 17:55:15.122079
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # current_if dictionary to store values
    current_if = {}
    # 'media' value to test
    words = ['media:', 'autoselect', 'none']
    obj = DarwinNetwork()
    # parse_media_line is called using the object created above
    obj.parse_media_line(words, current_if, [])
    # assert 'media' value
    assert current_if['media'] == 'Unknown'
    # assert 'media_select' value
    assert current_if['media_select'] == 'autoselect'
    # assert 'media_type' value
    assert current_if['media_type'] == 'none'



# Generated at 2022-06-20 17:55:15.889378
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector



# Generated at 2022-06-20 17:55:18.533441
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-20 17:55:23.923701
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    ips = None
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if.get('media') == 'Unknown'
    assert current_if.get('media_select') == 'Unknown'
    assert current_if.get('media_type') == 'unknown type'
    assert current_if.get('media_options') is None

# Generated at 2022-06-20 17:55:28.181083
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # This test instantiates the class and uses it for parsing the output of
    # the 'ifconfig' command.  It is not a real unit test.
    ifc = DarwinNetwork()
    ifc_info = ifc.populate()
    print(ifc_info)