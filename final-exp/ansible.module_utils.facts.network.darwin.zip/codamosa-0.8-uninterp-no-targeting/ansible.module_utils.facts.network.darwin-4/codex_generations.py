

# Generated at 2022-06-20 17:49:01.027109
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create a mock 'module' object which is actually just a dummy class.
    class args:
        pass
    module = args()
    module.params = {
        'config': '',
        'gather_subset': [],
        'gather_network_resources': 'no'
    }
    dn = DarwinNetwork(module)

    # Test the init method and the _load_config method.
    assert dn.config == {}

    # Test the parse_interfaces method.
    assert dn.interfaces == {}

    # Test the parse_route_n method.
    assert dn.routes == {}

    # Test the parse_ipv6_neighbors method.
    assert dn.neighbors == {}


# Generated at 2022-06-20 17:49:09.990286
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_collector = DarwinNetworkCollector()

    # Do not test with all possible input permutations, it is handled
    # by the FreeBSD test case above

    # Media line is different to the FreeBSD one
    current_if = {}
    ips = {}
    words = ['media', 'unknown', 'type>']
    network_collector.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'unknown'
    assert current_if['media_type'] == 'type'
    assert current_if['media_options'] == ''

# Generated at 2022-06-20 17:49:17.565195
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': None}
    DarwinNetwork.parse_media_line(DarwinNetwork, ['media:', '<unknown', 'type>', '(none)'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ['none']

# Generated at 2022-06-20 17:49:25.530472
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    #Create instance of class DarwinNetwork
    darwin_network = DarwinNetwork()
    #Call the method parse_media_line
    current_if = dict()
    darwin_network.parse_media_line(['media:', 'autoselect', '<unknown type>'], current_if,dict())
    darwin_network.parse_media_line(['media:', 'ethernet', '10baseT/UTP'], current_if,dict())
    darwin_network.parse_media_line(['media:', '10baseT/UTP', 'status:', 'active'], current_if,dict())

# Generated at 2022-06-20 17:49:27.378099
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert isinstance(obj._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:49:31.491677
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface_test_in = ['media: <unknown type> status: inactive']
    iface_test_out = {'media': 'Unknown',
                    'media_select': '<unknown',
                    'media_type': 'unknown type'}

    iface = DarwinNetwork()
    iface.parse_media_line(iface_test_in[0].split(), {}, {})
    assert iface.interface == iface_test_out

# Generated at 2022-06-20 17:49:32.945725
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork({})
    assert net.platform == 'Darwin'

# Generated at 2022-06-20 17:49:42.004191
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = []
    c = DarwinNetwork()

    # Regular case
    words = ['media:', 'autoselect', '100baseTX', 'full-duplex']
    c.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == ['full-duplex']

    # Single word options
    current_if = {}
    ips = []
    words = ['media:', 'autoselect', '100baseTX', 'full-duplex', 'full-fx-mode']
    c.parse_media_line(words, current_if, ips)
    assert current_if['media_select']

# Generated at 2022-06-20 17:49:42.816314
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:47.251441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    # test with invalid input
    assert {} == net.parse_media_line(None, None, None)
    assert {} == net.parse_media_line([], None, None)
    assert {} == net.parse_media_line(['en0', 'autoselect'], None, None)
    assert {} == net.parse_media_line(['en1', 'media', '<unknown'], None, None)
    # test with valid input
    assert {'media_select': 'autoselect', 'media': 'Unknown'} == net.parse_media_line(['en0', 'autoselect'], {}, None)
    assert {'media_select': 'autoselect', 'media': 'Unknown', 'media_options': '10baseT/UTP <full-duplex>'} == net

# Generated at 2022-06-20 17:49:52.451140
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Make sure we construct the object correctly
    """
    netobj = DarwinNetworkCollector()
    assert netobj.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-20 17:49:54.561943
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    f = DarwinNetworkCollector()
    assert f.platform == 'Darwin'
    assert isinstance(f.fact_class(), DarwinNetwork)

# Generated at 2022-06-20 17:50:00.327180
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    # words = ['media:', 'autoselect', '(none)']
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == []



# Generated at 2022-06-20 17:50:01.145901
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    Collector = DarwinNetworkCollector()
    assert Collector.get_facts() is not None

# Generated at 2022-06-20 17:50:01.824324
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-20 17:50:03.495859
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test case for DarwinNetwork constructor """
    darwin_net = DarwinNetwork()
    assert darwin_net.get_file_path() == '/sbin/ifconfig'

# Generated at 2022-06-20 17:50:11.146862
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__module__ == 'ansible.module_utils.facts.network.darwin'
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._config_file == ['ifconfig', 'networksetup', 'route']
    assert DarwinNetworkCollector._collector == 'DarwinNetworkCollector'

# Generated at 2022-06-20 17:50:14.689369
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetwork.platform == 'Darwin'
    DarwinNetworkCollector_obj = DarwinNetworkCollector()
    assert DarwinNetworkCollector_obj._platform == 'Darwin'
    assert DarwinNetworkCollector_obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:17.008833
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinnetwork = DarwinNetwork()
    assert darwinnetwork.get_option('mtu') == 'mtu'


# Generated at 2022-06-20 17:50:26.946456
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    p = {'addr_family': None, 'active': True, 'address': None, 'broadcast': None, 'description': 'bridge0', 'duplex': None, 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST', 'UP', 'RUNNING'], 'inet': [{'address': 'fe80::ca0c:25ff:feae:b068', 'netmask': 'ffff:ffff:ffff:ffff::', 'peer': '::'}], 'macaddress': '02:a0:c2:ae:0b:69', 'mtu': 1500, 'netmask': None, 'permanent_address': None, 'promiscuous': False, 'type': 'Bridge'}
    m = ['media:', '<unknown', 'type>']
    n = DarwinNetwork()
    n.parse_

# Generated at 2022-06-20 17:50:30.364488
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:50:32.951596
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net is not None


# Generated at 2022-06-20 17:50:43.841983
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    test_DarwinNetwork = DarwinNetwork(module=None)
    test_DarwinNetwork.parse_media_line(['media:', 'autoselect', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert 'media_options' not in current_if

    current_if = dict()
    ips = dict()
    test_DarwinNetwork = DarwinNetwork(module=None)
    test_DarwinNetwork.parse_media_line(['media:', 'autoselect', '(none)', 'status:', 'inactive'], current_if, ips)
    assert current_

# Generated at 2022-06-20 17:50:45.174268
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_net = DarwinNetwork('ifconfig')
    assert test_net.platform == 'Darwin'

# Generated at 2022-06-20 17:50:49.478084
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector(None, None).collect()
    assert facts['all_ipv4_addresses'] == []
    assert facts['all_ipv6_addresses'] == []
    assert facts['default_ipv4']['address'] == '10.0.2.15'
    assert facts['default_ipv4']['interface'] == 'en0'

# Generated at 2022-06-20 17:50:50.633651
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:51.779242
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_DarwinNetwork = DarwinNetwork()
    assert my_DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:50:52.456188
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:50:54.553752
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'

# Generated at 2022-06-20 17:50:57.748679
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'


# Generated at 2022-06-20 17:51:12.365119
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:51:13.230166
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-20 17:51:24.328056
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    GenericBsdIfconfigNetwork.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == 'none'
    assert not current_if['media_type']

    current_if = dict()
    words = ['media:', 'ieee80211', '(autoselect)', 'status:', 'inactive']
    GenericBsdIfconfigNetwork.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'ieee80211'


# Generated at 2022-06-20 17:51:34.573330
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    This is a unit test for method parse_media_line of class DarwinNetwork
    """
    words1 = ['media', 'media_select', 'media_type', 'media_options']
    words2 = ['media', '<unknown', 'type>']
    current_if = {}
    ips = {}
    test_object1 = DarwinNetwork(fake_module)
    test_object1.parse_media_line(words1, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    assert 'media_options' in current_if
    test_object2 = DarwinNetwork(fake_module)

# Generated at 2022-06-20 17:51:41.046657
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_fixture = dict()
    test_fixture['iface'] = dict()
    test_fixture['current_if'] = dict()
    test_fixture['ips'] = dict()
    test_fixture['words'] = list()

    # test case 1 - media_select is missing
    # expected result: current_if['media'] is set to 'Unknown'
    test_fixture['current_if'] = {'media':'', 'media_select':'', 'media_type':'', 'media_options':''}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(test_fixture['words'], test_fixture['current_if'], test_fixture['ips'])
    assert test_fixture['current_if']['media'] == 'Unknown'

# Generated at 2022-06-20 17:51:48.361841
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fake_if = DarwinNetwork()
    test_media_lines = [
        ['media:', '<unknown type>'],
        ['media:', '10baseT', '/', 'full'],
        ]
    expected_medias = [
        ['Unknown', 'unknown type'],
        ['10baseT', 'full'],
        ]
    for media_line, expected_media in zip(test_media_lines, expected_medias):
        if_media = fake_if.parse_media_line(media_line, {}, [])
        assert if_media == expected_media

# Generated at 2022-06-20 17:51:52.109713
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork({'ansible_net_interfaces': {'eth0': {'flags': ['UP']}}})
    assert d['eth0']['flags'] == ['UP']

if __name__ == '__main__':
    test_DarwinNetwork()

# Generated at 2022-06-20 17:51:52.740150
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:00.425310
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create the object
    darwinnw = DarwinNetwork('test')

    # Create the fake line to parse
    words = ['2', 'Manual', '100baseTX', '<full-duplex>']

    # Create the object to fill
    current_if = dict()

    # Call the function to test. Call with a line with different content
    darwinnw.parse_media_line(words, current_if, [])

    # Check the result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Manual'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == {'full-duplex': None}

    # Create the fake line to parse

# Generated at 2022-06-20 17:52:02.995896
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector(None, None, None)
    assert dn._fact_class == DarwinNetwork
    assert dn._platform == 'Darwin'

# Generated at 2022-06-20 17:52:15.119939
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(NetworkCollector.collectors['Darwin'](), DarwinNetworkCollector)


# Generated at 2022-06-20 17:52:17.456161
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetwork.platform == 'Darwin'
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork



# Generated at 2022-06-20 17:52:25.285918
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    current_if = {'media': 'Unknown', 'media_select': 'media_select', 'media_type': 'media_type', 'media_options': 'media_options'}
    words = ['media:', 'media_select', 'media_type', 'media_options']
    DarwinNetwork.parse_media_line(current_if, words)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    assert current_if['media_options'] == 'media_options'
    # testing if/else
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line

# Generated at 2022-06-20 17:52:26.569226
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-20 17:52:28.630159
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class() is not None


# Generated at 2022-06-20 17:52:31.328335
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructor test, it checks if class DarwinNetworkCollector could be initialized with no arguments
    """
    collect = DarwinNetworkCollector()
    assert collect is not None

# Generated at 2022-06-20 17:52:33.014664
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-20 17:52:45.141350
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # First test: normal case
    # media line is of form
    # media: autoselect (<type>) <options list>
    words = ['media:', 'autoselect', '(100baseTX)', 'full-duplex']
    current_if = {'name': 'en0', 'type': 'ether'}
    ips = {'en0': {}}
    expected = {'name': 'en0', 'type': 'ether',
                'media': 'Unknown', 'media_select': 'autoselect',
                'media_type': '100baseTX', 'media_options': 'full-duplex'}
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ips)
    assert current_if == expected

    # Second test: a case where "type" isn't given

# Generated at 2022-06-20 17:52:54.493044
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # pylint: disable=attribute-defined-outside-init,bare-except
    # need a class for the try, since we have an exception handler
    class DarwinNetworkMock(object):
        def __init__(self):
            self.ansible_facts = {'ansible_interfaces': []}
            try:
                DarwinNetwork(self)
            except:
                pass
    dmac = DarwinNetworkMock()
    assert dmac.ansible_facts['ansible_network_resources']['interfaces']['bridge0']['mtu'] == 1500
    assert dmac.ansible_facts['ansible_network_resources']['interfaces']['bridge0']['has_ipv6']

# Generated at 2022-06-20 17:53:01.784945
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:53:28.402888
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mynet = DarwinNetwork()
    mynet.populate()
    mynet.get_facts()
    assert mynet.facts['all_ipv4_addresses'] == []

# Generated at 2022-06-20 17:53:28.961844
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:37.672956
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert ifc.interfaces['media'] == 'Unknown'
    assert ifc.interfaces['media_select'] == 'Unknown'
    assert ifc.interfaces['media_type'] == 'unknown type'
    ifc.parse_media_line(['media:', 'autoselect'], {}, {})
    assert ifc.interfaces['media_select'] == 'autoselect'
    ifc.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    assert ifc.interfaces['media_type'] == '(none)'

# Generated at 2022-06-20 17:53:39.440688
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_nw_collector = DarwinNetworkCollector()
    assert(darwin_nw_collector.platform == "Darwin")

# Generated at 2022-06-20 17:53:41.053657
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pass some test data to parse_media_line
    # assert the results
    # assert Exception
    pass



# Generated at 2022-06-20 17:53:42.182563
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == "Darwin"

# Generated at 2022-06-20 17:53:52.594509
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for media line 'autoselect (100baseTX <full-duplex>)'
    # A media line which specifies both media type and media mode
    testline = ['media:', 'autoselect', '(100baseTX', '<full-duplex>', ')']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(testline, current_if, ips)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' in current_if
    assert current_if['media_type'] == '100baseTX'
    assert 'media_mode' in current_if

# Generated at 2022-06-20 17:53:58.035092
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert hasattr(DarwinNetwork, 'platform')
    assert DarwinNetwork.platform == 'Darwin'
    assert hasattr(DarwinNetwork, 'parse_media_line')
    assert callable(DarwinNetwork.parse_media_line)
    assert hasattr(DarwinNetwork, 'parse_line')
    assert callable(DarwinNetwork.parse_line)

# Generated at 2022-06-20 17:54:01.654930
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _module = "ansible.module_utils.facts.network.darwin.DarwinNetworkCollector"
    _module_obj = __import__(_module, fromlist=['object'])
    dnc = _module_obj.DarwinNetworkCollector()
    assert dnc._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:54:02.871348
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork()

    assert(result.platform == 'Darwin')

# Generated at 2022-06-20 17:54:43.798410
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'
    assert dnc._fact_class is DarwinNetwork

# Generated at 2022-06-20 17:54:45.471277
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:54:55.010108
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', 'a/b/c', 'd/e/f', 'g/h/i'], {}, {})
    assert ifc.interfaces['media'] == 'Unknown'
    assert ifc.interfaces['media_select'] == 'a/b/c'
    assert ifc.interfaces['media_type'] == 'd/e/f'
    assert ifc.interfaces['media_options'] == {'g': 'h/i'}
    ifc.parse_media_line(['media:', 'auto', '10baseT/UTP', '(none)'], {}, {})
    assert ifc.interfaces['media'] == 'Unknown'
    assert ifc.interfaces['media_select'] == 'auto'

# Generated at 2022-06-20 17:55:04.685759
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    input_string = """
capabilities:5e8000<full-duplex,rx-checksumming,tx-checksumming,vlan-mtu,vlan-hwtagging,vlan-hwcsum,loopback,tso4,tso6>
supported:5e8000<full-duplex,rx-checksumming,tx-checksumming,vlan-mtu,vlan-hwtagging,vlan-hwcsum,loopback,tso4,tso6>
ether 00:a0:cc:00:00:00
media: autoselect (1000baseT <full-duplex>)
status: active
""".split('\n')
    media_select = "autoselect"
    media_type = "1000baseT <full-duplex>"

# Generated at 2022-06-20 17:55:11.914886
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    words = ['media:', 'autoselect', '(<unknown type>)', 'mediaopt', '(none)']
    media = iface.parse_media_line(words, {}, {})
    reference = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'unknown type',
        'media_options': 'none'
    }
    assert media == reference

# Generated at 2022-06-20 17:55:14.163160
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class._platform == 'Darwin'

# Generated at 2022-06-20 17:55:23.430311
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    current_if = {}
    media_line = 'media: <unknown type>'
    words = media_line.split()
    ips = ['192.168.1.1']
    darwin_if.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 17:55:29.982142
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Create test object
    darwinnet = DarwinNetwork()

    # make sure the filename looked for is what we expect
    assert darwinnet.filename == '/sbin/ifconfig'

    # test parsing of media line
    # test parsing of media line with media type unknown
    words = ['media:', '<unknown', 'type>']
    result = darwinnet.parse_media_line(words, {}, {})
    assert result['media_select'] == 'Unknown'
    assert result['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:55:40.569142
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', 'status:', 'inactive']
    current_if = {'media': 'Unknown'}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == None
    assert current_if['media_options'] == None
    
    words = ['media:', 'ieee80211', '<unknown', 'type>']
    current_if = {'media': 'Unknown'}
    ips = {}
    dn.parse_media_line(words, current_if, ips)

# Generated at 2022-06-20 17:55:44.002904
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fact_obj = DarwinNetwork()
    iface_dict = dict() # For this test, we only need the iface_dict
    media_line = 'media: autoselect (<unknown type>)'
    fact_obj.parse_media_line(media_line.split(), iface_dict, None)
    assert iface_dict['media'] == 'Unknown'
    assert iface_dict['media_select'] == 'autoselect'
    assert iface_dict['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:57:14.072142
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()
    darwinNetwork.get_facts()
    print(darwinNetwork.get_facts())

# Generated at 2022-06-20 17:57:20.189555
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_case_1 = ["media:", "--", "status:", "active"]
    result_1 = {'media': 'Unknown', 'media_select': '--'}
    assert DarwinNetwork.parse_media_line(test_case_1) == result_1

    test_case_2 = ["media:", "auto", "status:", "active"]
    result_2 = {'media': 'Unknown', 'media_select': 'auto'}
    assert DarwinNetwork.parse_media_line(test_case_2) == result_2

    test_case_3 = ["media:", "--", "status:", "active"]
    result_3 = {'media': 'Unknown', 'media_select': '--'}
    assert DarwinNetwork.parse_media_line(test_case_3) == result_3

   

# Generated at 2022-06-20 17:57:24.532707
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_inst = DarwinNetwork(None, 'Darwin')
    assert network_inst.platform == 'Darwin'

# Generated at 2022-06-20 17:57:27.333929
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Unit test for constructor
    assert DarwinNetworkCollector.__doc__ is not None
    myNetwork = DarwinNetworkCollector()
    assert myNetwork.__doc__ is not None


# Generated at 2022-06-20 17:57:35.107794
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'name': 'en5'}
    words = ["media:", "<unknown", "type>", "status:", "inactive"]
    darwin_if = DarwinNetwork()
    darwin_if.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:57:36.539584
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)



# Generated at 2022-06-20 17:57:46.212279
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    valid_words = ['media:', 'autoselect', '(none)']
    media_line = DarwinNetwork()
    media_line.parse_media_line(valid_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == []
    assert ips == {}

# Generated at 2022-06-20 17:57:53.368889
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_net_collector = DarwinNetworkCollector()
    assert darwin_net_collector._fact_class == DarwinNetwork
    assert darwin_net_collector._platform == 'Darwin'


# Generated at 2022-06-20 17:58:01.965173
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # get the Network class & test function
    dn = DarwinNetwork()
    pml = dn.parse_media_line

    # test method; word list is the split media line
    def _do_test(words, current_if_expected, ips_expected):
        # create the test parameter and expected results
        current_if = {}
        ips = {}
        # run the test
        pml(words, current_if, ips)
        # check current_if
        assert current_if == current_if_expected
        # check ips; check is empty by default
        assert ips == ips_expected

    # make tests using _do_test:
    # word list, current_if_expected, ips_expected
    _do_test([],
             {}, {})

# Generated at 2022-06-20 17:58:06.485517
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_collector = DarwinNetworkCollector()
    assert_equal(darwin_collector._platform, 'Darwin')
    assert_equal(darwin_collector._fact_class, DarwinNetwork)