

# Generated at 2022-06-20 17:49:01.776013
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:49:03.579190
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector


# Generated at 2022-06-20 17:49:05.491154
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    ifc = DarwinNetwork()
    ifc.get_facts()

# Generated at 2022-06-20 17:49:07.602464
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    # Just instantiating class should give the correct network platform
    assert network.get_platform() == 'Darwin'


# Generated at 2022-06-20 17:49:10.378190
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_object = DarwinNetwork()



# Generated at 2022-06-20 17:49:17.909785
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    media_data = 'supported media: autoselect <unknown type>'
    words = media_data.split()
    current_if = {}
    ips = None
    result = network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:49:19.346020
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Checks the creation of an instance
    """
    assert DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:21.086145
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test constructor of DarwinNetworkCollector class"""
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:25.197177
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    res = {}
    obj.parse_media_line(['media:','<unknown','type>'],res,[])
    assert res['media_select'] == 'Unknown', 'Failed to parse media_select'
    assert res['media_type'] == 'unknown type', 'Failed to parse media_type'

# Generated at 2022-06-20 17:49:32.382941
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    ifc = dict()
    line = ['<unknown type>']
    dn.parse_media_line(line, ifc, [{}, {}])
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'Unknown'
    assert ifc['media_type'] == 'unknown type'
    ifc = dict()
    line = ['<unknown type>', 'options', 'here']
    dn.parse_media_line(line, ifc, [{}, {}])
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'Unknown'
    assert ifc['media_type'] == 'unknown type'
    assert ifc['media_options'] == 'options'
    ifc = dict()

# Generated at 2022-06-20 17:49:42.832989
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    words = ['media', 'auto', 'full-duplex']
    expected = {'media_select': 'auto', 'media_type': 'full-duplex', 'media': 'Unknown'}
    darwin_network.parse_media_line(words, current_if, ips={})
    assert current_if == expected
    words = ['media', '100baseTX', '<full-duplex>']
    expected = {'media_select': '100baseTX', 'media_type': 'full-duplex', 'media': 'Unknown'}
    darwin_network.parse_media_line(words, current_if, ips={})
    assert current_if == expected

# Generated at 2022-06-20 17:49:43.364437
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork



# Generated at 2022-06-20 17:49:51.352146
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork()
    input = [
        ['<unknown type>'.split(), {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>'}],
        ['<unknown type> unknown type'.split(), {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type unknown type'}],
        ['<unknown type> autoselect (100baseTX <full-duplex>)'.split(), {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type', 'media_options': {'autoselect': '', 'full-duplex': '', '100basetx': ''}}],
    ]

# Generated at 2022-06-20 17:49:52.577930
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork('')
    assert dn.facts

# Generated at 2022-06-20 17:50:02.335151
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    import os
    import sys
    import unittest

    class AnsibleModule:
        params = {
            'gather_subset': ['']
        }

        def __init__(self, **kwargs):
            self.params = kwargs

    # We need a fake AnsibleModule object
    am = AnsibleModule()

    # We need the environment variable KERBEROS_CCACHE_PATH
    os.environ.pop('KERBEROS_CCACHE_PATH', None)
    # We need an argv list with module path and class name
    sys.argv = ['', 'DarwinNetworkCollector']
    # Create an instance of the DarwinNetworkCollector class
    dnc = DarwinNetworkCollector.from_module(am)
    assert dnc.platform == 'Darwin'
    # For inheritance from Generic

# Generated at 2022-06-20 17:50:03.039144
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector(None, None, None)

# Generated at 2022-06-20 17:50:14.602154
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork()
    current_if = {'macaddress': 'ba:db:1e:eb:ee:f', 'inet': '10.0.0.1',
            'media_select': 'autoselect', 'media_type': '802.11n'}
    darwin.parse_media_line(['media:','autoselect','802.11n',
        '(11n)','status:','inactive'], current_if, False)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '802.11n'
    assert current_if['media_options'] == {'11n': None}

# Generated at 2022-06-20 17:50:21.704961
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_words = ["media:", "<unknown", "type>", "(autoselect)"]
    current_if = {}
    ips = []
    d_net = DarwinNetwork()
    d_net.parse_media_line(media_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == '(autoselect)'



# Generated at 2022-06-20 17:50:23.759820
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector

# Functional test for constructor of class DarwinNetworkCollector

# Generated at 2022-06-20 17:50:31.464483
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    words = ['media:', '<unknown type> status:', 'inactive']
    dn.parse_media_line(words, current_if, ips)
    assert words[1] == '<unknown' and words[2] == 'type>'
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert not current_if['media_options']

    current_if = {}
    words = ['media:', 'autoselect status:', 'active']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:50:37.979274
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.up == 1
    assert obj.running == 1

# Generated at 2022-06-20 17:50:46.825128
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # create an instance of DarwinNetwork for testing
    darwin_network = DarwinNetwork()

    # test parse_media_line with normal scenario

# Generated at 2022-06-20 17:50:49.715256
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructor test of DarwinNetworkCollector
    """
    assert (DarwinNetworkCollector._fact_class == DarwinNetwork)
    assert (DarwinNetworkCollector._platform == 'Darwin')

# Generated at 2022-06-20 17:50:53.345762
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test class DarwinNetworkCollector"""
    darwinNetworkCollector = DarwinNetworkCollector()
    assert darwinNetworkCollector
    assert darwinNetworkCollector.__class__.__name__ == 'DarwinNetworkCollector'


# Generated at 2022-06-20 17:50:54.593681
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__doc__

# Generated at 2022-06-20 17:50:56.865699
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-20 17:51:05.260674
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # input
    line = 'media: <unknown type> <unknown subtype>'
    # expected output
    result = {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type',
        'media_options': 'unknown subtype'
    }
    # instantiate collector
    collector = DarwinNetworkCollector()
    # instantiate fact class
    fact = collector._fact_class()
    # instantiate fact
    fact.parse_media_line(line.split(' '), {}, {})
    # test
    assert fact.current_if == result

# Generated at 2022-06-20 17:51:13.133807
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create test object (because we need to call it with a class)
    dnw = DarwinNetwork()

    # test input as a list of strings
    assert dnw.parse_media_line(['media:', 'manual', '10baseT/UTP', '<full-duplex>'], {}, []) == {'media': 'Unknown', 'media_select': 'manual', 'media_type': '10baseT/UTP', 'media_options': 'full-duplex'}

    # test input with bridge interface
    assert dnw.parse_media_line(['media:', '<unknown', 'type>'], {}, []) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-20 17:51:20.741503
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    test_if = {}
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words
    words = ['media:', '<unknown', 'type>']
    darwin_network.parse_media_line(words, test_if, [])
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'

# Generated at 2022-06-20 17:51:29.104885
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.get_facts = dict()

    # Test media type not available
    line = '<unknown type>'
    words = line.split()
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == dict()

# Generated at 2022-06-20 17:51:40.056111
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:42.320738
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == "Darwin"
    assert obj.fact_class == DarwinNetwork


# Generated at 2022-06-20 17:51:44.861611
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-20 17:51:46.736560
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._fact_class.platform == 'Darwin'
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:51:54.706179
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = "media: autoselect <unknown type> status: inactive".split()
    # create an instance of the DarwinNetwork class
    darwin_network = DarwinNetwork()
    # call the method parse_media_line of the DarwinNetwork class
    darwin_network.parse_media_line(words, current_if, None)
    # check if the media_select is set properly
    assert current_if['media_select'] == 'autoselect'
    # check if the media_type is set properly
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:51:56.497509
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.fact_class == 'generic_bsd'
    assert d.platform == 'Darwin'



# Generated at 2022-06-20 17:51:57.074746
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:59.199424
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-20 17:52:03.643206
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    assert d.parse_media_line(['<unknown', 'type>'], {}, {}) == \
           {'media': 'Unknown', 'media_select': 'unknown type'}


# Generated at 2022-06-20 17:52:08.291478
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    c1 = DarwinNetwork()
    c2 = DarwinNetwork(None, None)
    c1_dict = c1.__dict__
    c2_dict = c2.__dict__
    for key in c1_dict.keys():
        assert key in c2_dict.keys()
        assert c1_dict[key] == c2_dict[key]


# Generated at 2022-06-20 17:52:30.902464
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin = DarwinNetworkCollector()
    assert darwin.platform == 'Darwin'
    assert darwin._fact_class.platform == 'Darwin'
    assert darwin._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:52:33.014054
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.get_file_path() == '/sbin/ifconfig'
    assert network.platform == 'Darwin'

# Generated at 2022-06-20 17:52:36.678204
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:52:38.423270
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()
    assert darwinNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:52:41.875107
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'



# Generated at 2022-06-20 17:52:44.631909
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert hasattr(DarwinNetworkCollector, '_fact_class')
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:52:49.804214
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_iface = DarwinNetwork()
    mac_iface.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert mac_iface.current_if['media'] == 'Unknown'
    assert mac_iface.current_if['media_select'] == 'Unknown'
    assert mac_iface.current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:52:56.260644
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()

    # parse_media_line is using list.pop() - convert string to list
    words = 'media: autoselect status: inactive'.split()
    current_if = {'media': None}
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == words[1]
    assert current_if['media_type'] == words[2][1:-1]
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:53:02.698243
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    dn = DarwinNetwork()
    words = ': autoselect status: active'.split()
    dn.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'
    assert current_if['media_options'] == 'active'

    words = ': <unknown type> status: active'.split()
    current_if = {}
    dn.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_

# Generated at 2022-06-20 17:53:05.630343
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Unit test for constructor of class DarwinNetworkCollector
    """
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:45.534101
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:53:54.888582
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test data to call method
    words_test = ['media:', 'autoselect', '(autoselect)', 'status:']
    current_if = dict()
    ips = dict()
    # Expected result
    expected_media_select = 'autoselect'
    expected_media_type = 'autoselect'
    expected_media_options = None

    # Call method to test
    DarwinNetwork(dict()).parse_media_line(words_test, current_if, ips)

    # Check results
    assert current_if['media_select'] == expected_media_select
    assert current_if['media_type'] == expected_media_type
    assert current_if['media_options'] == expected_media_options


# Generated at 2022-06-20 17:54:00.431595
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    import json

    obj = DarwinNetworkCollector()
    # Need to be able to construct an instance for this to work
    assert obj is not None

    # _fact_class must be set to DarwinNetwork
    assert obj._fact_class == DarwinNetwork

    # _platform must be set to 'Darwin'
    assert obj._platform == 'Darwin'


# Generated at 2022-06-20 17:54:01.921877
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network._fact_class._platform == 'Darwin'

# Generated at 2022-06-20 17:54:03.132535
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert instance is not None

# Generated at 2022-06-20 17:54:04.257628
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Test If instance is correctly created
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:15.144286
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    macDarwinNetwork = DarwinNetwork()
    macDarwinNetwork.media_select = "media_select"
    macDarwinNetwork.media_type = "media_type"
    macDarwinNetwork.media_options = "media_options"

    macDarwinNetwork.parse_media_line(['e1000g0:', 'autoselect', '<unknown type>'], macDarwinNetwork.interfaces, macDarwinNetwork.interfaces)
    macDarwinNetwork.parse_media_line(['e1000g0:', 'manual', '100baseTX', '(full-duplex,rxpause,txpause)'], macDarwinNetwork.interfaces, macDarwinNetwork.interfaces)

    assert macDarwinNetwork.media_select == "media_select"
    assert macDarwinNetwork.media_type == "media_type"
   

# Generated at 2022-06-20 17:54:20.751710
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(["media:", "<unknown_type>", "(unknown_type)"], {}, [])

    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == '<unknown_type>'
    assert ifc['media_type'] == 'unknown_type'
    assert ifc['media_options'] is None

# Generated at 2022-06-20 17:54:21.313827
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:22.890314
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Test class constructor"""

    obj = DarwinNetworkCollector()
    assert obj._facts['network']

# Generated at 2022-06-20 17:54:53.225439
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:03.125344
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_input_values = {
        'input': (['media:', 'IEEE', '802.11', '(autoselect)'], '', '', {}, {}, {}, True),
        'expected_output': {'media_type': '802.11',
                            'media_select': 'IEEE',
                            'media': 'Unknown',
                            'media_options': [(['autoselect'], {})]
                            }

    }
    test_network_class = DarwinNetwork()

# Generated at 2022-06-20 17:55:03.918790
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork(None)
    assert network is not None

# Generated at 2022-06-20 17:55:07.701040
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test constructor
    platform_network_collector = DarwinNetworkCollector()
    # test _fact_class attribute
    assert platform_network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:55:19.007710
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface_dict = {}
    iface = DarwinNetwork()
    iface.parse_media_line(['media:', 'autoselect', '(none)'], iface_dict, {})
    assert iface_dict['media_select'] == 'autoselect'
    assert iface_dict['media_type'] == '(none)'
    assert iface_dict['media_options'] == ''
    iface_dict = {}
    iface.parse_media_line(['media:', '10baseT/UTP', '(none)'], iface_dict, {})
    assert iface_dict['media_select'] == '10baseT/UTP'
    assert iface_dict['media_type'] == '(none)'
    assert iface_dict['media_options'] == ''
    iface_dict = {}
    iface

# Generated at 2022-06-20 17:55:20.138607
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = {'device_links': {}}
    DarwinNetworkCollector(facts)

# Generated at 2022-06-20 17:55:25.041187
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': 'Unknown',
                  'media_select': '',
                  'media_type': '',
                  'media_options': {}}
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(None, words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:55:28.038772
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    # check if d is instance of DarwinNetwork
    assert isinstance(d, DarwinNetwork)


# Generated at 2022-06-20 17:55:37.657270
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from mock import Mock
    from ansible.module_utils.facts.network.generic_bsd import MediaOption

    words = ['media:', '<unknown', 'type>']
    dn = DarwinNetwork({})
    assert dn.parse_media_line(words, dict(), dict()) == dict(
        media='Unknown'
    )

    words = ['media:', 'IEEE802.11', 'autoselect', '(unknown)']
    dn = DarwinNetwork({})
    assert dn.parse_media_line(words, dict(), dict()) == dict(
        media='IEEE802.11',
        media_select='autoselect',
        media_type='unknown',
        media_options=[MediaOption('unknown')]
    )

# Generated at 2022-06-20 17:55:46.220327
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Case 1: standard case
    iface1 = {}
    words1 = ['media:', 'autoselect', '(none)', 'status:', 'inactive', 'media:', 'autoselect', '1000baseT']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words1, iface1, {})
    assert iface1['media'] == 'Unknown'
    assert iface1['media_select'] == 'autoselect'
    assert iface1['media_type'] == '(none)'

    # Case 2: bridge interface
    iface2 = {}
    words2 = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words2, iface2, {})