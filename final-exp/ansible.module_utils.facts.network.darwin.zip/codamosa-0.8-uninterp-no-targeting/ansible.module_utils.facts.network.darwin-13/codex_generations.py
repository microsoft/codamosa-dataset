

# Generated at 2022-06-20 17:48:50.163231
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == "Darwin"


# Generated at 2022-06-20 17:48:53.661541
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector.platform == "Darwin"
    assert network_collector._network_class == DarwinNetwork

# Generated at 2022-06-20 17:48:56.725062
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert dn.flags == ['W', 'R', 'L', 'B', 'D', 'U']

# Generated at 2022-06-20 17:48:58.250222
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    n = DarwinNetwork()
    assert n.platform == 'Darwin'

# Generated at 2022-06-20 17:49:09.363733
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    iface.parse_media_line(["media:", "auto", "(100baseTX <full-duplex>)"], 0, 0)
    assert iface.iface['media'] == 'Unknown'
    assert iface.iface['media_select'] == 'auto'
    assert iface.iface['media_type'] == '100baseTX <full-duplex>'
    iface.parse_media_line(["media:", "<unknown", "type>"], 0, 0)
    assert iface.iface['media'] == 'Unknown'
    assert iface.iface['media_select'] == 'Unknown'
    assert iface.iface['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:49:11.255128
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Creates an instance of DarwinNetwork
    """
    net = DarwinNetwork()
    assert net is not None
    assert net.platform == 'Darwin'


# Generated at 2022-06-20 17:49:13.377580
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:49:18.529469
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test if parsing is fine with media set to "<unknown type>"
    iface = {}
    word = "media: <unknown type>"
    iface_expected = {'media_select': '<unknown', 'media_type': 'type'}
    DarwinNetwork(None).parse_media_line(word.split(), iface, None)
    assert iface_expected == iface

# Generated at 2022-06-20 17:49:27.959343
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_ifconfig_output1 = dict()
    darwin_ifconfig_output1['all_interfaces'] = ['lo0', 'gif0', 'stf0', 'en0', 'en1', 'en2', 'en3', 'p2p0', 'awdl0', 'bridge0', 'utun0']
    darwin_ifconfig_output1['lo0'] = {}
    darwin_ifconfig_output1['lo0']['device_type'] = 'loopback'
    darwin_ifconfig_output1['lo0']['macaddress'] = None
    darwin_ifconfig_output1['lo0']['inet'] = ['127.0.0.1']

# Generated at 2022-06-20 17:49:29.080769
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork({})
    assert dn.platform == 'Darwin'

# Generated at 2022-06-20 17:49:34.510896
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()

    for key in darwin_network.__dict__.keys():
        assert darwin_network.__dict__[key] == DarwinNetwork.__dict__[key]


# Generated at 2022-06-20 17:49:37.764914
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    _fact_class=DarwinNetwork
    _platform='Darwin'
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == DarwinNetworkCollector._platform

# Generated at 2022-06-20 17:49:47.592474
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', '(unknown)' ,'status:', 'active']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown'
    assert current_if['media_options'] is None

    words = ['media:', 'autoselect', '(100baseTX)' ,'status:', 'active']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_

# Generated at 2022-06-20 17:49:50.694341
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    net_collector = DarwinNetworkCollector()
    assert net_collector._platform == 'Darwin'


# Generated at 2022-06-20 17:50:00.596785
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'media': 'Unknown',
               'media_select': 'autoselect',
               'media_type': '<unknown type>',
               'media_options': 'none'}

    test_if_type = {'media_select': '10base5/AUI',
                    'media_type': 'BNC/AUI'}

    test_if_more_options = {'media_select': 'none',
                            'media_type': '<unknown type>',
                            'media_options': 'none'}

    test_if_words = ['media:', 'autoselect', '<unknown type>', 'none']
    test_if_words_type = ['media:', '10base5/AUI', 'BNC/AUI']

# Generated at 2022-06-20 17:50:11.251043
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Init the DarwinNetwork class
    current_if = dict()
    darwinNet = DarwinNetwork(current_if)
    # Define the arguments
    words = []
    ips = []
    # Test case 1
    words = ['media:', '<unknown', 'type>', '(none)']
    darwinNet.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}
    # Test case 2
    words = ['media:', 'autoselect', '(none)']
    darwinNet.parse_media_line(words, current_if, ips)
   

# Generated at 2022-06-20 17:50:11.847563
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:50:13.254897
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork({})
    # init, only sets some attributes
    assert d._platform == 'Darwin'
    assert d.facts == {}
    assert d.config == '/sbin/ifconfig -a'



# Generated at 2022-06-20 17:50:24.661109
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ''' Test function parse_media_line of class DarwinNetwork '''
    # Setup
    words = ["media:", "autoselect", "status:", "inactive"]  # Test line in ifconfig
    current_if = {
        "name": "en0", "type": "Ethernet", "macaddress": "00:00:00:00:00:00",
        "mtu": "1500", "metric": "0", "ipv6": [], "ipv4": []
    }  # Test current_if dict
    ips = None  # Not used in this function

    # Expected output: current_if with media keys set

# Generated at 2022-06-20 17:50:34.723315
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    test_if = {
        'media': '',
        'media_select': '',
        'media_options': '',
        'media_type': ''
    }

    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this if/else helps
    test_words_unknown_type = ['media:', '<unknown', 'type>']
    dn.parse_media_line(test_words_unknown_type, test_if, [])

    assert (test_if['media_select'] == 'Unknown')
    assert (test_if['media_type'] == 'unknown type')

