

# Generated at 2022-06-20 17:48:49.467182
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Instantiate a DarwinNetworkCollector()
    DarwinNetworkCollector = DarwinNetworkCollector()

    # Assert the values of the DarwinNetworkCollector attributes
    assert DarwinNetworkCollector._fact_class == DarwinNetwork
    assert DarwinNetworkCollector._platform == 'Darwin'



# Generated at 2022-06-20 17:48:51.610731
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert facts._fact_class == DarwinNetwork
    assert facts._platform == 'Darwin'


# Generated at 2022-06-20 17:48:54.863670
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d.platform == 'Darwin'


# Generated at 2022-06-20 17:48:55.832445
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:03.311961
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    test that the method
    :return: None
    '''
    iface = {'name': 'en0', 'type': 'ether', 'macaddress': 'enc:ca:ll:ad:dr:es',
             'mtu': 1500, 'metric': 1, 'ipv4': [], 'ipv6': []}
    ifconfig = DarwinNetwork(True, iface['name'], iface)
    # media line is different to the default FreeBSD one
    words = ['media:', 'autoselect', '<unknown type>']

# Generated at 2022-06-20 17:49:09.464106
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    interface = {}
    ips = []
    darwin_being_tested = DarwinNetwork()
    darwin_being_tested.parse_media_line(w, interface, ips)
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:49:16.696101
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork().platform == 'Darwin'
    assert DarwinNetwork().legacy_ifconfig_path == '/sbin/ifconfig'
    assert DarwinNetwork().legacy_route_path == '/sbin/route'
    assert DarwinNetwork().legacy_route_6_path == '/sbin/route'
    assert DarwinNetwork().legacy_netstat_path == '/usr/bin/netstat'
    assert DarwinNetwork().legacy_ip_path == '/sbin/ip'
    assert DarwinNetwork().legacy_brctl_path == '/usr/sbin/brctl'
    assert DarwinNetwork().legacy_iwconfig_path == '/usr/sbin/iwconfig'
    assert DarwinNetwork().legacy_iwlist_path == '/usr/sbin/iwlist'

# Generated at 2022-06-20 17:49:19.347310
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class is DarwinNetwork

# Unit tests for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:49:28.662552
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # type: () -> None
    """
    Unit test for method DarwinNetwork.parse_media_line of class DarwinNetwork
    """
    # Arrange
    raw_if = {
        "name": "bridge0",
        "type": "bridge",
        "macaddress": "02:42:ac:11:00:03",
        "mtu": 1500,
        "metric": 0,
        "ipv4": {
            "address": "172.17.0.3",
            "netmask": "255.255.0.0",
            "broadcast": "172.17.255.255"
        }
    }
    mac_network = DarwinNetwork()
    mac_network.ifaces = {'bridge0': raw_if}

    # Act

# Generated at 2022-06-20 17:49:37.080367
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork('name', 'en0', 'flags={"UP": true, "BROADCAST": true, "SMART": true, "RUNNING": true, "SIMPLEX": true, "MULTICAST": true}',
                        'ether', 'a0:99:9b:12:34:56', 'group', 'staff', 'mtu', '1500', 'options', 'nwid', 'Joyent_a099..',
                        'media:', 'autoselect', '(none)', 'status', 'inactive')



# Generated at 2022-06-20 17:49:40.694181
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()

    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:49:46.413960
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    current_if = {'media_select': 'Unknown', 'media_type': 'unknown type'}
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-20 17:49:49.170004
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().__class__.__name__ == 'DarwinNetworkCollector'
    assert DarwinNetworkCollector()._fact_class._platform == 'Darwin'
    assert DarwinNetworkCollector()._platform == 'Darwin'

# Generated at 2022-06-20 17:49:50.842808
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork


# Generated at 2022-06-20 17:49:53.856391
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Test to identify the DarwinNetworkCollector class constructor.
    """
    # create instance of DarwinNetworkCollector
    net_darwin = DarwinNetworkCollector()
    assert isinstance(net_darwin, DarwinNetworkCollector)



# Generated at 2022-06-20 17:50:00.597492
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    words = ['media:', 'autoselect', '(1000baseT)']
    current_if = {'device': 'lo0'}
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ''

# Generated at 2022-06-20 17:50:07.651175
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {'name': 'lo0'}
    lines = [
        ['  media: <unknown type> <unknown subtype>'],
    ]
    current_if = interface
    ips = {}
    DarwinNetwork().parse_media_line(lines[0], current_if, ips)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'
    assert interface['media_options'] == 'unknown subtype'



# Generated at 2022-06-20 17:50:12.813970
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
     data = DarwinNetwork().get_local_facts()
     assert 'default_ipv4' in data
     assert 'all_ipv4_addresses' in data
     assert 'interfaces' in data
     assert 'default_ipv6' in data
     assert 'all_ipv6_addresses' in data

# Generated at 2022-06-20 17:50:21.535977
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__doc__ is not None
    assert DarwinNetworkCollector.__init__ is not None
    assert DarwinNetworkCollector.get_network_facts is not None
    assert DarwinNetworkCollector.parse is not None
    assert DarwinNetworkCollector.process_parsed_data is not None
    assert DarwinNetworkCollector.get_data_from_parsed is not None
    assert DarwinNetworkCollector.interfaces is not None
    assert DarwinNetworkCollector.defaults is not None
    assert DarwinNetworkCollector._fact_class is not None
    assert DarwinNetworkCollector._platform is not None
    assert DarwinNetworkCollector.platform is not None


# Generated at 2022-06-20 17:50:26.700577
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    results = DarwinNetworkCollector()
    # As the DarwinNetworkCollector has not been initialised,
    # the following fields should be empty
    assert results.fact_class == None
    assert results.platform == None
    assert results.get_facts() == None
    assert results._exclude_unconfigured_interfaces == True
    assert results._excluded_interfaces == []
    assert results.ignore_lo == True

# Generated at 2022-06-20 17:50:31.551443
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetwork(), DarwinNetwork)


# Generated at 2022-06-20 17:50:43.108541
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dk_nw = DarwinNetwork()
    current_if = {}
    dk_nw.parse_media_line(['media:', 'auto', '1000baseT', '(none)'], current_if, None)
    assert current_if == {
        'media': 'Unknown',
        'media_select': 'auto',
        'media_type': '1000baseT',
        'media_options': 'none'
    }
    current_if = {}
    dk_nw.parse_media_line(['media:', '<unknown', 'type>'], current_if, None)
    assert current_if == {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type'
    }
    current_if = {}
    dk_nw.parse_media_

# Generated at 2022-06-20 17:50:46.129256
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    res = DarwinNetworkCollector()
    assert res._platform == 'Darwin'
    assert res._fact_class == DarwinNetwork
    assert res._options == {'config': ['-a']}
    assert res._config_file == '/sbin/ifconfig'

# Generated at 2022-06-20 17:50:47.017438
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector

# Generated at 2022-06-20 17:50:58.165666
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:51:07.893368
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork({})
    ips = []
    media_line = ['media:', 'autoselect (1000baseT <full-duplex>)']
    words = media_line[1].split()
    current_if = {'name': 'en0'}
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['full-duplex']



# Generated at 2022-06-20 17:51:14.726141
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:51:25.281462
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Verify the Darwin Network parse_media_line method.
    """

# Generated at 2022-06-20 17:51:25.855069
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:30.847021
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.tests.test_generic_bsd_ifconfig import TestGenericBsdIfconfigNetwork
    test = TestGenericBsdIfconfigNetwork()
    test.setUp()
    network = DarwinNetwork(test.parser)
    assert network.platform == 'Darwin'

# Generated at 2022-06-20 17:51:40.328817
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork(load_on_init=False)
    assert d


# Generated at 2022-06-20 17:51:46.516419
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_network = DarwinNetwork()
    # Test 1: bridge interface
    words = '<unknown type>'.split()
    current_if = {}
    ips = {}
    my_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:51:47.370008
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()


# Generated at 2022-06-20 17:51:57.273248
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Without spaces in the line
    dn1 = DarwinNetwork()
    dn1_words = dn1.parse_media_line(['media:autoselect',
                                      '<unknown-type>'],
                                      {'name': 'dummy'}, {'name': 'dummy'})
    assert(dn1_words['media'] == 'Unknown')
    assert(dn1_words['media_select'] == 'autoselect')
    assert(dn1_words['media_type'] == 'unknown-type')
    assert(dn1_words['media_options'] == {})

    # With spaces in the line
    dn2 = DarwinNetwork()

# Generated at 2022-06-20 17:52:08.293352
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import pprint
    dn = DarwinNetwork()
    current_if = dict()
    ips = dict()
    # Example output: ['media:', '<unknown type>', '<unknown subtype>']
    # Example output: ['media:', 'autoselect', '(none)']
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, ips)
    assert current_if ==  {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    words = ['media:', 'autoselect', '(none)']
    current_if = dict()
    dn.parse_media_line(words, current_if, ips)

# Generated at 2022-06-20 17:52:10.936314
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    n_c = DarwinNetworkCollector()
    assert n_c._fact_class is DarwinNetwork
    assert n_c._platform is 'Darwin'

# Generated at 2022-06-20 17:52:16.123046
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Unit test for class DarwinNetwork

    # create a test object of class DarwinNetwork
    testDarwinNetwork = DarwinNetwork()
    print("testDarwinNetwork.platform ====> " + testDarwinNetwork.platform)
    assert testDarwinNetwork.platform == 'Darwin'
    # test that the instance of DarwinNetwork does not have a 'platform' attribute
    assert not hasattr(testDarwinNetwork, 'platform')


# Generated at 2022-06-20 17:52:24.339670
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {}
    media_line = ['"en0"' , 'media:' , 'autoselect', '(1000baseT <full-duplex>)']
    DarwinNetwork().parse_media_line(media_line, iface, {})
    # test the results
    assert iface == {'media': 'Unknown',
                     'media_select': 'media:',
                     'media_type': 'autoselect',
                     'media_options': '(1000baseT <full-duplex>)'}
    media_line = ['"en0"' , 'media:' , '<unknown', 'type>', '(1000baseT <full-duplex>)']
    DarwinNetwork().parse_media_line(media_line, iface, {})
    # test the results

# Generated at 2022-06-20 17:52:34.598060
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from collections import namedtuple
    dn = DarwinNetwork([])
    current_if = namedtuple('current_if', ['media', 'media_select', 'media_type', 'media_options'])
    ips = {}
    words = ["media:", "autoselect", "100baseTX", "(100baseTX)"]
    results = dn.parse_media_line(words, current_if, ips)
    assert(results.media == 'Unknown')
    assert(results.media_select == "autoselect")
    assert(results.media_type == "100baseTX")
    assert(results.media_options == "(100baseTX)")
    words = ["media:", "<unknown", "type>", "(eee)"]

# Generated at 2022-06-20 17:52:36.523482
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_obj = DarwinNetwork()
    assert network_obj.platform == 'Darwin'

# Generated at 2022-06-20 17:52:55.854190
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', 'none']
    current_if = {}
    dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'

    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = {}
    dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == '(none)'

# Generated at 2022-06-20 17:53:02.509570
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line = [
        'media: autoselect (1000baseT <full-duplex>) status: active',
        'media: <unknown type> status: inactive',
        'media: <unknown type> (none) status: active',
        'media: IEEE 802.11 Wireless Ethernet autoselect status: inactive'
    ]
    test_interface = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '1000baseT',
        'media_options': 'full-duplex'
    }
    DarwinNetwork().parse_media_line(test_line[0].split(), test_interface, None)

# Generated at 2022-06-20 17:53:13.134418
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:53:13.865988
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d is not None

# Generated at 2022-06-20 17:53:22.257721
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()

    # line is not media line
    current_if = {}
    words = ['inet', '10.3.2.123', 'netmask', '0xffffff00', 'broadcast', '10.3.2.255']
    result = network.parse_media_line(words, current_if, None)
    assert result is None
    assert current_if == {}

    # valid line
    current_if = {}
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>', 'mediaopt', 'flow-control)']
    result = network.parse_media_line(words, current_if, None)
    assert result is None

# Generated at 2022-06-20 17:53:28.530373
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    current_if = {}
    dwn.parse_media_line(['media:', '<unknown type>', 'status:', 'inactive'], current_if, {})
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:53:35.469008
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>', 'autoselect'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ['autoselect']

# Generated at 2022-06-20 17:53:39.073079
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert isinstance(obj, DarwinNetworkCollector)
    assert obj._fact_class is not None
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'


# Generated at 2022-06-20 17:53:41.737062
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-20 17:53:42.833813
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()
    assert True

# Generated at 2022-06-20 17:54:04.910889
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinNetworkCollector = DarwinNetworkCollector()
    assert darwinNetworkCollector._platform == "Darwin"
    assert darwinNetworkCollector._fact_class._platform == "Darwin"

# Generated at 2022-06-20 17:54:05.983820
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork({}, [], [], [])
    assert True

# Generated at 2022-06-20 17:54:06.648825
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:09.450724
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.platform == 'Darwin'


# Generated at 2022-06-20 17:54:20.491194
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:54:22.428689
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    try:
        dummy = DarwinNetwork()
        assert 1 == 1
    except:
        assert 1 == 0, "Error creating DarwinNetwork"


# Generated at 2022-06-20 17:54:25.997694
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fact_class = DarwinNetwork()
    assert fact_class.parse_media_line(
        ['media:', '<unknown', 'type>', '(autoselect)'],
        None, None) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': ['autoselect']}

# Generated at 2022-06-20 17:54:37.645015
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'name': 'test_if'}
    test_ips = {'10.0.0.1': 'test'}
    network = DarwinNetwork()
    # Normal test

# Generated at 2022-06-20 17:54:39.045604
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_DarwinNetwork = DarwinNetwork()

    assert my_DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:54:46.588453
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', 'status:', 'inactive']
    current_if = {'media': 'unknown',
                  'media_select': 'unknown',
                  'media_type': 'unknown',
                  'media_options': 'unknown'}
    DarwinNetwork._parse_media_line(DarwinNetwork(), words, current_if, {'ipv4': {}, 'ipv6': {}})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] is None
    assert current_if['media_options'] == 'status: inactive'

# Generated at 2022-06-20 17:55:40.169536
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_nw_class = DarwinNetwork()
    assert darwin_nw_class.platform == 'Darwin'


# Generated at 2022-06-20 17:55:43.638241
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ construct a DarwinNetwork and ensure it has the proper attributes set to it by the constructor
    """

    facter = DarwinNetwork()
    facter.populate()
    result = facter.get_facts()
    assert 'interfaces' in result
    assert 'all_ipv4_addresses' in result
    assert 'all_ipv6_addresses' in result

# Generated at 2022-06-20 17:55:50.320355
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:55:58.332404
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    dn._mount_fs = []
    dn.populate()
    assert len(dn.interfaces) == 1  # we always have at least en0 exist
    assert 'ipv4' in dn.interfaces['en0']  # This is the first inet
    assert 'macaddress' in dn.interfaces['en0']
    assert dn.interfaces['en0']['macaddress'] == '00:00:00:00:00:00'
    assert 'mtu' in dn.interfaces['en0']

# Generated at 2022-06-20 17:55:59.957941
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'
    assert net._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:56:00.759796
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()

# Generated at 2022-06-20 17:56:07.648728
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dwn = DarwinNetwork()
    assert dwn.parse_media_line(["media:", "autoselect", "(100baseTX)"], {}, 0) == ({'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(100baseTX)'}, 0)
    assert dwn.parse_media_line(["media:", "autoselect", "(100baseTX", "(Half)"], {}, 0) == ({'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(100baseTX (Half)'}, 0)

# Generated at 2022-06-20 17:56:18.623441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    tested = DarwinNetwork()

    # media line is different to the default FreeBSD one
    # example from darwin 10.12.6
    words1 = ['supported', 'media', 'autoselect', '100baseTX', '(100baseTX-HD)', '100baseTX-FD', '(100baseTX-FD)', '10baseT', '(10baseT-HD)', '10baseT-FD', '(10baseT-FD)', '100baseFX', '100baseFX-FD', '(100baseFX-FD)']
    current_if1 = {}
    ips1 = []
    tested.parse_media_line(words1, current_if1, ips1)
    assert current_if1['media'] == 'Unknown'
    assert current_if1['media_select'] == 'autoselect'
    assert current_if1

# Generated at 2022-06-20 17:56:19.679584
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dnw = DarwinNetwork(None, None)



# Generated at 2022-06-20 17:56:23.955706
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    print('Constructing DarwinNetworkCollector instance')
    clct = DarwinNetworkCollector()
    print('DarwinNetworkCollector instance = ' + str(DarwinNetworkCollector))
    print('DarwinNetworkCollector config = ' + str(clct._config))
    assert clct._fact_class == DarwinNetwork
    assert clct._platform == 'Darwin'

# Generated at 2022-06-20 17:58:09.055126
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # test with a Darwin network interface
    source_data = dict(interfaces=dict(), routes=[] )
    source_data['interfaces']['lo0'] = dict(flags=['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
                                            inet=['127.0.0.1'], hwaddr='00:00:00:00:00:00',
                                            media=['<unknown type>'],
                                            status='active', mtu='16384', type='Ethernet')

# Generated at 2022-06-20 17:58:12.632732
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:58:21.141123
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    test_words = ['media:', '<unknown', 'type>', 'status:', 'active']
    test_current_if = {'media': 'Unknown'}
    test_ips = {}
    dn.parse_media_line(test_words, test_current_if, test_ips)
    assert test_current_if['media'] == 'Unknown'
    assert test_current_if['media_select'] == 'Unknown'
    assert test_current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:58:30.265492
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork

    The code is a bit brittle, because the media line can change,
    but I guess the test is better than nothing.
    """

    result = DarwinNetwork().parse_media_line(['media:','<unknown','type>','status:','active'], {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == '<unknown'
    assert result['media_type'] == 'unknown type'
    assert 'media_options' not in result

# Generated at 2022-06-20 17:58:31.246732
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:58:32.639687
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork().platform == 'Darwin'

# Generated at 2022-06-20 17:58:34.386767
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetworkCollector()
    out = obj.get_device_data()
    assert out is not None
    assert out['lo0']


# Unit tests for parsing of class DarwinNetwork

# Generated at 2022-06-20 17:58:46.565458
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    assert dn.parse_media_line([], {}, {}) == {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': {}}
    assert dn.parse_media_line(['media', 'Autoselect', '<unknown'], {}, {}) == {'media': 'Unknown', 'media_select': 'Autoselect', 'media_type': '<unknown', 'media_options': {}}
    assert dn.parse_media_line(['media', 'Autoselect', '<unknown type>'], {}, {}) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': {}}