

# Generated at 2022-06-20 17:48:58.603491
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_if = {'name': 'bridge0', 'enable_snmp': True}
    w = ['<unknown', 'type>']
    DarwinNetwork.parse_media_line(my_if, w)

    assert 'media' in my_if
    assert my_if['media'] == 'Unknown'
    assert 'media_select' in my_if
    assert my_if['media_select'] == 'Unknown'
    assert 'media_type' in my_if
    assert my_if['media_type'] == 'unknown type'
    assert 'media_options' not in my_if
    assert 'phy_address' not in my_if
    assert 'encapsulation' not in my_if

    w = ['media:', '<unknown', 'type>']

# Generated at 2022-06-20 17:49:09.601929
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    testobj1=DarwinNetwork()
    testobj1.parse_media_line(['media:', 'autoselect', '(none)'], current_if={}, ips={})
    assert testobj1.current_if['media'] == 'Unknown'
    assert testobj1.current_if['media_select'] == 'autoselect'
    assert testobj1.current_if['media_type'] == '(none)'

    testobj2=DarwinNetwork()
    testobj2.parse_media_line(['media:', '<unknown', 'type>'], current_if={}, ips={})
    assert testobj2.current_if['media'] == 'Unknown'
    assert testobj2.current_if['media_select'] == 'Unknown'

# Generated at 2022-06-20 17:49:12.956178
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    test_line1 = [ 'media:', 'autoselect', '(none)', 'full-duplex' ]
    test_line2 = [ 'media:', '<unknown', 'type>', '(none)', 'full-duplex' ]
    darwin_network.parse_media_line(test_line1, {}, {})

# Generated at 2022-06-20 17:49:23.411483
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test if media line is different to default FreeBSD one
    class DarwinTest(DarwinNetwork):
        # Test parse_media line
        def parse_media_line(self, words, current_if, ips):
            return

    words = ['media', 'autoselect', '(none)']
    current_if = {'media': 'unknown'}
    ips = {}
    d = DarwinTest()
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] is None
    assert current_if['media_options'] is None

    words = ['media', '<unknown', 'type>', 'status:', 'inactive']
    current_if

# Generated at 2022-06-20 17:49:24.110873
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork(None, None, None)

# Generated at 2022-06-20 17:49:25.656086
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'

# Generated at 2022-06-20 17:49:31.930055
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.network.dummy_output_darwin_ifconfig import IFACES
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    facts = DarwinNetwork(IFACES)
    assert isinstance(facts, GenericBsdIfconfigNetwork)
    assert facts.platform == 'Darwin'

# Generated at 2022-06-20 17:49:33.446639
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-20 17:49:35.279621
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    res = DarwinNetworkCollector()
    assert res.platform == 'Darwin'

# Generated at 2022-06-20 17:49:45.304193
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collector = NetworkCollector()
    # This is a list of possible media lines
    lines = ['media: <unknown type>',
             'media: autoselect (<unknown type> full-duplex)',
             'media: autoselect (1000baseT full-duplex)',
             'media: autoselect (<unknown type>) status: no carrier',
             'media: <unknown type> status: no carrier',
             'media: autoselect (10Gbase-LR full-duplex) status: inactive'
             ]

    # This is a list of media dicts we expect to get back from parse_media_line
    expected_media_list = []
    expected_media_list.append(collector.parse_media_line(lines[0].split(), dict(), dict()))

# Generated at 2022-06-20 17:49:53.197745
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )

    # To test the constructor we need to be able to instantiate
    # a subclass of DarwinNetworkCollector
    class TestDarwinNetworkCollector(DarwinNetworkCollector):
        def populate(self, collected_facts=None):
            pass

    net_collector_instance = TestDarwinNetworkCollector(module)
    # Just a basic sanity check on the DarwinNetworkCollector constructor
    assert(net_collector_instance.platform == 'Darwin')
    # Also check that we get DarwinNetwork as a fact class when we set
    # _platform to Darwin
    assert(net_collector_instance.get_fact_class() == DarwinNetwork)



# Generated at 2022-06-20 17:50:01.016211
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
   result = DarwinNetworkCollector()
   assert result.facts['all_ipv4_addresses'] == []
   assert result.facts['all_ipv4_addresses'] == []
   assert result.facts['default_ipv4'] == {}
   assert result.facts['default_ipv6'] == {}
   assert result.facts['interfaces'] == []
   assert result.facts['interfaces_ipv4'] == []
   assert result.facts['interfaces_ipv6'] == []
   assert result.facts['interface_ipv4'] == {}
   assert result.facts['interface_ipv6'] == {}

# Generated at 2022-06-20 17:50:02.741342
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_class = DarwinNetwork()
    assert test_class.platform == 'Darwin'
    assert test_class.media == 'Unknown'


# Generated at 2022-06-20 17:50:09.066674
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collector = DarwinNetworkCollector()
    fact_class = collector._fact_class
    fact_instance = fact_class({})
    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = {}
    ips = {}
    fact_instance.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:50:13.566689
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Class DarwinNetworkCollector constructor unit test
    """
    darwin_facts = DarwinNetworkCollector(None, None).get_all()

    # test the data
    assert isinstance(darwin_facts, dict)


# Generated at 2022-06-20 17:50:14.877557
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'

# Generated at 2022-06-20 17:50:17.088576
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc is not None

# Generated at 2022-06-20 17:50:18.978024
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin = DarwinNetworkCollector()
    assert darwin._fact_class._platform == 'Darwin'

# Generated at 2022-06-20 17:50:21.927545
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwinnwc = DarwinNetworkCollector()
    assert darwinnwc.platform == 'Darwin'
    assert issubclass(darwinnwc._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:50:22.761810
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:50:27.313809
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:50:31.346178
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    current_if = {}
    ips = {}

    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if


# Generated at 2022-06-20 17:50:35.013918
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network._platform == 'Darwin'
    assert network.platform == 'Darwin'
    assert network._fact_class == DarwinNetwork
    assert network.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:50:37.692224
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert dn._fact_class == DarwinNetwork



# Generated at 2022-06-20 17:50:39.375732
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    my_class=DarwinNetwork()

# Generated at 2022-06-20 17:50:48.092489
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # test 1
    media_line = ['media:', 'autoselect', '(none)']
    current_if = {'media': 'Unknown', 'media_select': 'None', 'media_type': 'none', 'media_options': {}}
    ips = {}
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}
    # test 2
    media_line = ['media:', '<unknown', 'type>']

# Generated at 2022-06-20 17:50:54.868816
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:50:57.202832
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    # TODO: create some/any tests
    return darwin


# Generated at 2022-06-20 17:51:08.202305
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collect = DarwinNetwork()
    # no media line
    words = []
    current_if = {}
    ips = []
    collect.parse_media_line(words, current_if, ips)
    assert 'media' not in current_if
    # default media line
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)', 'status:', 'active']
    current_if = {}
    ips = []
    collect.parse_media_line(words, current_if, ips)
    assert 'media' in  current_if
    # typical media line
    words = ['media:', 'manual', '10GbaseKR/Full', 'status:', 'inactive']
    current_if = {}
    ips = []

# Generated at 2022-06-20 17:51:10.143633
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(False, dict())

# Generated at 2022-06-20 17:51:23.206921
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    net = DarwinNetwork()
    net.parse_media_line(['media:', 'autoselect', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    net.parse_media_line(['media:', '<unknown', 'type>'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:51:30.421695
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is a unit test for the constructor of class DarwinNetworkCollector.
    The test will check for a successful instantiation of the class DarwinNetworkCollector by
    attempting to create an object of this class and see if an exception is thrown or not
    """
    # create an object of class DarwinNetworkCollector
    obj = DarwinNetworkCollector()

    # check that the object obj is an object of class DarwinNetworkCollector
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'


# Generated at 2022-06-20 17:51:32.020434
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinnet = DarwinNetwork({})
    assert darwinnet.platform == 'Darwin'

# Generated at 2022-06-20 17:51:33.881825
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc._fact_class is not None
    assert dnc._platform == 'Darwin'


# Generated at 2022-06-20 17:51:35.000705
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert 'Darwin' == module.platform

# Generated at 2022-06-20 17:51:41.373137
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fact_network_d = DarwinNetwork()
    words = ['media:', 'autoselect', '(100baseTX)']
    current_if = dict()
    ips = dict()
    fact_network_d.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': '(100baseTX)', 'media_options': dict()}
    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    ips = dict()
    fact_network_d.parse_media_line(words, current_if, ips)

# Generated at 2022-06-20 17:51:51.487187
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test for parse_media_line method of class DarwinNetwork
    """
    # Reference: Darwin 'ifconfig lo0' output (OS X 10.10)

    # expected results from method parse_media_line
    expected_results = {
        'media': 'Unknown',
        'media_type': 'none',
        'media_select': 'none'
    }

    # input: line to be parsed
    line = ('media: <unknown type> ')

    # attempt to parse line
    obj = DarwinNetwork()
    obj.parse_media_line(line.split(), {}, [])

    # compare expected results with actual results
    assert obj.current_if.get('media') == expected_results['media']
    assert obj.current_if.get('media_type') == expected_results['media_type']

# Generated at 2022-06-20 17:52:00.105211
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    p = DarwinNetwork()
    print("Testing parse_media_line")
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = []
    print("- Testing 1 word")
    p.parse_media_line(words[0:1], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert 'media_select' not in current_if
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if
    current_if = {}
    print("- Testing 2 words")
    p.parse_media_line(words[0:2], current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:52:01.550785
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:52:11.363673
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': None}
    line = 'media: unknown media type status: active'
    words = line.split()

    # Positive tests

# Generated at 2022-06-20 17:52:18.987162
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    nc = DarwinNetworkCollector()
    assert nc.platform == 'Darwin'


# Generated at 2022-06-20 17:52:23.657285
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    network_collector = collector.get_network_collector()
    assert network_collector.__class__.__name__ == 'DarwinNetworkCollector'



# Generated at 2022-06-20 17:52:30.052929
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    expected_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'status: inactive', 'media_options': {'status': 'inactive'}}
    inp = ['media:', 'autoselect', 'status:', 'inactive']
    assert(dwn.parse_media_line(inp, expected_if, None) == expected_if)



# Generated at 2022-06-20 17:52:31.996532
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Constructor for DarwinNetwork.
    this = DarwinNetwork({})
    assert this is not None

# Generated at 2022-06-20 17:52:33.646757
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    '''Unit test for DarwinNetworkCollector class'''
    # Test instantiation of the class
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:45.563783
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig_output = """  en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
	ether aa:bb:cc:dd:ee:ff
	inet6 fe80::9956:63ff:fe58:d8d8%en0 prefixlen 64 secured scopeid 0x5
	inet 192.168.0.2 netmask 0xffffff00 broadcast 192.168.0.255
	nd6 options=201<PERFORMNUD,DAD>
	media: <unknown type>
	status: active"""

    test_obj = DarwinNetwork()

# Generated at 2022-06-20 17:52:46.697743
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert(network)

# Generated at 2022-06-20 17:52:53.396198
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test case where media_select = '<unknown type>'
    darwin_ifconfig_content = """\
lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384
	options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>
	inet 127.0.0.1 netmask 0xff000000
	inet6 ::1 prefixlen 128
	inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
	nd6 options=201<PERFORMNUD,DAD>
gif0: flags=8010<POINTOPOINT,MULTICAST> mtu 1280
stf0: flags=0<> mtu 1280
"""
    darwin_network = DarwinNetwork()

# Generated at 2022-06-20 17:52:59.601413
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    #media_line = ['media:', '10baseT', '/', 'full', '(100baseTX)'],
    darwin_network.parse_media_line(['media:', '10baseT', '/', 'full', '(100baseTX)'], None, None)
    assert 'media' == darwin_network.media
    assert '10baseT' == darwin_network.media_select
    assert 'full' == darwin_network.media_type
    assert '100baseTX' == darwin_network.media_options

# Generated at 2022-06-20 17:53:10.499196
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork("")
    current_if = { 'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': {}}
    for words in [['media:','Ethernet','autoselect','10baseT/UTP']]:
        dn.parse_media_line(words, current_if, current_if)
        assert current_if['media'] == 'Unknown'
        assert current_if['media_select'] == 'Ethernet'
        assert current_if['media_type'] == 'autoselect'
        assert current_if['media_options'] == {'10baseT/UTP': ''}

    for words in [['media:','<unknown','type>']]:
        dn.parse_media_line(words, current_if, current_if)
       

# Generated at 2022-06-20 17:53:24.220459
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:29.011588
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert isinstance(dnc, DarwinNetworkCollector)
    assert dnc._platform == 'Darwin'


# Generated at 2022-06-20 17:53:38.704317
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for MacOSX bridge interface
    expected_dict = {'media_select': 'Unknown', 'media_options': {'supported': ['autoselect']}, 'media_type': 'unknown type', 'media': 'Unknown'}
    result_dict = {'media': 'Unknown', 'media_type': 'unknown type', 'media_select': 'Unknown', 'media_options': {'supported': ['autoselect']}}
    # Media line is 'Bridges: <unknown type> supported autoselect'
    # Word splitting gives ['Bridges:', '<unknown', 'type>', 'supported', 'autoselect']
    test_case = ['Bridges:', '<unknown', 'type>', 'supported', 'autoselect']
    result_dict = DarwinNetwork().parse_media_line(test_case, {}, {})

# Generated at 2022-06-20 17:53:50.683709
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetwork(), GenericBsdIfconfigNetwork)
    assert DarwinNetwork.platform == 'Darwin'
    assert DarwinNetwork.indent == '\t'
    assert DarwinNetwork.lo_regex == "(^\w+[^\d]*\d*:([^:]*):<.*>.*\n)+"
    assert DarwinNetwork.lo_regex_if
    assert DarwinNetwork.lo_regex_if_find
    assert DarwinNetwork.lo_regex_findall
    assert DarwinNetwork.regex
    assert DarwinNetwork.regex_if
    assert DarwinNetwork.regex_if_find
    assert DarwinNetwork.regex_findall
    assert DarwinNetwork.network_prefix_length_regex
    assert DarwinNetwork.mac_regex
    assert DarwinNetwork.ip_regex

# Generated at 2022-06-20 17:53:52.676784
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'



# Generated at 2022-06-20 17:53:55.203472
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    res = DarwinNetworkCollector()

    assert(res._platform == 'Darwin')
    assert(res._fact_class == DarwinNetwork)



# Generated at 2022-06-20 17:54:00.962899
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network.platform == 'Darwin'
    assert isinstance(network.get_facts(), DarwinNetwork)
    assert isinstance(network.get_facts()['all_ipv4_addresses'], list)
    assert isinstance(network.get_facts()['default_ipv4'], dict)
    assert isinstance(network.get_facts()['interfaces'], list)

# Generated at 2022-06-20 17:54:02.138590
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-20 17:54:02.986527
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector.collect()

# Generated at 2022-06-20 17:54:04.411901
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d is not None
    assert d.platform == 'Darwin'


# Generated at 2022-06-20 17:54:20.795820
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'
    assert obj._platform == 'Darwin'
    assert obj._fact_class.__name__ == 'DarwinNetwork'
    # test the method get_facts
    assert obj.get_facts() == []


# Generated at 2022-06-20 17:54:22.037246
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'


# Generated at 2022-06-20 17:54:27.019737
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = {}
    res = DarwinNetwork(None, None).parse_media_line(media_line, current_if, ips)
    assert res == None
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': {} }
    assert ips == {}

# Generated at 2022-06-20 17:54:38.197142
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """

    darwin_network = DarwinNetwork()

    # method parse_media_line
    # test case: words = ['supported', 'infrastructure', '(none)']
    words = ['supported', 'infrastructure', '(none)']
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'infrastructure'
    assert current_if['media_type'] == 'none'


    # method parse_media_line
    # test case: words = ['(none)', 'autoselect', '(none)']
    words = ['(none)', 'autoselect', '(none)']

# Generated at 2022-06-20 17:54:41.210952
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class == DarwinNetwork
    assert collector._platform == 'Darwin'
    assert collector._use_sudo == False



# Generated at 2022-06-20 17:54:48.081325
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # TestCase1: test media line with one extra input
    #   This method should return 'media_select' as words[1] and 'media_type' as ''
    #   if there are only two input, words[2] is NoneType
    ifconfig_data1 = '''
      media: autoselect
      status: active
      inet 10.0.0.1 netmask 0xffffff00 broadcast 10.0.0.255
    '''
    current_if1 = {'media': 'Unknown',
                          'media_select': '',
                          'media_type': ''}

# Generated at 2022-06-20 17:54:50.791194
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.facts['all_ipv4_addresses'] == []
    assert d.facts['all_ipv6_addresses'] == []

# Generated at 2022-06-20 17:54:57.607891
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    words = ['media:', '1000baseT', '<full-duplex>']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown',
                          'media_select': '1000baseT',
                          'media_type': 'full-duplex'}


# Generated at 2022-06-20 17:54:58.624732
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for constructor of class DarwinNetwork"""
    network = DarwinNetwork()
    assert network.plugin == 'Darwin'

# Generated at 2022-06-20 17:55:01.276889
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    result = obj.collect()

    # ifconfig output will change with kernel upgrades so just do a rough check
    # to make sure its output is not empty
    assert result['interfaces']

# Generated at 2022-06-20 17:55:27.170490
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()


# Generated at 2022-06-20 17:55:37.656919
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_module = DarwinNetwork()
    current_if = {'ifname': 'en1'}
    # Some words for testing
    words_as_is = ['2', 'Ethernet', 'Autoselect', 'status:active']
    words_with_unknown_type = ['2', '<unknown', 'type>']
    # Do some tests
    test_module.parse_media_line(words_as_is, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == 'Autoselect'
    assert current_if['media_options'] == {'status': 'active'}

# Generated at 2022-06-20 17:55:39.870816
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network is not None

# Generated at 2022-06-20 17:55:41.213839
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert isinstance(dn, DarwinNetwork)


# Generated at 2022-06-20 17:55:45.271990
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'name' : 'le0'}
    ips = []

    dn.parse_media_line(['<link>', 'select', '<unknown type>'],
                        current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'select'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'link'

    dn.parse_media_line(['media:', '10baseT/UTP', '(none)'],
                        current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '10baseT/UTP'

# Generated at 2022-06-20 17:55:46.604034
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:55:47.755787
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'


# Generated at 2022-06-20 17:55:54.769679
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this if/else helps
    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>'], current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:55:56.066566
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for DarwinNetworkCollector()
    """
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:58.398851
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """This unit test ensures that the DarwinNetworkCollector class can be created"""
    assert DarwinNetworkCollector() is not None

# Generated at 2022-06-20 17:56:49.314190
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork()
    assert d.platform == 'Darwin'

# Generated at 2022-06-20 17:56:50.408915
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()

# Generated at 2022-06-20 17:56:52.240448
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:57:02.784069
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test case for the method parse_media_line of class DarwinNetwork
    """
    # Set the media string words of Darwin, which is to be parsed for the
    # media line
    words1 = ['media:', '<unknown', 'type>', '(unspecified)']
    words2 = ['media:', 'autoselect', 'IEEE80211', '(autoselect)']
    words3 = ['media:', 'autoselect', '(autoselect)']
    words4 = ['media:', '(none)']

    # Set the current interface value which is to be used
    current_if = {'if': 'wifi_interface'}
    # ip address not required for the test case
    ips = {}

    # Set the expected result after parsing

# Generated at 2022-06-20 17:57:10.118375
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    lines = ["media: fixed <unknown type>"]
    dn = DarwinNetwork()
    dn.parse_media_line(lines[0].split(' '), {}, {})

    assert dn.parse_media_line(lines[0].split(' '), {}, {})['media_select'] == 'fixed'
    assert dn.parse_media_line(lines[0].split(' '), {}, {})['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:57:16.339013
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ansible_network = DarwinNetwork()
    words = ['some', 'words', 'from', 'ifconfig']
    current_if = {'some': 'stuff'}
    ips = [{'from': 'ifconfig'}]
    ansible_network.parse_media_line(words, current_if, ips)
    assert current_if == {'some': 'stuff', 'media_type': 'unknown type', 'media': 'Unknown', 'media_select': 'Unknown', 'media_options': {}}

# Generated at 2022-06-20 17:57:18.279092
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    check_collector = DarwinNetworkCollector()
    assert check_collector.platform == 'Darwin'

# Generated at 2022-06-20 17:57:27.835082
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'
    assert darwin_net.media_line_re == r'^\s*media:\s*(?P<media_select>.*?)\s*status:\s*(?P<media_status>\S*)\s*(?:.*?\s(?P<media_type>\S*)\s(?P<media_options>.*?))?\s*?$'

# Generated at 2022-06-20 17:57:37.890346
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    f = DarwinNetwork({})
    words = ['media:', 'type', '<unknown', 'type>', '10baseT/UTP*']
    d = {'media': 'Unknown', 'media_select': 'type', 'media_type': 'unknown type', 'media_options': {'10baset/utp': '*'}}
    f.parse_media_line(words, d, None)
    assert d == {'media': 'Unknown', 'media_select': 'type', 'media_type': 'unknown type', 'media_options': {'10baset/utp': '*'}}



# Generated at 2022-06-20 17:57:43.208284
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector(None, None, None)
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'