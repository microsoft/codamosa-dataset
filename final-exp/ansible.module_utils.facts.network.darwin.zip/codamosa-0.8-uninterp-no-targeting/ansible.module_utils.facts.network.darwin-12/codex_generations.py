

# Generated at 2022-06-20 17:49:00.939906
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    with open('tests/unit/module_utils/facts/network/test_Darwin_ifconfig.output', 'r') as output:
        darwin_network_output = output.read()
    darwin_network_obj = DarwinNetwork(darwin_network_output)
    # Assert LinuxNetwork attributes
    assert darwin_network_obj.platform == "Darwin"
    # Assert GenericBsdIfconfigNetwork attributes

# Generated at 2022-06-20 17:49:09.282146
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    good_line = "media: <unknown type> <unknown subtype>"
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(good_line.split(),current_if,ips)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == '<unknown')
    assert(current_if['media_type'] == 'unknown type')
    assert(current_if['media_options'] == 'unknown subtype')


# Generated at 2022-06-20 17:49:20.710590
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ Unit test for method parse_media_line of class DarwinNetwork """

    # Arrange:
    # It is sufficient to provide a minimal words list. we only care about the if
    words = ['this', 'is', 'a', 'test']
    # Initialize a minimal current_if dict
    current_if = {
        'interface': 'eth0'
    }
    # Initialize a minimal ips dict
    ips = {
        'lo': {'interface': 'eth0'}
    }
    # Create a DarwinNetwork instance
    network_ins = DarwinNetwork(None, words, current_if, ips)

    # Act:
    # Call the method parse_media_line on the instance
    network_ins.parse_media_line(words, current_if, ips)

    # Assert:
    # Verify the

# Generated at 2022-06-20 17:49:25.573316
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', '<full-duplex>']
    result = { 'media' : 'Unknown', 'media_select' : 'Unknown', 'media_options' : 'full-duplex' }
    dn = DarwinNetwork()
    ifinfo = {}
    dn.parse_media_line(words, ifinfo, [])
    assert ifinfo == result

# Generated at 2022-06-20 17:49:26.436199
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()

# Generated at 2022-06-20 17:49:26.953547
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:27.818912
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:29.340026
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert isinstance(dn, DarwinNetwork)


# Generated at 2022-06-20 17:49:31.331213
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()

# Generated at 2022-06-20 17:49:35.726291
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector is not None
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'


# Generated at 2022-06-20 17:49:38.390705
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:49:48.216689
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test method parse_media_line of class DarwinNetwork
    test_if = {}
    test_words = []
    test_ips = []
    # Test case 1 - media line with media_type
    expectedIf = {'media_type': '100baseTX', 'media_select': 'autoselect', 'media': 'Unknown'}
    test_if = {}
    test_words = ['media:', 'autoselect', '(100baseTX)' ]
    DarwinNetwork.parse_media_line(DarwinNetwork, test_words, test_if, test_ips)
    assert test_if == expectedIf
    # Test case 2 - media line without media_type
    expectedIf = {'media_select': 'autoselect', 'media': 'Unknown'}
    test_if = {}

# Generated at 2022-06-20 17:49:57.355752
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Arrange
    dn = DarwinNetwork()
    current_if = {}
    # line = 'media: autoselect () media open'
    # line = 'media: <unknown type> status: inactive'
    line = 'media: autoselect (<unknown type>)'

    # Act
    dn.parse_media_line(line.split(), current_if, {})

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'Unknown'
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:50:00.111056
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector(None, None, None, None)
    assert facts._fact_class.platform == 'Darwin'
    assert isinstance(facts._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:50:03.165140
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    invalid_platform = "invalid_platform"

    network_collector = NetworkCollector.create(invalid_platform)
    assert network_collector is None

    network_collector = NetworkCollector.create('Darwin')
    assert isinstance(network_collector, DarwinNetworkCollector)

# Generated at 2022-06-20 17:50:05.777389
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()

# unit test for class DarwinNetworkCollector

# Generated at 2022-06-20 17:50:14.270179
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Set data for test
    test_if = {'if': 'bridge0'}
    test_words = ['media', '<unknown', 'type>']
    test_ips = {}

    # Init class and parse data
    test_class = DarwinNetwork(module=None)
    test_class.parse_media_line(words=test_words, current_if=test_if, ips=test_ips)

    # Check result - media with brackets
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:50:23.095341
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:50:25.970950
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dn = DarwinNetworkCollector()
    assert dn._platform == 'Darwin'
    assert dn._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:50:26.449410
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()