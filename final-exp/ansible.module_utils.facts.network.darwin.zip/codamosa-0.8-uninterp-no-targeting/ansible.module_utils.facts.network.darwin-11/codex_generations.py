

# Generated at 2022-06-20 17:48:57.474053
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    assert dn.parse_media_line(['media:', '<unknown', 'type>'], {}, []) == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>'}
    assert dn.parse_media_line(['media:', '<unknown', 'type>', 'autoselect', 'full-duplex'], {}, []) == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>', 'media_options': {'autoselect': True, 'full-duplex': True}}

# Generated at 2022-06-20 17:48:59.794316
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    sc = DarwinNetwork()
    assert sc.platform == 'Darwin'



# Generated at 2022-06-20 17:49:07.039474
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = 'media: <unknown type> status: inactive'.split()
    current_if = {}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:49:07.539039
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:49:10.895904
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork({}, {}, {})
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-20 17:49:15.294519
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test instantiation of DarwinNetwork class """
    darwinnetwork = DarwinNetwork()
    assert darwinnetwork.fact_class == DarwinNetwork
    assert darwinnetwork.fact_subclass == GenericBsdIfconfigNetwork
    assert darwinnetwork.platform == 'Darwin'



# Generated at 2022-06-20 17:49:16.965329
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork()
    assert darwinNetwork is not None

# Generated at 2022-06-20 17:49:18.776766
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == 'Darwin'

# Generated at 2022-06-20 17:49:20.132551
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert isinstance(instance.collect(), list)

# Generated at 2022-06-20 17:49:22.165572
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:49:25.968757
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # this should work on any Darwin machine
    # TODO - maybe we can find a way to test this without depending on a host
    dn = DarwinNetwork('en0')
    assert dn is not None

# Generated at 2022-06-20 17:49:37.970720
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:49:47.832857
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_net = DarwinNetwork()
    # media line parsing

# Generated at 2022-06-20 17:49:59.234889
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {'name': 'foo'}
    ip = {}
    # Line: 'media: autoselect (1000baseT <full-duplex>)'
    DarwinNetwork.parse_media_line(['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status: active'], iface, ip)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '1000baseT'
    assert iface['media_options'] == ['full-duplex']
    # Line: 'media: <unknown type>'
    DarwinNetwork.parse_media_line(['media:', '<unknown', 'type>', 'status: active'], iface, ip)

# Generated at 2022-06-20 17:50:06.121257
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    facts = {}
    # GenericBsdIfconfigNetwork.populate() always has this if
    # the platform is Darwin
    current_if = {"name": "lo0", "ipv4": {}, "ipv6": {}, "bridge": {}}
    ips = []
    media_line = "media: autoselect <unknown type>"
    words = media_line.split()
    d.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-20 17:50:09.052744
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector().get_facts()['ansible_facts']['ansible_net_interfaces'], dict)

# Generated at 2022-06-20 17:50:15.419240
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    This is the test for the DarwinNetwork constructor.
    """
    darwin = DarwinNetwork()

    assert darwin.platform == "Darwin"
    assert darwin.interface_regex == ['^([0-9])', '^(ng[0-9])']
    assert darwin.default_interface == 'en0'
    assert darwin.default_bridge == 'bridge0'

# Generated at 2022-06-20 17:50:18.198306
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == 'Darwin'


# Generated at 2022-06-20 17:50:27.843612
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    macosx_if = {"media": "Unknown"}
    words = ["media:", "<unknown", "type>"]
    darwin_network.parse_media_line(words, macosx_if, {})
    assert macosx_if["media_select"] == "Unknown"
    assert macosx_if["media_type"] == "unknown type"
    macosx_if = {}
    words = ["media:", "autoselect", "(100baseTX)", "full-duplex"]
    darwin_network.parse_media_line(words, macosx_if, {})
    assert macosx_if["media_select"] == "autoselect"
    assert macosx_if["media_type"] == "100baseTX"
    assert macosx

# Generated at 2022-06-20 17:50:34.948962
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dar_nw = DarwinNetwork()

    # validate DarwinNetwork class attributes
    assert dar_nw.platform == 'Darwin'
    assert dar_nw.capabilities == ['ipv4', 'ipv6', 'active', 'arp']
    assert dar_nw.command.endswith('ifconfig')
    assert dar_nw.ignore_options == ['media_type']
    assert dar_nw.default_interface is None


# Generated at 2022-06-20 17:50:44.027973
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    import pprint
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    from ansible.module_utils.facts.network.darwin import DarwinNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    module = DarwinNetworkCollector()
    result = module.collect()
    pprint.pprint(result)
    assert result[0]['class'] == DarwinNetwork
    assert result[0]['platform'] == 'Darwin'



# Generated at 2022-06-20 17:50:45.616301
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj= DarwinNetworkCollector()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-20 17:50:49.266095
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None, "test_version", "test_instance")
    assert obj.platform == 'Darwin'
    # On a mac, this will always be 'Darwin'
    assert obj._platform == 'Darwin'
    # This should always return DarwinNetwork
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:51:00.702571
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    test_input_one = ['media:', '<unknown', 'type>', '<full-duplex> <rxpause> <txpause>']
    test_input_two = ['media:', 'autoselect', '(none)']
    test_input_three = ['media:', '10baseT/UTP', 'status:', 'active']

    expected_output_one = {'media': 'Unknown',
                           'media_select': '<unknown',
                           'media_type': '<full-duplex> <rxpause> <txpause>'}
    expected_output_two = {'media': 'Unknown',
                           'media_select': 'autoselect',
                           'media_type': '(none)'}

# Generated at 2022-06-20 17:51:10.871778
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    def get_options(word):
        return word
    m = DarwinNetwork()
    m.get_options = get_options
    current_if = {}
    ips = []
    # trailing space after <unknown type>
    words = 'media: <unknown type>  status: inactive'.split()
    m.parse_media_line(words, current_if, ips)
    assert current_if['media_options'] == 'status: inactive'
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_select'] == '<unknown'
    # no space after <unknown type>
    words = 'media: <unknown type>'.split()
    current_if = {}

# Generated at 2022-06-20 17:51:23.099432
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'name': 'test'}
    DarwinNetwork.parse_media_line(['media:', 'autoselect', 'Wi-Fi', '(autoselect)'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'Wi-Fi'
    assert current_if['media_options'] == ['autoselect']

    current_if = {'name': 'test'}
    DarwinNetwork.parse_media_line(['media:', '<unknown', 'type>'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-20 17:51:23.961672
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:51:25.679940
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__name__ == 'DarwinNetworkCollector'


# Generated at 2022-06-20 17:51:27.959505
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector('/sbin/ifconfig')
    assert dnc is not None
    assert dnc._fact_class is not None
    assert dnc._platform is not None

# Generated at 2022-06-20 17:51:33.248294
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_collector = DarwinNetworkCollector()
    assert isinstance(net_collector, NetworkCollector)
    assert dataclass_eq(net_collector, DarwinNetworkCollector())
    assert dataclass_eq(net_collector._fact_class, DarwinNetwork)
    assert dataclass_eq(net_collector._platform, 'Darwin')

# Generated at 2022-06-20 17:51:36.092877
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)

# Generated at 2022-06-20 17:51:36.649982
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:39.949256
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:51:41.373834
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork([])
    assert dn.platform == 'Darwin'

# Generated at 2022-06-20 17:51:51.487411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup 'current_if' and 'words'
    current_if = {}
    ips = {}
    words = ['media:', 'autoselect', '(100baseTX)', 'status:', 'inactive']
    
    # Create DarwinNetwork object
    dn = DarwinNetwork()
    
    # Call parse_media_line
    dn.parse_media_line(words, current_if, ips)
    
    # Assert the media types
    assert current_if.get('media', '') == 'Unknown'
    assert current_if.get('media_select', '') == 'autoselect'
    assert current_if.get('media_type', '') == '100baseTX'
    assert current_if.get('media_options', '') == {}
    
    # Update 'words'

# Generated at 2022-06-20 17:51:52.402880
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert isinstance(DarwinNetwork(), DarwinNetwork)

# Generated at 2022-06-20 17:51:59.525477
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc_lines = '''media: autoselect (100baseTX <full-duplex>)
status: active
'''.split('\n')

    # Setup
    darwin_network = DarwinNetwork('')

    # Exercise

    result = darwin_network.parse_media_line(ifc_lines[0].split(), {}, {})

    # Verify

    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == '100baseTX <full-duplex>'
    assert result['media_options'] == {}



# Generated at 2022-06-20 17:52:10.148611
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    This is a test for the method parse_media_line of the class DarwinNetwork
    """
    test_obj = DarwinNetwork()
    # test case 1
    test_dict = {('media_options'): None, ('media_select'): 'autoselect', ('media_type'): '<full-duplex>', ('media'): 'Unknown'}
    test_list = ['media:', 'autoselect', '<full-duplex>']
    test_obj.parse_media_line(test_list, test_dict, None)
    assert test_dict == test_dict

    # test case2
    test_dict = {('media_options'): None, ('media_select'): 'autoselect', ('media_type'): '<full-duplex>', ('media'): 'Unknown'}
    test

# Generated at 2022-06-20 17:52:19.496976
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["media:", "<unknown", "type>", "(autoselect)"]
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}
    words = ["media:", "autoselect", "(100baseTX", "<full-duplex,", "flow-control>)"]
    current_if = {'media': 'Unknown'}
    ips = []
    DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert current_if['media'] == 'Unknown'


# Generated at 2022-06-20 17:52:30.427208
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    ''' Unit test for the DarwinNetwork class constructor. '''

# Generated at 2022-06-20 17:52:45.647130
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # testcase A
    # media line is: media: <unknown type>
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', '<unknown', 'type>'], dict(), dict())
    assert ifc.current_if['media_select'] == 'Unknown'
    assert ifc.current_if['media_type'] == 'unknown type'
    assert ifc.current_if['media_options'] == {}

    # testcase B
    # media line is: media: autoselect (1000baseT <full-duplex>) status: inactive
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', 'autoselect', '(1000baseT', '<full-duplex>)'], dict(), dict())

# Generated at 2022-06-20 17:52:54.896836
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    current_if = {}
    words = [1, 2, 3, 4]
    ips = []
    dwn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown'}

    words = ['media', 'Unknown']
    dwn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown'}

    words = ['media', '<unknown', 'type>']
    dwn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown',
                          'media_type': 'unknown type'}


# Generated at 2022-06-20 17:53:01.633460
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.facts['default_ipv4']['interface'] is None
    assert net.facts['default_ipv6']['interface'] is None
    assert len(net.facts['all_ipv4_addresses']) == 0
    assert len(net.facts['all_ipv6_addresses']) == 0
    assert net.facts['netmask4'] is None
    assert net.facts['netmask6'] is None
    assert net.facts['network4'] is None
    assert net.facts['network6'] is None
    assert net.facts['broadcast4'] is None
    assert net.facts['broadcast6'] is None
    assert len(net.facts['interfaces']) == 0


# Generated at 2022-06-20 17:53:12.424650
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    test_DarwinNetwork_parse_media_line
    """

    current_if = {}
    words = ["media:", "<unknown", "type>", "status:", "inactive"]
    DarwinNetwork.parse_media_line(None, words, current_if, None)
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'
    assert not current_if.get('media_options')

    current_if = {}
    words = ["media:", "none", "status:", "active"]
    DarwinNetwork.parse_media_line(None, words, current_if, None)
    assert current_if['media'] == 'Unknown'  # Mac does

# Generated at 2022-06-20 17:53:20.885631
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    a = DarwinNetwork(None, None)

    words = ['<unknown', 'type>']
    current_if = {}
    ips = {}
    a.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT', '<full-duplex>)']
    current_if = {}
    ips = {}
    a.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Ethernet', 'media_select': 'autoselect', 'media_type': '1000baseT', 'media_options': {'full-duplex': ''}}

# Generated at 2022-06-20 17:53:23.148568
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'

# Generated at 2022-06-20 17:53:27.745615
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_iface = DarwinNetwork(None, None)
    expected_iface = 'Darwin'
    assert(darwin_iface.platform == expected_iface)

# Generated at 2022-06-20 17:53:37.504714
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn= DarwinNetwork()
    _parse_media_line = dn.parse_media_line([], {}, [])
    assert _parse_media_line == None

    dn= DarwinNetwork()
    _parse_media_line = dn.parse_media_line(['media'], {}, [])
    assert _parse_media_line == None
    dn= DarwinNetwork()
    _parse_media_line = dn.parse_media_line(['media', 'media_select'], {}, [])
    assert _parse_media_line == None
    dn= DarwinNetwork()
    _parse_media_line = dn.parse_media_line(['media', 'media_select', 'media_type'], {}, [])
    assert _parse_media_line == None
    dn= DarwinNetwork()

# Generated at 2022-06-20 17:53:38.698616
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-20 17:53:45.524581
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Test DarwinNetworkCollector()
    fact_class = DarwinNetwork
    platform = 'Darwin'
    dnc = DarwinNetworkCollector(fact_class, platform)
    assert dnc.fact_class == fact_class
    assert dnc.platform == platform
    assert dnc.data == {}

# Generated at 2022-06-20 17:53:57.803791
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    test_tuples = [
        (['media:', 'IEEE', '802.11', '(autoselect)'], {'media_type': '802.11', 'media_select': 'IEEE'}),
        (['media:', '<unknown', 'type>', 'status:', 'inactive'], {'media_type': 'unknown type', 'media_select': 'Unknown'}),
    ]
    for words, expected_result in test_tuples:
        new_if = {'media': 'Unknown'}
        ips = {}
        d.parse_media_line(words, new_if, ips)
        for key, value in expected_result.items():
            assert new_if[key] == value

# Generated at 2022-06-20 17:54:04.404638
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # setup
    ansible_facts = {'ansible_interfaces': ['eth0', 'eth1', 'eth2']}
    # test if the media_line has the form 'media: select media-type'
    line = 'media: select 10baseT/UTP'
    current_if = {'name': 'eth0',
                  'type': 'Ethernet',
                  'macaddress': '00:00:00:00:00:00'}

# Generated at 2022-06-20 17:54:06.091121
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == "Darwin"
    assert collector._fact_class == DarwinNetwork



# Generated at 2022-06-20 17:54:09.015911
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector([])
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:54:20.320154
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {}
    iface['media'] = 'Unknown'
    iface['media_select'] = 'autoselect'
    iface['media_type'] = 'none'
    iface['media_options'] = ['100baseTX', '10baseT/UTP', 'FDX', 'flow', 'half-duplex']
    # media_type is optional so test without it
    words = "media: autoselect 100baseTX 10baseT/UTP FDX flow half-duplex"
    words = words.split()
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, iface, {})
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'none'

# Generated at 2022-06-20 17:54:25.385834
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = ['media:', '<unknown', 'type>', '(autoselect)']
    DarwinNetwork().parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {'autoselect': ''}

# Generated at 2022-06-20 17:54:36.944994
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test result for media line with all parameters:
    media_line = '0x100004 <unknown type> fixed none none'
    dn = DarwinNetwork()
    try:
        dn.parse_media_line(media_line.split(' '), {}, [])
    except AttributeError:
        # No options in media_options
        assert True
    else:
        assert False

    # Test result for media line without option:
    media_line = '0xe <unknown type> fixed none'
    dn = DarwinNetwork()
    try:
        dn.parse_media_line(media_line.split(' '), {}, [])
    except AttributeError:
        # No options in media_options
        assert True
    else:
        assert False


# Generated at 2022-06-20 17:54:45.916581
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = None
    ips = {'inet': [], 'inet6': []}
    # test basic media line
    words = ['media:', 'autoselect', '(unknown)']
    current_if = DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown'
    # test invalid media line
    words = ['media:', 'autoselect', '(unknown)', 'foo:bar']
    current_if = DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_options'] is None
    # test bridge media line

# Generated at 2022-06-20 17:54:49.709126
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = dict()
    networks = DarwinNetworkCollector(facts)
    assert(isinstance(networks.parse(), dict))
    assert(networks.parse() == {})

# Generated at 2022-06-20 17:54:50.489494
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network.platform == 'Darwin'

# Generated at 2022-06-20 17:55:02.850917
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:04.464188
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    inst = DarwinNetworkCollector()
    assert inst._platform == 'Darwin'
    assert isinstance(inst._fact_class(None, None), DarwinNetwork)

# Generated at 2022-06-20 17:55:08.035312
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    new_instance = DarwinNetworkCollector()
    assert new_instance
    assert new_instance._fact_class == DarwinNetwork
    assert new_instance._platform == 'Darwin'

# Generated at 2022-06-20 17:55:17.527387
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor of DarwinNetwork class
    """
    darwin_net = DarwinNetwork()
    assert darwin_net._ifconfig_path == '/sbin/ifconfig'
    assert darwin_net._hostname_path == '/bin/hostname'
    assert darwin_net._platform == 'Darwin'
    assert darwin_net._interfaces == list()
    assert darwin_net._interfaces_ipv4 == dict()
    assert darwin_net._interfaces_ipv6 == dict()
    assert darwin_net._default_ipv4 == dict()
    assert darwin_net._default_ipv6 == dict()

# Generated at 2022-06-20 17:55:25.619908
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = []
    ips = {}
    
    # case 1
    # media line:  media: autoselect (1000baseT <full-duplex,flow-control>)
    words = ["media:", "autoselect", "(1000baseT", "<full-duplex,flow-control>)", "status:", "inactive"]
    DarwinNetwork(None, None).parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex,flow-control'
    assert current_if['status'] == 'inactive'
    current_if

# Generated at 2022-06-20 17:55:27.661948
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    nm = DarwinNetworkCollector()
    assert nm._fact_class == DarwinNetwork
    assert nm._platform == 'Darwin'

# Generated at 2022-06-20 17:55:29.938497
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Validate the DarwinNetwork constructor"""
    dn = DarwinNetwork()
    assert isinstance(dn, DarwinNetwork)


# Generated at 2022-06-20 17:55:32.139042
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:55:32.957818
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:55:34.488139
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'


# Generated at 2022-06-20 17:56:03.640128
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class.platform == 'Darwin'
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:56:06.833952
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == "Darwin"
    assert issubclass(DarwinNetworkCollector._fact_class, GenericBsdIfconfigNetwork)


# Generated at 2022-06-20 17:56:08.403789
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    netobj = DarwinNetwork()
    assert netobj.platform == 'Darwin'



# Generated at 2022-06-20 17:56:10.500003
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network = DarwinNetworkCollector()
    assert network.platform == 'Darwin'  # platform is Darwin
    assert network._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:56:13.176195
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Create instance of DarwinNetworkCollector
    name = "DarwinNetworkCollector"
    DarwinNetworkCollector(name)

# Generated at 2022-06-20 17:56:14.727589
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._fact_class is DarwinNetwork
    assert DarwinNetworkCollector._platform is 'Darwin'

# Generated at 2022-06-20 17:56:19.006185
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector._fact_class == DarwinNetwork
    assert darwin_network_collector._platform == 'Darwin'
    assert len(darwin_network_collector.collect()) == 0

# Generated at 2022-06-20 17:56:25.124441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # setup test variables
    darwin_network_collector = DarwinNetworkCollector()
    darwin_network_collector.parse_media_line(["media:","autoselect", "<unknown type>"],{'name': 'bridge0'},{})
    assert darwin_network_collector.parse_media_line(["media:","autoselect", "<unknown type>"],{'name': 'bridge0'},{}) == ({'name': 'bridge0', 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}, None)

# Generated at 2022-06-20 17:56:29.338085
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'
    assert network.media

# Generated at 2022-06-20 17:56:37.070336
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    # Test 'media: autoselect (1000baseT <full-duplex>) status: active'
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' in current_if
    assert current_if['media_type'] == '1000baseT'
    assert 'media_options' in current_if
    assert current_if['media_options']

# Generated at 2022-06-20 17:57:19.064959
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector(None)
    assert darwin_network_collector._platform == 'Darwin'
    assert darwin_network_collector.get_valid_facts() == ['all', 'interfaces', 'ipv4', 'ipv6', 'vendor', 'hardware', 'fqdn', 'hostname', 'domain', 'dns', 'gateway', 'ipcidr', 'os_version']
    assert darwin_network_collector.get_network_min_version() == '10.12'
    assert darwin_network_collector.get_network_max_version() == '10.12'
    assert darwin_network_collector.get_network_default_version() == '10.12'

# Generated at 2022-06-20 17:57:24.532268
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    net.populate()
    assert net.populated is True
    assert net.devices is not None
    assert net.networks is not None

# Generated at 2022-06-20 17:57:26.903631
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:57:31.274817
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class.platform == 'Darwin'
    assert DarwinNetworkCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:57:38.673902
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # setup
    darwin_network = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    ips = {}
    current_if = {}

    # execute
    darwin_network.parse_media_line(words, current_if, ips)

    # verify
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:57:47.891143
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test if the mac media line is correctly parsed
    """
    network_inspector = DarwinNetwork()
    network_inspector.set_option({'gather_network_resources': 'yes'})
    current_if = {}
    ips = []
    words = ['media:', '<unknown', 'type>']
    network_inspector.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:57:59.705763
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # first, test the case where the interface is a bridge
    test_if = {}
    test_ips = {}
    test_words = ['<unknown', 'type>', 'status:', 'inactive']
    dn.parse_media_line(test_if, test_ips, test_words)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == 'status: inactive'
    # now try the normal case
    test_if = {}
    test_ips = {}
    test_words = ['media:', 'autoselect', '(none)']

# Generated at 2022-06-20 17:58:03.759194
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()
    assert darwin_net.platform == "Darwin"
    assert darwin_net.get_facts() == {}


# Generated at 2022-06-20 17:58:05.637772
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    res = DarwinNetworkCollector()
    assert type(res) == DarwinNetworkCollector

# Generated at 2022-06-20 17:58:07.059520
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert isinstance(obj._fact_class, DarwinNetwork)
