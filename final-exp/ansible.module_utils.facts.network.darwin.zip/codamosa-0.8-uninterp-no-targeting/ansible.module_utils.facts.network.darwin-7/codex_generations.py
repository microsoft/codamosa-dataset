

# Generated at 2022-06-20 17:48:49.925344
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructs a test object of class DarwinNetwork and compares the expected
    value with the result of the object's properties.
    """
    my_test = DarwinNetwork()
    assert my_test.get_file() == '/sbin/ifconfig -a'


# Generated at 2022-06-20 17:49:00.539804
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test the media parsing code with a known example from the help of ifconfig
    # Test real media types
    # Test unknown type in bridge interface
    for words in [
        ['media:', 'autoselect', '10baseT/UTP', '<full-duplex>'],
        ['media:', 'autoselect', '(none)'],
        ['media:', '<unknown', 'type>'],
    ]:
        current_if = {}
        DarwinNetwork.parse_media_line(None, current_if, words)
        assert current_if['media'] == 'Unknown'
        assert current_if['media_select'] == 'autoselect'
        if len(words) > 2:
            assert current_if['media_type'] == words[2]
        if len(words) > 3:
            assert current_if

# Generated at 2022-06-20 17:49:02.465182
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Constructor test
    :return:
    """
    obj = DarwinNetworkCollector()
    print(obj.__dict__)

# Generated at 2022-06-20 17:49:04.899878
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    print(DarwinNetwork())

# Generated at 2022-06-20 17:49:10.421164
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '<unknown type>']
    current_if = dict()
    ips = dict()
    d = DarwinNetwork()
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-20 17:49:21.477881
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Unit test for DarwinNetwork constructor."""
    fact = DarwinNetwork('lo0', 'inet', '0.0.0.0', 'netmask', '0xff000000', '0', '0x1', '0x2', 'link', 'ether', '00:00:00:00:00:00', 'mtu', '0x0', '0x1', '0x2')

    assert fact.device == 'lo0'
    assert fact.inet == 'inet'
    assert fact.inet6 == '0'
    assert fact.addr == '0.0.0.0'
    assert fact.netmask == '0xff000000'
    assert fact.broadcast == 'netmask'
    assert fact.status == '0x1'
    assert fact.vlan == '0'

# Generated at 2022-06-20 17:49:22.441313
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    obj = DarwinNetwork()
    print(obj)

# Generated at 2022-06-20 17:49:24.395555
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector(None, None, None)
    assert obj.__class__.__name__ == 'DarwinNetworkCollector'

# Generated at 2022-06-20 17:49:25.280839
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-20 17:49:27.757099
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector.platform == 'Darwin'
    assert collector._fact_class.__name__ == 'DarwinNetwork'

# Generated at 2022-06-20 17:49:40.248406
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_object = DarwinNetwork()
    options = {'mtu': '1500', 'ether': '30:cd:c9:b9:7f:44'}
    current_if = {'options': options, 'media': '', 'media_type': '1T', 'media_select': 'autoselect',
                  'macaddress': '30:cd:c9:b9:7f:44', 'interface': 'en1', 'type': 'Ethernet'}
    words = ['media:', 'autoselect', '1T', 'status:', 'inactive', 'mtu', '1500', 'ether', '30:cd:c9:b9:7f:44']

# Generated at 2022-06-20 17:49:49.896271
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ans_test = DarwinNetwork()
    words = ['media:', '<unknown', 'type>']
    current_if = {'media_select': 'unknown_media'}
    ips = {}
    ans_test.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'
    assert not current_if.get('media_options')

    words = ['media:', 'autoselect', '10baseT/UTP']
    ans_test.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-20 17:49:51.457045
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'

# Generated at 2022-06-20 17:50:01.301449
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Method `parse_media_line` of class DarwinNetwork takes a list of words
    and a current interface, and depending on the data it gets from words
    it may update the values of media, media_select, media_type,
    media_options of the current interface.

    This test is a unit test for `parse_media_line` method of class DarwinNetwork
    It uses mock objects for both `words` and `current_if`. It asserts that
    the values of media, media_select, media_type, media_options of the current
    interface are updated correctly.

    :return: None
    """
    dnetwork = DarwinNetwork()
    words = ["media:", "autoselect", "(none)", "status:", "inactive"]
    current_if = dict()

# Generated at 2022-06-20 17:50:02.726987
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Test where MacOSX is NOT installed
    try:
        DarwinNetworkCollector()
        assert False
    except:
        assert True

# Generated at 2022-06-20 17:50:09.052754
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fact_cls = DarwinNetwork()
    current_if = {}
    fact_cls.parse_media_line(['media:', 'autoselect', '100baseTX', '(100baseTX)'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == '100baseTX'

    current_if = {}
    fact_cls.parse_media_line(['media:', '<unknown', 'type>'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-20 17:50:10.615697
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # instantiate class
    DarwinNetwork()

# Generated at 2022-06-20 17:50:12.413451
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d is not None

# Generated at 2022-06-20 17:50:13.047344
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-20 17:50:23.483546
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:50:27.769363
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(None)
    assert dn.platform == 'Darwin'
    assert isinstance(dn.facts, dict)
    assert 'default_ipv4' not in dn.facts
    assert 'interfaces' not in dn.facts


# Generated at 2022-06-20 17:50:30.501793
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'
    assert obj.media_sort_keys == ['media_select', 'media_type', 'media_options']

# Generated at 2022-06-20 17:50:32.007448
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()


# Generated at 2022-06-20 17:50:34.389343
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._fact_class.platform == 'Darwin'


# Generated at 2022-06-20 17:50:35.726787
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert(isinstance(DarwinNetwork({}), GenericBsdIfconfigNetwork))

# Generated at 2022-06-20 17:50:37.162557
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork
    assert module

# Generated at 2022-06-20 17:50:39.273604
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:50:45.075474
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    words = ['media:', '<unknown type>', 'status:', 'active']
    current_if = {}
    darwin = DarwinNetwork()  # create default instance
    darwin.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

# Generated at 2022-06-20 17:50:55.088023
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_str = 'media: <unknown type> <unknown type>'
    test_str_split = test_str.split(' ')
    iface = dict()
    DarwinNetwork.parse_media_line(None, test_str_split, iface)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'
    assert iface['media_options'] == dict()
    test_str = 'media: autoselect (none)'
    test_str_split = test_str.split(' ')
    iface = dict()
    DarwinNetwork.parse_media_line(None, test_str_split, iface)
    assert iface['media'] == 'Unknown'

# Generated at 2022-06-20 17:50:58.063982
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():

    network = DarwinNetwork()

    assert network.get_file_path() == '/sbin/ifconfig'
    assert network.platform == 'Darwin'

# Generated at 2022-06-20 17:51:00.833233
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()
    assert net.platform == 'Darwin'
    assert net.parse_media_line is not None

# Generated at 2022-06-20 17:51:10.978103
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test the parse_media_line method of class DarwinNetwork
    """
    test_class = DarwinNetwork(None)
    test_dict = dict()

    # used for testing
    inwords1 = ["<unknown", "type>"]
    inwords2 = ["alternate,", "full-duplex,", "100baseTX"]
    inwords3 = ["none"]
    # should be set for testing
    exp_out1 = 'Unknown'
    exp_out2 = '100baseTX'
    exp_out3 = 'none'

    test_class.parse_media_line(inwords1, test_dict, None)
    assert test_dict['media'] == exp_out1
    assert test_dict['media_select'] == exp_out1
    assert test_dict['media_type'] == exp_out1



# Generated at 2022-06-20 17:51:22.310140
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.set_iface_info('eth0')
    ifc.set_iface_data({'options': {'media': 'Unknown'},
                        'media_select': 'media',
                        'media_type': 'unknown type'})
    ifc.parse_media_line(['media', 'auto', '<unknown', 'type>', ''])
    ifc.assert_iface_data({'options': {'media': 'Unknown'},
                           'media_select': 'auto',
                           'media_type': 'unknown type'})

    ifc.set_iface_data({'options': {'media': 'Unknown'},
                        'media_select': 'media',
                        'media_type': 'unknown type'})

# Generated at 2022-06-20 17:51:28.501044
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    ad = DarwinNetwork()
    assert ad.get_file_name() == '/sbin/ifconfig'
    assert ad.get_interfaces() == []
    assert ad.get_interfaces_ip() == []
    assert ad.get_interfaces_ipv6() == []
    assert ad.get_route_numbers() == []
    assert ad.get_default_interfaces() == []
    assert ad.has_current() == False
    assert ad.facts == {}

# Generated at 2022-06-20 17:51:32.812559
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = NetworkCollector()
    dnfacts = dn.get_facts()
    assert ('interfaces' in dnfacts)
    assert ('all_ipv4_addresses' in dnfacts)
    assert ('all_ipv6_addresses' in dnfacts)

# Generated at 2022-06-20 17:51:36.129423
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector.platform == 'Darwin', \
           'DarwinNetworkCollector.platform is not Darwin'
    assert network_collector._fact_class == DarwinNetwork, \
           'DarwinNetworkCollector._fact_class is not DarwinNetwork'

# Generated at 2022-06-20 17:51:48.160446
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = ['media:', '<unknown', 'type>', 'supported:', 'none', 'none']
    DarwinNetwork.parse_media_line(current_if, words, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'none none'
    words = ['media:', 'autoselect', '(none)', 'supported:', 'none', 'none']
    DarwinNetwork.parse_media_line(current_if, words, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type']

# Generated at 2022-06-20 17:51:50.107390
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-20 17:51:50.667554
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:53.074964
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:51:59.012856
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>', '(autoselect)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'autoselect'

# Generated at 2022-06-20 17:52:09.501200
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    collectors = [DarwinNetworkCollector]
    for c in collectors:
        assert c._platform == 'Darwin'
        c = c()
        assert c.get_facts()['example.com']['interfaces']['lo0']['mtu'] == '16384'
        assert c.get_facts()['example.com']['interfaces']['lo0']['flags'] == ['UP', 'UP', 'LOOPBACK', 'RUNNING']
        assert c.get_facts()['example.com']['interfaces']['en3']['encapsulation'] == 'Ethernet'
        assert c.get_facts()['example.com']['interfaces']['en3']['mtu'] == '1500'

# Generated at 2022-06-20 17:52:15.029819
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # given
    # instantiate the DarwinNetwork class
    dn = DarwinNetwork()

    media_line = 'media: <unknown type>'

    # when
    parsed = dn.parse_media_line(media_line.split(), {}, {})

    # then
    assert parsed['media_select'] == 'Unknown'
    assert parsed['media_type'] == 'unknown type'
    assert 'media_options' not in parsed

# Generated at 2022-06-20 17:52:21.740426
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnif = DarwinNetwork()
    current_if = {}
    ips = {}
    dnif.parse_media_line(["media:", "autoselect", "(1000baseT"], current_if, ips)
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "(1000baseT"
    dnif.parse_media_line(["media:", "<unknown", "type>"], current_if, ips)
    assert current_if['media_select'] == "Unknown"
    assert current_if['media_type'] == "unknown type"

# Generated at 2022-06-20 17:52:24.210920
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == DarwinNetwork._platform
    assert collector._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:52:34.527562
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # test with single word
    dn.parse_media_line(['ethernet', 'auto'], {}, {})
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == 'auto'
    assert 'media_type' not in dn.current_if
    assert 'media_options' not in dn.current_if

    # test with two words
    dn.parse_media_line(['autoselect', 'none', '(none)'], {}, {})
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == 'none'
    assert dn.current_if['media_type'] == '(none)'

# Generated at 2022-06-20 17:52:46.204264
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:52:51.367409
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_string = "    media: <unknown type> <unknown subtype>"
    words = test_string.split()

    current_if = {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type', 'media_options': 'unknown subtype'}
    current_if_check = DarwinNetwork.parse_media_line(DarwinNetwork, words, {}, {})

    assert current_if == current_if_check

# Generated at 2022-06-20 17:52:59.738225
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-20 17:53:01.305711
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._platform == 'Darwin'
    assert obj._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:53:09.042157
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = ['media', '<unknown', 'type>']
    DarwinNetwork().parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-20 17:53:14.251837
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(DarwinNetwork(), line, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == "(none)"
    assert current_if['media_options'] == []

# Generated at 2022-06-20 17:53:22.380807
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    f = DarwinNetwork()
    assert f.BOND_OPTS == \
        ('ad_select', 'arp_interval', 'arp_ip_target', 'arp_validate', 'fail_over_mac', 'lacp_rate', 'lacp_bypass',
         'lacp_bypass_allow', 'lacp_bypass_delay', 'min_links', 'mode', 'primary', 'primary_reselect', 'resend_igmp',
         'updelay', 'use_carrier', 'xmit_hash_policy')

# Generated at 2022-06-20 17:53:30.404827
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    curr_if = {}
    ips = {}
    words = ['media:', 'none', 'status:', 'active']
    net.parse_media_line(words, curr_if, ips)
    assert curr_if['media'] == 'Unknown'
    assert curr_if['media_select'] == 'none'
    assert curr_if['media_type'] == 'status'
    assert curr_if['media_options'] == 'active'

# Generated at 2022-06-20 17:53:36.304584
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # parse media line
    words = "media: <unknown type> status: inactive".split()
    current_if = {}
    current_if['name'] = "bridge0"
    ips = {}
    dn.parse_media_line(words, current_if, ips)

    assert(current_if['media_select'] == '<unknown')
    assert(current_if['media_type'] == 'type>')

# Generated at 2022-06-20 17:53:43.560983
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork('en0')
    assert isinstance(net, DarwinNetwork)
    # DarwinNetwork module overrides these defaults
    assert net.config_scope == 'user'
    assert net.config_exclude == ['lo0', 'gif0', 'stf0', 'XHC1']
    assert net.config_scope == 'user'
    assert isinstance(net.defaults, dict)
    assert isinstance(net.defaults['enabled'], bool)
    assert net.defaults['enabled'] == True
    assert isinstance(net.defaults['ipv4'], bool)
    assert net.defaults['ipv4'] == True
    assert isinstance(net.defaults['ipv6'], bool)
    assert net.defaults['ipv6'] == False

# Generated at 2022-06-20 17:53:43.962230
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:44.702181
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:46.397094
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Not implemented, as instantiation is not required for this class
    assert True

# Generated at 2022-06-20 17:53:56.990522
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test to see that a media line of text is parsed correctly
    """
    # First test the default FreeBSD parsing
    current_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': None}
    mynetwork = DarwinNetwork()
    mynetwork.parse_media_line(['media:','1000baseTX', '(none)'], current_if, None)
    assert 'media' in current_if
    assert current_if['media_select'] == '1000baseTX'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == None

    # Now test the version of the parsing for MacOSX

# Generated at 2022-06-20 17:54:01.204557
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net_inst = DarwinNetwork()
    assert net_inst._fact_class == 'Darwin'

# Generated at 2022-06-20 17:54:11.151718
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    input = {
        'current_if': {},
        'ips': {},
        'words': ['media:', '<unknown', 'type>']
    }
    subject = DarwinNetwork()
    subject.parse_media_line(**input)
    assert input['current_if'] == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    # test with media 'autoselect'
    input = {
        'current_if': {},
        'ips': {},
        'words': ['media:', 'autoselect', '(100baseTX)'],
    }
    subject.parse_media_line(**input)

# Generated at 2022-06-20 17:54:13.165599
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Unit test for DarwinNetwork
    """
    DarwinNetwork()


# Generated at 2022-06-20 17:54:22.848430
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_if = DarwinNetwork()
    ifconfig = {'ifconfig_path': '/sbin/ifconfig'}
    mac_if.get_network_facts(ifconfig)

    # media line is different to the default BSD one so it has it's own method
    facts = mac_if.parse_media_line(['media:', 'autoselect', 'Wi-Fi'], {}, {})
    assert facts['media'] == 'Unknown'
    assert facts['media_select'] == 'autoselect'
    assert facts['media_type'] == 'Wi-Fi'
    assert len(facts['media_options']) == 0

    # for some interfaces there is no media_line
    facts = mac_if.parse_media_line(['some line'], {}, {})
    assert facts['media'] is None
    assert facts

# Generated at 2022-06-20 17:54:24.048375
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This function returns the facts of Darwin
    """
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:25.131122
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork(None, platform='Darwin')
    assert d is not None

# Generated at 2022-06-20 17:54:27.403827
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Create an instance of GenericBsdIfconfigNetwork to test methods
    of class DarwinNetwork
    """
    darwin_network = DarwinNetwork(None)
    assert isinstance(darwin_network, DarwinNetwork)


# Generated at 2022-06-20 17:54:29.696100
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
   network_collector = DarwinNetworkCollector()
   assert network_collector.fact_class == DarwinNetwork

# Generated at 2022-06-20 17:54:33.008478
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector._platform == 'Darwin'
    assert DarwinNetworkCollector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:54:34.926789
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_class = DarwinNetwork({})
    assert test_class.platform == 'Darwin'
    assert test_class.get_facts() == {}

# Generated at 2022-06-20 17:54:47.814976
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    fact_network = DarwinNetwork()

    # Test case 1
    test_words = ['media:', 'autoselect', '(1000baseT <full-duplex>)']
    test_media_data = ['Unknown', 'autoselect', '(1000baseT <full-duplex>)']
    test_current_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(1000baseT <full-duplex>)'}

    assert fact_network.parse_media_line(test_words, test_current_if, None) == test_media_data

    # Test case 2
    test_words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    test_media_data = ['Unknown', '<unknown', 'type>', 'status:', 'inactive']

# Generated at 2022-06-20 17:54:52.894142
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = []
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    darwin = DarwinNetwork()
    darwin.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}



# Generated at 2022-06-20 17:55:02.769049
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    dnet.parse_media_line(['media:', 'autoselect'], {}, {})
    assert dnet.ifdict[0]['media'] == 'Unknown'
    assert dnet.ifdict[0]['media_select'] == 'autoselect'
    dnet.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert dnet.ifdict[0]['media'] == 'Unknown'
    assert dnet.ifdict[0]['media_select'] == 'Unknown'
    assert dnet.ifdict[0]['media_type'] == 'unknown type'
    dnet.parse_media_line(['media:', '10baseT/UTP', '(none)'], {}, {})

# Generated at 2022-06-20 17:55:04.756512
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    We check for the correct platform, but this is not really a test
    unless the platform is Darwin
    """
    assert DarwinNetwork().platform == 'Darwin'

# Generated at 2022-06-20 17:55:07.375157
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    facts = DarwinNetworkCollector()
    assert(facts.platform == 'Darwin')

# Generated at 2022-06-20 17:55:18.646575
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {'media': ''}
    test_word_1 = ['media', 'autoselect', '(none)']
    test_word_2 = ['media', '<unknown', 'type>']
    test_word_3 = ['media', 'autoselect', '(none)', 'status:', 'inactive']
    test_word_4 = ['media', 'autoselect', '10baseT/UTP', 'status:', 'inactive']
    test_word_5 = ['media', 'autoselect', '100baseT', 'full-duplex', 'status:', 'active']

    # test_word_1
    darwin_network.parse_media_line(test_word_1, current_if, None)

# Generated at 2022-06-20 17:55:21.669900
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Make sure NetworkCollector is correctly initialized
    """
    module = AnsibleModule(argument_spec={})
    network_obj = DarwinNetworkCollector(module=module)
    assert network_obj.module == module
    assert isinstance(network_obj._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:55:26.821853
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    DarwinNetwork().parse_media_line(['media:', 'autoselect', '(none)'], current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none', 'media_options': None}
    DarwinNetwork().parse_media_line(['media:', '<unknown', 'type>'], current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': None}

# Generated at 2022-06-20 17:55:34.645944
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type> media <unknown type>'
    expected = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    macos = DarwinNetwork({})
    iface = {}
    macos.parse_media_line(line.split(), {}, {})
    # assertEqual does not take into account order of dictionary keys(values)
    assert(iface['media'] == expected['media'])
    assert(iface['media_select'] == expected['media_select'])
    assert(iface['media_type'] == expected['media_type'])

# Generated at 2022-06-20 17:55:35.922796
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == "Darwin"

# Generated at 2022-06-20 17:55:52.674279
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = {'media': 'Unknown',
            'media_select': 'autoselect', 'media_type': 'none',
            'media_options': None}
    get_ifconfig_output = lambda *args: ('foo0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500\n    options=8<VLAN_MTU>\n    ether 00:26:bb:6c:1b:03\n    inet6 fe80::226:bbff:fe6c:1b03%foo0 prefixlen 64 scopeid 0x3\n    autoselect (none) status: active\n')
    network = DarwinNetwork('fake_device', get_ifconfig_output)

# Generated at 2022-06-20 17:56:01.459989
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # darwin_network_instance is a DarwinNetwork instance
    darwin_network_instance = DarwinNetwork()
    # this is the content of the words parameter
    input_words = [ 'media:',
                    'autoselect',
                    '(1000baseT',
                    '<full-duplex,flow-control,master>)' ]
    # this is the expected value of the current_if parameter
    expected_current_if = { 'media': 'Unknown',
                            'media_select': 'autoselect',
                            'media_type': '1000baseT',
                            'media_options': { 'flow-control': '',
                                               'full-duplex': '',
                                               'master': '' } }
    # this executes the actual test_parse_media_line method
    darwin_network_instance.parse

# Generated at 2022-06-20 17:56:03.046238
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert isinstance(instance, NetworkCollector)

# Generated at 2022-06-20 17:56:07.269526
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # In this test we are going to test the NetworkCollector class
    # that DarwinNetworkCollector inherits from.

    # We will instantiate the class and then check for a few things
    c = NetworkCollector()

    # Check if the _fact_class variable is set correctly
    assert c._fact_class == NetworkCollector
    # Check if the _fact_class variable is set correctly
    assert c._platform == 'Generic'
    # Check if the _fact_class variable is set correctly
    assert c._collector_name == 'network'



# Generated at 2022-06-20 17:56:08.403254
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
  net = DarwinNetwork()
  assert net.platform == 'Darwin'

# Generated at 2022-06-20 17:56:19.329530
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.network import DarwinNetwork
    basic._ANSIBLE_ARGS = basic.parse_args([])
    current_if = {}
    ips = []
    # Parse a line with four words
    words = [None, '100baseTX', '<full-duplex,hw-loopback>']
    dn = DarwinNetwork()
    dn._current_if = {}
    dn._ips = []
    dn.parse_media_line(words, current_if, ips)
    res = {'media_select': '100baseTX', 'media_options': {'full-duplex': None, 'hw-loopback': None}, 'media': 'Unknown', 'media_type': 'full-duplex,hw-loopback'}
   

# Generated at 2022-06-20 17:56:22.081129
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():

    # Create a new DarwinNetworkCollector
    dn=DarwinNetworkCollector()

    # Check that the Platform is set correctly
    assert dn._platform == 'Darwin'

# Generated at 2022-06-20 17:56:23.479251
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork({}, {}, {})

    assert(obj.platform == 'Darwin')

# Generated at 2022-06-20 17:56:28.655231
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-20 17:56:32.149281
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    ifc = {}
    darwin_network.parse_media_line(['media:', 'autoselect', '802.11n'], ifc, {})
    assert ifc == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '802.11n'}
    ifc = {}
    darwin_network.parse_media_line(['media:', '<unknown', 'type>'], ifc, {})
    assert ifc == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-20 17:56:54.512441
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'


# Generated at 2022-06-20 17:56:56.812901
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'

# Generated at 2022-06-20 17:56:58.583074
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)


# Generated at 2022-06-20 17:57:09.642581
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # stub to simulate the ifconfig output
    class Stub:
        pass

    stub = Stub()
    stub.ifconfig_path = ''
    darwin_network = DarwinNetwork(stub)
    darwin_network.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], {}, {})
    assert darwin_network.interfaces['net0']['media'] == 'Unknown'
    assert darwin_network.interfaces['net0']['media_select'] == 'autoselect'
    assert darwin_network.interfaces['net0']['media_type'] == '10baseT/UTP'
    assert not darwin_network.interfaces['net0']['media_options']

# Generated at 2022-06-20 17:57:11.274179
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
   assert DarwinNetworkCollector.platform == 'Darwin'


# Generated at 2022-06-20 17:57:18.738809
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    a = DarwinNetworkCollector()
    assert a.platform == 'Darwin'


# test Darwin ifconfig output (using 'ifconfig -a' option)

# Generated at 2022-06-20 17:57:30.899893
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac = DarwinNetwork()

    # Test normal case
    words = 'media: autoselect (none) status: inactive'.split()
    current_if = {}
    mac.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == {}

    # Test more values
    words = 'media: autoselect <unknown type> status: inactive'.split()
    current_if = {}
    mac.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current

# Generated at 2022-06-20 17:57:37.412327
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.collect()
    for iface in ifc.interfaces.values():
        if iface['media'] == 'Unknown':
            assert iface['media_select'] != None
        else:
            assert iface['media_select'] == None
            assert iface['media_type'] != None
            assert iface['media_options'] != None


# Generated at 2022-06-20 17:57:48.492604
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    # Test for line media: <unknown type>
    words = ('media:', '<unknown', 'type>')
    current_if = {}
    d.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    # Test for line media: autoselect <full-duplex>
    words = ('media:', 'autoselect', '<full-duplex>')
    current_if = {}
    d.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-20 17:57:59.774380
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    options = {'loaded_into_kernel': False, 'gather_subset': 'all'}
    network_collector_obj = DarwinNetworkCollector(module_options=options)
    network_obj = DarwinNetwork(network_collector_obj)

    # Test for media_options
    words1 = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']