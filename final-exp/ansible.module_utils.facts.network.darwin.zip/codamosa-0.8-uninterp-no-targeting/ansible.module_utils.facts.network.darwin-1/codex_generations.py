

# Generated at 2022-06-20 17:48:49.028421
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = {'kernel': 'Darwin'}
    net = DarwinNetwork(facts)
    assert isinstance(net, DarwinNetwork)
    assert not net.use_ipv6


# Generated at 2022-06-20 17:48:59.646287
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:49:00.167121
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector

# Generated at 2022-06-20 17:49:02.114616
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    Tests that DarwinNetworkCollector is a subclass of NetworkCollector
    """

    assert issubclass(DarwinNetworkCollector, NetworkCollector)

# Generated at 2022-06-20 17:49:06.950106
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__name__ == "DarwinNetworkCollector"
    assert DarwinNetworkCollector._fact_class.__name__ == "DarwinNetwork"
    assert DarwinNetworkCollector._platform == 'Darwin'


# Generated at 2022-06-20 17:49:15.897809
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = ('<unknown type> status: active'
            '   supported media: autoselect <unknown type>')
    words = data.split()
    current_if = {"master": None, "type": None, "options": {}}

    DarwinNetwork().parse_media_line(words, current_if, {})
    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "unknown type"
    assert current_if['media_options'] == {}

# Generated at 2022-06-20 17:49:26.065839
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Set up test objects
    facts = {}

    # Check "media_select" darwin-specific option
    words = ['media:', 'autoselect', 'status:', 'inactive']
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'

    # Check "media_type" darwin-specific option
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'inactive']
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == '1000baseT'

    # Check that

# Generated at 2022-06-20 17:49:37.969944
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    # These tests are needed as the lines with 'media:' are not parsed correctly
    # by the parser.parse_ifconfig() method.
    # This is because the default parser does not have a parse_media_line
    # method to handle it - GenericBsdIfconfigNetwork does.
    # But the default parser does have a parse_media_line method so needs to
    # be overridden

    test_if = {}

    # test with media line with '<unknown type>:'
    test_words = [
        'media:',
        '<unknown',
        'type>',
        '802.11',
        '(autoselect)'
    ]
    obj.parse_media_line(test_words, test_if, [])
    assert test_if['media'] == 'Unknown'
    assert test_if

# Generated at 2022-06-20 17:49:47.831932
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network import DarwinNetwork
    from io import BytesIO

    current_if = {}
    ips = {}
    lines = [
        b'  media: <unknown type>',
        b'  media: <unknown type>',
        b'  media: autoselect',
        b'  media: autoselect (<unknown type> full-duplex, 10Gb/s, flow-control, no <unknown type>, rxpause)'
    ]

    # the media type is <unknown type>
    words = lines[0].split()
    gbn = GenericBsdIfconfigNetwork()
    dn = DarwinNetwork()

# Generated at 2022-06-20 17:49:53.152404
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Create an object of DarwinNetwork for testing
    :return:
    """
    dn = DarwinNetwork()


# Unit tests for parse_media_line of DarwinNetwork

# Generated at 2022-06-20 17:49:56.961808
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network = DarwinNetworkCollector()

    darwin_network.populate()

    assert darwin_network._platform == 'Darwin'

# Generated at 2022-06-20 17:50:00.810045
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Test instantiation of DarwinNetworkCollector class
    """
    network_collector = DarwinNetworkCollector()
    assert network_collector.platform == 'Darwin'
    assert network_collector._fact_class == DarwinNetwork
    assert network_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:50:01.732434
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert isinstance(obj, DarwinNetworkCollector)

# Generated at 2022-06-20 17:50:09.052757
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork('fake_module', 'fake_path')
    ifc = {'name': 'lo0'}
    ip4 = []
    words = ['media:', 'autoselect', '(none)']
    network.parse_media_line(words, ifc, ip4)
    assert ifc['media'] == 'Unknown'
    assert ifc['media_type'] == '(none)'
    assert ifc['media_select'] == 'autoselect'

# Generated at 2022-06-20 17:50:11.747128
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj._fact_class == DarwinNetwork
    assert obj._platform == "Darwin"

# Generated at 2022-06-20 17:50:13.410808
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin


# Generated at 2022-06-20 17:50:20.493469
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test method parse_media_line
    """
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], None, None)
    assert ifc.current_if['media'] == 'Unknown'
    assert ifc.current_if['media_select'] == 'autoselect'
    assert ifc.current_if['media_type'] == '10baseT/UTP'
    assert not ifc.current_if.get('media_options')

# Generated at 2022-06-20 17:50:22.848949
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    # check that the class is constructed OK
    assert isinstance(module, DarwinNetwork)
    assert module.platform == 'Darwin'

# Generated at 2022-06-20 17:50:23.439350
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:50:25.373337
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    x = DarwinNetworkCollector()
    assert x.platform == 'Darwin'

# Generated at 2022-06-20 17:50:32.946421
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:', '<unknown', 'type>', 'status:', 'inactive'], {}, None)
    assert darwin_network.current_if['media'] == 'Unknown'
    assert darwin_network.current_if['media_select'] == 'Unknown'
    assert darwin_network.current_if['media_type'] == 'unknown type'
    assert darwin_network.current_if['media_options'] == 'status:inactive'

    darwin_network.parse_media_line(['media:', 'autoselect', '(none)', 'status:', 'inactive'], {}, None)
    assert darwin_network.current_if['media'] == 'Unknown'
    assert dar

# Generated at 2022-06-20 17:50:33.919721
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:50:44.587404
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_net = DarwinNetwork()

# Generated at 2022-06-20 17:50:45.816287
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    f = DarwinNetwork()
    assert f.platform == 'Darwin'

# Generated at 2022-06-20 17:50:46.388520
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:50:53.778549
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    inet = DarwinNetwork()
    current_if = {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': ''}
    inet.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], current_if, 2)
    expected = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '10baseT/UTP', 'media_options': ''}
    if current_if != expected:
        raise RuntimeError("method parse_media_line did not work as expected")

# Generated at 2022-06-20 17:51:05.317919
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    macnet = DarwinNetwork()
    macnet.parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert macnet._current_if['media'] == 'Unknown'
    assert macnet._current_if['media_select'] == 'Unknown'
    assert macnet._current_if['media_type'] == 'unknown type'

    macnet = DarwinNetwork()
    macnet.parse_media_line(['media:', '100baseT', '<full-duplex>'], {}, {})
    assert macnet._current_if['media'] == 'Unknown'
    assert macnet._current_if['media_select'] == '100baseT'
    assert macnet._current_if['media_type'] == 'full-duplex'

    macnet = DarwinNetwork()

# Generated at 2022-06-20 17:51:07.193533
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'


# Generated at 2022-06-20 17:51:14.315173
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = []
    # Test 1: Test with 'media_select media_type media_options'
    words = ['media:', 'autoselect', '10baseT/UTP <full-duplex>', '(autoselect)']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == 'full-duplex'
    # Test 2: Test with 'media_select media_type'

# Generated at 2022-06-20 17:51:16.400799
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:51:23.754722
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # instantiate class
    c = DarwinNetworkCollector()
    assert isinstance(c, DarwinNetworkCollector)
    assert isinstance(c._fact_class, type(DarwinNetwork))
    assert isinstance(c._platform, type(''))

# Generated at 2022-06-20 17:51:26.205640
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
  # Test that we create a DarwinNetwork object
  mac_facts = DarwinNetwork()
  assert isinstance(mac_facts, DarwinNetwork)
  assert mac_facts.platform == 'Darwin'

# Generated at 2022-06-20 17:51:36.054730
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    test for DarwinNetwork.parse_media_line
    """
    darwin_network = DarwinNetwork()
    current_if = {}
    darwin_network.parse_media_line(['media_select', 'media_type'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert current_if['media_type'] == 'media_type'
    current_if = {}
    darwin_network.parse_media_line(['media_select'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'media_select'
    assert 'media_type' not in current_if.keys()



# Generated at 2022-06-20 17:51:37.145032
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert issubclass(DarwinNetworkCollector, NetworkCollector)

# Generated at 2022-06-20 17:51:48.814171
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    # create an instance of class DarwinNetwork
    n = DarwinNetwork

    # create a dictionary for test_if and add some necessary data to it
    test_if = dict()
    test_if['name'] = "en0"
    test_if['inet'] = ['192.168.0.1', '192.168.1.1']
    test_if['inet6'] = ['fe80::8e96:d6ff:fe09:a34', 'fe80::8e96:d6ff:fe09:a35']
    test_if['media_select'] = ''
    test_if['media_type'] = ''
    test_if['media_options'] = []

    # Act
    # parse a media_line with the use of parse_media_line method
    # the media_line is a bridge

# Generated at 2022-06-20 17:51:56.935859
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    DarwinNetwork.parse_media_line() Test Case
    """
    # Test case 1 - MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this if/else helps
    mac_osx_words = ['<unknown', 'type>']
    current_if = {'macaddress': 'de:ad:be:ef:13:37',
                  'bridge_ports': ['eth0'],
                  'driver': 'bridge',
                  'name': 'br0'}

# Generated at 2022-06-20 17:52:01.383245
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork()
    assert dn.platform == 'Darwin'
    assert dn.media_options == 'media: supported media options:'
    assert dn.media_select == 'media: selected media options:'

# Generated at 2022-06-20 17:52:11.216058
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Get a instance of class DarwinNetwork
    DarwinNetwork = DarwinNetwork()

    # Test parse_media_line method of class DarwinNetwork
    # 1. Media line with 3 words
    words = ['media:','autoselect','(1000baseT)']
    current_if = {}
    ips = {}
    DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown', 'media failed'
    assert current_if['media_select'] == 'autoselect', 'media_select failed'
    assert current_if['media_type'] == '1000baseT', 'media_type failed'
    assert current_if['media_options'] == {}, 'media_options failed'

    # 2. Media line with 4 words

# Generated at 2022-06-20 17:52:12.750152
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(None)
    assert dn is not None


# Generated at 2022-06-20 17:52:14.835474
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector_object = DarwinNetworkCollector()
    assert collector_object
    assert isinstance(collector_object._fact_class, DarwinNetwork)

# Generated at 2022-06-20 17:52:23.324513
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """This function instantiates a DarwinNetworkCollector object for testing"""
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:29.309032
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test when media line is well formatted
    current_if_1 = {
        'device': 'en0',
        'address': "",
        'ips': [
            {
                'address': 'fe80::dead:beaf:feed:cafe',
                'netmask': 'ffff:ffff:ffff:ffff::',
                'network': 'fe80::/64'
            }
        ],
        "media_select": "",
        "media": "",
        "media_type": "",
        "media_options": {}
    }
    media_line_1="media: autoselect status: active"
    assert DarwinNetwork._parse_media_line(media_line_1, current_if_1, current_if_1['ips']) == current_if_1
    # test when media line is not well formatted

# Generated at 2022-06-20 17:52:30.328431
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:32.518445
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    x=DarwinNetworkCollector()
    assert x._fact_class == DarwinNetwork
    assert x._platform == 'Darwin'

# Generated at 2022-06-20 17:52:33.850631
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dn = DarwinNetwork(None)
    assert dn.platform == 'Darwin'

# Generated at 2022-06-20 17:52:34.756686
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:52:46.485120
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create new instance of class DarwinNetwork
    test_DarwinNetwork = DarwinNetwork()

    # Media line [autoselect 100baseTX]
    words = ['Media:', 'autoselect', '100baseTX']
    current_if = {}
    test_DarwinNetwork.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == {}
    assert current_if['media_select'] == 'autoselect'

    # Media line [autoselect <unknown type>]
    words = ['Media:', 'autoselect', '<unknown', 'type>']
    current_if = {}

# Generated at 2022-06-20 17:52:51.327773
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # instantiate module with default values
    dn = DarwinNetwork()
    assert dn
    # invoke all of the getters to check that invariant holds
    assert dn.get_file_path() == ''
    assert dn.get_interfaces() == {}
    assert dn.get_interface_details() == {}
    assert dn.get_interfaces_ip() == {}

# Generated at 2022-06-20 17:52:59.704428
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test data
    # sample: <unknown type><unknown media><full-duplex><no flow-control>
    #         <unknown type><unknown media><simplex>
    #         <unknown type><no carrier>
    #         <unknown type><unknown media>
    mac_words1 = ['', '<unknown', 'type>', '<unknown', 'media>', '<full-duplex>',
                  '<no', 'flow-control>']
    mac_words2 = ['', '<unknown', 'type>', '<unknown', 'media>', '<simplex>']
    mac_words3 = ['', '<unknown', 'type>', '<no', 'carrier>']
    mac_words4 = ['', '<unknown', 'type>', '<unknown', 'media>']

    # set up test conditions
    current

# Generated at 2022-06-20 17:53:00.642551
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'

# Generated at 2022-06-20 17:53:13.205225
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj = DarwinNetworkCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:53:14.076466
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().fact_class == DarwinNetwork

# Generated at 2022-06-20 17:53:22.289157
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    print('Testing DarwinNetwork.parse_media_line')

    test_if = {
        'name': 'en0',
        'type': 'ether',
        'mtu': 1500,
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'none',
        'media_options': []
    }
    test_words = ['media:', 'autoselect', '(none)']
    test_ipv4 = []
    test_ipv6 = []
    dn = DarwinNetwork()
    dn.parse_media_line(test_words, test_if, test_ipv4, test_ipv6)


# Generated at 2022-06-20 17:53:23.420884
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert(obj.platform == 'Darwin')

# Generated at 2022-06-20 17:53:33.061074
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    iface = DarwinNetwork()
    iface.parse_media_line(['media:', '<unknown type>', '(none)'], {}, {})
    assert iface._interfaces['media_select'] == 'Unknown'
    assert iface._interfaces['media_type'] == 'unknown type'
    iface.parse_media_line(['media:', 'autoselect', '100baseTX'], {}, {})
    assert iface._interfaces['media_select'] == 'autoselect'
    assert iface._interfaces['media_type'] == '100baseTX'

# Generated at 2022-06-20 17:53:33.426346
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:33.932163
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    t = DarwinNetwork({})

# Generated at 2022-06-20 17:53:41.769103
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a mock class object which behaves like a dictionary
    testee = type('testee', (object,), {'foo': 'bar'})()
    # call method with object and parameters
    DarwinNetwork.parse_media_line(
        testee,
        ['media:', '100baseTX', '<full-duplex>', 'status:', 'active'],
        testee,
        ['a', 'b', 'c'])
    # assert that the method did modify the dictionary
    assert testee.media == 'Unknown'
    assert testee.media_select == '100baseTX'
    assert testee.media_type == 'full-duplex'
    assert testee.media_options == 'status: active'

# Generated at 2022-06-20 17:53:42.612500
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), DarwinNetworkCollector)


# Generated at 2022-06-20 17:53:45.770637
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    fact_module = DarwinNetworkCollector(None, None)
    assert fact_module._fact_class is DarwinNetwork
    assert fact_module._platform == 'Darwin'

# Generated at 2022-06-20 17:54:09.056436
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.get_device('lo0') is not None


# Generated at 2022-06-20 17:54:20.320672
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Basic unit test for DarwinNetwork class
    """
    # This is a dict of the parsed interface information

# Generated at 2022-06-20 17:54:24.231590
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    obj1 = DarwinNetworkCollector()
    obj2 = DarwinNetworkCollector()
    assert obj1 == obj2
    assert obj1 is not obj2
    assert isinstance(obj1, DarwinNetworkCollector)
    assert isinstance(obj1, NetworkCollector)
    assert obj1.__doc__ == str(NetworkCollector)


# Generated at 2022-06-20 17:54:29.758790
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type>'
    current_if = {}
    ips = []
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(line.split(' '), current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media'] == 'Unknown'
    assert 'media_options' not in current_if.keys()
    line = 'media: autoselect 10baseT/UTP status: inactive'
    current_if = {}
    ips = []
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(line.split(' '), current_if, ips)
    assert current_if

# Generated at 2022-06-20 17:54:39.908821
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    result_media_select = 'autoselect'
    result_media_type = '100baseTX'
    result_media_options = dict(full_duplex='full-duplex')
    input_arr = ['media:', 'autoselect', '100baseTX', '(full-duplex)']
    obj = DarwinNetwork()
    obj.parse_media_line(input_arr, dict(), dict())
    assert obj.fact_subset['en0']['media_select'] == result_media_select
    assert obj.fact_subset['en0']['media_type'] == result_media_type
    assert obj.fact_subset['en0']['media_options'] == result_media_options
    input_arr = ['media:', 'autoselect', '100baseTX']
    obj.parse_media

# Generated at 2022-06-20 17:54:41.997797
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Testing constructor of DarwinNetworkCollector
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:54:43.483424
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'

# Generated at 2022-06-20 17:54:53.590705
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = DarwinNetwork()

    # standard media line
    line = ['media:', '<unknown type>', '(none)']
    # expected result dict
    result = {
        'media': 'Unknown',
        'media_select': '<unknown type>',
        'media_type': '(none)',
        'media_options': '',
    }
    # actual result
    media_line.parse_media_line(line, {}, {})
    assert media_line.current_if == result

    # media line for bridge interface
    line = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    # expected result dict

# Generated at 2022-06-20 17:55:03.338508
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    # Use 'lo0' interface for testing
    # --------------------------------
    temp_file_path = '/tmp/ansible_test_lo0'

# Generated at 2022-06-20 17:55:07.354483
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.system == "Darwin"
    assert darwin_network.platform == "Darwin"
    assert darwin_network.profile_dir == "/etc/network"
    assert darwin_network.config_base_name == "network.d"
    assert darwin_network.config_file_paths is None
    assert darwin_network.interface_driver == "generic_bsd"
    assert darwin_network.connection_network_cli == "ifconfig"
    assert darwin_network.connection_network_file == "interfaces"
    assert darwin_network.default_output_format == "text"
    assert darwin_network.output_formats == ["text", "json"]

# Generated at 2022-06-20 17:56:44.931436
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for media line for ethernet interface
    words = ['media:', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = {'type': 'ether'}
    ips = {}
    DarwinNet = DarwinNetwork()
    DarwinNet.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert not current_if.get('media_options')
    # Test for media line for unknown interface
    # This line may be found on Mac OS X (10.10)
    words = ['media:', '<unknown', 'type>', 'status:', 'no', 'carrier']

# Generated at 2022-06-20 17:56:52.877085
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    collector = DarwinNetworkCollector(None)
    assert collector.fact_class is DarwinNetwork
    assert collector.platform == 'Darwin'
    assert collector._facts == {'all_ipv4_addresses': list,
                                'all_ipv6_addresses': list,
                                'default_ipv4': dict,
                                'default_ipv6': dict,
                                'device': 'lo0',
                                'groups': list,
                                'interfaces': list,
                                'mtu': 1500,
                                'netmask': '255.0.0.0',
                                'network': '127.0.0.0',
                                'promisc': False,
                                'type': 'loopback'}

# Generated at 2022-06-20 17:57:03.154225
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    inst = DarwinNetwork()

    # Test set 1
    test_data_set1 = 'unknown link type'
    test_data_words1 = test_data_set1.split()
    current_if1 = dict()
    ips1 = list()
    inst.parse_media_line(test_data_words1, current_if1, ips1)
    assert current_if1['media'] == 'Unknown'
    assert current_if1['media_select'] == test_data_words1[0]
    assert current_if1['media_type'] == test_data_words1[-1]

    # Test set 2
    test_data_set2 = '<unknown type>'
    test_data_words2 = test_data_set2.split()
    current_if2 = dict()
    ips2

# Generated at 2022-06-20 17:57:04.619404
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-20 17:57:12.935874
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    dnc = DarwinNetworkCollector()
    assert dnc.get_device_names() == []
    assert dnc.get_device('') == {}
    assert dnc.get_interfaces() == {}
    assert dnc.get_interfaces_map() == {}
    assert dnc.get_interfaces_ip() == {}
    assert dnc.get_interfaces_ifindex() == {}
    assert dnc.get_interfaces_ifindex_with_ip() == {}

# Generated at 2022-06-20 17:57:13.828931
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # test instantiated class
    assert DarwinNetworkCollector()

# Generated at 2022-06-20 17:57:20.637709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # create test case:
    test_case = {
        'media_select': 'none',
        'media_type': 'none',
        'media_options': {'none'}
    }
    # create a test input
    input_words = 'media: <unknown type>'.split()
    # run test
    dn.parse_media_line(input_words, test_case, '')
    # did we get what we expected?
    assert test_case['media'] == 'Unknown'
    assert test_case['media_select'] == 'none'
    assert test_case['media_type'] == 'unknown type'
    assert test_case['media_options'] == {'none'}

# Generated at 2022-06-20 17:57:31.457472
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:57:35.154759
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwinNetwork = DarwinNetwork(collect_func=None)
    assert darwinNetwork


# Generated at 2022-06-20 17:57:43.490698
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test media_select, media_type and media_options are
    extracted in the right way
    """
    test_obj = DarwinNetwork()
    current_if = {}

    test_obj.parse_media_line(
        ['media:', 'autoselect', '<unknown type>', 'status:', 'active'],
        current_if,
        {}
    )

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

    test_obj.parse_media_line(
        ['media:', 'autoselect', '(none)', 'status:', 'active'],
        current_if,
        {}
    )