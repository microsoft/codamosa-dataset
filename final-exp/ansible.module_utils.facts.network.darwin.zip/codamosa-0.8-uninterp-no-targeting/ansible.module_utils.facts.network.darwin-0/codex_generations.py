

# Generated at 2022-06-20 17:48:50.097112
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type> status: inactive'
    words = media_line.split()
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:48:53.659130
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    network_collector = DarwinNetworkCollector()
    assert network_collector._platform == 'Darwin'
    assert network_collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:49:02.266690
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # load the ifconfig output from a linux system
    (ifconfig_out, _err, _rc) = module_utils.run_command("ifconfig -a")
    # initialize the fact class
    fact = DarwinNetwork(module_utils.get_platform(), 'ifconfig', '', ifconfig_out, None)

    # check that the fact class is initialized
    assert fact is not None

    # check the number of interfaces returned
    interfaces = fact.populate()
    assert len(interfaces) == 2

    # ensure that each interface has the right data
    interface = interfaces['lo0']
    assert interface['device'] == 'lo0'
    assert len(interface['ipv4']) == 1
    assert interface['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-20 17:49:04.656491
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    instance = DarwinNetworkCollector()
    assert instance

# Generated at 2022-06-20 17:49:15.747570
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork('vmnet1', 'ether', 'vmnet1', '00:50:56:b9:37:d0', '', '', '', '', '', '', '', '', '', '', '',
                      '', '', '', '', '', '', '', '', '', '', '', '', '', {}, {}, {}, '', '', '', '', '', '', '', '', '', '', '',
                      '', {}, {}, {}, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
                      '', '', '', '', '', '', '', '', '')

    assert d.media == 'Unknown'


# Unit

# Generated at 2022-06-20 17:49:17.812163
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    col = DarwinNetwork()
    assert col is not None
    assert col.path == '/sbin/ifconfig'

# Generated at 2022-06-20 17:49:19.998546
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    d = DarwinNetworkCollector()
    assert d._fact_class == DarwinNetwork
    assert d._platform == 'Darwin'


# Generated at 2022-06-20 17:49:21.769481
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    try:
        d=DarwinNetworkCollector()
    except:
    	assert False

# Generated at 2022-06-20 17:49:22.700686
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-20 17:49:30.838792
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(["media:", "autoselect", "(none)"], {"name": "bridge100"}, [])
    assert ifc.interfaces == {"name": "bridge100", "media": "Unknown", "media_select": "autoselect", "media_type": "(none)"}

    ifc = DarwinNetwork()
    ifc.parse_media_line(["media:", "autoselect", "(none)", "status:", "inactive"], {"name": "bridge100"}, [])
    assert ifc.interfaces == {"name": "bridge100", "media": "Unknown", "media_select": "autoselect", "media_type": "(none)", "media_options": {'status': 'inactive'}}

    ifc = DarwinNetwork()
    ifc.parse_media

# Generated at 2022-06-20 17:49:33.746391
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert network.platform == 'Darwin'

# Generated at 2022-06-20 17:49:35.957253
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = DarwinNetwork(None)
    assert isinstance(facts,DarwinNetwork)


# Generated at 2022-06-20 17:49:37.095001
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert isinstance(DarwinNetworkCollector(), NetworkCollector)

# Generated at 2022-06-20 17:49:37.818712
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:49:47.672130
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    n = DarwinNetwork()
    words = "media: <unknown type>".split()
    current_if = {'media_select': 'autoselect',
                  'media_options': 'none'}
    ips = {}
    n.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'none'

    words = "media: autoselect (100baseTX <full-duplex>)".split()
    current_if = {'media_select': 'autoselect',
                  'media_options': 'none'}
    ips = {}

# Generated at 2022-06-20 17:49:54.028243
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:',
             '<unknown type>']
    current_if = {}
    ips = []
    dn.parse_media_line(words=words, current_if=current_if, ips=ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:49:55.525510
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork(None, None, None)
    assert network


# Generated at 2022-06-20 17:50:04.510488
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-20 17:50:10.271873
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {'interface': 'bridge1'}
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(words, interface)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:50:21.083504
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a DarwinNetwork for testing
    darwin_network = DarwinNetwork()

    # Create a Fake data for the test
    fake_current_data = {
        'media': 'Unknown',
        'media_select': '',
        'media_type': '',
        'media_options': '',
    }
    fake_ips = []

    # Test with a list of words contain the most data that darwin ifconfig can present
    # in the media line
    words = ['media:', 'none', 'status:', 'inactive']
    darwin_network.parse_media_line(words, fake_current_data, fake_ips)
    assert fake_current_data['media'] == 'Unknown'
    assert fake_current_data['media_select'] == 'none'

# Generated at 2022-06-20 17:50:26.581831
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """
    This is to test the constructor of DarwinNetworkCollector class.
    """
    # There is no constructor for this class
    os_facts = DarwinNetworkCollector()
    assert os_facts.platform == 'Darwin'

# Generated at 2022-06-20 17:50:29.951335
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dar = DarwinNetwork(None)
    print(dar.get_device_name('lo0'))
    print(dar.get_device_name('en0'))
    assert dar.get_device_name('en0') == 'en0'
    assert dar.get_device_name('en0') == 'en0'

# Generated at 2022-06-20 17:50:37.114470
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test the DarwinNetwork constructor."""
    dn1 = DarwinNetwork()
    assert dn1.platform == 'Darwin'
    assert dn1._platform == 'Darwin'
    assert dn1.facts == {}
    assert dn1._fact_class == DarwinNetwork
    assert dn1._fact_subclasses == dict()
    assert dn1._fact_class._platform == 'Darwin'



# Generated at 2022-06-20 17:50:46.297028
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line("media: autoselect <unknown type>", dict(), dict())
    assert ifc.facts['all_ipv4_addresses']['en5']['media'] == 'Unknown'
    assert ifc.facts['all_ipv4_addresses']['en5']['media_select'] == 'autoselect'
    assert ifc.facts['all_ipv4_addresses']['en5']['media_type'] == 'unknown type'
    assert not ifc.facts['all_ipv4_addresses']['en5'].get('media_options')
    ifc.parse_media_line("media: autoselect <unknown type> (100baseTX <full-duplex>)", dict(), dict())
    assert ifc

# Generated at 2022-06-20 17:50:56.862473
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork('')

    # unit_test_dn is the output of ifconfig
    # we have saved here so we don't have to run ifconfig

# Generated at 2022-06-20 17:50:59.117099
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    # Instantiate DarwinNetworkCollector object
    collector = DarwinNetworkCollector()
    assert collector is not None


# Generated at 2022-06-20 17:51:01.887306
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    darwin_network_collector = DarwinNetworkCollector()
    assert darwin_network_collector.__class__.__name__ =='DarwinNetworkCollector'

# Generated at 2022-06-20 17:51:11.570672
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'autoselect', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_status'] == 'inactive'
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_status'] == 'inactive'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:51:13.523312
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector.__init__(DarwinNetworkCollector)

# Generated at 2022-06-20 17:51:17.111376
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    nc = DarwinNetworkCollector()
    assert nc is not None
    assert nc._platform == 'Darwin'
    assert nc._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:51:33.169738
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this if/else helps
    # Test case 1
    facts = Facts(dict())
    interface = DarwinNetwork(facts, None)
    words = ['media:', '<unknown', 'type>', '(none)', '(none)']
    current_if = dict()
    interface.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # Test case 2

# Generated at 2022-06-20 17:51:34.361762
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork.platform == 'Darwin'



# Generated at 2022-06-20 17:51:34.861299
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork({})

# Generated at 2022-06-20 17:51:35.353908
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:51:36.457135
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mac_network = DarwinNetwork()
    assert mac_network.platform == 'Darwin'

# Generated at 2022-06-20 17:51:37.614393
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork(None) is not None

# Generated at 2022-06-20 17:51:49.642920
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    dn = DarwinNetwork()
    current_if = {}
    words = ['media:', 'autoselect', 'status:', 'active', 'media', 'type']
    ips = {}
    dn.parse_media_line(words, current_if, ips)

    assert (current_if['media_select'] == 'autoselect' and
            current_if['media_type'] == 'type' and
            not current_if.get('media') and
            not current_if.get('media_options'))

    current_if = {}
    words = ['media:', 'autoselect', 'status:', 'active']
    dn.parse_media_line(words, current_if, ips)


# Generated at 2022-06-20 17:51:58.864164
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test data to run tests against
    test_data = [
        ['media: autoselect (<unknown type>)'],
        ['media: 10baseT/UTP <aoutx>'],
        ['media: 10baseT/UTP <full-duplex>'],
        ['media: 10baseT/UTP'],
        ['media: <unknown type>'],
    ]

    # Expected output for the test data

# Generated at 2022-06-20 17:52:01.676587
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    result = DarwinNetworkCollector()
    assert result.platform == 'Darwin'
    assert result._fact_class == DarwinNetwork


# Generated at 2022-06-20 17:52:11.473558
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # input & expected output
    input_words1 = ['media:','autoselect','<unknown type>', 'status']
    input_words2 = ['media:', '1000baseX', '(none)', '']
    input_words3 = ['media:', '1000baseX', '(none)']

    current_if1 = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': 'status'}
    current_if2 = {'media': 'Unknown', 'media_select': '1000baseX', 'media_type': '(none)', 'media_options': ''}
    current_if3 = {'media': 'Unknown', 'media_select': '1000baseX', 'media_type': '(none)', 'media_options': ''}

    # test output from

# Generated at 2022-06-20 17:52:33.890199
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Create instance of DarwinNetwork
    Darwin_net = DarwinNetwork()

    # Testing of media line for 'Autoselect': 'Autoselect ('1000baseT'): active'
    words = ['Autoselect', '(1000baseT)', 'active']
    current_if = {'device': 'igb0', 'media_select': '', 'media_type': '', 'media_options': [], 'media': ''}
    Darwin_net.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == 'Autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['active']

    # Testing of media line for '

# Generated at 2022-06-20 17:52:35.090733
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()

# Generated at 2022-06-20 17:52:38.638237
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from os import path
    from ansible.module_utils.facts.network.darwin import DarwinNetworkCollector
    a = DarwinNetworkCollector()
    assert a._platform == 'Darwin'


# Generated at 2022-06-20 17:52:41.324567
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork({})
    assert obj._fact_class is DarwinNetwork
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:52:43.052892
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    collector = DarwinNetworkCollector()
    assert collector._platform == 'Darwin'



# Generated at 2022-06-20 17:52:53.396230
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    ips = {}
    test_words = ["media:", "none", "status:", "inactive", "id:", "0", "device:", "lo0"]
    d.parse_media_line(test_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'none'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if
    test_words = ["media:", "<unknown", "type>", "(none)", "status:", "inactive", "id:", "0", "device:", "lo0"]
    d.parse_media_line(test_words, current_if, ips)
    assert current_

# Generated at 2022-06-20 17:52:54.286299
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()


# Generated at 2022-06-20 17:53:01.661390
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    test_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': None}
    dn.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], test_if, '')
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '10baseT/UTP'
    assert test_if['media_options'] == None

    dn.parse_media_line(['media:', '<unknown', 'type>'], test_if, '')
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'

# Generated at 2022-06-20 17:53:12.467309
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create dummy DarwinNetwork instance
    class DarwinNetworkFact:
        platform = 'Darwin'
    DarwinNetworkMock = DarwinNetworkFact()

    # create dicitionary for current_if
    current_if = {}

    # test for first use case
    input_words = ['media:', 'autoselect', 'status:', 'active']
    input_ips = []
    DarwinNetworkMock.parse_media_line(input_words, current_if, input_ips)
    expected_output = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'status',
                       'media_options': 'active'}
    assert(current_if == expected_output)

    # test for second use case
    input_words = ['media:', '<unknown', 'type>']
    input_ips

# Generated at 2022-06-20 17:53:16.697735
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Empty object
    darwinnet = DarwinNetwork()

    # Input and output network data
    darwinnet_input_netdata = {'iface': {'name': 'en0'}, 'inet': {'inet': '192.168.1.101'}, 'netmask': {'inet': '0xffffff00'}, 'addr_select': {'inet': '0x1'}}

# Generated at 2022-06-20 17:53:36.651362
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-20 17:53:37.549506
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-20 17:53:44.467273
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'media':'Unknown', 'media_select':'autoselect', 'media_type':'', 'media_options':''}
    test_words = ['media', 'autoselect', '(none)']
    network = DarwinNetwork()
    network.parse_media_line(test_words, test_if, {})
    assert test_if == {'media':'Unknown', 'media_select':'autoselect', 'media_type':'none', 'media_options':''}

    test_if = {'media':'Unknown', 'media_select':'', 'media_type':'', 'media_options':''}
    test_words = ['media', 'autoselect', '(1000baseX)', 'full-duplex']
    network = DarwinNetwork()

# Generated at 2022-06-20 17:53:45.671876
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    assert DarwinNetworkCollector().platform == 'Darwin'

# Generated at 2022-06-20 17:53:54.883405
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """ Test the constructor of class DarwinNetworkCollector

    The constructor of the DarwinNetworkCollector should be called:
        - with minimal argument (platform)
        - with all available argument

    The DarwinNetworkCollector instance should have:
        - the correct network_provider value
        - the correct platform value
        - the correct fact_class value

    """
    darwin_net_collector_minimal = DarwinNetworkCollector(
        'Darwin'
    )
    assert darwin_net_collector_minimal.network_provider is None
    assert darwin_net_collector_minimal.platform == 'Darwin'
    assert darwin_net_collector_minimal.fact_class == DarwinNetwork


# Generated at 2022-06-20 17:53:55.874457
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:53:59.051601
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    from ansible.module_utils.facts.plugins.network.darwin import DarwinNetworkCollector
    collector = DarwinNetworkCollector()
    assert collector._fact_class == DarwinNetwork

# Generated at 2022-06-20 17:54:02.986612
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # set up
    net_tool = DarwinNetwork()
    # assert
    assert isinstance(net_tool, DarwinNetwork)
    assert isinstance(net_tool, GenericBsdIfconfigNetwork)
    assert net_tool.platform == 'Darwin'
    assert net_tool.collect() is not None


# Generated at 2022-06-20 17:54:13.857854
# Unit test for constructor of class DarwinNetworkCollector

# Generated at 2022-06-20 17:54:16.586105
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ Test the initialization of the Network Class """
    facts = dict()
    fact_class = DarwinNetwork(facts=facts, options=None)
    assert fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:55:00.960981
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    f = DarwinNetwork()
    assert f.facts == {'interfaces': {}, 'all_ipv4_addresses': set(), 'all_ipv6_addresses': set(), 'default_ipv4': {}, 'default_ipv6': {}}
    assert f.platform == 'Darwin'

# Generated at 2022-06-20 17:55:10.812475
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'name': 'en0'}
    words = ['media:', 'autoselect']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media'] == 'Unknown'
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media'] == 'Unknown'
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
   

# Generated at 2022-06-20 17:55:12.484871
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:55:12.993421
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-20 17:55:14.161626
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert isinstance(obj, DarwinNetwork)

# Generated at 2022-06-20 17:55:15.308106
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Construct a DarwinNetworkCollector object"""
    assert DarwinNetworkCollector is not None

# Generated at 2022-06-20 17:55:24.720060
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a DarwinNetwork object to call the method parse_media_line
    Darwin_ifconfig_network_object = DarwinNetwork()
    # create a dict to store the media line
    Darwin_current_if = dict()

    # create an array of different words to test the method parse_media_line
    # test case 1
    words_1 = ['media:', '<unknown type>']
    # call the method parse_media_line with iphone
    Darwin_ifconfig_network_object.parse_media_line(words_1, Darwin_current_if, [])
    # assert result - media line 1
    assert Darwin_current_if['media'] == 'Unknown'
    assert Darwin_current_if['media_select'] == 'Unknown'
    assert Darwin_current_if['media_type'] == 'unknown type'

    # create an

# Generated at 2022-06-20 17:55:31.647698
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    dm = DarwinNetwork()
    assert dm.platform == 'Darwin'
    assert 'all_ipv4_addresses' in dm.facts
    assert 'default_ipv4' in dm.facts
    assert 'interfaces' in dm.facts
    assert 'all_ipv6_addresses' in dm.facts
    assert 'default_ipv6' in dm.facts


# Generated at 2022-06-20 17:55:41.460801
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    macnetwork = DarwinNetwork()
    current_if = {'macaddress': '78:ac:c0:ff:00:00', 'subnets': [], 'addresses': {}}
    macnetwork.parse_media_line(['media:', '<unknown', 'type>'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type'
    assert current_if['media_options'] == []
    current_if = {'macaddress': '78:ac:c0:ff:00:00', 'subnets': [], 'addresses': {}}

# Generated at 2022-06-20 17:55:41.943693
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    DarwinNetworkCollector()

# Generated at 2022-06-20 17:56:50.152713
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    print("**** TEST: _parse_media_line")
    ifcfg = DarwinNetwork()
    ifcfg._parse_media_line([], 0, [])
    ifcfg._parse_media_line(['media:', '10baseT/UTP'], 0, [])
    ifcfg._parse_media_line(['media:', '<unknown', 'type>'], 0, [])
    ifcfg._parse_media_line(['media:', '10baseT/UTP', '(none)'], 0, [])
    ifcfg._parse_media_line(['media:', '10baseT/UTP', '(autoselect)'], 0, [])
    ifcfg._parse_media_line(['media:', '10baseT/UTP', '(autoselect)'], 0, [])
    ifcfg._parse_media_

# Generated at 2022-06-20 17:57:01.699997
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 'media' and 'media_select'
    d = DarwinNetwork()
    d.parse_media_line(['media:', 'autoselect', '(unknown)'], {}, {})
    assert d.current_if['media'] == 'Unknown'
    assert d.current_if['media_select'] == 'autoselect'
    # Test 'media_type' which is (unknown)
    assert d.current_if['media_type'] == '(unknown)'
    # Test 'media_type' which is 10baseT
    d = DarwinNetwork()
    d.parse_media_line(['media:', 'autoselect', '10baseT'], {}, {})
    assert d.current_if['media_type'] == '10baseT'
    # Test 'media_options'
    d = DarwinNetwork()
    d

# Generated at 2022-06-20 17:57:07.832760
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    r = DarwinNetwork()
    r.parse_media_line(['media:','<unknown','type>'], {}, {})
    assert r._current_if['media'] == 'Unknown'
    assert r._current_if['media_select'] == '<unknown'
    assert r._current_if['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:57:17.250370
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = []
    ips = {}
    obj = DarwinNetwork()

    # Test case1
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert 'media_options' not in current_if

    # Test case2
    words = ['media:', '1000baseT', '(none)', 'status:', 'active']
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_

# Generated at 2022-06-20 17:57:30.047596
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    expected = """{"lo0": {"device": "lo0", "flags": ["UP", "LOOPBACK", "RUNNING"], "hwaddr": "00:00:00:00:00:00", "ipv4": [{"address": "127.0.0.1", "broadcast": "N/A", "netmask": "8"}, {"address": "::1", "broadcast": "N/A", "netmask": "128"}], "media": "Unknown", "media_select": "autoselect", "media_type": "autoselect", "mtu": 16384, "type": "loopback"}, "vboxnet1": {"device": "vboxnet1", "ipv4": [], "mtu": 1500, "type": "ethernet"} }"""

# Generated at 2022-06-20 17:57:36.483205
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork({})
    media = network.parse_media_line(words=['media:', '<unknown', 'type>'], current_if={}, ips={})
    assert media['media'] == 'Unknown'
    assert media['media_select'] == 'Unknown'
    assert media['media_type'] == 'unknown type'

# Generated at 2022-06-20 17:57:48.091238
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = dict()
    ips = dict()
    words1 = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    darwin_network.parse_media_line(words1, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == dict()

    current_if = dict()
    ips = dict()
    words2 = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    darwin_network.parse_media_line(words2, current_if, ips)


# Generated at 2022-06-20 17:57:51.519501
# Unit test for constructor of class DarwinNetworkCollector
def test_DarwinNetworkCollector():
    """Unit test for constructor of class DarwinNetworkCollector"""
    expected_result = {'default-network-collector-class': DarwinNetworkCollector,
                       'platform': 'Darwin', 'fact-class': DarwinNetwork}
    # Test with no optional arguments
    obj = DarwinNetworkCollector()
    assert type(obj) is DarwinNetworkCollector
    assert obj._fact_class is DarwinNetwork
    assert obj._platform is 'Darwin'

# Generated at 2022-06-20 17:58:01.150245
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork({})
    current_if = {}

    darwin_network.parse_media_line(['media:', 'autoselect', '(100baseTX)'], current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == []

    darwin_network.parse_media_line(['media:', '<unknown', 'type>'], current_if, [])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == []


# Generated at 2022-06-20 17:58:10.250777
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['foo']

    # Test1: Word is not a media line
    DarwinNetwork.parse_media_line(words, current_if, None)
    assert 'media' not in current_if
    assert 'media_select' not in current_if

    # Test2: Word is a media line but length is 1
    words = ['media:', 'foo']
    DarwinNetwork.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'foo'

    # Test3: Word is a media line and length is 2
    words = ['media:', 'foo', 'bar']
    DarwinNetwork.parse_media_line(words, current_if, None)