

# Generated at 2022-06-24 22:29:48.187195
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_1 = b'1G inet6 fe80::6c40:6aff:feaa:21a8%en0 prefixlen 64 scopeid 0x4'
    bytes_2 = b'<unknown type> status: inactive'
    bytes_3 = b'Ethernet'
    darwin_network_1 = DarwinNetwork(bytes_1)
    results = darwin_network_1.parse_media_line(bytes_2.split(), {}, {})
    assert results['media'] == 'Unknown'
    assert results['media_select'] == '<unknown type>'
    assert results['media_type'] == 'type>'
    assert results['media_options'] == {'status': 'inactive'}

# Generated at 2022-06-24 22:29:57.284319
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-24 22:30:04.597172
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test DarwinNetwork parse_media_line
    """

    # create a DarwinNetwork object
    bytes_1 = b'p'
    darwin_network_1 = DarwinNetwork(bytes_1)

    # create the words param
    words_1 = 'autoselect status: inactive'

    # create the current_if param
    current_if_1 = dict()

    # create the ips param
    ips_1 = dict()

    # call the method parse_media_line
    darwin_network_1.parse_media_line(words_1, current_if_1, ips_1)

    # assert that current_if['media'] has the expected value
    assert current_if_1['media'] == 'Unknown'

    # assert that current_if['media_select'] has the expected value

# Generated at 2022-06-24 22:30:07.350153
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    bytes_0 = b'p'
    darwin_network_0 = DarwinNetwork(bytes_0)
    if darwin_network_0.platform != 'Darwin':
        raise Exception()


# Generated at 2022-06-24 22:30:12.289126
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_1 = b''
    darwin_network_1 = DarwinNetwork(bytes_1)
    words_2 = ['media:','unknown','<unknown type>','status:','active','\n']
    current_if_3 = {}
    ips_4 = {}
    darwin_network_1.parse_media_line(words_2, current_if_3, ips_4)

# Generated at 2022-06-24 22:30:14.287825
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
   bytes_0 = b'p'
   darwin_network_0 = DarwinNetwork(bytes_0)
   words_0 = []
   current_if_0 = {}
   ips_0 = {}
   darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)



# Generated at 2022-06-24 22:30:24.373742
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Initializing byte_string
    byte_string = b"lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384\n" \
                  b"options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>\n" \
                  b"    inet 127.0.0.1 netmask 0xff000000\n" \
                  b"    inet6 ::1 prefixlen 128\n" \
                  b"    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1\n" \
                  b"    nd6 options=201<PERFORMNUD,DAD>\n" \
                  b"gif0: flags=8010<POINTOPOINT,MULTICAST> mtu 1280\n"

# Generated at 2022-06-24 22:30:34.211631
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-24 22:30:37.013602
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    try:
        test_case_0()
    except (NameError, UnboundLocalError):
        assert False, "constructor not found"


# Generated at 2022-06-24 22:30:41.381069
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    bytes_0 = b'p'
    darwin_network_0 = DarwinNetwork(bytes_0)

if __name__ == '__main__':
    test_case_0()
# End of generated code

# Generated at 2022-06-24 22:30:49.876984
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Create an instance of class DarwinNetwork
    darwin_network = DarwinNetwork(None)

    # Set up parameters
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive\n']
    current_if = {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'unknown type', 'media_options': {'status': 'inactive'}}
    ips = '255.0.0.0'

    # Call method under test
    result = darwin_network.parse_media_line(words, current_if, ips)

    # Assert results
    assert result == None


# Generated at 2022-06-24 22:30:57.174331
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    Test to ensure media line is parsed correctly
    '''
    bsd_class = DarwinNetwork()
    current_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': None}
    words = ['media:', 'autoselect', '(none)']
    bsd_class.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    words = ['media:', '<unknown', 'type>']
    bsd_class.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if

# Generated at 2022-06-24 22:31:06.116719
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork(None)
    dn.parse_media_line(['media', 'autoselect', 'none'], {}, {})
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == 'autoselect'
    assert dn.current_if['media_type'] == 'none'
    dn.parse_media_line(['media', 'manual'], {}, {})
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_select'] == 'manual'
    assert dn.current_if['media_type'] is None
    dn.parse_media_line(['media', '<unknown', 'type>'], {}, {})
    assert dn.current_

# Generated at 2022-06-24 22:31:15.040967
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork({}, bytes_0)
    assert len(d.interfaces) == 2
    assert d.interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert d.interfaces['lo0']['hwaddr'] == 'Unknown'
    assert d.interfaces['lo0']['inet'] == ['127.0.0.1']
    assert d.interfaces['lo0']['inet6'] == ['::1', 'fe80::1%lo0']
    assert d.interfaces['lo0']['netmask'] == ['0xff000000']
    assert d.interfaces['lo0']['prefixlen'] == ['128', '64']

# Generated at 2022-06-24 22:31:26.651776
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_run = DarwinNetwork('lo0', bytes_0, '127.0.0.1')
    assert test_run.device == 'lo0'
    assert test_run.ipv4 is None
    assert test_run.ipv6 is None
    assert test_run.capabilities == 'LOOPBACK,RUNNING,MULTICAST'
    assert test_run.mtu == 16384
    assert test_run.media == 'Unknown'
    assert test_run.media_select == '1203'
    assert test_run.media_type is None
    assert test_run.media_options == '<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>'
    assert test_run.slave is False
    assert test_run.module is None

# Generated at 2022-06-24 22:31:34.830208
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    tmp = DarwinNetwork()
    fact = {'interfaces':[], 'all_ipv4_addresses':[], 'all_ipv6_addresses':[]}

    bytes = b'en0: flags=8963<UP,BROADCAST,SMART,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500\n    options=60<TSO4,TSO6>\n    ether xx:xx:xx:xx:xx:xx\n    nd6 options=1<PERFORMNUD>\n    media: autoselect\n    status: inactive\n'
    words = bytes.split()

# Generated at 2022-06-24 22:31:37.014210
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-24 22:31:47.654078
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    i = dict()
    line_0 = b'media: autoselect (<unknown type>) status: inactive'
    line_1 = b'media: autoselect (100baseTX <full-duplex>) status: active'
    line_2 = b'media: autoselect (1000baseT <full-duplex>) status: active'
    line_3 = b'media: autoselect (10baseT, 10baseT-FDX, 100baseTX, 100baseTX-FDX, 1000baseT, 1000baseT-FDX, <unknown type>, <unknown type>, autoselect) status: active'
    line_4 = b'media: autoselect (<unknown type>) status: active'

    d.parse_media_line(line_0.split(), i, None)

# Generated at 2022-06-24 22:31:53.883816
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words_0 = ['media:', 'autoselect', '(none)']
    words_1 = ['media:', '<unknown', 'type>', '(none)']
    words_2 = ['media:', 'autoselect', '(none)']
    words_3 = ['media:', 'autoselect', '(none)']
    words_4 = ['media:', '<unknown', 'type>', '(none)']
    words_5 = ['media:', '<unknown', 'type>', '(none)']
    words_6 = ['media:', 'autoselect', '(none)']
    words_7 = ['media:', 'autoselect', '(none)']
    words_8 = ['media:', 'autoselect', '100baseTX', 'full-duplex']

# Generated at 2022-06-24 22:31:56.518635
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork(bytes_0)
    assert obj.platform == 'Darwin'
    assert obj.parse_ifconfig([bytes_0])
