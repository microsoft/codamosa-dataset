

# Generated at 2022-06-24 22:29:51.235993
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = None
    darwin_network_1 = DarwinNetwork(darwin_network_0)
    # Test with a bridge interface
    words = 'media: <unknown type> autoselect (100baseTX <full-duplex>)'.split()
    current_if = dict()
    ips = list()
    darwin_network_1.parse_media_line(words, current_if, ips)
    # Test with a regular interface
    words = 'media: autoselect (1000baseT <full-duplex>) status: active'.split()
    current_if = dict()
    ips = list()
    darwin_network_1.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:29:52.309379
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork is not None




# Generated at 2022-06-24 22:29:54.126237
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    result = DarwinNetwork()
    assert(result is not None)


# Generated at 2022-06-24 22:30:02.372546
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # fixture
    words = ['        media:', '<unknown type>', '<unknown subtype>', '(0x10010001)']
    current_if = {}
    ips = '10.0.0.1'

    # test
    result = DarwinNetwork.parse_media_line(words, current_if, ips)

    # check outcome
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'unknown subtype'

# Generated at 2022-06-24 22:30:12.498087
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork(None)
    # Test 1
    words_0 = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if_0 = dict()
    ips_0 = dict()
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    # Assert
    assert current_if_0 == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    # Test 2
    words_1 = ['media:', 'autoselect', '(none)']
    current_if_1 = dict()
    ips_1 = dict()

# Generated at 2022-06-24 22:30:15.494598
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize the object
    darwin_network = DarwinNetwork(None)
    # This test is incomplete, will fix later
    assert darwin_network.parse_media_line([], {}, []) is None

# Generated at 2022-06-24 22:30:25.091877
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network0 = DarwinNetwork(None)
    words = ['media:', 'autoselect', '(100baseTX,FDX,flow-control,full-duplex)', 'status:', 'inactive', 'type:', 'en8', 'vlan:', '33', 'mtu:', '1500']
    current_if = darwin_network0.current_if
    darwin_network0.parse_media_line(words, current_if, '')
    assert 'media' in current_if.keys()
    assert 'media_select' in current_if.keys()
    assert 'media_type' in current_if.keys()
    assert 'media_options' in current_if.keys()

# Generated at 2022-06-24 22:30:30.060556
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork({})
    darwin_network_0.parse_media_line(['media:', '<unknown type>', 'status:', 'inactive'], {}, {})

# Generated at 2022-06-24 22:30:36.666430
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork(darwin_network_0)
    darwin_network_1 = ["autoselect","(none)","status:","active"]
    darwin_network_2 = ""
    darwin_network_3 = None
    darwin_network_4 = {}
    
    darwin_network_2 = darwin_network_0.parse_media_line(darwin_network_1, darwin_network_2, darwin_network_3)
    darwin_network_4["media"] = "Unknown"
    darwin_network_4["media_select"] = "autoselect"
    darwin_network_4["media_type"] = "none"

# Generated at 2022-06-24 22:30:43.140362
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_media_line = ['media:', '<unknown type>', '(<unknown>', '<unknown>', '<simple>', '<host>)'][0]
    darwin_network_0 = DarwinNetwork(None)
    darwin_network_1 = DarwinNetwork(darwin_network_0)
    darwin_network_1.parse_media_line(darwin_media_line)