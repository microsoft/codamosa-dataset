

# Generated at 2022-06-24 22:29:47.991934
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork({})
    # test parse_media_line with data from ifconfig on OSX
    darwin_network_0.current_if = {'if_name': 'vmnet8'}
    darwin_network_0.parse_media_line(darwin_network_0.current_if, ['', '<unknown type>', ''], 'mock_ips')
    assert darwin_network_0.current_if['media'] == 'Unknown'
    assert darwin_network_0.current_if['media_select'] == 'Unknown'
    assert darwin_network_0.current_if['media_type'] == 'unknown type'
    assert not darwin_network_0.current_if.get('media_options')

# Generated at 2022-06-24 22:29:57.157979
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    assert darwin_network.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': '(none)'}
    darwin_network.parse_media_line(['media:', '100baseTX', '<full-duplex>', '10baseT/UTP'], {}, {})

# Generated at 2022-06-24 22:30:00.832751
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # setup test object
    darwin_network = DarwinNetwork()

    # test
    darwin_network.parse_media_line(["en0:","autoselect","status:","inactive"], {}, {})


# Generated at 2022-06-24 22:30:12.000725
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # Test case 0
    words = ['media:', 'autoselect', '(none)']

# Generated at 2022-06-24 22:30:19.072055
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'active']
    current_if = {'name': 'Wi-Fi'}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

# Generated at 2022-06-24 22:30:28.564511
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(["media:", "autoselect", "(none)"],{}, {}) == ({"media": "Unknown", "media_select": "autoselect", "media_type": "none"}, {})
    assert darwin_network.parse_media_line(["media:", "autoselect", "(100baseTX)", "full-duplex"],{}, {}) == ({"media": "Unknown", "media_select": "autoselect", "media_type": "100baseTX", "media_options": "full-duplex"}, {})
    assert darwin_network.parse_media_line(["media:", "1000baseT"],{}, {}) == ({"media": "Unknown", "media_select": "1000baseT"}, {})

# Generated at 2022-06-24 22:30:33.810721
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media', 'autoselect', 'type', '802.11ac', 'fsampled']
    current_if = {}
    ips = {}
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_type': '802.11ac', 'media_select': 'autoselect', 'media_options': ['fsampled']}

# Generated at 2022-06-24 22:30:44.985368
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.media_lines = []
    darwin_network.parse_media_line(['media:','1000baseT','LFP','<full-duplex>','4','txload','1','rxload','1','<en1>'], {'device': 'en0'}, [])
    darwin_network.parse_media_line(['media:','1000baseT','HD','<full-duplex>','4','txload','1','rxload','1','<en1>'], {'device': 'en1'}, [])
    assert darwin_network.media_lines[0] == ['media:','1000baseT','LFP','<full-duplex>','4','txload','1','rxload','1','<en1>']
    assert d

# Generated at 2022-06-24 22:30:50.950048
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'IEEE', '802.11', 'Autoselect']
    current_if = {'media': 'Unknown', 'media_select': 'IEEE', 'media_type': '802.11', 'media_options': {'Autoselect': 'on'}}
    DarwinNetwork._parse_media_line(words, current_if)
    assert current_if == {'media': 'Unknown', 'media_select': 'IEEE', 'media_type': '802.11', 'media_options': {'Autoselect': 'on'}}

# Generated at 2022-06-24 22:31:01.480467
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """This test involves using the DarwinNetwork class, calling the parse_media_line method
    and asserting what the results should be.  This test case also asserts the results when a
    different ifconfig output is used as input.
    """

    # Prepare a set of Arguments to pass to parse_media_line method
    mac_ifconfig_output_file = '../ansible_collections/ansible/netcommon/tests/test_utils/test_facts/test_darwin_ifconfig_output.txt'
    mac_ifconfig_output = open(mac_ifconfig_output_file, 'r')

    parse_media_line_args = ['', 'active', '<unknown type>', 'none']
    parse_media_line_kwargs = {'current_if': {'device': 'en0'}, 'ips': []}

    #

# Generated at 2022-06-24 22:31:07.951953
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test case with len(words) < 2
    words = 'foo'
    current_if = {}
    ips = {}
    ret = DarwinNetwork.parse_media_line(words, current_if, ips)
    assert ret is None


# Generated at 2022-06-24 22:31:15.300000
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Init
    darwin_network = DarwinNetwork()

    # parse_media_line
    darwin_network.parse_media_line(['media:', 'autoselect', '(none)'], {}, 'fake_ip')
    darwin_network.parse_media_line(['media:', 'autoselect', '10baseT/UTP'], {}, 'fake_ip')
    darwin_network.parse_media_line(['media:', 'autoselect', '(autoselect)'], {}, 'fake_ip')
    darwin_network.parse_media_line(['media:', 'autoselect', '<unknown type>'], {}, 'fake_ip')


# Generated at 2022-06-24 22:31:22.859892
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test case 1
    # input
    words = ['some words']
    current_if = {}
    ips = {}
    # expected output
    expected_current_if = {'media': 'Unknown'}
    expected_ips = {}
    # actual output
    actual_current_if, actual_ips = DarwinNetwork.parse_media_line(words, current_if, ips)
    # test assertions
    assert expected_current_if == actual_current_if
    assert expected_ips == actual_ips

# Generated at 2022-06-24 22:31:32.405097
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork_test = DarwinNetwork()
    words_0 = ['media:','autoselect','<unknown','type>']
    ips_0 = ''

# Generated at 2022-06-24 22:31:41.549033
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Instantiates DarwinNetwork
    darwin_network_obj = DarwinNetwork()

    # Test case #0: media line is different to the default FreeBSD one

    # Test step #0.1:
    # Test data # 0.1:
    current_if = dict()
    words = ['media:', 'select', 'Auto', '(autoselect)']
    ips = []
    # Expected result #0.1:
    expected_result_0 = dict(media='Unknown', media_select='select', media_type='Auto', media_options=['autoselect'])
    # Run test #0.1
    darwin_network_obj.parse_media_line(words, current_if, ips)
    assert (current_if == expected_result_0)

    # Test step #0.2:
    #

# Generated at 2022-06-24 22:31:48.946170
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()

    line_1 = '    inet 10.0.0.3 netmask 0xffffff00 broadcast 10.0.0.255'
    words_1 = line_1.split()

    current_if_1 = {}
    current_if_1['ips'] = []

    darwin_network_0.parse_media_line(words_1, current_if_1, current_if_1['ips'])

    line_2 = '    media: autoselect (1000baseT <full-duplex>)'
    words_2 = line_2.split()

    current_if_2 = {}
    current_if_2['ips'] = []


# Generated at 2022-06-24 22:31:55.560284
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # Parse a valid media line
    current_if = dict()
    ips = dict()
    words = ['utun9', 'active', 'Ethernet', '10baseT/UTP', 'full-duplex']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'active'
    assert current_if['media_type'] == 'Ethernet'
    assert current_if['media_options'] == '10baseT/UTP,full-duplex'

    # Parse a weird media line
    current_if = dict()
    ips = dict()

# Generated at 2022-06-24 22:32:05.990442
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:32:13.540517
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_iface={}
    test_iface['media'] = 'Unknown'
    test_iface['media_select'] = 'media type'

    words= 'media type'
    ips={}
    darwin_network_collector_0 = DarwinNetwork()
    test_iface = darwin_network_collector_0.parse_media_line(words.split(" "), test_iface, ips)
    assert test_iface['media'] == 'Unknown'

    words = 'media type media_type'
    test_iface = darwin_network_collector_0.parse_media_line(words.split(" "), test_iface, ips)
    assert test_iface['media'] == 'Unknown'
    assert test_iface['media_select']=='media type'


# Generated at 2022-06-24 22:32:23.469335
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:32:34.021930
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    print("\nTest method parse_media_line of class DarwinNetwork")

    # Initialize network class object
    darwin_network_0 = DarwinNetwork('en0')

    # Test parse_media_line method
    darwin_network_0.parse_media_line(['media:', 'none', 'media_select'],
                                      {}, {})
    darwin_network_0.parse_media_line(['media:', '<unknown', 'type>'],
                                      {}, {})

# Generated at 2022-06-24 22:32:42.839460
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_1 = DarwinNetworkCollector()
    darwin_network_1 = DarwinNetwork()
    current_if = {}
    ips = {}
    line = 'media: autoselect    <unknown type>'
    words = line.split()
    darwin_network_1.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:32:49.786436
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # input
    words = ['media:','autoselect','(1000baseT)','<full-duplex,flow-control>','status:','active','']
    current_if = {}
    ips = ['1.1.1.1','2.2.2.2']
    darwin_network = DarwinNetwork()

    # execution
    darwin_network.parse_media_line(words, current_if, ips)

    # assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(1000baseT)'
    assert current_if['media_options'] == ['full-duplex', 'flow-control']

# Generated at 2022-06-24 22:32:50.340033
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:32:56.917158
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a test instance of the DarwinNetwork Class
    dn_mock = DarwinNetwork()
    # Create a test dictionary to hold the ifconfig output
    test_ifconfig_dict = {}
    # Create a test dictionary to hold the parsed ifconfig output
    test_ifconfig_dict['current_if'] = {}
    # Create a test dictionary to hold the parsed IP addresses
    test_ifconfig_dict['ips'] = {}
    # Create a test list for the parsing words in the media line
    # First entry is the media line type
    # Second is the media select
    # Third is the media type
    # Fourth is the media options
    test_words = ['media', 'autoselect', '10baseT/UTP', '(none)']

    # Call the method to parse the media line and verify the expected results
    # use the parse_media

# Generated at 2022-06-24 22:33:02.679456
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    print('media_line: "<unknown type> unknown media, no supported options"')
    words = ["media:", "<unknown", "type>", "unknown", "media,", "no", "supported", "options"]
    current_if = {}
    ips = {}
    darwin_network_0.parse_media_line(words, current_if, ips)
    print('media_select: ' + current_if['media_select'])
    print('media_type: ' + current_if['media_type'])
    print('media_options: ' + str(current_if['media_options']))


# Generated at 2022-06-24 22:33:12.963519
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ["media:", "<unknown", "type>", "full-duplex"]

# Generated at 2022-06-24 22:33:19.237895
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:','<unknown','type>']
    current_if = {'media':'Unknown', 'media_select':'Unknown', 'media_type':'unknown type'}
    darwin_network = DarwinNetwork()
    module = AnsibleModule(
        argument_spec = dict(
            current_if=dict(type='dict'),
            words=dict(type='list'),
        )
    )
    darwin_network.parse_media_line(module.params['words'], module.params['current_if'])
    assert current_if == module.params['current_if']


# Generated at 2022-06-24 22:33:25.373972
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    mac_os_x_04_11_5_eth_0_media_line = ["media:", "autoselect", "(none)", "(none)"]

    mac_os_x_04_11_5_eth_1_media_line = ["media:", "Ethernet", "autoselect"]

    mac_os_x_04_11_5_eth_2_media_line = ["media:", "<unknown", "type>"]

    mac_os_x_04_11_5_current_if = dict()

    mac_os_x_04_11_5_ips = dict()

    mac_os_x_04_11_5_eth_0_media_result = dict()

    mac_os_x_04_11_5_eth_1_media_result = dict()

    mac_os_x

# Generated at 2022-06-24 22:33:30.475250
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Tests for correct media options, media type and media select
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(100baseTX)', 'status:', 'active']
    current_if = {}
    ips = None
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert not current_if['media_options']