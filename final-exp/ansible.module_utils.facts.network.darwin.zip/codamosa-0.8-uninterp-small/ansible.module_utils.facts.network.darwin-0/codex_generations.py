

# Generated at 2022-06-24 22:29:43.806036
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    obj = DarwinNetwork()


# Generated at 2022-06-24 22:29:45.131610
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Unit test if the variable, platform is initialized correctly

# Generated at 2022-06-24 22:29:48.293096
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork('')
    darwin_network_0.parse_media_line(['media:', '<unknown type>', '(unsupported)'], {}, {})

# Generated at 2022-06-24 22:29:49.404987
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    myDarwinNetwork = DarwinNetwork({}, {}, {})
    assert myDarwinNetwork

# Generated at 2022-06-24 22:29:53.391439
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words_0 = ['inet', '1.2.3.4', 'netmask', '0xffffff00', 'broadcast', '1.2.3.255']
    current_if_0 = {}
    ips_0 = []
    assert darwin_network_0.parse_media_line(words_0, current_if_0, ips_0) is None

# Generated at 2022-06-24 22:30:01.446587
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media', 'media_select', "media_type'", 'media_options']
    darwin_network_parse_media_line_0 = DarwinNetwork.parse_media_line(words, current_if, 'ips')
    assert darwin_network_parse_media_line_0 == {'media': 'Unknown', 'media_select': 'media_select', 'media_type': "media_type'", 'media_options': 'media_options'}

# Generated at 2022-06-24 22:30:12.041244
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:30:22.221179
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect']  # test method with media line with no options
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect'}
    words = ['media:', '1000baseSX', 'full-duplex,', 'flow-control']  # test method with media line with options
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': '1000baseSX', 'media_type': 'full-duplex,',
                          'media_options': 'flow-control'}

# Generated at 2022-06-24 22:30:32.375872
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test parse_media_line"""
    # negative test cases
    # test case with no arguments
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(None, None, None) == "test failed for no arguments"

    # test case with invalid number of arguments
    assert darwin_network.parse_media_line([], "en0", ["en0"]) == "test failed for invalid number of arguments"
    assert darwin_network.parse_media_line([], "en0", []) == "test failed for invalid number of arguments"
    assert darwin_network.parse_media_line([], "", []) == "test failed for invalid number of arguments"

# Generated at 2022-06-24 22:30:34.236953
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(["foo", "bar", "foobar", "foobar"], {}, [])

# Generated at 2022-06-24 22:30:46.541718
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_darwin_network = DarwinNetwork()
    current_if = dict()
    ips = list()
    mac_darwin_network.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], current_if, ips)
    assert ('media_select' in current_if)
    assert ('media_type' in current_if)
    assert (current_if['media_select'] == 'autoselect')
    assert (current_if['media_type'] == 'inactive')

    mac_darwin_network.parse_media_line(['media:', '10baseT/UTP'], current_if, ips)
    assert (current_if['media_select'] == '10baseT/UTP')
    assert (current_if['media_type'] is None)



# Generated at 2022-06-24 22:30:54.893095
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    class MockDarwinNetwork():
        def __init__(self):
            pass
        def get_options(self, arg):
            return "Ok"

    wlan_mock_media_line = [
        'media:' + ' '.join(['autoselect', 'status:active', 'supported:autoselect', '10baseT/UTP', '10baseT/UTP', '100baseTX', '100baseTX']),
        "media: autoselect <unknown type>",
        "media: Ethernet autoselect (1000baseT full-duplex)"
    ]
    expected_media_select = [
        'autoselect',
        'autoselect',
        'Ethernet'
    ]

# Generated at 2022-06-24 22:31:01.900227
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(["media:", "autoselect", "100baseTX", "status:", "active"], {}, {})
    darwin_network.parse_media_line(["media:", "autoselect", "(", "none", ")"], {}, {})
    darwin_network.parse_media_line(["media:", "<unknown", "type>"], {}, {})
# Test coverage complete

# Generated at 2022-06-24 22:31:11.484795
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_0 = DarwinNetwork()

    current_if = dict()
    ips = dict()
    words = list()
    words.append(None)
    words.append('alternate')
    words.append('autoselect')
    words.append('<xxx>')
    words.append('[100basetx-fd]')
    words.append('none')
    words.append('status:')
    words.append('active')

    darwin_network_0.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'alternate'
    assert current_if['media_type'] == 'autoselect'

# Generated at 2022-06-24 22:31:16.098703
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Method test
    words = 'media: <unknown type> status: active'.split()
    current_if = dict()
    ips = dict()
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if == dict(
        media_type='unknown type',
        media_options=dict(),
        media_select=words[1],
        media='Unknown'
    )

# Generated at 2022-06-24 22:31:21.989281
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {}, [])
    assert 'media' in darwin_network.interfaces['bridge0']
    assert darwin_network.interfaces['bridge0']['media'] == 'Unknown'

# Generated at 2022-06-24 22:31:27.818068
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Input:
    current_if = {'media': 'Unknown', 'media_select': '10baseT',
                  'media_type': 'Unknown', 'media_options': {}}
    words = ['media:', '10baseT', '<half', 'duplex>']
    # Expected result: nothing
    current_if = DarwinNetwork._parse_media_line(
            current_if,
            words)

# Generated at 2022-06-24 22:31:34.863336
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words_0 = ['media:', 'autoselect', 'none', 'status:', 'active']
    current_if_0 = {'device': 'eth0'}
    ips_0 = {}
    darwin_network_0.parse_media_line(words=words_0, current_if=current_if_0, ips=ips_0)
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == 'autoselect'
    assert current_if_0['media_type'] == 'none'
    assert current_if_0['media_options'] == {}

# Generated at 2022-06-24 22:31:41.340739
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a default instance of DarwinNetwork
    darwinn = DarwinNetwork()

    # create a list of words
    words = ['media:','<unknown','type>','full','duplex']

    # current_if object
    current_if = {}
    ips = []

    # call parse_media_line
    darwinn.parse_media_line(words,current_if,ips)

    # test for media
    assert current_if['media'] == 'Unknown'

    # test for media_select
    assert current_if['media_select'] == 'Unknown'

    # test for media_type
    assert current_if['media_type'] == 'unknown type'

    # test for media_options
    assert current_if['media_options'] == ['full', 'duplex']


# Generated at 2022-06-24 22:31:49.284799
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {'media': '', 'media_type': '', 'media_options': '', 'media_select': ''}
    ips = {'ipv4': '', 'ipv6': ''}

    # test case 1: Mac does not give us this so we set to Unknown
    words = ['media:', 'autoselect', 'status:', 'inactive']
    darwin_network.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == ''

    # test case 2: MacOSX sets the media to '<unknown type

# Generated at 2022-06-24 22:31:55.541069
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_info_0 = DarwinNetwork()
    ret = darwin_network_info_0.parse_media_line(('<UP,BROADCAST,RUNNING,MULTICAST,POINTOPOINT>', '<unknown type>', '<unknown ssid>', 'channel'), {}, {'ipv4': [{'address': '10.10.10.2', 'netmask': '255.255.255.0', 'broadcast': '10.10.10.255'}]})
    assert 'Unknown' in ret['media']


# Generated at 2022-06-24 22:32:03.042771
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'en10MB', 'media_options': {}}
    darwin_network_0 = DarwinNetwork()
    test_words = ['media:', 'autoselect', '(en10MB)', 'status:', 'inactive']
    test_current_if = {}
    test_ips = {}
    assert darwin_network_0.parse_media_line(test_words, test_current_if, test_ips) == test_dict


# Generated at 2022-06-24 22:32:07.562627
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media', '<unknown type>']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:32:14.904563
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(['', 'link', '<unknown', 'type>'], {}, {})
    darwin_network_0.parse_media_line(['', 'link', '<unknown', 'type>'], {'media':'Unknown', 'media_select':'Unknown', 'media_type':'unknown type'}, {})
    darwin_network_0.parse_media_line(['', 'link', 'autoselect', '(100baseTX)'], {'media':'Unknown', 'media_select':'Unknown', 'media_type':'unknown type'}, {})
    darwin_network_0.parse_media_line(['', 'link', 'autoselect', '(100baseTX)'], {}, {})

# Generated at 2022-06-24 22:32:24.232612
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()

    words = []
    current_if = {}
    ips = {}
    expected = {}

    # Test 1
    # Testing with 0 elements in word
    words = []
    current_if = {}
    ips = {}
    expected = {'media': 'Unknown', 'media_select': ''}
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if == expected

    # Test 2
    # Testing with 1 element in word
    words = ['10Baset']
    current_if = {}
    ips = {}
    expected = {'media': 'Unknown', 'media_select': '10Baset'}

# Generated at 2022-06-24 22:32:31.566988
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    test_words = ['media:', '10baseT/UTP', '<link>']
    test_current_if = {}
    test_ips = []
    assert darwin_network_0.parse_media_line(test_words, test_current_if, test_ips) is None
    assert test_current_if['media'] == 'Unknown'
    assert test_current_if['media_select'] == '10baseT/UTP'
    assert test_current_if['media_type'] == '<link>'
    assert test_current_if['media_options'] == {}

# Generated at 2022-06-24 22:32:35.232947
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:','autoselect','status:','active', 'media_select:','autoselect'],
                                    {'type': 'Ethernet'}, 'ips')
    media_select_str = 'media_select:autoselect'
    assert media_select_str in darwin_network.interfaces['media_select']


# Generated at 2022-06-24 22:32:41.216602
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize arguments used for calling parse_media_line
    words = ["ether", "<unknown"]
    current_if = {}
    ips = {}
    obj = DarwinNetwork()
    # Call parse_media_line
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == '<unknown'

# Generated at 2022-06-24 22:32:49.503333
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {'media': 'Unknown', 'name': 'lo0', 'type': 'loopback'}
    ips = {'lo0': {'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'}], 'ipv6': []}}
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert('Unknown' == current_if['media'])
    assert('Unknown' == current_if['media_select'])

# Generated at 2022-06-24 22:32:56.783190
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Case 1:
    darwin_network_test_0 = DarwinNetwork()
    words_1 = ['media:', '<unknown type>', '(none)']
    current_if_1 = {}
    ips_1 = {}
    darwin_network_test_0.parse_media_line(words_1, current_if_1, ips_1)

    assert 'media' in current_if_1
    assert 'media_select' in current_if_1
    assert 'media_type' in current_if_1
    assert 'media_options' in current_if_1

    assert current_if_1['media'] == 'Unknown'
    assert current_if_1['media_select'] == 'Unknown'
    assert current_if_1['media_type'] == 'unknown type'
    assert current_

# Generated at 2022-06-24 22:33:12.357457
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork({}, [])
    # test parse_media_line of class DarwinNetwork
    darwin_network_0.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], {}, {})
    darwin_network_0.parse_media_line(['media:', 'autoselect', 'status:', 'active'], {}, {})
    darwin_network_0.parse_media_line(['media:', '<unknown', 'type>', 'active'], {}, {})
    darwin_network_0.parse_media_line(['media:', '10baseT/UTP(<unknown'], {}, {})


# Generated at 2022-06-24 22:33:20.273709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # results are different: no media is returned
    darwin_network = DarwinNetwork()
    if0 = {}
    ips = []
    words = ['media:', '<unknown type>']
    darwin_network.parse_media_line(words, if0, ips)
    expected = 'Unknown'
    assert if0['media'] == expected
    assert if0['media_select'] == '<unknown type>'
    assert if0['media_type'] == 'unknown type'
    assert 'media_options' not in if0

    words = ['media:', 'ethernet', '100baseTX']
    if0 = {}
    ips = []
    darwin_network.parse_media_line(words, if0, ips)
    expected = 'Unknown'
    assert if0['media'] == expected

# Generated at 2022-06-24 22:33:23.166520
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    result = darwin_network_0.parse_media_line(['media:', '<unknown type>', 'status:', 'active'], {}, [])
    assert 'Unknown' in [result['media'], result['media_select']]

# Generated at 2022-06-24 22:33:30.141680
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    # Test for normal case of parse_media_line()
    darwin_network_0.parse_media_line(['media', 'config', '<unknown type>'], {}, {})
    assert darwin_network_0.current_if == {'media': 'Unknown', 'media_select': 'config', 'media_type': 'unknown type'}
    assert darwin_network_0.ips == {}
    # Test for 2nd case of parse_media_line()
    darwin_network_0.parse_media_line(['media', 'config'], {}, {})
    assert darwin_network_0.current_if == {'media': 'Unknown', 'media_select': 'config', 'media_type': None}
    assert darwin_

# Generated at 2022-06-24 22:33:38.591515
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
        DarwinNetwork = darwin_network_collector_0._fact_class()

        # Test data of the form:
        # [words, current_if, ips, result]

# Generated at 2022-06-24 22:33:48.496035
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_interface_data = {'device' : 'en1'}
    test_ips = ['10.0.0.8','fe80::5054:ff:fe1b:b821','fe80::116a:12ff:feff:b821']
    test_words = ['media:','autoselect','<unknown type>','status:','inactive']
    DarwinNetwork().parse_media_line(test_words, test_interface_data, test_ips)
    assert test_interface_data['media_select']=='autoselect'
    assert test_interface_data['media_type']=='unknown type'
    assert test_interface_data['media_options']=='status: inactive'
    assert test_interface_data['media']=='Unknown'

# Generated at 2022-06-24 22:33:53.507872
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    media_line = 'media: <unknown type> <unknown subtype>'
    words = media_line.split(' ')
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'unknown subtype'

# Generated at 2022-06-24 22:33:59.025691
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_instance = DarwinNetworkCollector()._fact_class()
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    current_if = dict()
    ips = dict()

    darwin_network_instance.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'

# Generated at 2022-06-24 22:34:06.677986
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type> autoselect (none)'
    words = media_line.split()
    current_if = dict()
    ips = dict()
    darwin_network = DarwinNetwork(None, None)
    darwin_network.parse_media_line(words, current_if, ips)
    assert 'Unknown' == current_if['media']
    assert '<unknown' == current_if['media_select']
    assert 'type>' == current_if['media_type']
    assert 'none' == current_if['media_options']



# Generated at 2022-06-24 22:34:16.004110
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # create instance of DarwinNetwork
    darwin_network = DarwinNetwork()

    current_if = dict()

    # test case with Media present, media_select present, media_type present,
    # media_option present
    media_line = ['media:', 'autoselect', '(100baseTX)', 'full-duplex']
    darwin_network.parse_media_line(media_line, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == 'full-duplex'

    # test case with Media present, media_select present, media_type present,
    # media_option not present
    media_