

# Generated at 2022-06-24 22:29:38.718396
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 748
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    array_0 = ["media:", "--", "10baseT/UTP"]
    darwin_network_0.parse_media_line(array_0, {}, {})
    array_1 = ["media:", "ieee", "802.11", "(autoselect)"]
    darwin_network_0.parse_media_line(array_1, {}, {})
    array_2 = ["media:", "ieee", "802.11", "bg"]
    darwin_network_0.parse_media_line(array_2, {}, {})
    array_3 = ["media:", "ieee", "802.11"]
    darwin

# Generated at 2022-06-24 22:29:46.672459
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 748
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    current_if_0 = {}
    ips_0 = {}
    words_0 = ['media', '<unknown', 'type>']
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    # Check the media_select field
    assert darwin_network_0.interfaces[int_0]['media_select'] == 'Unknown'
    assert darwin_network_0.interfaces[int_0]['media_type'] == 'unknown type'
    words_1 = ['media', 'aui']

# Generated at 2022-06-24 22:29:53.172396
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = False
    int_0 = 1000
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    words_0 = ['', '', '', '', '']
    current_if_0 = {}
    ips_0 = {}
    # SUT
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    # assertions
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == ''
    assert 'media_type' not in current_if_0
    assert 'media_options' not in current_if_0



# Generated at 2022-06-24 22:30:00.062679
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 748
    words = ['', '', '', '']
    current_if = dict()
    ips = []
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    darwin_network_0.parse_media_line(words, current_if, ips)



# Generated at 2022-06-24 22:30:08.798610
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 748
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    bool_1 = True
    int_1 = 748
    darwin_network_1 = DarwinNetwork(bool_1, int_1)
    current_if = dict()
    words = list()
    ips = list()
    darwin_network_1.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'


# Generated at 2022-06-24 22:30:12.664886
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 748

    darwin_network_0 = DarwinNetwork(bool_0, int_0)

    str_0 = 'en1: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500'
    str_1 = 'en1 media: autoselect (<unknown type>)'
    str_2 = 'status: inactive'

    current_if = {}
    words = []
    ips = []

    darwin_network_0.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:30:22.920587
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 748
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    words = [None]
    current_if = dict()
    # we need to provide a value for ips for the current_if to have a key
    # but it does not matter what as we do not access it
    ips = dict()
    ips['ipv4'] = dict()
    ips['ipv4']['address'] = '127.0.0.1'
    current_if['ips'] = ips
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    # this is the default value
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-24 22:30:29.498290
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Create the object
    darwin_network_obj = DarwinNetwork(True, 748)
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active', 'supported', 'media:', '(none)']
    current_if = {}
    ips = {}
    darwin_network_obj.parse_media_line(words, current_if, ips)


# Generated at 2022-06-24 22:30:36.332358
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bool_0 = True
    int_0 = 896
    darwin_network_0 = DarwinNetwork(bool_0, int_0)

    # testing media_select
    test_words = ['media:', 'Ethernet', 'autoselect', '(100baseTX', 'full-duplex,)']
    current_if = {'media_select': None}
    darwin_network_0.parse_media_line(test_words, current_if, None)
    assert current_if['media_select'] == 'Ethernet', 'media_select failed'

    test_words = ['media:', 'Ethernet', '(100baseTX', 'full-duplex,)']
    current_if = {'media_select': None}

# Generated at 2022-06-24 22:30:47.039474
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    int_0 = 748
    bool_0 = True
    darwin_network_0 = DarwinNetwork(bool_0, int_0)
    str_0 = '_!@#$%^&*()_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    darwin_network_0._get_options = MagicMock(return_value=str_0)

    str_1 = 'bogus'
    str_2 = 'fake'
    str_3 = 'garbage'
    str_4 = 'trash'

    words_0 = [str_1, str_2, str_3, str_4]
    dict_0 = dict()

    ret_0 = darwin_network_0._parse