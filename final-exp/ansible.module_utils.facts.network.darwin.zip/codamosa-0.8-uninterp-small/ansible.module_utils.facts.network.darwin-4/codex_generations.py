

# Generated at 2022-06-24 22:29:39.187462
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert DarwinNetwork().__class__.__name__ == 'DarwinNetwork'

# Generated at 2022-06-24 22:29:43.354280
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_0 = DarwinNetwork('/sbin/ifconfig', '/sbin/sysctl', 'Darwin')

if __name__ == '__main__':
    print(test_DarwinNetwork())
    print(test_case_0())

# Generated at 2022-06-24 22:29:51.019702
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    media_line = 'media: autoselect (none)'

    result = darwin_network_0.parse_media_line(media_line.split(), {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'autoselect'
    assert result['media_options'] == 'none'

    result = darwin_network_0.parse_media_line(media_line.split(), {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'autoselect'
    assert result['media_options'] == 'none'

# Generated at 2022-06-24 22:29:52.461075
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_0 = DarwinNetwork()


# Generated at 2022-06-24 22:30:03.044324
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork(None, None)


# Generated at 2022-06-24 22:30:12.918072
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    fake = 'foo'
    if_dict = {}
    ips = []

    # media line is different to the default FreeBSD one
    words = ['foo']
    if_dict = darwin_network.parse_media_line(words, if_dict, ips)
    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == 'foo'

    words = ['foo', 'foo']
    if_dict = darwin_network.parse_media_line(words, if_dict, ips)
    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == 'foo'
    assert if_dict['media_type'] == 'foo'

    words = ['foo', 'foo', 'foo']
   

# Generated at 2022-06-24 22:30:15.210120
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_0 = DarwinNetwork()
    assert darwin_network_0.platform == 'Darwin'


# Generated at 2022-06-24 22:30:23.008382
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line_0 = ['10baseT/UTP']
    words_0 = ['10baseT/UTP']
    current_if_0 = {}
    ips_0 = {}

    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)

    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == '10baseT/UTP'
    assert current_if_0['media_type'] == 'unknown type'



# Generated at 2022-06-24 22:30:25.388411
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_0 = DarwinNetwork()
    assert darwin_network_0 is not None


# Generated at 2022-06-24 22:30:32.298408
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media','type','<unknown','type>','options','autoselect','status','inactive']
    current_if = {}
    ips = []
    result = darwin_network.parse_media_line(words, current_if, ips)
    assert result == None
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'type'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'autoselect'

# Generated at 2022-06-24 22:30:40.825965
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['<unknown', 'type>']
    current_if = dict()
    ips = dict()
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert('Unknown' == current_if['media_select'])
    assert('unknown type' == current_if['media_type'])

# Generated at 2022-06-24 22:30:50.063238
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}
    words_1 = ['media:', 'autoselect', '<unknown type>']
    expected_if_1 = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': ''}
    words_2 = ['media:', 'IEEE', '802.11D/E', 'autoselect']
    expected_if_2 = {'media': 'Unknown', 'media_select': 'IEEE', 'media_type': '802.11D/E', 'media_options': 'autoselect'}
    test_DarwinNetwork = DarwinNetwork()
    test_DarwinNetwork_parse_media_line_1 = test_Dar

# Generated at 2022-06-24 22:30:59.285816
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test case for parse_media_line method of DarwinNetwork
    """
    # Create a dictionary for test
    test_interface_dict = dict()

    # Create an object of DarwinNetwork class
    DarwinNetwork_instance = DarwinNetwork()

    # Test valid input
    # First test case
    test_word_list = ['media:','autoselect','10baseT/UTP']
    test_interface_dict = DarwinNetwork_instance.parse_media_line(test_word_list,test_interface_dict,{})
    assert test_interface_dict['media'] == 'Unknown' and \
           test_interface_dict['media_select'] == 'autoselect' and \
           test_interface_dict['media_type'] == '10baseT/UTP' and \
           test_interface_dict['media_options'] == None

# Generated at 2022-06-24 22:31:10.180224
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_params = {'words': ['media:', '<unknown type>', '(none)'], 'current_if': {}, 'ips': {}}
    test_obj = DarwinNetwork()
    output = test_obj.parse_media_line(test_params['words'], test_params['current_if'], test_params['ips'])
    expected_output = {'media': 'Unknown', 'media_select': '<unknown type>', 'media_type': 'unknown type', 'media_options': 'none'}
    assert output == expected_output

    test_params = {'words': ['media:', '<unknown type>', '(none)'], 'current_if': {}, 'ips': {}}
    test_obj = DarwinNetwork()

# Generated at 2022-06-24 22:31:20.186803
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinNetwork = DarwinNetwork()
    test_case_words_0 = ['media:', 'autoselect', '10baseT/UTP', '<full-duplex>']
    test_case_current_if_0 = {
        'media': None,
        'media_select': None,
        'media_type': None,
        'media_options': None
    }
    darwinNetwork.parse_media_line(test_case_words_0, test_case_current_if_0, '')
    expected_current_if_0 = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '10baseT/UTP',
        'media_options': 'full-duplex'
    }
    assert test_case_current_if_

# Generated at 2022-06-24 22:31:26.980745
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    current_if = {}
    ips = [] 
    words = ['media', 'autoselect', '(none)', '(none)']
    darwin_network_collector_0.facts['network'].parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == 'none'

# Generated at 2022-06-24 22:31:37.550553
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.ifconfig_path = '/usr/sbin/ifconfig'
    darwin_network_0.route_path = '/usr/sbin/route'
    darwin_network_0.ipv6_capable = True
    darwin_network_0.interfaces = {'bridge0': {}, 'lo0': {}, 'p2p0': {}, 'utun0': {}}

    # Test ifconfig output with the following line:
    #     bridge0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    # where the media line is missing.

# Generated at 2022-06-24 22:31:48.120454
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_net = DarwinNetwork()
    interf = {
        'keys': ['en0'],
        'ipv4': [],
        'ipv6': [],
        'status': 'UP',
        'media_select': None,
        'media_type': None,
        'media_options': None
    }
    words = ['media:', 'autoselect', '(none)', 'status:', 'active']
    mac_net.parse_media_line(words, interf, [])
    assert interf == {
        'keys': ['en0'],
        'ipv4': [],
        'ipv6': [],
        'status': 'UP',
        'media_select': 'autoselect',
        'media_type': '(none)',
        'media_options': None
    }
    words

# Generated at 2022-06-24 22:31:54.876425
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0._iface_aliases = [{"name": "lo0", "type": "loopback", "ipv4": {"address": "127.0.0.1", "netmask": "255.0.0.0", "broadcast": "127.255.255.255"}, "ipv6": []}]

    darwin_network_0.parse_media_line(words=['<unknown>', '<unknown type>'], current_if='lo0', ips={'ipv4': [], 'ipv6': []})

# Generated at 2022-06-24 22:32:03.690185
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    current_if = {'macaddress': '01:23:45:67:89:ab'}
    ips = {'01:23:45:67:89:ab': {}}
    expected_result = {'macaddress': '01:23:45:67:89:ab',
                       'media': 'Unknown',
                       'media_select': 'autoselect',
                       'media_type': '(none)'}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if == expected_result

# Generated at 2022-06-24 22:32:13.944186
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # create an instance of DarwinNetwork class and test if it type is what we expect
    darwin_network_0 = DarwinNetwork()
    assert type(darwin_network_0) == DarwinNetwork

    # Note that the parse_media_line method of DarwinNetwork class is inherited from GenericBsdIfconfigNetwork
    # So we will only test when media line is different to the default FreeBSD one

    # Test 1: check media_line is valid with parameter words =  ['media:', '<unknown', 'type>', 'status:', 'inactive']
    # Check if the output is as expected
    darwin_network_0.current_if = {}
    darwin_network_0.ips = {}


# Generated at 2022-06-24 22:32:18.901189
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words_0 = []
    current_if_0 = dict()
    ips_0 = []
    assert darwin_network_0.parse_media_line(words_0, current_if_0, ips_0) == (current_if_0, ips_0)

# Generated at 2022-06-24 22:32:29.614289
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_class_0 = DarwinNetwork()
    words = ["media:", "none"]
    current_if = {"media": None, "media_select": None, "media_type": None, "media_options": None}
    ips = {"lo0": {}, "gif0": {}, "stf0": {}, "en0": {}, "en1": {}, "en2": {}, "en3": {}}
    darwin_network_class_0.parse_media_line(words, current_if, ips)
    assert not current_if["media"]
    assert current_if["media_select"] == "none"
    assert not current_if["media_type"]
    assert not current_if["media_options"]


# Generated at 2022-06-24 22:32:34.605170
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    ifconfig_output = open('../utils/sample_outputs/ifconfig_output_macosx')
    darwin_network_collector_0._parse_ifconfig(ifconfig_output)
    assert darwin_network_collector_0._fact_class._ifcfg_data['en0']['media'] == 'Unknown'
    assert darwin_network_collector_0._fact_class._ifcfg_data['bridge0']['media'] == 'Unknown'

# Generated at 2022-06-24 22:32:45.521020
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test case 0
    darwin_network_0 = DarwinNetwork()
    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}
    assert darwin_network_0.parse_media_line(words=words, current_if=current_if, ips=ips) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    # Test case 1
    darwin_network_1 = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    current_if = {'media_select': 'autoselect'}
    ips = {}

# Generated at 2022-06-24 22:32:47.807275
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Given
    darwin_network_0 = DarwinNetwork()

    # When
    words = ['media:', '<unknown', 'type>', '(autoselect)']
    current_if = {}
    ips = {}

    # Then
    darwin_network_0.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:32:54.954081
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_0 = darwin_network_collector_0._fact_class()

# Tests that test_DarwinNetwork_parse_media_line is able to parse with valid
# input
    input_0 = ['media:','auto','1000baseT','<full-duplex>']
    assert darwin_network_0.parse_media_line(input_0, dict(), dict()) == dict(
        media='Unknown', media_select='auto', media_type='1000baseT', \
        media_options='full-duplex')

    input_1 = ['media:','manual','100baseTX','<full-duplex>']
    assert darwin_network_0.parse_media_line(input_1, dict(), dict())

# Generated at 2022-06-24 22:33:00.216307
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media:', '<unknown type>']
    current_if = {}
    ips = None
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_options': None, 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-24 22:33:11.104399
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """DarwinNetwork.parse_media_line"""
    words = [
        '0',
        'Media',
        '1000baseT',
        '<full-duplex,rxpause,txpause>',
        'status:',
        'active',
    ]
    current_if = {'name': 'en0'}
    ips = {
        '127.0.0.1': {
            'peer': '::1',
            'prefixlen': 8,
        }
    }
    osx_media_line = DarwinNetwork(module=None)
    osx_media_line.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1000baseT'

# Generated at 2022-06-24 22:33:19.037796
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test case 1
    darwin_network_0 = DarwinNetwork(module=None, fallback=None)
    words_0 = ['media:', 'none', 'status:', 'inactive']
    current_if_0 = dict()
    ips_0 = dict()
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0['media'] == 'none'
    assert current_if_0['media_select'] == 'none'
    assert ips_0 == dict()

    # test case 2
    darwin_network_1 = DarwinNetwork(module=None, fallback=None)
    words_1 = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_

# Generated at 2022-06-24 22:33:26.949926
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    media_line1 = ['media:', 'autoselect', '(1000baseT)', 'status:', 'active']
    result = darwin_network.parse_media_line(media_line1, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == '1000baseT'
    assert result['media_options'] == {'status': 'active'}

    media_line2 = ['media:', '<unknown', 'type>', 'status:', 'active']
    result = darwin_network.parse_media_line(media_line2, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'Unknown'


# Generated at 2022-06-24 22:33:31.726096
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(['status:', 'active', 'media:', '<unknown type>'], {}, [])
    darwin_network_0.parse_media_line(['status:', 'active', 'media:', 'autoselect', '(100baseTX)'], {}, [])
    darwin_network_0.parse_media_line(['status:', 'inactive', 'media:', '100baseTX'], {}, [])
    darwin_network_0.parse_media_line(['status:', 'active', 'media:', '1000baseT', 'status:', 'inactive'], {}, [])

# Generated at 2022-06-24 22:33:38.955065
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = dict()
    ips = []
    words = ['media:', 'autoselect', '10baseT/UTP']
    darwin_network.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    assert 'media_options' not in current_if


# Generated at 2022-06-24 22:33:43.513746
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin_network_0 = DarwinNetwork()

    if name == '__main__':
        test_case_0()
        test_DarwinNetwork_parse_media_line()

# Generated at 2022-06-24 22:33:50.988229
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_DarwinNetwork = DarwinNetwork()
    words = ['media:', '<unknown>', 'type', '<unknown>']
    current_if = dict()
    ips = dict()
    test_DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

# Generated at 2022-06-24 22:33:57.621760
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a test DarwinNetwork instance
    darwin_network = DarwinNetwork()

    # create simple test input
    words = list(['Media:', 'autoselect', 'status:', 'active'])
    current_if = {}
    current_if['ipv4'] = []
    current_if['ipv6'] = []
    ips = {}
    ips['ipv4'] = []
    ips['ipv6'] = []

    # call method
    darwin_network.parse_media_line(words, current_if, ips)

    # check results
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'

# Generated at 2022-06-24 22:34:03.545930
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector = DarwinNetworkCollector()
    darwin_network_collector.collect()
    for interface in darwin_network_collector.get_facts():
        if interface == 'vmnet8':
            assert darwin_network_collector.get_facts()[interface]['media_type'] == 'Ethernet autoselect'
            assert darwin_network_collector.get_facts()[interface]['media'] == 'Unknown'
            assert darwin_network_collector.get_facts()[interface]['media_select'] == '(autoselect)'

# Generated at 2022-06-24 22:34:11.833871
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork({})

# Generated at 2022-06-24 22:34:20.989582
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc1 = {'name':'en1', 'type':'ether'}
    ifc_list = []
    ifc_list.append(ifc1)
    words = ['media:', 'autoselect', '(none)', '[none']
    n = DarwinNetwork(ifc_list)
    n.parse_media_line(words, ifc1, None)
    assert ifc1['media'] == 'Unknown'
    assert ifc1['media_select'] == 'autoselect'
    assert ifc1['media_type'] == 'none'
    assert ifc1['media_options'] == 'none'
    #
    ifc2 = {'name':'en2', 'type':'ether'}
    ifc_list = []
    ifc_list.append(ifc2)
    words

# Generated at 2022-06-24 22:34:29.238604
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # unit test for parse_media_line in class DarwinNetwork
    darwin_network = DarwinNetwork()

    # test 1: test passing in expected data
    ifc_dict = {'inet': [], 'inet6': [], 'lladdr': None, 'macaddress': None, 'mtu': None, 'state': None, 'type': None, 'hwassist': None, 'group': None, 'metric': None, 'active': None, 'description': None}
    test_line = 'media: <unknown type>'
    darwin_network.parse_media_line(test_line.split(), ifc_dict, {})
    assert ifc_dict['media'] == 'Unknown'
    assert ifc_dict['media_select'] == 'Unknown'
    assert ifc_dict['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:34:42.645757
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Default macOS media line
    words = [
        "media:", "autoselect", "(none)", "status:", "inactive"]
    current_if = {'state': 'up',
                  'description': 'en0',
                  'speed': 1000,
                  'macaddress': '70:f1:a1:c9:d6:ba'}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == "(none)"
    assert current_if['media_type'] == "none"

    # Bridge interface macOS media line
    words = [
        "media:", "<unknown", "type>" "status:", "inactive"]

# Generated at 2022-06-24 22:34:48.725398
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    result = True
    test_case_1 = DarwinNetwork(None)
    test_case_1.parse_media_line(['media:', 'autoselect', '(none)'], {}, [])
    result = result and (test_case_1.current_if['media'] == 'Unknown' and test_case_1.current_if['media_select'] == 'autoselect' and test_case_1.current_if['media_type'] == '(none)')

    test_case_2 = DarwinNetwork(None)
    test_case_2.parse_media_line(['media:', '<unknown', 'type>', '(none)'], {}, [])

# Generated at 2022-06-24 22:34:58.507603
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    Darwin = DarwinNetwork()
    words = ['media:', 'autoselect', 'status:', 'active']
    current_if = {'inet': '127.0.0.1'}
    ips = ['127.0.0.1']
    Darwin.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_status'] == 'active'

    words = ['media:', 'autoselect', 'status:', 'active', '10baseT/UTP']
    Darwin.parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == '10baseT/UTP'


# Generated at 2022-06-24 22:35:05.908146
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Instantiate a DarwinNetwork object
    d_n = DarwinNetwork()

    # Media line from Darwin 10.12.6
    media_line_1 = ['media:', 'autoselect', '(none)']

    # Call the method
    d_n.parse_media_line(media_line_1, 'current_interface', 'ips')

    # Check if the result is as expected
    assert d_n.current_interface['media'] == 'Unknown'
    assert d_n.current_interface['media_select'] == 'autoselect'
    assert d_n.current_interface['media_type'] == '(none)'



# Generated at 2022-06-24 22:35:11.568359
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(["media:", "0", "<unknown", "type>"], {"foo": "bar"}, [])
    assert darwin_network_0.interfaces['foo'] == {'foo': 'bar'}
    assert darwin_network_0.interfaces['foo']['media'] == 'Unknown'
    assert darwin_network_0.interfaces['foo']['media_select'] == 'Unknown'
    assert darwin_network_0.interfaces['foo']['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:35:18.437844
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    current_if['ifname'] = 'lo0'
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(['media:','<unknown','type>'], current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-24 22:35:28.769743
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:35:36.604063
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(['media:', '10baseT/FULL'], 'lo0', {}) == {'media': 'Unknown', 'media_select': '10baseT/FULL'}
    assert darwin_network.parse_media_line(['media:', '10baseT', '<unknown type>'], 'en0', {}) == {'media': 'Unknown', 'media_select': '10baseT', 'media_type': 'unknown type'}
    assert darwin_network.parse_media_line(['media:', '10baseT', 'eui64'], 'en1', {}) == {'media': 'Unknown', 'media_select': '10baseT', 'media_type': 'eui64'}

# Generated at 2022-06-24 22:35:41.303314
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_1 = DarwinNetworkCollector()
    media_line_1 = ['media:',
                    'none',
                    'status:',
                    'active',
                    ]
    if_name_1 = 'bridge1000'
    ips_1 = {'bridge1000': {}}
    darwin_network_collector_1.network.parse_media_line(media_line_1, if_name_1, ips_1)

# Generated at 2022-06-24 22:35:50.826861
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test method of DarwinNetwork class that parses the media line of ifconfig output
    """
    darwin_network_0 = DarwinNetwork()
    # Example media line of ifconfig output, 'media:' line is not present in
    # FreeBSD
    media_line_0 = ['media:', '<unknown type>', '<unknown subtype>']
    ips_0 = dict()
    current_if_0 = dict()
    # Test the regular case
    darwin_network_0.parse_media_line(media_line_0, current_if_0, ips_0)
    # Asserts
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == 'Unknown'
    assert current_if_0['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:36:06.207717
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork({})
    words_0 = ['media:', 'autoselect', '(none)']
    words_1 = ['media:', '<unknown', 'type>']
    words_2 = ['media:', '100baseTX', '(none)']
    words_3 = ['media:', '1000baseTX', '(full-duplex,flowcontrol,rxpause,txpause)']
    current_if_0 = {}
    ips_0 = []
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert 'media' in current_if_0.keys()
    assert 'media_select' in current_if_0.keys()
    assert 'media_options' not in current_if_0.keys()


# Generated at 2022-06-24 22:36:15.293468
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork(None, None, None)
    media_words_0 = ['media:', '<unknown', 'type>']
    current_if_0 = {}
    ips_0 = {}
    darwin_network_0.parse_media_line(words=media_words_0, current_if=current_if_0, ips=ips_0)
    media_words_1 = ['media:', 'autoselect', '100baseTX', '(100baseTX', '<full-duplex>)']
    current_if_1 = {}
    ips_1 = {}
    darwin_network_0.parse_media_line(words=media_words_1, current_if=current_if_1, ips=ips_1)

# Generated at 2022-06-24 22:36:21.809153
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()

    # Parse media line of 'media: autoselect <unknown type> status: active'
    current_if = dict()
    ips = dict()
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words=['media:', 'autoselect', '<unknown', 'type>', 'status:', 'active'],
                                    current_if=current_if,
                                    ips=ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

    # Parse media line of 'media: none (<unknown type>)'
    current_if = dict()
    ips = dict

# Generated at 2022-06-24 22:36:27.412289
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test default case
    darwin_network_0 = DarwinNetwork()
    result = darwin_network_0.parse_media_line(words = ['media','media_select','media_type','media_options'],
                                               current_if = {'media': 'Unknown','media_select': 'media_select','media_type': 'Unknown','media_options': 'media_options'},
                                               ips = [])
    assert result == {'media': 'Unknown','media_select': 'media_select','media_type': 'media_type','media_options': 'media_options'}
    # Test default case
    darwin_network_1 = DarwinNetwork()

# Generated at 2022-06-24 22:36:30.983602
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create an instance of DarwinNetwork
    darwin_network_instance = DarwinNetwork()
    # Create test data
    words = ['media:', 'autoselect(none)', 'status:', 'inactive']
    # Create an instance of dict
    current_if = dict()
    ips = dict()
    # Unit test parse_media_line()
    darwin_network_instance.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:36:41.145578
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # Check if media_line is known type
    assert darwin_network.parse_media_line(['media:', 'autoselect', '100baseTX', 'full-duplex'], {}, {}) == \
           {'media_type': '100baseTX', 'media_select': 'autoselect', 'media_options': 'full-duplex'}
    assert darwin_network.parse_media_line(['media:', '10baseT', '<unknown type>'], {}, {}) == \
           {'media_type': 'Unknown', 'media_select': '10baseT'}

# Generated at 2022-06-24 22:36:50.969441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()

    words_0 = []
    current_if_0 = dict()
    ips_0 = dict()
    words_0.append("media:")
    words_0.append("autoselect")
    words_0.append("(none)")

    expected_0 = dict()
    expected_0['media'] = 'Unknown'
    expected_0['media_select'] = "autoselect"
    expected_0['media_type'] = "(none)"

    darwin_network_0.parse_media_line(words_0,current_if_0,ips_0)
    assert(expected_0==current_if_0)


    words_1 = []
    current_if_1 = dict()
    ips_1 = dict()
    words_1

# Generated at 2022-06-24 22:36:58.433822
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:37:03.263779
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector = DarwinNetworkCollector()
    words = ['media:', 'autoselect', '<unknown-type>']
    current_if = {}
    ips = []
    # call the method
    darwin_network_collector.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown-type'
    assert current_if['media_options'] == []

# Generated at 2022-06-24 22:37:12.960200
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    Darwin_Network = DarwinNetwork()
    assert Darwin_Network.parse_media_line(['media:', 'autoselect', 'media_type:', '<unknown type>', 'status:', 'inactive'],{},[]) ==  {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'unknown type',
        'media_options': {},
        'status': 'inactive',
    }