

# Generated at 2022-06-24 22:29:46.383864
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    tuple_0 = ()
    darwin_network_collector_0 = DarwinNetworkCollector(tuple_0)
    darwin_network_0 = DarwinNetwork(tuple_0)



# Generated at 2022-06-24 22:29:49.370486
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Invoking constructor of class DarwinNetwork with arguments (empty tuples)
    tuple_0 = ()
    darwin_network_0 = DarwinNetwork(tuple_0)
    # Instance created using parameterized constructor should not be None
    assert darwin_network_0 is not None

# Generated at 2022-06-24 22:30:01.619502
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    tuple_0 = ()
    darwin_network_collector_0 = DarwinNetworkCollector(tuple_0)
    darwin_network_0 = DarwinNetwork(darwin_network_collector_0)
    str_0 = str(darwin_network_0)
    # AssertionError: 'DarwinNetwork' != 'network_collector.Fact_Class: DarwinNetwork network_collector.Platform: Darwin'
    assert str_0 == 'network_collector.Fact_Class: DarwinNetwork network_collector.Platform: Darwin', str_0
    # AssertionError: 'Darwin' != 'network_collector.Platform: Darwin'
    assert str_0 == 'network_collector.Platform: Darwin', str_0
    # AssertionError: 'network_collector.Platform: Darwin' != 'network_collect

# Generated at 2022-06-24 22:30:04.713475
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dict_0 = dict()
    tuple_0 = ("", "", "", "")
    dict_1 = dict()
    darwin_network_0 = DarwinNetwork(None, dict_0, tuple_0)
    darwin_network_0.parse_media_line()

# Generated at 2022-06-24 22:30:08.195419
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {u'media': 'Unknown', u'media_select': 'autoselect', u'media_type': '<unknown type>'}
    words = ['<unknown', 'type>']
    darwin_network_0 = DarwinNetwork()
    result = darwin_network_0.parse_media_line(words, current_if)
    assert result is None


# Generated at 2022-06-24 22:30:12.967141
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-24 22:30:23.227665
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', 'status:', 'active', 'last', 'active', 'never']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}
    current_if = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    words = ['media:', 'autoselect', '(100baseTX', '<full-duplex>)']
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if

# Generated at 2022-06-24 22:30:28.410294
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    tuple_0 = ()
    darwin_network_collector_0 = DarwinNetworkCollector(tuple_0)
    darwin_network_0 = darwin_network_collector_0._fact_class(tuple_0)

    assert darwin_network_0.platform == 'Darwin'

# Generated at 2022-06-24 22:30:32.525690
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    tuple_0 = ()
    darwin_network_collector_0 = DarwinNetworkCollector(tuple_0)
    words_0 = ()
    current_if_0 = {}
    ips_0 = {}

    darwin_network_collector_0.fact_class.parse_media_line(words_0, current_if_0, ips_0)

# Generated at 2022-06-24 22:30:36.237023
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    tuple_0 = ()
    darwin_network_0 = DarwinNetwork(tuple_0)
    assert darwin_network_0.platform == DarwinNetwork.platform


# Generated at 2022-06-24 22:30:39.825215
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test DarwinNetwork.parse_media_line()"""
    darwin_network = DarwinNetwork()

    current_if = {}
    ips = []
    data = []
    data.append('media: <unknown type>')

    darwin_network.parse_media_line(data, current_if, ips)

# Generated at 2022-06-24 22:30:41.426249
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["unknown", "select", "type", "options"]
    current_if = {"media_type": "unknown type"}
    ips = "Unknown"
    darwinnetwork_2 = DarwinNetwork()
    darwinnetwork_2.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:30:47.235513
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    words = []
    darwin_network = DarwinNetwork(None, None)
    words = list(['media:', '<unknown', 'type>'])
    darwin_network.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:30:57.590571
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = [None, "auto", "unknown", "up"]
    ips = {"destination": "0.0.0.0", "broadcast": "0.0.0.0", "netmask": "0.0.0.0", "address": "link:#17"}
    darwin_network_0 = DarwinNetwork(current_if, words, ips)
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "auto"
    assert current_if["media_type"] == "unknown"
    assert current_if["media_options"] == "up"
    return

# Generated at 2022-06-24 22:31:02.798431
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words_0 = []
    current_if_0 = {}
    ips_0 = {}
    darwin_network_0 = DarwinNetwork(words_0)
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)

# Generated at 2022-06-24 22:31:10.443639
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'autoselect', '(none)']
    ips = {}
    darwin_network_0 = DarwinNetwork({})
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

if __name__ == '__main__':
    # test_case_0()
    # test_DarwinNetwork_parse_media_line()
    print('no tests')

# Generated at 2022-06-24 22:31:20.316323
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Testing with data from MacOSX (macOS High Sierra)
    current_if = {}
    # for ssid: word[1] = '"ssid"'
    words = ["media:", "IEEE", "802.11", "Autoselect", "(ofdm11g)", "status:", "inactive"]
    darwin_network = DarwinNetwork(None)
    darwin_network.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'IEEE'
    assert current_if['media_type'] == '802.11'
    assert current_if['media_options'] == ['Autoselect', '(ofdm11g)']
    assert current_if['status'] == 'inactive'

    # for ethernet interface

# Generated at 2022-06-24 22:31:28.373983
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if_0 = {'current_if': {}}
    words_0 = {}
    ips_0 = {}
    darwin_network_0 = DarwinNetwork('tuple_0', 'tuple_1', current_if_0, words_0, ips_0)
    current_if_0 = None
    words_0 = None
    ips_0 = None
    assert darwin_network_0.parse_media_line(current_if_0, words_0, ips_0) == (None, None, None)


# Generated at 2022-06-24 22:31:36.041717
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a new instance of Network
    darwin_network_0 = DarwinNetwork({})
    # run the parse_media_line function with arguments
    # and test its output
    tuple_0 = ('media:', 'autoselect', '10baseT/UTP')
    darwin_network_0.parse_media_line(tuple_0, {}, {})
    assert darwin_network_0.interface_details['media'] == 'Unknown'
    assert darwin_network_0.interface_details['media_select'] == 'autoselect'
    assert darwin_network_0.interface_details['media_type'] == '10baseT/UTP'
    tuple_1 = ('media:', '10baseT/UTP', '<unknown type>')
    darwin_network_0.parse

# Generated at 2022-06-24 22:31:40.763300
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    words = list()

    # should set medias
    current_if['media'] = None
    current_if['media_select'] = None
    current_if['media_type'] = None
    current_if['media_options'] = None
    words.append('media:')
    words.append('none')
    words.append('supported')
    ips = None
    DarwinNetwork.parse_media_line(current_if, words, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'none'
    assert current_if['media_type'] == 'supported'