

# Generated at 2022-06-24 22:29:52.423980
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['lo0:', 'media', '10Gbase-T', '(<unknown type>)', 'status', 'inactive']
    current_if = {'name': '', 'is_up': False, 'is_enabled': False, 'speed': 0, 'macaddress': '', 'options': {}, 'device_type': '', 'ipv4': {}, 'ipv6': {}}
    ips = {}
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '10Gbase-T'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:29:59.615490
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # testcase 0
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(['media:', 'autoselect', '(none)'], {}, None)
    assert darwin_network_0.facts['all_ipv4_addresses'] == {}
    assert darwin_network_0.facts['interfaces'] == {}

# Generated at 2022-06-24 22:30:11.097667
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin_network_0 = DarwinNetwork()
    darwin_network_1 = DarwinNetwork()
    darwin_network_2 = DarwinNetwork()

    current_if0 = dict()
    current_if1 = dict()
    current_if2 = dict()

    darwin_network_0.parse_media_line(["media:", "select", "10baseT/UTP", "status:", "active"], current_if0, {})
    darwin_network_1.parse_media_line(["media:", "autoselect", "media", "mediaopt", "mediaopt", "mediatype", "mediatype", "mediaopt"], current_if1, {})

# Generated at 2022-06-24 22:30:15.711414
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    network = DarwinNetwork()

    line = "media: autoselect"
    words = line.split()
    network.parse_media_line(words, current_if, None)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    current_if = {}
    line = "media: autoselect (100baseTX <full-duplex>)"
    words = line.split()
    network.parse_media_line(words, current_if, None)
    assert 'media' in current_if

# Generated at 2022-06-24 22:30:22.837741
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 1 from Darwin
    instance = DarwinNetwork()
    line = "media: autoselect (100baseTX <full-duplex>)"
    device = []
    device.append(line)
    result = instance.parse_media_line(line.split(' '), {}, None)
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == '100baseTX'
    assert result['media_options'] == ['full-duplex']


# Generated at 2022-06-24 22:30:32.933703
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork({})
    assert darwin_network_0.parse_media_line(["media:", "<unknown", "type>"], {}, {}) == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'unknown type'}
    assert darwin_network_0.parse_media_line(["media:" ,"autoselect", "none"], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none'}

# Generated at 2022-06-24 22:30:41.858385
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'active']
    current_if = dict()
    ips = dict()
    result = darwin_network_0.parse_media_line(words, current_if, ips)
    assert isinstance(result, dict)
    assert result['media'] == 'Unknown'
    assert result['media_select'] == '<unknown'
    assert result['media_type'] == 'unknown type'
    assert result['media_options'] == 'active'

# Generated at 2022-06-24 22:30:49.980259
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_data = DarwinNetwork()
    # bridge interface test case
    assert network_data.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {'media': 'Unknown', 'media_select': '<unknown type>', 'media_type': 'unknown'}
    # standard interface test case
    assert network_data.parse_media_line(['media:', 'autoselect', '(none)', 'status:'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': {}}

# Generated at 2022-06-24 22:30:57.244191
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    media_line_0 = ['media:','<unknown','type>']
    media_line_1 = ['media:','autoselect','100baseTX','full-duplex']
    media_line_2 = ['media:','ieee80211','autoselect','status:','inactive']


    # TODO: We need a better way of doing this...
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    network._current_if = GenericBsdIfconfigNetwork.If()
    network._current_if['ips'] = {}

    if network.parse_media_line(media_line_0, network._current_if, network._current_if['ips']) is not None:
        assert False

# Generated at 2022-06-24 22:31:05.532475
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig_output = '''media: autoselect (1000baseT <full-duplex>)
status: active
'''

    network_fact_0 = DarwinNetwork(ifconfig_output)
    words = ifconfig_output.split()
    current_if = {'name': 'eth0'}
    ips = []
    network_fact_0.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'

