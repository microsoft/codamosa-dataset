

# Generated at 2022-06-24 22:29:49.791779
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_0 = b'mXB'
    darwin_network_0 = DarwinNetwork(bytes_0)
    words_0 = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if_0 = {}
    ips_0 = {}
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0 == {'media_select': 'autoselect', 'media_type': '(none)', 'media': 'Unknown'}

# Generated at 2022-06-24 22:30:01.024696
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_0 = b'        media: autoselect ('
    darwin_network_0 = DarwinNetwork(bytes_0)
    words_0 = ['', 'autoselect', '(autoselect)']
    current_if_0 = {}
    ips_0 = {}
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == 'autoselect'
    assert current_if_0['media_type'] == 'autoselect'
    assert current_if_0['media_options'] == {}



# Generated at 2022-06-24 22:30:12.000003
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_0 = b'mXB'
    darwin_network_0 = DarwinNetwork(bytes_0)
    words_0 = [b'mXB']
    current_if_0 = {}
    ips_0 = {}
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)

    words_1 = [b'100baseTX', b'<full-duplex>', b'master', b'auto', b'nway']
    current_if_1 = {}
    darwin_network_0.parse_media_line(words_1, current_if_1, ips_0)

    words_2 = [b'<unknown', b'type>', b'nway', b'auto']
    current_if_2 = {}
   

# Generated at 2022-06-24 22:30:19.474141
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_0 = b'mXB'
    darwin_network_0 = DarwinNetwork(bytes_0)
    current_if = {}
    ips = {}
    words_0 = ['media:', '<unknown', 'type>', '']
    result_0 = darwin_network_0.parse_media_line(words_0, current_if, ips)
    assert result_0['media_select'] == 'Unknown'
    assert result_0['media_type'] == 'unknown type'
    assert result_0['media_options'] == {}

# Generated at 2022-06-24 22:30:28.594114
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin_network_1 = DarwinNetwork(b'lo0')
    darwin_network_1.parse_media_line(['media:', '<full-duplex>', '<100baseTX>', 'status:'], darwin_network_1.current_if, '192.168.0.1')
    assert darwin_network_1.current_if['media'] == 'Unknown'
    assert darwin_network_1.current_if['media_select'] == '<full-duplex>'
    assert darwin_network_1.current_if['media_type'] == '100baseTX'
    assert darwin_network_1.current_if['media_options'] is None

    darwin_network_2 = DarwinNetwork(b'lo0')
    darwin_network_2

# Generated at 2022-06-24 22:30:32.278325
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_0 = b'mXB'
    input_0 = ['1000baseT', '<unknown type>']
    output_0 = {'media': 'Unknown', 'media_type': 'unknown type', 'media_select': '1000baseT'}
    darwin_network_0 = DarwinNetwork(bytes_0)
    assert darwin_network_0.parse_media_line(input_0, {}, {}) == output_0

# Generated at 2022-06-24 22:30:38.162063
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    bytes_0 = b'    autoselect          status: inactive'
    parse_media_line_0_words = [b'autoselect', b'status:', b'inactive']
    parse_media_line_0_current_if = {}
    parse_media_line_0_ips = {'inet6': []}
    parse_media_line_0_return = {'media': 'Unknown',
                                 'media_select': 'autoselect',
                                 'media_type': 'status:',
                                 'media_options': {'inactive': 'inactive'}}
    darwin_network_0 = DarwinNetwork(bytes_0)

# Generated at 2022-06-24 22:30:43.532325
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Define the Params
    bytes_0 = b'mXB'
    darwin_network_0 = DarwinNetwork(bytes_0)

    words_0 = '[]'
    current_if_0 = {}
    ips_0 = {}
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)

# Generated at 2022-06-24 22:30:51.486934
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    bytes_1 = b'aXB'
    darwin_network_1 = DarwinNetwork(bytes_1)
    words = ['media:','100baseTX','<full-duplex>']
    line = " ".join(words)
    current_if = {}
    ips = {}

    # Act
    darwin_network_1.parse_media_line(words, current_if, ips)

    # Assert
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '100baseTX'
    assert current_if['media_type'] == 'full-duplex'
    assert current_if['media_options'] == {}


# Generated at 2022-06-24 22:30:58.031058
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    bytes_0 = b'mXB'
    darwin_network_obj = DarwinNetwork(bytes_0)
    words = ["media:", "none"]
    current_if = {"media_select": "", "media_type": "", "media_options": [""] }
    ips = []
    assert darwin_network_obj.parse_media_line(words, current_if, ips) == None


if __name__ == '__main__':
    test_case_0()
    test_DarwinNetwork_parse_media_line()