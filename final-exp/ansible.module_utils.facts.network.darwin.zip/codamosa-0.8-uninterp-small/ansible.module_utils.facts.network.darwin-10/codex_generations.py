

# Generated at 2022-06-24 22:29:46.413924
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words=['media:','autoselect','(1000baseT)','full-duplex,100baseTX,10baseT']
    current_if={}
    ips={}
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert (current_if['media'] == 'Unknown')
    assert (current_if['media_select'] == 'autoselect')
    assert (current_if['media_type'] == '1000baseT')
    assert (current_if['media_options']['full-duplex'] == True)
    assert (current_if['media_options']['100baseTX'] == True)
    assert (current_if['media_options']['10baseT'] == True)

# Generated at 2022-06-24 22:29:53.650631
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.interface_name = "bridge100"
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    current_if = {}
    ips = []
    result = darwin_network_0.parse_media_line(words, current_if, ips)
    print(result)
    assert result is True
    assert current_if['media'] == "Unknown"
    assert current_if['media_type'] == "full-duplex"
    assert current_if['media_select'] == "autoselect"

# Generated at 2022-06-24 22:30:00.705983
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Arrange:
    darwin_network_0 = DarwinNetwork()

    # Act:
    darwin_network_0.parse_media_line(words=['media', '<unknown', 'type>'], current_if={}, ips={})
    # Assert:
    assert darwin_network_0.interfaces['media'] == 'Unknown'
    assert darwin_network_0.interfaces['media_select'] == '<unknown'
    assert darwin_network_0.interfaces['media_type'] == 'unknown type'

    # Act:
    darwin_network_0.parse_media_line(words=['media', '10baseT/UTP', '(<unknown type>)'], current_if={}, ips={})
    # Assert:
    assert darwin_network_

# Generated at 2022-06-24 22:30:11.917441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # media line is different to the default FreeBSD one
    def parse_media_line(self, words, current_if, ips):
        # not sure if this is useful - we also drop information
        current_if['media'] = 'Unknown'  # Mac does not give us this
        current_if['media_select'] = words[1]
        if len(words) > 2:
            # MacOSX sets the media to '<unknown type>' for bridge interface
            # and parsing splits this into two words; this if/else helps
            if words[1] == '<unknown' and words[2] == 'type>':
                current_if['media_select'] = 'Unknown'
                current_if['media_type'] = 'unknown type'

# Generated at 2022-06-24 22:30:22.076120
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_0 = darwin_network_collector_0._fact_class()

    # First argument is a list of strings, each string represents a word
    # Second argument is an interface, we don't care what it is
    # Third argument is a list of IPs, we don't care what it is

    # Test 1: media, media_select, media_type, media_options  are correctly set for a new media line
    darwin_network_0.parse_media_line(["media:", "autoselect", "(none)"], "", [])


# Generated at 2022-06-24 22:30:31.298353
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    current_if_0 = dict()
    ips_0 = dict()
    lines_0 = "media: autoselect (100baseTX <full-duplex>) status: inactive"
    words_0 = lines_0.split()
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == 'autoselect'
    assert current_if_0['media_type'] == '100baseTX'
    assert current_if_0['media_options'] == 'full-duplex'

# Generated at 2022-06-24 22:30:36.593660
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    # For line:
    #  media: autoselect (none)
    # media='Unknown', media_select='autoselect', media_type='none', media_options=[]
    test1_words = ['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media_line(None, test1_words, current_if, ips)
    assert (current_if['media'] == 'Unknown')
    assert (current_if['media_select'] == 'autoselect')
    assert (current_if['media_type'] == 'none')
    assert (current_if['media_options'] == [])
    # For line:
    #  media: autoselect (1000baseT <full-duplex>)
    # media='Unknown', media_select

# Generated at 2022-06-24 22:30:47.299314
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(['<unknown type>'], None, None)
    assert darwin_network_0.ansible_facts['all_ipv4_addresses']['lo0']['media'] == 'Unknown'
    assert darwin_network_0.ansible_facts['all_ipv4_addresses']['lo0']['media_select'] == '<unknown type>'
    assert darwin_network_0.ansible_facts['all_ipv4_addresses']['lo0']['media_type'] == 'unknown type>'

    darwin_network_1 = DarwinNetwork()

# Generated at 2022-06-24 22:30:55.550880
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: autoselect status: active'
    darwin_network = DarwinNetwork()

    current_if = {}
    ips = []
    darwin_network.parse_media_line(line.split(), current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_status'] == 'active'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if


# Generated at 2022-06-24 22:31:01.523881
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork({})

    words = ['<unknown type>', '[none]' ]
    current_if = {}
    ips = []

    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'none'

# Generated at 2022-06-24 22:31:09.466552
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()

    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}

    test_object.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert not current_if.__contains__('media_options')

# Generated at 2022-06-24 22:31:18.499253
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(['media:'], {}, {}) == ({'media': 'Unknown', 'media_select': 'media:'}, {})
    assert darwin_network.parse_media_line(['media:', '10baseT/UTP'], {}, {}) == ({'media': 'Unknown', 'media_select': '10baseT/UTP', 'media_type': 'UTP'}, {})


# Execute all tests
test_DarwinNetwork_parse_media_line()
test_case_0()

# Generated at 2022-06-24 22:31:29.880768
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_1 = DarwinNetworkCollector()
    collector_1 = DarwinNetwork()
    facts = dict()
    facts['interfaces'] = dict()
    interface_name = 'lo0'
    facts['interfaces'][interface_name] = dict()
    words = ['media:', 'autoselect', '(100baseTX)']
    fact_if = darwin_network_collector_1._fact_class.parse_media_line(collector_1, words, interface_name, facts['interfaces'])
    assert 'media' in fact_if
    assert fact_if['media'] == 'Unknown'
    assert 'media_select' in fact_if
    assert fact_if['media_select'] == 'autoselect'
    assert 'media_type' in fact_if
    assert fact_

# Generated at 2022-06-24 22:31:38.596587
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    network_fact_class_0 = darwin_network_collector_0._fact_class()
    current_if = dict()
    words = ['none', 'none', 'none']
    media_line_result = network_fact_class_0.parse_media_line(words, current_if)
    media_line_expected_result = {'media': 'Unknown', 'media_select': 'none', 'media_type': 'none', 'media_options': 'none'}
    assert media_line_result == media_line_expected_result

# Generated at 2022-06-24 22:31:49.239936
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    assert darwin_network_0.parse_media_line(['media:','selection:','autoselect','4','full','-','duplex'], {}, {}) == (None, {}, {}, True)
    assert darwin_network_0.parse_media_line(['media:','10','baseT','full','-','duplex'], {}, {}) == (None, {}, {}, True)
    assert darwin_network_0.parse_media_line(['media:','10','baseT','<unknown','type>','full','-','duplex'], {}, {}) == (None, {}, {}, True)

# Generated at 2022-06-24 22:31:54.399354
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    result = DarwinNetwork.parse_media_line(None, ["media:", "autoselect", ""], {}, None)
    assert result == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '', 'media_options': {}}
    result = DarwinNetwork.parse_media_line(None, ["media:", "autoselect", "none", "full-duplex"], {}, None)
    assert result == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none', 'media_options': {'full-duplex': None}}

# Generated at 2022-06-24 22:31:59.660789
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork(None)
    assert darwin_network.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'autoselect', 'media_options': {}}
    assert darwin_network.parse_media_line(['media:', '<unknown', 'type>', 'status:', 'inactive'], {}, {}) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': {}}

# Generated at 2022-06-24 22:32:04.895826
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media', 'autoselect', '(none)']
    current_if = {}
    ips = None
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    current_if = {}
    darwin_network_0.parse_media_line(['media', 'autoselect', '(none)', 'full-duplex'], current_if, ips)
    assert current_if['media_options'] == 'full-duplex'

    current_if = {}
    darwin_network_0.parse_media_

# Generated at 2022-06-24 22:32:12.898672
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()

    # Ensure that the function returns correct value when it's being run on a Darwin machine
    assert darwin_network_collector_0.fact_class.parse_media_line(["media:", "autoselect", "<unknown type>"],
                                                                   {"media": "Unknown", "media_select": "autoselect"}, None) == \
           {"media": "Unknown", "media_select": "autoselect", "media_type": "unknown type"}

    # Ensure that the function returns correct value when it's being run on non-Darwin machine
    darwin_network_collector_1 = DarwinNetworkCollector()
    darwin_network_collector_1.fact_class._platform = "FreeBSD"
    assert darwin_network_collector

# Generated at 2022-06-24 22:32:18.615083
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 1: Darwin example media line
    macos_media_line = 'media: autoselect (1000baseT <full-duplex>)'
    current_if = {}
    darwin_network_0 = DarwinNetwork()
    words = macos_media_line.split()
    darwin_network_0.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['full-duplex']

    # Test 2: Darwin example media line with special media type
    macos_media_line = 'media: autoselect (<unknown type>)'
    current_if = {}
    words = macos_media_line.split()
