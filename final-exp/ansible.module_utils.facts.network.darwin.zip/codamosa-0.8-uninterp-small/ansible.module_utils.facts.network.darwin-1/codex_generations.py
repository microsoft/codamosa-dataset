

# Generated at 2022-06-24 22:29:45.971596
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = -154.656003
    darwin_network_0 = DarwinNetwork(float_0)
    words_0 = ['status:', 'active', '', '']
    current_if_0 = {'up': True, 'flags': 'UP', 'addresses': ['127.0.0.1/8'], 'type': 'Loopback', 'device': 'lo0'}
    ips_0 = ['127.0.0.1/8']
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0) 
    words_0 = ['', '', '', 's' ]

# Generated at 2022-06-24 22:29:49.624075
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_osx_line = "media: autoselect  <unknown type>  status: inactive"
    darwin_network_0 = DarwinNetwork(0.0)
    words = mac_osx_line.split()
    current_if = dict()
    darwin_network_0.parse_media_line(words, current_if, '')

# Generated at 2022-06-24 22:30:00.398482
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = -154.656003
    darwin_network_0 = DarwinNetwork(float_0)
    words_0 = ['<unknown type>', 'autoselect <none>']
    current_if_0 = {}
    ips_0 = {}

    # Test cases
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == 'autoselect'
    assert current_if_0['media_type'] == 'unknown type'


# Generated at 2022-06-24 22:30:08.157682
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = -154.656003
    darwin_network_0 = DarwinNetwork(float_0)
    words_0 = ['Unknown', ' ', '<unknown type>']
    current_if_0 = darwin_network_0.active_interfaces.get('lo')
    ips_0 = {}
    assert darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)



# Generated at 2022-06-24 22:30:16.289509
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Test fixture
    words = ['media:', 'auto', '10baseT/UTP', '(none)', 'mediaopt', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = []

    # Test
    darwin_network_0 = DarwinNetwork(None)
    darwin_network_0.parse_media_line(words, current_if, ips)
    current_if_expected = {'media': 'Unknown', 'media_select': 'auto', 'media_type': '10baseT/UTP', 'media_options': 'mediaopt'}
    assert current_if == current_if_expected

# Generated at 2022-06-24 22:30:26.124424
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = -153.0006342
    darwin_network_0 = DarwinNetwork(float_0)
    current_if = {}
    ips = {}
    words = ['foo', 'bar', 'baz']
    darwin_network_0.parse_media_line(words, current_if, ips)

    words = ['foo', 'bar', 'baz', 'qux']
    darwin_network_0.parse_media_line(words, current_if, ips)

    words = ['foo', 'bar', 'baz', 'qux', 'quux']
    darwin_network_0.parse_media_line(words, current_if, ips)


# Generated at 2022-06-24 22:30:32.695139
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = -154.656003
    darwin_network_0 = DarwinNetwork(float_0)
    darwin_network_1 = DarwinNetwork(0.0)
    words = ['media', 'autoselect', '10baseT/UTP', '(none)', 'mediaopt', 'hdx']
    current_if = dict()
    darwin_network_0 = DarwinNetwork(float_0)
    darwin_network_0.parse_media_line(words, current_if, None)
    #check if the media, media_select, media_type and media_options attributes have been set in the current_if dict
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-24 22:30:40.564993
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = -154.656003
    darwin_network_0 = DarwinNetwork(float_0)
    words = ['media:','avg','10Mbps','full-duplex']
    current_if = {'dummy': 'dummy'}
    ips = ['test_ips', 'test_ips_1']
    result = darwin_network_0.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'avg'
    assert current_if['media_type'] == '10Mbps'
    assert current_if['media_options'] == 'full-duplex'

# test for bridge interface

# Generated at 2022-06-24 22:30:49.755261
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = 123.749
    darwin_network_0 = DarwinNetwork(float_0)
    tuple_0 = (DarwinNetwork, 'media', 'media_select', 'media_type', 'media_options', 'media_status')
    tuple_1 = ('Unknown', '<unknown type>', 'Fixed', {'autoselect': 'on', 'full-duplex': 'on', 'status': 'active', 'supported': '10baseT/UTP'}, 'active')
    darwin_network_0.parse_media_line(tuple_0, tuple_1)

# Generated at 2022-06-24 22:30:57.099088
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    float_0 = 65.22
    darwin_network_0 = DarwinNetwork(float_0)

    expected_result = {'media': 'Unknown', 'media_select': 'full-duplex', 'media_type': 'Ethernet',
                       'media_options': ['autoselect']}
    words = ['media:', 'full-duplex', 'Ethernet', 'autoselect']
    current_if = {}

    darwin_network_0.parse_media_line(words, current_if, None)

    assert current_if == expected_result

    expected_result = {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'unknown type'}
    words = ['media:', '<unknown', 'type>']
    current_if = {}

    darwin_network

# Generated at 2022-06-24 22:31:08.471555
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # test case 0
    words_0 = ['media:','100baseTX','<full-duplex>','media','100baseTX','<full-duplex>','status:','active','active','status:','active','active','inactive','inactive']
    current_if_0 = {}
    ips_0 = {}
    darwin_network.parse_media_line(words_0, current_if_0, ips_0)

    # test case 1
    words_1 = ['media:','<unknown','type>','autoselect','(none)','status:','inactive','inactive','status:','inactive','inactive','inactive','inactive']
    current_if_1 = {}
    ips_1 = {}
    darwin_network.parse_media_

# Generated at 2022-06-24 22:31:11.564766
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork().parse_media_line([':', 'autoselect', 'status:', 'active'], {}, None)

    DarwinNetwork().parse_media_line([':', 'autoselect', 'status:', 'active'], {'media_type': 'unknown type'}, None)

# Generated at 2022-06-24 22:31:15.137298
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Return media line of each interface"""
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_0 = darwin_network_collector_0.get_devices()
    for device in darwin_network_0.values():
        for iface in device.values():
            if 'media' in iface:
                print("media: " + iface['media'])
            else:
                print("media: [UNAVAILABLE]")


# Generated at 2022-06-24 22:31:26.738775
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # check media line with unknown type
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    darwin_network.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    # check media line with multiple options
    words = ['media:', 'autoselect', '(100baseTX', 'full-duplex,rxpause)', 'status:', 'active']
    current_if['media_select'] = 'default'

# Generated at 2022-06-24 22:31:37.426445
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    words = ['media:', 'autoselect', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': None}

    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': None}

    words = ['media:', '<unknown', 'type>']

# Generated at 2022-06-24 22:31:48.064224
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ["media:", "none", "(no carrier)"]
    current_if = dict()
    ips = dict()
    darwin_network_0.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'none'
    assert current_if['media_type'] == '(no carrier)'
    assert 'media_options' not in current_if

# Generated at 2022-06-24 22:31:50.484136
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    media_line = ['', 'none', 'none']
    current_if = {}
    ips = None
    darwin_network_0.parse_media_line(media_line, current_if, ips)

# Generated at 2022-06-24 22:31:56.425283
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_obj = DarwinNetwork()
    assert darwin_network_obj.parse_media_line(['media:', '10baseX', '(none)'], {'iface': 'en0'}, {}) == ({'iface': 'en0', 'media': 'Unknown', 'media_select': '10baseX', 'media_type': '(none)'}, {})
    assert darwin_network_obj.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {'iface': 'en2'}, {}) == ({'iface': 'en2', 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}, {})

# Generated at 2022-06-24 22:32:06.701851
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    print("Testing DarwinNetwork class")
    darwin_network = DarwinNetwork()

    current_if = dict()
    ips = dict()

    mac_words = ["<unknown type>"]
    darwin_network.parse_media_line(mac_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

    net_words = ["100baseTX", "Lnk", "100baseTx", "FD", "UP"]
    darwin_network.parse_media_line(net_words, current_if, ips)
    assert current_if['media'] == '100baseTxFD'

# Generated at 2022-06-24 22:32:13.623234
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = [ 'media:', 'autoselect', '(none)' ]
    current_if = { 'media': None, 'media_select': None, 'media_type': None, 'media_options': None }
    darwin_network_0.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] is None
    words = [ 'media:', 'media:', 'autoselect', 'ofdm', '-54dbm' ]

# Generated at 2022-06-24 22:32:24.355731
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Example data
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = None

    # Run method
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_collector_0.get_fact_class().parse_media_line(words, current_if, ips)

    # Assertions
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == 'none'
    

# Generated at 2022-06-24 22:32:30.302974
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork()
    (current_if, ips, words) = ({}, {}, ['media:', 'autoselect', '(none)'])
    test_obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

# Generated at 2022-06-24 22:32:31.610460
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork.parse_media_line("This is words", "This is current_if", "This is ips")

# Generated at 2022-06-24 22:32:37.230348
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:32:47.978169
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:32:54.984926
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test 0
    words_0 = ['media:', 'autoselect', '[none]']
    current_if_0 = {'media_options': 'none'}
    ips_0 = {}
    result_0 = DarwinNetwork.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0['media'] == 'Unknown'
    assert current_if_0['media_select'] == 'autoselect'
    assert current_if_0['media_type'] == 'none'
    assert current_if_0['media_options'] == 'none'


# test 1
words_1 = ['media:', '<unknown', 'type>']
current_if_1 = {}
ips_1 = {}

# Generated at 2022-06-24 22:33:01.171387
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # test case 0
    case_0_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    case_0_current_if = dict()
    case_0_ips = dict()
    darwin_network.parse_media_line(case_0_words, case_0_current_if, case_0_ips)
    assert case_0_current_if == dict(media='Unknown', media_select='autoselect', media_type='none', media_options={})


# Generated at 2022-06-24 22:33:11.923747
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()

    words = [
        'media:',
        'autoselect',
        '10baseT/UTP'
    ]
    current_if = {
        'active': True,
        'device': 'en0',
        'inet': [
            {
                'address': '192.168.2.3',
                'broadcast': '192.168.2.255',
                'netmask': '255.255.255.0'
            }
        ],
        'media_select': '',
        'media_type': '',
        'media_options': '',
        'media': '',
        'mtu': '1500',
        'status': 'active',
        'type': 'en0',
        'up': True
    }

# Generated at 2022-06-24 22:33:19.843129
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Set the line to parse
    line = '\tmedia: autoselect <unknown type> status: active'

    # Init the class
    darwin_network = DarwinNetwork()

    # Init the empty interface
    current_if = {}

    # Init empty list of ips
    ips = []

    # Split the line in words
    words = line.split()

    # Call the method
    res = darwin_network.parse_media_line(words, current_if, ips)

    # Asserts
    assert res is None
    assert current_if == { 'media': 'Unknown',
                           'media_select': 'autoselect',
                           'media_type': 'unknown type',
                           'media_options': { 'status': 'active' }
                         }


# Generated at 2022-06-24 22:33:25.821032
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_0 = DarwinNetwork()

    assert darwin_network_0.parse_media_line(['media:', 'autoselect', '(none)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': 'none'}
    assert darwin_network_0.parse_media_line(['media:', 'autoselect', '(none)'], {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': 'none'}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': 'none'}

# Generated at 2022-06-24 22:33:40.840530
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', 'status:', 'active', 'ethernet', 'autoselect']
    current_if = {"type": "Ethernet"}
    ips = {}
    darwin_network = DarwinNetwork()
    darwin_network_parse_media_line_result = darwin_network.parse_media_line(words, current_if, ips)
    assert darwin_network_parse_media_line_result is None
    assert current_if == {'media_type': 'ethernet', 'type': 'Ethernet', 'media': 'Unknown', 'media_options': {'status': 'active', 'autoselect': ''}}

# Generated at 2022-06-24 22:33:50.205263
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    test_current_if_0 = {}
    test_ips_0 = {}
    test_words_0 = ['media:', 'autoselect', '100baseTX', '(100baseTX<full-duplex>)']
    assert darwin_network_collector_0._fact_class.parse_media_line(test_words_0, test_current_if_0, test_ips_0) == None
    assert test_current_if_0['media_type'] == '100baseTX'
    assert test_current_if_0['media_options'] == {'full-duplex': True}
    assert test_current_if_0['media_select'] == 'autoselect'


# Generated at 2022-06-24 22:34:00.013411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(["media:", "autoselect", "100baseTX", "full-duplex"], {}, {})

# Generated at 2022-06-24 22:34:04.421119
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # We need to do that to avoid errors when we run the tests in the CI Server
    ifconfig_path = ''
    ifconfig_path = './tests/unit/module_utils/facts/network/darwin_eth_ifconfig_output'
    darwin_network_0 = DarwinNetwork({'module_facts': {'network': {'interfaces': {}}, 'ansible_facts': {}}}, ifconfig_path=ifconfig_path)
    darwin_network_0._parse_media_line(['media:', '<unknown', 'type>'], {}, {})
    assert darwin_network_0._current_if['media_select'] == 'Unknown'
    assert darwin_network_0._current_if['media_type'] == 'unknown type'

# Generated at 2022-06-24 22:34:07.519093
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create instance
    darwin_network_0 = DarwinNetwork()
    # test empty media line
    darwin_network_0.parse_media_line([], {}, None)



# Generated at 2022-06-24 22:34:12.939709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = dict(
        words=["media:", "<unknown type>"],
        current_if=dict(),
        ips=list()
    )
    current_if = dict()
    darwin_network_obj = DarwinNetwork()
    darwin_network_obj.parse_media_line(test_data['words'], test_data['current_if'], test_data['ips'])
    assert test_data['current_if']['media'] == current_if['media']
    assert test_data['current_if']['media_select'] == current_if['media_select']
    assert test_data['current_if']['media_type'] == current_if['media_type']



# Generated at 2022-06-24 22:34:22.075411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """test for parse_media_line"""
    i_fallback_0 = Darwin(None)
    i_fallback_0._fact_class = DarwinNetwork
    i_fallback_0._platform = 'Darwin'
    test_words_0 = ['media:', 'IEEE', '802.11', 'Diversity', 'Autoselect', '(auto', '11b)', 'status:', 'inactive', 'nwid:', '0', 'rx', 'invalid', 'nwid:', '0', 'in', 'crypt:', '0', 'decomp:', '0', 'tx', 'invalid', 'nwid:', '0', 'in', 'crypt:', '0', 'decomp:', '0']

# Generated at 2022-06-24 22:34:29.312178
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    assert darwin_network_0.parse_media_line(['media:', 'media_select', 'media_type']) == {'media': 'Unknown', 'media_select': 'media_select', 'media_type': 'media_type'}
    assert darwin_network_0.parse_media_line(['media:', 'media_select', 'media_type', 'media_options']) == {'media': 'Unknown', 'media_select': 'media_select', 'media_type': 'media_type', 'media_options': 'media_options'}

# Generated at 2022-06-24 22:34:35.335661
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    current_if = {}
    ips = {}
    words = ['media', 'autoselect', '10baseT/UTP']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': '10baseT/UTP'}
    assert ips == {}

    current_if = {}
    ips = {}
    words = ['media', '<unknown', 'type>', 'status:', 'inactive']
    darwin_network.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:34:39.771511
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'Wi-Fi', 'media_options': {'mode': 'managed'}}
    input_words = "media: autoselect Wi-Fi(mode managed)"
    current_if = {'media': 'Unknown'}
    ips = []
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(input_words.split(), current_if, ips)
    assert test_dict['media'] == current_if['media']
    assert test_dict['media_select'] == current_if['media_select']
    assert test_dict['media_type'] == current_if['media_type']
    assert test_dict['media_options'] == current_if['media_options']

# Generated at 2022-06-24 22:35:01.212630
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector = DarwinNetworkCollector()
    # Test case 1:
    darwin_network_0 = DarwinNetwork(darwin_network_collector)
    words = ['media:', 'autoselect', 'Wi-Fi', 'status:', 'inactive']
    current_if = {'device': 'en0', 'inet': '6', 'inet6': '2001:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx%en0', 'ipv4': [], 'ipv6': []}
    current_if['netmask'] = 'ffff:ffff:ffff:ffff::'
    current_if['network'] = '2001:xxxx:xxxx:xxxx::'
    ips = []
    darwin_network_0.parse_media_line(words, current_if, ips)
   

# Generated at 2022-06-24 22:35:08.474701
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()

    # test_case_0
    network_if = 'eth0'
    line = 'media: Ethernet autoselect (1000baseT <full-duplex>) status: active'
    words = line.strip().split()
    ips = dict()
    darwin_network_0.parse_media_line(words, network_if, ips)
    print(('test case 0:', network_if))
    print(network_if['media'])
    print(network_if['media_select'])
    print(network_if['media_type'])
    print(network_if['media_options'])

    # test_case_1
    network_if = 'eth1'
    line = 'media: <unknown type>'

# Generated at 2022-06-24 22:35:18.462375
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    # Test with current_if = None
    retval = darwin_network_0.parse_media_line(['media:', 'autoselect', '(1000baseT)'], None, None)
    assert retval is None
    # Test with (ips=None, media_type=1000baseT)
    retval = darwin_network_0.parse_media_line(['media:', 'autoselect', '(1000baseT)'], {'media_type': '1000baseT', 'ips': None}, None)
    assert retval is None
    # Test with (ips=None, media_select=autoselect, media_type=1000baseT)

# Generated at 2022-06-24 22:35:25.935287
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    iface = {}
    ips = {}
    darwin_network.parse_media_line(words, iface, ips)

    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '(none)'
    assert not iface['media_options']



# Generated at 2022-06-24 22:35:33.061200
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = dict()

    # default case
    words = [0, 'autoselect', 'media', 'options']
    darwin_network.parse_media_line(words=words, current_if=current_if, ips=dict())
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'media'
    assert current_if['media_options'] == ['options']

    # unknown type media types
    current_if = dict()
    words = [0, '<unknown', 'type>']
    darwin_network.parse_media_line(words=words, current_if=current_if, ips=dict())
    assert current_if

# Generated at 2022-06-24 22:35:40.479690
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector = DarwinNetwork()
    assert darwin_network_collector.parse_media_line(['media:', 'autoselect', '100baseTX', 'full-duplex', 'autoselect'],
                                                     {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect',
                                                                  'media_type': '100baseTX', 'media_options': {}}
    assert darwin_network_collector.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == {'media': 'Unknown',
                                                                                                'media_select': 'Unknown',
                                                                                                'media_type': 'unknown type',
                                                                                                'media_options': {}}

# Generated at 2022-06-24 22:35:50.131922
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()
    test_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    expected_result = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '(none)',
        'media_options': {}
    }
    actual_result = test_object.parse_media_line(test_words, {}, [])
    assert actual_result == expected_result
    test_words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    expected_result = {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type',
        'media_options': {}
    }
    actual_result = test_

# Generated at 2022-06-24 22:35:58.887511
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()  # unit test of class
    darwin_network_collector_0._platform = 'Darwin'

    current_if = dict()
    darwin_network_0 = DarwinNetwork()  # unit test of class
    ips = dict()
    words = ['media:', 'autoselect', '', 'status:', 'active']

    darwin_network_0.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == ''
    assert 'media_options' not in current_if
    assert 'options' not in current_if
    assert 'inet' not in current

# Generated at 2022-06-24 22:36:07.362591
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    This test case tests the parse_media_line method of class DarwinNetwork.

    """
    darwin_network_0 = DarwinNetwork()
    darwin_media_line = darwin_network_0.parse_media_line(['media:', '<unknown type>'], {}, {})
    assert darwin_media_line['media'] == 'Unknown'
    assert darwin_media_line['media_select'] == '<unknown type>'
    assert 'media_type' not in darwin_media_line

# Generated at 2022-06-24 22:36:14.999529
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork(ignore_lo=True)
    # example from http://osx.iusethis.com/app/ifconfig
    words = ['media:', 'autoselect', 'status:', 'inactive']
    current_if = {'device': 'en0', 'inet': []}
    ips = []

    media_line = darwin_network_0.parse_media_line(words, current_if, ips)

    assert media_line.get('media') == 'Unknown'
    assert media_line.get('media_select') == 'autoselect'
    assert media_line.get('media_type') == None
    assert media_line.get('media_options') == None



# Generated at 2022-06-24 22:36:46.899958
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media', 'autoselect', '100baseTX', '(100baseTX)', 'status:', 'inactive']
    current_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX', 'media_options': ['100baseTX']}
    ips = {}
    darwin_network_0.parse_media_line(words, current_if, ips)

    words = ['media', '<unknown', 'type>', 'status:', 'active']
    current_if = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    ips = {}

# Generated at 2022-06-24 22:36:50.988516
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_obj = DarwinNetwork()
    test_values = [
        ([ 'media:', '<unknown type>', 'status:', 'inactive'], {}),
    ]
    for test_value in test_values:
        darwin_network_obj.parse_media_line(test_value[0], test_value[1], False)
    return

# Generated at 2022-06-24 22:36:58.468505
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_facts_obj = DarwinNetwork()
    words = ['media:', '$test_media_select', '$test_media_type', '$test_media_options']
    current_if = {'$test_key': '$test_value'}
    ips = ['$test_ip_1', '$test_ip_2']
    darwin_facts_obj.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': '$test_media_select', 'media_type': '$test_media_type', 'media_options': '$test_media_options', '$test_key': '$test_value'}
    words = ['media:', '<unknown', 'type>']

# Generated at 2022-06-24 22:37:06.425366
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-24 22:37:10.602298
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words_0 = []
    current_if_0 = {}
    ips_0 = {}
    # We need to initialize the class
    DarwinNetwork_instance = DarwinNetwork()

    # We are going to test the default parse_media_line as we have no other
    # special cases
    DarwinNetwork_instance.parse_media_line(words_0, current_if_0, ips_0)

# Generated at 2022-06-24 22:37:17.253822
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instance of DarwinNetwork
    darwin_network_0 = DarwinNetwork()
    # Store parsed output of media line
    darwin_network_0.parse_media_line('media: autoselect (100baseTX full-duplex,flowcontrol,rxpause,txpause)',
        {'media': 'Unknown'}, {}, None)
    # Test assertions
    assert darwin_network_0.data['interfaces'][None]['media'] == 'Unknown'
    assert darwin_network_0.data['interfaces'][None]['media_select'] == 'autoselect'
    assert darwin_network_0.data['interfaces'][None]['media_type'] == '100baseTX full-duplex,flowcontrol,rxpause,txpause'
    assert darwin_network_0.data

# Generated at 2022-06-24 22:37:23.272508
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    test_words_0 = ['media:', 'autoselect', 'status:', 'inactive']
    test_current_if_0 = {}
    test_ips_0 = []
    darwin_network_0.parse_media_line(test_words_0, test_current_if_0, test_ips_0)
    assert test_current_if_0['media'] == 'Unknown'
    assert test_current_if_0['media_select'] == 'autoselect'
    assert test_current_if_0['media_type'] == 'status'
    assert test_current_if_0['media_options'] == {'inactive': ''}

# Generated at 2022-06-24 22:37:26.058443
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    # No assert as unkown, do not know what to assert

# Generated at 2022-06-24 22:37:31.273456
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_media_line = ['media:', 'autoselect', '(none)']
    current_if = {'media': 'Unknown', 'media_select': 'none', 'media_type': '(none)', 'media_options': {}}
    # Call the method to test
    result = DarwinNetwork.parse_media_line(None, test_media_line, current_if);
    # Assert the results
    assert result.get('media') == 'Unknown'
    assert result.get('media_select') == 'autoselect'
    assert result.get('media_type') == '(none)'


# Generated at 2022-06-24 22:37:35.346633
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    darwin_network_0.parse_media_line(['media:','none','status:','inactive'],{},{})
    assert darwin_network_0.interfaces['media']=='Unknown'
    assert darwin_network_0.interfaces['media_select']=='none'
    assert darwin_network_0.interfaces['media_type']=='Unknown'
    #not sure if this is useful - we also drop information


# Generated at 2022-06-24 22:38:24.980178
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], dict(), dict())
    assert 'media' in darwin_network.current['interfaces']['lo0']
    assert darwin_network.current['interfaces']['lo0']['media'] == 'Unknown'
    assert 'media_select' in darwin_network.current['interfaces']['lo0']
    assert darwin_network.current['interfaces']['lo0']['media_select'] == 'autoselect'
    assert 'media_options' not in darwin_network.current['interfaces']['lo0']

# Generated at 2022-06-24 22:38:34.434495
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    words = ['media:', 'auto', '10baseT/UTP', '(<unknown option>;']
    current_if = {'macaddress': '00:00:00:00:00:00', 'mtu': 1500, 'type': 'ether', 'active': True}
    darwin_network_0.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == [('unknown option', None)]


# Generated at 2022-06-24 22:38:38.275696
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()

    # test case 0
    words = [
        'media:', '<unknown type>', 'status:', 'inactive'
    ]
    current_if = {
        'device': 'bridge0'
    }
    ips = []
    darwin_network_0.parse_media_line(words, current_if, ips)


test_case_0()
test_DarwinNetwork_parse_media_line()

# Generated at 2022-06-24 22:38:46.455476
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ test parse media line without unknown type """
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', 'status:', 'active']
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert('media' in current_if)
    assert('media_select' in current_if)
    assert('media_type' in current_if)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == 'autoselect')
    assert(current_if['media_type'] == 'status:')


# Generated at 2022-06-24 22:38:54.474852
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'auto', '(none)']
    ips = {}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}

    current_if = {}
    words = ['media:', '<unknown', 'type>']
    ips = {}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if

# Generated at 2022-06-24 22:39:02.098776
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    """
    Unit test for method parse_media_line of class DarwinNetwork.

    The test_case_0 is used to test the default route setting
    """

# Generated at 2022-06-24 22:39:11.979111
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin_network_0 = DarwinNetwork()

    assert darwin_network_0.parse_media_line(['media:', 'autoselect', '(none)'],
                                             {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': 'none'}

    assert darwin_network_0.parse_media_line(['media:', '1000baseT', '(none)'],
                                             {}, {}) == {'media': 'Unknown', 'media_select': '1000baseT', 'media_options': 'none'}


# Generated at 2022-06-24 22:39:19.295945
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    media_line = [ 'media:', '<unknown type>', '(none)' ]
    result = darwin_network.parse_media_line(media_line, {}, {})
    assert result['media'] == 'Unknown'
    assert result['media_select'] == 'Unknown'
    assert result['media_type'] == 'unknown type'
    assert result['media_options'] == '(none)'

# Generated at 2022-06-24 22:39:24.506894
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork(None)
    facts = {}
    # parsing of a simple line
    test_line = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    current_if = {}
    darwin_network.parse_media_line(test_line, current_if, facts)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'autoselect'

    # parsing of a empty line
    test_line = []
    current_if = {}
    darwin_network.parse_media_line(test_line, current_if, facts)

# Generated at 2022-06-24 22:39:27.596571
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_network = DarwinNetwork()
    words = ['media:', '<unknown type>']
    mac_network.parse_media_line(words, mac_network.current_if, mac_network.interfaces)
    assert mac_network.current_if['media_select'] == 'Unknown'
    assert mac_network.current_if['media_type'] == 'unknown type'