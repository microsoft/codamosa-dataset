

# Generated at 2022-06-24 22:29:43.684406
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_obj = DarwinNetwork()
    darwin_network_obj.parse_media_line(['Current', 'autoselect', '<unknown>'], {}, {})
    assert darwin_network_obj.parse_media_line(['Current', 'autoselect', 'media', 'mediaoptions'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'media', 'media_options': 'mediaoptions'}

# Generated at 2022-06-24 22:29:52.329527
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork()
    # Media Hash of following form
    #media:        autoselect (100baseTX <full-duplex>)
    #media_select: autoselect
    #media_type:   100baseTX
    #media_options:<full-duplex>
    words = ['media:', 'autoselect', '(100baseTX', '<full-duplex>)']
#     print(words)
    current_if = dict()
    current_if['media'] = 'Unknown'
    current_if['media_select'] = words[1]

# Generated at 2022-06-24 22:30:02.993629
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin_network_1 = DarwinNetwork()

    # test 0: unknown media line
    media_line = [ 'media:', '<unknown type>', '(none)' ]
    current_if = dict()
    darwin_network_1.parse_media_line(media_line, current_if, None)
    assert current_if == {'media_options': None, 'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

    # test 1: media line for unknown device type
    media_line = [ 'media:' ]
    current_if = dict()
    darwin_network_1.parse_media_line(media_line, current_if, None)
    assert current_if == {'media_options': None, 'media': 'Unknown'}

    # test 2

# Generated at 2022-06-24 22:30:12.894469
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_collector_0 = DarwinNetworkCollector()
    darwin_network_0 = DarwinNetwork()

    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    words2 = ['media:', 'autoselect', '(none)', 'status:', 'active']
    words3 = ['media:', '<unknown', 'type>', 'status:', 'active']
    words4 = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    words5 = ['media:', 'autoselect', '(none)', 'status:', 'active', 'lladdr', 'some:mac:address']


# Generated at 2022-06-24 22:30:23.141291
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # Given a media line of 'Media: <unknown type>'
    words = [u'Media:', u'<unknown', u'type>']
    current_if = {u'media': u'Unknown', u'media_type': u'unknown type', u'media_select': u'<unknown', u'media_options': u''}
    ips = None
    # When the method parse_media_line is called with the given arguments
    darwin_network.parse_media_line(words, current_if, ips)
    # Then the result should be 'Unknown', 'unknown type', '<unknown', ''
    assert current_if[u'media'] == u'Unknown'
    assert current_if[u'media_type'] == u'unknown type'
    assert current_if

# Generated at 2022-06-24 22:30:29.031885
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    parsed_interface = dict()
    darwin_network = DarwinNetwork()
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1']
    ips = dict()
    darwin_network.parse_media_line(words, parsed_interface, ips)

    assert parsed_interface['media'] == 'Unknown'

# Generated at 2022-06-24 22:30:32.480786
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['foo', 'bar', 'type']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'bar'
    assert current_if['media_type'] == 'type'

# Generated at 2022-06-24 22:30:40.071235
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_0 = DarwinNetwork('')
    words_0 = ["media:", "<unknown", "type>", "supported", "OUI", "IEEE802/EUI-48"]
    current_if_0 = dict()
    ips_0 = dict()
    darwin_network_0.parse_media_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:30:49.224310
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # from /sbin/ifconfig
    media_line_1 = ['media:', '<unknown type>', '(0xffff)']
    media_line_2 = ['media:', 'autoselect', '(0xffffffff)']
    media_line_3 = ['media:', 'autoselect', '10baseT/UTP', '(0x8)']

    # from /sbin/ifconfig lo0
    media_line_4 = ['media:', '10Gbase-LR/LRM', '10GBASE-LR/LRM <1310nm Single-Mode Fiber>', '(0x1a)']

    # current_if = {}
    dn_1 = DarwinNetwork()
    dn_1.parse_media_line(media_line_1, current_if={}, ips={})
    assert current_

# Generated at 2022-06-24 22:30:56.114241
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a test instance of DarwinNetwork
    darwin_network_0 = DarwinNetwork()

    # define variables to test parse_media_line method
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']
    current_if = {}

    # call parse_media_line method and check it's output
    if darwin_network_0.parse_media_line(words,current_if):
        assert current_if['media'] == 'Unknown'
        assert current_if['media_select'] == 'autoselect'
        assert current_if['media_type'] == '1000baseT <full-duplex>'
    else:
        assert False