

# Generated at 2022-06-11 03:04:16.873112
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    _current_if = dict()
    _current_if['name'] = 'en0'
    _words = ['en0:', 'media:', '<unknown', 'type>']
    _ips = '127.0.0.1'
    DarwinNetwork.parse_media_line(_current_if, _words, _ips)
    assert _current_if == dict(
        name='en0',
        media='Unknown',
        media_select='media:',
        media_type='unknown type',
    )

# Generated at 2022-06-11 03:04:26.886186
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_module = DarwinNetwork()
    # Test case 1 - set media_select and media_type
    media_line = ['media:', 'autoselect', '(1000baseT)']
    expected_if = {
        'macaddress': None,
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '1000baseT',
        'media_options': None,
        'options': None,
        'type': None,
        'dhcpclient': None,
        'dhcpserver': None,
        'counters': {},
        'active': True,
        'description': None,
        'type_description': None,
        'features': None
    }
    result_if = test_module.parse_media_line(media_line, {}, False)
   

# Generated at 2022-06-11 03:04:28.317319
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    iface = DarwinNetwork()
    assert iface.platform == 'Darwin'


# Generated at 2022-06-11 03:04:39.607235
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w1 = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}
    dn = DarwinNetwork()
    dn.parse_media_line(w1, current_if, ips)
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}

    w2 = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}
    dn = DarwinNetwork()
    dn.parse_media_line(w2, current_if, ips)
    assert current_if['media'] == 'Unknown' 

# Generated at 2022-06-11 03:04:47.375562
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig = DarwinNetwork()

# Generated at 2022-06-11 03:04:50.750620
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network = DarwinNetwork()
    assert isinstance(network, DarwinNetwork)
    assert network.platform == 'Darwin'
    # Assert that parser can be caught
    assert isinstance(network, GenericBsdIfconfigNetwork)


# Generated at 2022-06-11 03:04:55.007740
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork({})
    assert d.platform == 'Darwin'
    assert isinstance(d.facts, dict)
    assert isinstance(d.facts['interfaces'], list)
    assert not d.facts['all_ipv4_addresses']


# Generated at 2022-06-11 03:04:56.589192
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """
    Constructor test.
    """
    DarwinNetwork(None)

# Generated at 2022-06-11 03:05:05.933454
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {
        'media': '',
        'media_select': '',
        'media_type': '',
        'media_options': {},
        'up': False
    }
    words = ['', 'status:', 'active', 'inactive']
    network_object = DarwinNetwork()
    network_object.parse_media_line(words, iface, {})
    # Result should be 1
    assert iface == {
        'media': 'Unknown',
        'media_select': 'status:',
        'media_type': 'active inactive',
        'media_options': {},
        'up': False
    }

    # Test of the media_type option

# Generated at 2022-06-11 03:05:09.284654
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>'], current_if, 'ips')
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:05:20.788498
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from collections import OrderedDict
    test_data = [(['media:', 'autoselect'], {'media': 'Unknown', 'media_select': 'autoselect'}),
                 (['media:', 'P2P'], {'media': 'Unknown', 'media_select': 'P2P'}),
                 (['media:', '<unknown', 'type>'], {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}),
                 (['media:', '1000baseT', '(none)'], {'media': 'Unknown', 'media_select': '1000baseT', 'media_type': '(none)'})]

    dn = DarwinNetwork()

# Generated at 2022-06-11 03:05:28.807279
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_test_dict = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'none',
        'media_options': 'none',
    }
    mac_test_line = 'media: autoselect None none'
    mac_test_words = mac_test_line.split()
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(DarwinNetwork, mac_test_words, current_if, ips)
    assert current_if == mac_test_dict

# Generated at 2022-06-11 03:05:38.161518
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Initialize the test object
    dn = DarwinNetwork()

    # Initialize a test interface
    iface1 = dict()
    iface1['name'] = 'test_iface'
    iface1['type'] = 'Ethernet'
    iface1['number'] = '1'
    iface1['media'] = None
    iface1['media_type'] = None
    iface1['media_select'] = None
    iface1['media_options'] = None

    # Valid input
    words1 = ['media:', 'autoselect', 'none', 'status:', 'inactive']

    expected_iface1 = dict()
    expected_iface1['name'] = 'test_iface'
    expected_iface1['type'] = 'Ethernet'

# Generated at 2022-06-11 03:05:48.476086
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # GenericBsdIfconfigNetwork.parse_media_line()
    gen = GenericBsdIfconfigNetwork()

    # Media line without media options
    cur_if = dict()
    words = ['media:', 'none', '(none)']
    gen.parse_media_line(words, cur_if, [])
    assert cur_if['media'] == 'none'
    assert 'media_select' not in cur_if
    assert 'media_type' not in cur_if
    assert 'media_options' not in cur_if

    # Media line with media options
    cur_if = dict()
    words = ['media:', '1000baseT', '(1000baseT)', 'full-duplex']
    gen.parse_media_line(words, cur_if, [])

# Generated at 2022-06-11 03:05:54.837328
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    mac_words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {'device': 'en0'}
    ips = []
    dwn.parse_media_line(mac_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:05.867795
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_DarwinNetwork = DarwinNetwork()
    test_interface = dict()
    test_ips = list()

    # Case 1: words split 'media auto' into two words
    test_words = ['media', 'auto']
    test_DarwinNetwork.parse_media_line(test_words, test_interface, test_ips)
    assert test_interface['media'] == 'Unknown'
    assert test_interface['media_select'] == 'auto'
    assert not 'media_options' in test_interface
    assert not 'media_type' in test_interface

    # Case 2: words split 'media <unknown type>' into three words
    test_words = ['media', '<unknown', 'type>']
    test_DarwinNetwork.parse_media_line(test_words, test_interface, test_ips)
    assert test_

# Generated at 2022-06-11 03:06:14.843771
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Tests for method parse_media_line of class DarwinNetwork."""
    darwin_network = DarwinNetwork()

    # Test normal case
    words_test_normal = ['media:', 'auto', '1000baseT', '(<full-duplex>,master)']
    current_if_test_normal = dict()
    ips_test_normal = list()

    darwin_network.parse_media_line(words_test_normal, current_if_test_normal, ips_test_normal)
    assert current_if_test_normal['media'] == 'Unknown'
    assert current_if_test_normal['media_select'] == 'auto'
    assert current_if_test_normal['media_type'] == '1000baseT'
    assert len(current_if_test_normal['media_options']) == 2

# Generated at 2022-06-11 03:06:26.991724
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    generic_bsd = DarwinNetwork()
    medias = [
        ['supported', 'autoselect', '10baseT/UTP', '<flow-control>'],
        ['supported', '<unknown type>', '<unknown type>', '<flow-control>'],
        ['supported', 'autoselect', '/admin/MyMediaType', '<flow-control>'],
        ['supported', '/admin/MyMediaType', '<flow-control>'],
    ]
    for media in medias:
        current_if = {}
        generic_bsd.parse_media_line(media, current_if, None)
        assert 'media' in current_if

# Generated at 2022-06-11 03:06:32.746624
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    generic = GenericBsdIfconfigNetwork()
    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = dict()
    ips = dict()

    generic.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-11 03:06:34.297098
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Method Parse_media_line is not tested.
    """
    pass

# Generated at 2022-06-11 03:06:46.445014
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test the parsing of media line for ethernet interfaces:
    #   media: autoselect (none) status: inactive
    # and bridge interfaces:
    #   media: autoselect <unknown type>
    test_data_for_eth = [
        ['media:', 'autoselect', '(none)', 'status:', 'inactive'],
        ['media:', 'autoselect', '<unknown type>'],
        ['media:', 'autoselect', '<unknown type>', 'status:', 'inactive']
    ]
    current_if = dict(media='Unknown', media_select='')
    obj = DarwinNetwork('', '')
    for words in test_data_for_eth:
        obj.parse_media_line(words, current_if, '')

# Generated at 2022-06-11 03:06:55.657438
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.facts['interfaces'] = dict()

    # media line with only 2 words
    ifc.parse_media_line(['media:', '10baseT/UTP'], {}, '')
    assert ifc.facts['interfaces']['bridge0']['media_select'] == '10baseT/UTP'
    assert 'media_type' not in ifc.facts['interfaces']['bridge0']
    assert 'media_options' not in ifc.facts['interfaces']['bridge0']

    # media line with 3 words
    ifc.parse_media_line(['media:', '10baseT/UTP', '(<unknown type>)'], {}, '')

# Generated at 2022-06-11 03:07:05.789010
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    c = DarwinNetwork()

# Generated at 2022-06-11 03:07:10.818930
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect'}

# Generated at 2022-06-11 03:07:18.189956
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork_instance = DarwinNetwork({}, [])
    #Input for method: parse_media_line of class DarwinNetwork
    words = ['<unknown', 'type>']
    current_if = {'media': 'Unknown', 'macaddress': '00:1c:42:16:a4:f7'}
    ips = {'00:1c:42:16:a4:f7': {'ipv6': [], 'ipv4': []}}
    #Expected result:
    excepted_result = {'media': 'Unknown', 'macaddress': '00:1c:42:16:a4:f7', 'media_select': 'Unknown'}
    #Actual result:
    DarwinNetwork_instance.parse_media_line(words, current_if, ips)
    assert current_if == excepted

# Generated at 2022-06-11 03:07:23.349464
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    interface = {
        'name': 'en1'
    }
    words = ['media:', 'autoselect', '(none)']
    dn.parse_media_line(words, interface, None)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] is None
    assert interface['media_options'] is None

# Generated at 2022-06-11 03:07:29.980824
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'full-duplex']
    DarwinNetwork.parse_media_line(current_if, words, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'full-duplex'

# Generated at 2022-06-11 03:07:38.079056
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    # Test Valid
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {None: {}}
    result = network.parse_media_line(words, current_if, ips)
    assert 'media' in current_if.keys()
    assert 'media_select' in current_if.keys()
    assert 'media_type' in current_if.keys()
    assert not 'media_options' in current_if.keys()
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    # Test Valid

# Generated at 2022-06-11 03:07:47.882246
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    result = dwn.parse_media_line(['media:', 'autoselect', '(none)'],
                                  {},
                                  {})
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == '(none)'
    assert not result.get('media_options')

    result = dwn.parse_media_line(['media:', '10baseT/UTP', '<unknown', 'type>'],
                                  {},
                                  {})
    assert result['media_select'] == '10baseT/UTP'
    assert result['media_type'] == 'unknown type'
    assert not result.get('media_options')


# Generated at 2022-06-11 03:07:58.234890
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for the media line for a regular interface
    network_obj = DarwinNetwork()
    test_if = {}
    test_words = ["media:", "autoselect", "(", "100baseTX", "<full-duplex>,", "100baseTX", "<full-duplex>,", "100baseTX", "<full-duplex>,", "100baseTX", "<full-duplex>)", "status:", "active"]
    network_obj.parse_media_line(test_words, test_if, [])
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '100baseTX'
    assert test_if['media_options'] == 'full-duplex'

    # Test for the media line for a bridge interface
    test_if = {}
    test_

# Generated at 2022-06-11 03:08:10.808091
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import sys
    # Local import
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class testDarwinNetwork(unittest.TestCase):
        def test_parse_media_line(self):
            from ansible.module_utils.facts.network.darwin import DarwinNetwork
            # Test for line: media: autoselect (100baseTX <full-duplex>)
            # It should set values for media, media_select and media_options
            # and NOT for media_type
            dn = DarwinNetwork()
            current_if = {}
            ips = {}
            words = ['media:', 'autoselect', '(100baseTX', '<full-duplex>)']
            dn.parse_media_line

# Generated at 2022-06-11 03:08:20.644707
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a Debugger object for debugging.
    #
    # Do not use the same Debugger object for multiple threads
    # as a Debugger object is not thread safe.
    # Also do not use the print function as a debug function as
    # the print function can change in future Python versions.
    # Use the Debugger class to print debug messages.
    from module_utils.facts.network.base import Debugger
    debug = Debugger()

    test_darwin_if = {'ifname': 'test_if', 'media_select': 'unknown', 'media_type': 'unknown', 'media_options': None}

    debug.print('test_darwin_if = %s' % test_darwin_if)

    test_darwin_if_words = ['media:', '<unknown', 'type>']


# Generated at 2022-06-11 03:08:27.303239
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Fake platform to run DarwinNetwork unit tests
    dn = DarwinNetwork()
    dn.platform = dn.platform
    # Expected data to run the test

# Generated at 2022-06-11 03:08:33.887013
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # The line must starts with 'media:'
    result = dn.parse_media_line([], {}, [])
    assert not result

    # The media must be set to Unknown
    result = dn.parse_media_line(['media:', '<unknown>'], {}, [])
    assert 'media' in result
    assert result['media'] == 'Unknown'
    assert 'media_select' in result
    assert result['media_select'] == '<unknown>'

# Generated at 2022-06-11 03:08:40.146083
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', '<full-duplex>']
    current_if = {}
    ips = []

    darwin_if = DarwinNetwork()
    darwin_if.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ['full-duplex']

# Generated at 2022-06-11 03:08:47.086017
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # set up fixture
    dwn = DarwinNetwork(None,None,None)
    words = ['media:','<unknown','type>']
    current_if = {}
    ips = {}

    # execute test
    dwn.parse_media_line(words, current_if, ips)

    # assert media_select set correctly
    assert 'Unknown' == current_if['media_select']

    # assert media_type set correctly
    assert 'unknown type' == current_if['media_type']

    # assert media_options is not set
    assert current_if.get('media_options') is None

# Generated at 2022-06-11 03:08:56.762857
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    testwords = ['media:', 'autoselect', '<unknown', 'type>']
    current_if = dict()
    ips = dict()
    dn = DarwinNetwork()
    dn.parse_media_line(testwords, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == dict()
    testwords.pop()
    dn.parse_media_line(testwords, current_if, ips)
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'

# Generated at 2022-06-11 03:08:59.935574
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    module = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', '(autoselect)']
    current_if = {'name': 'lo0'}
    ips = []
    # call to the parse_media_line with the collected data
    module.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ['autoselect']

# Generated at 2022-06-11 03:09:08.008094
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """ Tests for media line parsing of DarwinNetwork class """
    # initialize the object of DarwinNetwork class
    darwin_object = DarwinNetwork()

    # initialize the darwin current interface dictionary
    darwin_current_interface = {}

    # initialize the darwin ips list
    darwin_ips = []

    # initialize parameter 'words'
    words = []

    # call parse_media_line with argument as follows
    # media 100baseTX <full-duplex>, mediaopt full-duplex
    # which is example of line from ifconfig command output
    # and verify that media_select and media_type are not None
    words = ['media', '100baseTX', '<full-duplex>,']

# Generated at 2022-06-11 03:09:13.693181
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    word = ['media:', '<unknown', 'type>', 'status:', 'active']
    obj = DarwinNetwork()
    current_if = {'name': 'lo0'}
    ips = {}
    obj.parse_media_line(word, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    #assert current_if['media_options'] == 'status: active'