

# Generated at 2022-06-11 03:04:19.523547
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    osx_network = DarwinNetwork()
    line = "media: autoselect (1000baseT <full-duplex>)"
    words = line.split()
    current_if = dict()
    ips = dict()
    osx_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'  # MacOSX does not give this
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'

    line = "media: <unknown type>"
    words = line.split()
    current_if = dict()
    ips = dict()

# Generated at 2022-06-11 03:04:28.115259
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test = DarwinNetwork()
    test.init({})
    test_if = {}
    test.parse_media_line(['media:', '<unknown type>'], test_if, None)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    test.parse_media_line(['media:', '<unknown', 'type>'], test_if, None)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:04:39.367118
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    current_if['media_options'] = {}
    ips = {}
    words = ['media:', 'autoselect']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == {}

    current_if = {}
    current_if['media_options'] = {}
    ips = {}
    words = ['media:', 'autoselect', '(1000baseT)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert current_if['media'] == 'Unknown'


# Generated at 2022-06-11 03:04:43.713963
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.parse_media_line(['media:', '<unknown', 'type>', '<none>'], {}, None)
    assert dn.current_if['media'] == 'Unknown'
    assert dn.current_if['media_type'] == 'unknown type'
    assert dn.current_if['media_select'] == 'Unknown'
    assert dn.current_if['media_options'] == ['<none>']

# Generated at 2022-06-11 03:04:50.051749
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test the DarwinNetwork method parse_media_line for both supported MacOSX
    media line formats with the following words parameter:

    Parse a media line with words[1] as 'Unknown' and words[2] as '<unknown type>'
    words = ['media:', 'Unknown', '<unknown', 'type>']

    Parse a media line with words[1] as '1000baseX' and words[2] as 'media'
    words = ['media:', '1000baseX', 'media', 'full-duplex,txpause,rxpause']
    """
    current_if = dict()
    ips = dict()
    test_mac_1 = ['media:', 'Unknown', '<unknown', 'type>']

# Generated at 2022-06-11 03:05:00.757197
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Get a fake "current_if" dict
    current_if = {}
    current_if['macaddress'] = '00:11:22:33:44:aa'
    current_if['type'] = 'ether'

    # Media line with 4 words
    words = ['media:', '<unknown', 'type>', '(0x1)']
    expected_result = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': '(0x1)'}
    darwin_network_collector = DarwinNetworkCollector()
    darwin_network_collector._fact_class.parse_media_line(words, current_if, None)
    assert expected_result == current_if

    # Media line with 3 words

# Generated at 2022-06-11 03:05:10.449147
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a DarwinNetwork object
    darwin_network = DarwinNetwork()
    # Create a list of words to parse
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)']
    # Create a dictionary to put the parsed lines
    current_if = {}
    # Parse the words list
    darwin_network.parse_media_line(words, current_if)
    # Check the result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == {'full-duplex': ''}
    # Create a new current_if dictionary
    current_if = {}
    # Create a new words list

# Generated at 2022-06-11 03:05:19.765945
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # no media info provided
    test_dict = {}
    dn = DarwinNetwork()
    dn.parse_media_line(None, test_dict, None)
    assert test_dict['media'] == 'Unknown'
    assert 'media_select' not in test_dict
    assert 'media_type' not in test_dict
    assert 'media_options' not in test_dict

    # media info provided
    test_dict = {}
    words = ['media:', 'MII', '(100baseTX)']
    dn.parse_media_line(words, test_dict, None)
    assert test_dict['media'] == 'Unknown'
    assert test_dict['media_select'] == 'MII'
    assert test_dict['media_type'] == '100baseTX'
    assert 'media_options' not in test

# Generated at 2022-06-11 03:05:29.833676
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_dict = {}
    mac_dict['media'] = 'Unknown'
    mac_dict['media_select'] = '100baseTX'
    mac_dict['media_type'] = 'full-duplex'
    mac_dict['media_options'] = 'media:autoselect'
    mac_dict['media_select_raw'] = '100baseTX'
    mac_dict['media_options_raw'] = 'media:autoselect'
    mac_net = DarwinNetwork()
    mac_net.parse_media_line(['media:', '100baseTX', 'full-duplex', 'media:autoselect'], mac_dict, ['192.168.0.1', '192.168.0.2'])
    assert mac_dict == mac_dict

# Generated at 2022-06-11 03:05:40.361778
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize
    w = ["media:", "autoselect", "<unknown", "type>", "none"]  # Tuple to be tested
    w2 = ["foo:", "bar", "baz", "none"]  # Tuple to be tested
    current_if = dict()  # dict to be filled
    current_if['media'] = 'baz'  # This field shall not be changed
    ips = 'ips'  # Setting this parameter value is not needed

    d = DarwinNetwork()
    d.parse_media_line(w, current_if, ips)
    d.parse_media_line(w2, current_if, ips)

    assert current_if['media'] == 'baz'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:05:52.565473
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test case 1: ifconfig output on Darwin with 1 interface
    words = []

# Generated at 2022-06-11 03:06:01.762307
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mediainfo = ['Supported', 'media:', '<unknown type>']
    media_select = 'Supported'
    media_type = 'unknown type'
    eth_info = {}
    eth_info1 = {}
    ip_info = {}
    a, b, c = DarwinNetwork().parse_media_line(mediainfo, eth_info, ip_info)
    d, e, f = DarwinNetwork().parse_media_line(mediainfo, eth_info1, ip_info)
    assert ('Unknown' == a)
    assert ('Unknown' == d) and ('unknown type' == e)
    assert (media_select == c) and (media_type == f)

# Generated at 2022-06-11 03:06:12.044583
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {'name': 'eth0'}
    ips = []

# Generated at 2022-06-11 03:06:21.735720
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    line = ['en0:',
            'status:',
            'active',
            'en1:',
            'status:',
            'active',
            'media:',
            '<unknown type>',
            '(none)',
            'active']
    
    current_if = {'full_name': 'en1', 'name':'en1', 
                  'macaddress': '', 'ipv4': [], 'ipv6': [],
                  'module': '', 'mtu': 0, 'type': ''}

    DarwinNetwork._parse_media_line(line,  current_if, [])
    
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'
    assert current

# Generated at 2022-06-11 03:06:31.928775
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork()
    test_obj.current_if = {'interface': 'en1'}
    test_obj.ips = {}

    # test default case
    test_obj.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], test_obj.current_if, test_obj.ips)
    assert test_obj.current_if['media'] == 'Unknown'
    assert test_obj.current_if['media_select'] == 'autoselect'
    assert test_obj.current_if['media_type'] == 'status:'
    assert test_obj.current_if['media_options'] == 'inactive'

    # test case with media: <unknown type>

# Generated at 2022-06-11 03:06:42.776741
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test1_words = ['media:', '<unknown', 'type>', '<unknown>', 'status:', 'active']
    test1_if = {}
    test1_if['name'] = 'lo0'
    test1_if['up'] = True
    test1_if['macaddr'] = '00:00:00:00:00:00'
    test1_if['mtu'] = 16384
    test1_if['promisc'] = False
    test1_if['active'] = True
    test1_if['bridge'] = False
    test1_if['wireless'] = False
    test1_if['virtual'] = True
    test1_if['type'] = 'Loopback'
    test1_if['state'] = 'unknown'
    test1_if['ipv4'] = []
   

# Generated at 2022-06-11 03:06:48.115716
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork()
    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    ips = dict()
    darwin.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == "Unknown"
    assert current_if['media_type'] == "unknown type"
    assert current_if['media_options'] == None

# Generated at 2022-06-11 03:06:53.565169
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwinNetwork = DarwinNetwork()
    media = ['media:','<unknown','type>','status:','inactive']
    current_if = {}
    ips = {}
    darwinNetwork.parse_media_line(media, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:07:03.709965
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict(media='Unknown')

    # media line is different to the default FreeBSD one
    # 'media: <unknown type> <unknown subtype>'
    _words = ['media:', '<unknown', 'type>', '<unknown', 'subtype>']
    DarwinNetwork.parse_media_line(_words, current_if, '')

    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type <unknown'
    assert current_if['media_options'] == 'subtype>'
    assert current_if['media'] == 'Unknown'

    # 'media: autoselect (none)'
    _words = ['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media_line(_words, current_if, '')

# Generated at 2022-06-11 03:07:13.129062
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    dn.parse_media_line(words, current_if, ips=[])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == []
    current_if = {}
    words = ['media:', '1000baseT', 'status:', 'active']
    dn.parse_media_line(words, current_if, ips=[])
    assert current_if['media_select'] == '1000baseT'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == []

# Generated at 2022-06-11 03:07:27.172327
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()


# Generated at 2022-06-11 03:07:34.447936
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    ips = {}

# Generated at 2022-06-11 03:07:44.925681
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    dn = DarwinNetwork()

    # Test media line similar to FreeBSD format
    words = ['media:', 'autoselect', '100baseTX', '<full-duplex,flow-control>']

    dn.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == 'full-duplex,flow-control'

    # Test media line similar to FreeBSD format
    words = ['media:', '<unknown type>', '(none)']

    dn.parse_media_line(words, current_if, ips)

   

# Generated at 2022-06-11 03:07:54.437034
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifname = 'en0'
    current_if = {'if': ifname}
    media_select = 'autoselect'
    media_type = '10baseT/UTP'
    media_options = '(none)'
    words = ['media', media_select, media_type, media_options]
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, None)
    assert current_if == {'if': 'en0',
                          'media': 'Unknown',
                          'media_options': [],
                          'media_select': 'autoselect',
                          'media_type': '10baseT/UTP'}
    current_if = {'if': ifname}
    words = ['media', media_select, media_type]
    dn = Darwin

# Generated at 2022-06-11 03:08:02.028463
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = {'capabilities': {}}
    words = ['media:', 'autoselect', '(unknown)', '']
    ips = {'ipv4': [], 'ipv6': []}
    darwin_network.parse_media_line(words, current_if, ips)
    expected_current_if = dict(media='Unknown', media_select='autoselect', media_type='unknown', media_options=dict())
    assert current_if == expected_current_if
    words = ['media:', 'autoselect', '1000baseTX', '(full-duplex,flow-control,txpause)']
    darwin_network.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:08:12.397486
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    words = ['foo', 'auto', '1000baseT', '<full-duplex>']
    current_if={}
    ips={}

    obj.parse_media_line(words, current_if, ips)

    assert 'auto' == current_if['media_select']
    assert '1000baseT' == current_if['media_type']
    assert 'full-duplex' == current_if['media_options']
    assert len(current_if) == 4

    # test with 'Unknown' input
    words = ['foo', '<unknown', 'type>']
    obj.parse_media_line(words, current_if, ips)

    assert 'Unknown' == current_if['media_select']
    assert 'unknown type' == current_if['media_type']

# Generated at 2022-06-11 03:08:22.678751
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork()
    iface = dict()
    ips = dict()
    words = ['media', 'autoselect', '10baseT/UTP', 'status', 'active']
    iface = darwin.parse_media_line(words, iface, ips)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '10baseT/UTP'
    assert iface['media_options'] == {'status': 'active'}

    iface = dict()
    words = ['media', '<unknown', 'type>', 'status', 'active']
    iface = darwin.parse_media_line(words, iface, ips)

# Generated at 2022-06-11 03:08:32.662519
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if = DarwinNetwork()
    # words media_select media_type media_options
    if_dict = darwin_if.parse_media_line(['media:', 'auto', '100baseTX', '(100baseTX)'], {}, {'inet': []})
    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == 'auto'
    assert if_dict['media_type'] == '100baseTX'
    assert if_dict['media_options'] == '(100baseTX)'
    # words media_select
    if_dict = darwin_if.parse_media_line(['media:', 'half-duplex'], {}, {})
    assert if_dict['media'] == 'Unknown'

# Generated at 2022-06-11 03:08:37.463806
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test parsing of ifconfig output on Mac."""
    words = ['<unknown type>']
    current_if = {}
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'type>'
    assert current_if['media_options'] == {}

# Generated at 2022-06-11 03:08:46.450696
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test Variables
    output = None
    current_if = {}
    ips = {}

    # Test Cases
    # Simple test case
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>)']
    DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT <full-duplex>'
    assert current_if['media_options'] == ''

    # Test unexpected length of list
    words = ['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']

# Generated at 2022-06-11 03:08:59.603317
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Method parse_media_line of class DarwinNetwork
    """
    # First test case, with 2 words
    words = ['media:', 'autoselect']
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert ('media_select' in current_if
            and 'media_type' not in current_if
            and 'media_options' not in current_if
            and current_if['media_select'] == 'autoselect'
            )
    # Second test case
    words.append('<unknown>')
    DarwinNetwork().parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:09:04.260130
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    dn = DarwinNetwork()

    # parse_media_line returns nothing
    if dn.parse_media_line(['media:', 'autoselect', '<unknown type>'],
                           {}, {}) != None:
        assert False
    if dn.parse_media_line(['media:', 'autoselect', '<unknown type>'],
                           {'media': 'Autoselect'}, {}) != None:
        assert False

# Generated at 2022-06-11 03:09:12.388420
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from facts.facts import Facts
    import json

    test_if = {'media_select': 'autoselect', 'media_options': None, 'media_type': 'None', 'media': 'Unknown', 'state': 'unknown', 'type': 'Broadcast'}
    collector = DarwinNetworkCollector(Facts())
    collector.platform = 'Darwin'
    collector.python_version = 2

    # test with different media line structures
    # correct media line
    words_1 = ['media:', 'autoselect', '(none)']
    collector.parse_media_line(words_1, test_if, [])

# Generated at 2022-06-11 03:09:16.612706
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_obj = DarwinNetwork()

# Generated at 2022-06-11 03:09:23.738492
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    dn = DarwinNetwork()
    # media line 'media: autoselect (1000baseT <full-duplex>)'
    txt = "media: autoselect (1000baseT <full-duplex>)"
    current_if = {}
    ips = {}
    dn.parse_media_line(txt.split(), current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'
    # line 'media: <unknown type> (none)'
    txt = "media: <unknown type> (none)"

# Generated at 2022-06-11 03:09:29.572857
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = []
    ips = None
    ifc = DarwinNetwork()
    ifc.parse_media_line(words, current_if, ips)
    assert "Unknown" == current_if['media']
    assert "Unknown" == current_if['media_select']
    assert "unknown type" == current_if['media_type']
    assert "0" == current_if['media_options']



# Generated at 2022-06-11 03:09:38.680004
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net_obj = DarwinNetwork()

# Generated at 2022-06-11 03:09:46.190892
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork(None)
    current_if = {}
    words = ['media', '<unknown', 'type>']
    
    darwin_network.parse_media_line(words, current_if, None)
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'Unknown'
    # the parse_media_line method stores the 
    # media type in media_options instead of the expected media_type
    assert 'media_options' in current_if
    assert current_if['media_options'] == 'unknown type'

# Generated at 2022-06-11 03:09:50.681121
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    f = DarwinNetwork()
    line = "'media: <unknown type> status: no carrier'"
    words = line.split()
    print(words)
    f.parse_media_line(words, f.current_if, f.current_ip)
    print(f.current_if)
    assert "Unknown" in f.current_if['media_select']

# Generated at 2022-06-11 03:09:57.247381
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # 1 media_select, no media_type, no media_options
    test_data = '  media: autoselect (1000baseT <full-duplex>)'
    words = test_data.split()
    current_if = {}
    ips = []
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # 1 media_select, 1 media_type, no media_options
    test_data = '  media: autoselect (1000baseT)'
    words = test_data.split()
    current_if = {}
    ips