

# Generated at 2022-06-11 03:04:25.932440
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create an instance of DarwinNetwork
    darwin_network = DarwinNetwork('en0', 'en0', {})

    # create test data for method parse_media_line
    test_data = {
        'media': 'Uknown',
        'media_select': 'autoselect',
        'media_type': '(none)',
        'media_options': 'none',
    }
    # run method parse_media_line with test data
    darwin_network.parse_media_line(('media:', 'autoselect', '(none)', 'none'),
                                    {}, {})

    # check result
    assert darwin_network.current_if == test_data

# Generated at 2022-06-11 03:04:33.648851
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    iface = dict()
    iface['media'] = '1000baseT <full-duplex,flow-control>'
    d.parse_media_line(['media:','1000baseT','<full-duplex,flow-control>'],iface,'not used')
    assert(iface['media'] == 'Unknown')
    assert(iface['media_select'] == '1000baseT')
    assert(iface['media_type'] == 'full-duplex,flow-control')
    iface['media'] = '<unknown type>'
    d.parse_m

# Generated at 2022-06-11 03:04:44.150952
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialise object
    obj = DarwinNetwork()

    # Valid test cases

# Generated at 2022-06-11 03:04:54.483841
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_string_1 = "media: <unknown type>"
    test_string_2 = "media: <unknown type> <unknown subtype>"
    test_string_3 = "media: <unknown type> <unknown subtype> <unknown option>"
    test_string_4 = "media: 1000baseX <full-duplex>"

    expected_result_1 = {'media': 'Unknown',
                         'media_select': 'Unknown',
                         'media_type': 'unknown type'}
    expected_result_2 = {'media': 'Unknown',
                         'media_select': 'Unknown',
                         'media_type': 'unknown subtype'}

# Generated at 2022-06-11 03:05:02.611397
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize
    words = "media: <unknown type>".split()

    # Set class attributes
    current_if = {}  # will hold the output of the parsing
    ips = []

    # Run test
    fact_class = DarwinNetwork()
    fact_class.parse_media_line(words, current_if, ips)

    # Assert output
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-11 03:05:10.894564
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net_collector = DarwinNetwork()
    media_line = ['media:', '<unknown type>', '(autoselect)']
    net_collector.parse_media_line(media_line, {}, {})
    assert net_collector.data[0]['media'] == 'Unknown'
    assert net_collector.data[0]['media_select'] == 'Unknown'
    assert net_collector.data[0]['media_type'] == 'unknown type'
    assert 'media_options' not in net_collector.data[0]
    media_line = ['media:', '<unknown type>']
    net_collector.parse_media_line(media_line, {}, {})
    assert net_collector.data[1]['media'] == 'Unknown'

# Generated at 2022-06-11 03:05:18.693802
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_object = DarwinNetwork()
    darwin_network_object.parse_media_line(['status','active','1000baseT','none','none','none'], {}, [])
    darwin_network_object.parse_media_line(['status','active','1000baseT','none','none','none'], {}, [])
    darwin_network_object.parse_media_line(['status','active','<unknown','type>','none','none'], {}, [])
    darwin_network_object.parse_media_line(['status','active','none','none','none'], {}, [])

# Generated at 2022-06-11 03:05:28.996044
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = {}
    tests = [
        [['media:', '<unknown', 'type>', '(autoselect)'], current_if, []],
        [['media:', 'autoselect', '(1000baseT)'], current_if, []],
        [['media:', '10baseT/UTP', '(10baseT/UTP)'], current_if, []],
    ]
    for test in tests:
        darwin_net.parse_media_line(test[0], test[1], test[2])
        assert current_if['media'] == 'Unknown'
        assert current_if['media_select'] == test[0][1]
        assert current_if['media_type'] == test[0][2]

# Generated at 2022-06-11 03:05:36.011734
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup, before running any unit tests
    word_list = ['10baseT/UTP', '<unknown', 'type>']
    current_if = dict()
    ips = dict()

    # Run the unit test
    # Expect function to return the current_if dictionary correctly filled-out
    DarwinNetwork._parse_media_line(word_list, current_if, ips)

    # Verify results
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '10baseT/UTP'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:05:43.922770
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    current_if = {}
    ips = {}
    words = ['media:', 'autoselect', 'status:', 'active']

    # Act
    DarwinNetwork.parse_media_line(words, current_if, ips)

    # Assert
    assert current_if.get('media') == 'Unknown'
    assert current_if.get('media_select') == 'autoselect'
    assert current_if.get('media_type') == 'status'
    assert current_if.get('media_options') == {'active': None}

# Generated at 2022-06-11 03:05:53.725959
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    domain = dict() # domain is the dictionary in which we store the test function output
    current_if = dict()
    words_1 = ['media:', '<unknown type>']
    words_2 = ['media:', '<unknown', 'type>']
    words_3 = ['media:', 'autoselect', '(none)']
    ips = dict()
    # Testing for case where device is bridge
    DarwinNetwork().parse_media_line(words_1, current_if, ips)
    domain['media'] = 'Unknown'
    domain['media_select'] = 'Unknown'
    domain['media_type'] = 'unknown type'
    assert domain == current_if
    # Testing for case where device is not a bridge
    current_if = dict()

# Generated at 2022-06-11 03:06:04.739355
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    parser = DarwinNetwork()

    # test with line = <unknown type>
    words = ['<unknown', 'type>']

    current_if = {}
    ips = {}
    parser.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # test with line = autoselect (1000baseT, full-duplex)
    words = ['autoselect', '(1000baseT,', 'full-duplex)']

    current_if = {}
    ips = {}
    parser.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:06:14.111943
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork = DarwinNetworkCollector.get_network_collector()
    # ['-media', 'autoselect', 'Burst', '10baseT/UTP', '(none)', 'mediaopt', 'mediaopt2']
    current_if = {}
    DarwinNetwork.parse_media_line(["-media", "autoselect", "10baseT/UTP", "(none)", "mediaopt", "mediaopt2"], current_if, {})
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == "autoselect")
    assert(current_if['media_type'] == "10baseT/UTP")
    assert(current_if['media_options'] == "mediaopt,mediaopt2")

    # ['undef', '<unknown type>', 'full-duplex,

# Generated at 2022-06-11 03:06:26.052196
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    media_line = ['media:', '<unknown type>', '<unknown subtype>']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(media_line, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'},\
        "DarwinNetwork parse_media_line failed"
    media_line = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(media_line, current_if, ips)

# Generated at 2022-06-11 03:06:28.767293
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': 'Unknown'}
    media_line = ['media: <unknown type>']
    DarwinNetwork.parse_media_line(DarwinNetwork, media_line, current_if, {})
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:37.560408
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig_data = (
        "lladdr e8:03:9a:5a:2f:75\n"
        "media: autoselect\n"
        "status: active\n"
        "supported media: autoselect\n"
        "inactive"
    )
    ifc_net = DarwinNetwork()
    current_if = {}
    ips = {}
    lines = ifconfig_data.split('\n')
    for line in lines:
        words = line.split()
        ifc_net.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:06:45.806567
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # prepare data
    test_if = {}
    test_ips = {}
    test_words = ['media:', '<unknown', 'type>', '(autoselect)']

    # run code
    macOS_network = DarwinNetwork()
    macOS_network.parse_media_line(test_words, test_if, test_ips)

    # check result
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == 'autoselect'

# Generated at 2022-06-11 03:06:54.969454
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 1
    m = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    current_if = {"media": '', "media_select": '', "media_type": '', "media_options": ''}
    m.parse_media_line(words, current_if, [])
    assert current_if["media"] == 'Unknown'
    assert current_if["media_select"] == 'autoselect'
    assert current_if["media_type"] == '(none)'
    assert current_if["media_options"] == ''

    # Test 2
    m = DarwinNetwork()
    words = ['media:', '<unknown', 'type>']
    current_if = {"media": '', "media_select": '', "media_type": '', "media_options": ''}
    m

# Generated at 2022-06-11 03:07:05.147709
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_type = 'Example'
    darwin_if = {'media_type': media_type, 'media_select': media_type, 'media_options': media_type}
    darwin_if_parse = {'media': 'Unknown', 'media_type': media_type, 'media_select': media_type, 'media_options': media_type}
    darwin_network = DarwinNetwork()
    # assert that get_options() returns exactly what it is given
    assert darwin_if == darwin_network.parse_media_line(['media:', media_type, media_type, media_type], darwin_if, [])

# Generated at 2022-06-11 03:07:14.586989
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # make a dummy ifconfig with this media line in it
    ifconfig = [
        'awdl0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1484',
        '    ether 9c:1c:12:38:c4:4a',
        '    inet6 fe80::9e1c:12ff:fe38:c44a%awdl0 prefixlen 64 scopeid 0x8',
        '    nd6 options=1<PERFORMNUD>',
        '    media: autoselect',
        '    status: active'
    ]

    # make a DarwinNetwork class
    dwn = DarwinNetwork()

    # set up the output
    current_if = {}
    ips = []

    # send the output through the Darwin method
   

# Generated at 2022-06-11 03:07:30.301414
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_words = ['media:', 'IEEE', '802.11', 'autoselect', 'status:', 'inactive']
    test_current_if = dict()

    test_object = DarwinNetwork('en0', 'en0', 'en0', dict())
    test_object.parse_media_line(test_words, test_current_if)

    assert test_current_if['media_select'] == 'IEEE'
    assert test_current_if['media_type'] == '802.11'
    assert test_current_if['media_options']['autoselect'] == True


# Test cases for class DarwinNetwork and subclasses

# Generated at 2022-06-11 03:07:38.373619
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()

    words = ['autoselect', 'status:', 'none', 'active']
    current_if = dict()
    ips = dict()
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'
    assert current_if['media_options'] == dict(active='active', none='none')

    words = ['<unknown', 'type>', 'status:', 'active']
    current_if = dict()
    ips = dict()
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
   

# Generated at 2022-06-11 03:07:46.677699
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    facts = {}
    darwin_network = DarwinNetwork(facts, None)  # facts comes from parent class and is not used here
    current_if = {}

    # MacOSX sets the media to '<unknown type>' for bridge interface and parsing splits this into two words
    # this if/else helps
    words = ['', '<unknown', 'type>']
    expected_result = {'media_select': 'Unknown', 'media_type': 'unknown type', 'media': 'Unknown'}
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if == expected_result



# Generated at 2022-06-11 03:07:56.784336
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create instance
    mac_network = DarwinNetwork()
    # Create an iface
    current_if = {}
    # Create a list of words for the media line
    words = ['media:', 'autoselect', '(100baseTX', 'full-duplex)', 'status:', 'active']

    # Run parse_media line
    mac_network.parse_media_line(words, current_if, None)

    # Check the output
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options']['full-duplex'] == True

    # Check the output if media is <unknown type>
    current_if = {}

# Generated at 2022-06-11 03:08:02.994322
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_interface = {}
    test_interface['ipv4'] = {}
    test_interface['ipv6'] = {}
    test_interface['ipv4']['address'] = ''
    test_interface['ipv4']['broadcast'] = ''
    test_interface['ipv4']['netmask'] = ''
    test_interface['ipv4']['network'] = ''
    test_interface['ipv6']['address'] = ''
    test_interface['ipv6']['prefix'] = ''
    test_interface['media'] = ''
    test_interface['media_select'] = ''
    test_interface['media_type'] = ''
    test_interface['media_options'] = {}

    fclass = DarwinNetwork()

# Generated at 2022-06-11 03:08:13.008119
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    words = 'media autoselect'.split()
    current_if = dict()
    ips = dict()
    obj.parse_media_line(words, current_if, ips)
    expected = {'current_if':{'media':'Unknown', 'media_select':'autoselect'}}
    assert current_if == expected['current_if']
    words = 'media autoselect (1000baseT <full-duplex>) status: inactive'.split()
    current_if = dict()
    ips = dict()
    obj.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:08:23.229533
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc_dict = {}
    ifc.parse_media_line(['media:', 'autoselect', '(none)'], ifc_dict, [])
    assert(ifc_dict['media_select'] == 'autoselect')
    assert(ifc_dict['media_type'] == '(none)')
    ifc_dict = {}
    ifc.parse_media_line(['media:', 'autoselect', '(none)'], ifc_dict, [])
    assert(ifc_dict['media_select'] == 'autoselect')
    assert(ifc_dict['media_type'] == '(none)')
    ifc_dict = {}
    ifc.parse_media_line(['media:', '<unknown', 'type>'], ifc_dict, [])


# Generated at 2022-06-11 03:08:26.889615
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    iface = {}
    dn.parse_media_line(['media:', 'HWaddr:', 'b8:27:eb:1a:0e:cb'], iface, [])
    assert iface['macaddress'] == 'b8:27:eb:1a:0e:cb'

# Generated at 2022-06-11 03:08:35.504634
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import collections

    mac_eth0_media_line_1 = '  media: autoselect (<unknown type>)'
    mac_eth0_media_line_2 = '  media: autoselect (1000baseT <full-duplex,flow-control>)'
    mac_eth0_media_line_3 = '  media: autoselect (1000baseT <full-duplex>)'
    mac_eth0_media_line_4 = '  media: autoselect (1000baseT <full-duplex,flow-control,hw-loopback>)'
    mac_eth0_media_line_5 = '  media: autoselect (1000baseT <flow-control>)'

    mac_eth1_media_line_1 = '  media: autoselect <unknown type>'
    mac_eth1_media_line

# Generated at 2022-06-11 03:08:43.558811
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a new object
    d = DarwinNetwork()
    current_if = {}
    ips = []

    # example of a media line from ifconfig that should be parsed correctly
    media_line = ['media:', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']
    d.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT <full-duplex>'
    assert current_if['media_options'] == {}