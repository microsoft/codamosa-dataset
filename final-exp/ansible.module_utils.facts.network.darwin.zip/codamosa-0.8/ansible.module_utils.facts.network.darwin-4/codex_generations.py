

# Generated at 2022-06-11 03:04:17.308235
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'media': 'Unknown',
               'media_select': 'autoselect',
               'media_type': '',
               'media_options': ''
    }
    dn = DarwinNetwork()
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, test_if, None)
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:04:27.048411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    testing method DarwinNetwork.parse_media_line
    """
    base_path = 'ansible.module_utils.facts.network.darwin.'

# Generated at 2022-06-11 03:04:31.903076
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_obj = DarwinNetwork()
    current_if = {}
    network_obj.parse_media_line(['media:', 'status:', 'active'], current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'status:'
    assert current_if['media_type'] == 'active'

# Generated at 2022-06-11 03:04:36.706117
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {}
    words = ['media', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, interface, {})
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:04:45.992925
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()
    test_object._platform = "Darwin"
    test_object._fact_class = DarwinNetwork

    # test case 1: media line is different to the default FreeBSD one
    media_line = "media: <unknown type>"
    iface = {"name": "en0"}
    test_object.parse_media_line(media_line.split(), iface, None)
    assert ('media' in iface)
    assert ('media_select' in iface)
    assert ('media_type' in iface)
    assert ('media_options' in iface)
    assert (iface['media'] == 'Unknown')
    assert (iface['media_select'] == '<unknown')
    assert (iface['media_type'] == 'type>')

# Generated at 2022-06-11 03:04:50.009940
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    ifconfig = d._get_ifconfig()
    #ifconfig is empty, test parse_media_line() with dummy data
    d.parse_media_line(['autoselect', 'none', 'none'], {'inet': '127.0.0.1'}, {})

# Generated at 2022-06-11 03:05:00.703483
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Check that parsing of media line ('media: autoselect (1000baseT <full-duplex>)' for example)
    # works correctly
    current_if = dict()
    ips = dict()
    dn = DarwinNetwork()
    dn.parse_media_line(['media:', 'autoselect', '(1000baseT', '<full-duplex>)'], current_if, ips)
    assert current_if == dict(media='Unknown', media_select='autoselect', media_type='1000baseT', media_options='full-duplex')

    # Check that media line is parsed correctly when there is space in the option
    current_if = dict()
    ips = dict()
    dn

# Generated at 2022-06-11 03:05:10.450395
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # first test case
    media_line = "media: autoselect <unknown type>"
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(media_line.split(), current_if, ips)
    assert current_if['media'] == "Unknown"
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "unknown type"
    assert current_if['media_options'] == ""
    # second test case
    media_line = "media: autoselect <unknown type> mediaopt: none"
    darwin_network.parse_media_line(media_line.split(), current_if, ips)
    assert current_if['media'] == "Unknown"


# Generated at 2022-06-11 03:05:18.940368
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_nw_collector = DarwinNetwork(None)
    current_if = {}

    words = ['media:', '<unknown', 'type>']
    darwin_nw_collector.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    words = ['media:', 'autoselect', '(none)']
    darwin_nw_collector.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'

# Generated at 2022-06-11 03:05:29.282858
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test the parse_media_line method of DarwinNetwork
    """