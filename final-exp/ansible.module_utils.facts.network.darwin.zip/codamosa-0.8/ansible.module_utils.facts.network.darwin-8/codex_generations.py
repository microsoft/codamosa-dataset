

# Generated at 2022-06-11 03:04:19.648575
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(
        words=['media:', 'autoselect', 'status:', 'inactive'],
        current_if={},
        ips=[]
    ) == {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'status:',
        'media_options': 'inactive',
    }

# Generated at 2022-06-11 03:04:29.383589
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Object of class DarwinNetwork
    darwin_network = DarwinNetwork()
    # Object of class ifconfig_interface
    ifconfig_interface={}
    # Object of class ifconfig_result
    ifconfig_result={}

    ifconfig_result['interfaces']={}

    # Testcase 1:
    # Media line words
    media_line_words=['status:', 'active', 'type:', 'AirPort', 'type:', 'hardware', 'type:', 'Ethernet']
    # Expected output of parse_media_line
    expected_output = {
        'media': 'Unknown',
        'media_select': 'active',
        'media_type': 'hardware',
        'media_options': 'Ethernet'
    }
    
    # Check if parse_media_line is executed correctly
   

# Generated at 2022-06-11 03:04:40.316557
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifs = dict()
    ifs['current_if'] = dict()
    ips = dict()
    facts = dict()

    ifs['current_if']['media'] = 'Unknown'
    ifs['current_if']['media_select'] = 'media_select'
    ifs['current_if']['media_type'] = 'media_type'
    ifs['current_if']['media_options'] = {'option1': 'a'}
    words = ['media_line', 'media_select', 'media_type', "'option1':'a'"]
    dn = DarwinNetwork(facts, ifs, ips)
    dn.parse_media_line(words, ifs, ips)

    assert ifs['current_if']['media'] == "Unknown"

# Generated at 2022-06-11 03:04:43.771910
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    ifs = {'flags': 'none', 'active': True}
    words = list(['media:', '<unknown', 'type>'])

    d.parse_media_line(words, ifs, list())
    assert ifs['media'] == 'Unknown'
    assert ifs['media_select'] == 'Unknown'
    assert ifs['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:04:53.065639
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    # this is the media line of an interface on a Mac with 10.15.3; parse_media_line should fill in current_if from it
    words  = ['media:', '<unknown', 'type>', 'status:', 'active']

    # instantiate the class
    dn = DarwinNetwork()
    # call the method
    dn.parse_media_line(words, current_if, ips)

    # inspect the result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

# Generated at 2022-06-11 03:05:03.559835
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    # media line with all info
    line = 'media: autoselect (<unknown type> full-duplex)'
    words = line.split(' ')
    current_if = {}
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'Unknown'
    assert current_if['media_options'] == 'full-duplex'
    # media line without media type and options
    line = 'media: autoselect'
    words = line.split(' ')
    current_if = {}
    ips = []
    network.parse_media_line(words, current_if, ips)
    assert current_if['media_select']

# Generated at 2022-06-11 03:05:11.509834
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Init
    current_if = {}
    ips = []
    media_lines = [
        'media: Ethernet autoselect',
        'media: <unknown type>',
        'media: autoselect (none) status: inactive'
    ]
    # Call
    for line in media_lines:
        words = line.split()
        DarwinNetwork.parse_media_line(None, words, current_if, ips)
    # Asserts
    assert current_if['media'] == 'Unknown' and \
           current_if['media_select'] == 'autoselect' and \
           current_if['media_options'] == [] and \
           current_if['media_type'] == 'Ethernet'

# Generated at 2022-06-11 03:05:20.427044
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_cases = [
        {   'input': {'words': ['media:', '<unknown', 'type>', 'status:', 'active'],
                     'current_if': {},
                     'ips': {}},
            'expected': {'current_if': {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type',
                                        'media_options': []},
                         'ips': {}}
        }
    ]

    for case in test_cases:
        dnet = DarwinNetwork()
        dnet.parse_media_line(case['input']['words'], case['input']['current_if'],
                              case['input']['ips'])

# Generated at 2022-06-11 03:05:26.847614
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_interface_media_string = 'media: <unknown type> status: inactive'

    test_object = DarwinNetwork()
    test_object.parse_media_line(mac_interface_media_string.split(), {}, [])

    if not (test_object.current_if['media'] == 'Unknown' and
            'status' in test_object.current_if['media_options']):
        raise Exception('Media line not parsed correctly')

# Generated at 2022-06-11 03:05:33.812686
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # First test case - 'media: autoselect (1000baseT <full-duplex>)'
    # Split the line into words and pass them to parse media line
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)']
    current_if = {}
    darwin_network.parse_media_line(words, current_if, [])
    assert current_if == {'media': 'Unknown',
                          'media_select': 'autoselect',
                          'media_type': '1000baseT',
                          'media_options': ['full-duplex']}

    # Second test case - 'media: autoselect <unknown type>'
    # Split the line into words and pass them to parse media line

# Generated at 2022-06-11 03:05:49.111688
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test data - taken from running ifconfig on Mac OSX
    testdata = [
        "media: autoselect (1000baseT <full-duplex,flow-control>) status: active",
        "media: autoselect (<unknown type>,none) status: active",
        "media: autoselect (100baseTX <full-duplex>) status: active"
        ]

    # Expected results

# Generated at 2022-06-11 03:05:59.736350
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_network = DarwinNetwork()
    current_if = {"media" : "Unknown", "media_select" : "", "media_type" : "", "media_options" : {}}
    mac_network.parse_media_line(["media:", "autoselect", "status:", "active"], current_if, {})
    assert current_if["media_select"] == "autoselect"
    assert current_if["media_type"] == ""
    assert current_if["media_options"] == {}
    mac_network.parse_media_line(["media:", "autoselect", "(1000baseT)", "status:", "active"], current_if, {})
    assert current_if["media_select"] == "autoselect"
    assert current_if["media_type"] == "(1000baseT)"
    assert current

# Generated at 2022-06-11 03:06:10.463055
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darNetwork = DarwinNetwork()
    darNetwork.parse_media_line(['media:', 'autoselect', '100baseTX', '(100baseTX)'], {}, {'media': 'media', 'media_select': 'media_select', 'media_type': 'media_type', 'media_options': 'media_options'})
    assert darNetwork.current_if['media_select'] == 'autoselect'
    assert darNetwork.current_if['media_type'] == '100baseTX'
    assert darNetwork.current_if['media_options'] == {'(100baseTX)': None}

# Generated at 2022-06-11 03:06:17.410831
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import tempfile
    import shutil
    import os
    # pylint: disable=missing-docstring
    def _create_tmp_dir_and_file(content):
        tmp_dir = tempfile.mkdtemp()
        tmp_file = open(os.path.join(tmp_dir, 'ifconfig.out'), 'w+')
        tmp_file.write(content)
        tmp_file.seek(0)
        return os.path.join(tmp_dir, 'ifconfig.out')


# Generated at 2022-06-11 03:06:29.286355
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    current_if = {}
    words = ['Media:', '<unknown', 'type>', 'status:', 'active']
    ifc.parse_media_line(words, current_if, {})
    assert 'media' in current_if
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert not 'media_options' in current_if
    words.insert(2, 'autoselect')
    words.insert(4, 'supported:')
    words.insert(6, 'none')
    ifc.parse_media_line(words, current_if, {})
    assert current_if['media_select'] == '<unknown'
    assert current

# Generated at 2022-06-11 03:06:38.185653
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    collector = DarwinNetwork()
    fake_iface = { 'media':'Unknown', 'media_select':'autoselect', 'media_type':'bond', 'media_options':'none' }
    words = ['media:','autoselect','(bond)','none']
    assert collector.parse_media_line(words,fake_iface,{}) == None
    assert fake_iface['media'] == 'Unknown'
    assert fake_iface['media_select'] == 'autoselect'
    assert fake_iface['media_type'] == 'bond'
    assert fake_iface['media_options'] == 'none'


# Generated at 2022-06-11 03:06:43.999193
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    if_dict = {}
    words = ['media:', 'autoselect', '(none)']
    ips = {}
    d = DarwinNetwork(None)

    d.parse_media_line(words, if_dict, ips)

    assert if_dict == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)'}

# Generated at 2022-06-11 03:06:49.011617
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test with empty parameters
    darwinNetwork = DarwinNetwork({})
    current_if = {}
    ips = {}
    media_line = ""
    darwinNetwork.parse_media_line(media_line.split(), current_if, ips)
    # Test with full parameters
    current_if = {}
    ips = {}
    media_line = "media: <unknown type> <unknown>"
    darwinNetwork.parse_media_line(media_line.split(), current_if, ips)

# Generated at 2022-06-11 03:06:54.091666
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    if_line = [ "media: <unknown type> status: inactive" ]
    network_obj = DarwinNetwork(module=None)
    result = network_obj.parse_media_line(if_line, {}, {})
    assert result == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-11 03:07:04.253296
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media = ['media', '10baseT/UTP', '<link>']
    current_if = {'media': '10baseT/UTP', 'media_select': '10baseT/UTP', 'media_type': '<link>'}
    words = []
    if current_if == DarwinNetwork().parse_media_line(media, words):
        print('Test 1 of DarwinNetwork.parse_media_line() passed.')
    else:
        print('Test 1 of DarwinNetwork.parse_media_line() FAILED.')

    media = ['media', 'autoselect', '<unknown type>']
    current_if = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    words = []

# Generated at 2022-06-11 03:07:14.780252
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # input test data
    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = {}
    ips = {}

    # expected output if
    expected_if = {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type',
        'media_options': None
    }

    # Construct DarwinNetwork object
    darwin_network = DarwinNetwork()
    # call method parse_media_line
    darwin_network.parse_media_line(words, current_if, ips)
    # compare actual output if with expected output if
    assert current_if == expected_if

# Generated at 2022-06-11 03:07:21.069597
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    for case, expected in [
            (('media:', 'airdrop', '11ac', '(auto)'), {'media': 'Unknown', 'media_select': 'airdrop', 'media_type': '11ac', 'media_options': ['auto']}),
            (('media:', '<unknown', 'type>'), {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}),
    ]:
        assert DarwinNetwork.parse_media_line(case, {}, []) == expected, case

# Generated at 2022-06-11 03:07:27.171385
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {}
    words = ['media:', 'autoselect', '<unknown type>']
    result = {'media': 'Unknown', 'media_select': 'autoselect',
              'media_type': 'unknown type'}
    d.parse_media_line(words, current_if, '10.0.0.1')
    assert current_if == result

# Generated at 2022-06-11 03:07:34.447711
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifcfg = DarwinNetwork()

    ifcfg._interfaces['lo0'] = dict()
    ifcfg.parse_media_line(['media:', 'Autoselect', '(100baseTX)'], ifcfg._interfaces['lo0'], dict())

    assert ifcfg._interfaces['lo0']['media'] == 'Unknown'
    assert ifcfg._interfaces['lo0']['media_select'] == 'Autoselect'
    assert ifcfg._interfaces['lo0']['media_type'] == '100baseTX'
    assert ifcfg._interfaces['lo0']['media_options'] == dict()

    ifcfg._interfaces['lo0'] = dict()

# Generated at 2022-06-11 03:07:39.929474
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = 'media: autoselect (none)'
    words = data.split()
    current_if = {'type': 'ethernet'}

    darwin_network = DarwinNetwork('')

    assert darwin_network.parse_media_line(words, current_if, '') == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': {'none': 'none'}}

# Generated at 2022-06-11 03:07:47.916841
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Tests the parse_media_line method of the DarwinNetwork class.
    """
    mac_network = DarwinNetwork()
    mac_words = ['media:', 'auto', '1000baseT', 'copper']
    mac_current_if = {}
    mac_ips = {}

    # Ensure the media line is parsed correctly
    mac_network.parse_media_line(mac_words, mac_current_if, mac_ips)
    assert mac_current_if['media_select'] == 'auto'
    assert mac_current_if['media_type'] == '1000baseT'
    assert mac_current_if['media_options'] == 'copper'

# Generated at 2022-06-11 03:07:58.233456
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_iface = {'name': 'lo0'}
    test_ips = []
    # test expected input
    result_iface_expected = {'description': '',
                             'name': 'lo0',
                             'address': '::1',
                             'media': 'Unknown',
                             'media_select': 'autoselect',
                             'media_type': 'status: inactive',
                             'media_options': []}
    result_ips_expected = []
    test_obj = DarwinNetwork()
    test_obj.parse_media_line(['lo0:', 'autoselect', 'status:', 'inactive'], test_iface, test_ips)

    assert test_iface == result_iface_expected and test_ips == result_ips_expected
    # test empty interface name
   

# Generated at 2022-06-11 03:08:07.791251
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}

    # line containing a media field
    # a line like this comes from 'networksetup -listallhardwareports'
    words = ['media:', 'autoselect', '(100baseTX)', 'full-duplex']
    network.parse_media_line(words, current_if, {})
    assert  current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(100baseTX)'
    assert current_if['media_options'] == 'full-duplex'

    # line not containing a media field
    words = ['autoselect', '(100baseTX)', 'full-duplex']
    network.parse_media_line(words, current_if, {})

# Generated at 2022-06-11 03:08:15.434696
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import timeout
    import pytest
    from sys import version_info

    if version_info.major < 3:
        pytest.skip('This test is for Python 3 only')

    network = DarwinNetwork()
    iface = Facts({}, timeout.Timeout())
    ips = []

    words = ['media:', 'autoselect', 'none', 'status:', 'inactive']
    network.parse_media_line(words, iface, ips)
    assert iface == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none',
                     'media_options': None, 'media_status': 'inactive'}


# Generated at 2022-06-11 03:08:24.555347
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_d = DarwinNetwork()
    current_if = {}
    # Test case when media_type is passed
    mac_d.parse_media_line(['media:','none','none','none'], current_if, {})
    assert current_if['media'] == 'Unknown', \
        'Parsing media_type line failed'
    assert current_if['media_select'] == 'none', \
        'Parsing media_type line failed'
    assert current_if['media_type'] == 'none', \
        'Parsing media_type line failed'
    current_if = {}
    mac_d.parse_media_line(['media:','none','none'], current_if, {})
    assert current_if['media'] == 'Unknown', \
        'Parsing media_type line failed'
   

# Generated at 2022-06-11 03:08:36.106296
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_interfaces = {}
    current_interfaces['en0'] = {'name': 'en0', 'options': {}}
    darwin_net_mock = DarwinNetwork(current_interfaces=current_interfaces)
    darwin_net_mock.parse_media_line(['media:', 'Ethernet', 'autoselect', '10baseT'], current_interfaces['en0'], 'ips')
    assert current_interfaces['en0']['media_select'] == 'Ethernet'
    assert current_interfaces['en0']['media_type'] == 'autoselect'
    assert current_interfaces['en0']['media_options'] == ['10baseT']
    assert current_interfaces['en0']['media'] == 'Unknown'
    darwin_net

# Generated at 2022-06-11 03:08:41.135939
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {'name': 'en0'}
    words = ['media:', 'autoselect', '<unknown type>', '(none)']
    DarwinNetwork.parse_media_line(None, words, interface, None)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] == 'unknown type'
    assert interface['media_options'] == None

# Generated at 2022-06-11 03:08:50.586754
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network=DarwinNetwork()

    if_dict={'address': 'fe80::4c55:28ff:fe67:5a5e',
             'macaddress': '4c:55:28:67:5a:5e',
             'type': 'Loopback',
             'netmask': 'ffff:ffff:ffff:ffff::'
         }

    ips=[]

    words=['media:', '<unknown', 'type>', '(0x2)']

    darwin_network.parse_media_line(words, if_dict, ips)

    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == 'Unknown'
    assert if_dict['media_type'] == 'unknown type'
    assert 'media_options' not in if_dict




# Generated at 2022-06-11 03:08:58.502565
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test data
    # Media: autoselect (1000baseT <full-duplex>)
    media_line = ['Media:', 'autoselect', '(1000baseT', '<full-duplex>)']
    # test case
    current_if = {'media': 'Unknown'}
    ips = 'Unknown'
    expected_result = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'full-duplex'}
    # run test
    DarwinNetwork.parse_media_line(DarwinNetwork(), media_line, current_if, ips)
    assert(current_if == expected_result)



# Generated at 2022-06-11 03:09:02.895780
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line = 'media: <unknown type> <unknown>'
    iface = {}
    d = DarwinNetwork()
    d.parse_media_line(test_line.split(), iface, None)
    assert iface.get('media_select') == 'Unknown'
    assert iface.get('media_type') == 'unknown type'
    assert iface.get('media_options') == []

# Generated at 2022-06-11 03:09:10.916326
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'ipv4': [], 'ipv6': [], 'module': 'en0',
                  'type': 'Ethernet', 'bond': False}
    ips = {'ipv4': [], 'ipv6': []}

    # MacOSX 10.11.6, ifconfig -a
    # en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    #       options=10b<RXCSUM,TXCSUM,VLAN_HWTAGGING,AV>
    #       ether e8:de:27:6f:b3:3e
    #       inet6 fe80::eade:27ff:fe6f:b33e%en0 prefixlen 64 secured scopeid 0x5

# Generated at 2022-06-11 03:09:17.109666
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 1: Empty current_if
    DarwinNetwork.parse_media_line(DarwinNetwork, [], {}, [])
    # Test 2: Empty words
    DarwinNetwork.parse_media_line(DarwinNetwork, [""], {}, [])
    # Test 3: Empty media_select
    DarwinNetwork.parse_media_line(DarwinNetwork, [""], {"media_select": ""}, [])
    # Test 4: Empty ips
    DarwinNetwork.parse_media_line(DarwinNetwork, [""], {"media_select": ""}, [{}])



# Generated at 2022-06-11 03:09:20.730769
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media = ['autoselect', '<unknown type>']
    current_if = dict()
    ip_version = '4'

    darwin_network = DarwinNetwork()

    darwin_network.parse_media_line(media, current_if, ip_version)

    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:09:25.195186
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_class = DarwinNetwork()

    darwin_network_class.parse_media_line(['unknown', 'type', '>'], {}, {})
    assert darwin_network_class.parse_media_line(['<unknown', 'type>'], {}, {}) is None
    assert darwin_network_class.parse_media_line(['unknown', 'type', '>'], {}, {}) == {'media': 'Unknown',
                                                                                      'media_select': 'Unknown',
                                                                                      'media_type': 'unknown type'}

# Generated at 2022-06-11 03:09:35.294318
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for correct result for media line with 3 words
    line = "media: autoselect (<unknown type>)"
    current_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type',
                  'media_options': {}}
    assert DarwinNetwork.parse_media_line(None, line.split(), current_if, None) == current_if
    # Test for correct result for media line with 4 words
    line = "media: autoselect (1000baseT <full-duplex>)"
    current_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '1000baseT',
                  'media_options': {'full-duplex': ''}}

# Generated at 2022-06-11 03:09:52.796705
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    drwm = DarwinNetwork()
    # test with normal media line
    words = ['media:', 'auto', '10baseT/UTP', '(<unknown subtype>)' ]
    current_if = {}
    ips = {}
    drwm.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '10baseT/UTP'
    assert current_if['media_options'] == '(<unknown subtype>)'

    # test with media line of bridge interface
    words = ['media:', '<unknown', 'type>']
    current_if = {}

# Generated at 2022-06-11 03:10:01.240181
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    # media line is different to the default FreeBSD one
    def test_parse_media_line(self, words, current_if, ips):
        if current_if:  # we get a line each time, just keep the first
            # media line is different to the default FreeBSD one
            current_if['media'] = words[1]
            current_if['media_select'] = words[1]
            if len(words) > 2:
                current_if['media_type'] = words[2][1:-1]
            if len(words) > 3:
                current_if['media_options'] = self.get_options(words[3])

        def get_options(self, str):
            options = []

# Generated at 2022-06-11 03:10:11.251824
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    test_if = {'media': 'Unknown'}

    # test media select without media type
    test_words = ['media:', 'autoselect', 'mediaopts']
    network.parse_media_line(test_words, test_if, None)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_options'] == 'mediaopts'

    # test media select with media type
    test_words = ['media:', '10baseT/UTP', '<full-duplex>', 'mediaopts']
    network.parse_media_line(test_words, test_if, None)
    assert test_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:10:19.055661
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_darwin = DarwinNetwork()
    my_if = {}

    # test with 4 words
    my_words = ['media:', 'autoselect', '<unknown type>', '(none)']
    my_if = my_darwin.parse_media_line(my_words, my_if, [])
    assert my_if['media'] == 'Unknown'
    assert my_if['media_select'] == 'autoselect'
    assert my_if['media_type'] == 'unknown type'
    assert my_if['media_options'] == 'none'

    # test with 3 words
    my_words = ['media:', 'autoselect', '(100baseTX)']
    my_if = my_darwin.parse_media_line(my_words, my_if, [])

# Generated at 2022-06-11 03:10:26.519729
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of DarwinNetwork
    darwin_network = DarwinNetwork(None, "darwin")
    # create a dictionary to hold the parsed data
    current_if = {}
    # create a list of words that represent the command output
    words = ["media:", "autoselect", "(none)", "status:", "inactive"]
    # call the parse_media_line function and store the result in the dictionary
    darwin_network.parse_media_line(words, current_if, "ips")
    # check that the result is as expected
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none', 'media_options': {}}, "testcase failed"

# Generated at 2022-06-11 03:10:36.164832
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # Test for standard media line
    words = ['media:', 'autoselect', '(none)']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    # Test for media line where words[1] == '<unknown' and words[2] == 'type>'
    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:10:42.161085
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {}
    words = []
    words.append('media:')
    words.append('autoselect')
    words.append('(none)')

    osx = DarwinNetwork()
    osx.parse_media_line(words, iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'none'

    # now do an empty test just to get the code coverage
    words = []
    osx.parse_media_line(words, iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] is None
    assert 'media_options' not in iface.keys()

# Generated at 2022-06-11 03:10:46.745336
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ["media:", "autoselect", "<unknown", "type>", "status:", "active"]
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}

# Generated at 2022-06-11 03:10:51.713067
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    media_line_words = "media: <unknown type> <unknown type>".split()
    current_if = {}
    ips = []
    network.parse_media_line(media_line_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:10:56.184626
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    expected = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'none'
    }

    test_string = ['media:', 'autoselect', 'none']

    fact_obj = DarwinNetwork()
    test_result = fact_obj.parse_media_line(test_string, {}, [])

    assert test_result == expected



# Generated at 2022-06-11 03:11:24.635303
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current = dict()
    ips = dict()
    dn.parse_media_line(['en0', 'autoselect', '(none)'], current, ips)
    assert 'media' in current
    assert 'media_select' in current
    assert not 'media_type' in current
    assert current['media'] == 'Unknown'
    assert current['media_select'] == 'autoselect'

    dn.parse_media_line(['en0', '<unknown', 'type>'], current, ips)
    assert current['media_select'] == 'Unknown'
    assert 'media_type' in current
    assert current['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:11:31.248309
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()

    assert test_object.parse_media_line(words=['    media:', 'Ethernet', 'autoselect'], current_if={}, ips=[]) == None

    test_object.parse_media_line(words=['    media:', '<unknown', 'type>'], current_if={}, ips=[])
    assert test_object.parse_media_line(words=['    media:', '<unknown', 'type>'], current_if={}, ips=[]) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}


# Generated at 2022-06-11 03:11:39.208181
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import inspect
    class testClass:
        def get_options(self, words):
            return words
    # test 1
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = dict()
    ips = dict()
    t = testClass()
    dnif = DarwinNetwork(t)
    dnif.parse_media_line(words, current_if, ips)
    assert (current_if.get('media_select') == 'autoselect') and (current_if.get('media_type') == '(none)')
    # test 2
    words = ['media:', '<unknown', 'type>', 'media_options']
    current_if = dict()
    ips = dict()
    t = testClass()

# Generated at 2022-06-11 03:11:47.540696
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test format 1 - typical case
    current_if = {'media': 'Unknown'}
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork._parse_media_line(words, current_if)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': []}

    # Test format 2 - bridge interface
    current_if = {'media': 'Unknown'}
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork._parse_media_line(words, current_if)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': []}

# Generated at 2022-06-11 03:11:57.248316
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifn = DarwinNetwork()  # ifn = interface
    words = ['status:', 'active', 'type:', 'Ethernet', 'autoselect', '<unknown type>']
    current_if = dict()
    ips = dict()
    ifn.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': 'unknown type', 'media_options': None}
    words = ['status:', 'active', 'type:', 'Ethernet', 'autoselect', '(1000baseT,HD)']
    current_if = dict()
    ips = dict()
    ifn.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:12:05.938338
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    iface = {}
    darwin_net.parse_media_line(['media:', 'Auto', '1000baseT', '(full-duplex)'], iface, {})
    assert iface['media'] == 'Unknown', "Did not set key media to value Unknown"
    assert iface['media_select'] == 'Auto', "Did not set key media_select to correct value"
    assert iface['media_type'] == '1000baseT', "Did not set key media_type to correct value"
    assert iface['media_options'] == {'full-duplex': None}, "Did not set key media_type to correct value full-duplex"

    iface = {}

# Generated at 2022-06-11 03:12:12.706038
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = ["media:", "<unknown type>",
                  "status:", "active"]
    test_if = []
    test_ips = {}
    expected_result = {'media_options': [],
                       'media_select': 'Unknown',
                       'media_type': 'unknown type',
                       'media': 'Unknown'}
    DarwinNetwork().parse_media_line(media_line, test_if, test_ips)
    assert test_if[0] == expected_result

# Generated at 2022-06-11 03:12:18.692383
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if_dict = {'inet6': [], 'inet': []}
    test_ips = []
    test_words = ['media:', 'autoselect', 'status:', 'active']
    DarwinNetwork().parse_media_line(test_words, test_if_dict, test_ips)
    assert test_if_dict.get('media') == 'Unknown'
    assert test_if_dict.get('media_select') == 'autoselect'
    assert test_if_dict.get('media_type') == 'status:'
    assert test_if_dict.get('media_options') == 'active'

# Generated at 2022-06-11 03:12:28.277992
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    facts = DarwinNetwork()
    # test 1
    words = ['Media:', 'autoselect', '(autoselect)']
    # test output
    facts.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'autoselect'

    # test 2
    words = ['Media:', '<unknown', 'type>']
    # test output
    facts.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:12:35.297120
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # This is a little out of the ordinary
    # Normally we call the method directly but this is a class method
    # as such we could call it like this
    # DarwinNetwork.parse_media_line( ... )
    # but I don't like fiddling with class variables
    # and find this more in the spirit of testing.
    # So the solution is to do it this way
    # Note this is a class method so don't try and instantiate DarwinNetwork first
    # Also note that self is not needed - because it is a class method

    # Setup iface (the interface we are populating)
    iface = {}

    # normal non bridge interface
    # test data
    words = [
        'media:', 'autoselect', '(none)', 'status:', 'inactive'
    ]
    # call method
    iface = DarwinNetwork

# Generated at 2022-06-11 03:13:18.547668
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    words1 = ["media:", "media_select", "media_type<>", "media_options"]
    words2 = ["media:", "<unknown", "type>"]
    current_if = {
        'media': None,
        'media_select': None,
        'media_type': None,
        'media_options': None
    }
    ips = None

    dn = DarwinNetwork()
    dn.parse_media_line(words1, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == words1[1]
    assert current_if['media_type'] == words1[2][1:-1]

# Generated at 2022-06-11 03:13:23.359758
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': 'Unknown', 'media_select': None, 'media_type': None, 'media_options': {}}
    words = ["<unknown", "type>"]
    DarwinNetwork.parse_media_line(words, current_if)
    assert current_if == {'media': 'Unknown', 'media_select': "Unknown", 'media_type': "unknown type", 'media_options': {}}

# Generated at 2022-06-11 03:13:28.732664
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {'if': 'vboxnet0'}
    ips = {}
    network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert 'media_options' not in current_if

# Generated at 2022-06-11 03:13:35.985633
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test to see if we get the right interface media information.
    """
    ifc_info = {'name': 'en0', 'macaddress': 'c4:0e:10:7b:d1:e4', 'v4_subnets': [], 'v6_subnets': [],
                'mtu': '1500'}

    # Test with a single word
    test_words = ['media:', 'autoselect']
    DarwinNetwork.parse_media_line(ifc_info, test_words, None)
    # Check ifc_info with the expected value for the interface
    assert 'media' in ifc_info
    assert ifc_info['media'] == 'Unknown'
    assert 'media_select' in ifc_info

# Generated at 2022-06-11 03:13:44.321226
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

# Generated at 2022-06-11 03:13:48.036312
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = ['media:', '<unknown type>']
    network = DarwinNetwork()
    network.parse_media_line(media_line, {}, {})
    assert network.current_if['media_type'] == 'unknown type'
    assert network.current_if['media_select'] == 'Unknown'



# Generated at 2022-06-11 03:13:56.880433
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test = DarwinNetwork()
    words = ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST', 'mtu', '1500', 'options=8<VLAN_MTU>']
    current_if = {'media': 'Unknown', 'media_select': 'UP', 'media_type': 'BROADCAST', 'media_options': 'SIMPLEX'}
    #test.parse_media_line(words, current_if, ips)
    #current_if['media_options'] = 'SIMPLEX'
    assert current_if == {'media': 'Unknown', 'media_select': 'UP', 'media_type': 'BROADCAST', 'media_options': 'SIMPLEX'}


# Generated at 2022-06-11 03:14:04.447051
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test if every item of media_select, media_type and media_options
    is set properly.
    """
    dn = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': {}}
    ips = {}
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == {'none': True}
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if

# Generated at 2022-06-11 03:14:10.100505
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    my_network = DarwinNetwork()
    test_if = {}
    my_words = ['media:', '<unknown', 'type>', 'none']
    my_network.parse_media_line(my_words, test_if, {})
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == {}