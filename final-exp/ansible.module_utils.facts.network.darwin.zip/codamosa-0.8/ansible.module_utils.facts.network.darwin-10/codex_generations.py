

# Generated at 2022-06-11 03:04:20.034028
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {'media': 'Unknown', 'media_select': 'none', 'media_type': 'unknown type', 'media_options': []}
    test = DarwinNetwork()
    test.parse_media_line(['media:', '<unknown', 'type>'], test_dict, [])
    assert test_dict == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': []}

# Generated at 2022-06-11 03:04:25.285164
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    n = DarwinNetwork()
    current_if = {}
    n.parse_media_line('media: <unknown type>'.split(), current_if, 0)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type'

# Generated at 2022-06-11 03:04:35.578021
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    assert darwin_network.parse_media_line(['media:', 'autoselect', '(1000baseT)'], {}, {}) == \
        {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(1000baseT)', 'media_options': []}
    assert darwin_network.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {}, {}) == \
        {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'Unknown', 'media_options': []}
    assert darwin_network.parse_media_line(['media:', 'media', '10baseT/UTP', '<full-duplex>'], {}, {})

# Generated at 2022-06-11 03:04:45.262165
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    facts = DarwinNetwork()
    test_if = {'media_select': '', 'media_type': '', 'media_options': '', 'media': ''}
    test_if['media_select'] = 'none'
    test_if['media_type'] = 'N/A'
    test_if['media_options'] = 'none'
    test_if['media'] = 'N/A'
    words = ['media', 'none', 'N/A', 'none']
    ips = []
    facts.parse_media_line(words, test_if, ips)
    assert test_if['media_select'] == 'none'
    assert test_if['media_type'] == 'N/A'
    assert test_if['media_options'] == ''

# Generated at 2022-06-11 03:04:55.897544
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    t = DarwinNetwork()

    # Check if a media line is correctly parsed
    words = ['media:', 'autoselect', '(100baseTX)',
             'status:', 'active']
    t.parse_media_line(words)
    assert t.current['media'] == 'Unknown'
    assert t.current['media_select'] == 'autoselect'
    assert t.current['media_type'] == '100baseTX'
    assert t.current['media_options'] == ''

    # Check if the media line is correctly parsed
    # when the media_type has a '<' symbol
    words = ['media:', 'autoselect', '<unknown type>']
    t.parse_media_line(words)
    assert t.current['media_select'] == 'Unknown'
    assert t.current['media_type']

# Generated at 2022-06-11 03:05:05.400197
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup
    dn = DarwinNetwork()

    # media line is different to the default FreeBSD one
    def parse_media_line(self, words, current_if, ips):
        # not sure if this is useful - we also drop information
        current_if['media'] = 'Unknown'  # Mac does not give us this
        current_if['media_select'] = words[1]
        if len(words) > 2:
            # MacOSX sets the media to '<unknown type>' for bridge interface
            # and parsing splits this into two words; this if/else helps
            if words[1] == '<unknown' and words[2] == 'type>':
                current_if['media_select'] = 'Unknown'
                current_if['media_type'] = 'unknown type'

# Generated at 2022-06-11 03:05:12.816105
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_instance = DarwinNetwork()
    current_if = {}
    words = ['media:', 'autoselect', '(none)', '(none)', '(none)']
    test_instance.parse_media_line(words,current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    words = ['media:', 'autoselect', '(none)', '(none)', '(none)']
    test_instance.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    words = ['media:', '<unknown', 'type>', '(none)', '(none)']

# Generated at 2022-06-11 03:05:20.788500
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # pylint: disable=protected-access
    mac = DarwinNetwork()  # get a DarwinNetwork object
    mac.parse_media_line(['(', 'supported', 'media:', '10baseT/UTP', '<half-duplex>', ')'], {}, [])
    mac.parse_media_line(['(', 'supported', 'media:', '10baseT/UTP', '<full-duplex>', ')'], {}, [])
    mac.parse_media_line(['(', 'supported', 'media:', '10baseT/UTP', '<full-duplex,flow-control>', ')'], {}, [])

# Generated at 2022-06-11 03:05:27.675593
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # not sure this is even possible to test, since we use the same implementation as
    # FreeBSD and the tests already cover this function.  For now all we can do is
    # test that the function exists and returns a value so we can use it in the
    # instantiation of DarwinNetwork class
    net_obj = DarwinNetwork()
    ret = net_obj.parse_media_line(['media:','100BaseTX','<full-duplex>','mediaopt'], {})
    assert ret

# Generated at 2022-06-11 03:05:34.133961
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.dirname(__file__))

    # Prepare mock ifconfig output

# Generated at 2022-06-11 03:05:46.041421
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_DarwinNetwork = DarwinNetwork()
    test_current_if = {}
    test_ips = []

    test_words = ['media:', '<unknown', 'type>']
    test_DarwinNetwork.parse_media_line(test_words, test_current_if, test_ips)
    assert test_current_if['media_select'] == 'Unknown'
    assert test_current_if['media_type'] == 'unknown type'
    test_words = ['media:', 'autoselect', '(none)']
    test_DarwinNetwork.parse_media_line(test_words, test_current_if, test_ips)
    assert test_current_if['media_select'] == 'autoselect'
    assert test_current_if['media_type'] == '(none)'

# Generated at 2022-06-11 03:05:52.754074
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}
    words = ['media:', 'autoselect', '(none)']

    media1 = network.parse_media_line(words, current_if, {})

    assert media1['media'] == 'Unknown'
    assert media1['media_select'] == 'autoselect'
    assert media1['media_type'] == 'none'

    words = ['media:', '<unknown', 'type>']
    media1 = network.parse_media_line(words, current_if, {})

    assert media1['media'] == 'Unknown'
    assert media1['media_select'] == 'Unknown'
    assert media1['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:00.117533
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Arrange
    test_class = DarwinNetwork()
    test_media_line = ['media:', '<unknown type>', 'link', 'status:', 'active']
    test_if = { 'name': 'eth0' }
    test_ips = []

    # Act
    test_class.parse_media_line(test_media_line, test_if, test_ips)

    # Assert
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:08.689084
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    This tests the scenarios
    1. when current_if['media']  = 'Unknown'
    2. when words[1] == '<unknown' and words[2] == 'type>'
    """
    obj = DarwinNetwork()
    words = ['media:', '<unknown type>']
    obj.parse_media_line(words, None, None)
    result = obj.current_if
    media_select = obj.current_if['media_select']
    media_type = obj.current_if['media_type']
    assert media_select == '<unknown type>'
    assert media_type == 'unknown type'

# Generated at 2022-06-11 03:06:16.573914
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc._interfaces = {}
    ifc._interfaces['en0'] = {}
    ifc._interfaces['en1'] = {}
    ifc._interfaces['en2'] = {}
    ifc._interfaces['en3'] = {}
    ifc._interfaces['en4'] = {}

    # Test parsing media line for ethernet interface
    words = ['media:', 'autoselect', '(1000baseT)']
    ifc.parse_media_line(words, ifc._interfaces['en0'])
    assert ifc._interfaces['en0']['media'] == 'Unknown'
    assert ifc._interfaces['en0']['media_select'] == 'autoselect'

# Generated at 2022-06-11 03:06:24.408925
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # prepare test
    dn = DarwinNetwork()
    current_if = {}
    # run test
    dn.parse_media_line(['<unknown type>', 'type', 'unknown type>'], current_if, [])
    # check result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-11 03:06:32.890792
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Implement requirements:
    # - all the current_if keys that can be populated with parse_media_line
    #   are defined in current_if
    current_if = {}
    d = DarwinNetwork()
    d.parse_media_line(['media:', 'none', 'status:', 'inactive'], current_if, None)
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    assert 'media_options' in current_if
    # - parsing of media line with kind of unknown media type
    current_if = {}
    d.parse_media_line(['media:', '<unknown', 'type>', 'status:', 'inactive'], current_if, None)
    assert current_if['media'] == 'Unknown'


# Generated at 2022-06-11 03:06:43.903551
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net_obj = DarwinNetwork()
    # Test for a media line with two words
    current_if = {}
    words = ['media:', 'none']
    darwin_net_obj.parse_media_line(words, current_if, ips=None)
    assert current_if == {'media': 'Unknown', 'media_select': 'none'}

    # Test for a media line with three words
    current_if = {}
    words = ['media:', '<unknown', 'type>']
    darwin_net_obj.parse_media_line(words, current_if, ips=None)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

    # Test for a media line with four words
    current_

# Generated at 2022-06-11 03:06:50.544698
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    words = ['media:', 'autoselect', ' status:', 'inactive']
    current_if = {'name': 'en4', 'inet6': []}

    dnet.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'inactive'

    current_if['name'] = 'bridge0'
    dnet.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    words = ['media:', '10baseT/UTP', 'status:', 'active']
    current_if['name'] = 'en4'

# Generated at 2022-06-11 03:07:00.282317
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = {}

    # test the normal, expected output

# Generated at 2022-06-11 03:07:07.590328
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {'name': 'en0'}
    test_ips = []
    test_words = ''
    test_network = DarwinNetwork(module=None, collected_facts=None, resources=None)
    return_if = test_network.parse_media_line(test_words, test_if, test_ips)
    assert return_if['media'] == 'Unknown'
    assert return_if['media_select'] == test_words
    test_words = '<unknown type>'
    return_if = test_network.parse_media_line(test_words, test_if, test_ips)
    assert return_if['media'] == 'Unknown'
    assert return_if['media_select'] == 'Unknown'
    assert return_if['media_type'] == 'unknown type'
    assert 'media_options'

# Generated at 2022-06-11 03:07:13.502463
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test for media line with correct option
    object_name = DarwinNetwork()
    test_line = ["media:", "autoselect", "Wi-Fi", "(autoselect)"]
    object_name.parse_media_line(test_line, {}, [])

    # Test for media line with undefined option
    object_name = DarwinNetwork()
    test_line = ["media:", "autoselect", "(unknown type)"]
    object_name.parse_media_line(test_line, {}, [])

# Generated at 2022-06-11 03:07:21.573429
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:07:31.530066
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line_1 = ['media:', 'autoselect', '(100baseTX)', 'status:', 'active']
    test_line_2 = ['media:', '<unknown', 'type>', 'status:', 'active']

    a = DarwinNetwork()
    a.parse_media_line(test_line_1, {}, [])
    assert a.current_if['media_select'] == 'autoselect'
    assert a.current_if['media_type'] == '(100baseTX)'
    assert a.current_if['media_options'] == ''

    a.parse_media_line(test_line_2, {}, [])
    assert a.current_if['media_type'] == None
    assert a.current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:07:38.845982
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    darwin_network = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}
    words = ['media:', 'autoselect', '(autoselect)', 'status:', 'inactive']
    current_if = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:07:48.463917
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # we should parse media_select, media_type and media_options correctly
    fake_ifconfig = [
        "media: ",
        "media: autoselect (100baseTX full-duplex,flow-control,100baseTX full-duplex,flow-control)",
        "media: autoselect <unknown type>",
        "media: autoselect <unknown type,flow-control>"
    ]
    mac = DarwinNetwork()
    result = mac.parse_media_line(fake_ifconfig[0].split(), {}, [])
    assert result == {}
    result = mac.parse_media_line(fake_ifconfig[1].split(), {}, [])

# Generated at 2022-06-11 03:07:57.572641
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    iface = {'media': 'Unknown',
             'media_select': 'ieee80211',
             'media_type': '11n',
             'media_options': 'ht/40'}
    test = DarwinNetwork()
    words = ['media:', 'ieee80211', '11n', 'ht/40']

    # Act
    test.parse_media_line(words, iface, None)

    # Assert
    assert iface == {'media': 'Unknown',
             'media_select': 'ieee80211',
             'media_type': '11n',
             'media_options': 'ht/40'}

# Generated at 2022-06-11 03:08:06.658221
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {'media': '', 'media_type': '', 'media_select': '', 'media_options': '', 'address': ''}
    # Test 1:
    # media line only contains one word, expect media_select
    words = ['', 'auto']
    current_if = DarwinNetwork.parse_media_line(
        DarwinNetwork(), words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == ''

    # Test 2:
    # media line is 'auto 1000baseTX'
    words = ['', 'auto', '1000baseTX']

# Generated at 2022-06-11 03:08:14.997570
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    changed_if = {}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(['media:', 'autoselect', '(', '100baseTX', '<full-duplex>)'],
                                    current_if,
                                    changed_if)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == 'full-duplex'

    current_if = {}
    changed_if = {}
    # MacOSX sets the media type to '<unknown type>' for a bridge interface
    # and parsing splits this into two words; this if/else helps
    darwin_network = DarwinNetwork()

# Generated at 2022-06-11 03:08:20.396827
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {}
    DarwinNetwork.parse_media_line(DarwinNetwork(), ["media:","autoselect","<unknown type>"], test_dict)
    assert test_dict['media'] == "Unknown"
    assert test_dict['media_select'] == "autoselect"
    assert test_dict['media_type'] == "unknown type"
    assert test_dict['media_options'] == ""

# Generated at 2022-06-11 03:08:34.709130
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_fact = DarwinNetwork()

    test_data = ['media: <unknown type> <unknown>',
                 'mediaopt: none supported',
                 'status: active',
                 'lladdr: f2:f0:c2:b7:a8:8e']

    test_fact.parse_media_line(test_data[0].split(), test_fact.interfaces['eth0'], test_fact.interfaces['eth0']['ipv4'])
    assert test_fact.interfaces['eth0']['media'] == 'Unknown'
    assert test_fact.interfaces['eth0']['media_select'] == '<unknown'
    assert test_fact.interfaces['eth0']['media_type'] == 'unknown type'



# Generated at 2022-06-11 03:08:44.051461
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:08:53.642009
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    iface = {}
    ips = {}

    # Test default case
    words = ['media:', 'autoselect', '(1000baseT)']
    iface = net.parse_media_line(words, iface, ips)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '(1000baseT)'
    assert iface['media_options'] == ''

    # Test unknown media case
    words = ['media:', '<unknown', 'type>']
    iface = net.parse_media_line(words, iface, ips)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:08:59.678903
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for parse_media_line of class DarwinNetwork
    """
    test_obj = DarwinNetwork()
    current_if = {}
    test_obj.parse_media_line(["media:", "unknown", "type", "unknown", "options"], current_if, {})

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'unknown'

# Generated at 2022-06-11 03:09:07.780145
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test if a media line is parsed correctly
    # using the method parse_media_line of class DarwinNetwork
    mac_osX_words = [
        'media:', '<unknown type>', '(100baseTX <full-duplex,flow-control>)',
        'status:', 'active'
    ]
    media_line = {
        'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': {
            'full-duplex': True, 'flow-control': True
        }
    }
    current_if = {}
    ips = {}
    DarwinNetwork.parse_media_line(
        DarwinNetwork(),  # ignored
        mac_osX_words,
        current_if,
        ips
    )
    assert media_line == current_if


# Generated at 2022-06-11 03:09:11.799654
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dummy_if = {'media': 'Unknown', 'media_select': '10baseT/UTP', 'media_type': '<link type>', 'media_options': []}
    assert(dummy_if == DarwinNetwork.parse_media_line(DarwinNetwork(), ['media:', '10baseT/UTP', '<link', 'type>'], dummy_if, {}))

# Generated at 2022-06-11 03:09:18.489446
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # emulate data from ifconfig
    words = [ 'unknown', 'type', ]
    current_if = dict()
    ips = dict()
    # initialize the target class
    dwin = DarwinNetwork(ansible_module_instance=None, include_defaults=True, config=None)
    # parse the data
    dwin.parse_media_line(words, current_if, ips)
    # check if the result is as expected
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'unknown'
    assert current_if['media_type'] == 'type'

# Generated at 2022-06-11 03:09:24.821624
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork({})
    if_dict = {}
    darwin_network.parse_media_line(['media:', 'auto', '(none)'], if_dict, {})
    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == 'auto'
    assert if_dict['media_type'] == 'none'
    darwin_network.parse_media_line(['media:', '1000baseT', '(none)'], if_dict, {})
    assert if_dict['media'] == 'Unknown'
    assert if_dict['media_select'] == '1000baseT'
    assert if_dict['media_type'] == 'none'

# Generated at 2022-06-11 03:09:34.868271
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Prepare a test context
    test_ctx = {}
    test_ctx['current_if'] = {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}
    test_ctx['ips'] = ''

    # Create an instance of the DarwinNetwork class
    obj = DarwinNetwork()
    # Check that there are no changes while parsing an empty line
    obj.parse_media_line([], test_ctx['current_if'], test_ctx['ips'])
    assert test_ctx['current_if'] == {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}
    assert test_ctx['ips'] == ''

    # Check that media is set to Unknown

# Generated at 2022-06-11 03:09:43.884593
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    new_if = DarwinNetwork()
    new_if.parse_media_line(['media:', 'auto', '100baseTX', 'full-duplex'], {}, {})
    assert 'Unknown' == new_if.current_if['media']
    assert 'auto' == new_if.current_if['media_select']
    assert '100baseTX' == new_if.current_if['media_type']
    assert 'full-duplex' == new_if.current_if['media_options']
    new_if.parse_media_line(['media:', 'auto', '<unknown', 'type>'], {}, {})
    assert 'Unknown' == new_if.current_if['media_select']
    assert 'unknown type' == new_if.current_if['media_type']

# Generated at 2022-06-11 03:09:55.775850
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test the method DarwinNetwork.parse_media_line,
    """
    current_if = dict()
    ips = list()
    # first case - words[1] == '<unknown' and words[2] == 'type>'
    words = ['media:', '<unknown', 'type>', '']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    # second case - words[1] != '<unknown' and words[2] != 'type>'
    words = ['media:', 'autoselect', '(none)', '']
    DarwinNetwork.parse_media_line

# Generated at 2022-06-11 03:10:05.131434
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type>'
    words = media_line.split()
    current_if = {'ifdef_index': '', 'bridge_port': '', 'bridge_slave': '', 'encapsulation': '', 'ipv4': {}, 'macaddress': '', 'media': '', 'media_select': '', 'media_type': '', 'media_options': {}, 'name': '', 'type': '', 'ipv6': {'addr_flags': {}, 'addresses': {}, 'scope': ''}, 'mtu': 1518, 'flags': [], 'features': {'rx': {}, 'tx': {}}, 'status': ''}
    ips = {}
    # FACT

# Generated at 2022-06-11 03:10:14.664302
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    # Test case with a different media_type
    current_if = {}
    words = ['media:', 'autoselect', '<unknown', 'type>']
    network.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    # Test case with a normal media_type
    current_if = {}
    words = ['media:', 'autoselect', '(1000baseT']
    network.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:10:20.958069
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = {
        'media': 'media',
        'media_select': 'media_select',
        'media_type': 'media_type',
        'media_options': 'media_options',
    }
    test_if = dict.fromkeys(test_data.keys(), 'unset')
    for key, value in test_data.items():
        test_if[key] = value
        # call the method under test
        DarwinNetwork(None, None).parse_media_line((value,), test_if, None)
        # check that the attribute has been set
        assert(test_if['media'] == 'Unknown')
        assert(test_if['media_select'] == value)
        assert(test_if['media_type'] == value)
        assert(test_if['media_options'] == value)


# Generated at 2022-06-11 03:10:29.646049
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test case with a normal line
    test_object = DarwinNetwork()
    line = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = []
    test_object.parse_media_line(line, current_if, ips)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == 'autoselect')
    assert(current_if['media_type'] == '(none)')
    assert(current_if['media_options'] == [])
    # Test case with a broken line
    line = ['media:', 'autoselect']
    current_if = {}
    ips = []
    test_object.parse_media_line(line, current_if, ips)

# Generated at 2022-06-11 03:10:38.694896
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # media line is different to the default FreeBSD one
    def parse_media_line(self, words, current_if, ips):
        # not sure if this is useful - we also drop information
        current_if['media'] = 'Unknown'  # Mac does not give us this
        current_if['media_select'] = words[1]
        if len(words) > 2:
            # MacOSX sets the media to '<unknown type>' for bridge interface
            # and parsing splits this into two words; this if/else helps
            if words[1] == '<unknown' and words[2] == 'type>':
                current_if['media_select'] = 'Unknown'
                current_if['media_type'] = 'unknown type'
            else:
                current_if['media_type'] = words[2][1:-1]

# Generated at 2022-06-11 03:10:43.203502
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:','none','<unknown','type>']
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'None'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {}

# Generated at 2022-06-11 03:10:52.141395
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

    # test if method returns a dict
    assert isinstance(d.parse_media_line(['media:', 'none', 'status:', 'active'], dict(), dict()), dict)

    # test for media field
    assert d.parse_media_line(['media:', 'none', 'status:', 'active'], dict(), dict())['media'] == 'Unknown'
    assert d.parse_media_line(['media:', '<unknown', 'type>', '(none)', 'status:', 'active'], dict(), dict())['media'] == 'Unknown'

    # test for media_type field
    assert d.parse_media_line(['media:', 'none', 'status:', 'active'], dict(), dict())['media_type'] == '(none)'
    assert d.parse_media_line

# Generated at 2022-06-11 03:10:56.061544
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    test_DarwinNetwork_parse_media_line: Test network facts for parsing the media line of DarwinNetwork
    """
    dnetwork = DarwinNetwork()
    current_if = {}
    # Test 'media' line for different scenarios

# Generated at 2022-06-11 03:10:59.792225
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = [
        'media:', 'autoselect', '(none)', '(none)', 'status:', 'inactive'
    ]
    current_if = {}

    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options']['(none)'] == '(none)'



# Generated at 2022-06-11 03:11:15.005821
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # If the media line contains '<unknown' in the middle,
    # current_if['media_select'] should be 'Unknown'
    # current_if['media_type'] should be 'unknown type'
    test_words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(test_words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    # If the media line contains '<unknown' in the middle,
    # current_if['media_select']

# Generated at 2022-06-11 03:11:20.663462
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    words = ['media:', 'none']
    current_if_ref = {'media': 'Unknown', 'media_select': 'none'}
    dn.parse_media_line(words, current_if, ips)
    assert current_if == current_if_ref

    words = ['media:', 'auto', '(none)']
    current_if_ref = {'media': 'Unknown', 'media_select': 'auto', 'media_type': '(none)'}
    dn.parse_media_line(words, current_if, ips)
    assert current_if == current_if_ref

    words = ['media:', 'auto', '(none)', 'status:', 'active']

# Generated at 2022-06-11 03:11:27.232698
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface_data = {'name': 'loopback', 'inet': [], 'inet6': []}
    line = 'media: autoselect (<unknown type>)'
    iface = DarwinNetwork()
    iface.parse_media_line(line.split(), iface_data, None)
    assert iface_data['media'] == 'Unknown'
    assert iface_data['media_select'] == 'autoselect'
    assert iface_data['media_type'] == 'unknown type'
    assert iface_data['media_options'] is None

# Generated at 2022-06-11 03:11:33.844254
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Arrange
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive', 'last', 'cleared', 'Thu', 'Aug', \
             '1', '14:29:45', '2019']

    # Act
    current_if_with_unknown_type = {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type'
    }
    current_if = {}
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, None)

    # Assert
    assert current_if == current_if_with_unknown_type

# Generated at 2022-06-11 03:11:38.905874
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    ips = {}

    # Test for line: media: <unknown type>
    # Result: media_select = 'Unknown' and media_type = 'unknown type'
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, ips)
    assert(current_if['media_select'] == 'Unknown')
    assert(current_if['media_type'] == 'unknown type')

# Generated at 2022-06-11 03:11:47.540512
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test 1
    words_1 = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if_1 = {}
    ips_1 = {}
    network_1 = DarwinNetwork()
    network_1.parse_media_line(words_1, current_if_1, ips_1)
    assert current_if_1['media'] == 'Unknown'
    assert current_if_1['media_select'] == 'autoselect'
    assert current_if_1['media_type'] == '(none)'
    assert current_if_1['media_options'] == None

    # Test 2
    words_2 = ['media:', '10baseT/UTP', '(<unknown type>)', 'status:', 'inactive']
    current_if_2 = {}
    

# Generated at 2022-06-11 03:11:57.251783
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test function parse_media_line() with various ifconfig output lines
    """
    ifconfig_out = {
        'media': '1000baseTX <full-duplex>',
        'media_select': '1000baseTX',
        'media_type': 'full-duplex',
        'media_options': None,
    }
    media_line = "media: 1000baseTX <full-duplex>"
    words = media_line.split()
    current_if = dict()
    ips = dict()
    ifconfig_cls = DarwinNetwork()
    ifconfig_cls.parse_media_line(words, current_if, ips)
    assert ifconfig_out == current_if, ifconfig_cls.parse_media_line.__doc__ + " failed"

# Generated at 2022-06-11 03:12:05.938030
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    facts = {'default_ipv4': {'address': '192.0.2.1'}}
    darwin_network = DarwinNetwork(facts)
    current_if = {'name': 'eth0'}

    darwin_network.parse_media_line(['media:', 'Ethernet', 'autoselect'], current_if, ['192.0.2.1'])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == 'autoselect'
    assert current_if['media_options'] == {}

    # Should handle the case where media_type is a single word -
    # note that this is not a typical case for MacOS.
    darwin_network.parse_media_

# Generated at 2022-06-11 03:12:11.040281
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ds = DarwinNetwork()
    interface = {}
    ds.parse_media_line(["<unknown" , "type>", "none", "none"], interface)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'Unknown'
    assert interface['media_type'] == 'unknown type'
    assert 'media_options' not in interface

# Generated at 2022-06-11 03:12:18.414601
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    first = ['media', 'autoselect', 'status:', 'inactive']
    second = ['media', '<unknown', 'type>']

    DarwinNetwork.parse_media_line(first, current_if, None)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == 'status:'

    DarwinNetwork.parse_media_line(second, current_if, None)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:12:34.156612
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    media_line_1 = ['media:', 'autoselect', '(100baseTX)', 'status:', 'active']
    media_line_2 = ['media:', '<unknown', 'type>', 'status:', 'active']
    current_if = {}
    ips = {}
    dn.parse_media_line(media_line_1, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == []
    current_if = {}
    dn.parse_media_line(media_line_2, current_if, ips)

# Generated at 2022-06-11 03:12:44.267636
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork
    """
    macos_10_12 = DarwinNetwork()
    macos_10_13 = DarwinNetwork()
    macos_10_14 = DarwinNetwork()
    macos_10_15 = DarwinNetwork()
    macos_bridge = DarwinNetwork()

    # for macOS 10.12 and 10.13, output of ifconfig command is:
    # 'media: <unknown type> <full-duplex>' (string)
    # macOS 10.14 and 10.15 output:
    # 'media: autoselect (none)' (string)
    # bridge output is:
    # 'media: <unknown type> <full-duplex>' (string)
    # 'media: <unknown type> (<unknown subtype>)' (string)
    macos_10_

# Generated at 2022-06-11 03:12:53.357644
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # not sure if this method is useful - we drop information
    n = DarwinNetwork()

    # no media line, no current if
    media_line = None
    current_if = {}
    ips = []
    result = n.parse_media_line(words=None, current_if=current_if, ips=ips)
    assert not result

    # no media line, no current if
    media_line = None
    current_if = {}
    ips = []
    result = n.parse_media_line(words=None, current_if=current_if, ips=ips)
    assert not result

    # no media line, no current if
    media_line = ""
    current_if = {}
    ips = []

# Generated at 2022-06-11 03:12:58.003545
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['<unknown', 'type>']
    current_if = dict()
    ips = dict()
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:13:03.380284
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = {}
    ifc = ["media:", "autoselect", "(none)", "", "status:", "inactive"]
    ips = []
    for word in ifc:
        network.parse_media_line(word, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': None}

# Generated at 2022-06-11 03:13:12.633368
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_network = DarwinNetwork()
    mac_if = {}

    # First line:
    #   media: autoselect (1000baseT <full-duplex>)
    mac_network.parse_media_line(['media:', 'autoselect', '(1000baseT', '<full-duplex>)'], mac_if, {})
    assert mac_if['media'] == 'Unknown'  # Mac does not give us this
    assert mac_if['media_select'] == 'autoselect'
    assert mac_if['media_type'] == '1000baseT'
    assert mac_if['media_options'] == ['full-duplex']

    # Second line:
    #   media: <unknown type> (none)
    mac_if = {}

# Generated at 2022-06-11 03:13:17.662653
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Set up test input
    dn = DarwinNetwork()
    current_if = {'media': 'Unknown'}
    words = ['media', 'auto', '<unknown', 'type>']
    # Check the result
    dn.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None

# Generated at 2022-06-11 03:13:23.477416
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["media:", "<unknown", "type>"]
    current_if = {}
    ips = None
    # parse words
    DarwinNetwork.parse_media_line(None, words=words, current_if=current_if, ips=ips)
    # compare result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:13:31.636667
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_DarwinNetwork_parse_media_line_obj = DarwinNetwork()
    media_line = [
        'media:', 'autoselect', '(none)',
        'status:', 'inactive'
    ]
    current_if = {
        'device': 'lo0', 'inet': ['127.0.0.1']
    }
    ips = {}
    test_DarwinNetwork_parse_media_line_obj.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == []



# Generated at 2022-06-11 03:13:36.724339
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:14:02.508941
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '<unknown>', '(media)']
    current_if = dict()
    ips = dict()
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert(current_if['media'] == 'Unknown')
    assert(current_if['media_select'] == 'autoselect')
    assert(current_if['media_options'] == 'media')
    words = ['media:', 'autoselect', '<unknown type>', '(media)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert(current_if['media_type'] == 'unknown type')

# Generated at 2022-06-11 03:14:10.242885
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    desired_result = {'media_select': '1000baseT', 'media_type': 'full-duplex', 'media_options': 'none'}
    input = ['media:', '1000baseT', 'full-duplex', '(none)']
    d1 = DarwinNetwork()
    d1.parse_media_line(input, {}, {})
    assert d1.current_if == desired_result, 'test_DarwinNetwork_parse_media_line_a failed'

    desired_result = {'media_select': '1000baseT', 'media_type': 'full-duplex', 'media_options': 'master'}
    input = ['media:', '1000baseT', 'full-duplex', '(master)']
    d1 = DarwinNetwork()
    d1.parse_media_line(input, {}, {})