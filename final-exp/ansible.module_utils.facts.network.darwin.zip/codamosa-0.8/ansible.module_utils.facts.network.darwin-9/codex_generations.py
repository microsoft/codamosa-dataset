

# Generated at 2022-06-11 03:04:19.297024
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork({})
    darwin_network.parse_media_line(['media:','autoselect','','status:','inactive'],{},'')
    assert darwin_network.current_if['media'] == 'Unknown'
    assert darwin_network.current_if['media_select'] == 'autoselect'
    assert darwin_network.current_if['media_type'] == ''
    assert darwin_network.current_if['media_options'] == ''

    darwin_network.parse_media_line(['media:','none','','status:','inactive'],{},'')
    assert darwin_network.current_if['media'] == 'Unknown'
    assert darwin_network.current_if['media_select'] == 'none'
   

# Generated at 2022-06-11 03:04:29.097677
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ''' test DarwinNetwork.parse_media_line() '''
    darwin_net = DarwinNetwork()
    # test media line parsing with valid input
    line  = 'media: autoselect (<unknown type>)'
    words = line.split()
    current_if = {}
    darwin_net.parse_media_line(words, current_if)
    assert current_if['media_select'] == 'autoselect', \
        "Can't parse the media_select for input '%s'" % line
    assert current_if['media'] == 'Unknown', \
        "Can't parse the media for input '%s'" % line
    assert current_if['media_type'] == 'unknown type', \
        "Can't parse the media_type for input '%s'" % line
    assert not 'media_options' in current

# Generated at 2022-06-11 03:04:30.316796
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    test_object = DarwinNetwork()
    assert test_object


# Generated at 2022-06-11 03:04:30.967696
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    net = DarwinNetwork()

# Generated at 2022-06-11 03:04:32.712636
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network=DarwinNetwork()
    assert darwin_network != None


# Generated at 2022-06-11 03:04:43.437909
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    d = DarwinNetwork('lo0')
    assert d.platform == 'Darwin'
    assert d.interface == 'lo0'
    assert d.module == 'netifaces'
    assert d.cache_expiration == 3600  # seconds
    assert d.flags == ['LOOPBACK', 'UP', 'RUNNING']
    assert d.inet is ['127.0.0.1']
    assert d.inet6 is ['::1']
    assert d.macaddr is None
    assert d.broadcast is None
    assert d.netmask is ['255.0.0.0']
    assert d.metric is None
    assert d.mtu == 16384
    assert d.media is None
    assert d.media_select is None
    assert d.media_type is None
    assert d.media_options is None

# Generated at 2022-06-11 03:04:49.940833
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    network_collector = DarwinNetworkCollector()
    network_collector.collect()
    network = network_collector.get_network_facts()

# Generated at 2022-06-11 03:04:51.033619
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    # Arrange
    DarwinNetwork()



# Generated at 2022-06-11 03:04:52.553639
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    module = DarwinNetwork()
    assert module.platform == 'Darwin'

# Generated at 2022-06-11 03:05:03.172935
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_if = {'iface': 'bridge100'}
    my_if['media_select'] = 'manual'
    my_if['media_type'] = '100baseTX'
    my_if['media_options'] = '100baseTX media:100baseTX'

    dn = DarwinNetwork()
    dn.parse_media_line(['media:', 'manual', '100baseTX', 'media:100baseTX'], my_if, None)
    assert my_if['media_select'] == 'manual'
    assert my_if['media_type'] == '100baseTX'
    assert my_if['media_options'] == '100baseTX media:100baseTX'

    # Now test the special case of the bridge interface
    my_if['iface'] = 'bridge0'
    my_if

# Generated at 2022-06-11 03:05:10.253433
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    words = ['media:', '1000baseT', '<full-duplex>']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '1000baseT'
    assert current_if['media_type'] == 'full-duplex'

# Generated at 2022-06-11 03:05:19.636685
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    m_facts = DarwinNetwork()
    # Test for single word media_select
    # Test should not fail with this single word media_select
    media_select = ["media:", "autoselect"]
    actual_result = m_facts.parse_media_line(media_select, {}, {})
    expected_result = {'media': 'Unknown', 'media_select': 'autoselect'}
    assert expected_result == actual_result
    # Test with three words media_select media_type media_options
    media_select = ["media:", "autoselect", "1000baseT", "(none)"]
    actual_result = m_facts.parse_media_line(media_select, {}, {})

# Generated at 2022-06-11 03:05:29.995114
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test that DarwinNetwork parses media line correctly
    """
    # Create some words
    words1 = ["media:", "autoselect", "(cable)", "status:", "active"]
    words2 = ["media:", "<unknown", "type>", "status:", "active"]
    # Create a DarwinNetwork instance
    network = DarwinNetwork()
    # Populate current_if with test data
    current_if = {}
    current_if["media"] = ""
    current_if["media_select"] = ""
    current_if["media_type"] = ""
    current_if["media_options"] = []
    # Call method parse_media_line of the instance
    network.parse_media_line(words1, current_if, None)
    # Assert that the expected values are in current_if
    assert current

# Generated at 2022-06-11 03:05:40.490342
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # arrange
    network = DarwinNetwork()
    current_if_dict = {}
    words = ['media:', 'none', 'status:', 'inactive']
    # act
    new_current_if_dict = network.parse_media_line(words, current_if_dict)
    # assert
    assert new_current_if_dict['media'] == 'Unknown'
    assert new_current_if_dict['media_select'] == 'none'
    assert new_current_if_dict['media_type'] is None
    assert new_current_if_dict['media_options'] is None

    # arrange
    network = DarwinNetwork()
    current_if_dict = {}
    words = ['media:', 'autoselect', 'status:', 'inactive']
    # act

# Generated at 2022-06-11 03:05:50.086811
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    current_if = dict()
    ips = dict()
    words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == '(none)'
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'


# Generated at 2022-06-11 03:06:01.206780
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_darwin_network = DarwinNetwork()
    test_darwin_network.parse_media_line(['media:', 'none', 'status:', 'inactive'], {}, [])

    # media_line = ['media:', 'autoselect']
    test_darwin_network.parse_media_line(['media:', 'autoselect', 'status:', 'inactive'], {}, [])

    # media_line = ['media:', 'autoselect', '(', 'none', ')', 'status:', 'inactive']
    test_darwin_network.parse_media_line(['media:', 'autoselect', '(', 'none', ')', 'status:', 'inactive'], {}, [])

    # media_line = ['media:', 'autoselect', '(', '1000baseT',

# Generated at 2022-06-11 03:06:07.543623
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # We use Mac OSX to test the function
    test_line = ['media: <unknown type>']
    test_dict = {}
    test_ip_interfaces = []
    DarwinNetwork().parse_media_line(test_line, test_dict,
                                     test_ip_interfaces)
    assert test_dict['media'] == 'Unknown'
    assert test_dict['media_select'] == 'Unknown'
    assert test_dict['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:15.653434
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['none', '<unknown', 'type>']
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    current_if = {}
    words = ['none', '<unknown', 'type>', '"a b c"']
    ips = {}
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-11 03:06:27.661669
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import json
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    my_object = DarwinNetwork()
    my_object.current_iface = {}
    my_object.ips = []
    my_object.alias = []
    my_object.parse_media_line(['media:', '<unknown', 'type>'], my_object.current_iface, my_object.ips)
    assert json.dumps(my_object.current_iface, sort_keys=True) == '{"media": "Unknown", "media_options": {}, "media_select": "Unknown", "media_type": "unknown type"}'

    my_object.current_iface = {}
    my_object.ips = []
    my_object.alias = []

# Generated at 2022-06-11 03:06:37.326096
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # we simulate a result of ifconfig
    # actually all old parsing was just being replaced by this one method
    # additional cases can be added later
    # sample taken from MacOS 10.10.5
    words = ("media:", 'autoselect', '</unknown type>')
    current_if = {"name": "name"}
    ips = []
    media_info = DarwinNetwork.parse_media_line(words, current_if, ips)
    assert media_info['media'] == 'Unknown'
    assert media_info['media_select'] == 'autoselect'
    assert media_info['media_type'] == '/unknown type'
    assert media_info['media_options'] == ''

# Generated at 2022-06-11 03:06:46.234549
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: <unknown type> <full-duplex>'
    words = line.split()
    current_if = {}
    ips = set()
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == {'full-duplex': None}

# Generated at 2022-06-11 03:06:55.398423
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test parse_media_line method of DarwinNetwork class"""
    darwin_network = DarwinNetwork()
    # test media_select, media_type, media_options
    words = ['none', '10baseT/UTP', '<unknown', 'type>']
    current_if = {'media_select': '', 'media_type': '', 'media_options': ''}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == '10baseT/UTP'
    assert current_if['media_type'] == 'Unknown'
    assert current_if['media_options'] == ''
    del current_if['media_select']
    del current_if['media_type']

# Generated at 2022-06-11 03:07:05.549773
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()
    assert test_object.parse_media_line(["ifconfig", "en0", "media", "autoselect", "(none)", "status:", "inactive"], {}, {}) == ({'media': 'Unknown', 'media_select': 'autoselect'}, {})
    assert test_object.parse_media_line(["ifconfig", "bridge0", "media:", "<unknown", "type>"], {}, {}) == ({'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'unknown type'}, {})

# Generated at 2022-06-11 03:07:14.971066
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    m = DarwinNetwork()

    # create a dummy interface with properties that parse_media_line relies on
    current_if = {
        'ipv4': []
    }

    # set of lines generated from MacOSX
    # (some lines have been edited to check that different words lengths are handled)

# Generated at 2022-06-11 03:07:23.885751
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork = __import__('ansible.module_utils.facts.network.darwin.DarwinNetwork', globals(), locals(), [], -1).DarwinNetwork
    media_line_list = [['media:', 'autoselect', '<unknown', 'type>'],
                       ['media:', 'autoselect', '(100baseTX)'],
                       ['media:', 'autoselect', '(1000baseT)']]
    result = { 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type',
               'media_options': '', 'tcp_offload': '', 'encapsulation': '', 'tunnel_type': ''}
    assert DarwinNetwork.parse_media_line(media_line_list[0]) == result

# Generated at 2022-06-11 03:07:32.867272
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = dict()

    iface['media'] = 'Unknown'
    assert iface['media'] == 'Unknown'
    iface['media_select'] = '10baseT/UTP'
    assert iface['media_select'] == '10baseT/UTP'
    iface['media_type'] = '<unknown type>'
    assert iface['media_type'] == '<unknown type>'

    iface['media'] = 'Unknown'
    assert iface['media'] == 'Unknown'
    iface['media_select'] = '10baseT/UTP'
    assert iface['media_select'] == '10baseT/UTP'
    iface['media_type'] = '-'
    assert iface['media_type'] == '-'

# Generated at 2022-06-11 03:07:39.639087
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '<unknown type>', '(none)']
    current_if = {}
    ips = {}
    darwin = DarwinNetwork(None, None)
    darwin.parse_media_line(words, current_if, ips)
    # On MacOSX the media line is parsed differently than on FreeBSD
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == ['none']

# Generated at 2022-06-11 03:07:46.482733
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Given
    test_class = DarwinNetwork(None, None)
    # When
    test_class.parse_media_line(['<unknown type>', 'autoselect', 'status:', 'active'], {}, [])
    # Then
    assert test_class.current_if['media_select'] == 'autoselect'
    assert test_class.current_if['media_type'] == "unknown type"
    assert test_class.current_if['media_options'] == {'status': 'active'}

# Generated at 2022-06-11 03:07:56.550043
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    words = ["media:", "<unknown", "type>", "status:", "active"]
    current_if = {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>', 'media_data': 'None', 'media_data_bus': 'None', 'media_options': []}
    # test case 1
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': '<unknown', 'media_type': 'type>', 'media_data': 'None', 'media_data_bus': 'None', 'media_options': []}

    words = ["media:", "autoselect", "EEPROM", "status:", "active"]


# Generated at 2022-06-11 03:08:02.888598
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    dn.parse_media_line(['media:', 'media_select', 'media_type', 'media_options'], {}, {})
    assert dn.interface['media'] == 'Unknown'
    assert dn.interface['media_select'] == 'media_select'
    assert dn.interface['media_type'] == 'media_type'
    assert dn.interface['media_options'] == 'media_options'

    dn.parse_media_line(['media:', 'media_select', 'media_type'], {}, {})
    assert dn.interface['media'] == 'Unknown'
    assert dn.interface['media_select'] == 'media_select'
    assert dn.interface['media_type'] == 'media_type'

# Generated at 2022-06-11 03:08:14.106919
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = "media: <unknown type>".split()
    dn = DarwinNetwork()

    current_if = {'media': 'unknown', 'media_select': 'unknown'}
    ips = {}
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'unknown'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    current_if = {'media': 'unknown', 'media_select': 'unknown'}
    ips = {}
    media_line = "media: autoselect (<unknown type>)".split()
    dn.parse_media_line(media_line, current_if, ips)

# Generated at 2022-06-11 03:08:23.908771
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # the input media line
    line = 'media: <unknown type>'
    # create a instance of DarwinNetwork to test
    darwin_network = DarwinNetwork()
    # create a empty dict
    dic = {}
    # set word to be the input media line, split by space
    words = line.split()
    darwin_network.parse_media_line(words, dic, None)

    # the init result would be:
    # 1.media = 'Unknown'
    # 2.media_select = '<unknown'
    # 3.media_type = 'type>'
    # 4.media_options = None

    media_select = dic['media_select']
    media_type = dic['media_type']

    assert darwin_network.media == 'Unknown'

# Generated at 2022-06-11 03:08:33.467044
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    # Test a media line that has one option
    line = 'media: autoselect (1000baseT <full-duplex>)'
    iface.parse_media_line(line.split(), {}, None)
    assert iface.current_if['media'] == 'Unknown'
    assert iface.current_if['media_select'] == 'autoselect'
    assert iface.current_if['media_type'] == '1000baseT'
    assert iface.current_if['media_options'] == {'full-duplex': ''}
    # Test a media line with multiple options
    line = 'media: autoselect <full-duplex> <txpause> <rxpause>'
    iface.parse_media_line(line.split(), {}, None)
    assert iface.current

# Generated at 2022-06-11 03:08:42.345954
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Unit test for method parse_media_line of class DarwinNetwork"""
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    dn = DarwinNetwork()


# Generated at 2022-06-11 03:08:52.024553
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'up']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

    words = ['media:', 'autoselect', '(1000baseT', 'full-duplex,flow-control,encap)', 'status:', 'active']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
   

# Generated at 2022-06-11 03:08:57.765441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    darwin_network = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']

    darwin_network.parse_media_line(words, current_if, 0)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
# end of unit test

# Generated at 2022-06-11 03:09:05.828421
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # no media_line
    device = {'device': 'bridge0'}
    media_line = ''
    expected_media_line = {'device': 'bridge0', 'media_select': 'Unknown', 'media_type': 'unknown type',
                           'media': 'Unknown'}
    mac = DarwinNetwork(device)
    mac.parse_media_line(media_line, device)
    assert device == expected_media_line
    # test 1st special case:
    device = {'device': 'bridge1'}
    media_line = ['10baseT/UTP <unknown type>', 'link', 'auto']
    expected_media_line = {'device': 'bridge1', 'media_select': '10baseT/UTP', 'media_type': 'unknown type',
                           'media': 'Unknown'}


# Generated at 2022-06-11 03:09:14.014499
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    os_network = DarwinNetwork()

    # create mock ifconfig output line
    line_a_media = "media: <unknown type>\n"
    line_a_media_words = ['media:', '<unknown', 'type>']

    # create mock ifconfig output line
    line_b_media = "media: 10baseT/UTP <full-duplex>\n"
    line_b_media_words = ['media:', '10baseT/UTP', '<full-duplex>']

    # create mock current_if dict
    current_if = {}

    # call parse_media_line with line and current_if
    os_network.parse_media_line(line_a_media_words, current_if)

    # check if current_if contains correct values

# Generated at 2022-06-11 03:09:22.000372
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    dn = DarwinNetwork(NetworkCollector)
    current_if = dict()
    # test standard case
    dn.parse_media_line(('media:', 'auto', '1000baseTX', 'full-duplex'), current_if, None)
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '1000baseTX'
    assert current_if['media_options'] == 'full-duplex'
    assert 'media' not in current_if
    # test bridge case
    dn.parse_media_line(('media:', '<unknown', 'type>'), current_if, None)

# Generated at 2022-06-11 03:09:29.127909
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # The below string is a line from the output of ifconfig -a as ran on macOS 10.15.2
    s = "media: autoselect <unknown type>"
    words = s.split()

    current_if = dict()
    ips = dict()

    # Test media line parsing
    DarwinNetwork.parse_media_line(DarwinNetwork, words, current_if, ips)

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:09:39.732833
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifconfig_output = {
        'en0': [
            'media: autoselect (<unknown type>)\n',
        ],
    }
    expected_ifdict = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type'}
    dn = DarwinNetwork(ifconfig_output)
    current_if = {}
    dn.parse_media_line(['media:', 'autoselect', '(<unknown type>)'], current_if, {})
    assert current_if == expected_ifdict

# Generated at 2022-06-11 03:09:48.592941
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_DarwinNetwork = DarwinNetwork()
    test_words = []
    test_iface = {}
    test_ips = {}
    # set a few items in test_iface to check that they are untouched
    test_iface['media'] = 'hello'  # will be overwritten
    test_iface['media_select'] = 'hello'  # will be overwritten
    test_iface['media_type'] = 'hello'  # will be overwritten
    test_iface['media_options'] = 'hello'  # will be overwritten
    assert test_DarwinNetwork.parse_media_line(test_words, test_iface, test_ips) is None
    assert test_iface['media'] == 'Unknown'
    assert test_iface['media_select'] == 'hello'
    assert test_iface

# Generated at 2022-06-11 03:09:55.950776
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:10:05.342431
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetworkCollector()
    data = []
    current_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': None}
    ips = {}
    darwin_network.parse_media_line(data, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': None, 'media_type': None, 'media_options': None}

# Generated at 2022-06-11 03:10:14.877468
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()

    # Tests a bridge interface
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

    # Tests an en0 interface
    words = ['media:', 'autoselect', '100baseTX', '(full-duplex,rxpause)'
             'status:', 'active']
    current_if = {}
    ips = []

# Generated at 2022-06-11 03:10:21.055327
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    networkObj = DarwinNetwork()
    interface = {}
    # basic
    words = ['media:', 'autoselect', '(100baseTX)']
    interface = networkObj.parse_media_line(words, interface, [])
    assert('media'       in interface)
    assert('media_select'in interface)
    assert('media_type'  in interface)
    assert('media_options' not in interface)
    assert(interface['media'] == 'Unknown')
    assert(interface['media_select'] == 'autoselect')
    assert(interface['media_type'] == '100baseTX')

    # options
    words = ['media:', '10baseT/UTP', '(10baseT)']
    interface = networkObj.parse_media_line(words, interface, [])
    assert('media_options' in interface)

# Generated at 2022-06-11 03:10:29.767944
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    result = net.parse_media_line(['media:','autoselect','','status:','inactive'], {}, {})
    assert result['media_select'] == 'autoselect'
    assert 'media_type' not in result
    assert 'media_options' not in result
    result = net.parse_media_line(['media:','autoselect','<unknown type>','status:','inactive'], {}, {})
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == 'unknown type'
    assert 'media_options' not in result
    result = net.parse_media_line(['media:','autoselect','10baseT/UTP','status:','inactive'], {}, {})

# Generated at 2022-06-11 03:10:35.302676
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test case for parse_media_line method of DarwinNetwork class
    """
    test_obj = DarwinNetwork()
    # Test case for parse_media_line with type unknown
    words = ['media', '<unknown', 'type>']
    current_if = dict()
    ips = dict()
    expected_dict = {'media': 'Unknown'}
    test_obj.parse_media_line(words, current_if, ips)
    assert current_if == expected_dict

# Generated at 2022-06-11 03:10:42.000251
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    module_input = dict()
    module_input['media_select'] = 'autoselect'
    module_input['media_type'] = '10baseTX'
    module_input['media_options'] = 'none'
    test_if = dict(
        name='en0',
        type='ethernet',
        macaddress='00:00:00:00:00:00',
        wakeonlan=False,
    )
    m_dw = DarwinNetwork(module_input)
    m_dw.parse_media_line(['media:', 'autoselect', '(10baseTX)'], test_if, dict())
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '10baseTX'

# Generated at 2022-06-11 03:10:51.009755
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    media_line = ['media:', 'auto', '(none)', 'status:', 'inactive']
    current_if = {'name': 'en0', 'media': {} }
    ips = []
    dn.parse_media_line(media_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == []

    media_line = ['media:', 'autoselect', '<unknown', 'type>']
    current_if = {'name': 'en0', 'media': {} }
    ips = []

# Generated at 2022-06-11 03:11:09.995376
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    media = []
    media.append('media: <unknown type> status: inactive')
    media.append('media: autoselect (1000baseT <full-duplex>) status: active')
    media.append('media: autoselect (1000baseT <full-duplex>, 100baseTX <full-duplex>, 10baseT <full-duplex>, 10baseT-FDX, 100baseTX-FDX, 1000baseT-FDX <full-duplex>) status: active')

    for m in media:
        words = m.split()
        current_if = {}
        current_if['media'] = 'Unknown'  # Mac does not give us this
        dn.parse_media_line(words, current_if, None)

# Generated at 2022-06-11 03:11:18.784792
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin = DarwinNetwork()
    # Check bridge interface media line
    line = 'media: <unknown type>'
    darwin.parse_media_line(line.split(), {'type': 'bridge'}, [])
    assert darwin.current_if['media'] == 'Unknown'
    assert darwin.current_if['media_select'] == 'Unknown'
    assert darwin.current_if['media_type'] == 'unknown type'
    # Check standard interface media line
    darwin.current_if = {}
    line = 'media: autoselect (100baseTX <full-duplex>) status: inactive'
    darwin.parse_media_line(line.split(), {}, [])
    assert darwin.current_if['media'] == 'Unknown'
    assert darwin.current_

# Generated at 2022-06-11 03:11:23.722796
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:','<unknown','type>'], {}, {})

    assert ifc.interfaces['bridge0']['media'] == 'Unknown'
    assert ifc.interfaces['bridge0']['media_select'] == '<unknown'
    assert ifc.interfaces['bridge0']['media_type'] == 'type>'

# Generated at 2022-06-11 03:11:30.846301
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:11:38.437534
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

# Generated at 2022-06-11 03:11:47.211193
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:11:57.021331
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

# Generated at 2022-06-11 03:12:05.715319
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    x = DarwinNetwork()
    y = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'None', 'media_options': {}}
    assert x.parse_media_line(['media:', 'autoselect'], {}, {}) == y
    assert x.parse_media_line(['media:', '10baseT/UTP', '(none)'], {}, {}) == y
    assert x.parse_media_line(['media:', '10baseT/UTP', '(none)'], {}, {}) == y
    assert x.parse_media_line(['media:', '10baseT/UTP'], {}, {}) == y
    assert x.parse_media_line(['media:', '<unknown', 'type>'], {}, {}) == y
    assert x

# Generated at 2022-06-11 03:12:15.853955
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:','<unknown','type>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if
    current_if = {}
    dn.parse_media_line(['media:','Wi-Fi','Configured', 'autoselect'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Wi-Fi'
    assert current_if['media_type'] == 'Configured'

# Generated at 2022-06-11 03:12:26.003811
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    mac = DarwinNetwork()

    mac.parse_media_line(['media:', '<unknown', 'type>'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    mac.parse_media_line(['media:', 'autoselect', '(none)'], current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert 'media_options' not in current_if

    mac

# Generated at 2022-06-11 03:12:44.270708
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork(None)
    test_if = {'media': 'Unknown', 'media_select': 'none',
               'media_type': 'none', 'media_options': []}
    network.parse_media_line(['media:', 'none', '(none)'], test_if, None)
    assert test_if == {'media': 'Unknown', 'media_select': 'none',
               'media_type': 'none', 'media_options': []}

    network.parse_media_line(['media:', '1000baseT', '(none)'], test_if, None)
    assert test_if == {'media': 'Unknown', 'media_select': '1000baseT',
               'media_type': 'none', 'media_options': []}


# Generated at 2022-06-11 03:12:53.396870
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:12:59.968776
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    media_line = ['media:', 'select', '<unknown type>']
    darwin_network.parse_media_line(media_line, darwin_network.current_if, darwin_network.interfaces)
    assert darwin_network.current_if.get('media') == 'Unknown'
    assert darwin_network.current_if.get('media_select') == 'select'
    assert darwin_network.current_if.get('media_type') == 'unknown type'
    assert darwin_network.current_if.get('media_options') is None

# Generated at 2022-06-11 03:13:09.318414
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import json

# Generated at 2022-06-11 03:13:17.492973
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words
    current_if = {}
    DarwinNetwork().parse_media_line(['media:', '<unknown', 'type>', 'status:', 'inactive'], current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    # This is the normal case
    current_if = {}
    DarwinNetwork().parse_media_line(['media:', 'autoselect', '(none)', 'status:', 'active'], current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'none'}

# Generated at 2022-06-11 03:13:26.431620
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_ips = {}
    test_words = [u'inet6', u'fe80::224:e9ff:fe00:117%en0', u'prefixlen', u'64', u'autoconf', u'privacy', u'autohome']
    DarwinNetwork().parse_media_line(test_words, test_if, test_ips)
    assert 'Unknown' == test_if['media']

    test_words = [u'media:', u'autoselect', u'(none)', u'status:', u'inactive']
    DarwinNetwork().parse_media_line(test_words, test_if, test_ips)
    assert 'none' == test_if['media_select']
    assert 'Unknown' == test_if['media']


# Generated at 2022-06-11 03:13:34.483764
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a temporary instance of DarwinNetwork
    d = DarwinNetwork()

    # Create a temporary dict for holding current interface
    current_if = dict()

    # Create a temporary dict for holding all interfaces
    interfaces = dict()

    # Test only 'media_select' has been set
    words = ['media:', 'autoselect']
    ips = dict()
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # Test only 'media_select' and 'media_type' have been set
    words = ['media:', 'autoselect', '(none)']
    d

# Generated at 2022-06-11 03:13:38.212790
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_instance = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {'media': 'Unknown', 'media_select': '<unknown'}
    ips = {}
    test_instance.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_type': 'unknown type', 'media_select': 'Unknown'}
    assert ips == {}

# Generated at 2022-06-11 03:13:46.457252
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_words = ['media', '<unknown', 'type>', 'status:', 'inactive', 'lladdr', '00:00:00:00:00:00',
                  'class', 'I', 'priority:', '4', 'wired', 'mtu', '1500', 'security', 'none',
                  'power', 'off', 'current', 'media:', '<unknown', 'type>']

# Generated at 2022-06-11 03:13:54.671848
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['firewire0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'ether', '00:00:00:00:00:00', 'media', '<unknown type>']
    current_if = {}
    ips = {}
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ips
    assert current_if['media'] == 'Unknown'


# Generated at 2022-06-11 03:14:10.988783
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create test instance of DarwinNetwork class
    test_DarwinNetwork = DarwinNetwork()
    test_if = {}
    test_ips = {}
    # create test input argument list (split whitepaces is default)
    test_in = ['media:', 'autoselect', '(none)', '']
    # run tested class method
    test_DarwinNetwork.parse_media_line(test_in, test_if, test_ips)
    # check the result
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '(none)'
    assert test_if['media_options'] == []
    # create test input argument list (split whitepaces is default)