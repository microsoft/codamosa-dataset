

# Generated at 2022-06-11 03:04:24.581988
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test that the method parse_media_line of class DarwinNetwork correctly
    parses a string with media information.
    """
    d = DarwinNetwork()
    current_if = dict()
    d.parse_media_line('media: <unknown type> status: inactive', current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'
    assert not current_if.get('media_options')
    current_if = dict()
    d.parse_media_line('media: 10baseT/UTP status: inactive', current_if, {})
    assert current_if['media'] == '10baseT/UTP'

# Generated at 2022-06-11 03:04:34.972487
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    #setup test object
    module = DarwinNetwork()
    current_if = {}
    #test 1
    words = ["media:", "autoselect", "(none)"]
    ips = ""
    assert(module.parse_media_line(words, current_if, ips) == None)
    assert(current_if['media_select'] == "autoselect")
    assert('media' not in current_if)
    assert('media_type' not in current_if)
    assert('media_options' not in current_if)

    #test 2
    words = ["media:", "Ethernet", "autoselect"]
    ips = ""
    assert(module.parse_media_line(words, current_if, ips) == None)

# Generated at 2022-06-11 03:04:44.814690
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create the object
    dn = DarwinNetwork(None)
    current_if = {}
    dn.parse_media_line(['media:', 'Ethernet', 'autoselect'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Ethernet'
    assert current_if['media_type'] == 'autoselect'
    assert current_if['media_options'] is None
    current_if = {}
    dn.parse_media_line(['media:', '<unknown', 'type>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current

# Generated at 2022-06-11 03:04:55.252633
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test = DarwinNetwork()
    def test_parse_media_line(words, current_if, ips):
        return test.parse_media_line(words, current_if, ips)
    assert {'media': 'Unknown', 'media_select': 'media', 'media_type': 'auto'} == test_parse_media_line(["media:", "media", "auto"], {}, {})
    assert {'media': 'Unknown', 'media_select': 'media', 'media_type': 'auto', 'media_options': 'none'} == test_parse_media_line(["media:", "media", "auto", "none"], {}, {})
    assert {'media': 'Unknown', 'media_select': 'media', 'media_type': 'auto', 'media_options': 'none'} == test_parse_media_

# Generated at 2022-06-11 03:05:05.034174
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = {'media_select': '', 'media': '', 'media_options': '', 'media_type': '', 'ipv4': {}, 'ipv6': {}}

    # First test, check media info is written properly
    words = ['media:', '1000baseT', '(<unknown type>)', 'full-duplex,', '1000baseT-FDX,', 'auto,', '1000baseT-HDX']
    DarwinNetwork.parse_media_line(data, words)
    assert data['media_select'] == '1000baseT'
    assert data['media'] == 'Unknown'
    assert data['media_type'] == 'unknown type'
    assert data['media_options'] == 'full-duplex, 1000baseT-FDX, auto, 1000baseT-HDX'

    # Second test, check media info

# Generated at 2022-06-11 03:05:11.990117
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnet = DarwinNetwork()
    # media line with all information - '    media: autoselect (1000baseT <full-duplex>) status: active'
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    current_if = {'name': 'eth0'}
    ips = []
    dnet.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'
    assert current_if['media'] == 'Unknown'
    # media line with less information - '    media: autoselect status: active'
    words

# Generated at 2022-06-11 03:05:20.692253
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_if['name'] = 'lo0'
    d = DarwinNetwork()
    test_words = ['media:', '<unknown', 'type>']
    d.parse_media_line(test_words, test_if, '')
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    test_words = ['media:', 'autoselect', '(1000baseT)']
    d.parse_media_line(test_words, test_if, '')
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'autoselect'
    assert test_if['media_type'] == '(1000baseT)'
    test

# Generated at 2022-06-11 03:05:30.939410
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    iface = {}
    # Test 1
    d.parse_media_line(['media:', 'autoselect', '(none)'], iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '(none)'
    # Test 2
    d.parse_media_line(['media:', 'autoselect'], iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'Unknown'
    # Test 3
    d.parse_media_line(['media:', '<unknown', 'type>'], iface, None)

# Generated at 2022-06-11 03:05:40.840693
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w = DarwinNetwork()
    data = dict()
    data['media'] = ''
    data['media_select'] = ''
    data['media_type'] = ''
    data['media_options'] = ''
    # split line into words
    words = ["media:", "autoselect", "10baseT/UTP"]
    # method to test
    w.parse_media_line(words, data, None)
    assert data['media_select'] == 'autoselect'
    assert data['media_type'] == '10baseT/UTP'
    assert data['media'] == 'Unknown'
    assert data['media_options'] == ''
    # test media line with options
    data['media_select'] = ''
    data['media_type'] = ''

# Generated at 2022-06-11 03:05:50.087293
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    #Construct DarwinNetwork object
    test_object = DarwinNetwork()

    #Construct media_line
    media_line = 'media: <unknown type>'

    #Split media_line into words
    words = media_line.split()

    #Construct current_if object with media_line
    current_if = {"media_line": media_line }

    #Construct ips object with media_line
    ips = {"media_line": media_line}

    #Invoke method under test
    test_object.parse_media_line(words, current_if, ips)

    #Test against expected_result
    expected_result = {'media': 'Unknown', 'media_select': 'media', 'media_type': 'unknown type'}
    assert(current_if == expected_result)