

# Generated at 2022-06-11 03:04:23.233279
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Setup the test
    d = DarwinNetwork()
    ips = dict()
    current_if = dict()

    # Test the standard media line
    words = ['media:', 'autoselect', '(none)']
    current_if['media_select'] = ''
    current_if['media_type'] = ''
    current_if['media_options'] = ''
    d.parse_media_line(words, current_if, ips)
    # assert current_if == {'media_select': 'autoselect', 'media_type': 'none'}
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == ''

    # Test the media line with options

# Generated at 2022-06-11 03:04:27.249864
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = []
    words = ['media:', 'none', 'supported', 'media', 'unknown']
    collector = DarwinNetwork()
    collector.parse_media_line(words, current_if, ips)
    assert current_if['media_options'] == ['unknown']


# Generated at 2022-06-11 03:04:37.404181
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    my_obj = DarwinNetwork()
    my_if = {}
    my_ips = {}
    assert my_obj.parse_media_line(['media:', 'en0', 'auto'], my_if, my_ips) == None
    assert my_if['media'] == 'Unknown'
    assert my_if['media_select'] == 'en0'
    assert my_if['media_type'] == 'auto'

    assert my_obj.parse_media_line(['media:', '<unknown', 'type>'], my_if, my_ips) == None
    assert my_if['media'] == 'Unknown'
    assert my_if['media_select'] == 'Unknown'
    assert my_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:04:46.362100
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_obj = DarwinNetwork()
    test_input = ["media:", "auto", "(none)"]
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}

    darwin_network_obj.parse_media_line(test_input, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == ''


    test_input = ["media:", "auto", "1000baseTX", "full-duplex"]

# Generated at 2022-06-11 03:04:57.039553
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifmac = DarwinNetwork()

    ifstats = dict()
    ifstats['media'] = 'Unknown'
    ifstats['media_select'] = 'Ethernet autoselect'
    ifstats['media_type'] = 'status'
    ifstats['media_options'] = dict()

    # Same as FreeBSD, with space after Ethernet
    ifmac.parse_media_line(words=['media:', 'Ethernet', 'autoselect', 'status'], current_if=ifstats, ips=dict())
    assert ifstats['media'] == 'Unknown'
    assert ifstats['media_select'] == 'Ethernet'
    assert ifstats['media_type'] == 'autoselect'
    assert ifstats['media_options']['status'] == ''

    # MacOSX sets the media to '<unknown type>' for

# Generated at 2022-06-11 03:05:06.255797
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # Arrange
    words = ['media:', 'autoselect', '(100baseTX)']  # input list
    current_if = {'media': 'Unknown', 'media_select': '', 'media_type': '', 'media_options': ''}
    ips = {'test': {'ipv4': '[unknown]', 'ipv6': 'fe80::6fd:5bff:fe7f:f01a%awdl0', 'mac': 'a2:3c:69:19:da:a0'}}  # input dict
    expected_result = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX', 'media_options': ''} # expected result

    # Act

# Generated at 2022-06-11 03:05:12.514919
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    macos_if = {'ifname': 'lo0', 'if_type': 'loopback'}
    macos_if = DarwinNetwork.parse_media_line(['media:', '<unknown', 'type>'], macos_if, [])
    assert macos_if['media'] == 'Unknown'
    assert macos_if['media_select'] == 'Unknown'
    assert macos_if['media_type'] == 'unknown type'
    macos_if = {'ifname': 'en2', 'if_type': 'bridge'}
    macos_if = DarwinNetwork.parse_media_line(['media:', '<unknown', 'type>'], macos_if, [])
    assert macos_if['media'] == 'Unknown'
    assert macos_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:05:20.337297
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'auto', '<unknown type>']
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'auto',
                          'media_type': 'unknown type'}

    current_if = {}
    words = ['media:', '<unknown', 'type>']
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, None)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown',
                          'media_type': 'unknown type'}

# Generated at 2022-06-11 03:05:30.651697
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork_test = DarwinNetwork()
    if_bond0_test = dict(
        device='bond0',
        macaddress='aa:bb:cc:dd:ee:ff',
        inet='192.168.1.100',
        netmask='255.255.255.0',
        broadcast='192.168.1.255',
        inet6='fe80::8cba:1fff:fea9:6ff2',
        scope6='link',
        media='None',
        media_select='autoselect',
        media_type='ethernet',
        media_options=('none', 'none'),
    )
    assert DarwinNetwork_test.parse_media_line(('Ethernet',), if_bond0_test, []) == if_bond0_test
    if_lo

# Generated at 2022-06-11 03:05:40.613559
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    assert d.parse_media_line(["media:", "autoselect", "(none)"],
                              {'device': 'br0'},
                              {}) == {'device': 'br0', 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': {}}

    assert d.parse_media_line(["media:", "autoselect", "(1000baseT)"],
                              {'device': 'em0'},
                              {}) == {'device': 'em0', 'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(1000baseT)', 'media_options': {}}


# Generated at 2022-06-11 03:05:52.619220
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    m = d.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    assert m['media'] == 'Unknown'
    assert m['media_select'] == 'autoselect'
    assert m['media_type'] == '(none)'
    assert 'media_options' not in m

    m = d.parse_media_line(['media:', 'autoselect', '100baseTX', 'full-duplex,upsym_encap'], {}, {})
    assert m['media_select'] == 'autoselect'
    assert m['media_type'] == '100baseTX'
    assert m['media_options'] == 'full-duplex,upsym_encap'


# Generated at 2022-06-11 03:06:03.353676
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create an instance of the class
    this_if = DarwinNetwork()

    # create a list of words to test, and the result we expect
    word_list = [(['media:', '<unknown', 'type>', 'status:', 'active'], 'Unknown'),
                 (['media:', 'autoselect', 'nonegotiate', 'status:', 'active'], 'autoselect')]

    # create a list of interfaces
    ifs = []
    # fill it with empty dictionaries (we don't care about the content for this test)
    for i in range(0, 3):
        ifs.append({})

    for words, expected_result in word_list:
        # run the method to be tested
        this_if.parse_media_line(words, ifs[0], ifs[1])

        # check

# Generated at 2022-06-11 03:06:13.348024
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    lines = ['media: <unknown type>', 'media: autoselect (100baseTX <full-duplex>)', 'media: autoselect (100baseTX <half-duplex>)', 'media: autoselect (10baseT <half-duplex>)', 'media: autoselect (1000baseTX <full-duplex>)', 'media: autoselect (1000baseTX <half-duplex>)', 'media: autoselect <full-duplex>', 'media: 100baseTX <full-duplex>', 'media: autoselect <half-duplex>', 'media: 100baseTX <half-duplex>', 'media: 10baseT <half-duplex>']

# Generated at 2022-06-11 03:06:24.648504
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from collections import OrderedDict
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    ifconfig = GenericBsdIfconfigNetwork()
    expected_result = OrderedDict()
    expected_result['media'] = 'Unknown'
    expected_result['media_select'] = 'auto'
    expected_result['media_type'] = '10baseT/UTP'
    expected_result['media_options'] = {'100baseTX': '100baseTX', '10baseT': '10baseT', 'auto': 'auto', 'FDx': 'FDx', 'HDx': 'HDx', 'flow': 'flow', 'none': 'none'}

# Generated at 2022-06-11 03:06:31.791827
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Unit test for method parse_media_line of class DarwinNetwork

    """
    (words, current_if, ips) = (['media:', '<unknown', 'type>'],
                               dict(), dict())
    class_under_test = DarwinNetwork()
    class_under_test.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert len(current_if['media_options']) == 0

# Generated at 2022-06-11 03:06:42.670124
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    module = DarwinNetwork()
    iface = dict()
    ips = dict()
    # test regular case
    words = ['media:', 'autoselect', '(1000baseT)']
    iface = dict()
    module.parse_media_line(words, iface, ips)
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '1000baseT'
    assert iface['media_options'] == dict()
    # test if statement
    words = ['media:', '<unknown', 'type>']
    iface = dict()
    module.parse_media_line(words, iface, ips)
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:48.789231
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = ['media: <unknown type>\n', 'media: <unknown type> abcd\n', 'media: <unknown type> media_select \n']
    for datum in data:
        words = datum.split()
        current_if = {}
        DarwinNetwork.parse_media_line(None, words, current_if, None)
        if current_if['media_type'] != 'unknown type':
            raise AssertionError('Expected: unknown type got: {}'.format(current_if['media_type']))
test_DarwinNetwork_parse_media_line()



# Generated at 2022-06-11 03:06:58.261145
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', '(none)']
    current_if = {'name': 'en0', 'mtu': '1500'}
    ips = []
    DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    words = ['media:', '<unknown', 'type>', '(none)']
    current_if = {'name': 'bridge0', 'mtu': '1500'}
    DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current

# Generated at 2022-06-11 03:07:08.568148
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    t_DarwinNetwork = DarwinNetwork({})
    current_if = {}
    media_line = ['media:', 'autoselect', '(', '1000baseT', 'master', ')', 'full-duplex']
    t_DarwinNetwork.parse_media_line(media_line, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'master'

    media_line = ['media:', 'autoselect', '(', '10baseT', ')', 'full-duplex']
    t_DarwinNetwork.parse_media_line(media_line, current_if, {})
    assert current_if

# Generated at 2022-06-11 03:07:17.010002
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    darwin_net = DarwinNetwork('lo0')
    ips = []
    words = ['media:', 'autoselect (100baseTX <full-duplex>)',
             '(status:', 'active)']
    result = darwin_net.parse_media_line(words, current_if, ips)

    assert result == None
    assert 'media' not in current_if
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == ['full-duplex']
    assert current_if['media_status'] == 'active'
    assert current_if['media_capabilities'] == ['100baseTX', 'autoselect', 'full-duplex']

# Generated at 2022-06-11 03:07:33.895614
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()

    def test(data, expected_media_select, expected_media_type, expected_media_options):
        data['media'] = ''
        data['media_options'] = ''
        data['media_select'] = ''
        data['media_type'] = ''
        network.parse_media_line(words, data, '')
        assert data['media'] == 'Unknown'
        assert data['media_select'] == expected_media_select
        assert data['media_type'] == expected_media_type
        assert data['media_options'] == expected_media_options

    words = ['<unknown type>']
    test({}, '<unknown', 'type>', '')

    words = ['100baseTX', 'full-duplex']
    test({}, '100baseTX', 'full-duplex', '')

# Generated at 2022-06-11 03:07:44.295901
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:07:50.943302
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Configuration of test
    test_words = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    test_current_if = {}
    test_ips = []

    # Precondition: 'ifconfig' command output is parsed into words and selected data is stored in 'test_current_if' dictionary
    # Precondition: 'ifconfig' command output contains media information for the interface
    # Precondition: 'ifconfig' command output contains IPv4 or IPv6 address
    assert 'media' not in test_current_if
    assert 'media_select' not in test_current_if
    assert 'media_type' not in test_current_if
    assert 'media_options' not in test_current_if
    assert len(test_ips) > 0

    # Execute parse_media_line method
    DarwinNetwork

# Generated at 2022-06-11 03:07:56.997611
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_network = DarwinNetwork()
    test_network.parse_media_line('media: autoselect (100baseTX <full-duplex>)', {}, {})
    assert test_network.current_if['media_select'] == 'autoselect'
    assert test_network.current_if['media_type'] == '100baseTX'
    assert test_network.current_if['media_options'] == 'full-duplex'


# Generated at 2022-06-11 03:08:05.458765
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialize test data
    data = dict()
    # Initialize current_if dictionary
    current_if = dict()
    current_if['name'] = 'bge0'
    current_if['type'] = 'ether'
    current_if['macaddress'] = '00:00:00:00:00:00'
    current_if['mtu'] = 1500
    current_if['media'] = 'Unknown'
    # Initialize ips dictionary
    ips = dict()
    # Initialize class DarwinNetwork
    darwin_network = DarwinNetwork()
    # Test first media line
    darwin_network.parse_media_line(['media', 'media_select'], current_if, ips)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:08:14.474910
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'devname': 'lo0',
        'ipv4': [],
        'ipv6': []
    }

    # Test for media line with media name and media type
    result_if = {
        'devname': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'media': 'Unknown',
        'media_select': 'Fixed',
        'media_type': '1000baseT'
    }
    words = ['media:', 'Fixed', '(1000baseT)']
    DarwinNetwork().parse_media_line(words, current_if, {'ipv4': [], 'ipv6': []})
    assert current_if == result_if

    # Test for media line with media name, media type, and media options

# Generated at 2022-06-11 03:08:24.182734
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network = DarwinNetwork()
    network.parse_media_line('media: IEEE 802.11 Wireless Ethernet autoselect status: associated'.split(),
                             {}, {})
    media_select = 'media: IEEE 802.11 Wireless Ethernet autoselect'
    media_type = 'status: associated'
    assert media_select == network.current_if['media_select'], \
        'parse_media_line failed media_select check. Expected %s, got %s' \
        % (media_select, network.current_if['media_select'])
    assert media_type == network.current_if['media_type'], \
        'parse_media_line failed media_type check. Expected %s, got %s' \
        % (media_type, network.current_if['media_type'])

# Generated at 2022-06-11 03:08:33.680035
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    network_test = DarwinNetwork()
    current_if = {}
    
    # case 1: list words contains 4 elements
    media_line = "media: autoselect (1000baseT <full-duplex>) status: active"
    words = media_line.split()
    network_test.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'full-duplex'
    current_if = {}
    
    # case 2: list words contains 3 elements
    media_line = "media: autoselect (1000baseT)"
    words = media_line.split()
    network

# Generated at 2022-06-11 03:08:42.659411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = {}
    net = DarwinNetwork()
    net.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown',
                          'media_select': 'Unknown',
                          'media_type': 'unknown type',
                          'media_options': {}}
    words = ['media:', 'Autoselect', '(1000baseT', 'full-duplex,flow-control,txpause,rxpause)', 'status:', 'active']
    current_if = {}
    ips = {}
    net = DarwinNetwork()
    net.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:08:52.248284
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    result = {'media': 'Unknown', 'media_select': 'none', 'media_options': None}
    iface.parse_media_line(['media:', 'none'], {}, '')
    assert result == iface.current_if
    result = {'media': 'Unknown', 'media_select': 'manual',
              'media_type': '100baseTX', 'media_options': None}
    iface.parse_media_line(['media:', 'manual', '100baseTX'], {}, '')
    assert result == iface.current_if

# Generated at 2022-06-11 03:09:12.794629
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_current_if = {}

    # test for setting media, media_select, media_type & media_options
    test_words = [
        'media:', 'autoselect', '(none)', 'status:', 'active'
    ]
    test_current_if['media'] = None
    test_current_if['media_select'] = None
    test_current_if['media_type'] = None
    test_current_if['media_options'] = None
    DarwinNetwork._parse_media_line(test_current_if, test_words)
    assert test_current_if['media'] == 'Unknown'
    assert test_current_if['media_select'] == 'autoselect'
    assert test_current_if['media_type'] == '(none)'

# Generated at 2022-06-11 03:09:18.489682
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Parameters
    words = ['media:', '<unknown', 'type>']
    current_if = {'media': 'Unknown'}
    ips = {}
    # Call the parse_media_line method of DarwinNetwork
    DarwinNetwork(None).parse_media_line(words, current_if, ips)
    # Assertions
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None

# Generated at 2022-06-11 03:09:24.379215
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    assert DarwinNetwork().parse_media_line(['<unknown', 'type>'], {}, {}) == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    assert DarwinNetwork().parse_media_line(['autoselect', '(100baseTX)'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(100baseTX)'}
    assert DarwinNetwork().parse_media_line(['autoselect', '(100baseTX)', 'full-duplex'], {}, {}) == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(100baseTX)', 'media_options': ['full-duplex']}

# Generated at 2022-06-11 03:09:34.466087
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    Test parsing a media line
    '''

# Generated at 2022-06-11 03:09:43.544191
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = {}
    mac = DarwinNetwork()
    words = ['media:', 'autoselect', '(none)']
    mac.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}

    words = ['media:', 'autoselect', '(100baseTX)']
    mac.parse_media_line(words, current_if, ips)
    assert current_if['media_type'] == '(100baseTX)'

    words = ['media:', 'autoselect', '(100baseTX', 'full-duplex)']
    mac.parse_

# Generated at 2022-06-11 03:09:50.991084
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_string = '<unknown type>'
    words = media_string.split()
    darwin_network = DarwinNetwork()
    current_if = dict()
    ips = dict()
    darwin_network.parse_media_line(words, current_if, ips)
    assert len(current_if) == 3
    assert 'media' in current_if.keys()
    assert 'media_select' in current_if.keys()
    assert 'media_type' in current_if.keys()
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:09:57.455723
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = dict()
    data['media_select'] = ''
    data['media_type'] = ''
    data['media_options'] = []
    data['media'] = ''
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(["media:", "None", "(inactive)"], data, None)
    assert data['media_select'] == "None"
    assert data['media_type'] == ''
    assert data['media_options'] == ['inactive']
    assert data['media'] == 'Unknown'
    darwin_network.parse_media_line(["media:", "autoselect", "(nofdx,nopauses)"], data, None)
    assert data['media_select'] == "autoselect"

# Generated at 2022-06-11 03:10:07.059071
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # first test case - media line with all values for media_type, media_select and media_options
    words = ['media:', 'autoselect', '(none)', 'mediaopt', '(none)']
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(words, current_if, ips)
    assert 'media' not in current_if
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == ['mediaopt', '(none)']

    # second test case - media line with media_select and media_options
    words = ['media:', 'autoselect', 'mediaopt', '(none)']
    current_if = {}
    DarwinNetwork().parse_media_line

# Generated at 2022-06-11 03:10:16.029872
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork({}) # unit test requires an object with self.get_options function defined
    test_cases = [
        {'input': 'autoselect status: inactive', 'output': {'media': 'Unknown', 'media_select': 'autoselect'}},
        {'input': 'autoselect (none) status: inactive', 'output': {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': None}},
        {'input': 'autoselect (none) status: active', 'output': {'media': 'Unknown', 'media_select': 'autoselect', 'media_options': None}}
    ]

# Generated at 2022-06-11 03:10:23.066810
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = 'media: autoselect'
    words = line.split()
    current_if = {}
    ips = []
    retval = DarwinNetwork().parse_media_line(words, current_if, ips)
    assert retval == None
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "autoselect"

    line = 'media: autoselect <unknown type>'
    words = line.split()
    current_if = {}
    ips = []
    retval = DarwinNetwork().parse_media_line(words, current_if, ips)
    assert retval == None
    assert current_if["media"] == "Unknown"
    assert current_if["media_select"] == "autoselect"