

# Generated at 2022-06-11 03:04:10.926199
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    DarwinNetwork()

# Generated at 2022-06-11 03:04:11.809612
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    x = DarwinNetwork()
    assert x is not None


# Generated at 2022-06-11 03:04:18.605963
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    facts = dict()

    darwin_network = DarwinNetwork()
    darwin_network.populate(facts)

    # Test if variables are strings
    assert isinstance(facts['default_ipv4']['interface'], unicode)
    assert isinstance(facts['default_ipv4']['gateway'], unicode)
    assert isinstance(facts['default_ipv6']['interface'], unicode)
    assert isinstance(facts['default_ipv6']['gateway'], unicode)

    # Test if variables are integers
    assert isinstance(facts['default_ipv4']['metric'], int)
    assert isinstance(facts['default_ipv6']['metric'], int)

    # Test if variables are dictionaries

# Generated at 2022-06-11 03:04:28.424722
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork({}, {}, {})  # we don't care about the first arguments

    current_if = {}
    words = ['media:', 'autoselect', 'status:', 'active', 'supported', 'line-level']
    d.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status'
    assert current_if['media_options'] == 'active supported line-level'

    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    d.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
   

# Generated at 2022-06-11 03:04:39.702926
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # media line is different to the default FreeBSD one
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    current_if = {}
    ips = {}

    test_data = {'medialine' : ['autoselect', 'autoselect', 'status:', 'active', 'supported', 'media:', '10baseT/UTP', '10baseT/UTP', 'autoselect', '(none)'],
                 'medialine2' : ['autoselect', '<unknown', 'type>'],
                 'medialine3' : ['autoselect', '10baseT/UTP', '(none)'],
                 'expected' : 'Unknown'}
    dn = DarwinNetwork()
    medialine = test_data['medialine']

# Generated at 2022-06-11 03:04:42.258866
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """Test class DarwinNetwork
    """
    dnw = DarwinNetwork()
    assert dnw.platform == 'Darwin'
    assert dnw.library_file.endswith('/module_utils/facts/network/darwin/ifconfig.py')

# Generated at 2022-06-11 03:04:49.424745
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # double check we are using the Darwin versions of the methods
    if DarwinNetwork.platform != 'Darwin':
        raise Exception("DarwinNetwork not set to Darwin for testing")

    # set up objects for test
    current_if = {}
    ips = {}
    # test one
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == {}
    # test two
    words = ['media:', '<unknown', 'type>']
    current_if = {} # need to set current_

# Generated at 2022-06-11 03:04:56.287311
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    mediatext = ["media:", "<unknown type>", "status:", "inactive"]
    if_obj = {}
    ips = []
    dn.parse_media_line(mediatext, if_obj, ips)
    assert (if_obj['media'] == 'Unknown')
    assert (if_obj['media_select'] == 'Unknown')
    assert (if_obj['media_type'] == 'unknown type')

# Generated at 2022-06-11 03:05:05.688058
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = "media: autoselect (<unknown type>)"
    line2 = "media: 10baseT/UTP <full-duplex>"
    line3 = "media: autoselect (none)"
    current_if = {}
    ips = []
    DarwinNetwork().parse_media_line(line.split(), current_if, ips)
    assert current_if == {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': 'unknown type'}
    DarwinNetwork().parse_media_line(line2.split(), current_if, ips)
    assert current_if == {
        'media': 'Unknown',
        'media_select': '10baseT/UTP',
        'media_type': 'full-duplex'}
    DarwinNetwork().parse_media

# Generated at 2022-06-11 03:05:12.308513
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    dn = DarwinNetwork(None)
    current_if = {}

    # case 1: valid media line, with no options
    line = 'media: <unknown type>'
    words = line.split()
    dn.parse_media_line(words, current_if, {})

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    # case 2: valid media line, with options
    line = 'media: autoselect (100baseTX <full-duplex>) status: active'
    words = line.split()
    dn.parse_media_line(words, current_if, {})


# Generated at 2022-06-11 03:05:15.619760
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network = DarwinNetwork()
    assert darwin_network.platform == 'Darwin'


# Generated at 2022-06-11 03:05:18.605808
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin_network_fact = DarwinNetwork(None, None)
    # TODO: Use mocked output of Darwin data and test accordingly
    # this is a test of the constructor only
    assert darwin_network_fact is not None

# Generated at 2022-06-11 03:05:28.852032
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    '''
    DarwinNetwork() method parse_media_line(), should set media_select, media_type, media_options accordingly
    '''
    current_if = {'media': 'Unknown'}

    # media line with media_select, media_type, media_options
    words = ['media:', '<select>', '(autoselect)', '<options>']
    DarwinNetwork().parse_media_line(words, current_if, ips=[])
    assert current_if['media'] == 'Unknown'  # Mac does not give us this
    assert current_if['media_select'] == '<select>'
    assert current_if['media_type'] == 'autoselect'
    assert current_if['media_options'] == 'options'

    # media line with media_select and media_type, no media_options
   

# Generated at 2022-06-11 03:05:33.407923
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    class TestDarwin():
        interface = 'en0'
        inet = ''
        inet6 = ''
        flags = ''

    test_obj = DarwinNetwork(TestDarwin())
    assert(test_obj.interface == 'en0')
    assert(test_obj.ipv4['address'] == '127.0.0.1')
    assert(test_obj.ipv6['address'] == '::1')

# Generated at 2022-06-11 03:05:35.164880
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    mod = DarwinNetwork({})
    assert mod.platform == 'Darwin'
    assert mod._platform == 'Darwin'


# Generated at 2022-06-11 03:05:38.349002
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == "Darwin"
    assert darwin.command == "/sbin/ifconfig -a"

# Generated at 2022-06-11 03:05:48.676866
# Unit test for constructor of class DarwinNetwork

# Generated at 2022-06-11 03:05:52.369824
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    """ This test creates the object DarwinNetwork
    """
    # Create an object with the generic BSD class
    darwin_network = DarwinNetwork(None, None)

    # Check if the object created is of the correct type
    assert isinstance(darwin_network, DarwinNetwork)

# Generated at 2022-06-11 03:05:53.365677
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    assert not DarwinNetwork()._check_platform()

# Generated at 2022-06-11 03:05:55.733114
# Unit test for constructor of class DarwinNetwork
def test_DarwinNetwork():
    darwin = DarwinNetwork()
    assert darwin.platform == 'Darwin'
# End Unit test for constructor of class DarwinNetwork
