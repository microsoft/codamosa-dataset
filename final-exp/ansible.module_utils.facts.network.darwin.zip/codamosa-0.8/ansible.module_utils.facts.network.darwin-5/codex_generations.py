

# Generated at 2022-06-11 03:04:16.027545
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    current_if = {}
    words = [None, '<unknown', 'type>']
    net.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:04:24.719384
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    w = DarwinNetwork()
    w.parse_media_line(['media:', 'auto', '1000baseTX'], {}, {})
    assert 'media' in w
    assert 'media_select' in w
    assert 'media_type' in w
    assert 'media_options' in w
    assert w['media'] == 'Unknown'
    assert w['media_select'] == 'auto'
    assert w['media_type'] == '1000baseTX'
    w = DarwinNetwork()
    w.parse_media_line(['media:', 'auto', '1000baseTX', '(full-duplex,txpause)'], {}, {})
    assert w['media_options'] == ['full-duplex', 'txpause']

# Generated at 2022-06-11 03:04:35.168271
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Make sure that the regexp compiles
    regexp = GenericBsdIfconfigNetwork.media_regexp
    assert regexp.search('media: <unknown type> status: inactive')
    assert regexp.search('media: <unknown> status: inactive')
    assert regexp.search('media: autoselect status: inactive')
    assert regexp.search('media: autoselect (none) status: inactive')
    assert regexp.search('media: 10baseT/UTP status: inactive')
    assert regexp.search('media: 10baseT/UTP <full-duplex> status: inactive')
    assert regexp.search('media: 10baseT/UTP <full-duplex> status: active')

# Generated at 2022-06-11 03:04:44.968198
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """Test media line parsing on a Darwin platform"""

    mac = DarwinNetwork()

    # Test line: media: autoselect (1000baseT <full-duplex>) status: active
    line = [
        'media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:',
        'active'
    ]

    assert mac.parse_media_line(line, {}, []) == {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '1000baseT',
        'media_options': ['full-duplex']
    }

    # Test line: media: <unknown type> (none) status: inactive
    line = ['media:', '<unknown', 'type>', '(none)', 'status:', 'inactive']


# Generated at 2022-06-11 03:04:55.534732
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    module = NetworkCollector.get_network_collector_class('Darwin')(None)
    # test if media_select, media_type and media_options are set
    words = ["media:", "autoselect", "(none)"]
    current_if = {}
    ips = []
    module.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == []
    # test if media_type is set
    words = ["media:", "autoselect", "(none)"]
    current_if = {}
    ips = []
    module.parse_media_line(words, current_if, ips)
    assert current_if

# Generated at 2022-06-11 03:04:58.954218
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'autoselect', '(none)']
    GenericBsdIfconfigNetwork.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'

    words = ['media:', '<unknown', 'type>']
    GenericBsdIfconfigNetwork.parse_media_line(words, current_if)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:05:08.996872
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.network.darwin import DarwinNetwork
    test_obj = DarwinNetwork()
    # test media_select and media_type for bridge interface of MacOSX
    test_arg_1 = ['media:', '<unknown', 'type>']
    expected_dict_1 = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
    test_obj.parse_media_line(test_arg_1, {}, {})
    assert expected_dict_1 == test_obj.current
    # test media_select and media_type for ethernet interface of MacOSX
    test_arg_2 = ['media:', 'autoselect', '(none)']

# Generated at 2022-06-11 03:05:14.650051
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import json
    my_DarwinNetwork = DarwinNetwork()
    ip_addr = {}
    ip_addr["ipv4"] = {
        "address": "10.0.0.2",
        "netmask": "255.255.255.0",
        "broadcast": "10.0.0.255"
    }
    ip_addr["ipv6"] = {
        "address": "fe80::2",
        "prefix": "64",
        "scope": "link"
    }
    ips = [ip_addr]
    current_if = {}
    current_if['name'] = "lo0"
    current_if['macaddress'] = "02:1e:67:7f:d3:94"

# Generated at 2022-06-11 03:05:23.561566
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    test_if_dict = {}

    # media line with media_select, media_type and media_options:
    test_words = ["media:", "autoselect", "(none)", "status:", "inactive"]
    DarwinNetwork.parse_media_line(test_if_dict, test_words, None)
    assert test_if_dict == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': 'status: inactive'}

    # media line with only media_select and media_type:
    test_words = ["media:", "autoselect", "(none)"]
    DarwinNetwork.parse_media_line(test_if_dict, test_words, None)

# Generated at 2022-06-11 03:05:31.376704
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    iface.parse_media_line(['media:', '<unknown', 'type>'],{},{})
    assert iface._interfaces['media'] == 'Unknown'
    assert iface._interfaces['media_select'] == 'Unknown'
    assert iface._interfaces['media_type'] == 'unknown type'
    iface.parse_media_line(['media:', 'autoselect', '<unknown>'],{},{})
    assert iface._interfaces['media_select'] == 'autoselect'
    assert iface._interfaces['media_type'] == '<unknown>'

# Generated at 2022-06-11 03:05:41.621422
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mediaData = "media: <unknown type>\n"
    mediaWords = mediaData.split(' ')
    current_if = {}
    ips = {}
    darwinNet = DarwinNetwork()
    darwinNet.parse_media_line(mediaWords, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'type>'

# Generated at 2022-06-11 03:05:45.715902
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_media_input = 'media: <unknown type>'
    mac_media_expected = '<unknown type>'
    assert mac_media_expected == DarwinNetwork().parse_media_line(mac_media_input.split(), {}, {})['media_select']

# Generated at 2022-06-11 03:05:51.894711
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_line = ['media:', 'autoselect', '<unknown type>']
    #  call method with mock values
    #  we pass two dicts so we can check for side effects
    darwin_nw = DarwinNetwork({}, {})
    iface = {}
    ips = {}
    darwin_nw.parse_media_line(test_line, iface, ips)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'unknown type'
    assert iface['media_options'] == {}

# Generated at 2022-06-11 03:06:02.603813
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    interface = {'active': True}
    ips = []
    words = ['media:', 'autoselect', '<unknown', 'type>']
    dn.parse_media_line(words, interface, ips)
    assert interface['media'] == 'Unknown'
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] == 'unknown type'
    interface = {'active': True}
    words = ['media:', 'autoselect', '10baseT/UTP', 'status:', 'active']
    dn.parse_media_line(words, interface, ips)
    assert interface['media_select'] == 'autoselect'
    assert interface['media_type'] == '10baseT/UTP'

# Generated at 2022-06-11 03:06:12.770264
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialise a dictionary of words to be passed to parse_media_line
    words = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    words2 = ['media:', 'autoselect', '(unknown', 'type)']  # for bridge
    # Initialise a dictionary of ips to be passed to parse_media_line
    ips = {'ipv4': [{}], 'ipv6': [{}]}
    # Initialise the current_if dict
    current_if = {}

    # Run the parse_media_line function
    # Note that the DarwinNetwork.parse_media_line function call is in the same line as the DarwinNetwork instantiation
    DarwinNetwork().parse_media_line(words, current_if, ips)

    # Unit test for

# Generated at 2022-06-11 03:06:18.498798
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_media_line = 'media: autoselect <unknown type> status: inactive'
    words = mac_media_line.split()

    instance_DarwinNetwork = DarwinNetwork()
    returned_if = {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': 'unknown type', 'media_options': ''}
    if_if = {}
    instance_DarwinNetwork.parse_media_line(words, if_if, None)
    assert(returned_if == if_if)

# Generated at 2022-06-11 03:06:26.858104
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    current_if = dict()
    words = [0, '<unknown', 'type>']
    ips = dict()
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

# Generated at 2022-06-11 03:06:32.164214
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    iface.parse_media_line(['media:', 'autoselect', '(none)'], {}, {'inet': []})
    assert iface.current_if['media'] == 'Unknown'
    iface.parse_media_line(['media:', 'autoselect', '(none)'], {'media_type': '1000baseTX'}, {'inet': []})
    assert iface.current_if['media'] == 'Unknown'
    assert iface.current_if['media_type'] == '1000baseTX'

# Generated at 2022-06-11 03:06:37.242260
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    obj = DarwinNetwork()
    current_if = {'name': 'en0'}
    ips = {}
    words = ['media:', '<unknown', 'type>']
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:43.807545
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test with media line from darwin 'en0' interface
    line = '  media: autoselect (unknown type)'
    dn = DarwinNetwork()
    dn.parse_media_line(line.split(), {}, ['1.1.1.1'])
    assert dn.interfaces[0]['media_select'] == 'autoselect'
    assert dn.interfaces[0]['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:58.968538
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_ips = []
    result = {'media': 'Unknown', 'media_select': 'media', 'media_type': 'autoselect', 'media_options': {'dBm': '-1'}}
    test_words = ['media', 'media', 'autoselect', 'status:', 'active', 'dBm', '-1']
    DarwinNetwork.parse_media_line(test_words, test_if, test_ips)
    assert test_if == result
    test_words = ['media', 'media', 'autoselect', 'status:', 'No', 'Carrier']
    result = {'media': 'Unknown', 'media_select': 'media', 'media_type': 'autoselect', 'media_options': {'status': 'No Carrier'}}
    DarwinNetwork.parse_media

# Generated at 2022-06-11 03:07:05.707839
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ["media:", "<unknown type>", "status:", "inactive"]
    current_if = {'media': 'Unknown'}
    ips = {}
    res = DarwinNetwork.parse_media_line(words, current_if, ips)
    assert res is None  # no return value
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'Unknown'

# Generated at 2022-06-11 03:07:15.160404
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    dict = {}
    dict['media'] = ''
    dict['media_select'] = ''
    dict['media_type'] = ''
    dict['media_options'] = ''
    # Test case 1 (MacOSX media line)
    dict['media_select'] = 'autoselect'
    dict['media_type'] = 'none'
    darwin_net.parse_media_line(['media:', 'autoselect', 'none'], dict, [])
    assert dict['media'] == 'Unknown'
    # Test case 2 (MacOSX media line for bridge)
    dict['media_select'] = 'Unknown'
    dict['media_type'] = 'unknown type'

# Generated at 2022-06-11 03:07:24.280242
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line_1 = ['media:', '<unknown type>', '(none)', '(none)']
    media_line_2 = ['media:', '<unknown type>', '(none)']
    media_line_3 = ['media:', '<unknown type>']
    current_if = dict()
    dnet = DarwinNetwork(1)
    dnet.parse_media_line(media_line_1, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == 'none'
    dnet.parse_media_line(media_line_2, current_if, {})

# Generated at 2022-06-11 03:07:30.761817
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = "media: <unknown type>"
    current_if = {'media': ''}
    line = media_line.split()
    darwin_if = DarwinNetwork()
    darwin_if.parse_media_line(line, current_if, None)
    assert current_if['media_select'] == '<unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

# Generated at 2022-06-11 03:07:38.707134
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    nc = DarwinNetwork()
    current_if = {}
    words = ['media:', 'auto', '<unknown', 'type>']
    nc.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if
    words = ['media:', 'auto', '10baseT/UTP']
    nc.parse_media_line(words, current_if, [])
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '10baseT/UTP'

# Generated at 2022-06-11 03:07:47.532777
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()

    # convenience variables
    test = {}
    test['interface'] = {}
    test['interface']['media'] = 'Unknown'
    test['interface']['media_select'] = 'autoselect'
    test['interface']['media_type'] = 'ieee80211'
    test['interface']['media_options'] = 'ssid=""'

    # test the parsing: media line should be 'autoselect media ieee80211 ssid=""'.
    words = test['interface']['media_select'].split()
    d.parse_media_line(words, test['interface'], 'x.x.x.x')
    assert test == d.interfaces

# Generated at 2022-06-11 03:07:57.824381
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Set up test structures
    current_if = dict()
    ips = dict()
    current_if['media'] = None
    current_if['media_select'] = None
    current_if['media_type'] = None
    current_if['media_options'] = None
    # Test 1
    test_word_list_1 = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(current_if, test_word_list_1, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == None
    # Test 2
    test_word_list_2

# Generated at 2022-06-11 03:08:03.278411
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_str = '<unknown type>'
    words = mac_str.split()
    current_if = {'ipv4': [], 'ipv6': []}
    ips = {}
    expected_result = {
        'media': 'Unknown',
        'media_options': None,
        'media_select': '<unknown',
        'media_type': 'type>'
    }
    assert DarwinNetwork.parse_media_line(words, current_if, ips) == expected_result

# Generated at 2022-06-11 03:08:13.237246
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {}
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, iface, {})
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'
    assert 'media_options' not in iface

    iface = {}
    words = ['media:', 'autoselect', '10baseT/UTP', '(none)', 'status:', 'active']
    DarwinNetwork.parse_media_line(DarwinNetwork, words, iface, {})
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'

# Generated at 2022-06-11 03:08:24.044992
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # set up and call the method
    device = {'ips': []}
    iface = {}
    test_word_list = ['media:','<unknown','type>','none','status:','inactive']
    DarwinNetwork.parse_media_line(None, test_word_list, iface, device)
    # check result
    assert(iface['media'] == 'Unknown')
    assert(iface['media_select'] == '<unknown')
    assert(iface['media_type'] == 'unknown type')

# Generated at 2022-06-11 03:08:30.484710
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    iface.parse_media_line(['media:', '<unknown type>', 'status:', 'inactive'], {'media_type': 'unknown type'}, None)
    assert iface.current_if['media_type'] == 'unknown type'
    iface.parse_media_line(['media:', '<unknown type>', 'status:', 'inactive'], {'media_type': 'unknown type'}, None)

# Generated at 2022-06-11 03:08:35.179582
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    line = 'media: <unknown type>  autoselect'
    words = line.split()
    # init the dictionary
    current_if = {}
    # init the list
    ips = []
    # create the object DarwinNetwork
    obj = DarwinNetwork(mock=True)
    # run method parse_media_line
    obj.parse_media_line(words, current_if, ips)

    assert current_if == {'media': 'Unknown',
                          'media_select': 'autoselect'}

# Generated at 2022-06-11 03:08:43.974351
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # set up
    media_line_1 = ['media:','autoselect','(100baseTX)' ,'status:','active']
    media_line_2 = ['media:','<unknown','type>','status:','active']

    # test
    test1 = DarwinNetwork()
    test1.parse_media_line(media_line_1, {}, [])
    test2 = DarwinNetwork()
    test2.parse_media_line(media_line_2, {}, [])

    # assert
    assert test1.media_select == 'autoselect'
    assert test1.media_type == '100baseTX'
    assert test2.media_select == 'Unknown'
    assert test2.media_type == 'unknown type'

# Generated at 2022-06-11 03:08:53.558737
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    ips = []
    obj = DarwinNetwork(None)
    obj._macs = []

    # Test for expected media line
    words = ['media:', 'auto', '10baseT/UTP', '(<unknown type>)']
    obj.parse_media_line(words, current_if, ips)
    assert obj._macs == ['10baseT/UTP']
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

    # Test for unexpected media line
    current_if = {}
    ips = []
    words = ['media:', 'auto', 'unknown']

# Generated at 2022-06-11 03:08:58.639968
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d_net = DarwinNetwork()
    words = 'media: <unknown type> status: inactive'.split()
    current_if = {}
    ips = {}
    d_net.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown',
                          'media_select': 'Unknown',
                          'media_type': 'unknown type',
                          'media_options': None}

# Generated at 2022-06-11 03:09:04.300018
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown type>', 'status:', 'active']
    dn = DarwinNetwork(None)
    current_if = {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type',
    }
    dn.parse_media_line(words, current_if, None)
    assert current_if == {
        'media': 'Unknown',
        'media_select': 'Unknown',
        'media_type': 'unknown type',
    }

# Generated at 2022-06-11 03:09:12.426610
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # test case 1
    current_if = {'name': 'en0'}
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)', 'status:', 'active']
    dn.parse_media_line(words, current_if, {})
    assert {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '100baseTX <full-duplex>', 'media_options': 'active'} == current_if
    # test case 2
    current_if = {'name': 'en0'}
    words = ['media:', 'autoselect', '(100baseTX <full-duplex>)', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, {})

# Generated at 2022-06-11 03:09:19.353249
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {
        'interface': 'lo0',
        'inet': '127.0.0.1 netmask 0xff000000',
        'media_select': 'Autoselect',
        'media_type': '',
        'media_options': '',
        'type': 'Loopback'}
    expected = {'interface': 'lo0', 'inet': '127.0.0.1 netmask 0xff000000',
                'media': 'Unknown'}
    c = DarwinNetwork()
    c.parse_media_line(['media:', 'Autoselect'], test_dict, None)
    assert test_dict == expected

# Generated at 2022-06-11 03:09:24.009263
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    words = ["media:", "<unknown", "type>"]
    current_if = dict()
    ips = dict()
    dn.parse_media_line(words, current_if, ips)
    assert current_if["media"] == 'Unknown'
    assert current_if["media_select"] == 'Unknown'
    assert current_if["media_type"] == 'unknown type'
    assert current_if["media_options"] == ''

# Generated at 2022-06-11 03:09:44.185430
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    media_line = ['media:', 'autoselect', '(100baseTX <full-duplex,flow-control>)', 'status:', 'inactive']
    current_if = {}
    dn.parse_media_line(media_line, current_if, {})
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == ['full-duplex', 'flow-control']

    media_line = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    dn.parse_media_line(media_line, current_if, {})
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:09:52.608347
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {"name": "en0", "type": "ether", "macaddress": "00:00:00:00:00:00", "mtu": 1500,
               "inet": [
                   {"address": "ff:ff:ff:ff:ff:ff", "netmask": "ffffffff", "broadcast": "ff:ff:ff:ff:ff:ff",
                    "destination": "ff:ff:ff:ff:ff:ff"}
               ], "status": "active"}


# Generated at 2022-06-11 03:10:01.201781
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # test the case where media is not 'Unknown'
    x = [ 'media:', 'autoselect', '(none)', 'mediaopt:', 'none', 'status:', 'inactive', ]
    y = { 'media': 'Unknown',
          'media_select': 'autoselect',
          'media_type': '(none)',
          'media_options': 'none', }
    assert DarwinNetwork._parse_media_line(x, y) == y

    # test the case where media is 'Unknown'
    x = [ 'media:', '<unknown', 'type>', 'status:', 'inactive', ]
    y = { 'media': 'Unknown',
          'media_select': 'Unknown',
          'media_type': 'unknown type',
          'media_options': None, }
    assert DarwinNetwork._parse_media

# Generated at 2022-06-11 03:10:11.252328
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:10:19.025988
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # In case of bridge interface, the media line is something like this
    # media: <unknown type>
    # which is splitted into words to be:
    # ['media:', '<unknown', 'type>']
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': {}}
    words = ['media:', '<unknown', 'type>']
    # This post-condition is only for media line of bridge interface
    expected = {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': {}}
    parse_media_line(current_if, words)
    assert(current_if == expected)

    # In case of typical interface, the media line is something like this
    # media: autoselect (

# Generated at 2022-06-11 03:10:27.405056
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network import DarwinNetwork
    dn = DarwinNetwork()
    current_if = dict()

    words = ['media:', 'autoselect', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == ''
    assert current_if['media'] == 'Unknown'

    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    dn.parse_media_line(words, current_if, None)
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:10:31.618063
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {}
    line = "media: autoselect ("
    linewords = line.split()
    DarwinNetwork.parse_media_line(DarwinNetwork(), linewords, iface, [])
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == linewords[1]

# Generated at 2022-06-11 03:10:39.908114
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dnw=DarwinNetwork()
    current_if={}
    ips=[]
    # media line with all optional information
    words = ['media:', 'autoselect', '(none)', 'mediaopt', 'mediaopt_val']
    dnw.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': {'mediaopt': 'mediaopt_val'}}
    current_if={}
    # media line without optional information
    words = ['media:', 'autoselect']
    dnw.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:10:47.601353
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    # create a DarwinNetwork object
    dn = DarwinNetwork()

    # create a sample media line
    media_line = 'media: <unknown type>'
    words = media_line.split()

    # create a current_if dict
    current_if = dict()

    # create an ips dict
    ips = dict()

    # test that the result of the method parse_media_line
    # is what we expect
    assert dn.parse_media_line(words, current_if, ips) == None
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

# Generated at 2022-06-11 03:10:56.117542
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifname_dict = {'name': 'bridge0'}
    current_if = {}
    obj = DarwinNetwork()

    # Test method parse_media_line with media line word array length 4
    words = ['media:', '<unknown', 'type>', '(none)']
    obj.parse_media_line(words, current_if, ifname_dict)
    assert current_if == {'media': 'Unknown',
                          'media_select': 'Unknown',
                          'media_type': 'unknown type',
                          'media_options': 'none'}

    # Test method parse_media_line with media line word array length 3
    words = ['media:', 'autoselect', '(none)']
    obj.parse_media_line(words, current_if, ifname_dict)

# Generated at 2022-06-11 03:11:31.247142
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}

    # Test parse_media_line with normal media line
    words = ['media:', 'autoselect', '(100baseTX)', 'status:', 'active']
    DarwinNetwork.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == None

    # Test parse_media_line with media line with options
    words = ['media:', 'fddi(autoselect)', 'status:', 'inactive']
    DarwinNetwork.parse_media_line(words, current_if)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:11:36.006551
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    current_if = {}
    words = ['media:', '<unknown', 'type>', '(autoselect)']
    dn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ['autoselect']

# Generated at 2022-06-11 03:11:40.001711
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    media_line = 'media: <unknown type>'
    darwin_network = DarwinNetwork()
    current_if = {}
    ips = []
    darwin_network.parse_media_line(media_line.split(), current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:11:46.741441
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', '<unknown', 'type>'], dict(), list())
    assert ifc.current_if['media'] == 'Unknown'
    assert ifc.current_if['media_select'] == 'Unknown'
    assert ifc.current_if['media_type'] == 'unknown type'
    ifc.parse_media_line(['media:', 'autoselect'], dict(), list())
    assert ifc.current_if['media'] == 'Unknown'
    assert ifc.current_if['media_select'] == 'autoselect'

# Generated at 2022-06-11 03:11:56.664893
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_str = ["media: <unknown type>", "status: inactive"]
    test_str1 = ["media: autoselect status: inactive"]
    test_str2 = ["media: autoselect (1000baseT <full-duplex,flow-control>) status: inactive"]
    test_str3 = ["media: autoselect (1000baseT <full-duplex,flow-control>) status: active"]
    current_if = {'network_type': ''}
    ips = {}

    os = DarwinNetwork()
    os.parse_media_line(test_str1, current_if, ips)
    assert current_if['media_select'] == "autoselect"
    assert current_if['media'] == "Unknown"
    os.parse_media_line(test_str2, current_if, ips)


# Generated at 2022-06-11 03:12:05.572767
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = {}
    mac = DarwinNetwork(test_dict)
    # Docker bridge
    mac.parse_media_line(['media:', '<unknown', 'type>', '(Ethernet)'], test_dict, [])
    assert test_dict.get('media') == 'Unknown'
    assert test_dict.get('media_select') == 'Unknown'
    assert test_dict.get('media_type') == 'unknown type'
    assert test_dict.get('media_options') == {'Ethernet': True}

    # Ethernet
    mac.parse_media_line(['media:', 'autoselect', '(none)'], test_dict, [])
    assert test_dict.get('media') == 'Unknown'
    assert test_dict.get('media_select') == 'autoselect'
    assert test

# Generated at 2022-06-11 03:12:15.710134
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', 'AUTOSELECT',
                          '(1000baseTX <full-duplex,flow-control,hw-loopback>)'], {}, '')
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == 'AUTOSELECT'
    assert ifc['media_type'] == '1000baseTX'
    assert ifc['media_options'] == 'full-duplex,flow-control,hw-loopback'

    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', '10baseT/UTP', '(none)'], {}, '')
    assert ifc['media'] == 'Unknown'
    assert ifc['media_select'] == '10baseT/UTP'

# Generated at 2022-06-11 03:12:20.287827
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    current_if = {}
    dn = DarwinNetwork()
    words = ['media:','<unknown','type>','status:','active']
    ips = []
    dn.parse_media_line(words,current_if,ips)
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:12:29.389445
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()

    ifc.parse_media_line(['media:', '<unknown type>'], {}, {})
    assert 'Unknown' == ifc.facts['interfaces']['lo0']['media_select']
    assert 'unknown type' == ifc.facts['interfaces']['lo0']['media_type']

    ifc.parse_media_line(['media:', 'autoselect', '(none)'], {}, {})
    assert 'autoselect' == ifc.facts['interfaces']['lo0']['media_select']
    assert '(none)' == ifc.facts['interfaces']['lo0']['media_type']

# Generated at 2022-06-11 03:12:35.939939
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_facts = DarwinNetwork()
    words = []
    current_if = {}
    ips = {}
    mac_facts.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] is None
    words = ['media:', 'autoselect', '(none)']
    mac_facts.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    mac_facts.parse_media_line(words, current_if, ips)