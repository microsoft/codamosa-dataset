

# Generated at 2022-06-11 03:04:18.578594
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    # this line is what Darwin returns on en0
    # media: autoselect (1000baseT <full-duplex>) status: inactive
    words = "media: autoselect (1000baseT <full-duplex>) status: inactive".split()
    current_if = {'media': None, 'media_select': None, 'media_type': None, 'media_options': None}
    ips = []
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert 'full-duplex' in current_if['media_options']
    # this line is what Darwin returns for bridge100
    # media

# Generated at 2022-06-11 03:04:28.386703
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Set up
    fac = DarwinNetwork()
    fac.parse_media_line(['media:', 'autoselect', '(none)'],{},{})
    fac.parse_media_line(['media:', 'autoselect', '(none)', '(oe)'],{},{})
    # test simple
    media = dict()
    fac.parse_media_line(['media:', 'autoselect', '100baseTX'],{},{})
    assert media['media'] == 'Unknown'
    assert media['media_select'] == 'autoselect'
    assert media['media_type'] == '100baseTX'
    # test simple with additional media
    fac.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'],{},{})
    assert media['media_select']

# Generated at 2022-06-11 03:04:33.230356
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test method parse_media_line of class DarwinNetwork
    """
    current_if = {}
    ips = []
    words = ['media:', '<unknown', 'type>']
    result = DarwinNetwork.parse_media_line(None, words, current_if, ips)
    assert result == 'Unknown'

# Generated at 2022-06-11 03:04:43.821109
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    darwin_network = DarwinNetwork()

    # Test for media parsing without 'media_type'
    media_line = ['media:', 'autoselect', '(100baseTX)']
    iface_dict = {'media': 'Unknown',
                  'media_select': 'autoselect'}
    darwin_network.parse_media_line(media_line, iface_dict, [])
    assert iface_dict['media'] == 'Unknown'
    assert iface_dict['media_select'] == 'autoselect'

    # Test for media parsing with 'media_type'
    media_line = ['media:', 'autoselect', '(100baseTX)', 'full-duplex']

# Generated at 2022-06-11 03:04:54.145139
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    _fact_class = DarwinNetwork
    iface = {}
    _fact_class.parse_media_line(['media:', 'autoselect', 'none', 'status:', 'inactive'], iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == 'none'
    del iface['media']
    del iface['media_select']
    del iface['media_type']
    _fact_class.parse_media_line(['media:', '<unknown', 'type>', 'status:', 'inactive'], iface, None)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:05:04.309698
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    test_words = ['media:', 'autoselect', '(100baseTX)' ]
    result = { 'media_select': 'autoselect', 'media_type': '(100baseTX)', 'media': 'Unknown' }
    DarwinNetwork.parse_media_line(test_if, test_words, None)
    assert test_if == result

    test_if = {}
    test_words = ['media:', 'autoselect', 'Gigabit', '<full-duplex,txpause>']
    result = {
        'media_select': 'autoselect',
        'media_type': 'Gigabit',
        'media_options': {
            'full_duplex': True,
            'txpause': True,
        },
        'media': 'Unknown'
    }
    Darwin

# Generated at 2022-06-11 03:05:09.320355
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.parse_media_line(['media:', '', ''], {}, {})
    ifc.parse_media_line(['media:', '<unknown type>', ''], {}, {})
    ifc.parse_media_line(['media:', 'autoselect', ''], {}, {})
    ifc.parse_media_line(['media:', '1000baseT', '<full-duplex>'], {}, {})

# Generated at 2022-06-11 03:05:19.502261
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = dict()
    ips = dict()
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    DarwinNetwork._parse_media_line(None, words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type', 'media_options': None}
    del current_if['media']  # restore original since parse_media_line sets it
    words = ['media:', 'ieee80211', 'status:', 'associated']
    DarwinNetwork._parse_media_line(None, words, current_if, ips)
    assert current_if == {'media_select': 'ieee80211', 'media_type': 'associated', 'media_options': None}

# Generated at 2022-06-11 03:05:25.664751
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dwn = DarwinNetwork()
    words = ['media:', '<unknown', 'type>', 'status:', 'active']
    iface = {'name': 'en0', 'state': 'up'}
    iface = dwn.parse_media_line(words, iface, {})
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'Unknown'
    assert iface['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:05:33.449953
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create an instance of DarwinNetwork
    DarwinNetwork_obj = DarwinNetwork(None)
    # words is always a list
    # the value of current_if does not matter
    # the value of ips does not matter
    # first test: words = ['media:', 'none', '(autoselect)']
    # expected result:
    #   current_if['media'] = 'Unknown'
    #   current_if['media_select'] = 'none'
    #   current_if['media_type'] = 'autoselect'
    #   current_if['media_options'] = None
    result1 = {}
    words1 = ['media:', 'none', '(autoselect)']
    DarwinNetwork_obj.parse_media_line(words1, result1, None)

# Generated at 2022-06-11 03:05:40.573125
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNet = DarwinNetwork()
    iface = {}
    ips = None
    words = ['media', 'autoselect', '(none)']
    DarwinNet.parse_media_line(words, iface, ips)
    assert iface['media'] == 'Unknown'
    assert iface['media_select'] == 'autoselect'
    assert iface['media_type'] == '(none)'

# Generated at 2022-06-11 03:05:46.528048
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_os_x_network = DarwinNetwork()
    current_if = {}
    words = ['media:', 'autoselect', '<unknown type>']
    mac_os_x_network.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:05:53.642867
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:06:04.640985
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_net = DarwinNetwork()
    current_if = dict()

    # media_select is 'Unknown'
    current_if = darwin_net.parse_media_line(["status:", "inactive"],
                                            current_if)
    assert current_if['media_select'] == "inactive"
    assert 'media' not in current_if

    # media_select is 'active', media is 'Unknown, and media_type is 'unknown type'
    current_if = darwin_net.parse_media_line(["status:", "active", "(<unknown", "type>)"],
                                             current_if)
    assert current_if['media_select'] == "active"
    assert current_if['media'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:14.042421
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test with 2 words
    current_if={}
    words=['media:', 'autoselect']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, None)
    assert len(current_if) == 2
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

    # Test with more than 2 words
    current_if={}
    words=['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, current_if, None)
    assert len(current_if) == 3
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-11 03:06:25.999036
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # Case 1: no media_type
    current_if = {}
    ips = {}
    words = "media: autoselect (none)"
    dn.parse_media_line(words.split(' '), current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # Case 2: media_type present
    current_if = {}
    ips = {}
    words = "media: autoselect (1000baseT <full-duplex>)"
    dn.parse_media_line(words.split(' '), current_if, ips)

# Generated at 2022-06-11 03:06:30.182440
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_object = DarwinNetwork()

    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}
    test_object.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}

# Generated at 2022-06-11 03:06:41.069043
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'device': 'en0',
        'type': 'ether',
        'mtu': '1500',
        'media_select': 'Autoselect',
        'macaddress': 'f0:18:98:f6:d7:c0',
        'media_type': 'Ethernet autoselect',
        'media_options': 'none',
        'enabled': True,
        'promiscuous': True,
    }

# Generated at 2022-06-11 03:06:48.150263
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_dict = dict()
    test_dict['media'] = ""
    test_dict['media_select'] = ""
    test_dict['media_type'] = ""
    test_dict['media_options'] = ""

    DarwinNetwork("").parse_media_line(['media:', '10baseTX', 'mediaopt', 'mediaopt'], test_dict, dict())

    assert test_dict['media'] == 'Unknown'
    assert test_dict['media_select'] == '10baseTX'
    assert test_dict['media_type'] == 'mediaopt'
    assert test_dict['media_options'] == 'mediaopt'



# Generated at 2022-06-11 03:06:56.790310
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create an instance of the DarwinNetwork class
    dn = DarwinNetwork()

    words = []
    words.append('plain')
    words.append('media')
    words.append('auto')
    words.append('full\-duplex')
    words.append('10baseT')

    current_if = {}

    dn.parse_media_line(words, current_if, {})

    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == 'full-duplex'
    assert current_if['media_options'] == ['10baseT']


# vim: set et cc=80 tw=79 sts=4 ts=4 sw=4:

# Generated at 2022-06-11 03:07:08.980633
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', 'autoselect', 'status:', 'inactive']
    current_if = {}
    ips = {}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'status:'
    assert current_if['media_options'] == 'inactive'
    words = ['media:', '<unknown', 'type>', 'status:', 'inactive']
    current_if = {}
    ips = {}
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:07:17.253260
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface_dict = DarwinNetwork(None, None).parse_media_line(['media:', 'none', '(none)'], {}, [])
    assert interface_dict == {'media': 'none', 'media_select': 'none', 'media_type': '(none)'}

    interface_dict = DarwinNetwork(None, None).parse_media_line(['media:', 'ieee80211', '(autoselect)'], {}, [])
    assert interface_dict == {'media': 'ieee80211', 'media_select': 'ieee80211', 'media_type': '(autoselect)'}

    interface_dict = DarwinNetwork(None, None).parse_media_line(['media:', '<unknown', 'type>'], {}, [])

# Generated at 2022-06-11 03:07:27.365667
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    mac_DarwinNetwork = DarwinNetwork()
    current_if = {}
    words = ['media:','autoselect','(none)' ]
    mac_DarwinNetwork.parse_media_line(words, current_if, '')
    assert current_if.get('media_select') == words[1]
    assert current_if.get('media_type') == None
    assert current_if.get('media_options') == None
    assert current_if.get('media') == 'Unknown'

    current_if = {}
    words = ['media:','autoselect','10baseT/UTP', '<link>']
    mac_DarwinNetwork.parse_media_line(words, current_if, '')
    assert current_if.get('media_select') == words[1]

# Generated at 2022-06-11 03:07:34.547511
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    # net.parse_media_line(words, current_if, ips)
    # media line is different to the default FreeBSD one
    words = ['media:', 'auto']
    current_if = {'name': 'eth0'}
    ips = {}

    net.parse_media_line(words, current_if, ips)
    assert current_if['media_select'] == 'auto'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if

    # media line is different to the default FreeBSD one
    words = ['media:', '10baseT/UTP', '(<unknown type>)']
    net.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:07:40.056653
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = '''
    media: <unknown type> <unknown subtype>
    status: inactive
    '''
    iface = {}
    words = line.split()
    DarwinNetwork._parse_media_line(words, iface, [])
    assert(iface['media'] == 'Unknown')
    assert(iface['media_select'] == '<unknown')
    assert(iface['media_type'] == 'unknown type')

# Generated at 2022-06-11 03:07:49.183575
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = DarwinNetwork()
    iface.parse_media_line(['media:', 'autoselect', '10baseT/UTP', '(none)'], {}, {})
    assert iface.facts['all_ipv4_addresses'] == {}
    assert iface.facts['all_ipv6_addresses'] == {}
    assert iface.facts['default_ipv4'] == {}
    assert iface.facts['default_ipv6'] == {}
    assert iface.facts['interfaces'] == ['lo0']
    assert iface.facts['local4'] == ['127.0.0.1']
    assert iface.facts['local6'] == ['::1']
    assert iface.facts['network4'] == {}
    assert iface.facts['network6'] == {}
    assert iface.facts

# Generated at 2022-06-11 03:07:58.153217
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()
    ifc.interface_ipv4_addresses = {}
    current_if = {}
    ips = []
    words = []
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words
    words = ['media:', '<unknown', 'type>', 'media:', 'none', 'supported']
    ifc.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'



# Generated at 2022-06-11 03:08:05.641389
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_if_info = {'media': 'Unknown', 'media_select': '<unknown type>',
                      'media_type': 'unknown type', 'media_options': None}
    darwin_if = DarwinNetwork()
    darwin_if.parse_media_line(['media:', '<unknown', 'type>'], darwin_if_info, None)
    assert darwin_if_info['media'] == 'Unknown'
    assert darwin_if_info['media_select'] == 'Unknown'
    assert darwin_if_info['media_type'] == 'unknown type'
    assert darwin_if_info['media_options'] is None

# Generated at 2022-06-11 03:08:14.581474
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_if = {}
    obj = DarwinNetwork(None, None)
    words = []
    words.append('media:')
    words.append('<unknown')
    words.append('type>')
    obj.parse_media_line(words, test_if)
    assert test_if['media'] == 'Unknown'
    assert test_if['media_select'] == 'Unknown'
    assert test_if['media_type'] == 'unknown type'
    assert test_if['media_options'] == {}

    words = []
    words.append('media:')
    words.append('autoselect')
    words.append('(none)')
    obj.parse_media_line(words, test_if)
    assert test_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:08:24.280815
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork(None, MockNetworkRunner())
    current_if = {}
    ips = []
    words = ['media:', 'none', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'none'
    assert 'media_type' not in current_if
    assert 'media_options' not in current_if
    words = ['media:', 'autoselect', '(none)']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' not in current_if