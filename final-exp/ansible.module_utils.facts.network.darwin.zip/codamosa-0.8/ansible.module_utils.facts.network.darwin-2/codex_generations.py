

# Generated at 2022-06-11 03:04:24.180916
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    net = DarwinNetwork()
    words = ['media:', '(none)', '(none)']
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}
    net.parse_media_line(words, current_if, '')
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'none'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == ''

    words = ['media:', '<unknown', 'type>', '10baseT']
    current_if = {'media': '', 'media_select': '', 'media_type': '', 'media_options': ''}

# Generated at 2022-06-11 03:04:31.668264
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create instance of DarwinNetwork class
    network_obj = DarwinNetwork()
    # create test interface dictionary
    interface = {'type': 'unknown'}
    media_select = ' <unknown type>'

# Generated at 2022-06-11 03:04:42.333360
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    iface = {'device': 'en1', 'name': 'en1', 'enabled': True, 'type': '', 'macaddress': '', 'ipv4': [], 'ipv6': []}
    parsed_iface = {}
    dn = DarwinNetwork()
    # words[1] = 'auto'
    # words[2] = '10Gb/s-SR'
    # words[3] = 'full'
    words = 'media: auto 10Gb/s-SR full'.split()
    parsed_iface = dn.parse_media_line(words, iface, {})

    assert(parsed_iface['device'] == 'en1')
    assert(parsed_iface['media_select'] == 'auto')

# Generated at 2022-06-11 03:04:49.472178
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Test parsing of media line (Darwin specific)
    """
    # ifconfig output with bridge interface
    line = 'media: <unknown type> (none)'
    # ifconfig output with ethernet interface
    line2 = 'media: auto autoselect (100baseTX <full-duplex>)'
    # ifconfig output with ethernet interface (option "media" has a value)
    line3 = 'media: Ethernet autoselect (100baseTX <full-duplex>)'
    # ifconfig output with wireless interface
    line4 = 'media: auto autoselect (none)'

    curr_if = {}
    darwin_network = DarwinNetwork()
    darwin_network.parse_media_line(line.split(), curr_if, {})
    assert curr_if['media'] == 'Unknown'
   

# Generated at 2022-06-11 03:05:00.117821
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    DarwinNetwork_testcase_parse_media_line_output = {
        'media': 'Unknown',
        'media_select': 'autoselect',
        'media_type': '10Gbase-SR',
        'media_options': {
            'mau': '10GBASE-SR',
            'fc': 'speed'
        }
    }

    DarwinNetwork_testcase_parse_media_line = DarwinNetwork([])
    DarwinNetwork_testcase_parse_media_line_result = DarwinNetwork_testcase_parse_media_line.parse_media_line(
        ['media:', 'autoselect', '(10Gbase-SR,', 'mau=10GBASE-SR,', 'fc=speed)'], {}, {})
    assert DarwinNetwork_testcase_parse_media_line_result == DarwinNetwork_testcase

# Generated at 2022-06-11 03:05:09.351158
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.darwin import DarwinNetwork
    dwn = DarwinNetwork()

    # Test media line parsed properly
    test_line = ['media:', 'autoselect', '<unknown type>']
    current_if = {}
    ips = []
    dwn.parse_media_line(test_line, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert 'media_options' not in current_if

    # Test media line with options
    test_line = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = []
   

# Generated at 2022-06-11 03:05:19.502652
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test when media line contains media, media select and media type
    d = DarwinNetwork()
    words = d.splitter('media: autoselect (1000baseT <full-duplex>) status: active')
    current_if = {}
    ips = {}
    d.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT <full-duplex>'

    # Test when media line contains only media select
    d = DarwinNetwork()
    words = d.splitter('media: autoselect')
    current_if = {}
    ips = {}
    d.parse_media_line(words, current_if, ips)

# Generated at 2022-06-11 03:05:29.875712
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_iface = dict()
    parser = DarwinNetwork()

    # Test for empty media line
    parser.parse_media_line([], test_iface)
    assert test_iface == {'media': 'Unknown', 'media_select': None, 'media_type': None, 'media_options': None}

    # Test for media_select only
    test_iface.clear()
    parser.parse_media_line(['media:', 'Autoselect'], test_iface)
    assert test_iface == {'media': 'Unknown', 'media_select': 'Autoselect', 'media_type': None, 'media_options': None}

    # Test for media_select and media_type
    test_iface.clear()

# Generated at 2022-06-11 03:05:38.121568
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Initialization of test variables
    current_if = {}
    ips = {}
    test_line = ('media: autoselect (100baseTX <full-duplex>) status: active')
    expected_result = {'media_select': 'autoselect',
                       'media_type': '100baseTX <full-duplex>',
                       'media': 'Unknown'}
    # Setting up test object
    test_obj = DarwinNetwork()
    # Execute method
    test_obj.parse_media_line(test_line.split(), current_if, ips)
    # Assertion
    assert current_if == expected_result

# Generated at 2022-06-11 03:05:45.015238
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # dict to pass to DarwinNetwork method
    words = []
    current_if = {}
    ips = {}
    # test for branch of if-else to handle '<unknown type>'
    words = ['media:', '<unknown', 'type>']
    DarwinNetwork.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:05:57.866536
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    iface = DarwinNetwork(None, None)
    iface.parse_media_line(['media:', 'IEEE802.11', '<unknown type>(autoselect)'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'IEEE802.11'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'autoselect'

    current_if = {}
    iface.parse_media_line(['media:', '<unknown', 'type>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'

# Generated at 2022-06-11 03:06:08.646328
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create the object to test
    darwin_network = DarwinNetwork()
    darwin_network.ifconfig_path = "/sbin/ifconfig"
    darwin_network.is_valid = True
    # Check parsing of media information like "media: autoselect (1000baseT <full-duplex>)"
    media_line = ['media:', 'autoselect', '(1000baseT', '<full-duplex>)']
    expected_media_type = '1000baseT'
    expected_media_options = 'full-duplex'
    current_if = {'device': 'en1'}
    darwin_network.parse_media_line(media_line, current_if, None)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:06:15.387009
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    data = {}
    data['media'] = 'Unknown'
    data['media_select'] = 'dw1000'
    data['media_type'] = 'Wi-Fi'
    data['media_options'] = 'Channel 11'
    # (not used) data['media_status'] = 'active'

    # Testing the class
    # test object
    f = DarwinNetwork()
    f.parse_media_line(['media:', 'dw1000', 'Wi-Fi', '(Channel', '11,', 'active)'], data, {})


if __name__ == '__main__':
    test_DarwinNetwork_parse_media_line()

# Generated at 2022-06-11 03:06:27.414414
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network = DarwinNetwork()
    current_if = dict()

    # First case tested: it raises a ValueError because the function
    # requires at least two parameters
    darwin_network.parse_media_line([], current_if, None)
    assert current_if['media'] == 'Unknown'

    # Second case tested
    darwin_network.parse_media_line(['media', 'autoselect'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'

    # Third case tested
    darwin_network.parse_media_line(['media', 'autoselect', '(1000baseT)'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if

# Generated at 2022-06-11 03:06:33.662910
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create a DarwinNetwork object to test the parse_media_line method
    darwinnetwork = DarwinNetwork()
    # create a current_if dict with the required 'type' entry
    current_if = {'type': 'bridge'}  # for the bridge interface
    # set up the media line to be parsed
    words = ['media:', '<unknown', 'type>']
    # call the method to test
    darwinnetwork.parse_media_line(words, current_if, None)
    # check for the expected result
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:44.672452
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin_network_fact_instance = DarwinNetwork()

    # test_media_type_Unknown

# Generated at 2022-06-11 03:06:52.083284
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # MacOSX sets the media to '<unknown type>' for bridge interface
    # and parsing splits this into two words; this if/else helps
    current_if = {}
    DarwinNetwork.parse_media_line(None, current_if, ['media', '<unknown', 'type>'])
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    DarwinNetwork.parse_media_line(None, current_if, ['media', 'autoselect', '<none>'])
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'

# Generated at 2022-06-11 03:07:02.392625
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:07:11.918246
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # This function tests the parse_media_line method of class DarwinNetwork
    # If setup correctly it should return
    # current_if['media'] as 'Unknown'
    # current_if['media_select'] as 'autoselect'
    # current_if['media_type'] as '10baseT/UTP'
    # current_if['media_options'] as ['full-duplex']
    test_string = 'media: autoselect (10baseT/UTP <full-duplex>)'
    current_if = {}
    DarwinNetwork().parse_media_line(test_string.split(), current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '10baseT/UTP'

# Generated at 2022-06-11 03:07:18.361506
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # We instantiate one class DarwinNetwork
    darwin_network = DarwinNetwork()
    # And we instantiate a class GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    # This is the media line we parse
    media_line = 'media: autoselect (100baseTX <full-duplex>) '
    # This is the current_if we pass to parse_media_line
    current_if = {}
    # This is the dictionary of ips for the current interface
    ips = {}
    # This is the expected result from the parse_media_line
    # It is what the method returns in normal conditions