

# Generated at 2022-06-11 03:04:18.798656
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # test for #13795: parse_media_line() should handle bridge interfaces
    result = dict(
        name='bridge100',
        type='<unknown type>',
        media_select='autoselect',
        media_options='',
    )
    words = ['media:', 'autoselect', '<unknown type>', '']
    DarwinNetwork().parse_media_line(words, result, dict())
    assert result == dict(
        name='bridge100',
        type=None,
        media='Unknown',
        media_select='autoselect',
        media_type='unknown type',
        media_options='',
    )


# Generated at 2022-06-11 03:04:28.612718
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()

    ifc.parse_media_line(words=['media:', 'Ethernet', 'autoselect', '(100baseTX)'],
        current_if=ifc.facts['interfaces']['eth0'], ips=['192.168.1.1/24'])

    assert ifc.facts['interfaces']['eth0']['media'] == 'Unknown'
    assert ifc.facts['interfaces']['eth0']['media_select'] == 'Ethernet'
    assert ifc.facts['interfaces']['eth0']['media_type'] == 'autoselect'
    assert ifc.facts['interfaces']['eth0']['media_options'] == ['100baseTX']


# Generated at 2022-06-11 03:04:39.894710
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import sys
    sys.path.append(".")
    from module_utils.facts.network.darwin import DarwinNetwork

    dn = DarwinNetwork()
    current_if = {}
    dn.parse_media_line(['media:', '<unknown type>', '<unknown subtype>'], current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == 'unknown subtype'

    dn.parse_media_line(['media:', '<unknown', 'type>', '<unknown subtype>'], current_if, None)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:04:47.628270
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ['media:', 'autoselect', '<unknown type>']
    darwin_net = DarwinNetwork()
    darwin_net.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] is None

    current_if = {}
    words = ['media:', '10baseT/UTP', '(none)']
    darwin_net = DarwinNetwork()
    darwin_net.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Unknown'

# Generated at 2022-06-11 03:04:55.635365
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    adapter = DarwinNetwork()
    device = dict()

    adapter.parse_media_line(['media:', '<unknown type>', 'autoselect', 'status:', 'inactive'], device, None)
    assert 'Unknown' == device['media_select']
    assert 'unknown type' == device['media_type']

    adapter.parse_media_line(['media:', '<unknown>', '<unknown>', 'status:', 'inactive'], device, None)
    assert 'Unknown' == device['media_select']
    assert 'unknown' == device['media_type']

# Generated at 2022-06-11 03:05:03.744433
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():

    darwin = DarwinNetwork()

    # Testing a simple method
    media = darwin.parse_media_line(words=["media:", "line"], current_if={}, ips={})
    assert media['media'] == 'Unknown' and media['media_select'] == 'line'

    # Testing a simple method with 3 words
    media = darwin.parse_media_line(words=["media:", "line", "test"], current_if={}, ips={})
    assert media['media'] == 'Unknown' and media['media_select'] == 'line' and media['media_type'] == 'test'


# Generated at 2022-06-11 03:05:09.463334
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    darwin_network_parse_media_line = DarwinNetworkCollector._fact_class()
    words = ['media:', 'auto', '1000baseT']
    current_if = dict()
    ips = dict()
    darwin_network_parse_media_line.parse_media_line(words,
                                                     current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type'] == '1000baseT'

# Generated at 2022-06-11 03:05:19.504230
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # create instance
    dn = DarwinNetwork()

    # create test data
    current_if = {}
    ips = []

    # case 1: unknown type
    words = ['media:', '<unknown', 'type>']
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    assert current_if['media_options'] == ''

    # case 2: autoselect
    words = ['media:', 'autoselect', '(1000baseT)']  # 'autoselect' is a select, not a type
    dn.parse_media_line(words, current_if, ips)
    assert current_

# Generated at 2022-06-11 03:05:29.875717
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    # data for test case
    ifdata1 = {'name': 'vboxnet0', 'hwaddr': '0a:00:00:00:00:00'}
    ips1 = []
    words1 = ['media:', 'auto', '1000baseT']
    words2 = ['media:', '<unknown', 'type>']
    words3 = ['media:', 'auto', '1000baseT', '(none)']
    words4 = ['media:', 'auto', '(none)']

    # test case 1
    dn.parse_media_line(words1, ifdata1, ips1)
    assert ifdata1['media'] == 'Unknown'
    assert ifdata1['media_select'] == 'auto'

# Generated at 2022-06-11 03:05:40.403278
# Unit test for method parse_media_line of class DarwinNetwork

# Generated at 2022-06-11 03:05:52.832231
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    ifc = DarwinNetwork()

    # test with no media
    current_if = {}
    words = ['media:','','','','','','']
    ifc.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == ''
    assert current_if['media_type'] == ''
    assert current_if['media_options'] == ''

    # test with just select
    current_if = {}
    words = ['media:','auto', '', '', '', '', '']
    ifc.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'auto'
    assert current_if['media_type']

# Generated at 2022-06-11 03:06:00.160886
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    """
    Testing the parsing of the media line on MacOS
    """
    # Case 1: single word on media line
    dns = DarwinNetwork()
    media_line = 'media: <unknown type>'
    media = {}
    words = media_line.split(' ')
    dns.parse_media_line(words, media, None)
    assert media['media'] == 'Unknown'
    assert media['media_select'] == '<unknown'
    assert media['media_type'] == 'type>'
    assert 'media_options' not in media

# Generated at 2022-06-11 03:06:10.867757
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    target = DarwinNetwork()
    target.parse_media_line({}, {}, None)
    target.parse_media_line(['media:', '', ''], {}, None)
    target.parse_media_line(['media:', '<unknown'], {}, None)
    target.parse_media_line(['media:', 'autoselect', ''], {}, None)
    target.parse_media_line(['media:', 'autoselect', '<unknown'], {}, None)
    target.parse_media_line(['media:', '<unknown', 'type>'], {}, None)
    target.parse_media_line(['media:', 'autoselect', '<unknown', 'type>'], {}, None)

# Generated at 2022-06-11 03:06:15.713255
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()

    # Test media line with media type unknown type
    words = ['media:', '<unknown', 'type>']
    current_if = dict()
    dn.parse_media_line(words, current_if, dict())
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_options'] == dict()
    assert current_if['media_type'] == 'unknown type'

# Generated at 2022-06-11 03:06:27.755404
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create darwin network object
    fact_module = DarwinNetwork()
    # Test media_line parsing for ethernet

# Generated at 2022-06-11 03:06:38.906819
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Create a mock interface
    current_if={}
    # Create a mock list of IP addresses
    ips=[]
    # Create a DarwinNetwork instance
    darwin_network = DarwinNetwork()
    # Set the list of words in the media line and test that the media items are parsed correctly
    words = ['status:', 'active', 'options:', 'none', '<unknown', 'type>']
    darwin_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'active'
    assert current_if['media_type'] == 'unknown type'
    # Set the list of words in the media line for an interface without media options and test that the media items are parsed correctly

# Generated at 2022-06-11 03:06:48.373923
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {
        'name': 'lo0',
        'macaddress': '52:54:00:1c:ef:2c',
        'mtu': 16384,
        'media_select': 'autoselect',
        'media_type': 'en'
    }
    words = [
        'media:',
        'autoselect',
        '(en)'
    ]
    ifconfig_inst = DarwinNetwork({'lo0': current_if})
    ifconfig_inst.parse_media_line(words, current_if)

# Generated at 2022-06-11 03:06:57.791874
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    interface = {}
    ips = {}

    # case 1
    words = ['media:', 'autoselect', '(none)']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, interface, ips)
    assert interface['media_select'] == 'autoselect'
    assert interface['media'] == 'Unknown'
    assert interface['media_options'] == '(none)'
    assert interface['media_type'] == 'none'

    # case 2
    words = ['media:', 'autoselect', '10baseT/UTP']
    DarwinNetwork.parse_media_line(DarwinNetwork(), words, interface, ips)
    assert interface['media_select'] == 'autoselect'
    assert interface['media'] == 'Unknown'
    assert interface['media_options'] == '10baseT/UTP'


# Generated at 2022-06-11 03:07:08.080659
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.darwin import DarwinNetwork

    darwin = DarwinNetwork()

    # Test with media line with media_select and media_type
    line = ['media:', 'autoselect', '(none)', 'status:', 'inactive']
    current_if = {}
    ips = {}

    darwin.parse_media_line(line, current_if, ips)
    assert current_if == {'media': 'Unknown', 'media_select': 'autoselect',
                          'media_type': '(none)', 'media_options': None}

    # Test with media_select, media_type and media_options

# Generated at 2022-06-11 03:07:16.713169
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    import re

    # Media line with multiple words
    mac_line = 'media: autoselect status: active'
    dn = DarwinNetwork()
    current_if = {}
    ips = {}
    mac_words = re.split('\s+', mac_line)
    assert len(mac_words) > 3
    dn.parse_media_line(mac_words, current_if, ips)
    # check that the word list has been parsed into the dict
    assert current_if['media'] == 'Unknown', 'parse_media_line bad media value for multiple word media line'
    assert current_if['media_select'] == mac_words[1], 'parse_media_line bad media_select value for multiple word media line'

# Generated at 2022-06-11 03:07:31.261701
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    # media line with 3 words
    words = ['media:', 'autoselect', '(100baseTX)', '(100baseTX,FDX)']
    dn = DarwinNetwork()
    dn.parse_media_line(words, current_if, {})
    assert 'media' not in current_if
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == ['100baseTX', 'FDX']
    # media line with 2 words
    words = ['media:', '10baseT/UTP']
    dn.parse_media_line(words, current_if, {})
    assert current_if['media_select'] == '10baseT/UTP'


# Generated at 2022-06-11 03:07:38.767696
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    d = DarwinNetwork()
    current_if = {'media': 'n/a'}
    # Test case 1: Unknown media, media_select and media_type
    d.parse_media_line(['media:', '<unknown type>', 'status:', 'inactive'], current_if, {})
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    # Test case 2: Known media, media_select and media_type
    current_if['media'] = 'n/a'
    d.parse_media_line(['media:', 'autoselect', '(none)', 'status:', 'inactive'], current_if, {})
    assert current_if['media_select'] == 'autoselect'

# Generated at 2022-06-11 03:07:48.404310
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Test with a line from ifconfig output containing media information
    dn = DarwinNetwork()
    line = "media: autoselect (<unknown type>)"
    words = line.split()

    current_if = {'device': 'lo0'}
    ips = []
    dn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Unknown', 'Test media failed'
    assert current_if['media_select'] == 'autoselect', 'Test media_select failed'
    assert current_if['media_type'] == 'unknown type', 'Test media_type failed'
    assert current_if['media_options'] == '', 'Test media_options failed'

    # Test with a line from ifconfig output containing a media option
    dn = DarwinNetwork()

# Generated at 2022-06-11 03:07:58.779930
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media', '<unknown', 'type>']
    current_if = {}
    DarwinNetwork().parse_media_line(words, current_if, "")
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'Unknown'
    assert current_if['media_type'] == 'unknown type'
    words = ['media', 'autoselect', 'none', 'none']
    current_if = {}
    DarwinNetwork().parse_media_line(words, current_if, "")
    assert current_if['media'] == 'Unknown'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert current_if['media_options'] == {}

# Generated at 2022-06-11 03:08:01.700347
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    dn = DarwinNetwork()
    result = dn.parse_media_line(['media:', 'autoselect', '<unknown'], None, None)
    assert result['media_select'] == 'autoselect'
    assert result['media_type'] == 'unknown'

# Generated at 2022-06-11 03:08:05.363877
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    current_if = {}
    words = ["media:", "<unknown", "type>"]
    DarwinNetwork(None).parse_media_line(words, current_if, None)
    assert current_if['media_select'] == "Unknown"

# Generated at 2022-06-11 03:08:14.419792
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    line = ("media: <unknown type> " +
            "(0x1000000 <unknown subtype> <no options> <no mode>)")
    current_if = dict()
    ips = dict()
    DarwinNetwork().parse_media_line(line.split(), current_if, ips)
    actual = current_if['media']
    expected = 'Unknown'
    assert actual == expected
    actual = current_if['media_select']
    expected = '<unknown'
    assert actual == expected
    actual = current_if['media_type']
    expected = 'unknown type'
    assert actual == expected
    actual = current_if['media_options']
    expected = None
    assert actual == expected

    line = "media: autoselect (100baseTX <full-duplex>)"
    current_if = dict()
   

# Generated at 2022-06-11 03:08:23.597200
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    test_data = [
        (
            ['media:', '<unknown type>', '(none)'],
            {'media': 'Unknown', 'media_select': 'Unknown', 'media_type': 'unknown type'}
        ),
        (
            ['media:', 'auto', '10baseT/UTP'],
            {'media': 'Unknown', 'media_select': 'auto', 'media_type': '10baseT/UTP'}
        ),
    ]

    # Testing with empty dict
    current_if = {}
    darwinnet = DarwinNetwork()
    for test in test_data:
        darwinnet.parse_media_line(test[0], current_if, {})
        assert current_if == test[1]

# Generated at 2022-06-11 03:08:33.272924
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    # Method parse_media_line should return the expected dict
    # if we pass a media line (list) with one word (media select only)
    # or a list with three words (media select, media type, and media options)
    media_line1 = ['media:', 'autoselect', '(none)']
    media_line2 = ['media:', '<unknown', 'type>']
    current_if = {'name': 'lo0'}
    ips = []
    macos = DarwinNetwork(2, None)
    macos.parse_media_line(media_line1, current_if, ips)
    expected = {'name': 'lo0', 'media': 'Unknown', 'media_select': 'autoselect'}
    assert current_if == expected

# Generated at 2022-06-11 03:08:38.740375
# Unit test for method parse_media_line of class DarwinNetwork
def test_DarwinNetwork_parse_media_line():
    words = ['media:', '<unknown', 'type>']
    current_if = {}
    ips = {}
    d = DarwinNetwork()
    d.parse_media_line(words, current_if, ips)
    assert '<unknown type>' == current_if['media_select']
    assert 'Unknown' == current_if['media']
    assert 'unknown type' == current_if['media_type']
    assert not 'media_options' in current_if