

# Generated at 2022-06-23 01:19:07.357870
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        LSBFactCollector()
    except Exception as exception:
        assert False, exception

# Generated at 2022-06-23 01:19:17.690038
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_dir = os.path.dirname(os.path.realpath(__file__))

    # unit test for case where lsb_release is installed and
    # /etc/lsb-release file exists
    def test_lsb_release_exists_etc_lsb_release_file_exists():
        module = FakeModule(run_command_return=0)
        etc_lsb_release_location = os.path.join(test_dir,
                                                'test_files/lsb_release/etc_lsb_release_1')
        lsb_facts = LSBFactCollector().collect(module=module,
                                               etc_lsb_release_location=etc_lsb_release_location)
        assert("lsb" in lsb_facts)

# Generated at 2022-06-23 01:19:24.842316
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleModule

    test_module = ModuleModule()
    test_module.run_command = call_run_command
    lsb_facts = LSBFactCollector(None, test_module).collect()

    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.1 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'

# Unit test when lsb_bin_path is a file

# Generated at 2022-06-23 01:19:28.954077
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    module = None
    collected_facts = None
    test_LFS = LSBFactCollector()
    assert test_LFS.name == 'lsb'
    test_LFS.collect(module, collected_facts)
    assert test_LFS._fact_ids == set()

# Generated at 2022-06-23 01:19:31.421525
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_obj = LSBFactCollector()
    assert not test_obj.collect()

# Generated at 2022-06-23 01:19:33.664383
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lfs = LSBFactCollector()
    facts = lfs.collect()
    assert type(facts['lsb']) is dict, "Unexpected lsb fact type"

# Generated at 2022-06-23 01:19:36.637341
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-23 01:19:45.758843
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()

    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector_dict = lsb_fact_collector.collect(module=module)

    assert 'lsb' in lsb_fact_collector_dict
    assert lsb_fact_collector_dict['lsb']['id'] == 'RedHatEnterpriseServer'
    assert lsb_fact_collector_dict['lsb']['major_release'] == '7'
    assert lsb_fact_collector_dict['lsb']['description'] == 'Red Hat Enterprise Linux Server'
    assert lsb_fact_collector_dict['lsb']['codename'] == 'Maipo'

# Generated at 2022-06-23 01:19:47.856341
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    a = LSBFactCollector()
    assert a.name == 'lsb'
    assert a._fact_ids == set()

# Generated at 2022-06-23 01:19:50.797962
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("Testing constructor of class LSBFactCollector")
    lsb_collector = LSBFactCollector()
    assert lsb_collector

# Generated at 2022-06-23 01:19:53.687595
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()
    assert l
    assert l.name == 'lsb'
    assert not l._fact_ids

# Generated at 2022-06-23 01:19:55.066062
# Unit test for constructor of class LSBFactCollector

# Generated at 2022-06-23 01:20:02.895696
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    lsb_fact_collector = get_collector_instance('lsb')

    assert(lsb_fact_collector.name == 'lsb')
    assert(lsb_fact_collector._fact_ids == set())
    assert(lsb_fact_collector.STRIP_QUOTES == r'\'\"\\')


# Generated at 2022-06-23 01:20:13.262699
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    class MockModule:
        def __init__(self, bin_path=None, command_rc=0, command_out='', command_err=''):
            self.bin_path = bin_path
            self.command_rc = command_rc
            self.command_out = command_out
            self.command_err = command_err

        def get_bin_path(self, *argv):
            return self.bin_path

        def run_command(self, *argv, **kwargs):
            return (self.command_rc, self.command_out, self.command_err)

    lsb_path = '/usr/bin/lsb_release'
    etc_lsb_release_location = '/etc/lsb-release'

    # No lsb_release or /etc/lsb-release,
    #

# Generated at 2022-06-23 01:20:22.001074
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsbfc = LSBFactCollector()
    lsbfc._lsb_release_file = lambda l: {'id': 'Debian', 'release': '9.11'}

    # TEST-1: When _lsb_release_bin fails
    lsbfc._lsb_release_bin = lambda a, b: {'release': '2'}
    assert lsbfc.collect() == {'lsb': {'release': '2'}}

    # TEST-2: When _lsb_release_bin works as expected
    lsbfc._lsb_release_bin = lambda a, b: {'release': '2', 'id': 'test_id', 'description': 'test_desc', 'codename': 'test_codename'}

# Generated at 2022-06-23 01:20:31.925934
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Open file /usr/bin/lsb_release if it exists
    # otherwise return None
    def _open_mock(path, mode):
        class open_mock_result:
            def __init__(self):
                self.i = 0
                self.content = [
                    "LSB Version: 1.4",
                    "Distributor ID: Ubuntu",
                    "Description: Ubuntu 14.04.5 LTS",
                    "Release: 14.04",
                    "Codename: trusty"
                ]

            def __enter__(self):
                return self

            def __iter__(self):
                return self

            def __next__(self):
                if self.i >= len(self.content):
                    raise StopIteration
                else:
                    self.i += 1

# Generated at 2022-06-23 01:20:32.530545
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector

# Generated at 2022-06-23 01:20:35.709445
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {}
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts is not None
    assert 'lsb' in lsb_facts
    assert lsb_facts['lsb'] == {}

# Generated at 2022-06-23 01:20:47.005765
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    ##Mocking data for testing.
    test_data_1 = """LSB Version:  :core-4.1-amd64:core-4.1-noarch
Distributor ID: Fedora
Description:    Fedora release 25 (Twenty Five)
Release:        25
Codename:       TwentyFive
"""
    test_data_2 = """LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID:
Description:
Release:
Codename:
"""
    test_data_3 = """# File automatically generated by IOx
DISTRIB_ID=Foo
DISTRIB_RELEASE=1.0
DISTRIB_DESCRIPTION="Foo Linux"
DISTRIB_CODENAME=Bar
"""

    ##Mocking object of class LSBFactCollector
    L

# Generated at 2022-06-23 01:20:50.892447
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.lsb import LSBFactCollector

    facts_collector = FactsCollector()
    facts_collector.collectors = [LSBFactCollector]
    facts_collector.collect()

# Generated at 2022-06-23 01:20:52.679491
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        x = LSBFactCollector()
    except Exception as e:
        assert False, e


# Generated at 2022-06-23 01:20:53.469339
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-23 01:21:00.448632
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import os
    os.environ['ETC_LSB_RELEASE'] = "tests/unittests/files/lsb-release.txt"
    lsb_path = "/usr/bin/lsb_release"
    lsb_facts = {}
    lsb_facts = LSBFactCollector()._lsb_release_bin(lsb_path, None)
    assert "Red Hat Enterprise Linux Server" == lsb_facts["description"]
    assert "7.4" == lsb_facts["release"]
    assert "Maipo" == lsb_facts["codename"]
    assert "7" == lsb_facts["major_release"]

# Generated at 2022-06-23 01:21:10.686855
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, 'Foo: bar', '')
    lsb_path = mock_module.get_bin_path('lsb_release')
    lsb_result = LSBFactCollector()._lsb_release_bin(lsb_path, mock_module)
    assert lsb_result['id'] == 'bar'

    mock_module = MockModule()
    mock_module.run_command.return_value = (0, 'Foo: bar', '')
    lsb_path = mock_module.get_bin_path('lsb_release')
    lsb_result = LSBFactCollector()._lsb_release_bin(lsb_path, mock_module)
    assert lsb_result['id'] == 'bar'

# Generated at 2022-06-23 01:21:12.931475
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'

# Generated at 2022-06-23 01:21:20.466056
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec = dict()
    )

    LSBFactCollector._lsb_release_file = Mock(return_value = {})
    LSBFactCollector._lsb_release_bin = Mock(return_value = {})

    test_collector = LSBFactCollector()

    test_collector.collect(module=test_module)

    LSBFactCollector._lsb_release_file.assert_called_with('/etc/lsb-release')
    LSBFactCollector._lsb_release_bin.assert_not_called()

# Generated at 2022-06-23 01:21:31.326590
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import platform
    import tempfile
    from ansible.module_utils.facts import collector
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector

    def expected_lsb_facts(self, module):
        return {
            'codename': '',
            'description': '',
            'id': '',
            'major_release': '',
            'release': ''
        }

    test_platform = platform.system().lower()
    # Only run on linux
    if test_platform != 'linux':
        return None

    # Create a tmp directory that contains lsb
    tmp_dir = tempfile.mkdtemp

# Generated at 2022-06-23 01:21:37.010565
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect(module=None, collected_facts=None)
    if lsb_facts is None:
        assert False
    else:
        assert type(lsb_facts) == dict
        assert type(lsb_facts.get('lsb')) == dict

# Generated at 2022-06-23 01:21:38.730368
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert isinstance(x, LSBFactCollector)


# Generated at 2022-06-23 01:21:45.843705
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    # Create a fake AnsibleModule
    class AnsibleModuleFake:
        def __init__(self, run_command_return_value, get_bin_path_return_value):
            self.run_command_return_value = run_command_return_value
            self.get_bin_path_return_value = get_bin_path_return_value

        def run_command(self, cmd, errors):
            return self.run_command_return_value

        def get_bin_path(self, path):
            return self.get_bin_path_return_value

    class FakeAnsibleFile:
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content


# Generated at 2022-06-23 01:21:48.644550
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    f = LSBFactCollector()
    assert f.name == 'lsb'

# Generated at 2022-06-23 01:21:50.784905
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("Testing LSBFactCollector constructor")
    lsb_collector = LSBFactCollector()
    assert lsb_collector is not None

# Generated at 2022-06-23 01:22:01.132815
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsbfc = LSBFactCollector()
    lsbfc._lsb_release_bin = lambda lsb_path, module: {'release': '7.3',
                                                       'id': 'Ubuntu',
                                                       'description': 'Ubuntu 14.04.5 LTS',
                                                       'release': '14.04',
                                                       'codename': 'trusty'}
    lsbfc._lsb_release_file = lambda release_file: {}
    lsb_facts = lsbfc.collect()
    assert lsb_facts['lsb']['release'] == '7.3'
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 14.04.5 LTS'
    assert l

# Generated at 2022-06-23 01:22:02.971377
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.name == 'lsb'

# Generated at 2022-06-23 01:22:09.569166
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = DummyModule({'lsb_release': 'path/to/lsb_release'})
    lsb_facts = {'id': 'id', 'release': 'release',
                 'description': 'description', 'codename': 'codename'}
    collector = LSBFactCollector()
    collector._lsb_release_bin = MagicMock(return_value=lsb_facts)
    lsb = collector.collect(module=module)
    assert lsb.get('lsb') == lsb_facts

# Generated at 2022-06-23 01:22:12.687195
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbFC = LSBFactCollector()
    assert lsbFC.name == 'lsb'

# Generated at 2022-06-23 01:22:13.851702
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert issubclass(LSBFactCollector, BaseFactCollector)


# Generated at 2022-06-23 01:22:22.280508
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

    # List of attributes, methods and properties.
    expected_attributes = [ 'collect' ]
    expected_methods = [ '_lsb_release_bin', '_lsb_release_file' ]

    # Compare the set of attributes, methods and properties of the class with the
    # expected values
    actual_attributes = dir(LSBFactCollector)
    assert set(actual_attributes) == set(expected_attributes)
    actual_methods = [e for e in actual_attributes if callable(getattr(LSBFactCollector, e))]

# Generated at 2022-06-23 01:22:28.064165
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    name = 'lsb'
    collected_facts = {}
    lsb_facts = lsbfc.collect(collected_facts=collected_facts)
    assert type(lsb_facts) is dict
    assert lsb_facts['lsb'] == {}
    assert lsbfc.name == name

# Generated at 2022-06-23 01:22:29.546152
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert 'lsb' == lsb.name


# Generated at 2022-06-23 01:22:38.420969
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    m = MockModule()
    lsb_path = '/usr/bin/lsb_release'
    m.get_bin_path.return_value = lsb_path
    lsb_facts = {}
    lsb_facts['id'] = "CentOS"
    lsb_facts['release'] = '7.5.1804'
    lsb_facts['major_release'] = '7'
    lsb_facts['description'] = 'CentOS Linux release 7.5.1804 (Core)'
    lsb_facts['codename'] = 'Core'
    m.run_command.return_value = (0, " ".join(['{0}:{1}'.format(k, v) for k, v in lsb_facts.items()]), "")
    c = LSBFactCollector()
    result = c.collect

# Generated at 2022-06-23 01:22:48.469941
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock({'command': '/usr/bin/lsb_release'})
    LSBFactCollectorMock = LSBFactCollector()
    result = LSBFactCollectorMock.collect(module=module)
    expected_result = {'lsb': {'codename': 'trusty',
                               'description': 'Ubuntu 14.04.1 LTS',
                               'id': 'Ubuntu',
                               'major_release': '14',
                               'release': '14.04'}}
    assert result == expected_result


# Generated at 2022-06-23 01:22:57.478134
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ModuleFacts

    test_module = ModuleFacts()
    test_module.lsb_release = {}
    test_module.lsb_release['release'] = '10.1'
    test_module.lsb_release['major_release'] = '10'
    test_module.lsb_release['id'] = 'Foo'
    test_module.lsb_release['codename'] = 'Bar'

    test_lsb = LSBFactCollector()
    test_facts = test_lsb.collect(test_module)
    print(test_facts)


# Generated at 2022-06-23 01:22:59.928923
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_factCollector = LSBFactCollector()
    assert lsb_factCollector.name == 'lsb'
    assert lsb_factCollector._fact_ids == set()

# Generated at 2022-06-23 01:23:01.479106
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert isinstance(LSBFactCollector(), LSBFactCollector)

# Generated at 2022-06-23 01:23:11.390506
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector._lsb_release_file = lambda x: {"id":"RedHatEnterpriseServer", "release":"7.6 (Maipo)"}
    lsb_fact_collector._lsb_release_bin = lambda lsb_path, module: {"id":"RedHatEnterpriseServer", "release":"7.6 (Maipo)"}
    result_facts = lsb_fact_collector.collect()
    expected_facts = {'lsb': {'id': 'RedHatEnterpriseServer', 'release': '7.6 (Maipo)', 'major_release': '7'}}
    assert result_facts == expected_facts


# Generated at 2022-06-23 01:23:13.234766
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.name == 'lsb'

# Generated at 2022-06-23 01:23:16.740228
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb.collect() == {'lsb': {}}
    assert lsb.collect(collected_facts=None) == {}

# Generated at 2022-06-23 01:23:18.155601
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'

# Generated at 2022-06-23 01:23:27.544033
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import AnsibleModuleMock
    from ansible.module_utils.facts.utils import get_bin_path
    from ansible.module_utils.facts.utils import get_module

    from ansible.module_utils.facts.utils import MockModule

    LSBFactCollector.STRIP_QUOTES = '\''

    module = get_module()
    # case lsb_release
    with MockModule(module):
        MockedModule = AnsibleModuleMock()
        MockedModule.params = {}

# Generated at 2022-06-23 01:23:34.422955
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector._lsb_release_bin = lambda self, x, y: {'release': '16.04',
                                                            'id': 'Ubuntu',
                                                            'description': 'Ubuntu 16.04.4 LTS',
                                                            'codename': 'xenial'}
    LSBFactCollector._lsb_release_file = lambda self, x: {'release': '16.04',
                                                          'id': 'Ubuntu',
                                                          'description': 'Ubuntu 16.04.4 LTS',
                                                          'codename': 'xenial'}
    fact_collector = LSBFactCollector()
    facts = fact_collector.collect()
    assert facts['lsb']['release'] == '16.04'

# Generated at 2022-06-23 01:23:44.228201
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # input parameters
    params = {
        'ansible_facts': {
            'lsb': {}
        }
    }
    lsb_facts = {'major_release': '6', 'description': 'CentOS release 6.4 (Final)', 'release': '6.4', 'id': 'CentOS', 'codename': 'Final'}

    # LSBFactCollector class object
    collector = LSBFactCollector()
    
    # run '_lsb_release_bin' method
    lsb_facts = collector._lsb_release_bin('lsb_release', '-a')
    

    # Checking the result
    assert facts_dict['lsb'] == lsb_facts


# Generated at 2022-06-23 01:23:54.402218
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_expected_lsb = {
        'description': 'Ubuntu 16.04.3 LTS',
        'codename': 'xenial',
        'id': 'Ubuntu',
        'release': '16.04',
        'major_release': '16'
    }

    def mock_get_file_lines(filename):
        return ['DISTRIB_ID=Ubuntu',
                'DISTRIB_RELEASE=16.04',
                'DISTRIB_CODENAME=xenial',
                'DISTRIB_DESCRIPTION="Ubuntu 16.04.3 LTS"']

    def mock_get_bin_path(name):
        return 'lsb_release'

    def mock_run_command(cmd, errors):
        return 0, '', ''

    my_module = MockModule()
   

# Generated at 2022-06-23 01:23:57.390026
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == 'lsb'
    assert lsb_facts._fact_ids == set()

# Generated at 2022-06-23 01:24:01.831133
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule(**{'command.exists': lambda x: True, 'get_bin_path': lambda x: 'bin_path'})
    LSBFactCollector.collect(module)
    module.run_command.assert_called_with(['bin_path', '-a'], errors='surrogate_then_replace')

# Generated at 2022-06-23 01:24:07.885327
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    rc, out, err = module.run_command(['/bin/ls /proc/cpuinfo'], errors='surrogate_then_replace')
    if rc != 0:
        module.fail_json(msg="lsb_release not found in PATH")

    lsb_facts = LSBFactCollector().collect(module)
    assert 'lsb' in lsb_facts

# Generated at 2022-06-23 01:24:10.078667
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbFactCollector = LSBFactCollector()
    assert isinstance(lsbFactCollector, LSBFactCollector)

# Generated at 2022-06-23 01:24:12.194954
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lfc = LSBFactCollector()

    assert lfc.name == 'lsb'
    assert lfc._fact_ids == set()

# Generated at 2022-06-23 01:24:21.005723
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible_collections.community.general.tests.unit.compat.mock import patch, Mock

    mock_module = Mock()

    executables = ['/bin/lsb_release']
    for executable in executables:
        mock_module.get_bin_path.return_value = executable
        with patch("ansible.module_utils.facts.collector.BaseFactCollector._load_facts_from_cache") as mock_cache:
            mock_cache.return_value = {}
            with patch("ansible.module_utils.facts.collector.BaseFactCollector._exec_command") as mock_command:
                LSBFactCollector().collect(mock_module, {})
                mock_command.assert_called_with([executable, '-a'], errors='surrogate_then_replace')

# Generated at 2022-06-23 01:24:26.428465
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleStub()
    lsb_obj = LSBFactCollector()

    # invoking the method with None value for module argument
    assert lsb_obj.collect(module=None) == {}

    # invoking the method with correct arguments
    assert lsb_obj.collect(module=module) == {'lsb':{}}

# Generated at 2022-06-23 01:24:34.317345
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsbin = LSBFactCollector()
    lsb_withoutput = lsbin._lsb_release_bin('/usr/bin/awk',
                                             module='AnsibleModule')
    lsb_withoutput = lsbin._lsb_release_bin('/usr/bin/awk',
                                             module='AnsibleModule')
    lsb_withfile = lsbin._lsb_release_file('/etc/lsb-release')
    assert lsb_withoutput != {}
    assert lsb_withfile != {}


# Generated at 2022-06-23 01:24:39.831399
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_object = LSBFactCollector()
    assert lsb_object.name == 'lsb'
    assert lsb_object._fact_ids == set()
    assert lsb_object.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-23 01:24:42.630795
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector.fact_ids == set()



# Generated at 2022-06-23 01:24:48.880871
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    result = lsb.collect()
    assert(result['lsb']['release'] == '20.04')
    assert(result['lsb']['id'] == 'Ubuntu')
    assert(result['lsb']['description'] == 'Ubuntu 20.04 LTS')
    assert(result['lsb']['codename'] == 'focal')

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-23 01:24:53.538481
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == "lsb"
    assert collector._fact_ids is not None
    assert collector.STRIP_QUOTES is not None

# Unit tests for _lsb_release_bin function

# Generated at 2022-06-23 01:24:59.532291
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import mock

    module = mock.Mock()
    module.get_bin_path = mock.Mock()
    module.get_bin_path.return_value = "lsb_release"

    collector = LSBFactCollector()

    # run the test
    collector.collect(module=module)

    # assert that lsb_release was invoked
    module.run_command.assert_called_once_with(["lsb_release", "-a"], errors='surrogate_then_replace')


# Generated at 2022-06-23 01:25:03.581400
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_instance = LSBFactCollector()
    assert lsb_fact_instance.name == 'lsb'
    assert isinstance(lsb_fact_instance._fact_ids, set)
    assert lsb_fact_instance.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-23 01:25:06.701281
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    f = LSBFactCollector()
    assert (f.name == 'lsb')
    assert (f.collect() == {'lsb': {}})

# Generated at 2022-06-23 01:25:14.735382
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts_collector = LSBFactCollector()
    assert lsb_facts_collector.name == 'lsb'
    assert lsb_facts_collector._fact_ids == set()
    assert lsb_facts_collector.STRIP_QUOTES == '\'\"\\'
    assert lsb_facts_collector.collect() == {
        'lsb': {
            'id': 'Ubuntu',
            'release': '18.04',
            'description': 'Ubuntu 18.04.1 LTS',
            'codename': 'bionic'
        }
    }

# Generated at 2022-06-23 01:25:25.548444
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    Unit test for method collect of class: LSBFactCollector
    """
    # create instance of class LSBFactCollector
    lsbfc = LSBFactCollector()

    # test empty case
    lsb_facts = lsbfc.collect()
    assert 'lsb' not in lsb_facts

    # test no lsb_release
    class ModuleFake():
        def run_command(self, args, errors=None):
            return (1, 'output', 'error')

        def get_bin_path(self, cmd):
            return None

    lsb_facts = lsbfc.collect(module=ModuleFake())
    assert 'lsb' not in lsb_facts

    # test with lsb_release
    class ModuleFake():
        def run_command(self, args, errors=None):
            return

# Generated at 2022-06-23 01:25:30.536829
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_bc = LSBFactCollector()
    facts = lsb_bc.collect()
    assert isinstance(facts, dict)
    assert 'lsb' in facts
    assert isinstance(facts['lsb'], dict)
    assert 'id' in facts['lsb']
    assert 'release' in facts['lsb']
    assert 'codename' in facts['lsb']
    assert 'description' in facts['lsb']

# Generated at 2022-06-23 01:25:40.375412
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    mock_module = MagicMock()

    mock_module.get_bin_path.return_value = '/bin/lsb_release'
    mock_module.run_command.return_value = (0, 'Description:\tUbuntu 16.04 LTS\nRelease:\t16.04\nCodename:\txenial', '')
    lsb_facts = LSBFactCollector().collect(mock_module)
    expected_lsb_facts = {'codename': 'xenial', 'description': 'Ubuntu 16.04 LTS', 'id': 'Description', 'major_release': '16', 'release': '16.04'}
    assert expected_lsb_facts == lsb_facts['lsb']

    mock_module.reset_mock()

# Generated at 2022-06-23 01:25:49.752219
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import platform
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import json

    from ansible.module_utils.facts import collector

    class MockModule:
        def __init__(self):
            self.params = {}

        def run_command(self, cmd, errors='surrogate_then_replace'):
            out = err = rc = None
            if cmd[0] == '/tmp/lsb_release':
                out = '''
                Distributor ID:	ubuntu
                Description:	Ubuntu 16.04.3 LTS
                Release:	16.04
                Codename:	xenial
                LSB Version:	n/a
                Distribution Release: Ubuntu 16.04.3 LTS
                '''
                rc = 0

# Generated at 2022-06-23 01:25:59.252835
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()

    lsb_path_none_bin_path_none = lsb_fact_collector.collect(collected_facts=None, module=None)
    lsb_path_none_bin_path_non_none = lsb_fact_collector.collect(collected_facts=None, module=type('ModuleUtils',
                                                                                                 (object,),
                                                                                                 {'get_bin_path':
                                                                                                     lambda self, arg1: None}))


# Generated at 2022-06-23 01:26:01.760618
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()

# Generated at 2022-06-23 01:26:08.071615
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    class module(object):
        def __init__(self):
            self.params = {
                'system': None
            }

        def get_bin_path(self, binary):
            return None

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, "", ""
    module_obj = module()
    LSBFactCollector_obj = LSBFactCollector()

    try:
        LSBFactCollector_obj.collect(module_obj)
    except Exception as e:
        raise e

# Generated at 2022-06-23 01:26:10.329714
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'



# Generated at 2022-06-23 01:26:19.056909
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    if not HAS_PSUTIL:
        raise SkipTest("[unittest/skip] psutil python module is not installed")
    
    lsb_facts = LSBFactCollector().collect()
    facts_dict = {}
    args = ['/etc/lsb-release', '/usr/bin/lsb_release']
    if os.path.exists(args[0]):
        lsb_facts = LSBFactCollector._lsb_release_file(args[0])
    elif os.path.exists(args[1]):
        lsb_facts = LSBFactCollector._lsb_release_bin(args[1], None)
    else:
        return facts_dict

# Generated at 2022-06-23 01:26:23.608460
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-23 01:26:25.927806
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = None
    collected_facts = None

    lsb_facts = LSBFactCollector().collect(module, collected_facts)

    print(lsb_facts)

# Generated at 2022-06-23 01:26:33.419053
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    manager = LSBFactCollector({})
    expected = {
            'lsb': {
                'codename': 'bionic',
                'description': 'Ubuntu 18.04.2 LTS',
                'id': 'Ubuntu',
                'major_release': '18',
                'release': '18.04',
            }
        }
    assert manager.collect({'run_command': lambda cmd, **kwargs: (0,
                                                         '\n'.join([
                                                             'LSB Version:',
                                                             'Distributor ID: Ubuntu',
                                                             'Description: Ubuntu 18.04.2 LTS',
                                                             'Release: 18.04',
                                                             'Codename: bionic'
                                                         ]), '')}, {}) == expected

# Generated at 2022-06-23 01:26:43.831416
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test collect with lsb_release available
    module = AnsibleModuleMock(command_warnings=[])
    module.run_command = lambda x, **kwargs: (0, 'LSB Version: :core-4.1-amd64:core-4.1-noarch\nDistributor ID: Debian\nDescription: Debian GNU/Linux 7.9 (wheezy) \nRelease: 7.9 \nCodename: wheezy', '')
    module.get_bin_path = lambda x: '/usr/bin/lsb_release'
    lsb = LSBFactCollector()

# Generated at 2022-06-23 01:26:48.631930
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    _test = LSBFactCollector()
    assert _test.name == 'lsb'
    assert _test._fact_ids == set()
    assert _test.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-23 01:26:50.154263
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.name == "lsb"

# Generated at 2022-06-23 01:26:52.576813
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None

# Generated at 2022-06-23 01:26:53.774070
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'

# Generated at 2022-06-23 01:27:00.971095
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector.STRIP_QUOTES == "'\"\\"
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == "'\"\\"

# Unit tests for function _lsb_release_bin of class LSBFactCollector

# Generated at 2022-06-23 01:27:10.246088
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    '''
    Unit test for collect method of LSBFactCollector
    '''
    import unittest
    import mock

    class LSBFactCollectorTestCase(unittest.TestCase):
        def setUp(self):
            self.lsb_collector = LSBFactCollector()
            self.mock_moudle = mock.Mock()
            self.lsb_path = 'lsb_path'

        def test_lsb_release_bin(self):
            lsb_path = self.lsb_path
            self.mock_moudle.get_bin_path.return_value = lsb_path

# Generated at 2022-06-23 01:27:18.567379
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import os, sys
    sys.modules['ansible.module_utils.facts.lsb'] = os.path.dirname(os.path.realpath(__file__))
    from ansible.module_utils.facts.lsb import LSBFactCollector

    class testModule:
        def __init__(self):
            self.params = {}

        def run_command(self, cmd, errors='surrogate_then_replace'):
            retval = {'rc': 0, 'out': '', 'err': ''}

            if cmd[0] == 'lsb_release':
                retval['out'] = '''\
Distributor ID:	Ubuntu
Description:	Ubuntu 14.04.2 LTS
Release:	14.04
Codename:	trusty
'''

            return retval


# Generated at 2022-06-23 01:27:21.360901
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact = LSBFactCollector()
    assert fact.name == 'lsb'
    assert fact._fact_ids == set()
    assert fact.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-23 01:27:26.839351
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-23 01:27:29.198407
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_instance = LSBFactCollector()
    assert lsb_fact_instance.name == 'lsb'

# Generated at 2022-06-23 01:27:30.620410
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == "lsb"

# Generated at 2022-06-23 01:27:31.911976
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    a = LSBFactCollector()
    assert a is not None

# Generated at 2022-06-23 01:27:39.394320
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector.STRIP_QUOTES == '\'\"\\'
    assert lsb_fact_collector._fact_ids is not None
    assert len(lsb_fact_collector._fact_ids) == 0
    assert lsb_fact_collector._lsb_release_bin is not None
    assert lsb_fact_collector._lsb_release_file is not None
    assert lsb_fact_collector.collect is not None

# Generated at 2022-06-23 01:27:45.280929
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert isinstance(LSBFactCollector._fact_ids, set)


# Generated at 2022-06-23 01:27:48.665389
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    lsb_facts_collector = LSBFactCollector()

    lsb_facts_collector.collect()

# Generated at 2022-06-23 01:27:52.021924
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    sut = LSBFactCollector()
    assert sut is not None and isinstance(sut, LSBFactCollector)

# Generated at 2022-06-23 01:27:53.428501
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # load the class for testing
    LSBFactCollector()

# Generated at 2022-06-23 01:28:02.375318
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # create LSBFactCollector
    testlsb = LSBFactCollector()

    # create mock module method run_command
    def run_command(cmd, **kwargs):
        # return results of command execution
        return 1, """Description:    Ubuntu 16.04.3 LTS
Release:        16.04
Codename:       xenial
""", 'error'

    # set mock_module to module with mock_run_command
    mock_module = type('', (object,), {
        'run_command': run_command
    })

    # collect facts
    testlsb.collect(mock_module)

    # assert lsb facts

# Generated at 2022-06-23 01:28:04.985377
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    # Default value of name
    assert obj.name == 'lsb'
    assert obj._fact_ids == set()
    assert obj.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-23 01:28:09.228944
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lfc = LSBFactCollector()
    assert lfc.name == 'lsb'
    assert not lfc.mandatory_facts
    assert len(lfc._fact_ids) == 0


# Generated at 2022-06-23 01:28:12.244314
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == 'lsb'
    assert lsb_facts._fact_ids == set()
    assert lsb_facts.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-23 01:28:23.226376
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collectors import get_collector_instance
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector

    lsb_facts_from_file = {
        'id': 'Ubuntu',
        'release': '16.04',
        'description': 'Ubuntu 16.04.3 LTS',
        'codename': 'xenial'
    }

    lsb_facts_from_bin = {
        'id': 'Ubuntu',
        'release': '16.04.3 LTS (Xenial Xerus)',
        'description': 'Ubuntu 16.04.3 LTS',
        'codename': 'xenial'
    }


# Generated at 2022-06-23 01:28:24.028679
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-23 01:28:26.009925
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb
    assert lsb.name == 'lsb'
    assert lsb.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-23 01:28:37.789738
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """Unit test for LSBFactCollector method collect"""
    #
    # These expected values are for an Ubuntu system
    #
    expected_lsb_facts = {
        'description': 'Ubuntu 14.04.5 LTS',
        'id': 'Ubuntu',
        'major_release': '14',
        'release': '14.04',
        'codename': 'trusty'
    }
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect()
    assert lsb_facts
    assert lsb_facts['lsb'] == expected_lsb_facts

# Generated at 2022-06-23 01:28:47.160051
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_size_from_fstab
    from ansible.module_utils.facts.utils import is_exe


    class TestModule:
        def __init__(self):
            self.params = {'gather_timeout': 10}

        def get_bin_path(self, bin):
            return bin

    class TestFacts():
        def ansible_test(self):
            return

# Generated at 2022-06-23 01:28:52.210317
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    lsb_collector.content = {'lib_path': '/usr/local/lib', 'bin_path': '/usr/local/bin'}
    lsb_collector.collect()

# Generated at 2022-06-23 01:28:56.429569
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """
    Unit test for constructor of class LSBFactCollector
    """
    lsb_fc = LSBFactCollector()

    assert lsb_fc.name == 'lsb'
    assert lsb_fc._fact_ids is not None
    assert lsb_fc.STRIP_QUOTES == "'\"\\"


# Generated at 2022-06-23 01:29:07.520217
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    class AnsibleModuleMock():
        def __init__(self, lsb_path):
            self._path = lsb_path

        def get_bin_path(self, name):
            if name == 'lsb_release':
                return self._path

        def run_command(self, args, errors='surrogate_then_replace'):
            if args[0] == '/dev/null':
                # /dev/null has not lsb_release installed
                return [1, '', '']

            # /usr/bin/lsb_release has lsb_release installed