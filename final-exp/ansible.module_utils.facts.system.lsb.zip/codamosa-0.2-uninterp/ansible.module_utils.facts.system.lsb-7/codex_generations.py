

# Generated at 2022-06-17 02:16:26.245041
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:16:37.873175
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Test the collect method
    lsb_facts = lsb_fact_collector.collect(module=module)
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_

# Generated at 2022-06-17 02:16:47.698918
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_excluded_facts
   

# Generated at 2022-06-17 02:16:52.784858
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:00.807871
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.2 LTS'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:17:08.291615
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:11.704437
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:16.487905
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:27.043604
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 02:17:34.050630
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:51.570247
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Create a mock module
    mock_module = MockModule()

    # Create a mock ansible module
    mock_ansible_module = MockAnsibleModule()

    # Set the lsb_release path
    mock_ansible_module.get_bin_path_mock_result = '/usr/bin/lsb_release'

    # Set the lsb_release output

# Generated at 2022-06-17 02:17:56.973994
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:00.290992
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:07.369966
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:12.893252
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:18.274435
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:27.121304
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/lsb_release')

    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Call method collect of the LSBFactCollector object
    lsb_facts = lsb_fact_collector.collect(module=module)

    # Assert that the return value of method collect is a dictionary
    assert isinstance(lsb_facts, dict)

    # Assert that the dictionary returned by method collect has the key 'lsb'
    assert 'lsb' in lsb_facts

    #

# Generated at 2022-06-17 02:18:30.014439
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:32.651708
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:18:34.807490
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'

# Generated at 2022-06-17 02:18:50.785495
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:53.797992
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:04.043329
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exception
    from ansible.module_utils.facts.collector import get_collector_exception_only
    from ansible.module_utils.facts.collector import get_collector_exception_msg
    from ansible.module_utils.facts.collector import get_collector_exception_traceback
    from ansible.module_utils.facts.collector import get_collector_exception_type
   

# Generated at 2022-06-17 02:19:08.699877
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:12.609283
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:19.042434
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:19:24.732223
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:29.449689
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:33.628162
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:43.229765
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock command
    command = CommandMock()

    # Create a mock file
    file = FileMock()

    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Test the collect method
    lsb_fact_collector.collect(module=module, collected_facts=None)

    # Assert that the command was run
    assert command.run_command.called

    # Assert that the file was read
    assert file.read.called

    # Assert that the lsb_release file was read
    assert file.read.call_args[0][0] == '/etc/lsb-release'

    # Assert that the lsb_release file was read

# Generated at 2022-06-17 02:20:10.582762
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:17.061541
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:20.476779
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:29.180477
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {'id': 'CentOS', 'release': '7.0.1406', 'major_release': '7', 'description': 'CentOS Linux release 7.0.1406 (Core)', 'codename': 'Core'}
    lsb_path = '/usr/bin/lsb_release'
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value=lsb_path)
    lsb_collector = LSBFactCollector()
    lsb_collector.collect(module=module)
    assert lsb_collector.collect(module=module) == {'lsb': lsb_facts}


# Generated at 2022-06-17 02:20:30.972326
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:32.996972
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb'] == {'id': 'Ubuntu', 'release': '16.04', 'description': 'Ubuntu 16.04.3 LTS', 'codename': 'xenial', 'major_release': '16'}

# Generated at 2022-06-17 02:20:37.047552
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:44.679132
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class for the lsb_release script
    class MockLSBRelease(object):
        def __init__(self, module):
            self.module = module

        def run_command(self, command, errors='surrogate_then_replace'):
            if command[0] == '/usr/bin/lsb_release':
                return (0, '''
LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: Fedora
Description:    Fedora release 28 (Twenty Eight)
Release:        28
Codename:       TwentyEight
''', '')
            else:
                return (1, '', '')


# Generated at 2022-06-17 02:20:51.206294
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:54.692467
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:22:00.769740
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:22:08.179879
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'

# Generated at 2022-06-17 02:22:15.798381
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    Unit test for method collect of class LSBFactCollector
    """
    lsb_facts = LSBFactCollector().collect()
    assert isinstance(lsb_facts, dict)
    assert 'lsb' in lsb_facts
    assert isinstance(lsb_facts['lsb'], dict)
    assert 'id' in lsb_facts['lsb']
    assert 'release' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-17 02:22:26.336789
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test with lsb_release
    module = MockModule()
    module.run_command = Mock(return_value=(0, '''
LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: RedHatEnterpriseServer
Description:    Red Hat Enterprise Linux Server release 7.3 (Maipo)
Release:        7.3
Codename:       Maipo
''', ''))
    lsb_facts = LSBFactCollector().collect(module=module)

# Generated at 2022-06-17 02:22:35.470780
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}

        def get_bin_path(self, name):
            return '/usr/bin/lsb_release'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, '''
LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: Fedora
Description:    Fedora release 28 (Twenty Eight)
Release:        28
Codename:       TwentyEight
''', ''

    # Create a fake ansible module
    class FakeAnsibleModule:
        def __init__(self):
            self.params = {}
            self.run_command_environ

# Generated at 2022-06-17 02:22:46.214137
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:22:49.609622
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:22:54.509387
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:22:58.454280
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:23:06.360392
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert 'lsb' in lsb_facts
    assert 'id' in lsb_facts['lsb']
    assert 'release' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-17 02:25:48.050435
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:25:58.288639
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command
    module.get_bin_path = AnsibleModuleMock.get_bin_path
    module.get_bin_path.return_value = '/usr/bin/lsb_release'
    module.run_command.return_value = (0, 'LSB Version:    :core-4.1-amd64:core-4.1-noarch\nDistributor ID: Fedora\nDescription:    Fedora release 28 (Twenty Eight)\nRelease:        28\nCodename:       TwentyEight', '')
    lsb_facts = LSBFactCollector().collect(module=module)
    assert lsb_facts['lsb']['id'] == 'Fedora'

# Generated at 2022-06-17 02:26:00.996088
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:26:14.447800
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_package_facts
    from ansible.module_utils.facts.utils import get_service_status
    from ansible.module_utils.facts.utils import get_sysctl