

# Generated at 2022-06-17 02:16:32.506717
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:16:36.909225
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:16:40.702655
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:16:46.413324
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:16:52.670056
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:04.535892
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path_cache = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return self.bin_path_cache[name]

    # Create a mock module
    module = MockModule()

    # Create a mock class
    class MockFile(object):
        def __init__(self):
            self.content = ''

        def read(self):
            return self.content

    # Create a mock file
    file = MockFile()

    # Create a mock class
    class MockOs(object):
        def __init__(self):
            self.path = {}
            self.path['exists'] = False


# Generated at 2022-06-17 02:17:07.372599
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'

# Generated at 2022-06-17 02:17:14.027162
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.1 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:17:17.466869
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:22.041125
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:41.543850
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:47.719492
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:50.986412
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:53.413483
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:04.005726
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test with lsb_release command
    lsb_path = '/usr/bin/lsb_release'
    lsb_facts = {'id': 'Ubuntu', 'release': '16.04', 'codename': 'xenial', 'description': 'Ubuntu 16.04.3 LTS'}
    lsb_facts_major_release = {'id': 'Ubuntu', 'release': '16.04', 'codename': 'xenial', 'description': 'Ubuntu 16.04.3 LTS', 'major_release': '16'}
    lsb_facts_no_major_release = {'id': 'Ubuntu', 'codename': 'xenial', 'description': 'Ubuntu 16.04.3 LTS'}

# Generated at 2022-06-17 02:18:10.445451
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a mock ansible module
    lsb_collector = LSBFactCollector()
    lsb_facts = lsb_collector.collect(module=module)
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'

# Generated at 2022-06-17 02:18:13.670481
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'
    assert lsb_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:24.037475
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector._lsb_release_bin = lambda x, y: {'id': 'Ubuntu', 'release': '18.04', 'description': 'Ubuntu 18.04.1 LTS', 'codename': 'bionic'}
    lsb_fact_collector._lsb_release_file = lambda x: {}
    assert lsb_fact_collector.collect() == {'lsb': {'id': 'Ubuntu', 'release': '18.04', 'description': 'Ubuntu 18.04.1 LTS', 'codename': 'bionic', 'major_release': '18'}}


# Generated at 2022-06-17 02:18:29.740887
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:34.072069
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:03.262152
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:07.678354
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:11.866575
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:18.511504
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:19:30.455034
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {
        'id': 'Ubuntu',
        'release': '16.04',
        'description': 'Ubuntu 16.04.1 LTS',
        'codename': 'xenial',
        'major_release': '16'
    }
    lsb_facts_bin = {
        'id': 'Ubuntu',
        'release': '16.04',
        'description': 'Ubuntu 16.04.1 LTS',
        'codename': 'xenial'
    }
    lsb_facts_file = {
        'id': 'Ubuntu',
        'release': '16.04',
        'description': 'Ubuntu 16.04.1 LTS',
        'codename': 'xenial',
        'major_release': '16'
    }
    lsb_

# Generated at 2022-06-17 02:19:40.234745
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import MockCommand
    from ansible.module_utils.facts.collector import MockFileLine
    from ansible.module_utils.facts.collector import MockFileLines
    from ansible.module_utils.facts.collector import MockFileStat

    module = MockModule()
    module.get_bin_path = MockCommand()
    module.run_command = MockCommand()
    module.get_file_lines = MockFileLines()
    module.get_file_stat = MockFileStat()

    # no lsb_release, try looking in /etc/lsb-release
    module.get_file_lines.set_file_lines

# Generated at 2022-06-17 02:19:44.951095
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '14.04'
    assert lsb_facts['lsb']['major_release'] == '14'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 14.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'trusty'

# Generated at 2022-06-17 02:19:49.969286
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:55.849519
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:20:02.667165
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 02:20:32.912709
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:39.695921
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    #
    # Test with lsb_release
    #
    lsb_facts = {
        'codename': 'xenial',
        'description': 'Ubuntu 16.04.2 LTS',
        'id': 'Ubuntu',
        'major_release': '16',
        'release': '16.04'
    }
    lsb_path = '/usr/bin/lsb_release'
    module = MockModule(lsb_path)
    lsb_collector = LSBFactCollector()
    facts = lsb_collector.collect(module=module)
    assert facts['lsb'] == lsb_facts
    #
    # Test without lsb_release
    #

# Generated at 2022-06-17 02:20:42.813302
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:49.367304
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:51.065297
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:54.582030
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:21:04.358542
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {'id': 'Ubuntu', 'release': '16.04', 'description': 'Ubuntu 16.04.2 LTS', 'codename': 'xenial'}
    lsb_facts_major_release = {'id': 'Ubuntu', 'release': '16.04', 'description': 'Ubuntu 16.04.2 LTS', 'codename': 'xenial', 'major_release': '16'}
    lsb_facts_no_major_release = {'id': 'Ubuntu', 'release': '16.04', 'description': 'Ubuntu 16.04.2 LTS', 'codename': 'xenial'}

# Generated at 2022-06-17 02:21:07.725970
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:21:17.776453
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type

# Generated at 2022-06-17 02:21:21.157781
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert isinstance(lsb_facts, dict)
    assert 'lsb' in lsb_facts
    assert isinstance(lsb_facts['lsb'], dict)

# Generated at 2022-06-17 02:22:28.024708
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:22:31.912931
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:22:37.645658
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {
        'id': 'Ubuntu',
        'release': '14.04',
        'description': 'Ubuntu 14.04.5 LTS',
        'codename': 'trusty'
    }


# Generated at 2022-06-17 02:22:47.793619
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_classes
    from ansible.module_utils.facts.collector import list_fact_classes
    from ansible.module_utils.facts.collector import get_fact_subset_names

# Generated at 2022-06-17 02:22:59.450925
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid


# Generated at 2022-06-17 02:23:05.628451
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:11.618525
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:20.505472
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_ids
    from ansible.module_utils.facts.collector import get_collector_fact_names

# Generated at 2022-06-17 02:23:25.799667
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:23:31.354197
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:26:16.307322
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:26:18.758056
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()