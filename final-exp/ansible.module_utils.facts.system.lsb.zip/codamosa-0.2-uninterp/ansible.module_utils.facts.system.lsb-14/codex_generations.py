

# Generated at 2022-06-17 02:16:38.543639
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # create a mock module
    module = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock ansible module
    ansible_module = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock ansible module
    ansible_module_2 = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock ansible module
    ansible_module_3 = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock ansible module
    ansible_module_4 = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock ansible module
    ansible_module_5 = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock ansible module
   

# Generated at 2022-06-17 02:16:50.572090
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 02:16:53.408165
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:05.078564
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=module)
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'


# Generated at 2022-06-17 02:17:09.464575
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'

# Generated at 2022-06-17 02:17:17.593075
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:17:22.042415
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:28.506772
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:34.244691
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:43.871299
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect()
    assert 'lsb' in lsb_facts
    assert 'release' in lsb_facts['lsb']
    assert 'id' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-17 02:17:58.131290
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import remove_file
    from ansible.module_utils.facts.utils import set_file_content
    from ansible.module_utils.facts.utils import set_file_lines
    from ansible.module_utils.facts.utils import write_file
    from ansible.module_utils.facts.utils import write_file_lines
    from ansible.module_utils.facts.utils import get_bin

# Generated at 2022-06-17 02:18:02.960983
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=module)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['/usr/bin/lsb_release', '-a']
    assert module.run_command.call_args[1]['errors'] == 'surrogate_then_replace'


# Generated at 2022-06-17 02:18:11.580306
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']
    assert lsb_facts['lsb']['id']
    assert lsb_facts['lsb']['release']
    assert lsb_facts['lsb']['major_release']
    assert lsb_facts['lsb']['description']
    assert lsb_facts['lsb']['codename']

# Generated at 2022-06-17 02:18:16.270852
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:26.250208
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test if LSBFactCollector is in the list of available collectors
    assert 'lsb' in get_collector_names()

    # Test if LSBFactCollector is an instance of Collector
    assert isinstance(get_collector_instance('lsb'), Collector)

    # Test if LSBFactCollector is in the list of collectors
    assert 'lsb' in list_collectors()

    # Test if LSBFactCollector is an instance of LSBFactCollector

# Generated at 2022-06-17 02:18:29.408397
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:18:39.546017
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:18:50.284802
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import get_collector_for_fact
    from ansible.module_utils.facts.collector import get_fact_names
    from ansible.module_utils.facts.collector import get_fact_classes
    from ansible.module_utils.facts.collector import get_fact_instance

# Generated at 2022-06-17 02:18:56.820224
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a fake module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Create a fake lsb_release file
    lsb_release_file = tempfile.NamedTemporaryFile(delete=False)
    lsb_release_file.write(b'DISTRIB_ID=Ubuntu\n')
    lsb_release_file.write(b'DISTRIB_RELEASE=14.04\n')
    lsb_release_file.write(b'DISTRIB_DESCRIPTION="Ubuntu 14.04.5 LTS"\n')
    lsb_release_file.write(b'DISTRIB_CODENAME=trusty\n')
    lsb_release_file.close()

    # Create

# Generated at 2022-06-17 02:19:02.964036
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:22.589646
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:32.539616
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return '/bin/lsb_release'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return 0, '''
LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: Fedora
Description:    Fedora release 28 (Twenty Eight)
Release:        28
Codename:       TwentyEight
''', ''

    # Create a mock ansible module
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

    #

# Generated at 2022-06-17 02:19:42.851590
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import sys
    import tempfile
    import shutil
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, "test_file")

# Generated at 2022-06-17 02:19:45.361197
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:50.380132
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:54.601139
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:03.058661
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock module.run_command
    module.run_command = AnsibleModuleMock.run_command

    # Create a mock module.get_bin_path
    module.get_bin_path = AnsibleModuleMock.get_bin_path

    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Create a mock lsb_release_bin
    lsb_fact_collector._lsb_release_bin = LSBFactCollector._lsb_release_bin

    # Create a mock lsb_release_file
    lsb_fact_collector._lsb_release_file = LSBFactCollector._lsb_release_file

    # Test the collect method
    lsb_

# Generated at 2022-06-17 02:20:08.325884
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:11.978089
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:20:18.496737
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert 'lsb' in lsb_facts
    assert 'release' in lsb_facts['lsb']
    assert 'id' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-17 02:20:56.291926
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module)
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '12.04'
    assert lsb_facts['lsb']['major_release'] == '12'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 12.04.5 LTS'
    assert lsb_facts['lsb']['codename'] == 'precise'


# Generated at 2022-06-17 02:21:07.087346
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector

    module = ModuleStub()
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=module)
    assert isinstance(lsb_facts, dict)
    assert isinstance(lsb_facts['lsb'], dict)
    assert 'id' in lsb_facts['lsb']
    assert 'release' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']

# Generated at 2022-06-17 02:21:17.185069
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:21:22.760300
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert 'lsb' in lsb_facts
    assert 'release' in lsb_facts['lsb']
    assert 'id' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-17 02:21:25.610992
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:21:34.854867
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Create a temporary module
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda self, x: os.path.join(tmpdir, x),
        'run_command': lambda self, x, **kwargs: (0, '', '')
    })

    # Create a temporary lsb_release script
    lsb_release_script = os.path.join(tmpdir, 'lsb_release')

# Generated at 2022-06-17 02:21:40.062514
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:21:44.879842
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:21:54.693310
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import set_collector_status
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists

# Generated at 2022-06-17 02:21:59.842227
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:23:00.591659
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a mock ansible module
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=module)

    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'


# Generated at 2022-06-17 02:23:13.488407
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Call method collect of the LSBFactCollector object
    lsb_facts = lsb_fact_collector.collect(module=module)

    # Check if lsb_facts is empty
    assert not lsb_facts

    # Check if lsb_facts is not empty
    lsb_facts = lsb_fact_collector.collect(module=module, collected_facts={})
    assert lsb_facts


# Generated at 2022-06-17 02:23:16.692623
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:23:19.529747
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:24.950312
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:31.289225
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:41.401233
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import tempfile
    import shutil
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, "test_file")

# Generated at 2022-06-17 02:23:42.907775
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:23:46.982337
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:52.114832
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'