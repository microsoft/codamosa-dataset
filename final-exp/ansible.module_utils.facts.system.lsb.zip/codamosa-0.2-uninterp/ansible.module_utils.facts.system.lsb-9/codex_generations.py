

# Generated at 2022-06-17 02:16:39.287427
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module.run_command = Mock(return_value=(0, '', ''))

    # Create a LSBFactCollector object
    lsb_collector = LSBFactCollector()

    # Create a mock collected_facts
    collected_facts = dict()

    # Call method collect of LSBFactCollector
    lsb_collector.collect(module=ansible_module, collected_facts=collected_facts)

    # Assertion
    assert collected_facts['lsb'] == {}



# Generated at 2022-06-17 02:16:45.766504
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:16:49.301966
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:16:57.737008
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_points

# Generated at 2022-06-17 02:17:02.396660
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:04.673696
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:17:10.410978
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:21.281122
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=module)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['lsb_release', '-a']
    assert module.run_command.call_args[1]['errors'] == 'surrogate_then_replace'
    assert os.path.exists.call_count == 1
    assert os.path.exists.call_args[0][0] == '/etc/lsb-release'
    assert get_file_lines.call_count == 1
    assert get_file_lines.call_args[0][0] == '/etc/lsb-release'


# Generated at 2022-06-17 02:17:27.841320
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:17:38.525151
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {
        'id': 'Ubuntu',
        'release': '14.04',
        'description': 'Ubuntu 14.04.1 LTS',
        'codename': 'trusty',
        'major_release': '14'
    }

    lsb_facts_bin = {
        'id': 'Ubuntu',
        'release': '14.04',
        'description': 'Ubuntu 14.04.1 LTS',
        'codename': 'trusty',
        'major_release': '14'
    }


# Generated at 2022-06-17 02:17:47.920235
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None


# Generated at 2022-06-17 02:17:59.048986
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test with lsb_release command
    module = MockModule()
    module.run_command = Mock(return_value=(0, '''
LSB Version:	:core-4.1-amd64:core-4.1-noarch
Distributor ID:	CentOS
Description:	CentOS Linux release 7.4.1708 (Core)
Release:	7.4.1708
Codename:	Core
''', ''))
    lsb_collector = LSBFactCollector()
    lsb_facts = lsb_collector.collect(module=module)
    assert lsb_facts['lsb']['release'] == '7.4.1708'
    assert lsb_facts['lsb']['id'] == 'CentOS'

# Generated at 2022-06-17 02:18:02.702148
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:08.998247
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:14.704581
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:18:19.379976
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:27.594684
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_status

# Generated at 2022-06-17 02:18:33.085347
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:18:42.797670
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test with lsb_release command
    module = MockModule()
    module.run_command = Mock(return_value=(0, "LSB Version:    :core-4.1-amd64:core-4.1-noarch\nDistributor ID: RedHatEnterpriseServer\nDescription:    Red Hat Enterprise Linux Server release 7.2 (Maipo)\nRelease:        7.2\nCodename:       Maipo", ""))
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=module)
    assert lsb_facts['lsb']['release'] == '7.2'
    assert lsb_facts['lsb']['id'] == 'RedHatEnterpriseServer'

# Generated at 2022-06-17 02:18:51.111394
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()
    # Create a mock command
    command = CommandMock()
    # Set the command output
    command.set_output(rc=0, out="""
LSB Version:	:core-4.1-amd64:core-4.1-noarch
Distributor ID:	CentOS
Description:	CentOS Linux release 7.6.1810 (Core)
Release:	7.6.1810
Codename:	Core
""")
    # Set the command output
    module.set_command(command)
    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()
    # Collect the facts
    facts = lsb_fact_collector.collect(module=module)
    # Assert the facts
   

# Generated at 2022-06-17 02:19:15.985563
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModuleMock()

    # Create a mock lsb_release file
    lsb_release_file = '/etc/lsb-release'
    lsb_release_content = '''
DISTRIB_ID=Ubuntu
DISTRIB_RELEASE=14.04
DISTRIB_CODENAME=trusty
DISTRIB_DESCRIPTION="Ubuntu 14.04.3 LTS"
'''
    with open(lsb_release_file, 'w') as f:
        f.write(lsb_release_content)

    # Create a mock lsb_release script
    lsb_release_script = '/usr/bin/lsb_release'

# Generated at 2022-06-17 02:19:20.995808
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:19:25.772692
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:35.348023
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    Test the collect method of the LSBFactCollector class.
    """
    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Create a mock module
    module = MockModule()

    # Create a mock module.run_command
    module.run_command = Mock(return_value=(0, '', ''))

    # Create a mock module.get_bin_path
    module.get_bin_path = Mock(return_value='/usr/bin/lsb_release')

    # Create a mock os.path.exists
    os.path.exists = Mock(return_value=True)

    # Create a mock get_file_lines

# Generated at 2022-06-17 02:19:41.184256
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:44.613487
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:49.626102
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:53.657469
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:19:58.832204
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:06.012553
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:39.254057
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:20:42.554428
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:20:44.238986
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.collect() == {}

# Generated at 2022-06-17 02:20:50.868069
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:20:56.150514
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert lsb_facts['lsb']['id'] == 'Ubuntu'
    assert lsb_facts['lsb']['release'] == '16.04'
    assert lsb_facts['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    assert lsb_facts['lsb']['codename'] == 'xenial'
    assert lsb_facts['lsb']['major_release'] == '16'

# Generated at 2022-06-17 02:21:04.443760
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a mock command
    command = Command(
        module=module,
        stdout='''
LSB Version:	:core-4.1-amd64:core-4.1-noarch
Distributor ID:	CentOS
Description:	CentOS Linux release 7.4.1708 (Core)
Release:	7.4.1708
Codename:	Core
''',
        rc=0
    )

    # Create a mock module
    module.run_command = Mock(return_value=command)

    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()

    # Call method collect

# Generated at 2022-06-17 02:21:07.812752
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:21:09.990589
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb._fact_ids == set()
    assert lsb.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:21:16.949084
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()
    assert 'lsb' in lsb_facts
    assert 'id' in lsb_facts['lsb']
    assert 'release' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-17 02:21:21.596439
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:22:30.734726
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:22:34.130750
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:22:45.424524
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 02:22:49.473872
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=module)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args == call([module.get_bin_path.return_value, "-a"], errors='surrogate_then_replace')
    assert module.get_bin_path.call_count == 1
    assert module.get_bin_path.call_args == call('lsb_release')


# Generated at 2022-06-17 02:22:59.604085
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a mock module
    module = MockModule()
    # Create a mock command
    command = MockCommand()
    # Set the command output
    command.set_output([0, 'LSB Version:    :core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch\nDistributor ID: RedHatEnterpriseServer\nDescription:    Red Hat Enterprise Linux Server release 7.2 (Maipo)\nRelease:        7.2\nCodename:       Maipo', ''])
    #

# Generated at 2022-06-17 02:23:05.653739
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:12.320532
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:15.916984
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:23:26.474064
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=module)
    assert lsb_facts['lsb']['id'] == 'CentOS'
    assert lsb_facts['lsb']['release'] == '7.2.1511'
    assert lsb_facts['lsb']['description'] == 'CentOS Linux release 7.2.1511 (Core)'
    assert lsb_facts['lsb']['codename'] == 'Core'
    assert lsb_facts['lsb']['major_release'] == '7'


# Generated at 2022-06-17 02:23:28.107575
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:26:09.385051
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-17 02:26:13.936486
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:26:17.765557
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-17 02:26:20.757035
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'
