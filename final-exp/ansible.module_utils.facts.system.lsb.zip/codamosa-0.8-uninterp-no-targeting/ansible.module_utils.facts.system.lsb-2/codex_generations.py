

# Generated at 2022-06-20 19:32:41.758897
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    class ModuleStub():
        def get_bin_path(self, command, *args, **kwargs):
            return "/some/path"

        def run_command(self, args, **kwargs):
            return 0, "", ""

    m = ModuleStub()
    f = LSBFactCollector()

    # Does not contain key 'lsb_release'
    assert 'lsb_release' not in f.collect(module=m)
    # No arguments
    assert 'lsb_release' not in f.collect()

# Generated at 2022-06-20 19:32:47.403529
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:32:51.222517
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    fact_collector = LSBFactCollector('lsb', {}, {}, 'ansible.module_utils.facts.lsb')
    facts_dict = fact_collector.collect()

    assert isinstance(facts_dict, dict)

# Generated at 2022-06-20 19:32:51.830433
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-20 19:32:53.992001
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = Mock()
    module.get_bin_path.return_value = "/bin/lsb_release"
    module.run_command.return_value = (0, 'Release:\tSomeLinux', '')

    # run collect on LSBFactCollector
    LSBFactCollector().collect(module)
    assert module.get_bin_path.called
    assert module.run_command.called


# Generated at 2022-06-20 19:33:04.916379
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock(params=dict())
    lsb_collector = LSBFactCollector(module=module)
    module.run_command.return_value = 0, "Distributor ID: Ubuntu\nDescription: Ubuntu Bionic Beaver (development branch)\nRelease: 18.04\nCodename: bionic", ''
    module.get_bin_path.return_value = '/bin/lsb_release'
    lsb_facts = lsb_collector.collect()
    assert lsb_facts['lsb'] == dict(id='Ubuntu', description='Ubuntu Bionic Beaver (development branch)',
                                    release='18.04', codename='bionic', major_release='18')
    module.run_command.return_value = 1, '', ''
    lsb_facts = lsb_collector.collect

# Generated at 2022-06-20 19:33:16.623692
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = AnsibleModuleMock()
    test_module.run_command = run_command_mock
    test_module.get_bin_path = get_bin_path_mock

    test_get_bin_path_mock = True
    test_run_command_mock = True

    lsb_collector = LSBFactCollector()
    lsb_facts = lsb_collector.collect()

    if test_get_bin_path_mock:
        assert get_bin_path_mock.call_count == 1

    if test_run_command_mock:
        assert run_command_mock.call_count == 1
        assert run_command_mock.call_args[0][0] == ['/test_fakelsb_release_location']
        assert run_command_m

# Generated at 2022-06-20 19:33:19.577927
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert len(LSBFactCollector._fact_ids) == 0
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:33:21.449812
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lf = LSBFactCollector()
    assert lf.STRIP_QUOTES == r'\'\"\\'

    assert lf.name == 'lsb'

# Generated at 2022-06-20 19:33:24.517866
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact_mod = LSBFactCollector()

    assert fact_mod.name == 'lsb'

# Generated at 2022-06-20 19:33:43.254267
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    # The local helper methods
    def _lsb_release_bin_success_side_effect(*args, **kwargs):
        out = r'LSB Version:    core-9.20170808ubuntu1-noarch:security-9.20170808ubuntu1-noarch'
        out += r'\nDistributor ID: PokingDistro'
        out += r'\nDescription:    PokingDistro\sRelease\sV1.0.0'
        out += r'\nRelease:        V1.0.0'
        out += r'\nCodename:       codename'
        return (0, out, '')

    def _lsb_release_bin_fail_side_effect(*args, **kwargs):
        return (1, '', '')


# Generated at 2022-06-20 19:33:50.382529
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a instance of LSBFactCollector for test
    lsb_fact_collector = LSBFactCollector()

    # Lsb facts collected from /etc/lsb-release
    etc_lsb_release_vars = {'description': '"Ubuntu 12.04.5 LTS"',
                            'id': 'Ubuntu',
                            'major_release': '12',
                            'release': '12.04.5'}

    # Check results
    assert lsb_fact_collector._lsb_release_file('/etc/lsb-release') == etc_lsb_release_vars
    assert lsb_fact_collector._lsb_release_file('/etc/lsb-release_doesnt_exist') == {}


# Generated at 2022-06-20 19:33:51.598245
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'

# Generated at 2022-06-20 19:33:56.268281
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    collected_facts = { 'lsb': {'codename': 'Hardy'}}
    LSBFactCollector().collect(collected_facts)
    assert 'lsb' in collected_facts
    assert collected_facts['lsb'] == {'codename': 'Hardy'}

# Generated at 2022-06-20 19:34:08.085015
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector._lsb_release_bin = lambda lsb_path, module: { 'id': 'ansible', 'release': '1.0', 'description': 'ansible is awesome' }
    lsb_fact_collector._lsb_release_file = lambda etc_lsb_release_location: { 'id': 'ansible', 'release': '1.0', 'description': 'ansible is awesome' }
    lsb_fact_dict = lsb_fact_collector.collect()
    assert lsb_fact_dict['lsb']['id'] == 'ansible'
    assert lsb_fact_dict['lsb']['release'] == '1.0'

# Generated at 2022-06-20 19:34:12.327121
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == 'lsb'
    assert lsb_facts.STRIP_QUOTES == r'\'\"\\'
    assert lsb_facts.priority == -1
    assert not lsb_facts._fact_ids

# Generated at 2022-06-20 19:34:15.166170
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector
    assert lsb_fact_collector.name == 'lsb'

# Generated at 2022-06-20 19:34:26.838477
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsbfc = LSBFactCollector()

    # testing the lsb_release method
    test_module = FakeModule()
    lsb_facts = lsbfc._lsb_release_bin('/usr/bin/lsb_release',
                                       module=test_module)

    assert len(lsb_facts) == 4
    assert lsb_facts['id'] == 'RedHatEnterpriseServer'
    assert lsb_facts['release'] == '7.3'
    assert lsb_facts['description'] == 'Red Hat Enterprise Linux Server release 7.3 (Maipo)'
    assert lsb_facts['codename'] == 'Maipo'

    # testing the /etc/lsb-release method
    lsb_facts = lsbfc._lsb_release_file('test_etc_lsb_release')


# Generated at 2022-06-20 19:34:29.184642
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb is not None

# Generated at 2022-06-20 19:34:32.170263
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert hasattr(LSBFactCollector, 'collect')
    assert isinstance(LSBFactCollector, object)

# Generated at 2022-06-20 19:34:56.023452
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = MockModule()
    test_module.get_bin_path = Mock(return_value="/usr/bin/lsb_release")
    test_module.run_command = Mock(return_value=(0, '''
LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: Fedora
Description:    Fedora release 20 (Heisenbug)
Release:        20
Codename:       Heisenbug
    ''', ""))

    expected_lsb_dict = {
        'release': '20',
        'id': 'Fedora',
        'description': 'Fedora release 20 (Heisenbug)',
        'codename': 'Heisenbug',
        'major_release': '20'
    }

    # test with lsb_release
    test_LSB

# Generated at 2022-06-20 19:35:05.706877
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import tempfile

    module = None

    def run_command(cmd, errors='surrogate_then_replace'):
        if cmd == ['/tmp/does_not/exist', "-a"]:
            return (1, "", "")
        elif cmd == ['/usr/bin/lsb_release', "-a"]:
            return (0, "LSB Version:\t:core-4.1-amd64:core-4.1-noarch\n"
                         "Distributor ID:\tCentOS\n"
                         "Description:\tCentOS Linux release 7.4.1708 (Core)\n"
                         "Release:\t7.4.1708\n"
                         "Codename:\tCore\n", "")


# Generated at 2022-06-20 19:35:06.818578
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-20 19:35:18.060549
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    import os

    # Create a file to be used as input to LSBFactCollector
    os.makedirs('/tmp/test_lsb_release')
    with open('/tmp/test_lsb_release/lsb-release', 'w') as content_file:
        content_file.write("aaa=\n")
        content_file.write("bbb='xx'\n")
        content_file.write("ccc=\"yy\"\n")
        content_file.write("ddd=zz\n")

    # Create and initialize Facts object
    facts = Facts()
    facts._collector_facts[LSBFactCollector.name] = LSBFactCollector

# Generated at 2022-06-20 19:35:19.549639
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fc = LSBFactCollector()
    assert fc.name == 'lsb'

# Generated at 2022-06-20 19:35:27.387040
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    fixture_data = {
        'lsb_path': '/usr/bin/lsb_release',
        'lsb_release_bin_results': {
            'id': 'Debian',
            'release': '8.3',
            'description': 'Debian GNU/Linux 8.3 (jessie)',
            'codename': 'jessie'
        },
        'lsb_file_results': {
            'id': 'Debian',
            'release': '8.3',
            'description': 'Debian GNU/Linux 8.3 (jessie)',
            'codename': 'jessie'
        }
    }


# Generated at 2022-06-20 19:35:38.042144
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = object()
    lsb_path = None
    lsb_dict = {}
    etc_lsb_release_location = '/etc/lsb-release'
    lsb_release_file_contents = ['DISTRIB_ID=MyLinux', 'DISTRIB_RELEASE=1.0',
                                 'DISTRIB_DESCRIPTION=My Linux', 'DISTRIB_CODENAME=xenial']

    collector = LSBFactCollector()

    # Case 1: try the lsb_release script first and check if the return matches lsb_dict
    with mock.patch.object(LSBFactCollector, '_lsb_release_bin') as mock_bin, \
            mock.patch.object(LSBFactCollector, '_lsb_release_file') as mock_file:
        mock_bin

# Generated at 2022-06-20 19:35:42.768998
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    lsb_path = '/usr/bin/lsb_release'
    module.get_bin_path.return_value = lsb_path
    lsb_out = """\
LSB Version:    core-9.20160110ubuntu0.2-amd64:core-9.20160110ubuntu0.2-noarch
Distributor ID: Ubuntu
Description:    Ubuntu 16.04.3 LTS
Release:    16.04
Codename:   xenial
""".split('\n')
    module.run_command.return_value = (0, lsb_out, '')

    lsb_fct_collector = LSBFactCollector()
    facts_dict = lsb_fct_collector.collect(module)
    lsb_facts = facts_dict.get

# Generated at 2022-06-20 19:35:45.986507
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-20 19:35:47.736043
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector().name == 'lsb'

# Generated at 2022-06-20 19:36:19.205396
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    facts_dict = collector.collect()
    if facts_dict:
        lsb_facts = facts_dict['lsb']
        if lsb_facts:
            assert 'major_release' in lsb_facts
            assert 'codename' in lsb_facts


if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-20 19:36:29.046329
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleDataCollector

    # Create a class object
    lsb_fact_collector = LSBFactCollector()
    # Create a mock module and dependency
    mock_module = AnsibleModuleMock()
    mock_module.get_bin_path.return_value = '/usr/bin/lsb_release'

# Generated at 2022-06-20 19:36:29.586536
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-20 19:36:31.754805
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fc = LSBFactCollector()
    assert lsb_fc.name == 'lsb'
    assert lsb_fc._fact_ids is not None


# Generated at 2022-06-20 19:36:33.928009
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    n = LSBFactCollector()
    assert n.name == 'lsb'
    assert n.STRIP_QUOTES == '\'\"\\'


# Generated at 2022-06-20 19:36:44.443423
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command = magic_run_commad
    LSBFactCollector_instance = LSBFactCollector()

    # case 1: lsb_release binary exits, lsb_release file not exist
    test_module.get_bin_path = magic_get_bin_path_exist
    test_lsb_facts = LSBFactCollector_instance.collect(test_module)
    assert test_lsb_facts == {'lsb': {'codename': 'Ubuntu', 'description': 'Ubuntu 19.04', 'id': 'Ubuntu', 'major_release': '19', 'release': '19.04'}}

    # case 2: (lsb_release binary exits, ) and lsb_release file exist

# Generated at 2022-06-20 19:36:50.155924
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = ['lsb_release','','None']
    lsb = LSBFactCollector()
    result = lsb.collect(module=module, collected_facts={})
    assert result == {'lsb': {'release': '12.04', 'id': 'Ubuntu', 'description': 'Ubuntu 12.04.5 LTS', 'codename': 'precise'}}



# Generated at 2022-06-20 19:36:52.335069
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_class = LSBFactCollector()
    assert test_class.collect() == {'lsb': {}}

# Generated at 2022-06-20 19:36:53.451443
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb = LSBFactCollector()
    lsb.collect()

# Generated at 2022-06-20 19:36:54.548214
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-20 19:37:58.861386
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbFactCollector = LSBFactCollector()
    assert lsbFactCollector.name == 'lsb'

    assert lsbFactCollector._fact_ids == set()

    assert lsbFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:38:01.515867
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    facts = {}
    collector = LSBFactCollector()
    result = collector.collect(module=module, collected_facts=facts)
    assert 'lsb' in result


# Generated at 2022-06-20 19:38:05.696447
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = None
    lsb_facts = LSBFactCollector().collect(module=module)

    assert lsb_facts == {'lsb': {}}


# Generated at 2022-06-20 19:38:09.657980
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector.STRIP_QUOTES == '\'\"\\'

# Generated at 2022-06-20 19:38:11.146301
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    assert lsbfc.name == 'lsb'

# Generated at 2022-06-20 19:38:23.218387
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    m = MockLSBFactModule()
    fc = LSBFactCollector()
    facts = fc.collect(m, {})
    assert 'lsb' in facts
    lsb_facts = facts['lsb']
    assert 'release' in lsb_facts
    assert lsb_facts['release'] == '12.03'
    assert 'major_release' in lsb_facts
    assert lsb_facts['major_release'] == '12'
    assert 'id' in lsb_facts
    assert lsb_facts['id'] == 'Ubuntu'
    assert 'description' in lsb_facts
    assert lsb_facts['description'] == 'Ubuntu 12.03.1 LTS'
    assert 'codename' in lsb_facts
    assert lsb_facts['codename'] == 'precise'
   

# Generated at 2022-06-20 19:38:28.645547
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector = LSBFactCollector()
    lsb_collector = LSBFactCollector()
    facts = lsb_collector.collect()
    lsb_facts = facts['lsb']
    expected = {'lsb': {}}
    assert lsb_facts == expected

# Generated at 2022-06-20 19:38:31.286571
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    assert lsbfc is not None
    assert lsbfc.name == 'lsb'


# Generated at 2022-06-20 19:38:32.659036
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.name == 'lsb'

# Generated at 2022-06-20 19:38:34.332572
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()
    assert 'lsb' == l.name

# Generated at 2022-06-20 19:41:19.564116
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_data = {'lsb': {'id': 'CentOS', 'major_release': '7',
                        'release': '7.2.1511', 'description':
                        'CentOS Linux release 7.2.1511 (Core)'}}
    lsb_obj = LSBFactCollector()
    test_lsb_obj = lsb_obj.collect()
    assert isinstance(test_lsb_obj, dict)
    assert test_lsb_obj == lsb_data

# Generated at 2022-06-20 19:41:27.958675
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    LSBFactCollector class unit test stub.
    """

    # Constructing a fake module object
    module = AnsibleModule(argument_spec={})

    if module._name == 'lsb_release':
        module.exit_json(changed=False, ansible_facts={'ansible_lsb': 
                                                       {'id': "Ubuntu",
                                                        'distrib_release': "18.04",
                                                        'distrib_codename': "bionic",
                                                        'distrib_description': "Ubuntu 18.04.2 LTS",
                                                        'description': "Ubuntu 18.04.2 LTS",
                                                        'release': "18.04",
                                                        'codename': "bionic",
                                                        'major_release': "18"}})

# Generated at 2022-06-20 19:41:30.114279
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact = LSBFactCollector()
    assert lsb_fact.name == 'lsb'
    assert lsb_fact.collect() == {}

# Generated at 2022-06-20 19:41:41.137801
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    class TestModule:
        def get_bin_path(self, path):
            if path == 'lsb_release':
                return '/path/to/lsb_release'
            else:
                return None

        def run_command(self, args, errors):
            if args == ['/path/to/lsb_release', "-a"]:
                return (0, "LSB Version:	1.2\nDistributor ID:	Ubuntu\nDescription:	Ubuntu 16.04.3 LTS\nRelease:	16.04\nCodename:	xenial", None)

    # Test that a dictionary is returned with a lsb key
    test_module = TestModule()
    lsb = LSBFactCollector()
    assert 'lsb' in lsb.collect(module=test_module)

# Generated at 2022-06-20 19:41:46.915634
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible_collections.ansible.community.plugins.module_utils import basic

    etc_lsb_release_location = '/tmp/etc-lsb-release'
    lsb_path = '/tmp/bin/lsb_release'

    lsb_release_args = {'executable': lsb_path, '_raw_params':
                        '-a', '_uses_shell': False, '_tmpdir': '/tmp',
                        'stdin': None}

    lsb_release_command = '/tmp/bin/lsb_release -a'


# Generated at 2022-06-20 19:41:50.273247
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()

    assert lsb_facts
    assert lsb_facts['lsb']
    assert (isinstance(lsb_facts['lsb'], dict))

# Generated at 2022-06-20 19:41:54.479344
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:41:55.305498
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-20 19:41:56.615663
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-20 19:42:02.709293
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    m = mock.Mock()
    m.get_bin_path.return_value = '/bin/lsb_release'
    m.run_command.return_value = [0, 'LSB Version:\tGeneric', None]

    test = LSBFactCollector()
    result = test.collect(m)
    m.get_bin_path.assert_called_once_with('lsb_release')
    m.run_command.assert_called_once_with(['/bin/lsb_release', '-a'], errors='surrogate_then_replace')
    assert_equals(result, {'lsb': {'release': 'Generic'}})
