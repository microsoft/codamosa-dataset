

# Generated at 2022-06-20 19:32:37.806341
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'

# Generated at 2022-06-20 19:32:44.438281
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    m = Mock()
    m.run_command.return_value = (0, '', '')
    m.get_bin_path.side_effect = ['', '']

    m.get_bin_path.return_value = 'lsb_release'
    collect_dict = {
        'lsb': {
            'id': 'Ubuntu',
            'release': '14.04',
            'major_release': '14',
            'codename': 'trusty',
            'description': 'Ubuntu 14.04.4 LTS'
        }
    }

    lsb_path = m.get_bin_path('lsb_release')

# Generated at 2022-06-20 19:32:54.934524
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a dummy module to use during testing
    class DummyModule(object):
        def __init__(self, *args, **kwargs):
            super(DummyModule, self).__init__(*args, **kwargs)

        def run_command(self, *args, **kwargs):
            return (0, '', '')

        def get_bin_path(self, *args, **kwargs):
            return './lsb_release'

    # Test lsb_release with DummyModule
    module = DummyModule()
    lsb = LSBFactCollector()
    expected = {'description': None, 'major_release': '2', 'release': '2', 'codename': 'Beta', 'id': 'test'}

# Generated at 2022-06-20 19:33:01.501808
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    facts_dict = get_facts_from_collector(LSBFactCollector)
    assert type(facts_dict) == dict
    assert type(facts_dict['lsb']) == dict
    assert all(item in facts_dict['lsb'].iterkeys() for item in ['id', 'release', 'codename', 'description', 'major_release'])

# Generated at 2022-06-20 19:33:04.274605
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    assert lsbfc.name == 'lsb'
    assert lsbfc._fact_ids == set()
    assert lsbfc.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:33:07.046128
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'



# Generated at 2022-06-20 19:33:10.976837
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector().collect()

    # by default, this fact is empty
    assert(len(lsb_facts) == 1)
    assert(lsb_facts['lsb'] == {})


# Generated at 2022-06-20 19:33:13.823009
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector.collect() == {}

# Generated at 2022-06-20 19:33:24.698666
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = LSBFactCollector()
    lsb_path = None
    lsb_facts = {}

    # case 1: path of file 'lsb_release' exists in PATH, the return value of method 'get_bin_path' is not None
    lsb_facts = module._lsb_release_bin(lsb_path='/usr/bin/lsb_release', module=module)
    assert lsb_facts
    assert lsb_facts['release'] == '7.0'

    # case 2: file '/etc/lsb-release' exists and the content of this file is not None
    lsb_facts = module._lsb_release_file('/etc/lsb-release')
    assert lsb_facts
    assert lsb_facts['release'] == '7.0'

# Generated at 2022-06-20 19:33:33.451142
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.collectors import base

    # Setup the class
    lsb_collector = LSBFactCollector()

    # Test with lsb_release binary

# Generated at 2022-06-20 19:33:46.944745
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_obj=LSBFactCollector()
    assert lsb_obj

# Generated at 2022-06-20 19:33:51.368000
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact_collector = LSBFactCollector()
    assert fact_collector.name == 'lsb'
    # assert set(fact_collector.collect().keys()) == set(['lsb'])

# Generated at 2022-06-20 19:33:52.337192
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-20 19:33:55.572880
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'

# Generated at 2022-06-20 19:34:03.344244
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ansible_module
    from ansible.module_utils.facts.collector.system import LSBFactCollector
    from ansible.module_utils.facts.utils.file import get_file_content

    # Mock ansible_module
    module = ansible_module.AnsibleModule()

    # Set module attribute
    module.run_command = lambda x: (0, get_file_content('tests/fixtures/etc_lsb_release'))
    module.get_bin_path = lambda x: 'path/to/bin'

    # Execute method
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=module)

    # Assert result

# Generated at 2022-06-20 19:34:14.920852
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = AnsibleModuleMock()
    test_module.run_command.return_value = (0, 'LSB Version: 1.0\n'
                                           'Distributor ID: Ubuntu\n'
                                           'Description: Ubuntu 10.04.4 LTS\n'
                                           'Release: 10.04\n'
                                           'Codename: lucid\n', '')
    test_module.get_bin_path.return_value = '/usr/bin/lsb_release'

    lsb = LSBFactCollector()
    facts = lsb.collect(module=test_module)

    test_module.run_command.assert_called_with(['/usr/bin/lsb_release', '-a'], errors='surrogate_then_replace')
    test_module.get

# Generated at 2022-06-20 19:34:15.901039
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()


# Generated at 2022-06-20 19:34:16.674478
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-20 19:34:20.671386
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'
    assert LSBFactCollector.depends_on() == ('command',)

# Generated at 2022-06-20 19:34:29.403339
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # lsb_release test will pass when lsb_release is installed
    facts_dict = LSBFactCollector().collect()
    assert facts_dict
    # test_lsb_release_file will pass with /etc/lsb-release
    facts_dict = LSBFactCollector()._lsb_release_file('/etc/lsb-release')
    assert facts_dict
    # test_lsb_release_bin will pass if lsb_release is installed
    lsb_path = None
    returned_lsb_facts = LSBFactCollector()._lsb_release_bin(lsb_path)
    assert returned_lsb_facts

# Generated at 2022-06-20 19:35:03.293044
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector.system import LSBFactCollector

    etc_lsb_release_location = '/tmp/123/etc/lsb-release'
    open(etc_lsb_release_location, 'a').close()
    lsb_facts = LSBFactCollector()._lsb_release_file(etc_lsb_release_location)
    assert 'codename' not in lsb_facts
    assert 'id' not in lsb_facts
    assert 'release' not in lsb_facts
    assert 'description' not in lsb_facts

    with open(etc_lsb_release_location, 'a') as myfile:
        myfile.write('DISTRIB_ID=Debian')
        myfile.write('DISTRIB_RELEASE=8.2')
        my

# Generated at 2022-06-20 19:35:05.583455
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:35:07.945260
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:35:12.329644
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbFactCollector = LSBFactCollector()
    assert lsbFactCollector.name == 'lsb'
    assert lsbFactCollector._fact_ids == set()
    assert lsbFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:35:15.171678
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None
    assert lsb_fact_collector._fact_ids == {}

# Generated at 2022-06-20 19:35:20.182225
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector._lsb_release_bin = lambda *arg: {'id': 'Linux'}
    LSBFactCollector._lsb_release_file = lambda *arg: {}
    assert LSBFactCollector.collect(None)['lsb'] == {'id': 'Linux'}

# Generated at 2022-06-20 19:35:23.989209
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact = LSBFactCollector()
    test_dict = {
        'lsb': {
            'id': 'RedHatEnterpriseServer',
            'release': '6.4',
            'major_release': '6',
            'codename': 'Santiago'}}
    assert lsb_fact.collect(None) == test_dict

# Generated at 2022-06-20 19:35:25.400558
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb
    assert isinstance(lsb, BaseFactCollector)

# Generated at 2022-06-20 19:35:33.064892
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.utils.lsb import LSB_FACTS

    lsb = LSBFactCollector()
    returned_facts = lsb.collect(None)
    assert 'lsb' in returned_facts
    if LSB_FACTS:
        for k, v in LSB_FACTS.items():
            assert k in returned_facts['lsb']
            assert returned_facts['lsb'][k] == v
    else:
        assert returned_facts['lsb'] == {}

# Generated at 2022-06-20 19:35:40.221339
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact = LSBFactCollector()
    lsb_fact.collect()
    assert lsb_fact.collect() == {'lsb': {'id': 'Ubuntu',
                                          'major_release': '14',
                                          'release': '14.04',
                                          'description': 'Ubuntu 14.04.5 LTS',
                                          'codename': 'trusty'}}
    lsb_fact1 = LSBFactCollector()
    lsb_fact1.collect(True, True)
    assert lsb_fact1.collect(True, True) == {}

# Generated at 2022-06-20 19:36:06.583593
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()
    assert collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:36:13.626870
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.collector import Collector
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.utils import mock_module

    Collector.collectors.append(LSBFactCollector())
    collected_facts = Collector.collect(mock_module())
    assert collected_facts['ansible_lsb'] == {'description': 'Ubuntu 16.04.5 LTS',
                                              'id': 'Ubuntu',
                                              'major_release': '16',
                                              'release': '16.04',
                                              'codename': 'xenial'}



# Generated at 2022-06-20 19:36:15.369772
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# vim: set et sw=4 ts=4:

# Generated at 2022-06-20 19:36:25.377945
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    return_values_lsb_release = [
        ('i686', '/usr/bin/lsb_release'),
        ('x86_64', '/usr/bin/lsb_release')
    ]
    return_values_etc_lsb_release = [
        ({'etc_lsb_release': (os.path.join(os.path.dirname(__file__), 'fixtures/lsb_release_redhat_7_1'))}, []),
        ({'etc_lsb_release': (os.path.join(os.path.dirname(__file__), 'fixtures/lsb_release_debian_8_2'))}, [])
    ]

# Generated at 2022-06-20 19:36:31.242761
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    lsb_facts = {'description': 'Red Hat Enterprise Linux Server release 7.5 (Maipo)', 'codename': 'Maipo', 'id': 'RedHatEnterpriseServer', 'release': '7.5'}
    result = lsb_collector.collect()
    assert "lsb" in result and result['lsb'] == lsb_facts


# Generated at 2022-06-20 19:36:38.016124
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = dict()
    module = dict()
    module['run_command'] = LSBFactCollector._lsb_release_bin

    lsb_facts = LSBFactCollector._lsb_release_file('/etc/lsb-release')
    lsb_facts = LSBFactCollector._lsb_release_bin('lsb_release', module)

    if lsb_facts and 'release' in lsb_facts:
        lsb_facts['major_release'] = lsb_facts['release'].split('.')[0]

    for k, v in lsb_facts.items():
        if v:
            lsb_facts[k] = v.strip(LSBFactCollector.STRIP_QUOTES)

    lsb_facts['lsb'] = lsb_facts
    return lsb

# Generated at 2022-06-20 19:36:48.043033
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import sys

    if sys.version_info.major >= 3:
        import unittest.mock as mock
    else:
        import mock

    mock_module = mock.Mock()

    lsb_path = '/usr/bin/lsb_release'
    mock_module.get_bin_path.return_value = lsb_path

# Generated at 2022-06-20 19:36:49.511423
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert 'LSBFactCollector' in str(LSBFactCollector)


# Generated at 2022-06-20 19:36:56.583841
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector._lsb_release_bin = None
    lsb_fact_collector._lsb_release_file = None
    ansible_lsb = {"release": "18.04", "major_release": 18, "id": "Ubuntu", "codename": "bionic"}
    assert(lsb_fact_collector.collect({'get_bin_path': lambda a: None}) == {})
    assert(lsb_fact_collector.collect({'get_bin_path': lambda a: "A"}, {'lsb': ansible_lsb}) == {})


# Generated at 2022-06-20 19:37:03.354262
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("Testing LSBFactCollector constructor")
    base_fact_collector = BaseFactCollector()
    lsb_fact_collector = LSBFactCollector()

    assert(base_fact_collector.__class__.__name__ == 'BaseFactCollector')
    assert(lsb_fact_collector.__class__.__name__ == 'LSBFactCollector')

# Generated at 2022-06-20 19:37:39.986168
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    collected_facts = {}
    collected_facts = lsb_collector.collect(collected_facts=collected_facts)

    assert isinstance(collected_facts.get('lsb'), dict)
    assert (collected_facts.get('lsb').get('id') in ['Ubuntu', 'Redhat', 'Oracle'])


# Generated at 2022-06-20 19:37:41.463223
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    module = LSBFactCollector()
    assert module.name == 'lsb'

# Generated at 2022-06-20 19:37:42.442935
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-20 19:37:44.397198
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'

# Generated at 2022-06-20 19:37:49.361653
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # check the length of _fact_ids
    assert len(LSBFactCollector._fact_ids) == 0

    # check the name
    assert LSBFactCollector.name == 'lsb'

    # check STRIP_QUOTES
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:37:51.430703
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfactcollector = LSBFactCollector()
    assert lsbfactcollector


# Generated at 2022-06-20 19:38:01.065952
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    LSBFactCollector.collect()
    """
    # make a fake module class to pass in
    class FakeModule(object):
        def get_bin_path(self, param):
            if param == 'lsb_release':
                return "lsb/path"
            return None

        # dummy function, returns out/err/rc

# Generated at 2022-06-20 19:38:03.761374
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collect_from_source(LSBFactCollector)

# Generated at 2022-06-20 19:38:04.774831
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-20 19:38:09.103560
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    lsb_fact_collector = LSBFactCollector()

    lsb_fact_collector.collect(module)

    assert module.run_command.call_count >= 1


# Generated at 2022-06-20 19:39:13.597995
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import tempfile
    import os
    from ansible.module_utils.facts import FactsCollector

    # Create the Collector Object
    collector = FactsCollector()

    # Create some fake files and directories to simulate the lsb info
    test_dir = tempfile.mkdtemp()
    test_lsb_release_file = os.path.join(test_dir, "lsb-release")
    with open(test_lsb_release_file, 'w') as f:
        f.write("DISTRIB_ID=RedHatEnterpriseServer\n")
        f.write("DISTRIB_RELEASE=6.5\n")
        f.write("DISTRIB_DESCRIPTION=\"Red Hat Enterprise Linux\"\n")
        f.write("DISTRIB_CODENAME=Santiago\n")
    os.en

# Generated at 2022-06-20 19:39:16.263949
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-20 19:39:17.156769
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # TODO: write unit test
    pass

# Generated at 2022-06-20 19:39:17.947192
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # call should not fail
    LSBFactCollector()

# Generated at 2022-06-20 19:39:24.805389
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module_mock = Mock()
    module_mock.run_command.return_value[0] = 0
    module_mock.run_command.return_value[1] = """
    LSB Version:    :core-4.1-amd64:core-4.1-noarch
    Distributor ID: Fedora
    Description:    Fedora release 24 (Twenty Four)
    Release:        24
    Codename:       TwentyFour
    """
    lsb_facts_mock = LSBFactCollector()
    lsb_facts_mock.collect(module=module_mock)
    assert lsb_facts_mock.name is 'lsb'
    assert lsb_facts_mock._fact_ids == set()

# Generated at 2022-06-20 19:39:28.167074
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact = LSBFactCollector()
    lsb_facts = lsb_fact.collect()
    assert lsb_facts['lsb'] is not None

# Generated at 2022-06-20 19:39:36.800350
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    lsb_fact_collector = LSBFactCollector(module=None, collected_facts=None)
    ansible_collector.add_collector(lsb_fact_collector)
    ansible_collector.populate()

    assert ansible_collector.ansible_facts['lsb']

    if ansible_collector.ansible_facts['lsb'].get('id'):
        assert ansible_collector.ansible_facts['lsb']['id'].strip(
            LSBFactCollector.STRIP_QUOTES) == ansible_collector.ansible_facts['lsb']['id']

    if ansible_collector.ansible_facts['lsb'].get('release'):
        assert ans

# Generated at 2022-06-20 19:39:47.032098
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Initialize LSBFactCollector object
    lsb = LSBFactCollector()

    # Test when lsb is not found
    facts = lsb.collect(fakemodule())
    assert facts == {}

    # Test when lsb is '/usr/bin/lsb_release'
    fakemodule.bin_path_returns = '/usr/bin/lsb_release'
    fakemodule.run_command_returns = (0, '''LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: CentOS
Description:    CentOS Linux release 7.5.1804 (Core)
Release:        7.5.1804
Codename:       Core''', '')
    facts = lsb.collect(fakemodule())

# Generated at 2022-06-20 19:39:49.950629
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.name == 'lsb'
    assert not obj._fact_ids
    assert obj.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:39:52.356438
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb._fact_ids == set()
    assert lsb.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:42:20.501396
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import os
    import tempfile

    module = AnsibleModule(argument_spec=dict())

    lsb_output = b"""
    Distributor ID: Debian
    Description:    Debian GNU/Linux 9.6 (stretch)
    Release:        9.6
    Codename:       stretch
    LSB Version:    core-9.20160110ubuntu0.2-amd64:core-9.20160110ubuntu0.2-noarch:security-9.20160110ubuntu0.2-amd64:security-9.20160110ubuntu0.2-noarch
    """
    lsb_release_path = '/etc/lsb-release'

# Generated at 2022-06-20 19:42:21.934682
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.name == 'lsb'

# Generated at 2022-06-20 19:42:22.647224
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector({})

# Generated at 2022-06-20 19:42:23.777650
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:42:24.947471
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector


# Generated at 2022-06-20 19:42:29.801245
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb', '__init__() method of LSBFactCollector class did not set the name attribute'
    assert not lsb_fact_collector._fact_ids, '__init__() method of LSBFactCollector class did not set the _fact_ids attribute'
    assert lsb_fact_collector.STRIP_QUOTES == '\'\"\\', '__init__() method of LSBFactCollector class did not set the STRIP_QUOTES attribute'