

# Generated at 2022-06-20 19:32:38.043774
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbFC = LSBFactCollector()
    assert lsbFC.name == 'lsb'
    assert lsbFC._fact_ids == set()
    assert lsbFC.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:32:40.438362
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-20 19:32:43.026057
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:32:45.161902
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    result = LSBFactCollector()
    assert result._fact_ids == set()

# Generated at 2022-06-20 19:32:55.488736
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # lsb_release module is found
    lsb_path = '/usr/bin/lsb_release'
    module = MockModule()
    module.get_bin_path.return_value = lsb_path
    module.run_command.return_value = (0, '', '')
    lsb_fact_collector = LSBFactCollector(module=module)
    lsb_facts = lsb_fact_collector._lsb_release_bin(lsb_path, module)
    assert lsb_facts == {}

    # lsb_release module is not found
    lsb_path = None
    module = MockModule()
    module.get_bin_path.return_value = lsb_path
    module.run_command.return_value = (0, '', '')
    lsb_fact_collect

# Generated at 2022-06-20 19:33:02.631757
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  import tempfile
  import ansible.module_utils.facts.collector
  import ansible.module_utils.facts
  #Setup test environment
  module = ansible.module_utils.facts.collector.BaseFactCollector
  module.run_command = lambda command: (0, '', '')
  module.get_bin_path = lambda command: "lsb_release"
  get_file_lines = lambda file: [
                                 "DISTRIB_ID=Ubuntu\n", 
                                 "DISTRIB_RELEASE=14.04\n",
                                 "DISTRIB_DESCRIPTION=\"Ubuntu 14.04.3 LTS\"\n",
                                 "DISTRIB_CODENAME=trusty\n"]  

  # Test lsb_release binary

# Generated at 2022-06-20 19:33:14.813397
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = dict(description="\tClear Linux OS for Intel Architecture \t\t", id="Clear", major_release="27000",
                     release="27000", codename="Core")

    # This is the output of lsb_release -a where all fields except id are set to empty string
    # NoReleaseID_NoReleaseMajorVersion_NoRelease_NoDescription_NoCodename

    lsb_facts_no_release = dict(description="", id="NoReleaseID", major_release="", release="", codename="")

    lsb_release_file_no_release = """\
DISTRIB_ID=NoReleaseID
DISTRIB_RELEASE=
DISTRIB_DESCRIPTION=
DISTRIB_CODENAME=
"""

    # This is the output of lsb_release -a where all fields except id and release

# Generated at 2022-06-20 19:33:23.447868
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict()
    )
    lsb_facts = LSBFactCollector.collect(module)
    assert 'lsb' in lsb_facts
    assert lsb_facts.get('lsb')
    assert lsb_facts.get('lsb').get('release')
    assert lsb_facts.get('lsb').get('id')
    assert lsb_facts.get('lsb').get('description')
    assert lsb_facts.get('lsb').get('codename')
    assert lsb_facts.get('lsb').get('major_release')

# Generated at 2022-06-20 19:33:30.753497
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb = LSBFactCollector()
    lsb_facts = lsb._lsb_release_bin('/usr/bin/lsb_release',
                                     module=None)
    assert isinstance(lsb_facts, dict)
    assert lsb_facts
    assert isinstance(lsb_facts['release'], str)
    assert isinstance(lsb_facts['id'], str)
    assert isinstance(lsb_facts['description'], str)
    assert isinstance(lsb_facts['release'], str)
    assert isinstance(lsb_facts['codename'], str)


# Generated at 2022-06-20 19:33:34.593939
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
     assert LSBFactCollector.name == 'lsb'
     assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:33:44.272223
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:33:46.652108
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    module_utils = 'ansible.module_utils.facts.collector.BaseFactCollector'
    lsbfc = LSBFactCollector()
    assert isinstance(lsbfc, LSBFactCollector)

# Generated at 2022-06-20 19:33:48.059912
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == 'lsb'

# Generated at 2022-06-20 19:33:53.862255
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = {}

    assert lsb_facts == {}
    lsb_facts = '/usr/bin/lsb_release'
    lsb_facts = 'lsb-release'
    assert lsb_facts != {}

if __name__ == "__main__":
    test_LSBFactCollector()

# Generated at 2022-06-20 19:33:57.856282
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()

    assert lsb_facts is not None
    assert lsb_facts.name == 'lsb'
    assert lsb_facts._fact_ids == set()
    assert type(lsb_facts.STRIP_QUOTES) == str
    return True

# Generated at 2022-06-20 19:33:59.193284
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'

# Generated at 2022-06-20 19:34:10.798893
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    m = MagicMock()

# Generated at 2022-06-20 19:34:13.834255
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    module = object()
    collector = LSBFactCollector()
    assert collector.collect(module)['lsb'] == collector._lsb_release_file('/etc/lsb-release')

# Generated at 2022-06-20 19:34:17.086578
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-20 19:34:18.386003
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-20 19:34:34.183533
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'

# Generated at 2022-06-20 19:34:44.587585
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_path = '/usr/bin/lsb_release'
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = lsb_path
    lsbfacts = LSBFactCollector()
    mock_output = b'''LSB Version:    n/a
Distributor ID:    Automate-Testing
Description:    Automate-Testing
Release:        n/a
Codename:       n/a
'''
    mock_module.run_command.return_value = (0, mock_output, '')
    lsb_facts = lsbfacts.collect(mock_module)
    assert lsb_facts['lsb']['release'] == 'n/a'
    assert lsb_facts['lsb']['id'] == 'Automate-Testing'

# Generated at 2022-06-20 19:34:46.457263
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert(obj is not None)

# Generated at 2022-06-20 19:34:49.431980
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    lsb_facts_dict = lsb_collector.collect()
    assert lsb_facts_dict['lsb']['id'] == 'RedHat'

# Generated at 2022-06-20 19:34:51.426183
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact_collector = LSBFactCollector()

    assert fact_collector.name == 'lsb'

# Generated at 2022-06-20 19:34:54.543099
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """Test constructor of class LSBFactCollector"""

    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect()

# Generated at 2022-06-20 19:35:00.180320
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Assume that the lsb_release script is available on the search path
    lsb_path = LSBFactCollector().which('lsb_release')
    if lsb_path:
        lsb_facts = LSBFactCollector()._lsb_release_bin(lsb_path, None)
        assert 'id' in lsb_facts
        assert 'release' in lsb_facts
        assert 'description' in lsb_facts

# Generated at 2022-06-20 19:35:03.044248
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    from ansible.module_utils.facts.collector import get_collector_class
    test_constructor = get_collector_class('lsb')
    assert test_constructor is LSBFactCollector

# Generated at 2022-06-20 19:35:07.575771
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    lsb_facts = {
        'codename': 'trusty',
        'description': 'Ubuntu 14.04.3 LTS',
        'id': 'Ubuntu',
        'major_release': '14',
        'release': '14.04'
    }
    assert lsb_facts == lsb_collector.collect()

# Generated at 2022-06-20 19:35:09.304328
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb = LSBFactCollector()
    lsb.collect()
    LSBFactCollector.name = 'lsb'
    lsb.collect()

# Generated at 2022-06-20 19:35:40.714573
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    module = AnsibleModuleMock()
    lsb = LSBFactCollector()
    lsb_facts = lsb.collect(module=module)
    assert lsb_facts['lsb'] == {'major_release': '18', 'release': '18.04', 'id': 'Ubuntu', 'codename': 'bionic', 'description': 'Ubuntu 18.04.1 LTS'}


# Generated at 2022-06-20 19:35:44.720053
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert not lsb_fact_collector._fact_ids



# Generated at 2022-06-20 19:35:50.799120
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    class TestModule:
        def __init__(self):
            self.params = {}

        # For AnsibleModule Utils
        def get_bin_path(self, app, default=None, opt_dirs=[]):
            return "lsb_release"


# Generated at 2022-06-20 19:36:02.134412
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    class TestModule(object):

        def __init__(self, bin_path, run_command_return_value):
            self.bin_path = bin_path
            self.run_command_value = run_command_return_value

        def get_bin_path(self, command):
            return self.bin_path

        def run_command(self, command_tuple, errors='surrogate_then_replace'):
            return self.run_command_value

    lsb_path = "/usr/bin/lsb_release"

# Generated at 2022-06-20 19:36:03.299973
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect()

# Generated at 2022-06-20 19:36:04.802965
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.__class__.__name__ == 'LSBFactCollector'

# Generated at 2022-06-20 19:36:07.770856
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb._fact_ids == set()


# Generated at 2022-06-20 19:36:08.969206
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'


# Generated at 2022-06-20 19:36:12.224650
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact = LSBFactCollector()
    assert fact.name == 'lsb'
    assert isinstance(fact._fact_ids, set)
    assert isinstance(fact._allowed_collectors, tuple)
    assert isinstance(fact.STRIP_QUOTES, str)
    assert fact.COLLECTORS == ('lsb',)

# Generated at 2022-06-20 19:36:23.447700
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # create a simple test module
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector import Collector

    class CustomModule(ModuleStub):
        def __init__(self):
            self.params = {}
            self.facts_module = Collector().module
            self._debug = []
            self._log = []
            self._warnings = []
            self._deprecations = []
            self._verbosity = 0

    module = CustomModule()

    # get the LSB facts
    lsb_fact_collector = LSBFactCollector()
    facts = lsb_fact_collector.collect(module)

    # make sure facts are set
    assert facts['lsb']
    assert facts['lsb']['description']

# Generated at 2022-06-20 19:37:28.790980
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    facts = LSBFactCollector().collect(module)
    assert 'lsb' in facts

# Generated at 2022-06-20 19:37:30.395746
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb.collect() == {'lsb': {}}

# Generated at 2022-06-20 19:37:43.025134
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import mock
    import ansible.module_utils.facts.collectors.lsb as lsb_facts
    from ansible.module_utils.facts import ModuleFailedException

    # Testing if lsb_release is present and if so populate lsb_facts
    test_data = {
        'args': [
            'lsb_release',
            '-a'
        ],
        'rc': 0,
        'stdout': "Distributor ID:\tRaspberry Pi Foundation\nRelease:\t\t5.4\nCodename:\t\tbeta\n",
        'stderr': ""
    }

    lsb_facts.get_file_lines = mock.MagicMock(return_value=None)
    module = mock.MagicMock()

# Generated at 2022-06-20 19:37:44.529408
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert LSBFactCollector.collect()

# Generated at 2022-06-20 19:37:46.410268
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None

# Generated at 2022-06-20 19:37:50.728348
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:37:58.989257
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Init the class
    lsb_collector = LSBFactCollector()
    
    # Return a dictionnary for tests
    # Here you can put your fixture dictionnary
    return_fact_dict = {
        "lsb": {
             "id": "Debian",
             "major_release": "9",
             "release": "9.8",
             "codename": "stretch",
             "description": "Debian GNU/Linux 9.8 (stretch)"
        }
    }
    
    # Asserts on the method collect
    assert lsb_collector.collect() == return_fact_dict

# Generated at 2022-06-20 19:38:07.502859
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.utils import cd_data

    with cd_data('../../..'):
        from ansible.module_utils.facts import ModuleStub, get_module_facts

        module = ModuleStub()
        facts_dict = get_module_facts(module=module)

        assert 'lsb' in facts_dict

        # test that 'lsb' dict doesn't contain an empty dict when it wasn't found
        assert facts_dict['lsb']

        # test that the 'lsb' dict has the correct keys
        assert 'release' in facts_dict['lsb']

# Generated at 2022-06-20 19:38:09.869426
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test for instance creation
    my_lsb_fact_collector = LSBFactCollector()
    assert my_lsb_fact_collector

# Generated at 2022-06-20 19:38:15.934125
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    Tests for Ansible's module_utils.facts.collector.LSBFactCollector.collect
    """
    # lsb_release_bin is tested in test_lsb.py
    # lsb_release_file is tested in test_lsb.py
    lsb_result = {
        'id': 'Ubuntu',
        'release': '12.04',
        'description': 'Ubuntu 12.04.4 LTS',
        'codename': 'precise',
        'major_release': '12'
    }

    # Test _lsb_release_bin
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    lsb_release_bin = LSBFactCollector._lsb_release_bin('lsb_release', None)
    assert lsb_

# Generated at 2022-06-20 19:40:46.489144
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Assume lsb_release is available
    lsb_cmd = LSBFactCollector()
    lsb_result = {
                'codename': 'xenial',
                'description': 'Ubuntu 16.04.1 LTS',
                'id': 'Ubuntu',
                'release': '16.04',
                'major_release': '16'
             }

    # emulate lsb_cmd.collect()
    lsb_cmd.module = True
    lsb_cmd.module.get_bin_path = lambda x: '/usr/bin/lsb_release'
    with open('/proc/cmdline', 'r') as f:
        lsb_cmd.module.run_command = lambda x: (0, f.read(), '')

    assert lsb_cmd.collect()['lsb'] == lsb_

# Generated at 2022-06-20 19:40:57.215501
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    '''
    Test collect method of LSBFactCollector
    '''

    lsb_cmd_output = ('LSB Version:   :core-4.1-amd64:core-4.1-noarch\n'
                      'Distributor ID: Fedora\n'
                      'Description:    Fedora release 26 (Twenty Six)\n'
                      'Release:        26\n'
                      'Codename:       TwentySix\n')
    etc_lsb_release_file = ('DISTRIB_ID=LinuxMint\n'
                            'DISTRIB_RELEASE=18.3\n'
                            'DISTRIB_CODENAME=syl-via\n'
                            'DISTRIB_DESCRIPTION="Linux Mint 18.3 Sylvia"\n')

# Generated at 2022-06-20 19:41:03.563531
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'
    assert lsb_collector._lsb_release_bin(None, None) == {}
    assert lsb_collector._lsb_release_file(None) == {}

# Generated at 2022-06-20 19:41:09.367278
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command.side_effect = [
        (0, 'LSB Version:    :core-4.1-amd64:core-4.1-noarch\ndistributor-id:Centos\ndescription:CentOS Linux release 7.7.1908 (Core)\nrelease:7.7.1908\ncodename:Core', 'Error'),
        (0, 'DISTRIB_ID=Centos\nDISTRIB_RELEASE=7.7.1908\nDISTRIB_DESCRIPTION="CentOS Linux release 7.7.1908 (Core)"\nDISTRIB_CODENAME=Core', None)
    ]

    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=module)



# Generated at 2022-06-20 19:41:14.696721
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == "lsb" 
    assert lsb._fact_ids == set()
    assert lsb.STRIP_QUOTES == r'\'\"\\'

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-20 19:41:17.368860
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert set(lsb_fact_collector._fact_ids) == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-20 19:41:19.189673
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:41:21.371678
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name in lsb._fact_ids

# Generated at 2022-06-20 19:41:32.793599
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # pylint: disable=invalid-name
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    class MockModule(object):
        """Mock class module"""
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            return "/usr/bin/lsb_release"

        def run_command(self, cmd, errors='surrogate_then_replace', check_rc=True):
            return [self.rc, self.out, self.err]


# Generated at 2022-06-20 19:41:35.722223
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    module = ansible_fake_module()
    module.params = {}
    lsb_collector.collect(module, {})


