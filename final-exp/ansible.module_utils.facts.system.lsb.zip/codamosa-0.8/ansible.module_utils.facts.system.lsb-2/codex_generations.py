

# Generated at 2022-06-11 04:49:34.409204
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.utils.fake_module import FakeModule
    from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    from ansible.module_utils.facts.platform.linux import Linux
    import os

    module = FakeModule(platform='linux')
    module.run_command = lambda command, **kwargs : (0, 'test output', 'test errors')
    module.get_bin_path = lambda *args : '/bin/lsb_release'
    module.params = {}

    collector = LSBFactCollector()
    output = collector.collect(module=module)

    if not isinstance(output, dict):
        print('Failed to retrieve the facts!')
        # Assert in the 'finally' block to avoid code coverage failure
        assert False

    # Ass

# Generated at 2022-06-11 04:49:43.304798
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_path = '/usr/bin/lsb_release'
    lsb_fail_path = '/usr/bin/lsb_releas'
    module = ""
    result = LSBFactCollector._lsb_release_bin(lsb_path, module)
    assert result
    result = LSBFactCollector._lsb_release_bin(lsb_fail_path, module)
    assert not result
    result = LSBFactCollector._lsb_release_file('/etc/lsb-release')
    assert result
    result = LSBFactCollector._lsb_release_file('/etc/lsb-release1')
    assert not result

# Generated at 2022-06-11 04:49:49.996870
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactsCollector
    test_module_collector = ModuleFactsCollector(None)
    test_result = dict(lsb=dict(codename="", description="", id="", major_release="", release=""))
    test_module_collector.lsb_collector.bin_path = None
    assert test_result == test_module_collector.lsb_collector.collect(test_module_collector), "Did not return expected result"

# Generated at 2022-06-11 04:49:58.538443
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_info = {
        'id' : 'Debian',
        'description' : 'Debian GNU/Linux 6.0.6 (squeeze)',
        'release' : '6.0.6',
        'codename' : 'squeeze',
        'major_release' : '6'
    }
    lsb_fact_collector = LSBFactCollector(name='Test LSB')
    lsb_facts = lsb_fact_collector.collect(module=None,
                                           collected_facts=None)
    assert 'lsb' in lsb_facts
    assert lsb_facts['lsb'] == lsb_info

# Generated at 2022-06-11 04:50:08.234675
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    TEST_DATA_1 = """
LSB Version:  :core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch:supplementary-4.1-amd64:supplementary-4.1-noarch
Distributor ID: CentOS
Description:    CentOS Linux release 7.5.1804 (Core)
Release:        7.5.1804
Codename:       Core
"""


# Generated at 2022-06-11 04:50:09.989322
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        LSBFactCollector()
    except Exception as e:
        print(e)

# Generated at 2022-06-11 04:50:16.954530
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = lsb_test_data()

    class Module:
        def get_bin_path(lsb_path, *a, **kw):
            return '/bin/' + lsb_path

        def run_command(cmd, **kw):
            return [
                0,
                '\n'.join(['%s:%s' % (k, v) for k, v in lsb_facts.items()]),
                ''
            ]

    collected_facts = LSBFactCollector().collect(Module())
    assert collected_facts['lsb'] == lsb_facts



# Generated at 2022-06-11 04:50:26.829974
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector

    test_facts = dict(
        lsb=dict(
            id=None,
            release=None,
            codename=None,
            major_release=None,
            description=None
        )
    )

    test_module = dict(
        get_bin_path=lambda x: x
    )

    def test_run_command_func(cmd, *args, **kwargs):
        if cmd == 'lsb_release':
            return 0, """
LSB Version:<magic>
Distributor ID:<id>
Description:<description>
Release:<release>
Codename:<codename>
            """.strip(), ''
        else:
            return 0, '', ''

# Generated at 2022-06-11 04:50:29.279157
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()

    assert lsb_facts.name == "lsb"
    assert lsb_facts._fact_ids == set()

# Generated at 2022-06-11 04:50:31.088556
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector



# Generated at 2022-06-11 04:50:40.920919
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    fact_collector = LSBFactCollector()
    assert 'lsb' in fact_collector.collect()

# Generated at 2022-06-11 04:50:50.102607
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule

    # test a lsb_release bin with output
    test_module = AnsibleModule(argument_spec={})
    lsb = LSBFactCollector()
    lsb.collect(module=test_module, collected_facts=None)

    # test lsb_release bin with no output
    lsb = LSBFactCollector()
    lsb.collect(module=test_module, collected_facts=None)

    # test lsb_release file with output
    test_module = AnsibleModule(argument_spec={})
    lsb = LSBFactCollector()
    lsb.collect(module=test_module, collected_facts=None)

    # test l

# Generated at 2022-06-11 04:50:51.013948
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector().collect()

# Generated at 2022-06-11 04:51:00.210576
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = {'id': 'Ubuntu',
                 'release': '18.04',
                 'codename': 'bionic',
                 'description': 'Ubuntu 18.04.2 LTS'}
    expected_lsb_facts = {'id': 'Ubuntu',
                          'release': '18.04',
                          'codename': 'bionic',
                          'major_release': '18',
                          'description': 'Ubuntu 18.04.2 LTS'}

    lsb_path = '/usr/bin/lsb_release'
    # try the 'lsb_release' script first
    if lsb_path:
        collected_facts = LSBFactCollector()._lsb_release_bin(lsb_path,
                                                              module=None)

    # no lsb_release

# Generated at 2022-06-11 04:51:03.333355
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print('Testing LSBFactCollector')
    lsb_obj = LSBFactCollector()
    print('Test constructor of LSBFactCollector success')
    assert(lsb_obj.name == 'lsb')


# Generated at 2022-06-11 04:51:05.841276
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert(LSBFactCollector.name == 'lsb')
    assert(LSBFactCollector.STRIP_QUOTES == '\'\"\\')


# Generated at 2022-06-11 04:51:06.802568
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-11 04:51:16.273450
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Ansible facts for a test environment
    ansible_facts = {
        'system': 'Linux',
        'distribution': 'Debian',
    }

    # Test instance of the class
    test_obj = LSBFactCollector.test(ansible_facts)

    # Expected instance variables
    expected_instance_vars = {
        'name': 'lsb',
        '_fact_ids': set(),
        'STRIP_QUOTES': r'\'\"\\',
        '_ansible_facts': ansible_facts,
    }

    # Compare the test instance variables with the expected
    for k, v in expected_instance_vars.items():
        assert test_obj.__dict__[k] == v

# Generated at 2022-06-11 04:51:18.227294
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact = LSBFactCollector()
    assert isinstance(lsb_fact, LSBFactCollector)

# Generated at 2022-06-11 04:51:27.797782
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    dummy_collected_facts = dict()
    test_collector = LSBFactCollector()
    test_collector._lsb_release_bin = lambda lsb_path, module: {'id': 'Fedora', 'release': '20', 'major_release': '20', 'description': 'Fedora 20 (Heisenbug)', 'codename': 'Heisenbug'}
    test_collector._lsb_release_file = lambda etc_lsb_release_location: None
    dummy_module = object()
    test_collector.collect(dummy_module, dummy_collected_facts)
    assert dummy_collected_facts['lsb']['id'] == 'Fedora'

# Generated at 2022-06-11 04:51:37.546553
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:51:38.679326
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector.collect()

# Generated at 2022-06-11 04:51:44.629590
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test set up
    module = collections.namedtuple('module', 'get_bin_path run_command')
    module.get_bin_path = lambda s, x: '/bin/lsb_release'
    module.run_command = lambda s, x: ('0', 'Distributor ID: Ubuntu\nDescription: Ubuntu 14.04.3 LTS\nRelease: 14.04\nCodename: trusty', '')
    fake_etc_lsb_release_location = 'fake_etc_lsb_release_location'
    os.path.exists = lambda x: x == fake_etc_lsb_release_location
    # Test set up end

    lsb_fact_collector = LSBFactCollector()
    lsb_dict = lsb_fact_collector.collect(module=module)
    assert l

# Generated at 2022-06-11 04:51:53.186932
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = MockAnsibleModule()
    test_module.lsb_release_bin_path = "lsb_release"
    test_module.lsb_release_file_path = "/etc/lsb-release"
    test_module.lsb_release_script_output = "Distributor ID: Ubuntu\nDescription:    Ubuntu 16.04.2 LTS\nRelease:        16.04\nCodename:       xenial"
    test_module.lsb_release_file_content = "DISTRIB_ID=Ubuntu\nDISTRIB_RELEASE=16.04\nDISTRIB_CODENAME=xenial\nDISTRIB_DESCRIPTION=\"Ubuntu 16.04.2 LTS\""

# Generated at 2022-06-11 04:51:53.979770
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    tmp = LSBFactCollector()
    assert tmp

# Generated at 2022-06-11 04:51:57.509002
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_obj = LSBFactCollector()
    assert lsb_fact_collector_obj.name == "lsb"
    assert lsb_fact_collector_obj._fact_ids == set()
    assert lsb_fact_collector_obj.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:51:59.192362
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    # First test to make sure the class is created
    lsb_collector = LSBFactCollector()

    assert lsb_collector is not None

# Generated at 2022-06-11 04:52:04.953715
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_obj = LSBFactCollector()

    assert test_obj.name == 'lsb'
    assert test_obj._fact_ids is not None
    assert test_obj.STRIP_QUOTES == r'\'\"\\'

    assert test_obj._lsb_release_file('/etc/lsb-release') is not None
    assert test_obj._lsb_release_bin('/etc/lsb-release', 'module') is not None
    assert test_obj.collect() is not None

# Generated at 2022-06-11 04:52:13.309048
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    mocker = Mocker()
    module = mocker.mock()
    class_obj = LSBFactCollector()

    assert class_obj._fact_ids == set()
    assert class_obj.STRIP_QUOTES == r'\'\"\\'
    assert class_obj.name == 'lsb'
    assert class_obj._collect_fake is False
    assert class_obj._module is None
    assert class_obj.lsb_release_command is None
    assert class_obj._module.run_command.call_count == 0
    assert class_obj._module.get_bin_path.call_count == 0


# Generated at 2022-06-11 04:52:15.011384
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert isinstance(x, LSBFactCollector)


# Generated at 2022-06-11 04:52:41.225705
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Because Ansible relies on /usr/bin/lsb_release to obtain LSB facts,
    # mocking this executable is not possible.  In order to run unit tests,
    # we must comment out the os.path.exists check for lsb_release before
    # returning facts or the unit test will return an empty dictionary.

    # Mock of class AnsibleModule is defined below
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # Calling constructor for class BaseFactCollector
    base_collector = BaseFactCollector()
    lsb_facts_dict = {}


# Generated at 2022-06-11 04:52:43.785477
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.name == 'lsb'
    assert obj.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:52:45.906397
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:52:47.858810
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    instance = LSBFactCollector()
    assert instance.name == 'lsb'

    assert instance._fact_ids is not None


# Generated at 2022-06-11 04:52:55.082469
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    test_LSBFactCollector_collect()
    """
    # lsb_release not installed
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_dict = lsb_fact_collector.collect(
        {"get_bin_path": lambda *args: None}
    )
    assert lsb_fact_dict == {"lsb": {}}
    # lsb_release not present in PATH
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_dict = lsb_fact_collector.collect(
        {"get_bin_path": lambda *args: "/usr/bin/lsb_release"}
    )
    assert lsb_fact_dict == {"lsb": {}}
    # lsb_release present in PATH but not executable
    l

# Generated at 2022-06-11 04:52:57.484991
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert set(lsb_fact_collector._fact_ids) == set()

# Generated at 2022-06-11 04:52:59.534332
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    c = LSBFactCollector()
    assert c.name == 'lsb'
    assert c.collect() == {}


# Generated at 2022-06-11 04:53:08.633110
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector.STRIP_QUOTES = '\"'
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Distributor ID:	RedHatEnterpriseServer\nDescription:	Red Hat Enterprise Linux Server release 7.2 (Maipo)\nRelease:	7.2\nCodename:	Maipo'))
    lsb_path = module.get_bin_path('lsb_release')
    lsb_facts = LSBFactCollector()._lsb_release_bin(lsb_path,module=module)

# Generated at 2022-06-11 04:53:11.165577
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:53:11.972543
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-11 04:53:55.628516
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test an object can be created from the class
    LSBFactCollector()

# Generated at 2022-06-11 04:54:03.465398
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import sys
    import os

    sys.path.insert(0, os.path.abspath(os.path.dirname(__file__) + '/../../../lib/ansible/module_utils/'))
    from ansible.module_utils.facts.system import DummyModule

    dummy_module = DummyModule(
        argument_spec={},
        supports_check_mode=False,
    )

    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=dummy_module)
    lsb_fact_collector.post_process_facts(lsb_facts)
    assert 'lsb' in lsb_facts
    assert len(lsb_facts['lsb']) > 0

# Generated at 2022-06-11 04:54:04.346044
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  assert LSBFactCollector().name == 'lsb'

# Generated at 2022-06-11 04:54:12.754552
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    input_lsb_path = "/sbin/lsb_release"
    input_etc_lsb_release_location = "/etc/lsb-release"
    input_module = "module"
    input_collector = "collector"
    lsbfc = LSBFactCollector(input_lsb_path, input_etc_lsb_release_location, input_module, input_collector)

    assert lsbfc.lsb_path == input_lsb_path
    assert lsbfc.etc_lsb_release_location == input_etc_lsb_release_location
    assert lsbfc.module == input_module
    assert lsbfc.collector == input_collector
    assert lsbfc.name == "lsb"
    assert lsbfc._fact_ids == set()
    assert lsbfc

# Generated at 2022-06-11 04:54:14.944126
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.name == 'lsb'
    assert x._fact_ids == set()
    assert x.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:54:18.769542
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector

    collector = LSBFactCollector(basic.AnsibleModule)
    assert isinstance(collector, LSBFactCollector)
    assert isinstance(collector, collector.BaseFactCollector)

# Generated at 2022-06-11 04:54:26.613649
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = mock.MagicMock()
    module.get_bin_path = mock.Mock(return_value='/bin/lsb_release')
    module.run_command = mock.Mock(return_value=(0, "LSB Version:	:core-4.1-amd64:core-4.1-noarch\n" \
        "Distributor ID:	RedHatEnterpriseServer\nDescription:	Red Hat Enterprise Linux Server release 7.0 (Maipo)\n" \
        "Release:	7.0\nCodename:	Maipo", ''))
    collected_facts = LSBFactCollector().collect(module=module, collected_facts=None)
    assert collected_facts['lsb']['id'] == "RedHatEnterpriseServer"

# Generated at 2022-06-11 04:54:29.137474
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert collector.STRIP_QUOTES == r'\'\"\\'
    assert not collector._fact_ids

# Generated at 2022-06-11 04:54:39.602626
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # simulating ansible module object
    class Module:
        def __init__(self):
            self._bin_path = {}
        def get_bin_path(self, name):
            return self._bin_path.get(name)
        # simulating abstract method
        def run_command(self, *args, **kwargs):
            pass

    # tests
    lfc = LSBFactCollector()
    # test no lsb_release found
    assert lfc.collect() == {}
    # test lsb_release found
    m = Module()
    m._bin_path['lsb_release'] = 'lsb_release'
    # test lsb_release v1
    lfc = LSBFactCollector()

# Generated at 2022-06-11 04:54:47.824615
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping, MutableSequence
    import collections
    lsb_facts = None

    if not hasattr(collections, 'Mapping'):
        collections.Mapping = Mapping
    if not hasattr(collections, 'MutableMapping'):
        collections.MutableMapping = MutableMapping
    if not hasattr(collections, 'MutableSequence'):
        collections.MutableSequence = MutableSequence

    #  Run Ansible test
    facts_collector = FactsCollector('collect')
    fact_collectors = facts_collector.get_fact_collectors()



# Generated at 2022-06-11 04:56:26.853587
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    '''Unit test for method collect of class LSBFactCollector'''

    # mock module and class
    from ansible.module_utils import basic
    from ansible.module_utils.facts import FactsCollector

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    # mock lsb_release binary returns something
    module.run_command = lambda path, errors: (0, '''\
LSB Version:	1.4
Distributor ID:	Ubuntu
Description:	Ubuntu 16.04.3 LTS
Release:	16.04
Codename:	xenial''', '')
    lsb_fact_collector = LSBFactCollector()

# Generated at 2022-06-11 04:56:27.846528
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'

# Generated at 2022-06-11 04:56:30.550453
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module)

# Unit test method collect of class LSBFactCollector, where lsb_path is wrong

# Generated at 2022-06-11 04:56:33.143015
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-11 04:56:39.757027
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import platform
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_lsb_file = tmp_dir + '/' + 'lsb_file'
    f = open(tmp_lsb_file, 'w')

    # test data
    id = "RedHatEnterpriseServer"
    release = "7.1"
    description = "Red Hat Enterprise Linux " + release + " (Maipo)"
    codename = "Maipo"
    major_release = release.split('.')[0]


# Generated at 2022-06-11 04:56:40.947467
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'


# Generated at 2022-06-11 04:56:42.689344
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_dict = {'lsb': {'codename': 'bsd', 'id': 'FreeBSD', 'release': '12.0'}}
    assert test_dict == LSBFactCollector().collect({})

# Generated at 2022-06-11 04:56:43.823530
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Call the constructor
    tester = LSBFactCollector(None)
    assert tester == None

# Generated at 2022-06-11 04:56:48.375169
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """Test LSBFactCollector._collect, returns a dict of lsb facts"""
    module = MockModule()
    module.run_command = Mock(return_value=(0, MOCK_LSB_1, ''))
    module.get_bin_path = Mock(return_value='/bin/lsb_release')
    lsb = LSBFactCollector()
    # Call tested function
    result = lsb.collect(module=module)
    # Check if result is as expected
    assert result == {'lsb': MOCK_OUTPUT_1}


# Generated at 2022-06-11 04:56:49.026282
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert(LSBFactCollector())