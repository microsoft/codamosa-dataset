

# Generated at 2022-06-11 04:49:33.896655
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.result = {}
        
        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/lsb_release"

        def run_command(self, *args, **kwargs):
            return 0, 'LSB Version:    :core-4.1-amd64:core-4.1-noarch\nDistributor ID: Fedora', ''

    # Create instance of module, so AnsibleModule can be initialized
    module = MockModule()

    # Mock AnsibleModule

# Generated at 2022-06-11 04:49:35.719179
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None

# Generated at 2022-06-11 04:49:46.342707
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/bin/lsb_release'
    module_mock.run_command.return_value = (0, 'LSB Version:    :core-4.1-amd64:core-4.1-noarch', None)
    os.path.exists.return_value = False
    os.stat.return_value = MagicMock()
    os.stat.return_value.st_size = 0
    get_file_lines.return_value = ['DISTRIB_ID="CentOS"']
    
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=module_mock)
    
    assert os.path.exists.called_once_

# Generated at 2022-06-11 04:49:50.419301
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert issubclass(LSBFactCollector, BaseFactCollector)
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:49:51.453209
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()

# Generated at 2022-06-11 04:49:53.520259
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create an instance of LSBFactCollector then call the method collect
    LSBFactCollector().collect()


# Generated at 2022-06-11 04:50:03.728344
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import __init__ as facts_init
    from ansible.module_utils._text import to_bytes

    facts_init.collectors = []
    LSBFactCollector.init_module_facts(None)
    collectors = facts_init.collectors

    # test that there is an instance of the LSB fact collector
    assert len([c for c in collectors if c.__name__ == 'LSBFactCollector']) == 1

    # test collection
    fact_collector = [c for c in collectors if c.__name__ == 'LSBFactCollector'][0]

    collect_result = fact_collector.collect(None, None)

    lsb_fact_exists = 'lsb' in collect_result
    assert lsb_fact_exists


# Generated at 2022-06-11 04:50:06.412132
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.name == 'lsb'
    assert x._fact_ids == set()
    assert x.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:50:09.410865
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import Collector

    module = pytest.fixture
    lsb_facts = LSBFactCollector().collect(module=module)
    print(lsb_facts)

# Generated at 2022-06-11 04:50:14.844887
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector()
    platform_facts = {
        "lsb": {
            "release": "7.6",
            "id": "RedHatEnterpriseServer",
            "description": "Red Hat Enterprise Linux Server release 7.6 (Maipo)",
            "codename": "Maipo",
            "major_release": "7"
        }
    }
    assert platform_facts == lsb_facts.collect(None, None)

# Generated at 2022-06-11 04:50:24.314940
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test that missing file (/etc/lsb-release) yields empty dict
    # Note: I couldn't find a way to mock this, so I am not testing it.
    # lsb = LSBFactCollector()
    # lsb.collect()
    pass

# Generated at 2022-06-11 04:50:33.343819
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    os_facts = LSBFactCollector()

    # is _fact_ids is a set
    assert isinstance(os_facts._fact_ids, set)

    # is _fact_ids has at least 1 fact
    assert len(os_facts._fact_ids) >= 1

    # Does the _fact_ids set contain the os fact
    assert 'lsb' in os_facts._fact_ids

    # is lsb in LSBFactCollector.STRIP_QUOTES
    assert '\'' in LSBFactCollector.STRIP_QUOTES
    assert '\"' in LSBFactCollector.STRIP_QUOTES
    assert '\\' in LSBFactCollector.STRIP_QUOTES

# Generated at 2022-06-11 04:50:42.081955
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import os

    # create mock "module"
    class MockModule(object):
        def __init__(self, lsb_path=None,
                     lsb_release_bin_output=None, lsb_release_bin_rc=0,
                     lsb_release_bin_err=None,
                     lsb_release_file_output=None):
            self._lsb_path = lsb_path
            self._lsb_release_bin_rc = lsb_release_bin_rc
            self._lsb_release_bin_output = lsb_release_bin_output
            self._lsb_release_bin_err = lsb_release_bin_err
            self._lsb_release_file_output = lsb_release_file_output

        def get_bin_path(self, path):
            return self

# Generated at 2022-06-11 04:50:44.855892
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()
    assert l.name == 'lsb'
    assert l._fact_ids == set()
    assert l.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:50:53.899154
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import FactsModule
    from ansible.module_utils.facts.utils import get_file_content
    args = get_file_content('/etc/lsb-release',
                            skip_lines_with_comments=False)
    lsb_facts = LSBFactCollector()._lsb_release_file(args)
    assert lsb_facts == {'id': 'Ubuntu', 'release': '18.04',
                         'description': 'Ubuntu 18.04.1 LTS',
                         'codename': 'bionic'}

# Generated at 2022-06-11 04:50:56.726265
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == "lsb"
    assert not LSBFactCollector._fact_ids
    assert LSBFactCollector.STRIP_QUOTES == r"\'\"\\"


# Generated at 2022-06-11 04:51:01.983784
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lfc = LSBFactCollector()
    lsb = {
        'codename': 'vivid',
        'description': 'Ubuntu 15.04',
        'id': 'Ubuntu',
        'major_release': '15',
        'release': '15.04'
    }
    facts_dict = {'lsb': lsb}
    assert lfc.collect(collected_facts={}) == facts_dict


# Generated at 2022-06-11 04:51:05.879732
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == "'\"\\"

# Generated at 2022-06-11 04:51:06.865054
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector



# Generated at 2022-06-11 04:51:17.076783
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import get_file_contents
    import mock
    import os

    class TestModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    def _run_command_mock(cmd, errors='surrogate_then_replace'):
        if cmd == ['lsb_release', '-a']:
            return 0, get_file_contents(LSBFactCollector.__name__, 'lsb_release-a.out'), ''

# Generated at 2022-06-11 04:51:25.664865
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    uut = LSBFactCollector()

    assert uut.name == 'lsb'
    assert len(uut._fact_ids) == 0



# Generated at 2022-06-11 04:51:28.358829
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert isinstance(LSBFactCollector._fact_ids, set)
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:51:30.596039
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect()
    assert lsb_facts

# Generated at 2022-06-11 04:51:33.907315
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.name == 'lsb'
    assert obj._fact_ids == set()
    assert obj.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:51:41.973449
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    def run_commands(commands, rc, out, err):
        # print(commands)
        if commands[0] == 'lsb_release':
            if commands[1] == '-a':
                return (0, '''LSB Version:\tcore-9.20160110ubuntu0.2-amd64:core-9.20160110ubuntu0.2-noarch:security-9.20160110ubuntu0.2-amd64:security-9.20160110ubuntu0.2-noarch
Distributor ID:\txenial
Description:\tUbuntu 16.04 LTS
Release:\t16.04
Codename:\txenial
''', '')
            else:
                return (1, 'Unknown option', '')
        return (rc, out, err)


# Generated at 2022-06-11 04:51:49.632080
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector._lsb_release_bin = lambda lsb_path, m: {'lsb_release_bin': lsb_path}
    lsb_fact_collector._lsb_release_file = lambda f: {'lsb_release_file': f}

    assert lsb_fact_collector.collect(module=None) == {}
    assert lsb_fact_collector.collect(module=object()) == {}

    class Module:
        def get_bin_path(self, bin):
            return bin + '_path'
    module = Module()

    assert lsb_fact_collector.collect(module) == {'lsb': {'lsb_release_bin': 'lsb_release_path'}}
    assert l

# Generated at 2022-06-11 04:51:53.329742
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector
    assert lsb_fact_collector.name == "lsb"
    assert lsb_fact_collector._fact_ids == set()



# Generated at 2022-06-11 04:51:54.125313
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-11 04:51:56.998882
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact_collector_object = LSBFactCollector()
    assert fact_collector_object.name == 'lsb'
    assert fact_collector_object._fact_ids == set()
    assert fact_collector_object.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:51:59.305033
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == '\'\"\\'

# Generated at 2022-06-11 04:52:13.013427
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector

# Generated at 2022-06-11 04:52:15.053381
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert not lsb._fact_ids

# Generated at 2022-06-11 04:52:24.401978
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.system.lsb import LSBFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.facts import __virtual__
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    def _exec(cmd, sudoable=False):
        return 0, '', ''

    def _isfile(path):
        if path == "/etc/lsb-release":
            return True
        else:
            return False

    m = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )


# Generated at 2022-06-11 04:52:27.319571
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

    return True

# Generated at 2022-06-11 04:52:33.354046
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module = MockModule()
    test_module.run_command = Mock(return_value=(0, 'Description:    Linux Mint 18 Sarah\nRelease:    18\nCodename:    sarah', ''))

    lsb = LSBFactCollector()
    result = lsb.collect(module=test_module)

    assert result.get('lsb').get('id') == 'LinuxMint'
    assert result.get('lsb').get('description') == 'Linux Mint 18 Sarah'
    assert result.get('lsb').get('release') == '18'
    assert result.get('lsb').get('codename') == 'sarah'
    assert result.get('lsb').get('major_release') == '18'


# Unit test to check for stripped values.

# Generated at 2022-06-11 04:52:35.407952
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fc = LSBFactCollector()
    assert fc.name == 'lsb'
    assert fc.collect() == {}

# Generated at 2022-06-11 04:52:36.571977
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-11 04:52:39.194419
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == 'lsb'

# Generated at 2022-06-11 04:52:48.828962
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_col = LSBFactCollector()
    facts = lsb_col.collect()
    assert 'lsb' in facts

    lsb_fact = facts['lsb']
    assert 'release' in lsb_fact
    assert 'id' in lsb_fact
    assert 'description' in lsb_fact
    assert 'codename' in lsb_fact

    # just make sure the /etc/lsb-release file was parsed
    if 'Ubuntu' in lsb_fact['description']:
        assert 'major_release' in lsb_fact

    # just make sure the /etc/lsb-release file was parsed
    if 'CentOS' in lsb_fact['description']:
        assert 'major_release' in lsb_fact

# Generated at 2022-06-11 04:52:50.558190
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.name == 'lsb'
    assert x._fact_ids == set()

# Generated at 2022-06-11 04:53:24.004136
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.name == "lsb"
    assert obj._fact_ids == set()
    assert obj.STRIP_QUOTES == r'\'\"\\'

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-11 04:53:26.896174
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_obj = LSBFactCollector()
    assert isinstance(lsb_fact_collector_obj, LSBFactCollector)
    assert lsb_fact_collector_obj.name == 'lsb'

# Generated at 2022-06-11 04:53:34.418738
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    class GetBinPathMock(object):
        def __init__(self):
            self.path = None

        def get_bin_path(self, path):
            self.path = path
            return path

    class RunCommandMock:
        def __init__(self):
            self.command = None
            self.module_name = None
            self.rc = 0
            self.out = ""
            self.err = ""
            self.call_count = 0

        def run_command(self, command, module_name, errors):
            self.command = command
            self.module_name = module_name
            self.call_count += 1
            return (self.rc, self.out, self.err)


# Generated at 2022-06-11 04:53:35.914921
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect()


# Generated at 2022-06-11 04:53:39.892002
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    lsb_path = module.get_bin_path('lsb_release')
    lsb_facts = LSBFactCollector()._lsb_release_bin(lsb_path, module=module)
    assert lsb_facts['id'] == 'Ubuntu'
    assert lsb_facts['codename'] == 'xenial'


# Generated at 2022-06-11 04:53:44.316787
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # expected_name is initialized to None
    expected_name = None
    # expected_fact_ids is initialized to empty set
    expected_fact_ids = set()

    # Actual constructor
    lsb = LSBFactCollector()

    # Assert if name of the object is correct
    assert lsb.name == expected_name

    # Assert if _fact_ids of the object is correct
    assert lsb._fact_ids == expected_fact_ids

# Generated at 2022-06-11 04:53:51.970674
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import sys
    import mock
    import ansible.module_utils.facts.collector

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    class TestLSBFactCollector(unittest.TestCase):

        def setUp(self):
            self.org_run_commands = ansible.module_utils.facts.collector.run_commands


# Generated at 2022-06-11 04:53:59.927368
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    class MockModule(object):
        def __init__(self, lsb_script_path=None, etc_lsb_path=None):
            self.lsb_script_path = lsb_script_path
            self.etc_lsb_path = etc_lsb_path

        def get_bin_path(self, _):
            return self.lsb_script_path

        def _read_file(self, _):
            if self.etc_lsb_path:
                with open(self.etc_lsb_path, 'rb') as f:
                    return f.read()
            else:
                return ''

        def run_command(self, _, **kwargs):
            return 0, '', ''

    # Test lsb_release script

# Generated at 2022-06-11 04:54:02.940079
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    lsb_obj = LSBFactCollector()

    assert lsb_obj.name == 'lsb'
    assert lsb_obj._fact_ids == set()
    assert lsb_obj.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:54:08.083549
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # module_utils/facts/collector.py:Collector.populate() calls LSBFactCollector.collect()
    c = Collector("Setup")
    c.populate()
    lsb_facts = c.ansible_facts['lsb']

    assert 'id' in lsb_facts
    assert 'release' in lsb_facts
    assert 'major_release' in lsb_facts

# Generated at 2022-06-11 04:55:21.646622
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector import Collector
    import os
    import tempfile

    lsb_release_content = (
        'DISTRIB_ID=Ubuntu\n'
        'DISTRIB_RELEASE=16.04\n'
        'DISTRIB_CODENAME=xenial\n'
        'DISTRIB_DESCRIPTION="Ubuntu 16.04.3 LTS"\n'
    )


# Generated at 2022-06-11 04:55:23.367933
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    instance = LSBFactCollector()
    assert instance.name == 'lsb'
    assert LSBFactCollector.STRIP_QUOTES == '\'\"\\'

# Generated at 2022-06-11 04:55:25.107075
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact = LSBFactCollector()
    assert isinstance(lsb_fact, LSBFactCollector)


# Generated at 2022-06-11 04:55:27.185689
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """
    Test_lsbfactcollector is the class that test the constructor of LSBFactCollector
    """

    lsb_obj = LSBFactCollector()
    assert lsb_obj.name == "lsb"

# Generated at 2022-06-11 04:55:34.230386
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    options = {'module_utils': 'ansible.module_utils.facts.utils', 'run_command': {
    'return_value': (0, 'Architecture: x86_64\n' \
                 'Codename: xenial\n' \
                 'Description: Ubuntu 16.04.1 LTS\n' \
                 'ID: ubuntu' \
                 'Release: 16.04\n' \
                 'Semantic Version: 16.04.20170821\n' \
                 'Version: 16.04\n', ''), 'side_effect': None}}
    module = Mock(**options)
    module.get_bin_path.return_value = True


# Generated at 2022-06-11 04:55:42.063482
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic


# Generated at 2022-06-11 04:55:43.228738
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == "lsb"

# Generated at 2022-06-11 04:55:49.739744
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils._text import to_bytes

    def get_bin_path(self, binary):
        if binary == 'lsb_release':
            return '/usr/bin/lsb_release'
        return None

    class AnsibleModule:
        def get_bin_path(self, binary):
            return get_bin_path(self, binary)


# Generated at 2022-06-11 04:55:55.226233
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # init
    m = MockModule()
    LF = LSBFactCollector()

    # prepare MockModule
    m.params = LF.setup()
    m.commands = {
        'lsb_release': '',
        'lsb_release -a': 'LSB Version:\t\tcore-9.20170808ubuntu1-noarch:security-9.20170808ubuntu1-noarch\nDistributor ID:\tUbuntu\nDescription:\tUbuntu 16.04.3 LTS\nRelease:\t16.04\nCodename:\txenial'
    }

    # prepare
    lsb_release_path = m.get_bin_path('lsb_release')
    etc_lsb_release_location = '/etc/lsb-release'

    # call

# Generated at 2022-06-11 04:55:56.287618
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    inst = LSBFactCollector()
    assert inst.name == 'lsb'

# Generated at 2022-06-11 04:58:49.436410
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lfc = LSBFactCollector()

    assert lfc.name == 'lsb'
    assert lfc._fact_ids == set()
    assert lfc.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:58:50.109464
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-11 04:58:51.011753
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    assert lsbfc is not None

# Generated at 2022-06-11 04:58:52.395598
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 04:58:58.424965
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    os.environ['PATH'] = ''
    module = AnsibleModuleStub()
    module.params = {'module_name': 'test'}

    etc_lsb_release_location = os.path.join(os.path.dirname(__file__), 'etc/lsb-release')

    def mock_run_command(args, errors='surrogate_then_replace'):
        if args[0] == 'lsb_release':
            return (0, None, None)
        elif args[1] == '-a':
            return (0, '''
Distributor ID: Ubuntu
Description:    Ubuntu 14.04.1 LTS
Release:        14.04
Codename:       trusty
''', None)

    module.run_command = mock_run_command
    LSBFactCollector().collect

# Generated at 2022-06-11 04:58:59.501794
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector

# Generated at 2022-06-11 04:59:00.979294
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    my_collector = LSBFactCollector()
    assert(my_collector.name == 'lsb')
    assert(my_collector._fact_ids is not None)

# Generated at 2022-06-11 04:59:07.306716
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_lsb_dict = {}
    test_lsb_dict['id'] = 'RedHatEnterpriseServer'
    test_lsb_dict['release'] = '7.3'
    test_lsb_dict['description'] = 'Red Hat Enterprise Linux Server'
    test_lsb_dict['codename'] = 'Maipo'
    test_lsb_dict['major_release'] = '7'
    test_lsb = LSBFactCollector()
    test_facts = {}
    module = True

    test_facts = test_lsb.collect(module=module, collected_facts=test_facts)
    _facts = test_facts['lsb']
    assert type(_facts) is dict
    assert type(test_lsb_dict) is dict
    assert _facts == test_lsb_dict

# Generated at 2022-06-11 04:59:08.532005
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()
    assert l.name == 'lsb'
    assert l.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:59:15.659574
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    from ansible.module_utils.facts.utils import ModuleStub
    from ansible.module_utils.facts.collector import get_collector_facts

    module = ModuleStub({
        'command': 'lsb_release -a',
        'rc': 0,
        'stdout': '''\
Distributor ID:   Ubuntu
Description:  Ubuntu 16.04.3 LTS
Release:  16.04
Codename: xenial
LSB Version:    1.4
'''
    })

    # Setting up module, and env variables that usually come
    # from ansible, we will not be able to resolve
    # ansible_local facts but that is not the point of this test.
    module.run_command_environ_update = dict()