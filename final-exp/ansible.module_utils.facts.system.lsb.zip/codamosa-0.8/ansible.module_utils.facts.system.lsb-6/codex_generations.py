

# Generated at 2022-06-11 04:49:26.060337
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()

    # test _fact_ids
    assert len(lsb_facts._fact_ids) > 0
    assert 'lsb' in lsb_facts._fact_ids

    # test name
    assert lsb_facts.name == 'lsb'

# Generated at 2022-06-11 04:49:29.002689
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:49:35.718520
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    module = None
    facts_dict = {}
    lsb_facts = {}
    lsb_path = "/usr/bin/lsb_release"

    c = LSBFactCollector()
    lsb_facts = c._lsb_release_bin(lsb_path, module)
    c.collect(module, facts_dict)
    expected_dict = { 'lsb': lsb_facts }
    assert facts_dict == expected_dict


# Generated at 2022-06-11 04:49:38.232180
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb = LSBFactCollector()

    #TODO: Unit test for lsb_release_bin
    #TODO: Unit test for lsb_release_file

# Generated at 2022-06-11 04:49:41.170742
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """Unit test cases: lsb fact collector collect"""
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module=None)

# Generated at 2022-06-11 04:49:51.537472
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    '''Test collect() method of LSBFactCollector'''

    # Get the class under test
    LSBFactCollector_class = LSBFactCollector()

    #
    # Unit test for collect() method
    # when lsb_release command is available
    #
    lsb_path = "/bin/lsb_release"
    lsb_facts = {'codename': '',
                'description': 'Red Hat Enterprise Linux Server release 7.1 (Maipo)',
                'id': 'RedHatEnterpriseServer',
                'major_release': '7',
                'release': '7.1'}
    module = MagicMock()
    module.run_command.return_value = (0, '', '') # no error
    module.get_bin_path.return_value = lsb_path
    module

# Generated at 2022-06-11 04:49:53.202104
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_obj=LSBFactCollector()
    assert lsb_obj.name == "lsb"

# Generated at 2022-06-11 04:50:01.046711
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # lsb exists
    result = LSBFactCollector.collect({'get_bin_path': lambda x: True})
    assert result
    assert result['lsb']
    assert result['lsb']['release']
    assert result['lsb']['major_release']
    assert result['lsb']['id']
    assert result['lsb']['description']
    assert result['lsb']['codename']
    # lsb doesn't exist
    result = LSBFactCollector.collect({'get_bin_path': lambda x: False})
    assert result
    assert not result['lsb']

# Generated at 2022-06-11 04:50:10.640404
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import os
    import sys

    # Test lsb_release
    output = '''
    Distributor ID:    Ubuntu
    Description:    Ubuntu 14.04.1 LTS
    Release:    14.04
    Codename:   trusty
    '''
    lsb_path = "/bin/lsb_release"

    if os.path.exists(lsb_path):
        class _module(object):
            def get_bin_path(self, _):
                return lsb_path

            def run_command(self, _, errors=None):
                return (0, output, '')

        collector = LSBFactCollector()
        res = collector._lsb_release_bin(lsb_path, _module())

        assert isinstance(res, dict)
        assert res['id'] == 'Ubuntu'


# Generated at 2022-06-11 04:50:16.012540
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Modify get_file_lines() to return a list of test lines
    BaseFactCollector.get_file_lines = lambda x: ['DISTRIB_ID=foo', 'DISTRIB_RELEASE=2.0', 'DISTRIB_CODENAME=bar', 'DISTRIB_DESCRIPTION="A test distro"']
    lsb_collector = LSBFactCollector()
    assert lsb_collector is not None

# Generated at 2022-06-11 04:50:28.956501
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-11 04:50:31.627372
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert repr(lsb._fact_ids) == "<set id='lsb'>"

# Generated at 2022-06-11 04:50:40.838840
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import types
    import pprint

    # Create a mock module and facts file
    module = types.ModuleType('ansible.module_utils.basic')

# Generated at 2022-06-11 04:50:42.906128
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-11 04:50:44.008965
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-11 04:50:45.907027
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb == LSBFactCollector._fact_ids
    assert lsb.name == 'lsb'

# Generated at 2022-06-11 04:50:54.937278
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = make_module()
    lsb_bin_path = module.get_bin_path('lsb_release')
    os.environ['LANG'] = 'C'
    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect(module=module)[0]
    assert lsb_facts is not None
    assert os.path.exists(lsb_bin_path)
    assert 'lsb' in lsb_facts
    assert 'id' in lsb_facts['lsb']
    assert 'release' in lsb_facts['lsb']
    assert 'codename' in lsb_facts['lsb']
    assert 'description' in lsb_facts['lsb']
    assert 'major_release' in lsb_facts['lsb']

# Generated at 2022-06-11 04:51:04.132026
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test lsb_release_bin test
    lsb_path = '/usr/bin/lsb_release'

    class Module:
        def get_bin_path(lsb_path):
            return lsb_path

        def run_command(cmd, errors):
            if cmd[0] == lsb_path and cmd[1] == "-a":
                return 0, '''
Distributor ID: Ubuntu
Description:    Ubuntu 14.04.3 LTS
Release:        14.04
Codename:       trusty
''', ''

    fc = LSBFactCollector()

# Generated at 2022-06-11 04:51:10.435200
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    lsb_facts_dict = LSBFactCollector.collect(module=module)

    output_dict = {'codename': 'xenial',
                   'description': 'Ubuntu 16.04.2 LTS',
                   'distributor_id': 'Ubuntu',
                   'id': 'Ubuntu',
                   'major_release': '16',
                   'release': '16.04'}
    assert lsb_facts_dict == output_dict


# Generated at 2022-06-11 04:51:17.200744
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    '''Unit test for method collect of class LSBFactCollector'''
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    module = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/ansible'
    lfb = LSBFactCollector
    lfb.lsb_release_bin = MagicMock(return_value = "")
    lfb.lsb_release_file = MagicMock(return_value = "")
    lfb.collect(module)

# Generated at 2022-06-11 04:51:37.508677
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MagicMock()
    module.get_bin_path.return_value = '/bin/lsb_release'
    lsb_facts = {}
    lsb_facts['release'] = '12.04'
    lsb_facts['id'] = 'Ubuntu'
    lsb_facts['description'] = 'Ubuntu 12.04.2 LTS'
    lsb_facts['codename'] = 'precise'
    lsb_facts['major_release'] = '12'

# Generated at 2022-06-11 04:51:44.181319
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'release: Red Hat Enterprise Linux Server release 5.6 (Tikanga) \
                                             codename: Tikanga description: Red Hat Enterprise Linux Server release 5.6 (Tikanga) \
                                             distributor-id: RedHatEnterpriseServer \
                                             release: 5.6', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/lsb_release')
    lsb_collector = LSBFactCollector()
    facts = lsb_collector.collect(module=module)
    assert 'lsb' in facts
    assert facts['lsb']['release'] == '5.6'
    assert facts['lsb']['major_release'] == '5'

# Generated at 2022-06-11 04:51:45.260879
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    os = LSBFactCollector()
    assert 'lsb' == os.name

# Generated at 2022-06-11 04:51:50.326213
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    for info in ('', '\n'):
        class module_mock:
            def get_bin_path(self, x):
                return '/bin/lsb_release'

            def run_command(self, cmd):
                return (0, info, '')
        lsb = LSBFactCollector()
        assert lsb.collect(module_mock()).get('lsb') == {}

    lsb = LSBFactCollector()
    assert lsb.collect(None).get('lsb') == {}

# Generated at 2022-06-11 04:51:58.184080
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Creating instance of class LSBFactCollector
    test_obj = LSBFactCollector()

    # Creating dummy class to mock module class of ansible
    class MockModule:
        def get_bin_path(self, filename):
            return '/dummy_path'
        def run_command(self, command, errors='surrogate_then_replace'):
            return 0, 'test_line1\ntest_line2', ''

    # Testing method collect using dummy class instance
    collected_fact = test_obj.collect(module=MockModule())
    assert collected_fact['lsb'] == {'description': 'test_line2',
                                     'release': 'test_line1'}
# end unit test for method collect of class LSBFactCollector

# Generated at 2022-06-11 04:51:59.001341
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-11 04:52:01.777584
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = None
    collected_facts = None
    lsb_facts = LSBFactCollector().collect(module, collected_facts)
    assert isinstance(lsb_facts, dict)
    assert lsb_facts == {'lsb': {}}

# Generated at 2022-06-11 04:52:11.968277
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    LSBFactCollector = LSBFactCollector()

    # Create a basic set of module input arguments and assume success.
    #   Check that the output matches the input.
    module_args = dict(
        ANSIBLE_MODULE_ARGS={},
        ansible_facts={},
    )

    module = AnsibleModule(
        argument_spec=module_args['ANSIBLE_MODULE_ARGS'],
        supports_check_mode=False,
    )

    os.environ["LSB_ETC_LSB_RELEASE_FILENAME"] = "test/data/lsb_etc_lsb_release_file"
    os.environ["LSB_LSB_RELEASE_BIN_FILENAME"] = "test/data/lsb_lsb_release_script"

    rc, out,

# Generated at 2022-06-11 04:52:13.270005
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test = LSBFactCollector()
    assert test.collect()

# Generated at 2022-06-11 04:52:15.325486
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb._fact_ids == set()

# Generated at 2022-06-11 04:52:45.341136
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils.facts.system.lsb import LSBFactCollector

    # On Windows, sys.executable points to python.exe and will not run the
    # lsb_release command
    if sys.platform.startswith('win'):
        return


# Generated at 2022-06-11 04:52:47.686922
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact_collector_class = LSBFactCollector()
    assert fact_collector_class
    assert fact_collector_class.name == 'lsb'

# Generated at 2022-06-11 04:52:50.704174
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fc = LSBFactCollector()
    assert 'lsb' == lsb_fc.name
    assert set() == lsb_fc._fact_ids
    assert r'\'\"\\' == LSBFactCollector.STRIP_QUOTES



# Generated at 2022-06-11 04:52:52.878936
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()
    assert collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:52:54.305363
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 04:53:03.169232
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # lsb_release_bin_output is the output of the lsb_release command
    lsb_release_bin_output = '''
    bash-3.2$ lsb_release -a
    LSB Version:    :core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch
    Distributor ID: AmazonAMI
    Description:    Amazon Linux AMI release 2012.03
    Release:    2012.03
    Codename:   n/a
    '''
    # lsb_release

# Generated at 2022-06-11 04:53:04.025504
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass


# Generated at 2022-06-11 04:53:06.444922
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_obj = LSBFactCollector()
    assert lsb_fact_collector_obj.name == 'lsb'

# Generated at 2022-06-11 04:53:09.730350
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    fact_collector = LSBFactCollector()
    facts = fact_collector.collect(module=module)

    assert facts['lsb'] == fact_collector._lsb_release_bin(None, module)


# Generated at 2022-06-11 04:53:13.914067
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """This is a test to ensure the constructor of class LSBFactCollector works correctly."""
    lsb_obj = LSBFactCollector()
    assert lsb_obj.name == 'lsb'
    assert lsb_obj._fact_ids == set()
    assert lsb_obj.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:54:23.634928
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()
    assert isinstance(l, LSBFactCollector)
    assert isinstance(l.name, str)
    assert isinstance(l._fact_ids, set)


# Generated at 2022-06-11 04:54:25.406048
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_facts = LSBFactCollector.collect(None)
    assert lsb_facts.get('lsb') is None

# Generated at 2022-06-11 04:54:28.772818
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:54:39.269967
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collectors import which
    from ansible.module_utils.facts.collectors.lsb import LSBFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    LSBFactCollector._lsb_path = None

    def run_command_mock(cmd_parts, errors='surrogate_then_replace'):
        return 0, '', ''

    def get_bin_path_mock(path):
        return '/bin/lsb_release'

    def which_mock(cmd):
        return cmd

    def get_file_lines_mock(path):
        return ['DISTRIB_ID=test']

    mock_module = MagicMock()
    mock_

# Generated at 2022-06-11 04:54:42.224429
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    assert lsbfc.name == 'lsb'
    assert lsbfc._fact_ids == set()
    assert lsbfc.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:54:46.400832
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'
    assert str(lsb_fact_collector) == '<LSBFactCollector>'


# Generated at 2022-06-11 04:54:49.185578
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    #Check instance attributes were initialized correctly
    assert lsb.name == "lsb"
    assert lsb._fact_ids == set()
    assert lsb.STRIP_QUOTES == '\'\"\\'


# Generated at 2022-06-11 04:54:50.834345
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    e = LSBFactCollector()
    assert e.name == 'lsb'
    assert e.default_file_system == 'Linux'

# Generated at 2022-06-11 04:54:58.057911
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """Generates a fact dict containing LSB facts"""
    lsb_facts = dict(
        id='RedHatEnterpriseServer',
        release='7.3',
        description='Red Hat Enterprise Linux Server release 7.3 (Maipo)',
        major_release='7',
        codename='Maipo'
    )

    module = FakeModule()
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.get_file_lines = FakeFileLines
    lsb = LSBFactCollector()
    assert lsb.collect(module)['lsb'] == lsb_facts



# Generated at 2022-06-11 04:54:59.658310
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact_collector = LSBFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-11 04:57:53.836722
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector_returned_dict = {'lsb': {'major_release': '7', 'release': '7.3.1611', 'id': 'CentOS', 'codename': 'Core', 'description': 'CentOS Linux release 7.3.1611 (Core)'}}
    lsb_fact_collector_returned_dict_collect_method_returned = lsb_fact_collector.collect(module=None)
    assert lsb_fact_collector_returned_dict_collect_method_returned == lsb_fact_collector_returned_dict

# Generated at 2022-06-11 04:58:00.031419
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """ Unit test for method collect of class LSBFactCollector """

    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collectors.system import LSBFactCollector

    ansible_collector = AnsibleCollector()

    ansible_collector.include_collector(LSBFactCollector())
    facts = ansible_collector.collect(module=None, collected_facts=None)
    assert 'lsb' in facts
    assert 'release' in facts['lsb']
    assert 'major_release' in facts['lsb']
    assert 'id' in facts['lsb']
    assert 'description' in facts['lsb']
    assert 'codename' in facts['lsb']

# Generated at 2022-06-11 04:58:01.936799
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == "lsb"
    assert lsb.STRIP_QUOTES == "'\"\\"

# Generated at 2022-06-11 04:58:09.456619
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    Test the LSBFactCollector.collect() function adds proper facts to the
    fact_dict.
    """
    import ansible.module_utils.facts.collectors.lsb as lsb
    import ansible.module_utils.facts.collectors.base as base
    import ansible.module_utils.facts.utils as util
    import ansible.module_utils.basic as module

    class TestModule():
        bin_path = '/bin/lsb_release'

        def get_bin_path(self, exec_name):
            return self.bin_path

        def run_command(self, args, errors='strict'):
            # The variables below are used to provide a return code and output for
            # the command run by run_command

            # return code indicating if the command ran successfully
            rc = 0

           

# Generated at 2022-06-11 04:58:12.769466
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # create object
    lsb_facts = LSBFactCollector()

    # test attributes
    assert lsb_facts.name == 'lsb'
    assert lsb_facts._fact_ids == set()
    assert lsb_facts.STRIP_QUOTES == r'\'\"\\'

    return lsb_facts


# Generated at 2022-06-11 04:58:19.921826
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_text

    test_dir = os.path.dirname(__file__)
    data_dir = os.path.join(test_dir, 'data')

    def fake_run_command(args, errors='surrogate_then_replace'):
        rc = 0
        out = ''
        err = ''

# Generated at 2022-06-11 04:58:26.977460
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.system.lsb import LSBFactCollector
    from ansible.module_utils._text import to_bytes

    lsb_facts = {}
    lsb_facts = LSBFactCollector().collect()
    with open('/tmp/etc/lsb-release', 'w+') as lsb:
        lsb.write('DISTRIB_ID=CentOS\n')
        lsb.write('DISTRIB_RELEASE=7.5\n')
        lsb.write('DISTRIB_CODENAME=Core\n')
        lsb.write('DISTRIB_DESCRIPTION="CentOS Linux 7 (Core)"\n')

    module_mock = None

# Generated at 2022-06-11 04:58:27.619398
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()

# Generated at 2022-06-11 04:58:32.648009
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create empty dicts
    lsb_facts = {}
    lsb_facts_2 = {}
    facts_dict = {}
    # Create expected lsb_facts
    lsb_facts = {
        'major_release': '16',
        'id': 'Ubuntu',
        'description': 'Ubuntu 16.04.2 LTS',
        'codename': 'xenial',
        'release': '16.04'
    }
    # Create expected lsb_facts_2
    lsb_facts_2 = {
        'id': 'Ubuntu',
        'codename': 'xenial',
        'release': '16.04'
    }
    # Create expected facts_dict
    facts_dict = {
        'lsb': lsb_facts
    }
    # Test on lsb_facts


# Generated at 2022-06-11 04:58:36.489249
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    _fact_ids = lsb_fact_collector._fact_ids
    assert len(_fact_ids) == 1
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'