

# Generated at 2022-06-11 04:49:25.038952
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test with empty argument
    assert dict(LSBFactCollector().collect()) == dict()


# Generated at 2022-06-11 04:49:30.190336
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_path = '/usr/bin/lsb_release'
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock(return_value=lsb_path)
    module.run_command = MagicMock(return_value=(0, '', ''))
    collector = LSBFactCollector(module=module)

    assert collector is not None


# Generated at 2022-06-11 04:49:40.318952
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test 1: test constructor of class LSBFactCollector
    obj = LSBFactCollector()

    # Test if obj is instance of class BaseFactCollector
    assert isinstance(obj, BaseFactCollector)

    # Test __str__ of class LSBFactCollector
    assert obj.__str__() == '[' + obj.name + ']'

    # Test __repr__ of class LSBFactCollector
    assert obj.__repr__() == obj.__str__()

    # Test _fact_ids of class LSBFactCollector
    assert obj._fact_ids == set()

    # Test STRIP_QUOTES

# Generated at 2022-06-11 04:49:45.181592
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_obj = LSBFactCollector()
    assert lsb_fact_collector_obj.name == 'lsb'
    assert lsb_fact_collector_obj._fact_ids == set()
    assert lsb_fact_collector_obj.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:49:47.373477
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lc = LSBFactCollector()
    assert lc.name == 'lsb'
    assert lc._fact_ids == set()

# Generated at 2022-06-11 04:49:50.371887
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert x.name == 'lsb'
    assert x._fact_ids == set()
    assert x.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:50:00.417161
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    ansible_module_instance = AnsibleModule()
    ansible_module_instance.get_bin_path = lambda x: "/bin/lsb_release"
    ansible_module_instance.run_command = lambda x: (0, "LSB Version:  :core-4.1-amd64:core-4.1-noarch", "")
    ansible_module_instance.run_command.return_value = (0, "DISTRIB_ID=CentOS", "")
    lsb_fact_collector = LSBFactCollector()
    result = lsb_fact_collector.collect(module=ansible_module_instance)
    assert result['lsb']['description'] == ":core-4.1-amd64:core-4.1-noarch"

# Generated at 2022-06-11 04:50:03.486767
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()
    assert collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:50:06.167139
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:50:09.579538
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector().name == "lsb"
    assert LSBFactCollector()._fact_ids == set()
    assert LSBFactCollector().STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:50:16.382375
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-11 04:50:26.020283
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    one_lsb_script = '''#!/bin/sh
    . /etc/lsb-release
    DISTRIB_ID="$DISTRIB_ID"
    DISTRIB_RELEASE="$DISTRIB_RELEASE"
    DISTRIB_DESCRIPTION="$DISTRIB_DESCRIPTION"
    DISTRIB_CODENAME="$DISTRIB_CODENAME"
    lsb_release -a
    '''

    lsb_script_path = "/tmp/ansible-test-lsb-release"
    with open(lsb_script_path, "w") as lsb_file:
        lsb_file.write(one_lsb_script)


# Generated at 2022-06-11 04:50:36.110964
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """Unit test for method collect of class LSBFactCollector."""
    # Mock module class
    class MockModule(object):
        def get_bin_path(self, path):
            return '/bin/lsb_release'

        def run_command(self, params, errors):
            class MockRC:
                returncode = 0
            rc = MockRC()
            out = '''
            Distributor ID: Ubuntu
            Description:    Ubuntu xenial (development branch)
            Release:        16.04
            Codename:       xenial
            '''
            err = ''
            return rc, out, err

    # Run collect method
    lsb_collector = LSBFactCollector()
    result = lsb_collector.collect(MockModule())

    # Check result

# Generated at 2022-06-11 04:50:38.375395
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    fact = LSBFactCollector()
    assert fact.name == 'lsb'
    assert fact._fact_ids is not None

# Generated at 2022-06-11 04:50:48.364491
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module_mock = {}
    collected_facts_mock = {}
    module_mock['get_bin_path'] = lambda _: '/usr/bin/lsb_release'
    module_mock['run_command'] = lambda _, errors: (0, 'LSB Version:	:core-4.1-amd64:core-4.1-noarch\nDistributor ID: RedHatEnterpriseServer\nDescription:	Red Hat Enterprise Linux Server\nRelease:	7.4\nCodename:	Maipo', '')
    #/usr/bin/lsb_release -a
    collector = LSBFactCollector('lsb')
    result = collector.collect(module_mock, collected_facts_mock)
    assert 'lsb' in result
    assert 'release' in result['lsb']


# Generated at 2022-06-11 04:50:49.697762
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name=='lsb'

# Generated at 2022-06-11 04:50:51.338962
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l = LSBFactCollector()
    assert l.name == 'lsb'

# Generated at 2022-06-11 04:50:54.314645
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:50:59.021067
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """ test_LSBFactCollector: Test constructor of LSBFactCollector """

    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:51:02.083826
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb._fact_ids == set()
    assert lsb.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-11 04:51:18.347212
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, path):
            return '/usr/bin/lsb_release'

        def run_command(self, cmd, errors='surrogate_then_replace'):
            return (0, '''Description:    Ubuntu 16.04.3 LTS
Release:        16.04
Codename:       xenial
LSB Version:    core-9.20160110ubuntu0.2-amd64:core-9.20160110ubuntu0.2-noarch:security-9.20160110ubuntu0.2-amd64:security-9.20160110ubuntu0.2-noarch''', None)

    lsb_fact_collector = LSBFactCollect

# Generated at 2022-06-11 04:51:27.928253
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_module_mock = {}
    test_module_mock['get_bin_path'] = lambda x : "bin/lsb_release"
    test_module_mock['run_command'] = lambda x, errors : (0, "LSB Version:  n/a\nDistributor ID: Debian\nDescription:    Debian GNU/Linux 7.0 (wheezy)\nRelease:        7.0\nCodename:       wheezy\n", "")
    result = LSBFactCollector().collect(test_module_mock, {})
    assert result == {'lsb': {'release': '7.0', 'id': 'Debian', 'description': 'Debian GNU/Linux 7.0 (wheezy)', 'codename': 'wheezy', 'major_release': '7'}}

# Generated at 2022-06-11 04:51:29.152991
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.name == 'lsb'

# Generated at 2022-06-11 04:51:30.072598
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'

# Generated at 2022-06-11 04:51:31.436921
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact = LSBFactCollector()
    assert lsb_fact.collect() == {}

# Generated at 2022-06-11 04:51:39.627180
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFact
    from ansible.module_utils.facts import cache
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    def mock_module_run_command(self, *args, **kwargs):
        """Mock AnsibleModule.run_command() method"""
        if args[0] == [lsb_path, "-a"]:
            if PY3:
                return 0, '''
Distributor ID: Ubuntu
Description:    Ubuntu 16.04.1 LTS
Release:    16.04
Codename:   xenial
'''.encode('utf-8'), ''

# Generated at 2022-06-11 04:51:42.172362
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """Tests the LSBFactCollector constructor"""
    lsb_factcollector = LSBFactCollector()
    assert lsb_factcollector


# Generated at 2022-06-11 04:51:44.374768
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    if not isinstance(LSBFactCollector.collect(), dict):
        raise Exception
    assert LSBFactCollector.collect() == {}

# Generated at 2022-06-11 04:51:46.099298
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert isinstance(lsb_collector, LSBFactCollector)


# Generated at 2022-06-11 04:51:46.628424
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-11 04:52:00.350349
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModuleMock()
    my_obj = LSBFactCollector()

    # lsb_path is not found
    module.run_command.return_value = (1, '', '')
    module.get_bin_path.return_value = '/path/to/lsb_release'
    my_obj.collect(module=module)
    module.run_command.assert_has_calls([call(['/path/to/lsb_release', '-a'])])
    assert module.run_command.call_count == 1

    # lsb_path is found but return code is not zero
    module.run_command.return_value = (0, '', '')
    my_obj.collect(module=module)
    assert module.run_command.call_count == 2

    # lsb

# Generated at 2022-06-11 04:52:04.044655
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.name == 'lsb'
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:52:06.807004
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # create a class instance
    obj = LSBFactCollector()

    # check the name and the fact_ids
    assert obj.name == 'lsb'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:52:08.734123
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Init facts collector
    #
    lsb = LSBFactCollector()
    # Run collect method
    #
    lsb.collect()

# Generated at 2022-06-11 04:52:12.928001
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector
    assert lsb_fact_collector.name == 'lsb'
    assert not lsb_fact_collector._fact_ids

# Generated at 2022-06-11 04:52:14.969140
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert isinstance(lsb_facts, LSBFactCollector)


# Generated at 2022-06-11 04:52:19.944982
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collected_facts = {}
    collected_facts['ansible_lsb'] = {'id': 'centos', 'major_release': '7', 'release': '7.3.1611', 'description': 'CentOS Linux release 7.3.1611 (Core)', 'codename': 'Core'}
    lsb_facts = LSBFactCollector().collect(None, collected_facts)
    assert 'lsb' in lsb_facts

# Generated at 2022-06-11 04:52:29.089663
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # This part is used for unit test
    # we simulate that module is initialized and ready to be called
    # lsb_release is in the path
    #
    # In case of failure, an exception will be raised
    # In case of success, the facts will be returned
    # and the facts will be checked

    module = MockModule()

    # Define some os.path result
    LSB_BIN = '/usr/bin/lsb_release'
    LSB_FILE = '/etc/lsb-release'

    os.path.exists.side_effect = [True, True]
    module.get_bin_path.return_value = LSB_BIN

    # we define the expected result

# Generated at 2022-06-11 04:52:40.085590
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    """
    Unit test for collect function from LSB Fact Collector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.base import BaseFactModule

    LSBFactCollector._fact_ids = set()

    test_data = {
        'lsb': {
            'codename': 'Krypton',
            'description': 'This is an awesome test',
            'id': 'TheID',
            'major_release': '10',
            'release': '10.1',
        },
    }

    lsb_release_path = '/etc/lsb-release'

# Generated at 2022-06-11 04:52:49.024808
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None
    assert lsb_fact_collector.name == 'lsb'
    assert 'lsb.major_release' in lsb_fact_collector.get_fact_ids()
    assert 'lsb.release' in lsb_fact_collector.get_fact_ids()
    assert 'lsb.id' in lsb_fact_collector.get_fact_ids()
    assert 'lsb.description' in lsb_fact_collector.get_fact_ids()
    assert 'lsb.codename' in lsb_fact_collector.get_fact_ids()

# Generated at 2022-06-11 04:53:04.389263
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    module.lsb_release = True
    lsb_facts = LSBFactCollector().collect(module)
    assert(lsb_facts)

# Generated at 2022-06-11 04:53:07.850369
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert lsb_collector._fact_ids == set()
    assert lsb_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:53:10.796178
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect(module)
    assert module.run_command.call_count == 1


# Generated at 2022-06-11 04:53:13.552016
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-11 04:53:21.361375
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    from ansible.module_utils.common.process import get_bin_path

    lsb_path = get_bin_path('lsb_release', ['/bin', '/usr/bin'])
    lsb_path = lsb_path if lsb_path else 'lsb_release'   # Ugly but works

    expected_result = {'description': 'Ubuntu 12.04.5 LTS', 'id': 'Ubuntu', 'codename': 'precise', 'major_release': '12',
                       'release': '12.04'}

    # Create a module_wrapper object
    class ModuleWrapperClass(object):
        module_name = None
        args = None
        kwargs = None
        _result = None
        _ansible_vsn = None

        def __init__(self):
            pass


# Generated at 2022-06-11 04:53:22.157298
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    instance = LSBFactCollector()
    assert instance

# Generated at 2022-06-11 04:53:25.766406
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    linux_info = LSBFactCollector()
    assert linux_info.name == 'lsb'
    assert linux_info._fact_ids == set()

    # Test the collect method
    lsb_facts = linux_info.collect()
    assert lsb_facts == {}


# Generated at 2022-06-11 04:53:26.975459
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb is not None

# Generated at 2022-06-11 04:53:29.495358
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-11 04:53:31.351543
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert hasattr(LSBFactCollector, 'collect')
    assert callable(LSBFactCollector.collect)

# Generated at 2022-06-11 04:54:12.041439
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # data to be used as return value of mocked subprocess.Popen.communicate() call
    lsb_release_stderr = "lsb_release: command not found\n"
    lsb_release_output = """
        Distributor ID: Ubuntu
        Description:    Ubuntu 14.04.5 LTS
        Release:        14.04
        Codename:       trusty
    """


# Generated at 2022-06-11 04:54:14.010204
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fc = LSBFactCollector()
    assert lsb_fc.name == 'lsb'
    assert lsb_fc._fact_ids == set()

# Generated at 2022-06-11 04:54:19.533172
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleStub
    from ansible.module_utils.facts.collector import CollectedFacts

    module = ModuleStub()
    module.run_command = lambda *args, **kwargs: (1, '', '')
    module.get_bin_path.return_value = None

    fact_collector = LSBFactCollector()

    lsb_facts = fact_collector.collect(module=module)
    assert {} == lsb_facts['lsb']


# Generated at 2022-06-11 04:54:24.528130
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = MockModule()
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector._lsb_release_bin = Mock(return_value={'release' : '20.04'})
    lsb_fact_collector._lsb_release_file = Mock(return_value={})
    result = lsb_fact_collector.collect(module)
    assert result == {'lsb': {'major_release': '20', 'release': '20.04'}}

# Generated at 2022-06-11 04:54:26.010739
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert not(LSBFactCollector()._fact_ids)
    assert LSBFactCollector.name == 'lsb'

# Generated at 2022-06-11 04:54:28.018933
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'
    assert lsb.collect() != {}
    assert lsb.collect()['lsb'] != {}

# Generated at 2022-06-11 04:54:38.532922
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.bin_path_value = None
            self.run_command_return_value = None

        def get_bin_path(self, name):
            return self.bin_path_value

        def run_command(self, args, *args2, **kwargs):
            return self.run_command_return_value

    module = MockModule()
    lsbfc = LSBFactCollector()

    # No lsb_release command, no /etc/lsb-release, empty lsb facts, does not blow up
    module.bin_path_value = None
    module.run_command_return_value = (0, '', '')
    lsb_facts = lsbfc.collect(module)
    assert lsb_facts == {}

    # No

# Generated at 2022-06-11 04:54:42.225344
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'
    assert len(lsb_collector._fact_ids) == 0
    assert lsb_collector.STRIP_QUOTES == '\'\"\\'


# Generated at 2022-06-11 04:54:44.217407
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_facts = LSBFactCollector()
    assert lsb_facts.name == 'lsb'
    assert lsb_facts._fact_ids == set()

# Generated at 2022-06-11 04:54:45.420767
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb = LSBFactCollector()
    assert lsb.name == 'lsb'

# Generated at 2022-06-11 04:56:15.246023
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Arrange
    # Mock module object
    module = MagicMock()
    module.run_command.return_value = (0, '''
    Distributor ID: Ubuntu
    Description:    Ubuntu 18.04.3 LTS
    Release:        18.04
    Codename:       bionic
    ''', '')
    module.get_bin_path.return_value = '/usr/bin/lsb_release'

    # Mock class, instance and collect
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector_instance = lsb_fact_collector.collect(module)

    # Assert
    assert lsb_fact_collector_instance['lsb']['id'] == 'Ubuntu'

# Generated at 2022-06-11 04:56:17.643663
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    tmp_fact_collector = LSBFactCollector()
    assert tmp_fact_collector.collect() == {'lsb': {}}


# Generated at 2022-06-11 04:56:18.928418
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsbfc = LSBFactCollector()
    assert lsbfc.name == 'lsb'


# Generated at 2022-06-11 04:56:21.056256
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()
    assert collector.collect() is not None
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 04:56:24.003243
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    import ansible.module_utils.facts.collector
    lsb_fact_collector = LSBFactCollector()
    assert isinstance(lsb_fact_collector, ansible.module_utils.facts.collector.BaseFactCollector)


# Generated at 2022-06-11 04:56:31.396237
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.ansible_release import __version__

    # Without lsb_release
    module = MockAnsibleModule(ansible_version=__version__)
    module.run_command = Mock(return_value=(1, None, None))
    facts = FactsCollector(module).collect()
    module.fail_json.assert_not_called()
    assert 'lsb' not in facts
    assert 'distribution' not in facts
    assert 'distribution_version' not in facts
    assert 'distribution_release' not in facts
    assert 'distribution_major_version' not in facts

    # With lsb_release

# Generated at 2022-06-11 04:56:32.871162
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.name == 'lsb'

# Generated at 2022-06-11 04:56:34.310489
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact = LSBFactCollector()
    assert type(lsb_fact) == LSBFactCollector

# Generated at 2022-06-11 04:56:40.517372
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    class Module:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
            self.bin_path = '/bin/'

        def run_command(self, args, errors='surrogate_then_replace'):
            return self.rc, self.out, self.err

        def get_bin_path(self, path):
            return os.path.join(self.bin_path, path)

    with open('/etc/lsb-release', 'w') as lsb:
        lsb.write('DISTRIB_ID=TestID\nDISTRIB_RELEASE=TestRelease\nDISTRIB_DESCRIPTION=TestDescription\nDISTRIB_CODENAME=TestCodeName\n')


# Generated at 2022-06-11 04:56:46.487500
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    from ansible.module_utils.facts.collector import AnsibleCollector

    # LSB data with lsb_release script
    lsb_path = '/bin/lsb_release'
    lsb_out = b"""LSB Version:    :core-4.1-amd64:core-4.1-noarch
Distributor ID: CentOS
Description:    CentOS Linux release 8.1.1911 (Core) 
Release:        8.1.1911
Codename:       Core
"""
    lsb_facts = {'release': 'core-4.1-amd64:core-4.1-noarch',
                 'id': 'CentOS',
                 'description': 'CentOS Linux release 8.1.1911 (Core)',
                 'codename': 'Core'}

    # LSB data without lsb_release