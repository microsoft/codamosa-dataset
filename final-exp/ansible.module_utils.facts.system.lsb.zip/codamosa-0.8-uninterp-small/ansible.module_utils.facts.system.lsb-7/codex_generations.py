

# Generated at 2022-06-25 00:13:17.847119
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 00:13:20.487986
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:22.714492
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:24.274440
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert hasattr(LSBFactCollector(), 'collect')

# Generated at 2022-06-25 00:13:26.016435
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:30.085932
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:13:40.081669
# Unit test for method collect of class LSBFactCollector

# Generated at 2022-06-25 00:13:43.979854
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
	assert LSBFactCollector.name == 'lsb'


# Generated at 2022-06-25 00:13:45.402166
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:49.508674
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()



# Generated at 2022-06-25 00:13:57.315186
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:14:03.073070
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert type(l_s_b_fact_collector_1) == LSBFactCollector


# Generated at 2022-06-25 00:14:05.025984
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    _lsb_path = '/usr/bin/lsb_release'
    _lsb_bin = LSBFactCollector._lsb_release_bin(_lsb_path)

# Generated at 2022-06-25 00:14:10.328910
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-25 00:14:16.447289
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    var_0 = l_s_b_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:14:24.716444
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {lsb_fact_collector_0: lsb_fact_collector_0}
    var_0 = l_s_b_fact_collector_0.collect(dict_0)
    module_0 = AnsibleModule(argument_spec={})
    var_0 = l_s_b_fact_collector_0.collect(module=module_0)
    module_0 = AnsibleModule(argument_spec={})
    var_0 = l_s_b_fact_collector_0.collect(module=module_0)

# Generated at 2022-06-25 00:14:28.776877
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.priority == 75
    assert l_s_b_fact_collector_0.mandatory is False


# Generated at 2022-06-25 00:14:32.333945
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_1: l_s_b_fact_collector_1}
    var_0 = l_s_b_fact_collector_1.collect(dict_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:14:34.962222
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:14:38.699167
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    assert True == l_s_b_fact_collector_0.collect(dict_0)

# Generated at 2022-06-25 00:14:55.905462
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:14:56.462491
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-25 00:15:00.528535
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    try:
        # Test case with no module argument
        l_s_b_fact_collector_0 = LSBFactCollector()
        var_0 = l_s_b_fact_collector_0.collect()
        assert var_0 == {}
    except Exception:
        assert False, "Failed to pass test"


# Generated at 2022-06-25 00:15:04.156192
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    var_0 = l_s_b_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:15:06.427607
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:15:08.633727
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:15:10.761761
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() == {'lsb': {}}


# Generated at 2022-06-25 00:15:17.512821
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    var_0 = l_s_b_fact_collector_0.collect(dict_0)


# Generated at 2022-06-25 00:15:21.412264
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()

    dict_0 = {lsb_fact_collector_0: lsb_fact_collector_0}
    var_0 = lsb_fact_collector_0.collect(dict_0)


if __name__ == "__main__":
    # Need to test the functions not in class
    test_case_0()

    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:15:26.699776
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == {'lsb'}


# Generated at 2022-06-25 00:15:56.707192
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert l_s_b_fact_collector_0 is not l_s_b_fact_collector_1


# Generated at 2022-06-25 00:15:59.451525
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:16:07.861620
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    os.environ['PATH'] = '/bin:/usr/bin'
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    var_0 = l_s_b_fact_collector_0.collect(dict_0)
    assert var_0 == {'lsb': {'codename': 'bionic', 'id': 'Ubuntu', 'major_release': '18', 'release': '18.04', 'description': 'Ubuntu 18.04.2 LTS'}}


# Generated at 2022-06-25 00:16:08.804035
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-25 00:16:14.382057
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    BASE_PATH = os.path.dirname(__file__)
    FILE = os.path.join(BASE_PATH, 'fixtures/lsb_facts.out')
    with open(FILE, 'r') as f:
        for line in f:
            print(line)

if __name__ == "__main__":
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:16:18.123400
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    if not isinstance(LSBFactCollector, type):
        raise Exception("Missing type information")


# Generated at 2022-06-25 00:16:23.722338
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    with mock.patch.object(LSBFactCollector, "collect") as collect_mock:
        with mock.patch.object(LSBFactCollector, "_lsb_release_file") as lsb_release_file_mock:
            lsb_fact_collector_1 = LSBFactCollector()
            lsb_fact_collector_1.name = "lsb"
            lsb_fact_collector_1._fact_ids = "set()"
            lsb_fact_collector_1.STRIP_QUOTES = "r'\'\"\\'"
            collected_facts_1 = {lsb_fact_collector_1: lsb_fact_collector_1}
            lsb_fact_collector_1.collect(collected_facts=collected_facts_1)
            collect_m

# Generated at 2022-06-25 00:16:24.899913
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

# Generated at 2022-06-25 00:16:25.780094
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-25 00:16:27.205275
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:17:32.503543
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector


# Generated at 2022-06-25 00:17:33.831043
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    for var_0 in range(0, 0):
        try:
            test_case_0()
        except:
            assert False


# Generated at 2022-06-25 00:17:38.547314
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    #assert False  # TODO: implement your test here


# Generated at 2022-06-25 00:17:41.570158
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    setup()
    test_case_0()
    teardown()
    pass



# Generated at 2022-06-25 00:17:43.655467
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect()

# Generated at 2022-06-25 00:17:45.111269
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert test_case_0()

# Generated at 2022-06-25 00:17:50.175947
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'
    assert l_s_b_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:17:53.605723
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert 'lsb' == l_s_b_fact_collector.name
    assert not l_s_b_fact_collector._fact_ids

# Generated at 2022-06-25 00:17:54.795793
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert isinstance(LSBFactCollector(), BaseFactCollector)

# Generated at 2022-06-25 00:17:58.081739
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'
    test_case_0()


# Generated at 2022-06-25 00:20:33.644734
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    str_0 = str(l_s_b_fact_collector_1)
    str_1 = str(LSBFactCollector.STRIP_QUOTES)
    str_2 = str(LSBFactCollector._fact_ids)
    str_3 = str(LSBFactCollector.__dict__)

test_case_0()
test_LSBFactCollector()

# Generated at 2022-06-25 00:20:34.786359
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:20:37.630827
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector().name == 'lsb'
    assert LSBFactCollector()._fact_ids == set()
    assert LSBFactCollector().STRIP_QUOTES == "'\"\\"


# Generated at 2022-06-25 00:20:47.245549
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # test case 0
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}
    var_0 = l_s_b_fact_collector_0.collect(dict_0)
    if (not (var_0)):
        print("%s" % str(var_0))
    var_1 = l_s_b_fact_collector_0.collect(dict_0)
    if (not (var_1)):
        print("%s" % str(var_1))

# Generated at 2022-06-25 00:20:49.058134
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    dict_0 = dict()
    dict_0[dict().itervalues()] = dict()
    var_0 = LSBFactCollector.collect(dict_0)


# Generated at 2022-06-25 00:20:58.519506
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    dict_0 = {l_s_b_fact_collector_0: l_s_b_fact_collector_0}

    # Call method
    result = l_s_b_fact_collector_0.collect(dict_0)
    assert result['lsb']['id'] == 'Ubuntu', "Test failed for value of variable result['lsb']['id']"
    assert result['lsb']['codename'] == 'xenial', "Test failed for value of variable result['lsb']['codename']"
    assert result['lsb']['major_release'] == '16', "Test failed for value of variable result['lsb']['major_release']"


# Generated at 2022-06-25 00:21:00.103330
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("")
    print("Testing constructor of class LSBFactCollector:")
    test_case_0()
    print("done.")


# Generated at 2022-06-25 00:21:00.566272
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:21:05.239573
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    class_obj_0 = l_s_b_fact_collector_1.collect({l_s_b_fact_collector_1: l_s_b_fact_collector_1})

# Generated at 2022-06-25 00:21:09.928084
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == "lsb"
    assert l_s_b_fact_collector_0.STRIP_QUOTES == '\'\"\\'
    assert (l_s_b_fact_collector_0._fact_ids == set())
    assert l_s_b_fact_collector_0.collect() == {}
