

# Generated at 2022-06-25 00:13:21.638913
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    assert isinstance(lsb_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:13:26.662652
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:13:29.309055
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.collect() == {}

# Generated at 2022-06-25 00:13:37.957419
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()

    module_0 = MockModule()
    collected_facts_0 = { }

    result_0 = l_s_b_fact_collector_0.collect(module_0, collected_facts_0)
    result_1 = l_s_b_fact_collector_0.collect(module_0, collected_facts_0)
    assert result_0 == result_1
    assert result_0 == { }
    assert result_1 == { }


# Generated at 2022-06-25 00:13:42.703425
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

if __name__ == '__main__':
    # initialize logging
    initlog()
    log = logging.getLogger()
    log.setLevel(logging.ERROR)

    # call test
    test_LSBFactCollector()

# Generated at 2022-06-25 00:13:47.455219
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    result = l_s_b_fact_collector_0.collect()
    assert result == {"lsb": {"codename": "na", "description": "na", "id": "na", "release": "na"}}
    result = l_s_b_fact_collector_0.collect()
    assert result == {"lsb": {"codename": "na", "description": "na", "id": "na", "release": "na"}}


# Generated at 2022-06-25 00:13:51.783455
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()



# Generated at 2022-06-25 00:13:56.546732
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()
    test_case_1()

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:14:02.649630
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
   l_s_b_fact_collector_1 = LSBFactCollector()

   assert l_s_b_fact_collector_1.collect() == {}


# Generated at 2022-06-25 00:14:10.673433
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    #
    # get_bin_path method not mocked
    #
    # get_file_lines method not mocked
    #
    # _lsb_release_bin method not mocked, no return value
    #
    # _lsb_release_file method not mocked, no return value
    #
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect(module='Not None')


# Generated at 2022-06-25 00:14:19.375294
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_0, LSBFactCollector)


# Generated at 2022-06-25 00:14:20.429193
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:14:20.912319
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-25 00:14:23.535622
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    r = l_s_b_fact_collector_0.collect()
    assert r == {}


# Generated at 2022-06-25 00:14:24.334196
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass


# Generated at 2022-06-25 00:14:25.394826
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    [l_s_b_fact_collector_0]


# Generated at 2022-06-25 00:14:28.263664
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == "lsb", "expected 'lsb', got {}".format(l_s_b_fact_collector_0.name)


# Generated at 2022-06-25 00:14:31.332645
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    module0 = object()
    collected_facts = object()

    # Call method
    result = lsb_fact_collector_0.collect(module=module0,
                                          collected_facts=collected_facts)

    assert result['lsb']
    assert len(result['lsb']) > 0

# Generated at 2022-06-25 00:14:35.519030
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name in LSBFactCollector.__dict__


# Generated at 2022-06-25 00:14:37.673772
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    print(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:14:48.088635
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_0.collect()



# Generated at 2022-06-25 00:14:50.095584
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()

    # Constructor test case
    assert l_s_b_fact_collector



# Generated at 2022-06-25 00:14:54.305144
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  var_0 = LSBFactCollector()
  var_1 = LSBFactCollector()
  var_0.collect()
  var_1.collect(var_1)

# Generated at 2022-06-25 00:15:03.215728
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    result_1 = lsb_fact_collector.collect()

    assert(result_1['lsb']['codename'] == "trusty")
    assert(result_1['lsb']['description'] == "Ubuntu 14.04.5 LTS")
    assert(result_1['lsb']['id'] == "Ubuntu")
    assert(result_1['lsb']['major_release'] == "14")
    assert(result_1['lsb']['release'] == "14.04")

# For testing only
if __name__ == "__main__":
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:15:10.489126
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_3 = LSBFactCollector()
    # Testing the name of the class
    var_4 = LSBFactCollector.name
    assert var_4 == 'lsb'
    # Testing the attribute _fact_ids of the class
    var_5 = LSBFactCollector._fact_ids
    assert var_5 == set()
    # Testing the attribute STRIP_QUOTES of the class
    var_6 = LSBFactCollector.STRIP_QUOTES
    assert var_6 == r'\'\"\\'
    # Testing the return of the method collect
    var_10 = LSBFactCollector.collect()
    # Testing the return of the method collect
    var_12 = LSBFactCollector.collect(LSBFactCollector)


# Generated at 2022-06-25 00:15:16.922778
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    if var_0 == {'lsb': {}}:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:15:18.287123
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  assert LSBFactCollector is not None


# Generated at 2022-06-25 00:15:23.188959
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:15:24.779889
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect()


# Generated at 2022-06-25 00:15:30.475800
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    collector = LSBFactCollector()

    # Verify that the class attributes exist
    assert hasattr(collector, 'name')
    assert hasattr(collector, '_fact_ids')
    assert hasattr(collector, 'STRIP_QUOTES')

    # Verify that the class attributes are set correctly
    assert collector.name == 'lsb'
    assert collector._fact_ids == set()
    assert collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-25 00:15:49.670755
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:15:52.466518
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    st_0 = LSBFactCollector()
    st_0.collect(st_0)


# Generated at 2022-06-25 00:15:57.728452
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'
    assert l_s_b_fact_collector_0.__class__.__name__ == 'LSBFactCollector'


# Generated at 2022-06-25 00:16:01.428629
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("test_LSBFactCollector()")
    assert LSBFactCollector.__doc__ == "Collect facts related to LSB (Linux Standard Base)"
    assert LSBFactCollector.name == 'lsb'
    assert type(LSBFactCollector._fact_ids) == set
    assert LSBFactCollector.STRIP_QUOTES == "\\'\"\\"

test_LSBFactCollector()
print("=======================")
test_case_0()
print("+++++++++++++++++++++++")

# Generated at 2022-06-25 00:16:07.932109
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)
    print("type(var_0): {}".format(type(var_0)))
    print("var_0: {}".format(var_0))

# Generated at 2022-06-25 00:16:09.977338
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:16:16.790891
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == 'lsb'
    assert l_s_b_fact_collector._fact_ids == set()
    assert l_s_b_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:16:18.509918
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector().name == "lsb"
    assert LSBFactCollector()._fact_ids == set()

# Generated at 2022-06-25 00:16:19.971508
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:16:23.734037
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_0, LSBFactCollector)


if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:17:01.572640
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()

    assert (lsb_fact_collector.name == 'lsb')

    assert (isinstance(lsb_fact_collector._fact_ids, set))
    assert (not lsb_fact_collector._fact_ids)


# Generated at 2022-06-25 00:17:04.797436
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test for constructor with no argument
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector is not None


# Generated at 2022-06-25 00:17:06.249479
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_1.collect()

# Generated at 2022-06-25 00:17:07.937551
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    f = LSBFactCollector()


# Generated at 2022-06-25 00:17:11.348102
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:17:16.697405
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    f_c_0 = LSBFactCollector()

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:17:24.962924
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector()
    var_1 = LSBFactCollector

# Generated at 2022-06-25 00:17:28.655496
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  # arr_0 is type Array
  # l_s_b_fact_collector_0 is type LSBFactCollector
  l_s_b_fact_collector_0 = LSBFactCollector()
  arr_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:31.778044
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:17:32.941227
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:18:35.622480
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_2.collect(None)


# Generated at 2022-06-25 00:18:36.297919
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector()



# Generated at 2022-06-25 00:18:42.530161
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)
    var_2 = l_s_b_fact_collector_0.collect(module=l_s_b_fact_collector_0,
                                           collected_facts=l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:18:43.773016
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except AssertionError:
        print("Test Case 0 failed")
        raise


# Generated at 2022-06-25 00:18:44.708332
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:18:49.052161
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector()

# Generated at 2022-06-25 00:18:54.459330
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    collected_facts = {}

    lsb_fact_collector._lsb_release_bin = MagicMock(return_value={'id': 'Ubuntu', 'description': 'Ubuntu'})
    lsb_fact_collector.collect(collected_facts=collected_facts)

    assert collected_facts == {'lsb': {'id': 'Ubuntu', 'description': 'Ubuntu'}}

    lsb_fact_collector._lsb_release_bin = MagicMock(return_value={})
    lsb_fact_collector._lsb_release_file = MagicMock(return_value={'id': 'Ubuntu', 'description': 'Ubuntu'})

# Generated at 2022-06-25 00:18:56.348068
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # runs constructor for LSBFactCollector
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:18:59.062958
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:19:01.665914
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-25 00:21:44.631060
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    ansible_path = '/usr/bin/ansible'
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:21:46.664222
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # TODO: add tests
    assert(False)


# Generated at 2022-06-25 00:21:50.761335
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == 'lsb'
    assert l_s_b_fact_collector._fact_ids == set()
    assert l_s_b_fact_collector.STRIP_QUOTES == "'\"\\"


# Generated at 2022-06-25 00:21:51.676088
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:21:54.071451
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)
    #assert var_0 == var_1

# Generated at 2022-06-25 00:22:03.194931
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_2.collect(None)
    var_3 = l_s_b_fact_collector_2.collect(None)
    var_4 = l_s_b_fact_collector_2.collect(l_s_b_fact_collector_2)
    var_5 = l_s_b_fact_collector_2.collect(None, None)
    var_6 = l_s_b_fact_collector_2.collect(l_s_b_fact_collector_2, None)
    var_7 = l_s_b_fact_collector_2.collect(None, None)

# Generated at 2022-06-25 00:22:06.850275
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name is not None
    assert LSBFactCollector._fact_ids is not None
    assert LSBFactCollector.STRIP_QUOTES is not None
    assert LSBFactCollector._lsb_release_bin is not None
    assert LSBFactCollector._lsb_release_file is not None
    assert LSBFactCollector.collect is not None
    test_case_0()

# Generated at 2022-06-25 00:22:07.331238
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:22:09.171464
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj1 = LSBFactCollector()
    assert obj1._fact_ids == set()
    assert obj1.name == 'lsb'


# Generated at 2022-06-25 00:22:13.326653
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'