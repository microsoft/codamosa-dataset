

# Generated at 2022-06-25 00:13:20.509738
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:13:28.021956
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    facts_dict = { 'ansible_check_mode': False, 'ansible_module_args': { '_ansible_syslog_facility': 'LOG_USER'}, 'ansible_facts': { 'command_warnings': [], 'command_specific_facts': {}}}

    l_s_b_fact_collector_0.collect(module=None, collected_facts=facts_dict)
    assert 0 == len(facts_dict['ansible_facts']['lsb'])


# Generated at 2022-06-25 00:13:30.583308
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:34.635786
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:13:38.892955
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert l_s_b_fact_collector_0 is not None


# Generated at 2022-06-25 00:13:41.141482
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    f = LSBFactCollector()
    assert f.name == 'lsb'

# Generated at 2022-06-25 00:13:44.841898
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()

    l_s_b_fact_collector_0.collect()

    return

# Generated at 2022-06-25 00:13:49.128780
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:13:51.946049
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:13:57.051777
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert l_s_b_fact_collector_0._fact_ids == set(), 'Constructor of class LSBFactCollector should have the instance property "_fact_ids" initialized to set()'

# Generated at 2022-06-25 00:14:11.285409
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    float_1 = -3276.76945
    var_2 = l_s_b_fact_collector_2.collect(float_1)
    float_2 = -3276.76945
    var_3 = l_s_b_fact_collector_2.collect(float_2)
    float_3 = -3276.76945
    var_4 = l_s_b_fact_collector_2.collect(float_3)
    float_4 = -3276.76945
    var_5 = l_s_b_fact_collector_2.collect(float_4)
    float_5 = -3276.76945
    var_6 = l_s_b_fact_

# Generated at 2022-06-25 00:14:15.781299
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    float_0 = -3276.76945
    var_0 = l_s_b_fact_collector_0.collect(float_0)
    l_s_b_fact_collector_1 = LSBFactCollector()

# Generated at 2022-06-25 00:14:22.510985
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  l_s_b_fact_collector = LSBFactCollector()
  var_0 = l_s_b_fact_collector.collect()
  float_0 = -3276.76945
  var_1 = l_s_b_fact_collector.collect(float_0)
  l_s_b_fact_collector_1 = LSBFactCollector()

if __name__ == '__main__':
  test_case_0()
  test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:14:24.023628
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:14:25.800228
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert(l_s_b_fact_collector)


# Generated at 2022-06-25 00:14:27.937611
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:14:30.773524
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    float_0 = -3276.76945
    var_0 = l_s_b_fact_collector_0.collect(float_0)


# Generated at 2022-06-25 00:14:33.629803
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == '\'\"\\'
    assert l_s_b_fact_collector_0.collect() == var_0
    assert l_s_b_fact_collector_0.collect() == var_1

# Generated at 2022-06-25 00:14:36.189918
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert callable(LSBFactCollector)
    assert isinstance(LSBFactCollector(), LSBFactCollector)



# Generated at 2022-06-25 00:14:43.257141
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None
    assert l_s_b_fact_collector_0.collect() is None

# Generated at 2022-06-25 00:14:58.442444
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    some_lsb_facts = LSBFactCollector()
    print('some_lsb_facts:', some_lsb_facts)

# Generated at 2022-06-25 00:15:00.797610
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts import utils

    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = AnsibleModule(argument_spec=dict())
    var_3 = l_s_b_fact_collector_2.collect(var_2)


# Generated at 2022-06-25 00:15:05.595058
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0, l_s_b_fact_collector_0)
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:15:11.516089
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_0, l_s_b_fact_collector_1)
    var_2 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_1, l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:15:14.807440
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    #TODO: Implement unit test for LSBFactCollector
    return


# Generated at 2022-06-25 00:15:18.649388
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    line_2 = 'some random line for test'
    l_s_b_fact_collector_2.collect(line_2, l_s_b_fact_collector_2)


# Generated at 2022-06-25 00:15:21.749940
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_2 = LSBFactCollector()



# Generated at 2022-06-25 00:15:30.818707
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert 'ansible.module_utils.facts.linux.lsb' == l_s_b_fact_collector_0.name
    assert 'lsb' == l_s_b_fact_collector_0.name
    assert not l_s_b_fact_collector_0._fact_ids
    assert not l_s_b_fact_collector_0._fact_ids
    assert '\'\"\\' == l_s_b_fact_collector_0.STRIP_QUOTES
    assert '\'\"\\' == l_s_b_fact_collector_0.STRIP_QUOTES


# Generated at 2022-06-25 00:15:32.928522
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_2.collect()

# Generated at 2022-06-25 00:15:39.713376
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0, l_s_b_fact_collector_0)
    assert type(var_0) == dict
    assert type(var_1) == dict
    """
    assert var_0['lsb']['id'] != ''
    assert var_1['lsb']['id'] != ''
    """


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:16:13.105800
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:16:16.034979
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    lsb_fact_collector = LSBFactCollector()
    lsb_facts = lsb_fact_collector.collect()

    if not lsb_facts:
        return

    # check for required keys
    for key in ['id', 'release']:
        if key not in lsb_facts['lsb']:
            return

    return lsb_facts

# Generated at 2022-06-25 00:16:19.610511
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:16:21.597281
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_lsb = LSBFactCollector()
    var_lsb.collect()
    var_lsb.collect(var_lsb)

# Generated at 2022-06-25 00:16:22.837313
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert callable(LSBFactCollector)


# Generated at 2022-06-25 00:16:26.277795
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    name = l_s_b_fact_collector.name
    fact_ids = l_s_b_fact_collector._fact_ids
    assert name == 'lsb'
    assert not fact_ids


# Generated at 2022-06-25 00:16:31.344092
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()

    # real test here
    # real test here


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 00:16:37.683891
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    import sys

    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collector.base
    import ansible.module_utils.facts.collector.lsb
    import ansible.module_utils.facts.collector.platform
    import ansible.module_utils.facts.collector.distribution
    import ansible.module_utils.facts.collector.kernel

    try:
        l_s_b_fact_collector_0 = ansible.module_utils.facts.collector.lsb.LSBFactCollector()
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 00:16:40.643606
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

# Generated at 2022-06-25 00:16:47.236316
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == "lsb"
    assert l_s_b_fact_collector._fact_ids == set()
    assert l_s_b_fact_collector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-25 00:18:00.859807
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:18:01.807155
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector


# Generated at 2022-06-25 00:18:03.268275
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()

# Unit test class LSBFactCollector

# Generated at 2022-06-25 00:18:11.456417
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    method_name = '_lsb_release_file'

    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect(collected_facts=None)
    assert var_0['lsb']['id'] == 'Ubuntu'
    assert var_0['lsb']['description'] == 'Ubuntu 16.04.1 LTS'
    assert var_0['lsb']['release'] == '16.04'
    assert var_0['lsb']['codename'] == 'xenial'
    assert var_0['lsb']['major_release'] == '16'

# Generated at 2022-06-25 00:18:15.441264
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:18:17.247085
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    temp_lsbfactcollector = LSBFactCollector()



# Generated at 2022-06-25 00:18:26.971143
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # setup test data
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_1._lsb_release_bin = lambda x, y: {'release': '7.6', 'description': '"API Linux", "BASE 3.4.4-3.4.4", "prod 3.4.4-3.4.4"'}
    l_s_b_fact_collector_1.STRIP_QUOTES = r'\'"'

    # run test
    l_s_b_fact_collector_1.collect()

    # assert test
    var_2 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_1)

    # verify results
    # assert var

# Generated at 2022-06-25 00:18:34.977112
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    if LSBFactCollector.STRIP_QUOTES != r'\'\"\\':
        print("expected LSBFactCollector.STRIP_QUOTES == r'\'\"\\', actual value was LSBFactCollector.STRIP_QUOTES")
        return
    if LSBFactCollector.name != 'lsb':
        print("expected LSBFactCollector.name == 'lsb', actual value was LSBFactCollector.name")
        return
    var_2 = l_s_b_fact_collector_1.collect()
    var_3 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_1)

# Generated at 2022-06-25 00:18:39.201141
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()

    # Test with and without module's argument passed
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

# Generated at 2022-06-25 00:18:42.743165
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    # No parameters
    var_2 = l_s_b_fact_collector_1.collect()
    # No parameters
    var_3 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_1)

# Generated at 2022-06-25 00:21:39.046822
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_0 = LSBFactCollector()
    lsb_fact_collector_0.collect()
    lsb_fact_collector_0.collect(lsb_fact_collector_0)

if __name__ == "__main__":
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:21:45.265340
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.name
    var_1 = l_s_b_fact_collector_0.collect()
    var_2 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

    assert var_0 == 'lsb'
    assert var_1['lsb']
    assert var_2['lsb']

# Generated at 2022-06-25 00:21:47.537597
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    my_collector = Collector()
    my_collector.collect_each_subclass(LSBFactCollector)

    my_collector.get_fact('lsb', dict())

# Generated at 2022-06-25 00:21:54.518580
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:21:55.766249
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    #test_case_0()
    print("Passed all tests!")


# Generated at 2022-06-25 00:21:59.344480
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except:
        print("Exception thrown")

test_LSBFactCollector()

# Generated at 2022-06-25 00:22:00.258051
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:22:02.650203
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:22:06.980429
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Although the method is public, this test case calls
    # the module directly.
    from ansible.module_utils.facts.collector import BaseFactCollector

    # The first type of test case must be unit test.
    assert len(BaseFactCollector.collectors) == 0

    # Test the second type of test case here.
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import LSBFactCollector

    l_s_b_fact_collector_1 = LSBFactCollector()

    fact_collector_1 = collector.get(l_s_b_fact_collector_1.name)
    assert isinstance(fact_collector_1, LSBFactCollector)
    # Covered by the first type of test case.
    # assert len(

# Generated at 2022-06-25 00:22:07.598227
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_0 = LSBFactCollector()
    assert var_0 != None