

# Generated at 2022-06-25 00:13:24.136278
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    result = l_s_b_fact_collector_0.collect()
    assert type(result) == dict


# Generated at 2022-06-25 00:13:26.201176
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()

    assert l_s_b_fact_collector_1


# Generated at 2022-06-25 00:13:28.386070
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-25 00:13:32.955278
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    res = l_s_b_fact_collector.collect()

    assert res is not None, "LSBFactCollector works incorrectly"

# Generated at 2022-06-25 00:13:35.860599
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:39.375764
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()


if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:13:41.597295
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    l = LSBFactCollector()
    assert l.name == 'lsb'

# Generated at 2022-06-25 00:13:43.309805
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-25 00:13:46.680049
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.STRIP_QUOTES is not None
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:13:50.034964
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:14:01.446998
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert True


# Generated at 2022-06-25 00:14:02.614029
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert(isinstance(LSBFactCollector, object))


# Generated at 2022-06-25 00:14:13.288442
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import subprocess
    
    lsb_path = subprocess.getoutput('/usr/bin/lsb_release -a')
    # try the 'lsb_release' script first
    if lsb_path:
            # lsb_facts = self._lsb_release_bin(lsb_path,
                                              # module=module)
            print('_lsb_release_bin')
    # no lsb_release, try looking in /etc/lsb-release
    if not lsb_path:
            # lsb_facts = self._lsb_release_file('/etc/lsb-release')
            print(lsb_path)
            print('_lsb_release_file')
    # if lsb_facts and 'release' in lsb_facts:
        # lsb_facts['major_release']

# Generated at 2022-06-25 00:14:14.216058
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:14:16.074071
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:14:18.880732
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("\nTesting Constructor")
    test_case_0()


# Generated at 2022-06-25 00:14:20.531217
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()



# Generated at 2022-06-25 00:14:22.376555
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_0 = LSBFactCollector.collect()
    assert test_0 == {'lsb': {}}


# Generated at 2022-06-25 00:14:24.977645
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:30.806687
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    # Check if the instance initialized properly
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.collector == 'lsb', 'Collector is set to {}'.format(l_s_b_fact_collector_0.collector)
    assert l_s_b_fact_collector_0.fact_ids == {'lsb'}, 'Facts are set to {}'.format(l_s_b_fact_collector_0.fact_ids)

# Generated at 2022-06-25 00:14:39.884243
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:41.013109
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:14:43.724209
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_path = '/usr/bin/lsb_release'
    module = [lsb_path, "-a"]
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect(module=module)


# Generated at 2022-06-25 00:14:47.313514
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:14:48.231708
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  pass


# Generated at 2022-06-25 00:14:52.148077
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:14:55.186090
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:15:03.750361
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    # Call the constructor without arguments
    l_s_b_fact_collector_0 = LSBFactCollector()

    # Check if the created object is of class LSBFactCollector
    assert(isinstance(l_s_b_fact_collector_0, LSBFactCollector))

    # Check the LG_FACT_COLLECTOR_NAME
    if os.environ.get('LG_FACTS_TEST_CASE') == '0':
        assert(l_s_b_fact_collector_0.name == 'lsb')

    # Check the LG_FACT_COLLECTOR__FACT_IDS
    assert(len(l_s_b_fact_collector_0._fact_ids) == 0)



# Generated at 2022-06-25 00:15:04.528627
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:06.252769
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:15:30.274128
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    if true:
        import ansible.module_utils.facts.collector.system
        class Module():
            def get_bin_path(arg_0):
                var_0 = ansible.module_utils.facts.collector.system.get_file_content('/home/vagrant/testdir/ansible/test/unit/module_utils/facts/collector/system.py', arg_0)
                return var_0
        var_0 = None
        var_0 = Module()
        var_1 = l_s_b_fact_collector_0.collect(var_0)
        assert var_1['lsb']['codename'] == 'jessie'
        assert var_1['lsb']['id']

# Generated at 2022-06-25 00:15:32.864487
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_LSBFactCollector()
# End of test_LSBFactCollector

# Generated at 2022-06-25 00:15:40.130017
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.fact_type == 'lsb'
    assert l_s_b_fact_collector_0.fact_subset == None
    assert l_s_b_fact_collector_0.collect_subset == 'all'
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == '\'\"\\'
    # test for private method collect
    assert l_s_b_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:15:43.006719
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except:
        assert False, "Exception"
    else:
        assert True, "Success"

test_LSBFactCollector()

# Generated at 2022-06-25 00:15:44.328781
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass



# Generated at 2022-06-25 00:15:46.117470
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:15:47.745088
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:15:51.448509
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    # Test invoking of method LSBFactCollector.collect of class LSBFactCollector
    test_case_0()
    return 0

# Program entrypoint
if __name__ == "__main__":
    print(test_LSBFactCollector())

# Generated at 2022-06-25 00:15:56.440069
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0 is not None

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:15:59.915631
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    var_1 = {'lsb': {'id': 'RedHatEnterpriseServer', 'major_release': '7', 'codename': 'Maipo', 'description': 'Red Hat Enterprise Linux Server release 7.3 (Maipo)', 'release': '7.3'}}
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:16:32.359866
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    result = l_s_b_fact_collector_0.collect()
    assert result['lsb']['id'] == 'Ubuntu'
    assert result['lsb']['release'] == '18.04'
    assert result['lsb']['codename'] == 'bionic'
    assert result['lsb']['description'] == 'Ubuntu 18.04.1 LTS'

# Generated at 2022-06-25 00:16:34.291267
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_1 = LSBFactCollector()


# Generated at 2022-06-25 00:16:37.709710
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:16:39.165340
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert l_s_b_fact_collector_0 is not None


# Generated at 2022-06-25 00:16:40.262392
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    if var_0 is False:
        print("true")
    else:
        print("false")

# Generated at 2022-06-25 00:16:43.288545
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:16:47.880515
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect( module=None, collected_facts=None )
    #assert var_0 == ( foo, bar )


# Generated at 2022-06-25 00:16:56.063130
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == '\'\"\\'
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:16:57.969273
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:17:01.191544
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

    assert(True)


# Generated at 2022-06-25 00:18:07.818328
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:18:14.186071
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert type (var_0) == dict
    assert 'lsb' in var_0
    assert 'codename' in var_0['lsb']
    assert 'id' in var_0['lsb']
    assert 'release' in var_0['lsb']
    assert 'description' in var_0['lsb']
    assert 'major_release' in var_0['lsb']



# Generated at 2022-06-25 00:18:17.553120
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == 'lsb'
    assert l_s_b_fact_collector._fact_ids == set()
    assert l_s_b_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-25 00:18:20.197264
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # initializing object
    l_s_b_fact_collector_0 = LSBFactCollector()
    # testing class
    test_case_0()

# Unit test function

# Generated at 2022-06-25 00:18:28.517818
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("Test for constructor of class LSBFactCollector")
    print("==============================================")
    print()

    var_0 = LSBFactCollector()
    print("\nObject: " + str(var_0))
    print("\nType: " + str(type(var_0)))
    print("\nStr: " + str(var_0))
    print("\nName: " + str(var_0.name))
    print("\nFact Ids: " + str(var_0._fact_ids))
    print("\nStrip Quotes: " + str(var_0.STRIP_QUOTES))


# Generated at 2022-06-25 00:18:30.283926
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()



# Generated at 2022-06-25 00:18:36.082258
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_0.collect()
    assert var_1 == {'lsb': {'codename': 'Wheezy', 'description': 'Debian GNU/Linux 7.7 (wheezy)', 'id': 'Debian', 'major_release': '7', 'release': '7.7'}}


# Generated at 2022-06-25 00:18:39.761787
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_0 = LSBFactCollector()
    if var_0.name != 'lsb':
        return 0
    if var_0._fact_ids != set():
        return 0
    if var_0.STRIP_QUOTES != r'\'\"\\':
        return 0
    return 1


# Generated at 2022-06-25 00:18:43.191407
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector()

# Generated at 2022-06-25 00:18:45.609669
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    '''
    Unit test for method collect of class LSBFactCollector
    '''
    print('\n>>>>>>>>>> Run test for method collect of class LSBFactCollector\n')
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:21:40.764117
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()
    if l_s_b_fact_collector_0.name != 'lsb':
        raise Exception('Assertion Error: expected l_s_b_fact_collector_0.name to equal "lsb"')

if __name__ == '__main__':
    test_LSBFactCollector_collect()
    test_case_0()

# Generated at 2022-06-25 00:21:42.121245
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()

# Generated at 2022-06-25 00:21:46.866730
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert l_s_b_fact_collector_1.name == 'lsb'


# Generated at 2022-06-25 00:21:53.792669
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    module_1 = mock.Mock()
    collected_facts_2 = {}
    setattr(module_1, 'run_command', mock.Mock(return_value=(
        0, b'', b'')))
    setattr(module_1, 'get_bin_path', mock.Mock(return_value=''))
    setattr(l_s_b_fact_collector_0, '_lsb_release_bin', mock.Mock(return_value={
    }))
    setattr(os, 'path', mock.Mock())
    setattr(os.path, 'exists', mock.Mock(return_value=False))

# Generated at 2022-06-25 00:21:55.604986
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0 != None


# Generated at 2022-06-25 00:22:04.161753
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.get_name() == "lsb"
    assert l_s_b_fact_collector._fact_ids == set()
    assert l_s_b_fact_collector.STRIP_QUOTES == r'\'\"\\'


lsb_release_output = """
No LSB modules are available.
Distributor ID: RedHatEnterpriseServer
Description:    Red Hat Enterprise Linux Server release 7.4 Beta (Maipo)
Release:        7.4
Codename:       Maipo
"""

# Generated at 2022-06-25 00:22:09.197257
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-25 00:22:12.437297
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:22:14.027699
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()

    # Call to collect() of LSBFactCollector
    var_0 = l_s_b_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:22:18.047312
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0
