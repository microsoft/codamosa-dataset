

# Generated at 2022-06-25 00:13:17.201726
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    return

# Generated at 2022-06-25 00:13:20.445277
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:13:23.415878
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    test_case_0()



# Generated at 2022-06-25 00:13:24.652109
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


test_case_0()

# Generated at 2022-06-25 00:13:26.662371
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() is None

# Generated at 2022-06-25 00:13:29.504391
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_0 = LSBFactCollector()
    assert lsb_fact_collector_0.name == 'lsb'
    assert lsb_fact_collector_0._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'



# Generated at 2022-06-25 00:13:32.694130
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:13:38.158260
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._lsb_release_file('/etc/lsb-release')
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:39.119412
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_1.collect()


# Generated at 2022-06-25 00:13:43.497779
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    result = LSBFactCollector.collect()
    assert isinstance(result, dict)
    assert len(result) == 1
    assert 'lsb' in result

if __name__ == '__main__':
    test_LSBFactCollector_collect()
    test_case_0()

# Generated at 2022-06-25 00:13:50.372722
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print(test_case_0())

# Generated at 2022-06-25 00:13:54.920468
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    assert l_s_b_fact_collector_0.collect(int_0) is not None, 'Test failed at line: 13'

test_case_0()

# Generated at 2022-06-25 00:13:59.999219
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print('Test constructor of class LSBFactCollector class')
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)
    print('Test of constructor of class LSBFactCollector succeeded')


# Generated at 2022-06-25 00:14:01.417570
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:14:06.028808
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_path = 'lsb_release'
    etc_lsb_release_location = '/etc/lsb-release'
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect(etc_lsb_release_location=etc_lsb_release_location, lsb_path=lsb_path)
    assert getattr(var_0, 'lsb', None)


# Generated at 2022-06-25 00:14:09.198134
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)


# Generated at 2022-06-25 00:14:11.990452
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)

# Generated at 2022-06-25 00:14:14.058152
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)


# Generated at 2022-06-25 00:14:16.062609
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)
    assert var_0 == {'lsb': {}}


# Generated at 2022-06-25 00:14:20.325178
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(13)


# Generated at 2022-06-25 00:14:37.673599
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)
    assert var_0 == {}

# Generated at 2022-06-25 00:14:41.013098
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test false condition
    if False:  # noqa: B014
        l_s_b_fact_collector_0 = LSBFactCollector()
    # Test true condition
    if True:  # noqa: B014
        l_s_b_fact_collector_0 = LSBFactCollector(str_0)


# Generated at 2022-06-25 00:14:49.674174
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert True

# Don't run the following tests
# def test_case_3():
#     int_0 = 7
#     l_s_b_fact_collector_0 = LSBFactCollector()
#     var_0 = l_s_b_fact_collector_0._lsb_release_file(int_0)

# def test_case_4():
#     int_0 = 7
#     str_0 = '--token'
#     l_s_b_fact_collector_0 = LSBFactCollector(str_0)
#     var_0 = l_s_b_fact_collector_0._lsb_release_bin(int_0, str_0)

# def test_case_5():
#     int_0 = 7
#     str_0 = '--

# Generated at 2022-06-25 00:14:55.692503
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    int_0 = 6
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    assert l_s_b_fact_collector_0.name == str_0

    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)

if __name__ == '__main__':
    test_LSBFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:15:00.425281
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    the_str = '--token'
    l_s_b_fact_collector = LSBFactCollector(the_str)
    the_str2 = 'the_str2'
    the_str3 = 'the_str3'
    l_s_b_fact_collector.collect(int_0=the_str, collected_facts=the_str2, module=the_str3)

# Generated at 2022-06-25 00:15:02.151661
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector.LSBFactCollector(self, self, self)


# Generated at 2022-06-25 00:15:05.810538
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:15:08.879250
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    l_s_b_fact_collector_0.collect(int_0)
    assert True == True


# Generated at 2022-06-25 00:15:11.609057
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    int_0 = 13
    str_0 = '--token'
    l_s_b_fact_collector_0 = LSBFactCollector(str_0)
    var_0 = l_s_b_fact_collector_0.collect(int_0)


# Generated at 2022-06-25 00:15:21.605388
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    etc_lsb_release_location = '/etc/lsb-release'
    lsb_path = 'lsb_release'
    lsb_facts_dict = {'release':'codename', 'id':'distributor_id'}
    lsb_facts_dict['description'] = 'description'
    lsb_facts_dict['release'] = 'release'
    lsb_facts_dict['codename'] = 'codename'
    lsb_facts_dict['release'] = 'release_2'
    lsb_facts_dict['codename'] = 'codename_2'
    lsb_facts_dict['major_release'] = 'release_2'
    exit_0 = 13
    module_0 = AnsibleModuleStub(lsb_path)

# Generated at 2022-06-25 00:15:50.475541
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert 'lsb' in l_s_b_fact_collector_1.collect()


# Generated at 2022-06-25 00:15:55.901080
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name is 'lsb'


# Generated at 2022-06-25 00:16:00.227432
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_3 = l_s_b_fact_collector_1.collect()
    assert var_3 == {}

# Generated at 2022-06-25 00:16:02.548676
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test with simple parametrization
    l_s_b_fact_collector_0 = LSBFactCollector()
    print(l_s_b_fact_collector_0.name)

test_LSBFactCollector()

test_case_0()

# Generated at 2022-06-25 00:16:06.144576
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:09.619324
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert isinstance(var_0, dict)

test_case_0()

# Generated at 2022-06-25 00:16:20.834102
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Mock module
    class MockModule():
        def get_bin_path(self, value=None):
            return '/bin/lsb_release'

        def run_command(self, value=None, errors=None):
            pass

    mock_module = MockModule()

    # Mock module.run_command
    def mock_run_command(value=None, errors=None):
        print('In mock_run_command')
        class MockResult0():
            def __init__(self, rc=None, out=None, err=None):
                self.rc = rc
                self.out = out
                self.err = err
            def __bool__(self):
                return True


# Generated at 2022-06-25 00:16:24.230375
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # invokes the LSBFactCollector constructor and checks if the return value
    # is an instance of the LSBFactCollector class
    assert isinstance(LSBFactCollector(), LSBFactCollector), 'Should create an instance of the LSBFactCollector class'


# Generated at 2022-06-25 00:16:30.311998
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.collect() == {}
    assert l_s_b_fact_collector.collect(l_s_b_fact_collector) == {}


# Generated at 2022-06-25 00:16:32.694028
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test set-up
    l_s_b_fact_collector_0 = LSBFactCollector()

    # Test for constructor
    assert l_s_b_fact_collector_0 is not None



# Generated at 2022-06-25 00:17:45.109496
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:17:49.530767
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_0.collect()
    var_3 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:17:54.072110
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:17:54.951576
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:17:56.156229
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:17:56.545529
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass

# Generated at 2022-06-25 00:18:05.911729
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert var_0 == {'lsb': {'id': 'rhel', 'release': '7.3', 'codename': 'Maipo', 'major_release': '7', 'description': 'Red Hat Enterprise Linux Server release 7.3 (Maipo)'}}, "grep -E 'DISTRIB_ID=|DISTRIB_RELEASE=|DISTRIB_CODENAME=|DISTRIB_DESCRIPTION=' /etc/lsb-release works"
    l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

# Generated at 2022-06-25 00:18:10.068979
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.collect() == {"lsb": {}}
    assert l_s_b_fact_collector.collect(l_s_b_fact_collector) == {"lsb": {}}


# Generated at 2022-06-25 00:18:11.302049
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:18:15.308113
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_1.collect()
    assert var_2.get('lsb') == {
        'release': '14.04',
        'codename': 'trusty',
        'id': 'Ubuntu',
        'description': 'Ubuntu 14.04.3 LTS',
        'major_release': '14',
    }


# Generated at 2022-06-25 00:21:04.325100
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:21:09.174087
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    var = {'lsb': {'description': 'CentOS release 6.8 (Final)', 'codename': 'Final', 'id': 'CentOS', 'release': '6.8', 'major_release': '6'}}
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)
    assert var == var_0

# Generated at 2022-06-25 00:21:14.583872
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_0.collect()
    var_3 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:21:15.405886
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'


# Generated at 2022-06-25 00:21:18.286384
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:21:22.190507
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:21:26.685902
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:21:32.771080
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Instantiate an object of class LSBFactCollector()
    l_s_b_fact_collector_0 = LSBFactCollector()
    # Ensure l_s_b_fact_collector_0 is an object of class LSBFactCollector
    assert isinstance(l_s_b_fact_collector_0, LSBFactCollector)


# Generated at 2022-06-25 00:21:33.845188
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert isinstance(LSBFactCollector(), LSBFactCollector)


# Generated at 2022-06-25 00:21:42.439995
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = {'lsb': {'codename': 'xenial', 'release': '16.04', 'id': 'Ubuntu', 'major_release': '16', 'description': 'Ubuntu 16.04.3 LTS'}}
    l_s_b_fact_collector_3 = LSBFactCollector()
    var_3 = l_s_b_fact_collector_3.collect(l_s_b_fact_collector_3)
    assert var_2['lsb']['id'] == var_3['lsb']['id']
    assert var_2['lsb']['description'] == var_3['lsb']['description']