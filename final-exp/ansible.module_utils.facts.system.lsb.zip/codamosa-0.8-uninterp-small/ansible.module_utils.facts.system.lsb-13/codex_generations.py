

# Generated at 2022-06-25 00:13:27.556124
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    res = l_s_b_fact_collector_0.collect()
    assert res == {'lsb': {}}
    res = l_s_b_fact_collector_0.collect(None)
    assert res == {'lsb': {}}
    res = l_s_b_fact_collector_0.collect(None, None)
    assert res == {'lsb': {}}
    res = l_s_b_fact_collector_0.collect(None, None, None, None, None)
    assert res == {'lsb': {}}
    res = l_s_b_fact_collector_0.collect(None, None, None, None, None,
        None, None, None)
   

# Generated at 2022-06-25 00:13:32.358875
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    """Check that LSBFactCollector can be created correctly."""
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:33.010964
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass

# Generated at 2022-06-25 00:13:35.908251
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:13:43.232516
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    dict_0 = l_s_b_fact_collector_1.collect()
    keys_0 = dict_0.keys()
    keys_0.sort()

if __name__ == '__main__':
    test_case_0()
    #test_LSBFactCollector_collect()
    pass

# Generated at 2022-06-25 00:13:44.305648
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert LSBFactCollector().collect() is None


# Generated at 2022-06-25 00:13:45.683359
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        assert LSBFactCollector.__init__("lsb")
    except:
        raise


# Generated at 2022-06-25 00:13:47.862920
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    l_s_b_fact_collector_collect = l_s_b_fact_collector.collect()
    assert l_s_b_fact_collector_collect == {}


# Generated at 2022-06-25 00:13:50.276153
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:13:52.006511
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:14:03.225382
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:14:04.596493
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_0 = LSBFactCollector()
    var_0.collect()


# Generated at 2022-06-25 00:14:08.834924
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:14:11.891474
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()
    l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:14:14.126916
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_1, LSBFactCollector)
    assert hasattr(l_s_b_fact_collector_1, 'collect')


# Generated at 2022-06-25 00:14:22.828158
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

if __name__ == '__main__':
    test_case_0()

# Collect facts related to LSB (Linux Standard Base)
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
#

# Generated at 2022-06-25 00:14:26.322698
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert var_0 == {'ansible_lsb': {}}

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 00:14:30.773584
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    print("")
    print("test_LSBFactCollector_collect")
    l_s_b_fact_collector = LSBFactCollector()
    l_s_b_fact_collector.collect()
    del l_s_b_fact_collector

if __name__ == '__main__':
    #test_LSBFactCollector_collect()  # no coverage
    pass

# Generated at 2022-06-25 00:14:36.368931
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:14:39.539156
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Create a stub for the base class.
    l_s_b_fact_collector = LSBFactCollector()

    # Test for valid return values of method 'collect'
    l_s_b_fact_collector.collect(l_s_b_fact_collector)


# Generated at 2022-06-25 00:14:57.525829
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    facts_dict = l_s_b_fact_collector_0.collect()
    assert ('lsb' in facts_dict) == True
    assert facts_dict['lsb'].get('id', False) == 'Ubuntu'


# Generated at 2022-06-25 00:15:03.744984
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    print(l_s_b_fact_collector_1.name)
    print(l_s_b_fact_collector_1._fact_ids)
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

# Generated at 2022-06-25 00:15:04.359392
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()

# Generated at 2022-06-25 00:15:06.355864
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:11.906513
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:15:15.612916
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:15:18.360484
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector._fact_ids == set()
    assert lsb_fact_collector.name == 'lsb'


# Generated at 2022-06-25 00:15:21.378961
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert isinstance(LSBFactCollector(), LSBFactCollector)

# Generated at 2022-06-25 00:15:27.889394
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert (LSBFactCollector.__dict__ == {})
    assert (LSBFactCollector.__doc__ == None)
    assert (LSBFactCollector.__module__ == 'ansible.module_utils.facts.lsb')
    assert (LSBFactCollector.__weakref__ == None)
    assert (LSBFactCollector.name == 'lsb')
    


# Generated at 2022-06-25 00:15:31.589247
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()

# Generated at 2022-06-25 00:16:05.309739
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    import mock

    class MockModule(object):
        def get_bin_path(self, arg_0_0):
            return None

        def run_command(self, arg_0_0, errors_1_0):
            if arg_0_0[0] == 'lsb_release':
                return 0, '''LSB Version:\tcore-9.20160110ubuntu0.2-amd64:core-9.20160110ubuntu0.2-noarch
Distributor ID:\tUbuntu
Description:\tUbuntu 16.04.1 LTS
Release:\t16.04
Codename:\ttrusty''', ''

# Generated at 2022-06-25 00:16:09.090250
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Start a  LSBFactCollector instance
    l_s_b_fact_collector_0 = LSBFactCollector()
    # Start recursion with call to method collect of class LSBFactCollector
    l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:13.001297
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    l_s_b_fact_collector_0 = LSBFactCollector()
    var_3 = l_s_b_fact_collector_0.collect()

    assert var_3 == {}


# Generated at 2022-06-25 00:16:16.050251
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:16:17.745157
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0



# Generated at 2022-06-25 00:16:18.362750
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert 1


# Generated at 2022-06-25 00:16:19.493226
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
	lsb_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:16:25.505227
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    # BEGIN, DO NOT EDIT
    l_s_b_fact_collector_0._fact_ids = set()
    l_s_b_fact_collector_0.name = 'lsb'
    l_s_b_fact_collector_0.STRIP_QUOTES = r'\'\"\\'
    # END, DO NOT EDIT
    return l_s_b_fact_collector_0



# Generated at 2022-06-25 00:16:26.616390
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert isinstance(LSBFactCollector(), LSBFactCollector)

# Generated at 2022-06-25 00:16:33.994392
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'

    # AssertionError: 'lsb' == 'test'
    try:
        assert l_s_b_fact_collector_0.name == 'test'
    except AssertionError:
        assert True

    # AssertionError: set(['id', 'major_release', 'release', 'codename', 'description']) == set([])
    try:
        assert l_s_b_fact_collector_0._fact_ids == set([])
    except AssertionError:
        assert True

    # AssertionError: '\'\"\\' != ''

# Generated at 2022-06-25 00:17:38.953157
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

# Test case for method of class LSBFactCollector, _lsb_release_bin

# Generated at 2022-06-25 00:17:43.301100
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

# Generated at 2022-06-25 00:17:46.433254
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:17:55.569881
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_0.collect()
    var_3 = l_s_b_fact_collector_0.collect()
    var_4 = l_s_b_fact_collector_0.name
    var_0 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:17:57.888368
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    var_0 = None
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    if var_0 == None:
        assert False
    else:
        assert True


# Generated at 2022-06-25 00:18:02.637229
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:18:05.863613
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:18:10.267985
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  l_s_b_fact_collector_1 = LSBFactCollector()
  l_s_b_fact_collector_2 = LSBFactCollector()
  result = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_2)
  assert result == {'lsb': {}}


# Generated at 2022-06-25 00:18:11.338376
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:18:13.377122
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_0.collect()
    assert var_2 == {}


# Generated at 2022-06-25 00:20:45.610651
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_0.collect()
    var_3 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:20:46.971425
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass

if __name__ == "__main__":
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:20:50.459260
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_0 = LSBFactCollector()
    var_0 = lsb_fact_collector_0.name
    var_1 = lsb_fact_collector_0.collect()
    var_2 = lsb_fact_collector_0.collect(lsb_fact_collector_0)
    var_3 = lsb_fact_collector_0._lsb_release_bin()
    var_4 = lsb_fact_collector_0._lsb_release_file()

# Generated at 2022-06-25 00:20:56.636313
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == '\'\"\\'


# Generated at 2022-06-25 00:20:59.798545
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    var = l_s_b_fact_collector.collect()
    assert var['lsb'] == {}

test_case_0()
test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:21:01.543993
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:21:02.879528
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

# Generated at 2022-06-25 00:21:04.527848
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:21:05.197825
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 00:21:08.634892
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_2 = LSBFactCollector()
    var_3 = l_s_b_fact_collector_0.collect(var_2)
    assert True
