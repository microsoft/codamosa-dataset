

# Generated at 2022-06-25 00:13:19.857906
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.name == 'lsb'

# Generated at 2022-06-25 00:13:24.402106
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:13:29.755391
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert not l_s_b_fact_collector_0.test_case


# Generated at 2022-06-25 00:13:33.761520
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:37.029302
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:41.218837
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:42.929755
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == 'lsb'

# Generated at 2022-06-25 00:13:45.635227
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == 'lsb'
    assert l_s_b_fact_collector._fact_ids == set([])



# Generated at 2022-06-25 00:13:47.557019
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 00:13:57.392589
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_1 = LSBFactCollector()

    # Test case: Try with lsb_release script not found
    l_s_b_fact_collector_0.get_bin_path = lambda x: None
    os.path.exists = lambda x: False
    module = None
    collected_facts = None
    result = l_s_b_fact_collector_0.collect(module=module, collected_facts=collected_facts)
    assert result == {}

    # Test case: Try with lsb_release script found and
    # /etc/lsb-release not found

# Generated at 2022-06-25 00:14:06.173000
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    collected_facts_0 = {}
    returned_facts_0 = lsb_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert 'lsb' in returned_facts_0
    assert returned_facts_0['lsb'] == {}
    assert returned_facts_0 == {}

# Generated at 2022-06-25 00:14:07.845030
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()




# Generated at 2022-06-25 00:14:09.121335
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:14:09.849891
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    LSBFactCollector().collect()


# Generated at 2022-06-25 00:14:13.064991
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    if type(l_s_b_fact_collector_0.collect()) is dict:
        print("collect method of LSBFactCollector class returned a dictionary")
    else:
        print("collect method of LSBFactCollector class did not return a dictionary")


# Generated at 2022-06-25 00:14:16.180025
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    # Test with module argument set to None
    l_s_b_fact_collector_1.collect(None)
    # Test the return type of the method
    assert isinstance(l_s_b_fact_collector_1.collect(None), dict)

# Generated at 2022-06-25 00:14:19.847819
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:14:20.881090
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:14:25.118691
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == str('lsb')
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == str('\'\"\\')



# Generated at 2022-06-25 00:14:29.806517
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert len(l_s_b_fact_collector_0._fact_ids) == 0
    assert len(l_s_b_fact_collector_0.STRIP_QUOTES) == 4
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:14:36.502839
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:14:42.172814
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  l_s_b_fact_collector_0 = LSBFactCollector()
  # Put your test code here
  pass

# Generated at 2022-06-25 00:14:45.726982
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    str_0 = '%s : '
    l_s_b_fact_collector_0.collect(str_0)

# Generated at 2022-06-25 00:14:50.450979
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    str_0 = '%s : '
    var_1 = l_s_b_fact_collector_0.collect(str_0)


# Generated at 2022-06-25 00:14:51.134786
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:14:57.107795
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  l_s_b_fact_collector = LSBFactCollector()
  var = l_s_b_fact_collector.collect()

  l_s_b_fact_collector.collect(var)
  l_s_b_fact_collector.collect(var)



# Generated at 2022-06-25 00:14:58.854315
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:15:01.296775
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    assert obj.collector == 'lsb'
    assert obj._fact_ids == set(['lsb'])


# Generated at 2022-06-25 00:15:02.895837
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:05.046365
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# def main():
#     test_LSBFactCollector()

# if __name__ == '__main__':
#     main()

# Generated at 2022-06-25 00:15:17.245694
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_1.collect()
    str_1 = '%s : '
    var_3 = l_s_b_fact_collector_1.collect(str_1)


# Generated at 2022-06-25 00:15:20.011442
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("Inside test_LSBFactCollector()")
    test_case_0()
    print("End of test_LSBFactCollector()")
    print(" ")
    return None


if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:15:21.136763
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert True


# Generated at 2022-06-25 00:15:26.773937
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector is not None
    assert l_s_b_fact_collector.STRIP_QUOTES == "\'\"\\"
    assert l_s_b_fact_collector.name == 'lsb'

# Generated at 2022-06-25 00:15:29.716079
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    str_0 = '%s : '
    l_s_b_fact_collector_0.collect(str_0)

# Generated at 2022-06-25 00:15:35.771174
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector.collector == 'LSBFactCollector'
    assert lsb_fact_collector._fact_ids == {}
    assert lsb_fact_collector.STRIP_QUOTES == '\'\"\\'


# Generated at 2022-06-25 00:15:42.902016
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    str_0 = '%s : '
    var_1 = l_s_b_fact_collector_0.collect(str_0)
    var_2 = l_s_b_fact_collector_0.collect({})
    var_3 = l_s_b_fact_collector_0.collect(str_0, {})
    print(LSBFactCollector.__doc__)
    print(LSBFactCollector.collect.__doc__)
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-25 00:15:46.434945
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    if isinstance(l_s_b_fact_collector_0, LSBFactCollector):
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:15:49.401356
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    module = ansible_module_get_bin_path()
    l_s_b_fact_collector.collect(module, collected_facts)
    return


# Generated at 2022-06-25 00:15:54.972604
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    str_0 = "lsb_release"
    str_1 = 'zfs'
    str_2 = 'whatnot'
    l_s_b_fact_collector_0.collect(str_0, str_1)
    l_s_b_fact_collector_0.collect(str_2)

test_case_0()
test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:16:05.505419
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    str_0 = "lsb-release"
    var_0 = LSBFactCollector.name
    assert var_0 == str_0, "Failed to return the correct name of the class"
    str_1 = "release"
    bool_0 = str_1 in LSBFactCollector._fact_ids
    assert bool_0, "Failed to return the correct name of the class"
    str_2 = "codename"
    bool_1 = str_2 in LSBFactCollector._fact_ids
    assert bool_1, "Failed to return the correct name of the class"
    str_3 = "description"
    bool_2 = str_3 in LSBFactCollector._fact_ids
    assert bool_2, "Failed to return the correct name of the class"
    str_4 = "id"


# Generated at 2022-06-25 00:16:12.581640
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    str_0 = '%s : '
    var_1 = l_s_b_fact_collector_0.collect(str_0)
    str_0 = '%s : '
    var_1 = l_s_b_fact_collector_0.collect(str_0)


# Generated at 2022-06-25 00:16:13.078653
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert False

# Generated at 2022-06-25 00:16:15.401511
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  lsbfactcollector = LSBFactCollector()
  assert lsbfactcollector is not None


# Generated at 2022-06-25 00:16:16.245627
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass



# Generated at 2022-06-25 00:16:19.855862
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    str_0 = '%s : '
    var_1 = l_s_b_fact_collector_0.collect(str_0)


# Generated at 2022-06-25 00:16:24.862108
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    str_0 = '%s : '
    l_s_b_fact_collector_0.collect(str_0)
    var_0 = l_s_b_fact_collector_0.name
    var_1 = 'lsb'
    var_2 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:25.795608
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_0 = LSBFactCollector()


# Generated at 2022-06-25 00:16:32.628964
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        # Test for Permission denied
        assert_false(subprocess.check_output("lsb_release -a 2>&1|grep -q 'Permission denied'"))
    except AssertionError as e:
        print("lsb_release command requires elevated privileges")
    except OSError as e:
        print("lsb_release command does not exist")
    except AttributeError as e:
        print("lsb_release command does not exist")

# Generated at 2022-06-25 00:16:38.161761
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_3 = LSBFactCollector()
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_7 = LSBFactCollector()
    str_1 = '%s : '
    var_8 = l_s_b_fact_collector_2.collect(str_1)


# Generated at 2022-06-25 00:16:51.543945
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:16:56.581705
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    with pytest.raises(Exception) as e_info:
        LSBFactCollector()
    var_1 = str(e_info.value)
    assert var_1 == "'LSBFactCollector' object has no attribute '_fact_ids'", 'Expected different'

# Unit tests for methods of class LSBFactCollector

# Generated at 2022-06-25 00:17:01.860083
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_1.collect()
    var_3 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_1)


# Generated at 2022-06-25 00:17:05.452682
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector.name == "lsb"

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:17:09.346701
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_2.collect()
    var_3 = l_s_b_fact_collector_2.collect(l_s_b_fact_collector_2)

# Generated at 2022-06-25 00:17:11.316141
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert(l_s_b_fact_collector.name == 'lsb')

# Generated at 2022-06-25 00:17:17.401207
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  lsb_fact_collector = LSBFactCollector()
  assert isinstance(lsb_fact_collector, LSBFactCollector)


if __name__ == '__main__':
  test_case_0()

# Generated at 2022-06-25 00:17:20.219919
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:17:20.768957
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-25 00:17:22.610166
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 00:17:43.357849
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:17:48.675837
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
	l_s_b_fact_collector = LSBFactCollector()
	assert l_s_b_fact_collector._fact_ids == set()
	assert l_s_b_fact_collector.name == 'lsb'
	assert l_s_b_fact_collector.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-25 00:17:51.817857
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    # l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:17:59.597650
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    var_0 = LSBFactCollector()
    var_0._lsb_release_file = lambda param_0: (88, 'en_US', 'Linux')
    var_0.collect = lambda param_0, param_1: (88, 'en_US', 'Linux')
    var_0.collect(var_0)
    var_0._lsb_release_bin = lambda param_0, param_1: (88, 'en_US', 'Linux')
    var_0.collect(var_0)


# Generated at 2022-06-25 00:18:03.843598
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert 'lsb_release' in l_s_b_fact_collector_1.get_fact_names(), \
           """Failed to get fact with name lsb_release"""
    assert 'lsb' in l_s_b_fact_collector_1.get_fact_names(), \
           """Failed to get fact with name lsb"""

# Generated at 2022-06-25 00:18:09.620619
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() == {}
    assert l_s_b_fact_collector_1.collect(l_s_b_fact_collector_0) == {}


# Generated at 2022-06-25 00:18:11.047877
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:18:15.102944
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # test_collect_0
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    # test_collect_1
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect(l_s_b_fact_collector_1)

# Generated at 2022-06-25 00:18:16.636513
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:18:17.673852
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        assert LSBFactCollector()
    except NameError:
        assert False

# Generated at 2022-06-25 00:18:59.842893
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:19:06.566394
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)
    assert var_0['lsb'] == {'release': '', 'id': '', 'description': '', 'codename': '', 'major_release': ''}, 'Should return {\'release\': \'\', \'id\': \'\', \'description\': \'\', \'codename\': \'\', \'major_release\': \'\'} got %s' % var_0['lsb']

# Generated at 2022-06-25 00:19:11.788306
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_cases = [test_case_0]
    for test in test_cases:
        test()

# Generated at 2022-06-25 00:19:14.429124
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Unit test entry point
if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:19:21.410648
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)


# Generated at 2022-06-25 00:19:27.353488
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()
    l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)

# Generated at 2022-06-25 00:19:30.692859
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var = LSBFactCollector()
    assert var._fact_ids == set()


# Generated at 2022-06-25 00:19:34.598529
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # setup and test
    l_s_b_fact_collector = LSBFactCollector()

    # check for getter function for class attribute 'name'
    val = l_s_b_fact_collector.name
    assert val == 'lsb'

    # check for getter function for class attribute '_fact_ids'
    val = l_s_b_fact_collector._fact_ids
    assert val == set()

    # teardown
    tearDownTestCase()



# Generated at 2022-06-25 00:19:39.394200
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Create a new instance of LSBFactCollector
    l_s_b_fact_collector_2 = LSBFactCollector()

if __name__ == '__main__':
    test_LSBFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:19:40.847431
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    obj = LSBFactCollector()
    obj.collect()

# Generated at 2022-06-25 00:21:07.160411
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    # Calling __init__(self)
    l_s_b_fact_collector_0 = LSBFactCollector()

    # Calling collect(self, module=None, collected_facts=None)
    l_s_b_fact_collector_0.collect()

    # Calling collect(self, module=None, collected_facts=None)
    l_s_b_fact_collector_0.collect(l_s_b_fact_collector_0)



# Generated at 2022-06-25 00:21:07.961474
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  assert LSBFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:21:12.976542
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except Exception as exception:
        print(exception)
        assert False
    else:
        print('All test cases passed')
        assert True


if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:21:14.398581
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:21:15.817962
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:21:16.433984
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:21:17.266717
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:21:18.728038
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    # Calling the constructor
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:21:20.728629
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:21:21.483617
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert(True)
