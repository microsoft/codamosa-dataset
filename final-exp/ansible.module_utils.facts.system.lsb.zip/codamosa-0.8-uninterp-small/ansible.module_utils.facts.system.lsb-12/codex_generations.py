

# Generated at 2022-06-25 00:13:24.108765
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Create a LSBFactCollector object
    lsb_fact_collector = LSBFactCollector()
    assert lsb_fact_collector is not None, 'lsb_fact_collector is None'
    assert lsb_fact_collector.name == 'lsb', 'lsb_fact_collector.name is not lsb'
    assert lsb_fact_collector._fact_ids == set(), 'lsb_fact_collector._fact_ids is not set()'
    assert lsb_fact_collector.STRIP_QUOTES == '\'\"\\', 'lsb_fact_collector.STRIP_QUOTES is not \'\''


# Generated at 2022-06-25 00:13:25.568101
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector = LSBFactCollector()
    lsb_fact_collector.collect()

# Generated at 2022-06-25 00:13:30.590820
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()

    # Testing concept of initializing own class
    obj = LSBFactCollector()
    obj = LSBFactCollector()
    obj = LSBFactCollector()

    ret_val = obj.collect()
    pass

# Generated at 2022-06-25 00:13:33.906908
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  my_lsb_fact_collector = LSBFactCollector()
  my_lsb_fact_collector.collect()

# Generated at 2022-06-25 00:13:36.604134
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()



# Generated at 2022-06-25 00:13:42.090706
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    print(l_s_b_fact_collector_0)
    #assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:13:42.594830
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass

# Generated at 2022-06-25 00:13:43.979910
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Test for method collect of class LSBFactCollector

# Generated at 2022-06-25 00:13:46.182291
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    # noinspection PyUnusedLocal
    l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:47.267917
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:56.115855
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()

# Generated at 2022-06-25 00:13:58.167566
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:01.522635
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # TODO
    pass


# Generated at 2022-06-25 00:14:03.000025
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()


# Generated at 2022-06-25 00:14:04.699857
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()
    assert l_s_b_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:14:12.220827
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    dict_0 = dict()

    import ansible_module_utils.basic
    import ansible_module_utils.facts.collector

    from ansible_module_utils.facts.collector import BaseFactCollector

    class TestModule:
        def run_command(self, arg1, arg2):
            pass

        def get_bin_path(self, arg1):
            return ''

    test_module = TestModule()

    def test_ansible_module_utils_basic_run_command(arg1, arg2):
        pass

    ansible_module_utils_basic_run_command_result_0 = { 'cmd': 5 }
    ansible_module_utils_basic_run_command_result = ansible_module_utils_

# Generated at 2022-06-25 00:14:15.377897
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    var_1 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:16.065135
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:14:18.881163
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # TBD: Implement this test
    assert True


# Generated at 2022-06-25 00:14:21.061036
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert(l_s_b_fact_collector_0.collect())

# Generated at 2022-06-25 00:14:35.391562
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert 'lsb' in LSBFactCollector().collect()


# Generated at 2022-06-25 00:14:42.785459
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    etc_lsb_release_location = '/etc/lsb-release'
    lsb_path = 'lsb_release'
    l_s_b_fact_collector_0 = LSBFactCollector()
    # create mock module, get_bin_path
    mock_module = MockModule()
    mock_module.get_bin_path = MagicMock(return_value=lsb_path)
    # mock_module.get_bin_path.return_value = lsb_path
    # create mock module, run_command
    out = mock_module_lsb_out
    err = mock_module_lsb_err
    rc = 0
    mock_module.run_command = MagicMock(return_value=(rc, out, err))
    # mock_module.run_command.return_value = rc,

# Generated at 2022-06-25 00:14:44.939771
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:14:47.415716
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:14:49.536121
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()



# Generated at 2022-06-25 00:14:50.903383
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:14:52.934958
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_1, LSBFactCollector)


# Generated at 2022-06-25 00:14:56.008743
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:58.109366
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:59.783794
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:15:29.104300
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:31.452702
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector()


# Generated at 2022-06-25 00:15:33.521443
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    module = AnsibleModule({})
    lsb_fact_collector = LSBFactCollector()
    result = lsb_fact_collector.collect(module=module)
    assert "lsb" in result.keys()

# Generated at 2022-06-25 00:15:38.287732
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    # Check if facts_dict  is None
    assert l_s_b_fact_collector_0.facts_dict is not None
    # Check if name of collector equal to lsb
    assert l_s_b_fact_collector_0.name == 'lsb'


# Generated at 2022-06-25 00:15:40.350272
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:42.194331
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_3 = LSBFactCollector()


# Generated at 2022-06-25 00:15:45.258855
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_1.collect()


# Generated at 2022-06-25 00:15:47.487271
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    l_s_b_fact_collector_1 = LSBFactCollector()
    assert l_s_b_fact_collector_1.collect() is None

# Generated at 2022-06-25 00:15:48.389904
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:50.916052
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    # Test if class LSBFactCollector is available.
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:16:52.208278
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:16:56.006551
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_1 = LSBFactCollector()
    dict_0 = lsb_fact_collector_1.collect()
    assert True




# Generated at 2022-06-25 00:17:05.146567
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    f = float(randint(1, 1))
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    print("Required total_steps")
    print("Required image_url")
    print("Required image_name")
    print("Required name")
    print("Required details")
    print("Required id")
    print("Required steps")
    print("Required total_steps")
    print("Required image_url")
    print("Required name")
    print("Required details")
    print("Required image_name")
    print("Required steps")
    print("Required id")



# Generated at 2022-06-25 00:17:07.819900
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_2 = LSBFactCollector()
    var_2 = l_s_b_fact_collector_2.collect()


# Generated at 2022-06-25 00:17:11.014856
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect({'get_bin_path': test_case_0})
    assert var_1 == {'lsb': {}}


# Generated at 2022-06-25 00:17:15.383231
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    collected_facts_1 = {}
    var_1 = l_s_b_fact_collector_1.collect(module=None,
                                           collected_facts=collected_facts_1)
    if var_1 is None:
        print('Module not returning a dictionary!')

if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:17:20.190843
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  try:
    test_case_0()
  except Exception as e:
    traceback.print_exc()
    return False
  else:
    return True

# Main function
if __name__ == '__main__':
  res = test_LSBFactCollector()
  if res:
    print('OK')
  else:
    print('Failed')
  sys.exit(res)

# Generated at 2022-06-25 00:17:20.733526
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert True

# Generated at 2022-06-25 00:17:24.584530
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()


LSBFactCollector.test_case_0 = test_case_0
LSBFactCollector.test_LSBFactCollector_collect = test_LSBFactCollector_collect

# Generated at 2022-06-25 00:17:28.592287
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()
    l_s_b_fact_collector_1.collect()



# Generated at 2022-06-25 00:20:01.637341
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert not l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:20:03.121462
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()

# Generated at 2022-06-25 00:20:04.372771
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()
    assert True

# Generated at 2022-06-25 00:20:08.301356
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  l_s_b_fact_collector = LSBFactCollector()
  assert l_s_b_fact_collector is not None


# Generated at 2022-06-25 00:20:12.749972
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() == None


# Generated at 2022-06-25 00:20:18.112055
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    # No input
    var_1 = lsb_fact_collector_0.collect()

if __name__ == "__main__":
    # Unit test this module
    test_case_0()

# Generated at 2022-06-25 00:20:22.788533
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:20:24.801899
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:20:28.624133
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb', "Test failed: test_LSBFactCollector()"
    assert LSBFactCollector._fact_ids.__class__.__name__ == 'set', "Test failed: test_LSBFactCollector()"
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\', "Test failed: test_LSBFactCollector()"


# Generated at 2022-06-25 00:20:34.977321
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()

if __name__ == "__main__":
    import sys
    import ctypes
    import inspect

    # From http://stackoverflow.com/questions/279237/python-import-a-module-from-a-folder
    cmd_subfolder = os.path.realpath(os.path.abspath(os.path.join(os.path.split(inspect.getfile(inspect.currentframe()))[0], "../ansible")))
    if cmd_subfolder not in sys.path:
        sys.path.insert(0, cmd_subfolder)

    # Import shared memmory