

# Generated at 2022-06-25 00:13:27.999219
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0 != None
# Unit test to check l_s_b_fact_collector_0._fact_ids
    assert l_s_b_fact_collector_0._fact_ids == set()
# Unit test to check _get_lsb_release_bin
    l_s_b_fact_collector_0._get_lsb_release_bin()
# Unit test to check _get_lsb_release_file
    l_s_b_fact_collector_0._get_lsb_release_file()
# Unit test to check collect
    assert l_s_b_fact_collector_0.collect() == {}
# Unit test to check name
    assert l_s

# Generated at 2022-06-25 00:13:32.474103
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # from ansible.module_utils.facts.collector.lsb import LSBFactCollector
    l_s_b_fact_collector = LSBFactCollector()



# Generated at 2022-06-25 00:13:35.812715
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_1.collect()

# Generated at 2022-06-25 00:13:42.638521
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    expected_result_0 = None
    result_0 = l_s_b_fact_collector_0.collect(module=None,
                                              collected_facts=None)
    assert result_0 == expected_result_0


# Generated at 2022-06-25 00:13:48.814896
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Mock class arguments
    args = {'lsb': {'description': 'Red Hat Enterprise Linux Server release 7.2 (Maipo)', 'codename': 'Maipo', 'id': 'RedHatEnterpriseServer', 'major_release': '7', 'release': '7.2'}}
    LSBFactCollector_instance = LSBFactCollector()
    args.update({'lsb': {'description': 'Red Hat Enterprise Linux Server release 7.2 (Maipo)', 'codename': 'Maipo', 'id': 'RedHatEnterpriseServer', 'major_release': '7', 'release': '7.2'}})

    # Invoke method
    answer = LSBFactCollector_instance.collect(**args)
    assert answer == args



# Generated at 2022-06-25 00:13:51.854294
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_3 = LSBFactCollector()
    assert l_s_b_fact_collector_3._fact_ids == set()

# Generated at 2022-06-25 00:14:01.505917
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert l_s_b_fact_collector_1._fact_ids == {'lsb'}, "Expected value is {'lsb'}, Actual value is %s" % repr(l_s_b_fact_collector_1._fact_ids)
    assert l_s_b_fact_collector_1.name == 'lsb', "Expected value is 'lsb', Actual value is %s" % repr(l_s_b_fact_collector_1.name)


# Generated at 2022-06-25 00:14:04.526184
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_1 = LSBFactCollector()
    l_s_b_fact_collector_1.collect()



# Generated at 2022-06-25 00:14:04.997525
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:14:09.001576
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:14:18.808271
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:23.815553
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'

# Generated at 2022-06-25 00:14:31.700819
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    result_collect_0 = lsb_fact_collector_0.collect()  # TODO parametrize
    assert result_collect_0['lsb']['id'] == 'Ubuntu'
    assert result_collect_0['lsb']['release'] == '16.04'
    assert result_collect_0['lsb']['codename'] == 'Xenial'
    assert result_collect_0['lsb']['description'] == 'Ubuntu 16.04.3 LTS'
    result_collect_1 = lsb_fact_collector_0.collect()  # TODO parametrize
    assert result_collect_1['lsb']['id'] == 'Ubuntu'

# Generated at 2022-06-25 00:14:35.855954
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    x = LSBFactCollector()
    assert isinstance(x, LSBFactCollector)
    assert x.name == "lsb"
    assert x.collect() is not None


# Generated at 2022-06-25 00:14:36.981978
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector = LSBFactCollector()

# Generated at 2022-06-25 00:14:37.779405
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:14:40.849909
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()


if __name__ == "__main__":
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:14:43.661712
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() == {'lsb': {'id': 'Ubuntu', 'release': '18.04', 'description': 'Ubuntu 18.04.4 LTS', 'major_release': '18'}}

# Generated at 2022-06-25 00:14:49.750180
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert callable(l_s_b_fact_collector_0.collect)


if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector()

# Generated at 2022-06-25 00:14:52.483052
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    var_0 = lsb_fact_collector_0.collect()
    assert len(var_0) == 1
    assert var_0['lsb'].keys() == set(['id', 'release', 'description', 'major_release', 'codename'])

test_case_0()

# Generated at 2022-06-25 00:15:06.465002
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:12.557070
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    module_0 = MagicMock()
    module_0.run_command.return_value = (0, "LSB Version:\tcore-4.1-amd64:core-4.1-noarch\nDistributor ID:\tCentOS\nDescription:\tCentOS Linux release 7.5.1804 (Core)\nRelease:\t7.5.1804\nCodename:\tCore", None)
    var_0 = lsb_fact_collector_0.collect(module=module_0)

# Generated at 2022-06-25 00:15:18.649805
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    #
    # Default test to validate the constructor
    #
    l_s_b_fact_collector_0 = LSBFactCollector()
    if isinstance(l_s_b_fact_collector_0, LSBFactCollector):
        pass
    else:
        raise AssertionError('Unable to create an object of class LSBFactCollector')

# Generated at 2022-06-25 00:15:30.274512
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # Test that the LSBFactCollector.collect method behaves as expected
    # when lsb_release and /etc/lsb-release are absent on the system
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0._lsb_release_bin_0 = mock.Mock(return_value={})
    l_s_b_fact_collector_0._lsb_release_file_0 = mock.Mock(return_value={})
    var_0 = l_s_b_fact_collector_0.collect()
    assert var_0 == {'lsb': {}}

    # Test that the LSBFactCollector.collect method behaves as expected
    # when /etc/lsb-release is present on the system
    l_s

# Generated at 2022-06-25 00:15:32.863103
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector = LSBFactCollector()
    var_1 = l_s_b_fact_collector.collect()



# Generated at 2022-06-25 00:15:38.623189
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    lsb_release_bin_0 = LSBFactCollector._lsb_release_bin(l_s_b_fact_collector_0, 'lsb_path', module='module')
    lsb_release_file_0 = LSBFactCollector._lsb_release_file(l_s_b_fact_collector_0, 'etc_lsb_release_location')
    facts_dict_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:39.496563
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:15:45.955527
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect('./module_utils/facts/lsb_release.py', './module_utils/facts/lsb_release.py')


if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:15:48.594002
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_1, LSBFactCollector) == True


# Generated at 2022-06-25 00:15:49.127023
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:16:19.011781
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    from ansible.module_utils.facts.collector import LSBFactCollector
    from ansible.module_utils.facts.utils import BaseFactCollector

    l_s_b_fact_collector_1 = LSBFactCollector()
    assert(isinstance(l_s_b_fact_collector_1, BaseFactCollector))

    l_s_b_fact_collector_2 = LSBFactCollector(
        name = 'lsb', _fact_ids = set()
    )
    assert(l_s_b_fact_collector_2._fact_ids is set())

# Generated at 2022-06-25 00:16:22.705380
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()

    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:16:24.268930
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:16:25.257677
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_1 = LSBFactCollector()

# Generated at 2022-06-25 00:16:26.087175
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector


# Generated at 2022-06-25 00:16:27.166704
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert not 'lsb' in LSBFactCollector.__dict__


# Generated at 2022-06-25 00:16:31.053458
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:16:33.843938
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert l_s_b_fact_collector_1.name == 'lsb'
    assert l_s_b_fact_collector_1.STRIP_QUOTES == '\'\"\\'


# Generated at 2022-06-25 00:16:37.128994
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:42.627853
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()

    class ModuleStub():
        pass

    module_stub_1 = ModuleStub()
    module_stub_1.get_bin_path = lambda x: 'foo'

    class SubprocessStub():
        CalledProcessError = None

    module_stub_1.run_command = lambda x, y: (0, '', '')

    var_1 = l_s_b_fact_collector_1.collect(module=module_stub_1)
    assert var_1 == {
        'lsb': {
        }
    }

    module_stub_2 = ModuleStub()
    module_stub_2.get_bin_path = lambda x: 'foo'


# Generated at 2022-06-25 00:17:45.357914
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector() is not None


# Generated at 2022-06-25 00:17:48.493240
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert True

# Generated at 2022-06-25 00:17:50.861451
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert (l_s_b_fact_collector_0 != None)



# Generated at 2022-06-25 00:17:56.627512
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:17:59.742216
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()



# Generated at 2022-06-25 00:18:02.570969
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert var_0 is not None


# Generated at 2022-06-25 00:18:03.463714
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_0 = LSBFactCollector()


# Generated at 2022-06-25 00:18:08.372760
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_0 = LSBFactCollector()
    var_0 = lsb_fact_collector_0.collect()
    print(var_0)
    assert var_0 is not None
    print ("Success")

if __name__ == "__main__":
    test_case_0()
    test_LSBFactCollector_collect()
    test_case_0()

# Generated at 2022-06-25 00:18:13.467163
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
  if not os.path.exists("/usr/bin/lsb_release"):
    import pytest
    pytest.skip("skipping lsb_release unit tests")

  lsb_fact_collector = LSBFactCollector()
  lsb_fact_collector.collect()
  lsb = lsb_fact_collector.ansible_facts['lsb']
  assert lsb['id'] == 'Debian'
  assert lsb['release'] == '9.5'



# Generated at 2022-06-25 00:18:17.497723
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

if __name__ == '__main__':
    test_lsb_facts_class()

# Generated at 2022-06-25 00:20:45.760239
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:20:47.564742
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.__class__ == LSBFactCollector


# Generated at 2022-06-25 00:20:49.574599
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
  lsb_fact_collector = LSBFactCollector()

test_case_0()

# Generated at 2022-06-25 00:20:54.784129
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    target_0 = LSBFactCollector()
    module_0 = LSBFactCollector()
    collected_facts_0 = set()
    var_0 = l_s_b_fact_collector_0.collect(module_0, collected_facts_0)

# Generated at 2022-06-25 00:20:57.681445
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except:
        assert False

if __name__ == '__main__':
    test_LSBFactCollector()

# Generated at 2022-06-25 00:20:59.730141
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    func = LSBFactCollector()
    assert func is not None, "Method \"LSBFactCollector\" class \"LSBFactCollector\" not was not created."


# Generated at 2022-06-25 00:21:04.240462
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsbFC = LSBFactCollector()
    lsbFC.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:21:05.434902
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

if __name__ == '__main__':
    print(__doc__)

# Generated at 2022-06-25 00:21:07.519798
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:21:11.431213
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
