

# Generated at 2022-06-25 00:13:14.937499
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
 

# Generated at 2022-06-25 00:13:15.311064
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:13:17.369833
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:13:19.982188
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector.collect()


# Generated at 2022-06-25 00:13:22.561285
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-25 00:13:25.382054
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:13:29.640853
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_collector = LSBFactCollector()
    assert lsb_collector.collect() == {'lsb': {}}

# Generated at 2022-06-25 00:13:32.854199
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:13:35.766894
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:13:41.099346
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0


# Generated at 2022-06-25 00:13:52.111699
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    var_0 = LSBFactCollector()
    assert isinstance(var_0, LSBFactCollector)
    assert var_0.name == 'lsb'
    assert var_0.STRIP_QUOTES == '\'\"\\'

# Generated at 2022-06-25 00:13:57.641086
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    try:
        l_s_b_fact_collector_0 = LSBFactCollector()
        var_0 = l_s_b_fact_collector_0.collect()
    except Exception:
        assert False


# Generated at 2022-06-25 00:14:03.109520
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-25 00:14:07.764628
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_case = test_case_0()


# Generated at 2022-06-25 00:14:11.479879
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():

    # Arrange
    from ansible.module_utils.facts import collector

    # Stub out Collector.collect
    collector.Collector.collect = lambda self: 'collector stub'

    # Act
    l_s_b_fact_collector = LSBFactCollector()
    result = l_s_b_fact_collector.collect()

    # Assert
    assert result == 'collector stub'


#TODO: Add more tests

# Generated at 2022-06-25 00:14:12.095677
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass


# Generated at 2022-06-25 00:14:20.768920
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0._lsb_release_file()

    # unit test for method '_lsb_release_bin' of class LSBFactCollector
    def test_lsb_release_bin():
        pass

    # unit test for method 'collect' of class LSBFactCollector
    def test_collect():
        pass

    # unit test for method '_lsb_release_file' of class LSBFactCollector
    def test_lsb_release_file():
        pass

    test_lsb_release_bin()
    test_collect()
    test_lsb_release_file()

# Generated at 2022-06-25 00:14:23.091682
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_1, LSBFactCollector)


# Generated at 2022-06-25 00:14:26.218523
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

test_case_0()
test_LSBFactCollector_collect()

# Generated at 2022-06-25 00:14:28.051118
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:14:40.635725
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    LSBFactCollector()


# Generated at 2022-06-25 00:14:44.504069
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_0.collect()
    assert var_1 == {'lsb': {'codename': 'tara',
                             'description': 'Linux Mint 19 Tara',
                             'id': 'LinuxMint',
                             'major_release': '19',
                             'release': '19'}}, var_1



# Generated at 2022-06-25 00:14:49.464189
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Case 0
    l_s_b_fact_collector_0 = LSBFactCollector()
    # Case 1
    l_s_b_fact_collector_1 = LSBFactCollector()


# Generated at 2022-06-25 00:14:54.277803
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.__name__ == "LSBFactCollector"

    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.name == "lsb"
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'

    assert l_s_b_fact_collector_0.collect() == {}


# Generated at 2022-06-25 00:14:56.793209
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert l_s_b_fact_collector_0.collect() == "successful"

# Generated at 2022-06-25 00:14:58.258859
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    var_0 = LSBFactCollector()
    assert var_0._fact_ids == set()



# Generated at 2022-06-25 00:14:59.118062
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:02.277039
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_0, LSBFactCollector)
    # var_0 = l_s_b_fact_collector_0._lsb_release_bin('/usr/bin/lsb_release')
    # var_1 = l_s_b_fact_collector_0._lsb_release_file('/etc/lsb-release')
    # var_2 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:04.416507
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:05.521602
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

# Generated at 2022-06-25 00:15:19.350658
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
# for debug
    l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:21.054015
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector


# Generated at 2022-06-25 00:15:30.886755
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    import random
    import string

    def randomword(max_length):
        length = random.randint(1, max_length)
        return ''.join(random.choice(string.lowercase) for i in range(length))

    l_s_b_fact_collector_0 = LSBFactCollector()
    assert_equal(l_s_b_fact_collector_0.name, 'lsb')

    # Test the random number is generated correctly
    assert_equal(l_s_b_fact_collector_0._fact_ids, set())
    # Test _lsb_release_bin
    l_s_b_fact_collector_0._lsb_release_bin('/usr/bin/lsb_release -a', 'ansible.module_utils.facts.collector.BaseFactCollector')

# Generated at 2022-06-25 00:15:32.405709
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # TODO: implement test_LSBFactCollector_collect
    assert True


# Generated at 2022-06-25 00:15:34.651027
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Ensures that the instance of the class LSBFactCollector is created
    assert LSBFactCollector()


# Generated at 2022-06-25 00:15:35.771802
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert (LSBFactCollector() is not None)



# Generated at 2022-06-25 00:15:38.342619
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    if var_0['lsb']['release'] == '16.04':
        print(True)
    else:
        print(False)

test_case_0()
test_LSBFactCollector()

# Generated at 2022-06-25 00:15:38.842707
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert True


# Generated at 2022-06-25 00:15:42.340273
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()

test_case_0()
test_LSBFactCollector()

# Generated at 2022-06-25 00:15:44.456484
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    print("Run test_LSBFactCollector")
    test_case_0()


# Generated at 2022-06-25 00:16:11.928628
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:16:17.454274
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()
    assert var_1 == {u'lsb': {'major_release': '7', 'release': '7.4', 'id': 'CentOS', 'codename': 'Core', 'description': 'CentOS Linux release 7.4.1708 (Core)'}}



if __name__ == "__main__":
    import sys
    import pytest

    pytest.main([sys.argv[0]])

# Generated at 2022-06-25 00:16:18.896774
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    assert True
# vim: set tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 00:16:19.774725
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:16:21.776308
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # get the facts of the system
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:16:24.648760
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name is not None
    assert LSBFactCollector._fact_ids is not None


if __name__ == '__main__':
    test_LSBFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:16:31.616127
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0._lsb_release_bin = lambda a, b: (None)
    l_s_b_fact_collector_0._lsb_release_file = lambda a: (None)
    var_1 = l_s_b_fact_collector_0.collect()
    assert var_1 == {}

# Generated at 2022-06-25 00:16:32.806076
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:16:36.832578
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # Test whether the following are handled properly
    # 1. Without arguments
    # 2. With arguments

    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:16:39.105365
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()


# Generated at 2022-06-25 00:17:44.595803
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    l_s_b_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:17:50.033187
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    lsb_fact_collector_1 = LSBFactCollector()
    lsb_fact_collector_1.collect()


# Generated at 2022-06-25 00:17:52.567021
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:54.331040
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    pass

if __name__ == '__main__':
    print('no unit tests for this module')

# Generated at 2022-06-25 00:17:57.247842
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    # arrange
    l_s_b_fact_collector_0 = LSBFactCollector()

    # act
    var_0 = l_s_b_fact_collector_0.collect()

    # assert
    expected_value_0 = {'lsb': {}}
    assert var_0 == expected_value_0

# Generated at 2022-06-25 00:18:01.808951
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    # When tested without any additional parametes
    l_s_b_fact_collector_1 = LSBFactCollector()

    assert isinstance(l_s_b_fact_collector_1, LSBFactCollector)



# Generated at 2022-06-25 00:18:04.089660
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    try:
        test_case_0()
    except Exception as e:
        raise IOError(e)
    else:
        print("Success")

# Generated at 2022-06-25 00:18:10.436226
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()
    assert isinstance(l_s_b_fact_collector_0, LSBFactCollector)
    assert l_s_b_fact_collector_0.name == 'lsb'
    assert l_s_b_fact_collector_0._fact_ids == set()
    assert l_s_b_fact_collector_0.STRIP_QUOTES == r'\'\"\\'


# Generated at 2022-06-25 00:18:11.686417
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:18:13.475963
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_0 = LSBFactCollector()


# Generated at 2022-06-25 00:20:46.349540
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()


# Generated at 2022-06-25 00:20:46.780092
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    pass

# Generated at 2022-06-25 00:20:48.431659
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()



# Generated at 2022-06-25 00:20:51.603965
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert var_0 == {'lsb': {}}


# Generated at 2022-06-25 00:20:53.376634
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    lsb_fact_collector0 = LSBFactCollector()


# Generated at 2022-06-25 00:21:03.512761
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    if os.path.exists("/etc/lsb-release"):
        lsb_file = "/etc/lsb-release"
    else:
        lsb_file = "/etc/lsb_release"

    out = get_file_lines(lsb_file)
    lsb_info = {}
    for line in out:
        value = line.split('=', 1)[1].strip()
        if 'DISTRIB_ID' in line:
            lsb_info['id'] = value
        elif 'DISTRIB_RELEASE' in line:
            lsb_info['release'] = value
        elif 'DISTRIB_DESCRIPTION' in line:
            lsb_info['description'] = value

# Generated at 2022-06-25 00:21:08.909229
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():

    # Check if constructor returns an object of LSBFactCollector
    assert type(LSBFactCollector()) == LSBFactCollector
    # Check if name field of constructed object is populated correctly 
    assert LSBFactCollector().name == 'lsb'
    # Check if _fact_ids field of constructed object is populated correctly
    # Assert the _fact_ids field of __init__ function return is empty
    assert not LSBFactCollector()._fact_ids
    assert type(LSBFactCollector()._fact_ids) == set



# Generated at 2022-06-25 00:21:11.871293
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    assert LSBFactCollector.name == 'lsb'
    assert LSBFactCollector._fact_ids == set()
    assert LSBFactCollector.STRIP_QUOTES == "'\"\\"

# Generated at 2022-06-25 00:21:14.203175
# Unit test for constructor of class LSBFactCollector
def test_LSBFactCollector():
    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect()


# Generated at 2022-06-25 00:21:17.424236
# Unit test for method collect of class LSBFactCollector
def test_LSBFactCollector_collect():
    l_s_b_fact_collector_0 = LSBFactCollector()
    var_0 = l_s_b_fact_collector_0.collect()
    assert var_0 == {'lsb': {}}

    l_s_b_fact_collector_1 = LSBFactCollector()
    var_1 = l_s_b_fact_collector_1.collect(module=None)
    assert var_1 == {'lsb': {}}
