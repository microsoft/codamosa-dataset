

# Generated at 2022-06-21 22:07:49.005527
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return cls.__name__

    a = A()
    a.x = 1
    assert a.x != 1
    assert a.x == 'A'
    assert A.x == 'A'



# Generated at 2022-06-21 22:07:59.327110
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:08:01.784083
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass():
        @lazyclassproperty
        def theprop(cls):
            print("Running")
            return 5

    assert MyClass.theprop == 5
    assert MyClass.theprop == 5


# Generated at 2022-06-21 22:08:07.271255
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        # Lazy class property.
        @lazyclassproperty
        def func(cls):
            print('Function func instantiated.')
            return 'Hello'

    # Get class property.
    s = MyClass.func
    # Get class property again.
    s = MyClass.func
    assert s == 'Hello'



# Generated at 2022-06-21 22:08:14.832847
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class data(object):
        @lazyclassproperty
        def dict(cls):
            print('init dict')
            return {}

    @classproperty
    def dict(cls):
        print('init dict')
        return {'a': 'abc'}

    class data(object):
        dict = dict

    print(data.dict)
    print(data.dict)
    print('-'*50)
    print(data().dict)
    print(data().dict)



# Generated at 2022-06-21 22:08:20.258875
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 1
    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return 2
    class C(A):
        pass
    assert A.foo == 1
    assert B.foo == 2
    assert C.foo == 1


# Generated at 2022-06-21 22:08:30.450490
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty.
    """
    import types
    import logging

    class A(object):
        logger = logging.getLogger()

        def __init__(self):
            self._log_level = logging.INFO

        def get_log_level(self):
            return self._log_level

        def set_log_level(self, value):
            self._log_level = value
            self.logger.setLevel(value)

        log_level = setterproperty(fset=set_log_level, fget=get_log_level)

    a = A()
    assert a.log_level == logging.INFO
    a.log_level = logging.WARNING
    assert a.log_level == logging.WARNING
    assert a._log_level == logging.WARNING

# Generated at 2022-06-21 22:08:41.659851
# Unit test for constructor of class setterproperty
def test_setterproperty():
    test_calls = []

    class Test(object):
        def __init__(self):
            self.v = 0

        @setterproperty
        def inc_v(self, value):
            test_calls.append(('obj', self.v))
            self.v += value

    with raises(TypeError, match='incorrect number of arguments'):  # missing the value argument
        Test.inc_v()

    with raises(TypeError, match='incorrect number of arguments'):  # too many arguments
        Test.inc_v(1, 1)

    with raises(TypeError, match='is not writable'):
        Test.inc_v = 2

    test_instance = Test()
    test_instance.inc_v = 1
    assert test_calls == [('obj', 0)]

# Generated at 2022-06-21 22:08:50.217296
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def foo(cls):
        return 'foo of {0}'.format(cls.__name__)
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'foo of A'
    assert B.foo == 'foo of B'
    assert C.foo == 'foo of C'



# Generated at 2022-06-21 22:08:56.139968
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:09:07.603607
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
        Unit test for class lazyclassproperty.
    """
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('called')
            return 'foo in class A'

    class B(A):
        @lazyclassproperty
        def bar(cls):
            return 'bar in class B'

        @lazyclassproperty
        def goo(cls):
            return 'goo in class B'

    class C(B):
        @lazyclassproperty
        def boo(cls):
            return 'boo in class C'

        @lazyclassproperty
        def goo(cls):
            return 'goo in class C'

    assert A.foo == 'foo in class A'
    assert B.foo == 'foo in class A'


# Generated at 2022-06-21 22:09:17.600814
# Unit test for constructor of class setterproperty
def test_setterproperty():
    import common.cachedproperty
    import common.classproperty
    import base.permissions

    class Test(object):
        def __init__(self, value):
            self.value = value

        @common.cachedproperty.cachedproperty
        def value_read_only(self):
            return self.value

        @common.classproperty.setterproperty
        def value_only_write(self, value):
            self.value = value

        # Test that we can read and write the value
        @base.permissions.setterproperty
        def value_read_and_write(self, value):
            self.value_only_write = value

    test = Test(1)
    # Check that we can read the value
    assert test.value_read_only == 1

    # Check that we can't write the value, shouldn't

# Generated at 2022-06-21 22:09:20.953518
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 1

    assert C.x == 1
    c = C()
    assert c.x == 1



# Generated at 2022-06-21 22:09:25.489817
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self.value = None

        @setterproperty
        def setter_prop(self, value):
            self.value = value

    c = C()
    assert c.value is None

    c.setter_prop = 5
    assert c.value == 5
    assert c.setter_prop is None



# Generated at 2022-06-21 22:09:29.486030
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def getx(self):
            return self._x
        def setx(self, value):
            self._x = value
        x = setterproperty(setx, getx.__doc__)

    obj = Foo()
    obj.x = 3
    assert obj.x == 3, obj.x



# Generated at 2022-06-21 22:09:36.016285
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        __doc__ = "foo bar"
        def __init__(self, x):
            self._x = x
        def _get(self):
            return self._x
        def _set(self, x):
            self._x = x
        x = setterproperty(_get, _set)
    c = C(10)
    c.x = 20
    assert c._x == 20
    assert c.x == 20
    c.x = c.x + c.x + c.x
    assert c._x == 80
    assert c.x == 80
    assert C.__doc__ == "foo bar"
    assert C.x.__doc__ == "foo bar"



# Generated at 2022-06-21 22:09:38.152258
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, a):
            self.a = a

        @setterproperty
        def x(self, value):
            self.a = value

    test = Test(3)
    test.x = 5
    assert test.a == 5



# Generated at 2022-06-21 22:09:43.143281
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class A(object):

        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, value):
            self._x = value

    a = A()
    assert a.x == 0
    a.x = 1
    assert a.x == 1
    a.x = 2
    assert a.x == 2


if __name__ == "__main__":

    test_setterproperty()

# Generated at 2022-06-21 22:09:49.778542
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def val(cls):
            print("A.val")
            return "foo"
        pass

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def val(cls):
            print("C.val")
            return "bar"
        pass

    class D(B, C):
        pass

    assert A.val == "foo"
    assert B.val == "foo"
    assert C.val == "bar"
    assert D.val == "bar"



# Generated at 2022-06-21 22:09:54.544205
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        x = 3

        def __init__(self):
            self.x = 5

        @setterproperty
        def y(self, value):
            self.x = value

    a = A()
    assert a.x == 5
    a.y = 7
    assert a.x == 7
    a.z = 9
    assert a.z == 9

# Generated at 2022-06-21 22:10:02.527772
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls.__name__


# Generated at 2022-06-21 22:10:08.334535
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.__b = 0

        @setterproperty
        def a(self, value):
            self.__b = value
            return None

        @setterproperty
        def b(self):
            return self.__b

    a = A()

    assert a.a == 0
    assert a.b == 0

    a.a = 1
    assert a.a == 0
    assert a.b == 1



# Generated at 2022-06-21 22:10:12.691395
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def get_name(cls):
            return cls.__name__
    class B(A):
        def __init__(self):
            pass
    b=B()

    assert(b.get_name == 'B')
    assert(B.get_name == 'B')
    assert(A.get_name == 'A')


# Generated at 2022-06-21 22:10:18.017052
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def myattribute(self):
            return self.__class__.__name__

    class Inh1(Base):
        pass

    class Inh2(Base):
        pass

    assert Inh1().myattribute == 'Inh1'
    assert Inh2().myattribute == 'Inh2'

# Generated at 2022-06-21 22:10:21.075838
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return 1
    assert A.a == 1

    class B(A):
        pass
    assert B.a == 1
    assert B().a == 1


# Generated at 2022-06-21 22:10:26.433840
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):

        def __init__(self):
            self.x = 100

        @roclassproperty
        def y(cls):
            return 42

    # Class property can be read before instance creation
    assert A.y == 42

    # Class property cannot be written
    with pytest.raises(AttributeError):
        A.y = 50

    # Class property cannot be written after instance creation
    a1 = A()
    with pytest.raises(AttributeError):
        a1.y = 50


# Generated at 2022-06-21 22:10:28.668576
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, x):
            self._x = x

    t = Test()
    t.x = "test"
    assert t._x == "test"


# Generated at 2022-06-21 22:10:32.681523
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):
        @setterproperty
        def mysetter(self, value):
            self._mysetter = value

    myobj = MyClass()
    myobj.mysetter = 42
    assert myobj._mysetter == 42

# Generated at 2022-06-21 22:10:42.147503
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestClass(object):
        def __init__(self):
            self.__x = 42
        @setterproperty
        def x(self, value):
            self.__x = value
        @setterproperty
        def y(self, value):
            self.x = value # Just to check if the attribute 'x' is still writable
        def getx(self):
            return self.__x
    t = TestClass()
    t.x = 8
    assert t.getx() == 8, 'attribute x should be 8, it was %d' % (t.getx(),)
    t.y = 16
    assert t.getx() == 16, 'attribute x should be 16, it was %d' % (t.getx(),)



# Generated at 2022-06-21 22:10:46.748155
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self, v):
            self.v = v

        @setterproperty
        def val(self, v):
            self.v = v

    foo = Foo(10)
    foo.val = 20
    assert foo.v == 20

    foo.val = '30'
    assert foo.v == '30'


# Generated at 2022-06-21 22:11:03.579682
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        pass

    assert Foo.__dict__ == {}
    def prop(cls):
        return 42
    roclassproperty(prop)  # no error
    assert Foo.__dict__ == {}

    f1 = Foo()
    f1.__class__.__dict__ == {}
    f2 = Foo()
    f2.__class__.__dict__ == {}
    assert f1.prop is f2.prop is None

    prop = roclassproperty(prop)
    assert Foo.__dict__ == {'prop': prop}
    Foo.prop
    assert Foo.__dict__ == {'prop': 42}
    assert f1.prop is f2.prop is 42

    # f1.prop = 'x'  # raises AttributeError



# Generated at 2022-06-21 22:11:09.237506
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        @roclassproperty
        def method(cls):
            return cls
    assert TestClass is TestClass.method
    # check the descriptor raises an expected exception
    with pytest.raises(AttributeError) as excinfo:
        TestClass().method
    assert 'attribute' in str(excinfo.value)
    assert TestClass is TestClass().method



# Generated at 2022-06-21 22:11:14.212101
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from datetime import datetime

    class ExampleClass:
        def __init__(self):
            self.now = datetime.now()

    @setterproperty
    def now(self, value):
        self._now = value

    eg1 = ExampleClass()
    eg2 = ExampleClass()

    eg1.now = datetime.now()
    print(eg1._now)
    print(eg2._now)


# Generated at 2022-06-21 22:11:17.609076
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def answer(cls):
            return 42
    
    # Test class
    t = Test()
    assert t.answer == 42
    
    # Test inherited class
    class Test2(Test):
        pass
    t2 = Test2()
    assert t2.answer == 42
    assert Test.answer == 42


# Generated at 2022-06-21 22:11:21.831341
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value
    c = C()
    assert c._x == None
    c.x = 42
    assert c._x == 42


# Generated at 2022-06-21 22:11:29.016253
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return "foo"

    assert Foo.__dict__.get("_lazy_foo") is None
    assert Foo.foo == "foo"
    assert Foo.__dict__.get("_lazy_foo") == "foo"

    class Bar(Foo):
        pass

    assert Bar.foo == "foo"
    assert Bar.__dict__.get("_lazy_foo") is None



# Generated at 2022-06-21 22:11:35.378475
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # given
    class foo(object):
        @roclassproperty
        def bar():
            return 'Bar'

    class bar(object):
        @roclassproperty
        def bar():
            return 'Bar'

    class baz(bar):
        pass

    # when
    # then
    assert foo.bar is 'Bar'
    assert bar.bar is 'Bar'
    assert baz.bar is 'Bar'



# Generated at 2022-06-21 22:11:40.318570
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from types import MethodType
    class A(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def incx(self, value):
            self.x += value
            
    a = A()
    assert a.x == 0
    a.incx = 1
    assert a.x == 1
    assert type(a.__dict__['incx']) is MethodType
    a.__dict__['incx'] = 2
    assert a.x == 2
    a.incx = 2
    assert a.x == 4


# Generated at 2022-06-21 22:11:44.418919
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        roclassproperty_f = roclassproperty(lambda cls: cls)

        @classmethod
        def roclassproperty_f_getter(cls):
            return cls

    assertCalled(C.roclassproperty_f_getter, C.roclassproperty_f.__get__(None, C))



# Generated at 2022-06-21 22:11:53.113604
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # No value before assignment
    class A(object):
        a = roclassproperty(classmethod(lambda cls: 'a'))
    assert A.a == 'a'
    a = A()
    assert a.a == 'a'
    # Set a instance value
    a.a = 'b'
    assert a.a == 'b'
    # Class value is still the same
    assert A.a == 'a'

    # Value is set before assignment
    class A(object):
        a = 'a'
        a = roclassproperty(classmethod(lambda cls: 'b'))
    assert A.a == 'b'
    a = A()
    assert a.a == 'b'
    # Set a instance value
    a.a = 'c'
    assert a.a == 'c'
    #

# Generated at 2022-06-21 22:12:18.581532
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class C(object):

        @roclassproperty
        def ro(cls):
            "The ro class property."
            return 1

    # Test the descriptor
    assert C.ro == 1

    c = C()

    # Read-only class property
    try:
        c.ro = 2
    except AttributeError:
        pass
    else:
        raise AssertionError("read-only class property can be set")

    # A subclass can override a read-only property
    class D(C):

        @roclassproperty
        def ro(cls):
            return 2

    assert D.ro == 2

    d = D()

    # But not set it
    try:
        d.ro = 2
    except AttributeError:
        pass

# Generated at 2022-06-21 22:12:23.102147
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        CONST = 'foo'  # This is a class property, not an instance property

        def __init__(self, val):
            self.CONST = val  # This is an instance property

        @roclassproperty
        def bar(cls):
            return Foo.CONST

        def __repr__(self):
            return 'Foo(%r)' % self.CONST

    for cls_or_obj in [Foo, Foo('spam')]:
        assert isinstance(Foo.bar, roclassproperty)
        assert Foo.bar == 'foo'  # uses __get__ method of roclassproperty
        assert cls_or_obj.bar == 'spam'  # uses __get__ method of roclassproperty
        assert 'bar' in dir(Foo)

# Generated at 2022-06-21 22:12:27.121885
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class testClass:
        def func(self, value):
            self.value = value

    obj = testClass()
    setter = setterproperty(obj.func)
    setter.__set__(obj, 5)
    assert_equal(obj.value, 5)


# Generated at 2022-06-21 22:12:38.066965
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('Generating prop')
            return 'the value'

        @lazyclassproperty
        def prop_with_doc(cls):
            return 'the value'
        prop_with_doc.__doc__ = 'A cached property'

    class B(A):
        pass

    assert not hasattr(A, '_lazy_prop')
    assert A.prop == 'the value'
    assert hasattr(A, '_lazy_prop')

    assert not hasattr(B, '_lazy_prop')
    assert B.prop == 'the value'
    assert hasattr(B, '_lazy_prop')

    assert A.prop_with_doc == 'the value'

# Generated at 2022-06-21 22:12:40.093451
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class cls(object):
        pass
    cls.a = roclassproperty(lambda owner: "I'm defined!")
    assert cls.a == "I'm defined!"



# Generated at 2022-06-21 22:12:47.216678
# Unit test for method __set__ of class setterproperty

# Generated at 2022-06-21 22:12:51.440463
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self.prop = '1'

        @setterproperty
        def prop(self, v):
            self._prop = v

    c = C()
    c.prop = '2'
    assert c._prop == '2'

    c.prop = '3'
    assert c._prop == '3'



# Generated at 2022-06-21 22:12:56.515227
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        @setterproperty
        def bar(self, value):
            self._bar = value

    foo = Foo()
    foo.bar = "bar"

# Generated at 2022-06-21 22:13:02.180916
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:13:11.712520
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:13:46.443357
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.__x = None
        @setterproperty
        def x(self, x):
            self.__x = x
        @property
        def x(self):
            return self.__x
    a = A()
    assert a.x == None
    a.x = 5
    assert a.x == 5



# Generated at 2022-06-21 22:13:53.154666
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._a = None

# Generated at 2022-06-21 22:14:03.745134
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazy(cls):
            return 'lazy_A'

        @lazyperclassproperty
        def lazy_initializer(cls):
            return 'lazy_initializer_A'

    class B(A):
        @lazyperclassproperty
        def lazy(cls):
            return 'lazy_B'

    class C(B):
        @lazyperclassproperty
        def lazy_initializer(cls):
            return 'lazy_initializer_C'


# Generated at 2022-06-21 22:14:09.768847
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Zoo(object):
        @lazyperclassproperty
        def name(cls):
            return cls.lower()

    class Dog(Zoo):
        pass

    class Cat(Zoo):
        pass

    assert Dog.name == 'dog'
    assert Cat.name == 'cat'



# Generated at 2022-06-21 22:14:16.394562
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self.__bar = None

        @setterproperty
        def bar(self, value):
            assert 10 <= value <= 20, "value must be between 10 and 20"
            self.__bar = value

    foo = Foo()
    # Should raise exception
    try:
        foo.bar = -10
    except AssertionError:
        pass
    # Should set value
    foo.bar = 10
    assert foo._Foo__bar == 10



# Generated at 2022-06-21 22:14:19.817531
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._a = None
        @setterproperty
        def a(self, value):
            self._a = value
    a = A()
    a.a = 1
    assert(a.a == 1)



# Generated at 2022-06-21 22:14:27.940655
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class LazyTestClass1(object):
    
        @lazyclassproperty
        def computed_value(cls):
            return 10

        @lazyclassproperty
        def another_value(cls):
            return 15

    class LazyTestClass2(object):
    
        @lazyclassproperty
        def computed_value(cls):
            return 20

        @lazyclassproperty
        def another_value(cls):
            return 25

    assert LazyTestClass1.computed_value == 10
    assert LazyTestClass2.computed_value == 20
    assert LazyTestClass1.another_value == 15
    assert LazyTestClass2.another_value == 25


# Generated at 2022-06-21 22:14:34.569563
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test_SetterProperty(object):
        count = 0

        @setterproperty
        def count(self, count):
            Test_SetterProperty.count = count

    test = Test_SetterProperty()
    assert test.count == 0

    test.count = 5
    assert test.count == 5

# Generated at 2022-06-21 22:14:39.236928
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    '''
    test_roclassproperty()
    '''
    class test_class(object):
        def __init__(self):

            self.value = 1

            self.rovalue = 2

        def test_method(self):
            def ro_f(cls):
                return cls.value

            self.ro_f_method = roclassproperty(ro_f)
            return self.ro_f_method

    class test_class_2(test_class):
        def __init__(self):
            self.value = 1

            self.rovalue = 2

        def test_method(self):
            def ro_f_2(cls):
                return cls.value

            self.ro_f_method_2 = roclassproperty(ro_f_2)
            return self.ro_f_method

# Generated at 2022-06-21 22:14:46.877669
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class S(object):

        @setterproperty
        def x(s, value):
            s._x = value**2

        @property
        def x(s):
            return s._x

    s = S()
    s.x = 3
    assert s.x == 9
    s.x = 4
    assert s.x == 16

# Generated at 2022-06-21 22:15:58.351724
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class X(object):
        @setterproperty
        def Y(self, value):
            self._y = value

        def __repr__(self):
            return repr(self._y)

    x = X()
    x.Y = 42
    assert repr(x) == '42'

# Generated at 2022-06-21 22:16:05.224472
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, x):
            self.x = x
        @setterproperty
        def x(self, x):
            if x < 0:
                raise ValueError('Cannot set x to a negative value')
            self._x = x

    c = C(10)
    assert c.x == 10
    c.x = 5
    assert c.x == 5
    try:
        c.x = -5
    except ValueError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-21 22:16:08.958848
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self, a):
            self.a = a
        @roclassproperty
        def ca(cls):
            return cls.__name__
    assert A.ca == 'A'
    a = A(1)
    assert a.ca == 'A'


# Generated at 2022-06-21 22:16:13.580543
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            print('Generating A.a')
            return 'A.a'

    class B(A):
        pass

    class C(B):
        pass

    assert A.a == 'A.a'
    assert B.a == 'A.a'
    assert C.a == 'A.a'



# Generated at 2022-06-21 22:16:16.316983
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 2

        baz = roclassproperty(lambda cls: 3)

    assert Foo.bar == 2
    assert Foo.baz == 3


# Generated at 2022-06-21 22:16:26.811806
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    ## class that has roclassproperty
    class Shape(object):
        @roclassproperty
        def shape(cls):
            return cls.__name__

    def cls_name(cls):
        return cls.__name__

    ## shapename is the same:
    ## - roclassproperty
    ## - regular (read-only) property
    ## - class method
    shapename = Shape.shape
    assert shapename == Shape.shape
    assert shapename == Shape.shape
    assert shapename == cls_name(Shape)

    ## check if read-only property
    ## resulting in AttributeError
    def assign_value_to_roprop(cls):
        cls.shape = 'value for shape'


# Generated at 2022-06-21 22:16:30.921696
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class cls:
        @lazyclassproperty
        def name(cls):
            return 'name'

        @classmethod
        def classmethod(cls):
            return 'classmethod'

    assert cls.name == 'name'
    assert cls.classmethod() == 'classmethod'
    assert cls.name == 'name'
    assert cls.classmethod() == 'classmethod'

# Generated at 2022-06-21 22:16:35.689360
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self._foo = None

        @setterproperty
        def foo(self, value):
            if value > 100:
                raise ValueError('foo value must be <= 100.')

            self._foo = value

    t = Test()

    t.foo = 10
    assert t._foo == 10

    def _test_exception():
        t.foo = 101

    raises(ValueError, _test_exception)

# Generated at 2022-06-21 22:16:44.814763
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:16:48.128268
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, v):
            self._v = v
        @setterproperty
        def setv(self, v):
            self._v = v
    a = A(v=1)
    assert a._v == 1
    a.setv = 2
    assert a._v == 2