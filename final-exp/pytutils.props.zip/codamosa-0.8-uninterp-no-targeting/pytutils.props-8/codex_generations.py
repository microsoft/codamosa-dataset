

# Generated at 2022-06-21 22:07:50.118239
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Testclass(object):
        def __init__(self, attr):
            self.attr = attr

        @roclassproperty
        def test(cls):
            return 'Testclass'

        @classmethod
        def get_test(cls):
            return cls.test

        @staticmethod
        def static_test():
            return Testclass.test

    assert Testclass.get_test() == Testclass.static_test() == Testclass('Test').get_test() == 'Testclass'



# Generated at 2022-06-21 22:07:58.393887
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        foo = roclassproperty(True)
    print('foo:', C.foo)
    # python 2.7, 3.5 does not return a value for __dict__ attribute, but 3.4 does.
    try:
        print('C.__dict__["foo"]:', C.__dict__['foo'])
    except:
        pass
    assert C.foo == True
    # forbidden to assign a value to the property.
    try:
        C.foo = False
        assertFalse('Should have forbidden to assign a value to the property.')
    except AttributeError:
        pass
    # forbidden to assign a value to the prope

# Generated at 2022-06-21 22:08:02.178569
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    a = C()
    b = C()
    print (a.x)
    print (b.x)


# Generated at 2022-06-21 22:08:08.908167
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def _get_bar(self):
            return self._bar

        @lazyclassproperty
        def bar(cls):
            return 'Lazy Value'

        bar = property(_get_bar)

    assert Foo.bar == 'Lazy Value'
    Foo._bar = 'Non-Lazy Value'
    assert Foo.bar == 'Non-Lazy Value'
    assert Foo().bar == 'Non-Lazy Value'
    Foo._bar = 'More Non-Lazy'
    assert Foo.bar == 'More Non-Lazy'



# Generated at 2022-06-21 22:08:20.590212
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import copy
    import inspect

    class Foo:
        @lazyperclassproperty
        def bar(cls):
            return inspect.getmembers(cls, lambda x: x.__name__ in ['baz'])

    class Baz(Foo):
        def baz(self):
            pass

    foo = Foo()
    baz = Baz()
    assert not hasattr(Foo, '_Foo_lazy_bar')
    assert not hasattr(Baz, '_Baz_lazy_bar')
    assert Foo.bar == Baz.bar == [('baz', baz.baz)]
    baz.baz = 10
    Foo.baz = 7
    assert Foo.bar == [('baz', 7)]
    assert Baz.bar == [('baz', 10)]

# Generated at 2022-06-21 22:08:24.150132
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @classproperty
        def myprop(cls):
            return cls

    assert MyClass.myprop is MyClass
    assert MyClass().myprop is MyClass

# Generated at 2022-06-21 22:08:32.612890
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # create parent class
    class A():
        @staticmethod
        def hi():
            return "hi"

        def foo(self):
            return "foo"

        @lazyclassproperty
        def bar(cls):
            return "bar"

        this_is_not_a_property = bar

        @lazyperclassproperty
        def foobar(cls):
            return "foobar"

    # create child class inheriting from class A
    class B(A):
        pass

    # create object for each class
    a = A()
    b = B()

    # check that variables are not set
    assert not hasattr(A, '_lazy_bar')
    assert not hasattr(A, '_B_lazy_foobar')

    # access the lazyperclassproperty value

# Generated at 2022-06-21 22:08:39.815006
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self, a):
            self.a = a

        def func(self, clazz):
            return clazz.__name__ + str(self.a)

        @roclassproperty
        def prop(self):
            return self.func(A)

    assert A(1).prop == 'A1'
    assert A(2).prop == 'A2'



# Generated at 2022-06-21 22:08:42.409050
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def c(cls): return 'c'
    assert C.c == 'c'
    with pytest.raises(AttributeError):
        C().c


# Generated at 2022-06-21 22:08:51.420954
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self._x = None
            pass

        @roclassproperty
        def x(cls):
            return cls._x

        @x.setter
        def x(cls, value):
            cls._x = value

    t = Test()
    assert t.x == None
    Test.x = 5
    assert Test.x == 5
    Test._x = 6
    assert Test.x == 6
    assert t.x == 6


# Generated at 2022-06-21 22:09:02.919945
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        def __init__(self):
            self.x = 2

        @lazyperclassproperty
        def foo(cls):
            print("Running lazy foo")
            return cls(3)

    class Child(Parent):
        def __init__(self, n):
            self.n = n
            super(Child, self).__init__()

    # We should have separate cached values for Parent and Child
    assert Parent(1).foo.n == 3
    assert Child(1).foo.n == 3

    # Same values
    assert Parent().foo is Parent().foo
    assert Child(1).foo is Child(1).foo

    # Different values
    assert Parent().foo is not Child(1).foo
    assert Parent().foo.x == Child(1).foo.x == 2



# Generated at 2022-06-21 22:09:05.674988
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'
    assert A().foo == 'foo'



# Generated at 2022-06-21 22:09:10.021831
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self.bar = 10

        @setterproperty
        def bar(self, value):
            self.__bar = value + 2
            return self.__bar

    f = Foo()
    f.bar = 2
    assert f.bar == 4


# Generated at 2022-06-21 22:09:19.171823
# Unit test for constructor of class setterproperty
def test_setterproperty():
    from collections import namedtuple

    x_attrs = ['x', 'y']

    class MyClass(namedtuple('MyClass', x_attrs)):
        @setterproperty
        def x(self, value):
            self.x = value
    return MyClass


if __name__ == '__main__':
    @lazyclassproperty
    def lazyprop(cls):
        return "lazy_class_property"

    @lazyperclassproperty
    def lazyperprop(cls):
        return "lazy_per_class_property"

    class Test1(object):
        pass

    class Test2(object):
        pass


# Generated at 2022-06-21 22:09:23.412732
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def b(cls):
            return A.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert(A.b == 'A')
    assert(B.b == 'B')
    assert(C.b == 'C')

# Generated at 2022-06-21 22:09:27.804309
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.x = 1

        @lazyperclassproperty
        @lazyperclassproperty
        @lazyperclassproperty
        def test(cls):
            return cls().x

    class B(A):
        pass

    a = A()
    b = B()
    assert a.test == 1
    assert b.test == 1



# Generated at 2022-06-21 22:09:33.529367
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    import pytest
    from soma import exceptions
    from soma.singleton import Singleton

    class TestExample(object):
        @classproperty
        def test_example_classproperty(cls):
            return 'test_example_classproperty'

        @roclassproperty
        def test_example_roclassproperty(cls):
            return 'test_example_roclassproperty'

        @property
        def test_example_property_getter(self):
            return 'test_example_property_getter'

        @property
        def test_example_property_getter_setter(self):
            return 'test_example_property_getter_setter'

        @test_example_property_getter_setter.setter
        def test_example_property_getter_setter(self, value):
            return



# Generated at 2022-06-21 22:09:36.074387
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def x(cls):
            return cls.__name__
    
    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'



# Generated at 2022-06-21 22:09:41.112065
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test that a call to the method __set__ of the class setterproperty
    actually passes the new set value to a setter function previously
    provided
    """
    instance = DummyClass()
    value = "This is a test"
    setterproperty._the_set = None
    setterproperty.__set__(instance, value)
    assert setterproperty._the_set == value



# Generated at 2022-06-21 22:09:44.308872
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class a(object):
        @lazyclassproperty
        def prop(cls):
            print("Lazy evaluation for cls.prop called!")
            return 1

    class b(a):
        pass

    assert a.prop == 1
    assert b.prop == 1
    assert a.prop == 1  # cached

# Generated at 2022-06-21 22:09:48.848165
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def g(cls):
            print("A's g() called")
            return {}

    class B(A):
        pass

    class C(A):
        pass

    assert A.g == A.g
    assert A.g is B.g
    assert A.g is C.g

# Generated at 2022-06-21 22:09:55.875753
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def largest(cls):
            return 'largest'
    assert A.largest == 'largest'
    A.largest = 'smallest'
    assert A.largest == 'smallest'

    class B(A):
        pass
    assert B.largest == 'largest'
    B.largest = 'smallest'
    assert B.largest == 'smallest'

    assert A.largest == 'largest'

lazyclassproperty = lazyclassproperty
lazyperclassproperty = lazyperclassproperty

# Generated at 2022-06-21 22:10:00.072340
# Unit test for constructor of class setterproperty
def test_setterproperty():
    x = 3

    class C(object):
        @setterproperty
        def x(self, value):
            x = self.x * value

    c = C()
    c.x = 2
    assert x == 3


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:10:04.843797
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Dummy(object):
        def foo(cls):
            return cls

        @roclassproperty
        def ro_foo(cls):
            return cls

    assert Dummy.foo() is Dummy
    assert Dummy.foo(object) is object
    assert Dummy.ro_foo is Dummy



# Generated at 2022-06-21 22:10:08.739418
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test1(object):
        i = lazyclassproperty(lambda x: [])

    t1 = Test1()
    t1.i.append(1)
    assert t1.i == [1]

    class Test2(Test1):
        pass

    t2 = Test2()
    assert t2.i == []



# Generated at 2022-06-21 22:10:13.822670
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def a(cls):
            return "A.a"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return "C.a"

    assert A.a == "A.a"
    assert B.a == "A.a"
    assert C.a == "C.a"


# Generated at 2022-06-21 22:10:18.455276
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('bar called')
            return 42

    assert Foo.bar == 42
    assert type(Foo.bar) == int
    assert Foo.bar == 42

    class Baz(Foo):
        pass
    assert Baz.bar == 42



# Generated at 2022-06-21 22:10:26.369489
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    @roclassproperty
    def test_rocp(receiver):
        """
        This is decorator test case 1.
        """
        return receiver.__name__

    class Test_rocp(object):
        """
        This is decorator test case 2.
        """
        test_rocp_class_property = test_rocp

    class Test_rocp2(Test_rocp):
        """
        This is decorator test case 3.
        """
        pass

    print("test_roclassproperty():")
    print("    test_rocp.__doc__: \n\t{}".format(test_rocp.__doc__))
    print("    test_rocp.__name__: \n\t{}".format(test_rocp.__name__))

# Generated at 2022-06-21 22:10:28.800120
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def foo(cls):
            print("foo called")
            return "bar"

    class B(A):
        pass

    assert A.foo == "bar"
    assert B.foo == "bar"
    assert A.foo == "bar"
    assert B.foo == "bar"


# Generated at 2022-06-21 22:10:35.231662
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('Calculating foo')
            return 42

    class B(A):
        pass
    class C(A):
        @classproperty
        def foo(cls):
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-21 22:10:43.593108
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def x(self, value):
            self._x = value

        @x.setter
        def x(self, value):
            self._x = value+1

    obj = C()
    obj.x = 1
    assert obj._x == 2
    obj.x = 2
    assert obj._x == 3

# Generated at 2022-06-21 22:10:49.832408
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        x = 1
        def getx(self):
            return self.x
        # Uncomment the following line to test the roclassproperty
        # getx = roclassproperty(getx)
    assert Foo.getx == 1
    f = Foo()
    # Uncomment the following line to test the roclassproperty
    # assert f.getx == 1



# Generated at 2022-06-21 22:10:59.824837
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def fset(self, value):
        self.__x = value

    X = setterproperty(fset)
    # Test isinstance
    assert isinstance(X, setterproperty)
    x = X()
    # Test X.__doc__ is None
    assert X.__doc__ == None
    # Test X.__set__ is fset
    assert X.__set__(x, 'fset') == 'fset'
    # Test x.__x is 'fset'
    assert x.__x == 'fset'
    # With doc
    def fset2(self, value):
        self.__x = value

    X2 = setterproperty(fset2, "With doc")
    # Test X2.__doc__ is "With doc"

# Generated at 2022-06-21 22:11:03.527333
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def f(self, value):
        print("In setterproperty")
        return self.value
    x=setterproperty(f)
    print(x)
    print(x.func)
    print(x.__doc__)


# Generated at 2022-06-21 22:11:13.353339
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import pytest

    class A(object):
        @lazyclassproperty
        def attr(cls):
            return 1

    a1 = A()
    a2 = A()
    assert A.attr == 1
    assert a1.attr == 1
    assert a2.attr == 1
    setattr(A, "attr", 2)
    assert A.attr == 2
    assert a1.attr == 2
    assert a2.attr == 2

    class B(A):
        pass

    b1 = B()
    b2 = B()
    assert B.attr == 1
    assert b1.attr == 1
    assert b2.attr == 1

    with pytest.raises(AttributeError):
        del B.attr


# Generated at 2022-06-21 22:11:15.981334
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 1

    assert C.x == 1
    assert C().x == 1
    with pytest.raises(AttributeError):
        C.x = 2

# Generated at 2022-06-21 22:11:18.724157
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'foo'
    assert Foo.bar == 'foo'

# Generated at 2022-06-21 22:11:24.051832
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.foo = 1

        @setterproperty
        def bar(self, value):
            self.foo = value

    f = Foo()
    assert f.foo == 1
    f.bar = 2
    assert f.foo == 2



# Generated at 2022-06-21 22:11:29.854594
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def f(cls):
            return 'A'

    class B(A):
        @roclassproperty
        def f(cls):
            return 'B'

    assert A.f == 'A'
    assert B.f == 'B'

    a = A()
    b = B()

    assert A.f == 'A'
    assert B.f == 'B'
    assert a.f == 'A'
    assert b.f == 'B'

# Generated at 2022-06-21 22:11:34.834761
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        @setterproperty
        def x(self, value):
            self._x = value
    a = A()

    def test(value):
        a.x = value
        print(a._x)

    test(value=10)
    test(value=20)
    test(value=30)



# Generated at 2022-06-21 22:11:50.358308
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return set(['bar', cls.__name__])
    class Baz(Foo):
        pass
    class Bam(Baz):
        pass
    assert Foo().bar == Baz().bar == Bam().bar == set(['bar', 'Foo'])
    assert Foo.bar != Baz.bar != Bam.bar != set(['bar', 'Foo'])
    assert Foo.bar == set(['bar', 'Foo'])
    assert Baz.bar == set(['bar', 'Baz'])
    assert Bam.bar == set(['bar', 'Bam'])

# Generated at 2022-06-21 22:11:55.909728
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Unit test for method __get__ of class roclassproperty.
    """

    class ClassA(object):
        x = roclassproperty(lambda cls: cls.__name__)

    # assert ClassA.x == ClassA.__name__
    assert ClassA.x == 'ClassA'
    assert issubclass(ClassA, object)
    assert isinstance(ClassA(), ClassA)



# Generated at 2022-06-21 22:12:01.523718
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        counter = 0

        @lazyclassproperty
        def bar(cls):
            cls.counter += 1
            return cls.counter

        @lazyclassproperty
        def baz(cls):
            cls.counter += 1
            return cls.counter

    assert Foo.bar == 1
    assert Foo.bar == 1 # hasn't inc. again
    assert Foo.baz == 2



# Generated at 2022-06-21 22:12:04.518404
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def tmp(cls):
            return 42

# Generated at 2022-06-21 22:12:08.470664
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:12:14.121512
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self, foo):
            self.foo = foo

        @roclassproperty
        def bar(cls):
            return cls

        @classproperty
        def baz(cls):
            return cls

    a = A('foo')
    assert a.bar is A
    assert a.bar == A
    assert a.baz is A
    assert a.baz == A



# Generated at 2022-06-21 22:12:18.128351
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @roclassproperty
        def myproperty(cls):
            return cls

    assert MyClass.myproperty is MyClass

    with pytest.raises(AttributeError):
        print(MyClass().myproperty)



# Generated at 2022-06-21 22:12:22.727884
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from six.moves.configparser import ConfigParser
    cfg = ConfigParser(allow_no_value=True)

    class ConfigFile(object):
        def __init__(self, cfg):
            self.__dict__['_file'] = ''
            self.__dict__['_cfg'] = cfg

        @setterproperty
        def file(self, file):
            self.__dict__['_file'] = file
            self.__dict__['_cfg'].read(self.file)

        def get(self, section, key):
            return self.__dict__['_cfg'].get(section, key)

    config = ConfigFile(cfg)
    config.file = 'test.ini'
    assert config.get('foo', 'bar') == 'baz'

# Generated at 2022-06-21 22:12:28.402315
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self, value):
            self._value = value

        def _get_value(self):
            return self._value

        def _set_value(self, value):
            self._value = value

        value = setterproperty(_set_value, _get_value.__doc__)

    obj = MyClass(1)
    obj.value = 2
    assert 2 == obj.value

# Generated at 2022-06-21 22:12:31.879173
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Simple class with a settable attribute a
    class A(object):
        def __init__(self):
            self.a = None

        @setterproperty
        def a(self, x):
            self.a = x

    a = A()
    assert_that(a.a, is_(None))

    # The setter method does nothing
    a.a = "hello"
    assert_that(a.a, is_(None))

# Generated at 2022-06-21 22:12:50.608889
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls

    assert Foo.bar is Foo
    assert Foo().bar is Foo



# Generated at 2022-06-21 22:12:56.898007
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class DataObject:
        def __init__(self):
            self.__value = None

        @setterproperty
        def value(self, value):
            self.__value = value

        @property
        def value(self):
            return self.__value

    class DerivedDataObject(DataObject):
        pass

    data = DataObject()
    assert data.value is None
    data.value = 10
    assert data.value == 10
    derived = DerivedDataObject()
    assert derived.value is None
    derived.value = 20
    assert derived.value == 20
    data.value = 30
    assert data.value == 30
    assert derived.value == 20

# Generated at 2022-06-21 22:12:59.375995
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def a(cls):
            return 'a'

    a = A()
    assert a.a == 'a'
    assert A.a == 'a'



# Generated at 2022-06-21 22:13:02.122445
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1
        x = roclassproperty(getx)

    assert C().x == 1
    assert C.x == 1



# Generated at 2022-06-21 22:13:10.893833
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def test(cls):
            return random.randint(0, 10)

    class B(A):
        pass

    class C(A):
        pass

    print(A.test)
    print(A.test)
    print(B.test)
    print(B.test)
    print(C.test)
    print(C.test)



# Generated at 2022-06-21 22:13:16.233252
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A():
        def __init__(self):
            self.x = 0

        @setterproperty
        def setx(self, x):
            self.x = x

    a = A()
    a.setx = 20
    print(a.x)



# Generated at 2022-06-21 22:13:22.720325
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, not_a_setter):
            self.not_a_setter = not_a_setter

        @setterproperty
        def a_setter(self, value):
            self.a_setter = value

    a = A(5)
    assert a.not_a_setter == 5
    assert not hasattr(a, 'a_setter')
    a.a_setter = 10
    assert a.a_setter == 10


# Generated at 2022-06-21 22:13:30.040941
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, param):
            self.param = param

        @setterproperty
        def a(self, value):
            print("setterproperty")
            self.param = value

    a = A("setterproperty")
    a.a = "100"
    print(a.param)



# Generated at 2022-06-21 22:13:41.317148
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class x(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        @setterproperty
        def a(self, value):
            self.a = value
            return self.a
    
    try:
        x(1,2)
        assert False, 'Should have raised an exception'
    except TypeError:
        pass
    
    a = x(1,2)
    assert a.a == 1
    a.a = 10
    assert a.a == 10

if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:13:53.643839
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # When function lazyclassproperty is called, a class property is returned that is only
    # calculated once and cached in an attribute in the class.
    class Foo:
        @lazyclassproperty
        def bar(cls):
            print('Foo.bar called')
            return 42

    assert Foo.bar == 42
    # The second time, the function is not called again, the cached value is returned.
    assert Foo.bar == 42

    # When a new class is defined and lazyclassproperty is used, a new attribute is created.
    del Foo
    class Foo:
        @lazyclassproperty
        def bar(cls):
            print('Foo.bar called')
            return 42

    assert Foo.bar == 42
    assert Foo.bar == 42


# Generated at 2022-06-21 22:14:32.142344
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        this = roclassproperty(lambda cls: cls)
        that = roclassproperty(lambda cls: 'that')

    class B(A):
        this = roclassproperty(lambda cls: A)
        that = roclassproperty(lambda cls: 'not that')

    assert A.this is A
    assert B.this is A

    assert A.that == 'that'
    assert B.that == 'not that'

    assert A().that == 'that'
    assert B().that == 'not that'


# Generated at 2022-06-21 22:14:37.104119
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        def get(cls):
            return cls.__name__
        test = roclassproperty(get)
    assert Test.test == 'Test'
    assert Test().test == 'Test'


# Generated at 2022-06-21 22:14:41.377959
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def foo(cls):
            return 'foo'
    assert Foo.foo == 'foo'



# Generated at 2022-06-21 22:14:51.713578
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        def __init__(self):
            self.value = 0

        @lazyclassproperty
        def prop(cls):
            return cls(1)

    t1 = Test()
    t2 = Test()
    assert t1.prop.value == 1
    assert t2.prop.value == 1
    t1.prop.value = 2
    assert t1.prop.value == 2
    t2.prop.value = 3
    assert t2.prop.value == 3

    class Test2(Test):
        pass

    t3 = Test2()
    assert t3.prop.value == 1
    t3.prop.value = 4
    assert t3.prop.value == 4
    assert t2.prop.value == 3



# Generated at 2022-06-21 22:15:01.000318
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        pass

    a = A( )
    a.var1 = 'test'
    a.var2 = 'test'
    a.var3 = 'test'
    assert a.var1 == 'test'
    assert a.var2 == 'test'
    assert a.var3 == 'test'
    a.var1 = 'override'
    a.var2 = 'override'
    a.var3 = 'overrite'
    assert a.var1 == 'override'
    assert a.var2 == 'override'
    assert a.var3 == 'overrite'



# Generated at 2022-06-21 22:15:03.693830
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'

    with raises(AttributeError):
        A().a
    with raises(AttributeError):
        B().a



# Generated at 2022-06-21 22:15:08.280441
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.__private_variable = None

        @setterproperty
        def visible_property(self, value):
            self.__private_variable = value

    a = A()
    a.visible_property = "hello"
    assert a.__private_variable == "hello"

# Generated at 2022-06-21 22:15:11.962665
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def func(cls):
            return "func A"

    class B(A):
        pass

    class C(B):
        pass

    assert A.func == "func A"
    assert B.func == "func A"
    assert C.func == "func A"



# Generated at 2022-06-21 22:15:17.479899
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def _x(cls):
            x = list(range(3))
            x.append(cls)
            return x

    class B(A):
        pass

    assert A._x == [0, 1, 2, A]
    assert B._x == [0, 1, 2, B]
    assert A._x is A._x
    assert B._x is B._x
    assert A._x is not B._x



# Generated at 2022-06-21 22:15:20.459072
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __set_prop(self, value):
            self.__prop = value

        prop = setterproperty(__set_prop)

    a = A()
    assert a.prop == None
    a.prop = 'value'
    assert a.prop == None



# Generated at 2022-06-21 22:16:32.564004
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def func(obj, value):
            obj.v = value

        def func2(obj, value):
            obj.v2 = value

        x = setterproperty(func, "hello")
        y = setterproperty(func2, "goodbye")

    c = C()
    c.x = 1
    c.y = 2
    assert c.v == 1
    assert c.v2 == 2
    assert C.x.__doc__ == "hello"
    assert C.y.__doc__ == "goodbye"

# Generated at 2022-06-21 22:16:37.286982
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self, data):
            self.data = data
        @setterproperty
        def val(self, val):
            self.data = val
    a = MyClass(None)
    b = MyClass(None)
    a.val = 1
    b.val = 2
    assert a.data == 1
    assert b.data == 2


# Generated at 2022-06-21 22:16:44.845771
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Method __set__ of class setterproperty unit test

    """

    class A(object):
        def __init__(self):
            self.lazy_var = None

# Generated at 2022-06-21 22:16:52.942493
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    from test.test_descrtut import Meta, Super, Sub
    class Foo(metaclass=Meta):
        @roclassproperty
        def spam(cls):
            return 1

    assert Foo.spam == 1
    with pytest.raises(AttributeError):
        Foo.spam = 2

    class Bar(Foo):
        pass

    assert Bar.spam == 1
    with pytest.raises(AttributeError):
        Bar.spam = 2

    class Foo(metaclass=Meta):
        @roclassproperty
        def spam(cls):
            return cls.__name__

    assert Foo.spam == 'Foo'
    with pytest.raises(AttributeError):
        Foo.spam = 2
    class Bar(Foo):
        pass

# Generated at 2022-06-21 22:16:57.454744
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.x = 10

    a = A()
    assert a.x == 10

    @setterproperty
    def x(self, value):
        self._x = value

    assert not hasattr(a, "_x")

    a.x = 20
    assert a._x == 20


if __name__ == "__main__":
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-21 22:17:06.212350
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def foo(self):
            return self.bar

        # Create a new read-only class property.
        foo_prop = roclassproperty(foo)

        def __init__(self, bar):
            self.bar = bar

    print(TestClass.foo_prop)
    # Output: "None"

    a = TestClass('a')
    b = TestClass('b')

    print(a.foo_prop)
    # Output: "a"

    print(b.foo_prop)
    # Output: "b"

    TestClass.foo_prop = 'c'

    print(a.foo_prop)
    # Output: "a"

    print(b.foo_prop)
    # Output: "b"

    print(TestClass.foo_prop)
    # Output:

# Generated at 2022-06-21 22:17:08.566669
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def x(cls):
            return 1

    assert C.x == 1
    assert C().x == 1



# Generated at 2022-06-21 22:17:13.906943
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        def __init__(self):
            self.val = 0

        @setterproperty
        def x(self, val):
            self.val = val

    tc = TestClass()
    assert tc.val == 0
    tc.x = 100
    assert tc.val == 100


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:17:17.419302
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        @setterproperty
        def test(self, value):
            self.__dict__['foo'] = value
            return value

    t = Test()
    t.test = 'baz'
    assert t.foo == 'baz'
    assert t.test == 'baz'



# Generated at 2022-06-21 22:17:21.851665
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def prop(cls):
            return 1

        @lazyclassproperty
        def prop2(cls):
            return 2

    assert C.prop == 1
    assert C.prop2 == 2

    # Don't override the cached value
    C.prop = 2
    assert C.prop == 2
    assert C.prop2 == 2

    class D(C):
        pass

    assert D.prop == 1
    assert D.prop2 == 2

    # Modifying parent class won't affect inheritor
    C.prop = 3
    assert D.prop == 1
    assert D.prop2 == 2

    # And vice versa
    D.prop2 = 3
    assert C.prop == 3
    assert C.prop2 == 2
    assert D.prop == 1
   