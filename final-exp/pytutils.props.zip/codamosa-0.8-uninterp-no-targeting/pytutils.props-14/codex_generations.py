

# Generated at 2022-06-21 22:07:46.311201
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self):
            self._x = None

        @setterproperty
        def set_x(self, value):
            # Possibly error checking on value
            self._x = value

    t = Test()
    t.set_x = 5
    assert t._x == 5

    @setterproperty
    def set_y(value):
        global y
        y = value

    set_y = 5
    assert y == 5

# Generated at 2022-06-21 22:07:49.844668
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'bar'

    print(Foo.bar)
    print(Foo().bar)

if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-21 22:07:55.588958
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestA(object):
        @lazyperclassproperty
        def unit_test(self):
            return "hi!"

    assert TestA.unit_test == "hi!"

    class TestB(TestA):
        pass

    assert TestB.unit_test != TestA.unit_test
    assert TestB.unit_test == "hi!"


# Generated at 2022-06-21 22:07:59.212351
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class X:
        @lazyperclassproperty
        def prop(self):
            return 42

    x = X()
    y = X()

    assert x.prop == 42
    assert y.prop == 42

    x.prop = 5
    assert x.prop == 5



# Generated at 2022-06-21 22:08:02.817211
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    @roclassproperty
    def rop(cls):
        return "rop"

    class C(object): pass
    assert C.rop == "rop"
    assert C().rop == "rop"
    assert C.rop.__doc__ is None
    assert C.rop.__class__ is roclassproperty

    assert C.rop is C.rop
    assert C().rop is C().rop


# Generated at 2022-06-21 22:08:10.420493
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def get_cache(cls):
            return defaultdict(int)

    class Inheritor(Base):
        pass

    class Inheritor2(Base):
        pass

    b = Base()
    i = Inheritor()
    i2 = Inheritor2()

    # Test that values are indeed cached
    b.get_cache['test'] += 1
    i.get_cache['test'] += 1
    i2.get_cache['test'] += 1

    assert b.get_cache['test'] == 1
    assert i.get_cache['test'] == 1
    assert i2.get_cache['test'] == 1

    # Test that each inheritor has it's own cache
    b.get_cache = defaultdict(int)

# Generated at 2022-06-21 22:08:17.789054
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, value):
            self._value = value

        value = setterproperty(lambda self, x: setattr(self, '_value', x))

        @property
        def get_value(self):
            return self._value

    x = Test('initial')
    assert x.get_value == "initial"
    x.value = 'updated'
    assert x.get_value == 'updated'



# Generated at 2022-06-21 22:08:21.451969
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test_func(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.test_func == "A"
    assert B.test_func == "B"



# Generated at 2022-06-21 22:08:26.862218
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass():
        def __init__(self):
            self.a = 42

        @setterproperty
        def b(self, value):
            self.a = value

    test_instance = TestClass()
    assert test_instance.a == 42
    test_instance.b = 1
    assert test_instance.a == 1

# Generated at 2022-06-21 22:08:31.239876
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test_setterproperty___set__:
        def __init__(self, value):
            self.value = value

        def set_value(self, value):
            self.value = value

        value = setterproperty(set_value)

    test = Test_setterproperty___set__(10)
    assert test.value == 10
    test.value = 4
    assert test.value == 4

# Generated at 2022-06-21 22:08:40.164194
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Person(object):
        _first_name = None

        @roclassproperty
        def first_name(cls):
            return cls._first_name

        @first_name.setter
        def first_name(cls, value):
            cls._first_name = value

    assert Person().first_name is None
    Person.first_name = "John"
    assert Person().first_name == "John"



# Generated at 2022-06-21 22:08:43.779824
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(self):
            a = 1
            b = 2
            return a + b

    assert A.b == 3
    assert A().b == 3

    class B(A):
        @lazyclassproperty
        def b(self):
            a = 4
            b = 5
            return a + b

    assert B.b == 9
    assert B().b == 9


# Generated at 2022-06-21 22:08:50.546896
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("I'm here")
            return 42

    class B(A):
        pass

    class C(A):
        pass

    print(A.prop)
    print(A.prop)
    print(B.prop)
    print(B.prop)
    print(C.prop)
    print(C.prop)


# Generated at 2022-06-21 22:08:53.442522
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Demo():
        def get_a(cls):
            return 1
        a = roclassproperty(get_a)
    d = Demo()
    print(d.a)


# Generated at 2022-06-21 22:08:59.098618
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    @roclassproperty
    def roprop(self):
        return self.__name__

    A.roprop = roprop
    B.roprop = roprop
    C.roprop = roprop

    assert A.roprop == 'A'
    assert B.roprop == 'B'
    assert C.roprop == 'C'



# Generated at 2022-06-21 22:09:03.256168
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def test_method(self):
            return 'test_method'
        test_method = roclassproperty(test_method)

    test_instance = TestClass()
    assert test_instance.test_method == 'test_method'
    assert TestClass.test_method == 'test_method'


# Generated at 2022-06-21 22:09:13.619596
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestA(object):
        @lazyperclassproperty
        def get_result(cls):
            return "testA"

    class TestB(TestA):
        @lazyperclassproperty
        def get_result(cls):
            return "testB"

    class TestC(TestA):
        @lazyperclassproperty
        def get_result(cls):
            return "testC"

    assert TestA.get_result == "testA"
    assert TestB.get_result == "testB"
    assert TestC.get_result == "testC"
    test_a = TestA()
    assert test_a.get_result == "testA"
    test_b = TestB()
    assert test_b.get_result == "testB"
    test_c = TestC()

# Generated at 2022-06-21 22:09:17.985677
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'C'

    assert C.foo == 'C'
    assert B.foo == 'A'



# Generated at 2022-06-21 22:09:25.343705
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self._x = None

        def get_x(self):
            return self._x

        def set_x(self, value):
            self._x = value

        @setterproperty
        def x(self):
            return self.get_x(), self.set_x

    assert A.x.__doc__ is None
    assert A.x.__name__ == 'x'
    a = A()
    assert a.x[0] is None
    a.x[1](1)
    assert a.x[0] == 1

# Generated at 2022-06-21 22:09:29.664828
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    from types import MethodType

    class A(object):
        @roclassproperty
        def a(cls):
            return 1

    assert A.a == 1
    assert isinstance(A.a, int)

    # Testing type of method
    assert isinstance(A.__dict__['a'], roclassproperty)
    assert isinstance(A().__dict__['a'], MethodType)

    assert A().a == 1
    assert isinstance(A().a, int)

# Generated at 2022-06-21 22:09:36.016268
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        class_prop = roclassproperty(lambda cls: "Hello")

    assert 'Hello' == Foo.class_prop, 'roclassproperty: __get__ returns incorrect value'


# Generated at 2022-06-21 22:09:37.729447
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class roclasspropertyTest:

        @roclassproperty
        def value():
            return "value"

    assert roclasspropertyTest.value == "value"
    assert roclasspropertyTest().value == "value"

# Generated at 2022-06-21 22:09:43.394883
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):

        @lazyperclassproperty
        def foo(cls):
            print('A init foo')
            return 1

    class B(A):

        @lazyperclassproperty
        def foo(cls):
            print('B init foo')
            return 2

    assert A.foo == 1
    assert B.foo == 2
    assert not hasattr(A, '_A_lazy_foo')
    assert hasattr(B, '_B_lazy_foo')



# Generated at 2022-06-21 22:09:50.354302
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from fractions import Fraction

    print('Testing setterproperty.__set__')
    class Example(object):
      @setterproperty
      def example_property(self, value):
        self._example_property = Fraction(value)

    e = Example()
    e.example_property = 10
    print(e._example_property)
    e.example_property = '10/2'
    print(e._example_property)
    e.example_property = [10, 2]
    print(e._example_property)

# Unit tests for method __get__ of class classproperty

# Generated at 2022-06-21 22:09:56.465591
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def v1(cls):
            return 42
        @classproperty
        def v2(cls):
            return 43
        def __init__(self):
            pass
    c = C()
    assert c.v1 == 42
    assert C.v1 == 42
    assert c.v2 == 43
    assert C.v2 == 43


# Generated at 2022-06-21 22:10:00.683335
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base():
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class Child(Base):
        pass

    class GrandChild(Child):
        pass

    assert Base().foo == 'Base'
    assert Child().foo == 'Child'
    assert GrandChild().foo == 'GrandChild'



# Generated at 2022-06-21 22:10:04.804121
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def name(cls):
            return "A"

    assert A.name == "A"
    try:
        A().name
    except AttributeError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 22:10:13.188803
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):

        _x = "this is class property x"

        @lazyclassproperty
        def x(cls):
            return cls._x

        @lazyperclassproperty
        def y(cls):
            return 'bar'

        @lazyperclassproperty
        def z(cls):
            return sum(range(0, cls.counter))

        counter = 0

    class B(A):
        counter = 5

    class C(object):
        pass

    a = A()
    assert a.x == a._x
    assert A.x == A._x

    assert a.y == 'bar'
    assert A.y == 'bar'
    assert B.y == 'bar'

    assert a.z == sum(range(0, A.counter))

# Generated at 2022-06-21 22:10:18.425362
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, a,b=0):
            self.a = a
            self.b = b
        @setterproperty
        def x(self, value):
            self.a = value - self.b
            self.b = 0

    a = Test(4,5)
    a.x = 8
    assert a.a == 3


# Generated at 2022-06-21 22:10:24.019313
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(cls):
            return 1

        @lazyclassproperty
        def c(cls):
            return 2

    class B(A):
        pass

    class C(A):
        @classproperty
        def b(cls):
            return 3

    assert A.b == 1
    assert B.b == 1
    assert C.b == 3

    assert A.c == 2
    assert B.c == 2
    assert C.c == 2



# Generated at 2022-06-21 22:10:37.221489
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class SampleClass(object):
        @setterproperty
        def attrib(self, value):
            pass

    s = SampleClass()
    setattr(s, '_attrib', [])

    s.attrib = 'a'
    s.attrib = 'b'
    s.attrib = 'c'

    assert s._attrib == 'c'



# Generated at 2022-06-21 22:10:42.804378
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class test(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            self._value = value

        @value.getter
        def value(self):
            return self._value

    value = '1'
    t = test(value)
    assert t.value == value
    value = '2'
    t.value = value
    assert t.value == value

# Generated at 2022-06-21 22:10:45.744101
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        a = 1

        @roclassproperty
        def b(cls):
            return cls.a

    assert A.b == A.a
    assert A.b == 1


# Generated at 2022-06-21 22:10:54.274313
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def __init__(self):
            self._x = ''

        @roclassproperty
        def x(cls):
            return cls._x

    c = C()
    assert C.x == ''
    assert c.x == ''
    C._x = 'foo'
    assert C.x == 'foo'
    assert c.x == 'foo'
    c._x = 'bar'
    assert C.x == 'foo'
    assert c.x == 'foo'



# Generated at 2022-06-21 22:10:58.239182
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        a = 1

        def __str__(self):
            return "A"

    class B(A):
        b = 2
        c = roclassproperty(lambda cls: cls.a + cls.b)

    print(B.c)


# Generated at 2022-06-21 22:11:02.017759
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return "a"

    class B(A):
        @lazyclassproperty
        def a(cls):
            return "b"

    assert A.a == "a"
    assert B.a == "b"



# Generated at 2022-06-21 22:11:07.987272
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.__x = 1
        @setterproperty
        def foo(self, val):
            self.__x = val
        @property
        def x(self):
            return self.__x

    a = A()
    assert a.x == 1
    a.foo = 2
    assert a.x == 2



# Generated at 2022-06-21 22:11:10.772483
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X(object):
        @lazyclassproperty
        def attr(cls):
            return 2

    assert X.attr == 2
    assert X.attr == 2 # make sure we cache



# Generated at 2022-06-21 22:11:13.080534
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class A:
        @roclassproperty
        def getA():
            return 'A'

    assert A().getA() == A.getA() == 'A'


# Generated at 2022-06-21 22:11:16.016774
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Z(object):
        class_member = 1
        @roclassproperty
        def class_attr(cls):
            return cls.class_member

    a = Z()
    assert a.class_attr == 1
    assert Z.class_attr == 1



# Generated at 2022-06-21 22:11:36.968798
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Test(object):
        def __init__(self, foo=0):
            self._foo = foo

        @setterproperty
        def foo(self, value):
            print("Setterproperty test: ", value)
            self._foo = value

    t = Test()
    t.foo = 5
    print("Property foo value: ", t.foo)



# Generated at 2022-06-21 22:11:43.839044
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import random

    class A:
        def __init__(self): self.value = 0

        @setterproperty
        def prop(self, value): self.value = value

    a1 = A()
    a2 = A()

    a1.prop = random.randrange(1, 1000)
    assert (a1.value == a1.prop)
    assert (a2.value != a1.value)

    a2.prop = random.randrange(1, 1000)
    assert (a2.value == a2.prop)
    assert (a1.value != a2.value)


if __name__ == "__main__":
    test_setterproperty___set__()

# Generated at 2022-06-21 22:11:47.124094
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            self._x = value

    t = Test(1)
    assert t.x == 1
    t.x = 2
    assert t.x == 2

# Generated at 2022-06-21 22:11:53.017483
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo:
        def bar(self, value):
            self.value = value

        def get_value(self):
            return self.value

        x = setterproperty(bar, "I am the 'x' property.")

    f = Foo()
    f.x = 'eggs'
    assert f.get_value() == 'eggs'


if __name__ == "__main__":
    print('running unittests ...')
    test_setterproperty___set__()
    print('done.')

# Generated at 2022-06-21 22:12:01.207172
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object): pass
    class B(A): pass
    class C(A): pass

    @lazyperclassproperty
    def x(cls):
        print('lazy called for class {}'.format(cls.__name__))
        return object()

    assert x.__get__(None, A) is x.__get__(None, B) is x.__get__(None, C)

    assert x.__get__(None, A) is not x.__get__(None, A)
    assert x.__get__(None, B) is not x.__get__(None, B)
    assert x.__get__(None, C) is not x.__get__(None, C)

# Generated at 2022-06-21 22:12:08.561247
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:12:11.818542
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Example(object):
        def f(cls):
            return cls

        x = roclassproperty(f)

    ex = Example()
    assert ex.x is Example


# Generated at 2022-06-21 22:12:18.761329
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyTest(object):
        def __init__(self):
            pass

        def get(self):
            return self._value

        def set(self, value):
            self._value = value

        attr = roclassproperty(get)


# Generated at 2022-06-21 22:12:20.987841
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value

    obj = C()
    obj.x = "foo"
    assert obj._x == "foo"



# Generated at 2022-06-21 22:12:33.256609
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Check with no docstring
    class test_setterproperty___set___01():
        def __init__(self):
            self.test = 0
            self._a = 0

        @setterproperty
        def a(self, value):
            self._a = value
            self.test = 1

    instance = test_setterproperty___set___01()
    instance.a = 1
    assert instance.test == 1 and instance._a == 1
    del instance.test
    del instance._a
    del instance, test_setterproperty___set___01

    # Check with docstring
    class test_setterproperty___set___02():
        def __init__(self):
            self.test = 0
            self._a = 0


# Generated at 2022-06-21 22:13:14.151672
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert C.foo == 'bar'

    class D(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert D.foo == 'bar'

    class E(D):
        pass

    assert A.foo == 'foo'
    assert E.foo == 'bar'


# Generated at 2022-06-21 22:13:19.198702
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        def __init__(self):
            pass

        @roclassproperty
        def readonly_property(cls):
            return 42

    assert MyClass.readonly_property == 42



# Generated at 2022-06-21 22:13:22.851046
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Example(object):
        def __init__(self, x):
            self.__x = x
            
        @roclassproperty
        def x(cls):
            return cls.__x
            
    ex1 = Example(1)
    assert ex1.x==1
    ex2 = Example(2)
    assert ex2.x==2
    
test_roclassproperty()

# Generated at 2022-06-21 22:13:27.108275
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        pass

    a = A()
    a.count = 0

    def fn(obj, value):
        assert(obj is a)
        assert(value == 5)
        a.count = a.count + 1

    setter = setterproperty(fn)

    for i in xrange(2):
        setter.__set__(a, 5)
        assert(a.count == i+1)



# Generated at 2022-06-21 22:13:32.423365
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A:
        pass

    class B(A):
        pass

    @lazyperclassproperty
    def foo(cls):
        return cls.__name__

    assert foo is A.foo
    assert foo.__get__(None, A) == "A"
    assert foo.__get__(None, B) == "B"

    assert A.foo == "A"
    assert B.foo == "B"



# Generated at 2022-06-21 22:13:36.813743
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @roclassproperty
        def a(cls):
            return cls

    assert MyClass.a == MyClass and MyClass().a == MyClass



# Generated at 2022-06-21 22:13:42.447953
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):

        @setterproperty
        def foo(self, val):
            self._foo = val

        @setterproperty
        def bar(self, val):
            self._bar = val
    a = A()
    a.foo = 'foo'
    a.bar = 'bar'
    assert a._foo == 'foo'
    assert a._bar == 'bar'



# Generated at 2022-06-21 22:13:52.068789
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # argument is setterproperty
    def set1(obj, value):
        obj.attr = value

    prop = setterproperty(set1)
    assert prop.__set__(object(), 'yes') == set1(object(), 'yes')

    # argument is a function
    def set2(value):
        return value

    prop = setterproperty(set2)
    assert prop.__set__(object(), 'yes') == set2('yes')



# Generated at 2022-06-21 22:14:02.504392
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        _a = 1
        @lazyperclassproperty
        def a(cls):
            print("A")
            return cls._a
    class B(A):
        _a = 2
    class C(A):
        _a = 3
    class D(B, C):
        _a = 4

    a = A()
    b = B()
    c = C()
    d = D()

    assert d.a == 4
    assert isinstance(d.a, int)
    assert c.a == 3
    assert b.a == 2
    assert a.a == 1


# Generated at 2022-06-21 22:14:09.631942
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self, v):
            self.__v = v

        @setterproperty
        def x(self, v):
            self.__v = v

        def get_x(self):
            return self.__v

    foo = A(10)
    foo.x = 20
    assert foo.get_x() == 20



# Generated at 2022-06-21 22:15:24.789669
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self):
            self.x = []
        @lazyperclassproperty
        def p(cls):
            return len(cls.x)
    class B(A):
        def __init__(self):
            self.x = [1]
    a = A()
    b = B()
    assert a.p == 0
    assert b.p == 1

# Generated at 2022-06-21 22:15:26.581513
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C:
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert C.x == 1



# Generated at 2022-06-21 22:15:30.006277
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def my_lazy_property(cls):
            print('We are in the method')
            return 'And we are done'

    print(Foo.my_lazy_property)
    print(Foo.my_lazy_property)
    print(Foo().my_lazy_property)
    print(Foo().my_lazy_property)



# Generated at 2022-06-21 22:15:33.733507
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    with pytest.raises(TypeError) as err:
        import math
        import os
        import random
        import sys


        class A:
            def __init__(self):
                self.x = False


            @setterproperty
            def x(self, value):
                if isinstance(value, bool):
                    self._x = value
                else:
                    raise TypeError


        a = A()
        a.x = 'hello'
    assert err.value.args[0] == 'hello is not of type <bool>'



# Generated at 2022-06-21 22:15:38.399142
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class A(object):
        @setterproperty
        def a(self, x):
            self.a_property = x

    class setterpropertyTest(unittest.TestCase):
        def setUp(self):
            self.A = A()

    def test_case(self):
        self.A.a = 1
        self.assertEqual(self.A.a_property, 1)

    test_case.__name__ = 'test_case %s' % 1
    setattr(setterpropertyTest, test_case.__name__, test_case)

    suite = unittest.TestSuite()
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(setterpropertyTest))

# Generated at 2022-06-21 22:15:41.705581
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:15:47.846898
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def cls_property(cls):
            return "A"
    a = A()

# Generated at 2022-06-21 22:15:53.562000
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls, a=1):
            return a

        def __init__(self):
            self.x = self.x + 1

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return 2

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    assert a1.x == 2
    assert a2.x == 2
    assert b1.x == 3
    assert b2.x == 3
    # The following suggests that it is working consistently:
    assert B.x == 2
    assert A.x == 1


# Generated at 2022-06-21 22:15:57.932456
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        @roclassproperty
        def class_name(cls):
            return cls.__name__

    assert TestClass.class_name == 'TestClass'
    assert TestClass().class_name == 'TestClass'


# Generated at 2022-06-21 22:16:06.384931
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class MyClass:
        def __init__(self):
            self.foo = 'foo'

        @setterproperty
        def foo(self, value):
            if value == 'foo':
                return
            self.foo = value

        @setterproperty
        def bar(self, value):
            if value == 'bar':
                return
            self.bar = value

    assert MyClass.foo is None
    my_obj = MyClass()
    assert my_obj.foo == 'foo'
    my_obj.foo = 'bar'
    assert my_obj.foo == 'bar'

    with pytest.raises(AttributeError):
        my_obj.bar = 'bar'

