

# Generated at 2022-06-21 22:07:43.205634
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def var(cls):
            return 5

    assert Test.var == 5
    Test.var = 6
    assert Test.var == 6
    Test.var = None
    assert Test.var == None


# Generated at 2022-06-21 22:07:49.379807
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, val):
            self.__val = val

        @setterproperty
        def x(self, val):
            self.__val = val

    a = A(5)
    a.x = 10
    assert a.__val == 10

if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-21 22:07:56.040120
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:08:05.196247
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @staticmethod
        def init_prop(cls):
            return cls.__name__

        @classproperty
        def prop(cls):
            return cls.init_prop(cls)

        @lazyperclassproperty
        def lazyprop(cls):
            return cls.init_prop(cls)

    class Test2(Test):
        pass

    assert Test.prop == Test.lazyprop
    assert Test2.prop == Test2.lazyprop
    assert Test.prop != Test2.prop
    assert Test.lazyprop != Test2.lazyprop

if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-21 22:08:07.774193
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def test(self, val):
            self.value = val

    c = C()
    c.test = 12
    assert c.value == 12



# Generated at 2022-06-21 22:08:13.855753
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            self.__x = value

        @property
        def x(self):
            return self.__x

    foo = Foo()
    foo.x = 2
    assert foo.x == 2



# Generated at 2022-06-21 22:08:20.499492
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self._y = 2

        @setterproperty
        def x(self, value):
            self._y = value if value < 0 else -value

        @property
        def y(self):
            return self._y

    a = A()
    assert a.y == 2

    a.x = 3
    assert a.y == 3

    a.x = -2
    assert a.y == 2



# Generated at 2022-06-21 22:08:30.608781
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from .helpers import DecoratorTestCase

    class ClassA(object):
        @lazyperclassproperty
        def obj(cls):
            return object()

    class ClassB(ClassA):
        pass

    class PerClassPropertyTest(DecoratorTestCase):
        def assertPerClassProperty(self, obj, cls, value):
            self.assertIs(getattr(obj, '_%s_lazy_obj' % cls.__name__), value)

        def setUp(self):
            self.a = ClassA()
            self.b = ClassB()

        def test_per_class(self):
            self.assertPerClassProperty(self.a, ClassA, self.a.obj)
            self.assertPerClassProperty(self.b, ClassB, self.b.obj)


# Generated at 2022-06-21 22:08:37.723068
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test_Class(object):
        def __init__(self):
            self.a = 0

        @setterproperty
        def a(self, value):
            print("setterproperty_test_a: {}".format(value))

    obj1 = Test_Class()
    assert obj1.a == 0
    obj1.a = 2
    assert obj1.a == 0


# Generated at 2022-06-21 22:08:41.035679
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def foo(cls):
            return (cls, 'foo')
    assert TestClass.__dict__ == {}
    assert TestClass.foo == (TestClass, 'foo')
    assert 'foo' in TestClass.__dict__
    assert TestClass.foo == (TestClass, 'foo')



# Generated at 2022-06-21 22:08:47.453038
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    c = C()
    assert c.x == 1


# Generated at 2022-06-21 22:08:53.695048
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def a(cls):
            return 1

        b = property(lambda self: 1)

    class Test2(Test):
        pass

    assert Test.a is Test.a
    assert Test.a is not Test2.a
    assert not hasattr(Test, '_lazy_a')
    assert hasattr(Test, '_lazy_a')
    assert Test.b is not Test.b



# Generated at 2022-06-21 22:08:58.314974
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:09:06.075179
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, i):
            self.i = i

        @setterproperty
        def i(self, i):
            if not isinstance(i, int):
                raise ValueError('Not a valid integer')
            self._i = i

        @property
        def i(self):
            return self._i

    a = A(5)
    assert a.i == 5
    a.i = 6
    assert a.i == 6
    try:
        a.i = 'x'
        assert False, 'exception not raised'
    except ValueError:
        pass
    assert a.i == 6



# Generated at 2022-06-21 22:09:16.312599
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:09:19.670530
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:09:28.187314
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class roclassproperty___get___Test(object):
        foo = roclassproperty(lambda cls: 42)
    assert roclassproperty___get___Test.foo == 42

# Exports

# Generated at 2022-06-21 22:09:35.523408
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyClass:
        @staticmethod
        def dummy_static_method():
            pass

        @roclassproperty
        def dummy_roclassproperty(cls):
            return DummyClass.dummy_static_method

    dummy_object = DummyClass()

    assert isinstance(dummy_object.dummy_roclassproperty, staticmethod)
    assert dummy_object.dummy_roclassproperty is DummyClass.dummy_static_method

    dummy_roclassproperty = dummy_object.dummy_roclassproperty
    assert isinstance(dummy_roclassproperty, staticmethod)

    dummy_roclassproperty2 = DummyClass.dummy_roclassproperty
    assert isinstance(dummy_roclassproperty2, staticmethod)
    assert dummy_roclassproperty2 is DummyClass.dummy_static_method

# Generated at 2022-06-21 22:09:42.885611
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():  # pragma: no cover
    class Foo(object):
        @lazyperclassproperty
        def number(cls):
            return 5

    class Bar(Foo):
        pass

    class Baz(Bar):
        @lazyperclassproperty
        def number(cls):
            return 6

    foo = Foo()
    assert foo.number == 5

    bar = Bar()
    assert bar.number == 5

    baz = Baz()
    assert baz.number == 6

    class Qux(Foo):
        pass

    qux = Qux()
    assert qux.number == 5


# Generated at 2022-06-21 22:09:47.254199
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def func(obj, value):
        return value
    setprop = setterproperty(func)
    setprop.__set__(None, 1)
    assert setprop.__doc__ is None
    setprop = setterproperty(func, "setterproperty")
    assert setprop.__doc__ == "setterproperty"


# Generated at 2022-06-21 22:10:01.839992
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    """
    class C1(object):
        def __init__(self):
            self.__var = 1
        @setterproperty
        def __setvar(self, new):
            if new < 5:
                self.__var = new
            else:
                self.__var = 0
        @property
        def __getvar(self):
            return self.__var
    class C2(C1):
        pass
    a = C1()
    b = C2()
    a.__setvar = 0
    assert a.__getvar == 0
    a.__setvar = 10
    assert a.__getvar == 0
    b.__setvar = 0
    assert b.__getvar == 0

# Generated at 2022-06-21 22:10:08.579187
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """ Function to tests method __set__ of class setterproperty"""
    class foo():
        __test = setterproperty(lambda self, x: setattr(self, '_foo__bar', x))

        def __init__(self):
            self.__bar = None
        
        def get_bar(self):
            return self.__bar

    f = foo()
    assert f.get_bar() is None
    f.__test = 'Set is working!'
    assert f.get_bar() == 'Set is working!'
    

test_setterproperty___set__()

# Generated at 2022-06-21 22:10:14.746176
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x of class %s' % cls.__name__

    class B(A):
        @lazyclassproperty
        def x(cls):
            return 'x of class %s' % cls.__name__

    class C(A):
        pass

    assert A.x == 'x of class A'
    assert B.x == 'x of class B'
    assert C.x == 'x of class A'


# Generated at 2022-06-21 22:10:18.880422
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def hello(cls):
            return 'hello from %s' % cls.__name__

    class B(A):
        pass

    assert A.hello == 'hello from A'
    assert B.hello == 'hello from B'



# Generated at 2022-06-21 22:10:22.868598
# Unit test for constructor of class setterproperty

# Generated at 2022-06-21 22:10:24.605997
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Class(object):
        @roclassproperty
        def get(cls):
            return 99

    assert 99 == Class.get



# Generated at 2022-06-21 22:10:28.757111
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def prop(cls):
            print("Initializing class A")
            return 1
    class B(A):
        @lazyclassproperty
        def prop(cls):
            print("Initializing class B")
            return 2
    class C(A):
        pass
    assert A.prop == 1
    assert B.prop == 2
    assert C.prop == 1
    A.prop = 2
    assert A.prop == 2
    assert B.prop == 2
    assert C.prop == 2

# Generated at 2022-06-21 22:10:34.894934
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import pytest

    class TestSetterProperty(object):
        def __init__(self):
            self._value = 0

        @setterproperty
        def value(self, value):
            self._value = value

    test_object = TestSetterProperty()
    test_object.value = 1
    assert test_object._value == 1


# Generated at 2022-06-21 22:10:38.415383
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    foo = Foo()
    assert foo.bar == 'bar'
    assert Foo.bar == 'bar'
    foo.bar = 'foo'
    assert Foo.bar == 'bar'



# Generated at 2022-06-21 22:10:42.875316
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self): self._x = None

        @setterproperty
        def x(self, v):
            self._x = v
            return self._x

    a = A()
    a.x = "hallo"
    assert a.x == "hallo"
    a.x = 42
    assert a.x == 42


# Generated at 2022-06-21 22:10:54.653139
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        _a = 1

        @roclassproperty
        def a(self):
            return self._a

    assert getattr(A, 'a') == 1



# Generated at 2022-06-21 22:10:58.237489
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value

    a = A()
    a.x = 10
    assert a._x == 10



# Generated at 2022-06-21 22:11:08.607842
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        x = roclassproperty(lambda cls: 1)
        __x = roclassproperty(lambda cls: 2)
        __x__ = roclassproperty(lambda cls: 3)
        x__ = roclassproperty(lambda cls: 4)

    # Check if a class has a public property x
    assert hasattr(A, 'x')
    # Check if a class has a hidden property __x
    assert hasattr(A, '__x')
    # Check if a class has a hidden property __x__
    assert hasattr(A, '__x__')
    # Check if a class has a public property x__
    assert hasattr(A, 'x__')

    assert A.x is 1
    # We cannot check A.__x == 2 because __x is a hidden property
    # We cannot check

# Generated at 2022-06-21 22:11:12.742124
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C:
        # Create a read-only class property
        @roclassproperty
        def name(cls):
            return cls.__name__

    print('Class name is: {:s}'.format(C.name))

# Execute the test
if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-21 22:11:18.517187
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def __init__(self):
            self.x = 42

        @roclassproperty
        def foo(cls):
            return cls.x

    c = C()

    c.x = 1
    assert c.foo == 1
    assert C.x == 1

    C.x = 2
    assert c.foo == 2
    assert C.x == 2

    c.x = 3
    assert c.foo == 3
    assert C.x == 3



# Generated at 2022-06-21 22:11:25.235372
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.x = None

        def set_x(self, value):
            self.x = value

        x = setterproperty(set_x)

    a = A()
    a.x = 12
    assert a.x is None
    assert a._x == 12


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-21 22:11:33.574265
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    """
    Test for for of constructor roclassproperty
    """
    class T(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @roclassproperty
        def z(cls):
            """
            Doc string added to class property
            """
            return cls.x + cls.y

    a = T(1, 2)

    assert a.x == 1
    assert a.y == 2
    assert a.z == 3

# Generated at 2022-06-21 22:11:36.214968
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def prop(cls):
            return 'Class property of {}'.format(cls.__name__)

    a = A()
    print(a.prop)


# Generated at 2022-06-21 22:11:39.405291
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:11:47.532423
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class test_roclassproperty___get___class(object):

        @roclassproperty
        def roclassproperty___get__(cls):
            return cls.__name__

        @classproperty
        def classproperty___get__(cls):
            return cls.__name__

    class test_roclassproperty___get___class_inheritor(test_roclassproperty___get___class):
        pass

    res = test_roclassproperty___get___class.roclassproperty___get__
    assert res == 'test_roclassproperty___get___class'
    res = test_roclassproperty___get___class.classproperty___get__
    assert res == 'test_roclassproperty___get___class'
    res = test_roclassproperty___get___class_inheritor.roclassproperty___

# Generated at 2022-06-21 22:12:06.513990
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    assert B.prop == 'B'
    assert A.prop == 'A'



# Generated at 2022-06-21 22:12:09.453793
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def test(self):
            return 'value'

    a = A()
    assert a.test == 'value'

# Generated at 2022-06-21 22:12:18.165568
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @classproperty
        def dict_object(cls):
            return dict()

        @lazyclassproperty
        def dict_object2(cls):
            return dict()

    f = Foo()
    f.dict_object['foo'] = 1
    f.dict_object2['foo'] = 1
    assert f.dict_object['foo'] == 1
    assert f.dict_object2['foo'] == 1

    g = Foo()
    assert g.dict_object['foo'] == 1
    assert g.dict_object2['foo'] == 1  # See https://github.com/bemasher/msdp/issues/22



# Generated at 2022-06-21 22:12:20.942999
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    try:
        assert A.foo == 'foo'
        assert B.foo == 'foo'
    except:
        raise
    finally:
        del A._lazy_foo
        del B._lazy_foo

# Generated at 2022-06-21 22:12:25.972676
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        value = None
        @setterproperty
        def set_value(self, val):
            self.value = val
    t = Test()
    t.value = 0
    t.set_value = 1
    assert t.value == 1


# Generated at 2022-06-21 22:12:32.662980
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # check correct behavior when setting value
    class MyClass(object):
        def __init__(self):
            self.test = self.test

        @setterproperty
        def test(self, value):
            self._test = value

    # check correct behavior when getting value
    my_instance = MyClass()
    my_instance.test = 'test_value'
    assert my_instance._test == 'test_value'



# Generated at 2022-06-21 22:12:34.336742
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    c = MyClass()
    c.name = 'Alex'
    assert c._name == 'Alex'



# Generated at 2022-06-21 22:12:44.252335
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from unittest.mock import MagicMock

    class A:
        counter = 0

        @lazyperclassproperty
        def prop(cls):
            cls.counter += 1
            return 'value ' + str(cls.counter)

    class B(A):
        pass

    assert A.prop == 'value 1'
    assert '_Alazy_prop' in A.__dict__
    assert '_Blazy_prop' not in B.__dict__

    assert B.prop == 'value 2'
    assert '_Alazy_prop' not in A.__dict__
    assert '_Blazy_prop' in B.__dict__

    m = MagicMock()
    m.prop = lazyperclassproperty(lambda cls: cls)
    assert m.prop == m



# Generated at 2022-06-21 22:12:49.098870
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class TestClass(object):
        __doc__ = "Test class for setterproperty"
        @setterproperty
        def my_property(self, value):
            "Setter for my_property"
            if value > 5: return value
            else: return None

    obj = TestClass()
    obj.my_property = 3


# Generated at 2022-06-21 22:12:51.658274
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Foo(object):
        @setterproperty
        def prop(self, value):
            return value

    foo = Foo()
    foo.prop = 10
    assert foo.prop == 10



# Generated at 2022-06-21 22:13:30.923379
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        __slots__ = ('_a', 'b')
        a = setterproperty(lambda self, value: setattr(self, '_a', value))
    t = Test()
    t.a = 5
    assert t._a == 5
    assert t.a is None # setterproperty is not a regular property



# Generated at 2022-06-21 22:13:36.737783
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Dummy:
        def __init__(self):
            self.x = None

        @setterproperty
        def x(self, value):
            self.x = value

    d = Dummy()
    d.x = 42
    assert d.x == 42

# Generated at 2022-06-21 22:13:40.709944
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def get_name(self):
            return self.__class__.__name__
        name = roclassproperty(get_name)

    assert A.name == 'A'



# Generated at 2022-06-21 22:13:46.833880
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('Making x')
            return 5

    print(A.x)
    print(A.x)

# Unti test for function lazyperclassproperty

# Generated at 2022-06-21 22:13:51.092676
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty.
    """
    print(inspect.getsource(setterproperty.__set__))



# Generated at 2022-06-21 22:14:03.240147
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class a(object):
        @classmethod
        def spam(cls):
            return [None]
        spam = lazyperclassproperty(spam)

    assert a.spam is a.spam
    assert a().spam is a().spam
    assert a().spam is a.spam
    assert a.spam is not b.spam
    assert a().spam is not b().spam
    assert a().spam is not b.spam

    class b(a):
        pass

    assert a.spam is a.spam
    assert a().spam is a().spam
    assert a().spam is a.spam
    assert a.spam is not b.spam
    assert a().spam is not b().spam
    assert a().spam is not b.spam



# Generated at 2022-06-21 22:14:09.290934
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Foo(object):
        pass

    class Foo1(Foo):
        pass

    @lazyperclassproperty
    def a(cls):
        return cls.__name__

    assert a(Foo) == 'Foo'
    assert a(Foo1) == 'Foo1'



# Generated at 2022-06-21 22:14:16.800205
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Demo(object):
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            print("Setting value to %s" % value)
            self._value = value

        @setterproperty
        def value2(self, value):
            print("Setting value2 to %s" % value)
            self._value = value

    a = Demo(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:14:25.104585
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, value, name):
            self._value = value
            self._name = name

        def get_value(self):
            return self._value

        def set_value(self, value):
            self._value = value

        @setterproperty
        def value(self):
            return self.get_value()

        @value.setter
        def value(self, value):
            return self.set_value(value)

    a = A(4, "Varun")
    assert a.value == 4
    assert a.get_value() == 4
    a.value = 2
    assert a.value == 2
    assert a.get_value() == 2


if __name__ == '__main__':
    # Testing lazyclassproperty
    import time
    import thread

# Generated at 2022-06-21 22:14:29.767449
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        @setterproperty
        def a(self, value):
            self._a = value

    a = A()
    a.a = 0
    assert a._a == 0
    a.a = 1
    assert a._a == 1


# Unit tests for method __init__ of class lazyperclassproperty

# Generated at 2022-06-21 22:15:44.422295
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest

    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 2

    class D(B):
        pass

    class Testlazyperclassproperty(unittest.TestCase):
        def test_lazyperclassproperty(self):
            self.assertEqual(B.foo, 1)
            self.assertEqual(C.foo, 2)
            self.assertEqual(D.foo, 1)

    unittest.main()

# Generated at 2022-06-21 22:15:50.477589
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):

        def __init__(self):
            self.value = 0

    mc = MyClass()
    assert mc.value == 0

    @setterproperty
    def iset(self, value):
        self.value += value

    mc.iset = 1
    assert mc.value == 1

    mc.iset = 1
    assert mc.value == 2

    mc.iset = 2
    assert mc.value == 4

# Generated at 2022-06-21 22:15:52.580154
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestFormat(object):
        @setterproperty
        def set_format(self, value):
            self.format = value

    test_format = TestFormat()
    test_format.set_format = 'test'
    assert test_format.format == 'test'



# Generated at 2022-06-21 22:15:55.358204
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def x(cls):
            return "test"
    assert Test.x == "test"


# Generated at 2022-06-21 22:16:01.023747
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        __metaclass__ = LazyPerClassPropertyMetaClass

        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == "A"
    assert B.x == "B"
    assert C.x == "C"



# Generated at 2022-06-21 22:16:09.572457
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    A.x = 'y'
    assert A.x == 'y'

    class B(A):
        pass

    assert B.x == 'y'
    B.x = 'z'
    assert B.x == 'z'
    assert A.x == 'y'

    class C(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

        @lazyclassproperty
        def y(cls):
            return 'y'

    assert C.x == 'x'
    assert C.y == 'y'

    C.x = 'z'
    assert C.x == 'z'
    assert C.y

# Generated at 2022-06-21 22:16:12.781649
# Unit test for constructor of class setterproperty
def test_setterproperty():
    a = 0
    def setter(obj, val):
        nonlocal a
        a = val
    sp = setterproperty(setter)
    sp.__set__(None, 5)
    assert a == 5


# Generated at 2022-06-21 22:16:15.755019
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Base:
        @roclassproperty
        def foo(cls):
            return cls.__name__

    Base.foo  # instance of roclassproperty
    assert Base.foo == 'Base'
    assert Base.foo == Base.foo



# Generated at 2022-06-21 22:16:23.611892
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, a):
            self._a = a

        @roclassproperty
        def a(cls):
            return cls._a
    a = A(2)
    assert a.a == 2

    class B(A):
        def __init__(self, a, b):
            super().__init__(a)
            self._b = b

        @roclassproperty
        def b(cls):
            return cls._b
    b = B(3,5)
    assert b.b == 5



# Generated at 2022-06-21 22:16:30.116758
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        foo_cls = 0
        foo_inst = 0

        @roclassproperty
        def foo(cls):
            cls.foo_cls += 1
            return cls.foo_cls

        @property
        def bar(self):
            self.foo_inst += 1
            return self.foo_inst

    a = A()
    assert a.foo == 1
    assert a.foo == 1
    assert A.foo == 1
    assert A.foo == 1

    assert a.bar == 1
    assert a.bar == 2
    assert A.bar  # Class has no 'bar' property