

# Generated at 2022-06-21 22:07:51.463002
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import copy

    class Dummy(object):
        def __init__(self, mydict):
            self.mydict = mydict

        @setterproperty
        def other(self, other):
            self.mydict['other'] = other

        @setterproperty
        def zap(self, other):
            self.mydict['zap'] = other

    mydict = {'zap': {'a': 1, 'b': 2}}
    d = Dummy(mydict)
    d.other = 'other'
    d.zap = {'a': 3}
    assert d.mydict['other'] == 'other' and d.mydict['zap'] == {'a': 3}
    assert mydict['other'] == 'other' and mydict['zap'] == {'a': 3}
    # Check

# Generated at 2022-06-21 22:07:59.207159
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, x):
            self.__x = x

        @setterproperty
        def x(self, value):
            if value < 0:
                raise ValueError("Negative value not allowed: %s" % value)
            self.__x = value

        def __str__(self):
            return '<%s object at %s, x: %s>' % (self.__class__.__name__, hex(id(self)), self.__x)

    t = Test(10)
    print(t)
    t.x = 20
    print(t)
    t.x = -30

# Generated at 2022-06-21 22:08:02.819028
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Test whether the __get__ method of roclassproperty works as planned.

    I found issues with this method, so here is a test
    """
    class A(object):
        @roclassproperty
        def value(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.value == 'A'
    assert B.value == 'B'



# Generated at 2022-06-21 22:08:09.934511
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class SampleClass(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def some_class_property(cls):
            return cls, "class property"

        @property
        def some_property(self):
            return self, "property"

    sc1 = SampleClass(1)
    sc2 = SampleClass(2)

    assert sc1.some_class_property == (SampleClass, "class property")
    assert sc2.some_class_property == (SampleClass, "class property")

    assert sc1.some_property == (sc1, "property")
    assert sc2.some_property == (sc2, "property")


# Generated at 2022-06-21 22:08:14.260458
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def set_name(self, value):
            self.__name = value

        name = setterproperty(set_name)

    test = Test()
    test.name = 'John Doe'



# Generated at 2022-06-21 22:08:25.452308
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        def __init__(self):
            self.internal_data = []

        @setterproperty
        def setterproperty_data(self, data):
            self.internal_data = data

        def add_data(self, x):
            self.internal_data.append(x)

    test = TestClass()
    test.add_data("test1")
    test.add_data("test2")
    test.add_data("test3")
    test.add_data("test4")
    assert test.internal_data == ["test1", "test2", "test3", "test4"]
    test.setterproperty_data = ["test5", "test6", "test7", "test8"]

# Generated at 2022-06-21 22:08:28.659027
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls

    class B(A):
        pass

    assert A.test is A
    assert B.test is B



# Generated at 2022-06-21 22:08:31.095021
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def a(cls):
            print('Computing a')
            return cls

    assert C.a is C.a


# Generated at 2022-06-21 22:08:41.847776
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def a_class_property(cls):
            print('A.a_class_property')
            return 100

        def __init__(self):
            pass

    class B(A):
        pass

    class C(B):

        @lazyclassproperty
        def a_class_property(cls):
            print('C.a_class_property')
            return 200

    a = A()
    b = B()
    c = C()
    print(a.a_class_property, b.a_class_property, c.a_class_property)
    """
    output:
    A.a_class_property
    C.a_class_property
    100 200 200
    """


# Generated at 2022-06-21 22:08:49.457678
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Father(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class Child1(Father):
        pass

    class Child2(Father):
        pass

    assert Father.x == 'Father'
    assert Child1.x == 'Child1'
    assert Child2.x == 'Child2'



# Generated at 2022-06-21 22:08:56.001403
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def bar(cls):
            return "bar"

    assert Foo.bar == "bar"
    assert Foo().bar == "bar"

    with raises(AttributeError):
        Foo.bar = "anotherbar"

    with raises(AttributeError):
        Foo().bar = "anotherbar"



# Generated at 2022-06-21 22:08:59.709023
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        print('Calling foo()')
        return 42

    class A(object):
        pass

    class B(object):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42



# Generated at 2022-06-21 22:09:02.072547
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'

# Generated at 2022-06-21 22:09:05.674634
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        a = None

        @setterproperty
        def foo(self, value):
            self.a = value

    x = A()
    x.foo = 'foo'
    assert x.a == 'foo'
    assert x.foo == 'foo'



# Generated at 2022-06-21 22:09:11.629259
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @readonlyclassproperty
        def foo(cls):
            return 'bar'
    assert A.foo == 'bar'

    # Test exception handling.
    with pytest.raises(AttributeError):
        A.foo='baz'

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 22:09:14.813912
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def prop(cls):
            return True
    a = A()
    assert a.prop
    with pytest.raises(AttributeError):
        a.prop = False
    with pytest.raises(AttributeError):
        del a.prop


# Generated at 2022-06-21 22:09:18.846811
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def getter(self):
            return self._x

        @setterproperty
        def setter(self, value):
            self._x = value

    test = Test()
    test.setter = 3
    assert test.getter() == 3


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:09:23.048162
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        _val = 10
        @setterproperty
        def val(self, value):
            self._val = value
        @property
        def val(self):
            return self._val

    foo = Foo()
    assert foo.val == 10
    foo.val = 5
    assert foo.val == 5

# Generated at 2022-06-21 22:09:27.522352
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class T(object):
        @roclassproperty
        def foo(cls):
            return 42

    t = T()
    assert t.foo == 42
    assert T.foo == 42, '__get__ does not work for class'

    try:
        t.foo = 3
    except AttributeError:
        pass
    else:
        raise Exception('Writing to class property works !')


# Generated at 2022-06-21 22:09:29.672285
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def class_name(cls):
            return cls.__name__

    assert A.class_name == "A"



# Generated at 2022-06-21 22:09:40.434250
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def lazy(cls):
            return [cls, []]
    class C1(C): pass
    class C2(C): pass
    assert C.lazy == C.lazy == [C, []]
    assert C1.lazy == C1.lazy == [C1, []]
    assert C2.lazy == C2.lazy == [C2, []]
    assert C.lazy != C1.lazy != C2.lazy


# Generated at 2022-06-21 22:09:43.430469
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:09:52.740273
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def method(cls):
            print("A")
            return 1
    class B(A):
        @lazyperclassproperty
        def method(cls):
            print("B")
            return 2
    class C(A):
        @lazyperclassproperty
        def method(cls):
            print("C")
            return 3
    class D(A):
        @lazyperclassproperty
        def method(cls):
            print("D")
            return 4
    class E(B):
        @lazyperclassproperty
        def method(cls):
            print("E")
            return 5
    class F(B):
        @lazyperclassproperty
        def method(cls):
            print("F")
            return 6
   

# Generated at 2022-06-21 22:09:57.966320
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestLazyClassProperty(object):
        a_lazy_property = lazyclassproperty(lambda c: 'lazy property after first call')
        def __init__(self):
            assert self.a_lazy_property == 'lazy property after first call'

    TestLazyClassProperty()
    TestLazyClassProperty()


# Generated at 2022-06-21 22:10:00.683326
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # roclassproperty.__get__
    class A(object):
        @roclassproperty
        def property(cls):
            return 'value'

    assert_equal(A.property, 'value')


# Generated at 2022-06-21 22:10:06.167706
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def p1(cls):
            return 'p1'
        @roclassproperty
        def p2(cls):
            return 'p2'

    assert A.p1 == 'p1'
    assert A().p1 == 'p1'
    assert A.p2 == 'p2'
    assert A().p2 == 'p2'

# Generated at 2022-06-21 22:10:15.184251
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def a(cls):
        return cls.__name__
    def b(cls):
        return cls.__name__

    class T:
        prop = lazyperclassproperty(a)
        prop2 = lazyperclassproperty(b)

    assert T.prop == 'T'
    assert T.prop2 == 'T'

    class T2(T):
        pass

    assert T2.prop == 'T2'
    assert T2.prop2 == 'T2'

    T.prop = 'override'
    T2.prop2 = 'override'

    assert T.prop == 'override'
    assert T2.prop2 == 'override'

    assert T2.prop != 'override'
    assert T.prop2 != 'override'

    class T3(T):
        pass

# Generated at 2022-06-21 22:10:22.656791
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Setup test data
    class TestClass(object):
        @roclassproperty
        def foo(cls):
            return 'class property'

    test_obj = TestClass()

    expected_class_property = 'class property'

    # Execute the SUT
    result_class_property = TestClass.foo

    # Verify the results
    assert expected_class_property == result_class_property

    # Verify that a descriptor object is returned when accessing the property through the class object
    assert isinstance(TestClass.foo, roclassproperty)

    # Verify that the return value of the descriptor is returned when accessing the property through the instance object
    assert expected_class_property == test_obj.foo



# Generated at 2022-06-21 22:10:25.881150
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class ClassWithProperty(object):
        def __init__(self):
            self.a = None

        @setterproperty
        def setter_method(self,value):
            self.a = value

    c = ClassWithProperty()
    c.setter_method = 5
    assert c.a == 5

# Generated at 2022-06-21 22:10:27.467183
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        @setterproperty
        def a(self, val):
            self._a = val

    a = A()
    a.a = 1
    assert a._a == 1


# Generated at 2022-06-21 22:10:44.183837
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    a, b, c = 1, 2, 3
    class test_roclassproperty___get___class0:
        @roclassproperty
        def test_roclassproperty___get___fun0(self):
            return a
    class test_roclassproperty___get___class1(test_roclassproperty___get___class0):
        @roclassproperty
        def test_roclassproperty___get___fun1(self):
            return b
    class test_roclassproperty___get___class2(test_roclassproperty___get___class1):
        @roclassproperty
        def test_roclassproperty___get___fun2(self):
            return c
    assert test_roclassproperty___get___class0.test_roclassproperty___get___fun0 == a
    assert test_roclassproperty___

# Generated at 2022-06-21 22:10:52.043020
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls): return 7
    class B(A): pass
    class C(B): pass
    assert A.x == 7
    assert B.x == 7
    assert C.x == 7
    try:
        B.x = 6
    except TypeError:
        pass
    else:
        assert False
    try:
        C.x = 6
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 22:10:53.807315
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.__a = None
        @setterproperty
        def a(self, value):
            self.__a = value
            return self.__a

    a = A()
    a.a = 1
    assert a.a == 1
    a.a = 2
    assert a.a == 2



# Generated at 2022-06-21 22:11:01.347568
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(klass):
            return 42

    # Test it's lazy and properly cached
    assert not hasattr(Foo, '_lazy_bar')
    assert Foo.bar == 42
    assert hasattr(Foo, '_lazy_bar')
    assert Foo.bar == 42

    # Test it shares the value between class and subclasses
    class Foobar(Foo):
        pass
    assert Foobar.bar == 42

    Foo.bar = 24
    # Test it doesn't share the cached value between classes
    class Foobar(object):
        @lazyclassproperty
        def bar(klass):
            return 42
    assert Foobar.bar == 42
    assert Foo.bar == 24


if __name__ == '__main__':
    test_l

# Generated at 2022-06-21 22:11:04.555033
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class B(object):
        @lazyclassproperty
        def A(cls):
            return 'x'

    assert B.A == 'x'
    assert B.A == 'x'



# Generated at 2022-06-21 22:11:10.198237
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from scal3 import locale_man
    from scal3.ui_gtk import LocaleGetter
    import gtk

    class LocaleSetter(LocaleGetter):
        @setterproperty
        def locale(self):
            return locale_man

    ls = LocaleSetter()
    ls.locale = gtk
    ls.locale = locale_man



# Generated at 2022-06-21 22:11:17.830871
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Example(object):
        def __init__(self):
            self.counter = 0

        @lazyclassproperty
        def myproperty(self):
            self.counter += 1
            return self.counter

    a = Example()
    b = Example()
    # There are two different instances of the object, so their counters start at zero

    assert a.myproperty == 1
    assert b.myproperty == 1
    # However, this property is the same for both objects, so they both return 1,
    # but the counter is only increased once

    assert a.counter == 1
    assert b.counter == 1
    # Confirm that the internal counter was only increased once

    assert a.myproperty == 1
    assert b.myproperty == 1
    # The value has already been calculated, so it should return the same

    assert a.counter == 1

# Generated at 2022-06-21 22:11:24.259231
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class foo:
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert foo.bar == 'bar'

    class bar(foo):
        pass

    assert bar.bar == 'bar'

    class baz(foo):
        @classproperty
        def bar(cls):
            return 'baz'

    assert baz.bar == 'baz'


# Generated at 2022-06-21 22:11:31.612257
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):

        def __init__(self):
            self.a = 'A'


    class B(A):
        pass

    class C(A):

        def __init__(self):
            super(C, self).__init__()
            self.a = 'C'


    class D(A):
        pass

    @lazyperclassproperty
    def a(cls):
        return getattr(cls(), 'a')

    assert a == 'A'
    assert B.a == 'A'
    assert C.a == 'C'
    assert D.a == 'A'

    class E(object):
        pass

    assert E.a == 'A'



# Generated at 2022-06-21 22:11:34.041360
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class ClassA:
        @roclassproperty
        def value(cls):
            return "value"


# Generated at 2022-06-21 22:11:57.537548
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        @lazyperclassproperty
        def b(cls):
            return 'b'

    class C(A):
        @lazyperclassproperty
        def b(cls):
            return 'c'

    print(A.a)
    print(B.a)
    print(C.a)
    print(B.b)
    print(C.b)



# Generated at 2022-06-21 22:12:05.986393
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Vehicle(object):
        def __init__(self, fuel):
            self.fuel = fuel
    
        @roclassproperty
        def type(cls):
            return 'vehicle'
    
        @property
        def fuel_left(self):
            return self.fuel
    
        @fuel_left.setter
        def fuel_left(self, amount):
            self.fuel = amount
    
    class Car(Vehicle):
        @property
        def doors(self):
            return self.door
    
        @doors.setter
        def doors(self, number):
            self.door = number
    
    assert Vehicle.type == "vehicle"
    assert Car.type == "vehicle"
    
    carOne = Car(80)
    carOne.doors = 5
    assert carOne.fuel

# Generated at 2022-06-21 22:12:09.998421
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    import doctest
    failures, _ = doctest.testmod()
    if failures > 0:
        raise RuntimeError("%d errors." % failures)


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-21 22:12:19.026172
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 5

    class B(A):
        @lazyperclassproperty
        def test(cls):
            return 10

    assert A.test == 5
    assert B.test == 10
    assert A().test == 5
    a = A()
    b = B()
    assert a.test == 5
    assert b.test == 10
    a.test = 15
    assert a.test == 15
    assert b.test == 10
    assert B.test == 10
    assert A.test == 5
    b.test = 20
    assert b.test == 20
    assert B.test == 20
    assert A.test == 5



# Generated at 2022-06-21 22:12:24.653420
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            A.was_created = True
        @lazyclassproperty
        def x(cls):
            return A()

    class B(A):
        pass

    assert not hasattr(A, '_lazy_x')
    assert not hasattr(B, '_lazy_x')
    assert not hasattr(A, 'was_created')
    x = A.x
    assert A.was_created
    assert not hasattr(B, 'was_created')
    assert A.x is x
    y = B.x
    assert not hasattr(B, 'was_created')
    assert B.x is y



# Generated at 2022-06-21 22:12:36.216305
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    from unittest import main, TestCase
    class Test(TestCase):
        @roclassproperty
        def val(cls):
            return cls.__name__
        @classmethod
        def test_roclassproperty(cls):
            cls1, cls2 = Test, Test()
            self.assertEqual(cls.val, 'Test')
            self.assertEqual(cls1.val, 'Test')
            self.assertEqual(cls2.val, 'Test')
            with self.assertRaises(AttributeError):
                cls.val = None
            with self.assertRaises(AttributeError):
                cls1.val = None
            with self.assertRaises(AttributeError):
                cls2.val = None
    main()

# Generated at 2022-06-21 22:12:45.389424
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Testme:
        @lazyperclassproperty
        def test(cls):
            return 'test in class %s' % cls.__name__

        @classproperty
        def name(cls):
            return cls.__name__

    class Derived(Testme):
        pass

    t = Testme()
    assert t.test == 'test in class Testme'
    assert t.name == 'Testme'

    d = Derived()
    assert d.test == 'test in class Derived'
    assert d.name == 'Derived'

    assert Testme.test == 'test in class Testme'
    assert Testme.name == 'Testme'

    assert Derived.test == 'test in class Derived'
    assert Derived.name == 'Derived'

# Generated at 2022-06-21 22:12:48.904657
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def name(self,name):
            self._name = name
    foo = Foo()
    foo.name = 'Jack'
    assert foo._name == 'Jack'


# Generated at 2022-06-21 22:12:53.901236
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        _flag = 0


# Generated at 2022-06-21 22:12:59.322380
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test():
        @setterproperty
        def prop(self):
            return self._i

        @prop.setter
        def prop(self, value):
            self._i = value

    t = Test()
    t.prop = 1
    assert t.prop == 1
    t.prop = 2
    assert t.prop == 2



# Generated at 2022-06-21 22:13:43.924842
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def num(cls):
            return 6

    class B(A):
        pass

    class C:
        @lazyperclassproperty
        def num(cls):
            return 5

    class D(C):
        pass

    a = A()
    b = B()
    c = C()
    d = D()

    assert a.num == 6
    assert b.num == 6
    assert c.num == 5
    assert d.num == 5

    assert A.num == 6
    assert B.num == 6
    assert C.num == 5
    assert D.num == 5

    assert a.num == 6
    assert b.num == 6
    assert c.num == 5
    assert d.num == 5


# Generated at 2022-06-21 22:13:53.264791
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, value):
            self._value = value
        @setterproperty
        def value(self, new_value):
            '''
            Get/set value.
            '''
            self._value = new_value
        @property
        def value(self):
            return self._value

    Test.value = 'new value'
    assert Test.value == 'new value'

    Test2 = Test('old value')

    Test2.value = 'new value2'
    assert Test2.value == 'new value2'



# Generated at 2022-06-21 22:13:58.718378
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def func(self, v):
            self.x = v
            return self.x
        func = func(func)

    a = A()
    assert a.func == a
    assert a.x == a



# Generated at 2022-06-21 22:14:02.763131
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:14:08.723537
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return cls

    class B(A):
        pass

    assert A.x == A
    assert B.x == B
    assert A().x == A
    assert B().x == B


# Generated at 2022-06-21 22:14:13.825450
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class foo(object):
        def __init__(self):
            self._x = 0

        def getx(self):
            return self._x

        def setx(self, value):
            self._x = value

        x = setterproperty(setx, getx.__doc__)


    f = foo()
    f.x = 1
    assert(f.x == 1)



# Generated at 2022-06-21 22:14:22.761332
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class Point2D(object):
        __slots__ = ['_x', '_y', '_z']

        def __init__(self, x=None, y=None, z=None):
            self._x = x
            self._y = y
            self._z = z

        def _validate_xyz(self):
            x = self._x
            y = self._y
            z = self._z
            assert (x is None or isinstance(x, int)), 'Point2D x should be int'
            assert (y is None or isinstance(y, int)), 'Point2D y should be int'
            assert (z is None or isinstance(z, int)), 'Point2D z should be int'


# Generated at 2022-06-21 22:14:25.286907
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'bar'

    assert A.__dict__['foo'].__class__ == roclassproperty


# Generated at 2022-06-21 22:14:30.210722
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):
        def __init__(self, n):
            self.n = n

        @setterproperty
        def n(self, n):
            self._n = n

    t = TestSetterProperty(1)
    assert t.n == 1
    t.n = 2
    assert t.n == 2



# Generated at 2022-06-21 22:14:39.972862
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def temp(cls):
            return "foo"

    assert A.temp == "foo"
    assert A.temp == "foo"
    assert A().temp == "foo"

    class B(A):
        pass

    assert B.temp == "foo"
    assert B.temp == "foo"
    assert B().temp == "foo"

    A.temp = "bar"
    assert A.temp == "bar"
    assert B.temp == "foo"
    assert A().temp == "bar"
    assert B().temp == "foo"
    assert B().temp == "foo"

    # Test for side-effects
    class C:
        count = 0

        @lazyclassproperty
        def temp(cls):
            cls.count += 1

# Generated at 2022-06-21 22:15:53.280139
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A():
        def f(self, value):
            self.value = value

        def g(self):
            return self.value
        p = setterproperty(f, "I am the property.")

    a = A()
    a.p = "I am the value"
    assert a.g() == "I am the value"
    assert a.p.__doc__ == "I am the property."


# Generated at 2022-06-21 22:16:03.472080
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def foo(self):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo
    assert A().foo() == 'foo'
    assert B().foo() == 'foo'

    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo
    assert A().foo == 'foo'
    assert B().foo == 'foo'



# Generated at 2022-06-21 22:16:11.620348
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()
    assert a.x == b.x == c.x == 'x'

    A.x = 'y'

    assert a.x == b.x == c.x == 'y'

    a.x = 'z'

    assert a.x == 'z'
    assert b.x == c.x == 'y'

    B.x = 'q'

    assert a.x == 'z'
    assert b.x == 'q'
    assert c.x == 'y'

    C.x = 'w'


# Generated at 2022-06-21 22:16:20.572930
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            if value < 0:
                self._x = 0
            elif value > 1000:
                self._x = 1000
            else:
                self._x = value

        def get_x(self):
            """I'm the 'x' property."""
            return self._x

    myinst = MyClass()
    myinst.x = 10
    assert myinst.get_x() == 10
    assert myinst.x is myinst.get_x()
    myinst.x = -11
    assert myinst.get_x() == 0
    myinst.x = 1000
    assert myinst.get_x() == 1000



# Generated at 2022-06-21 22:16:28.208590
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        num = 0

        @staticmethod
        def f():
            A.num += 1
            return A.num

        a = lazyclassproperty(f)


    class B(A):
        pass


    assert A.a == 1
    assert A.a == 1
    assert B.a == 2
    assert B.a == 2

    class C(A):
        @staticmethod
        def f2():
            A.num += 1
            return A.num

        a = lazyclassproperty(f2)

    assert C.a == 3



# Generated at 2022-06-21 22:16:34.129273
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    >>> class A(object):
    ...     def __init__(self, x=1234):
    ...         pass
    ...     def __setattr__(self, attr, value):
    ...         raise AttributeError('Attempt to set attribute %r! ' % attr)
    >>> a = A()
    >>> a.x
    Traceback (most recent call last):
    ...
    AttributeError: 'A' object has no attribute 'x'
    >>> a.x = 2
    Traceback (most recent call last):
    ...
    AttributeError: Attempt to set attribute 'x'!
    >>>
    """

# unit test for lazyclassproperty

# Generated at 2022-06-21 22:16:38.565687
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):
        @roclassproperty
        def f(cls):
            return "it worked!"

    assert A.f == "it worked!"

    # should not be able to set the value
    a = A()
    try:
        a.f = 5
    except Exception as e:
        assert isinstance(e, AttributeError)



# Generated at 2022-06-21 22:16:46.074349
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Test:
        def __init__(self, a, b):
            self._a = a
            self._b = b

        @setterproperty
        def a(self, value):
            self._a = value

        def get_a(self):
            return self._a

        def get_b(self):
            return self._b

    test1 = Test(10, 20)
    assert test1.get_a() == 10
    assert test1.get_b() == 20
    test1.a = 15
    assert test1.get_a() == 15
    assert test1.get_b() == 20


# Generated at 2022-06-21 22:16:49.060815
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def set_num(self, value):
            self.__num = value

        @setterproperty
        def num(self):
            return self.__num

    a = A()
    a.num = 123

    assert a.__num == 123
    assert a.num == 123

# Generated at 2022-06-21 22:16:52.137124
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'

