

# Generated at 2022-06-21 22:07:44.566339
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            return "hello"
    assert A.x == "hello"
    assert A().x == "hello"

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-21 22:07:47.903299
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return cls.__name__

    assert Foo.bar == 'Foo'
    assert Foo._lazy_bar == 'Foo'


# Generated at 2022-06-21 22:07:51.177807
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test:
        class Test2:
            y = roclassproperty(lambda a: 2)
        t2 = Test2()

    assert Test.Test2.y == 2
    assert Test.t2.y == 2
    assert Test.t2.__doc__ == 'Read-only class property descriptor factory/decorator.'



# Generated at 2022-06-21 22:08:00.391258
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, y):
            self.y = y

        @roclassproperty
        def x(cls):
            return 'x from class'

    class B(A):
        def __init__(self, y):
            super(B, self).__init__(y)

    a = A(1)
    assert 'x from class' == a.x
    with pytest.raises(AttributeError):
        a.x = 1

    a = A(1)
    assert 'x from class' == a.x
    assert 1 == a.y

    b = B(2)
    assert 'x from class' == b.x
    assert 2 == b.y


# Generated at 2022-06-21 22:08:07.981796
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class _Test(object):
        def _get_name(cls):
            return cls.__name__

        name = roclassproperty(_get_name)
        name2 = classproperty(_get_name)
        name3 = roclassproperty(_get_name)

    assert _Test.name == '_Test'
    assert _Test.name2 == '_Test'
    assert _Test.name3 == '_Test'

    t = _Test()
    t.name4 = _Test.name2
    assert t.name4 == '_Test'


# Generated at 2022-06-21 22:08:09.966829
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def test(cls):
            prin

# Generated at 2022-06-21 22:08:14.678220
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class ABC:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, val):
            self._x = val

    a = ABC()
    a.x = 133
    assert a._x == 133, a._x



# Generated at 2022-06-21 22:08:25.831458
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        print('Calculating foo')
        return 42

    class Bar(object):
        pass

    class Baz(Bar):
        pass

    assert Baz.foo == 42
    assert Bar.foo == 42
    assert Baz.__dict__['_lazy_foo'] == 42
    assert Bar.__dict__['_lazy_foo'] == 42
    assert Bar.foo is Baz.foo

    # Set the attribute on Bar to something else.
    # This should not be overridden when we access the property on the
    # inheriting class Baz.
    Bar.foo = 111
    assert Baz.foo == 42
    assert Bar.foo == 111
    assert Bar.foo is not Baz.foo

    # Delete the attribute from Bar and make sure it gets recalculated
    # when we access it

# Generated at 2022-06-21 22:08:30.300153
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Sample:
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self, value):
            self._x = value
            return self._x
    # Update the x value
    obj = Sample()
    obj.x = 10
    # Check the updated value
    assert obj.x == 10



# Generated at 2022-06-21 22:08:41.583388
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import weakref

    class A:
        @lazyclassproperty
        def prop(cls):
            return 1

    a = A()

    assert a.prop == 1
    assert A.prop == 1
    assert a.prop == 1

    # Make sure A.prop is cached on the class, not an instance
    # by comparing memory addresses
    assert hex(id(a.prop)) == hex(id(A.prop))
    assert hex(id(a.prop)) != hex(id(a.__dict__['prop']))

    # Make sure A.prop is a weakref, which will disappear if the only
    # reference to it is the class definition
    assert isinstance(A.__dict__['_lazy_prop'], weakref.ref)
    del A
    gc.collect()

# Generated at 2022-06-21 22:08:47.962111
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1


# Generated at 2022-06-21 22:08:54.058374
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            cls.val = 1
            return cls.val

        @lazyclassproperty
        def y(cls):
            cls.val = 2
            return cls.val

    assert A.x == 1
    assert A.val == 1
    assert A.x == 1

    assert A.y == 2
    assert A.val == 2
    assert A.y == 2



# Generated at 2022-06-21 22:08:58.280326
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def counter(cls):
            return sum(range(100))

    assert TestClass.counter == 4950
    assert TestClass.counter == 4950
    assert TestClass.counter == 4950

test_lazyclassproperty()


xrange = range



# Generated at 2022-06-21 22:09:02.290794
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Base(object):
        @roclassproperty
        def roprop(cls):
            return cls
    class Derived(Base):
        pass
    assert type(Base.roprop) is type
    assert type(Derived.roprop) is type
    assert Derived.roprop is Derived



# Generated at 2022-06-21 22:09:12.609617
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base():
        @lazyperclassproperty
        def prop1(cls):
            return 'b1'

        classproperty_var = 2

    class Derived(Base):
        @lazyperclassproperty
        def prop1(cls):
            return super().prop1 + "d1"

        classproperty_var = 3

    assert Base.prop1 == 'b1'
    assert Derived.prop1 == 'b1d1'

    (Derived.prop1 is Derived.prop1) == True #pylint:disable=expression-not-assigned
    (Base.prop1 is Base.prop1) == True #pylint:disable=expression-not-assigned
    (Derived.prop1 is Base.prop1) == False #pylint:disable=expression-not-assigned


# Generated at 2022-06-21 22:09:17.612925
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self, name):
            self._name = name

        @lazyclassproperty
        def name(cls):
            return cls._name


    class B(A):
        _name = "B"

    class C(A):
        _name = "C"

    assert A.name == "A"
    assert B.name == "B"
    assert C.name == "C"

# Generated at 2022-06-21 22:09:21.238925
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    with pytest.raises(AttributeError):
        A().foo


# Generated at 2022-06-21 22:09:29.339547
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop1(cls):
            return 'foo'

        @lazyclassproperty
        def prop2(cls):
            return 'bar'

    class B(A):
        pass

    class C(B):
        @lazyclassproperty
        def prop2(cls):
            return 'baz'

    class D(C):
        @lazyclassproperty
        def prop2(cls):
            return 'quux'

    assert A.prop1 == 'foo'
    assert A.prop2 == 'bar'
    assert B.prop1 == 'foo'
    assert B.prop2 == 'bar'
    assert C.prop1 == 'foo'
    assert C.prop2 == 'baz'
    assert D.prop1 == 'foo'


# Generated at 2022-06-21 22:09:33.091098
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    A.prop = 2
    assert A.prop == 2
    assert B.prop == 1


# Generated at 2022-06-21 22:09:38.077910
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def prop(self):
            return 3

    class TestSubClass(TestClass):
        pass

    assert TestClass().prop == TestSubClass().prop == 3
    TestClass().prop == 1


# ----------------------------------------------------------------------------------------------------------------------

# Ensure that the default value of defaultdict is suitable to be used in multithreading
if not isinstance(_defaultdict(), _defaultdict):
    raise AssertionError("The default value of defaultdict is not a defaultdict. This is a bug in Python. You must "
                         "install a version of Python that has the fix to this bug.")



# Generated at 2022-06-21 22:09:47.368457
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def _setter(self, x):
            self._x = x

        def _getter(self):
            return self._x

        _x = 1

        @setterproperty
        def foo(self):
            return 42

        @setterproperty
        def bar(self):
            return 42

    t = Test()
    t.foo = 3
    assert t.bar == 3
    assert t.foo == 3

# Generated at 2022-06-21 22:09:54.726458
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        @setterproperty
        def a(self, value):
            print("setter for a called!")
            self.a = value

        @setterproperty
        def b(self, value):
            print("setter for b called!")
            self.b = value

    a = A()
    print(a.a)
    print(a.b)
    a.a = 10
    a.b = 20
    print(a.a)
    print(a.b)



# Generated at 2022-06-21 22:10:05.507844
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # require more than one paramter
    try:
        s = setterproperty(lambda obj: None, lambda obj, value: None)
    except Exception as e:
        print(e)
    # require a parameter other than self
    try:
        s = setterproperty(lambda self: None)
    except Exception as e:
        print(e)
    # require a paramaeter other than self and value
    try:
        s = setterproperty(lambda self, value: None, lambda self, value, other: None)
    except Exception as e:
        print(e)
    # require two parameters other than self and value
    try:
        s = setterproperty(lambda self, value: None, lambda self, value, other1, other2: None)
    except Exception as e:
        print(e)
    # require one

# Generated at 2022-06-21 22:10:14.415234
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ClsWithProps(object):
        def __init__(self):
            self.class_prop = 1
            self.lazy_cls = 2

        @lazyperclassproperty
        def per_class_prop(self):
            return 1

        @lazyperclassproperty
        def per_class_prop_add(self):
            return self.lazy_cls + self.per_class_prop

        @lazyclassproperty
        def self_prop(self):
            return self

        def test(self):
            pass

    class SubClsWithProps(ClsWithProps):
        def __init__(self):
            super(SubClsWithProps, self).__init__()
            self.sub_prop = 10


# Generated at 2022-06-21 22:10:19.226837
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Class(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @roclassproperty
        def value(cls):
            return cls.__name__

    print(Class.value)
    ins = Class(1,2)
    print(ins.__class__)


# Generated at 2022-06-21 22:10:24.545490
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def method(cls):
            return "method A"
    class B(A):
        @lazyperclassproperty
        def method(cls):
            return "method B"
    class C(A):
        @lazyperclassproperty
        def method(cls):
            return "method C"

    assert A.method == 'method A'
    assert B.method == 'method B'
    assert C.method == 'method C'



# Generated at 2022-06-21 22:10:26.197656
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def test(cls):
            pass
    assert Test.test is None


# Generated at 2022-06-21 22:10:28.860941
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestClass(object):
        def __init__(self):
            self._value = None

        def _set_value(self, value):
            self._value = value

        value = setterproperty(_set_value)

    test = TestClass()
    assert test._value is None
    test.value = "value"
    assert test._value == "value"


# Generated at 2022-06-21 22:10:37.594984
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Define a Class
    class Test(object):
        # Define instance variable
        @lazyclassproperty
        def lazyvar(cls):
            # Class variable
            cls.var = cls.var + 1
            return cls.var

    Test.var = 0
    # Define another Class
    class Test2(Test):
        pass
    Test2.var = 1

    # Test variable for class Test
    assert Test.lazyvar == 1
    assert Test.lazyvar == 1

    # Test variable for class Test2
    assert Test2.lazyvar == 2
    assert Test2.lazyvar == 2



# Generated at 2022-06-21 22:10:40.303477
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class M(object):
        @roclassproperty
        def a(cls):
            return 1

    assert M.a == 1
    assert M().a == 1



# Generated at 2022-06-21 22:10:53.410551
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def fn(cls):
            "Lazy class property"
            return B()

    class B:
        def __init__(self):
            self.a = 1

    a = A()
    b = a.fn
    assert b.a == 1
    assert a.fn is b



# Generated at 2022-06-21 22:11:01.213363
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Tests that method __set__ of class setterproperty called.
    """

    @setterproperty
    def test_func_method(self, value):
        """
        Setter method to test class setterproperty.
        """
        self.__value = value

    class TestClass(object):
        @setterproperty
        def test_func_property(self, value):
            """
            Setter property to test class setterproperty.
            """
            self.__value = value

    class TestClass_Inherit(TestClass):
        pass

    # Unit test for method __set__ of class setterproperty.
    obj = TestClass()
    obj.__value = 0
    obj.test_func_method = "test"
    assert obj.__value == "test"

    obj = TestClass_Inherit

# Generated at 2022-06-21 22:11:06.318661
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # Usage Example
    class C(object):
        @roclassproperty
        def x(cls):
            return "hello world"

    c1 = C()

# Generated at 2022-06-21 22:11:11.880924
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = 0

        @setterproperty
        def x(self, value):
            self._x = value

    c = C()
    assert(c._x == 0)
    c.x = 1
    assert(c._x == 1)

if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-21 22:11:16.153581
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class cls(object):
        @roclassproperty
        def prop(cls):
            return cls

    assert cls.__class__ == cls.__class__.prop

    def f():
        cls.prop = 10

    assert_raises(AttributeError, f)

    def g():
        del cls.prop

    assert_raises(AttributeError, g)



# Generated at 2022-06-21 22:11:24.040630
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    from plenum.common.util import Hasher

    class A:
        _hasher = Hasher()

        @roclassproperty
        def hasher(cls):
            return cls._hasher

    assert A.hasher == A.hasher
    assert A.hasher.get_crypto_hash_instance()

    class B(A):
        pass

    assert B.hasher == B.hasher
    assert A.hasher == B.hasher



# Generated at 2022-06-21 22:11:26.700994
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:11:31.885343
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        class_var = 1
        @lazyperclassproperty
        def lazyprop(cls):
            return cls.class_var

    class Derived(Base):
        class_var = 2
        @lazyperclassproperty
        def lazyprop(cls):
            return cls.class_var

    assert Base.lazyprop == 1
    assert Derived.lazyprop == 2
    assert Base.lazyprop == 1
    assert Derived.lazyprop == 2

# Generated at 2022-06-21 22:11:35.233656
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def asdf(self, val):
            self.f = val

    f = Foo()
    f.asdf = 5
    assert f.f == 5


# Generated at 2022-06-21 22:11:37.337369
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def test(self):
            return 'test'

    a = A()

    assert a.test == 'test'
    assert A.test == 'test'

# Generated at 2022-06-21 22:11:58.274616
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class foo(object):
        def __init__(self):
            self.__a = 1

        @setterproperty
        def a(self, value):
            self.__a = value

        @property
        def a(self):
            return self.__a

    fu = foo()
    fu.a = 5
    assert fu.a == 5


# Generated at 2022-06-21 22:12:04.901202
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class roclasspropertyClass(object):
        def foo(cls):
            return cls.__name__

    # Assert that getter-function is set to 'foo'
    assert roclasspropertyClass.foo.f.__name__ == 'foo'

    # Assert that eval(roclasspropertyClass.foo.f) == 'roclasspropertyClass')
    assert roclasspropertyClass.foo.f(roclasspropertyClass) == 'roclasspropertyClass'

    # Assert that roclasspropertyClass.foo == 'roclasspropertyClass'
    assert roclasspropertyClass.foo == 'roclasspropertyClass'



# Generated at 2022-06-21 22:12:09.676511
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def roprop(cls):
            return 'roprop'

        @classproperty
        def roprop2(cls):
            return 'roprop2'

        bar = roclassproperty(lambda cls: 'bar')

    assert Foo.roprop == 'roprop'
    assert Foo.roprop2 == 'roprop2'
    assert Foo.bar == 'bar'

    foo = Foo()
    assert foo.roprop == 'roprop'
    assert foo.roprop2 == 'roprop2'
    assert foo.bar == 'bar'


# Generated at 2022-06-21 22:12:18.346737
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # We suppose that classproperty behaves same as roclassproperty

    def empty_function():
        return None

    class Parent:
        p_prop = classproperty(empty_function)

    class Child(Parent):
        pass

    parent_prop = Parent.p_prop
    assert isinstance(parent_prop, classproperty)

    assert parent_prop is Parent.p_prop
    assert parent_prop is Child.p_prop

    # Check that classproperty was called and returned a result
    parent_prop.f = MagicMock(return_value=234)
    assert Parent.p_prop == 234
    parent_prop.f.assert_called_once_with(Parent)



# Generated at 2022-06-21 22:12:21.413252
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert hasattr(A, 'getx')
    assert not hasattr(A, 'x')
    assert A.x == 1
    try:
        A.x = 2
    except AttributeError:
        pass
    else:
        raise AttributeError("shouldn't be able to set attribute")



# Generated at 2022-06-21 22:12:24.766289
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Person(object):
        @roclassproperty
        def species(cls):
            return 'Human'

    assert Person.species == 'Human'


# Generated at 2022-06-21 22:12:29.517998
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
  class BadClass(object):
      def __init__(self, val):
          self.__ro_value = val

      @roclassproperty
      def ro_value(cls):
          return cls.__ro_value

  instance = BadClass(1)
  instance.ro_value = 2
  assert instance.ro_value == 1

# Generated at 2022-06-21 22:12:36.707777
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class B(object):
        def __init__(self, s):
            self._s = s

        @setterproperty
        def s(self, value):
            print(self, value)
            self._s = value

    b = B(1)
    assert b._s == 1
    b.s = 2
    assert b._s == 2
    assert b.__dict__['_s'] == 2
    assert getattr(b, '_s') == 2

# Generated at 2022-06-21 22:12:38.702545
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls

    assert Foo.bar == Foo
    assert Foo().bar == Foo



# Generated at 2022-06-21 22:12:49.060806
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo:
        def __init__(self):
            self._a = 0
            self._b = 0
            self._c = 0

        @setterproperty
        def a(self, value):
            self._a = value

        @setterproperty
        def b(self, value):
            self._b = self._a * value

        @setterproperty
        def c(self, value):
            self._c = self._b * value

    f = Foo()
    f.a = 2
    f.b = 3
    f.c = 5
    if f._a != 2:
        log.error('self._a != 2')
        return False
    if f._b != 6:
        log.error('self._b != 6')
        return False
    if f._c != 30:
        log.error

# Generated at 2022-06-21 22:13:33.192683
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class MyClass(object):
        ATTRIBUTE_VALUE = "some value"
        @roclassproperty
        def attribute(cls):
            return cls.ATTRIBUTE_VALUE

    # Check the method __get__
    assert MyClass.attribute == MyClass.ATTRIBUTE_VALUE
    assert MyClass.attribute is MyClass.ATTRIBUTE_VALUE

    # Check that the descriptor is not callable
    with pytest.raises(TypeError):
        MyClass.attribute()

    # Check that it is still possible to call the function
    assert roclassproperty.attribute(MyClass) == MyClass.ATTRIBUTE_VALUE

    # Check that we can't override the class attribute
    with pytest.raises(AttributeError):
        MyClass.attribute = "another value"
    assert MyClass.attribute == MyClass

# Generated at 2022-06-21 22:13:40.121524
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):
        def __init__(self):
            self.a = 1

        @setterproperty
        def b(self, value):
            self.a = value

    obj = TestSetterProperty()
    assert obj.a == 1
    obj.b = 2
    assert obj.a == 2



# Generated at 2022-06-21 22:13:44.995150
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def foo(cls):
            return cls
    a = A()
    assert a.foo is A
    A.foo == a.foo


# Generated at 2022-06-21 22:13:52.214644
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, num):
            self.num = num

        @setterproperty
        def num(self, value):
            self.num = value

    a = A(0)
    print('a.num=', a.num)
    a.num = 0
    print('a.num=', a.num)



# Generated at 2022-06-21 22:14:01.165887
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            """I'm the 'x' property."""
            self._x = value
            return "Sure why not."

    f = Foo()
    f.x = 'bar'
    pprint.pprint(f.__dict__)

    pprint.pprint(Foo.x)



# Generated at 2022-06-21 22:14:04.304584
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X(object):
        a = lazyperclassproperty(lambda cls: cls.__name__)



# Generated at 2022-06-21 22:14:11.536787
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def f(c):
        return c.__name__
    class C(object):
        x = lazyperclassproperty(f)
    class D(C):
        pass
    class E(D):
        pass
    assert C.x == 'C'
    assert D.x == 'D'
    assert E.x == 'E'



################################################################################
### Miscellaneous
################################################################################


# Generated at 2022-06-21 22:14:14.574124
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'



# Generated at 2022-06-21 22:14:19.665442
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return "bar"

    class B(A):
        pass

    assert A.foo == "bar"
    assert B.foo == "bar"
    A.foo = "baz"
    assert A.foo == "baz"
    assert B.foo == "bar"


# Generated at 2022-06-21 22:14:25.105786
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self.__x = 1

        def getx(self):
            " I'm the 'x' property. "
            return self.__x

        def setx(self, value):
            self.__x = value

        x = setterproperty(getx, setx)

    f = Foo()
    assert f.__doc__ == " I'm the 'x' property. "
    assert f.x == 1
    f.x = 123
    assert f.x == 123



# Generated at 2022-06-21 22:15:36.469250
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self, foo):
            self.foo = foo

        @roclassproperty
        def bar(cls):
            return cls

    assert A(1).bar is A is A('a')
    with pytest.raises(AttributeError):
        A.bar = 2


# Generated at 2022-06-21 22:15:42.421644
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        _cache = 0

        @lazyclassproperty
        def count(cls):
            cls._cache += 1
            return cls._cache

    print(A.count)  # 1
    print(A.count)  # 1
    print(A._cache)  # 1

    class B(A):
        pass

    print(B.count)  # 2
    print(B.count)  # 2
    print(B._cache)  # 2



# Generated at 2022-06-21 22:15:48.329979
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test():
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value / 2

        @staticmethod
        def check(x):
            return x

    test = Test()
    test.x = 2
    assert test.check(test._x) == 1, "Expected 1, got '%s'" % test._x
    return True



# Generated at 2022-06-21 22:15:53.048347
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass:
        def __init__(self):
            pass

    class DerivedClass(BaseClass):
        def __init__(self):
            super().__init__()

    @lazyperclassproperty
    def test_func(cls):
        return cls

    assert DerivedClass.test_func is DerivedClass
    assert BaseClass.test_func is BaseClass

    DerivedClass.test_func = 2  # Can set

if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-21 22:16:03.815026
# Unit test for constructor of class setterproperty
def test_setterproperty():
    
    class A(object):
        def __init__(self, a):
            self.a = a
        @setterproperty
        def a(self, a):
            if isinstance(a, int) and a > 0:
                self._a = a
            else:
                raise ValueError("A's value should be a positive integer.")
                
    a1 = A(2)
    a1.a = 3
    assert a1.a == 3
    
    with pytest.raises(ValueError):
        a1.a = -5
        
    with pytest.raises(ValueError):
        a1.a = "a"

if __name__ == "__main__":
    import pytest
    test_setterproperty()
    pytest.main([__file__])

# Generated at 2022-06-21 22:16:07.580543
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Class:
        def method(self, value):
            self.value = value

        prop = setterproperty(method)

    inst = Class()
    inst.prop = 'set'
    assert inst.value == 'set'

    del inst.prop
    with pytest.raises(AttributeError):
        inst.prop


# Generated at 2022-06-21 22:16:13.141708
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def inst(cls):
            return cls(2)

    class D(B,C):
        pass

    class E(A):
        pass

    assert C.inst.x == 2
    assert D.inst.x == 2
    assert E.inst.x == 2



# Generated at 2022-06-21 22:16:15.827621
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Cls(object):
        @lazyperclassproperty
        def hello(cls):
            return object()
    class Inheritor(Cls):
        pass

    assert Cls.hello is not Inheritor.hello


# Generated at 2022-06-21 22:16:24.469047
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return 'a'

        def __init__(self):
            self.b = 'b'

        @property
        def d(self):
            return 'd'

    a = A()
    assert A.a == 'a'
    assert a.a == 'a'
    assert a.b == 'b'
    assert a.d == 'd'
    try:
        a.a = 'new a'
    except AttributeError:
        pass
    else:
        raise AssertionError('a.a should be immutable')


# Generated at 2022-06-21 22:16:29.761404
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        __defaults = {}
        @lazyperclassproperty
        def settings(cls):
            return {'A': cls.__name__}

    class B(A):
        __defaults = {}

    class C(B):
        __defaults = {}

    assert A.settings == {'A': 'A'}
    assert B.settings == {'A': 'B'}
    assert C.settings == {'A': 'C'}

