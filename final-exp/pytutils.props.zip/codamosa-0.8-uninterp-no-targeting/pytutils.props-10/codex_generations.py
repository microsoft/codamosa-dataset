

# Generated at 2022-06-21 22:07:43.782101
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def f(cls):
            pass
    assert C.f



# Generated at 2022-06-21 22:07:48.817693
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def get_a(self):
            return self._a

        def set_a(self, value):
            self._a = value

        a = setterproperty(set_a)

    a = A()
    a.a = 1
    assert a.get_a() == 1

# Generated at 2022-06-21 22:07:53.931144
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        _x = 1

        @roclassproperty
        def x(cls):
            return cls._x

    #Test the accessor function
    assert C.x == 1

    with pytest.raises(AttributeError):
        C.x = 2


# Generated at 2022-06-21 22:08:03.518702
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:08:08.587282
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        @setterproperty
        def x(self, value):
            self._x = value

        def get_x(self):
            return self._x

    obj = C()
    obj.x = 'foo'
    assert obj.get_x() == 'foo'
    obj.x = 'bar'
    assert obj.get_x() == 'bar'



# Generated at 2022-06-21 22:08:19.084387
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def _lazy_1(self):
            print('Parent')
            return 1

    class ChildOne(Parent):
        pass

    class ChildTwo(Parent):
        pass

    class TestThree(object):
        @lazyclassproperty
        def _lazy_1(self):
            print('TestThree')
            return 1

    c1 = ChildOne()
    c2 = ChildTwo()

    c1._lazy_1
    c2._lazy_1

    # Test lazyperclassproperty against lazyclassproperty
    t3 = TestThree()

    assert c1._lazy_1 != t3._lazy_1


# Generated at 2022-06-21 22:08:25.020062
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class TestClass(object):
        @roclassproperty
        def test_attr(cls):
            return "foo"

    assert hasattr(TestClass, "test_attr")
    assert TestClass.test_attr == "foo"

    test_class = TestClass()

    assert not hasattr(test_class, "test_attr")
    assert test_class.test_attr == "foo"


# Generated at 2022-06-21 22:08:27.978608
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # TODO Unit test for method __set__ of class setterproperty

    return True


if __name__ == '__main__':
    import pytest

    pytest.main('test_decorators.py')

# Generated at 2022-06-21 22:08:31.623515
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:08:37.601326
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return 1

    class Derived(Base):
        @lazyperclassproperty
        def prop(cls):
            return 2

    assert Base.prop == 1
    assert Derived.prop == 2


# Generated at 2022-06-21 22:08:46.198961
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, foo):
            self.foo = foo

        @setterproperty
        def foo(self, value):
            assert type(value) == int
            self._foo = value

        @foo.getter
        def foo(self):
            assert type(self._foo) == int
            return self._foo

    C(42)



# Generated at 2022-06-21 22:08:54.525828
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def __init__(self):
            self.foo = 'foo'

        @roclassproperty
        def bar(cls):
            return cls.__name__

        @classproperty
        def bar(cls):
            return cls.__name__

        @setterproperty
        def bar(self, value):
            self.foo = value

    assert Foo.bar == 'Foo'
    assert Foo().bar == 'Foo'
    Foo.bar = 'bar'
    assert Foo().foo == 'foo'
    Foo().bar = 'bar'
    assert Foo().foo == 'bar'



# Generated at 2022-06-21 22:08:57.157552
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A123(object):
        _x = 'A123'
        B_val = roclassproperty(lambda cls: cls._x)

    assert A123.B_val == 'A123'



# Generated at 2022-06-21 22:09:06.716950
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        classprop = roclassproperty(lambda cls: cls)
    assert C.classprop is C
    assert C.classprop is C()

    # Verify that the descriptor returns the same value each time.
    calls = []
    class C(object):
        classprop = roclassproperty(lambda cls: calls.append(True) or cls)
    # Verify that the descriptor is called exactly once per class, no
    # matter how many times its value is accessed.
    assert C.classprop is C
    assert C.classprop is C
    assert calls == [True]
    assert C().classprop is C
    assert C().classprop is C
    assert calls == [True]

    # Verify that the descriptor is called once per class, even if the
    # value is cached by another descriptor.

# Generated at 2022-06-21 22:09:12.431895
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:09:15.285502
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class ExampleClass():
        i = 5

        @roclassproperty
        def example_roclassprop(cls):
            return cls.i * 10

    assert ExampleClass.example_roclassprop == 50
    assert ExampleClass().example_roclassprop == 50



# Generated at 2022-06-21 22:09:20.045202
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def val(cls):
            return 'A'

    assert A.val == 'A'
    assert A().val == 'A'
    try:
        A.val = 7
    except Exception as e:
        assert str(e) == "can't set attribute"
    try:
        A().val = 7
    except Exception as e:
        assert str(e) == "can't set attribute"


# Generated at 2022-06-21 22:09:22.302197
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def f(cls):
            return 4
            
    c = C()
    assert c.f == 4



# Generated at 2022-06-21 22:09:26.046399
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        _value = 0

# Generated at 2022-06-21 22:09:29.724753
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        _counter = 0
        def get_counter(self):
            return self._counter
        def set_counter(self, value):
            self._counter = value
        counter = setterproperty(set_counter)

    a = A()
    assert a.counter == 0
    a.counter = 42
    assert a.counter == 42



# Generated at 2022-06-21 22:09:38.959856
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self.x = 1
            self.y = 2
            
        @roclassproperty
        def z(cls):
            return 3

    a = A()
    assert a.z == 3
    a.z = 4
    assert a.z == 3


# Generated at 2022-06-21 22:09:41.316503
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self._attr = 'attr'

        @setterproperty
        def attr(self, value):
            self._attr = value + '_changed'

    a = A()
    assert a.attr == 'attr'
    a.attr = 'new_value'
    assert a.attr == 'new_value_changed'



# Generated at 2022-06-21 22:09:43.513976
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.x = 0

        def set_x(self, x):
            self.x = x

        @setterproperty
        def sx(self):
            return self.x
    a = A()
    assert a.x == 0
    a.sx = 321
    assert a.x == 321

# Generated at 2022-06-21 22:09:47.625950
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(self):
            return 42

        x = roclassproperty(getx)

    assert C.x == 42
    c = C()
    assert c.x == 42
    with pytest.raises(AttributeError):
        c.x = 999



# Generated at 2022-06-21 22:09:51.732102
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def setter(self, value):
            if value == 5:
                raise ValueError('value is 5')
            self._x = value

        @setterproperty
        def setterdoc(self, value):
            "This is a docstring"
            self._x = value

    try:
        a = A()
        a.setter = 5
        assert False
    except:
        assert True
    a.setter = 10
    assert a._x == 10

    assert a.setterdoc.__doc__ == "This is a docstring"



# Generated at 2022-06-21 22:09:59.118132
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C1(object):
        @lazyperclassproperty
        def lazy_attr(cls):
            print('C1: %s' % cls.__name__)
            return 'C1'
    class C2(C1):
        pass
    class C3(C1):
        pass
    assert C1.lazy_attr == 'C1'
    assert C2.lazy_attr == 'C1'
    assert C3.lazy_attr == 'C1'
    print('OK')



# Generated at 2022-06-21 22:10:04.596960
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 'bar'

    assert C.x == 'bar'
    try:
        C.x = 'override'
        raise Exception('should not come to here')
    except AttributeError:
        pass
    print('pass')

if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-21 22:10:09.171855
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def test_setter_func(obj, value):
        obj.value = value

    class TestSetterProperty(object):
        @setterproperty
        def setter_property(self):
            return test_setter_func

    test_obj = TestSetterProperty()
    test_obj.setter_property = 'test_property'
    assert test_obj.value == 'test_property'



# Generated at 2022-06-21 22:10:11.367734
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class T(object):
        @roclassproperty
        def test(cls):
            return cls.__name__ + 'test'

    assert T.test == 'Ttest'
    assert T().test == 'Ttest'



# Generated at 2022-06-21 22:10:14.287516
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1
        x = roclassproperty(getx)

    assert C.x == 1
    assert C().x == 1



# Generated at 2022-06-21 22:10:27.027853
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def roclassproperty_method(self):
            return 10
    a = A()
    assert a.roclassproperty_method == 10

    # raise an exception, trying to modify the value
    try:
        a.roclassproperty_method = 20
    except AttributeError:
        pass
    else:
        assert 'Not an attribute error raised'



# Generated at 2022-06-21 22:10:35.740074
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):

        @lazyclassproperty
        def lazyprop(cls):
            return 'lazyprop'

        @lazyperclassproperty
        def perclasslazyprop(cls):
            return 'perclasslazyprop'

    class TestSub(Test):
        pass

    t = Test()
    ts = TestSub()
    assert t.lazyprop == 'lazyprop'
    assert ts.lazyprop == 'lazyprop'
    assert t.perclasslazyprop == 'perclasslazyprop'
    assert ts.perclasslazyprop == 'perclasslazyprop'
    assert t.perclasslazyprop == ts.perclasslazyprop



# Generated at 2022-06-21 22:10:39.009226
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def myprop(cls):
            return 'result'

    assert A.myprop == 'result'

    class B(A):
        pass

    assert B.myprop == 'result'



# Generated at 2022-06-21 22:10:49.316254
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):

        def __init__(self, x):
            self.x = x

        @roclassproperty
        def a(cls):
            return cls.__name__ + '1'

        @roclassproperty
        def b(cls):
            return cls.__name__ + '1'

    class B(A):

        def __init__(self, y):
            self.y = y

        @roclassproperty
        def a(cls):
            return cls.__name__ + '2'

    class C(B):

        def __init__(self, z):
            self.z = z

    print(A.a, A.b)
    a = A(1)
    print(a.x, a.a, a.b)

# Generated at 2022-06-21 22:10:51.535479
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def a(self):
            return 1
    assert A.a == 1



# Generated at 2022-06-21 22:10:56.159068
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class A(object):
        @setterproperty
        def foo(self, x):
            self.bar = x

    a = A()
    a.foo = 1
    assert a.bar == 1

    def test():
        a.foo = 2

    assert_raises(AttributeError, test)



# Generated at 2022-06-21 22:11:00.566031
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            assert value == 0
            self._x = value  # The property can update the instance's attribute

        @property
        def y(self):
            return self._x
    a = A()
    assert a.y is None
    a.x = 0
    assert a.x == 0

# Generated at 2022-06-21 22:11:08.654891
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test:
        @lazyperclassproperty
        def x(cls):
            print('inside x')
            return 'x'

        @lazyperclassproperty
        def y(cls):
            print('inside y')
            return 'y'

    class SubTest(Test):
        pass

    assert Test.x == 'x'
    assert Test.y == 'y'
    assert SubTest.x == 'x'
    assert SubTest.y == 'y'
    assert Test.x == SubTest.x
    assert Test.y == SubTest.y



# Generated at 2022-06-21 22:11:14.980156
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test(object):
        def __init__(self):
            self.type = ""

        @setterproperty
        def type(self, value):
            if value in ["openstack", "vmware"]:
                self._type = value
            else:
                raise Exception("Unsupported type %s"%value)

    t = test()
    t.type = "openstack"
    try:
        t.type = "vcenter"
    except Exception as e:
        assert str(e) == "Unsupported type vcenter"
    assert t.type == "openstack"

# Generated at 2022-06-21 22:11:19.569383
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            return "A"

    class B(A):
        pass

    assert A.x == "A"
    assert A().x == "A"
    assert B.x == "A"
    assert B().x == "A"
    assert B().x == "A"

    class C(B):
        @lazyperclassproperty
        def x(cls):
            return "C"

    assert A.x == "A"
    assert A().x == "A"
    assert B.x == "A"
    assert B().x == "A"
    assert C.x == "C"
    assert C().x == "C"

# Generated at 2022-06-21 22:11:44.619145
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    # Note: If a class defines a method `__set__` that is not a setterproperty,
    #       its `__init__` method is not called automatically, so the test for that
    #       case is not needed. It will be tested indirectly by the other tests.
    class A:
        @setterproperty
        def msg(self, msg):
            self.__set__called = True
            self.msg = msg

    class Test(unittest.TestCase):
        def test_setterproperty___set___called(self):
            a = A()
            a.msg = 'lala'
            self.assertTrue(hasattr(a, '__set__called'))
            self.assertEqual(a.msg, 'lala')

    unittest.main()



# Generated at 2022-06-21 22:11:48.936860
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo")
            return 1

    class B(A):
        pass
    print(A.foo)
    print(B.foo)
    print(A.foo)
    print(B.foo)


if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-21 22:11:54.184550
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        __test__ = False

        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            self.__x = value

        @property
        def x(self):
            return self.__x

    t = Test()
    assert t.x is None
    t.x = 'Test'
    assert t.x == 'Test'



# Generated at 2022-06-21 22:12:00.304397
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Callable
    assert callable(roclassproperty.__get__)
    # Callable return value
    assert callable(roclassproperty.__get__(roclassproperty, None))
    # Callable return value, source code
    assert (
        "return self.f(owner) # roclassproperty"
        == dis.disassemble(roclassproperty.__get__(roclassproperty, None).__code__).splitlines()[0]
        # Might have to be adjusted for Python version/implementation
    )



# Generated at 2022-06-21 22:12:07.452018
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        a = lazyperclassproperty(lambda x: 'foo')

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    class D(B):
        pass

    print(Base.a)
    print(A.a)
    print(B.a)
    print(C.a)
    print(D.a)

    assert Base.a == 'foo'
    assert A.a == 'foo'
    assert B.a == 'foo'
    assert C.a == 'foo'
    assert D.a == 'foo'


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-21 22:12:16.368591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def init_count():
        init_count.n += 1

    init_count.n = 0

    class A:
        @lazyclassproperty
        def prop(cls):
            init_count()
            return 'value'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            init_count()
            return super(C, cls).prop + '_mod'

    assert C.prop == 'value_mod'
    assert C.prop == 'value_mod'
    assert A.prop == 'value'
    assert B.prop == 'value'
    assert init_count.n == 2



# Generated at 2022-06-21 22:12:19.381165
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def foo(cls):
            return "foo"

        @roclassproperty
        def f(cls):
            return cls.foo()

    a = A()
    assert a.f == "foo"



# Generated at 2022-06-21 22:12:27.214762
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        __doc__ = 'Test class'

        def __init__(self, num):
            self.num = num

        @setterproperty
        def get(self):
            return self.num

        @get.setter
        def get(self, val):
            self.num = val

    t = Test(1)
    assert t.get == 1, "Initialization is 1"
    t.get = 2
    assert t.get == 2, "Setter is 2"



# Generated at 2022-06-21 22:12:30.391590
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class ClassA(object):

        @setterproperty
        def propA(self, value):
            self._propA = value

    classA = ClassA()
    classA.propA = 2


# Generated at 2022-06-21 22:12:34.401719
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        pass

    @setterproperty
    def test(self, value):
        self.test = value

    a = A()
    a.test = 1
    assert hasattr(a, 'test')



# Generated at 2022-06-21 22:13:13.775724
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestFoo(object):
        def __init__(self):
            self.x = 'hello'

        @roclassproperty
        def foo(cls):
            return cls.x

    class TestBar(TestFoo):
        x = 'world'

    foo = TestFoo()
    bar = TestBar()

    assert foo.foo == 'hello'
    assert TestFoo.foo == 'hello'
    assert bar.foo == 'world'
    assert TestBar.foo == 'world'



# Generated at 2022-06-21 22:13:20.005712
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def test(cls):
            return 1

    assert A.test == 1

    try:
        A().test = 2
    except AttributeError:
        pass
    else:
        assert False, 'Must be read-only property'



# Generated at 2022-06-21 22:13:25.092987
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class roclassproperty_test(object):
        @roclassproperty
        def test_property(cls):
            return 'test'
    assert roclassproperty_test.test_property == 'test'

# Generated at 2022-06-21 22:13:31.225487
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def add_x(self, value):
            self.x += value

    foo = Foo()
    assert 0 == foo.x
    foo.add_x = 2
    assert 2 == foo.x
    foo.add_x = -1
    assert 1 == foo.x



# Generated at 2022-06-21 22:13:37.458425
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def rnd(cls):
            return random.randint(0, 100)

    assert Test.rnd == Test.rnd

    class Test2(Test):
        pass

    assert Test.rnd != Test2.rnd



# Generated at 2022-06-21 22:13:40.051825
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def get_value(cls):
            return 'value'

    assert_equal(Foo.get_value, 'value')
    # the following raises an exception, as the method get_value is read-only:
    # Foo.get_value = 'value'



# Generated at 2022-06-21 22:13:43.314261
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def prop(cls):
            import time
            return time.time()

    assert C.prop != C.prop

    class D(C):
        pass

    assert C.prop != D.prop  # No overlap
    assert D.prop != D.prop  # Lazy



# Generated at 2022-06-21 22:13:46.088359
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Dummy(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self,  value):
            self._x = value

    d = Dummy(42)
    assert d._x == 42

    d.x = 0
    assert d._x == 0



# Generated at 2022-06-21 22:13:53.644957
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            print('Baz!')
            return cls.biff
        biff = 'none'

    print(Foo.bar)
    print(Foo.bar)

    Foo.biff = 'baz'
    print(Foo.bar)
    print(Foo.bar)

    class Qux(Foo):
        pass

    print(Qux.bar)
    print(Qux.bar)



# Generated at 2022-06-21 22:14:03.881861
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        def __init__(self):
            self.a = 0

        @lazyperclassproperty
        def b(cls):
            """
            This is a lazy per class property that is a counter for the class i.e. objects share the same b attribute.
            """
            r = getattr(cls, '_b', 0)
            setattr(cls, '_b', r + 1)
            return r

        @lazyclassproperty
        def c(cls):
            """
            This is a lazy class property that is a counter for the class i.e. objects share the same c attribute.
            """
            r = getattr(cls, '_c', 0)
            setattr(cls, '_c', r + 1)
            return r

    t = TestClass()


# Generated at 2022-06-21 22:15:24.614739
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def __init__(self):
            pass
        @roclassproperty
        def foo1(cls):
            return "{0}".format(cls.__name__)
        @classproperty
        def foo2(cls):
            return "{0}".format(cls.__name__)
        @classproperty
        def foo3(self):
            return "{0}".format(self.__name__)

    class Bar(Foo):
        def __init__(self):
            pass

    Test.assert_equals(Foo.foo1, 'Foo', 'should return class name')
    Test.assert_equals(Foo.foo2, 'Foo', 'should return class name')

# Generated at 2022-06-21 22:15:31.386373
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):
        def __init__(self):
            self.value = None

        @setterproperty
        def prop(self, value):
            self.value = value
            return self.value

        @setterproperty
        def prop_by_decorator(self, value):
            self.value = value
            return self.value

    test_setter_property = TestSetterProperty()
    print(test_setter_property.prop)
    test_setter_property.prop = 1
    print(test_setter_property.prop)

    @setterproperty
    def prop_by_decorator(value):
        return value

    test_setter_property.prop_by_decorator = 1

# Generated at 2022-06-21 22:15:39.880786
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("A: foo called")
            return 'foo'
    class B(A):
        pass
    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("C: foo called")
            return 'bar'
    class D(C):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert D.foo == 'bar'

    # Also check that it's not an instance variable
    a = A()
    assert not hasattr(a, 'foo')
    assert a.foo == 'foo'

    # Check that we don't get the same instance variable across classes
    # (thus proving that we store

# Generated at 2022-06-21 22:15:44.021480
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Root(object):
        def __init__(self):
            self._my_val = 1

        @lazyclassproperty
        def my_attr(cls):
            return cls()._my_val + 1

    class Inheritor(Root):
        def __init__(self):
            Root.__init__(self)
            self._my_val = 2

    assert Root.my_attr == 2
    assert Inheritor.my_attr == 2



# Generated at 2022-06-21 22:15:51.430558
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def thing(cls):
            print('thing')
            return 'thingy'

        def __init__(self):
            self.thing
            self.thing
            self.thing
            self.thing

    class B(A):
        pass

    a = A()
    assert a.thing == 'thingy'
    assert A.thing == 'thingy'
    b = B()
    assert b.thing == 'thingy'
    assert B.thing == 'thingy'
    assert A.thing == 'thingy'


# TODO: Documentation

# Generated at 2022-06-21 22:15:55.891853
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._x = None

        def getx(self):
            return self._x

        def setx(self, value):
            self._x = value

        x = setterproperty(setx)

    a=A()
    a.x=5
    assert a.getx() == 5



# Generated at 2022-06-21 22:16:02.871456
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Function test_lazyclassproperty()

    :return: True if test is passed, False otherwise
    :rtype: bool
    """
    from inspect import getmembers

    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 42
    assert A.prop == 42
    assert hasattr(A, '_lazy_prop')
    assert len([f for f in getmembers(A) if f[0] == '_lazy_prop']) == 1
    return A.prop == 42



# Generated at 2022-06-21 22:16:05.511437
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test:
        _value = None

        @setterproperty
        def prop(self, value):
            self._value = value

    test = Test()
    test.prop = 42
    assert test._value == 42

# Generated at 2022-06-21 22:16:09.843873
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:16:13.899848
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            print('In setter property x value')
            self._x = value

    c = C()
    c.x = 2
    print(c._x)

