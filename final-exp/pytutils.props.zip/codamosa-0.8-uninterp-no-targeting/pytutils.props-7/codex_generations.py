

# Generated at 2022-06-21 22:07:50.625404
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test class property
    """

    class ClassB(object):
        @lazyclassproperty
        def test(cls):
            return "Hello World"
    class ClassA(object):
        @lazyclassproperty
        def test(cls):
            ClassB.test
            return "Hello World"
    class ClassC(ClassA):
        pass

    a = ClassA()
    b = ClassB()
    c = ClassC()
    assert(ClassA.test == "Hello World")
    assert(ClassB.test == "Hello World")
    assert(ClassC.test == "Hello World")

    # We have to make sure that the lazyproperty has not been evaluated in ClassC()
    assert(not hasattr(ClassC, "_lazy_test"))

    # We now try to access ClassA.test in Class

# Generated at 2022-06-21 22:07:59.560657
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        @setterproperty
        def test(self, value):
            print('Value was', value)

    t = Test()
    t.test = "TEST"

    # Test alias
    class Test(object):
        @setterproperty
        def test(self, value):
            print('Value was', value)
        test2 = test

    t = Test()
    t.test = "TEST"
    t.test2 = "TEST2"

    # Test docstring
    class Test(object):
        @setterproperty
        def test(self, value):
            '''Test'''
            print('Value was', value)

    t = Test()
    assert t.test.__doc__ == 'Test'

# Generated at 2022-06-21 22:08:09.153694
# Unit test for method __set__ of class setterproperty

# Generated at 2022-06-21 22:08:18.036885
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        i = 0

        @lazyperclassproperty
        def prop(cls):
            cls.i += 1
            return cls.i

    class B(A):
        pass

    class C(A):
        pass

    a1 = A()
    b1 = B()
    c1 = C()
    assert a1.prop == 1
    assert b1.prop == 1
    assert c1.prop == 2
    assert a1.prop == 1
    assert b1.prop == 1
    assert c1.prop == 2



# Generated at 2022-06-21 22:08:22.504814
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        _x = 1

        @roclassproperty
        def x(cls):
            return cls._x

    class B(A):
        _x = 2

    assert A.x == 1
    assert B.x == 2



# Generated at 2022-06-21 22:08:31.604206
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def b(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def c(cls):
            return 'c'

    class D(C):
        @lazyperclassproperty
        def c(cls):
            return 'd'

    a = A()
    b = B()
    c = C()
    d = D()

    assert a.b == 'a'
    assert b.b == 'a'
    assert c.b == 'a'
    assert d.b == 'a'
    assert c.c == 'c'
    assert d.c == 'd'
    assert C.c == 'c'

# Generated at 2022-06-21 22:08:42.447471
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self, name):
            self.name = name

    class Sub1(Base):
        @lazyperclassproperty
        def foo(cls):
            print("Sub1.foo called")
            return cls.__name__

        @property
        def foo2(self):
            print("Sub1.foo2 called")
            return self.__class__.__name__

    class Sub2(Base):
        @lazyperclassproperty
        def foo(cls):
            print("Sub2.foo called")
            return cls.__name__

        @property
        def foo2(self):
            print("Sub2.foo2 called")
            return self.__class__.__name__

    if __name__ == '__main__':
        sub1 = Sub1

# Generated at 2022-06-21 22:08:48.714344
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    t = attrdict()

    @roclassproperty
    def f(c):
        return c

    assert t.f is t
    assert t.__class__.f is t.__class__
    assert f.__get__(None, t.__class__) is t.__class__



# Generated at 2022-06-21 22:08:52.601425
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, val):
            self.name = val

        @setterproperty
        def name(self, name):
            assert isinstance(name, str)
            self._name = name

        @name.getter
        def name(self):
            return self._name

    c = C('foo')
    assert c.name == 'foo'

    c.name = 'bar'
    assert c.name == 'bar'

    with pytest.raises(AssertionError):
        c.name = 1



# Generated at 2022-06-21 22:08:56.224239
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        def foo(cls):
            return "foo"
        bar = roclassproperty(foo)

    assert Foo.bar == "foo"
    assert Foo.bar is Foo.bar
    assert Foo().bar is Foo.bar



# Generated at 2022-06-21 22:09:01.232525
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        @roclassproperty
        def x(cls):
            return cls.__name__
    assert A.x == 'A'



# Generated at 2022-06-21 22:09:07.223786
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        num = 3

        def __init__(self):
            pass

        @setterproperty
        def incr(self, val):
            self.num = self.num + val

        @property
        def decr(self):
            self.num = self.num - 1
            return self.num

    incr = A.incr
    decr = A.decr

    a = A()
    a.incr = 5
    a.decr
    assert a.num == 7

# Generated at 2022-06-21 22:09:12.144139
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('bar called')
            return 42

    print(Foo.bar)
    print(Foo.bar)
    print(Foo().bar)
    print(Foo().bar)



# Generated at 2022-06-21 22:09:19.150649
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        class A:
            pass

        class B:
            pass

        class C(B):
            pass

        @roclassproperty
        def roclassprop(cls):
            return cls

        classprop = roclassprop

    assert A.roclassprop == A
    assert A.classprop == A

    assert A.A.roclassprop == A.A
    assert A.A.classprop == A.A

    assert A.B.roclassprop == A.B
    assert A.B.classprop == A.B

    assert A.C.roclassprop == A.C
    assert A.C.classprop == A.C



# Generated at 2022-06-21 22:09:22.625354
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = None

        @setterproperty
        def a(self, value):
            self._a = value

    a = A()
    a.a = 7
    assert a._a == 7



# Generated at 2022-06-21 22:09:25.747671
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class aclass(object):
        @lazyclassproperty
        def prop(cls):
            return 123

    assert aclass.prop == 123
    assert aclass().prop == 123
    assert aclass.__class__.prop == 123



# Generated at 2022-06-21 22:09:29.514637
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from types import FunctionType

    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42
    assert type(A.prop) is not FunctionType
    assert type(B.prop) is not FunctionType
    assert A.prop is B.prop



# Generated at 2022-06-21 22:09:33.686981
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.var1 = 1
            self.var2 = 2

        @setterproperty
        def foo(self, value):
            self.var1 = value + 1
            self.var2 = value * value

    a = A()
    a.foo = 5
    assert a.var1 == 6
    assert a.var2 == 25



# Generated at 2022-06-21 22:09:39.395470
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, i):
            self.__i = i

        # Method __set__ of class setterproperty
        def __set__(self, obj, value):
            self.__i = value

        def get(self):
            return self.__i

    class B():
        foo = A(2)

    class C(B):
        pass

    a = A(1)
    assert a.get() == 1

    b = B()
    assert b.foo.get() == 2

    c = C()
    assert c.foo.get() == 2

    a.__set__(None, 3)
    assert a.get() == 3

    b.foo.__set__(None, 4)
    assert b.foo.get() == 4

    c.foo.__

# Generated at 2022-06-21 22:09:46.175816
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            return "bar"

        @lazyperclassproperty
        def per_class_bar(cls):
            return "per_class_bar"

    for c in (Foo, object, object):
        assert Foo.bar is Foo.bar
        assert Foo.per_class_bar is Foo.per_class_bar

    class FooChild(Foo):
        pass

    assert FooChild.bar is Foo.bar
    assert FooChild.per_class_bar is not Foo.per_class_bar

# Generated at 2022-06-21 22:09:51.914332
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class X(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def property(cls):
            return "this is a class property"

    assert X.property() == "this is a class property"


# Generated at 2022-06-21 22:09:53.351487
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    d = None

    def f():
        nonlocal d
        d = 42
        return d

    c = roclassproperty(f)
    assert d is None
    c.__get__(None, object)
    assert d == 42



# Generated at 2022-06-21 22:10:04.229071
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    
    # method __set__ of class setterproperty returns NotImplemented
    # Negative test
    # AssertionError is raised
    class TestSetterproperty___set__:
        @setterproperty
        def method(self):
            pass

    test_setterproperty___set__ = TestSetterproperty___set__()
    with pytest.raises(AssertionError):
        assert(test_setterproperty___set__.method == NotImplemented)

    # method __set__ of class setterproperty returns None
    # Negative test
    # AssertionError is raised
    class TestSetterproperty___set__:
        @setterproperty
        def method(self):
            pass

        def __set__(self):
            return None

    test_setterproperty___set__ = TestSetterproperty___set__()

# Generated at 2022-06-21 22:10:12.666463
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self,var1,var2):
            self.var1=var1
            self.var2=var2
        @setterproperty
        def var1(self,value):
            assert isinstance(value, basestring)
            self._var1=value
        @setterproperty
        def var2(self,value):
            assert isinstance(value, basestring)
            self._var2=value
    c=C('a','b')
    assert c.var1=='a'
    assert c.var2=='b'
    assert c._var1=='a'
    assert c._var2=='b'
    c.var1='c'
    assert c.var1=='c'
    assert c.var2=='b'

# Generated at 2022-06-21 22:10:20.551014
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Define a simple class with a lazy property
    class MyClass(object):
        @lazyclassproperty
        def prop(cls):
            print('initializing prop!')
            return "This is a lazily evaluated property."

    # Verify that the property is initialized every time it's called
    print(MyClass.prop)
    print(MyClass.prop)
    # Define a subclass of the above class
    class MySubClass(MyClass): pass

    # Verify that the property is initialized only once per class
    print(MyClass.prop)
    print(MySubClass.prop)
    print(MySubClass.prop)



# Generated at 2022-06-21 22:10:25.410860
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import sys
    class TestLazyClassproperty(object):
        @lazyclassproperty
        def test(cls):
            return "Test %d" % sys.version_info[0]

        def __init__(self):
            self.test = "Test %d" % sys.version_info[0]

    test1 = TestLazyClassproperty()
    assert isinstance(test1.test, str)
    assert isinstance(TestLazyClassproperty.test, str)



# Generated at 2022-06-21 22:10:28.171254
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class B(object):
        @lazyperclassproperty
        def prop(cls):
            print('calculating')
            return 42
    class A(B):
        pass
    class C(B):
        pass
    assert A.prop == 42
    assert B.prop == 42
    assert C.prop == 42



# Generated at 2022-06-21 22:10:32.489311
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def setter(s, value):
        s.__value = value

    class Test(object):
        value = setterproperty(setter)

        def __init__(self, value):
            self.value = value

    t = Test(1)
    assert t.value == 1

# Generated at 2022-06-21 22:10:36.164986
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(selfcls):
            return selfcls

        x = roclassproperty(getx)

    assert C.x is C

    with pytest.raises(AttributeError):
        C().x


# Generated at 2022-06-21 22:10:40.635318
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def x(self, x):
            self._x = x
            
    assert not hasattr(A, '_x')
    a = A()
    assert not hasattr(a, '_x')
    a.x = 42
    assert a._x == 42
    
    

# Generated at 2022-06-21 22:10:55.143408
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class LazyTest(object):
        @lazyperclassproperty
        def prop(cls):
            return "hi"

    class LazyTest2(LazyTest):
        pass

    lt = LazyTest()
    assert lt.prop == "hi"
    lt.prop = "hello"
    assert lt.prop == "hello"
    assert LazyTest.prop == "hi"

    lt2 = LazyTest2()
    assert lt2.prop == "hi"
    lt2.prop = "hello"
    assert lt2.prop == "hello"
    assert LazyTest2.prop == "hi"


# Generated at 2022-06-21 22:10:57.910876
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        pass

    @roclassproperty
    def fooprop(cls):
        return 10

    assert fooprop.__get__(None, Foo) == 10



# Generated at 2022-06-21 22:11:05.759518
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def test(cls):
            print("Calculating Base.test ...")
            return 10

    class Subclass1(Base):
        pass

    class Subclass2(Base):
        pass

    print("Testing Base.test ...")
    assert Base.test == 10
    assert Base.test == 10
    print("Testing Subclass1.test ...")
    assert Subclass1.test == 10
    assert Subclass1.test == 10
    print("Testing Subclass2.test ...")
    assert Subclass2.test == 10
    assert Subclass2.test == 10



# Generated at 2022-06-21 22:11:09.189426
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:11:12.541203
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self):
            self.val = 0
        @setterproperty
        def set_val(self, val):
            self.val = val
    a = A()
    a.set_val = 1
    assert a.val == 1



# Generated at 2022-06-21 22:11:18.517812
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Example(object):
        pass

    def set_value(example, value):
        example.value = value

    example = Example()
    example.value = 1
    assert example.value == 1

    #here we add the custom setter
    Example.value = setterproperty(set_value)
    example.value = 2
    assert example.value == 2
    assert getattr(Example, 'value') == set_value


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:11:24.550492
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class R(object):
        def __init__(self, x):
            self._x = x

        @roclassproperty
        def x(cls):
            return cls._x

    assert R.x == R(5).x == 5

    # Uncomment the following line to show that the property is read-only
    # R.x = 10



# Generated at 2022-06-21 22:11:26.821936
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):

        def getx(cls):
                return 1

        x = roclassproperty(getx)

    assert C.x == 1



# Generated at 2022-06-21 22:11:33.484782
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:11:36.698989
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def set_value(self, value):
            self.value = value

    a = A(111)
    a.set_value = 10
    assert a.value == 10


# Generated at 2022-06-21 22:11:52.673920
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self, value=None):
            self.value = value
        def method(self, value):
            self.value = value
        value = setterproperty(method, "This is a test")

    t = Test()

    assert t.value is None, "Initial value not set"

    t.value = "Hello, world!"
    assert t.value == "Hello, world!", "Test value not set"

    assert t.value.__doc__ == "This is a test", "Test doc string not set"

# Generated at 2022-06-21 22:11:56.886124
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, b=None):
            self._b = b


# Generated at 2022-06-21 22:12:02.297849
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self):
            self._x = 1

        @roclassproperty
        def x(cls):
            return cls._x

        @x.setter
        def x(cls, value):
            cls._x = value

    test_class = TestClass()
    assert test_class.x == 1
    test_class.x = 3
    assert test_class.x == 3

# Generated at 2022-06-21 22:12:06.440986
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        __name__ = 'A'
        __doc__ = 'doc'
        def __init__(self):
            self._A = 1
        @roclassproperty
        def A(cls):
            return self._A
    assert A.A == 1
    print(A.A)
    print(A.__name__, A.__doc__)



# Generated at 2022-06-21 22:12:10.261264
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def prop_a(cls):
            return "Prop A"

    assert A.prop_a == "Prop A"
    assert A().prop_a == "Prop A"



# Generated at 2022-06-21 22:12:19.450816
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self, name):
            self.name = name

    class A(Base):
        @lazyperclassproperty
        def value(cls):
            return cls.__name__ + ":value"

    class B(Base):
        @lazyperclassproperty
        def value(cls):
            return cls.__name__ + ":value"

    a = A("a")
    b = B("b")

    assert A.value == "A:value"
    assert B.value == "B:value"

    assert a.value == "A:value"
    assert b.value == "B:value"

    assert a.value == A.value
    assert b.value == B.value


# Generated at 2022-06-21 22:12:31.137855
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Test for roclassproperty.__get__.
    """

    class A(object):
        def __init__(self, attr):
            self.attr = attr
        @roclassproperty
        def foo(cls):
            return cls.attr
        @roclassproperty
        def bar(self):
            return self.attr
    class B(A): pass

    assert A.foo == 'aaa'
    assert B.foo == 'bbb'

    a = A('aaa')
    assert a.foo == 'aaa'
    assert a.bar == 'aaa'
    b = B('bbb')
    assert b.foo == 'bbb'
    assert b.bar == 'bbb'
    
    with pytest.raises(AttributeError):
        A.foo = 'ccc'

# Generated at 2022-06-21 22:12:36.670856
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test:
        def __init__(self, c=0):
            self.counter = c

        @setterproperty
        def test(self, c):
            self.counter = c

    a = test()
    assert a.counter == 0

    a.test = 10
    assert a.counter == 10


# Generated at 2022-06-21 22:12:39.275596
# Unit test for constructor of class setterproperty
def test_setterproperty():
    @setterproperty
    def p(self, v):
        self._p = v

    class Tst:
        _p = 0

    t = Tst()
    t.p = 1
    assert t._p == 1

# Generated at 2022-06-21 22:12:45.777159
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def xxx(cls):
            return 'xxx'

    class B(A):
        pass

    class C(B):
        pass

    assert A.xxx is B.xxx is C.xxx == 'xxx'
    assert A.xxx is not 'xxx'

    A.xxx = 'yyy'
    assert B.xxx is C.xxx == 'xxx'
    assert A.xxx == 'yyy'



# Generated at 2022-06-21 22:13:13.466627
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class s(object):
        # Declare a read-only class property named value
        value = roclassproperty(lambda cls: cls.__name__)

        # Declare a regular class property named name
        name = classproperty(lambda cls: cls.__name__)

    # Print class name from the read-only class property named value
    print(s.value)

    # Try to set a class property - expected result: AttributeError
    try:
        s.value = "test"
    except AttributeError:
        print("Expected exception: AttributeError")

    # Print class name from the regular class property named name
    print(s.name)

    # Try to set a class property - expected result: OK
    s.name = "test"
    print(s.name)



# Generated at 2022-06-21 22:13:19.197567
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 0

        @setterproperty
        def add(self, v):
            self.a += v

    obj = A()
    obj.add = 1
    assert obj.a == 1

# Generated at 2022-06-21 22:13:22.700775
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C:
        @roclassproperty
        def x(cls):
            return "x"

    assert isinstance(C.x, roclassproperty)
    assert C.x == "x"

    # TODO: What should happen here?
    try:
        C.x = None
        assert False
    except Exception:
        pass



# Generated at 2022-06-21 22:13:30.858511
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class T1(object):
        def __init__(self, value):
            self.init_value = value

        @setterproperty
        def hello(self, value):
            return self.init_value + value

    class T2(T1):
        def __init__(self, value):
            super().__init__(value)

        @setterproperty
        def __init__(self, value):
            self.init_value = value



# Generated at 2022-06-21 22:13:42.330444
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, x):
            self.x = None

        @setterproperty
        def x(self, x):
            print("Setting x to %s" % str(x))
            self.__dict__['x'] = x

        @setterproperty
        def y(self, y):
            print("Testing y")
            self.__dict__['y'] = y

        @setterproperty
        def z(self, z): pass

    c = C(1)
    assert c.x == None
    c.x = 2
    assert c.x == 2
    c.y = 3
    assert c.y == 3
    c.z = None

# Generated at 2022-06-21 22:13:47.560580
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'baz'


    assert Foo.bar == 'baz'
    assert Foo().bar == 'baz'

# Generated at 2022-06-21 22:13:52.649458
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def func(cls):
            return "lazy_func"
    class B(A):
        pass
    assert A.func == "lazy_func"
    assert B.func == "lazy_func"


# Generated at 2022-06-21 22:14:00.441130
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class TestObj(object):
        x = setterproperty(lambda self, x: setattr(self, '__x', x))

    obj = TestObj()

    obj.x = 1
    assert (obj.__x == 1)

    obj2 = TestObj()
    obj2.x = 2
    assert (obj2.__x == 2)


# Generated at 2022-06-21 22:14:03.678991
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('called here')
            return 'baz'

    class Bar(Foo):
        pass

    assert Foo.bar == 'baz'
    assert Bar.bar == 'baz'
    assert Foo.bar == 'baz'
    assert Bar.bar == 'baz'



# Generated at 2022-06-21 22:14:13.102285
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    """
    Test roclassproperty
    """
    class Foo(object):
        TAG_NAME = roclassproperty(lambda cls: cls.__name__.lower())

    assert Foo.TAG_NAME == "foo"

    class Bar(Foo):
        pass

    class Foo2(object):
        TAG_NAME = roclassproperty(lambda cls: cls.__name__.lower())

        def __init__(self):
            self.TAG_NAME = 'foo'

    assert Foo2.TAG_NAME == 'foo'
    assert Foo2().TAG_NAME == 'foo'



# Generated at 2022-06-21 22:14:58.209581
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):

        def __init__(self):
            self.attr = None

        @setterproperty
        def attr(self, value):
            self.attr = value

    c = C()
    assert c.attr is None
    c.attr = "Hello, world!"
    assert c.attr == "Hello, world!"

# Generated at 2022-06-21 22:15:04.656137
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return "B"

    class C(B):
        pass

    assert A.foo == "A"
    assert B.foo == "B"
    assert C.foo == "B"

    # verify it is per class (not per instance)
    a = A()
    b = B()
    c = C()

    assert A.foo == "A"
    assert B.foo == "B"
    assert C.foo == "B"

    assert a.foo == "A"
    assert b.foo == "B"
    assert c.foo == "B"

# Generated at 2022-06-21 22:15:09.878580
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self.__name = ''

        @setterproperty
        def name(self, value):
            self.__name = value

        def get_name(self):
            return self.__name

    test = Test()
    test.name = 'name'
    assert test.get_name() == 'name'


# Generated at 2022-06-21 22:15:18.009130
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(self):
            return "A"

    class B(A):
        @lazyperclassproperty
        def prop(self):
            ret = "B"
            self.prop_ = ret
            return ret

    class C(B):
        pass

    a = A()

    assert not hasattr(a, '_A_lazy_prop')
    assert a.prop == "A"
    assert A.prop == "A"
    assert a.prop == "A"
    assert hasattr(a, '_A_lazy_prop')

    b = B()
    assert not hasattr(b, '_B_lazy_prop')
    assert b.prop == "B"
    assert B.prop == "B"
    assert b.prop

# Generated at 2022-06-21 22:15:21.896818
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        __bar = None

        @setterproperty
        def bar(self, value):
            self.__bar = value

    a = A()
    a.bar = 'test'
    assert a.__bar == 'test'
    print('test_setterproperty() passed')

if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:15:23.794851
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def func(self, value):
        pass

    sp = setterproperty(func)
    assert_equal(sp.__doc__, func.__doc__)
    assert_equal(sp.func, func)


# Generated at 2022-06-21 22:15:30.584097
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from functools import partial
    from datetime import datetime

    class Example:

        @lazyclassproperty
        def now(cls):
            return datetime.now().isoformat()

        def __init__(self):
            self._now = ''

        @property
        def ex_now(self):
            return self._now

        @ex_now.setter
        def ex_now(self, value):
            self._now = value

    e = Example()
    assert e.ex_now == ''
    e.ex_now = 'test'
    assert e.ex_now == 'test'

    assert Example.now == e.now
    assert Example.now == e.now

    class Example2(Example):

        def __init__(self):
            super(Example2, self).__init__()
           

# Generated at 2022-06-21 22:15:35.587369
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:15:42.153158
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('Foo called')
            return 42

    class B(A):
        pass

    print('This is A.foo: ' + str(A.foo))
    print('This is B.foo: ' + str(B.foo))
    # The second call to A.foo does not result in the print statement
    print('This is A.foo again: ' + str(A.foo))
    print('This is B.foo again: ' + str(B.foo))


# Generated at 2022-06-21 22:15:48.623413
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """lazyclassproperty() should only compute its value once."""
    _calls = 0
    class A(object):
        @lazyclassproperty
        def a(klass):
            global _calls
            _calls += 1
            return 42
    assert A.a == 42
    assert A.a == 42
    assert A.a == 42
    assert _calls == 1
    assert 'a' in A.__dict__  # it should have been stored in the class dict


# Generated at 2022-06-21 22:17:08.528175
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Class1:
        def __init__(self, a):
            self.a = a
            self.b = a + 1

        @setterproperty
        def b(self, b):
            self.b = b
            self.a = b - 1

    c1 = Class1(4)
    assert c1.a == 4
    assert c1.b == 5

    c1.b = 10
    assert c1.b == 10
    assert c1.a == 9



# Generated at 2022-06-21 22:17:17.346605
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self, name):
            self.name = name

    def compose_name(cls):
        return "Names of class " + cls.__name__ + ": " + ', '.join(
            a.name for a in cls.__dict__.values() if isinstance(a, A))

    class B(A):

        @lazyperclassproperty
        def names(cls):
            return compose_name(cls)

    class C(B):
        a = A("a-C")
        b = A("b-C")

    class D(B):
        a = A("a-D")
        b = A("b-D")
        c = A("c-D")

    assert B.names == 'Names of class B: a-B, b-B'

# Generated at 2022-06-21 22:17:19.091217
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class S(object):
        @roclassproperty
        def get_roclassproperty(cls):
            return 123
    assert S.get_roclassproperty == 123
    assert not hasattr(S(), 'get_roclassproperty')


# Generated at 2022-06-21 22:17:22.599735
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):
        def __init__(self):
            self.a = 1

        @roclassproperty
        def b(cls):
            return 1

    a = A()
    assert(a.a == 1)
    assert(a.b == 1)

    with pytest.raises(AttributeError):
        a.b = 2

    with pytest.raises(AttributeError):
        A.b = 2



# Generated at 2022-06-21 22:17:28.129110
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @setterproperty
        def b(self, x):
            self.a = x
            return x

    a = A(1, 2)
    assert a.a == 1
    assert a.b == 2
    a.b = 3
    assert a.a == 3
    assert a.b == 3

# Generated at 2022-06-21 22:17:33.194803
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def method(cls):
            return "a"

    class B(A):
        pass

    a = A()

    # Test if method is not implemented when trying to instantiate A
    with pytest.raises(TypeError):
        a.method

    # Test if method is class property
    assert(A.method == "a")
    assert(B.method == "a")

    # Test if method is read only
    with pytest.raises(AttributeError):
        A.method = "b"


# Generated at 2022-06-21 22:17:35.621257
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def prop(self, value):
            print("self is:", self)
            return value

    a = A()
    print(a.prop)
    a.prop = 2
    print(a.prop)

# Generated at 2022-06-21 22:17:37.957667
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
       def __init__(self):
           self._x = None

       @setterproperty
       def x(self, value):
           self._x = value

    a = A()
    a.x = 1
    assert a._x == 1
    return 0
