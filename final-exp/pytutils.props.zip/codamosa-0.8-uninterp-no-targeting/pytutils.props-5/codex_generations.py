

# Generated at 2022-06-21 22:07:48.288298
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 'abc'

    a = A()
    a.x = 'def'
    assert a.x == 'abc'
    assert A.x == 'abc'



# Generated at 2022-06-21 22:07:56.186550
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import pytest

    # A setterproperty method cannot be called with too few arguments
    with pytest.raises(TypeError):
        setterproperty(int).__set__()

    # A setterproperty method cannot be called with too many arguments
    with pytest.raises(TypeError):
        setterproperty(int).__set__(int, int, int)

    # A setterproperty method cannot be called with wrong type of arguments
    with pytest.raises(TypeError):
        setterproperty(int).__set__(int, "a string")

    def int_tuple(arg1, arg2):
        return int(arg1), tuple(arg2)

    result = setterproperty(int_tuple).__set__(1, [1, 2, 3])
    assert isinstance(result, tuple)
   

# Generated at 2022-06-21 22:08:02.084357
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class foo(object):
        @roclassproperty
        def bar(self):
            return "foobar"

    f = foo()
    assert foo.bar == f.bar == "foobar"
    with pytest.raises(AttributeError) as e:
        foo.bar = "faa"
    assert e.value.args[0]=="can't set attribute"
    with pytest.raises(AttributeError) as e:
        f.bar = "faa"
    assert e.value.args[0]=="can't set attribute"

# Generated at 2022-06-21 22:08:10.147255
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        # Test case with only one implementation
        @lazyperclassproperty
        def only_one_value(cls):
            if cls.__name__ == 'TestClass':
                return 5
            else:
                raise AttributeError

        # Test case with multiple implementations
        @lazyperclassproperty
        def multiple_values(cls):
            if cls.__name__ == 'TestClass':
                return 5
            elif cls.__name__ == 'TestClass2':
                return 6
            else:
                raise AttributeError

    class TestClass2(TestClass):
        def __init__(self):
            print("TestClass2")

    print("Testcase 1")
    print("TestClass.only_one_value = %d" % TestClass.only_one_value)

# Generated at 2022-06-21 22:08:14.054544
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class Test(object):

        @roclassproperty
        def _test(self):
            return 'test'

    test = Test()

    assert Test._test == 'test'



# Generated at 2022-06-21 22:08:25.259605
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        def __init__(self):
            self.test = 'foo'

    def test_func(cls):
        return cls()

    assert Foo.test_func.test == 'foo'
    assert Foo.test_func.test == 'foo'

    class Bar(Foo):
        pass

    assert Bar.test_func.test == 'foo'
    assert Bar.test_func.test == 'foo'

    class Foo(object):
        test_func = lazyperclassproperty(test_func)

    assert Foo.test_func.test == 'foo'
    assert Foo.test_func.test == 'foo'

    class Bar(Foo):
        pass

    assert Bar.test_func.test == 'foo'
    assert Bar.test_func.test == 'foo'


# Generated at 2022-06-21 22:08:29.828804
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def _f_get(cls):
            return 0

        x = roclassproperty(_f_get)

    class B(A):
        pass

    class C(B):
        pass


# Generated at 2022-06-21 22:08:34.993499
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.called = False

        @setterproperty
        def prop(self, val):
            self.called = True
            assert val == 1

    a = A()
    assert a.called == False
    a.prop = 1
    assert a.called == True


# Generated at 2022-06-21 22:08:41.701060
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C:
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, x):
            self.x_ = x

    c = C(x=1)
    print(c.x_) # 1
    c.x = 2
    print(c.x_) # 2


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-21 22:08:54.479957
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    import unittest

    class A(object):
        def __init__(self, x):
            self.x = x

        # factory method
        @roclassproperty
        def q(cls):
            return cls.s * 2

        @classproperty
        def s(cls):
            return cls.x * 10

    a = A(2)
    # assert isinstance(a, A)
    # assert hasattr(a, 'q')
    # assert hasattr(a, 's')
    # assert a.q == 40
    # assert a.s == 20
    # assert A.q == 40
    # assert A.s == 20

    class B(A):
        x = 3

    b = B()
    # assert isinstance(b, A)
    # assert isinstance(b, B)

# Generated at 2022-06-21 22:09:01.610053
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'A.a'

    class B(A):
        pass

    class C(A):
        pass

    assert A.a == 'A.a'
    assert B.a == 'A.a'
    assert C.a == 'A.a'



# Generated at 2022-06-21 22:09:04.273680
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def prop(cls):
            return 42

    assert A.prop == 42

    class B(A):
        pass

    assert B.prop == 42



# Generated at 2022-06-21 22:09:13.957818
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class_value = 'Hello'
    prop_name = 'some_prop'

    class A(object):
        @lazyclassproperty
        def some_prop(cls):
            return class_value

    assert A.some_prop == class_value
    assert A.some_prop == class_value
    assert A.some_prop == class_value

    class B(A):
        pass

    assert B.some_prop == class_value
    assert B.some_prop == class_value
    assert B.some_prop == class_value

    class C(object):
        pass

    # Ensure that this doesn't blow up when the class lacks the property
    assert not hasattr(C, prop_name)


# Generated at 2022-06-21 22:09:18.284852
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return object()

    class B(A):
        pass

    assert A.x is A.x
    assert B.x is B.x

    assert A.x is not B.x
    assert A.x is A.x
    assert B.x is B.x


# Generated at 2022-06-21 22:09:27.202477
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # pylint: disable=invalid-name

    class A(object):
        def __init__(self, value=0):
            self.value = value

    class B(object):
        b = roclassproperty(lambda cls: A(cls.value))

        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '{cls}({value!r})'.format(cls=self.__class__.__name__, value=self.value)

    assert A(3) == B.b
    B.value = 5
    assert A(5) == B.b
    B.b = A(7)
    assert A(7) == B.b
    b1 = B(1)
    assert A(1) == b1.b

# Generated at 2022-06-21 22:09:31.346802
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Tester(object):
        @lazyperclassproperty
        def get_val(cls):
            return cls.__name__

    class ChildTester(Tester):
        pass

    assert Tester.get_val == 'Tester'
    assert ChildTester.get_val == 'ChildTester'
    Tester.get_val == 'Tester'

# Generated at 2022-06-21 22:09:37.676624
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('foo')
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    # Check that foo is not accessed for A and B instances yet
    print('Checking A')
    print(A().foo)
    print(A().foo)
    print('Checking B')
    print(B().foo)
    print(B().foo)
    print('Checking C')
    print(C().foo)
    print(C().foo)

    # Check that foo is only accessed once per class/inheritor
    expected = [
        # A
        'foo',
        # B
        'foo',
        # C
        'foo',
    ]
    assert_

# Generated at 2022-06-21 22:09:46.949541
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Tests that the property is retrieved from the cache in all
    cases, including when the class is sub-classed and the subclass is
    instantiated.
    """

    call_count = 0

    class SomeClass(object):
        @lazyclassproperty
        def some_property(cls):
            nonlocal call_count
            call_count += 1
            return 'some_value'

    assert SomeClass.some_property == 'some_value'
    assert call_count == 1
    assert SomeClass.some_property == 'some_value'
    assert call_count == 1

    class SubclassOfSomeClass(SomeClass):
        pass

    assert SubclassOfSomeClass.some_property == 'some_value'
    assert call_count == 1
    assert SubclassOfSomeClass.some_property == 'some_value'

# Generated at 2022-06-21 22:09:49.093542
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def a(self, value):
            self.a = value

    a = A()
    a.a = 5



# Generated at 2022-06-21 22:09:50.956072
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'foo'

    class Bar(Foo):
        pass

    assert Foo.bar == Bar.bar == 'foo', 'lazyclassproperty failed to provide the same value.'



# Generated at 2022-06-21 22:09:59.359519
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    from unittest import TestCase, main

    class MyClass(object):
        x = roclassproperty(lambda c: c.__name__)

    class MyClassTest(TestCase):
        def test_x(self):
            self.assertEqual('MyClass', MyClass.x)

    main()

if __name__ == '__main__':
    test_roclassproperty___get__()

# Generated at 2022-06-21 22:10:08.915210
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        count = 0

        @lazyclassproperty
        def count_cls(self):
            TestClass.count += 1
            return TestClass.count

    instance1 = TestClass()
    instance2 = TestClass()
    assert instance1.count_cls == 1
    assert instance2.count_cls == 1
    assert TestClass.count_cls == 1
    assert TestClass.count == 1
    TestClass.count = 0

    class TestChildClass(TestClass):
        pass

    instance3 = TestChildClass()
    instance4 = TestChildClass()
    assert instance3.count_cls == 1
    assert instance4.count_cls == 1
    assert TestChildClass.count_cls == 1
    assert TestChildClass.count == 1
    assert TestClass.count_

# Generated at 2022-06-21 22:10:13.782867
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    A unit test for class setterproperty
    """
    # Creates an instance for class setterproperty
    a = setterproperty(lambda self, value: setattr(self, 'a', value))
    class Test0:
        a = a
    assert not hasattr(Test0, 'a')
    t = Test0()
    t.a = 1
    assert t.a == 1
    class Test1(Test0):
        pass
    assert t.a == 1
    t = Test1()
    t.a = 2
    assert t.a == 2
    assert 1 in [Test0().a, Test1().a]
    class Test2(Test1):
        pass
    t = Test2()
    assert t.a == 2
    t.a = 3
    assert t.a == 3

# Generated at 2022-06-21 22:10:20.015060
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            return 1

        @classmethod
        def get_foo(cls):
            return cls.foo
    assert Test.get_foo() == 1
    Test.get_foo.__func__.__globals__['foo'] = 2
    Test.get_foo.__func__.__globals__['_lazy_foo'] = 3
    assert Test.get_foo() == 1



# Generated at 2022-06-21 22:10:27.514896
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass:
        def __init__(self):
            self.__x = 0

        @setterproperty
        def x(self, x):
            if x < 0:
                self.__x = 0
            elif x > 1000:
                self.__x = 1000
            else:
                self.__x = x

        @setterproperty
        def y(self, y):
            self.__y = y

        def get_x(self):
            return self.__x

        def get_y(self):
            return self.__y

    obj = TestClass()
    obj.x = -10 # Should set x to 0
    obj.x = 2000 # Should set x to 1000
    assert obj.get_x() == 1000

    # Test assigning to y
    obj.y = 0

# Generated at 2022-06-21 22:10:32.051534
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def roc(cls):
            """C.roc class property, read-only"""
            return 'read-only'
    c = C()

    assert c.__class__.__name__ == 'C'
    assert c.__class__.roc == 'read-only'


# Generated at 2022-06-21 22:10:40.624355
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C1(object):
        def __init__(self, x):
            self.x = x

        @roclassproperty
        def y(clazz):
            return clazz.__name__ + str(self.x)

    class C2(C1):
        pass

    c1 = C1(123)
    c2 = C2(456)
    assert c1.y == 'C1123'
    assert c2.y == 'C2123'  # this will fail if C1.y is implemented in a different way!
    try:
        c1.y = 'c1y'
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-21 22:10:46.271078
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    """
    Test the constructor of class roclassproperty
    """
    import math
    print("PI is: ", math.pi)
    # Define a class DerivedClass
    class DerivedClass(object):
        """
        A derived class: class DerivedClass
        """
        # Define a constant variable PI
        PI = roclassproperty(lambda cls: 3.14159)
    print("DerivedClass.PI is: ", DerivedClass.PI)
    return None


# Generated at 2022-06-21 22:10:50.025669
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def x(cls):
            return cls
    c = C()
    assert c.x == C
    assert c.x == c.x


# Generated at 2022-06-21 22:10:55.533077
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Dummy:
        @setterproperty
        def foo(self, value):
            '''bar'''
            self.bar = value

    assert Dummy.foo.__doc__ == 'bar'
    inst = Dummy()
    assert not hasattr(inst, 'bar')
    inst.foo = 'baz'
    assert inst.bar == 'baz'

# Generated at 2022-06-21 22:11:05.572803
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def b(cls):
            return "test"

    class B(A):
        pass

    assert A.b == "test"
    assert B.b == "test"
    A.b = "test2"
    assert A.b == "test2"
    assert B.b == "test"



# Generated at 2022-06-21 22:11:10.462625
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.my_var = 'a'

        @setterproperty
        def my_var(self, val):
            return val.upper()

    a = A()
    a.my_var = 'b'
    assert 'B' == a.my_var



# Generated at 2022-06-21 22:11:17.976607
# Unit test for constructor of class roclassproperty

# Generated at 2022-06-21 22:11:23.997471
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class X(object):
        def __init__(self):
            self.val = None

        @setterproperty
        def p(self, val):
            """
            Property p
            """
            self.val = val

    x = X()
    x.p = 0
    assert x.val == 0
    assert x.p.__doc__ == "Property p"

# Generated at 2022-06-21 22:11:26.990111
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def f(cls):
            return len(cls.__name__)
    assert A.f == 1

    class B(A):
        pass
    assert B.f == 1


# Generated at 2022-06-21 22:11:38.093561
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        def __init__(self, n):
            self.n = n

        @lazyperclassproperty
        def testprop(cls):
            return cls.a_class_property

        @classmethod
        def a_class_method(cls):
            return cls.a_class_property + 1

        @classmethod
        def a_class_method2(cls):
            return cls.a_class_method() + 1

        @classproperty
        def a_class_property(self):
            return 5

    class Derived(Base):
        @classproperty
        def a_class_property(self):
            return 6

    assert Base(1).testprop == 5
    assert Derived(1).testprop == 6
    assert Base.a_class_method() == 6

# Generated at 2022-06-21 22:11:44.720795
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            pass

    class Sub(Base):
        def __init__(self):
            Base.__init__(self)

    class Test(object):
        @lazyperclassproperty
        def result(cls):
            return "{}-{}".format(cls, ''.join(random.choice('ABCDEF') for _ in range(10)))

    assert Test.result.startswith('Test')
    assert Base.result.startswith('Base')
    assert Sub.result.startswith('Sub')
    assert Test.result == Test.result
    assert Base.result != Sub.result



# Generated at 2022-06-21 22:11:50.703746
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            self.val = None

        def set_val(self, val):
            self.val = val

        @lazyclassproperty
        def calculated_val(cls):
            a = A()
            a.set_val(15)
            return a

    class B(A):
        pass

    class C(A):
        pass

    assert(A.calculated_val.val == 15)
    assert(B.calculated_val.val == 15)
    assert(C.calculated_val.val == 15)



# Generated at 2022-06-21 22:11:56.702709
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def counter(cls):
            return 0

    class Counted(Base):
        pass

    class OtherCounted(Base):
        pass

    Counted.counter += 1
    assert Counted.counter == 1
    assert OtherCounted.counter == 0

    OtherCounted.counter += 1
    assert OtherCounted.counter == 1
    assert Counted.counter == 1


# Generated at 2022-06-21 22:11:59.995750
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X:
        @lazyclassproperty
        def x(cls):
            print("X.x")
            return 3

    class Y(X):
        pass

    class Z(Y):
        pass

    assert Y.x == 3
    assert Z.x == 3
    assert Y.x == 3



# Generated at 2022-06-21 22:12:13.269318
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        x = roclassproperty(lambda cls: cls.__name__)
    assert A.x == 'A'
    try:
        A().x
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-21 22:12:17.977373
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        __metaclass__ = ABCMeta
        @roclassproperty
        @abstractmethod
        def name(cls):
            return 'C'

    assert C.name == 'C'
    assert isinstance(C.name, str)
    assert isinstance(C.name, basestring)



# Generated at 2022-06-21 22:12:21.899979
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, n):
            if n < 0:
                raise ValueError('Argument n is less than 0.')
            self._x = n

    a = A()

    try:
        a.x = -1
    except ValueError as e:
        assert(e.args[0] == 'Argument n is less than 0.')
        assert(a._x == 0)
    else:
        assert(False)

    a.x = 1
    assert(a._x == 1)

# Generated at 2022-06-21 22:12:30.255075
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        pass

    class B(A):
        @setterproperty
        def my_property(self, value):
            self._my_property = value

    b = B()
    b.my_property = 'value'
    assert b._my_property == 'value'

    class C(A):
        @setterproperty
        def my_property(self, value):
            raise TypeError("can't set attribute")

    c = C()
    try:
        c.my_property = 'value'
        assert False, 'TypeError not raised'
    except TypeError:
        pass

# Generated at 2022-06-21 22:12:35.781299
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        def foo(cls):
            return 'I am class!'

        bar = roclassproperty(foo)


# Generated at 2022-06-21 22:12:38.715057
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def lazyprop(cls):
        return 1
    assert lazyprop == 1
    assert Test.lazyprop == 1
    
    class Test(object):
        pass
    
    assert Test.lazyprop == 1



# Generated at 2022-06-21 22:12:47.429017
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class Foo(object):
        def get_bar(self):
            return 'bar'

    class Bar(object):
        x = 3
        _bar = roclassproperty(get_bar)

    assert Bar._bar() == 'bar'
    assert Bar._bar is Foo.get_bar
    assert Bar._bar.__get__(None, Bar) is Foo.get_bar
    assert Bar._bar.__get__(None, Bar) is Bar._bar
    assert Bar._bar() is Bar._bar()
    assert Bar._bar.x == 3
    assert Bar._bar.__get__(None, Bar).x == 3



# Generated at 2022-06-21 22:12:51.376274
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test():
        @lazyclassproperty
        def x(cls):
            cls.counter += 1
            return cls.counter

    Test.counter = 0
    a = Test()
    10
    b = Test()
    a.x
    b.x
    assert b.x == 2
    assert a.x == 2



# Generated at 2022-06-21 22:12:58.157960
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:13:01.459240
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Example(object):
        _x = 1

        @roclassproperty
        def x(cls):
            return cls._x

    assert Example.x == 1
    assert Example().x == 1



# Generated at 2022-06-21 22:13:29.347809
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        # @classproperty
        # def x(cls):
        #    return 1

        x = roclassproperty(lambda cls: 1)

    a = A()
    assert a.x == A.x == 1

    try:
        A.x = 2
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 22:13:42.113781
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # Case 1. Test the function works for both class and object
    class A():
        @setterproperty
        def x(self, value):
            self._x = value
        def get_x(self):
            return self._x
    a = A()
    assert a.get_x() == None
    a.x = 3
    try:
        assert a.get_x() == 3
    except:
        raise Exception("The setterproperty doesn't set the value correctly")
    b = A()
    assert b.get_x() == None
    b.x = 5
    try:
        assert b.get_x() == 5
    except:
        raise Exception("The setterproperty doesn't set the value correctly")

    # Case 2. Test the function works only for object, not class

# Generated at 2022-06-21 22:13:54.176522
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop1(cls):
            print('lazy 1')
            return 'prop1'
    class B(A):
        pass
    class C(A):
        pass
    class D(A):
       @lazyperclassproperty
       def prop1(cls):
           print('lazy 2')
           return 'prop1'
    class E(A):
       @lazyperclassproperty
       def prop1(cls):
           print('lazy 3')
           return 'prop1'

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()
    c1 = C()
    c2 = C()
    d1 = D()
    d2 = D()
    e1 = E()

# Generated at 2022-06-21 22:13:59.064542
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass():
        @lazyclassproperty
        def mylazyclassprop(cls):
            return len(dir(cls))

    assert MyClass.mylazyclassprop == len(dir(MyClass))



# Generated at 2022-06-21 22:14:04.361680
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, x=None):
            self._x = x

        def test__x(self, value):
            self._x = value

        x = setterproperty(test__x, "this is a test of setter property")

    # set the value of x, should run test__x(self, value)
    a = A()
    a.x = 10
    assert_equal(a._x, 10)
    # test the doc
    assert_equal(A.x.__doc__, "this is a test of setter property")



# Generated at 2022-06-21 22:14:10.447866
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value

    c = C()
    assert c._x is None
    c.x = 1
    assert c._x == 1

# Generated at 2022-06-21 22:14:14.839872
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, x):
            if not isinstance(x, int):
                raise TypeError('x must be int')
            self._x = x

    foo = Foo(42)
    foo.x = 'Hello'
    assert foo.x == 42
    assert foo._x == 42



# Generated at 2022-06-21 22:14:17.741614
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class A(object):
        @roclassproperty
        def a(cls):
            return 1

    assert A.a == 1
    assert A().a == 1



# Generated at 2022-06-21 22:14:19.780760
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def test(cls):
            return 'test'
    assert Test.test == 'test'

# Generated at 2022-06-21 22:14:21.388273
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 2
    assert A.foo == 2



# Generated at 2022-06-21 22:15:05.148061
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:15:08.093739
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def a(cls):
            return 1

    assert Foo.a == 1



# Generated at 2022-06-21 22:15:13.772382
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Cls1:
        x = roclassproperty(lambda self: 1)
    class Cls2:
        x = roclassproperty(lambda self: 1)

    o1 = Cls1()
    o2 = Cls2()

    assert o1.x == o2.x == 1

    assert Cls1.x == Cls2.x == 1

    Cls1.x = 2
    Cls2.x = 2

    assert Cls1.x == Cls2.x == 2

    with raises(AttributeError):
        o1.x = 3

    with raises(AttributeError):
        o2.x = 3

# Generated at 2022-06-21 22:15:20.138580
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestClass:
        def __init__(self):
            self.attr = 0

        def set_attr(self, value):
            self.attr = value

    @setterproperty
    def attr_prop(self, value):
        self.set_attr(value)

    test_obj = TestClass()
    assert test_obj.attr == 0, 'Incorrect default value of attribute "attr"'
    attr_prop.__set__(test_obj, 10)
    assert test_obj.attr == 10, 'Incorrect value of attribute "attr"'



# Generated at 2022-06-21 22:15:24.225013
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def __init__(self):
        self.a = 0

    def set_a(self, a):
        self.a = a

    A = type('A', (object,), {'__init__': __init__})
    A.a = setterproperty(set_a)

    a = A()
    assert a.a == 0
    a.a = 1
    assert a.a == 1

# Generated at 2022-06-21 22:15:28.574568
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        def property_getter(cls):
            cls.property_gettera = None
            return 'asdf'

        x = roclassproperty(property_getter)

    a = A()
    A.x  # Sets A.property_gettera to None
    assert a.x == 'asdf'

    # Confirm that it is read-only
    with pytest.raises(AttributeError):
        a.x = 'asdf'



# Generated at 2022-06-21 22:15:30.809591
# Unit test for constructor of class setterproperty

# Generated at 2022-06-21 22:15:33.881604
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class Bar(Foo):
        a = roclassproperty(lambda cls: cls.__name__)
        b = roclassproperty(lambda cls: cls.__module__)

    assert Bar(1,2).b == "__main__"
    assert Bar(1,2).a == "Bar"


# Generated at 2022-06-21 22:15:43.538061
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Getter is called once for each class
    # for each instance on each call
    # for each class then cached

    class A(object):
        _counter = 0
        @lazyclassproperty
        def inc(cls):
            cls._counter += 1
            return cls._counter

        def __init__(self):
            self._instance_counter = 0

        @property
        def inc_instance(self):
            self._instance_counter += 1
            return self._instance_counter

        @inc_instance.setter
        def inc_instance(self, value):
            self._instance_counter = value

    a1 = A()
    a2 = A()
    # A.inc is called once
    assert A.inc == 1
    # a1.inc_instance is called each time
    assert a1.inc_

# Generated at 2022-06-21 22:15:47.055192
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def foo(self, value):
            return value

    foo = Foo()
    foo.foo = 123
    assert foo.foo == 123

# Generated at 2022-06-21 22:17:07.708302
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.a = None


# Generated at 2022-06-21 22:17:16.930554
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x=None):
            self.x = x

        @setterproperty
        def x(self, x):
            return x

        @x.setterproperty
        def x(self, x):
            return x

    a = A()
    assert a.x is None
    a.x = 1
    assert a.x is 1
    a.x = 2
    assert a.x is 2
    assert a.x is not None
    assert a.x != a.x.x
    assert a.x != a.x.x.x
    assert a.x != a.x.x.x.x

    class B(object):
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-21 22:17:20.636698
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # This class should have a class property named 'test' with a documentation
    # string 'A class property' which can only be called, but not be set.
    class Test(object):

        @setterproperty
        def test(self, value):
            pass

        test = property(test, test)

    assert(Test.test.__doc__ == 'A class property')
    assert(callable(Test.test))
    assert(not hasattr(Test.test, '__set__'))


# Generated at 2022-06-21 22:17:26.108235
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:17:31.896877
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        test = roclassproperty(lambda cls: 'test')

    class Bar(Foo):
        pass

    assert Foo.test == 'test'
    assert Bar.test == 'test'


# Python 2.6/2.7 compatibility

# Generated at 2022-06-21 22:17:36.727766
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    from pytest import raises
    from inspect import isclass
    class A:
        def get_value(cls):
            return cls.__name__
        class_att = roclassproperty(get_value)
    class B(A):
        pass
    assert A.class_att == 'A'
    assert isclass(A.class_att)
    assert B.class_att == 'B'
    assert isclass(A.class_att)
    with raises(AttributeError):
        A.class_att = 1
    with raises(AttributeError):
        B.class_att = 2


# Generated at 2022-06-21 22:17:38.345799
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def method(obj, value):
        """method doc"""
        print("Original method")

    obj = setterproperty(method)
    obj.__set__("obj_instance", "value")



# Generated at 2022-06-21 22:17:41.305615
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class a(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self,x):
            self._x = x

        @x.getter
        def x(self):
            return self._x

    assert a().x == None
    a().x = 1
    assert a().x == 1
    a().x = 2
    assert a().x == 2

