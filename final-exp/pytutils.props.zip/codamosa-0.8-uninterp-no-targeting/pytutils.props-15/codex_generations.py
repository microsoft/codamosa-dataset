

# Generated at 2022-06-21 22:07:43.576252
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        _test = 1

        @setterproperty
        def test(self, value):
            self._test = value

    foo = Foo()
    foo.test = 2
    assert foo._test == 2


# Generated at 2022-06-21 22:07:47.149812
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        class ro_attr(roclassproperty):
            def __get__(self, instance, owner):
                return 1

    assert A.ro_attr == 1

# Generated at 2022-06-21 22:07:49.172527
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def get_x(self, x):
            self.x = x

        @setterproperty
        def get_y(self, y):
            self.y = y

    a = A()
    a.get_x = 10
    assert a.x == 10
    a.get_y = 20
    assert a.y == 20

# Generated at 2022-06-21 22:07:53.134072
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):

        @setterproperty
        def bar(self, value):
            self.bar = value
    foo = Foo()
    foo.bar = 1
    assert foo.bar == 1


# Generated at 2022-06-21 22:07:58.354067
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, x):
            "I'm the 'x' property."
            self._x = x

    c = C()
    c.x = 'foo'
    assert c._x == 'foo'

    assert C.x.__doc__ == "I'm the 'x' property."


# Generated at 2022-06-21 22:08:01.099788
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class X:

        @roclassproperty
        def foo(cls):
            return 'foo'

    assert X.foo == 'foo'
    assert X().foo == 'foo'



# Generated at 2022-06-21 22:08:07.193709
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from unittests.test_helpers import run_test
    from utils.decorators import setterproperty

    class C(object):
        @setterproperty
        def Prop(self, value):
            self.__prop = value

    obj = C()
    obj.Prop = 'test value'
    run_test(obj.__prop == 'test value', 'Setter method of setterproperty failed')

# Generated at 2022-06-21 22:08:12.275802
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def roclassproperty(self):
            return "roclassproperty"
        @roclassproperty
        def _ro_property(self):
            return self.roclassproperty()

    assert TestClass._ro_property == "roclassproperty"



# Generated at 2022-06-21 22:08:23.567417
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestSetterProperty(object):
        def __init__(self):
            self._prop1 = None
            self._prop2 = None
            self._prop3 = None

        @setterproperty
        def prop1(self, value):
            self._prop1 = value

        @setterproperty
        def prop2(self, value):
            self._prop2 = value

        @setterproperty
        def prop3(self, value):
            self._prop3 = value

    t = TestSetterProperty()

    t.prop1 = 'setter_prop1'
    t.prop2 = 'setter_prop2'
    t.prop3 = 'setter_prop3'

    assert t._prop1 == 'setter_prop1'
    assert t._prop2 == 'setter_prop2'
    assert t

# Generated at 2022-06-21 22:08:26.207236
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class T(object):
        @roclassproperty
        def prop(cls):
            return cls

    assert T.prop == T
    assert T().prop == T



# Generated at 2022-06-21 22:08:33.647234
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.value = 0

        def __repr__(self):
            return 'Test={}'.format(self.value)

        @setterproperty
        def setter(self, value):
            self.value = value

    class TestSub(Test):
        pass

    t = Test()
    t.setter = 1
    assert t.value == 1

    ts = TestSub()
    ts.setter = 1
    t.setter = 2
    assert t.value == 2
    assert ts.value == 1


# Generated at 2022-06-21 22:08:42.122487
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # Define a class with a property
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls.__name__ + ' class'

        @roclassproperty
        def baz(cls):
            return cls.__name__ + ' instance'

    assert isinstance(Foo.bar, roclassproperty)
    assert isinstance(Foo.baz, roclassproperty)

    assert Foo.__dict__['bar'].__get__(1) == 'Foo class'
    assert Foo().__dict__['baz'].__get__(1) == 'Foo instance'



# Generated at 2022-06-21 22:08:51.420986
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @classproperty
        def func(cls):
            return 'func'

        @roclassproperty
        def func(cls):
            return 'rofunc'

        @roproperty
        def get_func(self):
            return 'rogetfunc'


# Generated at 2022-06-21 22:08:59.327192
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit tests for __set__ of class setterproperty.
    """
    from pycosat import _cnf
    test_cnf = _cnf.CNF([['a', 'b'], ['b', 'c'], ['c', 'd'], ['a', '-d']])
    test_int = 0
    @setterproperty
    def test_setterproperty(self, value):
        test_int = value
    test_setterproperty.__set__(test_cnf, 1)
    assert test_cnf.satisfy_one() == [1, 1, 1, 0]
    assert test_int == 1



# Generated at 2022-06-21 22:09:03.152854
# Unit test for constructor of class setterproperty
def test_setterproperty():
    x = 1
    def add_x(self, value):
        nonlocal x
        x += value
    class A:
        s = setterproperty(add_x)
    A().s = 5
    assert x == 6, f'A().s = 5 should add 5 to x to make x = 6'



# Generated at 2022-06-21 22:09:11.313471
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # read only class property
    class A(object):
        @roclassproperty
        def f(cls):
            return "read only class property"

        @classmethod
        def g(cls):
            return "class method"


# Generated at 2022-06-21 22:09:18.466883
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:09:21.550092
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo:
        _x = 1
        @setterproperty
        def x(self, value):
            self._x = value + 1
    foo = Foo()
    foo.x = 0
    assert foo._x == 1



# Generated at 2022-06-21 22:09:26.416101
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class test_class:
        count = 0

        @roclassproperty
        def test(cls):
            test_class.count += 1
            return test_class.count + 1

    assert test_class.test == 3
    assert test_class.test == 4
    assert test_class.test == 5
    assert test_class.test == 6
    assert test_class.test == 7



# Generated at 2022-06-21 22:09:30.006038
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class myclass(object):
        count = 0

        @lazyclassproperty
        def method1(cls):
            myclass.count += 1
            return myclass.count
    # Run the lazy getter
    myclass.method1
    # Check that only one instance was created.
    assert myclass.count == 1


# Use the classproperty decorator to create a cached property on classes.

# Generated at 2022-06-21 22:09:41.604244
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.a = 1

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class T:
        @lazyperclassproperty
        def prop(cls):
            newobj = cls()
            newobj.a += 1
            return newobj

    assert T.prop.a == 2
    assert B.prop.a == 2
    assert C.prop.a == 2
    assert D.prop.a == 2

# Generated at 2022-06-21 22:09:50.320440
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class TestClass(object):
        __my_field = None

        @staticmethod
        def setter(value):
            TestClass.__my_field = value

        @roclassproperty
        def my_field(cls):
            return cls.__my_field

    # Test setting the value
    TestClass.setter("test value")
    assert TestClass.my_field == "test value"

    # Making sure that neither the class, nor the instance are writable
    try:
        TestClass.my_field = "new value"
    except Exception as e:
        assert type(e) == AttributeError
    try:
        TestClass().my_field = "new value"
    except Exception as e:
        assert type(e) == AttributeError

    # Making sure that both, class and instance are readable
    Test

# Generated at 2022-06-21 22:09:56.165123
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def _get_name(cls):
            print('_get_name')
            return 'bob'

        # This class property can be accessed as A.name
        name = lazyclassproperty(_get_name)

    assert A.name == 'bob', "It should return bob"


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-21 22:10:06.210306
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print('lazy getter a()' % cls)
            return 'return value a'
    a1 = A()
    a2 = A()
    A1 = A
    A2 = type('A2', (A,), {})
    assert a1.a == 'return value a'
    assert a1.a == 'return value a'
    assert a2.a == 'return value a'
    assert a2.a == 'return value a'
    assert A1.a == 'return value a'
    assert A1.a == 'return value a'
    assert A2.a == 'return value a'
    assert A2.a == 'return value a'
    assert a1.a == 'return value a'
    assert a

# Generated at 2022-06-21 22:10:15.269565
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class A(object):
        def __init__(self):
            self.val = None
            self.val2 = None

        @setterproperty
        def func(self, val):
            if isinstance(val, int):
                self.val = val
            else:
                self.val2 = val
        # enddef

        @classmethod
        def func2(cls, val):
            if isinstance(val, int):
                cls.val = val
            else:
                cls.val2 = val
        # enddef

    class B(A):
        def __init__(self):
            super(B, self).__init__()
        # enddef

    a = A()
    b = B()

    # Set an instance value
    a.func = 5

# Generated at 2022-06-21 22:10:23.391251
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.var1 = 0

        @setterproperty
        def var1(self, value):
            self._var1 = value
            self.var2 = value + 1
            return value

        @setterproperty
        def var2(self, value):
            self._var2 = value
            self.var1 = value - 1
            return value

    a = A()
    assert a.var1 == 0
    assert a.var2 == 1
    a.var1 = 2
    assert a._var1 == 2
    assert a._var2 == 3
    a.var2 = 4
    assert a._var1 == 3
    assert a._var2 == 4

# Generated at 2022-06-21 22:10:26.233265
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def foo(self, value):
        self.value = value

    class Test(object):
        prop = setterproperty(foo)

    test = Test()
    test.prop = 1
    if test.value != 1:
        raise ValueError('Property not set')



# Generated at 2022-06-21 22:10:30.684799
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        pass

    class Test(Base):
        @lazyperclassproperty
        def my_property(self):
            print("in property()")
            return 42

    class MyTest(Test):
        pass

    class MyTest1(Test):
        pass

    class MyTest2(MyTest):
        pass

    # Testing if each class have their own property
    assert Test.my_property == 42
    assert MyTest.my_property == 42
    assert MyTest1.my_property == 42
    assert MyTest2.my_property == 42

    # Change value to a different one
    Test.my_property = 99
    assert Test.my_property == 99
    assert MyTest.my_property == 42
    assert MyTest1.my_property == 42

# Generated at 2022-06-21 22:10:36.613709
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:

        def __init__(self):
            self._x = 'foo'

        @roclassproperty
        def x(cls):
            return cls._x

    a = A()
    assert a.x == a._x
    assert A.x == a._x
    A._x = 'bar'
    assert A.x == a.x
    a.x = 'foobar'
    assert a.x == a._x
    assert A.x == a._x

# Generated at 2022-06-21 22:10:41.651814
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test_setterproperty___set__:
        def __init__(self): self._x = None
        def _set_x(self, value): self._x = value
        x = setterproperty(_set_x)

    t = Test_setterproperty___set__()
    t.x = 'X'

    assert t.x, 'X'
    assert t._x, 'X'

# Generated at 2022-06-21 22:10:54.995052
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.value = -1
        @setterproperty
        def value(self, value):
             self.value = value
    a = A()
    a.value = 5
    assert(a.value == 5)

# Generated at 2022-06-21 22:11:01.600936
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return super(B, cls).x + 1

    assert A.x == 1
    assert B.x == 2

    # Make sure that the value is cached
    assert A.x == 1
    assert B.x == 2

    # Make sure different classes store different values
    class C(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 10

    assert C.x == 10
    assert A.x == 1


# Generated at 2022-06-21 22:11:04.817873
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

    assert Foo.foo == 'foo'
    assert Foo().foo == 'foo'



# Generated at 2022-06-21 22:11:10.058957
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def prop(cls):
            return 'prop_value'

        @classmethod
        def getprop(cls):
            return cls.prop

    # First test
    assert Test.getprop() == 'prop_value'

    # Second test
    assert Test.getprop() == 'prop_value'



# Generated at 2022-06-21 22:11:16.120318
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def foo(self, value):
            """
            Foo property docstring
            """
            self._foo = value

        @foo.setter
        def foo(self, value):
            self._foo = value

        @property
        def foo(self):
            return self._foo

    # Foo is working
    a = A()
    a.foo = 1
    assert a.foo == 1

    # Docstring is there
    assert A.foo.__doc__ == "Foo property docstring"



# Generated at 2022-06-21 22:11:26.093492
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @roclassproperty
        def rop_roclassproperty(cls):
            return 1

        @roclassproperty
        def rop_roclassproperty2(cls):
            return 2

        @classproperty
        def rop_classproperty(cls):
            return 3

    assert MyClass.rop_roclassproperty == 1
    assert MyClass.rop_roclassproperty2 == 2
    assert MyClass.rop_classproperty == 3
    mc = MyClass()
    assert mc.rop_roclassproperty == 1
    assert mc.rop_roclassproperty2 == 2
    assert mc.rop_classproperty == 3



# Generated at 2022-06-21 22:11:29.247195
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'baz'

    assert(Foo.bar == 'baz')
    assert(Foo().bar == 'baz')



# Generated at 2022-06-21 22:11:33.117711
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):

        @roclassproperty
        def get_something(cls):
            return cls.__name__

    print(MyClass.get_something)
    print(MyClass().get_something)



# Generated at 2022-06-21 22:11:37.484258
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class testSetterProperty(object):
        def __init__(self, mname):
            self.__mname = mname

        @setterproperty
        def name(self, newName):
            self.__mname = newName
    tester = testSetterProperty("justforfun")
    tester.name = "justforfun1"
    assert tester.__mname == "justforfun1"

# Generated at 2022-06-21 22:11:44.086914
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    foo = False

    class Foo():
        @lazyperclassproperty
        def prop(cls):
            nonlocal foo
            foo = True
            return True

    class Bar(Foo): pass

    assert not foo, "lazyperclassproperty has already been evaluated"
    assert Foo.prop, "lazyperclassproperty not evaluated"
    assert Bar.prop, "lazyperclassproperty not evaluated"
    assert foo, "lazyperclassproperty should have been evaluated"
    assert Foo.prop, "lazyperclassproperty not re-evaluated"
    assert Bar.prop, "lazyperclassproperty not re-evaluated"

    foo = False


# Generated at 2022-06-21 22:12:06.162847
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(self):
            x = 1
            return x

    a1 = A()
    a2 = A()
    assert a1.x == a2.x
    assert a1.x == 1
    assert a2.x == 1
    A.x = 2
    assert a1.x == 2
    assert a2.x == 2
    assert A.x == 2



# Generated at 2022-06-21 22:12:12.376109
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class roclassproperty_test(object):
        def __init__(self):
            self._x = 42

        @roclassproperty
        def x(cls):
            return cls._x

    t = roclassproperty_test()
    assert t.x == 42, "roclassproperty_test().x == " + str(t.x)
    #t.x = 999


# Generated at 2022-06-21 22:12:21.015272
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class _A(object):
        def _fn(self):
            return 1

    class _B(_A):
        pass

    class _C(_A):
        pass

    class A(object):
        @lazyperclassproperty
        def fn(cls):
            return cls._fn()

    assert A.fn == 1
    assert A.fn == 1 # Test for cache/lazyness: 2nd call should not change the value
    assert B.fn == 1
    assert isinstance(A.fn, int)
    assert isinstance(B.fn, int)

    class B(A):
        def _fn(self):
            return 2

    assert B.fn == 2
    assert A.fn == 1
    assert C.fn == 1

    class C(A):
        pass

    assert C.fn == 1


# Generated at 2022-06-21 22:12:33.250820
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class AAA(object):
        classval = 3

    class BBB(AAA):
        classval = 4

    class CCC(AAA):
        pass

    @lazyperclassproperty
    def classval2(a):
        return a.classval * 2

    assert not hasattr(AAA, '_AAA_lazy_classval2')
    assert not hasattr(BBB, '_BBB_lazy_classval2')
    assert not hasattr(CCC, '_CCC_lazy_classval2')

    assert AAA.classval2 == 6
    assert hasattr(AAA, '_AAA_lazy_classval2')
    assert BBB.classval2 == 8
    assert hasattr(BBB, '_BBB_lazy_classval2')
    assert CCC.classval2 == 6
   

# Generated at 2022-06-21 22:12:42.627238
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("Generating foo")
            return "foo"

    class B(A):
        @lazyperclassproperty
        def bar(cls):
            print("Generating bar")
            return "bar"

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("Generating foo")
            return "foo"

    assert hasattr(A, "_A_lazy_foo")
    assert hasattr(B, "_B_lazy_foo")
    assert hasattr(B, "_B_lazy_bar")
    assert hasattr(C, "_C_lazy_foo")
    assert B.foo == "foo"
    assert C.foo == "foo"

# Generated at 2022-06-21 22:12:48.055000
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class foo(object):
        @roclassproperty
        def foo(cls):
            return cls

        @roclassproperty
        def bar(cls):
            return foo

    assert foo.foo is foo
    assert foo.bar is foo

    assert foo().foo is foo
    assert foo().bar is foo


# Generated at 2022-06-21 22:12:53.065085
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def prop(cls):
            return 1

    class B(A):
        pass

    assert A.__dict__["prop"].__get__(None, A) == 1
    assert B.__dict__["prop"].__get__(None, B) == 1
    assert B.__dict__["prop"].__get__(None, B) == B.prop


if __name__ == "__main__":
    test_roclassproperty()

# Generated at 2022-06-21 22:13:00.406175
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Class:
        def __init__(self, value):
            self._x = value

        @setterproperty
        def x(self, value):
            self._x = value + 1

        @setterproperty
        def y(self, value):
            raise ValueError('error')

    o = Class(0)
    o.x = 100
    assert o._x == 101
    o._x = 0
    with pytest.raises(ValueError) as excinfo:
        o.y = 100
    assert 'error' in str(excinfo.value)



# Generated at 2022-06-21 22:13:07.261782
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self.x = 1

        @setterproperty
        def x(self, value):
            self.x = value
    test = Test()
    test.x = 2
    assert test.x == 2


# Generated at 2022-06-21 22:13:11.844792
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 1

    assert A.x == 1
    a = A()
    assert a.x == 1
    try:
        a.x = 2
    except AttributeError:
        pass
    else:
        assert False, "A.x should be read-only"



# Generated at 2022-06-21 22:13:55.088788
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def p(cls):
            "p help"
            return 1

    assert A.p == 1
    # Can't set class property A.p
    with pytest.raises(AttributeError):
        A.p = 2

    class B(A): pass
    assert B.p == 1
    # Can't set class property B.p
    with pytest.raises(AttributeError):
        B.p = 2

    class C(object):
        c = 1
        @roclassproperty
        def p(cls):
            "p help"
            return cls.c

    assert C.p == 1
    # Can't set class property C.p
    with pytest.raises(AttributeError):
        C.p = 2


# Generated at 2022-06-21 22:13:58.922363
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # case: method __get__ of class roclassproperty
    assert True

    # case: method __get__ of class roclassproperty
    assert True


# Generated at 2022-06-21 22:14:05.153825
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def name(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.name == "A"
    assert B.name == "B"
    assert A().name == "A"
    assert B().name == "B"
    try:
        A().name = 'test'
        assert False, "_test_roclassproperty - test_roclassproperty___get__() - " \
                      "expected TypeError to be thrown"
    except TypeError:
        assert True

    try:
        B().name = 'test'
        assert False, "_test_roclassproperty - test_roclassproperty___get__() - " \
                      "expected TypeError to be thrown"
    except TypeError:
        assert True


# Generated at 2022-06-21 22:14:11.034629
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass:
        def __init__(self):
            self.x = None

        @setterproperty
        def setter(self, value):
            self.x = value

    obj = TestClass()
    assert obj.x == None
    obj.setter = 10
    assert obj.x == 10

# Generated at 2022-06-21 22:14:14.115516
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def x(cls):
            print('x called')
            return 'y'

    print(Test.x)  # print('x called')
    print(Test.x)  # print() only



# Generated at 2022-06-21 22:14:17.932669
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def set_attr(self, value):
            self._attr = value
            
        attr = setterproperty(set_attr)

    a = A()
    a.attr = 'b'
    assert a._attr == 'b'


# Generated at 2022-06-21 22:14:23.891008
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return 1

    assert Foo.bar == 1
    assert Foo().bar == 1

    class Baz(Foo):
        pass

    assert Baz.bar == 1
    assert Baz().bar == 1

    Foo.bar = 2
    assert Foo.bar == 2
    assert Foo().bar == 2
    assert Baz.bar == 1
    assert Baz().bar == 1

    Baz.bar = 3
    assert Foo.bar == 2
    assert Foo().bar == 2
    assert Baz.bar == 3
    assert Baz().bar == 3

# Generated at 2022-06-21 22:14:28.061598
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 2

    print("Foo.bar =", Foo.bar)
    print("Foo.bar =", Foo.bar)



# Generated at 2022-06-21 22:14:30.915833
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X:
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert X.prop == 'value'



# Generated at 2022-06-21 22:14:36.667078
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def func(obj, value):
        return value

    val = setterproperty(func)
    assert val.func == func
    assert val.__doc__ == func.__doc__
    assert val.__set__("test", "test") == "test"

# Generated at 2022-06-21 22:15:53.784338
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        count = 0
        @lazyperclassproperty
        def class_num(cls):
            cls.count += 1
            return cls.count
    class B(A):
        pass
    for i, c in enumerate((A, B, A, B, A), 1):
        assert c.class_num == i
    assert A.count == 3


# Generated at 2022-06-21 22:15:58.882938
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    assert A.foo == 'bar'
    assert B.foo == 'bar'
    A().foo
    B().foo


# Generated at 2022-06-21 22:16:03.465765
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self._state = None

        @setterproperty
        def state(self, value):
            self._state = value

    t = Test()
    t.state = 'value'
    assert t._state == 'value'
    assert t.state is None



# Generated at 2022-06-21 22:16:11.620248
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # @roclassproperty
    # AttributeError: __class__ not accessible in classproperty objects
    class C1:
        class_counter = 0
        instance_counter = 0

        @classproperty
        def run(cls):
            return cls.class_counter

        def increase(cls):
            cls.class_counter += 1

        @roclassproperty
        def ro_run(cls):
            return cls.class_counter

        @classproperty
        def instance_count(cls):
            return cls.instance_counter

        def __init__(self):
            type(self).instance_counter += 1

    c1 = C1()
    c2 = C1()

    assert C1.class_counter == 2
    assert C1.run == 2
    assert C1.ro_run == 2


# Generated at 2022-06-21 22:16:18.498209
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self): self._x = {}

        @roclassproperty
        def x(cls):
            return cls._x
    assert [] == Test.x.keys()
    Test.x['a'] = 'A'
    Test().x['b'] = 'B'
    assert Test.x.keys() == ['a', 'b']
    assert Test().x.keys() == ['a', 'b']
    assert Test.x == Test().x

if __name__ == "__main__":
    test_roclassproperty()

# Generated at 2022-06-21 22:16:28.249541
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:16:35.460387
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestObject(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @setterproperty
        def set_x(self, value):
            self.x = value

        @setterproperty
        def set_y(self, value):
            self.y = value

    obj = TestObject(1, 2)
    assert obj.x == 1
    obj.set_x = 4
    assert obj.x == 4
    assert obj.y == 2

    obj = TestObject(-3, 4)
    assert obj.y == 4
    obj.set_y = -4
    assert obj.y == -4
    assert obj.x == -3



# Generated at 2022-06-21 22:16:38.689460
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class ClassROCP(object):
        @roclassproperty
        def prop_func(cls): return cls.__name__
    assert ClassROCP.prop_func == 'ClassROCP'
    assert ClassROCP().prop_func == 'ClassROCP'


# Generated at 2022-06-21 22:16:41.466810
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class ExampleClass(object):
        @roclassproperty
        def someproperty(cls):
            return 'value'

    assert ExampleClass.someproperty == 'value'



# Generated at 2022-06-21 22:16:44.178824
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestClass(object):

        @lazyclassproperty
        def TestProperty(cls):
            return 'Hello, World'


    assert TestClass.TestProperty == 'Hello, World'