

# Generated at 2022-06-21 22:07:54.255617
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class TestA(object):
        @lazyperclassproperty
        def test(cls):
            return 'test_in_a'
    class TestB(object):
        @lazyperclassproperty
        def test(cls):
            return 'test_in_b'
    class TestC(TestA):
        pass
    class TestD(TestB):
        pass

    a = TestA()
    b = TestB()
    c = TestC()
    d = TestD()

    assert a.test == 'test_in_a', "lazyperclassproperty error"
    assert b.test == 'test_in_b', "lazyperclassproperty error"
    assert c.test == 'test_in_a', "lazyperclassproperty error"

# Generated at 2022-06-21 22:08:03.789978
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def name(cls):
            print('Calling name()...')
            return 'C'

    assert C.name == 'C'
    assert C.name == 'C'
    assert C.name == 'C'

    # function lazyclassproperty caches the result per class
    class D(C): pass
    assert D.name == 'C'
    assert D.name == 'C'

    class E(C):
        @lazyclassproperty
        def name(cls):
            print('Calling name()...')
            return 'E'
    assert E.name == 'E'
    assert E.name == 'E'


# @lazyperclassproperty
# def lazyperclassproperty(fn):
#     """
#     Lazy/Cached class property that stores separate

# Generated at 2022-06-21 22:08:06.798534
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test_roclassproperty:

        @roclassproperty
        def foo(cls):
            return 'bar'

    assert Test_roclassproperty.foo == 'bar'



# Generated at 2022-06-21 22:08:09.453651
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import doctest

    failures, tests = doctest.testmod(verbose=True)
    return failures


# Generated at 2022-06-21 22:08:21.011947
# Unit test for constructor of class setterproperty
def test_setterproperty():
    from kombu import Exchange, Queue

    class Entity(object):

        # normal setterproperty
        @setterproperty
        def exchange(self, exchange):
            self._exchange = exchange
            return self

        # setterproperty with __doc__
        @setterproperty(doc='The default exchange, used for all entities that do\n    not explicitly specify an exchange.')
        def default_exchange(self, exchange):
            self._default_exchange = exchange
            return self

    def test_get_exchange():
        a = Entity()
        a.exchange = Exchange("test_exchange")
        assert a._exchange.name == "test_exchange"

    def test_get_default_exchange():
        b = Entity()
        b.default_exchange = Exchange("test_default_exchange")


# Generated at 2022-06-21 22:08:25.783437
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def random_number(cls):
            return random.randint(1,1000)

    assert A.random_number == A.random_number
    assert A.random_number != A.random_number

test_lazyclassproperty()



# Generated at 2022-06-21 22:08:31.972565
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        _x = 0

        @lazyperclassproperty
        def x(cls):
            cls._x += 1
            return cls._x

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    foo = Foo()
    bar = Bar()
    baz = Baz()

    assert Foo.x == 1
    assert Bar.x == 1
    assert Baz.x == 1
    assert foo.x == 1
    assert bar.x == 1
    assert baz.x == 1



# Generated at 2022-06-21 22:08:42.189269
# Unit test for constructor of class setterproperty
def test_setterproperty():
    import unittest

    class Foo(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            assert isinstance(value, int)
            self._x = value

        @x.getter
        def x(self):
            return self._x

    class TestSetterPropery(unittest.TestCase):
        def setUp(self):
            self.foo = Foo(8)

        def tearDown(self):
            pass

        def test_setter(self):
            self.foo.x = 10
            self.assertEquals(self.foo.x, 10)

    unittest.main()


# Generated at 2022-06-21 22:08:48.711059
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    VerificationError = AssertionError

    class Foo(object):
        def _get_lazy(cls):
            # should be called only once
            raise VerificationError('should not be reached')

        lazy = lazyclassproperty(_get_lazy)

    assert Foo.lazy is Foo.lazy



# Generated at 2022-06-21 22:08:51.544371
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls

        @roclassproperty
        def baz(cls):
            return cls.__name__

    f = Foo()
    assert f.bar() is Foo
    assert f.baz == 'Foo'


# Generated at 2022-06-21 22:08:59.175230
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    from classproperty import roclassproperty
    class C():
        @roclassproperty
        def a(cls):
            return "A"

        @roclassproperty
        def b(cls):
            return "B"

    assert C.a == 'A'
    assert C.b == 'B'

    C.a = "C"
    C.b = "D"

    assert C.a == 'A'
    assert C.b == 'B'



# Generated at 2022-06-21 22:09:02.766418
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self.x = 1

        @roclassproperty
        def y(cls):
            return 3

    a = A()
    assert a.x is 1
    assert a.y is 3



# Generated at 2022-06-21 22:09:03.840655
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    assert roclassproperty(lambda: return_true)()



# Generated at 2022-06-21 22:09:13.581956
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        _value = None

        @setterproperty
        def value(self, value):
            self._value = value

    a = A()

    assert(a._value is None)

    a.value = "test"
    assert(a.value == "test")
    assert(a._value == "test")

    a.value = "test"
    assert(a.value == "test")
    assert(a._value == "test")

    a.value = "test"
    assert(a.value == "test")
    assert(a._value == "test")

    a.value = "another test"
    assert(a.value == "another test")
    assert(a._value == "another test")

# Generated at 2022-06-21 22:09:19.319716
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        def getX(cls):
            return 1

        x = roclassproperty(getX)

    assert Foo.x == 1  # call class __getattr__
    assert Foo().x == 1  # use __dict__ lookup on class
    try:
        Foo.x = 2
        raise Exception('Expected AttributeError')
    except AttributeError:
        pass
    try:
        Foo().x = 2
        raise Exception('Expected AttributeError')
    except AttributeError:
        pass



# Generated at 2022-06-21 22:09:28.012875
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest2 as unittest
    from friend.utils import setterproperty

    class TestClass(object):
        def __init__(self):
            self.a = 1

        @setterproperty
        def a(self, value):
            if value == 2:
                return 'The secret value!'
            raise ValueError(value)

    class TestSetterProperty(unittest.TestCase):
        def test(self):
            tc = TestClass()
            self.assertEqual(tc.a, 1)
            tc.a = 2
            self.assertEqual(tc.a, 1)
            with self.assertRaises(ValueError) as cm:
                tc.a = 10
            self.assertEqual(cm.exception.args[0], 10)

    unittest.main()



# Generated at 2022-06-21 22:09:31.702549
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Testclass(object):
        def __init__(self):
            self.__test = None

        @setterproperty
        def test(self, value):
            self.__test = value

    tc = Testclass()
    tc.test = 'abc'
    assert tc.__test == 'abc'



# Generated at 2022-06-21 22:09:37.296890
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    import unittest

    class Owner(object):
        pass

    fn = lambda cls: 'hello'

    classproperty = roclassproperty(fn)

    class Test(unittest.TestCase):
        def test_get(self):
            classproperty.__get__(Owner, Owner)

            class Foo(object):
                bar = classproperty

            foo = Foo()

            self.assertEqual(foo.bar, classproperty.__get__(foo, Foo))
            self.assertEqual(foo.bar, fn(Foo))

    suite = unittest.TestLoader().loadTestsFromTestCase(Test)
    unittest.TextTestRunner().run(suite)



# Generated at 2022-06-21 22:09:39.514054
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def test(cls):
            return 1

    assert A.test == 1


# Generated at 2022-06-21 22:09:47.552017
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, v):
            self.__value = v

        @setterproperty
        def value(self, v):
            self.__value = v

        @property
        def value(self):
            return self.__value

    c = C(1)
    assert c.value == 1
    c.value = 2
    assert c.value == 2

    class E(C):
        def __init__(self, v):
            C.__init__(self, v)

    e = E(3)
    assert e.value == 3

    try:
        E.value = 5
    except AttributeError:
        assert True



# Generated at 2022-06-21 22:09:58.443498
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self.__bar = 'c'

        def _get_bar(self):
            return self.__bar

        def _set_bar(self, value):
            self.__bar = value

        bar = setterproperty(_get_bar, _set_bar)

    a = Foo()
    assert a.bar == 'c'

    a.bar = 'b'
    assert a.bar == 'b'

    

# Generated at 2022-06-21 22:10:08.129471
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class C(object):
        @lazyclassproperty
        def x(cls):
            print(cls.__name__)
            return 'foo'
        @lazyclassproperty
        def y(cls):
            print(cls.__name__)
            return 'foo'

    assert C.x == 'foo'
    assert C.x == 'foo'

    class D(C):
        pass
    #
    # Prints "C"
    assert D.x == 'foo'
    #
    # Doesn't print anything
    assert D.x == 'foo'

    class E(C):
        @lazyclassproperty
        def x(cls):
            print(cls.__name__)
            return 'bar'

    # Prints "E"
    assert E.x == 'bar'


# Generated at 2022-06-21 22:10:11.566319
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.__x = 0

        @setterproperty
        def x(self, value):
            self.__x = value

    a = A()
    assert a.x is None
    a.x = 1
    assert a.x is 1

# Generated at 2022-06-21 22:10:15.655004
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Base(object):
        @roclassproperty
        def foo(cls):
            return cls

    class Derived(Base):
        pass

    assert Base.foo is Base
    assert Derived.foo is Derived
    assert Base().foo is Base
    assert Derived().foo is Derived



# Generated at 2022-06-21 22:10:22.147356
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Example(object):
        @lazyperclassproperty
        def value(cls):
            return 1


    print("Parent class's value: %d" % Example.value)

    class SubExample(Example):
        pass


    print("Child class's value: %d" % SubExample.value)

    # Because SubExample and Example are two different class,
    # the two class's value will be different
    assert Example.value == 1
    assert SubExample.value == 1
    Example.value = 2
    assert Example.value == 2
    assert SubExample.value == 1


# Generated at 2022-06-21 22:10:27.665437
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def x(cls):
            return 'Base.x'

    class Child(Base):
        pass

    assert Base.x == 'Base.x'
    assert Child.x == 'Base.x'

    class GrandChild(Child):
        @lazyperclassproperty
        def x(cls):
            return 'GrandChild.x'

    assert Base.x == 'Base.x'
    assert Child.x == 'Base.x'
    assert GrandChild.x == 'GrandChild.x'
    assert Base.x != GrandChild.x



# Generated at 2022-06-21 22:10:31.412538
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def prop(cls):
            return "roclassproperty"

    assert A.prop == "roclassproperty"
    assert A().prop == "roclassproperty"



# Generated at 2022-06-21 22:10:34.697613
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        @setterproperty
        def value(self, val):
            self._value = val

    t = Test()
    t.value = 3
    eq_(t._value, 3)

# Generated at 2022-06-21 22:10:37.595611
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Hoge:
        pass

    @setterproperty
    def val(self, val):
        self._val = val

    hoge = Hoge()
    hoge.val = 'val'
    assert hoge._val == 'val'

# Generated at 2022-06-21 22:10:40.623882
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def p(cls):
            return 1

    assert C.p == 1
    with pytest.raises(AttributeError):
        C().p


# Generated at 2022-06-21 22:10:56.751299
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class P(object):
        def get_name(self):
            return "name"
        rocp = roclassproperty(get_name)

    assert P.rocp == "name"
    with pytest.raises(AttributeError):
        P().rocp
    #Change the value of the property by changing the value of the function.
    P.get_name = lambda self: "new_name"
    assert P.rocp == "new_name"
    #The value of the property cannot be modified.
    with pytest.raises(AttributeError):
        P.rocp = "abc"


# Generated at 2022-06-21 22:11:01.197702
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def name(cls):
            return "A"

    class B(A):
        @roclassproperty
        def name(cls):
            return "B"

    assert "A".__eq__(A.name)
    assert "B".__eq__(B.name)



# Generated at 2022-06-21 22:11:07.651889
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # both those class properties are set
    assert setterproperty(lambda self, value: setattr(self, 'value', value)) is not None, "Method __set__ of class setterproperty failed: cannot set value of class property"
    assert setterproperty(lambda self, value: setattr(self, 'value', value), doc=None) is not None, "Method __set__ of class setterproperty failed: cannot set value of class property"


# Generated at 2022-06-21 22:11:15.447971
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Foo(object):

        def __init__(self):
            self.value = 'Foo'

        @lazyperclassproperty
        def value(cls):
            return 'Hi from %s' % cls.__name__

    class Bar(Foo):

        def __init__(self):
            super(Bar, self).__init__()
            self.value = 'Bar'

        @lazyperclassproperty
        def value(cls):
            return 'Hello from %s' % cls.__name__

    foo = Foo()
    bar = Bar()

    assert foo.value == 'Hi from Foo'
    assert bar.value == 'Hello from Bar'



# Generated at 2022-06-21 22:11:16.963830
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    d = D()
    d.c = 1
    d.c += 1
    d.c -= 1
    d.c -= 1



# Generated at 2022-06-21 22:11:22.934981
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        pass

    class B(A):
        @setterproperty
        def a(self, value):
            self.__class__ = value

    a = A()
    b = B()
    b.a = A
    assert b.__class__ == A


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:11:26.260787
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        @setterproperty
        def B(self, value):
            return value

    a = A()
    assert a.B == None
    a.B = 1
    assert a.B == 1



# Generated at 2022-06-21 22:11:30.202310
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        pass

    @setterproperty
    def test_property(tcls, value):
        return value

    tcls = TestClass()
    tcls.test_property = "blah"
    assert tcls.test_property == "blah"
    return



# Generated at 2022-06-21 22:11:35.622102
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """ Unit test for function lazyclassproperty """
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return "value"

    class B(A):
        pass

    assert A.prop == "value"
    assert B.prop == "value"
    A.prop = "other value"
    assert A.prop == "other value"
    assert B.prop == "value"



# Generated at 2022-06-21 22:11:38.830599
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class LazyClass(object):
        @lazyclassproperty
        def val(cls):
            return 'value'

    assert LazyClass.val == 'value'
    assert LazyClass.val == 'value'
    LazyClass.val = 'new value'
    assert LazyClass.val == 'new value'



# Generated at 2022-06-21 22:11:57.538236
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def test(cls):
            return cls

    a = A()
    assert a.test == A
    assert A.test == A



# Generated at 2022-06-21 22:12:05.986802
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    单元测试, 测试懒加载属性是否正确加载.
    """
    class Foo:
        _value = None

        @lazyclassproperty
        def foo(cls):
            if not cls._value:
                cls._value = 'value'
            return cls._value

    foo_obj = Foo()

    # 是否懒加载, 即是否为None
    assert not foo_obj._value

    # 此时应该加载
    assert foo_obj.foo == foo_obj.__class__.foo

    # 加载后, 确认其

# Generated at 2022-06-21 22:12:12.634436
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        @setterproperty
        def setter_prop(self):
            return self._setter_prop

        @setter_prop.setter
        def setter_prop(self, val):
            self._setter_prop = val


    a = A()
    assert a.setter_prop is None

    a.setter_prop = 'test'
    assert a.setter_prop == 'test'


# Generated at 2022-06-21 22:12:18.054557
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 4

    assert(Foo.bar == 4)
    assert(Foo._lazy_bar == 4)

    class FooFoo(Foo):
        pass

    assert(FooFoo.bar == 4)
    assert(FooFoo._lazy_bar == 4)



# Generated at 2022-06-21 22:12:19.759149
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    def f(cls):
        print(cls.x)

    r = roclassproperty(f)
    r.__get__(None, object)



# Generated at 2022-06-21 22:12:26.155959
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'A'

        @lazyperclassproperty
        def list_instances(cls):
            return []

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return 'B'

    class C(A):
        @lazyperclassproperty
        def list_instances(cls):
            return []

        @lazyperclassproperty
        def foo(cls):
            return 'C'

    a = A()
    b = B()
    c = C()

    assert a.foo == 'A'
    assert b.foo == 'B'
    assert c.foo == 'C'

    assert a.list_instances == []
    assert b.list_inst

# Generated at 2022-06-21 22:12:37.312471
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self._x = None
            self._y = None
            self._z = None
            self._a = None
            self._b = None
            self._c = None
        @setterproperty
        def x(self, value):
            self._x = value
        @setterproperty
        def y(self, value):
            self._y = value
        @setterproperty
        def z(self, value):
            self._z = value
        @setterproperty
        def a(self, value):
            self._a = value
            return self._a
        @setterproperty
        def b(self, value):
            self._b = value
            return self._b
        @setterproperty
        def c(self, value):
            self._c

# Generated at 2022-06-21 22:12:42.714184
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C1(object):
        # A setter, with the setter argument passed as keyword
        @setterproperty
        def x(self, value):
            self._x = value

        # A setter without keyword argument
        @setterproperty
        def y(self, value):
            self._y = value

    c = C1()
    c.x = 41
    assert c._x == 41
    c.y = 42
    assert c._y == 42


# Generated at 2022-06-21 22:12:47.765327
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self._value = 5

        @roclassproperty
        def value(cls):
            return cls._value

    t = Test()
    assert t.value == Test.value
    t.value = 10
    assert t.value == Test.value == 5

# Generated at 2022-06-21 22:12:50.124686
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def name(cls):
            return cls.__name__

    assert A.name == "A"



# Generated at 2022-06-21 22:13:33.235430
# Unit test for constructor of class setterproperty
def test_setterproperty():
    c = 1
    d = 2
    class G(object):
        def __init__(self, a, b):
            self.c = b
            self.d = a

    g1 = G(c, d)
    g2 = G(d, c)

# Generated at 2022-06-21 22:13:38.243940
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def val(cls):
            return id(cls)

    a = A()
    aa = A()
    assert a.val != aa.val, 'Same id for different instances'
    assert a.val == A.val, 'Different ids for different instances and class'

    class B(A):
        pass

    b = B()
    assert b.val != A.val, 'Same id for descendants and ancestor'
    assert b.val == B.val, 'Different ids for same classes'



# Generated at 2022-06-21 22:13:41.393088
# Unit test for constructor of class setterproperty
def test_setterproperty():

    # Test class
    class A:

        @setterproperty
        def prop(self, value):
            return value + 1

    a = A()
    assert a.prop == 1

# Generated at 2022-06-21 22:13:50.380463
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.__prop_val = 0

        @setterproperty
        def prop(self, value):
            self.__prop_val = value


    foo = Foo()
    assert foo.__prop_val == 0

    foo.prop = 10

    assert foo.__prop_val == 10



# Generated at 2022-06-21 22:14:02.552431
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:14:13.349011
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def bar(cls):
            return 'Foo'

        baz = roclassproperty(bar)

    class Qux(Foo):
        def bar(cls):
            return 'Qux'

    assert Foo.baz == 'Foo'
    assert Qux.baz == 'Qux'

    try:
        Foo.baz = 1
        # FAIL
        assert False, "Should not be able to assign to a read-only property"
    except:
        pass

    try:
        Qux.baz = 1
        # FAIL
        assert False, "Should not be able to assign to a read-only property"
    except:
        pass



# Generated at 2022-06-21 22:14:16.394591
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object): pass
    class B(A): pass
    def f():
        return 1
    B.x = roclassproperty(f)
    assert A.x == 1



# Generated at 2022-06-21 22:14:23.251983
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        prop = roclassproperty(lambda cls: cls.value)

        def __init__(self, value):
            self.value = value
            self.prop = value

    assert Test.prop == 1
    assert Test(1).prop == 1

    # test with arguments
    class Test(object):
        prop = roclassproperty(lambda cls, p: (cls.value, p))

        def __init__(self, value):
            self.value = value
            self.prop = value

    assert Test.prop(1) == (1, 1)
    assert Test(1).prop(1) == (1, 1)


# Generated at 2022-06-21 22:14:30.412989
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    Raises:
        AssertionError: Method tests_setterproperty___set__() of class TestClass has failed
    """
    class TestClass(object):
        @setterproperty
        def test(self, value):
            self.value = value
    obj = TestClass()
    obj.test = 1
    assert obj.value == 1, "Method test_setterproperty___set__() of class TestClass has failed"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:14:38.914131
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class test:
        i = 1
        def __init__(self):
            self.i = 0

        def set_i(self, value):
            self.i = value

        i_ = setterproperty(set_i)

    x = test()
    y = test()
    assert(x.i == 0)
    assert(y.i == 0)
    x.i_ = 1
    assert(x.i == 1)
    assert(y.i == 0)
    y.i_ = 2
    assert(x.i == 1)
    assert(y.i == 2)



# Generated at 2022-06-21 22:15:53.263053
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self.x = None

        def sp_func(self, value):
            self.x = value + '_sp'

        @setterproperty
        def sp(self):
            return self.x

        def sp_getter(self):
            return self.x + '_sp_getter'

        @setterproperty
        def sp_getter_sp(self):
            return self.sp_getter

        @property
        def sp_getter_p(self):
            return self.x + '_sp_getter_p'

        @setterproperty
        def sp_getter_sp_getter_p(self):
            return self.sp_getter_p

    c = C()
    c.sp = "_sp"

# Generated at 2022-06-21 22:16:04.089225
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        '''
        I'm just a class used for testing the lazyperclassproperty decorator
        '''
        def __init__(self, id):
            self.id = id

        @lazyperclassproperty
        def a(cls):
            return A(cls.__name__)

        @classmethod
        def to_str(cls):
            return "Class " + cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.a.id == 'A'
    assert A.a.to_str() == 'Class A'
    assert A().a.id == 'A'
    assert A().a.to_str() == 'Class A'

    assert B.a.id == 'B'
    assert B.a

# Generated at 2022-06-21 22:16:06.973144
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class a(object):
        @roclassproperty
        def foo(cls):
            return cls.__name__

    class b(a):
        pass

    assert a.foo == "a"
    assert b.foo == "b"



# Generated at 2022-06-21 22:16:13.069935
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Setterproperty class method __set__
    """
    class M(object):
        def __init__(self):
            self.foo = -1
        @setterproperty
        def foo(self, value):
            self.foo = value
    m = M()
    m.foo = 0
    if m.foo != 0:
        raise ValueError("m.foo != 0")
    m.foo = 10
    if m.foo != 10:
        raise ValueError("m.foo != 10")
    print("OK")


# Generated at 2022-06-21 22:16:18.095293
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 42
    assert A().foo == 42
    assert A.foo == 42

    class B(A):
        @lazyperclassproperty
        def bar(cls):
            return 23
    assert B().foo == 42
    assert B.foo == 42
    assert B().bar == 23
    assert B.bar == 23

# Generated at 2022-06-21 22:16:22.545771
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        _x = 1

        @roclassproperty
        def x(cls):
            return cls._x

    assert(C.x == 1)
    with raises(AttributeError):
        C.x = 2

    c = C()
    assert(c.x == 1)
    with raises(AttributeError):
        c.x = 2



# Generated at 2022-06-21 22:16:31.434454
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def doit(cls):
            return cls.__name__

    a = A()

    assert not hasattr(a, 'doit')
    assert not hasattr(a, '_lazy_doit')
    assert not hasattr(A, 'doit')
    assert not hasattr(A, '_lazy_doit')
    assert A.doit == 'A'
    assert A._lazy_doit == 'A'
    assert a.__class__.doit == 'A'
    assert a.doit == 'A'
    assert a.__class__._lazy_doit == 'A'
    assert not hasattr(a, 'doit')
    assert hasattr(a, '_lazy_doit')



# Generated at 2022-06-21 22:16:39.956177
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.__dict__["x"] = 0

        @setterproperty
        def x(self, x):
            return int(x)

    a = A()
    a.x = 1
    assert a.x == 1
    assert type(a.x) == int
    a.x = "1"
    assert a.x == 1
    assert type(a.x) == int
    a.x = 1.1
    assert a.x == 1
    assert type(a.x) == int
    a.x = "1.1"
    assert a.x == 1
    assert type(a.x) == int

if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-21 22:16:43.271704
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        def f(cls): return 'f'

        g = roclassproperty(f)

    assert A.g == 'f'  # Test 0: Gets the function.
    assert A().g == 'f'  # Test 1: Gets the function.


# Generated at 2022-06-21 22:16:46.451810
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def x(cls):
        return 1

    class A(object):
        pass

    assert A.x == 1

    A.__dict__['x'] = 2

    assert A.x == 2

    del A.x

    assert A.x == 1

