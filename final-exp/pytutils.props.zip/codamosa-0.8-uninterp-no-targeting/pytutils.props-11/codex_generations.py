

# Generated at 2022-06-21 22:07:47.690072
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test():
        @setterproperty
        def prop(self, val):
            self.test = val

    test = Test()
    test.prop = 10
    assert test.test == 10



# Generated at 2022-06-21 22:07:55.984913
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Bar(object):
        def __init__(self):
            self._s = None

        def set_s(self, s):
            self._s = s

        s = setterproperty(set_s)

    bar = Bar()
    assert_is_none(bar._s)
    bar.s = 'foo'
    assert_equal(bar._s, 'foo')

    # Regression test for https://github.com/pydata/pandas/issues/8055
    # Make sure functools.wraps doesn't mess up the property wrapper
    class Baz(object):
        def __init__(self):
            self._s = None

        @wraps(set_s)
        def set_s(self, s):
            self._s = s

        s = setterproperty(set_s)



# Generated at 2022-06-21 22:08:06.289502
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):
        @lazyclassproperty
        def classprop_lazy(cls):
            """ Lazy/Cached class property. """
            print("BEGIN classprop_lazy")
            count = 1
            for i in range(2,10):
                count *= i
            print("END classprop_lazy")
            return count

    print(MyClass.classprop_lazy)
    print(MyClass.classprop_lazy)
    print(MyClass.classprop_lazy)

    class MyClass2(MyClass):
        pass

    print(MyClass2.classprop_lazy)
    print(MyClass2.classprop_lazy)

    class MyClass3(MyClass2):
        pass

    print(MyClass3.classprop_lazy)

# Generated at 2022-06-21 22:08:13.283941
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Base(object):
        @lazyclassproperty
        def x(cls):
            print('called')
            return 'x'

    assert Base.x == 'x'
    assert Base.x == 'x'

    class Derived(Base):
        pass

    assert Base.x == 'x'
    assert Derived.x == 'x'


# Generated at 2022-06-21 22:08:17.987851
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            self._value = value

    c = C(1)
    c.value = 2
    assert c._value == 2


# Generated at 2022-06-21 22:08:27.584040
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self,x):
            print('property x is being set to:',x)
            # when setterproperty is used to define setter for property x, the setter is called during initialization,
            # so self._x is None. The following causes error:
            # [in]self._x = x
            # AttributeError: 'Test' object has no attribute '_x'
            # to avoid this error, need to assign the variable inside the setter property
            # [out]self._x = x
        @property
        def x(self):
            return self._x
    t = Test()

# Generated at 2022-06-21 22:08:31.278920
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test_func(cls):
            return "a"

    class B(A):
        @lazyclassproperty
        def test_func(cls):
            return "b"

    assert A.test_func == "a"
    assert B.test_func == "b"



# Generated at 2022-06-21 22:08:42.251332
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    attr_name = '_MyClass_lazy_mylazy'

    class MyClass(object):
        @lazyperclassproperty
        def mylazy(cls):
            return 'mylazy'

    class MySubClass(MyClass):
        pass

    # Check for creation of fields for this class and it's parent class
    assert not hasattr(MyClass, attr_name)
    assert not hasattr(MySubClass, attr_name)
    MyClass.mylazy  # Call the lazyperclassproperty
    MySubClass.mylazy  # Call the lazyperclassproperty
    assert hasattr(MyClass, attr_name)
    assert hasattr(MySubClass, attr_name)
    assert MyClass.mylazy == 'mylazy'
    assert MySubClass.mylazy

# Generated at 2022-06-21 22:08:48.278170
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.attribute = 0

        @setterproperty
        def setter(self, value):
            self.attribute = value

    obj = A()
    obj.setter = 10
    assert obj.attribute == 10



# Generated at 2022-06-21 22:08:55.480799
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self):
            self._value = 0

    class B(A):
        @roclassproperty
        def value(cls):
            return cls._value

    a = A()
    b = B()
    assert a.value == 0
    assert a.value == b.value

    a._value = 2
    assert a.value == 2
    assert a.value == b.value

    b._value = 3
    assert b.value == 3
    assert a.value == 2
    assert b.value != a.value

# Generated at 2022-06-21 22:09:06.906424
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Colour(object):
        """
        A simple RGB colour object.
        """

        def __init__(self, red, green, blue):
            self.red = red
            self.green = green
            self.blue = blue

        def _set_colour(self, value):
            if len(value) == 3:
                self.red, self.green, self.blue = value
            else:
                raise ValueError('Invalid value for RGB colour')

        colour = setterproperty(_set_colour, doc="Retrieve or set colour as an RGB 3-tuple")

    c = Colour(1, 3, 5)
    assert c.colour == (1, 3, 5)
    c.colour = (1, 2, 3)
    assert c.colour == (1, 2, 3)



# Generated at 2022-06-21 22:09:10.022056
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test:
        @roclassproperty
        def x(cls):
            return "test_roclassproperty"

    assert Test.x == "test_roclassproperty"


# Generated at 2022-06-21 22:09:13.922354
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:09:18.825597
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self,value):
            """I'm the 'x' property."""
            self._x=value
    obj = C()

# Generated at 2022-06-21 22:09:26.484842
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """__get__ for read-only class property"""
    class A(object):
        @roclassproperty
        def roclassproperty(cls):
            return 'roclassproperty'

    assert A().roclassproperty == 'roclassproperty'
    assert A.roclassproperty == 'roclassproperty'
    assert A.__dict__['roclassproperty'].__get__(A, A) == 'roclassproperty'
    with pytest.raises(RuntimeError):
        A.__dict__['roclassproperty'].__set__(A, 'roclassproperty')
    with pytest.raises(RuntimeError):
        A.roclassproperty = 'roclassproperty'



# Generated at 2022-06-21 22:09:29.106816
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self):
            self.a = 0

        @setterproperty
        def A(self, value):
            self.a = value

    t = Test()
    t.A = 32
    assert t.a == 32

# Generated at 2022-06-21 22:09:32.967471
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # import doctest
    # doctest.testmod(extraglobs={'setterproperty': setterproperty})

    class A(object):
        @setterproperty
        def d(self, value):
            print('setting d...')
            self.__dict__['d'] = value

        @d.setter
        def d(self, value):
            print('changing d...')
            self.__dict__['d'] = value

    a = A()
    a.d = 2
    print(a.d)



# Generated at 2022-06-21 22:09:38.893480
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self, value=None, data=None):
            self.value = value
            self.data = data

    class B(A):
        def __init__(self, value=None, data=None):
            super(B, self).__init__(value=value, data=data)
            self.other_data = None

        @setterproperty
        def data(self, new):
            self.other_data = new

    a = A(value=1, data=2)
    b = B(value=1, data=2)

    assert a.value == 1
    assert a.data == 2

    assert b.value == 1
    assert callable(b.data) is False
    assert b.data == 2
    assert b.other_data is None

    b.data

# Generated at 2022-06-21 22:09:41.256132
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            self._value = value

        @value.getter
        def value(self):
            return self._value

    aa = TestSetterProperty("6")
    assert aa.value == "6"



# Generated at 2022-06-21 22:09:43.473968
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            print("SETTING X")
            self._x = value

        @property
        def x(self):
            return self._x

    foo = Foo("X")
    foo.x = "Y"
    assert foo.x == "Y"

# Generated at 2022-06-21 22:09:52.617560
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from poly import poly
    from poly import polylog

    class poly_mod(poly):
        def __init__(self, coeff):
            poly.__init__(self, coeff)

        y = setterproperty(poly.__setitem__)

    p = poly_mod([1, 2])
    p.y[1] = 2
    assert p.coeff == [1, 2]



# Generated at 2022-06-21 22:09:58.544874
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def a(self, value):
            self._a = value

    assert hasattr(C.a, '__doc__')
    assert C.a.__doc__ is None

    c = C()
    assert c._a == c.a == None
    c.a = 'hello'
    assert c._a == c.a == 'hello'



# Generated at 2022-06-21 22:10:04.484119
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
        @classproperty
        def x(cls):
            return cls.__name__
    a = A(x='foobar')
    assert a.x == 'A'
    assert a.__class__.x == 'A'


# Generated at 2022-06-21 22:10:08.739899
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        @setterproperty
        def x(this, val):
            if val == 0:
                raise ValueError("x = 0 not allowed")
            this.__x = val

    a = A()
    a.x = 3
    a.x = 0

if __name__ == "__main__":
    test_setterproperty___set__()

# Generated at 2022-06-21 22:10:15.738956
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Dummy:
        @roclassproperty
        def test_roclassproperty___get__(cls):
            return cls
    Dummy()  # class <test_roclassproperty___get__.<locals>.Dummy>
    Dummy.test_roclassproperty___get__  # <function test_roclassproperty___get__.<locals>.Dummy.test_roclassproperty___get__ at 0x104d32f28>
    Dummy.test_roclassproperty___get__()  # <class '__main__.test_roclassproperty___get__.<locals>.Dummy'>



# Generated at 2022-06-21 22:10:21.274133
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):
        def __init__(self, value=None):
            self._value = value
            pass


# Generated at 2022-06-21 22:10:23.391532
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def name(cls):
            return cls.__name__
    assert A.name == "A"


# Generated at 2022-06-21 22:10:25.888278
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def value(cls):
            return 'value'

    assert C.value == 'value'
    assert C().value == 'value'


# Generated at 2022-06-21 22:10:28.081751
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def x(cls):
            return cls.__name__

    assert A.x == A.__name__ == 'A'
    assert A().x == A.x == 'A'
    assert type(A.x) == str
    
    


# Generated at 2022-06-21 22:10:31.450409
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestGet(object):
        @roclassproperty
        def test(self):
            return 1

    t = TestGet()
    assert t.test == 1

# Generated at 2022-06-21 22:10:47.744145
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def myclassprop(cls):
            return cls.__name__

    class B(A):
        pass

    assert not hasattr(A, '_A_lazy_myclassprop')
    assert B.myclassprop == 'B'
    assert A.myclassprop == 'A'
    assert hasattr(A, '_A_lazy_myclassprop')
    assert hasattr(B, '_B_lazy_myclassprop')
    assert B._B_lazy_myclassprop == 'B'
    assert A._A_lazy_myclassprop == 'A'



# Generated at 2022-06-21 22:10:51.002348
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("evaluating prop")
            return 42
    A.prop
    A.prop
    assert A.prop == 42
    assert A._lazy_prop == 42
    
    class B(A):
        pass
    
    B.prop
    B.prop
    assert B.prop == 42
    assert B._lazy_prop == 42
    assert not hasattr(B, "_lazy_prop")
    assert getattr(A, "_lazy_prop") == 42
    
    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("evaluating prop")
            return 43
    C.prop
    C.prop
    assert C.prop == 43
    assert C._lazy_prop

# Generated at 2022-06-21 22:11:00.414322
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from test_helpers.test_frozendict import TestFrozenDict
    from test_helpers.test_frozendict import MyFrozenDict
    from test_helpers.test_frozendict import MyFrozenDict2

    t = TestFrozenDict()

    class Foo(object):
        x = setterproperty(MyFrozenDict, doc='doc')
        y = setterproperty(MyFrozenDict, doc='doc')

    foo = Foo()
    # Test the method __set__ of class setterproperty
    foo.x = {}
    t.assertIsInstance(foo.x, MyFrozenDict)
    foo.y = foo.x
    t.assertIsInstance(foo.y, MyFrozenDict)

# Generated at 2022-06-21 22:11:06.444501
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class lazy(object):
        @lazyclassproperty
        def foo(cls):
            return [1, 2, 3]

    assert lazy.foo is lazy.foo
    assert lazy.foo is not lazy().foo

    class lazy_child(lazy):
        pass

    assert lazy_child.foo is lazy_child.foo
    assert lazy_child.foo is not lazy().foo
    assert lazy_child.foo is not lazy_child().foo



# Generated at 2022-06-21 22:11:09.924430
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # __get__
    class A(object):
        def f(cls):
            pass
        p = roclassproperty(f)

    a = A()
    assert a.p == A.f

# Generated at 2022-06-21 22:11:14.225508
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:11:20.842675
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test(object):
        def __init__(self):
            self.__name = 'test'

        @setterproperty
        def name(self, value):
            self.__name = value

        @property
        def name(self):
            return self.__name

    t = test()
    print('name:', t.name)

    t.name = "test2"
    print('name:', t.name)


# TODO: implement tests
if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-21 22:11:24.085538
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return True

    assert Foo.bar == True



# Generated at 2022-06-21 22:11:27.080791
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class cls(object):
        attr = roclassproperty(lambda cls: 'value')

    assert cls.attr == 'value'
    with pytest.raises(AttributeError):
        cls.attr = 'other'



# Generated at 2022-06-21 22:11:33.081420
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X(object):
        @lazyperclassproperty
        def f(cls):
            print('return value')
            return 'value'

    class Y(X):
        pass

    assert X.f == 'value'
    assert Y.f == 'value'

# Generated at 2022-06-21 22:11:55.211601
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value
            return self._x

    assert (A().x == None)
    # consider this method of class A as an atomic transaction
    A().x = 1
    assert (A().x == 1)



# Generated at 2022-06-21 22:11:58.991154
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        value = setterproperty(lambda x, v: setattr(x, '_value', v))

    a = A()
    assert not hasattr(a, '_value')
    a.value = 42
    assert hasattr(a, '_value')
    assert a._value == 42

# Generated at 2022-06-21 22:12:07.263453
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class foo(object):

        @lazyclassproperty
        def bar(cls):
            print('one time')
            return 1

    class bar(foo):
        pass

    class foobar(foo):
        pass

    assert foo.bar == 1
    assert foo.bar == 1
    assert foo.bar == 1

    assert bar.bar == 1
    assert bar.bar == 1
    assert bar.bar == 1

    assert foobar.bar == 1
    assert foobar.bar == 1
    assert foobar.bar == 1

    foo.bar = 2
    bar.bar = 2
    foobar.bar = 2
    assert foo.bar == 2
    assert bar.bar == 2
    assert foobar.bar == 2

    assert foo.bar == 2
    assert bar.bar == 2

# Generated at 2022-06-21 22:12:14.008033
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return 1

    class Sub1(Base):
        pass

    class Sub2(Base):
        pass

    class Test(unittest.TestCase):
        def test(self):
            assert Sub1.prop == 1
            assert Sub2.prop == 1
            Sub1.prop = 2
            assert Sub1.prop == 2
            assert Sub2.prop == 1

    unittest.main()


# Generated at 2022-06-21 22:12:18.315402
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class obj(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, value):
            self.__dict__['x'] = value

    p = obj()
    p.x = 1
    assert p.x == 1


# Generated at 2022-06-21 22:12:20.716997
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self, a):
            self.a = a

        @setterproperty
        def a(self, a):
            return a

    a = A(1)
    assert a.a == 1
    a.a = 2
    assert a.a == 2

# Generated at 2022-06-21 22:12:24.320730
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class testclass(object):
        @roclassproperty
        def class_property():
            return 10

    assert testclass.class_property == 10

# Generated at 2022-06-21 22:12:33.814589
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def test_set1(self, value):
        super(Test, self).test1 = value

    def test_set2(self, value):
        super(Test, self).test2 = value

    class Test(object):
        test1 = setterproperty(test_set1)
        test2 = setterproperty(test_set2, "test2")

    obj = Test()
    obj.test1 = "a"
    obj.test2 = "b"
    print(obj.test1)
    print(obj.test2)
    print(obj.__doc__)


if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-21 22:12:37.916260
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test:

        @lazyclassproperty
        def __name__(cls):
            return cls.__name__

    assert Test.__name__ == 'Test'

    class Test2(Test):
        pass

    assert Test2.__name__ == 'Test2'


# Generated at 2022-06-21 22:12:41.508397
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetter(object):
        def __init__(self):
            self.a = 1

        @setterproperty
        def a(self, value):
            self._a = value

    t = TestSetter()
    assert t._a == 1

    t.a = 10
    assert t._a == 10



# Generated at 2022-06-21 22:13:20.675708
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class roclassproperty___get__(object):
        def __init__(self):
            self.a = 1

        @classproperty
        def test_roclassproperty___get__(cls):
            return "test_roclassproperty___get__"

        @roclassproperty
        def test_roclassproperty___get___roclassproperty(cls):
            return "test_roclassproperty___get___roclassproperty"

    a = roclassproperty___get__()
    assert(a.test_roclassproperty___get__ == "test_roclassproperty___get__")
    assert(a.test_roclassproperty___get___roclassproperty == "test_roclassproperty___get___roclassproperty")
    assert(isinstance(a.test_roclassproperty___get__, roclassproperty))

# Generated at 2022-06-21 22:13:31.494297
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    def f_get(obj, owner):
        return 42

    # Create the roclassproperty object
    obj = roclassproperty(f_get)

    # Try with object as first argument
    assert 42 == obj.__get__(None, None)
    assert 42 == obj.__get__(None, type)

    # Try with type as first argument
    assert 42 == obj.__get__(None)
    assert 42 == obj.__get__(type)

    # Check that the result has the expected type
    assert isinstance(obj.__get__(None), type(42))
    assert isinstance(obj.__get__(type), type(42))

# Generated at 2022-06-21 22:13:43.186666
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Data(object):
        def __init__(self, name, x, y, z=10):
            self.name = name
            self.x = x
            self.y = y
            self.z = z

        def get_name(self):
            return self.name

    class Action(object):
        def __init__(self, func):
            self.func = func

        def __call__(self, *args):
            return self.func(*args)

    class TestClass(object):
        _data_map = roclassproperty(lambda cls: {
            'name': Data('name', 1, 2),
            'email': Data('email', 3, 4),
            'address': Data('address', 5, 6, z=11)})


# Generated at 2022-06-21 22:13:47.393666
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    This method tests the __set__ function and the fact that it
    calls the function passed to the setterproperty class.
    """
    called = []
    class SetterTester:
        def __init__(self):
            self.some_attr = 0

        @setterproperty
        def some_attr(self, value):
            called.append(value)

    some_object = SetterTester()
    some_object.some_attr = 1
    assert called[0] == 1

    called = []
    some_object.some_attr = 3
    assert called[0] == 3

# Generated at 2022-06-21 22:13:53.882521
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def _getter(self):
        return self.__class__.name

    def _setter(self, name):
        self.__class__.name = name

    class A(object):
        name = 'test'

        get_name = lazyclassproperty(_getter)
        set_name = setterproperty(_setter)

    assert A.name == A.get_name == 'test'
    A.set_name = 'Testing'
    assert A.get_name == 'Testing'



# Generated at 2022-06-21 22:14:02.464826
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value

        @x.getter
        def x(self):
            return self._x

    a = MyClass()

    assert a.x is None
    a.x = 'hello'
    assert a.x == 'hello'
    # Nothing should have been changed here
    assert a.__dict__ == {'_x': 'hello'}



# Generated at 2022-06-21 22:14:06.048846
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def name(cls):
            return 'foo'

    assert Foo.name == 'foo'


# Generated at 2022-06-21 22:14:10.852810
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    assert A.foo == 'bar'
    assert B.foo == 'bar'



# Generated at 2022-06-21 22:14:13.030263
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        i = roclassproperty(lambda cls: cls.j * 3)
        j = 5
    assert C.i == 15



# Generated at 2022-06-21 22:14:16.682240
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def classmethod(cls):
            return "I'm a classmethod!"

    assert C.classmethod == "I'm a classmethod!"
    assert C().classmethod == "I'm a classmethod!"



# Generated at 2022-06-21 22:15:30.064758
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def x(cls):
            return cls.__name__

    assert A.x == 'A'



# Generated at 2022-06-21 22:15:33.042472
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self, num):
            self.num = num

        def get_num(self):
            return self.num

        @setterproperty
        def num(self, num):
            self.num = num

    a = A(5)
    print("Intial value", a.get_num())
    a.num = 10
    print("Set value", a.get_num())



# Generated at 2022-06-21 22:15:39.159120
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class roclassproperty_test(object):
        @roclassproperty
        def test_value(cls):
            """
            This is class property, read-only
            """
            return "Testing class property"

        def get_test_value(self):
            """
            This method will return class property
            """
            return self.test_value

    assert roclassproperty_test.test_value == "Testing class property"
    assert roclassproperty_test().get_test_value() == "Testing class property"



# Generated at 2022-06-21 22:15:44.423724
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def f(cls):
            return cls.__name__

    assert not hasattr(A, '_A_lazy_f')
    x = A()
    assert x.f == 'A'
    assert A._A_lazy_f == 'A'

    class B(A):
        pass

    assert not hasattr(B, '_B_lazy_f')
    y = B()
    assert y.f == 'B'
    assert B._B_lazy_f == 'B'
    assert A._A_lazy_f == 'A'



# Generated at 2022-06-21 22:15:50.477617
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def my_handle(self, value):
            self.my_handle_value = value

        @my_handle.setter
        def my_handle(self, value):
            self.my_handle_value = 'another_value'

    f = Foo()
    f.my_handle = '123'
    assert f.my_handle_value == 'another_value'



# Generated at 2022-06-21 22:15:53.425360
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        class _bar(object):
            pass

        def __init__(self):
            self.bar = self._bar()

        @setterproperty
        def bar(self, value):
            self._bar = value

    foo = Foo()
    foo.bar = "test"
    assert foo.bar == "test"



# Generated at 2022-06-21 22:15:57.446937
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        myproperty = roclassproperty(lambda cls: 'just a string')

    assert C.myproperty == 'just a string'
    assert C().myproperty == 'just a string'



# Generated at 2022-06-21 22:16:02.870719
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def method(self):
            return self

        @roclassproperty
        def prop(cls):
            return cls.method(object())

    a = A()
    assert a == a.prop
    with pytest.raises(AttributeError) as excinfo:
        a.prop = 1
    assert "can't set attribute" in str(excinfo.value)



# Generated at 2022-06-21 22:16:06.423589
# Unit test for constructor of class setterproperty

# Generated at 2022-06-21 22:16:14.795263
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class BaseClass():
        pass

    class DerivedClass(BaseClass):
        pass

    @lazyperclassproperty
    def test_prop(cls):
        return 'test_prop_value'

    @lazyperclassproperty
    def derived_test_prop(cls):
        return 'derived_test_prop_value'

    derived_class = DerivedClass()
    assert BaseClass.test_prop == 'test_prop_value'
    assert derived_class.derived_test_prop == 'derived_test_prop_value'
    assert DerivedClass.derived_test_prop == 'derived_test_prop_value'
    assert BaseClass.test_prop == 'test_prop_value'
    assert BaseClass.derived_test_prop == 'derived_test_prop_value'
    assert derived_class.test_