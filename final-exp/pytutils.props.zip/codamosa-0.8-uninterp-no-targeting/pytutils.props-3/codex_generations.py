

# Generated at 2022-06-21 22:07:50.151408
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        __prop = 100

        def set_call(self, value):
            print("set_call")
            self.__prop = value

        @setterproperty
        def my_prop(self, value):
            print("prop_set")
            self.set_call(value)

    f = Foo()
    print(f.__prop)
    f.my_prop = 1
    print(f.__prop)


if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-21 22:07:56.040887
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class A(object):
        __slots__ = '__weakref__',
        _x = 0

        @setterproperty
        def x(self, value):
            self._x = value

    a = A()
    assert a._x == 0
    assert a.x == 0
    a.x = 1
    assert a._x == 1
    assert a.x == 1



# Generated at 2022-06-21 22:07:58.942068
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        prop = roclassproperty(lambda cls: cls)

    assert Test.prop == Test
    assert Test().prop == Test
    assert Test().prop == Test



# Generated at 2022-06-21 22:08:02.023226
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test1(object):
        @roclassproperty
        def name(cls):
            return cls.__name__

    assert Test1.name == 'Test1'



# Generated at 2022-06-21 22:08:07.670006
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def get_x(self):
            return self.__x
        def set_x(self, value):
            self.__x = value
        x = setterproperty(get_x, set_x)

    a = A()
    assert_equal(a.x, None)
    a.x = 1
    assert_equal(a.x, 1)


# Generated at 2022-06-21 22:08:13.339944
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def setter_function(self, value):
            print("value set")
            self.data = value
        a_property = setterproperty(setter_function)

    t = Test()
    t.a_property = 'set value'
    assert t.data == 'set value'


# Generated at 2022-06-21 22:08:20.020241
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A:

        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(B):
        pass

    try:
        assert A.foo == 'A'
        assert B.foo == 'B'
        assert C.foo == 'C'
    except AssertionError:
        print('AssertionError: lazyperclassproperty failed')



# Generated at 2022-06-21 22:08:23.528061
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def x(cls):
            return cls.__name__
    assert A.x == 'A'
    assert A().x == 'A'

# Generated at 2022-06-21 22:08:26.822455
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test the return of method __get__ of class roclassproperty
    class Test(object):
        @roclassproperty
        def test(cls):
            return cls
    assert Test.test == Test



# Generated at 2022-06-21 22:08:33.780881
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def __init__(self):
            self.x = 1

        @roclassproperty
        def y(foo_class):
            return foo_class.z * foo_class.x

        @roclassproperty
        def z(foo_class):
            return foo_class.x + 1
    f = Foo()
    assert f.y == 3
    assert f.z == 2
    f.x = 3
    assert f.y == 6
    assert f.z == 2
    # Test lazy class property
    class A(object):
        attr = lazyclassproperty(lambda c: c.x)
        x = 1
    assert A.attr == 1
    A.x = 2
    assert A.attr == 2

test_roclassproperty___get__()
del test_roclassproperty___get

# Generated at 2022-06-21 22:08:43.945215
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # Test 1
    class TestClass(object):
        @roclassproperty
        def test_property(cls):
            return "hello world"
    t = TestClass()
    assert t.test_property == t.test_property
    assert t.test_property == TestClass.test_property
    assert TestClass.test_property == t.test_property
    assert TestClass.test_property == TestClass.test_property

    # Test 2
    class TestClass(object):
        @roclassproperty
        def test_property(cls):
            return "hello world"
    assert TestClass.test_property == "hello world"
    assert hasattr(TestClass, '__dict__')
    assert 'test_property' in TestClass.__dict__

# Generated at 2022-06-21 22:08:52.275690
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def my_prop(cls):
            return list(range(10))

    class A(Base):
        pass

    class B(Base):
        pass

    class C(Base):
        @lazyperclassproperty
        def my_prop(cls):
            return list(range(5))

    assert A.my_prop == B.my_prop
    assert Base.my_prop is not C.my_prop
    assert C.my_prop == list(range(5))



# Generated at 2022-06-21 22:08:58.687574
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def fn(self_, value):
        self_.new_attribute = value

    class kls(object):
        _new_attribute = None

        new_attribute = setterproperty(fn)

    obj = kls()
    assert obj._new_attribute is None
    assert not hasattr(obj, 'new_attribute')
    assert obj.new_attribute is None

    obj.new_attribute = 'test'
    assert obj._new_attribute == 'test'
    assert obj.new_attribute == 'test'



# Generated at 2022-06-21 22:09:08.036321
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # This class has a lazy class property that is not evaluated until after
    # the class has been created.
    class Test:
        @lazyclassproperty
        def TEST(cls):
            print('lazyclassproperty evaluated for %s' % (cls,))
            return 'value'
    # This class causes a name conflict because it uses the same name for its
    # own property.
    class Conflict:
        TEST = 'hack'
    # This class causes the lazy property to be evaluated by referencing the
    # class property.
    class User:
        use_test = True
        use_conflict = False
        value = Test.TEST
        if use_conflict:
            # This causes the class to be created, thus initializing the
            # lazy property of Test.
            value = Conflict.TEST

# Generated at 2022-06-21 22:09:14.170541
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Parent:

        @lazyclassproperty
        def property(cls):
            return 'parent'

    class Child(Parent):

        @lazyclassproperty
        def property(cls):
            return 'child'

    class Grandchild(Child):
        pass

    # Verify the workings of the class property.
    assert Parent.property == 'parent'
    assert Child.property == 'child'
    assert Grandchild.property == 'child'



# Generated at 2022-06-21 22:09:14.932038
# Unit test for constructor of class roclassproperty

# Generated at 2022-06-21 22:09:17.522095
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C:
        def getx(cls):
            return 1
        x = roclassproperty(getx)

    assert C.x == 1


# Generated at 2022-06-21 22:09:23.013395
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:09:30.512486
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test __set__ of class setterproperty
    """
    import random
    from inspect import isclass
    from pyutils.debug_utils.debug_utils import DebugLevel
    from pyutils.debug_utils.logger import Logger
    from pyutils.singleton_utils.singleton import Singleton

    class TestClass():
        """
        Test class
        """

        def __init__(self):
            self.counter = 0

        def setter(self, value):
            self.counter += value

    class TestClass2(TestClass):
        """
        Test class 2
        """

        @setterproperty
        def prop(self):
            """
            Property
            """
            return self.counter

        @prop.setter
        def prop(self, value):
            """
            Setter
            """


# Generated at 2022-06-21 22:09:34.065866
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Example(object):
        def __init__(self, value, value2):
            self.value = value
            self.value2 = value2

        @setterproperty
        def value(self, value):
            self._value = value

    a = Example(1, 2)
    a.value = 2
    assert a._value == 2


# Generated at 2022-06-21 22:09:43.500227
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.x = 10
        @setterproperty
        def x(self, value):
            self.__x = value
        @property
        def x(self):
            return self.__x

    a = A()
    assert a.x == 10
    a.x = 20
    assert a.x == 20


# More unit tests for the above:
_pv = []


# Generated at 2022-06-21 22:09:48.628358
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def a(cls):
            return "Parent"

    class Child(Parent):
        @lazyperclassproperty
        def a(cls):
            return "Child"

    assert Parent.a == "Parent"
    assert Child.a == "Child"
    assert Parent().a == "Parent"
    assert Child().a == "Child"



# Generated at 2022-06-21 22:09:57.466704
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:10:02.905549
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return 314

    class Bar(Foo):
        pass

    assert Foo.foo == 314
    assert Bar.foo == 314
    assert Foo.foo == Bar.foo
    assert Foo.__dict__['_lazy_foo'] is Bar.__dict__['_lazy_foo']


# Generated at 2022-06-21 22:10:06.010093
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def setter(self, value):
            self.x = value

        y = setterproperty(setter)

    a = A()
    a.y = 33

    assert a.x == 33

# Generated at 2022-06-21 22:10:14.941088
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self):
            self.x = 1

        @classproperty
        def y(cls):
            return cls.x + 1

        @lazyclassproperty
        def z(cls):
            return cls.x + 1

    a = A()
    assert a.x == 1
    assert a.y == 2
    assert a.z == 2
    # Can't set class property
    try:
        a.x = 2
        a.y = 3
        a.z = 3
        raise Exception
    except AttributeError:
        pass
    # Can't set lazyclassproperty
    try:
        a.z = 3
        raise Exception
    except AttributeError:
        pass
    # Can set attribute of lazyclassproperty
    a.z.a = 3


# Generated at 2022-06-21 22:10:19.268678
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        @classmethod
        def example(cls):
            return 'roclassproperty'

    a = A()
    # Read-only property
    assert a.example == 'roclassproperty'
    with pytest.raises(AttributeError):
        a.example = 'roclassproperty'



# Generated at 2022-06-21 22:10:27.017749
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test1:
        def __init__(self):
            self.value = None

        @setterproperty
        def value(self, value):
            self.__value = value
        @value.setter
        def value(self, value):
            self.value = value
    # test case
    t1=Test1()
    t1.value = 2
    assert t1.value == 2
    # additional test case
    class Test2:
        def __init__(self):
            self.value = None

        @setterproperty
        def value(self, value):
            print(value)
            self.__value = value
        @value.setter
        def value(self, value):
            self.value = value
    t2=Test2()
    t2.value = 3

# Generated at 2022-06-21 22:10:32.835727
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def name(cls):
            return cls.__name__

        @roclassproperty
        def module(cls):
            return cls.__module__

        @roclassproperty
        def dict(cls):
            return cls.__dict__
    t = Test()
    assert t.name == 'Test'
    assert t.module == '__main__'
    assert isinstance(t.dict, dict)


# Generated at 2022-06-21 22:10:38.933267
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class C(object):

        @setterproperty
        def set_x(self, value):
            self.x = value

        @setterproperty
        def set_y(self, value):
            if value < 0:
                raise ValueError
            self.y = value

    c = C()
    c.set_x = 10
    assert c.x == 10

    c.set_y = -1
    assert_raises(ValueError, c.set_y, -1)

# Generated at 2022-06-21 22:10:53.507610
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for function lazyclassproperty
    """

# Generated at 2022-06-21 22:10:59.267399
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Simple setter test
    :return:
    """
    class C(object):
        def __init__(self):
            self.value = None

        @setterproperty
        def x(self, value):
            self.value = value

    obj = C()
    obj.x = 2
    assert 2 == obj.value
    assert 'x' in obj.__dict__
    assert 2 == obj.__dict__['x']


# Generated at 2022-06-21 22:11:09.833706
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            # We need to declare them as None so we can do the
            # following test.
            self._x = None
            self._y = None

        @setterproperty
        def x(self, x):
            if x > 0:
                self._x = x
            else:
                raise ValueError

        @setterproperty
        def y(self, y):
            if y > 0:
                self._y = y
            else:
                raise ValueError

    # First check that the setterproperties work
    f = Foo()
    f.x = 1
    assert f.x == 1
    f.y = 2
    assert f.y == 2

    # Now check that we raise an exception if the value is not > 0
    f = Foo()
    f

# Generated at 2022-06-21 22:11:13.824517
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def prop(cls):
            return '123'

        @classmethod
        def clsmethod(cls):
            return 'abc'

    assert A.prop == '123'
    assert A.clsmethod() == 'abc'
    assert A().prop == '123'



# Generated at 2022-06-21 22:11:16.646064
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self):
            self.ro = roclassproperty(lambda cls: 42)

        def get_ro(self):
            return self.ro

    assert A().get_ro() == 42
    assert A.ro == 42

# Generated at 2022-06-21 22:11:24.763706
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Dummy(object):

        def __init__(self):
            self._a = "123"

        @setterproperty
        def set_a(self, value):
            self._a = value

        def get_a(self):
            return self._a

    dummy = Dummy()
    print(dummy.a)
    dummy.set_a = "321"
    print(dummy.get_a())


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-21 22:11:26.800792
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class Test(object):

        def _foo(self, owner):
            return owner

        foo = roclassproperty(_foo)

    t = Test()
    assert t.foo == Test

# Generated at 2022-06-21 22:11:31.947180
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def func(cls):
            return "one"

    class B(A):
        @lazyperclassproperty
        def func(cls):
            return "two"

    class C(B):
        @lazyperclassproperty
        def func(cls):
            return "three"

    assert A.func == "one"
    assert B.func == "two"
    assert C.func == "three"


# Generated at 2022-06-21 22:11:39.162960
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class Classic(object):
        def __init__(self, n):
            self._n = n

        @roclassproperty
        def n(cls):
            return cls._n

    class New(object):
        def __init__(self, n):
            self._n = n

        @roclassproperty
        def n(cls):
            return cls._n

    c = Classic(1)
    assert c.n == 1
    c.n = 2
    assert c.n == 1

    n = New(1)
    assert n.n == 1
    try:
        n.n = 2
    except AttributeError:
        pass
    assert n.n == 1



# Generated at 2022-06-21 22:11:43.217618
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class foo(object):
        def __init__(self, value):
            self.value = value

        def set_value(self,value):
            self.value = value

        value = setterproperty(set_value, 'value')

    a = foo(1)
    assert a.value == 1
    a.value = 2
    assert a.value == 2

# Generated at 2022-06-21 22:12:03.512956
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.x = None

        @setterproperty
        def setter(self, value):
            self.x = value
    a = A()
    a.setter = 1
    assert(a.x == 1)


# Generated at 2022-06-21 22:12:09.242350
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # Test class with roproperty
    class C:
        x = roclassproperty(lambda cls: 'x')
        t = roproperty(lambda cls: 0)
    assert C.x == 'x'
    assert C().t == 0
    # If the descriptor is mutable, show that it's shared
    # among instances
    C.x = ['y']
    assert C.x == ['y']
    assert C().x == ['y']
    # And if the descriptor is mutable and accessed
    # directly, the change is shared among instances
    C.x.append('z')
    assert C.x == ['y', 'z']
    assert C().x == ['y', 'z']

# Generated at 2022-06-21 22:12:13.531330
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ClassOne(object):
        @lazyperclassproperty
        def test(cls):
            return cls

    class ClassTwo(ClassOne):
        pass

    assert ClassOne.test is ClassOne
    assert ClassTwo.test is ClassTwo
    assert ClassOne.test is ClassOne



# Generated at 2022-06-21 22:12:21.756193
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class Response(object):
        def __init__(self, data=None, code=200, headers={}):
            self.data = data
            self.code = code
            self.headers = headers

        def __repr__(self):
            return "<Response [%d]>" % (self.code)

    @setterproperty
    def data(self, value):
        self._data = value

    @data.setter
    def data(self, value):
        self._data = value

    class ResponseTestCase(unittest.TestCase):
        def test_data_attribute(self):
            r = Response('test')
            self.assertEqual(r._data, 'test')

            r.data = 'test2'
            self.assertEqual(r._data, 'test2')

# Generated at 2022-06-21 22:12:27.672064
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class c1(object):
        @roclassproperty
        def x():
            return 1

        @roclassproperty
        def y(cls):
            return 2

    assert c1.x == 1
    with pytest.raises(AttributeError):
        c1.x = 2
    assert c1.y == 2
    with pytest.raises(AttributeError):
        c1.y = 2

# Generated at 2022-06-21 22:12:38.497344
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self._value = None
            self._value1 = None
            self._value2 = None

        @setterproperty
        def value(self, value):
            self._value = value

        @setterproperty
        def value1(self, value):
            self._value1 = value

        @setterproperty
        def value2(self, value):
            self._value2 = value

    t = Test()
    t.value = 5
    t.value1 = t.value * 2
    t.value2 = t.value1 * 2
    eq_(t._value, 5, t._value)
    eq_(t._value1, 10, t._value1)
    eq_(t._value2, 20, t._value2)

# Generated at 2022-06-21 22:12:45.137726
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-21 22:12:50.202027
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @staticmethod
        def fn():
            return "A"

        attr = lazyperclassproperty(fn)

    class B(A):
        @staticmethod
        def fn():
            return "B"
        attr = lazyperclassproperty(fn)

    assert A.attr == "A"
    assert B.attr == "B"



# Generated at 2022-06-21 22:12:53.266184
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class testclass(object):
        def __init__(self):
            self.val = 0
        @setterproperty
        def set_val(self, val):
            self.val = val
    t = testclass()
    assert t.val == 0
    t.set_val = 1
    assert t.val == 1

# Generated at 2022-06-21 22:12:59.001598
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def f(cls):
        return len(cls.__name__)

    class A(object):
        e = lazyperclassproperty(f)

    class B(A):
        pass

    class C(A):
        pass

    assert A.e == 1
    assert B.e == 1
    assert C.e == 1



# Generated at 2022-06-21 22:13:43.146040
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):
        def __init__(self, value):
            self._val = value

        def get_value(self):
            return self._val

        @setterproperty
        def set_value(self, value):
            self._val = value

    print("Testing setterproperty")
    test = TestSetterProperty("this is a test")

    print("object value is '%s'; correct." % test.get_value())
    print("set object value to 'changed value'.")

    test.set_value("changed value")
    if test.get_value() == "changed value":
        print("pass")
    else:
        print("fail")

if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-21 22:13:47.372269
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self, val):
            self.val = val

    class B(A):
        @setterproperty
        def setval(self, value):
            """
            Set val
            """
            self.val = value

    b = B(3)
    b.setval = 5
    assert b.val == 5

    assert isinstance(b.setval, setterproperty)
    assert isinstance(B.setval, setterproperty)
    assert B.setval.__doc__ == "Set val"
    assert B.setval.__name__ == "setval"

# Generated at 2022-06-21 22:13:54.241572
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test_lcp(object):
        @lazyclassproperty
        def test(cls):
            print('test function called')
            return 42
    assert test_lcp.test == 42
    assert test_lcp.test == 42

# Set up the method properties to be used
lazyperclassproperty = lazyperclassproperty
lazyclassproperty = lazyclassproperty
roclassproperty = roclassproperty
rproperty = rproperty


# Set up some more Pythonic names for these methods
classmethod = classmethod
staticmethod = staticmethod
property = property



# Generated at 2022-06-21 22:13:58.019625
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def fn(cls):
            return 'ro'
    a = A()
    assert a.fn == 'ro'

# Generated at 2022-06-21 22:14:00.463951
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Class(object):
        def __init__(self):
            # initial...
            self._value = 0

        @roclassproperty
        def value(self):
            """I'm the 'value' property."""

# Generated at 2022-06-21 22:14:05.717515
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def prop(cls):
            return 42
    assert A.prop==42 # no overlap
    assert A.prop is A.prop
    class B(A):
        pass
    assert B.prop==42 # no overlap
    assert B.prop is B.prop
    assert A.prop is not B.prop



# Generated at 2022-06-21 22:14:11.288409
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return 'a'

    # object of A class can't have method 'a'
    assert not hasattr(A(), 'a')
    # Class A can have method 'a'
    assert A.a == 'a'

# Generated at 2022-06-21 22:14:14.625252
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            self._x = 'foo'

        @lazyclassproperty
        def x(cls):
            print('initializing x', cls)
            return 'x_value'

        @lazyclassproperty
        def y(cls):
            print('initializing y', cls)
            return 'y_value'

    class B(A):
        pass

    a = A()
    a.x
    a.y
    b = B()
    b.x
    b.y



# Generated at 2022-06-21 22:14:20.585882
# Unit test for function lazyclassproperty

# Generated at 2022-06-21 22:14:23.314091
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test:
        @roclassproperty
        def test_property(cls):
            return 1

        @classproperty
        def test_property2(cls):
            return 1

    assert Test.test_property == 1
    assert Test.test_property2 == 1

# Generated at 2022-06-21 22:15:38.695085
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class TestClass(object):
        @lazyclassproperty
        def test_prop(cls):
            # This function is executed only once
            return 'test value'

    class TestLazyClassProperty(unittest.TestCase):
        def test_function(self):
            self.assertEqual(TestClass.test_prop, 'test value')

# Generated at 2022-06-21 22:15:41.979552
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    global roclassproperty

    # global roclassproperty
    class P(object):
        pass

    class C(P):
        @roclassproperty
        def p(cls):
            return 1

    assert C.p == 1
    assert P.p != 1
    # assert roclassproperty.__get__(C, C) == 1



# Generated at 2022-06-21 22:15:48.440334
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def tested_property(cls):
            return "Value"

    class Sub1(Base):
        pass

    class Sub2(Base):
        pass

    assert Base.tested_property == "Value"
    assert Sub1.tested_property == "Value"
    assert Sub2.tested_property == "Value"
    assert Base.tested_property is not Sub1.tested_property
    assert Base.tested_property is not Sub2.tested_property



# Generated at 2022-06-21 22:15:53.367684
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        pass

    class B(A):
        pass

    def fn(cls):
        return '%s: %s' % (cls.__name__, cls.__name__)

    @lazyclassproperty
    def bar(cls):
        return fn(cls)

    assert bar == 'A: A'  # class A
    assert B.bar == 'A: A'  # class B

    A.bar = 'Stuff!!'
    assert A.bar == 'Stuff!!'
    assert B.bar == 'A: A'

    del B.bar
    assert B.bar == 'B: B'



# Generated at 2022-06-21 22:15:57.696577
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Evaluating class property")
            return 'the property'

    class B(A):
        pass

    print(A.prop, B.prop)



# Generated at 2022-06-21 22:16:04.655392
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):

        @lazyperclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert A.x == 1
    assert B.x == 1
    assert C.x == 1
    assert D.x == 1

    A.x = 2
    assert A.x == 2
    assert B.x == 1
    assert C.x == 1
    assert D.x == 1

# Generated at 2022-06-21 22:16:07.790281
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test:
        def __init__(self):
            self.val = 0

        @setterproperty
        def val(self, value):
            self.value = value

    t = Test()
    t.val = 2
    assert t.val == 2

# Generated at 2022-06-21 22:16:12.449266
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        count = 0

        @setterproperty
        def foo(self, new_value):
            self.count = new_value

    thing = C()
    assert thing.count == 0
    thing.foo = 7
    assert thing.count == 7

    try:
        del thing.foo
    except Exception as ex:
        assert True
        return
    assert False



# Generated at 2022-06-21 22:16:16.358090
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def value(cls):
            return [1]

    class B(A):
        pass

    assert A.value == B.value
    assert A.value is not B.value
    A.value.append(2)
    assert A.value == [1, 2]
    assert B.value == [1]



# Generated at 2022-06-21 22:16:21.637951
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        a = 5

        @setterproperty
        def a(self, value):
            self._a = value

    a = A()
    assert isinstance(a, A)
    assert a.a == 5
    a.a = 10
    assert a._a == 10


if __name__ == '__main__':
    test_setterproperty___set__()