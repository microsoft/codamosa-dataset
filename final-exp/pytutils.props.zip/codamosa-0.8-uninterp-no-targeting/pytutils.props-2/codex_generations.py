

# Generated at 2022-06-21 22:07:47.149181
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):

        def __init__(self):
            self.a = 1
            self.b = roclassproperty(self.a)

    assert A().b == A().a



# Generated at 2022-06-21 22:07:51.006203
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):

        @setterproperty
        def foo(self, value):
            self._foo = 2 * value

    t = Test()

    t.foo = 3

    assert t._foo == 6 and t.__dict__ == {'_foo': 6}



# Generated at 2022-06-21 22:07:56.644804
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            print('called')
            return 'this is foo'
    assert Test.__dict__ == {}
    assert Test.foo == 'this is foo'
    assert Test.__dict__ == {'_lazy_foo': 'this is foo'}
    assert Test.foo == 'this is foo'


# Generated at 2022-06-21 22:08:00.428221
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test:

        def __init__(self):
            self.x = 1

        @setterproperty
        def x(self, v):
            self.x = v

    t = Test()
    assert t.x == 1
    t.x = 2
    assert t.x == 2

# Generated at 2022-06-21 22:08:03.986091
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        def f(cls):
            return 33
        x= roclassproperty(f)

    assert A.x == 33
    with pytest.raises(AttributeError):
        A().x


# Generated at 2022-06-21 22:08:11.342986
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def value(cls):
            return 1

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    class D(A):
        pass

    assert A.value == Base.value == B.value == 1
    assert A.value != C.value != D.value
    assert C.value == D.value


# Generated at 2022-06-21 22:08:22.508465
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    '''
    Ensure that the setter method of our descriptor class is called
    when we have a descriptor class with the __set__ method defined,
    but no __get__ method. This test is is useless, but it is here
    so that all methods get tested.
    '''

    class Junk():
        t = True
        val = 1
        value = 4

        @setterproperty
        def number(self, value, val=4):
            assert(value == 10)
            assert(self.t == 15)
            assert(self.value == 5)
            assert(val == 5)

        def __init__(self):
            self.t = 15
            self.value = 5

    j = Junk()
    j.number = 10



# Generated at 2022-06-21 22:08:26.124514
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def foo(cls):
            print("Called")
            return 42
    print("Property foo of class C:", C.foo)
    print("Property foo of class C:", C.foo)



# Generated at 2022-06-21 22:08:29.945409
# Unit test for constructor of class setterproperty
def test_setterproperty():
    @setterproperty
    def foo(self, value):
        self._foo = value

    class A(object):
        pass

    a = A()
    a.foo = 'bar'
    assert a._foo == 'bar'
    with pytest.raises(AttributeError):
        a.foo



# Generated at 2022-06-21 22:08:33.332215
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return "class"

        @roclassproperty
        def y(cls):
            return cls.__name__

        @roclassproperty
        def z(cls):
            return cls

    assert C.x == "class"
    assert C.y == "C"
    assert C.z == C



# Generated at 2022-06-21 22:08:36.620157
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'baz'

        @roclassproperty
        def bam(cls):
            return 'boo'
    assert Foo.bar == 'baz' == Foo.bam



# Generated at 2022-06-21 22:08:44.055589
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class bb(object):
        def __init__(self):
            self.inst_att = 'bb'

        @lazyperclassproperty
        def lazy_att(cls):
            return cls.__name__

    class cc(bb):
        def __init__(self):
            bb.__init__(self)
            self.inst_att = 'cc'

        @lazyperclassproperty
        def lazy_att(cls):
            return cls.__name__

    class dd(cc):
        def __init__(self):
            cc.__init__(self)
            self.inst_att = 'dd'

        @lazyperclassproperty
        def lazy_att(cls):
            return cls.__name__

    aa = bb()
    assert aa.lazy

# Generated at 2022-06-21 22:08:49.631422
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def set_value(self, value):
            self.__value = value
            return int(value)
    a = A()
    setterproperty(A.set_value).__set__(a, 10)


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-21 22:08:52.951224
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def foo(cls):
            return 'bar'

    assert C.foo == 'bar'
    c = C()
    assert c.foo == 'bar'


# Generated at 2022-06-21 22:08:55.855825
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    Test that setterproperty constructor works
    """
    @setterproperty
    def fun1(self, value):
        pass

    assert fun1.func.__name__ == "fun1"

# Generated at 2022-06-21 22:09:02.328525
# Unit test for constructor of class setterproperty
def test_setterproperty():
    '''
    Test setterproperty constructor
    '''
    class TestClass:
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            print("SET", value)
            self.__x = value

        @property
        def x(self):
            print("GET")
            return self.__x

    test_obj = TestClass()
    print(test_obj.x)
    test_obj.x = 2
    print(test_obj.x)



# Generated at 2022-06-21 22:09:11.360556
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.vari = None

        @setterproperty
        def var(self, value):
            if value > 10:
                self.vari = 10
            elif value < 0:
                self.vari = 0
            else:
                self.vari = value

        @setterproperty
        def var2(self, value):
            if value > 10:
                self.vari = 10
            elif value < 0:
                self.vari = 0
            else:
                self.vari = value

    test = A()
    test.var = 11
    test.var2 = -1
    assert test.vari == 0



# Generated at 2022-06-21 22:09:16.614889
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, x):
            """Test setter property"""
            self._x = x

    foo = Foo()
    assert foo.x is None, "foo.x is not None"
    foo.x = 2
    assert foo.x == 2, "foo.x is %d, expected 2" % foo.x



# Generated at 2022-06-21 22:09:21.744951
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self._var = None

        @setterproperty
        def var(self, value):
            if not value > 0:
                raise ValueError("value must be positive")
            self._var = value

    class B(A):
        @setterproperty
        def var(self, value):
            if not value < 0:
                raise ValueError("value must be negative")
            self._var = value

    a = A()
    b = B()

    a.var = 1
    assert a._var == 1
    b.var = -1
    assert b._var == -1
    try:
        a.var = -1
    except ValueError:
        pass
    else:
        raise AssertionError("Did not raise ValueError when setting value < 0")

# Generated at 2022-06-21 22:09:25.966584
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__
    class B(A):
        pass
    class C(B):
        pass
    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-21 22:09:32.443316
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):

        @roclassproperty
        def a(cls):
            return "Test"
        pass

    a = A()
    assert a.a == "Test"
    try:
        a.a = "Foobar"
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-21 22:09:35.125893
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return "foo"

    a = A()

    assert a.foo == "foo"
    assert A.foo == "foo"
    with pytest.raises(AttributeError):
        a.foo = "foo"

# Generated at 2022-06-21 22:09:39.768291
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Base(object):
        def __init__(self, A):
            self.a = A

        @setterproperty
        def a(self, value):
            return value

    o = Base("a")
    o.a = "b"
    assert o.a == "b"



# Generated at 2022-06-21 22:09:43.357950
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj(object):
        def __init__(self, val):
            self._val = val

        @setterproperty
        def val(self, val):
            self._val = val

    o = Obj(42)
    assert o.val == 42
    o.val = 13
    assert o.val == 13

# Generated at 2022-06-21 22:09:48.361442
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
	"""
	Tests that the setterproperty class sets the value on a given object.
	"""
	class TestClass(object):
		@setterproperty
		def test_property(self, value):
			self.test_property_value = value

	obj = TestClass()
	obj.test_property = 5
	assert obj.test_property_value == 5


# Generated at 2022-06-21 22:09:58.196045
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass

    @lazyperclassproperty
    def prop(cls):
        return id(cls)

    assert prop(A) == prop(A)
    assert prop(B) == prop(B)
    assert prop(C) == prop(C)
    assert prop(D) == prop(D)
    assert prop(A) != prop(B)
    assert prop(A) != prop(C)
    assert prop(A) != prop(D)
    assert prop(B) != prop(C)
    assert prop(B) != prop(D)
    assert prop(C) != prop(D)



# Generated at 2022-06-21 22:10:07.879690
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test return value of read-only class property
    class A(object):
        @roclassproperty
        def name(): return 'A'

    assert A.name == 'A'

    # Test property access from instance
    assert A().name == 'A'

    # Test property from base class
    class B(A):
        pass

    assert B.name == 'A'
    assert B().name == 'A'

    # Test property from derived class
    class D(B):
        @roclassproperty
        def name(): return 'D'

    assert D.name == 'D'
    assert D().name == 'D'

    # Test property from derived class overrides property from base class
    class B(A):
        @roclassproperty
        def name(): return 'B'

    assert B.name == 'B'
    assert B

# Generated at 2022-06-21 22:10:10.282218
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def a(self, value):
            return value

    a = A()
    a.a = 1
    assert a.a == 1



# Generated at 2022-06-21 22:10:15.480262
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # pylint: disable=R0903
    class C(object):
        def __init__(self, a):
            self._a = a

        def a(self):
            return self._a

        @lazyclassproperty
        def b(cls):
            return cls.a(1) + 1

    c = C(0)
    assert c.b == 2



# Generated at 2022-06-21 22:10:24.207237
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class A:
        def __init__(self, val):
            self.val = val

        def test1(self):
            print(self.val)

        def test2(self, val):
            self.val = val
            print(self.val)


    class B(A):
        @roclassproperty
        def test3(cls):
            return cls.val
        test3 = test3.__get__(A, A)

        @setterproperty
        def test4(self, val):
            self.val = val
            print(self.val)

    my_a = A(1)
    my_b = B(2)

    print(my_b.test3)
    B.test3 = 3
    print(my_b.test3)

# Generated at 2022-06-21 22:10:38.259922
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            self.__dict__['value'] = value

        @property
        def value(self):
            return self.__dict__['value']

    test = Test(10)
    test.value = 15
    assert test.value == 15


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-21 22:10:48.449026
# Unit test for function lazyclassproperty
def test_lazyclassproperty():    # pragma: no cover
    from collections import namedtuple
    from test.test_support import EnvironmentVarGuard

    class Context(namedtuple("Context", "klass")):
        def __enter__(self):
            with EnvironmentVarGuard() as env:
                env.set("FUNCTION_LAZYCLASSPROPERTY", "True")
                return self.klass

    class Base(object):
        f = "Base"
        @classmethod
        def cmethod(self):
            return "Base"

        @staticmethod
        def smethod():
            return "Base"

        @property
        def property(self):
            return "Base"

        @lazyclassproperty
        def lazy_property(cls):
            return cls.f, self.cmethod(), self.smethod(), self.property

   

# Generated at 2022-06-21 22:10:55.093611
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        def __init__(self):
            self._x = None

        @roclassproperty
        def x(cls):
            return cls._x

        @x.setter
        def x(cls, value):
            cls._x = value

        @x.deleter
        def x(cls):
            del cls._x

    if __name__ == '__main__':
        print(MyClass.x)  # None

# Generated at 2022-06-21 22:11:01.691128
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Test method __get__ of class roclassproperty.
    """
    class A(object):
        pass

    class B(A):
        @classproperty
        def prop(cls):
            return 'A property'

        @roclassproperty
        def roprop(cls):
            return 'A read-only property'

    assert B.roprop == 'A read-only property'
    assert B.prop == 'A property'
    assert A.prop == 'A property'
    assert A.roprop == 'A read-only property'



# Generated at 2022-06-21 22:11:05.660566
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def bar(self, val):
            self._bar = val

    foo = Foo()
    foo.bar = 42
    import nose.tools as n
    n.assert_equal(foo._bar, 42)

# Generated at 2022-06-21 22:11:10.887183
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        count = 0
        @setterproperty
        def set_count(self, value):
            A.count = value
    a = A()
    A.count = 5
    a.set_count = 10
    assert A.count == 10
    assert a.count == 10
    delattr(A, 'set_count')


# Generated at 2022-06-21 22:11:18.195932
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    a = 1
    b = 1

    class A(object):
        @lazyclassproperty
        def a(cls):
            nonlocal a
            a += 1
            return a

        @lazyclassproperty
        def b(cls):
            nonlocal b
            b += 1
            return b
    assert A.a == 2
    assert A.b == 2
    assert A.a == 2
    assert A.b == 2

    class B(A):
        pass
    assert B.a == 3
    assert B.b == 3
    assert B.a == 3
    assert B.b == 3

    assert A.a == 2
    assert A.b == 2

    assert A.a == 2
    assert A.b == 2
    assert B.a == 3
    assert B.b == 3



# Generated at 2022-06-21 22:11:23.487302
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        pass
    #
    @setterproperty
    def test(self, value):
        return value
    #
    a = A()
    assert(a.test is None)
    a.test = 'test'
    assert('test' == a.test)



# Generated at 2022-06-21 22:11:29.430152
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def name(cls):
            return 'Foo'

    foo = Foo()
    assert isinstance(Foo.name, roclassproperty)
    assert isinstance(foo.name, roclassproperty)
    assert Foo.name == 'Foo'
    assert foo.name == 'Foo'
    try:
        foo.name = 'Bar'
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 22:11:32.865002
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        pass

    class B(object):
        @roclassproperty
        def f(cls):
            return 123

    assert A.f == None
    assert B.f == 123

# Generated at 2022-06-21 22:11:55.210013
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def something_time_consuming(x):
        import time
        time.sleep(1)
        return x

    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return something_time_consuming(1234)

    start = time.time()
    assert Foo.foo == 1234
    assert Foo.foo == 1234
    assert time.time() - start < 1.5

    class Foo1(Foo):
        pass

    assert Foo1.foo == 1234
    assert Foo1.foo == 1234



# Generated at 2022-06-21 22:11:59.303718
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def name(cls):
            return cls.__name__

    class B(A): pass

    class C(A): pass

    assert A.name == 'A'
    assert B.name == 'B'
    assert C.name == 'C'

# Generated at 2022-06-21 22:12:04.716832
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        def set_x(self, x):
            self.x = x

        def get_x(self):
            return self.x

        X = setterproperty(set_x)

    a = A(x=1)
    assert a.get_x() == 1

    a.X = 3
    assert a.get_x() == 3



# Generated at 2022-06-21 22:12:09.736949
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def f(cls):
            return []
    class A(Base): pass
    class B(Base): pass
    class C(B): pass
    assert A.f is not B.f is not C.f
    assert A.f == []
    assert B.f == []
    assert C.f == []
    A.f.append(1)
    assert A.f == [1]
    B.f.append(2)
    assert B.f == [2]
    C.f.append(3)
    assert C.f == [3]



# Generated at 2022-06-21 22:12:15.063170
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        def f1(cls):
            return 1
        f1 = roclassproperty(f1)

        def f2(cls):
            return 2
        f2 = classproperty(f2)

    assert Foo.f1 == Foo.f1
    assert Foo.f2 == Foo.f2
    assert Foo.f1 == 1
    assert Foo.f2 == 2



# Generated at 2022-06-21 22:12:21.171241
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Dummy:
        def __init__(self):
            self.setted = False
        def set_value(self, value):
            self.setted = True

    def set_dummy(dummy):
        return setterproperty(dummy.set_value)

    d = Dummy()
    assert not d.setted

    dummy = set_dummy(d)
    dummy.__set__(d, "foobar")
    assert d.setted

    assert d.set_value == setterproperty(d.set_value)
    assert dummy.__doc__ is None

# Generated at 2022-06-21 22:12:33.295946
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self.a = 10

        @setterproperty
        def a(self, value):
            self._a = value
            return value

        @setterproperty
        def b(self, value):
            self._a = value
            return value

        @setterproperty
        def c(self, value):
            self._a = value
            return value

    test = Test()
    assert test.a == 10
    test.a = 12
    assert test.a == 12
    test.a = 15
    assert test.a == 15

    # test usage with multiple properties
    assert test.b == 10
    assert test.c == 10

    test.b = 12
    assert test.b == 12
    assert test.c == 10

    test.c = 15


# Generated at 2022-06-21 22:12:40.292535
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from random import random
    from collections import namedtuple

    Point = namedtuple('Point', 'x, y')

    class A:
        def __init__(self):
            self.z = 0

        @setterproperty
        def p(self, value):
            self.z = value.x + value.y

        def __str__(self):
            return 'A(%s)' % self.z

    a = A()
    assert str(a) == 'A(0)'
    a.p = Point(x=5, y=5)
    assert str(a) == 'A(10)'

# Generated at 2022-06-21 22:12:42.930911
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def TEST(cls):
            return "TEST"

    assert Test.TEST == "TEST"

# Generated at 2022-06-21 22:12:51.901752
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class test_setterproperty___set___Class1(object):
        @setterproperty
        def test_setterproperty___set___attrib1(self, value):
            self.attrib = value

        @setterproperty
        def test_setterproperty___set___attrib2(self, value):
            self.attrib2 = value

    instance = test_setterproperty___set___Class1()
    test_value = "test_value"
    instance.test_setterproperty___set___attrib1 = test_value
    assert instance.attrib == test_value
    instance.test_setterproperty___set___attrib2 = test_value
    assert instance.attrib2 == test_value


# Generated at 2022-06-21 22:13:34.112479
# Unit test for function lazyperclassproperty

# Generated at 2022-06-21 22:13:38.106913
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class Foo(object):

        def get_bar(cls):
            return 1

        bar = roclassproperty(get_bar)

    assert Foo.bar == 1

# Generated at 2022-06-21 22:13:43.154350
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def get_v(obj):
        return obj.__dict__.get('v', 0)

    def v_setter(obj, v):
        obj.__dict__['v'] = v
        return obj

    class Foo(object):
        v = setterproperty(v_setter)

    foo = Foo()
    assert get_v(foo) == 0
    foo.v = 1
    assert get_v(foo) == 1

# Generated at 2022-06-21 22:13:53.093271
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def func_test(cls):
        print('Inside function `{}` for class `{}`'.format(func_test.__qualname__, cls.__name__))
        return 1

    class A():
        pass

    class B():
        pass

    assert func_test == 1
    assert A.func_test == 1
    assert B.func_test == 1

    A.func_test = 2
    assert A.func_test == 2
    assert B.func_test == 1
    assert func_test == 1



# Generated at 2022-06-21 22:14:03.192096
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def method(self):
            pass

    class A(Base):
        @lazyperclassproperty
        def method(cls):
            print ("Called")
            return lambda self: "A"

    class B(Base):
        @lazyperclassproperty
        def method(cls):
            print ("Called")
            return lambda self: "B"

    # Check if we get only one print call, and proper results
    a = A()
    print(a.method())
    print(a.method())
    print(a.method())

    b = B()
    print(b.method())
    print(b.method())
    print(b.method())



# Generated at 2022-06-21 22:14:09.223287
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def getter(cls):
            return 1 + 1

    assert C.getter == 2
    assert C().getter == 2
    assert C.__dict__['getter'].__get__(None, C) == 2


# Generated at 2022-06-21 22:14:11.655825
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    method = roclassproperty(lambda cls: 42)
    assert method.__get__(None, object) == 42


# Generated at 2022-06-21 22:14:13.804027
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        class __metaclass__(type):
            @roclassproperty
            def p(cls):
                return cls.__name__

    class D(C):
        pass

    assert C.p == 'C'
    assert D.p == 'D'
    assert C().p == 'C'



# Generated at 2022-06-21 22:14:20.729250
# Unit test for constructor of class setterproperty
def test_setterproperty():
    @setterproperty
    def test_setterproperty_1(self, value):
        self.my_value = value

    @setterproperty
    def test_setterproperty_2(self, value):
        self.my_value_2 = value

    class A(object):
        def __init__(self):
            pass

    a = A()
    a.test_setterproperty_1 = 3
    assert a.my_value == 3
    a.test_setterproperty_2 = 4
    assert a.my_value_2 == 4


# Generated at 2022-06-21 22:14:29.736061
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class parent(object):
        @lazyperclassproperty
        def test(cls):
            return 'test'


    class child(parent):
        pass


    class child2(parent):
        pass


    class grandchild(child):
        pass


    class grandchild2(child):
        pass


    parent._test_lazy_test = 'test2'

    assert parent.test == 'test2'
    assert child.test == 'test'
    assert child2.test == 'test'
    assert grandchild.test == 'test'
    assert grandchild2.test == 'test'

    child._test_lazy_test = 'test3'

    assert parent.test == 'test2'
    assert child.test == 'test3'
    assert child2.test == 'test'
    assert grand

# Generated at 2022-06-21 22:15:42.815867
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @classmethod
        def class_method(cls):
            return 2

        @lazyclassproperty
        def class_prop(cls):
            return cls.class_method()

    assert 2 == A.class_prop
    assert 2 == A.class_prop

    class B(A):
        @classmethod
        def class_method(cls):
            return 3

    assert 2 == A.class_prop
    assert 3 == B.class_prop
    assert 3 == B.class_prop

# Generated at 2022-06-21 22:15:47.584207
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyObject(object):
        def __init__(self):
            self.foo = 1

        @setterproperty
        def bar(self, bar):
            self.foo = bar

    myObject = MyObject()
    myObject.bar = 3
    assert myObject.foo == 3


# Generated at 2022-06-21 22:15:53.438667
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ExampleClass(object):
        @lazyclassproperty
        def test(cls):
            print('hello world')
            return 'test'

    # Check the property is being lazily evaluated, not at load time.
    assert not hasattr(ExampleClass, 'test')

    # Call the property
    result = ExampleClass.test

    # Check the property is cached
    assert ExampleClass.test == result

    # Check the property is defined on the class
    assert hasattr(ExampleClass, 'test')
    assert ExampleClass.test == result

    # Check a new class instance doesn't redefine it
    class ExampleClass2(ExampleClass):
        pass
    assert ExampleClass2.test == result



# Generated at 2022-06-21 22:16:00.146693
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x):
            self.x = x
        
        @setterproperty
        def x(self, x):
            self._x = x
        
        @x.setter
        def x(self, x):
            self._x = x
    
    x = A(1)
    assert x._x == 1
    x.x = 2
    assert x._x == 2



# Generated at 2022-06-21 22:16:03.814175
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def value(self):
            return 1

    class B(A):
        pass

    print(A.value, B.value)
    A.value = 2
    print(A.value, B.value)



# Generated at 2022-06-21 22:16:07.867281
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestRoclassproperty:
        def __init__(self):
            self.a = 0

        @roclassproperty
        def prop(cls):
            return "hello"

    obj = TestRoclassproperty()
    assert obj.a == 0
    assert TestRoclassproperty.prop == "hello"
    assert obj.prop == "hello"


# Generated at 2022-06-21 22:16:14.203876
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class NonDataDescriptorClass(object):
        def __init__(self, value):
            self.value = value

        def __get__(self, obj, objtype):
            return self.value

    class Foo(object):
        foo = NonDataDescriptorClass(1)
        goo = 2

    assert Foo.foo == 1
    foo = Foo()
    assert foo.foo == 1
    foo.foo = 10
    assert foo.foo == 10

    assert Foo.goo == 2
    assert foo.goo == 2
    foo.goo = 20
    assert foo.goo == 20



# Generated at 2022-06-21 22:16:22.821187
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class lazycls(object):
        def __init__(self):
            self.att1 = 1
            self.att2 = 2

        @lazyclassproperty
        def att3(self):
            return self.att1 + self.att2

    lc = lazycls()
    assert lc.att1 == lc.att2 == 1 and lc.att3 == 3
    lc.att1 = 3
    assert lc.att1 == 3 and lc.att2 == 1 and lc.att3 == 3
    lc.att2 = 3
    assert lc.att1 == 3 and lc.att2 == 3 and lc.att3 == 3



# Generated at 2022-06-21 22:16:28.351100
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    N = 5
    class A():
        @lazyperclassproperty
        def prop(cls):
            return N-1
    A.prop == N-1
    class B(A):
        @lazyperclassproperty
        def prop(cls):
            return N-2
    A.prop == B.prop == N-1
    assert A.prop == N-1
    assert B.prop == N-2


# Generated at 2022-06-21 22:16:31.227058
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    a = A()
    with pytest.raises(AttributeError):
        print(a.foo)
