

# Generated at 2022-06-18 04:37:01.127594
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:37:04.904291
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return 2

    assert A.x == 1
    assert B.x == 2
    assert A.x == 1
    assert B.x == 2



# Generated at 2022-06-18 04:37:08.324163
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:37:12.676092
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1
    assert B.prop == 1



# Generated at 2022-06-18 04:37:17.663247
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return "B"

    class C(A):
        pass

    assert A.a == "A"
    assert B.a == "B"
    assert C.a == "A"



# Generated at 2022-06-18 04:37:20.741408
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert Test.foo == 'foo'
    assert Test.foo == 'foo'
    assert Test.foo == 'foo'



# Generated at 2022-06-18 04:37:30.393662
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'

    assert B.x == 'x'
    assert B.x == 'x'



# Generated at 2022-06-18 04:37:36.008583
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:39.481135
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1



# Generated at 2022-06-18 04:37:44.855806
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:37:51.194238
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'



# Generated at 2022-06-18 04:37:56.266436
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:38:02.181609
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'
    assert A.foo is not B.foo
    assert A.foo is not C.foo
    assert B.foo is not C.foo



# Generated at 2022-06-18 04:38:06.191242
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:38:08.369919
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:13.279490
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:16.396818
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:38:19.929366
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('computing')
            return 42

    assert A.prop == 42
    assert A.prop == 42

    class B(A):
        pass

    assert B.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:38:24.730931
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    class D(C):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'
    assert D.a == 'c'



# Generated at 2022-06-18 04:38:28.955418
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 1

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 1
    assert B.x == 1
    assert C.x == 1



# Generated at 2022-06-18 04:38:34.506857
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:38:39.550641
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:38:44.593132
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    A.foo = 24
    assert A.foo == 24
    assert B.foo == 42



# Generated at 2022-06-18 04:38:50.343938
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:38:53.005698
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x

    A.x = 'y'
    assert A.x == 'y'
    assert B.x == 'x'
    assert A.x is not B.x



# Generated at 2022-06-18 04:38:58.985554
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('A.foo')
            return 'A.foo'

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            print('B.foo')
            return 'B.foo'

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print('C.foo')
            return 'C.foo'

    assert A.foo == 'A.foo'
    assert B.foo == 'B.foo'
    assert C.foo == 'C.foo'



# Generated at 2022-06-18 04:39:04.962123
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1

    A.a = 2
    assert A.a == 2
    assert B.a == 1

    B.a = 3
    assert A.a == 2
    assert B.a == 3



# Generated at 2022-06-18 04:39:09.957971
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:39:14.371389
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:19.343972
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    assert B.x == 'x'
    assert B

# Generated at 2022-06-18 04:39:30.544663
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1



# Generated at 2022-06-18 04:39:36.466442
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("Calculating x")
            return "x"

    class B(A):
        pass

    assert A.x == "x"
    assert B.x == "x"



# Generated at 2022-06-18 04:39:42.672583
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:39:48.377396
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:39:52.027321
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:39:56.131085
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:03.000912
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:40:06.810110
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:40:14.926231
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('a')
            return 1

    class B(A):
        @lazyclassproperty
        def b(cls):
            print('b')
            return 2

    class C(B):
        @lazyclassproperty
        def c(cls):
            print('c')
            return 3

    assert A.a == 1
    assert B.a == 1
    assert C.a == 1
    assert A.b == 2
    assert B.b == 2
    assert C.b == 2
    assert A.c == 3
    assert B.c == 3
    assert C.c == 3



# Generated at 2022-06-18 04:40:18.157863
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    class B(A):
        pass

    assert A.prop == 'value'
    assert B.prop == 'value'
    assert A.prop is B.prop



# Generated at 2022-06-18 04:40:42.790596
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:40:46.677953
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 'test'

    class B(A):
        pass

    assert A.test == 'test'
    assert B.test == 'test'
    assert A.test is B.test



# Generated at 2022-06-18 04:40:50.847960
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:54.496489
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:40:59.709008
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:05.975727
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'cx'

    class D(C):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'cx'
    assert D.x == 'cx'



# Generated at 2022-06-18 04:41:14.306460
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert A().x == 'A'
    assert B().x == 'A'
    assert C().x == 'C'


# Generated at 2022-06-18 04:41:19.051345
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 'C'

    assert A.prop == 'A'
    assert B.prop == 'A'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:41:26.314823
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    class D(C):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'
    assert D.a == 'c'



# Generated at 2022-06-18 04:41:32.690021
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:17.763080
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:23.382085
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:42:28.010896
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:42:33.570464
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:38.792779
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:44.640174
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:42:48.763960
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:52.862839
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    class D(C):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert D.foo == 'bar'



# Generated at 2022-06-18 04:42:58.452657
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:43:03.213663
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class Derived(Base):
        pass

    assert Base.foo == 'foo'
    assert Derived.foo == 'foo'

    Base.foo = 'bar'
    assert Base.foo == 'bar'
    assert Derived.foo == 'foo'



# Generated at 2022-06-18 04:44:38.731061
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.test == 'A'
    assert B.test == 'B'



# Generated at 2022-06-18 04:44:41.460747
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:44:43.440799
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:44:46.698012
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42



# Generated at 2022-06-18 04:44:51.751852
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:44:56.036455
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    A.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:45:01.088561
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:45:05.438647
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:45:11.301342
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'



# Generated at 2022-06-18 04:45:27.795478
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'

