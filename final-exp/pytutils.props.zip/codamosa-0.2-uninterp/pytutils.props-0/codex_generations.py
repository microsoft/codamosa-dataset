

# Generated at 2022-06-18 04:37:05.436153
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:37:11.415160
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:16.764831
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            print("C.x")
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2



# Generated at 2022-06-18 04:37:24.467307
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:37:29.446177
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:34.948034
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return 'B'

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'A'


# Generated at 2022-06-18 04:37:39.481815
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42

    A.foo = 24
    assert A.foo == 24
    assert B.foo == 42



# Generated at 2022-06-18 04:37:45.931914
# Unit test for function lazyperclassproperty

# Generated at 2022-06-18 04:37:51.160671
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:37:57.284136
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:07.971680
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'

    class B(A):
        pass

    assert B.prop == 'value'
    assert B.prop == 'value'
    assert B.prop == 'value'

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return 'value2'

    assert C.prop == 'value2'
    assert C.prop == 'value2'
    assert C.prop == 'value2'

    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'

    assert B.prop == 'value'

# Generated at 2022-06-18 04:38:12.798214
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:16.539199
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'



# Generated at 2022-06-18 04:38:19.715459
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 'test'

    class B(A):
        pass

    assert A.test == 'test'
    assert B.test == 'test'
    assert A.test is B.test



# Generated at 2022-06-18 04:38:23.636688
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 'C'

    assert A.prop == 'A'
    assert B.prop == 'A'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:38:28.999827
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:31.977512
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    class B(A):
        pass

    assert A.prop == 'value'
    assert B.prop == 'value'
    assert A.prop is B.prop



# Generated at 2022-06-18 04:38:35.394630
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:38:39.401752
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return 'B'

    assert A.x == 'A'
    assert B.x == 'B'
    assert A().x == 'A'
    assert B().x == 'B'



# Generated at 2022-06-18 04:38:45.128368
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:38:52.854424
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    assert A.x == 1
    assert B.x == 1



# Generated at 2022-06-18 04:38:55.544976
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'



# Generated at 2022-06-18 04:39:00.506755
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("a")
            return 1

    class B(A):
        @lazyclassproperty
        def b(cls):
            print("b")
            return 2

    class C(B):
        @lazyclassproperty
        def c(cls):
            print("c")
            return 3

    assert A.a == 1
    assert B.a == 1
    assert C.a == 1
    assert A.b == 2
    assert B.b == 2
    assert C.b == 2
    assert C.c == 3



# Generated at 2022-06-18 04:39:06.687584
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    class C(B):
        @lazyperclassproperty
        def a(cls):
            return 3

    assert A.a == 1
    assert B.a == 2
    assert C.a == 3



# Generated at 2022-06-18 04:39:12.003320
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:39:16.826422
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return 2

    print(A.x)
    print(B.x)
    print(A.x)
    print(B.x)



# Generated at 2022-06-18 04:39:25.174950
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 'C'

    assert A.prop == 'A'
    assert B.prop == 'A'
    assert C.prop == 'C'
    assert A().prop == 'A'
    assert B().prop == 'A'
    assert C().prop == 'C'



# Generated at 2022-06-18 04:39:30.127506
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:32.857687
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    assert A.a == 1
    assert A.a == 1

    class B(A):
        pass

    assert B.a == 1
    assert B.a == 1



# Generated at 2022-06-18 04:39:39.402452
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:49.338960
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:52.869079
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42



# Generated at 2022-06-18 04:39:57.519271
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:40:03.713558
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:40:08.693981
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:13.706432
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:16.819956
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    print(A.prop)
    print(A.prop)
    print(A.prop)

    class B(A):
        pass

    print(B.prop)
    print(B.prop)
    print(B.prop)



# Generated at 2022-06-18 04:40:22.968443
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:26.544404
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('Calculating')
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42
    assert A.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:40:32.553149
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"
    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:40:58.779983
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyperclassproperty
        def x(cls):
            print("B.x")
            return 2

    class C(A):
        @lazyperclassproperty
        def x(cls):
            print("C.x")
            return 3

    class D(B, C):
        pass

    assert A.x == 1
    assert B.x == 2
    assert C.x == 3
    assert D.x == 2



# Generated at 2022-06-18 04:41:03.572557
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:41:06.849793
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('calculating')
            return 'some result'

    assert A.prop == 'some result'
    assert A.prop == 'some result'



# Generated at 2022-06-18 04:41:09.653532
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:41:14.308350
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:41:16.182219
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:21.265356
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:25.965197
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:41:31.729028
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:35.255271
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:42:22.431959
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:42:28.964775
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    class B(A):
        pass

    assert A.prop == 'value'
    assert B.prop == 'value'

    A.prop = 'new value'
    assert A.prop == 'new value'
    assert B.prop == 'value'



# Generated at 2022-06-18 04:42:32.450619
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:42:36.299035
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:42.901019
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:45.097157
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:49.155017
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:57.550641
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return "A.x"

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return "B.x"

    class C(A):
        pass

    assert A.x == "A.x"
    assert B.x == "B.x"
    assert C.x == "A.x"



# Generated at 2022-06-18 04:43:03.252657
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("bar")
            return "bar"

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "bar"


# Generated at 2022-06-18 04:43:06.428585
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Computing prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1
    assert B.prop == 1



# Generated at 2022-06-18 04:44:44.240061
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'


# Generated at 2022-06-18 04:44:46.885027
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == B.foo



# Generated at 2022-06-18 04:44:51.751884
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:44:57.606597
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:45:01.903609
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'
    assert B.foo == 'bar'



# Generated at 2022-06-18 04:45:10.131299
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo")
            return 43

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 43
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 43



# Generated at 2022-06-18 04:45:14.392772
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:17.464881
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:20.381587
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:30.389864
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    assert A.foo == "foo"
    assert A.foo == "foo"
    assert A.foo == "foo"

    class B(A):
        pass

    assert B.foo == "foo"
    assert B.foo == "foo"
    assert B.foo == "foo"

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo2"

    assert C.foo == "foo2"
    assert C.foo == "foo2"
    assert C.foo == "foo2"

    class D(C):
        pass

    assert D.foo == "foo2"