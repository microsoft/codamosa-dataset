

# Generated at 2022-06-18 04:37:07.642836
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return "A.x"

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return "B.x"

    class C(A):
        pass

    assert A.x == "A.x"
    assert B.x == "B.x"
    assert C.x == "A.x"

    A.x = "A.x2"
    assert A.x == "A.x2"
    assert B.x == "B.x"
    assert C.x == "A.x2"

    B.x = "B.x2"
    assert A.x == "A.x2"

# Generated at 2022-06-18 04:37:12.504338
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:37:17.485606
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:20.943440
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:37:29.749096
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'



# Generated at 2022-06-18 04:37:39.248489
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("A.foo")
            return "A.foo"

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            print("B.foo")
            return "B.foo"

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("C.foo")
            return "C.foo"

    assert A.foo == "A.foo"
    assert B.foo == "B.foo"
    assert C.foo == "C.foo"

    assert A().foo == "A.foo"
    assert B().foo == "B.foo"
    assert C().foo == "C.foo"


# Generated at 2022-06-18 04:37:44.481381
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:37:52.376609
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:37:57.779083
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1
    assert B.prop == 1



# Generated at 2022-06-18 04:38:02.288106
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:08.006152
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:38:12.839378
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:15.727959
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:38:20.822847
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('prop called')
            return 'prop'

    class B(A):
        pass

    assert A.prop == 'prop'
    assert B.prop == 'prop'
    assert A.prop == 'prop'
    assert B.prop == 'prop'



# Generated at 2022-06-18 04:38:28.061819
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'x'

    A.x = 'y'
    assert A.x == 'y'
    assert B.x == 'x'
    assert C.x == 'x'

    B.x = 'z'
    assert A.x == 'y'
    assert B.x == 'z'
    assert C.x == 'x'

    C.x = 'w'
    assert A.x == 'y'
    assert B.x == 'z'
    assert C.x == 'w'

# Unit

# Generated at 2022-06-18 04:38:30.086872
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:34.211834
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    A.x = 'y'
    assert A.x == 'y'
    assert B.x == 'x'



# Generated at 2022-06-18 04:38:42.073773
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1
    assert B.prop == 1

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 2

    assert A.prop == 1
    assert B.prop == 1
    assert C.prop == 2

    class D(C):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert C.prop == 2
    assert D.prop == 2



# Generated at 2022-06-18 04:38:44.952072
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:38:49.203542
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:38:57.318420
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:01.510346
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:39:12.002225
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'
    assert B.foo == 'bar'
    assert B.foo == 'bar'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'baz'

    assert C.foo == 'baz'
    assert C.foo == 'baz'
    assert C.foo == 'baz'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'

    assert B.foo == 'bar'

# Generated at 2022-06-18 04:39:15.484845
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:39:21.944445
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:26.463336
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:39:30.841464
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("Calculating x")
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    assert A.x == 1
    assert B.x == 1



# Generated at 2022-06-18 04:39:36.498158
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'



# Generated at 2022-06-18 04:39:43.263884
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:39:49.635336
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == 'foo'
    assert B.foo == 'foo'

    A.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:40:01.915959
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.prop == 'A'
    assert B.prop == 'B'



# Generated at 2022-06-18 04:40:04.669872
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("prop")
            return 1

    assert A.prop == 1
    assert A.prop == 1



# Generated at 2022-06-18 04:40:09.691237
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:15.874888
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'
    assert B.foo == 'bar'
    assert B.foo == 'bar'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'baz'

    assert C.foo == 'baz'
    assert C.foo == 'baz'
    assert C.foo == 'baz'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'



# Generated at 2022-06-18 04:40:21.000018
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:40:25.500881
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:40:31.432617
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    class D(C):
        pass

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert D.x == 'C'



# Generated at 2022-06-18 04:40:34.999639
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:40:41.504551
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    class D(C):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'
    assert D.a == 'c'



# Generated at 2022-06-18 04:40:46.680071
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:07.202319
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:13.397941
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42
    assert A.prop == 42
    assert B.prop == 42
    assert A.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:41:18.878306
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:26.117664
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('a')
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            print('c')
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2
    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:41:32.843306
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 2

    class D(C):
        pass

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2
    assert D.x == 2



# Generated at 2022-06-18 04:41:37.016672
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('a')
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            print('c')
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:41:41.514293
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:41:45.502072
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42



# Generated at 2022-06-18 04:41:48.065962
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:53.569256
# Unit test for function lazyperclassproperty

# Generated at 2022-06-18 04:42:35.715203
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x is evaluated")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x is evaluated")
            return 2

    class C(A):
        pass

    assert A.x == 1
    assert B.x == 2
    assert C.x == 1
    assert A().x == 1
    assert B().x == 2
    assert C().x == 1



# Generated at 2022-06-18 04:42:41.534840
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:44.947478
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class Derived(Base):
        pass

    assert Base.foo == 'foo'
    assert Derived.foo == 'foo'
    assert Base.foo is not Derived.foo



# Generated at 2022-06-18 04:42:47.217034
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:42:49.500247
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:42:54.709359
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:42:59.502800
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:43:02.820073
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:43:09.572871
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'
    assert B.foo == 'bar'
    assert B.foo == 'bar'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'baz'

    assert C.foo == 'baz'
    assert C.foo == 'baz'
    assert C.foo == 'baz'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'

    assert B.foo == 'bar'

# Generated at 2022-06-18 04:43:15.615134
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:44:47.162149
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.a == 'A'
    assert B.a == 'B'
    assert C.a == 'C'



# Generated at 2022-06-18 04:44:51.804895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:44:55.151781
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'



# Generated at 2022-06-18 04:44:58.873633
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:45:02.875192
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:06.797316
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:45:12.821684
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:27.441625
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return "bar"

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "bar"



# Generated at 2022-06-18 04:45:33.325250
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:37.432899
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            print("C.x")
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2

