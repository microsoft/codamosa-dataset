

# Generated at 2022-06-18 04:37:03.309598
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            print("y")
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2



# Generated at 2022-06-18 04:37:12.285741
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('calculating')
            return 42

    assert A.prop == 42
    assert A.prop == 42

    class B(A):
        pass

    assert B.prop == 42
    assert B.prop == 42

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print('calculating')
            return 43

    assert C.prop == 43
    assert C.prop == 43

    assert A.prop == 42
    assert A.prop == 42

    assert B.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:37:16.586262
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:37:21.670393
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('A.a')
            return 'A.a'

    class B(A):
        @lazyclassproperty
        def a(cls):
            print('B.a')
            return 'B.a'

    assert A.a == 'A.a'
    assert B.a == 'B.a'



# Generated at 2022-06-18 04:37:31.508469
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:37:36.718523
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:42.380253
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'

# Generated at 2022-06-18 04:37:47.741633
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return -1

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == -1



# Generated at 2022-06-18 04:37:52.725604
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:37:59.116078
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("A.a")
            return 1

    class B(A):
        @lazyclassproperty
        def a(cls):
            print("B.a")
            return 2

    class C(A):
        pass

    assert A.a == 1
    assert B.a == 2
    assert C.a == 1



# Generated at 2022-06-18 04:38:03.883193
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:38:07.385382
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    A.prop = 2
    assert A.prop == 2
    assert B.prop == 1



# Generated at 2022-06-18 04:38:10.797811
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:38:15.048419
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:18.780022
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:38:22.022625
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:38:26.800024
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    class D(B, C):
        pass

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert D.x == 'C'



# Generated at 2022-06-18 04:38:30.036107
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42



# Generated at 2022-06-18 04:38:31.969495
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.test == 'A'
    assert B.test == 'B'



# Generated at 2022-06-18 04:38:35.682513
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'

    class B(A):
        pass

    assert B.prop == 'value'
    assert B.prop == 'value'



# Generated at 2022-06-18 04:38:45.602266
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:51.246812
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:53.907245
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:38:56.271901
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:39:00.729404
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'



# Generated at 2022-06-18 04:39:09.544480
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo...")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo...")
            return 43

    class D(C):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 43
    assert D.foo == 43
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 43
    assert D.foo == 43



# Generated at 2022-06-18 04:39:13.794176
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:39:23.980962
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    assert B.x == 'x'
    assert B

# Generated at 2022-06-18 04:39:27.075491
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:39:34.995090
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'

    class B(A):
        pass

    assert B.prop == 'value'
    assert B.prop == 'value'
    assert B.prop == 'value'

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return 'value2'

    assert C.prop == 'value2'
    assert C.prop == 'value2'
    assert C.prop == 'value2'

    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'

    assert B.prop == 'value'

# Generated at 2022-06-18 04:39:48.845079
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:52.432052
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo


# Generated at 2022-06-18 04:39:56.454377
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:40:01.128005
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.__dict__['_lazy_foo'] == 'bar'



# Generated at 2022-06-18 04:40:06.143251
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:10.081722
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:40:12.075794
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:40:15.854724
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return 2

    assert A.x == 1
    assert B.x == 2



# Generated at 2022-06-18 04:40:18.928786
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:40:26.394522
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:40:50.250071
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:40:53.107135
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:40:58.676206
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'
    assert B.x == 'x'



# Generated at 2022-06-18 04:41:01.782192
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'



# Generated at 2022-06-18 04:41:03.998118
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:41:06.951097
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:41:17.775531
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'



# Generated at 2022-06-18 04:41:26.263701
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("A.foo")
            return 1

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            print("B.foo")
            return 2

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("C.foo")
            return 3

    assert A.foo == 1
    assert B.foo == 2
    assert C.foo == 3
    assert A.foo == 1
    assert B.foo == 2
    assert C.foo == 3



# Generated at 2022-06-18 04:41:30.978771
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:41:35.521253
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:25.063892
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A.foo is not B.foo
    assert A.foo is not C.foo
    assert B.foo is not C.foo


# Generated at 2022-06-18 04:42:32.723468
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'c'

    class D(C):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'c'
    assert D.x == 'c'



# Generated at 2022-06-18 04:42:39.111196
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:42:42.781621
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:49.048836
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyperclassproperty
        def x(cls):
            print("B.x")
            return 2

    class C(A):
        @lazyperclassproperty
        def x(cls):
            print("C.x")
            return 3

    assert A.x == 1
    assert B.x == 2
    assert C.x == 3
    assert A.x == 1
    assert B.x == 2
    assert C.x == 3



# Generated at 2022-06-18 04:42:51.819136
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print("a")
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    assert A.a == 1
    assert B.a == 1



# Generated at 2022-06-18 04:42:59.892550
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:43:03.482409
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo


# Generated at 2022-06-18 04:43:07.473319
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:43:12.501291
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:44:49.830420
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert A.a == B.a



# Generated at 2022-06-18 04:44:53.511423
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:44:58.956583
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:02.640951
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:45:07.105644
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("prop called")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert A.prop == 1
    assert B.prop == 1
    assert B.prop == 1
    assert A.prop == 1



# Generated at 2022-06-18 04:45:12.747201
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'prop'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return 'prop2'

    assert A.prop == 'prop'
    assert B.prop == 'prop'
    assert C.prop == 'prop2'



# Generated at 2022-06-18 04:45:25.265769
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:45:30.029596
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:45:34.794176
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    assert A.foo == 'bar'
    assert B.foo == 'bar'
    A.foo = 'baz'
    assert A.foo == 'baz'
    assert B.foo == 'bar'



# Generated at 2022-06-18 04:45:37.477593
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo

