

# Generated at 2022-06-18 04:37:06.227392
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    class D(C):
        pass

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert D.x == 'C'



# Generated at 2022-06-18 04:37:12.192052
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:18.635868
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert A().x == 'A'
    assert B().x == 'A'
    assert C().x == 'C'



# Generated at 2022-06-18 04:37:22.301181
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:37:28.329604
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:37:37.386600
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return 2

    class C(A):
        @lazyclassproperty
        def x(cls):
            print("C.x")
            return 3

    assert A.x == 1
    assert B.x == 2
    assert C.x == 3
    assert A.x == 1
    assert B.x == 2
    assert C.x == 3



# Generated at 2022-06-18 04:37:40.157656
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:37:45.740763
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:49.595712
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'


# Generated at 2022-06-18 04:37:56.266141
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:07.138497
# Unit test for function lazyperclassproperty

# Generated at 2022-06-18 04:38:10.714203
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:15.551268
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("prop called")
            return "prop"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("prop called")
            return "prop2"

    assert A.prop == "prop"
    assert B.prop == "prop"
    assert C.prop == "prop2"



# Generated at 2022-06-18 04:38:24.195362
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(B):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'

    A.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'foo'
    assert C.foo == 'foo'

    B.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert C.foo == 'foo'

    C.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert C.foo == 'bar'


# Unit

# Generated at 2022-06-18 04:38:29.206169
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:36.253599
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'
    assert A.foo == 'foo'

    class B(A):
        pass

    assert B.foo == 'foo'
    assert B.foo == 'foo'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert C.foo == 'bar'
    assert C.foo == 'bar'

    assert A.foo == 'foo'
    assert A.foo == 'foo'

    assert B.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:38:39.967378
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:44.546792
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:38:50.298125
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:38:53.831249
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('calculating')
            return 'some result'

    class B(A):
        pass

    assert A.prop == 'some result'
    assert B.prop == 'some result'



# Generated at 2022-06-18 04:39:02.362978
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:39:10.683799
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('A.a')
            return 1

    class B(A):
        @lazyclassproperty
        def a(cls):
            print('B.a')
            return 2

    class C(A):
        @lazyclassproperty
        def a(cls):
            print('C.a')
            return 3

    class D(B, C):
        pass

    assert A.a == 1
    assert B.a == 2
    assert C.a == 3
    assert D.a == 2



# Generated at 2022-06-18 04:39:15.275207
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1

    A.x = 2
    assert A.x == 2
    assert B.x == 1

    B.x = 3
    assert A.x == 2
    assert B.x == 3



# Generated at 2022-06-18 04:39:20.435906
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:39:26.754970
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            print("y")
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2
    assert A.x == 1
    assert B.x == 1
    assert C.x == 2



# Generated at 2022-06-18 04:39:31.734493
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:38.806131
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:39:44.328611
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo")
            return -42

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == -42
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == -42



# Generated at 2022-06-18 04:39:48.978667
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42
    assert A.prop == 42



# Generated at 2022-06-18 04:39:52.868923
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == B.foo
    assert A.foo is B.foo



# Generated at 2022-06-18 04:40:05.706870
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:40:11.027524
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:13.319529
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:40:15.253281
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:40:18.193386
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    class B(A):
        pass

    assert A.prop == 'value'
    assert B.prop == 'value'
    assert A.prop is B.prop



# Generated at 2022-06-18 04:40:24.714553
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            print('y')
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2



# Generated at 2022-06-18 04:40:28.173159
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    assert A.a == B.a
    assert A.a is B.a



# Generated at 2022-06-18 04:40:32.841583
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'



# Generated at 2022-06-18 04:40:36.205659
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.test == 'A'
    assert B.test == 'B'
    assert C.test == 'C'



# Generated at 2022-06-18 04:40:40.551317
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class Derived(Base):
        pass

    assert Base.foo == 'Base'
    assert Derived.foo == 'Derived'



# Generated at 2022-06-18 04:41:03.183522
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:07.355604
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Evaluating prop")
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42
    assert A.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:41:13.397688
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:18.588341
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:22.371406
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:41:26.871715
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:41:33.730990
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def y(cls):
            return cls.x

    class B(A):
        def __init__(self, x):
            super(B, self).__init__(x)

    a = A(1)
    b = B(2)
    assert a.y == 1
    assert b.y == 2



# Generated at 2022-06-18 04:41:37.143732
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:41:43.536413
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:50.483947
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    assert A.foo == "foo"
    assert A.foo == "foo"

    class B(A):
        pass

    assert B.foo == "foo"
    assert B.foo == "foo"

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo2"

    assert C.foo == "foo2"
    assert C.foo == "foo2"

    class D(C):
        pass

    assert D.foo == "foo2"
    assert D.foo == "foo2"



# Generated at 2022-06-18 04:42:33.361628
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:42:38.885929
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:41.871260
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:42:44.335793
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:42:47.574353
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo


# Generated at 2022-06-18 04:42:50.562577
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:42:54.913013
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:42:57.355043
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("A.a")
            return 1

    class B(A):
        @lazyclassproperty
        def a(cls):
            print("B.a")
            return 2

    assert A.a == 1
    assert B.a == 2
    assert A.a == 1
    assert B.a == 2



# Generated at 2022-06-18 04:43:04.282879
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'
    assert A.foo == 'foo'

    class B(A):
        pass

    assert B.foo == 'foo'
    assert B.foo == 'foo'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert C.foo == 'bar'
    assert C.foo == 'bar'
    assert A.foo == 'foo'
    assert A.foo == 'foo'



# Generated at 2022-06-18 04:43:09.473689
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'baz'

    assert C.foo == 'baz'
    assert A.foo == 'bar'



# Generated at 2022-06-18 04:44:45.561247
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('Calculating')
            return 42

    print(A.prop)
    print(A.prop)



# Generated at 2022-06-18 04:44:51.559626
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:44:56.191162
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'



# Generated at 2022-06-18 04:45:00.358533
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:45:05.657898
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:45:11.493209
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:14.145596
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:45:25.871591
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:45:29.381547
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1



# Generated at 2022-06-18 04:45:33.907776
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1

