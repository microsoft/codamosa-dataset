

# Generated at 2022-06-18 04:37:05.143516
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:11.049032
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:15.991521
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:17.962605
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 1

    class B(A):
        pass

    class C(B):
        pass

    assert A.x == 1
    assert B.x == 1
    assert C.x == 1



# Generated at 2022-06-18 04:37:26.859902
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:33.233657
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo called")
            return "foo"

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:37:37.738439
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    assert A.prop == 1
    assert A.prop == 1

    class B(A):
        pass

    assert B.prop == 1
    assert B.prop == 1



# Generated at 2022-06-18 04:37:40.587710
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:37:44.664544
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'



# Generated at 2022-06-18 04:37:49.890513
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2
    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:37:55.893327
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('called bar()')
            return 42

    assert Foo.bar == 42
    assert Foo.bar == 42



# Generated at 2022-06-18 04:38:00.682018
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:06.429442
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return 'B'

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:38:11.033316
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:38:15.263564
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:19.374539
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:22.341936
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:38:25.520755
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:30.182486
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return 2

    assert A.x == 1
    assert B.x == 2
    assert A.x == 1
    assert B.x == 2



# Generated at 2022-06-18 04:38:34.650591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1

    A.x = 2
    assert A.x == 2
    assert B.x == 1

    B.x = 3
    assert A.x == 2
    assert B.x == 3



# Generated at 2022-06-18 04:38:44.411747
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'



# Generated at 2022-06-18 04:38:50.523238
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:53.856517
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:38:57.419824
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Evaluating prop")
            return 42

    assert A.prop == 42
    assert A.prop == 42

    class B(A):
        pass

    assert B.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:39:00.849973
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'
    assert A.foo == 'bar'



# Generated at 2022-06-18 04:39:05.872984
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:39:11.656354
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:15.759781
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:39:21.944506
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:39:30.048700
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'
    assert B.foo == 'bar'

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'baz'

    assert C.foo == 'baz'
    assert C.foo == 'baz'
    assert A.foo == 'bar'
    assert A.foo == 'bar'



# Generated at 2022-06-18 04:39:42.025316
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:39:45.975536
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:39:51.612569
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'

# Generated at 2022-06-18 04:39:55.795092
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:03.047814
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:40:09.515221
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'cx'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'cx'
    assert A().x == 'x'
    assert B().x == 'x'
    assert C().x == 'cx'



# Generated at 2022-06-18 04:40:12.633635
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2


# Generated at 2022-06-18 04:40:15.793786
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:40:21.664373
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:26.401543
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:50.672653
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    class D(C):
        pass

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert D.x == 'C'



# Generated at 2022-06-18 04:40:57.362382
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 2

    assert A.prop == 1
    assert B.prop == 1
    assert C.prop == 2
    assert A.prop == 1
    assert B.prop == 1
    assert C.prop == 2



# Generated at 2022-06-18 04:41:00.943016
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo is B.foo



# Generated at 2022-06-18 04:41:06.344711
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:09.918861
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:14.740933
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("evaluating prop")
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42
    assert A.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:41:18.399726
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:41:23.743216
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:41:31.020896
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1
    B.x = 3
    assert A.x == 2
    assert B.x == 3



# Generated at 2022-06-18 04:41:36.142591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2
    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:42:24.948108
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("A.a")
            return 1

    class B(A):
        @lazyclassproperty
        def b(cls):
            print("B.b")
            return 2

    class C(A):
        @lazyclassproperty
        def a(cls):
            print("C.a")
            return 3

    assert A.a == 1
    assert B.a == 1
    assert B.b == 2
    assert C.a == 3



# Generated at 2022-06-18 04:42:31.466604
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:42:38.653671
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 'A'

    class B(A):
        @lazyperclassproperty
        def prop(cls):
            return 'B'

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 'C'

    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:42:45.767415
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Computing prop")
            return 42

    assert A.prop == 42
    assert A.prop == 42

    class B(A):
        pass

    assert B.prop == 42
    assert B.prop == 42

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("Computing prop")
            return 43

    assert C.prop == 43
    assert C.prop == 43

    assert A.prop == 42
    assert A.prop == 42

    assert B.prop == 42
    assert B.prop == 42



# Generated at 2022-06-18 04:42:48.649267
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:42:55.618578
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:43:01.720918
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2
    assert A().x == 1
    assert B().x == 1
    assert C().x == 2



# Generated at 2022-06-18 04:43:04.817229
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'



# Generated at 2022-06-18 04:43:08.493081
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 'test'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def test(cls):
            return 'test2'

    assert A.test == 'test'
    assert B.test == 'test'
    assert C.test == 'test2'



# Generated at 2022-06-18 04:43:14.194721
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:44:51.559882
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:44:56.227886
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:01.268502
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:05.698936
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert A.a is B.a



# Generated at 2022-06-18 04:45:10.891730
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.test == 'A'
    assert B.test == 'B'
    assert C.test == 'C'



# Generated at 2022-06-18 04:45:17.341091
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'

    A.foo = 'baz'
    assert A.foo == 'baz'
    assert B.foo == 'foo'
    assert C.foo == 'bar'

    B.foo = 'baz'
    assert A.foo == 'baz'
    assert B.foo == 'baz'
    assert C.foo == 'bar'

    C.foo = 'baz'

# Generated at 2022-06-18 04:45:20.274713
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'A'

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return 'B'

    class C(A):
        pass

    assert A.a == 'A'
    assert B.a == 'B'
    assert C.a == 'A'



# Generated at 2022-06-18 04:45:23.063902
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'

    class B(A):
        pass

    assert B.foo == 'bar'
    assert B.foo == 'bar'



# Generated at 2022-06-18 04:45:29.953125
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 'C'

    assert A.prop == 'A'
    assert B.prop == 'A'
    assert C.prop == 'C'



# Generated at 2022-06-18 04:45:34.287005
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1

