

# Generated at 2022-06-18 04:37:01.083845
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:37:06.628203
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            print('A.x')
            return 'A.x'

    class B(A):
        @lazyperclassproperty
        def x(cls):
            print('B.x')
            return 'B.x'

    class C(A):
        @lazyperclassproperty
        def x(cls):
            print('C.x')
            return 'C.x'

    assert A.x == 'A.x'
    assert B.x == 'B.x'
    assert C.x == 'C.x'



# Generated at 2022-06-18 04:37:11.262199
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42



# Generated at 2022-06-18 04:37:15.472490
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:37:24.263544
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return 'Base'

    class Derived(Base):
        pass

    assert Base.prop == 'Base'
    assert Derived.prop == 'Base'

    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return 'Base'

    class Derived(Base):
        @lazyperclassproperty
        def prop(cls):
            return 'Derived'

    assert Base.prop == 'Base'
    assert Derived.prop == 'Derived'



# Generated at 2022-06-18 04:37:27.776897
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:37:34.688785
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:37:38.738675
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:37:44.435564
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'
    assert A.foo == 'foo'

    class B(A):
        pass

    assert B.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:37:49.705835
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("prop")
            return "prop"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("prop2")
            return "prop2"

    assert A.prop == "prop"
    assert B.prop == "prop"
    assert C.prop == "prop2"



# Generated at 2022-06-18 04:37:56.077068
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:38:03.058017
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    assert A.a == 1
    assert A.a == 1

    class B(A):
        pass

    assert B.a == 1
    assert B.a == 1

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert C.a == 2
    assert C.a == 2

    assert A.a == 1
    assert A.a == 1

    assert B.a == 1
    assert B.a == 1



# Generated at 2022-06-18 04:38:06.277780
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('Computing prop')
            return 'prop'

    class B(A):
        pass

    assert A.prop == 'prop'
    assert B.prop == 'prop'



# Generated at 2022-06-18 04:38:09.245951
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:38:13.509648
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:38:17.079834
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2



# Generated at 2022-06-18 04:38:22.070056
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:26.071368
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'



# Generated at 2022-06-18 04:38:29.420183
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo == 42
    assert B.foo == 42



# Generated at 2022-06-18 04:38:33.149554
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1
    assert B.prop == 1



# Generated at 2022-06-18 04:38:42.604518
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return -1

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == -1



# Generated at 2022-06-18 04:38:48.113347
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:53.159835
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:38:56.771004
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:39:02.029751
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:39:07.850569
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:12.841808
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:16.149086
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:39:21.426136
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 2
    assert A.x == 2
    assert B.x == 1



# Generated at 2022-06-18 04:39:25.398197
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.test == 'A'
    assert B.test == 'B'



# Generated at 2022-06-18 04:39:38.977212
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:39:41.738278
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:39:45.108553
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:54.625036
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'

    class B(A):
        pass

    assert B.prop == 'value'
    assert B.prop == 'value'
    assert B.prop == 'value'

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return 'value2'

    assert C.prop == 'value2'
    assert C.prop == 'value2'
    assert C.prop == 'value2'

    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'

    assert B.prop == 'value'

# Generated at 2022-06-18 04:40:01.185694
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return "foo"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return "bar"

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "bar"



# Generated at 2022-06-18 04:40:05.077157
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    assert A.x == 1
    assert B.x == 1



# Generated at 2022-06-18 04:40:08.637181
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:40:12.511274
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is not B.foo



# Generated at 2022-06-18 04:40:16.157981
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'

    class B(A):
        pass

    assert B.prop == 'value'
    assert B.prop == 'value'



# Generated at 2022-06-18 04:40:22.117401
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:48.038338
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return 'b'

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    class D(B, C):
        pass

    assert A.a == 'a'
    assert B.a == 'b'
    assert C.a == 'c'
    assert D.a == 'b'



# Generated at 2022-06-18 04:40:52.735250
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return "prop"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return "prop_C"

    assert A.prop == "prop"
    assert B.prop == "prop"
    assert C.prop == "prop_C"



# Generated at 2022-06-18 04:40:58.945885
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return "bar"

    assert A.foo == "foo"
    assert B.foo == "foo"
    assert C.foo == "bar"



# Generated at 2022-06-18 04:41:03.104307
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:41:06.996345
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo == 'foo'



# Generated at 2022-06-18 04:41:11.128387
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return -1

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == -1
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == -1



# Generated at 2022-06-18 04:41:18.146795
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("A.x")
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            print("B.x")
            return 2

    class C(A):
        pass

    assert A.x == 1
    assert B.x == 2
    assert C.x == 1
    assert A().x == 1
    assert B().x == 2
    assert C().x == 1



# Generated at 2022-06-18 04:41:20.369360
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return "foo"

    class B(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "foo"



# Generated at 2022-06-18 04:41:24.013257
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:41:30.535367
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:42:17.245878
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:21.692423
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:42:23.870322
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:42:29.188211
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:34.525224
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 24

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 24



# Generated at 2022-06-18 04:42:39.883768
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:42:44.106416
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def test_property(cls):
            print("test_property is called")
            return "test_property"

    assert TestClass.test_property == "test_property"
    assert TestClass.test_property == "test_property"
    assert TestClass.test_property == "test_property"



# Generated at 2022-06-18 04:42:48.538908
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("bar")
            return "hello"

    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == "hello"



# Generated at 2022-06-18 04:42:51.150085
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert A.foo is B.foo



# Generated at 2022-06-18 04:42:58.077400
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:44:38.527487
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'a'

    assert A.a == 'a'
    assert A.a == 'a'
    assert A.a == 'a'

    class B(A):
        pass

    assert B.a == 'a'
    assert B.a == 'a'
    assert B.a == 'a'

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 'c'

    assert C.a == 'c'
    assert C.a == 'c'
    assert C.a == 'c'

    assert A.a == 'a'
    assert A.a == 'a'
    assert A.a == 'a'

    assert B.a == 'a'
    assert B

# Generated at 2022-06-18 04:44:42.063372
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 2

    assert A.prop == 1
    assert B.prop == 1
    assert C.prop == 2



# Generated at 2022-06-18 04:44:46.217059
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:44:51.559972
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:44:56.192110
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:45:00.110145
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:45:08.670411
# Unit test for function lazyperclassproperty

# Generated at 2022-06-18 04:45:11.645203
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:45:16.771906
# Unit test for function lazyperclassproperty

# Generated at 2022-06-18 04:45:18.579413
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'evaluated'

    assert A.prop == 'evaluated'
    assert A.prop == 'evaluated'

