

# Generated at 2022-06-18 04:37:03.697478
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'



# Generated at 2022-06-18 04:37:06.043372
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:37:10.107399
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:37:14.995593
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'



# Generated at 2022-06-18 04:37:19.522408
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'

    A.x = 'y'
    assert A.x == 'y'
    assert B.x == 'x'



# Generated at 2022-06-18 04:37:25.523817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-18 04:37:32.616347
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(B):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'

    A.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'foo'
    assert C.foo == 'foo'

    B.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert C.foo == 'foo'

    C.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert C.foo == 'bar'


# Unit

# Generated at 2022-06-18 04:37:37.865474
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:45.140282
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print('bar')
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:37:48.753859
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:37:57.599203
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("A.foo")
            return "foo"

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            print("B.foo")
            return "bar"

    class C(A):
        pass

    assert A.foo == "foo"
    assert B.foo == "bar"
    assert C.foo == "foo"



# Generated at 2022-06-18 04:38:02.453753
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            print("y")
            return 2

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2



# Generated at 2022-06-18 04:38:08.072380
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            print('A.x')
            return 'A.x'

    class B(A):
        @lazyperclassproperty
        def x(cls):
            print('B.x')
            return 'B.x'

    class C(A):
        pass

    assert A.x == 'A.x'
    assert B.x == 'B.x'
    assert C.x == 'A.x'



# Generated at 2022-06-18 04:38:10.572751
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:38:13.940627
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:38:18.581529
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    class D(C):
        pass

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'
    assert D.x == 'C'


# Generated at 2022-06-18 04:38:21.517195
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:38:24.689372
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:28.391063
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'


# Generated at 2022-06-18 04:38:31.577933
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:39.519809
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return "prop"

    class B(A):
        pass

    assert A.prop == "prop"
    assert B.prop == "prop"
    assert A.prop == "prop"
    assert B.prop == "prop"



# Generated at 2022-06-18 04:38:44.186068
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    assert A.x == 1
    assert B.x == 1



# Generated at 2022-06-18 04:38:47.787219
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'value'

    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-18 04:38:54.142100
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:38:58.163235
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:02.603160
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 1

    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1
    assert A.prop == 1



# Generated at 2022-06-18 04:39:08.718374
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:13.709548
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 'foo'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'



# Generated at 2022-06-18 04:39:15.896186
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'



# Generated at 2022-06-18 04:39:24.097818
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def a(cls):
            return 'c'

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'
    assert A().a == 'a'
    assert B().a == 'a'
    assert C().a == 'c'



# Generated at 2022-06-18 04:39:39.232100
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:39:43.430906
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'

    A.foo = 'bar'
    assert A.foo == 'bar'
    assert B.foo == 'foo'



# Generated at 2022-06-18 04:39:50.491535
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("A.foo")
            return "A.foo"

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            print("B.foo")
            return "B.foo"

    class C(A):
        pass

    assert A.foo == "A.foo"
    assert B.foo == "B.foo"
    assert C.foo == "A.foo"



# Generated at 2022-06-18 04:39:53.980280
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:40:00.827136
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    class D(C):
        pass

    assert A.a == 1
    assert B.a == 1
    assert C.a == 2
    assert D.a == 2


# Generated at 2022-06-18 04:40:05.840910
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:12.046100
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'C'

    class D(B, C):
        pass

    assert A.a == 'A'
    assert B.a == 'A'
    assert C.a == 'C'
    assert D.a == 'C'



# Generated at 2022-06-18 04:40:16.306247
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:40:19.772674
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:40:24.883772
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'C'



# Generated at 2022-06-18 04:40:48.469111
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'



# Generated at 2022-06-18 04:40:54.767169
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return cls

    assert A.prop is A
    assert A().prop is A

    class B(A):
        pass

    assert B.prop is B
    assert B().prop is B

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return cls

    assert C.prop is C
    assert C().prop is C

    class D(C):
        pass

    assert D.prop is D
    assert D().prop is D

    class E(C):
        @lazyclassproperty
        def prop(cls):
            return cls

    assert E.prop is E
    assert E().prop is E

    class F(E):
        pass

    assert F.prop is F


# Generated at 2022-06-18 04:41:00.053400
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return 'B'

    class C(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'A'



# Generated at 2022-06-18 04:41:05.029512
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('prop getter called')
            return 'the result'

    assert A.prop == 'the result'
    assert A.prop == 'the result'

    class B(A):
        pass

    assert B.prop == 'the result'
    assert B.prop == 'the result'



# Generated at 2022-06-18 04:41:12.209893
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:17.802835
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:22.973340
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:41:29.564451
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:41:33.598590
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:41:38.472808
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('Calculating')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            print('Calculating')
            return 43

    assert A.prop == 42
    assert B.prop == 42
    assert C.prop == 43
    assert A.prop == 42
    assert B.prop == 42
    assert C.prop == 43



# Generated at 2022-06-18 04:42:24.371766
# Unit test for function lazyclassproperty

# Generated at 2022-06-18 04:42:29.693115
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class Child(Base):
        pass

    class GrandChild(Child):
        pass

    assert Base.foo == 'Base'
    assert Child.foo == 'Child'
    assert GrandChild.foo == 'GrandChild'



# Generated at 2022-06-18 04:42:34.122991
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x


# Generated at 2022-06-18 04:42:39.414558
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1



# Generated at 2022-06-18 04:42:42.037564
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("Calculating bar")
            return 42

    assert Foo.bar == 42
    assert Foo.bar == 42



# Generated at 2022-06-18 04:42:49.014846
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'
    assert A.x == 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert B.x == 'x'

    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'

    assert C.x == 'y'
    assert C.x == 'y'

    assert A.x == 'x'
    assert A.x == 'x'

    assert B.x == 'x'
    assert B.x == 'x'



# Generated at 2022-06-18 04:42:55.986264
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:43:01.405676
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:43:07.097113
# Unit test for function lazyperclassproperty

# Generated at 2022-06-18 04:43:10.967630
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("A.foo called")
            return "A.foo"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("C.foo called")
            return "C.foo"

    class D(C):
        pass

    assert A.foo == "A.foo"
    assert B.foo == "A.foo"
    assert C.foo == "C.foo"
    assert D.foo == "C.foo"



# Generated at 2022-06-18 04:44:47.657039
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'
    assert A().a == 'a'
    assert B().a == 'a'
    assert C().a == 'c'


# Generated at 2022-06-18 04:44:52.277803
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:44:55.286128
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1



# Generated at 2022-06-18 04:44:58.995603
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert A.x is B.x



# Generated at 2022-06-18 04:45:02.904775
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-18 04:45:06.163923
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('prop')
            return 'prop'

    assert A.prop == 'prop'
    assert A.prop == 'prop'



# Generated at 2022-06-18 04:45:11.956776
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:45:25.551776
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert A.a == B.a



# Generated at 2022-06-18 04:45:32.452389
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'C'

    assert A.x == 'A'
    assert B.x == 'A'
    assert C.x == 'C'



# Generated at 2022-06-18 04:45:35.601371
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'

