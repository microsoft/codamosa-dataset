

# Generated at 2022-06-26 02:38:58.607914
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    start_time = time.time()
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)
    end_time = time.time()
    duration = end_time - start_time
    expected = 0
    assert expected == duration
    return True



# Generated at 2022-06-26 02:38:59.692015
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:39:02.705865
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Setup test case
    assert(hasattr(lazyclassproperty, '__call__'))

    try:
        test_case_0()
    except Exception:
        assert False, 'Unhandled exception raised.'



# Generated at 2022-06-26 02:39:07.326444
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """Check that lazyclassproperty works as expected"""
    class A(object):
        @lazyclassproperty
        def a(self):
            return 5
    assert A.a == 5


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:39:08.730852
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = lazyclassproperty(None)


# Generated at 2022-06-26 02:39:11.074358
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    global_var = False
    var = lazyperclassproperty(global_var)
    assert not var
    global_var = True
    assert var



# Generated at 2022-06-26 02:39:14.151089
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def func_0(arg_0):
        return arg_0

    bool_0 = True
    class_0 = lazyperclassproperty(func_0)
    var_0 = class_0

    assert True is class_0



# Generated at 2022-06-26 02:39:15.522837
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)


# Generated at 2022-06-26 02:39:20.021646
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
   
    try:
        test_case_0()
    except Exception as e:
        Assert.fail(
            "Failed to call function lazyclassproperty: " +
            str(e))


# Unit test execution
if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:39:26.299941
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Verify that the lazy property is not set yet
    bool_0 = False
    bool_1 = bool_0 is True
    assert bool_1

    # Verify expected output
    # Verify that the lazy property is set
    bool_0 = True
    bool_1 = bool_0 is True
    assert bool_1


# Generated at 2022-06-26 02:39:31.449242
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest
    import sys

    class TestSuite(unittest.TestCase):
        def test1(self):
            self.assertRaises(UnboundLocalError, test_case_0)

    unittest.main(argv=[sys.argv[0]])

# Generated at 2022-06-26 02:39:35.358110
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def _bool(): return False
    var_0 = lazyclassproperty(_bool)
    assert(var_0 == False)
    def _str(): return 'str'
    var_1 = lazyclassproperty(_str)
    assert(var_1 == 'str')
    def _float(): return float(10)
    var_2 = lazyclassproperty(_float)
    assert(var_2 == float(10))


# Generated at 2022-06-26 02:39:36.029185
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    var_0 = lazyperclassproperty(lambda: 4)

# Generated at 2022-06-26 02:39:39.129161
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # AssertionError: AttributeError not raised
    with pytest.raises(AssertionError):
        bool_0 = False
        var_0 = lazyperclassproperty(bool_0)


# Generated at 2022-06-26 02:39:40.347216
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty(test_case_0))


# Generated at 2022-06-26 02:39:44.520145
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert hasattr(lazyclassproperty, '__name__')


# Generated at 2022-06-26 02:39:49.312864
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test case 0
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)
    assert not var_0

    # Test case 1
    bool_1 = True
    var_1 = lazyclassproperty(bool_1)
    assert var_1


# Generated at 2022-06-26 02:40:01.294036
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test0:
        attr_0 = True

        @lazyclassproperty
        def attr_1(self):
            return self.attr_0
    assert Test0.attr_0 is True
    assert Test0.attr_1 is True

    class Test1(Test0):
        attr_0 = False
    assert Test1.attr_0 is False
    assert Test1.attr_1 is False
    assert Test0.attr_0 is True
    assert Test0.attr_1 is True

    class Test2:
        class Test2_1:
            attr_1 = True

            @lazyclassproperty
            def attr_2(self):
                return self.attr_1
        attr_1 = False

        @lazyclassproperty
        def attr_3(self):
            return self.attr

# Generated at 2022-06-26 02:40:03.827321
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)
    assert lazyclassproperty(bool)



# Generated at 2022-06-26 02:40:10.032406
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('called')
            return True

    class B(A):
        pass

    class C(A):
        pass

    foo_0 = A.foo
    foo_1 = B.foo
    foo_2 = C.foo



# Generated at 2022-06-26 02:40:15.556539
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test case template for lazyperclassproperty
    pass

# Generated at 2022-06-26 02:40:24.330087
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from copy import copy

    class Test(object):
        def __init__(self):
            self.value = 0
            self.__class__.value = copy(self.value)

        @lazyperclassproperty
        def value(cls):
            cls.value += 1
            return cls.value

    assert Test().value == 1
    assert Test().value == 2
    assert Test().value == 3
    assert Test().value == 4

    class Test1(Test):
        pass

    assert Test1().value == 1
    assert Test1().value == 2
    assert Test1().value == 3
    assert Test1().value == 4



# Generated at 2022-06-26 02:40:31.740522
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = True
    var_0 = lazyclassproperty(bool_0)
    var_1 = (bool_0)
    try:
        assert var_0 == var_1, 'var_0 == var_1'
    except AssertionError:
        raise AssertionError("unit test failed")


# Generated at 2022-06-26 02:40:35.389605
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:40:39.997136
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    obj = lazyclassproperty(bool)
    print("obj type: " + str(type(obj)))
    obj_1 = bool(obj)
    
#test_lazyclassproperty()


# Generated at 2022-06-26 02:40:42.982449
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    instance_0 = lazyclassproperty()
    assert callable(instance_0)
    instance_0 = lazyclassproperty()
    assert callable(instance_0)


# Generated at 2022-06-26 02:40:46.696804
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        bool_0 = False
        var_0 = lazyperclassproperty(bool_0)

    assert Foo.var_0 == False



# Generated at 2022-06-26 02:40:48.600251
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    lazyperclassproperty(bool_0)


# Generated at 2022-06-26 02:40:55.445254
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Call function lazyperclassproperty
    assert 'Expected type: <class \'function\'>, got: %s' % (type('Expected type: <class \'function\'>, got: %s'))
    assert 'Expected type: <class \'bool\'>, got: %s' % (type('Expected type: <class \'bool\'>, got: %s'))
    assert 'Expected type: <class \'bool\'>, got: %s' % (type('Expected type: <class \'bool\'>, got: %s'))
    assert 'Expected type: <class \'bool\'>, got: %s' % (type('Expected type: <class \'bool\'>, got: %s'))


# Generated at 2022-06-26 02:41:06.022454
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):

        @lazyperclassproperty
        def x(cls):
            print('Calculating for %s' % cls.__name__)
            return set([cls.__name__])

    class B(A):
        pass

    class C(A):
        pass

    print(A.x)
    print(B.x)
    print(C.x)

    assert C.x is not B.x
    assert A.x is not B.x
    assert A.x is not C.x
    assert A.x == set(['A'])
    assert B.x == set(['B'])
    assert C.x == set(['C'])

if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:41:21.810342
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = "lazyclassproperty"
    var_1 = False
    var_0 = lazyclassproperty(var_1)
    assert var_0.__name__ == '_lazy_False'
    assert type(var_0) == classproperty
    assert type(var_0(bool)) == bool


# Generated at 2022-06-26 02:41:28.948667
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        @lazyperclassproperty
        def myvar(cls):
            return 2

        @lazyperclassproperty
        def mylist(cls):
            return [1, 2, 3]

    # test inheritance
    class MyOtherClass(MyClass):
        pass

    mc = MyClass()
    moc = MyOtherClass()
    assert mc.myvar is moc.myvar
    assert mc.myvar == 2
    assert mc.myvar is moc.myvar
    assert moc.mylist is not mc.mylist
    assert moc.mylist == [1, 2, 3]
    assert mc.mylist == [1, 2, 3]
    assert moc.mylist is not mc.mylist



# Generated at 2022-06-26 02:41:34.128419
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class Bar(Foo):
        pass

    print(Foo.a)
    print(Bar.a)



# Generated at 2022-06-26 02:41:41.611242
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from pickle import loads, dumps
    
    d1 = lazyclassproperty(True)
    d2 = lazyclassproperty(lambda: True)
    
    assert d1(True) == d2(False)
    assert d1 == d2
    assert d1 is d2
    assert d1() == d2()
    assert d1(True) == d1(False)
    
    d1 = lazyclassproperty(lambda: True)
    d2 = lazyclassproperty(lambda: False)
    
    assert d1(True) != d2(False)
    assert d1 != d2
    assert d1 is not d2
    assert d1() != d2()
    
    d1pickle = dumps(d1)
    d2pickle = dumps(d2)
    
    assert len(d1pickle)

# Generated at 2022-06-26 02:41:48.280991
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)
    # Try to access lazy property.
    var_0


if __name__ == "__main__":
    # Load the test file from the command line
    try:
        filename = sys.argv[1]
    except IndexError:
        print("No filename specified. Cannot continue.")
        sys.exit(2)

    # Run the tests
    module_name = ".".join(filename.split(".")[:-1])
    testmod(module_name)


# EOF

# Generated at 2022-06-26 02:41:49.932672
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = True
    var_0 = lazyclassproperty(bool_0)
    assert var_0 == True



# Generated at 2022-06-26 02:41:55.865477
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("\n\n------------ Test lazyperclassproperty function ------------")
    res = lazyperclassproperty(test_case_0)
    print("Result:", res)
    assert callable(res)


if __name__ == '__main__':
    test_lazyperclassproperty()
    print("All tests passed!")

# Generated at 2022-06-26 02:41:59.388386
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def test_prop(self):
            return 1
    instance_1 = TestClass()
    assert instance_1.test_prop() == 1
    assert TestClass.test_prop() == 1


# Generated at 2022-06-26 02:42:05.576385
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    from .utils_test import TestCase

    class TestLazyClassProperty(TestCase):
        def test_lazyclassproperty(self):
            test_case_0()

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLazyClassProperty)
    return suite


# Generated at 2022-06-26 02:42:06.723152
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    result = lazyclassproperty(bool_0)
    assert result == expected_result



# Generated at 2022-06-26 02:42:32.593274
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import sys
    import inspect
    import unittest
    
    class TestLazyperclassproperty(unittest.TestCase):
        def test_module_presence(self):
            '''
            Test that the module is present in sys.modules
            '''
            self.assertIn("lazyperclassproperty", sys.modules)
        def test_function_present(self):
            '''
            Test that the function is present in the module
            '''
            module = sys.modules['lazyperclassproperty']
            self.assertIn("lazyperclassproperty", dir(module))
            self.assertEqual(type(module.lazyperclassproperty), type(lazyperclassproperty))

        def test_function_annotations(self):
            '''
            Test the function's annotations
            '''

# Generated at 2022-06-26 02:42:36.015211
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)
    return var_0

# Unit tests for class lazyperclassproperty

# Generated at 2022-06-26 02:42:37.471029
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)()



# Generated at 2022-06-26 02:42:39.651456
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)

# Generated at 2022-06-26 02:42:41.061987
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)

# Generated at 2022-06-26 02:42:46.349576
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def func(cls):
            return 100

    class A(Base):
        pass

    class B(Base):
        pass

    assert A.func == 100
    assert B.func == 100
    assert Base.func == 100


# Generated at 2022-06-26 02:42:50.401348
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass:
        @lazyperclassproperty
        def test(self):
            return 5 + 5

    class TestClass2(TestClass): pass

    assert TestClass.test == 10
    assert TestClass2.test == 10

# Generated at 2022-06-26 02:42:51.859599
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print(lazyclassproperty(False))


# Generated at 2022-06-26 02:42:57.550772
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # Delete function lazyclassproperty from memory.
    del lazyclassproperty

    # Assign function lazyclassproperty to variable test_lazyclassproperty.
    test_lazyclassproperty = lazyclassproperty

    try:
        test_lazyclassproperty()
    except NameError:
        var_0 = False
        assert var_0
    else:
        var_0 = True
        assert var_0


# Generated at 2022-06-26 02:42:58.841789
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:43:39.275792
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    def test_lazyclassproperty_exception(exception):
        if exception.args[0] != expected_exception:
            print("Expected exception: " + expected_exception + " but got " + exception.args[0])
            assert False

    class TestClass:

        @lazyclassproperty
        def get_lazyclassproperty(cls):
            return True

    # Define expected exception
    expected_exception = "NameError: name 'bool_0' is not defined"

    try:
        # Attempt to call function with incorrect arguments specified
        test_case_0()
    except NameError as exception:
        test_lazyclassproperty_exception(exception)

    assert TestClass.get_lazyclassproperty == True

# Unit test execution
if __name__ == '__main__':
    test_

# Generated at 2022-06-26 02:43:41.782375
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)


if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:43:49.229161
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):

        @lazyperclassproperty
        def instance_ct(cls):
            return 0

        def test(self):
            Test.instance_ct += 1
            print('Test.instance_ct=', Test.instance_ct)

    class SubTest(Test):
        pass

    t1 = Test()
    t2 = Test()
    st1 = SubTest()
    st2 = SubTest()

    t1.test()
    t2.test()
    st1.test()
    st2.test()



# Generated at 2022-06-26 02:43:58.160304
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("Test lazyperclassproperty")
    # Test function lazyperclassproperty
    # Initialize variables used for test
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)
    if isinstance(var_0, bool):
        print("Test 1 Passed")
    else:
        print("Test 1 Failed")



# Generated at 2022-06-26 02:44:09.269542
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test_lazyperclassproperty:
        def __init__(self, number):
            self.number = number

    class ClassA(Test_lazyperclassproperty):
        @lazyperclassproperty
        def test_lazy(cls):
            return "a"

    class ClassB(Test_lazyperclassproperty):
        @lazyperclassproperty
        def test_lazy(cls):
            return "b"

    class ClassC(Test_lazyperclassproperty):
        @lazyperclassproperty
        def test_lazy(cls):
            return "c"

    a = ClassA(1)
    b = ClassA(2)
    c = ClassB(3)
    d = ClassB(4)
    e = ClassC(5)
    f = ClassC(6)

# Generated at 2022-06-26 02:44:14.156077
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    a = lazyclassproperty(lambda: 1)
    b = lazyclassproperty(lambda: 2)
    def f():
        return 'X'
    c = lazyclassproperty(f)

    assert a() == a()
    assert a() == 1
    assert b() == 2
    assert c() == c()
    assert c() == f() == 'X'



# Generated at 2022-06-26 02:44:15.111329
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:44:18.371569
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class First:
        @lazyperclassproperty
        def a(self):
            return "First"
    assert First().a == "First"
    class Second(First):
        pass
    assert Second().a == "First"



# Generated at 2022-06-26 02:44:19.496494
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty == 0


# Generated at 2022-06-26 02:44:24.463351
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestObject:
        _test_value = None

        @lazyperclassproperty
        def generate_test_value(cls):
            return 'test' + str(cls.__name__)

    class TestSubObject(TestObject):
        pass

    assert TestObject.generate_test_value == 'testTestObject'
    assert TestSubObject.generate_test_value == 'testTestSubObject'



# Generated at 2022-06-26 02:44:54.369485
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import test_utils
    import pytest
    testcase_0 = test_utils.TestCase(test_case_0)
    testcase_0.run_tests()



# Generated at 2022-06-26 02:44:56.512867
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    @lazyclassproperty
    def foo(self):
        return 'Foo'

    assert foo == 'Foo'
    assert foo == 'Foo'

# Generated at 2022-06-26 02:44:57.914168
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)



# Generated at 2022-06-26 02:45:00.890168
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    bool_1 = False
    bool_0 = lazyclassproperty(bool_1)
    bool_0 = True
    bool_1 = True
    assert(bool_0 == bool_1)


# Generated at 2022-06-26 02:45:02.755619
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)
    

# Generated at 2022-06-26 02:45:03.651353
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)

# Generated at 2022-06-26 02:45:05.412957
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import builtins
    # Replace the builtin property with the decorator instance
    builtins.property = lazyclassproperty


# Generated at 2022-06-26 02:45:06.099079
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)


# Generated at 2022-06-26 02:45:10.146798
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Eliminate traceback outputs
    sys.tracebacklimit = 0

    # Arguments
    bool_0 = True
    var_0 = lazyclassproperty(bool_0)
    string_0 = "lazyclassproperty"
    var_1 = lazyclassproperty(string_0)
    # Unit test
    assert (var_0 == var_1) == var_0 == var_1



# Generated at 2022-06-26 02:45:12.156509
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    try:
        lazyperclassproperty(False)
    except AssertionError:
        pass
    # AssertionError: Argument must be callable


# Generated at 2022-06-26 02:46:08.873207
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    value = lazyperclassproperty(lambda cls: 'lazy' + str(cls))
    assert(value == 'lazytest_lazyperclassproperty.<locals>.Test')


# Generated at 2022-06-26 02:46:16.002492
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Create a variable named test_case_0 from class <class '__main__.test_lazyclassproperty'>
    test_case_0 = test_lazyclassproperty
    # Declare variables
    bool_0 = False
    # Obtain variable test_case_0 from class <class '__main__.test_lazyclassproperty'>
    var_0 = test_case_0.bool_0
    # Assert statement
    assert test_case_0.bool_0(var_0) is var_0
    # Obtain variable test_case_0 from class <class '__main__.tes

# Generated at 2022-06-26 02:46:19.619466
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test for lazyclassproperty with bool type input
    assert lazyclassproperty(True) == True, 'lazyclassproperty(True) should return True'
    assert lazyclassproperty(False) == False, 'lazyclassproperty(False) should return False'



# Generated at 2022-06-26 02:46:21.667317
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Testing 0
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)



# Generated at 2022-06-26 02:46:23.529537
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = True
    var_0 = lazyclassproperty(bool_0)

# Generated at 2022-06-26 02:46:26.722502
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def function_0(param_0):
        return True

    # Test the case where the function is a lambda
    lazyperclassproperty(lambda: True)
    # Test the case where the function is a function
    lazyperclassproperty(function_0)



# Generated at 2022-06-26 02:46:27.954871
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)

# Generated at 2022-06-26 02:46:33.086195
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Remove exisiting records from test file
    with open('./dypro/logs/test_lazyclassproperty.log', 'w'):
        pass
    test_case_0()
    # Check for records
    with open('./dypro/logs/test_lazyclassproperty.log') as logfile:
        assert len(logfile.read()) == 0

if __name__ == '__main__':
    # Run the test function
    test_lazyclassproperty()

# Generated at 2022-06-26 02:46:34.288662
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)



# Generated at 2022-06-26 02:46:37.626139
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)


# Generated at 2022-06-26 02:48:36.176811
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    foo = 'foo'
    bar = 'bar'
    var_0 = 'abc'
    class_0 = type('class_0', (object,), {'lazyperclassproperty_fn': lazyperclassproperty(foo)})
    class_1 = type('class_1', (class_0,), {'lazyperclassproperty_fn': lazyperclassproperty(bar)})

    assert class_0.lazyperclassproperty_fn == 'foo'
    assert class_1.lazyperclassproperty_fn == 'bar'

    class_0.lazyperclassproperty_fn = var_0
    assert class_0.lazyperclassproperty_fn == var_0
    assert class_1.lazyperclassproperty_fn == 'bar'



# Generated at 2022-06-26 02:48:37.139241
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)


# Generated at 2022-06-26 02:48:38.663151
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Call function lazyclassproperty
    test_case_0()


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:48:40.061033
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    var_0 = lazyperclassproperty(bool_0)


# Generated at 2022-06-26 02:48:41.158895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # TODO: Write unit test
    pass


# Generated at 2022-06-26 02:48:45.815484
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test_lazyperclassproperty(unittest.TestCase):
        def test_case_0(self):
            test_instance = Test_lazyperclassproperty()
            test_instance.assertIsNotNone(test_case_0)

    test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-26 02:48:47.005348
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    var_0 = lazyclassproperty(bool_0)


# Generated at 2022-06-26 02:48:53.140549
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class T(object):
        @lazyperclassproperty
        def a(cls):
            print("a")
            return 'a'

    class U(T):
        @lazyperclassproperty
        def a(cls):
            print("b")
            return 'b'

    class V(U):
        @lazyperclassproperty
        def a(cls):
            print("c")
            return 'c'
