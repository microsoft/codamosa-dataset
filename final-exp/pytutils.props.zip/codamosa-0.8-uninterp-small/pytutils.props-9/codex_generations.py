

# Generated at 2022-06-26 02:38:56.869359
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:39:01.490094
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for function lazyclassproperty.
    """
    import random

    def add(x):
        def decorator(fn):
            return lazyclassproperty(fn) + x
        return decorator

    @add(100)
    def f():
        return random.random()

    assert f + 10 == 110



# Generated at 2022-06-26 02:39:09.024289
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def __init__(self):
            self.counter = 0

        @lazyclassproperty
        def assert_one(cls):
            self.counter += 1
            cls.counter += 1
            # checking that the property is called only once per class
            assert cls.counter == 1
            assert self.counter == 1

    class FooChild(Foo):
        pass

    try:
        Foo.assert_one
    except AttributeError:
        return True



# Generated at 2022-06-26 02:39:17.687730
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass_0():
        @lazyclassproperty
        def random_int(cls):
            return random.randint(100, 300)

        @lazyclassproperty
        def random_int_2(cls):
            return random.randint(400, 600)

    assert TestClass_0.random_int == TestClass_0.random_int, "Expected random_int == random_int, but got random_int = %s and random_int = %s" % (TestClass_0.random_int, TestClass_0.random_int)

# Generated at 2022-06-26 02:39:20.415164
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert isinstance(lazyperclassproperty(test_case_0), lazyperclassproperty)
    assert lazyperclassproperty(test_case_0) is not None


# Generated at 2022-06-26 02:39:25.061519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = "\n    Lazy/Cached class property that stores separate instances per class/inheritor so there's no overlap.\n    "
    test_case_0()


# Generated at 2022-06-26 02:39:25.680818
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True


# Generated at 2022-06-26 02:39:33.739631
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = "\n    Lazy/Cached class property that stores separate instances per class/inheritor so there's no overlap.\n    "
    setterproperty_0 = setterproperty(str_0)
    class Base:
        def __init__(self):
            self.cls = None

        def test(self):
            self.cls = type(self)

    class Derived(Base):
        @lazyperclassproperty
        def prop(cls):
            instance = cls()
            instance.test()
            return instance

    assert Base().prop.cls == Base
    assert Derived().prop.cls == Derived

test_lazyclassproperty()

if __name__ == '__main__':
    print('Test passed!')

# Generated at 2022-06-26 02:39:37.470292
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = "\n    Lazy/Cached class property.\n    "
    setterproperty_0 = setterproperty(str_0)
    return

# Generated at 2022-06-26 02:39:40.790519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = "\n    Lazy/Cached class property that stores separate instances per class/inheritor so there's no overlap.\n    "
    setterproperty_0 = setterproperty(str_0)

# Generated at 2022-06-26 02:39:55.259221
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    log = logging.getLogger('test_lazyperclassproperty.py')
    log.info('*** Start test_lazyperclassproperty ***')
    log.info('*** End test_lazyperclassproperty ***\n')

# Execute the tests above

# Generated at 2022-06-26 02:39:56.548250
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty


# Generated at 2022-06-26 02:39:59.212721
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    global int_0
    global var_0
    int_0 = 0
    var_0 = lazyperclassproperty(int_0)



# Generated at 2022-06-26 02:40:03.354752
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert isinstance(lazyclassproperty, object)
    assert lazyclassproperty.__doc__ == 'Lazy/Cached class property. '


# Generated at 2022-06-26 02:40:05.958912
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    int_0 = 0
    var_0 = lazyperclassproperty(int_0)
    pass

# Generated at 2022-06-26 02:40:07.683951
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    int_0 = 0
    var_0 = lazyperclassproperty(int_0)
    assert var_0 == int_0

# Generated at 2022-06-26 02:40:19.382738
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import inspect
    import sys
    import types

    class DummyClass:
        def __init__(self):
            self.var2 = 3

        @lazyclassproperty
        def var(cls):
            print("lazytest1")
            a = 1
            return a

        @property
        def var3(self):
            print("lazytest2")
            return 4

        @classproperty
        def var5(cls):
            print("lazytest3")
            return 7

    d = DummyClass()
    assert d.var is DummyClass.var
    assert DummyClass.var == 1
    assert DummyClass.var == 1
    assert DummyClass.var == 1
    assert d.var3 == 4
    assert d.var3 == 4

# Generated at 2022-06-26 02:40:22.557414
# Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:40:26.630668
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def prop(self_0):
        return "foo"
    assert prop == "foo"



# Generated at 2022-06-26 02:40:32.191361
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_func():
        pass

    class TestClass(object):
        """
        Test class docstring
        """

        def test_func(self):
            pass

        test_prop = lazyclassproperty(test_func)

    assert TestClass.test_prop is TestClass.test_prop


# Generated at 2022-06-26 02:40:40.215168
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    int_0 = 0
    var_0 = lazyperclassproperty(int_0)


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:44.473312
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(0)() == 0
    assert lazyclassproperty(int)("0") == 0
    assert not lazyclassproperty(bool)("")
    assert (lazyclassproperty(str)(0) == "0")
    assert lazyclassproperty(4) == 4
    assert (lazyclassproperty(str)(False) == "False")


# Generated at 2022-06-26 02:40:47.093099
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("Testing lazyperclassproperty")
    Tester.run(test_case_0)



# Generated at 2022-06-26 02:40:51.851888
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Init
    @lazyclassproperty
    def int_0(x):
        return 1
    var_0 = int_0

    # Assert type
    assert variable_type_match(var_0, int)


# Generated at 2022-06-26 02:40:52.818741
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-26 02:41:02.901254
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def foo(cls):
            print('called foo()')
            return 'foo'

    class Bar(Foo):
        pass

    a = Foo()
    print(a.foo)
    print(a.foo)
    print(a.foo)

    b = Bar()
    print(b.foo)
    print(b.foo)
    print(b.foo)

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:41:09.416911
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Testing function lazyperclassproperty')
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('cls', cls.__name__)
            return 42

    a = A()
    print('a.foo', a.foo)
    b = A()
    print('b.foo', b.foo)

    class B:
        @classproperty
        def foo(cls):
            print('foo')
            return 42

    print(Vars(B.foo))
    print(Vars(A.foo))

    class C:
        @classmethod
        def foo(cls):
            print('foo')
            return 42

    print(Vars(C.foo))

    class D(A):
        pass

    d = D()

# Generated at 2022-06-26 02:41:11.784929
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    int_0 = 0
    var_0 = lazyclassproperty(int_0)


# Generated at 2022-06-26 02:41:13.669038
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty().__name__ == 'lazyclassproperty'

# Generated at 2022-06-26 02:41:16.624481
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def bar(cls):
            return cls



# Generated at 2022-06-26 02:41:25.152282
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert(True)



# Generated at 2022-06-26 02:41:35.495247
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty('int_0') == \
"    @classproperty\n    def _lazyclassprop(cls):\n        attr_name = '_%s_lazy_%s' % (cls.__name__, fn.__name__)\n        if not hasattr(cls, attr_name):\n            setattr(cls, attr_name, fn(cls))\n        return getattr(cls, attr_name)\n"


# Generated at 2022-06-26 02:41:41.658363
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    logger = logging.getLogger(__name__)

    class Dummy(object):
        @lazyclassproperty
        def lazyclassproperty(cls):
            return cls.__name__

        def dummymethod(self):
            logger.info('%s' % self.lazyclassproperty)

    d = Dummy()
    d.dummymethod()
    d2 = Dummy()
    d2.dummymethod()



# Generated at 2022-06-26 02:41:42.598680
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)

# Generated at 2022-06-26 02:41:45.716050
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = type
    var_1 = lazyclassproperty(var_0)
    var_2 = lazyclassproperty(var_0)

    if var_2 == var_1:
        return 1
    else:
        return 0


# Generated at 2022-06-26 02:41:53.370787
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test the case where there is no doc returned.

    var_0 = lazyclassproperty()
    var_0 = lazyclassproperty('')
    var_0 = lazyclassproperty(False)
    var_0 = lazyclassproperty(True)
    var_0 = lazyclassproperty(0)
    var_0 = lazyclassproperty(None)

    # Test the case where there is a doc returned.

    var_0 = lazyclassproperty('a')
    var_0 = lazyclassproperty('abc')
    var_0 = lazyclassproperty('a\nb\nc')
    var_0 = lazyclassproperty('0123456789')
    var_0 = lazyclassproperty('012345678901234')
    var_0 = lazyclassproperty('012345678901234567890123456789012345')


# Generated at 2022-06-26 02:42:00.045570
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """Test for lazyclassproperty"""
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    from pycotap import TAPTestRunner
    suite = doctest.DocTestSuite()
    suite.addTest(doctest.DocTestSuite(lazyclassproperty))
    TAPTestRunner().run(suite)

# Generated at 2022-06-26 02:42:08.053138
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Properties:
        def __init__(self):
            self.var_0 = 0
            self.var_1 = 1
            self.var_2 = 2
            self.var_3 = 3
            self.var_4 = 4

        @lazyclassproperty
        def lazyprop(self):
            return self.var_1 + self.var_2 + self.var_3 + self.var_4
    instance = Properties()
    if instance.lazyprop == 10:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:42:13.174876
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """Performs unit tests for :func:`lazyperclassproperty`."""
    import unittest
    import xx

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.str_0 = "str_0"
            self.str_1 = "str_1"
            self.lazyperclassproperty = lazyperclassproperty(self.str_0)

        def test_getter_0(self):
            # Test that it caches.
            self.assertIs(self.lazyperclassproperty, "str_0")
            self.assertIs(self.lazyperclassproperty, "str_0")

        def test_getter_1(self):
            # Test that it is lazy.
            self.assertIsNot(self.lazyperclassproperty, "str_1")

# Generated at 2022-06-26 02:42:15.444814
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # FIXME: Add tests for lazyclassproperty

    # Performs unit test for lazyclassproperty
    assert True == True # TODO: may be wrong spot


# Generated at 2022-06-26 02:42:32.772497
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0) == test_case_0

# Generated at 2022-06-26 02:42:44.963246
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class test():
        i = 0
        @lazyperclassproperty
        def perclass(cls):
            cls.i += 1
            return 'classname: %s' % cls.__name__
        @classproperty
        def perclass2(cls):
            cls.i += 1
            return 'classname: %s' % cls.__name__

    class test_1(test):
        pass

    class test_2(test):
        pass

    class test_3(test_1):
        pass

    t1 = test()
    t2 = test_1()
    t3 = test_2()
    t4 = test_3()
    assert t1.perclass == t1.perclass == 'classname: test'

# Generated at 2022-06-26 02:42:47.779143
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()
    return


if __name__ == '__main__':
    import sys
    sys.exit(test_lazyperclassproperty())

# Generated at 2022-06-26 02:42:50.471711
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def func1():
        print("func1")

    property_value = lazyclassproperty(func1)
    property_value()


# Generated at 2022-06-26 02:43:00.688553
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Dummy:
        def __init__(self, x):
            self.x = x

        @learning_rate.getter
        def learning_rate(self):
            return self._learning_rate

        @learning_rate.setter
        def learning_rate(self, value):
            self._learning_rate = value

        @classmethod
        def get_learning_rate(cls):
            return cls._learning_rate

        @lazyperclassproperty
        def learning_rate(cls):
            return cls.get_learning_rate()

        def get_bias(self):
            return self._bias

        @lazyperclassproperty
        def bias(cls):
            return cls.get_bias()

    assert Dummy.learning_rate
    assert Dummy.bias



# Generated at 2022-06-26 02:43:02.842296
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Pause system on completion
    """
    print('Testing lazyperclassproperty()')
    test_case_0()
    input('Press Enter to continue...')


# Generated at 2022-06-26 02:43:04.126214
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = lazyclassproperty(list)
    pass


# Generated at 2022-06-26 02:43:13.488538
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from dsrg_generator.classes.auto_dsrg import BaseAutoDSRG
    from dsrg_generator.classes.ms_dsrg import MSAutoDSRG
    from dsrg_generator.classes.pt_dsrg import PTAutoDSRG

    BaseAutoDSRG._ms_dsrg = lazyperclassproperty(MSAutoDSRG)
    BaseAutoDSRG._pt_dsrg = lazyperclassproperty(PTAutoDSRG)
    assert id(BaseAutoDSRG._ms_dsrg) != id(MSAutoDSRG)
    assert id(BaseAutoDSRG._pt_dsrg) != id(PTAutoDSRG)

    MSAutoDSRG._pt_dsrg = lazyclassproperty(PTAutoDSRG)

# Generated at 2022-06-26 02:43:14.317620
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty(0))

# Generated at 2022-06-26 02:43:15.474935
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass  # TODO: implement your test here


# Generated at 2022-06-26 02:43:52.337373
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class cls_0:
        @lazyperclassproperty
        def attr_0(cls):
            return 0
    assert cls_0.attr_0 == 0
    class cls_0:
        pass
    assert cls_0.attr_0 == 0
    class cls_0:
        @lazyperclassproperty
        def attr_0(cls):
            return 1
    assert cls_0.attr_0 == 0

# Compiled code for function lazyperclassproperty
# Used by code in test_case_0

# Generated at 2022-06-26 02:43:54.455236
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:43:55.304003
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty) == True



# Generated at 2022-06-26 02:44:00.657244
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    int_0 = 0
    var_0 = lazyperclassproperty(int_0)

# Generated at 2022-06-26 02:44:11.003224
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from collections import namedtuple
    from types import MethodType
    from unittest import TestCase

    class Base(object):
        @lazyclassproperty
        def value(cls):
            return 42

    class Child(Base):
        pass

    base_value = Base.value
    child_value = Child.value
    assert base_value == 42
    assert child_value == 42
    assert base_value is not child_value
    assert Base.__dict__['value'].__get__(None, Base) is base_value
    assert Child.__dict__['value'].__get__(None, Child) is child_value
    assert '_lazy_value' in Base.__dict__
    assert '_lazy_value' in Child.__dict__
    assert 'value' not in Base.__dict__
   

# Generated at 2022-06-26 02:44:22.043602
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    cfg_data = {'log_level':'DEBUG', 'log_format':'[%(asctime)s] %(levelname)s in %(module)s: %(message)s'}
    @lazyclassproperty
    def config(cls):
        return cfg_data
    @lazyclassproperty
    def config_file(cls):
        return config.get('config_file')
    config_file1 = config_file
    cfg_data['log_level'] = 'ERROR'
    config_file2 = config_file

    assert config_file1 == '/tmp/utils.json'
    assert config_file2 == '/tmp/utils.json'
    config_file_str = str(config_file)
    assert config_file_str == '/tmp/utils.json'



# Generated at 2022-06-26 02:44:23.504813
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def prop_0(cls):
            nonlocal var_0
            var_0 = 'unit'
            return var_0

    class TestSubclass(Test): pass

    assert Test().prop_0 == TestSubclass().prop_0 == 'unit'



# Generated at 2022-06-26 02:44:27.643261
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = 'name1'
    str_1 = 'name2'
    var_0 = lazyclassproperty(str_0)
    assert var_0 == 'name1' == lazyclassproperty(str_1)
    assert var_0 is lazyclassproperty(str_0)


if __name__ == '__main__':
    import sys
    sys.exit(int(test_lazyclassproperty() < 0))

# Generated at 2022-06-26 02:44:29.171415
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class_0 = LazyClassTest()
    assert class_0.lazy_per_class == 0



# Generated at 2022-06-26 02:44:38.975856
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    This is just a test function for the lazyclassproperty function
    """

    class Base(object):
        def check_value(self, other):
            if self is other:
                return 'identical'
            else:
                return 'not identical'

        @lazyclassproperty
        def value(cls):
            return cls()

    class Test(Base):
        pass

    class Test2(Base):
        pass

    class Test3(Base):
        @lazyclassproperty
        def value(cls):
            return cls()

    assert Test.value.check_value(Test.value) == 'identical'
    assert Test.value.check_value(Test2.value) == 'not identical'
    assert Test3.value.check_value(Test3.value) == 'identical'

# Generated at 2022-06-26 02:45:55.364734
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from collections import namedtuple

    Person = namedtuple('Person', 'id name')

    class Base(object):
        @lazyperclassproperty
        def persons(cls):
            return [Person(1, 'Person 1'), Person(2, 'Person 2')]

    class A(Base):
        pass

    class B(Base):
        @lazyperclassproperty
        def persons(cls):
            return [Person(3, 'Person 3'), Person(4, 'Person 4')]

    a = A()
    b = B()
    assert A.persons == [Person(1, 'Person 1'), Person(2, 'Person 2')]
    assert a.persons == [Person(1, 'Person 1'), Person(2, 'Person 2')]

# Generated at 2022-06-26 02:46:00.216210
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Testing function lazyperclassproperty')

    #
    # Test class C0
    #

    class C0:
        def __init__(self):
            pass

        @lazyperclassproperty
        def _lazy1(cls):
            return 1

        @lazyperclassproperty
        def _lazy2(cls):
            return cls._lazy1

    class C1(C0):
        @lazyperclassproperty
        def _lazy1(cls):
            return 2

    if C0._lazy1 != 1:
        raise AssertionError(
            "Expected %(expected)s, got %(actual)s" % {
                'expected': 1,
                'actual': C0._lazy1,
            }
        )


# Generated at 2022-06-26 02:46:06.666612
# Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:46:08.473418
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Container(object):
        @lazyclassproperty
        def _foo(self):
            return "bar"


# Generated at 2022-06-26 02:46:12.884368
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X:
        @lazyclassproperty
        def y(cls):
            return 'yay!'

    class Y(X):
        pass

    assert X.y == 'yay!'
    assert Y.y == 'yay!'


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:46:15.741118
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        pass

    class B(A):
        pass

    a = A()
    b = B()

    @lazyperclassproperty
    def var_0(cls):
        return None



# Generated at 2022-06-26 02:46:22.705775
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def var_0(cls):
            print('var_0')
            return True

    assert A.var_0 is True
    A.var_0 = False
    assert A.var_0 is False

    class B(A):
        @lazyclassproperty
        def var_0(cls):
            print('var_0')
            return False

    assert B.var_0 is False
    B.var_0 = True
    assert B.var_0 is True

test_lazyclassproperty()



# Generated at 2022-06-26 02:46:29.573058
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    class TestClass(object):
        def test_method(self):
            return 0
        lazyclass_method = lazyclassproperty(test_method)
    class TestClass2(TestClass): pass
    class TestCase(unittest.TestCase):
        def test_lazy(self):
            self.failUnlessEqual(TestClass.lazyclass_method, 0)
            self.failUnlessEqual(TestClass2.lazyclass_method, 0)
    unittest.main()

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-26 02:46:31.523576
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    int_0 = 0
    var_0 = lazyclassproperty(int_0)


# Generated at 2022-06-26 02:46:35.861139
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Initialize otj_0 of class TestClass
    otj_0 = TestClass()
    TestClass.var_0 = TestClass.int_0()

    # Test that method int_0 of class TestClass was called
    assert TestClass.var_0 == 42

    # Unit test for function lazyperclassproperty