

# Generated at 2022-06-26 02:39:08.072811
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def x(cls):
            return "I'm lazy"

        @lazyclassproperty
        def y(cls):
            return "I'm lazy too"

    assert Test.__dict__['_lazy_x'] is None
    assert Test.__dict__['_lazy_y'] is None
    assert Test.x == "I'm lazy"
    assert Test.y == "I'm lazy too"
    assert Test.__dict__['_lazy_x'] == "I'm lazy"
    assert Test.__dict__['_lazy_y'] == "I'm lazy too"
    del Test.x
    del Test.y
    assert Test.__dict__['_lazy_x'] is None
    assert Test.__dict__['_lazy_y']

# Generated at 2022-06-26 02:39:13.374468
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        @lazyclassproperty
        def test_property(cls):
            print("***generating***")
            return cls.__name__

    print(TestClass.test_property)
    print(TestClass.test_property)

    TestClass2 = type("TestClass2", (TestClass,), {})

    print(TestClass2.test_property)



# Generated at 2022-06-26 02:39:17.195282
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('Unit test for function lazyclassproperty')

    class A(object):
        @lazyperclassproperty
        def value(cls):
            return 1
        @classproperty
        def value2(cls):
            return 2
    a = A()
    assert a.value2 is 2
    assert a.__class__.value is 1

# Generated at 2022-06-26 02:39:20.369716
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)

# Generated at 2022-06-26 02:39:27.035288
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def __init__(self, value):
            self.value = value
        @lazyclassproperty
        def foo(cls):
            return cls(1)
    assert A.foo.value == 1
    assert A.foo.value == 1
    assert A.foo.value == 1
    assert A.foo.value == 1


# Generated at 2022-06-26 02:39:28.337537
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True, "Function lazyperclassproperty did not work as expected"


# Generated at 2022-06-26 02:39:33.406029
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)


# Generated at 2022-06-26 02:39:39.073267
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = (b'\x06\x9fQ\x82\x8b\xb1\x93\xaf', 'subtract to get: 0x137')
    print('Start!')
    test_case_0()
    print('Done!')

# Test for lazyclassproperty
if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:39:43.236522
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)
    print( "type(var_0): %s" % type(var_0) )
    print( "type(var_0.__dict__): %s" % type(var_0.__dict__) )


# Generated at 2022-06-26 02:39:45.204528
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """Check lazyclassproperty works"""
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 1

    assert A.prop == 1
    assert A().prop == 1



# Generated at 2022-06-26 02:39:55.139044
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyperclassproperty
        def bar(self):
            return "bar"
        def __init__(self):
            self.baz = "baz"

    foo = Foo()
    assert foo.bar == "bar"
    foo2 = Foo()
    foo2.baz = "baz"
    assert foo2.bar == "bar"


# Generated at 2022-06-26 02:40:00.064837
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        pass

    class B(A):
        pass

    #@lazyclassproperty
    @lazyperclassproperty
    def var_x(cls):
        return len(cls.__name__)

    print(A.var_x)
    print(B.var_x)



# Generated at 2022-06-26 02:40:01.050915
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:40:08.770486
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        @lazyclassproperty
        def test_class_property(cls):
            return "Hi, I'm a lazy class property"

    assert TestClass.test_class_property == "Hi, I'm a lazy class property"
    assert TestClass.test_class_property == "Hi, I'm a lazy class property"



# Generated at 2022-06-26 02:40:17.989215
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def __init__(self):
            return 6
        @lazyclassproperty
        def foo(cls):
            return 7

    a = Foo()
    print(a.foo)
    print(Foo.foo)
    Foo.foo = 4
    print(a.foo)
    print(Foo.foo)
    print(a.__dict__)
    print(Foo.__dict__)

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-26 02:40:22.956965
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Tests for usage of @lazyclassproperty decorator
    """

    class A(object):

        @lazyclassproperty
        def B(cls):
            return cls.C * 2

        @property
        def C(self):
            return 3

    assert A.B == 6

# Generated at 2022-06-26 02:40:32.718021
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random
    class ClassA(object):
        def _calculate_value(cls):
            return random.random()
        val = lazyclassproperty(_calculate_value)

    class ClassB(ClassA):
        pass

    lcprop1 = ClassA.val
    lcprop2 = ClassA.val
    lcprop3 = ClassB.val
    lcprop4 = ClassB.val

    # assert lcprop1 == lcprop2
    # assert lcprop3 != lcprop4



# Generated at 2022-06-26 02:40:44.893842
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test 1: ensure same instance is returned
    class P(object):
        @lazyclassproperty
        def test(cls):
            return 'foobar'
    assert P.test == 'foobar'
    assert P.test == 'foobar'

    class Q(P):
        pass

    assert Q.test == 'foobar'
    assert Q.test == 'foobar'

    # Test 2: different class, different instance
    class P(object):
        @lazyclassproperty
        def test(cls):
            return 'foobar'

    class R(object):
        @lazyclassproperty
        def test(cls):
            return 'baz'

    assert P.test == 'foobar'
    assert P.test == 'foobar'
    assert R.test == 'baz'
    assert R

# Generated at 2022-06-26 02:40:46.369729
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert test_case_0()  is None



# Generated at 2022-06-26 02:40:52.573030
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert Test.foo == 'bar'

    # class attributes are not shared among subclasses
    class TestSub(Test):
        pass

    assert TestSub.foo == 'bar'

    # but instances are not affected either
    assert TestSub().foo == 'bar'



# Generated at 2022-06-26 02:41:01.737557
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)



# Generated at 2022-06-26 02:41:05.081204
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import logging, random

    logging.basicConfig(level=logging.DEBUG)
    #logging.basicConfig(level=logging.INFO)
    logging.info("Test case 0")

    test_case_0()

if __name__ == '__main__':
    import sys
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:41:07.671012
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-26 02:41:14.537925
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)
    bytes_1 = b'\xb2\xb2\x82\x91\xbb\x8d\xc0'
    var_1 = lazyperclassproperty(bytes_1)
    assert var_0 != var_1


# Generated at 2022-06-26 02:41:27.344647
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_3 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf\x86\x91\xc4p\xce6\xf4\x1e\x14\x02\x8d\x15\xce\x16\x1cQ'
    var_3 = lazyclassproperty(bytes_3)

    bytes_4 = b'\x03\x13\xf7\x9e\x065\x0c\x8d\x96\xce\xc2'
    var_4 = lazyclassproperty(bytes_4)

    bytes_5 = b'\x04\x1e\x0c\xc2\x9d\r\x96\x19\xfe\xf0\x16\x99\x03'


# Generated at 2022-06-26 02:41:35.390517
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random

    def lazyprop():
        return random.choice(range(10000))

    def lazyperclassprop():
        return random.choice(range(10000))

    class Test(object):
        a = lazyclassproperty(lazyprop)
        b = lazyperclassproperty(lazyperclassprop)

    t = Test()
    for i in range(1000):
        t.a
        t.b


# Generated at 2022-06-26 02:41:42.163970
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    in0 = b'\x0b\xcc\x8d\xb2\x9f\x89\x12\x13'
    out0 = lazyperclassproperty(in0)
    expected_out0 = in0
    assert out0 == expected_out0

    in1 = b'\x9c\x85e\xfaC\xaf\xf3\x1b'
    out1 = lazyperclassproperty(in1)
    expected_out1 = in1
    assert out1 == expected_out1

    in2 = b'\xea\x1c\xd8\x0e\x04\x03\x86\x14'
    out2 = lazyperclassproperty(in2)
    expected_out2 = in2
    assert out2 == expected_out2


# Generated at 2022-06-26 02:41:47.792017
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)
    bytes_1 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_1 = lazyperclassproperty(bytes_1)
    assert(var_0 == var_1)


# Generated at 2022-06-26 02:41:48.482935
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:41:55.274855
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __str__(self):
            return 'a: %s, b: %s' % (self.a, self.b)
        @lazyclassproperty
        def test(cls):
            return A(1, 2)

        @lazyperclassproperty
        def test_perclass(cls):
            return A(1, 2)

    a = A(0, 0)
    print(a.test)

    b = A(0, 1)
    print(b.test)

    c = A(1, 0)
    print(c.test)

    print('--------')
    a = A(0, 0)
    print(a.test_perclass)

# Generated at 2022-06-26 02:42:05.617646
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    try:
        test_case_0()
    except Exception:
        pass



if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:07.462085
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test function without argument
    assert test_case_0() is None
    # Test function with argument
    # assert test_case_1() == 'Tested'



# Generated at 2022-06-26 02:42:10.128284
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_1 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_1 = lazyclassproperty(bytes_1)
    return var_1


# Generated at 2022-06-26 02:42:14.220007
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def attr_a(cls):
            return 1

    class B(A):
        pass

    assert A.attr_a == 1
    assert B.attr_a == 1



# Generated at 2022-06-26 02:42:18.901570
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)
    assert type(var_0) == lazyclassproperty


# Generated at 2022-06-26 02:42:23.623114
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class clazz_0(object):
        def __init__(self):
            return
    
        bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
        var_0 = lazyperclassproperty(bytes_0)
    
        def method_0(self):
            return self.var_0



# Generated at 2022-06-26 02:42:24.492353
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:42:32.772840
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from random import random
    from unittest import main, TestCase, TestLoader
    import logging
    import sys

    logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s', level=logging.DEBUG, stream=sys.stdout)

    class Derived(TestCase):
        @lazyperclassproperty
        def f(cls):
            return random()

        def test_f(self):
            self.assertTrue(self.f == self.f, "value returned from lazyperclassproperty should be equal to itself")

    test_suite = TestLoader().loadTestsFromTestCase(Derived)
    main()



# Generated at 2022-06-26 02:42:33.781930
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True

# Generated at 2022-06-26 02:42:36.973614
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert bytes_0 == b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'


# Test for lazyperclassproperty(fn) -> function lazypeclassprop

# Generated at 2022-06-26 02:42:56.371570
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)

test_case_0()

# Generated at 2022-06-26 02:42:57.342848
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:43:05.512256
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test for:
    - var_1
    - var_2
    - var_3
    - var_4
    """
    bytes_1 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_1 = lazyperclassproperty(bytes_1)
    assert var_1._lazyclassprop == b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_2 = lazyperclassproperty(b'\x06\x9fQ\x82\x8b\xb1\x93\xaf')
    assert var_2._lazyclassprop == b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'


# Generated at 2022-06-26 02:43:07.392587
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import types

    test_case_0()
    assert type(test_case_0.var_0) == types.FunctionType



# Generated at 2022-06-26 02:43:08.720949
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)



# Generated at 2022-06-26 02:43:19.895037
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # First, we define a class
    class class_0(object):
        # Then we define a class property
        @lazyperclassproperty
        def prop_0(cls):
            return int(42)

    # Checking if the property is lazy
    assert not hasattr(class_0, "_class_0_lazy_prop_0")

    # Checking if, after it's called, the attribute is created in `class_0` class
    assert class_0.prop_0 == 42
    # If a class property is defined, it should be present in the class
    assert hasattr(class_0, "_class_0_lazy_prop_0")

    # Let's define a new class, inheriting from class_0
    class class_1(class_0):
        pass

    # class_1 should not have any attribute related to

# Generated at 2022-06-26 02:43:20.851375
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty is not None


# Generated at 2022-06-26 02:43:21.766531
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:43:26.969299
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)
    assert var_0 == b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_1 = lazyperclassproperty(bytes_0)
    assert var_1 == b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'



# Generated at 2022-06-26 02:43:37.842238
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for lazyclassproperty.
    """
    # Test non-lazy class property.
    class ExampleClass(object):

        value = 5

        @lazyclassproperty
        def lazy_prop(cls):
            return cls.value

    e = ExampleClass()
    assert e.value == 5
    assert e.lazy_prop == 5
    # After changing value, lazy property should return new value as well.
    ExampleClass.value = 10
    assert e.value == 10
    assert e.lazy_prop == 10
    # Test lazyclassproperty
    class ExampleClass(object):

        value = 5

        @lazyperclassproperty
        def lazy_prop(cls):
            return cls.value

    e = ExampleClass()
    assert e.value == 5
    assert e.lazy_

# Generated at 2022-06-26 02:44:15.004375
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


if __name__ == "__main__":
    if __package__ is None:
        import os, sys
        parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
        sys.path.insert(0, parent_dir)
        __package__ = 'KubernetesHelpers'

    from .kubernetes_helpers import simple_long_to_ip

    simple_long_to_ip(0x9f06)

# Generated at 2022-06-26 02:44:24.430794
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    with open('src/fixed_struct.py') as f:
        rl_iter = f.readline()
        while rl_iter:
            rl_iter = f.readline()
            if rl_iter.startswith('# Unit test for function lazyperclassproperty'):
                break

        assert callable(lazyperclassproperty)
        print('lazyperclassproperty 1 ok')

    with open('src/fixed_struct.py') as f:
        rl_iter = f.readline()
        while rl_iter:
            rl_iter = f.readline()
            if rl_iter.startswith('# Unit test for function lazyclassproperty'):
                break

        assert callable(lazyclassproperty)
        print('lazyclassproperty 1 ok')


# Generated at 2022-06-26 02:44:26.186434
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    try:
        assert test_case_0()
    except Exception as e:
        raise e

# Generated at 2022-06-26 02:44:27.328460
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert bytes_0 == lazyperclassproperty(bytes_0)


# Generated at 2022-06-26 02:44:28.540896
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert isinstance(1, int) is True
    assert 1 == 1



# Generated at 2022-06-26 02:44:38.325404
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def assert_pass(lazyperclassproperty, input, result):
        assert result == lazyperclassproperty(input)

    def assert_exception(lazyperclassproperty, input, result):
        try:
            lazyperclassproperty(input)
        except:
            pass
        else:
            assert False

    # Arrange

    # Act
    # Assert
    assert_pass(test_case_0, bytes_0, b'\x06\x9fQ\x82\x8b\xb1\x93\xaf')
    assert_pass(test_case_0, bytes_0, b'\x06\x9fQ\x82\x8b\xb1\x93\xaf')

# Generated at 2022-06-26 02:44:40.197775
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty.__name__ == 'lazyclassproperty'
    assert lazyclassproperty.__doc__ == '\n    Lazy/Cached class property.\n    '

# Generated at 2022-06-26 02:44:43.515737
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:44:44.298847
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:44:47.336001
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        return get_random_string()

    assert 'foo' not in globals()
    assert foo == foo
    assert foo != bar

# Generated at 2022-06-26 02:45:55.049280
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(str) == str


# Generated at 2022-06-26 02:45:56.053667
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test the function
    test_case_0()



# Generated at 2022-06-26 02:46:00.546790
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)
    test_lazyclassproperty.__dict__.__setitem__('stypy_localization', localization)
    test_lazyclassproperty.__dict__.__setitem__('stypy_type_of_self', type_of_self)
    test_lazyclassproperty.__dict__.__setitem__('stypy_type_store', module_type_store)
    test_lazyclassproperty.__dict__.__setitem__('stypy_function_name', 'test_lazyclassproperty')

# Generated at 2022-06-26 02:46:01.450591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty([])

# Generated at 2022-06-26 02:46:04.699913
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:46:06.988621
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)



# Generated at 2022-06-26 02:46:09.726799
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from collections import namedtuple

    class MyClass(object):
        @lazyperclassproperty
        def test(cls):
            return namedtuple('test', 'test')

    assert MyClass.test is object.test



# Generated at 2022-06-26 02:46:19.543519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import random
    import __main__

    class Test_Class_0:
        pass

    class Test_Class_1:
        pass

    class Test_Class_2:
        pass

    obj_0 = Test_Class_0()
    obj_1 = Test_Class_1()
    obj_2 = Test_Class_2()

    # Test normal property
    obj_0.int_0 = random.randint(0, 1000)
    assert obj_1.int_0 is None
    assert obj_2.int_0 is None

    # Test lazyperclass property
    Test_Class_0.lazy_int_0 = lazyperclassproperty(lambda: random.randint(0, 1000))

# Generated at 2022-06-26 02:46:21.929767
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyclassproperty(bytes_0)

# Generated at 2022-06-26 02:46:24.495944
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def _myfunc(cls):
        return cls

    lazyclassproperty(_myfunc)

    def _myfunc(cls):
        return cls

    lazyclassproperty(_myfunc)(int)



# Generated at 2022-06-26 02:48:48.387249
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    TestClass = type('TestClass', (object,), {})
    TestClass2 = type('TestClass2', (object,), {})
    var_0 = lazyperclassproperty(TestClass)
    TestClass.var_0 = var_0
    TestClass2.var_0 = var_0
    assert TestClass.var_0 is not TestClass2.var_0


# Generated at 2022-06-26 02:48:56.051277
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b'\x06\x9fQ\x82\x8b\xb1\x93\xaf'
    var_0 = lazyperclassproperty(bytes_0)
    bytes_1 = b'\xa4\x91m"\x0e\x8d\xae'
    var_1 = lazyperclassproperty(bytes_1)
    bytes_2 = b'\x84\x91\x81p\x19\x0f\xe4\xfa'
    var_2 = lazyperclassproperty(bytes_2)
    bytes_3 = b"\x9c\xd9\xeb\x95\x0c'\xb8\x1b"
    var_3 = lazyperclassproperty(bytes_3)