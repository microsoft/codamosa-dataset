

# Generated at 2022-06-26 02:39:00.057944
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b"\xfeJy\xfaR&\x9c(1,\x04\x12\xad'"
    var_0 = lazyclassproperty(bytes_0)


# Generated at 2022-06-26 02:39:01.024690
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:39:02.987067
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:39:07.473824
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_0 = b"\xfeJy\xfaR&\x9c(1,\x04\x12\xad'"
    var_0 = lazyperclassproperty(bytes_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:39:08.893442
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:39:09.948271
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:39:15.506614
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty
    # Place your code here
    assert True # "Fail message"


if __name__ == "__main__":
    import sys
    import nose
    # This code will run under nose, so we can save the program's
    # command line arguments and pass in our specific testcase.
    save_argv = sys.argv
    sys.argv = [__file__, '-v']
    nose.main()
    sys.argv = save_argv

# Generated at 2022-06-26 02:39:18.645128
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b"\xfeJy\xfaR&\x9c(1,\x04\x12\xad'"
    assert lazyclassproperty(bytes_0)()

test_lazyclassproperty()


# Generated at 2022-06-26 02:39:20.216215
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('Testing function lazyclassproperty')
    test_case_0()


# Generated at 2022-06-26 02:39:21.265372
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True


# Generated at 2022-06-26 02:39:32.461392
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)
    # Test model class.
    class TestModel(object):

        num = 0

        @lazyclassproperty
        def test(cls):
            cls.num += 1
            return cls.num

    # Subclass model class.
    class SubTestModel(TestModel):
        pass

    # Test lazyclassproperty
    assert TestModel.test == 1
    assert TestModel.test == 2
    assert SubTestModel.test == 1
    assert SubTestModel.test == 2

    # Test lazyperclassproperty
    class A(object):
        x = 1

        @lazyperclassproperty
        def value(cls):
            return cls.x

    class B(A):
        x = 2

    class C(A):
        pass

    assert A.value == 1

# Generated at 2022-06-26 02:39:35.451843
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
    var_0 = lazyclassproperty(bytes_0)


# Generated at 2022-06-26 02:39:40.784974
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class TestLazyClassProperty(unittest.TestCase):
        def test_normal(self):
            class A:
                def __init__(self, n):
                    self.n = n

                @lazyclassproperty
                def prop(cls):
                    return cls.n + 1

            class B(A):pass

            class C(A):pass

            a = A(1)
            self.assertEqual(a.prop, 2)
            self.assertEqual(A.prop, 2)

            b = B(1)
            self.assertEqual(b.prop, 2)
            self.assertEqual(B.prop, 2)

            c = C(1)
            self.assertEqual(c.prop, 2)

# Generated at 2022-06-26 02:39:51.779193
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    aux_lazyperclassproperty = lazyperclassproperty(bytes_0)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_1)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_2)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_3)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_4)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_5)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_6)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_7)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_8)
    aux_lazyperclassproperty = lazyperclassproperty(bytes_9)


# Generated at 2022-06-26 02:40:02.423783
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """Test for lazyclassproperty"""

    def test_lazyclassproperty_run(cls):
        return {'lazy_var_1': 1}

    class Test0(object):
        var_1 = lazyclassproperty(test_lazyclassproperty_run)

    assert Test0.var_1 == {'lazy_var_1': 1}
    assert Test0.var_1 == {'lazy_var_1': 1}

    def test_lazyclassproperty_run_2(cls):
        return {'lazy_var_2': 2}

    class Test1(object):
        var_2 = lazyclassproperty(test_lazyclassproperty_run_2)

    assert Test1.var_2 == {'lazy_var_2': 2}

# Generated at 2022-06-26 02:40:09.325004
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        def f(cls):
            return "hello, world"
        f = lazyclassproperty(f)

    class D(C):
        pass

    assert C.f == C.f
    assert D.f == D.f
    assert C.f == "hello, world"
    assert D.f == "hello, world"

# Generated at 2022-06-26 02:40:13.010036
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()

# Generated at 2022-06-26 02:40:14.159819
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert(True)


# Generated at 2022-06-26 02:40:23.268953
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):
        def __init__(self):
            self.foo = 123

        @lazyclassproperty
        def foo(cls):
            return cls.__name__

        @lazyperclassproperty
        def bar(cls):
            return cls.__name__ + '1'

        @roclassproperty
        def baz(cls):
            return cls.__name__ + '2'

    a = Foo()
    b = Foo()
    assert Foo.foo == 'Foo'
    assert Foo.bar == 'Foo1'
    assert Foo.baz == 'Foo2'
    assert a.foo == 'Foo'
    assert a.bar == 'Foo1'
    assert b.foo == 'Foo'
    assert b.bar == 'Foo1'



# Generated at 2022-06-26 02:40:25.187570
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:40:37.147139
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        pass

    @lazyclassproperty
    def foo(cls):
        return 'foo'

    assert hasattr(Foo, 'foo')
    assert Foo.foo == 'foo'

    class Bar(Foo):
        pass

    assert hasattr(Bar, 'foo')
    assert Bar.foo == 'foo'

    # Make sure the attribute is not set on the parent class
    assert not hasattr(Foo, '_lazy_foo')

    # Make sure the attribute is not set on the inheritor class
    assert not hasattr(Bar, '_lazy_foo')

    # Make sure the attribute is only retrieved once,
    # even though we accessed it twice
    assert Foo._lazy_foo is Foo._lazy_foo



# Generated at 2022-06-26 02:40:42.224270
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Class0(object):
        pass

    class Class1(object):
        pass

    @lazyclassproperty
    def bytes_0():
        return b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'

    def _test():
        assert Class0.bytes_0 == Class1.bytes_0

        Class0.bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
        assert Class0.bytes_0 == Class1.bytes_0


# Generated at 2022-06-26 02:40:48.381066
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass():
        @lazyclassproperty
        def do_stuff(cls):
            return cls.get_something()

        @classmethod
        def get_something(cls):
            print('doing stuff')
            return 42

    assert TestClass.do_stuff == 42
    assert TestClass.do_stuff == 42

# Generated at 2022-06-26 02:40:53.862006
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    x = lazyperclassproperty(lambda: None)
    x = lazyperclassproperty(lambda: '')
    x = lazyperclassproperty(lambda: [])
    x = lazyperclassproperty(lambda: ())
    x = lazyperclassproperty(lambda: {})
    # x = lazyperclassproperty(str.upper)
    # x = lazyperclassproperty(bytes.hex)
    test_case_0()

test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:55.830000
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:41:06.174381
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @property
        def prop(self):
            pass

    f = Foo()
    assert isinstance(f.prop, property)

    class Bar:
        @lazyclassproperty
        def prop(cls):
            return "prop"

    bar = Bar()
    assert bar.prop == "prop"

    class Foo(object):
        def __init__(self):
            self._prop = None

        @property
        def prop(self):
            # This is the getter.
            return self._prop

        @prop.setter
        def prop(self, value):
            # This is the setter.
            self._prop = value

        @prop.deleter
        def prop(self):
            # This is the deleter.
            del self._prop

    foo = Foo()

# Generated at 2022-06-26 02:41:07.543162
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True == True



# Generated at 2022-06-26 02:41:08.860791
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True


# Generated at 2022-06-26 02:41:10.334627
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True

if __name__== "__main__":
    test_lazyperclassproperty()
    print('Test passed')

# Generated at 2022-06-26 02:41:16.047361
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class foo(object):
        @lazyperclassproperty
        def bar(cls):
            return 456
    class foo2(object):
        @lazyperclassproperty
        def bar(cls):
            return 789

    assert foo.bar == 456
    assert foo.bar == 456
    assert foo2.bar == 789
    assert foo2.bar == 789

    foo.bar = 123
    foo2.bar = 456

    assert foo.bar == 123
    assert foo2.bar == 456



# Generated at 2022-06-26 02:41:28.608620
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        def __init__(self):
            self.value = "Hello world"

        @lazyclassproperty
        def property_with_decorator(cls):
            return cls.value

        def property_without_decorator(cls):
            return cls.value

    test_class = TestClass()

    def test_decorated():
        test_class.property_with_decorator

    def test_function():
        test_class.property_without_decorator

    expected_with_decorator = 600
    expected_without_decorator = 1

    assert timeit(test_decorated, number=100000).microseconds == expected_with_decorator
    assert timeit(test_function, number=100000).microseconds == expected_without_decorator

# Generated at 2022-06-26 02:41:38.300956
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        def __init__(self):
            self.__dom_child_nodes = []

        @lazyclassproperty
        def test_lazyclassproperty(self):
            print('get the value')
            return self.__dom_child_nodes

        @test_lazyclassproperty.setter
        def test_lazyclassproperty(self, value):
            print('set the value')
            self.__dom_child_nodes = value

    test_class = TestClass()
    test_class.test_lazyclassproperty = [1, 2, 3]
    print(test_class.test_lazyclassproperty)


# Generated at 2022-06-26 02:41:46.597113
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def lazy_property(_):
        bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
        return bytes_0

    class Test(object):
        lazy_property = lazy_property

    var_1 = Test()
    assert var_1.lazy_property == b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'


# Generated at 2022-06-26 02:41:49.837537
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def examples(cls):
        x = 0
        while True:
            yield x
            x += 1
    assert C().lazyclassproperty == 0
    assert C().lazyclassproperty == 0
    assert C().lazyclassproperty == 0


# Generated at 2022-06-26 02:41:54.697257
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_fn():
        return 'Hello World!'

    class Test(object):

        @lazyclassproperty
        def my_prop(cls):
            return test_fn()

    t = Test()
    assert Test.my_prop == 'Hello World!'
    assert t.my_prop == 'Hello World!'


# Generated at 2022-06-26 02:41:57.127865
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    var_0 = lazyperclassproperty(bytes_0)


# Generated at 2022-06-26 02:42:03.489322
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    try:
        import __sklib__.skUnitTest as skut
    except ImportError as e:
        print(e)
        print('Unable to import skUnitTest, aborting unit test')
        return False
    else:
        u = skut.skUnitTest('Testing lazyclassproperty')
        u.setUp()

        class A(object):
            @lazyclassproperty
            def x(cls):
                return 3

        class B(A):
            pass

        class C(B):
            pass

        class D(A):
            pass

        u.assertEqual(A.x, 3, 'First lazyclassproperty get should assign value')
        u.assertEqual(B.x, 3, 'Second lazyclassproperty get (inherit) should fetch value')

# Generated at 2022-06-26 02:42:03.990132
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True


# Generated at 2022-06-26 02:42:05.100961
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for function call
    test_case_0()



# Generated at 2022-06-26 02:42:11.260534
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Create a test class
    class TestClass:

        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.counter = 0

        @lazyperclassproperty
        def mult(self):
            # lazyperclassproperty is not creating a new instance every time. It's only created once. We check that by
            # increasing the counter every time the function is called. If the instance is destroyed and recreated
            # then it'll start from zero.
            self.counter += 1
            return self.a * self.b

    # Create three instances of the class
    # Instances are created with different values for a and b
    test_obj_1 = TestClass(2, 3)
    test_obj_2 = TestClass(4, 5)

# Generated at 2022-06-26 02:42:27.802107
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass



# Generated at 2022-06-26 02:42:30.647977
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    with test_support.captured_stdout() as stdout:
        test_case_0()

    output = stdout.getvalue().strip()
    assert output == 'None', "Test #0 Failed: Wrong output: {0}".format(output)

if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:35.325584
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'
    assert Foo.foo == 'foo'
    Foo.foo = 'bar'
    assert Foo.foo == 'foo'
    class FooChild(Foo):
        @lazyclassproperty
        def bar(cls):
            return 'bar'
    assert FooChild.foo == 'foo'
    FooChild.foo = 'baz'
    assert FooChild.foo == 'foo'
    assert FooChild.bar == 'bar'
    FooChild.bar = 'baz'
    assert FooChild.bar == 'bar'


# Generated at 2022-06-26 02:42:39.684329
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from random import randint
    class Testing(object):
        def __init__(self, name):
            self.name = name
        @lazyclassproperty
        def random_value(cls):
            return randint(0, 100)
    assert Testing.random_value == 42

# Generated at 2022-06-26 02:42:47.274595
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            print("Test called")
            return 111

    a = A()
    assert a.test == 111

    class B(A):
        pass

    b = B()
    assert b.test == 111

    class C(B):
        @lazyperclassproperty
        def test(cls):
            print("test C")
            return 222

    c = C()
    assert c.test == 222



# Generated at 2022-06-26 02:42:49.879099
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for function lazyclassproperty
    """
    assert False, "Test case not implemented"


# Generated at 2022-06-26 02:42:51.261228
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:42:55.890240
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def value(cls):
            return 'value'

    assert C.value == 'value'
    assert C.__dict__ == {'value': 'value'}
    assert C.__class__.__dict__ == {'value': 'value'}

# Generated at 2022-06-26 02:42:56.878946
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert test_case_0() == None

# Generated at 2022-06-26 02:43:01.702790
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random
    import string

    class TestClass(object):
        @lazyclassproperty
        def random_string(cls):
            return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(3))

    assert TestClass.random_string == TestClass.random_string
    assert TestClass.random_string != TestClass().random_string



# Generated at 2022-06-26 02:43:40.413696
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase
    class myclass(object):

        @lazyclassproperty
        def prop1(cls):
            return 'prop1'

        @lazyclassproperty
        def prop2(cls):
            return 'prop2'

    class subclasstest(myclass):
        pass

    class subclasstest2(subclasstest):
        pass

    class Testlazyclassproperty(TestCase):
        def test_lazyclassproperty(self):
            self.assertEqual(myclass.prop1, 'prop1')
            self.assertEqual(myclass.prop2, 'prop2')
            # check if lazyclassproperty works with inheritance
            self.assertEqual(subclasstest.prop1, 'prop1')

# Generated at 2022-06-26 02:43:45.733773
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
    var_0 = lazyclassproperty(bytes_0)


# Generated at 2022-06-26 02:43:49.229406
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    if _test_lazyperclassproperty:
        test_case_0()
        return
    _test_lazyperclassproperty = True

# main function
if (__name__ == '__main__'):
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:43:58.149316
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Dog(object):
        @lazyclassproperty
        def bark(cls):
            print('bark')
            return "woof woof"

    assert isinstance(Dog.bark, property)
    assert Dog.bark is not None
    assert Dog.bark == "woof woof"



# Generated at 2022-06-26 02:44:09.257210
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # dummy class to hold the function
    class testclass:
        def __init__(self):
            pass

    class TestClass(object):
        """Test class for lazyclassproperty decorator"""
        # This property is lazy, so there's a little extra work to it
        # It's called foo.
        foo = lazyclassproperty(id)

        # This property is not lazy.
        # It's called bar.
        @property
        def bar(self):
            return id(self)

    # instantiate the testclass
    c = TestClass()

    # run the methods
    foo = c.foo
    bar = c.bar

    # check if it was successful
    print(foo)
    print(bar)

    # check if it was a method from module
    assert isinstance(foo, type(id))
    assert isinstance

# Generated at 2022-06-26 02:44:14.515048
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = lazyclassproperty(bytes)
    bytes_0 = b'=\xc2\xa2\xa9\x9e\x81\xbf\xfc\xb3\x1e\xc4\x04\xc8\x06\x9d\x12\x0b\x92\xa6M'
    assert var_0(bytes_0) == '=Â¢©ž¿ü±.Ä.È.œ\x12\x0b\x92¦M'


# Generated at 2022-06-26 02:44:17.151634
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert(callable(lazyperclassproperty))


if __name__ == '__main__':
    import pytest
    pytest.main(args=['.'])

# Generated at 2022-06-26 02:44:18.052348
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(None) == None



# Generated at 2022-06-26 02:44:23.819999
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Input:')
    func = bytes_0
    print('{}'.format(func))
    instance = var_0
    print('Output:')
    print('{}'.format(instance))
    var_1 = lazyperclassproperty(bytes_0)

    print('Input:')
    func = bytes_0
    print('{}'.format(func))
    instance = var_1
    print('Output:')
    print('{}'.format(instance))



# Generated at 2022-06-26 02:44:26.811635
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = b'\x8c\x10\x80\x87\xbf\x8b\x91\xcd\xd05\xc7\xf8\x08*\xef'
    var_0 = lazyclassproperty(bytes_0)


# Generated at 2022-06-26 02:45:35.315303
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()
    print('PASS')

if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:45:38.043238
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def p(cls):
            return 'hello'

    assert C.p == 'hello'


# Generated at 2022-06-26 02:45:48.510635
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_case_0():
        bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
        var_0 = lazyperclassproperty(bytes_0)
    def test_case_1():
        bytes_0 = b'\xd4\xcf\x1a\xbd\x90\xfe\xb6\x0f\xabR\x11\xc5\xb3\xe6\xaa+\xcf'
        var_1 = lazyperclassproperty(bytes_0)

# Generated at 2022-06-26 02:45:53.353997
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def random(cls):
            return random.random()
    assert A.random == A.random
    class B(A):
        pass
    assert B.random == B.random
    assert A.random != B.random
    class C(A):
        @lazyclassproperty
        def random(cls):
            return random.random()
    assert A.random != C.random
    assert B.random != C.random

# Generated at 2022-06-26 02:45:54.643931
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    result = test_case_0()
    assert(result == None)
    print("Test Result is Successful")



# Generated at 2022-06-26 02:45:59.891089
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test lazyperclassproperty
    """
    from random import randint as rand
    from types import ClassType
    from time import time
    from time import sleep
    from re import compile as re_compile
    var_1 = re_compile('^def __init__\\(self, l=None\\)')
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    var_6 = 0
    var_7 = 0
    var_8 = 0
    var_9 = 0
    var_10 = 0
    var_11 = 0
    var_12 = 0
    var_13 = 0
    var_14 = 0
    var_15 = 0
    var_16 = 0
    var_17 = 0
    var_18 = 0
    var

# Generated at 2022-06-26 02:46:03.950394
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bytes_1 = b'W\x92\xbd`\x93\xd9E\x8a\xe0;\x9b\xdc\x94\x8e'
    var_1 = lazyperclassproperty(bytes_1)
    assert var_1 == lazyperclassproperty(bytes_1)



# Generated at 2022-06-26 02:46:07.761611
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import sys
    import random

    class A(object):
        @lazyclassproperty
        def rand(cls):
            print("in randgetter")
            return random.random()

    def test():
        print(sys.version_info)
        print(A.__dict__)
        print(A.rand)
        print(A.rand)
        print(A())

    test()
    test()
    test()



# Generated at 2022-06-26 02:46:11.855087
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """This test is for test_lazyclassproperty"""
    bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
    var_0 = lazyclassproperty(bytes_0)


# Generated at 2022-06-26 02:46:21.507881
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # if __name__ == "__main__":
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            "I am the bar property."
            print('First reference to bar property in class: %s' % cls.__name__)
            return "bar"
        @lazyclassproperty
        def bar2(cls):
            "I am the bar2 property."
            print('First reference to bar2 property in class: %s' % cls.__name__)
            return "bar2"

    class Bar(Foo):
        pass

    class FooBar(Foo):
        pass

    # First time, prints a message
    # print(Foo.bar)    # 'First reference to bar property in class: Foo'
    # 'First reference to bar2 property in class: Foo'

# Generated at 2022-06-26 02:48:43.250184
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class TestCase(unittest.TestCase):
        def test_lazyclassproperty(self):
            bytes_0 = b'W\x92\xbd`\x93\xd9E\xc2\xb9\x11^\xae\xdd\xdb=\x13\x82\xa7'
            var_0 = lazyclassproperty(bytes_0)

# Generated at 2022-06-26 02:48:45.332687
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Call test_case_0
    assert test_case_0() == None

# Generated at 2022-06-26 02:48:52.762246
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    num_var = 5

    @lazyclassproperty
    def num():
        return 5

    @lazyperclassproperty
    def num():
        return 5

    assert num == num_var
    assert test_lazyclassproperty.num == num_var
    assert test_lazyclassproperty.num == num_var
    assert test_lazyclassproperty.num == num_var
    assert test_lazyclassproperty.num == num_var

    from sys import getrefcount
    assert getrefcount(num) == 3
    assert getrefcount(test_lazyclassproperty.num) == 3

    class A(object):
        pass

    class B(A):
        pass

    assert A.num == num_var
    assert getrefcount(A.num) == 3
    assert B.num == num_var
   

# Generated at 2022-06-26 02:48:53.540261
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:48:56.303583
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    attr_name = '_lazy_property'
    assert hasattr(decorators, attr_name) == False
    assert decorators.lazy_property() == 42
    assert hasattr(decorators, attr_name) == True
    assert decorators.lazy_property() == 42
