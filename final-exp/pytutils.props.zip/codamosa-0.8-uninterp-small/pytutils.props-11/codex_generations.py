

# Generated at 2022-06-26 02:38:56.122305
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def foo()-> int:
        return 9
    assert foo() == 9
    assert lazyclassproperty(foo)



# Generated at 2022-06-26 02:39:00.161549
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    foo = lazyperclassproperty(func=lambda x: 'foo')
    assert foo == 'foo'
    class Bar(object):
        bar = lazyperclassproperty(func=lambda x: 'bar')
    assert Bar.bar == 'bar'
    assert Bar().bar == 'bar'

# Generated at 2022-06-26 02:39:02.354296
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('Executing test_lazyclassproperty()...')
    test_case_0()
    print('Pass.')


# Generated at 2022-06-26 02:39:08.214324
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = 274.577795
    roclassproperty_0 = roclassproperty(float_0)
    decimal_0 = Decimal("-1.0")
    lazyclassproperty_0 = lazyclassproperty(roclassproperty_0)
    float_1 = 1.0
    assert_almost_equal(lazyclassproperty_0, float_1)


# Generated at 2022-06-26 02:39:09.225406
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True



# Generated at 2022-06-26 02:39:17.819856
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty(): 
    # Test with classproperty
    from functools import partial
    class Test(object):
        @lazyperclassproperty
        def foo(cls):
            return cls
    class Test1(Test):
        pass
    class Test0(Test):
        pass
    assert Test0.foo is Test0
    assert Test.foo is Test
    assert Test1.foo is Test1

    class Test2(Test):
        @lazyperclassproperty
        def foo(cls):
            return cls
    class Test3(Test2):
        pass
    class Test4(Test2):
        pass
    assert Test2.foo is Test2
    assert Test3.foo is Test3
    assert Test4.foo is Test4

    # Test with lazyclassproperty

# Generated at 2022-06-26 02:39:18.823226
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert 1 == 1


# Generated at 2022-06-26 02:39:20.809301
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = 274.577795
    lazyclassproperty_0 = lazyclassproperty(float_0)


# Generated at 2022-06-26 02:39:23.127024
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass


# Generated at 2022-06-26 02:39:32.329492
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test input is a tuple containing:
    #   --> 0.: An integer representing the number of test cases (default: 0)
    #   --> 1.: An integer representing the number of child classes (default: 1)
    #   --> 2.: An integer representing the number of retrieved attributes (default: 1)
    #   --> 3.: A boolean representing the code coverage (default: True)
    args = (0, 1, 1, True)
    if isinstance(args[0], int):
        test_cases = args[0]
    else:
        test_cases = 0
    if isinstance(args[1], int):
        child_classes = args[1]
    else:
        child_classes = 1
    if isinstance(args[2], int):
        retrieved_attributes = args[2]
    else:
        retrieved_attributes

# Generated at 2022-06-26 02:39:38.242496
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test:
        a = 0
        @lazyperclassproperty
        def Test(self):
            Test.a = 5

# Generated at 2022-06-26 02:39:40.697768
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def my_class_property(cls):
        return 'hello world'

    assert my_class_property == 'hello world'


# Generated at 2022-06-26 02:39:44.523556
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0)() == test_case_0()

# Generated at 2022-06-26 02:39:52.724918
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    
    class Fixtures(unittest.TestCase):
        @lazyclassproperty
        @classmethod
        def lazyprop(cls):
            return 'lazyclassproperty'
    
    assert Fixtures().lazyprop == 'lazyclassproperty'


# Generated at 2022-06-26 02:39:59.674709
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def b(cls):
            return cls.c + 3;
        c = 42
        def __init__(self):
            self.b = self.b + 1

    a = A()
    assert a.b == 46, "Error in lazyclassproperty decorator"
    assert A.b == 46, "Error in lazyclassproperty decorator"


# Generated at 2022-06-26 02:40:09.325698
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # Test for lazyperclassproperty
    class TestClass:

        @lazyperclassproperty
        def test_property(cls):
            return cls.__name__

        @property
        def test_func(self):
            return 'test_func'


    for cls in (TestClass, TestClass):
        assert cls.test_property == 'TestClass'
        assert cls().test_func == 'test_func'



# Generated at 2022-06-26 02:40:13.964965
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def func(cls):
        return cls.__name__



# Generated at 2022-06-26 02:40:19.935362
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def get_name(cls):
        return cls.__name__[::-1]

    class MyClass1(object):
        pass


    class MyClass2(object):
        pass


    assert MyClass1.get_name == '1ssalCM'
    assert MyClass2.get_name == '2ssalCM'


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:27.236961
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # Example 1
    class YourClass(object):
        some_value = 3

        @lazyperclassproperty
        def some_property(cls):
            # cls is the class where the property is defined
            # cls.some_value exists
            return cls.some_value * 11

    class InheritingClass(YourClass):
        some_value = 5

        @lazyperclassproperty
        def some_property(cls):
            # cls is the class where the property is defined
            # cls.some_value exists
            return cls.some_value * 11

    assert YourClass.some_property == 33
    assert YourClass().some_property == 33
    assert InheritingClass.some_property == 55
    assert InheritingClass().some_property == 55

    # Example 2

# Generated at 2022-06-26 02:40:28.776984
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class lazyclassproperty_0(object):
        foo_attr = lazyclassproperty(lambda x: 1)

    print(lazyclassproperty_0.foo_attr)



# Generated at 2022-06-26 02:40:38.105025
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def roclassproperty_0(cls):
        return cls.__name__

    assert roclassproperty_0 == 'test_lazyperclassproperty'



# Generated at 2022-06-26 02:40:45.226187
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class DummyClass:
        def __init__(self, x):
            self.x = x
            self.calls = 0

        @lazyclassproperty
        def prop(cls):
            cls.calls += 1
            return self.x

    d = DummyClass(10)
    assert d.prop == 10
    assert DummyClass.calls == 1
    d.prop = 20
    assert d.prop == 20
    assert DummyClass.calls == 1
    d.prop = 30
    assert d.prop == 30
    assert DummyClass.calls == 1


# Generated at 2022-06-26 02:40:52.374026
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class BaseCollection(object):
        @lazyclassproperty
        def collection_name(cls):
            return cls.__name__

    class UserCollection(BaseCollection):
        pass

    class ContentCollection(BaseCollection):
        pass

    assert BaseCollection.collection_name == "BaseCollection"
    assert UserCollection.collection_name == "UserCollection"
    assert ContentCollection.collection_name == "ContentCollection"


# Generated at 2022-06-26 02:40:54.112146
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert(render_lazyclassproperty([0]) == [0])


# Generated at 2022-06-26 02:40:57.102809
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    a = lazyclassproperty(lambda x: 36)
    assert a == 36



# Generated at 2022-06-26 02:41:04.404817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    some_dict = {'B': 1, 'A': 0}
    assert lazyperclassproperty(dict)({'C': 2, 'B': 1, 'A': 0}) == some_dict
    assert lazyperclassproperty(dict)({'C': 2, 'B': 1, 'A': 0}) == some_dict
    assert lazyperclassproperty(dict)({'C': 2, 'B': 1, 'A': 0}) == some_dict


# Generated at 2022-06-26 02:41:15.862590
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class PropertyTest(object):
        @lazyperclassproperty
        def lazy_property(cls):
            print("lazy_property")
            return "lazy_property_value"
    class_0 = PropertyTest()
    # Test: Access the lazy property
    lazy_property_0 = class_0.lazy_property
    # Test: The lazy property has been cached
    lazy_property_0 = class_0.lazy_property
    # Test: The lazy property is a per-class value - create a new instance
    class_1 = PropertyTest()
    # Test: Access the lazy property
    lazy_property_1 = class_1.lazy_property
    assert lazy_property_0 == lazy_property_1, "lazyperclassproperty: The lazy property should be per-class"

# Generated at 2022-06-26 02:41:27.708685
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Unit test for function lazyperclassproperty
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

        @lazyperclassproperty
        def bar2(cls):
            return cls.__name__

    class Baz(Foo):
        pass

    class Foo2(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

    class Baz2(Foo2):
        pass

    assert Foo.bar == 'Foo'
    assert Foo.bar2 == 'Foo'
    assert Baz.bar == 'Baz'
    assert Baz.bar2 == 'Baz'
    assert Foo2.bar == 'Foo2'
    assert Baz2.bar == 'Baz2'



# Generated at 2022-06-26 02:41:38.881889
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Case 0
    test_case_0()
    # Case 1: return special class
    class First(object):
        pass
    class Second(First):
        pass
    @lazyclassproperty
    def special_class(cls):
        if cls.__name__ == "First":
            return First
        return Second
    First.special_class
    assert First.special_class == First
    assert Second.special_class == Second
    # Case 2: return inherited class
    class First(object):
        pass
    class Second(First):
        pass
    @lazyclassproperty
    def inherit_class(cls):
        if cls.__name__ == "First":
            return Second
        return First
    First.inherit_class
    assert First.inherit_class == Second

# Generated at 2022-06-26 02:41:40.398298
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty


# Generated at 2022-06-26 02:41:52.479057
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Uses the random module
    import random

    class MyClass(object):
        RANGE_MIN = 1
        RANGE_MAX = 10

        @lazyperclassproperty
        def random_int(cls):
            return random.randint(cls.RANGE_MIN, cls.RANGE_MAX)

    class MyChildClass(MyClass):
        RANGE_MIN = 10
        RANGE_MAX = 20

    assert MyClass.random_int >= MyClass.RANGE_MIN and MyClass.random_int <= MyClass.RANGE_MAX
    assert MyClass.random_int >= MyClass.RANGE_MIN and MyClass.random_int <= MyClass.RANGE_MAX
    assert MyChildClass.random_int >= MyChildClass.RANGE_MIN and MyChildClass.random_int <= MyChildClass.R

# Generated at 2022-06-26 02:42:02.343128
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import sys
    import StringIO
    import logging

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    streamHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    streamHandler.setFormatter(formatter)
    logger.addHandler(streamHandler)

    class TestLazyClassProperty:

        def __init__(self):
            self.app_name = "TestLazyClassProperty"

        @lazyclassproperty
        def test_lazyclassproperty(self):
            logger.debug("In _lazy_test_lazyclassproperty")
            test_lazyclassproperty = 'TestLazyClassProperty'
            return test_l

# Generated at 2022-06-26 02:42:03.955449
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Place tests here
    assert True == True


# Generated at 2022-06-26 02:42:05.690319
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    classclassproperty_0 = classproperty(float_0)
    classclassproperty_0 = lazyclassproperty('self.f')


# Generated at 2022-06-26 02:42:08.052915
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Bar:
        @lazyperclassproperty
        def foo(cls):
            return 'foo'
    assert Bar.foo == 'foo'

    class Baz(Bar):
        pass
    assert Baz.foo == 'foo'



# Generated at 2022-06-26 02:42:10.127985
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = float
    lazyclassproperty_0 = lazyclassproperty(float_0)
    lazyclassproperty_0 == 274.577795


# Generated at 2022-06-26 02:42:11.937076
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Foo(object):

        @lazyperclassproperty
        def bar(cls):
            return cls.__name__


# Generated at 2022-06-26 02:42:19.571514
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestLazyperclass(object):
        @lazyperclassproperty
        def foo(cls):
            return [1,2]
        
        def get_foo(self):
            return self.foo
    a = TestLazyperclass()
    b = TestLazyperclass()
    # check if the instance b does not share the foo attribute with 
    # instance a
    assert b.get_foo() != a.get_foo()


# Generated at 2022-06-26 02:42:26.040888
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_file = os.path.basename(__file__)
    if not os.path.exists(test_file):
        assert False, test_file + ' does not exists'
    import sys
    orig_sys_argv = sys.argv
    sys.argv = ['']
    import tests.utils
    __main__, result = tests.utils.run_pycover(test_file, False)
    sys.argv = orig_sys_argv
    assert result.has_errored == False, 'There was an error'
    assert result.lines_covered.coverage == 100, 'Bad test coverage'

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:42:28.092192
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = 274.577795
    lazyclassproperty_0 = lazyclassproperty(float_0)


# Generated at 2022-06-26 02:42:41.341916
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            return 1

    assert A.x == 1
    assert A.x == 1

    class B(A):
        pass

    assert B.x == 1
    assert B.x == 1

    a = A()
    b = B()
    assert a.x == 1
    assert b.x == 1



# Generated at 2022-06-26 02:42:49.837099
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    classclassproperty_0 = classproperty
    roclassproperty_0 = roclassproperty
    class_0 = lazyperclassproperty(classclassproperty_0)
    assert class_0.f == class_0
    assert isinstance(class_0, object)
    assert issubclass(type(class_0), type)
    assert isinstance(class_0.f, roclassproperty_0)
    assert isinstance(type(class_0.f), roclassproperty_0)


# Generated at 2022-06-26 02:42:52.034901
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test for proper application of the decorator
    # TODO write test for lazyclassproperty
    assert(True)


# Generated at 2022-06-26 02:42:53.555057
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass  # TODO: Implement test or delete function


# Generated at 2022-06-26 02:42:54.718918
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty()


# Generated at 2022-06-26 02:43:00.129821
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def some_val(cls):
            return 42

    class A(Base):
        pass

    class B(Base):
        pass

    assert A.some_val == 42
    assert B.some_val == 42
    A.some_val = -1
    assert A.some_val == -1
    assert B.some_val == 42


# Generated at 2022-06-26 02:43:05.430078
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    '''
    Ensure that lazyclassproperty works as expected
    '''
    class A(object):
        @lazyclassproperty
        def B(cls):
            print('calling B getter')
            return 'B v1'

        @B.setter
        def B(cls, value):
            print('calling B setter')
            cls._B = value

    assert A.B == 'B v1'
    A.B = 'B v2'
    assert A.B == 'B v2'



# Generated at 2022-06-26 02:43:14.453837
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def lazyclassproperty_0(cls):
        return 'lazy_string_0'

    @lazyclassproperty
    def lazyclassproperty_1(cls):
        return 'lazy_string_1'

    @lazyclassproperty
    def lazyclassproperty_2(cls):
        return 'lazy_string_2'

    @lazyclassproperty
    def lazyclassproperty_3(cls):
        return 'lazy_string_3'

    class Test(object):
        pass

    @lazyclassproperty
    def lazyclassproperty_4(cls):
        return 'lazy_string_4'

    assert Test.lazyclassproperty_0 == 'lazy_string_0'
    assert Test.lazyclassproperty_1 == 'lazy_string_1'

# Generated at 2022-06-26 02:43:22.128227
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @classproperty
        def test_property(cls):
            return 42

    test_instance = TestClass()
    # Make sure the property returns the right value
    assert test_instance.test_property == 42

    class ExtendedTestClass(TestClass):
        pass

    test2_instance = ExtendedTestClass()
    # Make sure the property returns the right value without leaking between classes
    assert test2_instance.test_property == 42



# Generated at 2022-06-26 02:43:23.155109
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    x = lazyperclassproperty
    y = x
    assert x is y



# Generated at 2022-06-26 02:43:48.825241
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase
    from pmods.basic import classproperty, metaclassproperty, lazyclassproperty

    lazily_evaluated_global = []

    class Test(object):
        @classproperty
        def cp(cls):
            return 1

        @metaclassproperty
        def mp(cls):
            return 2

        @lazyclassproperty
        def lp(cls):
            lazily_evaluated_global.append('yay')
            return 3

    # These two should be already evaluated and should not be able to be changed:

    TestCase.assertEqual(Test.cp, 1)
    TestCase.assertEqual(Test.mp, 2)

    # This should change because it's not cached:

    TestCase.assertEqual(Test.lp, 3)

    # This should not be cached

# Generated at 2022-06-26 02:43:50.997924
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def func_0(cls_arg_0):
        print(cls_arg_0)
        return 50
    print('Beginning test')
    lazyclassproperty_0 = lazyclassproperty(func_0)
    dummy_0 = lazyclassproperty_0
    print('Finishing test')


# Generated at 2022-06-26 02:43:54.244743
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    lazyperclassproperty_0 = lazyperclassproperty(float)


# Generated at 2022-06-26 02:44:06.833926
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # Placeholder for test lazyclassproperty
    class TestLazyClassProperty:
        @lazyclassproperty
        def one(cls):
            return 1
        @lazyclassproperty
        def two(cls):
            return 2
    # Check that lazyclassproperties can be set in a class
    assert(TestLazyClassProperty.one == 1)
    # Check that lazyclassproperties can be accessed as other class properties
    assert(TestLazyClassProperty.one == TestLazyClassProperty().one)
    # Check that two different lazyclassproperties can be set with different values
    assert(TestLazyClassProperty.one == 1 and TestLazyClassProperty.two == 2)

    # Placeholder for test lazyclassproperty
    class TestLazyClassProperty2(TestLazyClassProperty):
        pass

    # Check that lazyclassproperty works as expected

# Generated at 2022-06-26 02:44:10.385234
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    @lazyclassproperty
    def classproperty_0(cls):
        return cls()

    # Assertions
    assert isinstance(classproperty_0(), object)
    assert classproperty_0._lazy_classproperty_0 == classproperty_0()


# Generated at 2022-06-26 02:44:16.341216
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Make sure we don't cause an early load of the class
    from .exceptions import ValidationError

    # Make sure when called, we actually load the class
    x = ValidationError.__name__
    assert (lazyclassproperty(lambda cls: cls.__name__) == x)



# Generated at 2022-06-26 02:44:20.770378
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from classes import B
    # Create an instance of the B class
    b_instance = B()
    # Print the value of the lazyperclassproperty
    print('B._lazyperclassproperty1 is {0}'.format(b_instance._lazyperclassproperty1))

# Call unit test function
test_lazyperclassproperty()


# Generated at 2022-06-26 02:44:24.530141
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    float_0 = 274.577795
    float_1 = float_0 // float(float_0)
    float_2 = float_0 % float_1
    setterproperty_0 = setterproperty(float_2)
    lazyperclassproperty_0 = lazyperclassproperty(setterproperty_0)



# Generated at 2022-06-26 02:44:27.517731
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert not hasattr(Test, '_lazy_lazyclassprop')
    Test.lazyclassprop
    assert hasattr(Test, '_lazy_lazyclassprop')
    assert Test.lazyclassprop == 'classproperty'


# Generated at 2022-06-26 02:44:31.672166
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    from unittest import TestCase

    class Test_lazyclassproperty(TestCase):
        def test_func(self):
            self.assertTrue(True)

    unittest.main(module=__name__, exit=False, verbosity=2)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:45:07.421695
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    actual = 'No run'
    expect = 'No run'

    class A(object):
        #@lazyclassproperty
        #def x():
        #    return "x"
        @lazyclassproperty
        def x(self):
            return "x"

    actual = A.x
    expect = "x"
    assert_equal(actual, expect)

if __name__ == "__main__":
    run_test(test_lazyclassproperty, "test_lazyclassproperty")

# Generated at 2022-06-26 02:45:10.261816
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Try to test for weird corner case that didn't work before
    class TestClass(object):
        @lazyclassproperty
        def test_value(cls):
            return "test"

    assert TestClass.test_value == "test"


# Generated at 2022-06-26 02:45:13.047313
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def B(self):
            value = "abc"
            return value

    class C(A):
        pass

    assert A().B == "abc"
    assert C().B == "abc"



# Generated at 2022-06-26 02:45:14.142052
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test():
        assert lazyclassproperty(5) == 5
    test()



# Generated at 2022-06-26 02:45:16.004213
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(test_case_0) == lazyclassproperty(test_case_0)



# Generated at 2022-06-26 02:45:17.970178
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty.__module__ == 'api.misc'
    assert lazyperclassproperty.__name__ == 'lazyperclassproperty'


# Generated at 2022-06-26 02:45:24.808240
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def foo(cls):
        return 'foo'

    class Bar(object):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    class Baz(Bar):
        pass

    class Bat(object):
        pass

    assert foo == 'foo'
    assert Bar.foo == 'bar'
    assert Baz.foo == 'bar'
    assert Bat.foo == 'foo'
    assert Bar().foo == 'bar'
    assert Baz().foo == 'bar'
    assert Bat().foo == 'foo'



# Generated at 2022-06-26 02:45:26.632612
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:45:28.606354
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = 274.577795
    test_case_0()



# Generated at 2022-06-26 02:45:35.003341
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = 274.577795
    class_0 = classproperty(float_0)
    float_1 = 3541.7907
    roclassproperty_1 = roclassproperty(float_1)
    class_1 = classproperty(float_1)
    float_2 = 6353.352425
    setterproperty_2 = setterproperty(float_2)
    float_3 = 9721.859332
    roclassproperty_3 = roclassproperty(float_3)
    float_4 = 11809.411465
    lc = lazyclassproperty(float_4)
    float_5 = 14891.561022
    setterproperty_4 = setterproperty(float_5)
    float_6 = 17997.894855

# Generated at 2022-06-26 02:46:45.104161
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test that use of a decorator without parenthesis works
    @lazyclassproperty
    def foo():
        return "foo"

    assert foo.__doc__ == "foo"

    # Test that use of a decorator with parenthesis works
    @lazyclassproperty()
    def bar():
        """bar"""
        return "bar"

    assert bar.__doc__ == "bar"

    # Test that use of a decorator with two arguments works
    @lazyclassproperty(doc="baz")
    def baz():
        return "baz"

    assert baz.__doc__ == "baz"

    # Test that use of a decorator with two arguments works
    @lazyclassproperty(doc="spam")
    def spam(cls):
        return cls


# Generated at 2022-06-26 02:46:46.061506
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)



# Generated at 2022-06-26 02:46:47.089795
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 1 == 1, 'This is a test'



# Generated at 2022-06-26 02:46:48.240205
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # TODO: Implement test
    pass



# Generated at 2022-06-26 02:46:54.595769
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    ex1_ret = 36
    ex1_class = ex1.Ex1()
    assert ex1_ret == ex1_class.prop
    assert ex1_ret == ex1_class.prop  # This line should be cached
    ex1_class = ex1.Ex1()
    assert ex1_ret == ex1_class.prop
    assert ex1_ret == ex1_class.prop  # This line should be cached

    ex2_ret = 49
    ex2_class = ex2.Ex2()
    assert ex2_ret == ex2_class.prop
    assert ex2_ret == ex2_class.prop  # This line should be cached
    ex2_class = ex2.Ex2()
    assert ex2_ret == ex2_class.prop

# Generated at 2022-06-26 02:46:56.236310
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_0 = _lazyclassprop()
    float_0 = lazyclassproperty(_lazyclassprop)


# Generated at 2022-06-26 02:47:00.017598
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from sklearn.linear_model import LinearRegression
    linear_regressor = lazyperclassproperty(lambda _cls: LinearRegression())
    assert isinstance(linear_regressor, roclassproperty)
    assert isinstance(linear_regressor, classproperty)
    assert linear_regressor == LinearRegression


# Generated at 2022-06-26 02:47:07.290893
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def foo(cls):
        print('foo', cls)
        return 42

    class Base(object):
        pass

    class A(Base):
        pass

    class B(Base):
        pass

    assert Base.foo == 42
    assert A.foo == 42
    assert B.foo == 42
    assert Base.foo is A.foo is B.foo

    class C(A):
        pass

    assert A.foo is C.foo

    class D(A):
        @lazyperclassproperty
        def foo(cls):
            print('foo', cls)
            return 42

    assert A.foo is not D.foo



# Generated at 2022-06-26 02:47:09.456574
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class_0 = PClass()
    classproperty_0 = classproperty(lambda: None)
    classproperty_0 = classproperty(lambda: None)


# Generated at 2022-06-26 02:47:15.892129
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    float_2 = 0x28
    int_0 = 0xff34
    float_1 = 0x274
    roclassproperty_0 = roclassproperty(float_2)
    setterproperty_0 = setterproperty(float_1)
    lazyclassproperty_0 = lazyclassproperty(int_0)
    roclassproperty_1 = roclassproperty(float_2)
    assert roclassproperty_1 == roclassproperty_0
    assert lazyclassproperty_0 == setterproperty_0
