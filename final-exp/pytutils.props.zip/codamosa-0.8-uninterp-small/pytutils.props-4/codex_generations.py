

# Generated at 2022-06-26 02:39:07.272047
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        # init function
        def __init__(self, i):
            self._foo_value = i
        # define a property
        def _getter(self):
            return self._foo_value
        def _setter(self, val):
            self._foo_value = val
        def _deleter(self):
            del self._foo_value
        foo = property(_getter, _setter, _deleter, None)


# Generated at 2022-06-26 02:39:07.865438
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert 1

# Generated at 2022-06-26 02:39:13.567577
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    #
    # Define a test class to use
    #
    class TestClass:
        #
        # This will be defined as a class property
        #
        value = lazyclassproperty(lambda: 1)

    #
    # Get the value of the class property
    #
    assert TestClass.value == 1

    #
    # Verify that the value is cached
    #
    TestClass.value = 2
    assert TestClass.value == 1



# Generated at 2022-06-26 02:39:20.058037
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass:
        number = lazyperclassproperty(lambda cls: 10)
    
    assert(MyClass.number == 10)
    
    class MySubClass(MyClass):
        pass
    
    assert(MySubClass.number == 10)

    # Test that the field is not cached for different classes    
    class MySubSubClass(MyClass):
        number = lazyperclassproperty(lambda cls: 20)
    
    assert(MySubSubClass.number == 20)

    # Test that the field is cached    
    MySubSubClass.number = 30
    assert(MySubSubClass.number == 30)

    def test_case_1():
        str_0 = ''
        lazyperclassproperty_0 = lazyperclassproperty(str_0)
    
    # Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:39:25.522761
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def bar(cls):
            return 'baz'
        def __init__(self, x):
            self.x = x
    assert Foo.bar == 'baz'
    assert Foo(1).x == 1



# Generated at 2022-06-26 02:39:29.095261
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test = lazyclassproperty(lambda self: "test")
    class A:
        pass
    a = A()
    assert test == "test", print(test)
    assert test != 1
    del A.test
    assert not hasattr(A, "test")



# Generated at 2022-06-26 02:39:32.602224
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    #print('Testing lazyclassproperty...')
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('Function called!')
            return 'foo'
    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'


# Generated at 2022-06-26 02:39:39.305902
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # Test case 0
    # Gets a class property.

    @lazyclassproperty
    def test_class_property(cls):
        return 0

    assert test_class_property == 0

    # Test case 1
    # Gets a property from a subclass.

    class TestSubclass(object):
        pass

    @lazyclassproperty
    def test_class_property(cls):
        return 1

    assert TestSubclass.test_class_property == 1

    # Test case 2
    # Gets a subclass property.

    class TestSubclass(object):
        @lazyclassproperty
        def test_class_property(cls):
            return 2

    assert TestSubclass.test_class_property == 2

    # Test case 3
    # Gets a property from the derived class.


# Generated at 2022-06-26 02:39:46.039404
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:39:53.245100
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def func_0(cls):
        pass

    lazyclassproperty_0 = lazyclassproperty(func_0)


# Generated at 2022-06-26 02:39:59.372878
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert not isinstance(lazyperclassproperty(str_0), classproperty)
    assert not isinstance(lazyperclassproperty, roclassproperty)
    assert not isinstance(lazyperclassproperty, setterproperty)


# Generated at 2022-06-26 02:40:06.351340
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ExampleClass(object):
        @lazyclassproperty
        def complex_property(cls):
            value = 5
            while value < 100:
                value *= value
            return value

    assert ExampleClass.complex_property == 5 ** 16

test_lazyclassproperty()
test_case_0()

# Generated at 2022-06-26 02:40:07.683233
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:40:14.207763
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    global data

    data = {}
    data["counter"] = 0
    class Foo(object):
        @lazyclassproperty
        def counter(cls):
            data["counter"] += 1
            return data["counter"]

    assert Foo.counter == 1
    assert Foo.counter == 1
    assert data["counter"] == 1
    assert Foo().counter == 1



# Generated at 2022-06-26 02:40:23.299575
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        _foo = None

        @lazyclassproperty
        def foo(cls):
            return cls._foo

        @foo.setter
        def foo(cls, value):
            cls._foo = value

    assert A.foo is None, 'lazyclassproperty: _foo is None'
    A.foo = 1
    assert A.foo == 1, 'lazyclassproperty: _foo was set to 1'

    class B(A):
        pass

    assert B.foo is None, 'lazyclassproperty: _foo should be None in B'
    B.foo = 2
    assert A.foo == 1, 'lazyclassproperty: _foo should still be 1 in A'
    assert B.foo == 2, 'lazyclassproperty: _foo was set to 2 in B'


# Generated at 2022-06-26 02:40:32.382082
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def test_lazyperclassproperty_0(cls):
        return 1 + 2

    class Test_lazyperclassproperty:

        @lazyclassproperty
        def test_lazyperclassproperty_1(cls):
            return 1 + 2

    assert test_lazyperclassproperty_0(Test_lazyperclassproperty) == Test_lazyperclassproperty.test_lazyperclassproperty_1


# Generated at 2022-06-26 02:40:44.758411
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # dummy function
    def foo_func(cls):
        return cls

    # test class with lazyclassproperty attribute
    @lazyclassproperty
    def foo_prop(cls):
        return foo_func(cls)

    class Foo(object):
        foo_prop2 = foo_prop

        def __init__(self):
            pass

    # test instantiation of class with lazyclassproperty attribute
    foo = Foo()
    # test lazyclassproperty attribute value
    assert foo_prop is foo_func
    # test that lazyclassproperty attribute is actually lazy (hasn't been evaluated on class creation)
    assert foo.foo_prop is foo_func
    # test another lazyclassproperty attribute with same value
    assert foo.foo_prop2 is foo_func


# Tests for roclassproperty

# Generated at 2022-06-26 02:40:48.978343
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def lazyprop(cls):
        return int(10)
    assert isinstance(lazyprop, setterproperty)
    assert lazyprop == lazyprop


# Generated at 2022-06-26 02:40:50.385933
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True


# Generated at 2022-06-26 02:40:53.571087
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        return cls.x + 5

    class A(object):
        x = 6

    assert A.foo == 11
    assert hasattr(A, '_lazy_foo')



# Generated at 2022-06-26 02:41:06.832436
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Item:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        @lazyclassproperty
        def prop(cls):
            return 'lazyclassproperty', cls.__name__

        @lazyperclassproperty
        def prop_per(cls):
            return 'lazyperclassproperty', cls.__name__

    class SubItem(Item):
        def __init__(self, name, value):
            Item.__init__(self, name, value)

    item = Item('item', 'item_value')
    item2 = Item('item2', 'item_value2')
    assert item.prop == item2.prop == ('lazyclassproperty', 'Item')
    assert item.prop_per == ('lazyperclassproperty', 'Item')

# Generated at 2022-06-26 02:41:07.654626
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    result = lazyperclassproperty(lambda: 'foo')
    assert result

# Generated at 2022-06-26 02:41:08.929048
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(str) == '_lazy_str'


# Generated at 2022-06-26 02:41:15.157365
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import datetime

    class MyList(list):
        def __init__(self, iterable):
            self.stamp = datetime.datetime.now()
            super().__init__(iterable)

        @lazyperclassproperty
        def stamp(cls):
            return datetime.datetime.now()

        @property
        def mutable(self):
            return [1, 2, 3]

    l0 = MyList([0, 1])
    l1 = MyList([0, 1])

    assert l0.stamp != l1.stamp

    l0.stamp = datetime.datetime(2018, 1, 1)
    l1.stamp = datetime.datetime(2018, 1, 1)

    assert l0.mutable == [1, 2, 3]

# Generated at 2022-06-26 02:41:18.822251
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = ''
    lazyclassproperty_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:41:22.775718
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = ''
    lazyperclassproperty_0 = lazyperclassproperty(str_0)

    assert(lazyperclassproperty_0 is not None)


# Generated at 2022-06-26 02:41:25.965587
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random

    class A:
        @lazyclassproperty
        def p(cls):
            return random.randint(1, 10)

    assert A.p == A.p



# Generated at 2022-06-26 02:41:28.080571
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass



# Generated at 2022-06-26 02:41:29.522969
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert False, "TODO"


# Generated at 2022-06-26 02:41:31.677874
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    _lazyclassprop = lazyperclassproperty(str)




# Generated at 2022-06-26 02:41:41.649496
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def _f():
        print('Hello World!')
    assert(callable(lazyclassproperty(_f)))
    assert(callable(_f))



# Generated at 2022-06-26 02:41:50.484664
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        def __init__(self, bar):
            self.bar = bar

        @lazyperclassproperty
        def prop0(cls):
            return cls.bar

        @lazyperclassproperty
        def prop1(cls):
            return 1

    class SubFoo(Foo):
        def __init__(self, bar, baz):
            super(SubFoo, self).__init__(bar)
            self.baz = baz

        @lazyperclassproperty
        def prop0(cls):
            return cls.bar + cls.baz

        @lazyperclassproperty
        def prop2(cls):
            return 2

    obj = SubFoo(3, 4)
    assert obj.prop0 == 7
    assert obj.prop1 == 1

# Generated at 2022-06-26 02:42:01.046436
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X:
        @lazyperclassproperty
        def foo(cls):
            ''' Doc string. '''
            return cls.__name__
        def __repr__(self):
            return 'Instance of {0}'.format(self.__class__.__name__)

    class Y(X):
        pass

    class Z(X):
        pass

    assert X.foo == 'X'
    assert Y.foo == 'Y'
    assert Z.foo == 'Z'

    x = X()
    assert repr(x) == 'Instance of X'

    y = Y()
    assert repr(y) == 'Instance of Y'

    z = Z()
    assert repr(z) == 'Instance of Z'


# Generated at 2022-06-26 02:42:05.695445
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestLazyPerClassProperty(object):
        @lazyperclassproperty
        def _test(cls):
            return 1

    assert TestLazyPerClassProperty._test == 1

    class TestLazyPerClassProperty2(TestLazyPerClassProperty):
        pass

    assert TestLazyPerClassProperty2._test == 1


# Generated at 2022-06-26 02:42:08.484415
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def str_0(cls):
        return '1'
    str_0 = ''


# Generated at 2022-06-26 02:42:11.610726
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test cases
    class c_0(object):
        c_0_property_0 = lazyclassproperty(test_lazyclassproperty.__code__)


if __name__ == '__main__':
    test_case_0()
    test_lazyclassproperty()
    print('All tests passed')

# Generated at 2022-06-26 02:42:22.332266
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    test_list = []

    @lazyperclassproperty
    def test_prop(n):
        test_list.append(n)
        return n

    assert A.test_prop is A
    assert B.test_prop is B
    assert C.test_prop is C
    assert test_list == [A, B, C]

    @lazyperclassproperty
    def test_prop_1(n):
        test_list.append(n)
        return n

    assert A.test_prop_1 is A
    assert B.test_prop_1 is B
    assert C.test_prop_1 is C
    assert test_list == [A, B, C, A, B, C]


# Generated at 2022-06-26 02:42:24.087725
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    value_0 = lazyclassproperty(str)


# Generated at 2022-06-26 02:42:27.116297
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(1) == 1
    assert isinstance(lazyclassproperty(1), lazyclassproperty)


# Generated at 2022-06-26 02:42:30.746821
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        def __init__(self, v):
            self.v = v

        @lazyclassproperty
        def prop1(cls):
            return cls.v

    print(TestClass(1).prop1)
    print(TestClass(2).prop1)


# Generated at 2022-06-26 02:42:51.344966
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    properties = []
    class G(object):
        @lazyclassproperty
        def a(clazz):
            properties.append('a')
            return 'a'

        @lazyclassproperty
        def b(clazz):
            properties.append('b')
            return 'b'
    G.a
    assert properties == ['a']
    G.b
    assert properties == ['a', 'b']



# Generated at 2022-06-26 02:42:56.372996
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    expected_value = 0.6780177208901753
    expected_value = -2.3596127539475433
    expected_value = 1.0
    actual_value = 0.0
    actual_value = 0.0
    actual_value = 0.0
    if (actual_value != expected_value):
        pass



# Generated at 2022-06-26 02:43:04.847896
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # FIXME: putting the test code inline causes weird issues
    import lazyclassproperty as test_lazyclassproperty
    class A(object):
        @test_lazyclassproperty.lazyclassproperty
        def is_other(cls):
            """ Tests lazy class property """
            return isinstance(cls, Other)

    class Other(A):
        pass

    assert not A.is_other
    assert Other.is_other
    assert not isinstance(A.is_other, property)
    assert isinstance(Other.is_other, property)
    assert Other.__dict__['is_other'].__doc__ == ' Tests lazy class property '

if __name__ == "__main__":
    import lazyclassproperty as test_lazyclassproperty
    test_lazyclassproperty.test_lazyclassproperty()

# Generated at 2022-06-26 02:43:13.936847
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def test_var(cls):
        return "I'm lazy"

    @lazyperclassproperty
    def test_perclass_var(cls):
        return "I'm lazy"

    @lazyclassproperty
    def test_var_exp(cls):
        raise Exception('I should not be executed if accessed')

    class TestClass(object):
        pass

    class TestClassSub(TestClass):
        pass

    try:
        return  test_var, test_var_exp
    except Exception:
        return  test_var, test_var_exp


    assert test_var == "I'm lazy"
    assert test_perclass_var == "I'm lazy"

    assert TestClass.test_var == "I'm lazy"
    assert TestClass.test_perclass_var

# Generated at 2022-06-26 02:43:24.571024
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    data = "Lorem ipsum dolor"
    d = {}
    # Function must return a callable object
    assert callable(lazyperclassproperty(lambda x: False))
    # Must store different values for different classes
    def lazy_getter(self):
        d[self] = data
        return data

    class SampleClass1(object):
        prop = lazyperclassproperty(lazy_getter)

    class SampleClass2(object):
        prop = lazyperclassproperty(lazy_getter)

    # Instances of SampleClass1 must report the same value
    obj_1 = SampleClass1()
    obj_2 = SampleClass1()
    assert obj_1.prop == data
    assert obj_2.prop == data
    assert obj_1.prop is data
    assert obj_2.prop is data


# Generated at 2022-06-26 02:43:25.772586
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = ''
    lazyclassproperty_0 = lazyclassproperty(str_0)



# Generated at 2022-06-26 02:43:27.177394
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = ''
    lazyclassproperty_1 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:43:28.360115
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:43:38.751332
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def lazyclassproperty_0(str_0):
        return str_0

    @lazyclassproperty
    def lazyclassproperty_1(str_0):
        return str_0

    @lazyclassproperty
    def lazyclassproperty_2(str_0):
        return str_0

    @lazyclassproperty
    def lazyclassproperty_3(str_0):
        pass

    @lazyclassproperty
    def lazyclassproperty_4(str_0):
        return False

    @lazyclassproperty
    def lazyclassproperty_5(str_0):
        return True

    @lazyclassproperty
    def lazyclassproperty_6(str_0):
        return False

    @lazyclassproperty
    def lazyclassproperty_7(str_0):
        pass


# Generated at 2022-06-26 02:43:39.984794
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:44:15.877021
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class clazz_0:
        attr_0 = None
        def __init__(self):
            self.attr_0 = 'aaa'
        @staticmethod
        def static_0():
            return 'bbb'
        def get_attr_0(self):
            return self.attr_0

    str_0 = lazyclassproperty(clazz_0.static_0)

    clazz_0.__dict__['str_0'] = str_0

    clazz_0_0 = clazz_0()
    clazz_1 = clazz_0()

    clazz_0_0.__dict__['str_0'] = str_0
    clazz_0_0.__dict__['get_attr_0'] = clazz_0_0.get_attr_0

    clazz_1.__dict

# Generated at 2022-06-26 02:44:22.024010
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    '''
    Test if there exists an instance attribute with the same name as the
    class attribute of the same name.
    '''
    r = random.random()
    @lazyclassproperty
    def temp_prop(cls):
        return r
    try:
        assert not hasattr(Temp.temp_prop, '__doc__'), \
                "The instance and class attributes shouldn't have the same name"
    except:
        print("lazyclassproperty's docstring must not be overridden")


# Generated at 2022-06-26 02:44:22.890516
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty is not None


# Generated at 2022-06-26 02:44:30.042031
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from random import random
    from datetime import datetime
    from time import sleep


    class TestClass(object):

        @lazyperclassproperty
        def random(cls):
            print('{} getting {} {}'.format(datetime.now(), cls.__name__, random()))
            sleep(1)
            return random()

    class ChildClass(TestClass):
        pass

    class ParentClass(object):
        pass

    class Child2Class(ParentClass):
        pass

    t = TestClass()
    assert TestClass.random == TestClass.random
    assert ChildClass.random == ChildClass.random

    # Test different class, and it's still cached
    print(TestClass.random)
    assert TestClass.random == TestClass.random

# Generated at 2022-06-26 02:44:31.991389
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_0():
        assert False

    class TestLazyclassproperty:
        test_property = lazyclassproperty(test_0)



# Generated at 2022-06-26 02:44:38.477179
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def foo(cls):
        return cls.__name__.upper()

    @lazyperclassproperty
    def bar(cls):
        return cls.__name__.upper()

    class A(object):
        pass

    class B(A):
        pass

    assert foo(A) == 'A'
    assert foo(B) == 'B'

    assert bar(A) == 'A'
    assert bar(B) == 'B'

# Generated at 2022-06-26 02:44:40.335406
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def f():
        return 'Hi, this is a lazy per-class property'
    print(lazyperclassproperty(f))
    print("Testing done")


# Generated at 2022-06-26 02:44:43.406843
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class_0 = type('', (), {})
    def func_0(cls_0):
        return cls_0
    lazyperclassproperty_0 = lazyperclassproperty(func_0)
    assert isinstance(lazyperclassproperty_0, roclassproperty)



# Generated at 2022-06-26 02:44:44.949101
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 'foo' in lazyperclassproperty(str)


# Generated at 2022-06-26 02:44:51.467035
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test parameters and expected results
    classes = [
        (lambda:0,
         [0, 0, 0, 1, 2, 4, 0, 8]),
        (lambda:(1,2,3),
         [(1,2,3), (1,2,3), (1,2,3), 1, 2, 4, (1,2,3), 8]),
        (lambda:[42],
         [[42], [42], [42], 1, 2, 4, [42], 8]),
        (lambda:{'a':1},
         [{'a':1}, {'a':1}, {'a':1}, 1, 2, 4, {'a':1}, 8])]

    for class_factory, values in classes:
        class A(object):
            x = lazyperclassproperty(class_factory)

# Generated at 2022-06-26 02:45:50.946178
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0) == None


# Generated at 2022-06-26 02:45:51.570257
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # Assert lazyclassproperty is true
    assert lazyclassproperty


# Generated at 2022-06-26 02:45:55.051450
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def get_test(cls):
        return "test"

    assert isinstance(get_test, classproperty)
    assert get_test.__name__ == "get_test"
    assert get_test.__doc__ == None
    assert MyClass.get_test == 'test'
    assert MyClass().get_test == 'test'


# Generated at 2022-06-26 02:45:56.519934
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for return type of function lazyperclassproperty
    assert (isinstance(lazyperclassproperty(str.upper), property))


# Generated at 2022-06-26 02:46:07.026845
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Get the class, not an instance
    class A:
        @lazyperclassproperty
        def test(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def test(cls):
            return "B"

    assert A.test == "A"
    assert B.test == "B"

    # Get the class, not an instance
    class A:
        @lazyclassproperty
        def test(cls):
            return "A"

    class B(A):
        @lazyclassproperty
        def test(cls):
            return "B"

    assert A.test == "A"
    assert B.test == "B"
    assert B._lazy_test is A._lazy_test

# Generated at 2022-06-26 02:46:15.933589
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:46:18.174768
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Function to test lazyclassproperty.
    """
    print(lazyclassproperty.__doc__)



# Generated at 2022-06-26 02:46:22.147774
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def name(cls):
            print('Creating name for {}'.format(cls))
            return 'The name'

    assert A.name == 'The name'
    assert A.name == 'The name'
    assert A.name == 'The name'

# Generated at 2022-06-26 02:46:23.897682
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    lazyperclassproperty_0 = lazyperclassproperty(0.0)
    assert lazyperclassproperty_0 == 0.0


# Generated at 2022-06-26 02:46:24.892560
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True == True


# Generated at 2022-06-26 02:48:28.249663
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Vars:
    # Used in the closure, and the method body
    x_0 = 0

    # Function:
    # Sample function to test
    def _lambda_0(cls):
        return x_0

    _lambda_0 = lazyclassproperty(_lambda_0)


# Generated at 2022-06-26 02:48:33.137938
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def func_0(arg_0):
        return lazyperclassproperty(func_0)
    test_case_0()

    test_obj = Test()

    test_obj.prop1 = 1
    assert test_obj.prop1 == 1

    # using it as a descriptor
    assert Test.kls_prop1 == 2
    assert Test2.kls_prop1 == 3

    test_obj2 = Test2()

    assert test_obj2.kls_prop1 == 3
    assert test_obj2.kls_prop1 == 4

    # assert isinstance(test_obj, Test)
    assert test_obj.lazy_prop1 == 1
    assert test_obj.lazy_prop1 == 1

    assert test_obj2.lazy_prop1 == 1



# Generated at 2022-06-26 02:48:36.485700
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:48:38.326079
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def f(cls):
        return 'abc'
    fn = lazyperclassproperty(f)
    class A:
        fn = fn
    class B(A):
        pass
    class C(A):
        pass
    assert A.fn == 'abc'
    assert B.fn == 'abc'
    assert C.fn == 'abc'


# Generated at 2022-06-26 02:48:45.404733
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def lazyperclassproperty_0(cls_0):
        return cls_0

    @lazyperclassproperty
    def lazyperclassproperty_1(cls_1):
        return cls_1

    class_0 = type('class_0', (), {})

    class_1 = type('class_1', (), {})

    class_0.val = class_0
    class_1.val = class_1

    assert lazyperclassproperty_0._lazyclassprop == class_0
    assert lazyperclassproperty_1._lazyclassprop == class_1



# Generated at 2022-06-26 02:48:46.683895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # TODO: Update tests to make use of the new function
    assert 0


# Generated at 2022-06-26 02:48:48.413134
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest
    class Test0(unittest.TestCase):
        def test_0(self):
            assert 1==1
    unittest.main()



# Generated at 2022-06-26 02:48:49.986253
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    lazyperclassproperty(str_0)


# Generated at 2022-06-26 02:48:52.550211
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def lazyperclassproperte(x):
        return x
    test_class = type("test_class", (), {})
    assert(test_class.lazyperclassproperte == test_class)



# Generated at 2022-06-26 02:48:59.951605
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class lazyperclassproperty_0(object):
        lazyperclassproperty_0 = lazyperclassproperty(lambda : _0)  # Infer type of _0: () -> Any
        lazyperclassproperty_0 = lazyperclassproperty(lambda _0: _0)  # Infer type of _1: (Any) -> Any
        lazyperclassproperty_0 = lazyperclassproperty(lambda _0, _1: _1)  # Infer type of _2: (Any, Any) -> Any
        lazyperclassproperty_0 = lazyperclassproperty(lambda _0, _1, _2: _1)  # Infer type of _3: (Any, Any, Any) -> Any
        lazyperclassproperty_0 = lazyperclassproperty(lambda _0, _1, _2, _3: _1)  # Infer type of _