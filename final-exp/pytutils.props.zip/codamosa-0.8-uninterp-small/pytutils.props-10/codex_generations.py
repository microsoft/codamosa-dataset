

# Generated at 2022-06-26 02:38:57.218142
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    f = lambda: random.randint(1, 2)
    var_0 = lazyclassproperty(f)
    # Test call
    try:
        var_0
    except:
        var_0



# Generated at 2022-06-26 02:39:00.300062
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from pytest import raises

    def complex_0():
        import complex_0
        return complex_0
    raises(UnboundLocalError, "var_0 = lazyperclassproperty(complex_0)")



# Generated at 2022-06-26 02:39:03.438676
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from testkvstore import testkvstore
    from testkvstore import testkvstore
    from testkvstore import testkvstore
    from testkvstore import testkvstore



# Generated at 2022-06-26 02:39:14.107852
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase

    class TestLazyClassProperty(TestCase):
        def setUp(self):
            self.called = 0
            self.obj = TestLazyClassProperty

        def test_constructor(self):
            @lazyclassproperty
            def foo():
                self.called += 1
                return 'foo'

            self.assertEqual(self.called, 0)
            self.assertEqual(foo, 'foo')
            self.assertEqual(self.called, 1)

        def test_get(self):
            @lazyclassproperty
            def foo():
                self.called += 1
                return 'foo'

            self.assertEqual(self.called, 0)
            self.assertEqual(foo, 'foo')
            self.assertEqual(self.called, 1)

       

# Generated at 2022-06-26 02:39:17.475192
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def complex_0():
        x = 0
        for k in [10, 20]:
            x += k
        return x

    assert complex_0() == 30
    p = lazyclassproperty(complex_0)
    x = p.__get__(None, None)
    assert x == 30

# Generated at 2022-06-26 02:39:29.261526
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Base(object):

        @lazyclassproperty
        def test(cls):
            print('lazy class property')
            return 42

        @lazyperclassproperty
        def test_perclass(cls):
            print('lazy per-class property')
            return 42

    class Derived(Base):
        pass

    assert Base.test == 42
    assert Base.test_perclass == 42
    assert Derived.test == 42

    # changing Base does not change Derived
    Base.test = 0
    assert Base.test == 0
    assert Derived.test == 42
    Base.test_perclass = 0
    assert Base.test_perclass == 0
    assert Derived.test_perclass == 42

    # changing Derived does not change Base
    Derived.test = 1

# Generated at 2022-06-26 02:39:31.553881
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    a = 0

    @lazyclassproperty
    def a_prop(cls):
        nonlocal a
        return a

    a_prop
    a = 1
    a_prop



# Generated at 2022-06-26 02:39:37.608974
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import sys
    import io
    import unittest

    class TestClassPropertyCase(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_lazyclassproperty(self):
            # Arrange
            complex_0 = None
            var_0 = lazyclassproperty(complex_0)

        @unittest.skip("example")
        def test_example(self):
            # Arrange
            complex_0 = None
            var_0 = lazyclassproperty(complex_0)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-26 02:39:39.250752
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 10 // 2 == 5


# Generated at 2022-06-26 02:39:40.667019
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert(lazyperclassproperty(test_case_0) is not None)


# Generated at 2022-06-26 02:39:44.308292
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object): pass
    assert Test.var == None
    Test.var = 'foo'
    assert Test.var == 'foo'



# Generated at 2022-06-26 02:39:52.091000
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def test_property(cls):
            print('in test_property')

    class Child(Parent):
        pass

    print('in main')
    Parent.test_property()
    Child.test_property()


# Generated at 2022-06-26 02:40:02.426835
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test_0(object):
        @lazyclassproperty
        def classattribute_0(cls):
            return 0

    Test_0.classattribute_0 = 1

    class Test_1(Test_0):
        pass

    assert Test_0.classattribute_0 == 1
    assert Test_1.classattribute_0 == 1

    class Test_2(Test_0):
        @lazyclassproperty
        def classattribute_0(cls):
            return 2

    assert Test_2.classattribute_0 == 2

    class Test_3(Test_2):
        pass

    assert Test_3.classattribute_0 == 2

    Test_0.classattribute_0 = 3

    assert Test_0.classattribute_0 == 3
    assert Test_1.classattribute_0 == 3
    assert Test_2

# Generated at 2022-06-26 02:40:08.769064
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def complex_0():
        return 1

    class Foo():
        pass

    class Bar(Foo):
        pass

    assert Foo.complex_0 == 1
    assert Bar.complex_0 == 1
    assert Foo.complex_0 == Bar.complex_0



# Generated at 2022-06-26 02:40:10.256130
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Assert if lazyclassproperty raises exception
    assert callable(lazyclassproperty)



# Generated at 2022-06-26 02:40:21.106142
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass:
        i = 0
        @lazyperclassproperty
        def num(cls):
            cls.i += 1
            return cls.i
    class ClassA(MyClass):
        pass
    class ClassB(MyClass):
        pass
    assert MyClass.num == 1
    assert ClassA.num == 2
    assert ClassB.num == 3


# Generated at 2022-06-26 02:40:27.046503
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test for functions that are not class methods
    def test_class_func_0(cls):
        return 1

    @classproperty
    def test_class_func_1(cls):
        return 1

    @lazyclassproperty
    def test_class_func_2(cls):
        return 1

    # Test for functions that are class methods
    class A(object):
        a = 1

        @classmethod
        def test_class_func_3(cls):
            return 2

    @classmethod
    def test_class_func_4(cls):
        return 2

    @lazyclassproperty
    def test_class_func_5(cls):
        return 2

    @lazyclassproperty
    def test_class_func_5_5(cls):
        return cls.a

# Generated at 2022-06-26 02:40:35.458391
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestLazyPerClassProperty(object):
        cnt = 0

        @lazyclassproperty
        def count(cls):
            cls.cnt += 1
            return cls.cnt

        @lazyclassproperty
        def count_new(cls):
            cls.cnt += 1
            return cls.cnt

        @lazyperclassproperty
        def per_count(cls):
            cls.cnt += 1
            return cls.cnt

    TestLazyPerClassProperty.count
    TestLazyPerClassProperty.count
    TestLazyPerClassProperty.count_new
    TestLazyPerClassProperty.count_new
    TestLazyPerClassProperty.per_count
    TestLazyPerClassProperty.per_count


# Generated at 2022-06-26 02:40:38.127927
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test():
        val = 1
        
        @lazyperclassproperty
        def get_val(self):
            return 2

    assert Test().get_val == 2
    

# Generated at 2022-06-26 02:40:42.897594
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test0(object):
        pass

    class Test1(Test0):
        pass

    class Test2(Test0):
        pass

    @lazyperclassproperty
    def foo(cls):
        return 'bar'

    assert Test0.foo == 'bar'
    assert Test1.foo == 'bar'
    assert Test2.foo == 'bar'

    Test0.foo = 'foo'
    assert Test0.foo == 'foo'
    assert Test1.foo == 'bar'
    assert Test2.foo == 'bar'

    Test1.foo = 'baz'
    assert Test0.foo == 'foo'
    assert Test1.foo == 'baz'
    assert Test2.foo == 'bar'

    Test2.foo = 'baz'
    assert Test0.foo == 'foo'

# Generated at 2022-06-26 02:40:48.517068
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert test_lazyclassproperty() == 1

# Generated at 2022-06-26 02:40:52.274148
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    instance_0 = None
    var_0 = lazyclassproperty(instance_0)
    var_1 = lazyclassproperty(instance_0)
    var_2 = lazyclassproperty(instance_0)


# Generated at 2022-06-26 02:40:56.285827
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Assert if lazyclassproperty raises an error
    error = False
    try:
        test_case_0()
    except:
        error = True
    assert error



# Generated at 2022-06-26 02:41:00.131616
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    complex_0 = None
    assert var_0
    var_0 = lazyclassproperty(complex_0)
    assert var_0

# Generated at 2022-06-26 02:41:02.530731
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert_equals(complex_0, var_0)


# Generated at 2022-06-26 02:41:12.051569
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('\nRunning unit test for lazyclassproperty')
    for i in range(1):
        print('Testing case # {}'.format(i))
        test_case_0()
    else:
        print('\nTesting complete!')

if __name__ == "__main__":
    print(functions.__file__)
    print(test_lazyclassproperty.__doc__)
    test_lazyclassproperty()

# Generated at 2022-06-26 02:41:17.909423
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # The lazyperclassproperty decorator should work on functions
    # that take no arguments.
    @lazyperclassproperty
    def get_five():
        return 5

    # classproperty descriptor is returned by the lazyperclassproperty
    # decorator
    assert isinstance(get_five, classproperty)

    # The computed value is cached on the decorated class.
    class Foo:
        pass

    assert Foo.get_five == 5

    # The computed value is cached on the decorated class, so it
    # shouldn't be called again.
    #
    # No assertion here, if an exception is raised the test case fails.
    Foo.get_five

    # The computed value is cached on the decorated class, so the
    # function should not be called.
    #
    # No assertion here, if an exception is raised the test case fails.


# Generated at 2022-06-26 02:41:21.952985
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            return 1

    assert C.x == 1



# Generated at 2022-06-26 02:41:25.861355
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def foo(self):
            return 2

    assert A.foo() == A.foo()

    class B(A):
        pass

    assert B.foo() != A.foo()


# Generated at 2022-06-26 02:41:35.859213
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def adds_one(cls):
        return cls.value + 1

    class C:
        value = 1

        _per_class_prop = lazyperclassproperty(adds_one)

    print(C._per_class_prop)  # prints 2
    print(C.value)  # prints 1
    C.value = 2
    print(C._per_class_prop)  # prints 2, cached


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:41:45.799763
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    complex_0 = None
    var_0 = lazyclassproperty(complex_0)


# Generated at 2022-06-26 02:41:47.564336
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test for loops for for String
    for i in range (1):
        test_case_0()

#Test the function
test_lazyclassproperty()

#Print the time taken

# Generated at 2022-06-26 02:41:57.539327
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from unittest import TestCase
    from operator import attrgetter

    class Foo(object):

        @lazyperclassproperty
        def prop(cls):
            return "%s.%s" % (cls.__module__, cls.__name__)

    class Metafoo(type):

        @lazyperclassproperty
        def prop(cls):
            return "%s.%s" % (cls.__module__, cls.__name__)

    class Bar(Foo):
        pass

    get_prop = attrgetter('prop')

    class TestLazyPerClassProperty(TestCase):

        def test_lazyperclassproperty(self):
            self.assertEqual(get_prop(Foo), "__main__.Foo")

# Generated at 2022-06-26 02:41:58.841261
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test lazyperclassproperty
    """
    pass


# Generated at 2022-06-26 02:42:03.815133
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from modgrammar import Grammar
    from modgrammar import WORD
    from modgrammar import OPTIONAL

    class Base(Grammar):
        grammar = (WORD, OPTIONAL("suffix"))

    class A(Base):
        pass

    class B(Base):
        grammar = (Base)

        @lazyperclassproperty
        def grammar(cls):
            return (WORD, Base, OPTIONAL("suffix"))

    a = A("test")
    b = B("test")

    assert str(a) == "test"
    assert str(b) == "test test suffix"


if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:07.251876
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def function_0():
        return 3.141592653589793

    gvar_0 = lazyperclassproperty(function_0)
    var_0 = gvar_0()


# Generated at 2022-06-26 02:42:10.233865
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    def test_func():
        def f():
            return 'test'

        class TestClass:
            value = lazyclassproperty(f)

        return TestClass()

    test_case = test_func()
    assert (test_case.value == 'test')



# Generated at 2022-06-26 02:42:13.682398
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyperclassproperty
        def attr(cls):
            return 'attr value'

    class TestChild(Test):
        pass

    assert Test.attr == 'attr value'
    assert TestChild.attr == 'attr value'

    TestChild.attr = 'new value'
    assert Test.attr == 'attr value'
    assert TestChild.attr == 'new value'


# Generated at 2022-06-26 02:42:22.768392
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # test class method
    class A(object):
        @lazyperclassproperty
        def test(self):
            return 'value'

    assert A.test == 'value'

    # test instance method
    class A(object):
        @lazyperclassproperty
        def test(self):
            return 'value'

    assert A().test == 'value'

    # test inherited class method
    class A(object):
        @lazyperclassproperty
        def test(self):
            return 'value in A'

    class B(A):
        pass

    assert B.test == 'value in A'

    # test inherited instance method
    class A(object):
        @lazyperclassproperty
        def test(self):
            return 'value in A'

    class B(A):
        pass

    assert B().test

# Generated at 2022-06-26 02:42:32.689919
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Execution: python -m wisepy2.python3.decorator test
    print('\nunit test Python3.decorator.lazyclassproperty')
    complex_0 = lambda x: x
    var_0 = lazyclassproperty(complex_0)
    assert_0 = var_0
    var_1 = type(var_0)
    assert_1 = classmethod
    var_2 = var_1 is assert_1
    assert_2 = True
    print(var_0)
    print(var_1)
    print(var_2)
    assert var_2 == True
    print('------')
    # Execution: python -m wisepy2.python3.decorator test
    complex_0 = lambda x: x
    var_0 = lazyclassproperty(complex_0)

# Generated at 2022-06-26 02:42:52.668440
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from types import MethodType

    class B(object):
        uninitialized = lazyperclassproperty(lambda cls: 'initialized')

        def get_uninitialized(self):
            return self.uninitialized
    assert B.uninitialized == 'initialized'
    assert B().get_uninitialized() == 'initialized'
    assert B.uninitialized == 'initialized'  # uninitialized unchanged by instance access
    assert B().uninitialized == 'initialized'  # attribute of class available on instances
    class C(B):
        pass
    assert C.uninitialized == 'initialized'  # uninitialized unchanged by subclass
    assert C().get_uninitialized() == 'initialized'
    assert C.uninitialized == 'initialized'  # uninitialized unchanged by instance access
    assert C().uninitialized == 'initialized'  # attribute of class available on instances

# Generated at 2022-06-26 02:42:56.110454
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    complex_0 = None
    var_0 = lazyperclassproperty(complex_0)


if __name__ == '__main__':
    test_case_0()
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:59.162481
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        x = lazyperclassproperty(lambda self: 1)

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1



# Generated at 2022-06-26 02:43:03.320865
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print(lazyclassproperty(None))
    print(lazyclassproperty)
    print(lazyclassproperty(0))
    print(lazyclassproperty(0.1))
    print(lazyclassproperty('string'))
    print(lazyclassproperty([]))
    print(lazyclassproperty({}))
    print(lazyclassproperty(()))


# Generated at 2022-06-26 02:43:04.268605
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True


# Generated at 2022-06-26 02:43:13.222085
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # test_case_0
    class class_0:
        def __init__(self, arg_0):
            self.var_0 = arg_0
    class class_1(class_0):
        pass
    class class_2(class_0):
        pass
    var_0 = lazyperclassproperty(lambda x: ''.join(x.__name__.split('class_')))
    var_1 = class_0(var_0)
    assert var_1.var_0 == "0"
    var_2 = class_1(var_0)
    assert var_2.var_0 == "1"
    var_3 = class_2(var_0)
    assert var_3.var_0 == "2"


# Generated at 2022-06-26 02:43:14.062455
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Add code here.
    pass



# Generated at 2022-06-26 02:43:22.346818
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    mock_0 = Mock()
    complex_0 = mock_0(lazyperclassproperty)
    complex_1 = mock_0(complex_0)
    var_0 = lazyperclassproperty(complex_1)

    # Mock for lazyperclassproperty
    mock_0.assert_called_once_with(complex_0)


if __name__ == '__main__':
    test_case_0()  # Unit testing for function test_case_0
    test_lazyperclassproperty()  # Unit testing for function lazyperclassproperty

# Generated at 2022-06-26 02:43:31.865539
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    @lazyperclassproperty
    def complex_lazyperclassproperty():
        print("This is complex_lazyperclassproperty")
        return 'complex_lazyperclassproperty'


    @lazyclassproperty
    def complex_lazyclassproperty():
        print("This is complex_lazyclassproperty")
        return 'complex_lazyclassproperty'


    @lazyperclassproperty
    def complex_lazyperclassproperty_2():
        print("This is complex_lazyperclassproperty_2")
        return 'complex_lazyperclassproperty_2'


    @lazyclassproperty
    def complex_lazyclassproperty_2():
        print("This is complex_lazyclassproperty_2")
        return 'complex_lazyclassproperty_2'



# Generated at 2022-06-26 02:43:33.983706
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    '''
    Ensure this function conforms to the specs.
    '''
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:43:56.217821
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test Python code as input
    def func_0(cls):
        print(cls)
        return cls
    lazyperclassproperty(func_0)



# Generated at 2022-06-26 02:44:07.805935
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    global _mocked_methods_
    _mocked_methods_ = []
    _mocked_methods_ += ['complex_0', 'complex_0']
    mocked_methods = {'complex_0': lambda : 'param 1'}

    real_methods = ['complex_0']

    class fake_complex_0():
        @classproperty
        def complex_0(cls):
            return 1

    _mocked_methods_.append('complex_0')
    def _complex_0(cls):
        global _mocked_methods_
        global _mocked_methods_counter_
        _mocked_methods_counter_ = 0

# Generated at 2022-06-26 02:44:11.762957
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    data0 = None


# def test():
#     """Test suite for decorators."""
#     import doctest
#     return doctest.DocTestSuite(__name__)
#
#
# if __name__ == '__main__':
#     import unittest
#     unittest.main(defaultTest='test')

# Generated at 2022-06-26 02:44:12.726200
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:44:17.451281
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    foo = 'bar'
    def _lazyclass(cls):
        return foo
    test = lazyclassproperty(_lazyclass)
    for i in range(10):
        assert test == foo
    foo = 'baz'
    assert test == foo
    assert test == 'baz'



# Generated at 2022-06-26 02:44:22.366339
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        pass

    class Test2(Test):
        pass

    @lazyperclassproperty
    def test(cls):
        return sum(range(10))

    tot = 0
    for c in (Test, Test2):
        tot += c.test

    assert tot == sum(range(10)) + sum(range(10))



# Generated at 2022-06-26 02:44:24.697473
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class InnerTestClass(object):
        str_0 = lazyperclassproperty(lambda self: self.__name__)
    assert InnerTestClass.str_0 == 'InnerTestClass'


# Generated at 2022-06-26 02:44:27.946418
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    try:
        complex_0 = None
        var_0 = lazyclassproperty(complex_0)
        assert True
    except NotImplementedError:
        assert False


if __name__ == "__main__":
    test_lazyclassproperty()
    print("All Tests Passed Successfully")

# Generated at 2022-06-26 02:44:29.679356
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def complex_0(cls):
        return 2
    var_0 = lazyperclassproperty(complex_0)


# Generated at 2022-06-26 02:44:37.275506
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    a = 0
    class A(object):
        @lazyclassproperty
        def a(cls):
            global a
            a += 1
            return a
    A.a
    assert A.a == 1
    A.a
    assert A.a == 1

    B = type('B', (A,), {})
    B.a
    assert B.a == 2
    B.a
    assert B.a == 2

    b = B()
    b.a
    assert b.a == 2

    b.a = 2
    assert b.a == 2



# Generated at 2022-06-26 02:45:14.062433
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    c = C()
    assert c.foo == 'foo'
    assert callable(c._callable_foo)

    assert c.bar == 'bar'
    assert callable(c._callable_bar)

    assert isinstance(C.foo, lazyclassproperty)
    assert isinstance(C.bar, lazyclassproperty)

    assert C.foo.__doc__ == 'foo doc string'
    assert C.bar.__doc__ == 'bar doc string'

# Generated at 2022-06-26 02:45:16.493909
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_func_0(cls):
        return "test" + str(cls)
    var_1 = lazyperclassproperty(test_func_0)



# Generated at 2022-06-26 02:45:17.748791
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = lazyclassproperty(test_case_0)


# Generated at 2022-06-26 02:45:18.962842
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True == True



# Generated at 2022-06-26 02:45:20.188171
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)
    # just a function with state, not really testable



# Generated at 2022-06-26 02:45:23.617591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    complex_0 = None
    var_0 = lazyclassproperty(complex_0)
    var_0 = lazyperclassproperty(complex_0)
    test_case_0()

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-26 02:45:29.248754
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    function lazyperclassproperty
    returns a classproperty
    """
    class A: pass
    @lazyperclassproperty
    def create():
        return "test"

    assert isinstance(create, classproperty)
    assert A.create == "test"

    class B(A): pass
    assert B.create == "test"
    assert A.create == "test"


# Generated at 2022-06-26 02:45:32.910888
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test types for function lazyperclassproperty
    class TestClass0:
        @lazyperclassproperty
        def TestProperty0(self):
            pass

    class TestSubclass0(TestClass0):
        def TestMethod0(self):
            pass

    complex_0 = TestClass0.TestProperty0
    complex_1 = TestSubclass0.TestProperty0



# Generated at 2022-06-26 02:45:38.575211
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test function lazyperclassproperty
    """

    # Arrange
    class TestCase:
        @lazyperclassproperty
        def SomeProperty(cls):
            return "A Value"

    # Act
    var_0 = TestCase()
    var_1 = TestCase()

    # Assert
    assert var_0.SomeProperty == "A Value"
    assert var_1.SomeProperty == "A Value"



# Generated at 2022-06-26 02:45:41.258615
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert (lazyperclassproperty.__name__ == 'lazyperclassproperty')


# Generated at 2022-06-26 02:46:48.785821
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def setUp():
        pass

    def tearDown():
        pass

    class TestCase(unittest.TestCase):
        pass

    del unittest

# Generated at 2022-06-26 02:46:51.358554
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def function_complex_0(complex_0_arg_0):
        return complex_0_arg_0

    complex_0 = None
    var_0 = lazyperclassproperty(function_complex_0)


# Generated at 2022-06-26 02:47:00.100658
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from nose.tools import assert_equals
    from nose.tools import assert_raises
    class testClass(object):
        def __init__(self, a):
            self.a = a

        @lazyperclassproperty
        def b(cls):
            print('lazyperclassproperty in action')
            return 'abc' + cls.a
    #test1
    expected_result = 'abc'
    test_object = testClass('')
    actual_result = test_object.b
    assert_equals(expected_result, actual_result)
    #test2
    expected_result = 'abcdef'
    test_object = testClass('def')
    actual_result = test_object.b
    assert_equals(expected_result, actual_result)


# Generated at 2022-06-26 02:47:06.699258
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    counter = 0

    class A(object):
        @lazyclassproperty
        def a(cls):
            nonlocal counter
            counter += 1
            return counter

        @lazyclassproperty
        def b(cls):
            nonlocal counter
            counter += 1
            return counter

    class B(A):
        pass

    assert A.a == 1
    assert A.a == 1
    assert A.b == 2
    assert B.a == 3
    assert B.a == 3
    assert A.b == 2
    assert B.b == 4
    assert B.b == 4



# Generated at 2022-06-26 02:47:09.131748
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def get_complex(self):
        return self.__complex__()

    assert test_case_0() is None



# Generated at 2022-06-26 02:47:17.974626
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        s = 0

        def __init__(self):
            self.s = 1

        @lazyperclassproperty
        def ss(cls):
            return cls.s

    assert A.s == 0
    assert A.ss == 0

    a = A()
    assert a.s == 1
    assert a.ss == 0

    class B(A):
        s = 2

    assert B.s == 2
    assert B.ss == 2

    b = B()
    assert b.s == 1
    assert b.ss == 2

    class C(B):
        s = 3

    assert C.s == 3
    assert C.ss == 3

    c = C()
    assert c.s == 1
    assert c.ss == 3

# Generated at 2022-06-26 02:47:18.979012
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:47:19.776446
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass


# Generated at 2022-06-26 02:47:24.239927
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo in %s' % cls.__name__

    a1 = A()
    a2 = A()

    class B(A):
        pass

    b1 = B()
    b2 = B()

    assert a1.foo == 'foo in A'
    assert a2.foo == 'foo in A'
    assert b1.foo == 'foo in B'
    assert b2.foo == 'foo in B'

# Generated at 2022-06-26 02:47:30.264249
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Set up test
    a = lazyperclassproperty(lambda x: 'a')
    b = lazyperclassproperty(lambda x: 'b')

    # Test that we get the correct value
    try:
        _ = a
    except NameError:
        assert False, "Expected value, got exception"
    try:
        _ = b
    except NameError:
        assert False, "Expected value, got exception"

    # Test that we get the correct value on inheritance
    class A(object):
        @a
        def a(self):
            pass
        @b
        def b(self):
            pass

    class B(A):
        pass
