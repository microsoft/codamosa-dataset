

# Generated at 2022-06-26 02:39:06.648761
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    list_0 = ['list_init_0']
    list_1 = ['list_init_1']
    list_2 = ['list_init_2']
    list_3 = ['list_init_3']
    list_4 = ['list_init_4']

    class A(object):
        list_0 = list_0

        @lazyperclassproperty
        def list_1(cls):
            return copy.deepcopy(cls.list_0)

        @lazyperclassproperty
        def list_2(cls):
            return cls.list_0 + ['list_2']

        @lazyperclassproperty
        def list_3(cls):
            return cls.list_2 + ['list_3']

    class B(A):
        list_0 = list_1


# Generated at 2022-06-26 02:39:11.410177
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    origin_file_path = os.path.abspath(os.path.dirname(__file__))
    file_name = os.path.basename(__file__)

    # Test Case:
    @lazyclassproperty
    def a(self):
        return "123"
    assert a == "123"



# Generated at 2022-06-26 02:39:16.199750
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def _get_lazyprop(self):
        print('lazy initialize')
        return 'value'

    class TestClass:
        lazyprop = _get_lazyprop

    assert TestClass.lazyprop == 'value'

    class TestSubClass(TestClass):
        pass

    assert TestSubClass.lazyprop == 'value'
    assert TestClass.lazyprop == 'value'



# Generated at 2022-06-26 02:39:25.263824
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import box.py3compat
    import box.classproperty

    class TestClass(object):
        @box.classproperty.lazyperclassproperty
        def list_0(cls):
            from box.py3compat import list_0
            return list_0(cls)

    class TestClass2(TestClass):
        pass

    TestClass.list_0.append(1)
    TestClass2.list_0.append(1)
    assert TestClass.list_0 == [1]
    assert TestClass2.list_0 == [1]



# Generated at 2022-06-26 02:39:33.740067
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import datatest

    class TestClass(object):
        _value = 'value'

        @lazyclassproperty
        def prop(cls):
            return cls._value + '_prop'

    @datatest.test
    def value():
        return TestClass._value
    @datatest.test
    def prop():
        return TestClass.prop
    @datatest.test
    def lazyclassproperty_test():
        return isinstance(prop, classproperty)
    @datatest.test
    def lazyclassproperty_test_1():
        return isinstance(prop, roclassproperty)
    @datatest.test
    def lazyclassproperty_test_2():
        return not isinstance(prop, property) and not isinstance(prop, setterproperty)

# Generated at 2022-06-26 02:39:34.722072
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(None) is None 


# Generated at 2022-06-26 02:39:37.949789
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(list) is not lazyclassproperty(list)
    assert lazyclassproperty(list) is lazyclassproperty(list)


# Generated at 2022-06-26 02:39:40.850134
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def for_lazyclassproperty(cls):
        return cls.fa
    cls = lazyclassproperty(for_lazyclassproperty)
    assert cls() == 2



# Generated at 2022-06-26 02:39:44.622565
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(None) is not None



# Generated at 2022-06-26 02:39:48.912804
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        foo = 1

        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert TestClass.bar == 'bar'
    assert TestClass.bar == 'bar'



# Generated at 2022-06-26 02:40:02.160799
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MetaA(type):
        @lazyperclassproperty
        def some_property(cls):
            return 'FOO'
    class A(metaclass=MetaA):
        pass

    assert(MetaA.some_property == 'FOO')
    assert(A.some_property == 'FOO')
    assert(A.some_property == 'FOO')
    assert(A().some_property == 'FOO')
    assert(A().some_property == 'FOO')

    class B(A):
        pass
    assert(B.some_property == 'FOO')
    assert(B.some_property == 'FOO')
    assert(B().some_property == 'FOO')
    assert(B().some_property == 'FOO')


# Generated at 2022-06-26 02:40:05.358458
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def value(cls):
        return str_0

    assert isinstance(value, property)
    assert value == 'value'

# Generated at 2022-06-26 02:40:12.846225
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class SomeClass(object):
        @lazyclassproperty
        def a_property(cls):
            return 5

    x = SomeClass()
    assert x.a_property == 5
    assert SomeClass.a_property == 5

    # Assert that the lazyclassproperty works across inheritance.
    class OtherClass(SomeClass):
        pass

    y = OtherClass()
    assert y.a_property == 5
    assert OtherClass.a_property == 5
    # Assert that the lazyclassproperty does not have its own copy.
    assert id(SomeClass.a_property) == id(OtherClass.a_property)
    assert id(x.a_property) != id(y.a_property)

    # Assert that the lazyclassproperty is cached.
    SomeClass.a_property = 10
    assert y.a_

# Generated at 2022-06-26 02:40:18.097924
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class B:
        pass

    @lazyclassproperty
    def str_0(cls):
        return 'value'

    assert hasattr(B, '_lazy_str_0') == False
    assert B.str_0 == 'value'
    assert hasattr(B, '_lazy_str_0') == True
    assert hasattr(B, 'str_0') == True



# Generated at 2022-06-26 02:40:19.864411
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:40:22.619277
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test function lazyclassproperty
    """
    def test_function(cls):
        return 'value'

    assertlazyclassproperty(test_function)


# Generated at 2022-06-26 02:40:29.487605
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Prepare test data
    str_1 = 'value'
    str_2 = 'value'
    test_case_0()
    str_3 = 'value'
    # Call function
    result = lazyperclassproperty(test_case_0())
    # Verify results
    assert result


# Generated at 2022-06-26 02:40:37.515355
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def _f(self):
            return "f is called"

        @lazyclassproperty
        def f(self):
            print(self._f())
            return self._f()

        def _h(self):
            return "h is called"

        @lazyclassproperty
        def h(self):
            print(self._h())
            return self._h()

    A._f = lambda: "f is updated"
    a = A()
    assert a.f == "f is called"
    assert A.f == "f is called"

    assert a.h == "h is called"
    assert A.h == "h is called"

    # after the access, fn is called. if fn is updated, returns the updated one
    a.f

# Generated at 2022-06-26 02:40:40.843373
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def value(cls):
            return 'value'
    print(A.value)



# Generated at 2022-06-26 02:40:44.700847
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def attr(cls):
            return 'value'
    test_case_0()
    assert A.attr == 'value'
    A.attr = 'test'
    assert A.attr == 'test'
    test_case_0()
    assert A.attr == 'value'


# Generated at 2022-06-26 02:40:49.043834
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:40:51.718180
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:56.873214
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    @classmethod
    def func(cls):
        return 'value'

    @lazyclassproperty
    def lazy_class_property(cls):
        return 'value'

    @lazyperclassproperty
    def lazy_class_property_perclass(cls):
        return 'value'

    class TestClass(object):
        @lazyclassproperty
        def lazy_class_property(cls):
            return 'value'

        @lazyperclassproperty
        def lazy_class_property_perclass(cls):
            return 'value'

    assert lazy_class_property == 'value', 'Failed to get expected value'
    assert TestClass.lazy_class_property == 'value', 'Failed to get expected value'

# Generated at 2022-06-26 02:41:01.987762
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyclassproperty
        def test_lazy_0(cls):
            return 'value'

    assert Test.test_lazy_0 == 'value'


# Generated at 2022-06-26 02:41:04.435849
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Setup
    class Test():
        @lazyperclassproperty
        def value(self):
            return 'value'

    # Teardown
    Test.value = 0
    # Test
    assert Test.value == 'value'


# Generated at 2022-06-26 02:41:08.924833
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    #assert test_case_0() == 
    pass


if __name__ == '__main__':
    lazyclassproperty(test_lazyclassproperty)

# Generated at 2022-06-26 02:41:10.315479
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:41:14.055751
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert_equals(lazyperclassproperty(test_case_0)(0), 'value')
    assert_equals(lazyperclassproperty(test_case_0)(1), 'value')


# Generated at 2022-06-26 02:41:20.840219
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_class = TestClass()

    func_0 = test_class.set_value
    func_1 = test_class.get_value

    assert func_1() == None
    func_0('value')
    assert func_1() == 'value'


# Generated at 2022-06-26 02:41:22.422773
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Class_0(object):
        @lazyclassproperty
        def method(cls):
            return 'value'

    str_1 = Class_0.method

    assert str_1 == 'value'

test_lazyclassproperty()


# Generated at 2022-06-26 02:41:36.032083
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    first = lazyperclassproperty(lambda x: x)
    second = lazyperclassproperty(lambda x: x)
    class A(object):
        first = first
        second = second

    class B(A):
        first = first
        second = second

    assert(A.first is A.first)
    assert(A.second is A.second)
    assert(B.first is B.first)
    assert(B.second is B.second)
    assert(A.first is not B.first)
    assert(A.second is not B.second)


# Generated at 2022-06-26 02:41:45.631690
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Create a function with a simple implementation
    @lazyperclassproperty
    def myClassFunc(cls):
        return 42

    # Create a couple classes
    class baseClass(object):
        pass

    class childClass(baseClass):
        pass

    # Verify that each class has its own version of myClassFunc
    print (baseClass.myClassFunc)
    print (childClass.myClassFunc)
    print (baseClass.myClassFunc != childClass.myClassFunc)
    print ((baseClass.myClassFunc == 42))
    print ((childClass.myClassFunc == 42))


if __name__ == '__main__':
    test_case_0()
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:41:46.935362
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty('s') == 's'



# Generated at 2022-06-26 02:41:48.519243
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_function():
        pass

    function_0 = lazyperclassproperty(test_function)


# Generated at 2022-06-26 02:41:50.677772
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def func_lazyclassproperty_0():
        return "ab"

    assert func_lazyclassproperty_0() == "ab"

# Generated at 2022-06-26 02:42:00.702518
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print(h_lazyperclassproperty.__doc__)

    class A:
        @lazyperclassproperty
        def some_attr(cls):
            print('executing...')
            return 'done'

    @add_metaclass(ABCMeta)
    class B:
        @lazyperclassproperty
        def some_attr(cls):
            print('executing with ABCMeta...')
            return 'done'

    class C(A):
        pass

    class D(B):
        pass

    assert A.some_attr == 'done'
    assert B.some_attr == 'done'
    assert C.some_attr == 'done'
    assert D.some_attr == 'done'


# Generated at 2022-06-26 02:42:09.202895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class TP:
        real_value = 0

        @lazyperclassproperty
        def lazyprop(cls):
            return cls.real_value

        @lazyperclassproperty
        def lazyprop_with_doc(cls):
            """Doc"""
            return cls.real_value

        @classmethod
        def set_real_value(cls, new_value):
            cls.real_value = new_value

    @lazyperclassproperty
    def lazyprop_for_function(cls):
        return 0

    class TP2(TP):
        pass

    assert TP.lazyprop == 0
    assert hasattr(TP.lazyprop, '__doc__')
    assert TP.lazyprop_with_doc == 0

# Generated at 2022-06-26 02:42:11.908097
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def fun():
        return 1
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert A.fun != B.fun != C.fun


# Generated at 2022-06-26 02:42:14.220363
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert (lazyclassproperty(lambda: 'Hi') == 'Hi')



# Generated at 2022-06-26 02:42:23.065861
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class MyClass(object):
        _lazy_result = None

        @lazyclassproperty
        def result(self):
            return 'result'

    assert MyClass._lazy_result is None
    assert MyClass.result == 'result'
    assert MyClass._lazy_result == 'result'
    assert MyClass.result == 'result'

    class MyClass(object):
        _lazy_result = None

        @lazyperclassproperty
        def result(cls):
            return 'result'

    assert MyClass._lazy_result is None
    assert MyClass.result == 'result'
    assert MyClass._lazy_result == 'result'
    assert MyClass.result == 'result'

    class MyChildClass(MyClass):
        pass

    assert MyChildClass._lazy

# Generated at 2022-06-26 02:42:33.989941
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # test case 0
    test_case_0()
    # test case 1
    # test case 2
    # test case 3
    # test case 4
    # test case 5
    # test case 6
    # test case 7
    # test case 8
    # test case 9
    # test case 10
    # test case 11
    # test case 12
    # test case 13
    # test case 14
    # test case 15
    # test case 16
    # test case 17
    # test case 18
    # test case 19
    # test case 20
    # test case 21
    # test case 22
    # test case 23
    # test case 24
    # test case 25
    # test case 26
    # test case 27
    # test case 28
    # test case 29
    # test case 30
    # test case 31

# Generated at 2022-06-26 02:42:35.556920
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # We do not have any test cases yet.
    assert False


# Generated at 2022-06-26 02:42:38.733008
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # TODO: Test is incomplete. Add better tests.
    list_0 = None
    lazyclassproperty_0 = lazyclassproperty(list_0)



# Generated at 2022-06-26 02:42:44.998165
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazy_property(cls):
            return 1

    class B(A):
        pass

    print(A.lazy_property)
    print(B.lazy_property)
    B.lazy_property = 2
    print(A.lazy_property)
    print(B.lazy_property)


# Generated at 2022-06-26 02:42:51.500199
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import copy

    class Foo(object):
        @lazyperclassproperty
        def t(cls):
            return copy.deepcopy(cls.__name__)

    class Bar(Foo):
        pass

    assert Foo.t is Foo.t
    assert Foo.t != Bar.t


if __name__ == '__main__':
    # Unit test for function lazyperclassproperty
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:52.459156
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(None)


# Generated at 2022-06-26 02:42:55.555853
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    instance_1 = lazyclassproperty()
    result = instance_1.__get__(None, 1)  # test for TypeError
    assert result is None


# Generated at 2022-06-26 02:42:58.717629
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    #  Example function
    def func(cls):
        return 'hello'

    @lazyclassproperty
    def lazyprop(cls):
        return func(cls)

    # Check the property
    assert lazyprop == 'hello'

# Generated at 2022-06-26 02:43:00.046357
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert not callable(lazyperclassproperty)



# Generated at 2022-06-26 02:43:04.847356
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Base(object):
        @lazyclassproperty
        def x(cls):
            print("lazy init")
            return 4

        @lazyclassproperty
        def y(cls):
            print("lazy init")
            return "bar"

    class Derived(Base):
        pass

    assert Base.x == 4
    assert Base.x == 4
    assert Derived.x == 4
    assert Derived.y == "bar"



# Generated at 2022-06-26 02:43:10.563598
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    fn = lazyperclassproperty(test_lazyperclassproperty)


# Generated at 2022-06-26 02:43:21.440602
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0) == lazyclassproperty(test_case_0)
    list_0 = [1, 2, 2, 3, 2, 4]
    setterproperty_0 = setterproperty(list_0)
    assert setterproperty_0
    assert setterproperty_0 == setterproperty(list_0, "")
    assert setterproperty_0 == setterproperty(list_0, 53)
    assert setterproperty_0 == setterproperty(list_0, True)
    assert setterproperty_0 == setterproperty(list_0, False)
    assert setterproperty_0 == setterproperty(list_0, None)
    assert setterproperty_0 == setterproperty(list_0, "")

# Generated at 2022-06-26 02:43:27.030198
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def test(cls):
        return 1
    class A(object):
        pass
    class B(object):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert test(A) == 1
    assert test(B) == 1
    assert test(C) == 1
    assert test(D) == 1
    A.test = 2
    assert test(A) == 2
    assert test(B) == 1
    assert test(C) == 1
    assert test(D) == 1



# Generated at 2022-06-26 02:43:37.869629
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class lazyclassproperty0:

        def __init__(self):
            pass

        def __eq__(self, other):
            pass

        def __hash__(self):
            pass
    class lazyclassproperty1(object):

        def __init__(self):
            pass

        def __eq__(self, other):
            pass

        def __hash__(self):
            pass

        @lazyclassproperty
        def lazyclassproperty0(cls):
            return int(str_0)
    class lazyclassproperty2(lazyclassproperty1):

        def __init__(self):
            pass

        def __eq__(self, other):
            pass

        def __hash__(self):
            pass
    lazyclassproperty0 = lazyclassproperty1()
    lazyclassproperty0 = lazyclassproperty2()
    lazy

# Generated at 2022-06-26 02:43:48.297872
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return 'bar of class {}'.format(cls)

    class Foo2(Foo):
        pass

    assert Foo.bar == 'bar of class __main__.Foo'
    assert Foo2.bar == 'bar of class __main__.Foo2'
    assert Foo2.__dict__['_Foo2_lazy_bar'] is Foo2.__dict__['_Foo_lazy_bar']
    assert Foo.bar == Foo2.bar
    # Ensure that the subclass attribute was not created
    with pytest.raises(AttributeError):
        Foo.__dict__['_Foo_lazy_bar']
    # Make sure there are no conflicts

# Generated at 2022-06-26 02:43:52.750755
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(lambda x: x) is not None



# Generated at 2022-06-26 02:44:04.458017
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class FakeClass(object):
        def __init__(self, value):
            self.value = value

    @lazyperclassproperty
    def test_fake_property(cls):
        return 'test-value'

    assert FakeClass('not-test-value').test_fake_property == 'test-value'

    class FakeSubClass(FakeClass):
        pass

    assert FakeSubClass('not-test-value').test_fake_property == 'test-value'

    # Check that we are caching separate objects for each class not globally
    assert FakeClass('not-test-value').test_fake_property != FakeSubClass('not-test-value').test_fake_property



# Generated at 2022-06-26 02:44:13.304316
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def foo(cls):
        return 'foo'

    @lazyperclassproperty
    def foo2(self):
        return 'foo2'

    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'
    
        @lazyperclassproperty
        def foo2(self):
            return 'foo'
    
    a = A()
    b = A()
    # create attribute on class
    assert A.foo == 'foo'
    # create attribute on class
    assert b.foo == 'foo'
    # create attribute on class
    assert a.foo == 'foo'
    # create attribute on class
    assert A.foo2 == 'foo2'
    # create attribute on class

# Generated at 2022-06-26 02:44:14.744287
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    raise NotImplementedError


# Generated at 2022-06-26 02:44:17.013856
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert len(re.findall(r'\w+', 'dog, cat, serial killers and geeks')) == 5


# Generated at 2022-06-26 02:44:26.635449
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def AB(self):
        return 1

    assert AB() == 1



# Generated at 2022-06-26 02:44:30.059153
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import io, sys, os, unittest, tempfile, contextlib, pathlib

    stdout, stderr = sys.stdout, sys.stderr
    @contextlib.contextmanager
    def stdout_stderr_redirector(stream):
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = stream
        sys.stderr = stream
        try:  
            yield
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr
    @contextlib.contextmanager
    def suppress_stdout():
        with stdout_stderr_redirector(io.StringIO()) as dummy_out:
            yield dummy_out

# Generated at 2022-06-26 02:44:36.514364
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:44:38.786020
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    list_0 = None
    classproperty_0 = classproperty(list_0)
    lazyperclassproperty_0 = lazyperclassproperty(classproperty_0)



# Generated at 2022-06-26 02:44:46.715155
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        def __init__(self):
            pass

        @lazyperclassproperty
        def foo(self):
            print("%s: foo()" % self.__class__.__name__)
            return "foo"

    class Bar(Foo):
        def __init__(self):
            pass

    f = Foo()
    b = Bar()
    assert f.foo == b.foo == "foo"
    f.foo = "foofoo"
    assert f.foo == "foofoo"
    assert b.foo == "foo"
    b.foo = "bar"
    assert f.foo == "foofoo"
    assert b.foo == "bar"


# Generated at 2022-06-26 02:44:49.871883
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        lazyprop = lazyclassproperty(lambda cls: len(cls.__name__))

    assert isinstance(A.lazyprop, roclassproperty)
    assert A.lazyprop == 1
    assert A().lazyprop == 1
    assert B.lazyprop == 1

    class B:
        pass

    assert B.lazyprop == 1



# Generated at 2022-06-26 02:44:51.966249
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def func(cls):
        return "ABC"
    assert_equal("ABC", func)


# Generated at 2022-06-26 02:44:53.147519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:44:56.478255
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def f():
            pass
    lazyclassproperty_0 = lazyclassproperty(A)
    assert_equal(lazyclassproperty_0, A)


# Generated at 2022-06-26 02:45:03.613048
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import random
    import hashlib
    random.seed(0)
    hashlib.sha1(b"").hexdigest()
    hashlib.sha1(b"").hexdigest()
    hashlib.md5(b"").hexdigest()
    hashlib.md5(b"").hexdigest()
    assert md5(b"").hexdigest() == "d41d8cd98f00b204e9800998ecf8427e"
    assert sha1(b"").hexdigest() == "da39a3ee5e6b4b0d3255bfef95601890afd80709"


# Generated at 2022-06-26 02:45:22.674195
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def func_0():
        pass

    lazyclassproperty_0 = lazyclassproperty(func_0)
    # <ref>


# Generated at 2022-06-26 02:45:32.238722
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class lazyperclassproperty_0(object):
        _lazyperclassproperty_0 = None
        def __init__(self):
            self._lazyperclassproperty_0 = []
        def __len__(self):
            return len(self._lazyperclassproperty_0)
        def __contains__(self, item):
            return item in self._lazyperclassproperty_0
        def __iter__(self):
            for i in range(len(self._lazyperclassproperty_0)):
                yield self._lazyperclassproperty_0[i]
        def append(self, item):
            self._lazyperclassproperty_0.append(item)
        def extend(self, item):
            self._lazyperclassproperty_0.extend(item)

# Generated at 2022-06-26 02:45:43.666762
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import sys
    import io
    import contextlib
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        class Foo(object):
            @classproperty
            def prop(cls):
                print("get class property foo")
                return "foo"

        class Bar(Foo):
            @property
            def prop(self):
                print("get property bar")
                return "bar"

        if "prop" in dir(Foo):
            del Foo.prop
        if "prop" in dir(Bar):
            del Bar.prop

        foo = Foo()
        print(foo.prop)
        print(Foo.prop)
        bar = Bar()
        print(bar.prop)
        print(Bar.prop)

# Generated at 2022-06-26 02:45:46.545016
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
  test_class = []

  @lazyperclassproperty
  def func():
    return test_class.__dict__

  var_1 = func
  assert var_1 == {'test_class': [], 'func': {}}, 'lazyperclassproperty'

# Generated at 2022-06-26 02:45:49.148007
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    list_0 = None
    lazyclassproperty_0 = lazyclassproperty(list_0)



# Generated at 2022-06-26 02:45:56.644480
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    a = 10

    @lazyclassproperty
    def a(cls):
        print("a is lazy property")
        return 10

    class A:
        a = a

    assert A.a == 10
    A.a = 11
    assert A.a == 11

    @classproperty
    def a(cls):
        print("a is lazy class property")
        return 10

    class A:
        a = a

    assert A.a == 10
    A.a = 11
    assert A.a == 11

    @lazyperclassproperty
    def a(cls):
        print("a is lazy class property")
        return 10

    class A:
        a = a

    class B(A):
        pass

    class A2:
        a = a

    assert A.a == 10

# Generated at 2022-06-26 02:46:01.961905
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def dummy_fn(param_0):
        return param_0
    dummy_fn.__name__ = 'dummy_fn'
    x = dummy_fn('dummy_str')
    assert x == 'dummy_str'


# Generated at 2022-06-26 02:46:04.237281
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_0(cls):
        return 1

    lazyclassproperty_0 = lazyclassproperty(test_0)
    print(lazyclassproperty_0)



# Generated at 2022-06-26 02:46:08.393557
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from inspect import getfullargspec as _gfa

    assert _gfa(lazyperclassproperty) == _gfa(lazyclassproperty)

    class A:
        @lazyperclassproperty
        def C(cls):
            return cls

    class B(A):
        pass

    assert A.C is A
    assert B.C is B
    assert A.C is A
    assert B.C is B


if __name__ == '__main__':
    test_lazyperclassproperty()
    print('Test passed!')

# Generated at 2022-06-26 02:46:17.833731
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random
    import time


    class MyClass(object):
        @lazyclassproperty
        def random_generator(cls):
            return random.Random()

        @lazyclassproperty
        def random_number(cls):
            return cls.random_generator.random()


    class MyClass2(MyClass):
        pass


    assert MyClass.random_generator.random() == MyClass.random_generator.random()  # this should be true, we don't want it to change each time
    assert MyClass.random_number == MyClass.random_number  # this should be true, we don't want it to change each time

    assert MyClass2.random_generator.random() == MyClass2.random_generator.random()  # this should be true, we don't want it to change each

# Generated at 2022-06-26 02:46:59.957829
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test for lazyclassproperty
    """

    def wrapper_lazyclassproperty(func, *args, **kwargs):
        """
        Wrapper for lazyclassproperty
        """

        @lazyclassproperty
        def wrapper_lazyclassproperty_inner(wrapped, instance, args, kwargs):
            """
            Wrapper for lazyclassproperty_inner
            """
            return wrapped(*args, **kwargs)
        return wrapper_lazyclassproperty_inner(func, *args, **kwargs)
    pass


# Generated at 2022-06-26 02:47:02.936728
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
      def __init__(self):
         self.x = None

      @lazyclassproperty
      def x_static(cls):
         return "hello"
    assert(MyClass.x_static == "hello")


# Generated at 2022-06-26 02:47:05.812965
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo():
        return 'fooooooo'

    if foo != 'fooooooo':
        print('Failed test_lazyclassproperty: foo')
        return False

    return True


# Generated at 2022-06-26 02:47:15.603315
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Verify that name and docstring are preserved.
    @lazyclassproperty
    def double(cls):
       """This computes 2 times the given number"""
       return 2 * cls._number
    class TestDouble:
       _number = 4
    assert double.__name__ == 'double'
    assert TestDouble.double.__doc__ == 'This computes 2 times the given number'
    assert TestDouble.double == 8
    TestDouble._number = 5
    assert TestDouble.double == 10
    TestDouble.double = 12
    assert TestDouble.double == 12
    TestDouble._number = 4
    assert TestDouble.double == 12
    # Verify that the property is actually cached.
    class TestCache:
        _number = 4
        @lazyclassproperty
        def cached(cls):
            "return number plus one"

# Generated at 2022-06-26 02:47:16.482299
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    lazyperclassproperty(list)



# Generated at 2022-06-26 02:47:17.280185
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass


# Generated at 2022-06-26 02:47:20.891161
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def roclassproperty_0(self):
        return self

    class_0 = type(None)
    lazyperclassproperty_0 = lazyperclassproperty(roclassproperty_0)
    assert_equal(lazyperclassproperty_0.f, roclassproperty_0)

# Definition of function lazyperclassproperty

# Generated at 2022-06-26 02:47:21.909698
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(instance_0)


# Generated at 2022-06-26 02:47:25.664653
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        def test_func(self):
            print('Function Called')
            return 'Value'

        @lazyperclassproperty
        def my_prop(cls):
            return cls().test_func()

    # call the property
    print(TestClass.my_prop)

    # call the function
    print(TestClass().test_func())

    # call the property again
    print(TestClass.my_prop)


if __name__ == '__main__':
    test_case_0()
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:47:33.454733
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Issue discovered with python3 version of roclassproperty
    # https://github.com/saltstack/salt/issues/43192
    class A(object):
        a = lazyperclassproperty(lambda c: 'A')
        b = lazyperclassproperty(lambda c: 'B')
    class B(A):
        c = lazyperclassproperty(lambda c: 'C')

    assert A.a == 'A'
    assert A.b == 'B'
    assert A().b == 'B'
    assert B.a == 'A'
    assert B.b == 'B'
    assert B.c == 'C'
    assert B().a == 'A'
    assert B().b == 'B'
    assert B().c == 'C'


if __name__ == "__main__":
    import doctest


# Generated at 2022-06-26 02:48:47.005376
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class_0 = None
    property_0 = lazyperclassproperty(class_0)
    return property_0


# Generated at 2022-06-26 02:48:51.746342
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class TestLazyClassProperty(unittest.TestCase):

        class Foo(object):

            @lazyclassproperty
            def bar(cls):
                return "baz"

        def test_lazyclassproperty(self):
            self.assertEqual(self.Foo.bar, "baz")

    unittest.main()


if __name__ == "__main__":
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:48:59.466749
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):

        def __init__(self):
            self._a = 0
            self._b = 0
            self._c = 0
            self._d = 0
            self._e = 0

        @lazyclassproperty
        def a(cls):
            return 1

        @lazyperclassproperty
        def b(cls):
            return cls._a

        @property
        def c(self):
            return self._c

        @c.setter
        def c(self, value):
            self._c = value

        @property
        def d(self):
            return self._d

        @d.setter
        def d(self, value):
            self._d = value
