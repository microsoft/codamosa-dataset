

# Generated at 2022-06-26 02:38:55.792046
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()

# Generated at 2022-06-26 02:38:56.916713
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:38:58.699987
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_class = lazyperclassproperty(lambda cls: cls.__name__)


# Generated at 2022-06-26 02:39:09.832368
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    dict_0 = dict()
    dict_0['G!%c'] = -34
    dict_0['f,uvio_47'] = 9
    dict_0['C:=*$vO'] = 20
    dict_0['wBK;A[Y'] = 1
    dict_0['ut?_6r'] = 1
    dict_0['^6zDU)o'] = 12
    dict_0['1:V:a+M'] = 1
    dict_0['cJ!Wg\n\\9'] = 0
    dict_0[':WJd~{y'] = 22
    dict_0['D]mfa|p'] = -5
    dict_0['*OL@xOt'] = 11
    dict_0['+M#~jKX'] = -2
    dict

# Generated at 2022-06-26 02:39:15.433209
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '6y\rFawEE"f-ivg{DCh>!'

    @lazyperclassproperty
    def str_1(str_2):
        return str_0

    roclassproperty_0 = roclassproperty(str_1)
    str_3 = str_1
    if __debug__:
        assert str_0 is str_3
        assert str_0 != str_3
    assert isinstance(str_1, str)


# Generated at 2022-06-26 02:39:20.035200
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def lazy(cls):
        print(cls)
        return cls.value

    class A(object):
        value = 123

    class B(A):
        pass

    class C(A):
        pass

    assert A.value == 123
    assert B.value == 123
    assert C.value == 123

    A.value = 456

    assert A.value == 456
    assert B.value == 123
    assert C.value == 123

    class D(C):
        pass

    assert D.value == 123

test_lazyperclassproperty()

# Generated at 2022-06-26 02:39:23.245728
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert_equals(lazyclassproperty(lambda: 1)(), 1)


# Generated at 2022-06-26 02:39:30.388275
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClassA:
        @lazyclassproperty
        def lazy_foo(cls):
            return 1

    assert TestClassA.lazy_foo == 1
    TestClassA.lazy_foo = 2
    assert TestClassA.lazy_foo == 2

    class TestClassB(TestClassA):
        pass

    assert TestClassB.lazy_foo == 1
    TestClassB.lazy_foo = 3
    assert TestClassB.lazy_foo == 3

    assert TestClassA.lazy_foo == 2


# Generated at 2022-06-26 02:39:31.976374
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)
    assert isinstance(lazyclassproperty, types.FunctionType)


# Generated at 2022-06-26 02:39:33.781482
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:39:38.319502
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # set up:
    test_case_0()

    assert lazyperclassproperty == None


# Generated at 2022-06-26 02:39:39.928811
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test case 0
    print(test_case_0())



# Generated at 2022-06-26 02:39:44.340401
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_cases = [
        # test_case_0
        (
            {
                "str_0": '6y\rFawEE"f-ivg{DCh>!',
            },
            True, # Test case should pass
        ),
    ]

    for test_case in test_cases:
        print("Case: %s" % test_case[0])
        assert test_lazyperclassproperty_0(test_case[0]) == test_case[1]



# Generated at 2022-06-26 02:39:56.910898
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '\\h*C=JX-^+<v)8W6U*h6U{'
    int_0 = 3
    int_1 = 2
    int_2 = 1
    int_3 = 0
    str_1 = 'Mg8(6W*Z:h(4X@'
    str_2 = 'h_V-UKxS='
    str_3 = 'W-$>o\x7fX1b;q'
    str_4 = '1tM#L-Dd^tBz~'
    str_5 = 'g'
    str_6 = 'NHy]N\\('
    str_7 = 'n_:l[9lKj'
    str_8 = '"*Ot2\x0fz^'
    str_9

# Generated at 2022-06-26 02:39:59.084207
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Input parameters
    # Output parameters
    # No output

    test_case_0()



# Generated at 2022-06-26 02:40:02.621313
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    x = lazyclassproperty(test_case_0)

# Generated at 2022-06-26 02:40:12.196904
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test_lazyclassproperty():
        def __init__(self):
            self.str_0 = '6y\rFawEE"f-ivg{DCh>!'
        @lazyclassproperty
        def method_0(self):
            """
            Str to int
            """
            return int(self.str_0)
        @lazyclassproperty
        def method_1(self):
            """
            Str to int
            """
            return int(self.str_0)
    _test_lazyclassproperty = test_lazyclassproperty()
    assert _test_lazyclassproperty.method_0 == 19562814260199074100387120557
    assert _test_lazyclassproperty.method_1 == 19562814260199074100387120557
   
# Unit test

# Generated at 2022-06-26 02:40:15.933146
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()
    def func_0(cls_0):
        return 0
    assert lazyclassproperty(func_0).__name__ == '_lazy_func_0'


# Generated at 2022-06-26 02:40:23.045462
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import md5
    class A(object):
        value = 0
        @lazyperclassproperty
        def value(cls): return 1

    class B(A):
        pass

    assert A.value == 1
    assert B.value == 1
    assert A.value == 1
    assert B.value == 1
    A.value = 2
    assert A.value == 2
    assert B.value == 1



# Generated at 2022-06-26 02:40:24.425990
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:40:35.226959
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import random
    import string

    # Test that each inheritor has its own instance of the lazy property
    class X:
        def __init__(self):
            self.s = ''.join(random.choice(string.ascii_letters) for i in range(10))

        @lazyperclassproperty
        def p(cls):
            return cls()

    class Y(X):
        pass

    assert X.p.s != Y.p.s

    # Test that the lazy property value is reused
    x_2 = X()
    assert x_2.p.s == X.p.s

    x_3 = X()
    assert x_3.p.s == X.p.s

    # Test that the lazy property is not shared across classes
    y_2 = Y()

# Generated at 2022-06-26 02:40:45.506979
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import random
    import string
    import threading

    class Foo:
        def __init__(self):
            self.str_0 = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(random.randint(6, 20)))
        def should_run_once_1(self):
            return self.str_0
        @lazyperclassproperty
        def should_run_once_2(cls):
            return cls.should_run_once_1()

    thread = threading.Thread(target=test_case_0)
    thread.start()
    test_0 = Foo()
    test_1 = Foo()
    test_2 = Foo()
    test_3 = Foo()
    test_4 = Foo()
    test_5 = Foo()
   

# Generated at 2022-06-26 02:40:49.651361
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    #@lazyclassproperty
    @lazyperclassproperty
    def testprop_lazyclassproperty(dummy):
        return 'hey'

    str_0 = testprop_lazyclassproperty


# Generated at 2022-06-26 02:40:52.848875
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Setup
    str_0 = '2\x1f%c\t#\x10'

    # Exercise
    # Verify
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:41:05.197037
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Base(object):
        def __init__(self, value):
            self.value = value

    class Test(Base):
        def __init__(self, value):
            super(Test, self).__init__(value)

        @lazyclassproperty
        def a(cls):
            print("a - %s"%cls.__name__)
            return cls.value


        @lazyclassproperty
        def b(cls):
            print("b - %s"%cls.__name__)
            return cls.value


    class TestSubClass(Test):
        def __init__(self, value):
            super(TestSubClass, self).__init__(value)


# Generated at 2022-06-26 02:41:09.823775
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for method lazyperclassproperty
    # Test for method lazyperclassproperty
    # Test for method lazyperclassproperty
    # Test for method lazyperclassproperty
    pass


# Generated at 2022-06-26 02:41:10.627489
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty()


# Generated at 2022-06-26 02:41:14.432403
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test 1
    result = lazyperclassproperty(test_case_0)
    assert type(result) == classproperty
    # Test 2
    result = lazyperclassproperty(test_case_0)
    assert type(result) == classproperty


# Generated at 2022-06-26 02:41:16.053762
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:41:22.165721
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print(lazyperclassproperty(test_case_0))
    print(test_case_0.__name__)

if __name__ == '__main__':
    test_lazyperclassproperty()


# Generated at 2022-06-26 02:41:27.068025
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '6y\rFawEE"f-ivg{DCh>!'
    str_1 = '^E\t\x01@=JBXr'
    str_2 = '^E\t\x01@=JBXr'
    lazyperclassproperty_0 = lazyperclassproperty(str_1)
    assert_equals(lazyperclassproperty_0, str_2)


# Generated at 2022-06-26 02:41:38.827394
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_1 = '6y\rFawEE"f-ivg{DCh>!'
    str_0 = '6y\rFawEE"f-ivg{DCh>!'
    str_2 = '6y\rFawEE"f-ivg{DCh>!'
    str_4 = '6y\rFawEE"f-ivg{DCh>!'
    str_5 = '6y\rFawEE"f-ivg{DCh>!'
    str_6 = '6y\rFawEE"f-ivg{DCh>!'
    str_3 = '6y\rFawEE"f-ivg{DCh>!'
    roclassproperty_1 = roclassproperty(str_0)
    str_2 = lazyperclassproperty(str_2)


# Generated at 2022-06-26 02:41:41.072234
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(str_0) == lazyperclassproperty(str_0)


# Generated at 2022-06-26 02:41:42.325488
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    lazyclassproperty_0 = lazyclassproperty("test")


# Generated at 2022-06-26 02:41:45.063750
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def prop(cls):
            print('prop init')
            return 5

    assert TestClass.prop == 5


# Generated at 2022-06-26 02:41:49.101766
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test_class:
        @lazyclassproperty
        def baz(cls):
            return "fafafafa"

        def __str__(self):
            return "test_class"
        __repr__ = __str__

    assert test_class.baz == "fafafafa"


# Generated at 2022-06-26 02:41:59.944460
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ExampleClass(object):
        """
        Example class for lazyperclassproperty function.
        """

        @lazyperclassproperty
        def prop_0(cls):
            print('Getting property for %s' % cls.__name__)
            return 42

        @lazyperclassproperty
        def prop_1(cls):
            return cls.prop_0 * cls.prop_0

    class InheritorClass(ExampleClass):
        pass

    class InheritorClass2(InheritorClass):
        pass

    print(ExampleClass.prop_0)
    print(ExampleClass.prop_1)
    print(InheritorClass.prop_0)
    print(InheritorClass.prop_1)
    print(InheritorClass2.prop_0)

# Generated at 2022-06-26 02:42:02.667997
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    num_0 = 14
    assert num_0 == 14


# Generated at 2022-06-26 02:42:04.573978
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(test_lazyclassproperty) == lazyclassproperty(test_lazyclassproperty)


# Generated at 2022-06-26 02:42:10.903312
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    This is a simple test case for the lazyperclassproperty.
    """
    class A(object):
        def __init__(self):
            self.is_init = True

        def return_array(self):
            return [1, 2, 3]

    @lazyperclassproperty
    def array_prop(cls):
        return A().return_array()

    class B(A):
        pass

    a = A()
    b = B()
    assert a.array_prop == b.array_prop and a.array_prop != a.return_array()

    class C(B):
        pass

    c = C()
    assert c.array_prop == b.array_prop and c.array_prop != a.array_prop and c.array_prop != a.return_array()

    # Test

# Generated at 2022-06-26 02:42:15.930210
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:42:18.230745
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert 1 == 1


# Generated at 2022-06-26 02:42:19.020294
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:42:21.597602
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class_0 = type(test_case_0())
    assert lazyperclassproperty(roclassproperty_0) is roclassproperty_0



# Generated at 2022-06-26 02:42:28.131817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import io
    import sys
    # captured output
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    # Call the function
    result = lazyperclassproperty(str)
    
    # restore stdout
    sys.stdout = sys.__stdout__

    # Return the function's return value
    return result


# Generated at 2022-06-26 02:42:32.464301
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyTest(object):
        @lazyclassproperty
        def test(cls):
            print(cls.__name__)
            return 'test'

    assert MyTest.test == 'test'
    assert MyTest.test == 'test'

    assert MyTest().test == 'test'
    assert MyTest().test == 'test'



# Generated at 2022-06-26 02:42:34.624948
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 'abc' == lazyperclassproperty(lambda: 'abc')

# Generated at 2022-06-26 02:42:36.542932
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    assert lazyclassproperty(str)(str) == str

    assert callable(lazyclassproperty(str))



# Generated at 2022-06-26 02:42:45.814761
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('test_lazyclassproperty')

    @lazyclassproperty
    def test_lazyclassproperty(x):
        return 'test_lazyclassproperty ok: %s' % x.__name__

    class A(object):
        pass

    class B(object):
        pass

    assert A.test_lazyclassproperty == 'test_lazyclassproperty ok: A'
    assert B.test_lazyclassproperty == 'test_lazyclassproperty ok: B'

if __name__ == '__main__':
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:42:51.090876
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '6y\rFawEE"f-ivg{DCh>!'
    str_1 = '6y\rFawEE"f-ivg{DCh>!'
    lazyclassproperty_0 = lazyclassproperty(str_0)
    assert_equal(lazyclassproperty_0, str_1)


# Generated at 2022-06-26 02:43:00.383299
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert inspect.isfunction(lazyclassproperty)


# Generated at 2022-06-26 02:43:07.245422
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test1:
        @lazyclassproperty
        def foo(self):
            return 'foo'
    assert Test1.foo == 'foo'

    class Test2(Test1):
        pass
    # Ensure that lazyclassproperty is cached per-class (or more accurately, per-class's-metaclass)
    assert not hasattr(Test2, '_lazy_foo')
    assert Test2.foo == 'foo'
    assert Test2.foo == 'foo'

    class Test3(Test1):
        @lazyclassproperty
        def foo(self):
            return 'bar'
    assert Test3.foo == 'bar'

    class Test4(Test1):
        @lazyclassproperty
        def foo(self):
            return 'baz'
    assert Test4.foo == 'baz'


# Generated at 2022-06-26 02:43:09.522446
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '6y\rFawEE"f-ivg{DCh>!'
    lazyclassproperty_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:43:10.885805
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert not lazyclassproperty()


# Generated at 2022-06-26 02:43:19.615231
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo():
        @lazyclassproperty
        def bar(cls):
            print('bar:bar:%s'%cls)
            return 'bar'

    class SubFoo(Foo):
        @lazyclassproperty
        def bar(cls):
            print('bar:bar:%s'%cls)
            return 'bar'

    print(Foo.bar)
    print(Foo.bar)
    print(SubFoo.bar)

if __name__ == '__main__':
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:43:21.681158
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str1 = 'lazyperclassproperty'
    roclassproperty_1 = roclassproperty(str1)



# Generated at 2022-06-26 02:43:23.753664
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def test_a_prop(cls):
        print('test_a_prop')
        return 42

    assert test_a_prop == 42



# Generated at 2022-06-26 02:43:33.898603
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from classdeco import lazyclassproperty
    object_0 = object()
    object_1 = object()

    class A(object):
        a = lazyclassproperty(lambda: object_0)

    assert A.a is object_0

    class B(A):
        pass

    assert B.a is object_0

    class C(A):
        a = lazyclassproperty(lambda: object_1)

    assert C.a is object_1

    # Unit test for function lazyperclassproperty
    from classdeco import lazyperclassproperty
    object_0 = object()
    object_1 = object()

    class A(object):
        a = lazyperclassproperty(lambda: object_0)

    assert A.a is object_0

    class B(A):
        pass

    assert B.a is not object_0


# Generated at 2022-06-26 02:43:35.138688
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(None) is not None

# Generated at 2022-06-26 02:43:36.038004
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass


# Generated at 2022-06-26 02:43:54.541900
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(str) == str
    assert lazyclassproperty(str) == str
    assert lazyperclassproperty(str) == str
    assert lazyperclassproperty(str) != str


# Generated at 2022-06-26 02:44:00.535920
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        @lazyclassproperty
        def foo(cls):
            return 'foo'

        @lazyperclassproperty
        def bar(cls):
            return 'bar'

    class B(A):
        pass


# Generated at 2022-06-26 02:44:03.488751
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 'lazyperclassproperty' in globals() or 'decorators.lazyperclassproperty' in globals()


# Generated at 2022-06-26 02:44:04.117983
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False


# Generated at 2022-06-26 02:44:08.195539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def test(cls):
            return cls.__name__

    assert Test.test == 'Test'
    assert Test().test == 'Test'
    assert Test.test == 'Test'
    assert Test.test == 'Test'


# Generated at 2022-06-26 02:44:11.800715
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '6y\rFawEE"f-ivg{DCh>!'

    @lazyperclassproperty
    def lazyperclassproperty_0(lazyperclassproperty_0):
        return str_0

    assert lazyperclassproperty_0 == str_0


# Generated at 2022-06-26 02:44:14.156208
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert (lazyperclassproperty(str)) == 'lazyperclassproperty_0'


# Generated at 2022-06-26 02:44:16.203898
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Testing function lazyperclassproperty')
    # No need to do anything here


# Generated at 2022-06-26 02:44:22.269986
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = 'q*^\r5r5>p"<9gv|]V*\t0A'
    str_1 = '(KU+#cexK=:{\';~6Ue'

    @lazyclassproperty
    def classproperty_0():
        return str_1

    @classproperty
    def classproperty_1():
        return str_0

    assert classproperty_0 == str_1
    assert classproperty_1 == str_0



# Generated at 2022-06-26 02:44:30.355138
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def f():
        return 1

    assert lazyperclassproperty(f)() == 1
    assert lazyperclassproperty(f).__get__(None, None) == 1

    def f():
        return 2

    assert lazyperclassproperty(f)() == 1
    assert lazyperclassproperty(f).__get__(None, None) == 1

    class C(object):
        @lazyperclassproperty
        def prop(cls):
            return 3

    assert C.prop() == 3
    assert C.prop == 3
    assert C.prop.__get__(None, C) == 3

    assert C.prop() == 3
    assert C.prop == 3
    assert C.prop.__get__(None, C) == 3

    class C2(C):
        pass

    assert C2.prop() == 3

# Generated at 2022-06-26 02:45:10.605742
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    call_count = [0]

    class TestClass(object):
        @lazyperclassproperty
        def test_property(cls):
            call_count[0] += 1
            return cls.__name__

    assert TestClass.test_property == 'TestClass'
    assert TestClass.test_property == 'TestClass'
    assert TestClass.test_property == 'TestClass'
    assert call_count[0] == 1

    class TestSubClass(TestClass):
        pass

    assert TestSubClass.test_property == 'TestSubClass'
    assert TestSubClass.test_property == 'TestSubClass'
    assert TestSubClass.test_property == 'TestSubClass'
    assert call_count[0] == 2

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-26 02:45:14.903696
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Make sure lazy class properties work by creating one
    @lazyclassproperty
    def test_property():
        return 'test'

    # Check that the property is defined once
    assert hasattr(test_property, '_lazy_test_property')
    assert test_property._lazy_test_property == 'test'
    # Check that the property points to the correct value
    assert test_property == 'test'
    # Change the value of the property
    test_property = 'new test'
    # Check that the property still points to the correct value
    assert test_property == 'new test'


# Generated at 2022-06-26 02:45:17.843398
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_lazyperclassproperty_0 = lazyperclassproperty(test_case_0)
    return test_lazyperclassproperty_0

if __name__ == '__main__':
    print(test_lazyperclassproperty())

# Generated at 2022-06-26 02:45:25.403224
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass():
        def __init__(self):
            self.x = 0
    @lazyperclassproperty
    def fun(cls):
        print('fun called')
        return cls().x
    class TestClass1(TestClass):
        pass
    class TestClass2(TestClass):
        pass

    assert TestClass1.fun == 0
    assert TestClass2.fun == 0
    #
    # def test_case_1():
    #     setterproperty_0 = setterproperty(str_0)
    #
    # def test_case_2():
    #     lazyclassproperty_0 = lazyclassproperty(str_0)



# Generated at 2022-06-26 02:45:29.589710
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Sample(object):
        @lazyclassproperty
        def x(cls):
            return 'abc'

        @lazyclassproperty
        def y(cls):
            return 'xyz'
    
    assert Sample.x == 'abc'
    assert Sample.y == 'xyz'
    

# Generated at 2022-06-26 02:45:30.617706
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    for i in range(0):
        assert lazyperclassproperty(str_0) == '"&{Pp<jsl/^d!}0G)sDxj'



# Generated at 2022-06-26 02:45:33.690895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def a_property(cls):
        print('Initializing a property')
        return 5

    class SomeClass(object):
        pass

    # Prints nothing
    print(SomeClass.a_property)

    # Prints 'Initializing a property'
    print(SomeClass.a_property)


# Generated at 2022-06-26 02:45:43.886867
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty not in globals()

    def example_fn(x):
        return 2 * x

    # test temp func to avoid scope issues
    def test_decorator(r_func, r_cls, r_fn):
        # test per class
        test_decorator.result = r_func(r_cls)
        assert test_decorator.result == r_fn(r_cls)

    class ClassA(object):
        # decorate a class property
        @lazyperclassproperty
        def prop(cls):
            return example_fn(cls) + 1

        @roclassproperty
        def prop_ro(cls):
            return example_fn(cls) + 1


    class ClassB(ClassA):
        pass


# Generated at 2022-06-26 02:45:45.931726
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 02:45:48.852395
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def dummy_function(*args):
        return True
    assert dummy_function == lazyclassproperty(dummy_function)()



# Generated at 2022-06-26 02:47:03.576403
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = str_1 = '6y\rFawEE"f-ivg{DCh>!'
    str_2 = '6y\rFawEE"f-ivg{DCh>!6y\rFawEE"f-ivg{DCh>!'
    roclassproperty_0 = roclassproperty(str_0)
    classproperty_0 = classproperty(str_1)
    setterproperty_0 = setterproperty(str_2)
    lazyclassproperty_0 = lazyclassproperty(str_0)
    lazyperclassproperty_0 = lazyperclassproperty(str_0)
    assert(type(roclassproperty_0) == roclassproperty)
    assert(type(classproperty_0) == classproperty)
    assert(type(setterproperty_0) == setterproperty)
   

# Generated at 2022-06-26 02:47:04.885470
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("Testing function lazyperclassproperty")
    test_case_0()

# Generated at 2022-06-26 02:47:14.312162
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from random import random
    from random import uniform
    from random import choice

    class Test_lazyclassproperty(unittest.TestCase):
        def testProp_0(self):
            str_0 = 'S!;>&LD'
            roclassproperty_0 = roclassproperty(str_0)

        def testProp_1(self):
            str_0 = 'I7V~]]>i3'
            roclassproperty_0 = roclassproperty(str_0)

        def testProp_2(self):
            str_0 = 'RcrN!SN/z;/'
            roclassproperty_0 = roclassproperty(str_0)

        def testProp_3(self):
            str_0 = 'w @'
            roclassproperty_0 = roclassproperty(str_0)


# Generated at 2022-06-26 02:47:21.728567
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
        class Foo:
            _g_value = 5
            _h_value = 5 * 2
            g = lazyperclassproperty(lambda x: x._g_value)
            h = lazyperclassproperty(lambda x: x._h_value)

        class Bar(Foo):
            _g_value = 10
            _h_value = 10 * 2

            @classmethod
            def some_method(cls):
                return cls.g

        assert(Foo.g == 5)
        assert(Bar.g == 10)
        assert(Bar.h == 5 * 2)
        assert(Bar.g == Bar.some_method())
        assert(Bar.g == Bar._h_value)



# Generated at 2022-06-26 02:47:23.870051
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '|lY"\x07$`-gx0h[A3]\\cH&0'
    lazyperclassproperty_0 = lazyperclassproperty(str_0)


# Generated at 2022-06-26 02:47:28.284092
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test:
        def __init__(self):
            self.count = 0

        @lazyperclassproperty
        def test_per_class_property(cls):
            return cls.count

    class TestSubclass(Test):
        pass

    assert Test.test_per_class_property == 0
    assert TestSubclass.test_per_class_property == 0
    Test.count = 2
    assert Test.test_per_class_property == 2
    assert TestSubclass.test_per_class_property == 0


# Generated at 2022-06-26 02:47:29.724565
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert(lazyclassproperty.__name__ == '_lazyclassprop')
    assert(lazyclassproperty.__doc__ == 'Lazy/Cached class property.')

# Generated at 2022-06-26 02:47:31.555980
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0)


# Generated at 2022-06-26 02:47:32.992621
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class_0 = classproperty(lazyperclassproperty)


# Generated at 2022-06-26 02:47:33.809211
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import pytest
    from pytest import raises
