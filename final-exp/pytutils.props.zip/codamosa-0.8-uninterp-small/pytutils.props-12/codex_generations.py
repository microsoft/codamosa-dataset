

# Generated at 2022-06-26 02:39:03.084782
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo:
        @lazyperclassproperty
        def test_attr(self):
            return 'I am the attr'

    assert Foo().test_attr == 'I am the attr'
    assert Foo().test_attr == 'I am the attr'
    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert Bar().test_attr == 'I am the attr'
    assert Baz().test_attr == 'I am the attr'
    assert Foo().test_attr == 'I am the attr'



# Generated at 2022-06-26 02:39:05.584198
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    tuple_0 = ()
    setterproperty_0 = setterproperty(tuple_0)


# Generated at 2022-06-26 02:39:06.737150
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class a(object):
        @lazyperclassproperty
        def foo(cls):
            return "bar"

    class b(a):
        pass

    a.foo
    b.foo



# Generated at 2022-06-26 02:39:08.547457
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    tuple_0 = ()
    lazyclassproperty_0 = lazyclassproperty(tuple_0)


# Generated at 2022-06-26 02:39:14.767341
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class sample_class:
        @lazyperclassproperty
        def sample_property(cls):
            return 'This is a sample property'

    class sample_class_2:
        @lazyperclassproperty
        def sample_property(cls):
            return 'This is a sample property'

    assert sample_class.sample_property == sample_class_2.sample_property
    assert id(sample_class.sample_property) != id(sample_class_2.sample_property)



# Generated at 2022-06-26 02:39:26.301286
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7

        @lazyclassproperty
        def x(cls):
            print('lazy evaluation!')
            return cls.a + cls.b

        def __repr__(self):
            return '<%s %s %s %s %s %s %s %s>' % (self.__class__.__name__, self.a, self.b, self.c, self.d, self.e, self.f, self.g)

    a = A()
    print(a.x)
    a.a = 11

# Generated at 2022-06-26 02:39:34.400728
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("foo!")
            return "foo"

        @lazyperclassproperty
        def bar(cls):
            print("bar!")
            return "bar"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def bar(cls):
            print("bar-C!")
            return "bar-C"

    a = A()
    b = B()
    c = C()

    # First, with A() as the context
    print("Calling with A() as context:")
    print("  a.foo:", a.foo)
    print("  a.foo:", a.foo)  # (repeat call to show it's cached)

# Generated at 2022-06-26 02:39:39.690761
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f(): pass
    assert f() is f()

    @lazyclassproperty
    def f2(): pass

    assert f2 != f2  # each class has its own property object

    @lazyclassproperty
    def f3(): pass

    assert f3 != f3  # each class has its own property object


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-26 02:39:49.011958
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ClassA:
        i = 0

        @lazyclassproperty
        def sum(cls):
            cls.i += 1
            return "%s" % cls.i

    # test
    assert ClassA.sum == '1'
    assert ClassA.sum == '1'

    # assert ClassA == 1
    # assert ClassA == 1



# Generated at 2022-06-26 02:39:51.009739
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_lazyperclassproperty) is not None


# Generated at 2022-06-26 02:39:59.704494
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ExampleClass(object):
        @lazyclassproperty
        def prop(cls):
            print("prop: %s" % cls)
            return 1

    assert ExampleClass.prop == 1

    class Subclass(ExampleClass):
        pass

    assert Subclass.prop == 1

    assert ExampleClass.prop == 1

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:40:09.397176
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Bar:
        @lazyclassproperty
        def my_property(cls):
            print('in lazyclassproperty')
            return 'test'
    print(Bar.my_property)
    print(Bar.my_property)
    Bar.my_property = 'another test'
    print(Bar.my_property)

if __name__ == '__main__':
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:40:21.724483
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import copy
    # A sample class that uses lazyperclassproperty
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            print("called")
            return ['Foo']

    class Baz(Foo):
        pass

    class Qux(Foo):
        pass

    obj = Foo()
    obj.bar = 'baz'
    assert obj.bar != 'baz'
    assert obj.bar == ['Foo']
    obj.bar = 'qux'
    assert obj.bar != 'qux'
    assert obj.bar == ['Foo']

    obj2 = Baz()
    obj2.bar = 'baz'
    assert obj2.bar != 'baz'
    assert obj2.bar == ['Foo']

    obj3 = Qux()

# Generated at 2022-06-26 02:40:25.690395
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # function lazyclassproperty
    global int_0
    global int_1
    int_1 = 0
    @lazyclassproperty
    def test_lazyclassproperty_0(cls):
        global int_0
        global int_1
        int_1 = int_1 + 1
    assert_equal(int_1, 0)
    int_0 = test_lazyclassproperty_0
    assert_equal(int_0, None)
    assert_equal(int_1, 1)
    int_0 = test_lazyclassproperty_0
    assert_equal(int_0, None)
    assert_equal(int_1, 1)


# Generated at 2022-06-26 02:40:30.469737
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def f(cls):
            print("call f()")
            return "F"

        _v = lazyclassproperty(f)

    a = A()
    assert a._v == "F"



# Generated at 2022-06-26 02:40:34.321147
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Class_0(object):
        int_0 = 0
        for i in range(100):
            int_0 = lazyperclassproperty(lambda x: i)
            print(int_0)
    test_case_0()
    test_obj = Class_0()
    print(test_obj.int_0)


if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:39.639033
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def lazy():
        return int_0
    # it runs
    assert lazy_0 == None
    print(lazy_0)
    print(int_0)


# Generated at 2022-06-26 02:40:45.127719
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def prop(cls):
            print('evaluating')
            return 42

    assert not hasattr(Foo, '_lazy_prop')
    assert not hasattr(Foo, 'prop')
    assert Foo.prop == 42
    assert Foo._lazy_prop == 42
    assert Foo.prop == 42
    assert not hasattr(Foo, '_lazy_prop')
    assert hasattr(Foo, 'prop')


# Generated at 2022-06-26 02:40:52.036828
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @lazyclassproperty
        def test_class_property(cls):
            return cls.a + cls.b

    test_obj = TestClass(1, 2)
    assert test_obj.test_class_property == 3

# Generated at 2022-06-26 02:41:04.847709
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyClassProperty(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @lazyclassproperty
        def temp(cls):
            print('cls.temp is called')
            return 2 * cls(1, 2)

    test_case_0()
    test_lazy = TestLazyClassProperty
    print(test_lazy.temp)
    print(test_lazy.temp)

    class TestLazyClassProperty2(TestLazyClassProperty):
        def __init__(self, a, b, c):
            super().__init__(a, b)
            self.c = c

    test_case_0()
    test_lazy2 = TestLazyClassProperty2

# Generated at 2022-06-26 02:41:08.259609
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo():
        x = lazyclassproperty(lambda _: True)
    assert Foo.x



# Generated at 2022-06-26 02:41:10.067534
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class lazyclassproperty_0(object):
        lazyclassproperty_0 = lazyclassproperty(None)
    try:
        assert False
    except AssertionError:
        assertTrue(False)


# Generated at 2022-06-26 02:41:15.084566
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Mock class to test against
    class A:
        @lazyclassproperty
        def lazy_prop(cls):
            return 1

    assert A.lazy_prop == 1

    # Mock inheriting class
    class B(A):
        pass

    assert B.lazy_prop == 1
    assert A.lazy_prop == 1

    # Mock inheriting class
    class C(A):
        @classproperty
        def lazy_prop(cls):
            return 2

    assert C.lazy_prop == 2
    assert B.lazy_prop == 1
    assert A.lazy_prop == 1



# Generated at 2022-06-26 02:41:21.295919
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class BaseClass0(object):
        @lazyclassproperty
        def func(cls):
            return super(BaseClass0, cls).__getattribute__('func')()

    assert BaseClass0.func


# Generated at 2022-06-26 02:41:28.969077
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    foo = {}
    Lazy = lazyclassproperty(lambda: foo)

    class A(object):
        Lazy = Lazy

    class B(A):
        pass

    A.Lazy = 'FOO'
    assert foo == 'FOO'
    assert A.Lazy == 'FOO'
    assert B.Lazy == 'FOO'

    B.Lazy = 'BAR'
    assert foo == 'BAR'
    assert A.Lazy == 'BAR'
    assert B.Lazy == 'BAR'

    A.Lazy = 'FOO'
    assert foo == 'FOO'
    assert A.Lazy == 'FOO'
    assert B.Lazy == 'FOO'

    with pytest.raises(AttributeError):
        foo.Lazy



# Generated at 2022-06-26 02:41:38.234831
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        return 1
    assert foo == 1
    assert foo == 1 # Run again to make sure it's memoized

    @lazyclassproperty
    def bar(cls):
        return lambda x: x
    assert bar('foo') == 'foo'

    @lazyclassproperty
    def baz(cls):
        return [1, 2, 3]
    assert baz[0] == 1

    class Peach:
        @lazyclassproperty
        def peach_prop(self):
            return 'peach'

    assert Peach.peach_prop == 'peach'

# Generated at 2022-06-26 02:41:43.288434
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def RESULT(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.RESULT == 'A'
    assert B.RESULT == 'B'
    assert C.RESULT == 'C'


# Generated at 2022-06-26 02:41:51.675020
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('Unit test for function lazyclassproperty')

    from functools import reduce

    class Base(object):
        @lazyclassproperty
        def all_subclasses(cls):
            return reduce(set.union,
                          (getattr(c, 'all_subclasses', set()) for c in cls.__subclasses__()),
                          set(cls.__subclasses__())) or set()

    class A(Base):
        pass

    class B(Base):
        pass

    class C(A):
        pass

    # assert C.all_subclasses == {C, B}
    assert set(Base.all_subclasses) == {A, B, C, Base}
    C.__subclasses__()
    assert set(C.all_subclasses) == {C}

# Generated at 2022-06-26 02:41:59.318081
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from random import randint
    class Test:
        @lazyperclassproperty
        def rand(cls):
            return randint(0, 1000)
    t = Test()
    assert callable(t.rand)
    assert isinstance(Test.rand, int)
    assert t.rand != Test.rand
    class Test2(Test):
        pass
    assert Test2.rand != Test.rand
    assert Test2.rand != t.rand


# Generated at 2022-06-26 02:42:00.045230
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True


# Generated at 2022-06-26 02:42:02.778168
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(True) == None

# Generated at 2022-06-26 02:42:04.427567
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_function(cls):
        return cls
    test_case_0()

# Generated at 2022-06-26 02:42:06.141170
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def _lazy_foo():
        return 42

    __class__ = None



# Generated at 2022-06-26 02:42:08.400250
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    f = lambda x: 1
    assert(lazyclassproperty(f) == 1)


# Generated at 2022-06-26 02:42:14.636053
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    from unittest import TestCase

    class A:
        @lazyperclassproperty
        def a(cls):
            print('calculating a', cls)
            return 1

    class B(A):
        pass

    a = A()
    b = B()

    # a.a should be 1
    TestCase.assertEqual(a.a, 1)
    # b.a should be 1 even though it's a different class
    TestCase.assertEqual(b.a, 1)
    # Now let's break it! (note the descriptor inheritance)
    b.a = 2
    # b.a should now be 2, but a.a should still be 1
    TestCase.assertEqual(b.a, 2)
    TestCase.assertEqual(a.a, 1)
    # Now let's

# Generated at 2022-06-26 02:42:23.255424
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class TestCase(object):
        def __init__(self):
            pass
        
        def func(self, str_0: str) -> str:
            return 'a' + str_0
        
        @lazyperclassproperty
        def func_instance(self):
            return self.func('b')

    class TestCase1(TestCase):
        def __init__(self):
            pass

    test_case_1 = TestCase()
    test_case_2 = TestCase()

    test_case_1_1 = TestCase1()
    test_case_2_2 = TestCase1()

    print(test_case_1.func_instance)
    print(test_case_2.func_instance)

    print(test_case_1_1.func_instance)

# Generated at 2022-06-26 02:42:29.946808
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class test_class(object):
        @lazyperclassproperty
        def test_lazyperclass(cls):
            return cls

    class test_class_2(test_class):
        pass

    assert test_class() is test_class().test_lazyperclass
    assert test_class_2() is test_class_2().test_lazyperclass
    assert test_class() is not test_class_2().test_lazyperclass


# Generated at 2022-06-26 02:42:33.371268
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def prop(cls):
            return 'result'

    a = A()
    assert a.prop == 'result'
    assert A.prop == 'result'
    A.prop = 'test'
    assert a.prop == 'test'
    assert A.prop == 'test'


# Generated at 2022-06-26 02:42:43.183591
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class test_lazyperclassproperty_class0(object):
        @lazyperclassproperty
        def a(self):
            return 5

    assert hasattr(test_lazyperclassproperty_class0, '_%s_lazy_a' % test_lazyperclassproperty_class0.__name__)
    assert test_lazyperclassproperty_class0._test_lazyperclassproperty_class0_lazy_a == 5
    test_0 = test_lazyperclassproperty_class0()
    assert test_0._test_lazyperclassproperty_class0_lazy_a == 5



# Generated at 2022-06-26 02:42:45.683325
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import abc
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            print('{0} called'.format(cls.__name__))
            return 123
    class TestA(Base):
        pass
    class TestB(Base):
        pass
    assert TestA.test == 123
    assert TestA.test == 123
    assert TestB.test == 123
    assert TestB.test == 123


# Generated at 2022-06-26 02:42:52.616595
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test0(object):
        @lazyperclassproperty
        def attr0(self):
            return 0
    assert Test0().attr0 == 0


    class Test1(Test0):
        pass

    assert Test0().attr0 == 0
    assert Test1().attr0 == 0



# Generated at 2022-06-26 02:42:53.892844
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(bytes)


# Generated at 2022-06-26 02:42:55.556392
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()

filters_registry = {}



# Generated at 2022-06-26 02:42:57.990507
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def bar(cls):
            return cls.__name__
    Foo.bar == "Foo"


# Generated at 2022-06-26 02:43:05.904640
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # If a class property describes a mutable object, such as a list or dictionary,
    # changes made to the object will affect all other instances of the class.
    # To avoid these side effects, you may use a factory function to return a new object each time
    # the property is accessed, as shown in the following example:
    class TestLazyClassProperty(object):
        @lazyperclassproperty
        def a(cls):
            return []


# Generated at 2022-06-26 02:43:14.317702
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def lazyperclassproperty_0(cls):
        return (cls + cls) + cls

    # Test error conditions
    with pytest.raises(TypeError) as excinfo:
        lazyperclassproperty_0(((object() if (6 < 0) else (object())), ))
    with pytest.raises(TypeError) as excinfo:
        lazyperclassproperty_0(True)
    with pytest.raises(TypeError) as excinfo:
        lazyperclassproperty_0(0)
    with pytest.raises(TypeError) as excinfo:
        lazyperclassproperty_0(0)

    # Test normal conditions
    assert True



# Generated at 2022-06-26 02:43:15.148432
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:43:25.632718
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from .context import saom
    from .structures import TestStructureClass
    from .structures import TestStructureSubclass

    test_structure_class = TestStructureClass()
    test_structure_subclass = TestStructureSubclass()

    assert TestStructureClass.lazyperclassproperty == 'Class property'
    assert TestStructureSubclass.lazyperclassproperty == 'Class property'
    assert test_structure_class.lazyperclassproperty == 'Class property'
    assert test_structure_subclass.lazyperclassproperty == 'Class property'

    assert TestStructureClass.lazyperinstanceproperty == 'Instance property'
    assert TestStructureSubclass.lazyperinstanceproperty == 'Instance property'
    assert test_structure_class.lazyperinstanceproperty == 'Instance property'
    assert test

# Generated at 2022-06-26 02:43:34.025916
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def foo(cls):
        return cls.__name__

    class Foo:
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    class Qux:
        pass

    assert foo.__get__(None, Foo) == 'Foo'
    assert foo.__get__(None, Bar) == 'Bar'
    assert foo.__get__(None, Baz) == 'Baz'
    assert foo.__get__(None, Qux) == 'Qux'


# Generated at 2022-06-26 02:43:35.638773
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def function_0():
        lazyperclassproperty_0 = lazyperclassproperty(function_0)
        return lazyperclassproperty_0



# Generated at 2022-06-26 02:43:49.839580
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def lazy_fn(cls):
        print("I am lazy!")
        return 42
    assert lazyclassproperty(lazy_fn) is not lazy_fn
    assert lazyclassproperty(lazy_fn).__name__ == "_lazy_lazy_fn"
    assert lazyclassproperty(lazy_fn).__doc__ == lazy_fn.__doc__
    assert lazyclassproperty(lazy_fn).__module__ == lazy_fn.__module__

    class Foo(object):
        lazyprop = lazyclassproperty(lazy_fn)

    assert Foo.lazyprop is 42
    assert Foo.lazyprop is 42
    assert Foo.lazyprop is 42


# Generated at 2022-06-26 02:43:56.217672
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def factory(cls):
        return "Hello"


    class Dumb(object):
        lazy = lazyclassproperty(factory)


    assert Dumb.lazy == "Hello"



# Generated at 2022-06-26 02:43:59.065388
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    assert A.a == 1


# Generated at 2022-06-26 02:44:01.464534
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    v1 = lazyperclassproperty(bytes_0)
    v2 = lazyperclassproperty(bytes_0)
    assert v1 is v2



# Generated at 2022-06-26 02:44:11.612399
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase, main

    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class TestLazyClassProperty(TestCase):
        def test_0(self):
            self.assertEqual(A.x, 1)
            self.assertEqual(B.x, 1)

        def test_1(self):
            A.x = 2
            self.assertEqual(A.x, 2)
            self.assertEqual(B.x, 1)
            B.x = 3
            self.assertEqual(A.x, 2)
            self.assertEqual(B.x, 3)

    if __name__ == '__main__':
        main()



# Generated at 2022-06-26 02:44:14.498922
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def fn_0():
        return None
    # call function lazyclassproperty with parameter fn
    lazyclassproperty(fn_0)


# Generated at 2022-06-26 02:44:19.786159
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert B.x == 'x'
    assert A.x == 'x'
    assert A.x != id(A.x)
    assert B.x != id(B.x)
    assert A.x == B.x



# Generated at 2022-06-26 02:44:22.215201
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class b:
        a = lazyclassproperty(lambda: 1)

    assert b.a == 1
    b.a = 2
    assert b.a == 2



# Generated at 2022-06-26 02:44:30.041298
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("Unit test for function lazyperclassproperty")
    @lazyperclassproperty
    def _prop(self):
        print("Using the property")
        return 42

    assert _prop == 42

    class ClassA:
        _prop = 42

    class ClassB(ClassA):
        pass

    assert ClassA._prop == 42
    assert ClassB._prop == 42

    ClassA._prop = 100
    assert ClassA._prop == 100
    assert ClassB._prop == 42

    ClassB._prop = 51
    assert ClassA._prop == 100
    assert ClassB._prop == 51

if __name__ == "__main__":
    print('Executing unit tests for lazyperclassproperty.py:')
    test_lazyperclassproperty()
    print('Finished unit tests for lazyperclassproperty.py')

# Generated at 2022-06-26 02:44:31.991039
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    attr_name = '_%s_lazy_%s' % ('cls', 'fn')
    pass


# Generated at 2022-06-26 02:44:49.493322
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(test_lazyclassproperty)

    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return 1

    class Bar(Foo):
        @lazyclassproperty
        def bar(cls):
            return 2

    assert Foo.foo == 1
    assert Foo.foo == 1
    assert Bar.foo == 1
    assert Bar.bar == 2


if __name__ == '__main__':
    """
    Run the unit tests for this module.
    """
    print('\n')
    unittest.main()

# Generated at 2022-06-26 02:44:51.965026
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def test(cls):
            return 'Hello World!'

    assert(Test.test == 'Hello World!')


# Generated at 2022-06-26 02:44:55.369356
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        @lazyclassproperty
        def prop(cls):
            return 1

    assert A.prop == 1

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:44:56.684340
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:45:01.580545
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test normal case
    try:
        print('testing function lazyperclassproperty')
        assert (True)
    except Exception as ex:
        print(str(ex))
        assert (False)
    # Test Exception case
    try:
        print('testing function lazyperclassproperty with Exception')
        raise Exception('This is a Exception')
    except Exception as ex:
        print(str(ex))
        assert (True)


# Generated at 2022-06-26 02:45:03.168552
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    assert lazyclassproperty(lambda: None) is None



# Generated at 2022-06-26 02:45:05.028281
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bytes_0 = None
    lazyclassproperty(bytes_0)
    bytes_0 = None
    lazyclassproperty(bytes_0)



# Generated at 2022-06-26 02:45:06.676661
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def f(arg_0):
        arg_0
        return arg_0
    print(f)


# Generated at 2022-06-26 02:45:09.208456
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test0:

        @lazyperclassproperty
        def f(cls):
            return 42

    class Test1(Test0):
        pass

    assert Test0.f == 42
    assert Test1.f == 42


# Generated at 2022-06-26 02:45:15.437387
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Dummy(): pass
    class DummyChild(Dummy): pass
    class DummyChildChild(DummyChild): pass

    @lazyperclassproperty
    def test(cls):
        return [cls]

    @lazyperclassproperty
    def test_two(cls):
        return [cls]

    assert id(test_two) != id(test)

    dummy = Dummy()
    dummy_child = DummyChild()
    dummy_child_child = DummyChildChild()

    assert id(test_two) != id(test)
    assert test == [Dummy]
    assert test_two == [Dummy]
    assert dummy.test == [Dummy]
    assert dummy.test_two == [Dummy]
    assert dummy_child.test == [DummyChild]
    assert dummy_

# Generated at 2022-06-26 02:45:41.122200
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:45:50.747970
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_val = {'__module__': 'test_class', '__doc__': None}
    # Test passing in a function
    test_fn = lambda: test_val
    lcp = lazyclassproperty(test_fn)
    class_obj = type('TestClass', (), {})
    assert lcp.__get__(class_obj) == test_val
    assert lcp.__name__ == '_lazy_' + test_fn.__name__

    # Test passing in a function with a doc string
    test_fn2 = lambda: test_val
    test_fn2.__doc__ = 'doc_string'
    lcp2 = lazyclassproperty(test_fn2)
    assert lcp2.__get__(class_obj) == test_val
    assert lcp2.__doc__ == test_fn

# Generated at 2022-06-26 02:45:57.490938
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    t_n = lambda cls: "some value"
    t_n1 = lazyperclassproperty(t_n)
    t_n2 = lazyperclassproperty(t_n)

    class S(object):
        t = t_n1

    s = S()
    assert s.t == "some value"
    assert S.t == "some value"
    S.t = "changed"
    assert s.t == "some value"
    assert S.t == "changed"

    class X(S):
        t = t_n2

    x = X()
    assert x.t == "some value"
    assert X.t == "some value"

    assert not hasattr(x, "__dict__")
    assert not hasattr(S, "__dict__")

# Generated at 2022-06-26 02:46:06.197753
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        return ['spam']

    assert foo is foo
    assert foo == ['spam']
    assert foo is foo
    assert foo == foo

    class Bar(object):
        pass

    assert foo is not Bar.foo
    assert foo == Bar.foo
    assert foo is not Bar.foo
    assert foo == Bar.foo

    assert foo is not Bar().foo
    assert foo == Bar().foo
    assert foo is not Bar().foo
    assert foo == Bar().foo

    assert foo is not foo
    assert foo == foo
    assert foo is not foo
    assert foo == foo



# Generated at 2022-06-26 02:46:08.937026
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    global roclassproperty_0
    assert roclassproperty_0 is not None

if __name__ == "__main__":
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:46:14.119737
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    if verbose:
        print("\nTesting function lazyclassproperty")
    class_0 = None
    functools_partial_0 = functools.partial(class_0)
    lazyclassproperty_0 = lazyclassproperty(functools_partial_0)
    # assert <condition>, <message>
    # assert <condition>
    # assert <message>, <condition>
    assert True


# Generated at 2022-06-26 02:46:16.577861
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def func_0(cls_0):
        return cls_0

    assertequals(lazyperclassproperty(func_0), lazyperclassproperty(func_0))


# Generated at 2022-06-26 02:46:21.635544
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass:
        @lazyclassproperty
        def test(cls):
            return "test"

        @lazyclassproperty
        def test_1(cls):
            return "test_1"

    # test1
    my_test_test = MyClass.test
    my_test_test_1 = MyClass.test_1



# Generated at 2022-06-26 02:46:22.705097
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert(lazyclassproperty is not None)



# Generated at 2022-06-26 02:46:28.747726
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
   

   @lazyperclassproperty
   def hello(cls):
       return "hello"

   def test():
       class A:
           pass

       assert A.hello == "hello"

       class B(A):
           pass

       assert B.hello == "hello"

       class C(A):
           pass

       assert C.hello == "hello"

       A.hello = "world"

       assert A.hello == "world"
       assert B.hello == "hello"
       assert C.hello == "hello"

# Generated at 2022-06-26 02:47:18.944122
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Assignments
    fn_0 = ''
    # Return call to function lazyperclassproperty
    return lazyperclassproperty(fn_0)


# Generated at 2022-06-26 02:47:22.655552
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A():
        @lazyclassproperty
        def test(cls):
            return 1
    class B(A):
        pass

    assert A.test == 1
    assert B.test == 1
    A.test = 2
    assert A.test == 2
    assert B.test == 1
    del A.test
    assert A.test == 1
    assert B.test == 1


# Generated at 2022-06-26 02:47:23.644750
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:47:29.827071
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import mock
    from io import BytesIO
    from src.utils.decorators import lazyclassproperty
    from src.utils.decorators import classproperty

    # Mock a class and a function
    m_cls_0 = mock.MagicMock(spec=classproperty)
    m_func_0 = mock.MagicMock(spec=BytesIO.readable)

    # Create lazyclassproperty
    lazyclassproperty_0 = lazyclassproperty(m_func_0)

    # Unit test for function lazyclassproperty
    def test_lazyclassproperty():
        from unittest import mock
        from io import BytesIO
        from src.utils.decorators import lazyclassproperty
        from src.utils.decorators import classproperty

        # Mock a class and a function
        m_cls_0 = mock

# Generated at 2022-06-26 02:47:36.718452
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("Testing lazyperclassproperty...")
    class C(object):
        @lazyperclassproperty
        def x(self):
            return 1234

    class C1(C):
        pass

    class C2(C):
        x = 5678

    assert C().x == 1234
    assert C1().x == 1234
    assert C2().x == 5678
    C2().x = 42
    assert C().x == 1234
    assert C1().x == 1234
    assert C2().x == 42

    print("Passed!")


# Generated at 2022-06-26 02:47:45.328468
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from random import shuffle

    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

    assert Foo.bar == 'Foo'
    assert Foo.bar == 'Foo'
    assert '_Foo_lazy_bar' in dir(Foo)

    class Bar(Foo):
        pass

    assert Bar.bar == 'Bar'
    assert Bar.bar == 'Bar'
    assert '_Foo_lazy_bar' in dir(Foo)
    assert '_Bar_lazy_bar' in dir(Bar)

    class Classy(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__


# Generated at 2022-06-26 02:47:46.873402
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def get_instance():
        return Class()
    classproperty_0 = lazyperclassproperty(get_instance)
    classproperty_0



# Generated at 2022-06-26 02:47:48.314707
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:47:52.933282
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def the_class_prop(cls):
            return 'value1'
    class B(A):
        pass

    assert A.the_class_prop == 'value1'
    assert B.the_class_prop == 'value1'
    A.the_class_prop = 'changed'
    assert A.the_class_prop == 'changed'
    assert B.the_class_prop == 'value1'



# Generated at 2022-06-26 02:48:02.770155
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test of a simple lambda function
    @lazyclassproperty
    def f(cls):
        return "test"
    assert f == "test"
    # Test of a lambda function that requires 2 arguments
    @lazyclassproperty
    def f(cls, a):
        return a
    assert f == 10
    assert f(10) == 10
    # Test of a function that uses a class property
    class A:
        @lazyclassproperty
        def b(cls):
            return cls.a
        a = 10
    assert A.b == 10
    # Test of a function that uses a class property
    class A:
        @lazyclassproperty
        def b(cls):
            return cls.a
        a = 10
    assert A.b == 10
    # Test of a fuction that uses