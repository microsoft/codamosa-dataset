

# Generated at 2022-06-26 02:38:57.561452
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True


# Generated at 2022-06-26 02:38:59.437536
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    result = lazyclassproperty("abcd")
    assert result == lazyclassproperty("abcd")


# Generated at 2022-06-26 02:39:10.638360
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    x = lazyperclassproperty(lambda: test_lazyperclassproperty_0())
    assert x == 0
    assert test_lazyperclassproperty_0.__name__ == '_MyClass_lazy_test_lazyperclassproperty_0'
    y = lazyperclassproperty(lambda: test_lazyperclassproperty_0())
    assert y == 0
    assert test_lazyperclassproperty_0.__name__ == '_MyClass_lazy_test_lazyperclassproperty_0'
    z = lazyperclassproperty(lambda: test_lazyperclassproperty_0())
    assert z == 0
    assert test_lazyperclassproperty_0.__name__ == '_MyClass_lazy_test_lazyperclassproperty_0'

global var_0
var_0 = 0



# Generated at 2022-06-26 02:39:14.069394
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    var_1 = lazyperclassproperty(test_case_0)

    assert_equal(test_lazyperclassproperty.test_lazyperclassproperty_0, None)
    test_lazyperclassproperty.test_lazyperclassproperty_0 = var_1


# Generated at 2022-06-26 02:39:20.310255
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from fractions import gcd
    from random import randint

    class LazyTest(object):

        def __init__(self, x, y):
            self.x = x
            self.y = y

        @lazyclassproperty
        def gcd(cls):
            return lambda x, y: gcd(x, y)

        @lazyperclassproperty
        def lcm(self):
            return lambda x, y: x * y // self.gcd(x, y)

    # Assuming that gcd works, test that lazyclassproperty works
    m = randint(0, 10)
    n = randint(0, 10)
    assert LazyTest.gcd(m, n) == gcd(m, n)

    # Assuming that gcd works, test that lazyperclassproperty works

# Generated at 2022-06-26 02:39:29.814190
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        count = 0

        @lazyclassproperty
        def prop(cls):
            cls.count += 1
            return cls.count

    assert A.prop == 1
    assert A.prop == 1
    assert A.prop == 1

    class B(A):
        pass

    assert B.prop == 1
    assert B.prop == 1
    assert B.prop == 1

    assert A.prop == 1
    assert A.prop == 1
    assert A.prop == 1

    c = A()
    assert c.prop == 1
    assert c.prop == 1
    assert c.prop == 1

# Generated at 2022-06-26 02:39:33.625720
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = 'c\x12\x06h\x0eb\x0c\\\x03\x87\x1c\x00\x11\x9d\x00'
    str_1 = '\x1d\x06o\x07\x06\x00\x0f\x97\x00\x00\x1a\x83\x00\x13\x15\x05\x02\x01\x08\x00\x08\x01\x11\x00\x13'

# Generated at 2022-06-26 02:39:38.175459
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_0 = lazyclassproperty(str_0)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:39:40.907974
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    @lazyperclassproperty
    def var_0():
        return str_0

    assert var_0 is str_0

# Generated at 2022-06-26 02:39:42.213048
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'L\x0c|<UG7$o"T'
    var_0 = lazyperclassproperty(str_0)



# Generated at 2022-06-26 02:39:56.978804
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import dill
    dill.settings['recurse'] = True

    def fn(x):
        return x

    cls = lazyclassproperty(fn)
    assert cls == fn

    # Default case
    lazyclassproperty(fn)

    # Duplicate case
    lazyclassproperty(fn)(fn)

    # Duplicate with hash(str) case
    lazyclassproperty(fn)(hash(str))

    # Empty case
    lazyclassproperty(fn)()

    # Empty with hash(str) case
    lazyclassproperty(fn)(hash(str))()

    # Case with hash(str)
    lazyclassproperty(fn)(hash(str))

    # Case with hash(str)
    lazyclassproperty(fn)(hash(str))

    # Case with hash(str)
    lazyclassproperty(fn)(hash(str))

   

# Generated at 2022-06-26 02:39:58.857792
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)



# Generated at 2022-06-26 02:40:05.832649
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        def foo(self):
            return 'foo'
        @lazyclassproperty
        def test_property(cls):
            return cls.foo()

    assert TestClass.test_property == 'foo'
    assert type(TestClass.test_property) == str


# Generated at 2022-06-26 02:40:07.800006
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_1 = 'h~bz]u,lXTo;i_'
    var_2 = lazyclassproperty(str_1)


# Generated at 2022-06-26 02:40:13.067017
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_0 = lazyclassproperty(str_0)
    assert var_0.func == str_0


# Generated at 2022-06-26 02:40:19.382713
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    s = 'test string'
    def func1():
        return s
    def func2():
        return s.split()
    class C(object):
        prop1 = lazyclassproperty(func1)
        prop2 = lazyclassproperty(func2)
    c = C()
    assert c.prop1 == s
    assert c.prop1 == s
    assert c.prop2 == s.split()
    assert c.prop2 == s.split()



# Generated at 2022-06-26 02:40:22.161635
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_0 = lazyclassproperty(str_0)
    assert var_0.__doc__ == 'Lazy/Cached class property.'


# Generated at 2022-06-26 02:40:24.728765
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert_equal(lazyclassproperty(lazyclassproperty), lazyclassproperty)



# Generated at 2022-06-26 02:40:28.013347
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:40:36.745772
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_1 = lazyperclassproperty(str_0)
    var_2 = var_1
    str_1 = 'gcxK\x0c|<UG7$o"T'
    var_3 = lazyperclassproperty(str_1)
    var_4 = var_3
    
# Asserts that the two variables both point to the same object
    assert var_2 is var_4

# Asserts that the two variables are not the same (false positive!)
    assert var_2 is not var_4

# Asserts that the two variables are equal
    assert var_2 == var_4

# Asserts that the two variables are not equal (false positive!)
    assert var_2 != var_4



# Generated at 2022-06-26 02:40:49.713218
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# _-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_


# Example of use
# @lazyclassproperty
# def get(self, class_name):
#     return MyClassFactory.create_by_name(class_name)



# Generated at 2022-06-26 02:40:52.603508
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def fn(cls):
            return 1

    class B:
        prop = lazyclassproperty(fn)

    assert B.prop == 1


# Generated at 2022-06-26 02:40:53.827099
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:40:56.359566
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def foo():
        return 7
    assert lazyclassproperty(foo) == 7


# Generated at 2022-06-26 02:40:57.103618
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True


# Generated at 2022-06-26 02:41:06.224618
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test: #1 (1.0s)
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_0 = lazyperclassproperty(str_0)
    assert var_0(hash) == 86729528565092517
    assert var_0.__name__ == '_hash_lazy_gcxK\x0c|<UG7$o"T'

    # We cannot compare the hash of a function with a precomputed value
    # because the hash is computed from the address of the function.
    # A simple test is to compare the hashes of two different functions.
    # Test: #2 (0s)
    assert hash(None) != hash(True)



# Generated at 2022-06-26 02:41:08.118584
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)



# Generated at 2022-06-26 02:41:09.419818
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:41:15.493042
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test edge cases: no param, 1 param, 2 params
    print("Test edge cases: no param, 1 param, 2 params")
    print(lazyclassproperty)

    @lazyclassproperty
    def test_no_param():
        print("In test_no_param")

    @lazyclassproperty
    def test_1_param(arg1):
        print("In test_1_param: " + str(arg1))

    @lazyclassproperty
    def test_2_param(arg1, arg2):
        print("In test_2_param: " + str(arg1) + ", " + str(arg2))

    class TempClass:
        def __init__(self, arg1, arg2):
            self.var1 = arg1
            self.var2 = arg2

        test_no_param

# Generated at 2022-06-26 02:41:21.667692
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_1 = 'gcxK\x0c|<UG7$o"T'
    var_1 = lazyperclassproperty(str_1)
    assert var_1 == 12, "wrong value returned"


# Generated at 2022-06-26 02:41:32.971374
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty is not None, 'Function "lazyclassproperty" is not defined, check your solution'


# Generated at 2022-06-26 02:41:40.586321
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # Test if the function returns the correct value with correct type
    # and correct behavior (when expected to be lazy)
    class Kls(object):
        def __init__(self):
            self.count = 0

        @lazyclassproperty
        def prop(cls):
            self = cls()
            self.count += 1
            return self, cls

        def check(self):
            assert self.prop[0] is self, "lazyclassproperty returned wrong instance"
            assert self.prop[1] is Kls, "lazyclassproperty returned wrong class"
            assert self.prop[0].count == 1, "lazyclassproperty returned wrong instance state"
            assert self.prop[0].count == self.count, "lazyclassproperty returned wrong instance state"

    i1 = Kls()
    i2 = Kls

# Generated at 2022-06-26 02:41:46.975372
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print("Test: lazyclassproperty")

    class MyClass(object):
        @lazyclassproperty
        def x(cls):
            return 'x'
        @lazyclassproperty
        def y(cls):
            return 'y'

    assert(MyClass.x == 'x')
    assert(MyClass.y == 'y')
    assert(MyClass.x == MyClass.x)
    assert(MyClass.y == MyClass.y)
    assert(MyClass.x != MyClass.y)



# Generated at 2022-06-26 02:41:55.100409
# Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:41:58.466349
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'

# Generated at 2022-06-26 02:42:02.957105
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test that the function is working
    dic_0 = test_case_0()
    assert dic_0 == {str_0: 'gcxK\x0c|<UG7$o"T'}
    # Test that the cached value is correct for multiple calls
    dic_1 = test_case_0()
    assert dic_1 == {str_0: 'gcxK\x0c|<UG7$o"T'}

# Cleanup
del str_0, var_0, dic_0, dic_1


# Generated at 2022-06-26 02:42:06.661437
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        @lazyclassproperty
        def var_0(cls):
            return TestClass.str_0

    TestClass.str_0 = 'gcxK\x0c|<UG7$o"T'

    var_0 = TestClass.var_0


# Generated at 2022-06-26 02:42:07.341098
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:42:09.716212
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# This is a standalone module, so test it here
if __name__ == '__main__':
    # Run unit tests
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:11.610841
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test with IRO 6c68669c3c00eacaf7bdd0da818d7f6bcccf6e7d
    test_case_0()

# Generated at 2022-06-26 02:42:30.892462
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print ("Testing function lazyclassproperty")
    test_case_0()

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:42:32.155135
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()

# Alternative implementation of function lazyperclassproperty

# Generated at 2022-06-26 02:42:34.658267
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    with pytest.raises(TypeError) as e_info:
        test_case_0()



# Generated at 2022-06-26 02:42:43.403795
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_0 = lazyperclassproperty(str_0)

    assert not hasattr(var_0, '_TestUnpacker_lazy_gcxK|<UG7$o"T')

# Generated at 2022-06-26 02:42:54.362447
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # This is an example code, but it's not very useful in practice.
    # A better way to do this is to setup a decorator that caches
    # the result of a call to the staticmethod.

    # Set up an example class
    class Example(object):
        @lazyclassproperty
        def STATIC_PROP(cls):
            print('executing property')
            return cls.static_method()

        @staticmethod
        def static_method():
            return 'the result'

    # Access STATIC_PROP
    print(Example.STATIC_PROP)  # Prints 'the result'

    # Access STATIC_PROP again
    print(Example.STATIC_PROP)  # Does not print anything. 'the result' from last time is used


# Generated at 2022-06-26 02:43:00.769621
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        def __init__(self):
            self.test_value = None

        @lazyclassproperty
        def test_prop(self):
            if self.test_value is None:
                self.test_value = 1
            else:
                self.test_value = self.test_value + 1
            return self.test_value

    assert TestClass().test_prop == 1
    assert TestClass().test_prop == 2
    assert TestClass().test_prop == 3



# Generated at 2022-06-26 02:43:07.633214
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Create mock object
    class MockClass:
        pass

    class MockClass2:
        pass

    def test_fun_1(_class):
        return _class

    def test_fun_2(_class):
        return _class

    test_var_0 = MockClass()
    test_var_1 = MockClass2()

    # Test the functionality of the decorated function
    assert lazyperclassproperty(test_fun_1)(test_var_0) == MockClass
    assert lazyperclassproperty(test_fun_2)(test_var_1) == MockClass2


# Generated at 2022-06-26 02:43:10.067401
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()

# ---------------------------------------------------------------------
# lazyclassproperty
# ---------------------------------------------------------------------

# Function lazyclassproperty is defined in the common.py module.


# Generated at 2022-06-26 02:43:11.080750
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:43:15.237488
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def attr(cls):
            print('Initializing attr on %s' % cls.__name__)
            return 1

    assert TestClass.attr == 1

    class TestSubClass(TestClass):
        pass

    assert TestSubClass.attr == 1
    assert TestSubClass.attr == 1

# Generated at 2022-06-26 02:43:54.893488
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test for lazyclassproperty
    """
    test_case_0()

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-26 02:43:56.795583
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:43:58.532369
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # YOUR CODE HERE
    raise NotImplementedError()



# Generated at 2022-06-26 02:44:05.492216
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def foo(cls):
            return "42"

    assert MyClass.__dict__['foo'].__doc__ == "Cached result from foo function"
    assert MyClass.foo == "42"
    assert MyClass.foo == "42"
    assert MyClass.__dict__['foo'].__doc__ == "Cached result from foo function"



# Generated at 2022-06-26 02:44:06.447585
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:44:06.949205
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty

# Generated at 2022-06-26 02:44:11.982707
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    var_0 = lazyperclassproperty(str_0)

    assert_equals(var_0.__class__.__name__, 'method_descriptor')
    assert_equal(var_0.__doc__, "Lazy/Cached class property that stores separate instances per class/inheritor so there's no overlap.")


# Generated at 2022-06-26 02:44:22.408525
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # <Value '_lazy_str_0' (0x01152c48)> undefined
    assert var_0.__doc__.strip() == 'gcxK\x0c|<UG7$o"T'
    # <Value '_lazy_str_0' (0x01152c48)> undefined
    assert var_0._lazyclassprop.__doc__.strip() == 'gcxK\x0c|<UG7$o"T'
    # <Value '_lazy_str_0' (0x01152c48)> undefined
    assert var_0.has_key('gcxK\x0c|<UG7$o"T')
    # <Value '_lazy_str_0' (0x01152c48)> undefined
    assert var_0.has_key

# Generated at 2022-06-26 02:44:23.240478
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:44:24.059471
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:45:44.673168
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):

        def __init__(self):
            self.x = 5
            self.y = 10

        @lazyperclassproperty
        def TestClass_lazypcprop_TestClass(cls):
            return cls.x + cls.y

        @lazyclassproperty
        def TestClass_lazyprop_TestClass(cls):
            return cls.x + cls.y

    class TestClass2(TestClass):
        x = 1
        y = 2

        @lazyperclassproperty
        def TestClass2_lazypcprop_TestClass2(cls):
            return cls.x + cls.y


# Generated at 2022-06-26 02:45:45.444245
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:45:48.851489
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test that the function doesn't raise an exception
    try:
        __var_0 = lazyclassproperty(str)
    except:
        raise AssertionError('lazyclassproperty raised an exception')



# Generated at 2022-06-26 02:45:49.652257
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty('123') == '123'

# Generated at 2022-06-26 02:45:53.589840
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty("abc")("def") == "abcdef"
    assert lazyperclassproperty("abc")("def") == "abcdef"
    assert lazyperclassproperty("abc")("def") == "abcdef"
    assert lazyperclassproperty("abc")("def") == "abcdef"
    assert lazyperclassproperty("abc")("def") == "abcdef"



# Generated at 2022-06-26 02:45:55.483690
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    #get the function for lazyclassproperty
    lazyclass = lazyclassproperty(str)
    print(lazyclass)
    assert lazyclass()==str


# Generated at 2022-06-26 02:46:05.596297
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from collections import OrderedDict
    from .utils import datadict
    data = datadict()
    class C(object):
        def __init__(self):
            pass

        @lazyclassproperty
        def b(cls):
            return 1

        @lazyclassproperty
        def items(cls):
            return data.items()

        @property
        def a(self):
            return 2

    assert C.b == 1
    assert C().a == 2
    assert C().b == 1
    assert C.a == 2
    assert C().items == data.items()
    assert isinstance(C().items, OrderedDict)
    assert isinstance(C.items, OrderedDict)



# Generated at 2022-06-26 02:46:09.818320
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        def __init__(self, d=0):
            self.d = d
            
        @lazyperclassproperty
        def b(self):
            return self.d
        
    a = A(1)
    assert(a.b == 1)


# Generated at 2022-06-26 02:46:11.724999
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test lazyclassproperty with default arguments
    assert lazyclassproperty(str_0) == str_0


# Generated at 2022-06-26 02:46:12.850989
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True == True


# Generated at 2022-06-26 02:48:46.466521
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'gcxK\x0c|<UG7$o"T'
    str_1 = 'gcxK\x0c|<UG7$o"T'
    int_0 = decode_xor(str_0)
    int_1 = decode_xor(str_1)
    assert (int_0 == int_1)

# Generated at 2022-06-26 02:48:54.108493
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)
    assert hasattr(lazyclassproperty, '__doc__')
    assert lazyclassproperty.__doc__
    assert callable(lazyclassproperty.__doc__)
    assert lazyclassproperty.__doc__()
    assert lazyclassproperty(lazyclassproperty)
    assert lazyclassproperty(str)
    assert lazyclassproperty(str())
    assert lazyclassproperty(int)
    assert lazyclassproperty(int())
    assert lazyclassproperty(float)
    assert lazyclassproperty(float())
    assert lazyclassproperty(list)
    assert lazyclassproperty(list())
    assert lazyclassproperty(dict)
    assert lazyclassproperty(dict())
    assert lazyclassproperty(tuple)
    assert lazyclassproperty(tuple())
    assert lazyclassproperty(set)
    assert lazyclassproperty

# Generated at 2022-06-26 02:48:56.101177
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def class_function():
        print('hello')
        return 1

    # checks that class_function is lazy
    assert class_function == 1
    assert class_function == 1

