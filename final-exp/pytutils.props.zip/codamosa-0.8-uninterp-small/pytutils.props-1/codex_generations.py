

# Generated at 2022-06-26 02:38:59.001229
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_lazyperclassproperty_0():
        roclassproperty_0 = None
        lazyperclassproperty(roclassproperty_0)

    test_lazyperclassproperty_0()


# Generated at 2022-06-26 02:39:02.442735
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(lambda x: "foo") == "foo"
    assert lazyclassproperty(lambda x: x.foo) == "bar"


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:39:09.067901
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    tester = __file__[:-3] + "_tester.py"
    retval = subprocess.call("python " + tester, shell=True)
    if retval != 0:
        raise Exception("Unit test for lazyperclassproperty failed!")

if __name__ == '__main__':
    import sys
    import subprocess
    subprocess.call("python " + __file__[:-3] + "_tester.py", shell=True)

# Generated at 2022-06-26 02:39:10.092077
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True


# Generated at 2022-06-26 02:39:11.965564
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Let the function coverage testing procedure begin
    assert lazyclassproperty(None) == None



# Generated at 2022-06-26 02:39:13.589982
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty


# Generated at 2022-06-26 02:39:14.564601
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True



# Generated at 2022-06-26 02:39:16.986245
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty.__doc__ is not None

    assert callable(lazyclassproperty(lambda x: True))
    assert lazyclassproperty(lambda x: True)(1) is True



# Generated at 2022-06-26 02:39:20.572401
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for the default value of the arguments
    var_0 = lazyperclassproperty()
    assert isinstance(var_0, lazyperclassproperty)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 02:39:23.354667
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Test lazyperclassproperty')
    test_case = 0

# Generated at 2022-06-26 02:39:26.782855
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:39:30.996030
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_variable_0 = None
    roclassproperty_0 = None
    var_0 = lazyperclassproperty(roclassproperty_0)
    var_0.__set__(roclassproperty_0, test_variable_0)
    var_0.f = roclassproperty_0
    var_0.__get__(roclassproperty_0)



# Generated at 2022-06-26 02:39:32.328745
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    roclassproperty_0 = None
    var_0 = lazyperclassproperty(roclassproperty_0)

# Generated at 2022-06-26 02:39:33.740367
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    roproperty_0 = None
    var_0 = lazyclassproperty(roproperty_0)


# Generated at 2022-06-26 02:39:34.464280
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True == True



# Generated at 2022-06-26 02:39:38.354867
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('Testing lazyclassproperty')

    class Foo:
        @lazyclassproperty
        def bar(cls):
            return cls

    assert(Foo.bar == Foo)



# Generated at 2022-06-26 02:39:39.966628
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False, "No unit test defined for function lazyperclassproperty"

# Generated at 2022-06-26 02:39:41.782754
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("Testing lazyperclassproperty...", end="")
    assert (test_case_0() is True)
    print("Passed!")

# Program test for function lazyperclassproperty

# Generated at 2022-06-26 02:39:45.329129
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        def __init__(self):
            self._x = None

        @lazyclassproperty
        def x(cls):
            print('Initializing x')
            cls._x = 'foo'
            return cls._x

    assert MyClass.x == 'foo'
    assert MyClass.x == 'foo'


# Generated at 2022-06-26 02:39:48.237978
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert inspect.isclass(lazyperclassproperty)

    # Call function lazyperclassproperty
    test_case_0()



# Generated at 2022-06-26 02:40:02.426881
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:40:06.678330
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty() == None, \
        'Incorrect default value for argument: lazyperclassproperty'
    # Uncomment this section if you want to test function arguments
    # test_case_0()



# Generated at 2022-06-26 02:40:07.844839
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    lazyclassproperty_0 = None
    var_1 = lazyclassproperty(lazyclassproperty_0)


# Generated at 2022-06-26 02:40:08.666521
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:40:13.140087
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test functions
    def function_0():
        # Testing function lazyclassproperty
        @lazyclassproperty
        def function_0():
            return "abcd"

        var_0 = function_0()
        assert var_0 == "abcd"
    function_0()

    def function_1():
        # Testing function lazyclassproperty
        class Class_1:
            @lazyclassproperty
            def function_1(cls):
                return cls.__name__

        var_0 = Class_1.function_1
        assert var_0 == "Class_1"
    function_1()

    # Restore original function
    perflogger.lazyclassproperty = lazyclassproperty_0


# Generated at 2022-06-26 02:40:15.556645
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class_0 = object
    var_0 = lazyclassproperty(class_0)



# Generated at 2022-06-26 02:40:16.956054
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)



# Generated at 2022-06-26 02:40:25.888240
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # When the class property @lazyclassproperty is defined and called, it should create the cached property on the class
    class MyClass:
        @lazyclassproperty
        def get_random_int(cls):
            return random.randint(0, 10)

    assert hasattr(MyClass, '_lazy_get_random_int')
    assert MyClass.get_random_int is MyClass.get_random_int

    # When the class property @lazyclassproperty is defined and called, it should create the property on the class
    class MyClass:
        @lazyclassproperty
        def get_random_int(cls):
            return random.randint(0, 10)

    assert hasattr(MyClass, '_lazy_get_random_int')

# Generated at 2022-06-26 02:40:31.127232
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    var_0 = lazyperclassproperty(lazyclassproperty)
    assert var_0.__str__() == "<class 'utils.lazyperclassproperty.<locals>._lazyclassprop'>", "Incorrect output for method utils.lazyperclassproperty()"



# Generated at 2022-06-26 02:40:33.996312
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Arrange
    roclassproperty_0 = None

    # Act
    var_0 = lazyperclassproperty(roclassproperty_0)

    # Assert
    assert callable(var_0)
    assert isinstance(var_0, lazyperclassproperty)


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:42.982448
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    roclassproperty_0 = None
    var_0 = lazyperclassproperty(roclassproperty_0)


# Generated at 2022-06-26 02:40:44.869518
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:40:46.904761
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:40:48.792587
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    roclassproperty_0 = None
    test_case_0(roclassproperty_0)

# Generated at 2022-06-26 02:40:50.704452
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert_equals(lazyperclassproperty(f), f)

# Generated at 2022-06-26 02:40:53.272349
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print ("Test for function lazyperclassproperty")
    test_case_0()

if __name__ == '__main__':
    print ("Running tests")
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:41:05.389729
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return "Foo A"

    class B(A):
        @lazyclassproperty
        def foo(cls):
            return "Foo B"

    class C(B):
        pass

    class D(B):
        @lazyclassproperty
        def foo(cls):
            return "Foo D"

    # Test that class property is cached
    assert A.foo == "Foo A"
    assert A.foo == "Foo A"

    # Test that subclasses cached their own class property
    assert B.foo == "Foo B"
    assert A.foo == "Foo A"

    # Test that D.foo is not the same as B.foo (which is in the cache)

# Generated at 2022-06-26 02:41:06.807130
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test type
    assert isinstance(var_0, roclassproperty)
    assert isinstance(var_0, lazyperclassproperty)

# Generated at 2022-06-26 02:41:07.602481
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:41:10.582481
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    global roclassproperty_0

    roclassproperty_0 = None
    var_0 = lazyperclassproperty(roclassproperty_0)



# Generated at 2022-06-26 02:41:26.696668
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert None == "a"


# Generated at 2022-06-26 02:41:29.378163
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_1 = None
    ts = lazyclassproperty(test_1)


# Generated at 2022-06-26 02:41:32.905564
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(None)  # FIXME


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-26 02:41:39.971163
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    
    import unittest


    class LazyClassPropertyTest(unittest.TestCase):

        def test_lazy_class_property(self):
            class A(object):
                @lazyclassproperty
                def a(cls):
                    return 100

            class B(A):
                pass
            self.assertTrue(A.a is B.a)

        def test_lazy_per_class_property(self):
            class A(object):
                @lazyperclassproperty
                def a(cls):
                    return 100

            class B(A):
                pass
            self.assertTrue(A.a is not B.a)
    unittest.main()



# Generated at 2022-06-26 02:41:49.140678
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo:
        pass

    class Bar(Foo):
        pass

    @lazyperclassproperty
    def foo_bar(cls):
        return object()

    foo_bar_foo = foo_bar
    foo_bar_bar = foo_bar

    assert foo_bar_foo is foo_bar_bar

    class Foo_:
        pass

    class Bar_(Foo_):
        pass

    @lazyperclassproperty
    def foo_bar_(cls):
        return object()

    foo_bar_foo_ = foo_bar_
    foo_bar_bar_ = foo_bar_

    assert foo_bar_foo_ is foo_bar_bar_

    assert foo_bar_foo is not foo_bar_foo_


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:41:50.277447
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:42:00.929098
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for __init__
    fn_0 = None
    var_1 = lazyperclassproperty(fn_0)
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    var_1.f
    # Test for __get__
    fn_0 = None
    var_2 = lazyperclassproperty(fn_0)
    var_2.f
    var_2.f
    var_2.f
    var_2.f
    var_2.f
    var_2.f
    var_2.f
    var_2.f
    var_2.f
    var_2.f

# Generated at 2022-06-26 02:42:07.342475
# Unit test for function lazyclassproperty
def test_lazyclassproperty():	
    c = 0
    def f(cls):
        return cls.__name__
    class Foo:
        @lazyclassproperty
        def name(cls):
            global c
            c += 1
            return cls.__name__
    class Bar(Foo):
        pass
    class Baz(Bar):
        pass

    assert c == 0
    a = Foo.name
    b = Bar.name
    c = Baz.name
    assert c == 1
    assert a == b == c == 'Foo'

# Generated at 2022-06-26 02:42:10.924587
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    field_0 = lazyperclassproperty(function_0)
    call_0 = field_0
    call_1 = call_0()
    assert_not_equals(call_1, None)

    field_1 = field_0

    with raises(TypeError):
        call_2 = field_1()



# Generated at 2022-06-26 02:42:22.111132
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    _INFO = "<module>:" + "test_lazyclassproperty" + ": "

    def _test_class_run(test_class):
        test_case_0 = test_class
        var_0 = lazyclassproperty(test_case_0)

    def _subtest_1():
        _INFO = "<module>:" + "test_lazyclassproperty" + ":_subtest_1" + ": "
        class _DummyClass_0(object):
            __module__ = "obj_t_utils__test_lazyclassproperty"

        _test_class_run(_DummyClass_0)

    def _subtest_2():
        _INFO = "<module>:" + "test_lazyclassproperty" + ":_subtest_2" + ": "

# Generated at 2022-06-26 02:42:52.320095
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()
# -----------------------------------------------------------------------------


# Generated at 2022-06-26 02:42:57.342350
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from pyccel.pyccel_ast_factories import ClassFactory
    cl = ClassFactory('roclassproperty_0')
    var_0 = lazyclassproperty(cl)
    #assert var_0.name == '_lazy_roclassproperty_0'
    assert str(var_0) == '_lazy_roclassproperty_0'

# Generated at 2022-06-26 02:42:58.673914
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    d = lazyperclassproperty()
    assert d.__name__ == 'd'

# Generated at 2022-06-26 02:43:00.350269
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    lazyclassproperty_0 = None
    var_0 = lazyclassproperty(lazyclassproperty_0)

# Generated at 2022-06-26 02:43:04.274970
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Testing function lazyperclassproperty')

    # function lazyperclassproperty
    roclassproperty_0 = None
    var_0 = lazyperclassproperty(roclassproperty_0)
    print(var_0)

# main function call
if __name__ == '__main__':
    test_case_0()
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:43:13.580896
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase, mock

    class A(object):
        def __init__(self):
            pass

        @lazyclassproperty
        def my_class_prop(cls):
            return 'Class property'

    a = A()
    assert a.my_class_prop == a.my_class_prop
    assert a.my_class_prop == 'Class property'
    assert a.my_class_prop == A.my_class_prop

    class B(A):
        pass

    assert B.my_class_prop == 'Class property'
    assert B.my_class_prop == a.my_class_prop

    # Verify that the property is cached.

# Generated at 2022-06-26 02:43:14.652418
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert not lazyclassproperty(lambda: None)

# Generated at 2022-06-26 02:43:25.182209
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import sys
    import StringIO
    import unittest
    class TestLazyperclassproperty(unittest.TestCase):
        def setUp(self):
            pass

        def test1(self):
            # from samples.simple_0 import *
            self.assertEqual(var_0, None)

    test_suite = unittest.TestSuite()
    test_suite.addTest(unittest.makeSuite(TestLazyperclassproperty))
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO.StringIO()
    unittest.TextTestRunner(verbosity=2).run(test_suite)
    sys.stdout = old_stdout

# Generated at 2022-06-26 02:43:26.584316
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    roclassproperty_0 = None
    var_0 = lazyclassproperty(roclassproperty_0)

# Generated at 2022-06-26 02:43:34.319110
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from unittest import mock
    import sys

    m_cls = mock.MagicMock(spec=lazyperclassproperty)
    m_cls.__name__ = 'lazyperclassproperty'
    m_cls.__module__ = __name__
    sys.modules[__name__] = m_cls

    import pkg
    pkg.lazyperclassproperty(2)

    m_cls.assert_called_with(2)

## Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:44:32.609393
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True == True



# Generated at 2022-06-26 02:44:34.375612
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    res = lazyperclassproperty(roclassproperty)
    assert res == classproperty



# Generated at 2022-06-26 02:44:40.228346
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    import sys

    class TestLazyClassProperty(unittest.TestCase):
        def setUp(self):
            class DummyClass(object):
                @lazyclassproperty
                def test_props(cls):
                    return 'gotcha'

            self.dummy = DummyClass()

        def test_props(self):
            self.failUnlessEqual(self.dummy.test_props, 'gotcha')

    try:
        unittest.main()
    except SystemExit:
        pass

# Generated at 2022-06-26 02:44:41.721460
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(roclassproperty).__name__ in dir(lazyclassproperty)


# Generated at 2022-06-26 02:44:44.240887
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Call function 'lazyclassproperty'
    roclassproperty_0 = None
    # Assert instance (obj_0) type
    assert isinstance(lazyclassproperty(roclassproperty_0), type)


# Generated at 2022-06-26 02:44:47.633830
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    for var_line_1 in range(0, 5):
        var_line_0 = 0
        assert var_line_0 == 0
    return

test_lazyperclassproperty()


# Generated at 2022-06-26 02:44:56.830769
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Make sure the code provided doesn't return a type error
    try:
        import types
        import inspect
        if inspect.isclass(roclassproperty) and hasattr(roclassproperty, '__call__'):
            var_0 = roclassproperty(None)
        else:
            raise AssertionError('roclassproperty is not a class or does not have a method call')
    except:
        raise AssertionError('Error during roclassproperty call')
    else:
        pass

    # Make sure the code provided doesn't return a type error

# Generated at 2022-06-26 02:44:57.660010
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:45:02.322142
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Set up test data
    value = 16

    class TestClass:
        def get_value(cls):
            return value

        # Check that property value is cached
        assert_func = lazyclassproperty(get_value)

    # Call the function
    TestClass()
    TestClass()
    TestClass()

    # Check the results
    assert TestClass.assert_func() == 16


test_lazyclassproperty()

# Generated at 2022-06-26 02:45:07.463580
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    cls = type("type_0", (), {})
    fn = None
    kwargs = {'cls_0': cls, }
    classproperty_0 = classproperty(fn, **kwargs)
    var_0 = lazyclassproperty(classproperty_0)
    attr_name = '_lazy_' + fn.__name__
    var_1 = cls.attr_name
    assert var_0.attr_name == var_1


# Generated at 2022-06-26 02:47:08.789612
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    with pytest.raises(AttributeError):
        roclassproperty_0 = None
        var_0 = lazyclassproperty(roclassproperty_0)


# Generated at 2022-06-26 02:47:12.572932
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test in case the function should returns a value
    roclassproperty_0 = None
    var_0 = lazyclassproperty(roclassproperty_0)
    # Test in case the function should returns a value
    roclassproperty_2 = None
    var_2 = lazyclassproperty(roclassproperty_2)


# Generated at 2022-06-26 02:47:18.294960
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Prepare testing enviroment
    BH = lambda x: x+1
    class A:
        def __init__(self):
            self._L = []
        @lazyclassproperty
        def L(cls):
            """
            Get the list of do_things function
            """
            return self._L

    # Pre-test
    assert len(A.L) == 0
    # Run-test
    A.L.append("test")
    # Post-test
    assert "test" in A.L

# Generated at 2022-06-26 02:47:19.578527
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 1 == 1

test_lazyperclassproperty()


# Generated at 2022-06-26 02:47:23.164741
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for example use of lazyperclassproperty
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            print('Calculating bar property.')
            return 10

    class Bar(Foo):
        pass

    assert Foo.bar == 10
    assert Foo.bar == 10
    assert Bar.bar == 10
    assert Bar.bar == 10



# Generated at 2022-06-26 02:47:26.563800
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Throw exception for invalid type
    assert_raises(TypeError, lazyperclassproperty, tuple)

    # Throw exception for invalid type
    assert_raises(TypeError, lazyperclassproperty, 1)

    # Throw exception for invalid type
    assert_raises(TypeError, lazyperclassproperty, 1.0)


if __name__ == "__main__":
    run_local_tests()

# Generated at 2022-06-26 02:47:35.340423
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random

    class Example(object):
        @lazyclassproperty
        def rand(cls):
            return random.random()

    # The first time Example.rand is accessed, a new random number is generated
    print(Example.rand)

    # Subsequent calls to Example.rand return the same value
    print(Example.rand)

    # Example2.rand gets a new random number
    class Example2(object):
        @lazyclassproperty
        def rand(cls):
            return random.random()

    # Example2.rand and Example.rand are different
    print(Example2.rand)
    print(Example.rand)
    assert Example.rand != Example2.rand



# Generated at 2022-06-26 02:47:36.601344
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    with pytest.raises(Exception):
        test_case_0()
    pass

# Generated at 2022-06-26 02:47:45.211666
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # example of lazyperclassproperty
    import xml.etree.ElementTree as ET
    import re
    class ClassOne:
        """
        First test class
        """
        path_0 = lazyperclassproperty(lambda ClassOne: re.compile(r"\w+"))
        def method_0(self, var_0):
            """
            First method
            """
            xml_0 = var_0.method_0()
            return self.path_0.findall(var_0.method_0())
        def method_1(self):
            """
            Second method
            """
            pass
    class ClassTwo(ClassOne):
        """
        Second test class
        """
        def method_0(self, var_0):
            """
            First method
            """
            pass

# Generated at 2022-06-26 02:47:53.143391
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        # '''
        # Test class property
        # '''
        attr_name = '_lazy_test'
        # assert not hasattr(Test, attr_name), "attr_name should not be set at this point."

        @lazyclassproperty
        def test(cls):
            return "Test"
        # assert hasattr(Test, attr_name), "attr_name should be set at this point."
        # assert getattr(Test, attr_name) == "Test", "attr_name should be set to \"Test\"."

    assert Test.test == "Test"

    class Test2(Test):
        pass
        # assert Test2.test == "Test", "Test2.test should return \"Test\"."
        # assert Test2.test == Test.test, "Test2.test