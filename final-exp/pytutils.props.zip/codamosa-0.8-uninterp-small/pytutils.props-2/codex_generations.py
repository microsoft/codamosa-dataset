

# Generated at 2022-06-26 02:39:00.506981
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Testing Code Here
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return "foo"
    # Testing Code End
    assert A.foo == "foo"
    class B(A):
        pass
    assert A.foo == "foo"
    assert B.foo == "foo"
    A.foo = "foobar"
    assert A.foo == "foobar"
    assert B.foo == "foo"


# Generated at 2022-06-26 02:39:07.911458
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    file_path = os.path.abspath('test_file.txt')
    with open(file_path, mode='w', encoding='utf-8') as fo:
        fo.write(str(time.time()))
    assert str((lazyclassproperty(time.sleep)._lazyclassprop.__doc__)) == ("Return the current time in seconds since the "
                                                                  "Epoch.")
    with open(file_path) as fo:
        assert float(fo.read()) > 0



# Generated at 2022-06-26 02:39:09.321918
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:39:10.500894
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:39:12.961885
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def test_classproperty(cls):
            return 123
    assert Foo.test_classproperty == 123


# Generated at 2022-06-26 02:39:16.869607
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    cls_1 = type('1', (object,), {})
    cls_2 = type('2', (cls_1,), {})
    @lazyperclassproperty
    def test(cls):
        return cls
    assert cls_1.test is cls_1
    assert cls_2.test is cls_2


# Generated at 2022-06-26 02:39:18.685399
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo():
       return 'bar'

    assert foo == 'bar'


# Generated at 2022-06-26 02:39:20.671198
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    lazyperclassproperty_0 = lazyperclassproperty('+yrd.h' + 'R}8')


# Generated at 2022-06-26 02:39:23.454999
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:39:24.696089
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:39:33.428824
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def test_property(cls):
        return TestClass()

    assert TestClass().test_property == TestClass().test_property
    assert TestClass().test_property is TestClass().test_property
    assert TestClass().test_property != TestSubclass().test_property
    assert TestClass().test_property is not TestSubclass().test_property

    @lazyperclassproperty
    def test_property(cls):
        return cls

    assert TestClass().test_property == TestSubclass().test_property

if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:39:34.939354
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_lazyperclassproperty) == lazyperclassproperty(test_lazyperclassproperty)


# Generated at 2022-06-26 02:39:40.531849
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # func_0 is for test case 0
    def func_0(cls):
        return cls

    # func_1 is for test case 1
    def func_1(cls):
        str_0 = '09P%Vp#s$G:uT7'
        lazyclassproperty_0 = lazyclassproperty(str_0)
        return lazyclassproperty_0

    # func_2 is for test case 2
    def func_2(cls):
        str_0 = '@.iVtT(:tTdT7'
        lazyclassproperty_1 = lazyclassproperty(str_0)
        return lazyclassproperty_1

    # func_3 is for test case 3
    def func_3(cls):
        str_0 = 'A.iVtT(:tTdT7'

# Generated at 2022-06-26 02:39:51.756333
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random
    import string

    def rand_string(length=10):
        return ''.join(random.choice(string.ascii_letters) for i in range(length))

    class Foo(object):
        _hello = None
        _world = None

        @lazyclassproperty
        def hello(cls):
            if not cls._hello:
                cls._hello = rand_string()
            return cls._hello

        @lazyclassproperty
        def world(cls):
            if not cls._world:
                cls._world = rand_string()
            return cls._world

    class Bar(Foo):
        pass

    assert Foo.hello == Foo.hello
    assert Foo.world == Foo.world

    assert Foo.hello != Bar.hello
    assert Foo.world != Bar.world



# Generated at 2022-06-26 02:40:02.301749
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase, main
    from textwrap import dedent
    from functools import partial, reduce

    class Test(TestCase):
        _missing = object()

        def __getattribute__(self, item):
            if item.startswith('test_') and item not in ('test_foo', 'test_bar'):
                return partial(self._run_test_case, item)
            return TestCase.__getattribute__(self, item)


# Generated at 2022-06-26 02:40:04.249153
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(''.join)


# Generated at 2022-06-26 02:40:05.761470
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(B)


# Generated at 2022-06-26 02:40:15.695500
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    v1 = 1
    v2 = 2
    v3 = 3

    class Foo:
        def __init__(self):
            self.foo = 1

        @lazyclassproperty
        def prop(cls):
            return 1


    class Bar(Foo):
        def __init__(self):
            super(Bar, self).__init__()
            self.bar = 2

        @lazyclassproperty
        def prop(cls):
            return 2


    assert Foo.prop == 1
    assert Bar.prop == 2
    foo = Foo()
    bar = Bar()
    assert foo.prop == 1
    assert bar.prop == 2



# Generated at 2022-06-26 02:40:23.182665
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test_Test():
        def __init__(self, test_0=None):
            self.test_0 = test_0

        def method_0(self, test_0=None):
            return test_0

        lazy_0 = lazyclassproperty(method_0)
    test_test_0 = Test_Test(0)
    assert test_test_0.method_0(0) == 0
    assert test_test_0.lazy_0 == 0


# Generated at 2022-06-26 02:40:34.467990
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from hashlib import md5
    from random import randint

    class A:
        @lazyclassproperty
        def lazy_method(cls):
            return md5(str(randint(0, 1000000)).encode()).digest()

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert A.lazy_method == a.lazy_method == b.lazy_method == c.lazy_method


# Generated at 2022-06-26 02:40:42.532204
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def foo(cls):
        return []

    assert(foo is foo)
    foo.append("bar")
    assert(foo == ["bar"])



# Generated at 2022-06-26 02:40:52.138229
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    my_class = type('MyClass', (), {})
    my_class_prop_var = 0

    @lazyclassproperty
    def a_class_property():
        nonlocal my_class_prop_var
        my_class_prop_var += 1
        return my_class_prop_var

    assert a_class_property == 1
    assert a_class_property == 1
    my_class = type('MyOtherClass', (), {})
    assert a_class_property == 2
    assert a_class_property == 2



# Generated at 2022-06-26 02:40:56.712118
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    buffer = pytest.dbt.schemas[0].tables[0]
    assert buffer.columns == lazyclassproperty.dbt._lazyclassprop(buffer)


# Generated at 2022-06-26 02:40:58.064018
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Return type unknown
    return


# Generated at 2022-06-26 02:41:03.299423
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '^],'
    classproperty_0 = classproperty(str_0)
    classproperty_0.test_classproperty_0(str_0)

    assert classproperty_0.test_classproperty_0(str_0) == expect_0


# Generated at 2022-06-26 02:41:09.760928
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    import tempfile
    import shutil
    import os
    from itertools import zip_longest

    import requests
    import requests_cache
    requests_cache.install_cache(os.path.join(tempfile.gettempdir(), 'requests-cache-test'))

    class A(object):
        @lazyclassproperty
        def prop(cls):
            return "{}-prop".format(cls.__name__)

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return "{}-prop".format(cls.__name__)

    class D(C, B):
        pass

    class E(C, B):
        @lazyclassproperty
        def prop(cls):
            return

# Generated at 2022-06-26 02:41:15.743747
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    local_0 = 20
    class LazyProperties(object):
        @lazyclassproperty
        def lazyprop_1(cls):
            return cls.inc_counter(local_0)

        @classproperty
        def lazyprop_2(cls):
            pass

        @lazyperclassproperty
        def lazyprop_4(cls):
            return cls.inc_counter()

        @classproperty
        def lazyprop_5(cls):
            pass

    class LazyPropertiesDescendants(LazyProperties):
        @lazyperclassproperty
        def lazyprop_3(cls):
            return cls.inc_counter()

        @classproperty
        def lazyprop_6(cls):
            pass

    assert LazyProperties.inc_counter(0) == 0

    assert Lazy

# Generated at 2022-06-26 02:41:20.025381
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    result = lazyperclassproperty(test_case_0)
    assert (result == lazyperclassproperty(test_case_0))


# Generated at 2022-06-26 02:41:28.596597
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:41:31.317712
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def test():
        return 'test'
    assert test == 'test'

# Generated at 2022-06-26 02:41:47.277887
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test that the `__doc__` attribute is not lost when using a function as a
    # decorator.
    @lazyperclassproperty
    def foo():
        """Return a value."""
        return 'bar'

    def class_with_foo():
        class X:
            foo = foo
        return X

    assert class_with_foo().foo == "bar"
    assert class_with_foo.foo == "bar"

    assert class_with_foo().foo == "bar"
    assert class_with_foo.foo == "bar"

    assert X.foo == "bar"

    assert X.foo.__doc__ == "Return a value."



# Generated at 2022-06-26 02:41:47.841936
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass


# Generated at 2022-06-26 02:41:51.021401
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # If a class property is lazily evaluated, it can be called multiple times
    # without running the created function multiple times.

    @lazyclassproperty
    def _some_property(cls):
        print('evaluated')
        return cls

    assert _some_property != _some_property
    assert _some_property != _some_property



# Generated at 2022-06-26 02:41:52.924936
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print('Test lazyclassproperty')
    test_case_0()
if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:42:02.587864
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import sys
    import random
    import unittest


    class Test(unittest.TestCase):
        def test(self):
            counter = []

            class Foo(object):
                @lazyclassproperty
                def bar(cls):
                    counter.append(0)
                    return random.random()

            foo = Foo()

            for _ in range(1, 4):
                self.assertEqual(len(counter), 1)
                self.assertEqual(foo.__class__.bar, foo.bar)

    @lazyclassproperty
    def baz(cls):
        sys.exit(43)

    try:
        lazyclassproperty_0 = lazyclassproperty(baz)
        unittest.main()
    except SystemExit as e:
        pass

    # AssertionError: 43 != 0

# Generated at 2022-06-26 02:42:06.339101
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(self):
            return '1'

    a = A()
    assert a.x == '1'
    print('Test lazyclassproperty success')


# Generated at 2022-06-26 02:42:10.875168
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random

    class TestClass(object):
        @lazyclassproperty
        def random_number(cls):
            print('computing...')
            return random.randint(0, 100)

    t = TestClass()

    assert t.random_number == t.random_number == t.random_number == t.random_number == t.random_number

# Generated at 2022-06-26 02:42:16.654977
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def fn_0(arg_0):
        return arg_0

    i = 0

    @lazyclassproperty
    def lazyclassproperty_0(cls):
        nonlocal i
        i += 1
        return i

    lazyclassproperty_1 = lazyclassproperty(fn_0)

    class_0 = type(
        'Test',
        (object,),
        {'lazyclassproperty_0': lazyclassproperty_0, 'lazyclassproperty_1': lazyclassproperty_1}
    )

    # Check if the value is set and cached on the first call
    assert class_0.lazyclassproperty_0 == 1
    assert class_0.lazyclassproperty_0 == 1
    assert class_0.lazyclassproperty_0 == 1

    # Check that the value is evaluated when needed and cached again
   

# Generated at 2022-06-26 02:42:18.600063
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(str) == 'lazyclassproperty'


# Generated at 2022-06-26 02:42:21.457657
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def _str_property(cls):
            return str(cls)

    print(A._str_property)
    class B(A):
        pass

    print(B._str_property)


# Generated at 2022-06-26 02:42:40.260037
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    var_0 = lazyclassproperty(lambda :{
        0: True
    })

    assert var_0()[0] is True

# Generated at 2022-06-26 02:42:41.122095
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()

# Generated at 2022-06-26 02:42:52.668284
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    '''
    @lazyclassproperty
    def greet(self):
        print('hello')
        return 'Hello, {}'.format(self.name)

    @property
    def greet(self):
        print('hello')
        return 'Hello, {}'.format(self.name)

    def greet(self):
        print('hello')
        return 'Hello, {}'.format(self.name)
    '''
    class Greeter(object):
        @lazyclassproperty
        def greet(self):
            print('hello')
            return 'Hello, {}'.format(self.name)

    g = Greeter()
    g.greet
    g.greet


if __name__ == '__main__':
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:42:59.451543
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def x():
        return 42

    assert x == 42
    assert x == 42  # check that it is cached

    class Foo(object):
        pass

    class Bar(Foo):
        foo = x

    b = Bar()
    assert b.foo == 42

    class Baz(Bar):
        pass

    baz = Baz()
    assert baz.foo == 42

    x.__doc__ = 'foo'
    assert x.__doc__ == 'foo'



# Generated at 2022-06-26 02:43:05.969836
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test for typemap
    class Parent:
        def __init__(self, a):
            self.a = a
    def typemap_0(cls): return [cls.a]
    Parent.typemap = lazyperclassproperty(typemap_0)
    parent_0 = Parent(0)
    parent_1 = Parent(1)
    assert parent_0.typemap() == [0]
    assert parent_1.typemap() == [1]

# Generated at 2022-06-26 02:43:08.361165
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def test(cls):
        print('Called')
        return 42

    print('First', test)
    print('Second', test)



# Generated at 2022-06-26 02:43:10.563777
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    assert lazyperclassproperty(test_0) == lazyperclassproperty(test_1), 'Failed unit test'



# Generated at 2022-06-26 02:43:14.708651
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):

        @lazyclassproperty
        def attr(cls):
            print('attr was computed for %s' % cls.__name__)
            return 'attr value'

    class SubTest(Test):
        pass

    print(Test.attr)
    print(SubTest.attr)
    print(Test.attr)


# Generated at 2022-06-26 02:43:22.347763
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def bar(cls):
            return 42
    foo_int_1=42
    str_2 = 'bar'
    assert getattr(Foo,str_2) == foo_int_1
    foo_int_2=43
    setattr(Foo,str_2,foo_int_2)
    assert getattr(Foo,str_2) == foo_int_2


# Generated at 2022-06-26 02:43:24.186417
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo_0:
        @lazyclassproperty
        def bar_0(cls):
            return 'foo'
    assert Foo_0.bar_0 == 'foo'

# Generated at 2022-06-26 02:43:47.941444
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test_case_1(object):
        def __init__(self):
            self._a = None
            self._b = None
            self._c = None

        @lazyclassproperty
        def a(self):
            self._a = 1
            return self._a

        @lazyclassproperty
        def b(self):
            self._b = 2
            return self._b

        @lazyclassproperty
        def c(self):
            self._c = 3
            return self._c

    def test_case_2():
        test_case_1_0 = test_case_1()
        assert test_case_1_0.a == 1
        assert test_case_1_0.b == 2
        assert test_case_1_0.c == 3


# Generated at 2022-06-26 02:43:52.700253
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:43:56.504436
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def fn_0(cls):
        pass
    lazyperclassproperty_0 = lazyperclassproperty(fn_0)


# Generated at 2022-06-26 02:44:01.631770
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X: pass
    class Y(X): pass
    class Z(Y): pass

    @lazyperclassproperty
    def prop(cls):
        return cls

    assert prop(X) is X
    assert prop(Y) is Y
    assert prop(Z) is Z


# Generated at 2022-06-26 02:44:03.624271
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(
      str_0) == roclassproperty_0


# Generated at 2022-06-26 02:44:06.227535
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{@bHK&C_:g(d8'
    lazyclassproperty_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:44:09.712744
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    foo = lambda: 5
    lazyclassproperty_0 = lazyclassproperty(foo)
    str_0 = 'rpT"8ky:g[1'
    function_0 = lazyclassproperty_0(str_0)
    assert function_0 == 5


# Generated at 2022-06-26 02:44:10.654119
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True == True


# Generated at 2022-06-26 02:44:21.563348
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    class MySubClass(MyClass):
        pass

    assert_equals(MyClass.foo, 'bar')
    assert_equals(MySubClass.foo, 'bar')

    MyClass.foo = 'baz'

    assert_equals(MyClass.foo, 'baz')
    assert_equals(MySubClass.foo, 'bar')

    MySubClass.foo = 'pony'

    assert_equals(MyClass.foo, 'baz')
    assert_equals(MySubClass.foo, 'pony')

# Test the case where functions are defined at the module level.
# Test case for lazyclassproperty

# Generated at 2022-06-26 02:44:28.197151
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        def __init__(self):
            self.num_calls = 0

        @lazyperclassproperty
        def test_func(self):
            self.num_calls += 1
            return self.num_calls

    test_class_0 = TestClass()
    lazyperclassproperty_0 = test_class_0.test_func
    assert lazyperclassproperty_0 == 1

    test_class_1 = TestClass()
    lazyperclassproperty_1 = test_class_1.test_func
    assert lazyperclassproperty_1 == 1
    assert test_class_0.num_calls == 1


# Generated at 2022-06-26 02:44:56.478333
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('# Unit test for function lazyperclassproperty')
    # TODO: Implement your unit test here
    assert(True)


# Generated at 2022-06-26 02:45:05.207047
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{@bHK&C_:g(d8'
    roclassproperty_0 = roclassproperty(str_0)
    roclassproperty_0 = roclassproperty(str_0)
    str_1 = '{@bHK&C_:g(d8'
    roclassproperty_1 = roclassproperty(str_1)
    roclassproperty_1 = roclassproperty(str_1)
    str_2 = '{@bHK&C_:g(d8'
    roclassproperty_2 = roclassproperty(str_2)
    roclassproperty_2 = roclassproperty(str_2)
    str_3 = '{@bHK&C_:g(d8'
    roclassproperty_3 = roclassproperty(str_3)

# Generated at 2022-06-26 02:45:07.801630
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    foo = None
    class Bar(object):
        @lazyperclassproperty
        def bar(cls):
            return foo

    assert Bar.bar is None
    foo = 'zoo'
    assert Bar.bar == 'zoo'


# Generated at 2022-06-26 02:45:11.376111
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        @lazyperclassproperty
        def myproperty(cls):
            return 1
    class MySubclass(MyClass):
        pass

    assert MyClass.myproperty == 1
    assert MySubclass.myproperty == 1
    assert MyClass.myproperty != MySubclass.myproperty


# Generated at 2022-06-26 02:45:12.912740
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'm6TGuTZ||A4'
    lazyperclassproperty_0 = lazyperclassproperty(str_0)


# Generated at 2022-06-26 02:45:13.575946
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:45:21.979260
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test lazyclassproperty(fn)
    """
    class Foo(object):
        _records = []
        @lazyclassproperty
        def records(cls):
            cls._records.append(1)
            return cls._records

        _record_set = set()
        @classproperty
        def record_set(cls):
            cls._record_set.add(1)
            return cls._record_set

        _records_0 = []
        @lazyclassproperty
        def records_0(cls):
            cls._records_0.append(2)
            return cls._records_0

        _record_set_0 = set()
        @classproperty
        def record_set_0(cls):
            cls._record_set_0.add

# Generated at 2022-06-26 02:45:31.726437
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_inp_0 = 'empty_string'
    test_inp_1 = 'There is one class property. Do you see it?'
    test_inp_2 = 'Did you hear something?'
    test_inp_3 = 'Did you hear that?'
    test_inp_4 = 'Did you hear something?'
    assert (lazyperclassproperty(test_inp_0), test_inp_0)
    assert (lazyperclassproperty(test_inp_0), test_inp_1)
    assert (lazyperclassproperty(test_inp_0), test_inp_2)
    assert (lazyperclassproperty(test_inp_0), test_inp_3)
    assert (lazyperclassproperty(test_inp_1), test_inp_4)

# Generated at 2022-06-26 02:45:40.509289
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar_perclass(cls):
            return 'bar'

    class Baz(Foo):
        pass

    assert(Foo.bar_perclass == 'bar')
    assert(Baz.bar_perclass == 'bar')
    Baz.bar_perclass = 'baz'
    assert(Baz.bar_perclass == 'baz')
    assert(Foo.bar_perclass == 'bar')


# Generated at 2022-06-26 02:45:42.321638
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert_equal(lazyperclassproperty(lambda x: x), lazyperclassproperty)


# Generated at 2022-06-26 02:46:44.677423
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Hello(object):
        str_0 = '{@bHK&C_:g(d8'
        cls_0_0 = lazyperclassproperty(str_0)
        str_1 = 'Hello world'
        cls_0_1 = lazyperclassproperty(str_1)

    def fun_0_1():
        str_0 = '{@bHK&C_:g(d8'
        return str_0

    class HelloWorld(Hello):
        cls_1_0 = lazyperclassproperty(fun_0_1)
        cls_1_1 = lazyperclassproperty(str_1)

    assert Hello.cls_0_0 == '{@bHK&C_:g(d8'

# Generated at 2022-06-26 02:46:47.231998
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_lambda_0(cls_0):
        return 'test_lambda_0'

    class test_class_0:
        test_lambda_0

    assert test_class_0.test_lambda_0 == 'test_lambda_0'


# Generated at 2022-06-26 02:46:48.964598
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0)._lazyclassprop == '{@bHK&C_:g(d8'


# Generated at 2022-06-26 02:46:52.981143
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:46:59.547978
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from test_fixtures import Data
    from copy import copy

    @lazyclassproperty
    def lazy_props(cls):
        d = Data()
        d['first'] = 'first'
        setattr(cls, '__lazy_prop', d)
        return d

    lazy_props_before = copy(lazy_props)
    assert(lazy_props == lazy_props_before)
    assert(lazy_props is not lazy_props_before)


# Generated at 2022-06-26 02:47:00.835798
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    c_0 = lazyperclassproperty
    classproperty_0 = classproperty(c_0)


# Generated at 2022-06-26 02:47:03.404691
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Testing class property
    """
    class A(object):
        @lazyclassproperty
        def b(cls):
            setattr(cls, 'a', 2)
            return 3 + 3



# Generated at 2022-06-26 02:47:05.315463
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '7y1E@>(B.'
    roclassproperty_0 = roclassproperty(str_0)



# Generated at 2022-06-26 02:47:14.707398
# Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:47:22.630206
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base0(object):
        def __init__(self):
            pass
        @lazyperclassproperty
        def f0(cls):
            return 0
    class Base1(object):
        def __init__(self):
            pass
        @lazyperclassproperty
        def f0(cls):
            return cls.__name__.encode('utf-8')
    class Class0(Base0):
        def __init__(self):
            Base0.__init__(self)
        @lazyperclassproperty
        def f0(cls):
            return cls.__name__.encode('utf-8')
    class Class1(Base0):
        def __init__(self):
            Base0.__init__(self)