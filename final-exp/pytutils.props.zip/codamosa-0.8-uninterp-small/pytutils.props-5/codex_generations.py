

# Generated at 2022-06-26 02:38:57.718243
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestSchoolMember(object):

        @lazyclassproperty
        def school_name(cls):
            return "SCHOOL NAME"

    TestSchoolMember.__dict__.get('school_name')


# Generated at 2022-06-26 02:39:08.841634
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import hashlib

    class TestClass(object):
        _class_prop_cache = None
        @lazyperclassproperty
        def class_prop(cls):
            """
            This should be cached per class.
            """
            print("Computing expensive result!")
            return hashlib.sha256(cls.__name__.encode("utf-8")).hexdigest()
    assert TestClass.class_prop == TestClass.class_prop
    print("TestClass: {0}".format(TestClass.class_prop))
    #print("TestClass: {0}".format(TestClass.class_prop))

    class DerivedTestClass(TestClass):
        pass
    assert DerivedTestClass.class_prop == DerivedTestClass.class_prop

# Generated at 2022-06-26 02:39:09.477616
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True

# Generated at 2022-06-26 02:39:10.638338
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(setterproperty_0)

# Generated at 2022-06-26 02:39:18.525806
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    global  default_instance

    # Init mocked instances
    class Any(object):
        @lazyperclassproperty
        def Any(cls):
            global default_instance
            default_instance = cls
            return default_instance

        def __init__(self):
            pass
    class Some(Any):
        pass

    class Others(Some):
        def __init__(self):
            pass
    class Another(object):
        def __init__(self):
            pass

    # Check lazyperclassproperty with mocked instances
    some_instance = Some()
    other_instance = Others()
    another_instance = Another()

    # Check The instance of Some
    assert(some_instance.Any is Some)
    # Check The instance of Other
    assert(other_instance.Any is Some)
    # Check The instance of Another


# Generated at 2022-06-26 02:39:20.923327
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    for i in xrange(0, 10):
        assert( i == lazyperclassproperty(lambda x: x)(i) )


# Generated at 2022-06-26 02:39:21.546057
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    con

# Generated at 2022-06-26 02:39:26.928445
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestObj(object):
        prop1 = lazyclassproperty(lambda cls: [123])
        prop2 = lazyclassproperty(lambda cls: {'456': 123})
    print(TestObj.prop1)
    print(TestObj.prop2)





# Generated at 2022-06-26 02:39:27.902397
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True == True



# Generated at 2022-06-26 02:39:40.236548
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # lazyclassproperty(lazyclassproperty(lazyclassproperty))
    lazyclassproperty_0 = lazyclassproperty(lazyclassproperty(lazyclassproperty))
    dict_0 = {}
    lazyclassproperty_0 = lazyclassproperty(dict_0)
    # lazyclassproperty(lazyclassproperty(lazyclassproperty(lazyclassproperty)))
    lazyclassproperty_0 = lazyclassproperty(lazyclassproperty(lazyclassproperty(lazyclassproperty)))
    dict_0 = {}
    lazyclassproperty_0 = lazyclassproperty(dict_0)
    # lazyperclassproperty(lazyclassproperty(lazyclassproperty))
    lazyperclassproperty_0 = lazyperclassproperty(lazyclassproperty(lazyclassproperty))
    dict_0 = {}

# Generated at 2022-06-26 02:39:44.034987
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_1 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:39:45.435697
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Basic lazyclassproperty call
    def func0(self):
        return 1

    lazyclassproperty(func0)


# Generated at 2022-06-26 02:39:48.298542
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:39:49.790056
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert test_case_0() == None
# if __name__ == '__main__':
#     print test_case_0()

# Generated at 2022-06-26 02:39:52.971256
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert(lazyperclassproperty(test_case_0) == lazyperclassproperty(test_case_0))



# Generated at 2022-06-26 02:39:54.512214
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True



# Generated at 2022-06-26 02:39:59.340031
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)


if __name__ == '__main__':
    test_case_0()
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:40:06.351779
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from ._lazyclassproperty import lazyclassproperty, TestClass
    try:
        test_class = TestClass()
        lazy_variable = test_class.lazy_var
        assert(lazy_variable == 42)
    except Exception as e:
        print(e)
        assert(False)

# Generated at 2022-06-26 02:40:09.125867
# Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:40:16.695931
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)
    def var_1():
        str_1 = '{+*|uQQw*tv[7'
        var_2 = lazyclassproperty(str_1)
    var_1()


# Generated at 2022-06-26 02:40:22.603298
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    with pytest.raises(TypeError):
        lazyclassproperty('{+*|uQQw*tv[7')



# Generated at 2022-06-26 02:40:26.127135
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
  # Try to fail an assert statement
  assert roclassproperty(0) >= 0


# Generated at 2022-06-26 02:40:35.155767
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Default test
    test_case_0()
    str_0 = '{+*|uQQw*tv[7'

    class Class_0(object):
        var_0 = lazyperclassproperty(str_0)

    class Class_1(Class_0):
        var_1 = lazyperclassproperty(str_0)

    class Class_2(Class_0):
        var_2 = lazyperclassproperty(str_0)

    class Class_3(Class_1, Class_2):
        var_3 = lazyperclassproperty(str_0)

    assert Class_3.var_0 == '{+*|uQQw*tv[7'
    assert Class_3.var_1 == '{+*|uQQw*tv[7'

# Generated at 2022-06-26 02:40:37.489032
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:40:46.063258
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Create fake class
    class_0 = new_class('class_0')

    # Create fake method
    def method_0(self, value):
        pass

    class_0.get_method_0 = lazyclassproperty(method_0)

    # Create fake method
    def method_1(self, value):
        pass

    class_0.get_method_1 = lazyclassproperty(method_1)

    # Create fake class
    class_1 = new_class('class_1', (class_0,))

    # Create fake method
    def method_0(self, value):
        pass

    class_1.get_method_0 = lazyclassproperty(method_0)

    # Create fake method
    def method_2(self, value):
        pass

    class_1.get_method_2 = lazyclass

# Generated at 2022-06-26 02:40:47.428858
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty


# Generated at 2022-06-26 02:40:51.647512
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # Check that the passed value is equal to the return value
    assert var_0 == '{+*|uQQw*tv[7'
test_lazyperclassproperty()

test_case_1()


# Generated at 2022-06-26 02:40:53.782053
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '^D*6Gmb[6q-;c8'
    var_0 = lazyperclassproperty(str_0)
    var_1 = isinstance(var_0, classproperty)
    assert var_1


# Generated at 2022-06-26 02:40:57.400088
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)

# Generated at 2022-06-26 02:41:01.884568
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print(lazyperclassproperty)


if __name__ == '__main__':
    test_lazyperclassproperty()
    test_case_0()

# Generated at 2022-06-26 02:41:11.105773
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty)


# Generated at 2022-06-26 02:41:17.643090
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    values = []
    class TestClass(object):
        def __init__(self, value):
            self.value = value
        @lazyclassproperty
        def prop(cls):
            values.append(cls.value)
            return cls.value
        @lazyclassproperty
        def prop2(cls):
            return cls.value
        @lazyclassproperty
        def prop3(cls):
            return cls.value

    assert TestClass.prop == 1
    assert TestClass.prop2 == 1
    assert TestClass.prop3 == 1
    assert values == [1]

    t1 = TestClass(0)
    assert t1.prop == 1
    assert t1.prop2 == 1
    assert t1.prop3 == 1
    assert values == [1]

    t2 = Test

# Generated at 2022-06-26 02:41:22.320763
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)


# Generated at 2022-06-26 02:41:25.758607
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)
    print(var_0)



# Generated at 2022-06-26 02:41:31.050802
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert '{+*|uQQw*tv[7' == lazyperclassproperty(str('{+*|uQQw*tv[7'))

# Test case for function test_case_0

# Generated at 2022-06-26 02:41:32.683017
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:41:40.466475
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Testing function lazyperclassproperty...', end='')
    # To test, we'll create a bunch of classes and make sure that
    # the same instances are used for properties on the same class.
    # To keep track, we'll use a dict with string keys as
    # class names and dict/set values, each containing instances.
    track_dict = {}
    def _class(name, bases):
        def _init(self): pass
        def _prop(self):
            if 'classes' not in track_dict:
                track_dict['classes'] = set()
            if name not in track_dict:
                track_dict[name] = {}
            prop_factory = track_dict[name]
            if 'instances' not in prop_factory:
                prop_factory['instances'] = set()
            prop_

# Generated at 2022-06-26 02:41:49.586062
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)
    var_1 = lazyperclassproperty(str_0)
    var_2 = lazyperclassproperty(str_0)
    var_3 = lazyperclassproperty(str_0)
    var_4 = lazyperclassproperty(str_0)
    var_5 = lazyperclassproperty(str_0)
    var_6 = lazyperclassproperty(str_0)
    var_7 = lazyperclassproperty(str_0)
    var_8 = lazyperclassproperty(str_0)
    var_9 = lazyperclassproperty(str_0)
    var_10 = lazyperclassproperty(str_0)
    var_11 = lazyperclassproperty(str_0)

# Generated at 2022-06-26 02:41:52.079401
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyclassproperty(str_0)


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-26 02:41:56.076532
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert [lazyclassproperty(lambda cls: cls.__name__ + ' lazy') for _ in range(2)]


# Generated at 2022-06-26 02:42:07.843745
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Test lazyperclassproperty() with real data')
    test_case_0()
    print('Test lazyperclassproperty() with empty data')
    test_case_0()

if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:42:10.463283
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    ## Test case 0
    var_0 = '{+*|uQQw*tv[7'
    str_0 = lazyperclassproperty(var_0)
    assert "AssertionError" not in str_0



# Generated at 2022-06-26 02:42:11.967362
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)

# Generated at 2022-06-26 02:42:14.219764
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Expected result:
    # *OK*
    pass

# Generated at 2022-06-26 02:42:17.371557
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # AssertionError: assert test_0() == '{+*|uQQw*tv[7'
    assert test_case_0() == ''

# Generated at 2022-06-26 02:42:18.862854
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    lazyclassproperty
    """



# Generated at 2022-06-26 02:42:24.519101
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert 1 == 1
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #assert lazyclassproperty(0) == 0

# Generated at 2022-06-26 02:42:33.630115
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    import random

    class A:
        x = lazyclassproperty(lambda: random.randrange(10))
        y = lazyclassproperty(lambda: random.randrange(10))

    class B(A):
        x = lazyclassproperty(lambda: random.randrange(10))
        y = lazyclassproperty(lambda: random.randrange(10))

    class TestLazyClassProperty(unittest.TestCase):
        def test_lazy_class_property(self):
            self.assertEqual(A.x, A.x)
            self.assertEqual(A.y, A.y)
            self.assertEqual(B.x, B.x)
            self.assertEqual(B.y, B.y)


# Generated at 2022-06-26 02:42:43.533447
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Class_0(object):
        str_0 = 'PW6xj{6U[9mn|PP}z'
        var_0 = lazyperclassproperty(Class_0.str_0)
    assert Class_0.var_0 == 'PW6xj{6U[9mn|PP}z'

    class Class_1(Class_0):
        pass

    assert Class_1.var_0 == 'PW6xj{6U[9mn|PP}z'
    assert Class_0.var_0 == 'PW6xj{6U[9mn|PP}z'



# Generated at 2022-06-26 02:42:44.510659
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()


# Generated at 2022-06-26 02:43:00.129280
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    locals()['test_case_0']()

test_lazyperclassproperty()

# Generated at 2022-06-26 02:43:03.392612
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # We are trying to access the variable
    var_0 = lazyperclassproperty(str_0).upper()
    print(var_0)

    print('Congratulations! Test 1 passed!')


# Test cases for function test_case_0

# Generated at 2022-06-26 02:43:05.097198
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    c = lazyclassproperty(lambda x: 'test')
    assert c == 'test'


# Generated at 2022-06-26 02:43:06.407147
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert callable(lazyclassproperty) == True


# Generated at 2022-06-26 02:43:07.278337
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:43:10.101174
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import random
    try:
        test_case_0()
    except Exception as e:
        if e.args[0] != "global name 'classproperty' is not defined":
            raise e


# Generated at 2022-06-26 02:43:12.248502
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = lambda str_1: str_1
    var_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:43:14.582062
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('Testing lazyperclassproperty...', end='')
    assert(lazyperclassproperty(str) == str)
    assert(lazyperclassproperty(len) == len)
    print('Done.')



# Generated at 2022-06-26 02:43:17.238648
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(0) == lazyclassproperty(0)
    assert lazyclassproperty(0) != lazyclassproperty(1)



# Generated at 2022-06-26 02:43:20.602577
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:43:58.422234
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    func = lazyperclassproperty('{+*|uQQw*tv[7')
    assert isinstance(func, classproperty) is True
    assert func.__doc__ == '  Lazy/Cached class property that stores separate instances per class/inheritor so there\'s no overlap.\n'

# Tests for function lazyclassproperty

# Generated at 2022-06-26 02:44:03.799565
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        class TestNestedClass:
            x = 1
        test_me = lazyclassproperty(TestNestedClass)

    assert TestClass().test_me == TestClass.test_me == TestClass.TestNestedClass


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:44:05.639105
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True
    # TODO: Implement the test for lazyclassproperty here.


# Generated at 2022-06-26 02:44:08.056239
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = 'K$Q(z=,HxA8t!d'
    var_0 = lazyclassproperty(str_0)


# Generated at 2022-06-26 02:44:15.727702
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from typing import Any
    from typing import Type
    from typing import TypeVar

    T = TypeVar('T')

    # type: (Type[T]) -> Type[T]
    def f(cls):
        return cls

    # type: (Type[T]) -> Type[T]
    def g(cls):
        return cls

    # type: (Type[T]) -> Type[T]
    def h(cls):
        return cls

    # type: (Type[T]) -> Type[T]
    def i(cls):
        return cls

    # type: (Type[T]) -> Type[Any]
    # type: (Type[T]) -> Type[Any]
    # type: (Type[T]) -> Type[Any]
    # type: (Type[T]) -> Type[Any]

# Generated at 2022-06-26 02:44:19.988014
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    try:
        var = lazyclassproperty(str_0)
        assert var is None, "Expected None, got: '{}'".format(var)
        return
    except Exception as e:
        print(e)
        return

if __name__ == '__main__':
    test_case_0()
    test_lazyclassproperty()

# Generated at 2022-06-26 02:44:21.089400
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert 1 == 1



# Generated at 2022-06-26 02:44:23.961568
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from pyds import lazyclassproperty
    class DemoClass(object):
        @lazyclassproperty
        def func(cls):
            return cls.__name__
    assert DemoClass.func == 'DemoClass'


# Generated at 2022-06-26 02:44:26.635401
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)

    assert str(var_0) == '<classproperty object at 0x616e74>'


# Generated at 2022-06-26 02:44:29.008497
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # test_case_0
    str_0 = '{+*|uQQw*tv[7'
    var_0 = lazyperclassproperty(str_0)



# Generated at 2022-06-26 02:45:29.898949
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


# Generated at 2022-06-26 02:45:30.894653
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True == True


test_case_0()

test_lazyclassproperty()

# Generated at 2022-06-26 02:45:31.937155
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()



# Generated at 2022-06-26 02:45:34.859265
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_case_0()

if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:45:37.940512
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:45:45.003579
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Make sure the test function runs, and returns a value
    """
    test_case_0()
    try:
        assert True
    except AssertionError:
        print('AssertionError raised in test_case_0!')

# Compiled python file '/Users/jamespetullo/Desktop/Programs/Python/PythonPrograms/src/syntax_programs/str_ops.py'
# Compiled at: 2017-09-24 08:25:27
# Size of source mod 2**32: 524 bytes

# Generated at 2022-06-26 02:45:53.901414
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'
    c = lambda cls: str_0
    d = lazyclassproperty(c)
    assert(d.__name__ == c.__name__)
    assert(d(C).__name__ == c.__name__)
    assert(d(C) == str_0)
    assert(C.__class__.__dict__['_lazy_' + d.__name__] == str_0)
    assert(C().__class__.__dict__['_lazy_' + d.__name__] == str_0)
    assert(C._lazyclassprop() == str_0)
    assert(C._lazyclassprop == str_0)
    assert(C.__class__._lazyclassprop == str_0)

# Generated at 2022-06-26 02:45:55.568922
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty('test_lazyclassproperty')('test_lazyclassproperty') == 'test_lazyclassproperty'


# Generated at 2022-06-26 02:45:56.948980
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_2 = '{+*|uQQw*tv[7'
    var_2 = lazyclassproperty(str_2)


# Generated at 2022-06-26 02:46:07.207002
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    output = 0
    if output == 0:
        print("Input: ")
        print("Output: ", test_case_0())
        print("Expected: ", )
    elif output == 17:
        print("Input: ")
        print("Output: ", test_case_1())
        print("Expected: ", )

# Generated at 2022-06-26 02:48:14.854777
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = 'abc'
    var_0 = lazyperclassproperty(str_0)     # func
    assert callable(var_0), "'var_0' is not callable"
    assert isinstance(var_0, roclassproperty), "'var_0' is not roclassproperty"



# Generated at 2022-06-26 02:48:16.557630
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    str_0 = '{+*|uQQw*tv[7'


# Generated at 2022-06-26 02:48:18.525782
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    str_0 = '0l0yc*]@vK_R'
    var_0 = lazyperclassproperty(str_0)


# Generated at 2022-06-26 02:48:19.312666
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test should pass.
    test_case_0()



# Generated at 2022-06-26 02:48:22.749834
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(str) == '{+*|uQQw*tv[7'
    assert lazyperclassproperty(int) == 1


# Generated at 2022-06-26 02:48:23.257292
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert 1 == 1

# Generated at 2022-06-26 02:48:24.558623
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Check string equality
    assert lazyclassproperty.__doc__ == 'Lazy/Cached class property.'


# Generated at 2022-06-26 02:48:29.619773
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            return 123
        @lazyclassproperty
        def bar(cls):
            return 456

    @test
    def test_lazy_foo():
        assert Test.foo == 123
        assert Test.foo == 123
        class Test2(Test):
            pass
        assert Test2.foo == 123
        assert Test2.foo == 123

    @test
    def test_lazy_bar():
        assert Test.bar == 456
        assert Test.bar == 456
        class Test2(Test):
            pass
        assert Test2.bar == 456
        assert Test2.bar == 456



# Generated at 2022-06-26 02:48:33.726248
# Unit test for function lazyclassproperty

# Generated at 2022-06-26 02:48:35.719880
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert(str(lazyperclassproperty.__doc__) == '\nLazy/Cached class property that stores separate instances per class/inheritor so there\'s no overlap.\n')
    assert(test_case_0() == None)
