

# Generated at 2022-06-26 02:39:00.202349
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # TODO: Fix this test
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 1
    assert Foo.bar == 1
    assert Foo.bar == 1
    Foo.bar = 2
    assert Foo.bar == 2



# Generated at 2022-06-26 02:39:02.810961
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def _lazyclassprop(cls):
        return 42

    assert _lazyclassprop is not None


# Generated at 2022-06-26 02:39:13.615152
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        def __init__(self, name):
            self.name = name
        @lazyperclassproperty
        def lazy_prop(cls):
            return ', '.join((t.name for t in cls.__subclasses__()))

    class TestChild1(Test):
        pass
    class TestChild2(Test):
        pass
    class TestChild3(Test):
        pass

    assert Test.lazy_prop == 'TestChild1, TestChild2, TestChild3'
    assert TestChild1.lazy_prop == 'TestChild1, TestChild2, TestChild3'
    assert TestChild2.lazy_prop == 'TestChild1, TestChild2, TestChild3'
    assert TestChild3.lazy_prop == 'TestChild1, TestChild2, TestChild3'


# Generated at 2022-06-26 02:39:16.132458
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    lazyperclassproperty_0 = lazyperclassproperty(test_case_0)
    if str(lazyperclassproperty_0) == "<class 'roclassproperty'>":
        assert False


# Generated at 2022-06-26 02:39:24.794764
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @classproperty
        def x(cls):
            return 'first'

    class Bar(Foo):
        @lazyclassproperty
        def x(cls):
            return 'second'

    foo = Foo()
    assert Foo.x == 'first'
    assert foo.x == 'first'
    assert Bar.x == 'second'
    assert Bar().x == 'second'

    class Baz(Foo):
        pass

    assert Baz.x == 'first'
    assert Baz().x == 'first'

# Generated at 2022-06-26 02:39:33.464911
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Define the class
    class TestLazyClassProperty(object):
        # Define some properties
        __var_0 = 0
        roclassproperty_0 = roclassproperty(__var_0)
        classproperty_0 = classproperty(__var_0)
        lazyclassproperty_0 = lazyclassproperty(__var_0)
        lazyperclassproperty_0 = lazyperclassproperty(__var_0)
        # Ensure that the properties aren't defined
        assert not hasattr(roclassproperty, '_TestLazyClassProperty_roclassproperty_0')
        assert not hasattr(classproperty, '_classproperty_0')
        assert not hasattr(lazyclassproperty, '_lazyclassproperty_0')

# Generated at 2022-06-26 02:39:41.582779
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # This unit test is for the scenario where a customized logger
    # needs to be defined for the class.  We don't know the logger
    # name until the class is created, so we use a lazyclassproperty
    # decorator to get the logger defined for the class.
    mylogger = logging.getLogger(__name__)

    class CustomizedLogger:
        @lazyclassproperty
        def logger(cls):
            return logging.getLogger(cls.__name__)

    class A(CustomizedLogger):
        pass

    class B(CustomizedLogger):
        pass

    assert A.logger != B.logger  # class B should have its own logger
    assert A.logger == logging.getLogger('tests.test_descriptors.A')
    assert B.logger == logging.get

# Generated at 2022-06-26 02:39:54.195796
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:40:02.616286
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def _recursive_class_builder(depth=0):
        if depth:
            return type('TestClass%d' % depth, (_recursive_class_builder(depth - 1),), {})
        return object

    @lazyperclassproperty
    def test_val(cls):
        return str(cls)

    base = _recursive_class_builder(10)
    assert base.test_val.startswith('<class \'__main__.TestClass10\'')

    class A(base):
        pass

    class B(base):
        pass

    assert A.test_val.startswith('<class \'__main__.A')
    assert B.test_val.startswith('<class \'__main__.B')



# Generated at 2022-06-26 02:40:04.515019
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)


# Generated at 2022-06-26 02:40:13.550142
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import mock

    class TestClass:

        def _call_foo(self):
            return 42

        foo = lazyclassproperty(_call_foo)

    # first call of foo
    test_obj = TestClass()
    assert test_obj.foo == 42

    # second call of foo
    with mock.patch.object(TestClass, '_call_foo', return_value=4711):
        assert test_obj.foo == 4711



# Generated at 2022-06-26 02:40:24.138832
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    import random

    class A(object):
        _counter = 0

        @staticmethod
        def get_and_increment():
            result = A._counter
            A._counter += 1
            return result

        @lazyclassproperty
        def result(cls):
            return cls.get_and_increment()

    # Make sure it's correctly lazy
    assert A._counter == 0
    assert A.result == 0
    assert A._counter == 1
    assert A.result == 0
    assert A._counter == 1

    # Make sure it caches the result
    random.seed(0)
    for i in range(100):
        assert A.result == random.randint(0, 1)



# Generated at 2022-06-26 02:40:32.937861
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

    @lazyperclassproperty
    def x(cls):
        return cls(4)

    class B(A):
        pass

    assert x == 4
    assert B.x.x == 4
    assert isinstance(x, A)
    assert isinstance(B.x, B)
    x.x += 1
    assert x.x == 5
    assert B.x.x == 4


# Generated at 2022-06-26 02:40:40.684482
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Setup

    # Lazyperclassproperty requires a method as input argument.
    # If a method is not used as input argument an exception will occur.
    try:
        assert False, "An exception should have been thrown"
    except:
        pass
    else:
        assert False, "An exception should have been thrown"



# Generated at 2022-06-26 02:40:45.048278
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def say_hello(cls):
        return 'Hello from %s' % cls.__name__


    class Lazy(object):
        pass


    assert say_hello is Lazy.say_hello
    assert say_hello == 'Hello from Lazy'


if __name__ == '__main__':
    import pytest

    pytest.main('property_descriptor.py')

# Generated at 2022-06-26 02:40:52.275562
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def function_0(arg_0):
        var_0 = arg_0
        var_1 = var_0
        return var_1
    lazyclassproperty_0 = lazyclassproperty(function_0)
    class_0 = Class()
    var_0 = class_0.prop_0
    assert var_0 != None
    assert var_0 != "Hallo Welt"


# Generated at 2022-06-26 02:41:04.937295
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from random import Random, choice

    class Test(object):
        def __init__(self):
            self.store = {}
            self.random = Random()

        colors = ['blue', 'green', 'magenta']

        @lazyclassproperty
        def color(cls):
            return choice(cls.colors)

        @lazyclassproperty
        def random_number(cls):
            return cls.random.randint(0, 100)

        @lazyclassproperty
        def random_number_again(cls):
            return cls.random_number

        @lazyclassproperty
        def random_number_again_chained(cls):
            return cls.random_number_again

    assert Test.color == 'blue'
    assert Test.random_number == 49
    assert Test.random_number

# Generated at 2022-06-26 02:41:11.908536
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass:
        noop_0 = lazyperclassproperty(lambda: None)
    assert TestClass.noop_0 is None

    class TestSubclass(TestClass):
        noop_0 = lazyperclassproperty(lambda: 'not None')
    assert TestSubclass.noop_0 is not None


# Generated at 2022-06-26 02:41:13.702322
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(lambda self: "abcd")


# Generated at 2022-06-26 02:41:27.128781
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from os.path import join
    from glob import glob

    def get_dict(path):
        """Create a dictionary with the contents of the files
        in `path` as keys and contents as values"""

        dict_ = {}
        for file in glob(join(path, '*')):
            dict_[file] = open(file).read()
        return dict_

    class Files(object):
        path = '.'


# Generated at 2022-06-26 02:41:31.807496
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # This is a dummy test
    assert lazyperclassproperty(None) == None


# Generated at 2022-06-26 02:41:38.600702
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert inspect.getsource(lazyclassproperty) == "def lazyclassproperty(fn):\n    attr_name = '_lazy_' + fn.__name__\n\n    @classproperty\n    def _lazyclassprop(cls):\n        if not hasattr(cls, attr_name):\n            setattr(cls, attr_name, fn(cls))\n        return getattr(cls, attr_name)\n\n    return _lazyclassprop\n"


# Generated at 2022-06-26 02:41:40.438087
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import doctest
    doctest.testmod()



# Generated at 2022-06-26 02:41:44.669756
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:41:46.638637
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import doctest
    doctest.run_docstring_examples(lazyperclassproperty, globals())


# Generated at 2022-06-26 02:41:49.587817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Set up test inputs
    fn = roclassproperty
    fn = roclassproperty

    # Execute the tested function
    lazyperclassproperty(fn)

    # Verify the results
    assert True # TODO: implement your test here


# Generated at 2022-06-26 02:41:50.719202
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert True
    # print 'lazyclassproperty'


# Generated at 2022-06-26 02:41:52.499390
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = bool()
    bool_1 = bool()
    bool_1 = bool(bool_0)



# Generated at 2022-06-26 02:42:02.343452
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_case_0():
        class Foo:
            @lazyperclassproperty
            def x(cls):
                return 42

        print(Foo.x)
        assert Foo.x == 42

    def test_case_1():
        class Foo:
            @lazyperclassproperty
            def x(cls):
                return cls.y

        class Bar(Foo):
            y = 42

        print(Bar.x)
        assert Bar.x == 42

    def test_case_2():
        class Foo:
            @lazyperclassproperty
            def x(cls):
                return cls.y

        class Bar(Foo):
            pass

        class Qat(Bar):
            y = 42

        print(Qat.x)
        assert Qat.x == 42


# Generated at 2022-06-26 02:42:09.312912
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
        @lazyperclassproperty
        def parent_prop(cls):
            return getattr(super(cls, cls), 'parent_prop', [])

    class MyClassSubclass(MyClass):
        pass

    class MyClassSubclassSubclass(MyClassSubclass):
        pass

    a = MyClass(1, 1)
    assert a.parent_prop == []

    b = MyClassSubclass(2, 2)
    assert b.parent_prop == []

    c = MyClassSubclassSubclass(3, 3)
    assert c.parent_prop == []



# Generated at 2022-06-26 02:42:14.686308
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert (lazyperclassproperty(lambda self: self.a) == 1)


# Generated at 2022-06-26 02:42:22.110093
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # this one fails, please debug
    # class BaseTest(object):
    #     @lazyclassproperty
    #     def test(cls):
    #         print('hi')
    #         return 'hi'
    #
    # class Test(BaseTest):
    #     pass
    #
    # a = Test()
    # print(a.test)
    class Container(object):
        def __init__(self):
            self._value = 1

        @lazyclassproperty
        def value(cls):
            return cls._value

    assert Container.value == 1



# Generated at 2022-06-26 02:42:25.706104
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def random_val(klass):
            return random.random()

    assert isinstance(A.random_val, float)



# Generated at 2022-06-26 02:42:28.270616
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    foo = lazyclassproperty(lambda: 'bar')

    assert foo == 'bar'
    assert foo.__class__ == roclassproperty


# Generated at 2022-06-26 02:42:30.675882
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    bool_0 = False
    classproperty_0 = classproperty(bool_0)
    lazyclassproperty_0 = lazyclassproperty(classproperty_0)



# Generated at 2022-06-26 02:42:37.051846
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from io import StringIO
    from unittest import main, TestCase


    class TestLazyClassProperty(TestCase):

        @lazyclassproperty
        def cprop(cls):
            return cls.__name__

        def test_property_computed(self):
            self.assertEqual(TestLazyClassProperty.cprop, 'TestLazyClassProperty')

        def test_property_cached(self):
            with captured_stdout() as s:
                TestLazyClassProperty.cprop

            self.assertEqual(s.getvalue(), '')

    main()


# Generated at 2022-06-26 02:42:41.399817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def fn(cls):
        return 'test'
    attr_name = '_%s_lazy_%s' % ('Test', fn.__name__)
    test = lazyperclassproperty(fn)
    assert test._lazyclassprop == 'test'


# Generated at 2022-06-26 02:42:44.109456
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # None -> None
    assert lazyperclassproperty(None) is None


# Generated at 2022-06-26 02:42:55.401584
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import pickle, types, unittest

    def get_x():
        return 42


# Generated at 2022-06-26 02:42:56.725790
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(test_case_0)


# Generated at 2022-06-26 02:43:13.284958
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from pytest import raises
    from examples.custom_decorators import lazyperclassproperty
    from examples.custom_decorators import lazyclassproperty


    def get_test_value(cls):
        return "Test_Value_CLS"

    def get_test_value_2(cls):
        return "Test_Value_2_CLS"

    result = lazyperclassproperty(get_test_value)
    assert isinstance(result, roclassproperty)
    assert result.f == get_test_value
    with raises(AttributeError):
        result.__set__(None, None)
    assert result.__get__(None, None) == "Test_Value_CLS"

    test_2_result = lazyperclassproperty(get_test_value_2)

# Generated at 2022-06-26 02:43:23.675875
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def a(cls):
        print("My class name is {}".format(cls.__name__))
        return cls.__name__

    class Foo(object):
        pass
    
    assert a == "Foo"
    assert Foo.a == "Foo"
    assert a == "Foo"
    class Bar(Foo):
        pass
    assert Bar.a == "Bar"
    assert Foo.a == "Foo"
    assert a == "Foo"
    Bar.a = 'Baz'
    assert Bar.a == "Baz"
    assert Foo.a == "Foo"

if __name__ == '__main__':
    test_case_0()
    test_lazyperclassproperty()

# Generated at 2022-06-26 02:43:33.742505
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    int_0 = 0
    int_1 = 1
    lazyperclassproperty_0 = lazyperclassproperty(bool)
    assert (lazyperclassproperty_0(bool_0, bool_0))
    assert (type(lazyperclassproperty_0(bool_0, bool_0)) == bool)
    assert (lazyperclassproperty_0(bool_0, bool_0) == False)
    assert (lazyperclassproperty_0(bool_0, bool_0) == bool_0)
    assert (lazyperclassproperty_0(bool_0, bool_0) == False)
    assert (lazyperclassproperty_0(bool_0, lazyperclassproperty_0(bool_0, bool_0)) == False)

# Generated at 2022-06-26 02:43:40.127745
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, _value):
            self._value = _value

        @lazyperclassproperty
        def value(self):
            return self._value

    class B(A):
        def __init__(self, *args, **kwargs):
            super(B, self).__init__(*args, **kwargs)

    class C(A):
        def __init__(self, *args, **kwargs):
            super(C, self).__init__(*args, **kwargs)

    a = A('1')
    b = B('2')
    c = C('3')


# Generated at 2022-06-26 02:43:42.991138
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    pass


if __name__ == '__main__':
    test_lazyperclassproperty()


# Generated at 2022-06-26 02:43:50.954519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class test_fixture_0(object):
        def __init__(self):
            self.x = 42
        @lazyperclassproperty
        def prop(cls):
            return cls.x + 1

    class test_fixture_1(test_fixture_0):
        def __init__(self):
            self.x = 43
        @lazyperclassproperty
        def prop(cls):
            return cls.x + 2

    class test_fixture_2(test_fixture_1):
        def __init__(self):
            self.x = 44
        @lazyperclassproperty
        def prop(cls):
            return cls.x + 3

    class test_fixture_3(test_fixture_2):
        def __init__(self):
            self.x

# Generated at 2022-06-26 02:43:58.330117
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    A = type('A', (object,), {})

    @lazyclassproperty
    def x(cls):
        return 1

    assert x._lazyclassprop == 1
    x._lazyclassprop = 2
    assert x._lazyclassprop == 2
    assert A.x == 2


# Generated at 2022-06-26 02:44:00.676026
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    lazyperclassproperty_0 = lazyperclassproperty(bool_0)


# Generated at 2022-06-26 02:44:02.938290
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    bool_0 = False
    lazyperclassproperty_0 = lazyperclassproperty(bool_0)



# Generated at 2022-06-26 02:44:03.597866
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert callable(lazyperclassproperty)

# Generated at 2022-06-26 02:44:22.021623
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test_case_0(object):
        bool_0 = False
        lazyclassproperty_0 = lazyclassproperty(bool_0)

    test_case_instance_0 = test_case_0
    assert test_case_instance_0.lazyclassproperty_0 == False


# Generated at 2022-06-26 02:44:29.947206
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random

    class MyClass(object):
        """
        test class
        """

        @classproperty
        def myfunc(cls):
            """
            test class property
            """
            return 'test class property'

        @lazyclassproperty
        def myfunc_lazy(cls):
            """
            test lazy class property
            """
            return 'test lazy class property'

        @lazyperclassproperty
        def myfunc_lazyperclass(cls):
            """
            test lazy per class property
            """
            return 'test lazy per class property'

        @setterproperty
        def myfunc_setter(self, v):
            """
            test setter class property
            """
            self._myfunc_setter = v


# Generated at 2022-06-26 02:44:31.355106
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert lazyperclassproperty(test_case_0) == bool_0



# Generated at 2022-06-26 02:44:37.019339
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from datetime import datetime
    class Test:
        @lazyperclassproperty
        def created(cls):
            return datetime.now()
    p = Test.created
    q = Test().created
    assert p == q
    time.sleep(1)
    del Test._Test_lazy_created
    p = Test.created
    q = Test().created
    assert p == q



# Generated at 2022-06-26 02:44:39.732342
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def prop(cls):
            return 'foo'

    assert A.prop == 'foo'

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-26 02:44:40.951387
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    lazyperclassproperty
    """
    pass


# Generated at 2022-06-26 02:44:49.055022
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestLazyPerClassProperty(object):
        def __init__(self):
            self._foo = 0
            self._bar = 0
            self._foobar = 0


# Generated at 2022-06-26 02:44:56.375113
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def dummy_fn(cls):
        return None

    # Test return value is a classproperty
    assert isinstance(lazyclassproperty(dummy_fn), classproperty)

    # Test return value has right name
    assert lazyclassproperty(dummy_fn).f.__name__ == "_lazyclassprop"

    class TestClass:
        pass

    @lazyclassproperty
    def dummy_class_prop(cls):
        return "something"

    # Test class_prop is accessible
    assert TestClass.dummy_class_prop == "something"



# Generated at 2022-06-26 02:45:05.102723
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # noinspection PyUnresolvedReferences
    success = True

    try:
        classproperty_0 = classproperty()
        success &= True
    except:
        success &= False
    if not success:
        raise AssertionError('Failure while testing function classproperty().')

    try:
        roclassproperty_0 = roclassproperty(bool_0)
        success &= True
    except:
        success &= False
    if not success:
        raise AssertionError('Failure while testing function roclassproperty().')

    try:
        classproperty_1 = classproperty
        success &= True
    except:
        success &= False
    if not success:
        raise AssertionError('Failure while testing function classproperty().')


# Generated at 2022-06-26 02:45:09.504177
# Unit test for function lazyperclassproperty

# Generated at 2022-06-26 02:45:44.396451
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 42

    assert Foo.bar == 42

    class Baz(Foo):
        pass

    assert Baz.bar == 42

    class Boo(Foo):
        @classproperty
        def bar(cls):
            return 43

    assert Boo.bar == 43
    return Foo



# Generated at 2022-06-26 02:45:51.696037
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def foo(cls):
        return 'bar'

    class A(object):
        pass

    a = A()
    # verify that our instance has the attribute
    eq("bar", foo)
    # verify that our instance does not have the attribute
    eq(False, hasattr(a, '_foo_lazy'))
    # verify that our class does have the attribute
    eq("bar", A._foo_lazy_foo)
    # verify that our class does have the attribute
    eq(False, hasattr(A, '_foo_lazy'))



# Generated at 2022-06-26 02:45:52.981089
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    try:
        assert False
    except:
        print('AssertionError raised')



# Generated at 2022-06-26 02:45:56.894393
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class lazyclassproperty_0(object):
        def __init__(self):
            pass

        def __get__(self, obj, objtype):
            return 0

    # Test for class lazyclassproperty_0
    assert lazyclassproperty_0.__dict__['__init__'](lazyclassproperty_0) is None
    assert lazyclassproperty_0.__dict__['__get__'](lazyclassproperty_0(), None, None) == 0

# Generated at 2022-06-26 02:45:59.920293
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    assert True



# Generated at 2022-06-26 02:46:05.378276
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f(cls):
        return cls.spam + 'bar'

    class A:
        spam = 'foo'
        _lazy_f = lazyclassproperty(f)

    a = A()

    assert A._lazy_f == 'foobar'
    assert a._lazy_f == 'foobar'

    A.spam = 'ham'

    assert A._lazy_f == 'hambar'
    assert a._lazy_f == 'hambar'



# Generated at 2022-06-26 02:46:10.266884
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import copy

    @lazyperclassproperty
    def prop(cls):
        return 'The value'

    class Base0(object):
        pass

    class Base1(object):
        pass

    class Derived(Base0, Base1):
        pass

    assert lazyperclassproperty is roclassproperty

    # Check that setting on Base is accessible on Derived
    Base0.prop = 123
    assert Derived.prop == 123
    Base1.prop = 234
    assert Derived.prop == 234

    # Check that settings on Derived are not accessible on Base
    Derived.prop = 123
    assert Base0.prop == 234
    assert Base1.prop == 234

    # Check that settings on Derived are not accessible on Derived from other Bases
    Base1.prop = 234
    assert Base0.prop == 123
   

# Generated at 2022-06-26 02:46:13.192397
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_lazyperclassproperty_1 = lazyperclassproperty(test_lazyperclassproperty_1)
    print(test_lazyperclassproperty_1)


# Generated at 2022-06-26 02:46:15.638178
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def lazyclassproperty_0():
        return 0
    lazyclassproperty_0_result = lazyclassproperty_0
    return lazyclassproperty_0_result


# Generated at 2022-06-26 02:46:21.703351
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def func_0(cls_0):
        attr_name_0 = '_lazy_' + func_0.__name__
        if not hasattr(cls_0, attr_name_0):
            setattr(cls_0, attr_name_0, func_0(cls_0))
        return getattr(cls_0, attr_name_0)
    lazyclassproperty_0 = lazyclassproperty(func_0)


# Generated at 2022-06-26 02:47:27.512380
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyClassProperty(object):
        def __init__(self, arg):
            self._args = arg


# Generated at 2022-06-26 02:47:28.226195
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert lazyclassproperty(bool)

# Generated at 2022-06-26 02:47:30.786405
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    lcp_max_int = lazyclassproperty(lambda cls: sys.maxsize)
    assert lcp_max_int == sys.maxsize

    class lcp_testcls(object):
        lcp_max_int = lazyclassproperty(lambda cls: sys.maxsize)

    assert lcp_testcls.lcp_max_int == sys.maxsize

# Generated at 2022-06-26 02:47:35.148193
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def test_case_0():
        pass

    @lazyperclassproperty
    def test_case_1():
        pass

    lazyperclassproperty_0 = lazyperclassproperty(test_case_0)
    assert_equal(lazyperclassproperty_0, lazyperclassproperty_0)



# Generated at 2022-06-26 02:47:41.772999
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        # Test class variable
        class_var = 'Test class variable'

        # Test variable
        var = 'Test variable'

        @lazyproperty
        def ordinal(self):
            return int(self.var[-1])

        @lazyclassproperty
        def class_ordinal(cls):
            return int(cls.class_var[-1])

    # Test the class property
    test_obj = TestClass()
    print(test_obj.class_ordinal)

    # Test the object property
    print(test_obj.ordinal)



# Generated at 2022-06-26 02:47:49.206710
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    Bool = False
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return object()

    class B(A):
        pass

    class C(B):
        pass

    assert A.a is A.a
    assert B.a is B.a
    assert C.a is C.a
    assert A.a is not B.a
    assert A.a is not C.a
    assert B.a is not C.a
    assert not hasattr(A, '_A_lazy_a')
    assert not hasattr(B, '_B_lazy_a')
    assert not hasattr(C, '_C_lazy_a')


# Generated at 2022-06-26 02:47:53.189553
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test for function lazyclassproperty
    def classproperty_0():
        str_0 = 'fdsa'
        str_1 = '[[[lk'
        str_2 = '%(a)s%(b)s' % {'a': str_0, 'b': str_1}
        return str_2
    lazyclassproperty_0 = lazyclassproperty(classproperty_0)

# Generated at 2022-06-26 02:47:56.795201
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ClassOne:
       def __init__(self):
          pass

    @lazyclassproperty
    def prop(cls):
        print("Called")
        return 5

    assert ClassOne.prop == 5


# Generated at 2022-06-26 02:48:00.692491
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from collections import namedtuple

    class Sample(object):
        @roclassproperty
        def _a(cls):
            return namedtuple('a', ('x'))

    assert Sample._a() == Sample._a()


# Generated at 2022-06-26 02:48:05.286884
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    global counter
    counter = 0
    class Test(object):
        @lazyclassproperty
        def myprop(cls):
            global counter
            counter += 1
            return counter
    class Test(unittest.TestCase):
        def test(self):
            self.assertEquals(Test.myprop, 1)
            self.assertEquals(Test.myprop, 1)
    unittest.main()

