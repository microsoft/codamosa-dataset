

# Generated at 2022-06-12 08:09:37.163683
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def value(cls):
            print("Initializing value")
            return 1234

    class B(A):
        pass

    assert A.value == 1234
    assert A.value == 1234
    assert B.value == 1234
    assert B.value == 1234


# Generated at 2022-06-12 08:09:44.415587
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def c(cls):
            class NestedClass(object):
                pass

            return NestedClass

    class TestClassDerived(TestClass):
        pass

    # A cached instance of NestedClass should be created for TestClass but not for TestClassDerived
    assert not hasattr(TestClass, '_TestClass_lazy_c')
    assert TestClass.c() is TestClass.c()
    assert TestClassDerived.c() is TestClassDerived.c()
    assert TestClass.c is not TestClassDerived.c



# Generated at 2022-06-12 08:09:47.335484
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        pass
    @lazyclassproperty
    def test(cls):
        return 1
    assert A.test == 1


# Generated at 2022-06-12 08:09:52.690916
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("called")
            return "foo"

    a1 = A()
    a2 = A()
    assert a1.foo == "foo"
    assert a2.foo == "foo"
    assert a1.foo == "foo"

# TODO: unit test for function lazyperclassproperty



# Generated at 2022-06-12 08:09:57.760224
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:05.966908
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseObject(object):
        def __init__(self, name):
            self.name = name

    class A(BaseObject):
        @lazyperclassproperty
        def prop(cls):
            return cls.name, "A"

    class B(A):
        pass

    class C(B):
        def __init__(self, name):
            super(C, self).__init__(name)

    a = A("a")
    b = B("b")
    c = C("c")

    assert a.prop == ("a", "A")
    assert b.prop == ("b", "A")
    assert c.prop == ("c", "A")
    assert a.prop is A.prop is b.prop



# Generated at 2022-06-12 08:10:13.457765
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert B.a == 2
    # Change A's a
    A.a = 3
    # Should not affect B's a
    assert B.a == 2
    # They should now have separate a properties
    assert not A.a is B.a



# Generated at 2022-06-12 08:10:18.362018
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 42

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def test(cls):
            return 43

    assert A.test == 42
    assert B.test == 42
    assert C.test == 43



# Generated at 2022-06-12 08:10:24.354767
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def Test(cls):
            return cls.__name__

    class Test2(Test):
        pass

    class Test3(Test):
        @classproperty
        def Test(cls):
            return 'Test3:' + cls.__name__

    assert Test.Test == 'Test'
    assert Test2.Test == 'Test'
    assert Test3.Test == 'Test3:Test3'



# Generated at 2022-06-12 08:10:33.518222
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Base(object):
        @lazyclassproperty
        def foo(cls):
            return 11

    class Derived(Base):
        @lazyclassproperty
        def foo(cls):
            return 22

    class AnotherDerived(Base):
        @lazyclassproperty
        def foo(cls):
            return 33

    assert Base.foo == 11
    assert Derived.foo == 22
    assert AnotherDerived.foo == 33
    # Check caches
    assert Base._lazy_foo == 11
    assert Derived._lazy_foo == 22
    assert AnotherDerived._lazy_foo == 33



# Generated at 2022-06-12 08:10:45.745625
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Parent(object):
        @lazyperclassproperty
        def anything(cls):
            return 'p'

    class Child(Parent):
        pass

    class Parent2(Parent):
        pass

    class Child2(Parent2):
        pass

    assert Parent.anything == 'p'
    assert Child.anything == 'p'
    assert Parent2.anything == 'p'
    assert Child2.anything == 'p'

    Child.anything = 'c'
    assert Parent.anything == 'p'
    assert Child.anything == 'c'
    assert Parent2.anything == 'p'
    assert Child2.anything == 'p'

    Parent2.anything = 'p2'
    assert Parent.anything == 'p'
    assert Child.anything == 'c'
    assert Parent2.anything == 'p2'
   

# Generated at 2022-06-12 08:10:55.385710
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        num = 0

        def __init__(self, val):
            self.val = val

        def say(self):
            return self.val

    @lazyclassproperty
    def obj(c):
       obj = A(c.num)
       c.num += 1
       return obj

    class B(A): pass

    class C(B): pass

    a1 = A(1)
    a2 = A(2)

    assert (a1.obj is a2.obj)
    assert (a1.obj.say() == 0)

    b1 = B(1)
    b2 = B(2)

    assert (b1.obj is not b2.obj)
    assert (b1.obj is a1.obj)

# Generated at 2022-06-12 08:11:01.157365
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Computing")
            return 1
    a = A()
    b = A()
    print(A.prop)
    print(A.prop)
    print(b.prop)
    print(a.prop)

test_lazyclassproperty()

# Generated at 2022-06-12 08:11:09.875492
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Animal(object):
        @lazyperclassproperty
        def foo(cls):
            return "Animal_foo"

    class Dog(Animal):
        @lazyperclassproperty
        def foo(cls):
            return "Dog_foo"

    class Wolf(Dog):
        @lazyperclassproperty
        def foo(cls):
            return "Wolf_foo"

    assert Animal.foo == "Animal_foo"
    assert Dog.foo == "Dog_foo"
    assert Wolf.foo == "Wolf_foo"

    assert Animal.foo == "Animal_foo"
    assert Dog.foo == "Dog_foo"
    assert Wolf.foo == "Wolf_foo"

    Animal.foo = "Animal_foo_2"
    assert Animal.foo == "Animal_foo_2"

# Generated at 2022-06-12 08:11:19.209358
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Define a class
    class foo:pass

    # Define a class that inherits from our class
    class bar(foo):pass

    # Define our per-class property getter
    # This gets called once for each class, then the value is cached and returned for all subsequent uses.
    @lazyperclassproperty
    def foo(cls):
        return 100

    # Check the value of our class property
    print(foo.foo)
    print(bar.foo)

    # Change the value of the derived class property
    bar.foo = 99

    # Print the values again
    print(foo.foo)
    print(bar.foo)



# Generated at 2022-06-12 08:11:24.926818
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            return "x"

    class B(A):
        pass

    assert A.x == "x"
    assert B.x == "x"
    A.x = 1
    assert A.x == 1
    assert B.x == "x"
    B.x = 2
    assert A.x == 1
    assert B.x == 2


# Generated at 2022-06-12 08:11:30.085408
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        def __init__(self):
            self._x = 3

        @lazyperclassproperty
        def x(cls):
            return cls._x

    class MyClassInheritor(MyClass):
        _x = 4

    assert MyClass.x == 3
    assert MyClassInheritor.x == 4
    assert MyClass().x == 3
    assert MyClassInheritor().x == 4


# Generated at 2022-06-12 08:11:41.014037
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class B(object):
        def __init__(self, v):
            self.v = v

    def fn0(cls):
        return cls.__name__

    @lazyperclassproperty
    def fn1(cls):
        return cls.__name__

    @lazyperclassproperty
    def fn2(cls):
        return B(cls.__name__)

    class A1(object):
        l_fn0 = lazyperclassproperty(fn0)
        l_fn1 = fn1
        l_fn2 = fn2

    class A2(object):
        l_fn0 = lazyperclassproperty(fn0)
        l_fn1 = fn1
        l_fn2 = fn2

    assert A1.l_fn0 == "A1"
    assert A1

# Generated at 2022-06-12 08:11:45.777982
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A: pass
    class B: pass

    @lazyperclassproperty
    def fn(cls):
        return cls()

    a = A()
    b = B()
    assert fn(A) is a
    assert fn(B) is b
    assert fn.f(A) is a
    assert fn.f(B) is b


# Generated at 2022-06-12 08:11:49.972854
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ParentClass:
        @lazyclassproperty
        def value(cls):
            return 'value on ParentClass'

    class ChildClass(ParentClass):
        pass

    assert ParentClass.value == 'value on ParentClass'
    assert ChildClass.value == 'value on ParentClass'



# Generated at 2022-06-12 08:12:00.132572
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    test = 0

    class X:
        @lazyperclassproperty
        def my_prop(self):
            return 'get value of my_prop'

    assert X().my_prop == 'get value of my_prop'

    class Y:
        @lazyperclassproperty
        def my_prop(self):
            nonlocal test
            test += 1
            return 'value of my_prop'

    assert Y.my_prop == 'value of my_prop'
    assert test == 1

    class Z:
        my_prop = lazyperclassproperty(lambda cls: 'value of my_prop')
    assert Z.my_prop == 'value of my_prop'

# Generated at 2022-06-12 08:12:05.128638
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("lazyclassproperty:foo: called")
            return 42

    class B(A):
        pass

    a = A()
    assert a.foo == 42

    b = B()
    assert b.foo == 42


# Generated at 2022-06-12 08:12:11.159053
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a1(cls):
            print("a")
            return 0

        @lazyclassproperty
        def a2(cls):
            print("b")
            return 0

    assert A.a1 == A.a1 == 0
    assert A.a2 == A.a2 == 0



# Generated at 2022-06-12 08:12:14.603501
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def func(cls):
            return 1

    class Child(Parent):
        pass

    assert Parent.func == 1
    assert Child.func == 1
    Parent.func = 2
    assert Parent.func == 2
    assert Child.func == 1



# Generated at 2022-06-12 08:12:19.839324
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(self):
            print("Evaluating foo")
            return [1]

    class B(A):
        pass

    a = A()
    print(a.foo)
    print(a.foo)
    print(a.__class__.foo)
    print(a.__class__.foo)
    print(A.foo)
    print(B.foo)
    print(B().foo)
    print(B().foo)



# Generated at 2022-06-12 08:12:23.704705
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return cls.__name__


    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'



# Generated at 2022-06-12 08:12:33.459429
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def one(cls):
            return 1

        @lazyperclassproperty
        def two(cls):
            return 2

    class B(A):
        @lazyperclassproperty
        def three(cls):
            return 3

    class C(B):
        @lazyperclassproperty
        def four(cls):
            return 4

    print("A.one = %d" % A.one)
    print("A.two = %d" % A.two)
    print("B.one = %d" % B.one)
    print("B.two = %d" % B.two)
    print("C.one = %d" % C.one)
    print("C.two = %d" % C.two)
    print

# Generated at 2022-06-12 08:12:35.563433
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

    assert A.a == 1
    assert A().a == 1



# Generated at 2022-06-12 08:12:45.834274
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        def __init__(self, value):
            self.value = value

        # No instance attribute 'data' available here

        @lazyclassproperty
        def data(cls):
            return cls(42)

    # No instance attribute 'data' available here

    # The class property is eagerly evaluated, but only once per class
    assert C.data == C.data == C(42)

    # The value of the property is the same on all instances
    c1 = C(1)
    assert c1.data == c1.data == c1.data == C.data
    assert c1.data.value == C(42).value

    c2 = C(2)
    assert c2.data == c2.data == c2.data == c1.data

# Generated at 2022-06-12 08:12:50.783457
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print('A')
            return 1

    class B(A):
        @lazyperclassproperty
        def prop(cls):
            print('B')
            return 2
    assert A.prop == 1
    assert B.prop == 2



# Generated at 2022-06-12 08:13:05.899882
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def testvar(cls):
            return 'test'
    class Bar(Foo):
        pass
    assert Foo.testvar == 'test'
    assert Bar.testvar == 'test'
    Foo.testvar = 'test2'
    assert Foo.testvar == 'test2'
    assert Bar.testvar == 'test'
    Bar.testvar = 'test3'
    assert Foo.testvar == 'test2'
    assert Bar.testvar == 'test3'



# Generated at 2022-06-12 08:13:13.137540
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, val):
            self.val = val

        @lazyperclassproperty
        def proper(cls):
            return cls.val ** 2

    class B(A):
        def __init__(self, val, val2):
            super(B, self).__init__(val)
            self.val2 = val2

        @lazyperclassproperty
        def proper(cls):
            return cls.val2 ** 3

    a = A(2)
    b = B(3, 4)

    assert a.proper == 4
    assert b.proper == 64

    a.val = 5
    assert a.proper == 4
    b.val2 = 6
    assert b.proper == 64



# Generated at 2022-06-12 08:13:19.308479
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:13:22.820721
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def property_getter(cls):
        return object.__new__(cls)

    class Demo(object):
        x = lazyclassproperty(property_getter)
    demo_1 = Demo()
    demo_2 = Demo()
    assert demo_1.x is demo_2.x



# Generated at 2022-06-12 08:13:28.715723
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def attr(cls):
            return cls

    class B(A):
        pass

    a = A()
    b = B()

    assert b.attr is not a.attr
    assert not a.attr is A
    assert not b.attr is B
    assert b.attr is B
    assert a.attr is A


# Generated at 2022-06-12 08:13:37.497591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Class(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 1

        @lazyclassproperty
        def y(cls):
            print('y')
            return 1

    class Inherit(Class):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 2

    assert Class.x == 1
    assert Class.x == 1
    assert Class.y == 1

    assert Inherit.x == 2
    assert Inherit.y == 1



# Generated at 2022-06-12 08:13:41.184504
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        def f(cls):
            print('function f called')
            return 42

        g = lazyclassproperty(f)

    assert C.g == 42
    assert C.g == 42     # test if f is called only once



# Generated at 2022-06-12 08:13:51.572569
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Create new class
    class Foo:
        @lazyclassproperty
        def bar(cls):
            return 'baz'

    # Check 'bar' caching
    assert Foo.bar == 'baz'  # create the variable and cache it
    Foo.bar = 'test'  # try to set variable
    assert Foo.bar == 'baz'  # not changed

    # Create new class inheritor
    class Baz(Foo):
        pass

    # Check 'bar' caching (should be separate for each inheritor)
    assert Baz.bar == 'baz'  # create the variable and cache it
    Baz.bar = 'test'  # try to set variable
    assert Baz.bar == 'baz'  # not changed



# Generated at 2022-06-12 08:13:55.324123
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'


# Generated at 2022-06-12 08:13:59.416151
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__


    class Baz(Foo):
        pass


    assert Foo.bar == 'Foo'
    assert Baz.bar == 'Baz'



# Generated at 2022-06-12 08:14:20.592406
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class C(object):

        @lazyclassproperty
        def foo(cls):
            return 42

    class D(C):

        @lazyclassproperty
        def foo(cls):
            return 13

    assert C.foo == 42
    assert D.foo == 13



# Generated at 2022-06-12 08:14:24.983811
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'
    assert Base.foo == 'bar'
    assert Base.__dict__['_Base_lazy_foo'] == 'bar'

    class Sub(Base):
        pass
    assert Sub.foo == 'bar'
    assert Sub.__dict__['_Sub_lazy_foo'] == 'bar'



# Generated at 2022-06-12 08:14:27.569168
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo:
        pass

    class Bar(Foo):
        pass

    class Baz(Bar):
        pass

    @lazyperclassproperty
    def bar(cls):
        return cls

    assert bar is Bar
    assert Baz.bar is Baz



# Generated at 2022-06-12 08:14:29.799230
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @staticmethod
        def test():
            return 1
        test_lazy = lazyclassproperty(test)
    assert Foo.test_lazy == 1



# Generated at 2022-06-12 08:14:32.653852
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def f(cls):
            print('in f')
            return 1
    assert C.f == 1
    assert C.f == 1


# Generated at 2022-06-12 08:14:38.038794
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def attr(cls):
            return 1

    class B(A):
        pass

    class C(B):
        pass

    assert A.attr == 1
    assert B.attr == 1
    assert C.attr == 1

    C.attr = 2
    assert A.attr == 1
    assert B.attr == 1
    assert C.attr == 2


# Generated at 2022-06-12 08:14:41.067219
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            print("Initializing x!")
            return "Hello x!"

    print(C.x)  # Initializes and prints "Initializing x!", then prints "Hello x!"
    print(C.x)  # Prints "Hello x!"
    print(C.x)  # Prints "Hello x!"



# Generated at 2022-06-12 08:14:45.190956
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyperclassproperty
        def prop(cls):
            return 42

    class Test2(Test):
        pass

    assert Test.prop == 42
    assert Test2.prop == 42

    Test.prop = 100
    assert Test.prop == 100
    assert Test2.prop == 42



# Generated at 2022-06-12 08:14:49.193162
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            print("Generating x")
            return 'x'

    # No matter how many times you access it, you get x
    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'

    # But it only prints once
    # Generating x



# Generated at 2022-06-12 08:14:57.493330
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        def __init__(self):
            self.instance_var = 1

        @lazyclassproperty
        def instance_prop(self):
            return self.instance_var

        @lazyperclassproperty
        def class_prop(self):
            return self.instance_var

    t1 = Test()
    t2 = Test()

    assert t1.instance_prop == 1
    assert t2.instance_prop == 1

    assert t1.class_prop == 1
    assert t2.class_prop == 1

    t1.instance_var = 2
    t1.instance_prop = 3

    assert t1.instance_prop == 3
    assert t1.instance_prop == t2.instance_prop

    assert t1.class_prop == 2

# Generated at 2022-06-12 08:15:40.626904
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object): pass
    class B(A): pass

    @lazyperclassproperty
    def foo(cls):
        '''
        DOC
        '''
        print('foo')
        return 'foo'

    assert A.foo == 'foo'
    assert A.foo == 'foo'
    assert B.foo == 'foo'
    print('A.foo.__doc__', A.foo.__doc__)
    assert A.foo.__doc__ == '\n        DOC\n        '
    assert B.foo.__doc__ == '\n        DOC\n        '



# Generated at 2022-06-12 08:15:44.093044
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):

        @lazyperclassproperty
        def x(cls):
            return 'this should be cached'

    class B(A):
        pass

    assert A.x == 'this should be cached'
    assert B.x == 'this should be cached'
    A.x = 'foo'
    assert A.x == 'this should be cached'
    assert B.x == 'this should be cached'



# Generated at 2022-06-12 08:15:47.503058
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        pass

    class Child(Base):
        pass

    @lazyperclassproperty
    def value(cls):
        return id(cls)

    assert Child.value != Base.value, 'Values should differ'
    assert Child.value == Child.value, 'Value should be cached'



# Generated at 2022-06-12 08:15:52.622553
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('call lazyclassproperty')
            return 'bar'

    assert Foo.bar == 'bar'
    assert Foo.bar == 'bar'

    # bar shall not appear in __dict__
    assert 'bar' not in Foo.__dict__

    class Bar(Foo):
        pass

    # the same cached property shall be shared
    # between super and sub class
    assert Foo.bar == Bar.bar == 'bar'
    assert 'bar' not in Bar.__dict__



# Generated at 2022-06-12 08:15:56.108372
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print('evaluating')
            return 'something for {}'.format(cls.__name__)

    a = A()

    # first call, print evaluating
    print(A.a)
    # no print evaluating
    print(A.a)
    # also no print evaluating
    print(a.a)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:16:02.444313
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        prop_counter = 0

        @lazyclassproperty
        def test_prop(cls):
            cls.prop_counter += 1
            return 42

    assert(Foo.test_prop == 42)
    assert(Foo.prop_counter == 1)

    del Foo.test_prop
    assert(Foo.test_prop == 42)
    assert(Foo.prop_counter == 2)

    # Explicitly set the property
    Foo.test_prop = 99
    assert(Foo.test_prop == 99)
    assert(Foo.prop_counter == 3)

    class Foo2(Foo):
        pass

    assert(Foo2.test_prop == 42)
    assert(Foo.test_prop == 99)
    assert(Foo.prop_counter == 4)
   

# Generated at 2022-06-12 08:16:09.255538
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        a = 1
        @lazyclassproperty
        def b(cls):
            print('accessing class property')
            return cls.a

    print(A.a)
    print(A.b)
    print(A.b)
    print(A.a)
    A.a = 2
    print(A.a)
    print(A.b)

    class B(A):
        a = 3

    print(B.a)
    print(B.b)
    print(B.b)
    print(B.a)
    B.a = 4
    print(B.a)
    print(B.b)

# test_lazyclassproperty()


# Generated at 2022-06-12 08:16:17.573026
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('set x')
            return 1

        @x.setter
        def x(cls, value):
            print('set value')
            cls._lazy_x = value

        @x.deleter
        def x(cls):
            del cls._lazy_x

    # Demonstrate value is cached
    assert A.x == 1
    A.x == 1
    print('caches')

    # Demonstrate set functionality
    A.x = 2
    assert A.x == 2
    print('sets')

    # Demonstrate delete functionality
    del A.x
    assert A.x == 1
    print('deletes')



# Generated at 2022-06-12 08:16:22.438881
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test_prop(cls):
            print('setting test_prop')
            return 'foo'

    class B(A): pass

    assert A.test_prop == 'foo'
    assert B.test_prop == 'foo'



# Generated at 2022-06-12 08:16:25.957622
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    print("> Starting test for lazyclassproperty")
    class MyClass(object):
        @lazyclassproperty
        def prop(self):
            return "hello world"

    print("MyClass.prop: %s" % MyClass.prop)
    print("> Test passed")



# Generated at 2022-06-12 08:17:48.656019
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    assert not hasattr(lazyclassproperty, '_lazy_lazyclassprop')
    assert isinstance(lazyclassproperty._lazy_lazyclassprop, lazyclassproperty)

    assert not hasattr(lazyclassproperty, '_lazy_lazyclassprop')
    assert isinstance(lazyclassproperty._lazy_lazyclassprop, lazyclassproperty)

# Generated at 2022-06-12 08:17:53.034557
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            "doc"

# Generated at 2022-06-12 08:18:00.692596
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:05.115282
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def myclassprop(cls):
            return {"x": 1}

        @classproperty
        def myroclassprop(cls):
            return 2
    assert Test.myclassprop == {"x": 1}
    assert Test.myroclassprop == 2



# Generated at 2022-06-12 08:18:10.512610
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class P(object):
        def __init__(self, name):
            self.name = name

    class C1(P):
        def __init__(self):
            super(C1, self).__init__('C1')

        @lazyperclassproperty
        def a(cls):
            return cls.name

    class C2(P):
        def __init__(self):
            super(C2, self).__init__('C2')

        @lazyperclassproperty
        def a(cls):
            return cls.name

    assert C1().a == 'C1'
    assert C2().a == 'C2'



# Generated at 2022-06-12 08:18:14.730742
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:18:20.427960
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import time

    class A(object):
        @lazyclassproperty
        def now(cls):
            time.sleep(2)
            return time.time()

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    start = time.time()
    assert a.now == b.now == c.now
    assert time.time() - start < 2



# Generated at 2022-06-12 08:18:25.556381
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('calculating x')
            return 1

    a = A()
    print(a.x)
    print(a.x)
    print(a.x)
    del a
    a = A()
    print(a.x)
    del a
    A.x = 2
    a = A()
    print(a.x)
    print(A.x)



# Generated at 2022-06-12 08:18:33.659967
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:18:38.040354
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass(object):

        @lazyperclassproperty
        def var(self):
            print('BaseClass.var called')
            return 1

    class InheritorClass(BaseClass):

        @lazyperclassproperty
        def var(self):
            print('InheritorClass.var called')
            return 1

    assert BaseClass.var == 1
    assert InheritorClass.var == 1
