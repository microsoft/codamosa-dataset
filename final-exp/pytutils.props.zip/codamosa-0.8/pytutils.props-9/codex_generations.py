

# Generated at 2022-06-12 08:09:35.901372
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('called')
            return 'bar'

    assert A.foo == 'bar'
    assert A.foo == 'bar'  # cached



# Generated at 2022-06-12 08:09:38.326661
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Meta(type):
        @lazyclassproperty
        def prop(cls):
            return 5

    class MyClass(metaclass=Meta):
        pass

    assert MyClass.prop == 5



# Generated at 2022-06-12 08:09:46.493210
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 2

    class D(B, C):
        pass

    assert A.x == 1
    assert B.x == 1
    assert C.x == 2
    assert D.x == 2
    assert D.x is D._x_lazy_x
    assert B.x is B._x_lazy_x
    assert C.x is C._x_lazy_x
    assert A.x is A._x_lazy_x


# Generated at 2022-06-12 08:09:50.964294
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class C(B):
        @lazyclassproperty
        def x(cls):
            return 2

    assert A.x == B.x == 1
    assert C.x == 2



# Generated at 2022-06-12 08:09:57.674739
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self, a):
            self.a = a

    class B(A):
        pass

    class C(B):
        pass

    @lazyperclassproperty
    def test_prop(self):
        return self.a

    a = A(1)
    assert a.test_prop == 1
    a.a = 2
    assert a.test_prop == 2

    b = B(1)
    assert b.test_prop == 1
    b.a = 2
    assert b.test_prop == 2

    c = C(1)
    assert c.test_prop == 1
    c.a = 2
    assert c.test_prop == 2


# Generated at 2022-06-12 08:10:02.348571
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class ClassA(object):
        @lazyclassproperty
        def class_var(cls):
            return 42

    assert ClassA.class_var == 42

    class ClassB(ClassA):
        pass

    assert ClassB.class_var == 42
    # the function is not called again
    assert ClassA.class_var == 42



# Generated at 2022-06-12 08:10:05.314643
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X(object):
        _x = 1
        @lazyclassproperty
        def x(cls):
            cls._x += 1
            return cls._x

    assert X.x == 2
    assert X.x == 2


# Generated at 2022-06-12 08:10:11.448949
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:14.803604
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def slow(cls):
            time.sleep(1)
            return 1

    class B(A):
        pass

    with Timeout(2):
        A.slow
        B.slow



# Generated at 2022-06-12 08:10:20.218459
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        x = lazyclassproperty(lambda cls: 1)

    class B(A):
        pass

    class C(A):
        pass

    assert all([A.x, B.x, C.x])
    assert all([A().x, B().x, C().x])

# Generated at 2022-06-12 08:10:30.741064
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def my_class_property(cls):
            return "my_class_property"

    class MyClass2(MyClass):
        pass


# Generated at 2022-06-12 08:10:36.959360
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, tid):
            self.tid = tid

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return A(cls.__name__)

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return A(cls.__name__)

    print(B.a.tid)
    print(C.a.tid)



# Generated at 2022-06-12 08:10:43.800500
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class D(object):
        pass

    class C(D):
        @lazyperclassproperty
        def a(cls):
            return "foo"

    assert D.a == "foo"
    assert C.a == "foo"

    D.a = "bar"
    assert C.a == "foo"

    C.a = "baz"
    assert D.a == "bar"
    assert C.a == "baz"



# Generated at 2022-06-12 08:10:54.064725
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert hasattr(A, '_A_lazy_foo')
    assert hasattr(B, '_B_lazy_foo')
    assert hasattr(C, '_C_lazy_foo')

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'

    a = A()
    b = B()
    c = C()

    assert a.foo == 'A'
    assert b.foo == 'B'
    assert c.foo == 'C'

# Generated at 2022-06-12 08:10:58.946538
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        foo = 1
        @lazyclassproperty
        def bar(cls):
            return Foo.foo + 1
    assert Foo.bar == 2
    Foo.foo = 2
    assert Foo.bar == 2
    class Bar(Foo):
        pass
    assert Bar.bar == 3
    class Bar2(Bar):
        pass
    assert Bar2.bar == 4
    class Bar3(Bar):
        foo = 2
    assert Bar3.bar == 3



# Generated at 2022-06-12 08:11:06.209994
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:11:08.716630
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def foo(cls):
            return 'FOO'

    class Child(Parent):
        pass

    assert Child.foo == Parent.foo == 'FOO'
    assert Child.foo != object.foo
    try:
        del Child.foo
        assert False
    except AttributeError:
        pass


if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:11:13.631279
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def f(cls):
            print(cls.__name__)
            return 'Base'

    class Sub(Base):
        pass

    print(Base.f)  # prints Base
    print(Sub.f)  # prints Sub
    assert Base.f == 'Base'
    assert Sub.f == 'Base'



# Generated at 2022-06-12 08:11:19.718573
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Class1(object):
        @lazyclassproperty
        def var(cls):
            return 1

    class Class2(object):
        @lazyclassproperty
        def var(cls):
            return 2

    assert Class1.var == 1
    assert Class2.var == 2

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:11:25.671040
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:11:37.708068
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    import inspect


# Generated at 2022-06-12 08:11:39.436214
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def test(self):
            return 1

    assert Test.test == 1

# Generated at 2022-06-12 08:11:45.551931
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        def __init__(self):
            pass

        @lazyclassproperty
        def prop(self):
            return "prop"

    a = MyClass()
    b = MyClass()
    print(MyClass.prop)
    print(a.prop)
    print(b.prop)

    MyClass.prop = 'changed'
    print(MyClass.prop)
    print(a.prop)
    print(b.prop)

# Generated at 2022-06-12 08:11:48.804965
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    testname = "test_lazyclassproperty"

    class TestLazyClassProperty:
        counter = 0

        @lazyclassproperty
        def test_name(cls):
            cls.counter += 1
            return testname

        def __init__(self):
            # Do nothing
            pass

    assert TestLazyClassProperty.counter == 0
    t1 = TestLazyClassProperty()
    assert TestLazyClassProperty.counter == 1
    t2 = TestLazyClassProperty()
    assert TestLazyClassProperty.counter == 1
    assert t1.test_name == testname
    assert t2.test_name == testname
    assert TestLazyClassProperty.counter == 1
    assert TestLazyClassProperty.test_name == testname
    assert TestLazyClassProperty.counter == 1



# Generated at 2022-06-12 08:11:54.981611
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print('initializing a')
            return 'a'

    class B(A):
        @lazyclassproperty
        def b(cls):
            print('initializing b')
            return 'b'

    a = A()
    b = B()
    assert A.a == 'a'
    assert B.a == 'a'
    assert B.b == 'b'
    assert A.b == 'b'


# Generated at 2022-06-12 08:12:01.529578
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'baz'

    assert hasattr(Foo, '_lazy_bar')
    assert not hasattr(Foo, 'bar')
    assert Foo.bar == 'baz'
    assert Foo.bar == 'baz'

    class Bar(Foo):
        pass

    assert Bar.bar == 'baz'



# Generated at 2022-06-12 08:12:06.397673
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def __call__(self):
            print('calling __call__')
            return 'called'

    class B(A):
        pass

    assert A().__call__ == 'called'
    assert B().__call__ == 'called'

    assert A.__call__ is not B.__call__

# Generated at 2022-06-12 08:12:08.743549
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def b(cls):
            return 'b'
    assert A.b == 'b'

# Generated at 2022-06-12 08:12:13.036735
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            print('Computing value...')
            return 1

    assert Foo.foo == 1
    assert Foo.foo == 1
    assert Foo.foo == 1



# Generated at 2022-06-12 08:12:19.813634
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # Base class
    class Base(object):
        def __init__(self):
            self.value = 0

        @lazyperclassproperty
        def f(cls):
            print(cls)
            cls.value = cls.value + 1
            return cls.value

    # Inheritor
    class Inheritor(Base):
        def __init__(self):
            super(Inheritor, self).__init__()
            self.value = 100

    assert Base.f == 1, 'lazyperclassproperty does not work for base classes'
    assert Inheritor.f == 2, 'lazyperclassproperty does not work for inheritors'


# Generated at 2022-06-12 08:12:33.312851
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def attr(cls):
            print("evaluating %s.%s..." % (cls, "attr"))
            return ["a"] * 5

    class B(A):
        pass

    assert A.attr == B.attr
    assert A.attr is not B.attr



# Generated at 2022-06-12 08:12:37.653302
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C():
        @lazyclassproperty
        def foo(cls):
            print ('called')
            return 'bar'

    print ('First call to x.foo:')
    x = C()
    print (x.foo)
    print ('Second call to x.foo:')
    print (x.foo)
    print ('First call to y.foo:')
    y = C()
    print (y.foo)



# Generated at 2022-06-12 08:12:49.027855
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class PropertyClass(object):

        @lazyclassproperty
        def lazyclassprop(cls):
            return 'I am %s' % cls.__name__

        inc_lazyclassprop_calls = 0

        @lazyclassproperty
        def lazyclassprop_with_args(cls, arg, extra=None):
            PropertyClass.inc_lazyclassprop_calls += 1
            return '%s %s %s' % (arg, cls.__name__, extra)

    assert PropertyClass.lazyclassprop == 'I am PropertyClass'
    assert PropertyClass.lazyclassprop == 'I am PropertyClass'

    assert PropertyClass.lazyclassprop_with_args('temp', 'arg') == 'temp PropertyClass arg'

# Generated at 2022-06-12 08:12:56.211829
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Father:
        def __init__(self, a):
            self.a = a

    class Child1(Father):
        def __init__(self, a):
            Father.__init__(self, a)

    class Child2(Father):
        def __init__(self, a):
            Father.__init__(self, a)

    class MyClass(object):
        @lazyperclassproperty
        def some_property(self):
            return Father([1])

    c1 = Child1([])
    c2 = Child2([])
    c1.some_property.a.append(2)
    print(c1.some_property.a)
    print(c2.some_property.a)



# Generated at 2022-06-12 08:13:02.868400
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:07.501562
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class X:
        def __init__(self):
            self.x = 1

        @lazyclassproperty
        def x(self):
            return X()

        @lazyclassproperty
        def y(cls):
            return cls()

    assert X.x is X.x
    assert X().x is X.x
    assert X().y is X()


# Generated at 2022-06-12 08:13:10.797854
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def i(cls):
            print('A.i called')
            return 123

    class B(A):
        pass

    a = A()
    b = B()

    assert a.i == b.i


# Generated at 2022-06-12 08:13:19.165242
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        def __init__(self, x):
            self._x = x

        @lazyperclassproperty
        def y(cls):
            return cls._x+1

    class B(A):
        _x = 2

    assert A.y == 2
    assert B.y == 3

    a = A(4)
    b = B()

    assert a.y == 5
    assert b.y == 3

    a.y = 6
    assert a.y == 6

    del A.y
    A.y = 7
    assert a.y == 7

    del B.y
    B.y = 8
    assert b.y == 8


# Generated at 2022-06-12 08:13:23.846062
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test(object):
        @lazyclassproperty
        def prop(cls):
            return 'a'

    test2 = type('test2', (test, ), {})

    assert test.prop == 'a'
    assert test2.prop == 'a'

    test.prop = 'b'
    assert test.prop == 'b'
    assert test2.prop == 'a'



# Generated at 2022-06-12 08:13:28.598128
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C:
        @lazyperclassproperty
        def double(cls):
            return cls * 2

    assert C.double == 2
    assert C.double == 2

    class D(C):
        pass

    assert D.double == 2
    assert D.double == 2



# Generated at 2022-06-12 08:13:55.543186
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazy_attr(self):
            print('lazyprop_attr')
            return 'lazyprop_attr'
    class B(A):
        pass
    class C(A):
        pass
    a = A()
    b = B()
    c = C()
    print(A.lazy_attr)
    print(a.lazy_attr)
    print(B.lazy_attr)
    print(b.lazy_attr)
    print(C.lazy_attr)
    print(c.lazy_attr)

    print(B.lazy_attr is C.lazy_attr is A.lazy_attr)
    print(b.lazy_attr is B.lazy_attr is a.lazy_attr)
   

# Generated at 2022-06-12 08:14:05.808553
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class OurMetaClass(type): pass

    class Base(object): pass
    class Inheritor(Base):
        __metaclass__ = OurMetaClass

    class TestClass(object):
        @lazyperclassproperty
        def list1(cls):
            return []

        @lazyperclassproperty
        def list2(cls):
            return []

    assert TestClass.list1 is TestClass.list1
    assert TestClass.list2 is TestClass.list2
    assert TestClass.list1 is not TestClass.list2

    assert Inheritor.list1 is Inheritor.list1
    assert Inheritor.list2 is Inheritor.list2
    assert Inheritor.list1 is not Inheritor.list2

    # Test that the values are really stored per class
    assert Base.list1 is not TestClass.list1


# Generated at 2022-06-12 08:14:12.433670
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:14:17.193636
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == B.foo == 'A'
    assert C.foo == 'C'

    A.foo = 'foobar'
    assert A.foo == 'foobar'
    assert B.foo == C.foo == 'A'



# Generated at 2022-06-12 08:14:20.993207
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("Assigning...")
            return "bar"

    class B(A):
        pass

    print(A.foo)
    print(A.foo)
    print(B.foo)
    print(B.foo)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:14:24.575560
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestSuperclass(object):
        @lazyperclassproperty
        @classmethod
        def Test(cls):
            TestSuperclass._t = 'test'
            return TestSuperclass._t

        @classmethod
        def TestValue(cls):
            return TestSuperclass._t

    class TestSubclass1(TestSuperclass):
        pass

    class TestSubclass2(TestSuperclass):
        pass


# Generated at 2022-06-12 08:14:29.727751
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print('Building A.prop')
            return cls.__name__

    @add_metaclass(proxy.Metaclass)
    class B(A):
        pass

    @add_metaclass(proxy.Metaclass)
    class C(A):
        pass

    print(A.prop, B.prop, C.prop)
    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'C'


# Generated at 2022-06-12 08:14:32.270356
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def foo(cls):
        return cls.__name__

    class Foo(object):
        bar = lazyperclassproperty(foo)

    class Bar(Foo):
        pass

    assert('Bar' == Bar.bar)
    assert('Foo' == Foo.bar)



# Generated at 2022-06-12 08:14:38.864718
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def test_value(cls):
            print('test_value called')
            return 'test value'
    print('A.test_value:', A.test_value)
    print('A.test_value:', A.test_value)
    print('A.test_value:', A.test_value)
    class B(A):
        pass
    print('B.test_value:', B.test_value)
    print('B.test_value:', B.test_value)



# Generated at 2022-06-12 08:14:47.527610
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        _x = None
    class B(A):
        @lazyperclassproperty
        def foo(cls):
            cls._x = 42
            return 'bar'
    class C(B):
        @lazyperclassproperty
        def foo(cls):
            cls._x = 123
            return 'notbar'
    assert not hasattr(A, '_x')
    assert B._x is None
    assert C._x is None
    assert A.foo == 'bar'
    assert B._x == 42
    assert C._x is None
    assert B.foo == 'bar'
    assert B._x == 42
    assert C._x is None
    assert C.foo == 'notbar'
    assert B._x == 42
    assert C._x == 123
    assert A

# Generated at 2022-06-12 08:15:27.007287
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def f(cls):
            return 'From class: ' + cls.__name__

    class D(C):
        pass

    class E(C):
        a = C.f
        b = D.f
        c = E.f


# Generated at 2022-06-12 08:15:34.061952
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Unit test for function lazyperclassproperty.
    Verifies that each class has it's own cached value.
    """

# Generated at 2022-06-12 08:15:39.876821
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print('Get a')
            return 1

    class B(A):
        @lazyclassproperty
        def b(cls):
            print('Get b')
            return 2

    class C(A):
        @lazyclassproperty
        def a(cls):
            print('Get c')
            return 3

    assert A.a == 1
    assert B.a == 1
    assert B.b == 2
    assert C.a == 3

    assert A().a == 1
    assert B().a == 1
    assert B().b == 2
    assert C().a == 3

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:15:43.863678
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'


    class B(A):
        pass


    class C(A):
        pass


    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'
    A.foo = 'bar'
    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'


# Util functions

# Generated at 2022-06-12 08:15:48.884399
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def fn(cls):
        return 'hi, this is a test!'

    class A(object):
        lp = lazyperclassproperty(fn)

    class B(A):
        pass

    assert A.lp == B.lp
    assert A.lp == 'hi, this is a test!'
    assert B.lp == 'hi, this is a test!'

    A.lp = 'Overwrite'
    assert A.lp == B.lp
    assert A.lp == 'Overwrite'
    assert B.lp == 'Overwrite'


# Generated at 2022-06-12 08:15:51.612010
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class Derived(Base):
        pass

    assert Base.foo == 'Base'
    assert Derived.foo == 'Derived'



# Generated at 2022-06-12 08:15:54.156367
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        _x = 1

        @lazyclassproperty
        def x(cls):
            return cls._x
    class B(A):
        _x = 2
    assert A.x == 1
    assert B.x == 2



# Generated at 2022-06-12 08:15:56.364734
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """Test for lazyclassproperty"""
    class Test(object):
        """Test for lazyclassproperty"""
        @lazyclassproperty
        def sum(cls):
            """Test for lazyclassproperty"""
            return sum(range(50))

    assert Test.sum == 1225

# Generated at 2022-06-12 08:15:58.368394
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:01.472508
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:17:19.673283
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def some_property(self):
            return 42

    assert TestClass.some_property == 42
    assert not hasattr(TestClass, '_lazy_some_property')


# Generated at 2022-06-12 08:17:23.203884
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test_class(object):
        @lazyclassproperty
        def test_property(cls):
            value = 'test_value'
            print('test_property evaluated')
            return value

    assert test_class.test_property == 'test_value'
    assert test_class.test_property == 'test_value'



# Generated at 2022-06-12 08:17:25.857346
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        a = 1
        b = lazyclassproperty(lambda inst: inst.a)

    class B(A):
        a = 2

    assert A.b == 1
    assert B.b == 2



# Generated at 2022-06-12 08:17:28.077542
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:32.340688
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:17:34.935063
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        test_counter = 0

        @lazyclassproperty
        def test_property(cls):
            cls.test_counter += 1
            return 42

    assert TestClass.test_property == 42
    assert TestClass.test_counter == 1



# Generated at 2022-06-12 08:17:37.402463
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def the_property(self):
            return 'hello world'

    assert A.the_property == 'hello world'



# Generated at 2022-06-12 08:17:42.747495
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def my_class_var(cls):
            return "Base"

    class Derived(Base):
        pass

    assert Base.my_class_var == "Base"
    assert Derived.my_class_var == "Base"


# Generated at 2022-06-12 08:17:48.239071
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def count(self):
            return 0

        def increase(self):
            self.count += 1

        def __repr__(self):
            return str(self.count)

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    for index in range(10):
        a.increase()
        b.increase()
        c.increase()

    for cls in [A, B, C]:
        assert cls.count == 10

# Generated at 2022-06-12 08:17:57.444105
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        def __init__(self):
            self.a = 0