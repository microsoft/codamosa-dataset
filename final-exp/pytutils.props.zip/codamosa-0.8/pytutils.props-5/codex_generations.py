

# Generated at 2022-06-12 08:09:38.840931
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest
    import os

    class Test(unittest.TestCase):
        def test(self):
            class A(object):
                pass

            class B(A):
                @lazyperclassproperty
                def test(self):
                    return os.getpid()

            class C(object):
                @lazyperclassproperty
                def test(self):
                    return os.getpid()

            a = A()
            b = B()
            c = C()

            pid = os.getpid()
            self.assertEqual(a.test, pid)
            self.assertEqual(b.test, pid)
            self.assertEqual(c.test, pid)
            self.assertEqual(A.test, pid)
            self.assertEqual(B.test, pid)

# Generated at 2022-06-12 08:09:47.474501
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestLazyClassProperty:
        @lazyclassproperty
        def foo(cls):
            print('called')
            return 'bar'

    assert TestLazyClassProperty.foo == 'bar'
    assert TestLazyClassProperty.foo == 'bar'

    class TestLazyClassProperty2(TestLazyClassProperty):
        pass

    assert TestLazyClassProperty2.foo == 'bar'

    class TestLazyClassProperty3(TestLazyClassProperty):
        @lazyclassproperty
        def foo(cls):
            print('called')
            return 'baz'

    assert TestLazyClassProperty3.foo == 'baz'
    assert TestLazyClassProperty3.foo == 'baz'

    assert TestLazyClassProperty2.foo == 'bar'

# Generated at 2022-06-12 08:09:54.244848
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    newattr = '_lazy_attr_created'

    class Foo(object):
        @classmethod
        def method(cls):
            return cls

        @lazyclassproperty
        def foo(cls):
            setattr(cls, newattr, True)
            return cls

    assert not hasattr(Foo, newattr)
    assert Foo.foo is Foo  # calls and caches the result
    assert hasattr(Foo, newattr)
    assert Foo.foo is Foo  # returns the cached result



# Generated at 2022-06-12 08:10:03.339866
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        x = 0

        @lazyperclassproperty
        def y(self):
            self.x = 1
            return self.x

        @lazyperclassproperty
        def z(self):
            self.x = 2
            return self.x

    class Bar(Foo):
        pass

    f = Foo()
    b = Bar()

    assert f.y == 1
    assert f.x == 1

    assert b.y == 1
    assert b.x == 1
    assert f.x == 1

    assert b.z == 2
    assert b.x == 2
    assert f.x == 1

    assert f.z == 2
    assert f.x == 1



# Generated at 2022-06-12 08:10:06.164789
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def ham(klass):
            return 'ham'

    class B(A):
        pass

    assert A.ham == 'ham'
    assert B.ham == 'ham'
    assert A.ham == B.ham



# Generated at 2022-06-12 08:10:16.055622
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        def __init__(self, value):
            self.value = value

        @classmethod
        def _create_value(cls, _):
            return 10

        @lazyperclassproperty
        def value(cls):
            return cls._create_value(cls)

    class Bar(Foo):
        def __init__(self, value):
            self.value = value

        @classmethod
        def _create_value(cls, _):
            return 20

    assert Foo.value == 10
    assert Bar.value == 20
    assert Foo(1).value == 10
    assert Bar(2).value == 20
    assert Bar(3).value == 20



# Generated at 2022-06-12 08:10:18.180508
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert Foo.bar == 'bar'

# Generated at 2022-06-12 08:10:25.167221
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:35.429722
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f(cls): return 1

    class A(object):
        x = lazyclassproperty(f)  # Creates a descriptor

    class B(A):
        pass

    assert A.x == 1  # Calls f(cls)
    assert B.x == 1

    class C(object):
        pass

    C.x = lazyclassproperty(f)  # Creates a descriptor

    assert C.x == 1  # Calls f(cls)

    class D(C):
        pass

    assert D.x == 1

    del A.x  # Deletes the descriptor
    assert not hasattr(A, '_lazy_f')

    A.x = 2  # Sets a normal class attribute
    assert A.x == 2

    del A.x
    A.x = lazyclassproperty(f)  # Creat

# Generated at 2022-06-12 08:10:41.614636
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def count(cls):
            return len(cls.x)

        x = range(10)

    assert A.count == 10
    A.x = range(20)
    assert A.count == 20
    delattr(A, '_lazy_count') # remove the cached value
    assert A.count == 20     # recompute the value and cache it



# Generated at 2022-06-12 08:10:53.533892
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class P(object):
        @lazyperclassproperty
        def __per_class_attr(cls):
            return "__per_class_attr"

    class C(P):
        pass

    assert C.__per_class_attr == "__per_class_attr"

    class D(P):
        @classproperty
        def __per_class_attr(cls):
            return "__per_class_attr_replaced"

    assert D.__per_class_attr == "__per_class_attr_replaced"

    class E(D):
        pass

    assert E.__per_class_attr == "__per_class_attr_replaced"



# Generated at 2022-06-12 08:10:56.924899
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('calculating bar')
            return 42

    assert Foo.bar == 42
    assert Foo.bar == 42
    assert Foo.bar == 42
    assert Foo.__dict__['_lazy_bar'] == 42



# Generated at 2022-06-12 08:11:03.042941
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def get_one(cls):
            return 1
    class B(A):
        pass

    assert A.get_one == 1
    assert A.get_one == 1 # check that property is really cached per class
    assert B.get_one == 1
# End unit test for function lazyclassproperty


# Generated at 2022-06-12 08:11:10.038662
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:18.329998
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        _foo = None
        @lazyclassproperty
        def foo(cls):
            cls._foo = 'It works (class property)!'
            return cls._foo
        def bar(self):
            return self.__class__._foo
    a = A()
    assert a.__class__._foo is None
    assert A._foo is None
    assert a.foo == 'It works (class property)!'
    assert A._foo == 'It works (class property)!'
    assert a.bar() == 'It works (class property)!'



# Generated at 2022-06-12 08:11:28.200123
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:35.158766
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    call_count = {'count': 0}

    class Foo(object):

        @lazyclassproperty
        def prop(cls):
            call_count['count'] += 1
            return 42

    assert not hasattr(Foo, '_lazy_prop')
    assert Foo.prop == 42
    assert Foo.prop == 42  # cached
    assert call_count['count'] == 1
    del Foo.prop
    assert Foo.prop == 42
    assert call_count['count'] == 2



# Generated at 2022-06-12 08:11:41.448353
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'string'

    assert A.prop == 'string'

    # Check whether the value is cached
    A.prop = 'test'
    assert A.prop == 'test'

    class B(A):
        pass

    B.prop = 'test2'
    assert B.prop == 'test2'
    assert A.prop == 'test'


# Generated at 2022-06-12 08:11:46.602845
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:55.950716
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            pass

        @lazyclassproperty
        def baz(cls):
            return 'class'

    class Foo(Base):
        def __init__(self):
            Base.__init__(self)

        @lazyperclassproperty
        def bar(cls):
            return 'class'

    class Bar(Base):
        def __init__(self):
            Base.__init__(self)

        @lazyperclassproperty
        def bar(cls):
            return 'class2'

    f = Foo()
    b = Bar()

    assert (Foo.bar == 'class')
    assert (Bar.bar == 'class2')
    assert (Base.bar == 'class')
    assert (Base.baz == 'class')



# Generated at 2022-06-12 08:12:07.631395
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):
        _bar = None

        def __init__(self):
            self._bar = True

        @lazyclassproperty
        def bar(cls):
            return 'foo'

    # Test that the class property is set correctly
    assert MyClass.bar == 'foo'

    # Test that instances do not override the class property
    m = MyClass()
    assert m.bar == 'foo'

    # Test that instances do not override the class property
    m = MyClass()
    m.bar = 'what?'
    assert MyClass.bar == 'foo'
    assert m.bar == 'foo'



# Generated at 2022-06-12 08:12:14.121476
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class Test(unittest.TestCase):
        def test_lazyclassproperty(self):
            class MyClass(object):
                @lazyclassproperty
                def foo(cls):
                    print('called')
                    return 42

            self.assertEqual(MyClass.foo, 42)
            self.assertEqual(MyClass.foo, 42)

    unittest.main()



# Generated at 2022-06-12 08:12:17.396464
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test lazyclassproperty.
    """
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'abc'
    assert A.x == 'abc'


# Generated at 2022-06-12 08:12:26.972624
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Foo(object):
        int = 0

        @lazyperclassproperty
        def perclassint(cls):
            print("Creating Foo.perclassint")
            cls.int += 1
            return cls.int

    class Bar(Foo):
        int = 0

        @lazyperclassproperty
        def perclassint(cls):
            print("Creating Bar.perclassint")
            cls.int += 1
            return cls.int

    assert Foo.perclassint == 1
    assert Bar.perclassint == 1
    assert Bar.perclassint == 1


    class Foo(object):

        @lazyclassproperty
        def perclassint(cls):
            print("Creating Foo.perclassint")
            return 1

    class Bar(Foo):
        int = 0


# Generated at 2022-06-12 08:12:36.843498
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Dummy:
        class_attr = []
        @lazyperclassproperty
        def random_attr(cls):
            return cls.class_attr + [random.random()]
    class DummyInheritor(Dummy):
        pass

    dummy = Dummy()
    dummy_inheritor = DummyInheritor()

    assert_equal(dummy.random_attr, dummy.random_attr)
    assert_not_equal(dummy_inheritor.random_attr, dummy_inheritor.random_attr)
    # DummyInheritor.random_attr is a cls's property
    assert_equal(dummy_inheritor.random_attr, DummyInheritor.random_attr)

# Generated at 2022-06-12 08:12:45.661147
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:54.909864
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def test(cls):
            return "AA"

        @lazyclassproperty
        def test2(cls):
            return "BB"

    class B(A):
        pass

    assert A.test == "AA"
    assert B.test == "AA"
    assert A.test2 == "BB"
    assert B.test2 == "BB"
    # Change value in subclass A
    A.test = "CC"
    assert A.test == "CC"
    assert B.test == "AA"
    assert A.test2 == "BB"
    assert B.test2 == "BB"
    # Change value in subclass B
    B.test2 = "DD"
    assert A.test == "CC"
    assert B.test == "AA"


# Generated at 2022-06-12 08:13:05.020161
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Parent(object):
        constants = [1, 2, 3]


# Generated at 2022-06-12 08:13:09.107214
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def __init__(self):
            self.checked = False

        @lazyclassproperty
        def prop(cls):
            obj = cls()
            obj.checked = True
            return obj

    assert not (A.prop.checked)
    assert A.prop.checked



# Generated at 2022-06-12 08:13:14.901805
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            print("Foo initializing")
            return 1

    class Bar(Foo):
        pass

    class Baz(Foo):
        @lazyclassproperty
        def foo(cls):
            print("Baz initializing")
            return 2

    assert Foo.foo == 1
    assert Bar.foo == 1
    assert Baz.foo == 2
    assert Foo.foo == 1
    assert Bar.foo == 1
    assert Baz.foo == 2



# Generated at 2022-06-12 08:13:26.995250
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:29.773651
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
                return 5
    
    class B(A):
        pass
    
    assert A.test == 5
    assert B.test == 5



# Generated at 2022-06-12 08:13:36.437967
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:40.523096
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 1

    class B(A):
        @lazyperclassproperty
        def prop(cls):
            return 2

    assert A.prop == 1
    assert B.prop == 2



# Generated at 2022-06-12 08:13:49.259365
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        counter = 0

        @lazyperclassproperty
        def prop(cls):
            cls.counter += 1
            return 'foo'

    class B(A):
        pass

    class C(A):
        pass


# Generated at 2022-06-12 08:13:56.261263
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def val(cls):
            print(f'val got called for class {cls}')
            return []

    class B(A):
        pass

    assert A.val is not B.val
    assert A.val is A.val
    assert B.val is B.val

    assert not A.val
    assert not B.val

    A.val.append('hello')
    assert A.val == ['hello']
    assert not B.val

    B.val.append('world')
    assert A.val == ['hello']
    assert B.val == ['world']



# Generated at 2022-06-12 08:14:00.360238
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        attr = 'This is the class prop'

        @lazyclassproperty
        def get_class_prop(cls):
            return cls.attr
    my_obj = MyClass()
    assert (MyClass.get_class_prop == MyClass.attr)
    assert (my_obj.get_class_prop == MyClass.attr)



# Generated at 2022-06-12 08:14:07.285540
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def v(cls):
            return 1
    assert A.v == 1
    assert A.__dict__['_lazy_v'] == 1

    class B(A):
        pass
    assert B.v == 1
    assert B.__dict__['_lazy_v'] == 1

    class C(A):
        @lazyclassproperty
        def v(cls):
            return 2
    assert C.v == 2
    assert C.__dict__['_lazy_v'] == 2

    class D(C):
        pass
    assert D.v == 2
    assert D.__dict__['_lazy_v'] == 2



# Generated at 2022-06-12 08:14:12.549573
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def test(cls):
            return id(cls)

    class Bar(Foo):
        pass

    class Baz(Bar):
        pass

    assert id(Foo) != id(Bar) != id(Baz)
    assert Foo.test == id(Foo)
    assert Bar.test == id(Bar)
    assert Baz.test == id(Baz)
    assert Foo.test == id(Foo)


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:14:14.948615
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('initializing')
            return 'foo'

    print(A.x)

    class B(A):
        pass

    print(B.x)



# Generated at 2022-06-12 08:14:37.698573
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:14:39.985301
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        def __init__(self):
            self.name = 'A'

        @lazyclassproperty
        def a(cls):
            return cls.__name__ + ' a'

    assert A.a == 'A a', 'test failed'



# Generated at 2022-06-12 08:14:48.282891
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import copy
    import random

    class A(object):
        @lazyperclassproperty
        def L(cls):
            return random.random()

    class B(A):
        pass

    class C(B):
        pass

    L = [1]

    class D(C):
        @lazyperclassproperty
        def L(cls):
            return copy.deepcopy(L)

    L.append(2)

    assert A.L is A.L
    assert A().L is A.L

    assert B.L is B.L
    assert B().L is B.L

    assert C.L is C.L
    assert C().L is C.L

    assert D.L is D.L
    assert D().L is D.L

    assert A.L is not B.L

# Generated at 2022-06-12 08:14:50.601710
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert Foo.bar == 'bar'
    assert Foo._lazy_bar == 'bar'



# Generated at 2022-06-12 08:14:53.697352
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:15:03.282677
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):

        @lazyperclassproperty
        def foo(cls):
            return id(cls)

    class B(A):
        pass

    class C(A):
        pass

    print(A.foo)
    print(B.foo)
    print(C.foo)

    # check that the lazy property was assigned only once to each class, not once for every instance
    a = A()
    b = B()
    c = C()

    print(a.foo, A.foo)
    print(b.foo, B.foo)
    print(c.foo, C.foo)

    assert a.foo == A.foo
    assert b.foo == B.foo
    assert c.foo == C.foo

    assert a.foo == id(A)

# Generated at 2022-06-12 08:15:10.062005
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test(object):
        @lazyclassproperty
        def test_fn(cls):
            return 'Test fn'

    class Test1(Test):
        pass

    class Test2(Test):
        @classproperty
        def test_fn2(cls):
            return Test.test_fn

    Test.test_fn == 'Test fn'
    Test1.test_fn == 'Test fn'
    Test2.test_fn2 == 'Test fn'
    Test2.test_fn == 'Test fn'



# Generated at 2022-06-12 08:15:12.933790
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def p(cls):
            return len(cls.__name__)

    class B(A):
        pass


# Generated at 2022-06-12 08:15:17.987375
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def foo(self):
            return 3

        @lazyperclassproperty
        def bar(self):
            return 4

    class TestClassChild(TestClass):
        @lazyperclassproperty
        def foo(self):
            return 5

    assert TestClass().foo == 3
    assert TestClass().bar == 4
    assert TestClassChild().foo == 5
    assert TestClassChild().bar == 4


# Generated at 2022-06-12 08:15:20.427452
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'

# Generated at 2022-06-12 08:16:10.236455
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass
    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'
    assert D.foo == 'D'


# Generated at 2022-06-12 08:16:15.820490
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def a(cls):
            return True

    class B(A):
        pass

    assert A.a is B.a, 'Both classes share the same lazy class property.'

    class C(A):
        @lazyclassproperty
        def a(cls):
            return False

    assert A.a is not C.a, 'Different lazy class property instance for A and C.'


# Generated at 2022-06-12 08:16:25.957199
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 1

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert b.test == 1
    assert c.test == 1
    assert C.test == 1

    # Make sure we get the right class in the property
    class D(A):
        @lazyclassproperty
        def test(cls):
            return cls.__name__

    d = D()
    assert d.test == 'D'
    assert D.test == 'D'

    # Make sure cached properties are still lazy

# Generated at 2022-06-12 08:16:33.389211
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            print('__foo__')
            return 42

    class A(Base): pass

    class B(Base): pass

    a1 = A()
    b1 = B()

    assert a1.foo == 42
    assert b1.foo == 42
    assert A.foo == 42
    assert B.foo == 42
    assert b1.foo is not a1.foo
    assert A.foo is a1.foo
    assert B.foo is b1.foo



# Generated at 2022-06-12 08:16:37.258731
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def value(cls):
            return 1
    class Inheritor1(Base):pass
    class Inheritor2(Base):pass
    assert Inheritor1.value == 1
    assert Inheritor2.value == 1
    Inheritor1.value = 2
    assert Inheritor1.value == 2
    assert Inheritor2.value == 1


# Generated at 2022-06-12 08:16:43.915879
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def lazy_loader(cls):
        return cls.__name__

    class Test:
        __test__ = False
        data = lazyclassproperty(lazy_loader)
        data2 = lazyclassproperty(lazy_loader)
        data3 = lazyclassproperty(lazy_loader)

    assert Test.data == 'Test'
    assert Test.data2 == 'Test'
    assert Test.data3 == 'Test'

    class Test2(Test):
        __test__ = False
        pass

    assert Test2.data == 'Test2'
    assert Test2.data2 == 'Test2'
    assert Test2.data3 == 'Test2'

    assert Test.data == 'Test'
    assert Test.data2 == 'Test'
    assert Test.data3 == 'Test'



# Generated at 2022-06-12 08:16:51.864697
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def lazy_property(cls):
            return 'a'

    class A(Base):
        pass

    a = A()
    b = A()
    assert a.lazy_property == 'a'
    assert a.lazy_property == 'a'
    assert b.lazy_property == 'a'
    assert b.lazy_property == 'a'

    class B(Base):
        @lazyperclassproperty
        def lazy_property(cls):
            return 'b'

    a = A()
    b = A()
    assert a.lazy_property == 'a'
    assert a.lazy_property == 'a'
    assert b.lazy_property == 'a'
    assert b.lazy_property == 'a'

# Generated at 2022-06-12 08:16:55.199157
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:01.988841
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class X(object):
        def __init__(self, result):
            self.result = result
            self.called = False

        @staticmethod
        def func():
            return X("result")

        @lazyclassproperty
        def x(cls):
            cls.called = True
            return cls.func()

    assert not X.called
    assert isinstance(X.x, X)
    assert X.x.result == "result"
    assert X.called

    X.called = False

    class Y(X):
        pass

    assert not X.called
    assert isinstance(Y.x, X)
    assert Y.x.result == "result"
    assert not X.called


# Generated at 2022-06-12 08:17:08.366561
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C1(object):
        @lazyperclassproperty
        def x(cls):
            print('Getting new x')
            return 'x'

    class C2(C1):
        pass

    class C3(C2):
        pass

    class C4(C3):
        pass

    x1 = C1.x
    x2 = C2.x
    x3 = C3.x
    x4 = C4.x

    assert x1 is not x2
    assert x2 is not x3
    assert x3 is not x4
    print('Success')



# Generated at 2022-06-12 08:18:55.602738
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def clsprop(cls):
            return 'lul'
    class B(A):
        pass
    class C(B):
        pass
    assert A.clsprop == 'lul'
    assert B.clsprop == 'lul'
    assert C.clsprop == 'lul'



# Generated at 2022-06-12 08:19:04.637793
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):
        def __init__(self, value):
            self.inst_value = value

        @lazyclassproperty
        def class_value(cls):
            return cls.inst_value * cls.inst_value

    class MyDerivedClass(MyClass):
        def __init__(self, value):
            MyClass.__init__(self, value)

    x = MyClass(2)
    y = MyDerivedClass(3)
    assert y.class_value == 9, y.class_value
    assert x.class_value == 4, x.class_value

    x.inst_value = 10
    y.inst_value = 20
    assert y.class_value == 400, y.class_value
    assert x.class_value == 100, x.class_value




# Generated at 2022-06-12 08:19:10.564090
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):

        @lazyperclassproperty
        def prop(cls):
            return 'A'

        @lazyperclassproperty
        def prop2(cls):
            return cls.prop

    class B(A):

        @lazyperclassproperty
        def prop(cls):
            return 'B'

    assert A.prop2 == 'A'
    assert B.prop2 == 'B'
    assert A.prop == 'A'
    assert B.prop == 'B'



# Generated at 2022-06-12 08:19:16.093643
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C1(object):
        @lazyperclassproperty
        def test_prop(cls):
            return 'test'

    class C2(C1):
        pass

    assert C1.test_prop == 'test'
    assert C2.test_prop == 'test'
    assert C1.test_prop == C2.test_prop



# Generated at 2022-06-12 08:19:21.749714
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def x():
        return "x"

    def y():
        return "y"

    class Test(object):
        x = lazyclassproperty(x)
        y = lazyclassproperty(y)

    assert Test.x == Test.x == "x"
    assert Test.y == Test.y == "y"
    assert Test.x != Test.y == "y"

    class Test1(object):
        x = lazyclassproperty(x)

    assert Test.x == Test1.x == "x"
    assert Test1.x != Test.y == "y"


# Generated at 2022-06-12 08:19:28.749053
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class cls(object):
        @lazyperclassproperty
        def prop(cls):
            cls.prop_called = True
            return 0
    class cls1(cls):
        pass
    a = cls()
    b = cls1()
    a.prop
    assert cls.prop_called
    assert not getattr(cls1, 'prop_called', False)
    b.prop
    assert cls1.prop_called
