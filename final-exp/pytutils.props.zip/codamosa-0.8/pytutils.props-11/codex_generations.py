

# Generated at 2022-06-12 08:09:38.599370
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Tests lazyperclassproperty.
    """

    class Class:
        @classmethod
        def get_a(cls):
            raise Exception("accessed")

        b = lazyperclassproperty(get_a)

    class Class1(Class):
        pass

    class Class2(Class):
        pass

    for cls in Class1, Class2, Class:
        assert cls.b == cls.b
        assert cls.b != Class1.b
        assert cls.b != Class2.b



# Generated at 2022-06-12 08:09:44.148385
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def attr(cls):
            return cls.__name__

    class B(A):
        pass

    # A.attr is instance of A
    assert isinstance(A.attr, str)
    assert A.attr == "A"
    # B.attr is instance of B
    assert isinstance(B.attr, str)
    assert B.attr == "B"

# Generated at 2022-06-12 08:09:47.126336
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def x(cls):
            return "hello world"

    print(C.x)
    print(C.x)



# Generated at 2022-06-12 08:09:56.215986
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        A1 = lazyperclassproperty(lambda cls: cls.__name__ + 'A1')
        A2 = lazyperclassproperty(lambda cls: cls.__name__ + 'A2')

    class B(A):
        B1 = lazyperclassproperty(lambda cls: cls.__name__ + 'B1')
        B2 = lazyperclassproperty(lambda cls: cls.__name__ + 'B2')

    class C(B):
        C1 = lazyperclassproperty(lambda cls: cls.__name__ + 'C1')
        C2 = lazyperclassproperty(lambda cls: cls.__name__ + 'C2')

    assert A.A1 == 'AA1'
    assert B.A1 == 'BA1'

# Generated at 2022-06-12 08:10:04.477153
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class FirstClass(object):
        @lazyperclassproperty
        def foo(self):
            print("Running test_lazyperclassproperty")
            return "FirstClass foo"
    class SecondClass(FirstClass):
        pass
    class ThirdClass(FirstClass):
        pass
    class FourthClass(SecondClass):
        pass
    fc = FirstClass()
    sc = SecondClass()
    tc = ThirdClass()
    fourthc = FourthClass()
    print(fc.foo)
    print(fc.foo)
    print(sc.foo)
    print(tc.foo)
    print(fourthc.foo)


# Generated at 2022-06-12 08:10:09.851777
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        _x = 1
        @lazyclassproperty
        def x(cls):
            return cls._x
    assert A.x == 1
    A._x = 2
    assert A.x == 2 # A.x is cached and won't change
    del A.x
    assert A.x == 2 # unless specifically deleted


# Generated at 2022-06-12 08:10:17.028122
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:22.673753
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def _test(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def _test(cls):
            return 2

    assert A._test == 1
    assert B._test == 1
    assert C._test == 2


# Generated at 2022-06-12 08:10:27.621731
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:34.939504
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            return 'baz'

    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert C.foo == 'baz'
    # Use is to avoid the case of two different instances that happen to have the same value
    assert A.foo is B.foo
    assert A.foo is not C.foo



# Generated at 2022-06-12 08:10:40.991494
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class DummyClass(object):
        @lazyclassproperty
        def dummy(cls):
            return 10
    assert DummyClass.dummy == 10
    dummy_obj = DummyClass()
    assert dummy_obj.dummy == 10



# Generated at 2022-06-12 08:10:48.094598
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:56.213971
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A():
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class C(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'bar'
    assert C.foo == 'foo'

    # Test caching/laziness
    A_attr = '_lazy_foo'
    B_attr = '_B_lazy_foo'
    assert hasattr(A, A_attr)
    assert hasattr(B, B_attr)
    assert not hasattr(C, A_attr)

    assert '_lazyclassprop' not in A.__dict__
    assert '_lazyclassprop' not in B.__

# Generated at 2022-06-12 08:11:02.219950
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    class MyTest(unittest.TestCase):
        @lazyclassproperty
        def test(cls):
            return "test"

        def test_lazyclassproperty(self):
            self.assertEqual(self.test, "test")
            self.assertTrue(hasattr(self, '_lazy_test'))

    unittest.main()

# Generated at 2022-06-12 08:11:10.125383
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # The decorator @lazyclassproperty creates a new attribute on the class
    # namely _lazy_property1. Because it's not a descriptor, it's created
    # when the class is created, before the instance creation.

    # The decorator @lazyclassproperty creates one attribute on the class
    # but two attributes on each instance of the class.
    # An attribute of the class is an attribute of the instance.
    # Thus, each instance has his own attribute _lazy_property2.

    # _lazy_property2 is a lazy class property so it's created the first
    # time it is called on the instance. After it is created, each instance
    # has his own attribute _lazy_property2.

    class Lazy(object):

        @lazyclassproperty
        def property1(cls):
            return cls


# Generated at 2022-06-12 08:11:12.583718
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def source(cls):
            return 'source'

    assert Test.source == 'source'
    del Test.source


# Generated at 2022-06-12 08:11:17.828285
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 0
    class B(A):
        pass

    assert A.test == B.test == 0
    A.test = 1
    assert A.test == 1
    assert B.test == 0


# Generated at 2022-06-12 08:11:25.253405
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'c'

    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'
    A.a = 'not a'
    assert A.a == 'a'
    assert B.a == 'a'
    assert C.a == 'c'



# Generated at 2022-06-12 08:11:30.783683
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test function test_lazyperclassproperty
    """
    class Base(object):
        def __init__(self, val):
            self.val = val

        @lazyperclassproperty
        def inc(cls):
            return cls.val + 1

    class Derived(Base):
        def __init__(self, val):
            super(Derived, self).__init__(val)

    a = Base(1)
    assert a.inc == 2
    b = Derived(2)
    assert b.inc == 3
    assert a.inc == 2

# Generated at 2022-06-12 08:11:36.735006
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from inspect import isclass
    from .utils import extendable

    @extendable
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls

    assert isclass(A.x)
    assert A.x is A

    class B(A):
        pass

    assert isclass(B.x)
    assert B.x is B



# Generated at 2022-06-12 08:11:42.465822
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def calc(self):
            return 10



# Generated at 2022-06-12 08:11:49.014955
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def get_random_value(cls):
            print ("cached value")
            return random.random()

        @lazyclassproperty
        def get_named_value(cls, name):
            print ("cached value")
            return random.random()

    first = Test.get_random_value
    second = Test.get_random_value

# Generated at 2022-06-12 08:11:55.803044
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:59.126407
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):

        @lazyclassproperty
        def myprop(cls):
            return 'hello'

    assert TestClass.myprop == 'hello'



# Generated at 2022-06-12 08:12:05.485828
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test_prop(cls):
            print('Generating test property')
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def test_prop(cls):
            print('Generating test property')
            return 43

    assert A.test_prop == 42
    assert B.test_prop == 42
    assert C.test_prop == 43



# Generated at 2022-06-12 08:12:10.456880
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def name(cls):
            return 'test'
    assert Test.name == 'test'
    Test.name = 'test2'
    assert Test.name == 'test2'


# Generated at 2022-06-12 08:12:14.210131
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyperclassproperty
        def test(cls):
            return cls
    
    class Test2(Test):
        pass
        
    assert Test.test is Test
    assert Test2.test is Test2
    
    class Test3(Test):
        pass
    
    assert Test3.test is Test3


# Generated at 2022-06-12 08:12:19.466355
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        _value = None

        @lazyperclassproperty
        def value(cls):
            return cls._value

    class B(A):
        _value = 'b'

    class C(B):
        _value = 'c'

    class D(A):
        _value = 'd'

    assert A.value == None
    assert B.value == 'b'
    assert C.value == 'c'
    assert D.value == 'd'



# Generated at 2022-06-12 08:12:27.301210
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def testperclass_str(cls):
            return str(cls)

        @lazyperclassproperty
        def testperclass_name(cls):
            return cls.__name__

    class TestSubClass(TestClass):
        pass

    assert TestClass.testperclass_str == "<class '{0}.TestClass'>".format(__name__)
    assert TestClass.testperclass_name == "TestClass"
    assert TestSubClass.testperclass_str == "<class '{0}.TestSubClass'>".format(__name__)
    assert TestSubClass.testperclass_name == "TestSubClass"


# Generated at 2022-06-12 08:12:30.683756
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def prop(cls):
            return cls.__name__

    assert A.prop == 'A'
    assert A().prop == 'A'



# Generated at 2022-06-12 08:12:46.729466
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def f(cls):
        print('f is called')
        return cls.__name__ + '_results'
    assert f == 'test_lazyclassproperty_results'
    assert type(f) == types.FunctionType # f is still a function not the actual results
    assert f() == 'test_lazyclassproperty_results'
    assert f._lazyclassprop == 'test_lazyclassproperty_results'
    assert test_lazyclassproperty.f._lazyclassprop == 'test_lazyclassproperty_results'


# Generated at 2022-06-12 08:12:50.115572
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class C(object):
        val = 'class property value'

        @lazyclassproperty
        def classprop(self):
            return self.val

    assert C.classprop is C.val, 'Lazy class property must return the expected value'



# Generated at 2022-06-12 08:12:57.206764
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    # When adding lazyperclassproperty, we assign a function to the
    # class; this function is called upon the first call to foo.x.
    Foo.x = lazyperclassproperty(lambda cls: cls.a + cls.b)

    foo = Foo()
    bar = Foo()
    foo.b = 5
    bar.b = 4
    assert foo.x == 6
    assert bar.x == 5

    # Note that changing a class variable after the property was
    # defined will not alter the value of the property.
    Foo.a = 5
    assert foo.x == 6
    assert bar.x == 5




# Generated at 2022-06-12 08:13:04.097627
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazyprop(cls):
            return 'lazyprop_A'

    class B(A):
        @lazyperclassproperty
        def lazyprop(cls):
            return 'lazyprop_B'

    assert B.lazyprop == 'lazyprop_B'
    assert A.lazyprop == 'lazyprop_A'

if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:13:11.114609
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __repr__(self):
            return 'A'

    class B(A):
        pass

    class C(A):
        pass

    @lazyperclassproperty
    def get_class(cls):
        return cls

    assert B.get_class is B
    assert C.get_class is C
    assert A.get_class is A

    @lazyperclassproperty
    def get_instance(cls):
        return cls()

    assert B.get_instance is B()
    assert C.get_instance is C()
    assert A.get_instance is A()


# Generated at 2022-06-12 08:13:14.756987
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'
    print(A.prop)
    print(A.prop)
    assert A.prop == 'value'
    assert A.prop == 'value'
    assert A.prop == 'value'



# Generated at 2022-06-12 08:13:21.586727
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert TestClass.foo == 'bar'
    assert TestClass.foo == 'bar'
    # assign something new to the generated property (not the descriptor itself)
    TestClass.foo = 'baz'
    assert TestClass.foo == 'baz'
    # the value should not be the same for the subclass
    class SubClass(TestClass):
        pass
    assert SubClass.foo == 'bar'



# Generated at 2022-06-12 08:13:28.820466
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def val(cls):
            return cls.x

    class Test2(Test):
        x = 2

    class Test3(Test):
        x = 3

    test = Test(1)
    test2 = Test2(2)
    test3 = Test3(3)

    assert test.val == 1
    assert test2.val == 2
    assert test3.val == 3



# Generated at 2022-06-12 08:13:33.326689
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):

        @lazyclassproperty
        def my_class_property(cls):
            return 'my_class_property value'

    assert 'my_class_property value' == MyClass.my_class_property



# Generated at 2022-06-12 08:13:37.689675
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class SomeClass(object):
        @lazyclassproperty
        def some_property(cls):
            print('Generating property')
            return 42

    assert SomeClass.some_property == 42
    # second time uses cached version
    assert SomeClass.some_property == 42



# Generated at 2022-06-12 08:13:55.692598
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1



# Generated at 2022-06-12 08:13:57.901007
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert Foo.bar == 'bar'



# Generated at 2022-06-12 08:14:05.229882
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test_prop(cls):
            return cls.__name__

    class Child(Base):
        pass

    class Grandchild1(Child):
        pass

    class Grandchild2(Child):
        pass

    class Base2(object):
        @lazyperclassproperty
        def test_prop(cls):
            return cls.__name__[::-1]

    assert hasattr(Base, '_Base_lazy_test_prop')
    assert not hasattr(Base, '_Base2_lazy_test_prop')
    assert not hasattr(Base2, '_Base_lazy_test_prop')
    assert hasattr(Base2, '_Base2_lazy_test_prop')

# Generated at 2022-06-12 08:14:13.019928
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Simple function-based class
    class A:
        @lazyclassproperty
        def prop(self):
            print ('Calculating')
            return 42

    # Testing, part 1
    a = A()
    b = A()

    assert a.prop == 42
    assert a.prop == 42  # Second time shouldn't print anything
    assert a.prop == 42  # Third time shouldn't print anything

    assert b.prop == 42
    assert b.prop == 42  # Second time shouldn't print anything

    a.prop = 24
    assert a.prop == 24
    assert b.prop == 42  # b should remain unchanged

    # Testing, part 2
    class B(A):
        pass

    c = B()

    assert c.prop == 42

    assert c.prop == 42  # Second time shouldn't print anything
   

# Generated at 2022-06-12 08:14:17.921947
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def c(cls):
            print("A.c")
            return 'c1'
    class B(A):
        @lazyperclassproperty
        def c(cls):
            print("B.c")
            return 'c2'

    assert A.c == 'c1'
    assert B.c == 'c2'
    assert A.c == 'c1'
    assert B.c == 'c2'


# Generated at 2022-06-12 08:14:24.373809
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo:
        @lazyperclassproperty
        def foo(cls):
            print("foo called")
            return cls
    class Bar(Foo):
        pass
    """
    >>> test_lazyperclassproperty()
    >>> print(Foo.foo)
    <class '__main__.Foo'>
    >>> print(Bar.foo)
    <class '__main__.Bar'>
    >>> print(Foo.foo)
    <class '__main__.Foo'>
    """
    print(Foo.foo)
    print(Bar.foo)
    print(Foo.foo)



# Generated at 2022-06-12 08:14:29.693514
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        foo_base = lazyperclassproperty(lambda c: 'foo_base')

    class A(Base):
        foo_a = lazyperclassproperty(lambda c: 'foo_a')

    class B(Base):
        foo_b = lazyperclassproperty(lambda c: 'foo_b')

    assert Base.foo_base == 'foo_base'
    assert A.foo_base == 'foo_base'
    assert A.foo_a == 'foo_a'
    assert B.foo_base == 'foo_base'
    assert B.foo_b == 'foo_b'



# Generated at 2022-06-12 08:14:31.805823
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseTest(object):
        var = 5
        @lazyperclassproperty
        def test(cls):
            return cls.var + 5

    class Test(BaseTest):
        var = 10

    class Test2(BaseTest):
        var = 15

    print(BaseTest.test)
    print(Test.test)
    print(Test2.test)



# Generated at 2022-06-12 08:14:37.926917
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        i = 4
        @lazyperclassproperty
        def c(cls):
            return cls.i
    class B(A):
        i = 3
    class C:
        i = 5
        @lazyperclassproperty
        def c(cls):
            return cls.i
    class D(C):
        i = 2
        
    assert A.c == 4
    assert B.c == 3
    assert C.c == 5
    assert D.c == 2

# Generated at 2022-06-12 08:14:41.353038
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def a(cls):
            return 1
    class B(A):
        pass
    class C(A):
        @classproperty
        def a(cls):
            return 3

    assert A.a == 1
    assert B.a == 1
    assert C.a == 3

    A.a = 5

    assert A.a == 5
    assert B.a == 1
    assert C.a == 3



# Generated at 2022-06-12 08:15:17.040871
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert A.a == B.a


# Generated at 2022-06-12 08:15:23.539851
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def a_func(self):
            print("a_func is executed")
            return 1
    class A(Base):
        pass
    class B(Base):
        pass

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    print("{} {} {} {}".format(a1.a_func, a2.a_func, b1.a_func, b2.a_func))


# Generated at 2022-06-12 08:15:25.229791
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def foo(cls):
        return "foo"

    class Example(object):
        x = lazyclassproperty(foo)

    assert Example.x == "foo"
    Example.x = "bar"
    assert Example.x == "bar"



# Generated at 2022-06-12 08:15:31.434374
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:15:36.380162
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:40.859682
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class SpecialBaseClass(object):
        @lazyclassproperty
        def specialized(cls):
            return 'special'

        @lazyclassproperty
        def classname(cls):
            return cls.__name__

    class BaseClass(SpecialBaseClass):
        pass

    class SubClass(BaseClass):
        pass

    SubClass._lazy_classname

    assert BaseClass.specialized == 'special'
    assert SubClass.specialized == 'special'

    assert BaseClass.classname == 'BaseClass'
    assert SubClass.classname == 'SubClass'



# Generated at 2022-06-12 08:15:42.943174
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('calculating')
            return sum(range(35))

    print(Foo.bar)
    print(Foo.bar)



# Generated at 2022-06-12 08:15:45.129459
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def test(cls):
            print("test is called")
            return "test"

    assert Test.test == "test"
    assert Test.test == "test"



# Generated at 2022-06-12 08:15:48.583480
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test(object):

        @lazyclassproperty
        def one(cls):
            print("ONE")
            return 'One'

        @lazyclassproperty
        def two(cls):
            print("TWO")
            return 'Two'

    assert Test.one == 'One'
    assert Test.two == 'Two'

# Generated at 2022-06-12 08:15:53.191344
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            print("Foo.bar called")
            return 1

    class Bar(Foo):
        pass

    class Baz(Foo):
        @lazyperclassproperty
        def bar(cls):
            print("Baz.bar called")
            return 2

    assert Baz.bar == 2
    assert Bar.bar == 1
    assert Foo.bar == 1
    assert Foo().bar == 1



# Generated at 2022-06-12 08:17:06.122514
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def lazyprop(cls):
            print("calculating...")
            return 42
    assert TestClass.lazyprop == 42
    TestClass.lazyprop = 2
    assert TestClass.lazyprop == 2



# Generated at 2022-06-12 08:17:13.790980
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        @lazyperclassproperty
        def b(cls):
            return cls.__name__
    class B(A):
        pass


# Generated at 2022-06-12 08:17:21.430140
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:27.018730
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    x = 0

    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return x

    class B(A):
        pass

    a = A()
    b = B()

    assert a.foo == 0
    assert b.foo == 0

    x = 1

    assert a.foo == 0
    assert b.foo == 0

    A.foo.__get__(a)

    assert a.foo == 1
    assert b.foo == 0

    B.foo.__get__(b)

    assert a.foo == 1
    assert b.foo == 1



# Generated at 2022-06-12 08:17:30.898633
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:37.271870
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    class B(A):
        pass

    print(A.foo, A.foo)

    try:
        print(B.foo)
    except AttributeError as e:
        print('b.foo -> %s: %s' % (e.__class__.__name__, e))

    try:
        print(A().foo)
    except AttributeError as e:
        print('a().foo -> %s: %s' % (e.__class__.__name__, e))



# Generated at 2022-06-12 08:17:47.227662
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestParent(object):
        attr1 = 42

    class TestChild(TestParent):
        pass

    class TestClass(object):

        @lazyperclassproperty
        def clsvar(cls):
            print("Retrieving clsvar for %s" % cls.__name__)
            return cls.attr1

        @lazyperclassproperty
        def clsvar2(cls):
            print("Retrieving clsvar2 for %s" % cls.__name__)
            return cls.attr1

    print("Running tests for TestParent")
    TestParent.clsvar
    TestParent.clsvar2
    TestParent.clsvar
    TestParent.clsvar = 43
    assert TestParent.clsvar == 43  # This call should hit the cache

# Generated at 2022-06-12 08:17:51.371384
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    check = []
    class A:
        @lazyclassproperty
        def a(cls):
            check.append(cls)
    class B(A):
        pass
    assert A.a is B.a
    assert check == [A]
    assert check == [A]



# Generated at 2022-06-12 08:17:57.048108
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test1(object):
        @lazyperclassproperty
        def a(cls):
            print("Define a " + cls.__name__)
            return "A for " + cls.__name__ + "!"
    class Test2(Test1):
        pass
    class Test3(Test2):
        pass

    print(Test1().a)
    print(Test2().a)
    print(Test3().a)
    print(Test3().a)

# Generated at 2022-06-12 08:18:06.824713
# Unit test for function lazyclassproperty