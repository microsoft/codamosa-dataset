

# Generated at 2022-06-12 08:09:31.847181
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    a = A()
    assert a.foo == 'foo'


# Generated at 2022-06-12 08:09:39.749468
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def some_attr(cls):
            print('A class is run')
            return 'some_attr_A'

    class B(A):
        @lazyperclassproperty
        def some_attr(cls):
            print('B class is run')
            return 'some_attr_B'

    class C(A):
        @lazyperclassproperty
        def some_attr(cls):
            print('C class is run')
            return 'some_attr_C'

    print(A.some_attr)
    print(B.some_attr)
    print(C.some_attr)


# Generated at 2022-06-12 08:09:48.073104
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class User(object):
        """
        Users of lazyperclassproperty must subclass object.
        """

        @lazyperclassproperty
        def unique_instance(cls):
            return "hello"

    class Student(User):
        pass

    class Teacher(User):
        pass

    assert User.unique_instance == "hello"
    assert Student.unique_instance == "hello"
    assert Teacher.unique_instance == "hello"
    assert User.unique_instance == "hello"
    assert Student.unique_instance == "hello"
    assert Teacher.unique_instance == "hello"
    User.unique_instance = "world"
    assert User.unique_instance == "world"
    assert Student.unique_instance != "world"
    assert Teacher.unique_instance != "world"



# Generated at 2022-06-12 08:09:52.382933
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test function lazyclassproperty
    """
    class Foo(object):
        @lazyclassproperty
        def AMsg(cls):
            return "Hello"

    class Bar(Foo):
        pass
    assert Foo.AMsg == 'Hello'
    assert Bar.AMsg == 'Hello'



# Generated at 2022-06-12 08:09:54.915851
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def a(cls):
            return 1

    assert Test.a == 1
    Test.a = 2
    assert Test.a == 2



# Generated at 2022-06-12 08:10:01.906593
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    class D(C):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'
    assert D.x == 'y'



# Generated at 2022-06-12 08:10:07.234219
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.x = 1

        @lazyperclassproperty
        def y(cls):
            return cls.x * 2

    class B(A):
        x = 2

    class C(A):
        pass

    class D(B):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    assert a.y == 2
    assert b.y == 4
    assert c.y == 2
    assert d.y == 4



# Generated at 2022-06-12 08:10:12.317189
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def x(cls):
            print("ceval")
            return 42

    assert C.x == 42
    assert C.x == 42
    del C.x
    assert C.x == 42
    assert C.x == 42



# Generated at 2022-06-12 08:10:22.943143
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(self):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(self):
            return 'c'

    class D(A):
        @lazyperclassproperty
        def x(self):
            return 'd'

        @classproperty
        def y(self):
            return 'y'

    class E(object):
        @lazyperclassproperty
        def x(self):
            return 'x'

    class F(E):
        pass

    class G(E):
        @lazyperclassproperty
        def x(self):
            return 'c'


# Generated at 2022-06-12 08:10:33.999127
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from pprint import pprint

    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            # print('Hello from {}, __mro__={}'.format(cls, cls.__mro__))
            return [random.randint(0, 100) for i in range(10)]

    class A(Foo): pass
    class B(A): pass
    class C(A): pass

    a, b, c = A(), B(), C()

    assert a.bar is b.bar is c.bar is A.bar
    assert A.bar is not B.bar is not C.bar

    pprint([a, b, c])


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:10:40.537395
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Obj():
        @lazyperclassproperty
        def foo(cls):
            return cls
    assert Obj.foo is Obj
    class Obj2(Obj):
        pass
    assert Obj2.foo is Obj
    assert Obj.foo is not Obj2.foo


# Generated at 2022-06-12 08:10:43.271295
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 'test'

    print(A.test)
    print(A.test)



# Generated at 2022-06-12 08:10:50.833542
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def func(cls):
            return lambda x: x

    class B(A):
        pass

    assert A.func is B.func

    a_func = A.func
    b_func = B.func

    assert a_func(3) == 3
    assert b_func(5) == 5

    assert a_func is A.func
    assert b_func is B.func



# Generated at 2022-06-12 08:10:54.705962
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def prop(cls):
            return "value"

    assert A.prop == "value"
    assert A().prop == "value"

    class B(A):
        pass

    assert B.prop == "value"
    assert B().prop == "value"
    assert A.prop == "value"



# Generated at 2022-06-12 08:11:00.920597
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('test_lazyperclassproperty')

    class A(object):
        @lazyperclassproperty
        def value(cls):
            print('A:value')
            return 1

        @classproperty
        def value2(cls):
            print('A:value2')
            return 2

        @property
        def value3(self):
            print('A:value3')
            return 3

    class B(A):
        @lazyperclassproperty
        def value(cls):
            print('B:value')
            return 4

    class C(A):
        pass

    assert A.value == 1
    assert B.value == 4
    assert C.value == 1
    assert A().value == 1
    assert B().value == 4
    assert C().value == 1


# Generated at 2022-06-12 08:11:06.365371
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Example(object):
        @lazyclassproperty
        def example(cls):
            print("Calc example")
            return 'example'

    print(Example.example)
    print(Example.example)
    print('---')

    class Example2(Example):
        pass

    print(Example2.example)
    print(Example2.example)



# Generated at 2022-06-12 08:11:13.765350
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    _test = []

    class MyClass(object):
        @lazyclassproperty
        def test_property(cls):
            _test.append(1)
            return 'TEST'

    # Check that it works as a property
    assert MyClass.test_property == 'TEST'

    # Check that it's not called more than once
    assert len(_test) == 1

    # Check that it works on inherited classes
    class MySubclass(MyClass):
        pass

    assert MySubclass.test_property == 'TEST'

    # Check that it's not called more than twice
    assert len(_test) == 2



# Generated at 2022-06-12 08:11:17.510712
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:22.885359
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class c:
        @lazyperclassproperty
        def a(cls):
            return "Hi"

    class d(c):
        pass

    class e(c):
        pass


# Generated at 2022-06-12 08:11:25.253160
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def foo(klass):
            return 'bar'
    assert Test.foo == 'bar'


# Generated at 2022-06-12 08:11:33.024925
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
       @lazyclassproperty
       def foo(cls):
           return 'bar'

    assert A.foo == 'bar'
    assert A.__dict__['_lazy_foo'] == 'bar'



# Generated at 2022-06-12 08:11:40.643405
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        def __init__(self):
            self.ret_value = 0

        @lazyclassproperty
        def prop(cls):
            return self.ret_value

    class Test2(Test):
        def __init__(self):
            super(Test2, self).__init__()
            self.ret_value = 2

    assert Test.prop == 0
    assert Test2.prop == 2
    self.ret_value = 1
    assert Test.prop == 0
    assert Test2.prop == 2



# Generated at 2022-06-12 08:11:50.539737
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(self):
            return self

        @lazyperclassproperty
        def bar(self):
            return self

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        @lazyperclassproperty
        def foo(self):
            return self

    assert A().foo is A()
    assert B().foo is B()
    assert C().foo is C()
    assert D().foo is D()

    assert A().bar is A()
    assert B().bar is B()
    assert C().bar is C()

    assert A.foo is A
    assert B.foo is B
    assert C.foo is C
    assert D.foo is D

    assert A.bar is A
    assert B.bar

# Generated at 2022-06-12 08:11:55.913777
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return "base"

    assert Base.foo == "base"

    class Derived(Base):
        pass

    assert Derived.foo == "base"

    class Derived(Base):
        @lazyperclassproperty
        def foo(cls):
            return "derived"

    assert Base.foo == "base"
    assert Derived.foo == "derived"



# Generated at 2022-06-12 08:12:02.217011
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class C(object):
        # testing with a callable for later modification
        def get_value(self):
            return 42
        value = lazyclassproperty(get_value)

    assert C.value == 42

    def get_value():
        return 24
    C.get_value = get_value
    C.value = None

    assert C.value == 24
    c = C()
    assert c.value == 24


# Generated at 2022-06-12 08:12:09.232639
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    f1 = lazyperclassproperty(lambda cls: len(cls.__name__))
    f2 = lazyperclassproperty(lambda cls: len(cls.__name__))
    # verify that lazyperclassproperty is per-class
    assert f1.__get__(None, str) != f1.__get__(None, list)
    assert f2.__get__(None, str) != f2.__get__(None, list)
    assert f1.__get__(None, str) == f2.__get__(None, str)
    assert f1.__get__(None, list) == f2.__get__(None, list)


# Generated at 2022-06-12 08:12:18.887826
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:12:26.747185
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def meaning_of_it_all(cls):
            return 42


    assert Foo.meaning_of_it_all == 42
    assert Foo().meaning_of_it_all == 42
    assert Foo.meaning_of_it_all == 42

    class Foo2:
        @lazyclassproperty
        def meaning_of_it_all(cls):
            return 43


    assert Foo2.meaning_of_it_all == 43
    assert Foo2().meaning_of_it_all == 43
    assert Foo2.meaning_of_it_all == 43



# Generated at 2022-06-12 08:12:29.766426
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

  

# Generated at 2022-06-12 08:12:38.294820
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test a property that maintains its own cache, and is scoped to the individual class.
    """

    class TestClass(object):

        def __init__(self):
            self.foo = None

        @lazyperclassproperty
        def LAZY(cls):
            return "LazyValue"

        @classproperty
        def value_1(cls):
            assert cls.LAZY == "LazyValue"
            return cls.LAZY

        @classproperty
        def value_2(cls):
            assert cls.LAZY == "LazyValue"
            return cls.LAZY

        @property
        def value_3(self):
            assert self.LAZY == "LazyValue"
            return self.LAZY


# Generated at 2022-06-12 08:12:52.776124
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:12:58.431819
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'test'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 'test2'

    class D(A):
        pass

    assert B.a == 'test'
    assert C.a == 'test2'
    assert D.a == 'test'

# Generated at 2022-06-12 08:13:08.614788
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, name):
            self.name = name

        @lazyperclassproperty
        def value(cls):
            return [cls.__name__]

    class B(A):
        pass

    class C(A):
        pass

    assert A.value is B.value
    assert A.value is not C.value
    assert C.value is B.value

    a = A('a')
    a.value.append(a.name)
    assert A.value == ['A', 'a']
    b = B('b')
    b.value.append(b.name)
    assert A.value == ['A', 'a', 'b']
    assert B.value == ['B', 'a', 'b']

    c = C('c')

# Generated at 2022-06-12 08:13:12.486313
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:19.655174
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    from nose.tools import assert_equal

    class TestA:
        test_value = "Hello"
        def __init__(self, *args, **kwargs):
            self.value = self.__class__.test_value
        @lazyclassproperty
        def test_func(cls):
            return str(cls.__name__)

    class TestB(TestA):
        test_value = "World"

    assert_equal(TestA().test_func, "TestA")
    assert_equal(TestB().test_func, "TestB")

# Generated at 2022-06-12 08:13:25.785678
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class AClass(object):
        @lazyclassproperty
        def a_prop(cls):
            return "a_prop"

    class BClass(AClass):
        pass

    assert AClass.a_prop == "a_prop"
    assert BClass.a_prop == "a_prop"
    AClass.a_prop = "a"
    assert AClass.a_prop == "a"
    assert BClass.a_prop == "a"



# Generated at 2022-06-12 08:13:30.461591
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == A.foo
    assert A().foo == A().foo
    assert A.foo == 'foo'

    class B(A):
        pass

    assert B.foo == B.foo
    assert B().foo == B().foo
    assert B.foo == 'foo'


# Generated at 2022-06-12 08:13:38.017560
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('Set prop')
            return 3

    class B(A):
        x = A.prop

        @classproperty
        def prop(cls):
            return A.prop + 1

    class C(B):
        pass

    assert A.prop == B.prop == C.prop == 3
    assert A.x == B.x == C.x == 3



# Generated at 2022-06-12 08:13:47.370427
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            self.calls = -1
            self.answer = 42

        @lazyclassproperty
        def answer(cls):
            cls.calls += 1
            return cls.answer

    a = A()
    b = A()

    assert a.calls == -1
    assert a.answer == 42
    assert a.calls == 0
    assert b.calls == -1
    assert b.answer == 42
    assert b.calls == 0
    assert a.answer == 42
    assert a.calls == 0
    assert b.answer == 42
    assert b.calls == 0



# Generated at 2022-06-12 08:13:56.431409
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def p(cls):
            print(cls)
            return cls
    class Derived(Base): pass
    class Derived2(Base): pass
    b = Base()
    d = Derived()
    d2 = Derived2()
    e = Base()
    print(Base.p)
    print(Derived.p)
    print(Derived2.p)
    assert not Base.p is Derived.p and not Derived.p is Derived2.p, 'expected property to be different for the three classes'
    assert Base.p is e.p, 'expected the same property for instances of the same class'
    print('SUCCESS')
    print(b.p)
    print(d.p)

# Generated at 2022-06-12 08:14:23.120133
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        def __init__(self, val):
            self.val = val

        @lazyclassproperty
        def prop(cls):
            return cls.val

    class B(A):
        pass

    b = B('B')
    b2 = B('B2')
    assert b.prop == 'B'
    assert b2.prop == 'B2'     # <--- fails for https://github.com/python/mypy/issues/1465



#
# class Genericmethod(object):
#     """
#     For defining a method in a class, but with a different calling syntax:
#     def f(self, x):
#         print(x)
#     g = Genericmethod(f)
#     g()             # gives error
#     g(1, 2, 3)     

# Generated at 2022-06-12 08:14:26.603490
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def prop(cls):
            return set()

    t1 = Test()
    t2 = Test()
    t1.prop.add(0)
    assert 0 in t1.prop
    assert 0 not in t2.prop

    t2.prop.add(1)
    assert 1 in t2.prop
    assert 1 not in t1.prop


# Generated at 2022-06-12 08:14:30.677301
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 42

    assert A.a == 42
    A.a = 100
    assert A.a == 42
    assert not hasattr(A, '_a')

    class B(A):
        pass

    assert B.a == 42
    B.a = 100
    assert B.a == 100
    assert not hasattr(B, '_a')

# Generated at 2022-06-12 08:14:37.401252
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Example(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c


# Generated at 2022-06-12 08:14:40.760147
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def a(cls):
            print("a")
            return 1

    assert TestClass.a() == 1
    assert TestClass.a() == 1
    assert TestClass.a() == 1
    assert TestClass.a() == 1
    assert TestClass.a() == 1
    assert TestClass.a() == 1

    assert TestClass.a == 1



# Generated at 2022-06-12 08:14:44.330871
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    a = A()
    b = B()

    assert a.a == b.a == 'a'



# Generated at 2022-06-12 08:14:51.838860
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:15:00.166945
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def _lazyprop(cls):
            return cls.name

        @property
        def name(cls):
            return 'Base'

    class A(Base):
        @property
        def name(cls):
            return 'A'

    class B(Base):
        @property
        def name(cls):
            return 'B'

    class C(A):
        @property
        def name(cls):
            return 'C'

    class D(C):
        @property
        def name(cls):
            return 'D'


# Generated at 2022-06-12 08:15:10.024370
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class AClass:
        a = 1

        def __init__(self):
            self.b = 2

        @lazyclassproperty
        def c(cls):
            print("Initializing c")
            return cls.a * cls.b

        @classproperty
        @cached
        def d(cls):
            print("Initializing d")
            return cls.a * cls.b

    print("Getting AClass.c")
    print(AClass.c)
    print(AClass.c)

    print("Getting AClass.d")
    print(AClass.d)
    print(AClass.d)

    inst = AClass()
    print("Getting inst.c")
    print(inst.c)
    print(inst.c)

    print("Getting inst.d")
    print

# Generated at 2022-06-12 08:15:12.898699
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        a = 1

        @lazyperclassproperty
        def b(self):
            return self.a + 100

    class B(A):
        a = 2

    assert B().b == 102
    assert A().b == 101



# Generated at 2022-06-12 08:16:04.361232
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self._value = None

        @lazyperclassproperty
        def value(cls):
            return cls._value

    assert (A.value is None)
    assert (A().value is None)
    A._value = 1
    assert (A.value == 1)
    assert (A().value == 1)

    class B(A):
        pass

    assert (B.value is None)
    assert (B().value is None)
    A._value = 2
    assert (A.value == 2)
    assert (A().value == 2)
    assert (B.value == 1)
    assert (B().value == 1)



# Generated at 2022-06-12 08:16:11.281957
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class TestA(object):
        def __init__(self, _a):
            self.a = _a

    class TestB(TestA):
        def __init__(self, _a, _b):
            super(TestB, self).__init__(_a)
            self.b = _b


# Generated at 2022-06-12 08:16:17.006980
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def a(self):
            return "test"

    test = Test()
    Test.a   # Calling Test.a once
    test.a   # Calling test.a once
    Test.__dict__['a']   # Calling Test.a once
    test.__dict__['a']   # Calling test.a once
    assert_equal(Test.a, test.a)   # Test.a and test.a should be the same object



# Generated at 2022-06-12 08:16:22.165936
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return 123

    class Bar(Foo):
        pass

    assert Foo.bar == 123
    assert Bar.bar == 123

    assert isinstance(Foo.bar, int)
    assert isinstance(Bar.bar, int)


# Generated at 2022-06-12 08:16:29.772165
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            return [1, 2, 3]

    assert(C.x == [1, 2, 3])
    C.x[0] = 'x'
    assert(C.x == ['x', 2, 3])
    C.x = 'foobar'
    assert(C.x == ['x', 2, 3])

    class D(C):
        pass

    assert(C.x == [1, 2, 3])
    assert(D.x == [1, 2, 3])
    D.x[0] = 'x'
    assert(C.x == [1, 2, 3])
    assert(D.x == ['x', 2, 3])



# Generated at 2022-06-12 08:16:37.493520
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'prop'

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return 'prop'

    class D(A):
        @staticmethod
        def prop():
            return 'prop'

    assert A.prop == 'prop'
    assert B.prop == 'prop'
    assert C.prop == 'prop'
    assert D.prop == 'prop'
    assert issubclass(B, A)
    assert not issubclass(A, B)
    assert not issubclass(C, B)
    assert not issubclass(B, C)
    assert issubclass(B, D)
    assert issubclass(A, D)
   

# Generated at 2022-06-12 08:16:40.343235
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def my_property(cls):
            print("calculating ...")
            return 'some value'

    # The first time it prints 'calculating...' and remembers the value
   

# Generated at 2022-06-12 08:16:47.755261
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass:
        @lazyclassproperty
        def x(cls):
            print('x', cls)
            return 'foo'

        @lazyclassproperty
        def y(cls):
            print('y', cls)
            return 'foo'

    class MyClass2(MyClass):
        pass

    assert MyClass.x == 'foo'
    assert MyClass2.x == 'foo'
    assert MyClass2.y == 'foo'
    assert MyClass.y == 'foo'



# Generated at 2022-06-12 08:16:54.505050
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:59.910471
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyclassproperty
        def func_simple(cls):
            return 1

        @lazyperclassproperty
        def func_perclass(cls):
            return 2

    class B(A):
        pass

    class C(A):
        pass

    assert A.func_simple == 1
    assert B.func_simple == 1
    assert C.func_simple == 1
    assert A.func_perclass == 2
    assert B.func_perclass == 2
    assert C.func_perclass == 2

# Generated at 2022-06-12 08:18:51.014963
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def get_rand_num(cls):
            return random.randint(0, 1000)

    a = A()
    b = A()
    assert a.get_rand_num == b.get_rand_num
    A.get_rand_num
    c = A()
    assert a.get_rand_num != c.get_rand_num



# Generated at 2022-06-12 08:18:54.958644
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Bird:
        @lazyclassproperty
        def wingspan(cls):
            return 20

    class Eagle(Bird):
        pass

    class Penguin(Bird):
        @lazyclassproperty
        def wingspan(cls):
            return 5

    assert Bird.wingspan == 20
    assert Eagle.wingspan == 20
    assert Penguin.wingspan == 5



# Generated at 2022-06-12 08:19:03.510540
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 1

        @lazyclassproperty
        def foo_bar(cls):
            return 2

    assert Foo.bar == 1
    assert Foo.foo_bar == 2
    assert Foo.bar == 1
    assert Foo.foo_bar == 2

    class Foo2(Foo):
        pass

    assert Foo2.bar == 1
    assert Foo2.foo_bar == 2
    assert Foo2.bar == 1
    assert Foo2.foo_bar == 2

    assert Foo.bar == 1
    assert Foo.foo_bar == 2
    assert Foo.bar == 1
    assert Foo.foo_bar == 2



# Generated at 2022-06-12 08:19:12.452828
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        # @lazyclassproperty
        # def lazy_1(cls):
        #     print("call lazy_1")
        #     return "lazy_1"
        #
        # @lazyclassproperty
        # def lazy_2(cls):
        #     print("call lazy_2")
        #     return "lazy_2"

        @lazyclassproperty
        def lazy_1(cls):
            print("call lazy_1")
            return "lazy_1"

        @lazyclassproperty
        def lazy_2(cls):
            print("call lazy_2")
            return "lazy_2"

    a = A()
    print("1=", a.lazy_1)
    print("2=", a.lazy_2)

# Generated at 2022-06-12 08:19:19.796258
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:19:23.939354
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def foo(cls):
            print("Calculating foo...")
            return "FOO"

        @lazyclassproperty
        def bar(cls):
            print("Calculating bar...")
            return "BAR"

    assert Test.foo == 'FOO'
    assert Test.bar == 'BAR'

    class TestSub(Test):
        pass

    assert TestSub.foo == 'FOO'
    assert TestSub.bar == 'BAR'



# Generated at 2022-06-12 08:19:31.035798
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(cls):
            return 1

    class C(A):
        pass

    assert A.b == 1
    assert C.b == 1

    # Change A.b won't affect C.b
    A.b = 2
    assert A.b == 2
    assert C.b == 1

    # Change C.b won't affect A.b
    C.b = 3
    assert A.b == 2
    assert C.b == 3